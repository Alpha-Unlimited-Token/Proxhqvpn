================================================================================
  QUANTUMAUDIT — SUSPICIOUS PATTERNS & RED FLAG SUMMARY
  Case Reference: QA-2026-0503-GK4-9rN
  Generated: 2026-05-03  |  Platform: ProxHQ VPN / QuantumAudit v2
================================================================================

This document consolidates all anomalous patterns, red flags, and suspicious
behaviors detected across the full investigation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 1 — DELIBERATE ON-CHAIN LAYERING  [CRITICAL]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallet Affected:  GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR

  What Was Found:
  The wallet's funding chain passes through two consecutive throwaway relay
  wallets that each existed for under 2 minutes before emptying completely:

    Relay 1 (7ywV56em…)   →  existed 79 SECONDS  →  now 0 SOL
    Relay 2 (6x7mout1…)   →  existed ~2 minutes  →  now 0 SOL

  Why This Is Significant:
  Throwaway relay wallets are a known on-chain obfuscation technique used to:
  • Break forensic tracing chains
  • Create plausible deniability between the source and destination
  • Make fund-origin analysis computationally and legally harder
  • Simulate the "layering" phase of traditional money laundering

  The 79-second existence of relay 7ywV56em… is consistent with automated
  layering infrastructure — no human is manually creating, funding, and
  abandoning a wallet in 79 seconds.

  Severity:  CRITICAL
  Action:    Report these relay wallet addresses to exchange compliance teams.
             If either wallet deposited from or withdrew to a CEX, KYC data
             may identify the operator.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 2 — SINGLE AUTOMATED BOT CONTROLS BOTH WALLET AND POOL  [CRITICAL]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallets Affected:  Both GK4 and 9rNuQiN1

  What Was Found:
  A single automated address — 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
  — appears in the background infrastructure of BOTH wallets:
  • Its bot network chain funded GK4's creation (through intermediaries)
  • It directly deployed and seeded the 9rN liquidity pool with 69 SOL

  This address holds 13,975 SPL token accounts — definitively non-human.

  Why This Is Significant:
  One automated operator is simultaneously:
  1. Seeding user wallets with startup SOL
  2. Deploying and providing liquidity to AMM pools
  3. Doing so using Jito MEV bundles for priority execution

  This pattern is consistent with a coordinated market-making or token
  manipulation operation where the same entity controls both the trading
  infrastructure (the pool) and some of the wallets interacting with it.

  Severity:  CRITICAL
  Action:    Investigate whether 54Pz1e35… is connected to any known
             market manipulation or wash trading operations.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 3 — $1.63M WHALE WITH 35% TRANSACTION FAILURE RATE  [HIGH]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallet Affected:  GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR (funder)

  What Was Found:
  The direct funder of GK4 (5ndLnEYq…) holds 11,491 SOL (~$1.63M) but
  fails 35.2% of its transactions. Normal DeFi users fail <5% of txs.
  A 35.2% failure rate indicates:
  • An aggressive front-running or sandwich attack bot losing competitive races
  • A high-frequency market-maker under extreme competition pressure
  • An automated system trying to execute before other bots and frequently losing

  The wallet also "appeared" fresh today (2026-05-03) despite having 1,000+
  recent transactions — confirming it cycles through wallet addresses regularly.

  Severity:  HIGH
  Action:    Flag 5ndLnEYq… to exchange compliance teams as a potential
             high-frequency market manipulation address.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 4 — CONFIRMED MEV BOT EXTRACTING FROM POOL AND WALLETS  [HIGH]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallets Affected:  9rNuQiN1 pool (direct), GK4 transactions (indirect)

  What Was Found:
  Address 6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN is a confirmed
  MEV (Maximal Extractable Value) extraction bot:
  • Receives SOL from the 9rN pool's swap transactions
  • Appears in wallet trace history co-executing in Jito bundles
  • Current balance: 10.189 SOL  (accumulated MEV profit)
  • Active today  (2026-05-03)

  Why This Is Significant:
  Any user trading through the 9rN pool is paying a hidden MEV tax on each
  transaction — the bot extracts a small amount per swap through sandwich
  attacks or arbitrage. This is a known issue with AMMs but confirms the
  pool is actively being front-run.

  Severity:  HIGH
  Action:    Users trading on this pool should use MEV protection (Jito
             Don't Front / private RPC) to minimize extraction losses.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 5 — ANONYMOUS OPERATION WITH NO IDENTITY LINKAGE  [MEDIUM]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallets Affected:  All wallets in this investigation

  What Was Found:
  Every wallet and bot address encountered in this investigation:
  • Has no registered Solana Name Service (SNS) domain
  • Appears in no public analytics labels (Solscan, DeFi Llama, Birdeye)
  • Has no social media or internet presence linkage
  • Is not associated with any known exchange deposit address
  • Is not on any OFAC or international sanctions list (checked)

  Why This Is Significant:
  The complete absence of any identity signal across all addresses suggests
  deliberate operational security (OPSEC) practices by the operator(s).
  This is consistent with either privacy-conscious but legal DeFi activity,
  or actors deliberately avoiding identity attribution.

  Severity:  MEDIUM
  Action:    Identity cannot be established through public on-chain or
             internet data. Legal subpoena of CEX records is required.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 6 — GK4 POSITIONED IN USDT  (exit preparation signal)  [MEDIUM]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallet Affected:  GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR

  What Was Found:
  GK4's final transaction (2026-05-02) was a complete conversion of
  remaining SOL to USDT via an Orca Whirlpool swap. The wallet now holds:
  • 96.878711 USDT  (stablecoin — immune to crypto price volatility)
  • 0.414 SOL  (minimal, likely for future gas fees)

  Why This Is Significant:
  Converting to USDT as a final position typically signals one of:
  1. Profit-taking — converting speculative gains to stable value
  2. Exit preparation — positioning for withdrawal to a CEX or bridge
  3. Waiting period — holding stable for the next trading opportunity

  The wallet has been dormant 24+ hours since this conversion.

  Severity:  MEDIUM
  Action:    Monitor GK4 for any USDT transfers to known CEX deposit
             addresses or cross-chain bridge contracts. If USDT moves
             to an exchange, a subpoena of that exchange would link
             this wallet to a real-world identity.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PATTERN 7 — BOT-DEPLOYED PUMPFUN POOL — POTENTIAL RUG RISK  [MEDIUM]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Wallet Affected:  9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY  (pool)

  What Was Found:
  The 9rN AMM pool was deployed by an automated bot (54Pz1e35…) using
  Jito MEV bundles on 2026-04-25. The pool contains 74.71 SOL of
  liquidity for a PumpFun-launched token.

  Why This Is Significant:
  PumpFun-launched tokens are frequently created and abandoned after
  a rapid price pump. The pool deployer (the bot) can withdraw all
  liquidity at any time — the 69+ SOL of initial liquidity could be
  removed in a single transaction (a "rug pull"), causing the token
  price to collapse to zero. Traders who hold this token would be left
  with worthless assets.

  The token itself (DFPGnoo…pump) has no verified identity, whitepaper,
  team disclosure, or locked liquidity.

  Severity:  MEDIUM
  Action:    Treat the paired token as high-risk speculative asset.
             Do not hold significant positions in DFPGnoo…pump without
             understanding rug-pull risk.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CLEAN CHECKS (no issues found)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ✓ GK4 — No token freeze authority exposure detected
  ✓ GK4 — No delegate abuse (no third-party token delegates set)
  ✓ GK4 — No unauthorized close authority on token accounts
  ✓ GK4 — No known drainer contract interactions
  ✓ GK4 — No OFAC / international sanctions match
  ✓ GK4 — No CEX withdrawal address pattern linking to known bad actors
  ✓ All addresses — No sanctioned counterparties in transaction sets

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RECOMMENDED ACTIONS (PRIORITY ORDER)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  PRIORITY 1 — Submit relay wallet addresses to major CEX compliance
    Addresses: 7ywV56em…  |  6x7mout1…
    Purpose: Determine if either wallet received funds from or sent funds
    to a centralized exchange. If so, a legal subpoena of that exchange's
    KYC records would identify the human operator.

  PRIORITY 2 — Monitor GK4 for USDT movement
    Address: GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR
    Purpose: If the 96.87 USDT is moved to a CEX, a subpoena would link
    this wallet to a real identity. Set up on-chain monitoring.

  PRIORITY 3 — Submit bot address to exchange compliance
    Address: 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
    Purpose: This bot deployed the pool and seeded multiple wallets.
    Exchanges may have KYC on wallet addresses that interacted with it.

  PRIORITY 4 — Flag MEV bot to Jito Labs
    Address: 6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN
    Purpose: Jito may have submission metadata (IP/timestamp) for MEV
    bundle transactions from this address.

================================================================================
  END OF SUSPICIOUS PATTERNS REPORT
================================================================================
