================================================================================
  QUANTUMAUDIT — POOL / ACCOUNT INTELLIGENCE REPORT
  Case Reference: QA-2026-0503-9rN
  Generated: 2026-05-03  |  Platform: ProxHQ VPN / QuantumAudit v2
================================================================================

TARGET: 9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY
CHAIN:  Solana Mainnet
SCAN:   Full — account identification, pool analysis, back-trace, forward-trace

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SECTION 1 — ACCOUNT IDENTIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  IMPORTANT: This is NOT a user wallet.

  Address:          9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY
  Account Type:     SPL TOKEN ACCOUNT — Wrapped SOL (wSOL) pool reserve vault
  Owner Program:    TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA (Token Program)
  Mint Held:        So11111111111111111111111111111111111111112  (Wrapped SOL)
  SOL Equivalent:   74.70804233 wSOL  (= 74.71 SOL ≈ $10,609 USD)
  Pool Authority:   6TpBkWtgqwGeTCi35Fwgi5vsKPzqPXdeboN5jrYdDTT6
  Authority Owner:  pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA  (Pump AMM)
  Is Executable:    No

  WHAT THIS MEANS:
  This address is the wSOL (Wrapped SOL) reserve vault for a PumpFun
  Automated Market Maker (pAMMBay6) liquidity pool. Every transaction
  on this account is a trader either:
    • BUYING the paired token with SOL  → SOL balance increases
    • SELLING the paired token for SOL  → SOL balance decreases

  The 74.71 SOL inside is NOT controlled by any single user — it is
  pooled liquidity managed by the Pump AMM smart contract.

  TOKEN PAIR:
  This pool facilitates swaps between:
    SOL  ↔  DFPGnooMjWMttYGF2Pegmsp4Vj2VFhLyrxc5Cp1wpump
             (a PumpFun-launched token)

  POOL STATISTICS:
  ┌──────────────────────────────────────────────────────────────────────┐
  │ SOL at Launch (2026-04-25):  69.191 SOL                             │
  │ SOL at Scan  (2026-05-03):   74.710 SOL  (+7.97% — growing pool)   │
  │ Total Transactions:          1,000+  (query limit hit; real # higher)│
  │ Failed Transactions:         140  (14.0% failure rate)              │
  │ Average Daily Volume:        ~125 txs/day over 8 days               │
  │ Pool Status:                 ACTIVE  (last tx: 2026-05-03 14:49:15) │
  │ MEV Bundles:                 CONFIRMED  (Jito bundles present)      │
  └──────────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SECTION 2 — BACK-TRACE  (who created this pool and where did the SOL come from)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  POOL CREATION EVENT:
  Date/Time:   2026-04-25  13:25:13 UTC
  Created By:  54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
  SOL Seeded:  69.191 SOL  (initial liquidity deposited at launch)
  Method:      Jito MEV bundle  (jitonobundLe1111… present in creation tx)

  ──────────────────────────────────────────────────────────────────────────
  POOL DEPLOYER PROFILE — 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
  ──────────────────────────────────────────────────────────────────────────
  Current Balance:  97.489 SOL
  Token Accounts:   13,975  ← definitively automated / non-human
  Account Owner:    System Program  (wallet address)
  Classification:   High-volume DeFi bot / automated liquidity deployer
  Failure Pattern:  High — consistent with aggressive automated system

  Significance:
  13,975 SPL token accounts is far beyond any human-operated wallet.
  This is an automated system that deploys liquidity pools, manages
  positions across thousands of tokens simultaneously, and uses Jito
  bundles to ensure priority transaction execution. This entity both
  created and seeded this pool with 69 SOL on April 25.

  ──────────────────────────────────────────────────────────────────────────
  POOL DEPLOYER'S OWN ORIGIN — Cannot be traced further
  ──────────────────────────────────────────────────────────────────────────
  54Pz1e35… returns 0 queryable transaction history despite holding
  97 SOL and 13,975 token accounts. This indicates the address predates
  the RPC transaction history window, or the bot cycles wallet addresses.
  The ultimate human operator behind this bot cannot be identified from
  public on-chain data alone.

  CREATION TRANSACTION — KEY PARTICIPANTS:
  ┌────────────────────────────────────────────────────────┬─────────────────┐
  │ Address (truncated)                                    │ Role            │
  ├────────────────────────────────────────────────────────┼─────────────────┤
  │ 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy        │ Pool deployer   │
  │ pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA          │ Pump AMM prog   │
  │ jitonobundLe1111111111111111111111111111123            │ Jito MEV relay  │
  │ proVF4pMXVaYqmy4NjniPh4pqKNfMmsihgd4wdkCX3u          │ Jito validator  │
  │ DFPGnooMjWMttYGF2Pegmsp4Vj2VFhLyrxc5Cp1wpump        │ Pool token mint │
  │ 3YANG71Bk8rXmaekTTnT6qMq28y3rFkKbELadzsDsj41        │ Jito tip acct   │
  │ EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v        │ USDC mint       │
  │ CASHx9KJUStyftLFWGvEVf59SGeG9sh5FfcnZMVPCASH        │ CASH token      │
  │ pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ         │ PumpFun fee     │
  │ ALPHAQmeA7bjrVuccPsYPiCvsi428SNwte66Srvs4pHA         │ ALPHA protocol  │
  │ MNFSTqtC93rEfYHB6hF82sKdZpUDFWkViLByLd1k1Ms         │ Manifest DEX    │
  └────────────────────────────────────────────────────────┴─────────────────┘

  BACK-TRACE VERDICT:
  ┌──────────────────────────────────────────────────────────────────────┐
  │ ORIGIN: Automated bot 54Pz1e35… deployed this pool on 2026-04-25.   │
  │ The bot's own funding source is untraceable from public data.       │
  │ The 69.19 SOL seeded into this pool came from bot operations        │
  │ that predate the available transaction history window.              │
  └──────────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SECTION 3 — FORWARD-TRACE  (who receives SOL from this pool)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  NOTE: SOL exits this pool when traders sell tokens. SOL enters when
  traders buy tokens. The analysis below covers 50 sampled transactions.

  TOP SOL RECIPIENTS FROM POOL (token sellers receiving SOL back):
  ┌─────────────────────────────────────────────────────────────────────────┐
  │                                                                         │
  │  F7mrwLgcKAnGgDBYXRmGFay1eAi8UyQuX7Fs6eYKM9Em                        │
  │  SOL Received:  0.01365 SOL  (2026-05-03 14:49:15)                    │
  │  Balance:       0.050 SOL  |  10 txs  |  2 token accounts             │
  │  Classification: Active user wallet — token seller                    │
  │                                                                         │
  │  6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN  ← MEV BOT           │
  │  SOL Received:  0.000525 SOL  (2026-05-03 12:53:48)                  │
  │  Balance:       10.189 SOL  |  10 txs                                 │
  │  Classification: Confirmed MEV extraction bot. This address           │
  │                  co-executes with pool transactions to extract         │
  │                  arbitrage/sandwich profits. (See Suspicious           │
  │                  Patterns report for full MEV bot profile.)            │
  │                                                                         │
  │  Bvtgim23rfocUzxVX9j9QFxTbBnH8JZxnaGLCEkXvjKS                       │
  │  SOL Received:  0.000064 SOL                                          │
  │  Balance:       2,740.734 SOL  (Token Program — large pool vault)     │
  │                                                                         │
  │  BWXT6RUhit9FfJQM3pBmqeFLPYmuxgmyhMGC5sGr8RbA                       │
  │  SOL Received:  0.000281 SOL                                          │
  │  Balance:       845.528 SOL  (Token Program — pool vault)             │
  │                                                                         │
  │  HjQjngTDqoHE6aaGhUqfz9aQ7WZcBRjy5xB8PScLSr8i                       │
  │  SOL Received:  0.000281 SOL  |  Balance: 1.396 SOL                  │
  │                                                                         │
  │  3YANG71Bk8rXmaekTTnT6qMq28y3rFkKbELadzsDsj41                        │
  │  SOL Received:  0.000223 SOL across 2 txs                             │
  │  Classification: Jito tip account — receives MEV bundle tips          │
  │                  Confirms every bundled trade pays Jito validators     │
  └─────────────────────────────────────────────────────────────────────────┘

  TOP SOL SENDERS INTO POOL (buyers purchasing tokens with SOL):
  ┌─────────────────────────────────────────────────────────────────────────┐
  │  63HUkft8L8exXm76gARiwmj2oyqFrETXQXZMSJo6tEQn                        │
  │  SOL Sent:   0.061910553 SOL  into pool  (1 tx in sample)             │
  │  Assessment: Token buyer — purchased DFPGnoo…pump tokens              │
  └─────────────────────────────────────────────────────────────────────────┘

  FORWARD-TRACE VERDICT:
  ┌──────────────────────────────────────────────────────────────────────┐
  │ Pool SOL flows represent normal AMM activity: traders buy and sell   │
  │ the paired PumpFun token. No single entity is systematically         │
  │ draining the pool.                                                   │
  │                                                                      │
  │ CONFIRMED MEV EXTRACTION: Bot 6Wzuv7vL… is co-executing with pool   │
  │ transactions and extracting small amounts per trade. This is         │
  │ sandwich/arbitrage MEV, a known issue with all on-chain AMMs.       │
  │                                                                      │
  │ POOL TREND: Growing (+7.97% since launch) — net buying pressure.   │
  └──────────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SECTION 4 — RISK ASSESSMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ┌──────────────────────────────────────────────────────────────────────┐
  │ SEVERITY MATRIX:   C=0   H=1   M=1   L=0   I=0                      │
  │                                                                      │
  │ [HIGH] Bot-controlled pool deployment                               │
  │   The pool was deployed by an automated system (13,975 token accts) │
  │   using Jito MEV bundles. The pool operator is anonymous and the    │
  │   token (DFPGnoo…pump) may carry rug-pull risk typical of PumpFun  │
  │   tokens — the deployer can remove liquidity at any time.           │
  │                                                                      │
  │ [MEDIUM] Active MEV extraction on all trades                        │
  │   Bot 6Wzuv7vL… is confirmed extracting value from pool swaps.     │
  │   Traders interacting with this pool are paying a hidden MEV tax    │
  │   on top of standard swap fees.                                     │
  └──────────────────────────────────────────────────────────────────────┘

  POOL RISK FACTORS:
  • LIQUIDITY REMOVAL RISK: The pool operator (54Pz1e35…) can withdraw
    the 69+ SOL of initial liquidity at any time (rug-pull risk).
  • TOKEN RISK: PumpFun tokens have no fundamental value guarantee.
  • MEV RISK: All trades are subject to sandwich attack extraction.
  • FAILURE RATE: 14% failure rate indicates competitive bot environment.

================================================================================
  END OF WALLET B / POOL REPORT
================================================================================
