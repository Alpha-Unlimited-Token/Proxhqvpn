================================================================================
  QUANTUMAUDIT — EXECUTIVE SUMMARY
  Case Reference: QA-2026-0503-GK4-9rN
  Generated: 2026-05-03  |  Platform: ProxHQ VPN / QuantumAudit v2
================================================================================

WALLETS INVESTIGATED:
  [A]  GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR
  [B]  9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY
  CHAIN: Solana Mainnet

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RISK RATINGS AT A GLANCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ┌─────────────────────────────────────────────────────────────────────────┐
  │  Wallet A — GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR             │
  │  RISK SCORE:  7.5 / 10   ██████████████░░░░░░   ELEVATED               │
  │  Primary Flag: Funding chain uses two consecutive throwaway relay       │
  │  wallets (each existed under 2 minutes, both now empty). Deliberate    │
  │  layering to obscure original fund source.                              │
  └─────────────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────────────┐
  │  Wallet B — 9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY             │
  │  RISK SCORE:  5.0 / 10   ██████████░░░░░░░░░░   MODERATE               │
  │  Primary Flag: AMM pool deployed and controlled by a high-volume       │
  │  automated bot (13,975 token accounts). MEV extraction confirmed.      │
  │  NOTE: This is NOT a user wallet — it is a liquidity pool vault.       │
  └─────────────────────────────────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  KEY FINDINGS — WALLET A (GK4)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. LAYERED FUNDING CHAIN — DELIBERATE OBFUSCATION
     The wallet was funded through a 3-layer chain specifically designed to
     hide the original source of funds:

     Unknown Origin
       └─► 6x7mout1… [now 0 SOL, untraceable root]
             └─► 7ywV56em… [existed 79 SECONDS then emptied — throwaway relay]
                   └─► 5ndLnEYq… [11,491 SOL DeFi bot, 35% fail rate]
                         └─► GK4 [WALLET A — funded at creation, March 2026]

     The 79-second throwaway relay wallet is a hallmark of automated
     layering infrastructure. Both relay wallets are now completely empty.

  2. WHALE INTERMEDIARY — 5ndLnEYqSFiA5yUFHo6LVZ1eWc6Rhh11K5CfJNkoHEPs
     • Current balance:   11,491 SOL  (~$1.63 million USD)
     • Token accounts:    149
     • Failure rate:      352 of 1,000 recent txs failed  (35.2%)
     • First seen today:  2026-05-03 07:05:56 UTC
     • Behavior:          High-volume DeFi bot / market-maker cycling addresses

  3. CURRENT STATE — GK4 holds 96.877 USDT (stablecoin)
     The wallet converted its SOL holdings to USDT via a Jupiter-routed
     Orca Whirlpool swap. Stablecoin holding suggests: profit-taking,
     positioning for exit, or CEX withdrawal preparation.

  4. 195 TRANSACTIONS, only 1 failed (0.5% failure = skilled operator)
     Uses Jito's anti-frontrunning service. Intermediate DeFi sophistication.

  5. DORMANT — last active 2026-05-02 (24+ hours before scan)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  KEY FINDINGS — WALLET B (9rNuQiN1)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. THIS IS A LIQUIDITY POOL VAULT, NOT A USER WALLET
     9rNuQiN1… holds Wrapped SOL (wSOL) as a PumpFun AMM pool reserve.
     The 74.71 SOL inside is pooled liquidity — traders swap tokens against it.

  2. POOL DETAILS
     • Token pair:   wSOL ↔ DFPGnooMjWMttYGF2Pegmsp4Vj2VFhLyrxc5Cp1wpump
     • Liquidity:    74.71 SOL at scan time (~$10,609 USD)
     • Launched:     2026-04-25 (8 days before this scan)
     • Activity:     1,000+ transactions in 8 days (~125/day)
     • Failure rate: 140/1000 (14%) — active bot competition on the pool

  3. BOT-DEPLOYED POOL
     Created by automated address 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
     (13,975 SPL token accounts — definitively non-human). The same bot
     address appears across multiple wallets in this investigation as a
     common infrastructure node.

  4. MEV EXTRACTION CONFIRMED
     Jito MEV bundles are wrapping trades on this pool. An MEV bot
     (6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN) is confirmed
     extracting value from pool swap transactions.

  5. POOL IS GROWING — net positive liquidity
     Started at 69.19 SOL, grew to 74.71 SOL (+8%) — more buyers than
     sellers in the 8 days since launch.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CRITICAL SHARED INFRASTRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  The two wallets share common automated infrastructure:

  SHARED ADDRESS: 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
  • Appears in back-trace of Wallet A (through the whale intermediary chain)
  • Deployed Wallet B's liquidity pool on 2026-04-25
  • 13,975 token accounts — automated system controlling both operations

  SHARED MEV BOT: 6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN
  • Extracting value from Wallet B's pool swap transactions
  • Current balance: 10.189 SOL (accumulated MEV profit)

  CONCLUSION: Both wallets are part of the same coordinated automated
  operation, sharing bot infrastructure and MEV extraction systems.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  TRACEABILITY ASSESSMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Can we identify the human operator(s)?

  ON-CHAIN DATA ALONE:   NO
  The funding chain uses deliberate throwaway relay wallets. Both
  relay wallets are now zero-balance. The original source of funds
  is beyond public on-chain trace capability.

  WITH CEX RECORDS:      POSSIBLY — if any relay wallet withdrew from or
  deposited to a centralized exchange, KYC data could link to a human.

  WITH PRIVATE RPC LOGS: POSSIBLY — archival node data may contain IP
  metadata associated with transaction broadcasts.

  RECOMMENDED NEXT STEPS:
  1. Submit wallet 5ndLnEYq… and 6x7mout1… to major CEX compliance teams
     requesting KYC lookups on associated deposit/withdrawal addresses.
  2. Subpoena Jito Labs for bundle submission metadata (IP/timestamp).
  3. Subpoena any CEX that may have received the USDT from Wallet A.

================================================================================
  END OF EXECUTIVE SUMMARY — See individual reports for full detail
================================================================================
