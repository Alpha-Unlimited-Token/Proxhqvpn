================================================================================
  QUANTUMAUDIT — FULL ADDRESS LEDGER
  Case Reference: QA-2026-0503-GK4-9rN
  Generated: 2026-05-03  |  Platform: ProxHQ VPN / QuantumAudit v2
================================================================================

Every on-chain address encountered during this investigation is listed below
with its role, current balance, owner type, and risk classification.

Legend:
  ★ = Key address in investigation chain
  ⚠ = Suspicious / anomalous behavior
  🤖 = Identified as automated bot / non-human
  🏦 = Liquidity pool / AMM vault
  🔁 = Throwaway relay / ephemeral wallet

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  INVESTIGATION TARGETS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

★  GK4Note9oHQY84JEtBFBRb6rBS8mSqryFQffdrWv67cR
   Role:          Investigation Target A — User Wallet
   Balance:       0.414624518 SOL + 96.878711 USDT
   Owner:         System Program (user wallet)
   Activity:      2026-03-24 → 2026-05-02  |  195 txs  |  1 failed
   Risk:          ELEVATED — funded through layered throwaway chain

★  9rNuQiN1NKbuaty33iyucCFcSoeUtTyf13AN89KSQ3XY
   Role:          Investigation Target B — PumpFun AMM wSOL Pool Vault
   Balance:       74.71 SOL (as wSOL)
   Owner:         Token Program (NOT a user wallet)
   Activity:      2026-04-25 → 2026-05-03  |  1000+ txs  |  140 failed (14%)
   Risk:          MODERATE — bot-deployed pool with MEV extraction

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WALLET A (GK4) BACK-TRACE CHAIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠🔁 6x7mout1JJUDeSCLbb5bVtmfh2YrPn8k4d2XYEMsmgkP
   Role:          HOP-3 ROOT — throwaway/burner origin wallet
   Balance:       0 SOL  (completely empty)
   Token Accts:   3 ghost accounts remaining
   Txs:           0 queryable
   Sent:          40.00008 SOL → HOP-2 relay
   Risk:          CRITICAL — empty burner wallet, root of obfuscation chain

⚠🔁 7ywV56emJ2cRmxhejwwG2wz72MkzujeZnGEi6YwESmbE
   Role:          HOP-2 — throwaway relay (existed 79 SECONDS)
   Balance:       0 SOL  (completely empty)
   Existed:       2026-05-03 07:04:37 → 07:05:56 UTC  (79 seconds)
   Total Txs:     4  (created, relayed, abandoned)
   Sent:          40.000010001 SOL → HOP-1 whale
   Risk:          CRITICAL — deliberate throwaway layering wallet

⚠🤖 5ndLnEYqSFiA5yUFHo6LVZ1eWc6Rhh11K5CfJNkoHEPs
   Role:          HOP-1 — DeFi bot / market-maker whale
   Balance:       11,491.575 SOL  (~$1.63M USD)
   Token Accts:   149
   Txs:           1,000+ in window  |  352 failed (35.2%)
   First Seen:    2026-05-03 07:05:56 UTC  (address-cycles regularly)
   Sent to GK4:   0.70269 SOL at GK4's creation
   Risk:          HIGH — automated bot, high failure rate, large balance

   7XLjRgUpjGGbM48BUmoZqUQCMPc3KF4uFVWKUrwwPHee
   Role:          Secondary participant in GK4's creation transaction
   Balance:       0.100000672 SOL
   Owner:         System Program
   Txs:           0 queryable
   Risk:          LOW — minimal activity, appears to be a dust account

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WALLET A (GK4) FORWARD-TRACE CHAIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏦 5pVN5XZB8cYBjNLFrsBCPWkCQBan5K5Mq2dWGzwPgGJV
   Role:          GK4 FWD HOP-1 — Orca Whirlpool wSOL AMM vault
   Balance:       6,261.122 SOL  (~$889K)
   Owner:         Token Program  |  Mint: Wrapped SOL
   Authority:     8ekCy2jHHUbW2yeNGFWYJT9Hm9FW7SvZcZK66dSZCDiF
   Protocol:      Orca Whirlpool concentrated liquidity AMM
   Received:      0.641212799 SOL from GK4 (swap input)
   Risk:          LOW — legitimate DEX protocol address

   FnStkCsMRp398HEHKoVCTgmYNFYMAXHtnTcTTPPR27PZ
   Role:          GK4 FWD HOP-1B — token account rent deposit (dust)
   Balance:       0.00203928 SOL
   Owner:         Token Program
   Received:      0.00203928 SOL from GK4 (rent minimum)
   Risk:          NONE — routine token account initialization

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WALLET B (9rN POOL) BACK-TRACE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠🤖 54Pz1e35z9uoFdnxtzjp7xZQoFiofqhdayQWBMN7dsuy
   Role:          Pool deployer / creator of 9rN pool
   Balance:       97.490 SOL
   Token Accts:   13,975  (definitively non-human / automated)
   Deployed:      9rN pool on 2026-04-25 with 69.19 SOL initial liquidity
   Txs:           0 queryable (cycles addresses / predates window)
   Risk:          HIGH — anonymous bot operator, unknown funding origin
   NOTE:          Same bot infrastructure appears across both wallet traces

   6TpBkWtgqwGeTCi35Fwgi5vsKPzqPXdeboN5jrYdDTT6
   Role:          Pool state / authority account (PDA)
   Balance:       0.00298584 SOL  (rent only)
   Owner:         pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA
   Risk:          LOW — protocol-derived address, not user-controlled

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WALLET B (9rN POOL) FORWARD-TRACE RECIPIENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   F7mrwLgcKAnGgDBYXRmGFay1eAi8UyQuX7Fs6eYKM9Em
   Role:          Token seller — received SOL from pool
   Balance:       0.050 SOL  |  10 txs  |  2 token accounts
   Received:      0.01365 SOL  (2026-05-03)
   Risk:          LOW — organic pool interaction, token seller

⚠🤖 6Wzuv7vLc6Vq8HJcHwwSCE9SKcdJiuoJmJm3EMFkWERN
   Role:          MEV extraction bot — active on pool transactions
   Balance:       10.189 SOL  (accumulated MEV profit)
   Txs:           10 in query window
   Received:      0.000525 SOL from pool transactions (MEV tips/arb)
   Risk:          HIGH — confirmed MEV bot operating across multiple wallets
                  in this investigation

🏦 Bvtgim23rfocUzxVX9j9QFxTbBnH8JZxnaGLCEkXvjKS
   Role:          Connected liquidity pool (Token Program)
   Balance:       2,740.734 SOL  (~$389K — very large pool)
   Received:      0.000064 SOL routing flow
   Risk:          LOW — AMM protocol address

🏦 BWXT6RUhit9FfJQM3pBmqeFLPYmuxgmyhMGC5sGr8RbA
   Role:          Connected liquidity pool (Token Program)
   Balance:       845.528 SOL
   Received:      0.000281 SOL routing flow
   Risk:          LOW — AMM protocol address

🏦 HjQjngTDqoHE6aaGhUqfz9aQ7WZcBRjy5xB8PScLSr8i
   Role:          Connected pool or account (Token Program)
   Balance:       1.396 SOL
   Received:      0.000281 SOL
   Risk:          LOW — protocol address

   63HUkft8L8exXm76gARiwmj2oyqFrETXQXZMSJo6tEQn
   Role:          Token buyer — sent SOL into pool
   Sent:          0.061910553 SOL into pool
   Risk:          LOW — organic pool interaction, token buyer

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SHARED INFRASTRUCTURE (appears in both wallet traces)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   3YANG71Bk8rXmaekTTnT6qMq28y3rFkKbELadzsDsj41
   Role:          Jito tip account — receives MEV bundle tips
   Balance:       0.024282761 SOL
   Appears in:    9rN pool creation tx + 9rN swap txs
   Risk:          NONE — public Jito infrastructure address

   jitonobundLe1111111111111111111111111111123
   Role:          Jito bundle relay — MEV-protected tx submission
   Appears in:    Pool creation tx for 9rN
   Risk:          NONE — public Jito infrastructure address

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PROTOCOL ADDRESSES (for reference)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA     PumpFun AMM program
   JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4    Jupiter v6 aggregator
   whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc    Orca Whirlpool AMM
   DFPGnooMjWMttYGF2Pegmsp4Vj2VFhLyrxc5Cp1wpump   Pool token mint (pump.fun)
   Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB    USDT mint (Tether)
   pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ     PumpFun fee collector
   EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v    USDC mint
   MNFSTqtC93rEfYHB6hF82sKdZpUDFWkViLByLd1k1Ms     Manifest DEX
   jitodontfront11111JustUseJupiterU1tra            Jito anti-MEV relay
   TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA     SPL Token Program
   11111111111111111111111111111111                  System Program

================================================================================
  END OF ADDRESS LEDGER
================================================================================
