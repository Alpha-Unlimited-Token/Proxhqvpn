(function() {
  // Nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.getElementById('primary-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', function() {
      var isOpen = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!isOpen));
      document.body.classList.toggle('nav-open', !isOpen);
    });
  }
})();

(function() {
  // Smooth scroll to eligibility and pulse highlight
  var heroEligibility = document.querySelector('.hero-cta.outline[href="#eligibility"]');
  var eligibilitySection = document.getElementById('eligibility');
  if (!heroEligibility || !eligibilitySection) { return; }
  heroEligibility.addEventListener('click', function(e) {
    // If it's a hash link, prevent default jump to handle with smooth scroll
    e.preventDefault();
    try {
      eligibilitySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
      // Fallback for older browsers
      window.location.hash = 'eligibility';
    }
    // Pulse the card for focus
    var card = eligibilitySection.querySelector('.eligibility-card');
    if (!card) { return; }
    card.classList.remove('is-highlighted');
    // Force reflow to restart animation
    void card.offsetWidth;
    card.classList.add('is-highlighted');
    // Remove the class after animation ends to keep DOM clean
    setTimeout(function(){ card.classList.remove('is-highlighted'); }, 1800);
  });
})();

(function() {
  // Live ETH price updater
  var priceElement = document.querySelector('.balance');
  var priceStoreElement = document.getElementById('eth-price');
  if (!priceElement) { return; }

  function formatUsd(amount) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(amount);
  }
  function setPriceText(amount) {
    priceElement.textContent = 'stETH ' + formatUsd(amount);
    if (priceStoreElement) {
      priceStoreElement.textContent = String(amount);
    }
  }
  async function fetchFromCoinbase() {
    var response = await fetch('https://api.coinbase.com/v2/prices/ETH-USD/spot');
    if (!response.ok) { throw new Error('Failed to fetch from Coinbase'); }
    var data = await response.json();
    var amount = parseFloat(data && data.data && data.data.amount);
    if (isNaN(amount)) { throw new Error('Invalid price from Coinbase'); }
    return amount;
  }
  async function fetchFromCryptoCompare() {
    var response = await fetch('https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=USD');
    if (!response.ok) { throw new Error('Failed to fetch from CryptoCompare'); }
    var data = await response.json();
    var amount = parseFloat(data && data.USD);
    if (isNaN(amount)) { throw new Error('Invalid price from CryptoCompare'); }
    return amount;
  }
  async function updateEthPrice() {
    try {
      var amount = await fetchFromCoinbase().catch(function() { return fetchFromCryptoCompare(); });
      setPriceText(amount);
    } catch (e) {
      // silently ignore
    }
  }
  updateEthPrice();
  setInterval(updateEthPrice, 60000);
})();

// Eligibility checker removed per request

(function() {
  // Node operators tab switching
  var tabs = document.querySelectorAll('.node-tab');
  var contents = document.querySelectorAll('.node-content[data-tab]');
  
  if (tabs.length === 0 || contents.length === 0) { return; }
  
  tabs.forEach(function(tab, index) {
    tab.addEventListener('click', function() {
      // Remove active from all tabs
      tabs.forEach(function(t) { t.classList.remove('active'); });
      // Add active to clicked tab
      tab.classList.add('active');
      
      // Hide all content panels
      contents.forEach(function(c) { c.style.display = 'none'; });
      
      // Show corresponding content based on index
      var tabNames = ['all', 'curated', 'simple-dvt', 'community'];
      var targetTab = tabNames[index] || 'all';
      var targetContent = document.querySelector('.node-content[data-tab="' + targetTab + '"]');
      if (targetContent) {
        targetContent.style.display = 'grid';
      }
    });
  });
})();


