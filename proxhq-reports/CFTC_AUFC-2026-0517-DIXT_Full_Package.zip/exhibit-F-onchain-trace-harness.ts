const K = process.env.ETHERSCAN_V2_API_KEY!;
if (!K) { console.error('Missing ETHERSCAN_V2_API_KEY'); process.exit(1); }
const BASE = 'https://api.etherscan.io/v2/api';
const CHAIN = '1';

const DECOY = '0x7637FF11eAb247aEa8E1bb9C5B9109392eA8F687';  // vanity-mined, never controlled
const SENDER = '0x5ecaf321936ee418b9197da8cf51a339e8346ce2';  // real EOA broadcaster
const DIXT_TOKEN = '0x43e6228b5bf22eab754486082ca91fdd8585521a';
const VICTIM = '0xf8CF11c1E6b14C62b3F79f70A986459CdEe2D8b3';
const TXHASH = '0xfc196eca600394f60b7d1230bcaddb5acb73a16971c837f12907cc5575f50a51';

// Known CEX/exchange hot-wallet labels (subset — high-signal only)
const CEX: Record<string, string> = {
  // Binance
  '0x28c6c06298d514db089934071355e5743bf21d60': 'Binance 14 (hot)',
  '0x21a31ee1afc51d94c2efccaa2092ad1028285549': 'Binance 15',
  '0xdfd5293d8e347dfe59e90efd55b2956a1343963d': 'Binance 16',
  '0x56eddb7aa87536c09ccc2793473599fd21a8b17f': 'Binance 17',
  '0x9696f59e4d72e237be84ffd425dcad154bf96976': 'Binance 18',
  '0x4d9ff50ef4da947364bb9650892b2554e7be5e2b': 'Binance Brokerage',
  '0x4976a4a02f38326660d17bf34b431dc6e2eb2327': 'Binance Deployer',
  '0xf977814e90da44bfa03b6295a0616a897441acec': 'Binance 8',
  '0x5a52e96bacdabb82fd05763e25335261b270efcb': 'Binance 20',
  '0xbe0eb53f46cd790cd13851d5eff43d12404d33e8': 'Binance 7',
  // Coinbase
  '0x71660c4005ba85c37ccec55d0c4493e66fe775d3': 'Coinbase 1',
  '0x503828976d22510aad0201ac7ec88293211d23da': 'Coinbase 2',
  '0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740': 'Coinbase 3',
  '0xa090e606e30bd747d4e6245a1517ebe430f0057e': 'Coinbase 6',
  '0xeb2629a2734e272bcc07bda959863f316f4bd4cf': 'Coinbase 7',
  '0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43': 'Coinbase 10',
  '0xfa9b5f7fdc8ab34aaf3099889475d47febf830d7': 'Coinbase 15',
  // Kraken
  '0x2910543af39aba0cd09dbb2d50200b3e800a63d2': 'Kraken 1',
  '0xae2d4617c862309a3d75a0ffb358c7a5009c673f': 'Kraken 4',
  '0xa83b11093c858c86321fbc4c20fe82cdbd58e09e': 'Kraken 9',
  // OKX
  '0x6cc5f688a315f3dc28a7781717a9a798a59fda7b': 'OKX 1',
  '0x236f9f97e0e62388479bf9e5ba4889e46b0273c3': 'OKX 7',
  '0xa7efae728d2936e78bda97dc267687568dd593f3': 'OKX',
  // Bybit
  '0xf89d7b9c864f589bbf53a82105107622b35eaa40': 'Bybit (hot)',
  // KuCoin
  '0x2b5634c42055806a59e9107ed44d43c426e58258': 'KuCoin 5',
  '0x689c56aef474df92d44a1b70850f808488f9769c': 'KuCoin 6',
  // Bitfinex
  '0x1151314c646ce4e0efd76d1af4760ae66a9fe30f': 'Bitfinex 8',
  // Tornado Cash routers (mixer = laundering)
  '0x12d66f87a04a9e220743712ce6d9bb1b5616b8fc': 'Tornado Cash 0.1 ETH',
  '0x47ce0c6ed5b0ce3d3a51fdb1c52dc66a7c3c2936': 'Tornado Cash 1 ETH',
  '0x910cbd523d972eb0a6f4cae4618ad62622b39dbf': 'Tornado Cash 10 ETH',
  '0xa160cdab225685da1d56aa342ad8841c3b53f291': 'Tornado Cash 100 ETH',
  '0xd96f2b1c14db8458374d9aca76e26c3d18364307': 'Tornado Cash router',
  // FixedFloat / Sideshift / Changenow (instant swap = anon)
  '0x4e5b2e1dc63f6b91cb6cd759936495434c7e972f': 'FixedFloat',
  '0xf1da173228fcf015f43f3ea15abbb51f0d8f1123': 'ChangeNOW',
  '0x077d360f11d220e4d5d831430c81c26c9be7c4a4': 'SideShift',
};

const cexHit = (a: string) => CEX[a.toLowerCase()] || null;

async function call(params: Record<string, string>): Promise<any> {
  const u = new URL(BASE);
  u.searchParams.set('chainid', CHAIN);
  u.searchParams.set('apikey', K);
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
  for (let attempt = 0; attempt < 6; attempt++) {
    await new Promise(r => setTimeout(r, 350));
    const r = await fetch(u.toString());
    const j = await r.json();
    const res = j?.result;
    if (typeof res === 'string' && /rate limit|Max calls/i.test(res)) {
      await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
      continue;
    }
    return j;
  }
  return { status: '0', message: 'rate-limit-exhausted', result: [] };
}

async function tx(hash: string) {
  return call({ module: 'proxy', action: 'eth_getTransactionByHash', txhash: hash });
}
async function txReceipt(hash: string) {
  return call({ module: 'proxy', action: 'eth_getTransactionReceipt', txhash: hash });
}
async function txlistNormal(addr: string, page = 1, offset = 100) {
  return call({ module: 'account', action: 'txlist', address: addr, startblock: '0', endblock: '99999999', page: String(page), offset: String(offset), sort: 'desc' });
}
async function txlistInternal(addr: string, page = 1, offset = 100) {
  return call({ module: 'account', action: 'txlistinternal', address: addr, startblock: '0', endblock: '99999999', page: String(page), offset: String(offset), sort: 'desc' });
}
async function tokenTransfers(addr: string, page = 1, offset = 1000) {
  return call({ module: 'account', action: 'tokentx', address: addr, startblock: '0', endblock: '99999999', page: String(page), offset: String(offset), sort: 'desc' });
}
async function balance(addr: string) {
  return call({ module: 'account', action: 'balance', address: addr, tag: 'latest' });
}
async function contractCreation(contracts: string[]) {
  return call({ module: 'contract', action: 'getcontractcreation', contractaddresses: contracts.join(',') });
}

interface Counterparty {
  addr: string;
  totalTxs: number;
  ethIn: bigint;
  ethOut: bigint;
  firstSeen: string;
  lastSeen: string;
  cex: string | null;
  isContract: boolean;
}

function tally(addr: string, txs: any[], col: 'from' | 'to'): Map<string, Counterparty> {
  const m = new Map<string, Counterparty>();
  const me = addr.toLowerCase();
  for (const t of txs) {
    const other = (col === 'from' ? t.to : t.from)?.toLowerCase();
    if (!other || other === me || other === '') continue;
    const v = BigInt(t.value || '0');
    let c = m.get(other);
    if (!c) { c = { addr: other, totalTxs: 0, ethIn: 0n, ethOut: 0n, firstSeen: t.timeStamp, lastSeen: t.timeStamp, cex: cexHit(other), isContract: !!t.contractAddress }; m.set(other, c); }
    c.totalTxs++;
    if (col === 'from') c.ethOut += v; else c.ethIn += v;
    if (+t.timeStamp < +c.firstSeen) c.firstSeen = t.timeStamp;
    if (+t.timeStamp > +c.lastSeen) c.lastSeen = t.timeStamp;
  }
  return m;
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function profileAddr(addr: string, depth: number): Promise<{
  addr: string;
  ethBalance: string;
  normalCount: number;
  internalCount: number;
  tokenCount: number;
  inbound: Counterparty[];
  outbound: Counterparty[];
  cexAnchors: { dir: 'in' | 'out'; cp: Counterparty }[];
  earliestTx: any | null;
  firstFunder: string | null;
}> {
  await sleep(450);
  const bal = await balance(addr); await sleep(450);
  const nt = await txlistNormal(addr, 1, 1000); await sleep(450);
  const it = await txlistInternal(addr, 1, 1000); await sleep(450);
  const tt = await tokenTransfers(addr, 1, 1000);
  const normal = Array.isArray(nt.result) ? nt.result : [];
  const internal = Array.isArray(it.result) ? it.result : [];
  const token = Array.isArray(tt.result) ? tt.result : [];
  // Merge all txs for counterparty graph (normal + internal — token doesn't move ETH)
  const all = [...normal, ...internal];
  const out = tally(addr, all, 'from');
  const inb = tally(addr, all, 'to');
  // Earliest tx (chronological) to find first funder
  const earliest = [...normal, ...internal].sort((a, b) => +a.timeStamp - +b.timeStamp)[0] || null;
  const firstFunder = earliest && earliest.to?.toLowerCase() === addr.toLowerCase() ? earliest.from?.toLowerCase() : null;
  const inboundArr = [...inb.values()].sort((a, b) => Number(b.ethIn - a.ethIn) || b.totalTxs - a.totalTxs).slice(0, 20);
  const outboundArr = [...out.values()].sort((a, b) => Number(b.ethOut - a.ethOut) || b.totalTxs - a.totalTxs).slice(0, 20);
  const cexAnchors: { dir: 'in' | 'out'; cp: Counterparty }[] = [];
  for (const c of inboundArr) if (c.cex) cexAnchors.push({ dir: 'in', cp: c });
  for (const c of outboundArr) if (c.cex) cexAnchors.push({ dir: 'out', cp: c });
  return { addr, ethBalance: bal.result || '0', normalCount: normal.length, internalCount: internal.length, tokenCount: token.length, inbound: inboundArr, outbound: outboundArr, cexAnchors, earliestTx: earliest, firstFunder };
}

const fmtEth = (wei: bigint | string) => (Number(BigInt(wei.toString())) / 1e18).toFixed(6);
const short = (a: string) => a.slice(0, 8) + '…' + a.slice(-6);

(async () => {
  const out: any = { runAt: new Date().toISOString(), chain: 'Ethereum mainnet', victim: VICTIM, dustingTxHash: TXHASH };

  console.log('━━━ STEP 1: Decoded scam tx + DIXT token contract identification ━━━\n');
  const [txd, txr] = await Promise.all([tx(TXHASH), txReceipt(TXHASH)]);
  const tokenContract = txd.result?.to?.toLowerCase();
  out.scamTx = {
    hash: TXHASH,
    block: parseInt(txd.result?.blockNumber || '0', 16),
    from: txd.result?.from,
    contractCalled: tokenContract,
    gasUsed: parseInt(txr.result?.gasUsed || '0', 16),
    logsCount: txr.result?.logs?.length || 0,
    firstLogTopic0: txr.result?.logs?.[0]?.topics?.[0] || null,
  };
  console.log('Scam tx → contract called:', tokenContract);
  console.log('Block:', out.scamTx.block, '  Logs:', out.scamTx.logsCount);

  // Contract deployer
  if (true) {
    const tokenContractReal = DIXT_TOKEN;
    const cc = await contractCreation([tokenContractReal, txd.result?.from || '']);
    out.tokenContract = { address: tokenContractReal, deployer: cc.result?.[0]?.contractCreator || null, deployTx: cc.result?.[0]?.txHash || null };
    console.log('Token contract:', tokenContractReal);
    console.log('  Deployed by:', out.tokenContract.deployer);
    console.log('  Deploy tx  :', out.tokenContract.deployTx);
  }
  console.log();

  console.log('━━━ STEP 2: HOP-1 — profile SENDER wallet ' + SENDER + ' ━━━\n');
  const h1Sender = await profileAddr(SENDER, 1);
  out.hop1_sender = h1Sender;
  console.log('  ETH bal:', fmtEth(h1Sender.ethBalance), '  norm txs:', h1Sender.normalCount, '  internal:', h1Sender.internalCount, '  token txs:', h1Sender.tokenCount);
  console.log('  First funder:', h1Sender.firstFunder || '(none/coinbase)');
  console.log('  Earliest tx:', h1Sender.earliestTx ? `${h1Sender.earliestTx.hash} @ ${new Date(+h1Sender.earliestTx.timeStamp * 1000).toISOString()}` : '(n/a)');
  console.log('  CEX anchors found:', h1Sender.cexAnchors.length);
  for (const a of h1Sender.cexAnchors) console.log(`    [${a.dir}] ${a.cp.cex}  ${short(a.cp.addr)}  ${a.cp.totalTxs} txs  in=${fmtEth(a.cp.ethIn)} ETH  out=${fmtEth(a.cp.ethOut)} ETH`);
  console.log('  Top outbound (where the scammer sent ETH):');
  for (const c of h1Sender.outbound.slice(0, 8)) console.log(`    → ${short(c.addr)}  ${c.totalTxs}tx  ${fmtEth(c.ethOut)} ETH  ${c.cex ? '[' + c.cex + ']' : ''}`);
  console.log('  Top inbound  (where the scammer got funded):');
  for (const c of h1Sender.inbound.slice(0, 8)) console.log(`    ← ${short(c.addr)}  ${c.totalTxs}tx  ${fmtEth(c.ethIn)} ETH  ${c.cex ? '[' + c.cex + ']' : ''}`);

  // Pick hop2 candidates: take top-5 outbound + top-5 inbound + the deployer if different
  const hop2Set = new Set<string>();
  for (const c of h1Sender.outbound.slice(0, 5)) hop2Set.add(c.addr);
  for (const c of h1Sender.inbound.slice(0, 5)) hop2Set.add(c.addr);
  if (out.tokenContract?.deployer && out.tokenContract.deployer.toLowerCase() !== SENDER.toLowerCase()) hop2Set.add(out.tokenContract.deployer.toLowerCase());
  if (h1Sender.firstFunder) hop2Set.add(h1Sender.firstFunder);
  // Drop CEX leaves (no need to trace into them — they ARE the KYC anchor)
  for (const c of [...hop2Set]) if (CEX[c]) hop2Set.delete(c);

  console.log('\n━━━ STEP 3: HOP-2 — profile ' + hop2Set.size + ' counterparties ━━━\n');
  const hop2: any[] = [];
  const hop3Set = new Set<string>();
  for (const addr of hop2Set) {
    const p = await profileAddr(addr, 2);
    hop2.push(p);
    const tag = CEX[addr.toLowerCase()] ? ` [${CEX[addr.toLowerCase()]}]` : '';
    console.log(`  ◉ ${short(addr)}${tag}  bal=${fmtEth(p.ethBalance)} ETH  txs=${p.normalCount}+${p.internalCount}int  cex-anchors=${p.cexAnchors.length}`);
    for (const a of p.cexAnchors.slice(0, 3)) console.log(`      [${a.dir}] ${a.cp.cex}  ${short(a.cp.addr)}  ${fmtEth(a.cp.ethIn + a.cp.ethOut)} ETH`);
    if (p.firstFunder) console.log(`      first funder: ${short(p.firstFunder)}${CEX[p.firstFunder] ? ' [' + CEX[p.firstFunder] + ' ← KYC ANCHOR]' : ''}`);
    // Hop3 picks: top-3 in/out
    for (const c of p.outbound.slice(0, 3)) if (!CEX[c.addr]) hop3Set.add(c.addr);
    for (const c of p.inbound.slice(0, 3)) if (!CEX[c.addr]) hop3Set.add(c.addr);
    if (p.firstFunder && !CEX[p.firstFunder]) hop3Set.add(p.firstFunder);
  }
  out.hop2 = hop2;

  // Drop already-seen
  hop3Set.delete(SENDER.toLowerCase());
  for (const a of hop2Set) hop3Set.delete(a);
  // Cap hop3 to first 12 to stay under rate limit
  const hop3List = [...hop3Set].slice(0, 12);

  console.log('\n━━━ STEP 4: HOP-3 — profile ' + hop3List.length + ' counterparties (capped) ━━━\n');
  const hop3: any[] = [];
  const kycAnchors: any[] = [];
  for (const addr of hop3List) {
    const p = await profileAddr(addr, 3);
    hop3.push(p);
    const tag = CEX[addr.toLowerCase()] ? ` [${CEX[addr.toLowerCase()]}]` : '';
    console.log(`  ◉ ${short(addr)}${tag}  bal=${fmtEth(p.ethBalance)} ETH  txs=${p.normalCount}+${p.internalCount}int  cex-anchors=${p.cexAnchors.length}`);
    for (const a of p.cexAnchors.slice(0, 3)) {
      console.log(`      [${a.dir}] ${a.cp.cex}  ${short(a.cp.addr)}`);
      kycAnchors.push({ pathHop: 3, addr, anchor: a.cp.cex, anchorAddr: a.cp.addr, dir: a.dir });
    }
    if (p.firstFunder && CEX[p.firstFunder]) {
      console.log(`      first funder: ${short(p.firstFunder)} [${CEX[p.firstFunder]} ← KYC ANCHOR]`);
      kycAnchors.push({ pathHop: 3, addr, anchor: CEX[p.firstFunder], anchorAddr: p.firstFunder, dir: 'first-funder' });
    }
  }
  out.hop3 = hop3;

  // Collect ALL KYC anchors discovered at any hop
  const allAnchors: any[] = [];
  for (const a of h1Sender.cexAnchors) allAnchors.push({ pathHop: 1, addr: SENDER.toLowerCase(), anchor: a.cp.cex, anchorAddr: a.cp.addr, dir: a.dir, ethIn: fmtEth(a.cp.ethIn), ethOut: fmtEth(a.cp.ethOut), txs: a.cp.totalTxs });
  if (h1Sender.firstFunder && CEX[h1Sender.firstFunder]) allAnchors.push({ pathHop: 1, addr: SENDER.toLowerCase(), anchor: CEX[h1Sender.firstFunder], anchorAddr: h1Sender.firstFunder, dir: 'first-funder' });
  for (const p of hop2) {
    for (const a of p.cexAnchors) allAnchors.push({ pathHop: 2, addr: p.addr, anchor: a.cp.cex, anchorAddr: a.cp.addr, dir: a.dir, ethIn: fmtEth(a.cp.ethIn), ethOut: fmtEth(a.cp.ethOut), txs: a.cp.totalTxs });
    if (p.firstFunder && CEX[p.firstFunder]) allAnchors.push({ pathHop: 2, addr: p.addr, anchor: CEX[p.firstFunder], anchorAddr: p.firstFunder, dir: 'first-funder' });
  }
  for (const p of hop3) {
    for (const a of p.cexAnchors) allAnchors.push({ pathHop: 3, addr: p.addr, anchor: a.cp.cex, anchorAddr: a.cp.addr, dir: a.dir, ethIn: fmtEth(a.cp.ethIn), ethOut: fmtEth(a.cp.ethOut), txs: a.cp.totalTxs });
  }
  out.kycAnchors = allAnchors;

  console.log('\n━━━ KYC ANCHOR SUMMARY ━━━\n');
  console.log('Total CEX/anchor links discovered across 3 hops:', allAnchors.length);
  for (const a of allAnchors) console.log(`  H${a.pathHop} | ${short(a.addr)} ←${a.dir}→ ${a.anchor} (${short(a.anchorAddr)})  ${a.txs || ''}tx  in=${a.ethIn || ''} out=${a.ethOut || ''}`);

  const fs = await import('fs');
  fs.writeFileSync('.local/dixt_forensic/trace_result.json', JSON.stringify(out, (_,v) => typeof v === 'bigint' ? v.toString() : v, 2));
  console.log('\n✓ Full graph saved → .local/dixt_forensic/trace_result.json');
})().catch(e => { console.error('FATAL:', e); process.exit(1); });
