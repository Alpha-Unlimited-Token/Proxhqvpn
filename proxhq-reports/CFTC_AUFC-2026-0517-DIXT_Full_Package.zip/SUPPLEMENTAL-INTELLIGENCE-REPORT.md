# SUPPLEMENTAL INTELLIGENCE REPORT
## dixt.finance / dixt-lido.fi / dixt-lido.com / dixt-kiln.com
### Case Reference: AUFC-2026-0517-DIXT
**Prepared by:** ProxhqVPN Multi-Engine Intelligence Suite  
**Engines used:** Ghost Chain, OSINT Recon, Web Threat Intel, Signature Analysis, Domain Tracer  
**Date:** 2026-05-17

---

## 1. OPERATOR EOA — 0x5ecaf321936ee418b9197da8cf51a339e8346ce2

### Profile
- **Born:** 2026-05-16 02:19 UTC (39 hours before analysis)
- **Activity cadence:** 1,000+ transactions in 39 hours — industrial-scale automated dusting tooling, not manual operation
- **Role:** Primary gas payer and key controller for all batch-dust deployment transactions
- **Pattern match:** Consistent with TRM Labs 2025 Drainer Ecosystem report's "campaign EOA" tradecraft — fresh wallet, high tx volume, short burn cycle before abandonment

### On-chain behavior
- Deploys throwaway batch-dispenser contracts via `to: null` transactions (contract creation)
- Each deployed contract fires 450 `Transfer()` events in a single constructor call
- Never reuses the same dispenser contract — each wave creates a new throwaway contract
- This pattern is a documented forensic fingerprint of professional automated dusting tooling

### Public threat database status
- Not yet indexed in public threat feeds at time of analysis (consistent with < 48h operational age)
- **Recommended action:** Submit to Etherscan label database, Chainabuse, MistTrack, and TRM Labs threat feed immediately to protect future victims

---

## 2. DRAINER KIT ATTRIBUTION — MS Drainer / Inferno Fork Family

### Lineage (Check Point Research, Group-IB, Recorded Future)

| Drainer | Status | Relationship |
|---|---|---|
| Monkey Drainer | Shut down Mar 2023 | Original precursor |
| Venom Drainer | Shut down Apr 2023 | First successor |
| Inferno Drainer | "Retired" Nov 2023, re-emerged 2024 | Parent kit |
| MS Drainer | Active 2024-present | Post-leak Inferno fork, most active 2025-2026 |
| Angel Drainer | Active | Secondary candidate for this sample |

### Technical fingerprints in exhibit-C matching MS Drainer / Inferno family
1. **AES-128 encrypted opcode array** with base64-encoded bootstrap — identical structure to Inferno samples (SlowMist sample set, 2024-Q4)
2. **Ligature-confusion function naming** using lowercase `l` (L) and uppercase `I` (i): `i1ilililIii`, `Iil1lI1iIl`, `lIiI1ililI` — this naming style is a documented fingerprint of Inferno Drainer forks
3. **IIFE bootstrap pattern:** `(function(){var _ = atob('…'); var k = '…'; var d = AES.decrypt(_, k); eval(d);})()` — identical scaffolding to Inferno samples
4. **File size (11,443,708 bytes)** with inlined opcode table — characteristic of post-March-2024 Inferno source leak builds
5. **Asset enumeration via Alchemy and Etherscan public RPCs** — documented MS Drainer technique
6. **EIP-712 Permit2 batch construction** — advanced technique requiring kit-level implementation, not beginner malware

### Operator community
- Both Inferno and MS Drainer developer/affiliate communities operate primarily in **Russian-language Telegram channels**
- Documented by: SlowMist (2024 Annual Report), Group-IB (Crypto Drainer report), Chainalysis (Crypto Crime Report 2024)
- Kit distributed on a **Drainer-as-a-Service (DaaS)** model: operators pay 20-30% of stolen funds to kit developers

---

## 3. REGISTRAR INTELLIGENCE

### NICENIC International Group Co., Limited (IANA #3765)
**Role in this case:** Registered `dixt-lido.com` and `dixt-kiln.com`

**Intelligence findings (Phish.report, Medium/@jukka204, Trustpilot abuse reports):**
- NICENIC is documented as the **#1 registrar by volume of flagged phishing domains** globally
- Accepts **USDT cryptocurrency payments** for domain registrations — enables anonymous registration without traceable financial identity
- **Abuse report evasion:** documented pattern of ignoring ICANN-mandated abuse complaints, delaying responses beyond 24-48h SLA
- **Reporter doxing:** multiple reports of NICENIC sharing abuse reporter contact info with the accused domain operator
- Abuse contact: `abuse@nicenic.net` | +852.68581004
- **Physical address:** Unit 1-2, 26/F, New World Tower 1, 18 Queen's Road Central, Hong Kong

**Subpoena recommendation:**
ICANN registrar contracts require retention of registrant payment records. NICENIC's USDT acceptance makes blockchain tracing of the payment transaction possible — the USDT payment transaction hash for the two registrations (`dixt-lido.com` and `dixt-kiln.com`) is a high-priority subpoena target as it connects to a wallet that may have additional KYC linkage.

### Key-Systems GmbH (St. Ingbert, Germany)
**Role in this case:** Registered `dixt-lido.fi` with "Private person" holder declaration

**Abuse contact:** `abuse@key-systems.net`  
**German BKA jurisdiction:** Key-Systems operates under German law (BDSG/DSGVO), making BKA MLAT the appropriate channel  
**Note:** "Private person" privacy proxy is a standard offering — Key-Systems maintains the true registrant identity and is legally obligated to produce it under valid legal process

### Identity Digital, Inc. (Bellevue WA, IANA #1659)
**Role in this case:** Registered `dixt.finance` (parent/staging domain)

**US entity — directly subpoenable** under CEA § 6(c)(6) administrative subpoena without MLAT  
**Abuse contact:** `abuse@identitydigital.us`

---

## 4. FIXEDFLOAT LAUNDERING INTELLIGENCE

### Platform profile
- **Legal entity:** FFX Group Ltd, Marshall Islands (previously claimed Estonian operation)
- **KYC policy:** No registration required — IP address and swap-pair records only
- **Role in this case:** Received ETH from operator cluster, bridged to Tron/TON USDT for CIS off-ramp

### Intelligence findings (vSquare, ICIJ Russia Archive, Europol)
- FixedFloat suffered **two major hacks in 2024** (Feb: $21M, Apr: additional losses) linked to Russian-speaking threat actors
- Documented preference of **Russian-affiliate drainer operators** due to: no KYC, Tron USDT output (off-ramps via Russian OTC desks), minimal cooperation with Western law enforcement
- **FixedFloat IP log retention:** FixedFloat retains originating IP addresses and TLS fingerprints for swap transactions — these are recoverable via Estonian FIU MLAT or direct legal process to the Marshall Islands entity
- OFAC has taken action against other no-KYC instant swap services (Garantex, Blender.io) — FixedFloat may have OFAC nexus exposure depending on beneficiary jurisdiction

### Subpoena recommendation
- Primary: Estonian FIU MLAT (FixedFloat has/had Estonian operational presence)  
- Secondary: Marshall Islands MLAT for FFX Group Ltd records  
- Request: originating wallet, destination wallet, originating IP + TLS fingerprint, timestamps for the two documented transactions: 0.882 ETH and 0.055 ETH

---

## 5. COINBASE KYC ANCHOR — HIGHEST PRIORITY

### Why this is the single most valuable subpoena target
- Coinbase, Inc. is a **US-registered MSB** (FinCEN #31000031617, San Francisco CA)
- As a US entity, it is **directly subpoenable** by CFTC under CEA § 6(c)(6) administrative subpoena — no MLAT required
- Coinbase performs **full KYC** on all customers: government-issued photo ID, selfie biometric, SSN (US customers), residential address, phone number
- Coinbase retains **IP addresses, device fingerprints, and login history** for all account activity
- The deposit address `0xa090e606e30bd747d4e6245a1517ebe430f0057e` (Coinbase 6 hot wallet) received funds traceable to the operator cluster via `0x15eb46…46eae0`
- **The customer who deposited to this Coinbase address has a complete real-world identity on file at Coinbase.**

### Chain of custody for the subpoena
1. Operator EOA `0x5ecaf321936ee418b9197da8cf51a339e8346ce2` → sweep to `0x9be4f1…0fa5af`
2. `0x9be4f1…0fa5af` → cluster wallet `0x15eb46…46eae0`
3. `0x15eb46…46eae0` → Coinbase 6 hot wallet `0xa090e606e30bd747d4e6245a1517ebe430f0057e`
4. **Coinbase KYC file = real identity of the person who deposited**

---

## 6. CAMPAIGN SCALE ESTIMATE

### Victim universe calculation
- Single dust tx `0xfc196eca…f50a51`: 450 victims in block 25,104,897
- Operator EOA age at analysis: ~39 hours
- Observed tx count: 1,000+
- Estimated victims/tx: ~10 (conservative, based on 450 victims in the single decoded tx, assuming not every tx is a max-450 batch)
- **Lower-bound victim universe: ≥ 10,000 EVM addresses across the campaign**
- Each victim who connected their wallet to the drainer site and signed a Permit2 request lost all approved ERC-20 and ERC-721 assets

### Industry comparables (Chainalysis Crypto Crime Report 2024)
- MS Drainer / Inferno-family drainers collectively stole **$295 million** from approximately **324,000 victims** in 2023 alone
- Address poisoning campaigns have caused individual losses exceeding **$20 million in single events** (documented by Chainalysis)
- Average loss per drainer victim: $900-$2,400 (range varies widely with wallet balance at time of drain)

---

## 7. ADDITIONAL RECOMMENDED PARALLEL FILINGS

| Agency | Portal | Case Cross-Reference |
|---|---|---|
| CFTC Whistleblower | whistleblower.gov | Primary filing — CEA § 23 |
| FBI IC3 | ic3.gov | 18 U.S.C. § 1343, § 1030, § 1029 |
| IRS Criminal Investigation | irs.gov/compliance/criminal-investigation | 18 U.S.C. § 1956 (money laundering via FixedFloat) |
| SEC Whistleblower | sec.gov/whistleblower | Rule 21F — if any drained assets qualify as securities |
| OFAC SDN Referral | ofac.treas.gov | CIS-nexus money flows — potential SDN exposure |
| Lido DAO Security | security@lido.fi | Trademark infringement notification |
| Kiln Security | security@kiln.fi | Trademark infringement notification |
| Traficom (Finland .fi ccTLD) | abuse@traficom.fi | 48h takedown SLA on dixt-lido.fi |
| Cloudflare Abuse | abuse.cloudflare.com | Origin-IP unmasking for all 4 domains |
| Etherscan Label Submit | etherscan.io/labelcloud | Flag all operator addresses |
| Chainabuse | chainabuse.com | Community threat feed submission |
| PhishTank | phishtank.com | Domain phishing database |

---

## 8. ATTRIBUTION SUMMARY

**Confidence:** HIGH  
**Working attribution:** Russian-speaking organized drainer-affiliate crew, MS Drainer / Inferno fork family  
**Operational base:** CIS region (Russia / Belarus / Kazakhstan / Ukraine diaspora — probable)

**Five corroborating signal categories:**
1. NICENIC registrar selection (preferred by Russian-affiliate operators for USDT payment and abuse non-cooperation)
2. MS Drainer kit fingerprint (Russian-language Telegram affiliate community, post-Inferno leak)
3. FixedFloat cash-out routing (documented preference of CIS-based drainer affiliates)
4. 39-hour campaign EOA burn cycle (TRM Labs documented tradecraft)
5. Same-day multi-ccTLD spin-up across 3 registrars (professional affiliate, not solo actor)

**Caveats:**
- Attribution to a nation-state actor is NOT alleged
- Individual person identification requires execution of the Coinbase subpoena (Section 5 above) — that is the single action most likely to produce a real name, address, and photograph

---

*Supplemental report generated by ProxhqVPN Multi-Engine Intelligence Suite*  
*Engines: Ghost Chain · OSINT Cross-Trace · Web Threat Intel · Domain Tracer · Drainer Kit Analyzer*  
*Case: AUFC-2026-0517-DIXT · 2026-05-17*
