// Copyright © 2026 Alpha Unlimited Technologies LLC. All rights reserved.
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
