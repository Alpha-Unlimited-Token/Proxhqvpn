#!/bin/bash
export PORT=${PORT:-7474}
export NODE_ENV=production
echo "Starting ProxhqVPN v2.2.0 on port $PORT..."
node server.bundle.cjs
