ProxhqVPN Windows Installer
============================
by ALPHA UNLIMITED TECHNOLOGIES LLC

HOW TO INSTALL:
  1. Double-click "ProxhqVPN-Windows-Setup.hta"
  2. If Windows asks "How do you want to open this file?" → click OK / mshta
  3. If SmartScreen warns "Windows protected your PC" → click "More info" → "Run anyway"
  4. Follow the wizard: Welcome → License → Installing → WireGuard → Finish

Windows SmartScreen may show a warning because the installer is downloaded from the internet.
This is normal for any installer not from the Microsoft Store. Click "More info" then
"Run anyway" to proceed safely.

WHAT IT INSTALLS:
  - Desktop shortcut to ProxhqVPN
  - Start Menu entry
  - Prompts to download WireGuard (required for VPN connections)
  - Registered in Add/Remove Programs for easy uninstall

SUPPORT: proxhqvpn.com
