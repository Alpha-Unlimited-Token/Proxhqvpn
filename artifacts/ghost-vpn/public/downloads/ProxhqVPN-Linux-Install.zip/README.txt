ProxhqVPN Linux Installer
===========================
by ALPHA UNLIMITED TECHNOLOGIES LLC

HOW TO INSTALL — Option A (double-click in file manager):
  1. Right-click "ProxhqVPN-Linux-Install.sh" → Properties → Permissions
     → check "Allow executing file as program"
  2. Double-click the file → choose "Run" or "Run in Terminal"

HOW TO INSTALL — Option B (terminal):
  1. Open a terminal in this folder
  2. chmod +x ProxhqVPN-Linux-Install.sh
  3. ./ProxhqVPN-Linux-Install.sh

The wizard uses your desktop's native GUI dialogs (zenity/yad/kdialog).
If none are available it falls back to a terminal prompt.

WHAT IT INSTALLS:
  - Desktop shortcut (ProxhqVPN.desktop)
  - ~/.local/bin/proxhqvpn launcher command
  - Installs WireGuard via your package manager (apt/dnf/pacman)
  - Registers with your application menu

To uninstall: run ~/.local/share/proxhqvpn/uninstall.sh

SUPPORT: proxhqvpn.com
