Public Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long
Public Const SND_ASYNC = &H1

Sub wav(path$)
'Plays a wav
Dim play As Long
play& = sndPlaySound(path$, SND_ASYNC)
End Sub