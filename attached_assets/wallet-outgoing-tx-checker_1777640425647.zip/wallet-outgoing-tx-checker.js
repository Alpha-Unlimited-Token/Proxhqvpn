#!/usr/bin/env node
/**
 * Wallet Outgoing-Transaction Checker
 * -----------------------------------
 * Given an EVM wallet address, reports for each major chain:
 *   • how many outgoing transfers exist (external + internal + ERC-20/721/1155)
 *   • the first and last outgoing transfer timestamps
 *   • current ETH balance + true total outgoing-tx count (the wallet's nonce)
 *
 * Uses Alchemy's `alchemy_getAssetTransfers` JSON-RPC method, which returns
 * decoded transfer events (no need to parse logs yourself).
 *
 * REQUIREMENTS
 *   - Node 18+ (uses the built-in global `fetch`)
 *   - Environment variable ALCHEMY_API_KEY  (https://www.alchemy.com/, free tier OK)
 *
 * USAGE
 *   ALCHEMY_API_KEY=xxx node wallet-outgoing-tx-checker.js 0x8e04af...
 *
 * NOTES
 *   - Alchemy's `internal` category is only supported on Ethereum and Polygon.
 *     We auto-omit it on the L2s.
 *   - `maxCount` is capped at 1000 per request. To get the FULL list, page with
 *     the `pageKey` value returned in the response (see `getAllTransfers` below).
 *   - Watch out for address-poisoning dust tokens with Cyrillic look-alikes
 *     (e.g. "UЅDT" with a Cyrillic Ѕ). They appear in `from=ADDR` queries even
 *     though the wallet didn't actually send them — the spoof contract forged
 *     the Transfer event's `from` field. Filter by `asset` and contract
 *     reputation if precision matters.
 */

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) {
  console.error('Set ALCHEMY_API_KEY in your environment.');
  process.exit(1);
}

const ADDRESS = process.argv[2];
if (!ADDRESS || !/^0x[0-9a-fA-F]{40}$/.test(ADDRESS)) {
  console.error('Usage: node wallet-outgoing-tx-checker.js 0x<40-hex-address>');
  process.exit(1);
}

// Network slug → human label. Add/remove chains here.
const NETWORKS = [
  ['eth-mainnet',     'Ethereum'],
  ['polygon-mainnet', 'Polygon' ],
  ['arb-mainnet',     'Arbitrum'],
  ['opt-mainnet',     'Optimism'],
  ['base-mainnet',    'Base'    ],
];

/**
 * Generic Alchemy JSON-RPC helper.
 */
async function rpc(network, method, params) {
  const url = `https://${network}.g.alchemy.com/v2/${ALCHEMY_KEY}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} on ${network} ${method}`);
  const json = await res.json();
  if (json.error) throw new Error(`${network} ${method}: ${json.error.message}`);
  return json.result;
}

/**
 * Get up to 1000 outgoing transfers (single page).
 * For the FULL set, see `getAllTransfers()` below — it pages until exhausted.
 */
async function getOutgoingTransfersPage(network, address) {
  const includeInternal = network === 'eth-mainnet' || network === 'polygon-mainnet';
  const category = includeInternal
    ? ['external', 'internal', 'erc20', 'erc721', 'erc1155', 'specialnft']
    : ['external',             'erc20', 'erc721', 'erc1155', 'specialnft'];

  return rpc(network, 'alchemy_getAssetTransfers', [{
    fromBlock:        '0x0',
    toBlock:          'latest',
    fromAddress:      address,
    category,
    withMetadata:     true,
    excludeZeroValue: false,
    maxCount:         '0x3e8',   // 1000 — Alchemy's hard cap per request
  }]);
}

/**
 * Page through every outgoing transfer using Alchemy's `pageKey` mechanism.
 * Returns the full array. Use this when you need the complete dataset.
 */
async function getAllOutgoingTransfers(network, address) {
  const includeInternal = network === 'eth-mainnet' || network === 'polygon-mainnet';
  const category = includeInternal
    ? ['external', 'internal', 'erc20', 'erc721', 'erc1155', 'specialnft']
    : ['external',             'erc20', 'erc721', 'erc1155', 'specialnft'];

  let pageKey, all = [];
  do {
    const params = [{
      fromBlock: '0x0', toBlock: 'latest', fromAddress: address,
      category, withMetadata: true, excludeZeroValue: false, maxCount: '0x3e8',
      ...(pageKey ? { pageKey } : {}),
    }];
    const res = await rpc(network, 'alchemy_getAssetTransfers', params);
    all.push(...(res.transfers || []));
    pageKey = res.pageKey;
  } while (pageKey);
  return all;
}

/**
 * Cheap one-call summary for a chain: first-page transfers + ETH balance + nonce.
 *   • The wallet's NONCE = total number of outgoing transactions ever sent
 *     from that address (the canonical, exact count). Use this when you only
 *     need a count, not the full transfer list.
 */
async function summarize(network, label, address) {
  try {
    const page = await getOutgoingTransfersPage(network, address);
    const transfers = page.transfers || [];
    const capped = transfers.length === 1000;

    // Bonus stats — only meaningful on EVM mainnets but we fetch them everywhere
    let balanceEth = null, nonce = null;
    try {
      const [balHex, nonceHex] = await Promise.all([
        rpc(network, 'eth_getBalance',          [address, 'latest']),
        rpc(network, 'eth_getTransactionCount', [address, 'latest']),
      ]);
      balanceEth = Number(BigInt(balHex)) / 1e18;
      nonce      = parseInt(nonceHex, 16);
    } catch { /* some networks may not return these */ }

    return { label, network, transfers, capped, balanceEth, nonce };
  } catch (err) {
    return { label, network, error: err.message };
  }
}

/**
 * Pretty-print a summary row.
 */
function printRow(s) {
  if (s.error) {
    console.log(`${s.label.padEnd(10)} : ERROR — ${s.error}`);
    return;
  }
  const count = s.transfers.length + (s.capped ? '+ (capped)' : '');
  if (s.transfers.length === 0) {
    console.log(`${s.label.padEnd(10)} : no outgoing transfers`);
  } else {
    const first = s.transfers[0];
    const last  = s.transfers[s.transfers.length - 1];
    console.log(`${s.label.padEnd(10)} : ${count} outgoing`);
    console.log(`             first: ${first.metadata?.blockTimestamp}  ${first.value || '?'} ${first.asset || ''}  → ${first.to}`);
    console.log(`             last : ${last .metadata?.blockTimestamp}  ${last .value || '?'} ${last .asset || ''}  → ${last .to}`);
  }
  if (s.balanceEth != null) console.log(`             balance: ${s.balanceEth.toFixed(6)} (native)  | nonce: ${s.nonce.toLocaleString()}`);
}

(async () => {
  console.log(`\nOutgoing-transaction report for ${ADDRESS}\n${'='.repeat(72)}`);
  for (const [network, label] of NETWORKS) {
    const s = await summarize(network, label, ADDRESS);
    printRow(s);
    console.log('');
  }
  console.log('Done.');
})();
