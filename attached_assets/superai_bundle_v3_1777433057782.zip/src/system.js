'use strict';

/*
  system.js — unified end-to-end runner.
  REQUIREMENTS MET:
  - require()s every other agent file in the lab (framework, math_engine, memory_system,
    benchmark, critic_tests, stress_test, capability_report, self_upgrade, integration_test,
    recursive_self_improver).
  - Runs a real pipeline: ACP->train NN->associative memory->hopfield completion->STDP->consolidation->ACP output.
  - Produces real computed console output.
*/

const path = require('path');
const {
  EventBus,
  PipelineEngine,
  ACP,
  SelfImprovementEngine,
  stableStringify,
  sha256,
} = require('./framework.js');

const math = require('./math_engine.js');
const mem = require('./memory_system.js');

// Require all other modules (some execute on require only when main; safe here)
require('./benchmark.js');
require('./critic_tests.js');
require('./stress_test.js');
require('./capability_report.js');
require('./self_upgrade.js');
require('./integration_test.js');
require('./recursive_self_improver.js');

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

function nowMs() {
  return Number(process.hrtime.bigint()) / 1e6;
}

function makeDeterministicClassificationData() {
  const X = [
    [-2.0, -1.0], [-1.5, -1.2], [-2.2, -0.7], [-1.8, -1.6],
    [ 0.2,  1.8], [ 0.6,  1.2], [ 0.1,  2.3], [ 1.0,  1.6],
    [ 2.0, -1.0], [ 1.6, -1.3], [ 2.2, -0.6], [ 1.8, -1.8],
  ];
  const y = [0,0,0,0, 1,1,1,1, 2,2,2,2];
  return { X, y };
}

function patternsToDataset(patterns01) {
  return patterns01.map((vec, i) => ({
    id: `p${i}`,
    label: `pattern_${i}`,
    vec: vec.slice(),
  }));
}

function computeConfusion3(predIdx, yIdx) {
  assert(Array.isArray(predIdx) && Array.isArray(yIdx) && predIdx.length === yIdx.length, 'computeConfusion3: length mismatch');
  const K = 3;
  const M = Array.from({ length: K }, () => Array(K).fill(0));
  for (let i = 0; i < yIdx.length; i++) {
    const yt = yIdx[i];
    const yp = predIdx[i];
    assert(Number.isInteger(yt) && yt >= 0 && yt < K, 'computeConfusion3: bad y');
    assert(Number.isInteger(yp) && yp >= 0 && yp < K, 'computeConfusion3: bad pred');
    M[yt][yp]++;
  }
  return M;
}

function argmaxRowWise(A) {
  assert(Array.isArray(A) && A.length > 0 && Array.isArray(A[0]), 'argmaxRowWise: A must be 2D array');
  const out = new Array(A.length);
  for (let i = 0; i < A.length; i++) {
    const row = A[i];
    let bestJ = 0;
    let bestV = row[0];
    for (let j = 1; j < row.length; j++) {
      if (row[j] > bestV) {
        bestV = row[j];
        bestJ = j;
      }
    }
    out[i] = bestJ;
  }
  return out;
}

function vec01To01Pattern(vec01) {
  assert(Array.isArray(vec01) && vec01.length > 0, 'vec01To01Pattern: vec01 must be non-empty');
  const out = new Array(vec01.length);
  for (let i = 0; i < vec01.length; i++) out[i] = vec01[i] ? 1 : 0;
  return out;
}

function flipBits(vec01, idxs) {
  const out = vec01.slice();
  for (const idx of idxs) out[idx] = out[idx] ? 0 : 1;
  return out;
}

function buildSystemPipeline({ eventBus }) {
  const pipeline = new PipelineEngine({ eventBus });

  pipeline.use(function acp_in(acpStr, ctx) {
    const env = ACP.deserialize(acpStr);
    ctx.msg = env;
    return env;
  });

  pipeline.use(async function train_math_engine(env, ctx) {
    const { X, y } = makeDeterministicClassificationData();
    const t0 = nowMs();
    const trained = math.train2LayerGD({ X, y, hidden: 10, lr: 0.2, iters: 25, seed: 20240315 });
    const t1 = nowMs();

    const W1 = trained.params.W1, b1 = trained.params.b1, W2 = trained.params.W2, b2 = trained.params.b2;

    const addBiasRowWise = (X2, b) => {
      const out = new Array(X2.length);
      for (let i = 0; i < X2.length; i++) {
        const row = X2[i];
        const r2 = new Array(row.length);
        for (let j = 0; j < row.length; j++) r2[j] = row[j] + b[j];
        out[i] = r2;
      }
      return out;
    };

    const Z1 = addBiasRowWise(math.matMul(X, W1), b1);
    const A1 = math.relu(Z1);
    const Z2 = addBiasRowWise(math.matMul(A1, W2), b2);
    const P = math.softmax(Z2);

    const pred = argmaxRowWise(P);
    let ok = 0;
    for (let i = 0; i < y.length; i++) if (pred[i] === y[i]) ok++;
    const acc = ok / y.length;

    ctx.training = {
      iters: 25,
      ms: Number((t1 - t0).toFixed(3)),
      loss: Number(trained.final.loss.toFixed(6)),
      acc: Number(acc.toFixed(4)),
      confusion: computeConfusion3(pred, y),
    };
    return env;
  });

  pipeline.use(function build_memory_and_retrieve(env, ctx) {
    const n = 18;
    const patterns = patternsToDataset(mem.makeDeterministicPatterns5(n));
    const am = new mem.AssociativeMemory({ metric: 'hamming01' });
    for (const p of patterns) am.addPattern(p);

    const target = patterns[3];
    const corrupted = flipBits(target.vec, [2, 7, 15].map(i => i % n));
    const top3 = am.retrieveClosest(corrupted, { topK: 3 }).map(r => ({ id: r.id, dist: r.dist }));

    ctx.memory = { n, stored: am.size(), ids: am.list(), target: target.id, top3FromCorrupt: top3 };
    ctx._am = am;
    ctx._patterns = patterns;
    ctx._corrupted = corrupted;
    return env;
  });

  pipeline.use(function hopfield_completion(env, ctx) {
    const n = ctx.memory.n;
    const hop = new mem.PatternCompletionHopfield({ n });
    for (const p of ctx._patterns) hop.storePattern(p.vec);

    const completion = hop.complete(ctx._corrupted, { steps: 10 });
    const match = ctx._am.retrieveClosest(completion.out01, { topK: 1 })[0];

    ctx.hopfield = {
      completedClosest: { id: match.id, dist: match.dist },
      energyCurve: completion.curve.map(e => Number(e.energy.toFixed(6))),
      completionOk: match.id === ctx.memory.target,
    };
    return env;
  });

  pipeline.use(function stdp_and_consolidation(env, ctx) {
    const stdp = new mem.STDPNetwork({ n: 3, tauPlus: 20, tauMinus: 20, APlus: 0.05, AMinus: 0.06, wMin: 0, wMax: 1 });
    const w01Before = stdp.getWeight(0, 1);
    const u1 = stdp.spike(0, 100);
    const u2 = stdp.spike(1, 110);
    const w01After = stdp.getWeight(0, 1);

    const w21Before = stdp.getWeight(2, 1);
    stdp.spike(1, 200);
    stdp.spike(2, 215);
    const w21After = stdp.getWeight(2, 1);

    const cons = new mem.MemoryConsolidation({ repeatsToConsolidate: 3 });
    const key = 'episode:alpha';
    const obs = [
      cons.observe(key, { valence: 0.2, context: 'lab' }),
      cons.observe(key, { valence: 0.3, context: 'lab' }),
      cons.observe(key, { valence: 0.4, context: 'lab' }),
    ];

    ctx.plasticity = {
      stdp: {
        w01Before: Number(w01Before.toFixed(6)),
        w01After: Number(w01After.toFixed(6)),
        delta01: Number((w01After - w01Before).toFixed(6)),
        updates: u1.length + u2.length,
        w21Before: Number(w21Before.toFixed(6)),
        w21After: Number(w21After.toFixed(6)),
        delta21: Number((w21After - w21Before).toFixed(6)),
      },
      consolidation: {
        key,
        obs,
        stats: cons.stats(),
        hasLongTerm: cons.hasLongTerm(key),
      },
    };
    return env;
  });

  pipeline.use(function summarize_and_acp_out(env, ctx) {
    const summary = {
      input: { id: env.id, from: env.from, to: env.to, type: env.type },
      training: ctx.training,
      memory: ctx.memory,
      hopfield: ctx.hopfield,
      plasticity: ctx.plasticity,
    };

    const canonical = stableStringify(summary);
    const outMsg = ACP.serialize({
      from: 'system',
      to: env.from || 'unknown',
      type: 'system:result',
      meta: {
        inSig: sha256(stableStringify(env)),
        outHash: sha256(canonical),
      },
      payload: summary,
    });
    return outMsg;
  });

  return pipeline;
}

async function main() {
  const bus = new EventBus();

  bus.on('pipeline:step:start', (e) => {
    console.log('PIPELINE_STEP_START', stableStringify({ i: e.index, name: e.name, dataHash: e.dataHash.slice(0, 12) }));
  });
  bus.on('pipeline:step:end', (e) => {
    console.log('PIPELINE_STEP_END', stableStringify({ i: e.index, name: e.name, ms: Number(e.ms.toFixed(3)), dataHash: e.dataHash.slice(0, 12) }));
  });

  const sie = new SelfImprovementEngine({ rootDir: process.cwd(), mainFile: path.basename(__filename), eventBus: bus });
  const baseline = await sie.scoreSelf();
  console.log('BASELINE_INTELLIGENCE_QUOTIENT', Number(baseline.summary.intelligence.quotient.toFixed(6)));

  const input = ACP.serialize({
    from: 'user',
    to: 'system',
    type: 'run',
    payload: {
      ts: Date.now(),
      note: 'integrated_pipeline',
      vec: vec01To01Pattern(mem.makeDeterministicPatterns5(18)[0]).slice(0, 10),
    },
  });

  const pipeline = buildSystemPipeline({ eventBus: bus });
  console.log('PIPELINE_DESC', stableStringify(pipeline.describe()));

  const outStr = await pipeline.run(input, {});
  const outEnv = ACP.deserialize(outStr);

  const p = outEnv.payload;
  console.log('SYSTEM_OUTPUT', stableStringify({
    outType: outEnv.type,
    outHashStart: outEnv.meta.outHash.slice(0, 16),
    train: { loss: p.training.loss, acc: p.training.acc, ms: p.training.ms },
    assocTop1: p.memory.top3FromCorrupt[0],
    hopfieldOk: p.hopfield.completionOk,
    stdpDelta01: p.plasticity.stdp.delta01,
    consolidated: p.plasticity.consolidation.hasLongTerm,
  }));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('SYSTEM_FAILED', e && e.stack ? e.stack : e);
    process.exitCode = 1;
  });
}

module.exports = { buildSystemPipeline };