#!/bin/bash
set -e
npm install
node run.js
