# ProxhqVPN Source Code Audit — Initial Full-Package Review

Package reviewed: `ProxhqVPN-Audit-Package.zip`

I read `ProxhqVPN-ChatGPT-Audit-Prompt.md` first, then unpacked and inspected `ProxhqVPN-SourceCode-Export.zip`.

## Inventory actually present

- 657 files total.
- About 186,653 lines across TypeScript/TSX/JS/shell/PowerShell/HTML.
- Present: `artifacts/ghost-vpn`, `artifacts/api-server`, `artifacts/omega-dashboard`, `artifacts/quantum-audit`, `lib/*`, `standalone/*`.
- Not present: the prompt mentions `artifacts/mobile/src`, but there is no `artifacts/mobile` directory in this zip.
- Desktop/mobile setup assets are present under `standalone/` and `artifacts/ghost-vpn/public/downloads/windows/`.

---

## SECTION 1 — Bug & Error Audit

### 1. Critical — root `dev` script likely unusable because API requires `PORT`

**File:** `artifacts/api-server/src/index.ts`

**Before:**
```ts
const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}
```

**After:**
```ts
const rawPort = process.env.PORT ?? (process.env.NODE_ENV === "development" ? "5000" : undefined);

if (!rawPort) {
  throw new Error("PORT environment variable is required in production.");
}
```

**Why:** local development should not crash immediately when `PORT` is omitted.

---

### 2. Critical — startup auto-installs OS packages from server code

**File:** `artifacts/api-server/src/index.ts`

**Before:**
```ts
exec(
  `DEBIAN_FRONTEND=noninteractive apt-get install -y ${missing.join(" ")} 2>&1`,
  { timeout: 180000 },
  ...
);
```

**After:**
```ts
function autoInstallDependencies() {
  if (process.env.PROXHQ_ALLOW_RUNTIME_APT !== "1") {
    logger.info("Runtime package installation disabled. Use Dockerfile/bootstrap scripts instead.");
    return;
  }
  // keep package list as a fixed allowlist, never derived from request/user input
}
```

**Why:** production services should not mutate host packages at runtime. This breaks immutable deployment, can fail under non-root, and creates supply-chain/control risk.

---

### 3. Critical — `ensureTor()` runs unconditionally and writes to `/tmp`

**File:** `artifacts/api-server/src/index.ts`

**Before:**
```ts
function ensureTor() {
  const dataDir = "/tmp/tor-data";
  fs.mkdirSync(dataDir, { recursive: true });
  exec(
    `tor --RunAsDaemon 1 --DataDirectory ${dataDir} --SocksPort 9050 --ControlPort 9051 --Log "warn stderr"`,
    ...
  );
}
ensureTor();
```

**After:**
```ts
function ensureTor() {
  if (process.env.PROXHQ_ENABLE_TOR !== "1") {
    logger.info("Tor disabled by configuration");
    return;
  }
  const dataDir = process.env.TOR_DATA_DIR ?? pathLib.join(process.cwd(), ".runtime", "tor-data");
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  execFile("tor", [
    "--RunAsDaemon", "1",
    "--DataDirectory", dataDir,
    "--SocksPort", "9050",
    "--ControlPort", "9051",
    "--Log", "warn stderr",
  ], (err) => { /* existing logging */ });
}
```

**Why:** Tor should be an explicitly enabled deployment service, not a default side process started by the web API.

---

### 4. Warning — in-memory job stores lose work on restart and can grow unbounded

**File:** `artifacts/api-server/src/routes/wallet-tx.ts`

**Before:**
```ts
const jobs = new Map<string, ScanJob>();
```

**After:**
```ts
// Use DB-backed jobs with retention cleanup
// wallet_scan_jobs(id, user_id, status, phase, progress_json, result_json, created_at, updated_at, expires_at)
setInterval(async () => {
  await db.delete(walletScanJobsTable).where(lt(walletScanJobsTable.expiresAt, new Date()));
}, 60_000 * 30);
```

**Why:** scan jobs and logs should survive restarts and should have TTL cleanup.

---

### 5. Warning — API responses are inconsistent

**Files:** most `artifacts/api-server/src/routes/*.ts`

Current responses vary between:
```ts
res.json(result);
res.json({ ok: true });
res.json({ error: "..." });
res.json({ success: true, data });
```

**Fix:** add a shared response helper.

**File to add:** `artifacts/api-server/src/lib/api-response.ts`
```ts
export type ApiSuccess<T> = { success: true; data: T };
export type ApiFailure = { success: false; error: { code: string; message: string; details?: unknown } };

export function ok<T>(data: T): ApiSuccess<T> {
  return { success: true, data };
}

export function fail(code: string, message: string, details?: unknown): ApiFailure {
  return { success: false, error: { code, message, details } };
}
```

**Why:** consistent envelopes simplify frontend hooks, logging, and support debugging.

---

### 6. Warning — `dev-audit` has manual URL checks that miss IPv6, DNS rebinding, and decimal/hex IP forms

**File:** `artifacts/api-server/src/routes/dev-audit.ts`

**Before:**
```ts
const isInternal = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host);
if (isInternal) {
  return res.status(400).json({ error: "Cannot probe internal/loopback addresses." });
}
```

**After:**
```ts
import { checkSsrf } from "../lib/ssrfGuard";

const ssrf = await checkSsrf(endpoint.trim(), true);
if (ssrf.blocked) {
  return res.status(400).json({ error: `Blocked unsafe target: ${ssrf.reason}` });
}
```

**Why:** centralized SSRF validation is already available and stronger than string-prefix checks.

---

### 7. Warning — OSINT route performs external HTTP/TLS without SSRF guard

**File:** `artifacts/api-server/src/routes/osint.ts`

**Before:**
```ts
target = target.trim().replace(/^https?:\/\//, "").replace(/\/.*/, "").toLowerCase();
if (target === "localhost" || target.startsWith("127.") || target.startsWith("192.168.") || target.startsWith("10.")) {
  return res.status(400).json({ error: "Private/internal targets not allowed" });
}
```

**After:**
```ts
import { checkSsrf } from "../lib/ssrfGuard";

const normalizedTarget = target.trim().replace(/^https?:\/\//, "").replace(/\/.*/, "").toLowerCase();
const ssrf = await checkSsrf(`https://${normalizedTarget}`, true);
if (ssrf.blocked) {
  return res.status(400).json({ error: `Blocked unsafe target: ${ssrf.reason}` });
}
target = normalizedTarget;
```

**Why:** blocks IPv6 loopback, DNS-resolved private addresses, metadata IPs, and rebinding-style hostnames.

---

### 8. Warning — `checkSsrf` does not block IPv4 `0.0.0.0/8`, CGNAT, documentation ranges, or IPv4-mapped non-private edge cases

**File:** `artifacts/api-server/src/lib/ssrfGuard.ts`

**Add ranges:**
```ts
const PRIVATE_RANGES: [number, number, number][] = [
  [0x00000000, 0xff000000, 4], // 0.0.0.0/8
  [0x7f000000, 0xff000000, 4], // 127.0.0.0/8
  [0x0a000000, 0xff000000, 4], // 10.0.0.0/8
  [0x64400000, 0xffc00000, 4], // 100.64.0.0/10 CGNAT
  [0xa9fe0000, 0xffff0000, 4], // 169.254.0.0/16
  [0xac100000, 0xfff00000, 4], // 172.16.0.0/12
  [0xc0000000, 0xffffff00, 4], // 192.0.0.0/24
  [0xc0000200, 0xffffff00, 4], // 192.0.2.0/24 TEST-NET-1
  [0xc0a80000, 0xffff0000, 4], // 192.168.0.0/16
  [0xc6336400, 0xffffff00, 4], // 198.51.100.0/24
  [0xcb007100, 0xffffff00, 4], // 203.0.113.0/24
  [0xe0000000, 0xf0000000, 4], // multicast
  [0xf0000000, 0xf0000000, 4], // reserved
];
```

**Why:** SSRF guards should reject all non-public routing ranges by default.

---

### 9. Critical — terminal route supports unrestricted shell via `ghostMode`

**File:** `artifacts/api-server/src/routes/terminal.ts`

**Before:**
```ts
// ProxhqVPN mode bypasses allowlist (full shell access)
if (!body.ghostMode && !isAllowed(cmd)) { ... }

const { stdout, stderr } = await execAsync(cmd, {
  timeout: body.timeout,
  shell: "/bin/bash",
  env: { ...process.env, HOME: process.env.HOME ?? "/tmp" },
});
```

**After:**
```ts
if (body.ghostMode) {
  return res.status(403).json({ error: "Unrestricted shell mode is disabled in production." });
}
if (!isAllowed(cmd) || hasShellChain(cmd)) {
  return res.status(403).json({ error: "Command not allowed." });
}
const parsed = parseAllowedCommand(cmd); // strict tokenizer, returns { file, args }
const child = spawn(parsed.file, parsed.args, {
  shell: false,
  timeout: body.timeout,
  env: { PATH: SAFE_TOOL_PATH, HOME: "/tmp" },
});
```

**Why:** `exec` with a user-controlled string is a high-risk command injection surface even behind admin auth. Use `spawn` with `shell:false` and argument arrays.

---

### 10. Critical — public or semi-public remote-control/agent subsystem needs stricter boundaries

**Files:**
- `artifacts/api-server/src/routes/omega/agent.ts`
- `artifacts/api-server/src/routes/omega/keylogger.ts`
- `artifacts/api-server/src/routes/omega/remote-commands.ts`
- `artifacts/api-server/src/routes/index.ts`
- `artifacts/api-server/src/app.ts`

**Issue:** the Omega subsystem includes keystroke capture, clipboard capture, screenshots, remote commands, and public check-in endpoints. Even when intended for authorized testing, this is an extremely sensitive capability and must be isolated from the general VPN API.

**Minimum defensive fixes:**
```ts
// app.ts — mount Omega only under explicit feature gate
if (process.env.PROXHQ_ENABLE_OMEGA === "1") {
  app.use("/api/omega", requireCommandCenter, requireAdmin, omegaRouter);
}
```

```ts
// omega/agent.ts — bind token to host AND tenant/project, require HMAC or mTLS-like shared secret
const signature = req.headers["x-omega-signature"];
if (!verifyOmegaSignature(signature, req.rawBody, process.env.OMEGA_SIGNING_SECRET)) {
  return res.status(401).json({ error: "Invalid agent signature" });
}
```

**Why:** remote-control features should be feature-gated, admin-only, separately logged, consent-based, and deployable as a separate service, not mixed into consumer VPN APIs.

---

### 11. Warning — `app.use('/api/omega', omegaRouter)` is mounted outside the main route entitlement tree

**File:** `artifacts/api-server/src/app.ts`

**Before:**
```ts
app.use("/api", router);
app.use("/api/omega", omegaRouter);
```

**After:**
```ts
// remove app-level omega mount
app.use("/api", router);

// in routes/index.ts
router.use("/omega", requireAdmin, omegaRouter);
```

**Why:** current ordering incidentally passes through `/api` auth first, but it is fragile. Put the mount exactly where entitlement is enforced.

---

### 12. Warning — `CORS` allows all Replit domains by regex

**File:** `artifacts/api-server/src/app.ts`

**Before:**
```ts
[/\.replit\.dev$/, /\.repl\.co$/, /\.replit\.app$/]
```

**After:**
```ts
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);
if (process.env.NODE_ENV === "production" && ALLOWED_ORIGINS.length === 0) {
  throw new Error("ALLOWED_ORIGINS must be set in production");
}
```

**Why:** any unrelated Replit app should not be a trusted credentialed origin in production.

---

### 13. Warning — `getClientIp()` trusts `x-forwarded-for` directly

**File:** `artifacts/api-server/src/app.ts`

**Before:**
```ts
const forwarded = req.headers["x-forwarded-for"];
const firstIp = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
return (firstIp ?? req.ip ?? "unknown").trim();
```

**After:**
```ts
function getClientIp(req: Request): string {
  return req.ip ?? req.socket.remoteAddress ?? "unknown";
}
```

**Why:** because Express `trust proxy` should be configured only for known proxies; otherwise attacker-supplied XFF can evade or poison IP-ban accounting.

---

### 14. Warning — DB pool lacks SSL config and limits

**File:** `lib/db/src/index.ts`

**Before:**
```ts
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
```

**After:**
```ts
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX ?? 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
  ssl: process.env.PGSSL === "require" ? { rejectUnauthorized: true } : undefined,
});
```

**Why:** prevents runaway connection count and makes production TLS explicit.

---

## SECTION 2 — Security Audit

### Critical findings

1. **Unrestricted shell path** — `terminal.ts` supports `ghostMode` and `exec` string execution. Disable in production and replace with `spawn(..., shell:false)`.
2. **Remote-control/keylogger subsystem** — Omega includes public callbacks, keystrokes, clipboard, screenshots, messages, and remote commands. Isolate behind `PROXHQ_ENABLE_OMEGA`, admin-only access, separate service, HMAC-signed callbacks, and explicit consent/audit logs.
3. **Runtime OS package installation** — API startup invokes `apt-get`. Move to Dockerfile or bootstrap script.
4. **Node setup script embeds `DAEMON_PSK` into downloadable script** — even though admin-only, this should be short-lived, one-time scoped, and revoked after registration.

### High findings

1. **SSRF gaps** in `dev-audit.ts`, `osint.ts`, `node-cracker.ts`, and any route taking URLs/endpoints. Use `checkSsrf()` everywhere and extend its blocked ranges.
2. **CORS regex trust** allows broad Replit origins in production.
3. **In-memory stores** for jobs, screenshots, and tokens (`omega-store`) create retention/leak risks and lose data on restart.
4. **Sensitive DB fields** include WireGuard private keys in `nodesTable.privateKey`. These should be envelope-encrypted with KMS or at minimum AES-GCM using an env-held key.

### Medium findings

1. **Error shape leakage** — some routes return `err.message` to client. Replace with generic client messages and structured server logs.
2. **Missing per-user tenancy on many tables** — VPN/security assets need `user_id` or `org_id`, otherwise future multi-tenant behavior risks cross-account data leaks.
3. **Insufficient DB indexes** on `hostId`, `createdAt`, `status`, `token`, and subscription lookup fields.
4. **Raw `fetch()` usage in frontend** is widespread, bypassing generated API hooks and consistent auth/error handling.

### Low findings

1. Console/logging inconsistency across frontend and backend.
2. Multiple pages/components exceed 400 lines and are difficult to review.
3. Large static docs/pages are bundled as TSX and should become markdown/MDX or fetched content.

---

## SECTION 3 — Architecture & Code Quality Review

### Backend

- Route organization is broad but too flat. Split into modules: `vpn`, `billing`, `admin`, `command-center`, `public`, `omega-isolated`.
- Move every route registration into one entitlement map instead of scattering `requireAccess`, `requireCommandCenter`, and `requireAdmin` manually.
- Add a central async route wrapper:
```ts
export const asyncRoute =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
```
- Add shared `ok/fail` response helpers.
- Move long-running scans to a queue/worker model. Do not run CPU/network-heavy scans inside Express request handlers.

### Frontend

Large components/pages to split immediately:
- `Downloads.tsx` — 3,202 lines
- `UserGuide.tsx` — 2,596 lines
- `Manuals.tsx` — 2,479 lines
- `OsintRecon.tsx` — 2,033 lines
- `OmniStrike.tsx` — 1,906 lines
- `BugBountyHub.tsx` — 1,598 lines
- `Home.tsx` — 1,137 lines
- `SocialBreach.tsx` — 1,080 lines
- `VpnCoexist.tsx` — 1,130 lines

Refactor pattern:
```txt
pages/Downloads.tsx
features/downloads/
  DownloadsPage.tsx
  PlatformSelector.tsx
  InstallerCard.tsx
  ChecksumPanel.tsx
  MobileSetupWizard.tsx
  useDownloads.ts
```

### Monorepo

- `pnpm-workspace.yaml` is advanced and mostly good, but platform-specific override removals may break local development on non-Linux machines. Keep Replit production overrides in a separate `.pnpmfile.cjs` or deployment-specific workspace file.
- Root license says MIT while files say all rights reserved. Align package metadata with copyright policy.

---

## SECTION 4 — UX Redesign

### Proposed one-screen layout

```txt
┌─────────────────────────────────────────────────────────────────────────────┐
│ Top Status Bar: VPN state | active server | IP | leaks | subscription | help │
├───────────────┬─────────────────────────────────────────────────────────────┤
│ Sidebar       │ Main Workspace                                               │
│               │                                                             │
│ VPN           │ [Active module header] [primary action] [status chips]       │
│  Connect      │ ┌───────────────────────┬───────────────────────────────┐   │
│  Servers      │ │ Primary Control Panel │ Context / Results / Logs       │   │
│  Devices      │ └───────────────────────┴───────────────────────────────┘   │
│  Privacy      │                                                             │
│ Security      │ Bottom drawer: logs, jobs, notifications, support export     │
│  Recon        │                                                             │
│  Web Testing  │                                                             │
│  Scanners     │                                                             │
│  Reports      │                                                             │
│ Admin         │                                                             │
└───────────────┴─────────────────────────────────────────────────────────────┘
```

### Main layout code skeleton

**File to add:** `artifacts/ghost-vpn/src/components/app-shell/UnifiedShell.tsx`
```tsx
import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";

const sections = [
  { title: "VPN", items: [
    ["/vpn", "Connect"], ["/vpn/servers", "Servers"], ["/vpn/devices", "Devices"], ["/vpn/privacy", "Privacy"],
  ]},
  { title: "Security", items: [
    ["/security/recon", "Recon"], ["/security/web", "Web Testing"], ["/security/scanners", "Scanners"], ["/security/reports", "Reports"],
  ]},
  { title: "Account", items: [["/billing", "Billing"], ["/support", "Support"]] },
];

export function UnifiedShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [logsOpen, setLogsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/95 px-4 py-2">
        <div className="flex items-center justify-between gap-4">
          <strong>ProxhqVPN</strong>
          <div className="flex gap-2 text-xs">
            <span>VPN: disconnected</span><span>IP: checking…</span><span>Leaks: unknown</span>
          </div>
        </div>
      </header>
      <div className="grid min-h-[calc(100vh-49px)] grid-cols-[260px_1fr]">
        <aside className="border-r border-slate-800 p-3">
          {sections.map((section) => (
            <div key={section.title} className="mb-5">
              <div className="mb-2 text-xs uppercase text-slate-500">{section.title}</div>
              {section.items.map(([href, label]) => (
                <Link key={href} href={href} className={`block rounded px-3 py-2 ${location === href ? "bg-slate-800" : "hover:bg-slate-900"}`}>
                  {label}
                </Link>
              ))}
            </div>
          ))}
        </aside>
        <main className="relative p-5">
          {children}
          <button className="fixed bottom-4 right-4 rounded bg-emerald-500 px-4 py-2 text-black" onClick={() => setLogsOpen(!logsOpen)}>
            Logs / Jobs
          </button>
          {logsOpen && <div className="fixed bottom-16 right-4 h-80 w-[520px] rounded border border-slate-700 bg-slate-900 p-4">Job log drawer</div>}
        </main>
      </div>
    </div>
  );
}
```

---

## SECTION 5 — Performance & Scalability

### Add DB indexes

**Migration SQL:**
```sql
CREATE INDEX IF NOT EXISTS idx_nodes_status_region ON nodes(status, region);
CREATE INDEX IF NOT EXISTS idx_nodes_layer_hop ON nodes(layer, hop_index);
CREATE INDEX IF NOT EXISTS idx_beacon_alerts_status_detected ON beacon_alerts(status, detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_devices_status_last_seen ON devices(status, last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_dns_shield_rules_domain ON dns_shield_rules(domain);
CREATE INDEX IF NOT EXISTS idx_firewall_rules_enabled_priority ON firewall_rules(enabled, priority);
CREATE INDEX IF NOT EXISTS idx_omega_keystrokes_host_created ON omega_keystrokes(host_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_omega_events_host_created ON omega_events(host_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_omega_remote_commands_host_status ON omega_remote_commands(host_id, status);
CREATE INDEX IF NOT EXISTS idx_crypto_subscriptions_user_expires ON crypto_subscriptions(user_id, expires_at DESC);
```

### Replace polling with WebSocket/SSE

Use WS/SSE for:
- scan job progress
- VPN node status
- active tunnel state
- notifications
- Omega/agent status if that subsystem remains enabled

### Bundle splitting

Lazy-load heavy routes:
```tsx
const OsintRecon = lazy(() => import("./pages/OsintRecon"));
const Downloads = lazy(() => import("./pages/Downloads"));
const UserGuide = lazy(() => import("./pages/UserGuide"));
const OmniStrike = lazy(() => import("./pages/OmniStrike"));
const QuantumAudit = lazy(() => import("./pages/QuantumAudit"));
```

### Installer ZIP size

- Publish per-platform packages instead of one all-platform 111 MB bundle.
- Add manifest JSON with platform, version, sha256, signature, size.
- Do not bundle repeated WireGuard binaries if the platform installer can use official package managers.

---

## SECTION 6 — What I Would Add

### Product additions vs major VPNs

1. Signed config delivery with device-bound keys.
2. Multi-hop WireGuard routes with clear UI and latency estimates.
3. Obfuscation mode that is explicit, measurable, and warns about speed impact.
4. Per-app split tunnel UI with OS-specific install helper.
5. In-app diagnostics: DNS leak, WebRTC leak, IPv6 leak, kill-switch verification.

### Security suite additions, defensively scoped

1. Project/workspace model: each scan belongs to a user/org project.
2. Scope authorization records: target domains/IPs require proof-of-ownership or written authorization flag.
3. Report builder: findings, evidence, remediation, export to PDF/Markdown.
4. Passive-first scanning mode by default.
5. Legal/scope guardrail modal before active scans.

### Developer experience

1. Add `pnpm test`, `pnpm lint`, `pnpm typecheck` to CI.
2. Add Playwright smoke tests for auth, pricing, downloads, and VPN dashboard.
3. Add API integration tests using Supertest.
4. Add route entitlement tests that prove public/protected/admin routes behave correctly.
5. Add OpenAPI generation from route contracts and remove raw frontend `fetch()` calls over time.

---

## Summary table

| Area/File | Critical | Warning | Suggestion |
|---|---:|---:|---:|
| `api-server/src/index.ts` | 2 | 2 | 2 |
| `api-server/src/app.ts` | 1 | 3 | 1 |
| `api-server/src/routes/terminal.ts` | 1 | 1 | 1 |
| `api-server/src/routes/dev-audit.ts` | 0 | 2 | 1 |
| `api-server/src/routes/osint.ts` | 0 | 2 | 1 |
| `api-server/src/lib/ssrfGuard.ts` | 0 | 1 | 1 |
| `api-server/src/routes/omega/*` | 1 | 4 | 2 |
| `lib/db/src/schema/*` | 0 | 3 | 4 |
| `ghost-vpn/src/pages/*` | 0 | 4 | 7 |
| `standalone/* installers` | 0 | 3 | 5 |
| Missing `artifacts/mobile` | 0 | 1 | 0 |

## Highest-priority fix order

1. Disable unrestricted shell mode and migrate command execution to `spawn(shell:false)`.
2. Isolate or disable Omega remote-control/keylogging subsystem unless it is a separately consented, admin-only internal testing product.
3. Move `apt-get`/Tor startup out of API runtime and into deployment scripts.
4. Apply SSRF guard everywhere URLs/endpoints are accepted.
5. Add DB tenancy columns/indexes before more users are onboarded.
6. Split large frontend pages and replace raw fetch calls with typed hooks.
7. Add signed installer/config manifests.
