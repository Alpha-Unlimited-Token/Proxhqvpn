# Alpha Unlimited Mining Technology Package

Complete extract of every mining/blockchain/AACC/QMGE/forge engine and its wiring,
ready to be lifted into another project. Generated April 2026 from the live
Alpha Unlimited Trading codebase.

> **PROPRIETARY**: All technology in this package is the intellectual property of
> Alpha Unlimited Trading Company. The proprietary guard module (`private/security/
> alpha_proprietary_guard.ts`) is loaded by every engine and emits copyright /
> DMCA / DTSA headers in every JSON, HTML, and PDF output.

---

## 1. What's in this package

```
mining-tech-package/
├── README.md                       ← this file
├── ARCHITECTURE.md                 ← system topology & data flow
├── WIRING_GUIDE.md                 ← step-by-step integration into a new project
├── BLOCKCHAIN_INTEGRATION.md       ← chain-by-chain endpoint reference
├── ENV_TEMPLATE.env                ← required environment variables
├── package.deps.json               ← npm dependencies you must install
│
├── client/
│   ├── public/manifest-miner.json
│   └── src/
│       ├── lib/
│       │   ├── mining/             ← browser-side mining client
│       │   │   ├── connection-manager.ts
│       │   │   ├── coordinator.ts
│       │   │   ├── hardware-registry.ts
│       │   │   └── protocol-handlers.ts
│       │   └── qmge/               ← Quantum Mining Genesis Engine (frontend)
│       │       ├── engine.ts
│       │       ├── index.ts
│       │       └── types.ts
│       └── pages/
│           ├── MiningCommandCenter.tsx    ← main mining dashboard
│           ├── AlphaBlockchain.tsx        ← chain explorer UI
│           ├── AlphaForge.tsx             ← block-forge UI (PoW worker)
│           ├── AlphaTradingMiner.tsx
│           ├── BlockchainHashAnalyzer.tsx
│           ├── LearnBIF.tsx               ← Blockchain Integrity Framework docs
│           ├── LearnBridgeFusion.tsx
│           ├── LearnQMGE.tsx
│           ├── GetQMGEApp.tsx
│           └── QMGEStandalone.tsx         ← standalone PWA mining app
│
├── server/
│   ├── blockchain/                 ← FULL custom L1 blockchain implementation
│   │   ├── index.ts                ← public API
│   │   ├── chain.ts                ← chain state, longest-chain rule
│   │   ├── block.ts                ← block structure & hashing
│   │   ├── consensus.ts            ← Proof-of-Work (SHA-256 difficulty target)
│   │   ├── mint.ts                 ← block-reward issuance
│   │   ├── wallet.ts               ← keypair / address derivation
│   │   ├── founder.ts              ← founder-block / genesis logic
│   │   ├── p2p.ts                  ← peer-to-peer node networking
│   │   ├── routes.ts               ← Express router (/api/blockchain/*)
│   │   ├── stratum.ts              ← Stratum-V1 mining-pool server
│   │   ├── spider.ts               ← chain-walking & re-org detector
│   │   ├── safeSend.ts             ← Alpha SafeSend Protocol™ (off-chain warning)
│   │   ├── safeSendRoutes.ts
│   │   ├── safeAsset.ts            ← Alpha SafeAsset Protocol™ (RWA tokenization)
│   │   ├── insuranceVault.ts       ← Insurance Vault smart contract logic
│   │   ├── forensicHooks.ts        ← per-block forensic instrumentation
│   │   └── forensicTracer.ts       ← deep tx tracer
│   │
│   └── services/
│       ├── minerService.ts         ← user-facing miner CRUD + auto-tune
│       ├── integrityBeacon.ts      ← Mining Integrity Beacon™ (heartbeats)
│       ├── spiderBeacon.ts         ← Spider Beacon (forensic anchoring)
│       └── chain-adapters/         ← UCAL adapters used by mining-bridge
│           ├── index.ts
│           ├── types.ts
│           ├── evmAdapter.ts       ← ETH/Polygon/Arbitrum/Optimism/Base
│           ├── solanaAdapter.ts
│           ├── bitcoinAdapter.ts
│           ├── tronAdapter.ts
│           ├── tonAdapter.ts
│           └── xrplAdapter.ts
│
├── contracts/atc/                  ← on-chain Solidity contracts
│   ├── AlphaTrackingCoin.sol       ← ERC-20 forensic-tracking token
│   ├── DAUv2_DyePack.sol           ← DAUv2 "Dye Pack" forensic token
│   ├── DAUv2_Lite.sol
│   ├── compile.ts                  ← solc compilation pipeline
│   ├── deploy.ts                   ← Sepolia / mainnet deployer
│   ├── DAUv2_Deploy.ts
│   ├── DAUv2_DeployNow.ts
│   ├── DAUv2_MintRemaining.ts
│   ├── DAUv2_AddressPoisoning.ts
│   ├── DAUv2_DeepForensics.ts
│   ├── DAUv2_HybridFusion.ts
│   ├── send.ts                     ← live tx broadcaster
│   ├── listener.ts                 ← on-chain event listener (long-running)
│   ├── DAUv2_Listener.ts
│   ├── artifacts/                  ← compiled bytecode + ABIs
│   │   ├── AlphaTrackingCoin.json
│   │   └── DAUv2DyePack.json
│   └── deployments/                ← deployment records (chain, address, tx)
│       ├── mainnet-deployment.json
│       ├── sepolia-deployment.json
│       └── dauv2-mainnet-deployment.json
│
├── private/security/
│   └── alpha_proprietary_guard.ts  ← REQUIRED license enforcement (every engine imports)
│
└── routes-extracted/
    └── mining-routes.ts            ← all 33 Express handlers, ready to mount
```

Total: **104 files, ~9.4 MB**.

---

## 2. The 30-second mental model

```
                             ┌────────────────────────────┐
                             │   YOUR NEW HOST APP        │
                             │   (Express / Next / etc.)  │
                             └──────────────┬─────────────┘
                                            │ mounts
                                            ▼
        ┌───────────────────────────────────────────────────────────┐
        │  routes-extracted/mining-routes.ts                        │
        │  registerMiningRoutes(app, { isAuthenticated, ... })      │
        └────┬──────────────────────────────────────────────────┬───┘
             │                                                  │
             ▼                                                  ▼
   ┌─────────────────────┐                          ┌──────────────────────┐
   │ server/blockchain/  │                          │ server/services/     │
   │  • chain.ts (PoW)   │ ◄──── stratum:tcp ────► │  • minerService      │
   │  • consensus.ts     │                          │  • integrityBeacon   │
   │  • p2p.ts           │ ◄──── peer:tcp  ────►   │  • spiderBeacon      │
   │  • spider.ts        │                          └──────────┬───────────┘
   └──────────┬──────────┘                                     │
              │ writes blocks/txs                              │ pushes signals
              ▼                                                ▼
   ┌────────────────────┐         ┌────────────────────────────────────────┐
   │ Postgres (Drizzle) │ ◄────── │ chain-adapters/  ───► EVM/SOL/BTC/...  │
   │   blocks, txs,     │         │ (UCAL: Alchemy, mempool.space, etc.)   │
   │   miners, beacons  │         └────────────────────────────────────────┘
   └────────────────────┘

                            ◄──── HTTPS REST ────►

   ┌───────────────────────────────────────────────────────────────────────┐
   │ client/src/lib/mining/      —  browser miner controller               │
   │   • connection-manager   ← talks to /api/miners + WebSocket stratum   │
   │   • coordinator          ← starts/stops jobs, splits nonces           │
   │   • hardware-registry    ← detects GPU/CPU/ASIC capabilities          │
   │   • protocol-handlers    ← Stratum V1 / V2 frame parser               │
   │ client/src/lib/qmge/        —  Quantum Mining Genesis Engine          │
   │   • engine.ts            ← AI-assisted block-template optimizer       │
   │ client/src/pages/MiningCommandCenter.tsx                              │
   │   • dashboard, hardware tuning, hashrate charts                       │
   └───────────────────────────────────────────────────────────────────────┘
```

See **ARCHITECTURE.md** for the full topology.

---

## 3. Quick start — drop into a new project

```bash
# 1. Unzip into the root of your destination project
unzip alpha-mining-tech.zip -d ./

# 2. Install dependencies
npm install ethers@^6.13.4 express drizzle-orm pg @sendgrid/mail \
            ws node-fetch crypto-js solc

# 3. Provide the required environment variables (see ENV_TEMPLATE.env)
cp mining-tech-package/ENV_TEMPLATE.env .env
# fill in ALCHEMY_API_KEY, ATC_DEPLOYER_PRIVATE_KEY, DATABASE_URL, ...

# 4. Mount the routes in your Express app
```

```typescript
// your-app/server/index.ts
import express from 'express';
import { registerMiningRoutes } from './mining-tech-package/routes-extracted/mining-routes';
import { startStratumServer } from './mining-tech-package/server/blockchain/stratum';
import { initBlockchain } from './mining-tech-package/server/blockchain';

const app = express();
app.use(express.json());

// Whatever auth middleware you use:
const isAuthenticated = (req, res, next) => req.user ? next() : res.status(401).end();

registerMiningRoutes(app, { isAuthenticated });

// Boot the L1 chain + mining pool
await initBlockchain();
startStratumServer({ port: 3333 });

app.listen(5000);
```

```typescript
// your-app/client/src/App.tsx
import MiningCommandCenter from './mining-tech-package/client/src/pages/MiningCommandCenter';
// ... wouter or react-router route:
<Route path="/mining" component={MiningCommandCenter} />
```

That's it. Read **WIRING_GUIDE.md** for every adjustment you need to make to
import paths and shared types.

---

## 4. Runtime services

| Service | Type | How it starts | Why you need it |
|---------|------|---------------|-----------------|
| Alpha L1 Blockchain | in-process | `initBlockchain()` | own PoW chain, blocks, mempool |
| Stratum Mining Pool | TCP server (port 3333) | `startStratumServer()` | accepts external miners |
| P2P Node | TCP server (port 6000) | `startP2PNode()` | peer gossip, block propagation |
| ATC On-Chain Listener | long-running script | `npx tsx contracts/atc/listener.ts` | receives ETH events |
| DAUv2 Listener | long-running script | `npx tsx contracts/atc/DAUv2_Listener.ts` | receives DyePack events |
| Integrity Beacon | cron / interval | inside `minerService.ts` boot | per-miner heartbeat anchoring |
| Spider Beacon | cron / interval | inside spider boot | re-org detection |

Every one of these is included in this package and runs unmodified.

---

## 5. The "wire it to a different engine" path

The mining stack is decoupled at three clean boundaries — pick which one you
want to swap:

1. **Replace the consensus algorithm** — edit `server/blockchain/consensus.ts`.
   The PoW SHA-256 verifier is ~80 lines; swap for PoS, BFT, RandomX, etc.
   `chain.ts` calls `validateBlockProof(block)` — keep that contract intact.

2. **Replace the mining-pool protocol** — `server/blockchain/stratum.ts` is a
   self-contained Stratum-V1 server. Replace with Stratum-V2, Getwork, or a
   custom binary protocol; the rest of the stack only knows about
   `submitShare(minerId, nonce, hash)`.

3. **Replace the on-chain target** — the chain adapters in
   `server/services/chain-adapters/` are thin wrappers over each public RPC.
   To target a new chain, implement the `ChainAdapter` interface in
   `chain-adapters/types.ts` (5 methods). The adapters auto-register through
   `chain-adapters/index.ts`.

See **ARCHITECTURE.md §5 "Extension Points"** for code-level diffs.

---

## 6. Documentation index

| File | Purpose |
|------|---------|
| `README.md` | this overview |
| `ARCHITECTURE.md` | system topology, data flow, extension points |
| `WIRING_GUIDE.md` | step-by-step integration into a host project |
| `BLOCKCHAIN_INTEGRATION.md` | chain-by-chain RPC reference & examples |
| `ENV_TEMPLATE.env` | every env var the stack reads |
| `package.deps.json` | exact npm dependencies + versions |

---

## 7. License

© 2024–2026 Alpha Unlimited Trading Company. All Rights Reserved.

This package is **PROPRIETARY AND CONFIDENTIAL** and is licensed exclusively
to its original purchaser/owner. Unauthorized reproduction, distribution, or
derivative use is a violation of:

- Title 17 U.S. Code (Copyright Act)
- Digital Millennium Copyright Act (DMCA)
- Computer Fraud and Abuse Act (CFAA)
- Defend Trade Secrets Act (DTSA), 18 U.S.C. § 1836

Owner of record: **alphaunlimitedtoken@gmail.com**
