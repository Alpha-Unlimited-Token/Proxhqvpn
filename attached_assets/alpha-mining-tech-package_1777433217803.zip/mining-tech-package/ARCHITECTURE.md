# Alpha Mining — System Architecture

## 1. Three-tier topology

```
┌──────────────────────────────────────────────────────────────────┐
│  TIER 1 — UI (browser)                                           │
│  React + Wouter + TanStack Query                                 │
│  ─────────────────────────────────────────────────────────────   │
│  • MiningCommandCenter      dashboard, hashrate, payout charts   │
│  • AlphaForge               in-browser PoW worker (web-worker)   │
│  • AlphaBlockchain          block explorer (lists, tx detail)    │
│  • BlockchainHashAnalyzer   forensic hash inspector              │
│  • QMGEStandalone           standalone PWA (own SW + manifest)   │
│                                                                  │
│  Talks to TIER 2 via:                                            │
│    HTTPS  → /api/miners, /api/blockchain/*, /api/qmge/*          │
│    WS     → wss://host/stratum  (mining-pool stratum bridge)     │
└──────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌──────────────────────────────────────────────────────────────────┐
│  TIER 2 — API + Services (Node.js / Express / TypeScript ESM)    │
│  ─────────────────────────────────────────────────────────────   │
│  • routes-extracted/mining-routes.ts   33 Express handlers       │
│  • server/services/minerService.ts     CRUD + auto-tuner         │
│  • server/services/integrityBeacon.ts  per-miner heartbeats      │
│  • server/services/spiderBeacon.ts     re-org/forensic anchor    │
│  • server/services/chain-adapters/     UCAL multi-chain adapter  │
│                                                                  │
│  Talks to TIER 3 via:                                            │
│    in-proc → server/blockchain/* (Alpha L1 chain)                │
│    tcp     → stratum miners (port 3333)                          │
│    tcp     → p2p peers (port 6000)                               │
│    https   → external chains (Alchemy, mempool.space, ...)       │
│    sql     → Postgres (Drizzle ORM)                              │
└──────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌──────────────────────────────────────────────────────────────────┐
│  TIER 3 — Chain layer                                            │
│  ─────────────────────────────────────────────────────────────   │
│  A. Alpha L1 (own PoW chain)                                     │
│     server/blockchain/chain.ts            longest-chain rule     │
│     server/blockchain/block.ts            block hashing          │
│     server/blockchain/consensus.ts        SHA-256 PoW verifier   │
│     server/blockchain/mint.ts             coinbase / reward      │
│     server/blockchain/p2p.ts              gossip protocol        │
│     server/blockchain/stratum.ts          Stratum-V1 pool        │
│                                                                  │
│  B. External chains (UCAL)                                       │
│     server/services/chain-adapters/                              │
│     ├─ evmAdapter        ETH, Polygon, Arbitrum, Optimism, Base │
│     ├─ solanaAdapter     SOL via Alchemy SOL RPC                │
│     ├─ bitcoinAdapter    BTC via mempool.space (UTXO-aware)     │
│     ├─ tronAdapter       TRX via TronGrid                       │
│     ├─ tonAdapter        TON via TonAPI                         │
│     └─ xrplAdapter       XRP via xrplcluster.com + XRPSCAN      │
│                                                                  │
│  C. ETH Mainnet contracts (deployed)                             │
│     contracts/atc/AlphaTrackingCoin.sol  ERC-20, deployed        │
│     contracts/atc/DAUv2_DyePack.sol      ERC-20, deployed        │
└──────────────────────────────────────────────────────────────────┘
```

---

## 2. Data flow — full mining round-trip

```
[1] Miner client (browser or external ASIC)
        │
        │  (a) `subscribe` over Stratum
        ▼
[2] server/blockchain/stratum.ts  — port 3333
        │
        │  (b) `getJob()` → builds template from current chain head
        ▼
[3] server/blockchain/chain.ts   — getLatestBlock(), getMempool()
        │
        │  (c) returns { header, target, txList }
        ▼
[2] stratum.ts                   — sends `mining.notify` to all subs
        │
        ▼
[1] Miner hashes; submits a share
        │
        │  (d) `mining.submit { nonce, jobId }`
        ▼
[2] stratum.ts.handleSubmit()
        │
        │  (e) calls validateShare(nonce) → consensus.ts
        ▼
[4] server/blockchain/consensus.ts
        │  hash = sha256(sha256(header || nonce))
        │  ok   = bigint(hash) <= target
        ▼
[2] stratum.ts                   — share accepted → minerService.recordShare()
        │
        │  if hash <= block_target (not just share_target):
        ▼
[3] chain.ts.appendBlock(block)
        │  • mint coinbase to miner address  (mint.ts)
        │  • broadcast to peers               (p2p.ts)
        │  • emit forensicHook events         (forensicHooks.ts)
        │  • spider.scan(newHead)             (spider.ts)
        │  • integrityBeacon.anchor(block)    (integrityBeacon.ts)
        ▼
[5] Postgres                     — insert block, txs, payouts
        │
        ▼
[1] Miner client receives `mining.set_difficulty` & next job
```

---

## 3. Backend service responsibilities

| Service | Responsibility | Key types |
|---------|----------------|-----------|
| `minerService.ts` | User registers a miner; we store hardware spec, current job assignment, hashrate samples, payouts. Includes the auto-tune loop that adjusts difficulty per-miner. | `Miner`, `MinerStatus`, `AutoAdjustResult` |
| `integrityBeacon.ts` | Every N blocks each active miner emits a signed heartbeat that we anchor into the next coinbase (proof the miner is real and ran the canonical software). | `Beacon`, `BeaconChain` |
| `spiderBeacon.ts` | Walks the chain backwards looking for re-orgs / equivocation; flags suspect blocks. | `SpiderTrail`, `ReorgEvent` |
| `chain-adapters/*` | Universal Chain Adapter Layer (UCAL). Every adapter exports the same `ChainAdapter` shape so callers don't care which chain. | `ChainAdapter` (in `types.ts`) |
| `forensicHooks.ts` | Per-block instrumentation point — emits events that downstream forensic engines consume. | `ForensicEvent` |
| `forensicTracer.ts` | Deep tx tracer: takes any chain id + tx hash and returns full call-tree, log decode, value flow. | `TraceResult` |

---

## 4. The custom Alpha L1 chain in detail

`server/blockchain/` is a complete (but minimal) UTXO-style proof-of-work
blockchain. It's roughly 1,200 lines and covers:

| File | What it does |
|------|--------------|
| `index.ts` | Public surface; `initBlockchain()`, `getChain()`, `getMempool()` |
| `block.ts` | Block struct: `{ index, prevHash, timestamp, txList, nonce, target }`. SHA-256 double-hash for the header. |
| `chain.ts` | In-memory chain + Postgres persistence. Implements the longest-chain (most-work) rule. Handles mempool and re-orgs. |
| `consensus.ts` | `validateBlockProof(block)` — recomputes header hash and compares to target. Difficulty retarget every 2,016 blocks. |
| `mint.ts` | Block reward schedule, halving, coinbase tx construction. |
| `wallet.ts` | secp256k1 keypair, Base58 address, signing/verification. |
| `founder.ts` | Genesis block + founder allocation. |
| `p2p.ts` | TCP node-to-node gossip. Messages: `HELLO`, `INV`, `GETDATA`, `BLOCK`, `TX`, `GETHEADERS`. |
| `stratum.ts` | Stratum-V1 server; manages subscriptions, `mining.notify`, `mining.submit`, per-conn difficulty. |
| `spider.ts` | Walks the chain, detects skipped indexes / orphan candidates, emits to `forensicHooks`. |
| `routes.ts` | Express router mounted at `/api/blockchain` — block list, tx detail, analyze. |

---

## 5. Extension points (where to plug in your "different engine")

### 5a. Swap consensus — `server/blockchain/consensus.ts`

```typescript
// Current PoW interface (keep this contract):
export function validateBlockProof(block: Block): boolean { ... }
export function calculateTarget(difficulty: number): bigint { ... }
export function difficultyForHeight(h: number): number { ... }

// To add e.g. PoS or RandomX:
//   1. Re-implement validateBlockProof() — return true if your rule is met.
//   2. Re-implement calculateTarget() — return a sentinel like 2^256-1
//      if your scheme doesn't use a numeric target, then bypass the
//      hash <= target check inside stratum.handleSubmit().
//   3. (optional) Re-write difficultyForHeight() — or hard-code 1.
//
// Nothing else in chain.ts / stratum.ts needs to change.
```

### 5b. Swap mining protocol — `server/blockchain/stratum.ts`

```typescript
// External contract (keep these calls):
export function startStratumServer(opts: { port: number }): Server;
export function broadcastJob(template: BlockTemplate): void;

// Internally, message parsing is in handleLine(line, conn).
// Replace with Stratum-V2, Getwork, or a custom binary protocol.
// As long as you call minerService.recordShare() on a valid share
// and chain.appendBlock() on a full solution, the rest works.
```

### 5c. Add a chain — `server/services/chain-adapters/`

```typescript
// types.ts — ChainAdapter interface (5 methods only):
export interface ChainAdapter {
  chainId: string;
  getLatestBlockNumber(): Promise<number>;
  getBalance(address: string): Promise<bigint>;
  getTransactions(address: string, opts?: TxOpts): Promise<Tx[]>;
  getTransaction(hash: string): Promise<Tx | null>;
  isAddress(s: string): boolean;
}

// Add a new file (e.g. nearAdapter.ts) that exports a ChainAdapter,
// then register it in chain-adapters/index.ts. The mining-bridge
// routes will pick it up automatically.
```

### 5d. Replace the AI block-template optimizer — `client/src/lib/qmge/engine.ts`

QMGE (Quantum Mining Genesis Engine) is a frontend module that takes the raw
job from the pool and re-orders / filters mempool txs to maximize fees per
share. Replace the optimizer body; keep the `optimizeTemplate(rawJob)` export.

---

## 6. Persistence schema (Postgres / Drizzle)

The mining stack writes to these tables (pulled from `shared/schema.ts` in the
parent project — recreate them in your destination):

```sql
miners              (id, userId, name, hardwareSpec, address, status, createdAt)
miner_shares        (id, minerId, jobId, nonce, hash, valid, ts)
miner_payouts       (id, minerId, blockHeight, amount, ts)
blocks              (height, hash, prevHash, miner, txCount, ts, raw)
transactions        (hash, blockHeight, fromAddr, toAddr, value, fee, ts)
beacons             (id, minerId, blockHeight, sig, anchored, ts)
spider_events       (id, kind, blockHeight, detail, severity, ts)
qmge_licenses       (userId, licenseKey, tier, status, expiresAt)
```

Drizzle definitions live in `shared/schema.ts` of the parent project; copy the
relevant tables across.

---

## 7. On-chain Solidity contracts

Two production ERC-20 contracts ship in `contracts/atc/`:

| Contract | File | Purpose |
|----------|------|---------|
| Alpha Tracking Coin (ATC) | `AlphaTrackingCoin.sol` | Dust-amount forensic tracker — the contract emits `Transfer` events that downstream forensic engines correlate to suspect wallets. |
| DAUv2 Dye Pack | `DAUv2_DyePack.sol` | "Honeypot" token: when an attacker moves it, the listener (`DAUv2_Listener.ts`) writes a forensic record + emails the response team. |

Both have:

* Compile pipeline → `compile.ts` (uses `solc`)
* Deploy script    → `deploy.ts` / `DAUv2_Deploy.ts` (uses `ethers`)
* Listener         → `listener.ts` / `DAUv2_Listener.ts` (long-running)

Compiled artifacts (ABI + bytecode) are bundled in `contracts/atc/artifacts/`
so you don't need to rebuild unless you modify the .sol files.

Deployment records (live mainnet + Sepolia addresses + tx hashes) are in
`contracts/atc/deployments/`. Inspect those JSON files to see which addresses
the listeners point at.

---

## 8. Proprietary guard

Every engine starts with:

```typescript
import { enforceProprietaryLicense, proprietaryHeader } from '<path>/private/security/alpha_proprietary_guard';
enforceProprietaryLicense('My Engine Name™');
```

The guard:

1. Verifies the running environment fingerprint against `.alpha_license.json`.
2. Refuses to start if the license is missing/tampered.
3. Exposes `proprietaryHeader(name)` which returns the copyright banner that
   gets embedded into every JSON / HTML / PDF the engine emits.

Keep this import in place if you want the proprietary protection rule from the
parent project to follow this code into the new project.
