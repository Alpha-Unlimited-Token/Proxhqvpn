/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * RAVEDAO Active-Wallets ⇄ Dev-Cohort Interaction Back-Trace
 *
 * For the 18 RAVE-dominant active wallets identified in the SillyTuna
 * categorized-active-wallets export, determines for EACH:
 *   1. DIRECT IDENTITY      — wallet IS a RAVEDAO dev (devCohort.earliestHolders)
 *   2. EXISTING FUNDING LINK — recorded in ravedao_dump_analysis.crossRef.fundingLinks
 *   3. DIRECT INTERACTION    — any ETH or ERC-20 transfer between active wallet
 *                              and any of the 30 dev wallets (forward + back)
 *   4. ONE-HOP INTERMEDIARY  — active wallet ↔ X ↔ dev wallet via shared
 *                              counterparty (ETH-funder or token transfer)
 *
 * Outputs:
 *   exports/ravedao_active_wallets_dev_interaction.json
 *   exports/ravedao_active_wallets_dev_interaction.md
 *
 * Distribution: INTERNAL OWNER USE ONLY.
 * Title 17 / DMCA / CFAA / DTSA protected.
 */

import fs from 'node:fs';
import path from 'node:path';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Active-Wallet Dev-Interaction Trace');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }

const ALCHEMY = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const RATE_MS = 220;
const PAGE_SIZE = 1000;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// --- The 18 RAVE-dominant active wallets ---------------------------------
// Pulled from exports/sillytuna_active_wallets_categorized.md (Bucket B
// rows whose top-tokens column included RAVE).
const ACTIVE_18 = [
  '0x7c5874a11b4dd3aba411fa8b942ae90d1d662705',
  '0xbcb5148b8348b022f8d4fc59d2a7295f6202c7a3',
  '0xd9e5c576de7be6c347d0168086db28eac392287c',
  '0x911203d9228f01503d8ffcd7b66eff367f1d3ee0',
  '0x0bbc493ac927e05cd9de8f716b1237272c42bce5',
  '0xc1b2aff52877b4a23422f554f3d240be50ec80cf',
  '0x310269e220749a71018310e22d006ead1fc2c764',
  '0xd7873d7c93a9fb1977e23be037a093697f3e0b6d',
  '0x8a5221f95c8af2d249bc1a7f075b31336ee5032f',
  '0xeeb4e7601559733d3879f55d58502f8cfb4d116e',
  '0x8cbaa834bd41d4c830254f34aa508ef3814d0263',
  '0x6843e9d53af732985e9af951f7f167ecec3a9fb0',
  '0xfbc370c33fcb5227f00df579a812d5073ea24a8a',
  '0x28d3bdece9a0c7f54687f734fa73fba04ecf5785',
  '0x137d1a5e99859ca68c4a757b4b1dcd1dbbf6ad24',
  '0x3c4bbb43a7283b32a684bcb17095eb8b7cf99dac',
  '0xfaad1edeaa58572c9c9be4e20653f0e15a1dd635',
  '0x609136915e8a8858f6cafd80138427646a7d2817',
].map(a => a.toLowerCase());

// --- Load dev cohort + existing funding links ----------------------------
const dumpJson = JSON.parse(
  fs.readFileSync('contracts/atc/ravedao_dump_analysis.json', 'utf-8'),
);
const DEVS: { address: string; tokensReceived: number }[] =
  (dumpJson.devCohort?.earliestHolders || []).map((d: any) => ({
    address: d.address.toLowerCase(),
    tokensReceived: d.tokensReceived,
  }));
const DEV_SET = new Set(DEVS.map(d => d.address));
const EXISTING_LINKS: any[] = dumpJson.crossRef?.fundingLinks || [];
const DUMPER_ADDRS = new Set<string>(
  (dumpJson.dumpers || []).map((d: any) => d.address.toLowerCase()),
);

console.log(`[INFO] Active wallets to scan: ${ACTIVE_18.length}`);
console.log(`[INFO] Dev cohort size:        ${DEVS.length}`);
console.log(`[INFO] Existing fundingLinks:  ${EXISTING_LINKS.length}`);

// --- Alchemy helpers -----------------------------------------------------
async function alchemy(method: string, params: any[]): Promise<any> {
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(ALCHEMY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      });
      if (!r.ok) { await sleep(600); continue; }
      const j: any = await r.json();
      if (j?.error) return null;
      return j?.result ?? null;
    } catch { await sleep(600); }
  }
  return null;
}

async function getTransfers(opts: {
  fromAddr?: string; toAddr?: string;
  category?: string[];
  maxPages?: number;
  pageSize?: number;
}): Promise<any[]> {
  const all: any[] = [];
  let pageKey: string | undefined;
  let pages = 0;
  const maxPages = opts.maxPages ?? 2;
  const ps = opts.pageSize ?? PAGE_SIZE;
  do {
    const params: any = {
      fromBlock: '0x0',
      toBlock: 'latest',
      category: opts.category || ['external', 'erc20'],
      maxCount: '0x' + ps.toString(16),
      order: 'desc',
      withMetadata: true,
    };
    if (opts.fromAddr) params.fromAddress = opts.fromAddr;
    if (opts.toAddr)   params.toAddress   = opts.toAddr;
    if (pageKey) params.pageKey = pageKey;
    const result = await alchemy('alchemy_getAssetTransfers', [params]);
    if (!result?.transfers) break;
    all.push(...result.transfers);
    pageKey = result.pageKey;
    pages++;
    if (pages >= maxPages) break;
    await sleep(RATE_MS);
  } while (pageKey);
  return all;
}

// --- Per-wallet evaluator -------------------------------------------------
type DevHit = {
  devAddress: string;
  devTokensReceived: number;
  direction: 'active→dev' | 'dev→active';
  category: string;          // external / erc20 / internal
  asset: string | null;
  value: number | null;
  blockNum: string;
  timestamp: string | null;
  hash: string;
};

type WalletReport = {
  wallet: string;
  isDev: boolean;
  devTokensReceivedIfDev: number | null;
  existingDirectFundingLinks: any[];   // from crossRef.fundingLinks
  directInteractions: DevHit[];        // freshly scanned
  oneHopIntermediaries: {
    intermediary: string;
    fromActiveTx: string;
    toDevTx: string;
    devAddress: string;
    asset: string | null;
  }[];
  summary: {
    directHitCount: number;
    uniqueDevsTouched: number;
    earliestInteraction: string | null;
    latestInteraction:   string | null;
    intermediariesFound: number;
  };
};

async function evaluateWallet(active: string): Promise<WalletReport> {
  console.log(`\n[SCAN] ${active}`);
  const isDev = DEV_SET.has(active);

  // Existing funding links involving this wallet (as dumper or dev)
  const existing = EXISTING_LINKS.filter(
    l => l.dev?.toLowerCase() === active || l.dumper?.toLowerCase() === active,
  );

  // ----- Direct interaction scan: forward (active→dev) and reverse -------
  const t0 = Date.now();
  const out = await getTransfers({ fromAddr: active, maxPages: 3 });
  console.log(`  out: ${out.length} txs (${Date.now()-t0}ms)`);
  const t1 = Date.now();
  const inn = await getTransfers({ toAddr:   active, maxPages: 3 });
  console.log(`  in:  ${inn.length} txs (${Date.now()-t1}ms)`);

  const directHits: DevHit[] = [];
  for (const t of out) {
    const to = (t.to || '').toLowerCase();
    if (DEV_SET.has(to)) {
      directHits.push({
        devAddress: to,
        devTokensReceived: DEVS.find(d => d.address === to)?.tokensReceived || 0,
        direction: 'active→dev',
        category: t.category,
        asset: t.asset,
        value: t.value ?? null,
        blockNum: t.blockNum,
        timestamp: t.metadata?.blockTimestamp || null,
        hash: t.hash,
      });
    }
  }
  for (const t of inn) {
    const from = (t.from || '').toLowerCase();
    if (DEV_SET.has(from)) {
      directHits.push({
        devAddress: from,
        devTokensReceived: DEVS.find(d => d.address === from)?.tokensReceived || 0,
        direction: 'dev→active',
        category: t.category,
        asset: t.asset,
        value: t.value ?? null,
        blockNum: t.blockNum,
        timestamp: t.metadata?.blockTimestamp || null,
        hash: t.hash,
      });
    }
  }
  console.log(`  direct hits: ${directHits.length}  (out=${out.length} in=${inn.length})`);

  // ----- One-hop intermediary scan ---------------------------------------
  // Strategy: for every counterparty `X` of the active wallet (ETH funder
  // or token sender/receiver), check if `X` also transacted with any dev.
  const counterparties = new Set<string>();
  for (const t of out) if (t.to)   counterparties.add((t.to as string).toLowerCase());
  for (const t of inn) if (t.from) counterparties.add((t.from as string).toLowerCase());
  counterparties.delete(active);
  for (const d of DEV_SET) counterparties.delete(d); // already counted as direct

  // Limit how many intermediaries we probe (Alchemy quota)
  const cpList = [...counterparties].slice(0, 8);
  console.log(`  probing ${cpList.length}/${counterparties.size} unique counterparties for dev links…`);

  const intermediaries: WalletReport['oneHopIntermediaries'] = [];
  let cpIdx = 0;
  for (const cp of cpList) {
    cpIdx++;
    const tcp = Date.now();
    const cpOut = await getTransfers({ fromAddr: cp, maxPages: 1, pageSize: 200 });
    const cpIn  = await getTransfers({ toAddr:   cp, maxPages: 1, pageSize: 200 });
    if (cpIdx === 1 || cpIdx === cpList.length) {
      console.log(`    cp ${cpIdx}/${cpList.length}: ${cp} (out=${cpOut.length} in=${cpIn.length}, ${Date.now()-tcp}ms)`);
    }
    for (const t of cpOut) {
      const to = (t.to || '').toLowerCase();
      if (DEV_SET.has(to)) {
        const sourceTx = out.find(o => (o.to || '').toLowerCase() === cp)
                      || inn.find(o => (o.from || '').toLowerCase() === cp);
        intermediaries.push({
          intermediary: cp,
          fromActiveTx: sourceTx?.hash || '',
          toDevTx: t.hash,
          devAddress: to,
          asset: t.asset,
        });
      }
    }
    for (const t of cpIn) {
      const from = (t.from || '').toLowerCase();
      if (DEV_SET.has(from)) {
        const sourceTx = out.find(o => (o.to || '').toLowerCase() === cp)
                      || inn.find(o => (o.from || '').toLowerCase() === cp);
        intermediaries.push({
          intermediary: cp,
          fromActiveTx: sourceTx?.hash || '',
          toDevTx: t.hash,
          devAddress: from,
          asset: t.asset,
        });
      }
    }
    await sleep(RATE_MS);
  }
  console.log(`  intermediaries: ${intermediaries.length}`);

  // ----- Summary -----------------------------------------------------------
  const ts = directHits.map(h => h.timestamp).filter(Boolean) as string[];
  ts.sort();
  const uniqueDevs = new Set(directHits.map(h => h.devAddress));

  return {
    wallet: active,
    isDev,
    devTokensReceivedIfDev: isDev
      ? (DEVS.find(d => d.address === active)?.tokensReceived || 0) : null,
    existingDirectFundingLinks: existing,
    directInteractions: directHits,
    oneHopIntermediaries: intermediaries,
    summary: {
      directHitCount: directHits.length,
      uniqueDevsTouched: uniqueDevs.size,
      earliestInteraction: ts[0] || null,
      latestInteraction:   ts[ts.length - 1] || null,
      intermediariesFound: intermediaries.length,
    },
  };
}

// --- Main ---------------------------------------------------------------
const CHECKPOINT = path.resolve('exports/ravedao_active_wallets_dev_interaction.checkpoint.json');

(async () => {
  let reports: WalletReport[] = [];
  if (fs.existsSync(CHECKPOINT)) {
    try { reports = JSON.parse(fs.readFileSync(CHECKPOINT,'utf-8')); console.log(`[RESUME] loaded ${reports.length} reports from checkpoint`); }
    catch {}
  }
  const done = new Set(reports.map(r => r.wallet));
  const MAX_THIS_RUN = parseInt(process.env.MAX_THIS_RUN || '999', 10);
  let processedThisRun = 0;
  for (const a of ACTIVE_18) {
    if (done.has(a)) { console.log(`[SKIP-CACHED] ${a}`); continue; }
    if (processedThisRun >= MAX_THIS_RUN) {
      console.log(`[STOP] hit MAX_THIS_RUN=${MAX_THIS_RUN}; resume by re-running.`);
      break;
    }
    const r = await evaluateWallet(a);
    reports.push(r);
    processedThisRun++;
    fs.mkdirSync(path.dirname(CHECKPOINT), { recursive: true });
    fs.writeFileSync(CHECKPOINT, JSON.stringify(reports, null, 2));
    console.log(`  💾 checkpoint saved (${reports.length}/${ACTIVE_18.length})`);
  }
  if (reports.length < ACTIVE_18.length) {
    console.log(`[PARTIAL] ${reports.length}/${ACTIVE_18.length} wallets done — re-run to continue, skipping final report write`);
    process.exit(0);
  }

  const outDir = path.resolve('exports');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const out = {
    _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Active-Wallet Dev-Interaction Trace'),
    caseId: 'RAVEDAO_DEV_INTERACTION_18ACTIVE',
    generatedAt: new Date().toISOString(),
    token: dumpJson.token,
    devCohortSize: DEVS.length,
    activeWalletsScanned: ACTIVE_18.length,
    aggregate: {
      walletsThatAreDev:                     reports.filter(r => r.isDev).length,
      walletsWithDirectInteraction:          reports.filter(r => r.summary.directHitCount > 0).length,
      walletsWithOneHopIntermediary:         reports.filter(r => r.summary.intermediariesFound > 0).length,
      walletsWithExistingFundingLink:        reports.filter(r => r.existingDirectFundingLinks.length > 0).length,
      walletsWithNoLinkAtAll:                reports.filter(r =>
        !r.isDev &&
        r.summary.directHitCount === 0 &&
        r.summary.intermediariesFound === 0 &&
        r.existingDirectFundingLinks.length === 0
      ).length,
    },
    walletReports: reports,
  };

  fs.writeFileSync(
    path.join(outDir, 'ravedao_active_wallets_dev_interaction.json'),
    JSON.stringify(out, null, 2),
  );
  console.log(`\n✅ JSON: exports/ravedao_active_wallets_dev_interaction.json`);

  // ----- Markdown summary -------------------------------------------------
  const lines: string[] = [];
  lines.push('# RAVEDAO — 18 Active Wallets ⇄ Dev-Cohort Interaction Trace');
  lines.push('');
  lines.push(`**Generated:** ${out.generatedAt}`);
  lines.push(`**Token:** ${dumpJson.token?.symbol} (${dumpJson.token?.address})`);
  lines.push(`**Dev cohort size:** ${DEVS.length} earliest holders`);
  lines.push(`**Active wallets scanned:** ${ACTIVE_18.length}`);
  lines.push('');
  lines.push('## Aggregate Findings');
  lines.push('');
  lines.push(`- Wallets that ARE a dev (direct identity overlap):     **${out.aggregate.walletsThatAreDev}**`);
  lines.push(`- Wallets with DIRECT interaction with a dev:           **${out.aggregate.walletsWithDirectInteraction}**`);
  lines.push(`- Wallets with ONE-HOP intermediary to a dev:           **${out.aggregate.walletsWithOneHopIntermediary}**`);
  lines.push(`- Wallets with existing recorded funding link:          **${out.aggregate.walletsWithExistingFundingLink}**`);
  lines.push(`- Wallets with NO link to any dev (clean):              **${out.aggregate.walletsWithNoLinkAtAll}**`);
  lines.push('');
  lines.push('---');
  lines.push('');
  for (const r of reports) {
    lines.push(`## \`${r.wallet}\``);
    lines.push('');
    if (r.isDev) lines.push(`- ⚠️ **IS A DEV** — received ${r.devTokensReceivedIfDev?.toLocaleString()} RAVE in pre-launch dev allocation`);
    if (DUMPER_ADDRS.has(r.wallet)) lines.push(`- 🔻 Also appears as a top RAVE dumper`);
    lines.push(`- Direct dev-interaction txs:   **${r.summary.directHitCount}** (${r.summary.uniqueDevsTouched} unique devs)`);
    lines.push(`- One-hop intermediary links:   **${r.summary.intermediariesFound}**`);
    lines.push(`- Existing recorded fundingLinks involving this wallet: **${r.existingDirectFundingLinks.length}**`);
    if (r.summary.earliestInteraction) lines.push(`- Time window: ${r.summary.earliestInteraction} → ${r.summary.latestInteraction}`);
    if (r.directInteractions.length > 0) {
      lines.push('');
      lines.push('### Direct interactions (top 8)');
      lines.push('| Direction | Dev | Asset | Value | Tx |');
      lines.push('|---|---|---|---|---|');
      for (const h of r.directInteractions.slice(0, 8)) {
        lines.push(`| ${h.direction} | \`${h.devAddress}\` | ${h.asset || '—'} | ${h.value ?? '—'} | \`${h.hash.slice(0,18)}…\` |`);
      }
    }
    if (r.oneHopIntermediaries.length > 0) {
      lines.push('');
      lines.push('### One-hop intermediaries (top 6)');
      lines.push('| Intermediary | Connects to dev | Asset |');
      lines.push('|---|---|---|');
      for (const h of r.oneHopIntermediaries.slice(0, 6)) {
        lines.push(`| \`${h.intermediary}\` | \`${h.devAddress}\` | ${h.asset || '—'} |`);
      }
    }
    lines.push('');
  }

  fs.writeFileSync(
    path.join(outDir, 'ravedao_active_wallets_dev_interaction.md'),
    lines.join('\n'),
  );
  console.log(`✅ MD:   exports/ravedao_active_wallets_dev_interaction.md`);
})().catch(e => { console.error(e); process.exit(1); });
