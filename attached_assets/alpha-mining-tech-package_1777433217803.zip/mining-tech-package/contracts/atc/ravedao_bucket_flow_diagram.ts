/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Generates a bucket-color-coded SVG flow diagram for the 22 dev wallets ↔
 * 18 active wallets relationship, using Alpha Forensic Flow Visualizer™.
 * Title 17 / DMCA / CFAA / DTSA protected.
 */
import * as fs from 'fs';
import { renderFlowDiagram } from '../../private/forensics/flowDiagramVisualizer.js';
import { enforceProprietaryLicense } from '../../private/security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Forensic Flow Visualizer™ — Bucket Map');

const buckets: Record<string, any> = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_buckets.json','utf-8'));
const trace = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const tdSet: Set<string> = new Set(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));

// Aggregate dev↔active edge volumes per (active-wallet, dev) pair
type Edge = { from: string; to: string; delta: number; tokens: Set<string>; firstTs?: string };
const edges: Record<string, Edge> = {};
for (const r of trace.walletReports) {
  for (const h of (r.directInteractions || [])) {
    const dev = String(h.devAddress).toLowerCase();
    if (!tdSet.has(dev)) continue;
    const wallet = String(r.wallet).toLowerCase();
    const from = h.direction === 'active→dev' ? wallet : dev;
    const to   = h.direction === 'active→dev' ? dev : wallet;
    const k = `${from}|${to}`;
    if (!edges[k]) edges[k] = { from, to, delta: 0, tokens: new Set() };
    edges[k].delta++;
    edges[k].tokens.add(h.asset || 'ETH');
    if (!edges[k].firstTs || (h.timestamp && h.timestamp < edges[k].firstTs!)) edges[k].firstTs = h.timestamp;
  }
}

// Restrict to top 8 most-active devs to keep the diagram readable
const devEdgeVol: Record<string, number> = {};
for (const e of Object.values(edges)) {
  const dev = tdSet.has(e.from) ? e.from : e.to;
  devEdgeVol[dev] = (devEdgeVol[dev] || 0) + e.delta;
}
const topDevs = Object.entries(devEdgeVol).sort((a,b)=>b[1]-a[1]).slice(0, 8).map(([d])=>d);
const topDevSet = new Set(topDevs);
const filteredEdges = Object.values(edges).filter(e =>
  (tdSet.has(e.from) && topDevSet.has(e.from)) || (tdSet.has(e.to) && topDevSet.has(e.to))
);

const nodes: any[] = [];
const seen = new Set<string>();
const labels: Record<string, string> = {};

for (const w of Object.keys(buckets)) {
  if (seen.has(w)) continue; seen.add(w);
  const b = buckets[w].bucket;
  let kind: any;
  if (b === 'IS_DEV')                       kind = 'attacker';
  else if (b === 'HARVESTER_BIDIR')         kind = 'mixer';
  else if (b === 'DISTRIBUTION_RECEIVER')   kind = 'victim';
  else                                       kind = 'intermediary';
  nodes.push({ address: w, kind });
  labels[w] = `${b}\n${w.slice(0,8)}…${w.slice(-6)}`;
}
for (const d of topDevs) {
  if (seen.has(d)) continue; seen.add(d);
  nodes.push({ address: d, kind: 'attacker' });
  labels[d] = `DEV\n${d.slice(0,8)}…${d.slice(-6)}`;
}

const vizEdges = filteredEdges.map(e => ({
  from: e.from, to: e.to,
  delta: e.delta,
  asset: [...e.tokens][0] || 'ETH',
  dir: 'forward' as const,
}));

const svg = renderFlowDiagram({
  title: 'RAVEDAO Active-Wallets ↔ Devs · Bucket-Coded Connection Map',
  caseId: 'ALPHA-RAVEDAO-2026-BUCKETS',
  ecosystem: 'ethereum',
  direction: 'bidirectional',
  rootAddresses: topDevs,
  nodes,
  edges: vizEdges,
  addressLabels: labels,
});
fs.writeFileSync('exports/ravedao_active_wallets_bucket_flow.svg', svg);

const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>RAVEDAO Bucket Map</title>
<style>body{background:#0a0e14;color:#e8eef5;font-family:system-ui;padding:20px;margin:0}
h1{color:#d4af37}
.legend{background:#0f1620;border:1px solid #2a3050;border-radius:8px;padding:15px;margin:15px 0;max-width:800px}
.legend-row{display:flex;align-items:center;gap:10px;margin:6px 0;font-size:14px}
.swatch{width:20px;height:20px;border-radius:4px;border:2px solid;flex-shrink:0}
.dev{background:#3d1e1e;border-color:#e74c3c}
.harv{background:#3d2e1e;border-color:#e67e22}
.dist{background:#1e3d2e;border-color:#27ae60}
.svg-container{overflow:auto;background:#0a0e14;border:1px solid #2a3050;padding:15px;border-radius:8px}
</style></head><body>
<h1>RAVEDAO Active-Wallets ↔ Devs · Bucket-Coded Connection Map</h1>
<div class="legend">
<div class="legend-row"><span class="swatch dev"></span><b style="color:#e74c3c">DEVS / IS_DEV</b> — RAVEDAO developer-cohort wallets (1 active wallet IS itself a dev)</div>
<div class="legend-row"><span class="swatch harv"></span><b style="color:#e67e22">HARVESTER_BIDIR</b> — bidirectional with devs · sub-treasury / consolidation pattern (2 wallets)</div>
<div class="legend-row"><span class="swatch dist"></span><b style="color:#27ae60">DISTRIBUTION_RECEIVER</b> — only receives from devs · downstream distribution outlet (15 wallets)</div>
</div>
<div class="svg-container">${svg}</div>
</body></html>`;
fs.writeFileSync('exports/ravedao_active_wallets_bucket_flow.html', html);
console.log('✅ exports/ravedao_active_wallets_bucket_flow.svg');
console.log('✅ exports/ravedao_active_wallets_bucket_flow.html');
