/* Finalize the genesis timeline JSON from the checkpoint. */
import * as fs from 'fs';
import { proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

const tdSet = new Set<string>(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));
const trueDevs: string[] = [...tdSet];
const traceJ = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const ACTIVE: string[] = traceJ.walletReports.map((r: any) => r.wallet.toLowerCase());
const scans: Record<string, any> = JSON.parse(fs.readFileSync('exports/ravedao_genesis_timeline.checkpoint.json','utf-8'));

type Pair = { active: string; dev: string; ts: string; direction: string; asset: string; value: any; hash: string };
const pairwise: Pair[] = [];
for (const a of ACTIVE) {
  for (const c of (scans[a]?.earliestDevContacts || [])) {
    pairwise.push({ active: a, dev: c.devAddress, ts: c.ts, direction: c.direction, asset: c.asset, value: c.value, hash: c.hash });
  }
}
for (const d of trueDevs) {
  for (const c of (scans[d]?.earliestActiveContacts || [])) {
    pairwise.push({ active: c.activeAddress, dev: d, ts: c.ts,
      direction: c.direction === 'this→target' ? 'dev→active' : 'active→dev',
      asset: c.asset, value: c.value, hash: c.hash });
  }
}
const earliestPair: Record<string, Pair> = {};
for (const p of pairwise) {
  const k = `${p.active}|${p.dev}`;
  if (!earliestPair[k] || p.ts < earliestPair[k].ts) earliestPair[k] = p;
}
const sortedPairs = Object.values(earliestPair).sort((a,b) => a.ts.localeCompare(b.ts));

const walletGenesisTimeline = [
  ...ACTIVE.map(a => ({ wallet: a, role: 'active', ...scans[a]?.walletGenesis })),
  ...trueDevs.filter(d => !ACTIVE.includes(d)).map(d => ({ wallet: d, role: 'dev', ...scans[d]?.walletGenesis })),
].filter((x: any) => x.ts).sort((a: any, b: any) => a.ts.localeCompare(b.ts));

const allWallets = new Set([...ACTIVE, ...trueDevs]);
const genesisCrossLinks: any[] = [];
const sharedFunders: Record<string, string[]> = {};
for (const w of allWallets) {
  const g = scans[w]?.walletGenesis;
  if (!g) continue;
  const fromAddr = String(g.from || '').toLowerCase();
  if (!sharedFunders[fromAddr]) sharedFunders[fromAddr] = [];
  sharedFunders[fromAddr].push(w);
  if (allWallets.has(fromAddr)) {
    genesisCrossLinks.push({
      recipient: w, recipientRole: ACTIVE.includes(w) ? 'active' : 'dev',
      fundedBy: fromAddr, funderRole: ACTIVE.includes(fromAddr) ? 'active' : 'dev',
      ts: g.ts, asset: g.asset, value: g.value, hash: g.hash,
    });
  }
}
// shared funders that funded multiple of our wallets
const commonFunders = Object.entries(sharedFunders)
  .filter(([k, v]) => v.length >= 2 && k && k !== '0x0000000000000000000000000000000000000000')
  .sort((a, b) => b[1].length - a[1].length)
  .map(([funder, wallets]) => ({ funder, walletCount: wallets.length, wallets }));

const out = {
  _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Genesis Timeline'),
  generatedAt: new Date().toISOString(),
  scope: { activeWalletCount: ACTIVE.length, trueDevCount: trueDevs.length },
  firstEverDevActiveContact: sortedPairs[0] || null,
  earliestDevActivePairs: sortedPairs,
  walletGenesisTimeline,
  genesisCrossLinks,
  commonFunders,
  perWalletScans: scans,
};
fs.writeFileSync('exports/ravedao_genesis_timeline.json', JSON.stringify(out, null, 2));
console.log(`✅ exports/ravedao_genesis_timeline.json`);
console.log(`first contact: ${sortedPairs[0]?.ts}`);
console.log(`pairs found: ${sortedPairs.length}`);
console.log(`common funders (funded ≥ 2 of our wallets): ${commonFunders.length}`);
commonFunders.slice(0, 8).forEach(f => console.log(`  ${f.funder} → ${f.walletCount} wallets`));
