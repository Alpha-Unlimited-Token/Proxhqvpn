/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Patches the deep-drill output by enriching dev-counterparty data from the
 * authoritative original trace (which queried each dev pair directly and is
 * not subject to the 8k-transfer page-cap of the wallet-history scan).
 * Title 17 / DMCA / CFAA / DTSA protected.
 */
import * as fs from 'fs';
import { enforceProprietaryLicense } from '../../private/security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Deep Drill Patch');

const drill = JSON.parse(fs.readFileSync('exports/ravedao_active_wallet_deep_drill.json','utf-8'));
const trace = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const tdSet = new Set<string>(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));

const target = String(drill.target).toLowerCase();
const report = trace.walletReports.find((r: any) => String(r.wallet).toLowerCase() === target);
if (!report) { console.error('target not found in trace'); process.exit(1); }

// Authoritative dev counterparties from the per-pair direct-interaction scan
const devCp: Record<string, { in: number; out: number; tokens: Set<string>; firstTs?: string; lastTs?: string }> = {};
for (const h of (report.directInteractions || [])) {
  const dev = String(h.devAddress).toLowerCase();
  if (!tdSet.has(dev)) continue;
  if (!devCp[dev]) devCp[dev] = { in: 0, out: 0, tokens: new Set() };
  if (h.direction === 'active→dev') devCp[dev].out++; else devCp[dev].in++;
  devCp[dev].tokens.add(h.asset || 'ETH');
  if (h.timestamp) {
    if (!devCp[dev].firstTs || h.timestamp < devCp[dev].firstTs!) devCp[dev].firstTs = h.timestamp;
    if (!devCp[dev].lastTs  || h.timestamp > devCp[dev].lastTs!)  devCp[dev].lastTs = h.timestamp;
  }
}

const authoritativeDevList = Object.entries(devCp).map(([cp,d]) => ({
  cp, in: d.in, out: d.out, total: d.in + d.out, tokens: [...d.tokens],
  firstTs: d.firstTs, lastTs: d.lastTs,
})).sort((a,b)=> b.total - a.total);

drill.devCounterparties = authoritativeDevList;
drill.aggregate.devCounterparties = authoritativeDevList.length;
drill.aggregate.totalDevTxs = authoritativeDevList.reduce((s,d)=>s+d.total, 0);
drill._note = 'devCounterparties enriched from authoritative per-dev-pair scan (original trace) — not subject to 8k page-cap.';

fs.writeFileSync('exports/ravedao_active_wallet_deep_drill.json', JSON.stringify(drill, null, 2));
console.log(`✅ Patched: ${authoritativeDevList.length} dev counterparties, ${drill.aggregate.totalDevTxs} total dev txs`);
authoritativeDevList.forEach(d => console.log(`  ${d.cp} — ${d.total} txs (in=${d.in}/out=${d.out}) · ${d.tokens.length} tokens · ${d.firstTs} → ${d.lastTs}`));
