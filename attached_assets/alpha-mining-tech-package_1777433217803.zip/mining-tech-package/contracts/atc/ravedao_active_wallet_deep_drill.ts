/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Deep drill on a single active wallet (default 0x7c5874a1…) — pulls full
 * transfer history (both directions), funding source, outbound destinations,
 * cross-references against the dev cohort + the other 17 active wallets, and
 * builds a per-token co-trading inventory.
 * Title 17 / DMCA / CFAA / DTSA protected.  INTERNAL CASE.
 */
import * as fs from 'fs';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Deep Drill');

const TARGET = (process.env.TARGET || '0x7c5874a11b4dd3aba411fa8b942ae90d1d662705').toLowerCase();
const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }
const ALCHEMY = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

const tdSet = new Set<string>(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));
const traceJ = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const ACTIVE = new Set<string>(traceJ.walletReports.map((r: any) => r.wallet.toLowerCase()));
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(ALCHEMY, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({jsonrpc:'2.0',id:1,method,params}) });
      if (!r.ok) { await sleep(400); continue; }
      const j: any = await r.json(); if (j?.error) return null; return j?.result ?? null;
    } catch { await sleep(400); }
  }
  return null;
}

async function getAllTransfers(addr: string, role: 'fromAddress'|'toAddress'): Promise<any[]> {
  const out: any[] = []; let pageKey: string|undefined;
  for (let p = 0; p < 8; p++) {
    const params: any = { [role]: addr, category:['external','erc20'], maxCount:'0x3e8', withMetadata:true, excludeZeroValue:true };
    if (pageKey) params.pageKey = pageKey;
    const res = await alchemy('alchemy_getAssetTransfers', [params]);
    if (!res?.transfers) break;
    out.push(...res.transfers);
    if (!res.pageKey) break;
    pageKey = res.pageKey;
    await sleep(180);
  }
  return out;
}

(async () => {
  console.log(`[DRILL] target = ${TARGET}`);
  const [outT, inT] = await Promise.all([
    getAllTransfers(TARGET, 'fromAddress'),
    getAllTransfers(TARGET, 'toAddress'),
  ]);
  console.log(`  out: ${outT.length} txs`);
  console.log(`  in:  ${inT.length} txs`);

  // ----- Token-level inventory -----
  const tokens: Record<string, { in: number; out: number; vIn: number; vOut: number; firstTs?: string; lastTs?: string }> = {};
  const counterPartyTok: Record<string, Record<string, { in: number; out: number }>> = {};
  const allCp: Record<string, { in: number; out: number; firstTs?: string; lastTs?: string; tokens: Set<string> }> = {};

  const proc = (t: any, dir: 'in'|'out') => {
    const sym = t.asset || (t.category === 'external' ? 'ETH' : '?');
    if (!tokens[sym]) tokens[sym] = { in: 0, out: 0, vIn: 0, vOut: 0 };
    const ts = t.metadata?.blockTimestamp || t.timestamp;
    if (ts) {
      if (!tokens[sym].firstTs || ts < tokens[sym].firstTs!) tokens[sym].firstTs = ts;
      if (!tokens[sym].lastTs  || ts > tokens[sym].lastTs!)  tokens[sym].lastTs = ts;
    }
    if (dir === 'in') { tokens[sym].in++; tokens[sym].vIn += Number(t.value)||0; }
    else              { tokens[sym].out++; tokens[sym].vOut += Number(t.value)||0; }
    const cp = String(dir === 'in' ? t.from : t.to).toLowerCase();
    if (!allCp[cp]) allCp[cp] = { in: 0, out: 0, tokens: new Set() };
    if (dir === 'in') allCp[cp].in++; else allCp[cp].out++;
    if (ts) {
      if (!allCp[cp].firstTs || ts < allCp[cp].firstTs!) allCp[cp].firstTs = ts;
      if (!allCp[cp].lastTs  || ts > allCp[cp].lastTs!)  allCp[cp].lastTs = ts;
    }
    allCp[cp].tokens.add(sym);
    if (!counterPartyTok[cp]) counterPartyTok[cp] = {};
    if (!counterPartyTok[cp][sym]) counterPartyTok[cp][sym] = { in: 0, out: 0 };
    if (dir === 'in') counterPartyTok[cp][sym].in++; else counterPartyTok[cp][sym].out++;
  };
  outT.forEach(t => proc(t, 'out'));
  inT.forEach(t => proc(t, 'in'));

  // ----- Classify counterparties -----
  const devCps:    Array<{cp: string; in: number; out: number; tokens: string[]}> = [];
  const activeCps: Array<{cp: string; in: number; out: number; tokens: string[]}> = [];
  const otherCps:  Array<{cp: string; in: number; out: number; tokens: string[]}> = [];
  for (const [cp, d] of Object.entries(allCp)) {
    const item = { cp, in: d.in, out: d.out, tokens: [...d.tokens] };
    if (tdSet.has(cp))      devCps.push(item);
    else if (ACTIVE.has(cp))activeCps.push(item);
    else                    otherCps.push(item);
  }
  devCps.sort((a,b) => (b.in+b.out)-(a.in+a.out));
  activeCps.sort((a,b) => (b.in+b.out)-(a.in+a.out));
  otherCps.sort((a,b) => (b.in+b.out)-(a.in+a.out));

  // ----- Funding source: earliest 5 inbound txs -----
  const earliestIn = [...inT].sort((a,b) => (a.metadata?.blockTimestamp||'').localeCompare(b.metadata?.blockTimestamp||'')).slice(0, 5);

  // ----- Top outbound destinations (non-active, non-dev) -----
  const topOtherOut = otherCps.filter(c => c.out > 5).slice(0, 15);

  const out = {
    _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Deep Drill'),
    target: TARGET,
    generatedAt: new Date().toISOString(),
    aggregate: {
      totalOut: outT.length,
      totalIn: inT.length,
      uniqueTokens: Object.keys(tokens).length,
      uniqueCounterparties: Object.keys(allCp).length,
      devCounterparties: devCps.length,
      otherActiveWalletCounterparties: activeCps.length,
      otherCounterparties: otherCps.length,
    },
    earliestInbound: earliestIn.map(t => ({
      hash: t.hash, from: t.from, asset: t.asset || 'ETH', value: t.value,
      ts: t.metadata?.blockTimestamp,
    })),
    devCounterparties: devCps,
    otherActiveWalletCounterparties: activeCps,
    topOtherOutbound: topOtherOut,
    tokenInventory: Object.entries(tokens).map(([sym, d]) => ({
      symbol: sym, in: d.in, out: d.out, valueIn: d.vIn, valueOut: d.vOut,
      firstTs: d.firstTs, lastTs: d.lastTs,
    })).sort((a,b)=>(b.in+b.out)-(a.in+a.out)),
    perCounterpartyTokens: counterPartyTok,
  };

  fs.writeFileSync('exports/ravedao_active_wallet_deep_drill.json', JSON.stringify(out, null, 2));
  console.log('\n✅ exports/ravedao_active_wallet_deep_drill.json');
  console.log(`[SUMMARY] ${out.aggregate.uniqueTokens} unique tokens, ${out.aggregate.uniqueCounterparties} counterparties (devs=${devCps.length}, otherActives=${activeCps.length}, others=${otherCps.length})`);
})().catch(e => { console.error(e); process.exit(1); });
