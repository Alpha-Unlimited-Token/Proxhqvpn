/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * RAVEDAO Dev-Cohort Classifier + Refined Active-Wallet Interaction Report
 *
 * Architect feedback: the raw devCohort.earliestHolders set may include
 * contracts, exchanges, routers, dead addresses, and burn sinks — inflating
 * "direct dev interaction" counts.  This pass:
 *   1. Classifies each of the 30 dev addresses via:
 *      - is_contract (eth_getCode)
 *      - dead/null/zero address pattern match
 *      - well-known label list (exchanges, Uniswap routers, common protocols)
 *   2. Splits into TRUE_DEV_EOA vs INFRA (contract/exchange/router/dead)
 *   3. Re-aggregates the 18-active-wallet trace JSON, computing direct +
 *      one-hop interactions filtered to TRUE_DEV_EOA only.
 *
 * Outputs:
 *   exports/ravedao_dev_cohort_classified.json
 *   exports/ravedao_active_wallets_dev_interaction_REFINED.md
 *
 * Distribution: INTERNAL OWNER USE ONLY.
 * Title 17 / DMCA / CFAA / DTSA protected.
 */

import fs from 'node:fs';
import path from 'node:path';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Cohort Classifier & Refinement');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }
const ALCHEMY = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// --- Known label/heuristic dictionaries ---------------------------------
// Hand-curated from on-chain reconnaissance + Etherscan tags. Conservative.
const KNOWN_LABELS: Record<string, string> = {
  // Common burn/dead/zero
  '0x0000000000000000000000000000000000000000': 'NULL_ADDRESS',
  '0x000000000000000000000000000000000000dead': 'DEAD_ADDRESS',
  // Permit2 / common protocol entry points
  '0x000000000022d473030f116ddee9f6b43ac78ba3': 'UNISWAP_PERMIT2',
  // Note: most CEX deposit addresses are labelled per-user, so we rely
  // on eth_getCode + naming heuristics for unknowns.
};
// Heuristic regex matchers for "vanity" addresses commonly used as
// system / protocol / aggregator sinks.
const SYSTEM_PATTERNS = [
  /^0x0{12,}/,                  // 12+ leading zeros → likely vanity router/system
  /^0x000000000004444/,         // 0x000000000004444c5dc75cb358380d2e3de08a90 — known
];

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(ALCHEMY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      });
      if (!r.ok) { await sleep(400); continue; }
      const j: any = await r.json();
      if (j?.error) return null;
      return j?.result ?? null;
    } catch { await sleep(400); }
  }
  return null;
}

async function isContract(addr: string): Promise<boolean> {
  const code = await alchemy('eth_getCode', [addr, 'latest']);
  return !!(code && code !== '0x' && code !== '0x0');
}

type DevClass = {
  address: string;
  tokensReceived: number;
  isContract: boolean;
  knownLabel: string | null;
  systemMatch: boolean;
  classification: 'TRUE_DEV_EOA' | 'CONTRACT' | 'KNOWN_INFRA' | 'SYSTEM_VANITY';
  reason: string;
};

(async () => {
  const dump = JSON.parse(fs.readFileSync('contracts/atc/ravedao_dump_analysis.json','utf-8'));
  const devs: { address: string; tokensReceived: number }[] = (dump.devCohort?.earliestHolders || [])
    .map((d: any) => ({ address: d.address.toLowerCase(), tokensReceived: d.tokensReceived }));

  console.log(`[INFO] Classifying ${devs.length} dev cohort addresses…`);

  const classified: DevClass[] = [];
  for (const d of devs) {
    const knownLabel = KNOWN_LABELS[d.address] || null;
    const systemMatch = SYSTEM_PATTERNS.some(rx => rx.test(d.address));
    const ic = await isContract(d.address);

    let classification: DevClass['classification'];
    let reason = '';
    if (knownLabel) { classification = 'KNOWN_INFRA'; reason = `Labeled: ${knownLabel}`; }
    else if (systemMatch) { classification = 'SYSTEM_VANITY'; reason = `Vanity/system pattern`; }
    else if (ic) { classification = 'CONTRACT'; reason = 'Has bytecode (eth_getCode)'; }
    else { classification = 'TRUE_DEV_EOA'; reason = 'EOA, no special label'; }

    classified.push({
      address: d.address,
      tokensReceived: d.tokensReceived,
      isContract: ic,
      knownLabel, systemMatch,
      classification, reason,
    });
    console.log(`  ${d.address}  →  ${classification.padEnd(16)}  (${reason})`);
    await sleep(120);
  }

  const trueDevEoas = new Set(classified.filter(c => c.classification === 'TRUE_DEV_EOA').map(c => c.address));
  console.log(`\n[CLASSIFIED] TRUE_DEV_EOA=${trueDevEoas.size}  CONTRACT=${classified.filter(c=>c.classification==='CONTRACT').length}  KNOWN_INFRA=${classified.filter(c=>c.classification==='KNOWN_INFRA').length}  SYSTEM_VANITY=${classified.filter(c=>c.classification==='SYSTEM_VANITY').length}`);

  // ----- Re-aggregate active-wallet interaction data --------------------
  const ckPath = 'exports/ravedao_active_wallets_dev_interaction.checkpoint.json';
  const fullPath = 'exports/ravedao_active_wallets_dev_interaction.json';
  const reportsRaw = JSON.parse(fs.readFileSync(fs.existsSync(fullPath) ? fullPath : ckPath, 'utf-8'));
  const reports = (reportsRaw.walletReports || reportsRaw);

  const refined = reports.map((r: any) => {
    const directReal = (r.directInteractions || []).filter((h: any) => trueDevEoas.has(h.devAddress));
    const interReal = (r.oneHopIntermediaries || []).filter((h: any) => trueDevEoas.has(h.devAddress));
    const uniqueDevs = new Set(directReal.map((h: any) => h.devAddress));
    const ts = directReal.map((h: any) => h.timestamp).filter(Boolean).sort();
    return {
      wallet: r.wallet,
      isTrueDev: trueDevEoas.has(r.wallet),
      directReal,
      interReal,
      summary: {
        directHits_RAW: r.summary.directHitCount,
        directHits_FILTERED: directReal.length,
        uniqueTrueDevs: uniqueDevs.size,
        intermediaries_RAW: r.summary.intermediariesFound,
        intermediaries_FILTERED: interReal.length,
        earliest: ts[0] || null,
        latest:   ts[ts.length-1] || null,
      },
    };
  });

  const cleanCount = refined.filter((r: any) => !r.isTrueDev && r.summary.directHits_FILTERED === 0 && r.summary.intermediaries_FILTERED === 0).length;
  const directCount = refined.filter((r: any) => r.summary.directHits_FILTERED > 0).length;
  const interCount  = refined.filter((r: any) => r.summary.intermediaries_FILTERED > 0).length;
  const isDevCount  = refined.filter((r: any) => r.isTrueDev).length;

  // Write classified JSON
  fs.writeFileSync('exports/ravedao_dev_cohort_classified.json', JSON.stringify({
    _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Cohort Classifier & Refinement'),
    generatedAt: new Date().toISOString(),
    classification: classified,
    trueDevEoas: [...trueDevEoas],
  }, null, 2));

  // Write refined Markdown
  const md: string[] = [];
  md.push('# RAVEDAO — 18 Active Wallets ⇄ Dev-Cohort Interaction (REFINED)');
  md.push('');
  md.push(`**Generated:** ${new Date().toISOString()}`);
  md.push(`**Token:** ${dump.token?.symbol} (${dump.token?.address})`);
  md.push('');
  md.push('## Cohort Classification');
  md.push('');
  md.push('| Class | Count | Description |');
  md.push('|---|---|---|');
  md.push(`| TRUE_DEV_EOA | ${trueDevEoas.size} | EOA, no contract code, no exchange/router label — these are the real human-controlled developer wallets |`);
  md.push(`| CONTRACT     | ${classified.filter(c=>c.classification==='CONTRACT').length} | Has on-chain bytecode (smart contract — not a person) |`);
  md.push(`| KNOWN_INFRA  | ${classified.filter(c=>c.classification==='KNOWN_INFRA').length} | Labeled exchange/router/permit2 |`);
  md.push(`| SYSTEM_VANITY| ${classified.filter(c=>c.classification==='SYSTEM_VANITY').length} | Vanity/system pattern (e.g. 12+ leading zeros) |`);
  md.push('');
  md.push('### TRUE_DEV_EOA list (the real developer wallets)');
  md.push('');
  md.push('| # | Address | Tokens received in dev allocation |');
  md.push('|---|---|---|');
  let i = 0;
  for (const c of classified.filter(c => c.classification === 'TRUE_DEV_EOA').sort((a,b) => b.tokensReceived - a.tokensReceived)) {
    i++;
    md.push(`| ${i} | \`${c.address}\` | ${c.tokensReceived.toLocaleString()} RAVE |`);
  }
  md.push('');
  md.push('### Excluded (CONTRACT / KNOWN_INFRA / SYSTEM_VANITY)');
  md.push('');
  md.push('| Address | Class | Reason |');
  md.push('|---|---|---|');
  for (const c of classified.filter(c => c.classification !== 'TRUE_DEV_EOA')) {
    md.push(`| \`${c.address}\` | ${c.classification} | ${c.reason} |`);
  }
  md.push('');
  md.push('---');
  md.push('');
  md.push('## Refined Aggregate (TRUE_DEV_EOA only)');
  md.push('');
  md.push(`- Active wallets that ARE a TRUE_DEV_EOA themselves: **${isDevCount}**`);
  md.push(`- Active wallets with DIRECT interaction with a true dev: **${directCount}/18**`);
  md.push(`- Active wallets with ONE-HOP intermediary to a true dev: **${interCount}/18**`);
  md.push(`- Active wallets with NO link to any true dev (clean):    **${cleanCount}/18**`);
  md.push('');
  md.push('---');
  md.push('');
  md.push('## Per-wallet refined findings');
  md.push('');
  md.push('| # | Wallet | Is true dev? | Direct (raw → filtered) | Unique true devs | One-hop (raw → filtered) | Window |');
  md.push('|---|---|---|---|---|---|---|');
  let n = 0;
  for (const r of refined) {
    n++;
    const win = r.summary.earliest ? `${r.summary.earliest.slice(0,10)} → ${r.summary.latest.slice(0,10)}` : '—';
    md.push(`| ${n} | \`${r.wallet}\` | ${r.isTrueDev?'**YES**':'no'} | ${r.summary.directHits_RAW} → **${r.summary.directHits_FILTERED}** | ${r.summary.uniqueTrueDevs} | ${r.summary.intermediaries_RAW} → **${r.summary.intermediaries_FILTERED}** | ${win} |`);
  }
  md.push('');
  md.push('### Detailed per-wallet (true-dev hits only)');
  md.push('');
  for (const r of refined) {
    if (r.summary.directHits_FILTERED === 0 && r.summary.intermediaries_FILTERED === 0 && !r.isTrueDev) continue;
    md.push(`#### \`${r.wallet}\``);
    if (r.isTrueDev) md.push(`- ⚠️ **IS A TRUE DEV** in the dev allocation cohort`);
    md.push(`- Direct true-dev interactions: ${r.summary.directHits_FILTERED} (across ${r.summary.uniqueTrueDevs} unique devs)`);
    md.push(`- One-hop intermediary links to true devs: ${r.summary.intermediaries_FILTERED}`);
    if (r.directReal.length > 0) {
      md.push('');
      md.push('| Direction | True dev | Asset | Tx |');
      md.push('|---|---|---|---|');
      for (const h of r.directReal.slice(0, 5)) {
        md.push(`| ${h.direction} | \`${h.devAddress}\` | ${h.asset || '—'} | \`${h.hash.slice(0,18)}…\` |`);
      }
    }
    md.push('');
  }

  fs.writeFileSync('exports/ravedao_active_wallets_dev_interaction_REFINED.md', md.join('\n'));
  console.log('\n✅ exports/ravedao_dev_cohort_classified.json');
  console.log('✅ exports/ravedao_active_wallets_dev_interaction_REFINED.md');
  console.log(`\n[FINAL REFINED] ${cleanCount}/18 clean | ${directCount}/18 direct | ${interCount}/18 one-hop | ${isDevCount} are true devs`);
})().catch(e => { console.error(e); process.exit(1); });
