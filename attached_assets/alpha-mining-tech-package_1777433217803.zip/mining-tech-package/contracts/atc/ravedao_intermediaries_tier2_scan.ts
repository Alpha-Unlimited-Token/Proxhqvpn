/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Tier-2 intermediary scan: takes the top-N 1-hop intermediary addresses surfaced
 * by the active-wallet trace and probes each for (a) co-trading depth with the
 * dev cohort, (b) extension into other active wallets, (c) bucket classification.
 *
 * Title 17 / DMCA / CFAA / DTSA protected.  INTERNAL CASE.
 */
import * as fs from 'fs';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Tier-2 Intermediary Scan');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }
const ALCHEMY = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const tdSet  = new Set<string>(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));
const traceJ = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const ACTIVE = new Set<string>(traceJ.walletReports.map((r: any) => r.wallet.toLowerCase()));
const interInput = JSON.parse(fs.readFileSync('exports/ravedao_intermediaries_tier2_input.json','utf-8'));

const CHECKPOINT = 'exports/ravedao_intermediaries_tier2.checkpoint.json';
const TOP_N = parseInt(process.env.TOP_N || '20', 10);
const MAX_THIS_RUN = parseInt(process.env.MAX_THIS_RUN || '99', 10);

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(ALCHEMY, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({jsonrpc:'2.0',id:1,method,params}) });
      if (!r.ok) { await sleep(400); continue; }
      const j: any = await r.json(); if (j?.error) return null; return j?.result ?? null;
    } catch { await sleep(400); }
  }
  return null;
}
async function getTransfers(addr: string, role: 'fromAddress'|'toAddress', maxPages = 3): Promise<any[]> {
  const out: any[] = []; let pageKey: string|undefined;
  for (let p = 0; p < maxPages; p++) {
    const params: any = { [role]: addr, category:['external','erc20'], maxCount:'0x3e8', withMetadata:true, excludeZeroValue:true };
    if (pageKey) params.pageKey = pageKey;
    const res = await alchemy('alchemy_getAssetTransfers', [params]);
    if (!res?.transfers) break;
    out.push(...res.transfers);
    if (!res.pageKey) break;
    pageKey = res.pageKey;
    await sleep(150);
  }
  return out;
}
async function isContract(addr: string): Promise<boolean> {
  const code = await alchemy('eth_getCode', [addr, 'latest']);
  return !!(code && code !== '0x' && code !== '0x0');
}

(async () => {
  let scans: any[] = [];
  if (fs.existsSync(CHECKPOINT)) {
    try { scans = JSON.parse(fs.readFileSync(CHECKPOINT,'utf-8')); console.log(`[RESUME] ${scans.length} prior scans`); } catch {}
  }
  const done = new Set(scans.map(s => s.address));
  const targets = interInput.slice(0, TOP_N);
  let processedThisRun = 0;

  for (const t of targets) {
    if (done.has(t.cp)) { console.log(`[SKIP] ${t.cp}`); continue; }
    if (processedThisRun >= MAX_THIS_RUN) { console.log(`[STOP] MAX_THIS_RUN`); break; }
    console.log(`\n[T2] ${t.cp}`);
    const ic = await isContract(t.cp);
    if (ic) {
      console.log(`  ↳ CONTRACT — skipping deep scan`);
      scans.push({ address: t.cp, isContract: true, classification: 'CONTRACT', referencedFromActives: t.activeWallets, referencedFromDevs: t.devs });
      fs.writeFileSync(CHECKPOINT, JSON.stringify(scans, null, 2));
      processedThisRun++; continue;
    }
    const [outT, inT] = await Promise.all([
      getTransfers(t.cp, 'fromAddress', 2),
      getTransfers(t.cp, 'toAddress', 2),
    ]);
    console.log(`  out=${outT.length}, in=${inT.length}`);

    // Counterparties seen in this intermediary's history
    const cpStats: Record<string, { in: number; out: number; tokens: Set<string>; firstTs?: string; lastTs?: string }> = {};
    const proc = (tx: any, dir: 'in'|'out') => {
      const cp = String(dir === 'in' ? tx.from : tx.to).toLowerCase();
      if (!cp || cp === t.cp) return;
      if (!cpStats[cp]) cpStats[cp] = { in: 0, out: 0, tokens: new Set() };
      if (dir === 'in') cpStats[cp].in++; else cpStats[cp].out++;
      const sym = tx.asset || (tx.category === 'external' ? 'ETH' : '?');
      cpStats[cp].tokens.add(sym);
      const ts = tx.metadata?.blockTimestamp;
      if (ts) {
        if (!cpStats[cp].firstTs || ts < cpStats[cp].firstTs!) cpStats[cp].firstTs = ts;
        if (!cpStats[cp].lastTs  || ts > cpStats[cp].lastTs!)  cpStats[cp].lastTs = ts;
      }
    };
    outT.forEach(tx => proc(tx, 'out'));
    inT.forEach(tx => proc(tx, 'in'));

    const devCp:    string[] = []; const activeCp: string[] = [];
    let devTxs = 0, activeTxs = 0;
    for (const [cp, d] of Object.entries(cpStats)) {
      if (tdSet.has(cp))      { devCp.push(cp); devTxs += d.in + d.out; }
      else if (ACTIVE.has(cp)) { activeCp.push(cp); activeTxs += d.in + d.out; }
    }

    // Token mix
    const tokenMix: Record<string, number> = {};
    for (const tx of [...outT, ...inT]) { const s = tx.asset || (tx.category === 'external' ? 'ETH' : '?'); tokenMix[s] = (tokenMix[s]||0)+1; }
    const topTokens = Object.entries(tokenMix).sort((a,b)=>b[1]-a[1]).slice(0,8);

    // Bucket the intermediary
    let bucket = 'PERIPHERAL';
    const linksDevs = devCp.length;
    const linksActives = activeCp.length;
    if (linksDevs >= 2 && linksActives >= 2) bucket = 'NETWORK_HUB';
    else if (linksDevs >= 2 && linksActives >= 1) bucket = 'DEV_HEAVY_RELAY';
    else if (linksActives >= 2) bucket = 'ACTIVE_HEAVY_RELAY';
    else if (linksDevs === 1 && linksActives === 1) bucket = 'BRIDGE_RELAY';

    scans.push({
      address: t.cp,
      isContract: false,
      bucket,
      referencedFromActives: t.activeWallets,
      referencedFromDevs: t.devs,
      directDevCounterparties: devCp,
      directActiveWalletCounterparties: activeCp,
      devCounterpartyCount: linksDevs,
      activeWalletCounterpartyCount: linksActives,
      txsWithDevs: devTxs,
      txsWithActives: activeTxs,
      totalOut: outT.length,
      totalIn:  inT.length,
      uniqueCounterparties: Object.keys(cpStats).length,
      topTokens: topTokens.map(([s,c]) => ({ symbol: s, count: c })),
    });
    console.log(`  bucket=${bucket} | direct devs=${linksDevs} (${devTxs} txs) | direct actives=${linksActives} (${activeTxs} txs) | tokens=${Object.keys(tokenMix).length}`);
    fs.writeFileSync(CHECKPOINT, JSON.stringify(scans, null, 2));
    processedThisRun++;
  }

  // Final
  if (scans.length < targets.length) {
    console.log(`[PARTIAL] ${scans.length}/${targets.length} — re-run to continue`);
    process.exit(0);
  }

  const summary = {
    _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Tier-2 Intermediary Scan'),
    generatedAt: new Date().toISOString(),
    totalScanned: scans.length,
    contracts: scans.filter(s => s.isContract).length,
    eoas:      scans.filter(s => !s.isContract).length,
    buckets: {
      NETWORK_HUB:        scans.filter(s => s.bucket === 'NETWORK_HUB').length,
      DEV_HEAVY_RELAY:    scans.filter(s => s.bucket === 'DEV_HEAVY_RELAY').length,
      ACTIVE_HEAVY_RELAY: scans.filter(s => s.bucket === 'ACTIVE_HEAVY_RELAY').length,
      BRIDGE_RELAY:       scans.filter(s => s.bucket === 'BRIDGE_RELAY').length,
      PERIPHERAL:         scans.filter(s => s.bucket === 'PERIPHERAL').length,
      CONTRACT:           scans.filter(s => s.isContract).length,
    },
    intermediaries: scans,
  };
  fs.writeFileSync('exports/ravedao_intermediaries_tier2_scan.json', JSON.stringify(summary, null, 2));
  console.log(`\n✅ exports/ravedao_intermediaries_tier2_scan.json`);
  console.log(`[DONE] hubs=${summary.buckets.NETWORK_HUB} devHeavy=${summary.buckets.DEV_HEAVY_RELAY} activeHeavy=${summary.buckets.ACTIVE_HEAVY_RELAY} bridge=${summary.buckets.BRIDGE_RELAY} periph=${summary.buckets.PERIPHERAL} contracts=${summary.buckets.CONTRACT}`);
})().catch(e => { console.error(e); process.exit(1); });
