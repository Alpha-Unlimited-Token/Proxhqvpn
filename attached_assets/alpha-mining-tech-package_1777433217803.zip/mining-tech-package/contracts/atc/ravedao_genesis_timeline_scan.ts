/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Genesis-Timeline scanner: for each of the 18 active wallets and each of the
 * 22 true dev EOAs, fetches the OLDEST inbound + outbound transfers (ascending
 * order from block 0) to find the very FIRST on-chain contact between any
 * (active, dev) pair, and builds the chronological progression of dev↔active
 * interactions from earliest known event to today.
 *
 * Title 17 / DMCA / CFAA / DTSA protected.  INTERNAL CASE.
 */
import * as fs from 'fs';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Dev-Dumper Collusion Detector™ — Genesis Timeline');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }
const ALCHEMY = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const tdSet  = new Set<string>(JSON.parse(fs.readFileSync('exports/ravedao_dev_cohort_classified.json','utf-8')).trueDevEoas.map((a: string) => a.toLowerCase()));
const trueDevs: string[] = [...tdSet];
const traceJ = JSON.parse(fs.readFileSync('exports/ravedao_active_wallets_dev_interaction.json','utf-8'));
const ACTIVE: string[] = traceJ.walletReports.map((r: any) => r.wallet.toLowerCase());

const CHECKPOINT = 'exports/ravedao_genesis_timeline.checkpoint.json';
const MAX_THIS_RUN = parseInt(process.env.MAX_THIS_RUN || '99', 10);

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(ALCHEMY, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({jsonrpc:'2.0',id:1,method,params}) });
      if (!r.ok) { await sleep(400); continue; }
      const j: any = await r.json(); if (j?.error) return null; return j?.result ?? null;
    } catch { await sleep(400); }
  }
  return null;
}

// Pull OLDEST transfers — ascending order, only first 2 pages (oldest 2000 txs)
async function getOldestTransfers(addr: string, role: 'fromAddress'|'toAddress'): Promise<any[]> {
  const out: any[] = []; let pageKey: string|undefined;
  for (let p = 0; p < 2; p++) {
    const params: any = {
      [role]: addr,
      category:['external','erc20'],
      order: 'asc',
      maxCount:'0x3e8',
      withMetadata:true,
      excludeZeroValue:true,
      fromBlock: '0x0',
    };
    if (pageKey) params.pageKey = pageKey;
    const res = await alchemy('alchemy_getAssetTransfers', [params]);
    if (!res?.transfers) break;
    out.push(...res.transfers);
    if (!res.pageKey) break;
    pageKey = res.pageKey;
    await sleep(150);
  }
  return out;
}

// First-funding source (the very first inbound transfer ever — origin of the wallet)
async function getWalletGenesis(addr: string): Promise<any | null> {
  const oldest = await getOldestTransfers(addr, 'toAddress');
  if (!oldest.length) return null;
  return oldest[0];   // earliest inbound = wallet creation/funding
}

// First contact between addr and any of the targets[]
async function findEarliestContact(addr: string, targets: Set<string>): Promise<any[]> {
  const matches: any[] = [];
  const out = await getOldestTransfers(addr, 'fromAddress');
  const inn = await getOldestTransfers(addr, 'toAddress');
  for (const t of out) { const cp = String(t.to).toLowerCase(); if (targets.has(cp)) matches.push({ ...t, _direction: 'this→target', _target: cp }); }
  for (const t of inn) { const cp = String(t.from).toLowerCase(); if (targets.has(cp)) matches.push({ ...t, _direction: 'target→this', _target: cp }); }
  matches.sort((a,b) => (a.metadata?.blockTimestamp||'').localeCompare(b.metadata?.blockTimestamp||''));
  return matches;
}

(async () => {
  let scans: Record<string, any> = {};
  if (fs.existsSync(CHECKPOINT)) {
    try { scans = JSON.parse(fs.readFileSync(CHECKPOINT,'utf-8')); console.log(`[RESUME] ${Object.keys(scans).length} prior records`); } catch {}
  }

  // For each active wallet, find genesis + earliest dev contact
  const devSet = new Set(trueDevs);
  let processed = 0;
  for (const a of ACTIVE) {
    if (scans[a]) { console.log(`[SKIP-A] ${a}`); continue; }
    if (processed >= MAX_THIS_RUN) { console.log(`[STOP]`); break; }
    console.log(`\n[GENESIS] active ${a}`);
    const genesis = await getWalletGenesis(a);
    const earliestDev = await findEarliestContact(a, devSet);
    console.log(`  wallet first funded: ${genesis?.metadata?.blockTimestamp || '?'} from ${genesis?.from || '?'} (${genesis?.asset || '?'} ${genesis?.value || '?'})`);
    console.log(`  earliest dev contacts found in oldest pages: ${earliestDev.length}`);
    if (earliestDev[0]) console.log(`    first dev contact: ${earliestDev[0].metadata?.blockTimestamp} | ${earliestDev[0]._direction} | ${earliestDev[0]._target}`);
    scans[a] = {
      role: 'active',
      walletGenesis: genesis ? {
        ts: genesis.metadata?.blockTimestamp,
        from: genesis.from, to: genesis.to,
        asset: genesis.asset || 'ETH',
        value: genesis.value,
        hash: genesis.hash,
      } : null,
      earliestDevContacts: earliestDev.slice(0, 5).map(t => ({
        ts: t.metadata?.blockTimestamp,
        direction: t._direction,
        devAddress: t._target,
        asset: t.asset || 'ETH',
        value: t.value,
        hash: t.hash,
      })),
    };
    fs.writeFileSync(CHECKPOINT, JSON.stringify(scans, null, 2));
    processed++;
  }

  // For each true dev, find genesis + earliest contact with any active wallet
  const activeSet = new Set(ACTIVE);
  for (const d of trueDevs) {
    if (scans[d]) { console.log(`[SKIP-D] ${d}`); continue; }
    if (processed >= MAX_THIS_RUN) { console.log(`[STOP]`); break; }
    console.log(`\n[GENESIS] dev ${d}`);
    const genesis = await getWalletGenesis(d);
    const earliestActive = await findEarliestContact(d, activeSet);
    console.log(`  wallet first funded: ${genesis?.metadata?.blockTimestamp || '?'} from ${genesis?.from || '?'} (${genesis?.asset || '?'} ${genesis?.value || '?'})`);
    console.log(`  earliest active contacts: ${earliestActive.length}`);
    if (earliestActive[0]) console.log(`    first active contact: ${earliestActive[0].metadata?.blockTimestamp} | ${earliestActive[0]._direction} | ${earliestActive[0]._target}`);
    scans[d] = {
      role: 'dev',
      walletGenesis: genesis ? {
        ts: genesis.metadata?.blockTimestamp,
        from: genesis.from, to: genesis.to,
        asset: genesis.asset || 'ETH',
        value: genesis.value,
        hash: genesis.hash,
      } : null,
      earliestActiveContacts: earliestActive.slice(0, 5).map(t => ({
        ts: t.metadata?.blockTimestamp,
        direction: t._direction,
        activeAddress: t._target,
        asset: t.asset || 'ETH',
        value: t.value,
        hash: t.hash,
      })),
    };
    fs.writeFileSync(CHECKPOINT, JSON.stringify(scans, null, 2));
    processed++;
  }

  if (Object.keys(scans).length < (ACTIVE.length + trueDevs.length)) {
    console.log(`[PARTIAL] ${Object.keys(scans).length}/${ACTIVE.length + trueDevs.length}`);
    process.exit(0);
  }

  // ---- Build pairwise first-contact matrix and global timeline ----
  type Pair = { active: string; dev: string; ts: string; direction: string; asset: string; value: any; hash: string };
  const pairwise: Pair[] = [];
  for (const a of ACTIVE) {
    for (const c of (scans[a]?.earliestDevContacts || [])) {
      pairwise.push({ active: a, dev: c.devAddress, ts: c.ts, direction: c.direction, asset: c.asset, value: c.value, hash: c.hash });
    }
  }
  for (const d of trueDevs) {
    for (const c of (scans[d]?.earliestActiveContacts || [])) {
      pairwise.push({ active: c.activeAddress, dev: d, ts: c.ts, direction: c.direction === 'this→target' ? 'dev→active' : 'active→dev', asset: c.asset, value: c.value, hash: c.hash });
    }
  }
  // dedupe to earliest per (active, dev) pair
  const earliestPair: Record<string, Pair> = {};
  for (const p of pairwise) {
    const k = `${p.active}|${p.dev}`;
    if (!earliestPair[k] || p.ts < earliestPair[k].ts) earliestPair[k] = p;
  }
  const sortedPairs = Object.values(earliestPair).sort((a,b) => a.ts.localeCompare(b.ts));

  // Wallet creation timeline
  const walletGenesisTimeline = [
    ...ACTIVE.map(a => ({ wallet: a, role: 'active', ts: scans[a]?.walletGenesis?.ts, from: scans[a]?.walletGenesis?.from, asset: scans[a]?.walletGenesis?.asset, value: scans[a]?.walletGenesis?.value, hash: scans[a]?.walletGenesis?.hash })),
    ...trueDevs.map(d => ({ wallet: d, role: 'dev', ts: scans[d]?.walletGenesis?.ts, from: scans[d]?.walletGenesis?.from, asset: scans[d]?.walletGenesis?.asset, value: scans[d]?.walletGenesis?.value, hash: scans[d]?.walletGenesis?.hash })),
  ].filter(x => x.ts).sort((a,b) => a.ts!.localeCompare(b.ts!));

  // Genesis funding cross-references — did any wallet's first inbound come from another wallet in our set?
  const allWallets = new Set([...ACTIVE, ...trueDevs]);
  const genesisCrossLinks: any[] = [];
  for (const w of allWallets) {
    const g = scans[w]?.walletGenesis;
    if (!g) continue;
    const fromAddr = String(g.from || '').toLowerCase();
    if (allWallets.has(fromAddr)) {
      genesisCrossLinks.push({
        recipient: w, recipientRole: ACTIVE.includes(w) ? 'active' : 'dev',
        fundedBy: fromAddr, funderRole: ACTIVE.includes(fromAddr) ? 'active' : 'dev',
        ts: g.ts, asset: g.asset, value: g.value, hash: g.hash,
      });
    }
  }

  const out = {
    _proprietaryHeader: proprietaryHeader('Alpha Dev-Dumper Collusion Detector™ — Genesis Timeline'),
    generatedAt: new Date().toISOString(),
    scope: {
      activeWalletCount: ACTIVE.length,
      trueDevCount: trueDevs.length,
    },
    walletGenesisTimeline,
    earliestDevActivePairs: sortedPairs,
    firstEverDevActiveContact: sortedPairs[0] || null,
    genesisCrossLinks,
    perWalletScans: scans,
  };
  fs.writeFileSync('exports/ravedao_genesis_timeline.json', JSON.stringify(out, null, 2));
  console.log(`\n✅ exports/ravedao_genesis_timeline.json`);
  console.log(`[DONE] ${sortedPairs.length} earliest pairs · ${genesisCrossLinks.length} genesis cross-links · first contact: ${sortedPairs[0]?.ts || 'none found'}`);
})().catch(e => { console.error(e); process.exit(1); });
