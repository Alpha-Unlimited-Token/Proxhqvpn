# Blockchain Integration Reference

Every external chain the mining stack talks to, with the exact RPC / API
endpoint each adapter calls and how it's wired.

---

## 1. Adapter map

| Adapter | File | Underlying provider | Auth |
|---------|------|---------------------|------|
| EVM (ETH/Polygon/Arbitrum/Optimism/Base) | `evmAdapter.ts` | Alchemy JSON-RPC | `ALCHEMY_API_KEY` |
| Solana | `solanaAdapter.ts` | Alchemy SOL RPC | `ALCHEMY_API_KEY` |
| Bitcoin | `bitcoinAdapter.ts` | mempool.space (UTXO-aware) | none (public) |
| Tron | `tronAdapter.ts` | TronGrid | none (public) |
| TON | `tonAdapter.ts` | TonAPI | none (public, optional key) |
| XRPL | `xrplAdapter.ts` | xrplcluster.com + XRPSCAN | none (public) |

All adapters expose the same `ChainAdapter` interface defined in
`chain-adapters/types.ts`:

```typescript
export interface ChainAdapter {
  chainId: string;
  name: string;
  getLatestBlockNumber(): Promise<number>;
  getBalance(address: string): Promise<bigint>;
  getTransactions(address: string, opts?: TxOpts): Promise<Tx[]>;
  getTransaction(hash: string): Promise<Tx | null>;
  isAddress(s: string): boolean;
}
```

Use them from any service:

```typescript
import { getAdapter } from './chain-adapters';

const adapter = getAdapter('polygon');
const head    = await adapter.getLatestBlockNumber();
const txs     = await adapter.getTransactions('0xabc...', { limit: 50 });
```

---

## 2. Alpha L1 — own chain endpoints

Mounted at `/api/blockchain/*` (see `server/blockchain/routes.ts`):

| Method | Path | Purpose | Auth |
|--------|------|---------|------|
| GET  | `/api/blockchain/blocks` | List recent blocks | required |
| POST | `/api/blockchain/analyze` | Run forensic analysis on a block / range | required + rate-limited |

Internally these call:

```typescript
import { getChain, getBlock, getMempool } from './blockchain';
const chain = getChain();
const tip   = chain.tip();         // latest block
const mp    = getMempool();        // pending txs
```

The Stratum mining pool listens on tcp **port 3333** (configurable in
`startStratumServer({ port })`). Standard Stratum-V1 messages are accepted:

```
{"id":1,"method":"mining.subscribe","params":["miner-name/1.0",null]}
{"id":2,"method":"mining.authorize","params":["worker.1","x"]}
{"id":3,"method":"mining.submit","params":["worker.1","jobId","extranonce2","ntime","nonce"]}
```

The P2P node listens on tcp **port 6000**. Add seed peers in
`startP2PNode({ port: 6000, peers: ['1.2.3.4:6000', ...] })`.

---

## 3. Mining-bridge endpoints (for external miner companions)

Mounted at `/api/mining-bridge/*`:

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/mining-bridge/publish` | External miner pushes a status / signal |
| GET  | `/api/mining-bridge/signals` | Pull recent signals |
| GET  | `/api/mining-bridge/status` | Bridge health |
| POST | `/api/mining-bridge/fusion/publish` | BIF (Bridge Integrity Fusion) signal |
| GET  | `/api/mining-bridge/fusion/signals` | Pull BIF signals |
| POST | `/api/mining-bridge/fusion/heartbeat` | Per-miner heartbeat |
| GET  | `/api/mining-bridge/fusion/heartbeats` | Recent heartbeats |
| POST | `/api/mining-bridge/fusion/conflict` | Report consensus conflict |
| GET  | `/api/mining-bridge/fusion/conflicts` | Recent conflicts |
| GET  | `/api/mining-bridge/fusion/status` | Fusion network state |

These are the endpoints `AlphaUnlimited-Miner.replit.app` (the desktop / mobile
companion) calls. Keep the wire format intact and your existing miners will
work against the new project.

---

## 4. Miner CRUD endpoints

Mounted at `/api/miners/*`:

| Method | Path | Purpose |
|--------|------|---------|
| GET    | `/api/miners` | List user's miners |
| POST   | `/api/miners` | Register a new miner |
| DELETE | `/api/miners/:id` | Remove a miner |
| PATCH  | `/api/miners/:id` | Update settings |
| POST   | `/api/miners/detect` | Auto-detect connected hardware |
| POST   | `/api/miners/scan` | Scan local network for ASICs |
| GET    | `/api/miners/:id/status` | Live hashrate + temps |
| POST   | `/api/miners/:id/adjust` | Manual difficulty adjust |
| POST   | `/api/miners/:id/restart` | Restart job assignment |
| POST   | `/api/miners/:id/identify` | Flash an LED to find a rig |
| POST   | `/api/miners/:id/auto-adjust` | Toggle the auto-tuner |

---

## 5. QMGE (Quantum Mining Genesis Engine) endpoints

Mounted at `/api/qmge/*`:

| Method | Path | Purpose | Auth |
|--------|------|---------|------|
| POST | `/api/qmge/checkout` | Stripe checkout for QMGE license | required |
| GET  | `/api/qmge/license` | Current license status | required |
| POST | `/api/qmge/license/activate` | Activate purchased license | required |
| POST | `/api/qmge/license/validate` | Server-side license check | required |
| POST | `/api/qmge/license/heartbeat` | Per-runtime heartbeat | required |
| POST | `/api/qmge/license/upgrade` | Tier upgrade | required |
| GET  | `/api/qmge/license/events` | Audit trail | required |
| GET  | `/api/qmge/download` | Download QMGE installer | required + rate-limited |
| GET  | `/api/qmge/mining-data` | Live mining feed (CORS-open) | rate-limited |

The `mining-data` endpoint is the only one that's CORS-open (handled with
`OPTIONS /api/qmge/mining-data`) — this is what the standalone PWA polls.

---

## 6. On-chain ETH contracts

| Contract | Source | Compiled artifact | Live address (mainnet) |
|----------|--------|-------------------|------------------------|
| Alpha Tracking Coin (ATC) | `contracts/atc/AlphaTrackingCoin.sol` | `contracts/atc/artifacts/AlphaTrackingCoin.json` | see `deployments/mainnet-deployment.json` |
| DAUv2 Dye Pack | `contracts/atc/DAUv2_DyePack.sol` | `contracts/atc/artifacts/DAUv2DyePack.json` | see `deployments/dauv2-mainnet-deployment.json` |
| DAUv2 Lite | `contracts/atc/DAUv2_Lite.sol` | (recompile from source) | not deployed |

### Compile

```bash
npx tsx contracts/atc/compile.ts
# writes contracts/atc/artifacts/<Name>.json
```

### Deploy

```bash
# Sepolia testnet first:
DEPLOY_NETWORK=sepolia npx tsx contracts/atc/deploy.ts

# Mainnet:
DEPLOY_NETWORK=mainnet npx tsx contracts/atc/deploy.ts
```

The deployer reads `ATC_DEPLOYER_PRIVATE_KEY` and `ALCHEMY_API_KEY`, builds an
`ethers.Wallet`, deploys the contract, and writes a deployment record to
`contracts/atc/deployments/<network>-deployment.json`.

### Listen

```bash
npx tsx contracts/atc/listener.ts        # ATC events
npx tsx contracts/atc/DAUv2_Listener.ts  # DyePack events
```

Both are designed to run forever; restart-on-fail with PM2 / systemd / a
Replit workflow.

---

## 7. Auth model

Every `isAuthenticated` route assumes you have set `req.user` upstream. The
parent project uses Replit Auth + Passport.js, but any middleware that
populates `req.user.id` (string) and `req.user.email` (string) will work.

For a quick test harness:

```typescript
function isAuthenticated(req, res, next) {
  req.user = { id: 'test-user', email: 'test@example.com' };
  next();
}
```

---

## 8. Rate-limit configuration

The route handlers expect three optional rate-limiters:

```typescript
miningDataRateLimit  : ~30 req/sec  // /api/qmge/mining-data
downloadRateLimit    : ~10 req/min  // /api/qmge/download
proprietaryRateLimit : ~60 req/min  // /api/blockchain/analyze
```

Pass `undefined` for any you don't want. The handlers check `if (limiter)
limiter(req, res, next)` before running.
