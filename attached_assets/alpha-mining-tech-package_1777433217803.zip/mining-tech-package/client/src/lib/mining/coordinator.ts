export type SignalPriority = 'qmge' | 'companion' | 'balanced';
export type ConflictResolution = 'qmge_override' | 'companion_override' | 'weighted_merge' | 'none';

export interface MinerAdjustments {
  intensity: number;
  nonceRange: number;
  difficulty: number;
  threads: number;
  refreshRate: number;
  latencyThreshold: number;
}

export interface QMGEMiningPayload {
  timestamp: number;
  symbol: string;
  difficultyPrediction: {
    direction: 'increasing' | 'decreasing' | 'stable';
    magnitude: number;
    confidence: number;
    optimalWindow: boolean;
  };
  chainProfitability: {
    score: number;
    signal: string;
    hashRateMigrationRisk: number;
    revenueProjection: number;
  };
  networkIntelligence: {
    congestionLevel: number;
    hashRateStability: number;
    orphanRiskFactor: number;
    blockPropagationScore: number;
  };
  miningWindow: {
    isOptimal: boolean;
    windowScore: number;
    timeRemaining: number;
    recommendation: string;
    reason: string;
  };
  hashOptimization: {
    nonceRangeHint: { start: number; end: number };
    resonanceFrequency: number;
    entropyGradient: number;
    convergenceTarget: number;
  };
  aggregateScore: number;
  genomePattern: string;
}

export interface CompanionSignals {
  isConnected: boolean;
  hashrate: number;
  temperature: number;
  powerUsage: number;
  efficiency: number;
  acceptedShares: number;
  rejectedShares: number;
  uptime: number;
}

export interface ConflictReport {
  hasConflict: boolean;
  severity: 'none' | 'low' | 'medium' | 'high' | 'critical';
  conflicts: ConflictDetail[];
  resolution: ConflictResolution;
  timestamp: number;
}

export interface ConflictDetail {
  parameter: string;
  companionValue: number;
  qmgeRecommended: number;
  delta: number;
  direction: 'increase' | 'decrease';
  reason: string;
  priority: 'qmge' | 'companion';
}

export interface CoordinatedCommand {
  adjustments: MinerAdjustments;
  source: SignalPriority;
  conflictReport: ConflictReport;
  qmgeApplied: boolean;
  recommendations: string[];
  overallAction: 'mine_full_power' | 'mine_reduced' | 'hold' | 'switch_chain' | 'manual';
  confidenceScore: number;
}

const INTENSITY_THRESHOLDS = {
  mine_full_power: { min: 85, max: 100 },
  mine_reduced: { min: 50, max: 75 },
  hold: { min: 10, max: 30 },
  switch_chain: { min: 0, max: 15 },
};

function qmgeToIntensity(qmge: QMGEMiningPayload): number {
  const windowScore = qmge.miningWindow.windowScore;
  const profitScore = qmge.chainProfitability.score;
  const stability = qmge.networkIntelligence.hashRateStability;

  const composite = windowScore * 0.4 + profitScore * 0.35 + stability * 0.25;
  return Math.max(10, Math.min(100, Math.round(composite)));
}

function qmgeToNonceRange(qmge: QMGEMiningPayload): number {
  const hint = qmge.hashOptimization.nonceRangeHint;
  const rangeSize = hint.end - hint.start;
  const normalized = Math.min(100, Math.round((rangeSize / 4294967295) * 100 * 50));
  return Math.max(0, Math.min(100, normalized));
}

function qmgeToDifficulty(qmge: QMGEMiningPayload): number {
  const dir = qmge.difficultyPrediction.direction;
  const magnitude = qmge.difficultyPrediction.magnitude;
  const confidence = qmge.difficultyPrediction.confidence;

  if (dir === 'decreasing') return Math.max(20, Math.round(50 - magnitude * 30 * (confidence / 100)));
  if (dir === 'increasing') return Math.min(90, Math.round(50 + magnitude * 40 * (confidence / 100)));
  return 50;
}

function qmgeToThreads(qmge: QMGEMiningPayload, currentThreads: number): number {
  const rec = qmge.miningWindow.recommendation;
  if (rec === 'mine_full_power') return Math.max(currentThreads, 8);
  if (rec === 'mine_reduced') return Math.max(4, Math.round(currentThreads * 0.7));
  if (rec === 'hold') return Math.max(2, Math.round(currentThreads * 0.3));
  return Math.max(1, Math.round(currentThreads * 0.2));
}

function qmgeToRefreshRate(qmge: QMGEMiningPayload): number {
  const congestion = qmge.networkIntelligence.congestionLevel;
  if (congestion > 70) return 5;
  if (congestion > 40) return 8;
  return 10;
}

function qmgeToLatency(qmge: QMGEMiningPayload): number {
  const propagation = qmge.networkIntelligence.blockPropagationScore;
  const orphanRisk = qmge.networkIntelligence.orphanRiskFactor;
  if (orphanRisk > 30) return 50;
  if (propagation > 80) return 150;
  return 100;
}

function detectConflicts(
  companionAdj: MinerAdjustments,
  qmgeAdj: MinerAdjustments,
  qmge: QMGEMiningPayload
): ConflictReport {
  const conflicts: ConflictDetail[] = [];

  const params: { key: keyof MinerAdjustments; label: string; threshold: number }[] = [
    { key: 'intensity', label: 'Mining Intensity', threshold: 20 },
    { key: 'nonceRange', label: 'Nonce Range', threshold: 25 },
    { key: 'difficulty', label: 'Difficulty Target', threshold: 15 },
    { key: 'threads', label: 'Thread Count', threshold: 3 },
    { key: 'refreshRate', label: 'Refresh Rate', threshold: 3 },
    { key: 'latencyThreshold', label: 'Latency Threshold', threshold: 30 },
  ];

  for (const param of params) {
    const compVal = companionAdj[param.key];
    const qmgeVal = qmgeAdj[param.key];
    const delta = Math.abs(compVal - qmgeVal);

    if (delta > param.threshold) {
      const isQmgeHighConfidence = qmge.difficultyPrediction.confidence > 70 && qmge.aggregateScore > 60;
      conflicts.push({
        parameter: param.label,
        companionValue: compVal,
        qmgeRecommended: qmgeVal,
        delta,
        direction: qmgeVal > compVal ? 'increase' : 'decrease',
        reason: generateConflictReason(param.key, compVal, qmgeVal, qmge),
        priority: isQmgeHighConfidence ? 'qmge' : 'companion',
      });
    }
  }

  let severity: ConflictReport['severity'] = 'none';
  if (conflicts.length >= 4) severity = 'critical';
  else if (conflicts.length >= 3) severity = 'high';
  else if (conflicts.length >= 2) severity = 'medium';
  else if (conflicts.length >= 1) severity = 'low';

  const qmgePriority = conflicts.filter(c => c.priority === 'qmge').length;
  const compPriority = conflicts.filter(c => c.priority === 'companion').length;

  let resolution: ConflictResolution = 'none';
  if (conflicts.length > 0) {
    if (qmgePriority > compPriority) resolution = 'qmge_override';
    else if (compPriority > qmgePriority) resolution = 'companion_override';
    else resolution = 'weighted_merge';
  }

  return {
    hasConflict: conflicts.length > 0,
    severity,
    conflicts,
    resolution,
    timestamp: Date.now(),
  };
}

function generateConflictReason(
  key: keyof MinerAdjustments,
  compVal: number,
  qmgeVal: number,
  qmge: QMGEMiningPayload
): string {
  switch (key) {
    case 'intensity':
      if (qmgeVal > compVal) return `QMGE detects ${qmge.miningWindow.recommendation === 'mine_full_power' ? 'optimal mining window' : 'favorable conditions'} — recommends higher intensity (${qmgeVal}% vs companion ${compVal}%)`;
      return `QMGE detects ${qmge.networkIntelligence.congestionLevel > 60 ? 'high network congestion' : 'suboptimal conditions'} — recommends lower intensity to reduce waste`;
    case 'nonceRange':
      return `QMGE genome analysis suggests ${qmgeVal > compVal ? 'wider' : 'narrower'} nonce search range based on convergence target ${qmge.hashOptimization.convergenceTarget}`;
    case 'difficulty':
      return `QMGE predicts difficulty ${qmge.difficultyPrediction.direction} (confidence ${Math.round(qmge.difficultyPrediction.confidence)}%) — adjusting target accordingly`;
    case 'threads':
      return `QMGE recommendation "${qmge.miningWindow.recommendation}" suggests ${qmgeVal > compVal ? 'more' : 'fewer'} threads for optimal power/performance ratio`;
    case 'refreshRate':
      return `Network congestion at ${Math.round(qmge.networkIntelligence.congestionLevel)}% — ${qmgeVal < compVal ? 'faster' : 'slower'} refresh needed for block propagation`;
    case 'latencyThreshold':
      return `Orphan risk factor at ${Math.round(qmge.networkIntelligence.orphanRiskFactor)}% — ${qmgeVal < compVal ? 'tighter' : 'looser'} latency threshold recommended`;
    default:
      return 'Signal divergence detected between companion and QMGE data sources';
  }
}

function mergeAdjustments(
  companionAdj: MinerAdjustments,
  qmgeAdj: MinerAdjustments,
  priority: SignalPriority,
  conflictReport: ConflictReport
): MinerAdjustments {
  if (priority === 'qmge') {
    return { ...qmgeAdj };
  }
  if (priority === 'companion') {
    return { ...companionAdj };
  }

  const qmgeWeight = conflictReport.resolution === 'qmge_override' ? 0.7 : 0.5;
  const compWeight = 1 - qmgeWeight;

  return {
    intensity: Math.round(companionAdj.intensity * compWeight + qmgeAdj.intensity * qmgeWeight),
    nonceRange: Math.round(companionAdj.nonceRange * compWeight + qmgeAdj.nonceRange * qmgeWeight),
    difficulty: Math.round(companionAdj.difficulty * compWeight + qmgeAdj.difficulty * qmgeWeight),
    threads: Math.round(companionAdj.threads * compWeight + qmgeAdj.threads * qmgeWeight),
    refreshRate: Math.round(companionAdj.refreshRate * compWeight + qmgeAdj.refreshRate * qmgeWeight),
    latencyThreshold: Math.round(companionAdj.latencyThreshold * compWeight + qmgeAdj.latencyThreshold * qmgeWeight),
  };
}

export function coordinateMiningSignals(
  companionAdj: MinerAdjustments,
  qmge: QMGEMiningPayload | null,
  companionConnected: boolean,
  qmgeConnected: boolean,
  priority: SignalPriority
): CoordinatedCommand {
  if (!qmgeConnected || !qmge) {
    return {
      adjustments: companionAdj,
      source: 'companion',
      conflictReport: { hasConflict: false, severity: 'none', conflicts: [], resolution: 'none', timestamp: Date.now() },
      qmgeApplied: false,
      recommendations: ['QMGE not connected — using companion settings only'],
      overallAction: 'manual',
      confidenceScore: 0,
    };
  }

  const qmgeAdj: MinerAdjustments = {
    intensity: qmgeToIntensity(qmge),
    nonceRange: qmgeToNonceRange(qmge),
    difficulty: qmgeToDifficulty(qmge),
    threads: qmgeToThreads(qmge, companionAdj.threads),
    refreshRate: qmgeToRefreshRate(qmge),
    latencyThreshold: qmgeToLatency(qmge),
  };

  if (!companionConnected) {
    return {
      adjustments: qmgeAdj,
      source: 'qmge',
      conflictReport: { hasConflict: false, severity: 'none', conflicts: [], resolution: 'none', timestamp: Date.now() },
      qmgeApplied: true,
      recommendations: generateRecommendations(qmge),
      overallAction: qmge.miningWindow.recommendation as CoordinatedCommand['overallAction'],
      confidenceScore: qmge.difficultyPrediction.confidence,
    };
  }

  const conflictReport = detectConflicts(companionAdj, qmgeAdj, qmge);
  const mergedAdj = mergeAdjustments(companionAdj, qmgeAdj, priority, conflictReport);

  const recommendations = generateRecommendations(qmge);
  if (conflictReport.hasConflict) {
    recommendations.unshift(
      `${conflictReport.conflicts.length} parameter conflict(s) detected — resolved via ${conflictReport.resolution.replace(/_/g, ' ')}`
    );
  }

  return {
    adjustments: mergedAdj,
    source: priority,
    conflictReport,
    qmgeApplied: true,
    recommendations,
    overallAction: qmge.miningWindow.recommendation as CoordinatedCommand['overallAction'],
    confidenceScore: qmge.difficultyPrediction.confidence,
  };
}

function generateRecommendations(qmge: QMGEMiningPayload): string[] {
  const recs: string[] = [];

  if (qmge.miningWindow.isOptimal) {
    recs.push('Optimal mining window detected — maximize hash power allocation');
  }

  if (qmge.difficultyPrediction.direction === 'decreasing' && qmge.difficultyPrediction.confidence > 60) {
    recs.push(`Difficulty predicted to decrease (${Math.round(qmge.difficultyPrediction.confidence)}% confidence) — favorable for solo mining`);
  } else if (qmge.difficultyPrediction.direction === 'increasing') {
    recs.push('Difficulty trending upward — consider reducing power to conserve resources');
  }

  if (qmge.networkIntelligence.orphanRiskFactor > 25) {
    recs.push(`Elevated orphan risk (${Math.round(qmge.networkIntelligence.orphanRiskFactor)}%) — tighten latency threshold`);
  }

  if (qmge.chainProfitability.hashRateMigrationRisk > 40) {
    recs.push('Hash rate migration risk detected — monitor chain profitability closely');
  }

  if (qmge.networkIntelligence.congestionLevel > 60) {
    recs.push(`Network congestion at ${Math.round(qmge.networkIntelligence.congestionLevel)}% — increase refresh rate for faster block propagation`);
  }

  if (qmge.hashOptimization.convergenceTarget > 0.7) {
    recs.push('High convergence target — nonce range optimization active for focused search');
  }

  return recs;
}

export function getConflictSeverityColor(severity: ConflictReport['severity']): string {
  switch (severity) {
    case 'critical': return '#EF4444';
    case 'high': return '#F97316';
    case 'medium': return '#EAB308';
    case 'low': return '#3B82F6';
    case 'none': return '#22C55E';
  }
}

export function getConflictSeverityLabel(severity: ConflictReport['severity']): string {
  switch (severity) {
    case 'critical': return 'CRITICAL';
    case 'high': return 'HIGH';
    case 'medium': return 'MEDIUM';
    case 'low': return 'LOW';
    case 'none': return 'SYNCED';
  }
}

export function getPriorityLabel(priority: SignalPriority): string {
  switch (priority) {
    case 'qmge': return 'QMGE Priority';
    case 'companion': return 'Companion Priority';
    case 'balanced': return 'Balanced Merge';
  }
}
