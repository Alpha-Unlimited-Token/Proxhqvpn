import type { MinerProtocol, MinerStats } from './hardware-registry';

export interface ProtocolResponse {
  success: boolean;
  data?: unknown;
  error?: string;
}

export interface AxeOSInfo {
  ASICModel: string;
  stratumURL: string;
  fallbackStratumURL: string;
  stratumUser: string;
  hostname: string;
  ssid: string;
  wifiStatus: string;
  sharesAccepted: number;
  sharesRejected: number;
  uptimeSeconds: number;
  ASICCount: number;
  hashRate: number;
  temp: number;
  vrTemp: number;
  fanSpeed: number;
  fanRPM: number;
  version: string;
  boardVersion: string;
  runningPartition: string;
  flipscreen: boolean;
  invertscreen: boolean;
  invertfanpolarity: boolean;
  autofanspeed: boolean;
  fanspeed: number;
  frequency: number;
  coreVoltage: number;
  coreVoltageActual: number;
  power: number;
  freeHeap: number;
  smallestFreeHeap: number;
}

export interface CGMinerSummary {
  STATUS: { STATUS: string; Code: number; Msg: string }[];
  SUMMARY: {
    Elapsed: number;
    'MHS av': number;
    'MHS 5s': number;
    'MHS 1m': number;
    'MHS 5m': number;
    'MHS 15m': number;
    'Found Blocks': number;
    Getworks: number;
    Accepted: number;
    Rejected: number;
    'Hardware Errors': number;
    Utility: number;
    Discarded: number;
    Stale: number;
    'Get Failures': number;
    'Local Work': number;
    'Remote Failures': number;
    'Network Blocks': number;
    'Total MH': number;
    'Work Utility': number;
    'Difficulty Accepted': number;
    'Difficulty Rejected': number;
    'Difficulty Stale': number;
    'Best Share': number;
    'Device Hardware%': number;
    'Device Rejected%': number;
    'Pool Rejected%': number;
    'Pool Stale%': number;
    'Last getwork': number;
  }[];
}

export interface ESPMinerStatus {
  hashrate: number;
  temp: number;
  bestDiff: string;
  shares: number;
  rejected: number;
  uptime: number;
  ssid: string;
  ip: string;
  version: string;
  pool: string;
  user: string;
}

export const PROTOCOL_CONFIGS: Record<MinerProtocol, {
  name: string;
  displayName: string;
  description: string;
  defaultPort: number;
  endpoints: {
    info: string;
    stats: string;
    version: string;
    restart?: string;
    updateFirmware?: string;
  };
  parseStats: (data: unknown) => MinerStats | null;
  parseVersion: (data: unknown) => string | null;
}> = {
  'axeos': {
    name: 'axeos',
    displayName: 'AxeOS',
    description: 'Bitaxe Open Source Mining Firmware',
    defaultPort: 80,
    endpoints: {
      info: '/api/system/info',
      stats: '/api/system/info',
      version: '/api/system/info',
      restart: '/api/system/restart',
      updateFirmware: '/api/system/OTA',
    },
    parseStats: (data: unknown): MinerStats | null => {
      const info = data as AxeOSInfo;
      if (!info || typeof info.hashRate !== 'number') return null;
      return {
        hashrate: info.hashRate,
        hashrateUnit: 'GH/s',
        temperature: info.temp,
        fanSpeed: info.fanRPM,
        uptime: info.uptimeSeconds,
        accepted: info.sharesAccepted,
        rejected: info.sharesRejected,
        efficiency: info.power > 0 ? (info.hashRate * 1000) / info.power : 0,
        power: info.power,
        voltage: info.coreVoltageActual,
        frequency: info.frequency,
      };
    },
    parseVersion: (data: unknown): string | null => {
      const info = data as AxeOSInfo;
      return info?.version || null;
    },
  },
  'cgminer': {
    name: 'cgminer',
    displayName: 'CGMiner API',
    description: 'Standard CGMiner/BFGMiner JSON-RPC API',
    defaultPort: 4028,
    endpoints: {
      info: 'summary',
      stats: 'summary',
      version: 'version',
      restart: 'restart',
    },
    parseStats: (data: unknown): MinerStats | null => {
      const response = data as CGMinerSummary;
      if (!response?.SUMMARY?.[0]) return null;
      const summary = response.SUMMARY[0];
      return {
        hashrate: summary['MHS 5m'] / 1000,
        hashrateUnit: 'GH/s',
        temperature: 0,
        fanSpeed: 0,
        uptime: summary.Elapsed,
        accepted: summary.Accepted,
        rejected: summary.Rejected,
        efficiency: 0,
      };
    },
    parseVersion: (data: unknown): string | null => {
      const response = data as { VERSION?: { CGMiner?: string }[] };
      return response?.VERSION?.[0]?.CGMiner || null;
    },
  },
  'esp-miner': {
    name: 'esp-miner',
    displayName: 'ESP-Miner',
    description: 'ESP32-based Mining Controller Firmware',
    defaultPort: 80,
    endpoints: {
      info: '/status',
      stats: '/status',
      version: '/status',
      restart: '/restart',
    },
    parseStats: (data: unknown): MinerStats | null => {
      const status = data as ESPMinerStatus;
      if (!status || typeof status.hashrate !== 'number') return null;
      return {
        hashrate: status.hashrate,
        hashrateUnit: 'KH/s',
        temperature: status.temp,
        fanSpeed: 0,
        uptime: status.uptime,
        accepted: status.shares,
        rejected: status.rejected,
        efficiency: 0,
      };
    },
    parseVersion: (data: unknown): string | null => {
      const status = data as ESPMinerStatus;
      return status?.version || null;
    },
  },
  'stratum': {
    name: 'stratum',
    displayName: 'Stratum Protocol',
    description: 'Standard Mining Stratum Protocol',
    defaultPort: 3333,
    endpoints: {
      info: 'mining.subscribe',
      stats: 'mining.get_stats',
      version: 'mining.get_version',
    },
    parseStats: (): MinerStats | null => null,
    parseVersion: (): string | null => null,
  },
  'bfgminer': {
    name: 'bfgminer',
    displayName: 'BFGMiner API',
    description: 'BFGMiner JSON-RPC API (CGMiner compatible)',
    defaultPort: 4028,
    endpoints: {
      info: 'summary',
      stats: 'summary',
      version: 'version',
      restart: 'restart',
    },
    parseStats: (data: unknown): MinerStats | null => {
      const response = data as CGMinerSummary;
      if (!response?.SUMMARY?.[0]) return null;
      const summary = response.SUMMARY[0];
      return {
        hashrate: summary['MHS 5m'] / 1000,
        hashrateUnit: 'GH/s',
        temperature: 0,
        fanSpeed: 0,
        uptime: summary.Elapsed,
        accepted: summary.Accepted,
        rejected: summary.Rejected,
        efficiency: 0,
      };
    },
    parseVersion: (data: unknown): string | null => {
      const response = data as { VERSION?: { BFGMiner?: string }[] };
      return response?.VERSION?.[0]?.BFGMiner || null;
    },
  },
  'custom-api': {
    name: 'custom-api',
    displayName: 'Custom API',
    description: 'Custom/Proprietary Mining API',
    defaultPort: 80,
    endpoints: {
      info: '/api/info',
      stats: '/api/stats',
      version: '/api/version',
    },
    parseStats: (): MinerStats | null => null,
    parseVersion: (): string | null => null,
  },
};

export function getProtocolConfig(protocol: MinerProtocol) {
  return PROTOCOL_CONFIGS[protocol];
}

export function getSupportedProtocols(): MinerProtocol[] {
  return Object.keys(PROTOCOL_CONFIGS) as MinerProtocol[];
}
