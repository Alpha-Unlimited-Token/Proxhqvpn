export type ConnectionInterface = 'wifi' | 'ethernet' | 'usb';
export type MinerProtocol = 'axeos' | 'cgminer' | 'esp-miner' | 'stratum' | 'bfgminer' | 'custom-api';
export type HashAlgorithm = 'sha256' | 'scrypt' | 'ethash' | 'randomx' | 'kawpow';

export interface FirmwareInfo {
  version: string;
  releaseDate: string;
  minCompatible: string;
  changelog?: string;
  downloadUrl?: string;
}

export interface HardwareDevice {
  id: string;
  name: string;
  manufacturer: string;
  model: string;
  hashrate: string;
  hashrateValue: number;
  hashrateUnit: 'H/s' | 'KH/s' | 'MH/s' | 'GH/s' | 'TH/s';
  power: number;
  interface: ConnectionInterface;
  protocol: MinerProtocol;
  algorithm: HashAlgorithm;
  defaultPort: number;
  apiEndpoint: string;
  firmware: FirmwareInfo;
  chips?: string;
  chipCount?: number;
  features: string[];
  autoDiscovery: boolean;
  mdnsService?: string;
  vendorId?: string;
  productId?: string;
}

export interface ProtocolHandler {
  name: MinerProtocol;
  displayName: string;
  description: string;
  defaultPort: number;
  supportedCommands: string[];
  connect: (ip: string, port: number) => Promise<boolean>;
  getStats: (ip: string, port: number) => Promise<MinerStats | null>;
  getVersion: (ip: string, port: number) => Promise<string | null>;
}

export interface MinerStats {
  hashrate: number;
  hashrateUnit: string;
  temperature: number;
  fanSpeed: number;
  uptime: number;
  accepted: number;
  rejected: number;
  efficiency: number;
  power?: number;
  voltage?: number;
  frequency?: number;
}

export interface DiscoveredDevice {
  id: string;
  device: HardwareDevice;
  ip?: string;
  port?: number;
  usbPath?: string;
  status: 'discovered' | 'connecting' | 'connected' | 'error';
  lastSeen: Date;
  stats?: MinerStats;
  firmwareVersion?: string;
  needsUpdate?: boolean;
}

export const WIFI_ETHERNET_HARDWARE: HardwareDevice[] = [
  // ==========================================
  // NerdQaxe++ Series (4× BM1370 ASIC chips)
  // ==========================================
  {
    id: 'nerdqaxe-plus-plus',
    name: 'NerdQaxe++ 4.8T',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdQaxe++ 4.8TH/s',
    hashrate: '4.8 TH/s',
    hashrateValue: 4.8,
    hashrateUnit: 'TH/s',
    power: 68,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 4,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'auto-tuning', 'esp32-s3', 'color-lcd'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  {
    id: 'nerdqaxe-plus-plus-hydro',
    name: 'NerdQaxe++ Hydro 4.8T',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdQaxe++ Hydro 4.8TH/s',
    hashrate: '4.8 TH/s',
    hashrateValue: 4.8,
    hashrateUnit: 'TH/s',
    power: 75,
    interface: 'ethernet',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 4,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'auto-tuning', 'water-cooling', 'silent'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  {
    id: 'nerdqaxe-plus-plus-rev61',
    name: 'NerdQaxe++ Rev6.1 6T',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdQaxe++ Rev6.1 6TH/s',
    hashrate: '6 TH/s',
    hashrateValue: 6,
    hashrateUnit: 'TH/s',
    power: 100,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 4,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'xt30-power', 'thickened-copper', 'esp32-s3', 'color-lcd', 'overclockable'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  {
    id: 'nerdqaxe-plus-plus-hydro-rev61',
    name: 'NerdQaxe++ Hydro Rev6.1 6T',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdQaxe++ Hydro Rev6.1 6TH/s',
    hashrate: '6 TH/s',
    hashrateValue: 6,
    hashrateUnit: 'TH/s',
    power: 100,
    interface: 'ethernet',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 4,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'water-cooling', 'xt30-power', 'thickened-copper', 'silent', 'overclockable'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  // ==========================================
  // NerdOCTAxe (8× BM1370 ASIC chips - Highest Power)
  // ==========================================
  {
    id: 'nerdoctaxe',
    name: 'NerdOCTAxe 9.6T',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdOCTAxe 9.6TH/s',
    hashrate: '9.6 TH/s',
    hashrateValue: 9.6,
    hashrateUnit: 'TH/s',
    power: 160,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 8,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'dual-fan', 'color-lcd', 'high-power', 'am4-mounting'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  // ==========================================
  // Bitaxe GT 800 (2× BM1370 Gamma Turbo)
  // ==========================================
  {
    id: 'bitaxe-gt-800',
    name: 'Bitaxe GT 800',
    manufacturer: 'Bitaxe (Open Source)',
    model: 'Bitaxe GT 800 2.4TH/s',
    hashrate: '2.4 TH/s',
    hashrateValue: 2.4,
    hashrateUnit: 'TH/s',
    power: 40,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 2,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'auto-tuning', 'oled-display', 'noctua-fan', 'overclockable'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  // ==========================================
  // Bitaxe Gamma Series (1× BM1370)
  // ==========================================
  {
    id: 'bitaxe-gamma-601',
    name: 'Bitaxe Gamma 601',
    manufacturer: 'Bitaxe (Open Source)',
    model: 'Gamma 601 1.2TH/s',
    hashrate: '1.2 TH/s',
    hashrateValue: 1.2,
    hashrateUnit: 'TH/s',
    power: 15,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1370',
    chipCount: 1,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'low-power', 'oled-display', 'ultra-compact', 'silent'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  // ==========================================
  // Bitaxe Supra Hex Series (6× BM1368)
  // ==========================================
  {
    id: 'bitaxe-supra-hex',
    name: 'Bitaxe Supra Hex 4.2T',
    manufacturer: 'Bitaxe (Open Source)',
    model: 'Supra Hex 4.2TH/s',
    hashrate: '4.2 TH/s',
    hashrateValue: 4.2,
    hashrateUnit: 'TH/s',
    power: 90,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.5.0',
      releaseDate: '2026-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1368',
    chipCount: 6,
    features: ['wifi-config', 'web-ui', 'stratum-v2', 'temperature-monitoring', 'hex-design', 'led-display', 'high-efficiency'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  // ==========================================
  // Magic Miner Series (Compact Desktop Miners)
  // ==========================================
  {
    id: 'magic-miner-bg01',
    name: 'Magic Miner BG01',
    manufacturer: 'Magic Miner',
    model: 'BG01 4.5TH/s',
    hashrate: '4.5 TH/s',
    hashrateValue: 4.5,
    hashrateUnit: 'TH/s',
    power: 120,
    interface: 'ethernet',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '1.0.0',
      releaseDate: '2026-01-01',
      minCompatible: '1.0.0',
    },
    chips: 'BM1368',
    chipCount: 4,
    features: ['wifi-config', 'web-ui', 'ethernet', 'atx-psu-compatible', 'compact', 'silent', 'dual-fan'],
    autoDiscovery: true,
    mdnsService: '_magicminer._tcp',
  },
  {
    id: 'magic-miner-bg02',
    name: 'Magic Miner BG02',
    manufacturer: 'Magic Miner',
    model: 'BG02 7TH/s',
    hashrate: '7 TH/s',
    hashrateValue: 7,
    hashrateUnit: 'TH/s',
    power: 150,
    interface: 'ethernet',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '1.0.0',
      releaseDate: '2026-01-01',
      minCompatible: '1.0.0',
    },
    chips: 'BM1368',
    chipCount: 6,
    features: ['wifi-config', 'web-ui', 'ethernet', 'atx-psu-compatible', 'pcie-form-factor', 'gpu-style', 'silent', 'dual-fan'],
    autoDiscovery: true,
    mdnsService: '_magicminer._tcp',
  },
  // ==========================================
  // NerdMiner (ESP32 Educational Miners)
  // ==========================================
  {
    id: 'nm-miner-v28',
    name: 'NM Miner V2.8 1010k',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NM Miner V2.8 1010kH/s',
    hashrate: '1010 KH/s',
    hashrateValue: 1010,
    hashrateUnit: 'KH/s',
    power: 2,
    interface: 'wifi',
    protocol: 'esp-miner',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/status',
    firmware: {
      version: '2.8.0',
      releaseDate: '2026-01-01',
      minCompatible: '2.0.0',
    },
    chips: 'ESP32-WROOM-32',
    chipCount: 1,
    features: ['wifi-direct', 'touchscreen', 'color-lcd-2.8', 'lottery-mode', 'educational', 'low-power', 'desktop-clock'],
    autoDiscovery: true,
    mdnsService: '_nerdminer._tcp',
  },
  {
    id: 'bitaxe-ultra',
    name: 'Bitaxe Ultra',
    manufacturer: 'Bitaxe (Open Source)',
    model: 'Ultra 500G',
    hashrate: '500 GH/s',
    hashrateValue: 500,
    hashrateUnit: 'GH/s',
    power: 12,
    interface: 'wifi',
    protocol: 'axeos',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/system/info',
    firmware: {
      version: '2.4.0',
      releaseDate: '2025-01-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1366',
    chipCount: 1,
    features: ['wifi-direct', 'web-ui', 'stratum-v2', 'ultra-compact'],
    autoDiscovery: true,
    mdnsService: '_axeos._tcp',
  },
  {
    id: 'nerdminer-v2',
    name: 'NerdMiner V2',
    manufacturer: 'NerdMiner (Open Source)',
    model: 'NerdMiner V2 78kH/s',
    hashrate: '78 KH/s',
    hashrateValue: 78,
    hashrateUnit: 'KH/s',
    power: 1,
    interface: 'wifi',
    protocol: 'esp-miner',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/status',
    firmware: {
      version: '2.0.0',
      releaseDate: '2025-12-01',
      minCompatible: '1.5.0',
    },
    chips: 'ESP32',
    chipCount: 1,
    features: ['wifi-direct', 'oled-display', 'lottery-mode', 'educational', 'low-power'],
    autoDiscovery: true,
    mdnsService: '_nerdminer._tcp',
  },
  {
    id: 'lucky-miner-lv06',
    name: 'Lucky Miner LV06',
    manufacturer: 'Lucky Miner',
    model: 'LV06 500G',
    hashrate: '500 GH/s',
    hashrateValue: 500,
    hashrateUnit: 'GH/s',
    power: 12,
    interface: 'wifi',
    protocol: 'esp-miner',
    algorithm: 'sha256',
    defaultPort: 80,
    apiEndpoint: '/api/status',
    firmware: {
      version: '1.2.0',
      releaseDate: '2024-11-15',
      minCompatible: '1.0.0',
    },
    chips: 'BM1366',
    chipCount: 1,
    features: ['wifi-config', 'web-ui', 'solo-mode', 'compact'],
    autoDiscovery: true,
    mdnsService: '_luckyminer._tcp',
  },
  {
    id: 'apollo-btc',
    name: 'Apollo BTC',
    manufacturer: 'FutureBit',
    model: 'Apollo BTC',
    hashrate: '3 TH/s',
    hashrateValue: 3,
    hashrateUnit: 'TH/s',
    power: 200,
    interface: 'ethernet',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: '/api',
    firmware: {
      version: '3.1.2',
      releaseDate: '2024-10-01',
      minCompatible: '3.0.0',
    },
    chips: 'BM1387',
    chipCount: 3,
    features: ['full-node', 'web-ui', 'cgminer-api', 'dual-mode'],
    autoDiscovery: true,
    mdnsService: '_cgminer._tcp',
  },
  {
    id: 'compac-f-ethernet',
    name: 'Compac F (Ethernet)',
    manufacturer: 'GekkoScience',
    model: 'Compac F 300G',
    hashrate: '300 GH/s',
    hashrateValue: 300,
    hashrateUnit: 'GH/s',
    power: 5,
    interface: 'ethernet',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: '/api',
    firmware: {
      version: '2.0.1',
      releaseDate: '2024-09-01',
      minCompatible: '1.8.0',
    },
    chips: 'BM1397',
    chipCount: 1,
    features: ['cgminer-api', 'frequency-tuning', 'voltage-control'],
    autoDiscovery: true,
    mdnsService: '_cgminer._tcp',
  },
  {
    id: 'gekkoscience-r909',
    name: 'GekkoScience R909',
    manufacturer: 'GekkoScience',
    model: 'R909 5.5T',
    hashrate: '5.5 TH/s',
    hashrateValue: 5.5,
    hashrateUnit: 'TH/s',
    power: 250,
    interface: 'ethernet',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: '/api',
    firmware: {
      version: '1.5.0',
      releaseDate: '2025-01-01',
      minCompatible: '1.0.0',
    },
    chips: 'BM1368',
    chipCount: 4,
    features: ['cgminer-api', 'high-efficiency', 'professional-grade'],
    autoDiscovery: true,
    mdnsService: '_cgminer._tcp',
  },
];

export const USB_HARDWARE: HardwareDevice[] = [
  {
    id: 'gekkoscience-newpac',
    name: 'GekkoScience NewPac',
    manufacturer: 'GekkoScience',
    model: 'NewPac 130G',
    hashrate: '130 GH/s',
    hashrateValue: 130,
    hashrateUnit: 'GH/s',
    power: 5,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '2.1.0',
      releaseDate: '2024-08-15',
      minCompatible: '2.0.0',
    },
    chips: 'BM1387',
    chipCount: 2,
    features: ['usb-hub-compatible', 'frequency-tuning', 'low-power'],
    autoDiscovery: true,
    vendorId: '0x067b',
    productId: '0x2303',
  },
  {
    id: 'gekkoscience-compac-f-usb',
    name: 'GekkoScience Compac F',
    manufacturer: 'GekkoScience',
    model: 'Compac F 300G USB',
    hashrate: '300 GH/s',
    hashrateValue: 300,
    hashrateUnit: 'GH/s',
    power: 5,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '2.0.1',
      releaseDate: '2024-09-01',
      minCompatible: '1.8.0',
    },
    chips: 'BM1397',
    chipCount: 1,
    features: ['usb-3.0', 'high-efficiency', 'compact'],
    autoDiscovery: true,
    vendorId: '0x10c4',
    productId: '0xea60',
  },
  {
    id: 'futurebit-moonlander-2',
    name: 'FutureBit Moonlander 2',
    manufacturer: 'FutureBit',
    model: 'Moonlander 2',
    hashrate: '5 MH/s',
    hashrateValue: 5,
    hashrateUnit: 'MH/s',
    power: 2,
    interface: 'usb',
    protocol: 'bfgminer',
    algorithm: 'scrypt',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.3.0',
      releaseDate: '2024-06-01',
      minCompatible: '1.0.0',
    },
    chips: 'LTC Scrypt',
    chipCount: 1,
    features: ['scrypt-mining', 'litecoin', 'dogecoin'],
    autoDiscovery: true,
    vendorId: '0x0483',
    productId: '0x5740',
  },
  {
    id: 'bitmain-u3',
    name: 'Bitmain U3',
    manufacturer: 'Bitmain',
    model: 'AntMiner U3',
    hashrate: '63 GH/s',
    hashrateValue: 63,
    hashrateUnit: 'GH/s',
    power: 63,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.0.5',
      releaseDate: '2015-03-01',
      minCompatible: '1.0.0',
    },
    chips: 'BM1382',
    chipCount: 1,
    features: ['classic-miner', 'reliable'],
    autoDiscovery: true,
    vendorId: '0x1fc9',
    productId: '0x0083',
  },
  {
    id: 'antminer-u1',
    name: 'AntMiner U1',
    manufacturer: 'Bitmain',
    model: 'AntMiner U1',
    hashrate: '1.6 GH/s',
    hashrateValue: 1.6,
    hashrateUnit: 'GH/s',
    power: 2,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.0.0',
      releaseDate: '2014-01-01',
      minCompatible: '1.0.0',
    },
    chips: 'BM1380',
    chipCount: 1,
    features: ['entry-level', 'educational', 'low-power'],
    autoDiscovery: true,
    vendorId: '0x10c4',
    productId: '0xea60',
  },
  {
    id: 'block-erupter-usb',
    name: 'Block Erupter USB',
    manufacturer: 'ASICMiner',
    model: 'Block Erupter',
    hashrate: '336 MH/s',
    hashrateValue: 336,
    hashrateUnit: 'MH/s',
    power: 2.5,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.0.0',
      releaseDate: '2013-06-01',
      minCompatible: '1.0.0',
    },
    chips: 'BE100',
    chipCount: 1,
    features: ['classic', 'collector-item', 'silent'],
    autoDiscovery: true,
    vendorId: '0x10c4',
    productId: '0xea60',
  },
  {
    id: 'red-blue-fury',
    name: 'Red/Blue Fury',
    manufacturer: 'HashFast',
    model: 'Fury 2.5G',
    hashrate: '2.5 GH/s',
    hashrateValue: 2.5,
    hashrateUnit: 'GH/s',
    power: 2.5,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.2.0',
      releaseDate: '2014-06-01',
      minCompatible: '1.0.0',
    },
    chips: 'BF1',
    chipCount: 1,
    features: ['compact', 'silent', 'reliable'],
    autoDiscovery: true,
    vendorId: '0x0483',
    productId: '0x5740',
  },
  {
    id: 'bi-fury',
    name: 'Bi•Fury',
    manufacturer: 'HashFast',
    model: 'Bi-Fury 5G',
    hashrate: '5 GH/s',
    hashrateValue: 5,
    hashrateUnit: 'GH/s',
    power: 5,
    interface: 'usb',
    protocol: 'cgminer',
    algorithm: 'sha256',
    defaultPort: 4028,
    apiEndpoint: 'usb',
    firmware: {
      version: '1.2.0',
      releaseDate: '2014-08-01',
      minCompatible: '1.0.0',
    },
    chips: 'BF1',
    chipCount: 2,
    features: ['dual-chip', 'compact', 'efficient'],
    autoDiscovery: true,
    vendorId: '0x0483',
    productId: '0x5740',
  },
];

export const ALL_HARDWARE: HardwareDevice[] = [...WIFI_ETHERNET_HARDWARE, ...USB_HARDWARE];

export function getHardwareById(id: string): HardwareDevice | undefined {
  return ALL_HARDWARE.find(hw => hw.id === id);
}

export function getHardwareByInterface(iface: ConnectionInterface): HardwareDevice[] {
  if (iface === 'usb') {
    return USB_HARDWARE;
  }
  return WIFI_ETHERNET_HARDWARE;
}

export function getHardwareByProtocol(protocol: MinerProtocol): HardwareDevice[] {
  return ALL_HARDWARE.filter(hw => hw.protocol === protocol);
}

export function getHardwareByAlgorithm(algo: HashAlgorithm): HardwareDevice[] {
  return ALL_HARDWARE.filter(hw => hw.algorithm === algo);
}
