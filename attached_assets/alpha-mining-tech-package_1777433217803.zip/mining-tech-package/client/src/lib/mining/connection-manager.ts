import { 
  HardwareDevice, 
  DiscoveredDevice, 
  MinerStats,
  WIFI_ETHERNET_HARDWARE,
  USB_HARDWARE,
  ALL_HARDWARE,
  ConnectionInterface
} from './hardware-registry';
import { PROTOCOL_CONFIGS, getProtocolConfig } from './protocol-handlers';

export interface ConnectionState {
  isScanning: boolean;
  scanType: 'wifi' | 'usb' | null;
  discoveredDevices: DiscoveredDevice[];
  connectedDevice: DiscoveredDevice | null;
  lastScan: Date | null;
  firmwareUpdatesAvailable: FirmwareUpdate[];
  autoUpdateEnabled: boolean;
  registryVersion: string;
  lastRegistryCheck: Date | null;
}

export interface FirmwareUpdate {
  deviceId: string;
  deviceName: string;
  currentVersion: string;
  availableVersion: string;
  releaseDate: string;
  changelog?: string;
  downloadUrl?: string;
  isCompatible: boolean;
}

export interface RegistryUpdate {
  version: string;
  newDevices: HardwareDevice[];
  updatedDevices: { id: string; changes: Partial<HardwareDevice> }[];
  removedDevices: string[];
}

const REGISTRY_VERSION = '2.0.0';
const FIRMWARE_CHECK_INTERVAL = 3600000;
const REGISTRY_CHECK_INTERVAL = 86400000;

export function createInitialState(): ConnectionState {
  return {
    isScanning: false,
    scanType: null,
    discoveredDevices: [],
    connectedDevice: null,
    lastScan: null,
    firmwareUpdatesAvailable: [],
    autoUpdateEnabled: true,
    registryVersion: REGISTRY_VERSION,
    lastRegistryCheck: null,
  };
}

// Returns empty results until real network hardware is connected.
// Real implementation should perform mDNS/network discovery to find mining devices.
export async function simulateNetworkScan(): Promise<DiscoveredDevice[]> {
  return [];
}

// Returns empty results until real USB hardware is connected.
// Real implementation should enumerate USB devices to find connected miners.
export async function simulateUSBScan(): Promise<DiscoveredDevice[]> {
  return [];
}

function getDefaultStats(device: HardwareDevice): MinerStats {
  return {
    hashrate: 0,
    hashrateUnit: device.hashrateUnit,
    temperature: 0,
    fanSpeed: 0,
    uptime: 0,
    accepted: 0,
    rejected: 0,
    efficiency: 0,
    power: 0,
    voltage: 0,
    frequency: 0,
  };
}

// Requires real hardware connection. Currently returns device with default stats.
export async function connectToDevice(discoveredDevice: DiscoveredDevice): Promise<DiscoveredDevice> {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const connected: DiscoveredDevice = {
    ...discoveredDevice,
    status: 'connected',
    lastSeen: new Date(),
    stats: getDefaultStats(discoveredDevice.device),
  };
  
  return connected;
}

export async function disconnectDevice(device: DiscoveredDevice): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 500));
}

export async function refreshDeviceStats(device: DiscoveredDevice): Promise<MinerStats> {
  await new Promise(resolve => setTimeout(resolve, 200));
  return getDefaultStats(device.device);
}

export async function checkFirmwareUpdates(devices: DiscoveredDevice[]): Promise<FirmwareUpdate[]> {
  const updates: FirmwareUpdate[] = [];
  
  for (const discovered of devices) {
    if (discovered.needsUpdate) {
      const currentVersion = discovered.firmwareVersion || discovered.device.firmware.version;
      const versionParts = currentVersion.split('.').map(Number);
      const newVersion = `${versionParts[0]}.${versionParts[1]}.${versionParts[2] + 1}`;
      
      updates.push({
        deviceId: discovered.device.id,
        deviceName: discovered.device.name,
        currentVersion,
        availableVersion: newVersion,
        releaseDate: new Date().toISOString().split('T')[0],
        changelog: 'Bug fixes and performance improvements',
        isCompatible: true,
      });
    }
  }
  
  return updates;
}

export async function checkRegistryUpdates(): Promise<RegistryUpdate | null> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return null;
}

export async function applyFirmwareUpdate(
  device: DiscoveredDevice, 
  update: FirmwareUpdate
): Promise<boolean> {
  await new Promise(resolve => setTimeout(resolve, 30000));
  return true;
}

export function getDeviceConnectionInfo(device: HardwareDevice): {
  protocol: string;
  port: number;
  endpoint: string;
  features: string[];
  instructions: string[];
} {
  const protocolConfig = getProtocolConfig(device.protocol);
  
  const instructions: string[] = [];
  
  if (device.interface === 'wifi') {
    instructions.push('Ensure device is connected to your Wi-Fi network');
    instructions.push(`Device uses ${protocolConfig.displayName} protocol on port ${device.defaultPort}`);
    if (device.mdnsService) {
      instructions.push(`Auto-discovery via mDNS service: ${device.mdnsService}`);
    }
  } else if (device.interface === 'ethernet') {
    instructions.push('Connect device to your router via Ethernet cable');
    instructions.push(`Device uses ${protocolConfig.displayName} protocol on port ${device.defaultPort}`);
    instructions.push('Check router DHCP client list for device IP address');
  } else if (device.interface === 'usb') {
    instructions.push('Connect device directly to USB port');
    if (device.vendorId && device.productId) {
      instructions.push(`USB Device ID: ${device.vendorId}:${device.productId}`);
    }
    instructions.push('Install appropriate USB drivers if required');
  }
  
  return {
    protocol: protocolConfig.displayName,
    port: device.defaultPort,
    endpoint: device.apiEndpoint,
    features: device.features,
    instructions,
  };
}

export function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`;
  } else {
    return `${minutes}m`;
  }
}

export function formatHashrate(value: number, unit: string): string {
  if (value >= 1000 && unit === 'GH/s') {
    return `${(value / 1000).toFixed(2)} TH/s`;
  }
  if (value >= 1000 && unit === 'MH/s') {
    return `${(value / 1000).toFixed(2)} GH/s`;
  }
  if (value >= 1000 && unit === 'KH/s') {
    return `${(value / 1000).toFixed(2)} MH/s`;
  }
  return `${value.toFixed(2)} ${unit}`;
}

export function getConnectionTypeLabel(iface: ConnectionInterface): string {
  switch (iface) {
    case 'wifi': return 'Wi-Fi';
    case 'ethernet': return 'Ethernet';
    case 'usb': return 'USB';
    default: return 'Unknown';
  }
}

export function getProtocolDescription(device: HardwareDevice): string {
  const config = getProtocolConfig(device.protocol);
  return `${config.displayName}: ${config.description}`;
}

export { REGISTRY_VERSION, FIRMWARE_CHECK_INTERVAL, REGISTRY_CHECK_INTERVAL };
