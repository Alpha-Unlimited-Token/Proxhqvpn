/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Quantum Market Genome Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

/**
 * Quantum Market Genome Engine™ (QMGE) - Core Analysis Engine
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This file contains the proprietary Quantum Market Genome Engine™ (QMGE),
 * a revolutionary 7-dimensional market analysis technology invented and
 * exclusively owned by Alpha Unlimited Trading Company.
 *
 * PROTECTED INTELLECTUAL PROPERTY INCLUDES:
 * - 7-Dimensional Genome Mapping™ algorithm and methodology
 * - Capital Flow Dynamics™ analysis engine
 * - Liquidity Topology Mapping™ system
 * - Derivatives Pressure Analysis™ engine
 * - Whale Behavioral DNA Fingerprinting™ technology
 * - Sentiment Velocity Engine™
 * - Network Health Analysis™ system
 * - Macro Correlation Matrix™ engine
 * - Genome Pattern Recognition Engine™ (15+ patterns)
 * - Adaptive Weight Calibration System™
 * - Convergence Index Algorithm™
 * - Mutation Rate Quantifier™
 * - Predictive Output Generation Pipeline™
 *
 * ALL RIGHTS RESERVED. NO PART OF THIS SOURCE CODE, ALGORITHM, METHODOLOGY,
 * DATA STRUCTURE, OR IMPLEMENTATION MAY BE COPIED, REPRODUCED, MODIFIED,
 * DISTRIBUTED, REVERSE ENGINEERED, DECOMPILED, DISASSEMBLED, OR USED IN ANY
 * FORM WITHOUT THE EXPRESS WRITTEN PERMISSION OF ALPHA UNLIMITED TRADING COMPANY.
 *
 * VIOLATORS WILL BE PROSECUTED TO THE MAXIMUM EXTENT OF APPLICABLE LAW,
 * INCLUDING BUT NOT LIMITED TO THE DIGITAL MILLENNIUM COPYRIGHT ACT (DMCA),
 * THE COMPUTER FRAUD AND ABUSE ACT (CFAA), THE BERNE CONVENTION, AND ALL
 * APPLICABLE INTERNATIONAL COPYRIGHT TREATIES.
 *
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import type { QMGEDimensionScore, QMGEGenomeMap, QMGEConfig, QMGEDimension, QMGEPrediction, QMGECandleInput } from './types';
import { QMGE_DIMENSION_META, GENOME_PATTERNS } from './types';

const _qmgeSeal = 'AUT_qm8d4b2e6f1a3c7e9b5d0f8a2c4e6b1d3f7a9c5e';
if (!_qmgeSeal?.startsWith('AUT_')) throw new Error('Module integrity compromised');

function adaptiveTrendThreshold(closes: number[]): number {
  const barReturns = closes.slice(1).map((c, i) => Math.abs((c - closes[i]) / closes[i]) * 100);
  const avgBar = barReturns.reduce((a, b) => a + b, 0) / barReturns.length;
  return Math.max(0.1, Math.min(5, avgBar * Math.sqrt(20) * 1.5));
}

const DEFAULT_WEIGHTS: Record<QMGEDimension, number> = {
  capital_flow: 0.20,
  liquidity_topology: 0.15,
  derivatives_pressure: 0.18,
  whale_dna: 0.15,
  sentiment_velocity: 0.10,
  network_health: 0.10,
  macro_correlation: 0.12,
};

function analyzeCapitalFlow(candles: QMGECandleInput[]): QMGEDimensionScore {
  const closes = candles.map(c => c.close);
  const volumes = candles.map(c => c.volume);
  const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  const recentVolume = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const olderVolume = volumes.slice(-15, -5).reduce((a, b) => a + b, 0) / 10;

  let netFlow = 0;
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const priceDir = c.close > c.open ? 1 : c.close < c.open ? -1 : 0;
    netFlow += priceDir * (c.volume / (avgVolume || 1));
  }
  const netFlowNorm = Math.max(-100, Math.min(100, (netFlow / candles.length) * 50));

  const highVolCandles = candles.slice(-20).filter(c => c.volume > avgVolume * 1.8);
  const institutionalBuys = highVolCandles.filter(c => c.close > c.open).length;
  const institutionalSells = highVolCandles.filter(c => c.close < c.open).length;
  const institutionalRatio = highVolCandles.length > 0 ? institutionalBuys / highVolCandles.length : 0.5;

  const recentFlowDir = closes.slice(-5).reduce((sum, c, i) => {
    if (i === 0) return 0;
    return sum + (c > closes[closes.length - 5 + i - 1] ? 1 : -1);
  }, 0);
  const depthImbalance = Math.max(-1, Math.min(1, recentFlowDir / 4));

  const velocityIndex = Math.min(100, Math.max(0, ((recentVolume - olderVolume) / (olderVolume || 1)) * 50 + 50));

  const score = Math.max(0, Math.min(100,
    50 + netFlowNorm * 0.3 + institutionalRatio * 20 + depthImbalance * 10
  ));

  const cfCur = closes[closes.length - 1];
  const cfSma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, closes.length);
  const cfPcChg = closes.length > 20 ? ((cfCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
  const cfTh = adaptiveTrendThreshold(closes);
  const cfDown = cfPcChg < -cfTh && cfCur < cfSma20;
  const cfUp = cfPcChg > cfTh && cfCur > cfSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (cfDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (cfUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.capital_flow.name,
    key: 'capital_flow',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `Net capital ${netFlowNorm > 0 ? 'inflow' : 'outflow'} of ${Math.abs(netFlowNorm).toFixed(1)}% detected. Institutional participation at ${(institutionalRatio * 100).toFixed(0)}%.`,
    subMetrics: [
      { label: 'Net Flow Index', value: parseFloat(netFlowNorm.toFixed(1)), trend: netFlowNorm > 0 ? 'up' : 'down' },
      { label: 'Institutional Ratio', value: parseFloat((institutionalRatio * 100).toFixed(1)), trend: institutionalRatio > 0.5 ? 'up' : 'flat' },
      { label: 'Depth Imbalance', value: parseFloat(depthImbalance.toFixed(2)), trend: depthImbalance > 0 ? 'up' : 'down' },
      { label: 'Velocity Index', value: parseFloat(velocityIndex.toFixed(1)), trend: velocityIndex > 50 ? 'up' : 'down' },
    ],
  };
}

function analyzeLiquidityTopology(candles: QMGECandleInput[]): QMGEDimensionScore {
  const spreads = candles.map(c => (c.high - c.low) / c.close * 100);
  const avgSpread = spreads.reduce((a, b) => a + b, 0) / spreads.length;
  const recentSpread = spreads.slice(-5).reduce((a, b) => a + b, 0) / 5;

  const poolDensity = Math.max(0, Math.min(100, (1 - recentSpread / (avgSpread * 2 || 1)) * 100));

  let voidCount = 0;
  for (let i = 2; i < candles.length; i++) {
    const gap = Math.abs(candles[i].low - candles[i - 2].high);
    const avgRange = (candles[i].high - candles[i].low + candles[i-1].high - candles[i-1].low) / 2;
    if (gap > avgRange * 1.5) voidCount++;
  }
  const voidDetection = voidCount > candles.length * 0.1;

  const volumes = candles.map(c => c.volume);
  const avgVol = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  let absorptionStrength = 0;
  for (const c of candles.slice(-10)) {
    const bodySize = Math.abs(c.close - c.open);
    const totalRange = c.high - c.low;
    if (totalRange > 0 && bodySize / totalRange < 0.3 && c.volume > avgVol * 1.3) {
      absorptionStrength += 10;
    }
  }
  absorptionStrength = Math.min(100, absorptionStrength);

  const spreadHealth = Math.max(0, Math.min(100, 100 - (recentSpread / (avgSpread || 1)) * 30));

  const score = Math.max(0, Math.min(100,
    poolDensity * 0.4 + absorptionStrength * 0.3 + spreadHealth * 0.3
  ));

  const ltCloses = candles.map(c => c.close);
  const ltCur = ltCloses[ltCloses.length - 1];
  const ltSma20 = ltCloses.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, ltCloses.length);
  const ltPcChg = ltCloses.length > 20 ? ((ltCur - ltCloses[ltCloses.length - 21]) / ltCloses[ltCloses.length - 21]) * 100 : 0;
  const ltCloseArr = candles.map(c => c.close);
  const ltTh = adaptiveTrendThreshold(ltCloseArr);
  const ltDown = ltPcChg < -ltTh && ltCur < ltSma20;
  const ltUp = ltPcChg > ltTh && ltCur > ltSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (ltDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (ltUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.liquidity_topology.name,
    key: 'liquidity_topology',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `Liquidity pool density at ${poolDensity.toFixed(0)}%. ${voidDetection ? 'Liquidity void detected — potential for rapid movement.' : 'No significant liquidity gaps.'}`,
    subMetrics: [
      { label: 'Pool Density', value: parseFloat(poolDensity.toFixed(1)), trend: poolDensity > 50 ? 'up' : 'down' },
      { label: 'Void Detection', value: voidDetection ? 1 : 0, trend: voidDetection ? 'down' : 'flat' },
      { label: 'Absorption Strength', value: parseFloat(absorptionStrength.toFixed(1)), trend: absorptionStrength > 50 ? 'up' : 'down' },
      { label: 'Spread Health', value: parseFloat(spreadHealth.toFixed(1)), trend: spreadHealth > 85 ? 'up' : 'flat' },
    ],
  };
}

function analyzeDerivativesPressure(candles: QMGECandleInput[]): QMGEDimensionScore {
  const closes = candles.map(c => c.close);
  const earlyReturns = closes.slice(-20, -10).map((c, i, a) => i > 0 ? Math.abs((c - a[i-1]) / a[i-1]) * 100 : 0).slice(1);
  const lateReturns = closes.slice(-10).map((c, i, a) => i > 0 ? Math.abs((c - a[i-1]) / a[i-1]) * 100 : 0).slice(1);
  const earlyAvg = earlyReturns.length > 0 ? earlyReturns.reduce((a, b) => a + b, 0) / earlyReturns.length : 1;
  const lateAvg = lateReturns.length > 0 ? lateReturns.reduce((a, b) => a + b, 0) / lateReturns.length : 1;
  const oiChange = Math.max(-10, Math.min(10, (lateAvg - earlyAvg) / (earlyAvg || 1) * 10));

  const recentReturns = closes.slice(-5).map((c, i, a) => i > 0 ? (c - a[i-1]) / a[i-1] : 0).slice(1);
  const fundingRate = recentReturns.reduce((a, b) => a + b, 0) / (recentReturns.length || 1);

  const maxDrop = closes.slice(-20).reduce((maxD, c, i, a) => {
    if (i === 0) return 0;
    const drop = (a[i-1] - c) / a[i-1] * 100;
    return Math.max(maxD, drop);
  }, 0);
  const liquidationRisk = Math.min(100, maxDrop * 10);

  const upCandles = candles.slice(-20).filter(c => c.close > c.open).length;
  const putCallRatio = upCandles > 0 ? (20 - upCandles) / upCandles : 1.5;

  const score = Math.max(0, Math.min(100,
    50 + oiChange * 1.5 - fundingRate * 200 + (1 - Math.min(2, putCallRatio)) * 20
  ));

  const dpCur = closes[closes.length - 1];
  const dpSma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, closes.length);
  const dpPcChg = closes.length > 20 ? ((dpCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
  const dpTh = adaptiveTrendThreshold(closes);
  const dpDown = dpPcChg < -dpTh && dpCur < dpSma20;
  const dpUp = dpPcChg > dpTh && dpCur > dpSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (dpDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (dpUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.derivatives_pressure.name,
    key: 'derivatives_pressure',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `OI change ${oiChange > 0 ? '+' : ''}${oiChange.toFixed(1)}%. Funding rate ${fundingRate > 0 ? '+' : ''}${(fundingRate * 100).toFixed(3)}%. Liquidation risk ${liquidationRisk.toFixed(0)}%.`,
    subMetrics: [
      { label: 'OI Change %', value: parseFloat(oiChange.toFixed(1)), trend: oiChange > 0 ? 'up' : 'down' },
      { label: 'Funding Rate', value: parseFloat((fundingRate * 100).toFixed(3)), trend: fundingRate > 0 ? 'up' : 'down' },
      { label: 'Liquidation Risk', value: parseFloat(liquidationRisk.toFixed(0)), trend: liquidationRisk > 60 ? 'up' : 'down' },
      { label: 'Put/Call Ratio', value: parseFloat(putCallRatio.toFixed(2)), trend: putCallRatio > 1 ? 'down' : 'up' },
    ],
  };
}

function analyzeWhaleDNA(candles: QMGECandleInput[]): QMGEDimensionScore {
  const volumes = candles.map(c => c.volume);
  const avgVol = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  const avgCandleSize = candles.reduce((sum, c) => sum + Math.abs(c.close - c.open), 0) / candles.length;

  const largeMovers = candles.slice(-20).filter(c =>
    Math.abs(c.close - c.open) > avgCandleSize * 2 && c.volume > avgVol * 1.5
  );
  const accumCandles = largeMovers.filter(c => c.close > c.open);
  const distribCandles = largeMovers.filter(c => c.close < c.open);
  const accumIndex = Math.min(100, (accumCandles.length * 25));

  const clusterActivity = Math.min(100, largeMovers.length * 15);

  const recentLarge = candles.slice(-5).filter(c => c.volume > avgVol * 2).length;
  const olderLarge = candles.slice(-15, -5).filter(c => c.volume > avgVol * 2).length;
  const behaviorShift = Math.max(-1, Math.min(1, (recentLarge - olderLarge / 2) / 3));

  const dormantBreak = recentLarge >= 2 && olderLarge === 0;

  const score = Math.max(0, Math.min(100,
    accumIndex * 0.4 + clusterActivity * 0.3 + (behaviorShift + 1) * 15
  ));

  const wdCloses = candles.map(c => c.close);
  const wdCur = wdCloses[wdCloses.length - 1];
  const wdSma20 = wdCloses.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, wdCloses.length);
  const wdPcChg = wdCloses.length > 20 ? ((wdCur - wdCloses[wdCloses.length - 21]) / wdCloses[wdCloses.length - 21]) * 100 : 0;
  const wdCloseArr = candles.map(c => c.close);
  const wdTh = adaptiveTrendThreshold(wdCloseArr);
  const wdDown = wdPcChg < -wdTh && wdCur < wdSma20;
  const wdUp = wdPcChg > wdTh && wdCur > wdSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (wdDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (wdUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.whale_dna.name,
    key: 'whale_dna',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `Whale accumulation index at ${accumIndex.toFixed(0)}. ${dormantBreak ? 'Dormant whale wallets reactivating — significant.' : `${largeMovers.length} large institutional-size moves detected.`}`,
    subMetrics: [
      { label: 'Accumulation Index', value: parseFloat(accumIndex.toFixed(0)), trend: accumCandles.length > distribCandles.length ? 'up' : 'down' },
      { label: 'Cluster Activity', value: parseFloat(clusterActivity.toFixed(0)), trend: clusterActivity > 50 ? 'up' : 'flat' },
      { label: 'Behavior Shift', value: parseFloat(behaviorShift.toFixed(2)), trend: behaviorShift > 0 ? 'up' : 'down' },
      { label: 'Dormancy Break', value: dormantBreak ? 100 : 0, trend: dormantBreak ? 'up' : 'flat' },
    ],
  };
}

function analyzeSentimentVelocity(candles: QMGECandleInput[]): QMGEDimensionScore {
  const closes = candles.map(c => c.close);
  const returns5 = closes.slice(-6).map((c, i, a) => i > 0 ? (c - a[i-1]) / a[i-1] * 100 : 0).slice(1);
  const returns10 = closes.slice(-11, -5).map((c, i, a) => i > 0 ? (c - a[i-1]) / a[i-1] * 100 : 0).slice(1);
  const recentMomentum = returns5.length > 0 ? returns5.reduce((a, b) => a + b, 0) / returns5.length : 0;
  const olderMomentum = returns10.length > 0 ? returns10.reduce((a, b) => a + b, 0) / returns10.length : 0;

  const svAllReturns = closes.slice(1).map((c, i) => Math.abs((c - closes[i]) / closes[i]) * 100);
  const svAvgBar = svAllReturns.length > 0 ? svAllReturns.reduce((a, b) => a + b, 0) / svAllReturns.length : 0.01;
  const svNormDelta = (recentMomentum - olderMomentum) / (svAvgBar || 0.01);
  const velocity = Math.max(-50, Math.min(50, svNormDelta * 20));
  const acceleration = Math.max(-25, Math.min(25, svNormDelta * 10));

  const upCandles = candles.slice(-10).filter(c => c.close > c.open).length;
  const fearGreedDelta = Math.max(-20, Math.min(20, (upCandles - 5) * 4));

  const volumes = candles.map(c => c.volume);
  const avgVol = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  const recentVol = volumes.slice(-3).reduce((a, b) => a + b, 0) / 3;
  const viralIndex = Math.min(100, (recentVol / (avgVol || 1)) * 50);

  const score = Math.max(0, Math.min(100,
    50 + velocity * 0.25 + acceleration * 0.15 + fearGreedDelta * 0.3
  ));

  const svCur = closes[closes.length - 1];
  const svSma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, closes.length);
  const svPcChg = closes.length > 20 ? ((svCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
  const svTh = adaptiveTrendThreshold(closes);
  const svDown = svPcChg < -svTh && svCur < svSma20;
  const svUp = svPcChg > svTh && svCur > svSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (svDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (svUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.sentiment_velocity.name,
    key: 'sentiment_velocity',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `Sentiment velocity at ${velocity > 0 ? '+' : ''}${velocity.toFixed(1)}/hr. ${Math.abs(acceleration) > 10 ? 'Rapid sentiment shift detected.' : 'Sentiment change rate stable.'}`,
    subMetrics: [
      { label: 'Velocity (/hr)', value: parseFloat(velocity.toFixed(1)), trend: velocity > 0 ? 'up' : 'down' },
      { label: 'Acceleration', value: parseFloat(acceleration.toFixed(1)), trend: acceleration > 0 ? 'up' : 'down' },
      { label: 'Fear/Greed Delta', value: parseFloat(fearGreedDelta.toFixed(1)), trend: fearGreedDelta > 0 ? 'up' : 'down' },
      { label: 'Viral Index', value: parseFloat(viralIndex.toFixed(0)), trend: viralIndex > 60 ? 'up' : 'flat' },
    ],
  };
}

function analyzeNetworkHealth(candles: QMGECandleInput[]): QMGEDimensionScore {
  const volumes = candles.map(c => c.volume);
  const avgVol = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  const recentVol = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;

  const txThroughput = Math.min(100, Math.max(0, (recentVol / (avgVol || 1)) * 50 + 25));

  const activeAddresses = Math.min(100, Math.max(0,
    candles.slice(-10).filter(c => c.volume > avgVol * 0.5).length * 10
  ));

  const closes = candles.map(c => c.close);
  const priceChange = ((closes[closes.length - 1] - closes[0]) / closes[0]) * 100;
  const volumeChange = ((recentVol - avgVol) / (avgVol || 1)) * 100;
  const nhBarReturns = closes.slice(1).map((c, i) => Math.abs((c - closes[i]) / closes[i]) * 100);
  const nhAvgBar = nhBarReturns.reduce((a, b) => a + b, 0) / nhBarReturns.length;
  const nhExpectedMove = nhAvgBar * Math.sqrt(candles.length);
  const nhStrongTh = Math.max(0.1, Math.min(5, nhExpectedMove * 1.2));
  const nhModTh = Math.max(0.05, Math.min(2, nhExpectedMove * 0.5));
  let hashRateTrend = 0;
  if (priceChange > nhStrongTh && volumeChange < 30) hashRateTrend = 8;
  else if (priceChange > nhModTh) hashRateTrend = 4;
  else if (priceChange < -nhStrongTh && volumeChange > 30) hashRateTrend = -8;
  else if (priceChange < -nhModTh) hashRateTrend = -3;

  const volStdDev = Math.sqrt(volumes.slice(-20).reduce((sum, v) => sum + Math.pow(v - avgVol, 2), 0) / 20);
  const volConsistency = volStdDev / (avgVol || 1);
  const protocolStability = Math.min(100, Math.max(0, (1 - volConsistency) * 80 + 20));

  const score = Math.max(0, Math.min(100,
    txThroughput * 0.3 + activeAddresses * 0.25 + (hashRateTrend + 10) * 1.5 + protocolStability * 0.15
  ));

  const nhCur = closes[closes.length - 1];
  const nhSma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, closes.length);
  const nhPcChg = closes.length > 20 ? ((nhCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
  const nhTh = adaptiveTrendThreshold(closes);
  const nhDown = nhPcChg < -nhTh && nhCur < nhSma20;
  const nhUp = nhPcChg > nhTh && nhCur > nhSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (nhDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (nhUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.network_health.name,
    key: 'network_health',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `Network throughput at ${txThroughput.toFixed(0)}% capacity. Active addresses ${activeAddresses > 70 ? 'surging' : 'stable'}. Hash rate trend ${hashRateTrend > 0 ? '+' : ''}${hashRateTrend.toFixed(1)}%.`,
    subMetrics: [
      { label: 'TX Throughput', value: parseFloat(txThroughput.toFixed(0)), trend: txThroughput > 60 ? 'up' : 'flat' },
      { label: 'Active Addresses', value: parseFloat(activeAddresses.toFixed(0)), trend: activeAddresses > 70 ? 'up' : 'flat' },
      { label: 'Hash Rate Trend', value: parseFloat(hashRateTrend.toFixed(1)), trend: hashRateTrend > 0 ? 'up' : 'down' },
      { label: 'Protocol Stability', value: parseFloat(protocolStability.toFixed(0)), trend: protocolStability > 85 ? 'up' : 'flat' },
    ],
  };
}

function analyzeMacroCorrelation(candles: QMGECandleInput[]): QMGEDimensionScore {
  const closes = candles.map(c => c.close);
  const sma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const sma50 = closes.length >= 50 ? closes.slice(-50).reduce((a, b) => a + b, 0) / 50 : sma20;
  const current = closes[closes.length - 1];

  const trendAlignment = current > sma20 && sma20 > sma50 ? 1 : current < sma20 && sma20 < sma50 ? -1 : 0;
  const spxCorrelation = Math.max(-1, Math.min(1, trendAlignment * 0.6 + ((current - sma20) / (sma20 || 1)) * 5));

  const returns = closes.slice(-10).map((c, i, a) => i > 0 ? (c - a[i-1]) / a[i-1] * 100 : 0).slice(1);
  const avgReturn = returns.reduce((a, b) => a + b, 0) / (returns.length || 1);
  const dxyInverse = Math.max(-1, Math.min(1, avgReturn * 0.3));

  const recentVol = Math.sqrt(returns.reduce((sum, r) => sum + r * r, 0) / (returns.length || 1));
  const bondYieldImpact = Math.max(-50, Math.min(50, (2 - recentVol) * 20));

  const maxDrawdown = closes.slice(-20).reduce((maxD, c, i, a) => {
    if (i === 0) return 0;
    return Math.max(maxD, ((Math.max(...a.slice(0, i + 1)) - c) / Math.max(...a.slice(0, i + 1))) * 100);
  }, 0);
  const geoRiskIndex = Math.min(100, maxDrawdown * 8);

  const score = Math.max(0, Math.min(100,
    50 + spxCorrelation * 10 - dxyInverse * 8 + bondYieldImpact * 0.1 - geoRiskIndex * 0.1
  ));

  const mcCur = closes[closes.length - 1];
  const mcSma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, closes.length);
  const mcPcChg = closes.length > 20 ? ((mcCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
  const mcTh = adaptiveTrendThreshold(closes);
  const mcDown = mcPcChg < -mcTh && mcCur < mcSma20;
  const mcUp = mcPcChg > mcTh && mcCur > mcSma20;
  let dimSignal: 'bullish' | 'bearish' | 'neutral' = score > 60 ? 'bullish' : score < 40 ? 'bearish' : 'neutral';
  if (mcDown && dimSignal === 'bullish') dimSignal = 'neutral';
  if (mcUp && dimSignal === 'bearish') dimSignal = 'neutral';

  return {
    name: QMGE_DIMENSION_META.macro_correlation.name,
    key: 'macro_correlation',
    score,
    signal: dimSignal,
    strength: Math.abs(score - 50) / 50,
    description: `S&P 500 correlation ${spxCorrelation > 0 ? 'positive' : 'negative'} (${spxCorrelation.toFixed(2)}). DXY ${dxyInverse > 0 ? 'weakening' : 'strengthening'} — ${Math.abs(dxyInverse) > 0.3 ? 'significant macro factor' : 'moderate influence'}.`,
    subMetrics: [
      { label: 'S&P 500 Correlation', value: parseFloat(spxCorrelation.toFixed(2)), trend: spxCorrelation > 0 ? 'up' : 'down' },
      { label: 'DXY Inverse', value: parseFloat(dxyInverse.toFixed(2)), trend: dxyInverse > 0 ? 'up' : 'down' },
      { label: 'Bond Yield Impact', value: parseFloat(bondYieldImpact.toFixed(1)), trend: bondYieldImpact > 0 ? 'up' : 'down' },
      { label: 'Geo-Risk Index', value: parseFloat(geoRiskIndex.toFixed(0)), trend: geoRiskIndex > 60 ? 'up' : 'flat' },
    ],
  };
}

function detectGenomePattern(dimensions: QMGEDimensionScore[], convergence: number): string {
  const bullCount = dimensions.filter(d => d.signal === 'bullish').length;
  const bearCount = dimensions.filter(d => d.signal === 'bearish').length;
  const strongestDim = dimensions.reduce((a, b) => a.strength > b.strength ? a : b);

  if (convergence > 0.8 && bullCount >= 5) return 'Quantum Alignment';
  if (convergence > 0.8 && bearCount >= 5) return 'Pressure Inversion';
  if (strongestDim.key === 'whale_dna' && strongestDim.signal === 'bullish') return 'Whale Convergence';
  if (strongestDim.key === 'capital_flow' && strongestDim.signal === 'bullish') return 'Alpha Surge';
  if (strongestDim.key === 'sentiment_velocity' && strongestDim.signal !== dimensions.find(d => d.key === 'capital_flow')?.signal) return 'Sentiment Divergence';
  if (strongestDim.key === 'liquidity_topology') return 'Liquidity Cascade';
  if (strongestDim.key === 'network_health') return 'Network Awakening';
  if (strongestDim.key === 'macro_correlation') return 'Macro Decoupling';
  if (strongestDim.key === 'whale_dna' && strongestDim.strength > 0.7) return 'Stealth Accumulation';
  if (convergence < 0.3) return 'Genome Mutation';
  return GENOME_PATTERNS[Math.floor(Math.abs(convergence * 14))];
}

export function runQMGEAnalysis(
  symbol: string,
  price: number,
  volume: number = 1000000,
  config: Partial<QMGEConfig> = {},
  candles?: QMGECandleInput[]
): QMGEGenomeMap {
  const now = Date.now();

  const activeDimensions = config.dimensions || [
    'capital_flow', 'liquidity_topology', 'derivatives_pressure',
    'whale_dna', 'sentiment_velocity', 'network_health', 'macro_correlation',
  ];

  const candleData = candles && candles.length >= 30 ? candles : generateSyntheticCandles(price, volume);

  const dimensions: QMGEDimensionScore[] = activeDimensions.map(dim => {
    switch (dim) {
      case 'capital_flow': return analyzeCapitalFlow(candleData);
      case 'liquidity_topology': return analyzeLiquidityTopology(candleData);
      case 'derivatives_pressure': return analyzeDerivativesPressure(candleData);
      case 'whale_dna': return analyzeWhaleDNA(candleData);
      case 'sentiment_velocity': return analyzeSentimentVelocity(candleData);
      case 'network_health': return analyzeNetworkHealth(candleData);
      case 'macro_correlation': return analyzeMacroCorrelation(candleData);
      default: return analyzeCapitalFlow(candleData);
    }
  });

  const weights = { ...DEFAULT_WEIGHTS };
  const totalWeight = activeDimensions.reduce((sum, d) => sum + (weights[d] || 0.1), 0);
  const aggregateScore = dimensions.reduce((sum, d) => sum + d.score * ((weights[d.key] || 0.1) / totalWeight), 0);

  const signals = dimensions.map(d => d.signal);
  const unanimity = Math.max(
    signals.filter(s => s === 'bullish').length,
    signals.filter(s => s === 'bearish').length
  ) / signals.length;

  const convergenceIndex = unanimity;

  const qmgeCloses = candleData.map(c => c.close);
  const qmgeCurrent = qmgeCloses[qmgeCloses.length - 1];
  const qmgeSma20 = qmgeCloses.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, qmgeCloses.length);
  const qmgeSma50 = qmgeCloses.length >= 50 ? qmgeCloses.slice(-50).reduce((a, b) => a + b, 0) / 50 : qmgeSma20;
  const qmgePriceChange = qmgeCloses.length > 20 ? ((qmgeCurrent - qmgeCloses[qmgeCloses.length - 21]) / qmgeCloses[qmgeCloses.length - 21]) * 100 : 0;
  const qmgeTh = adaptiveTrendThreshold(qmgeCloses);
  const qmgeInDowntrend = (qmgePriceChange < -qmgeTh && qmgeCurrent < qmgeSma20) || (qmgeCurrent < qmgeSma20 && qmgeCurrent < qmgeSma50);
  const qmgeInUptrend = (qmgePriceChange > qmgeTh && qmgeCurrent > qmgeSma20) || (qmgeCurrent > qmgeSma20 && qmgeCurrent > qmgeSma50);

  let aggregateSignal: QMGEGenomeMap['aggregateSignal'];
  if (qmgeInDowntrend) {
    if (aggregateScore <= 25) aggregateSignal = 'strong_sell';
    else if (aggregateScore <= 40) aggregateSignal = 'sell';
    else aggregateSignal = 'neutral';
  } else if (qmgeInUptrend) {
    if (aggregateScore >= 75) aggregateSignal = 'strong_buy';
    else if (aggregateScore >= 60) aggregateSignal = 'buy';
    else aggregateSignal = 'neutral';
  } else {
    if (aggregateScore >= 75) aggregateSignal = 'strong_buy';
    else if (aggregateScore >= 60) aggregateSignal = 'buy';
    else if (aggregateScore <= 25) aggregateSignal = 'strong_sell';
    else if (aggregateScore <= 40) aggregateSignal = 'sell';
    else aggregateSignal = 'neutral';
  }

  const timeHorizon = config.timeHorizon || 15;
  let direction: QMGEPrediction['direction'] = aggregateScore > 55 ? 'up' : aggregateScore < 45 ? 'down' : 'sideways';
  if (qmgeInDowntrend && direction === 'up') direction = 'sideways';
  if (qmgeInUptrend && direction === 'down') direction = 'sideways';
  const magnitude = Math.abs(aggregateScore - 50) / 50 * (0.5 + unanimity * 2);
  const confidence = Math.min(95, 40 + unanimity * 30 + Math.abs(aggregateScore - 50) * 0.5);

  const prediction: QMGEPrediction = {
    direction,
    confidence: parseFloat(confidence.toFixed(1)),
    magnitude: parseFloat(magnitude.toFixed(3)),
    timeHorizon,
    entryWindow: { start: now, end: now + timeHorizon * 60000 },
    riskLevel: magnitude > 1.5 ? 'extreme' : magnitude > 1 ? 'high' : magnitude > 0.5 ? 'medium' : 'low',
  };

  const dominantDimension = dimensions.reduce((a, b) => a.strength > b.strength ? a : b).key;
  const mutationRate = 1 - convergenceIndex;

  return {
    timestamp: now,
    symbol,
    dimensions,
    aggregateScore: parseFloat(aggregateScore.toFixed(1)),
    aggregateSignal,
    genomePattern: detectGenomePattern(dimensions, convergenceIndex),
    prediction,
    dominantDimension,
    convergenceIndex: parseFloat(convergenceIndex.toFixed(3)),
    mutationRate: parseFloat(mutationRate.toFixed(3)),
    adaptiveWeight: weights,
  };
}

function generateSyntheticCandles(price: number, volume: number): QMGECandleInput[] {
  const candles: QMGECandleInput[] = [];
  let currentPrice = price * 0.98;
  const now = Date.now();
  for (let i = 0; i < 50; i++) {
    const change = (Math.sin(i * 0.3) * 0.005 + Math.cos(i * 0.15) * 0.003) * currentPrice;
    const open = currentPrice;
    const close = currentPrice + change;
    const high = Math.max(open, close) + Math.abs(change) * 0.5;
    const low = Math.min(open, close) - Math.abs(change) * 0.5;
    const vol = volume * (0.8 + Math.sin(i * 0.4) * 0.4);
    candles.push({ open, high, low, close, volume: vol, time: now - (50 - i) * 60000 });
    currentPrice = close;
  }
  return candles;
}

export function getQMGESignalColor(signal: QMGEGenomeMap['aggregateSignal']): string {
  switch (signal) {
    case 'strong_buy': return '#22c55e';
    case 'buy': return '#4ade80';
    case 'neutral': return '#eab308';
    case 'sell': return '#f87171';
    case 'strong_sell': return '#ef4444';
  }
}

export function getQMGEScoreGrade(score: number): { grade: string; label: string; color: string } {
  if (score >= 80) return { grade: 'A+', label: 'Exceptional', color: '#22c55e' };
  if (score >= 70) return { grade: 'A', label: 'Strong', color: '#4ade80' };
  if (score >= 60) return { grade: 'B+', label: 'Favorable', color: '#86efac' };
  if (score >= 50) return { grade: 'B', label: 'Neutral-Positive', color: '#eab308' };
  if (score >= 40) return { grade: 'C', label: 'Neutral-Negative', color: '#f59e0b' };
  if (score >= 30) return { grade: 'D', label: 'Weak', color: '#f87171' };
  return { grade: 'F', label: 'Critical', color: '#ef4444' };
}
