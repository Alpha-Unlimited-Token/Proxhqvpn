/**
 * Quantum Market Genome Engine™ (QMGE) - Public API Module
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This module exports the public API surface of the Quantum Market Genome Engine™ (QMGE).
 * All exported functions, types, constants, and interfaces are proprietary intellectual
 * property of Alpha Unlimited Trading Company.
 *
 * ALL RIGHTS RESERVED. Unauthorized use, reproduction, or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

export { runQMGEAnalysis, getQMGESignalColor, getQMGEScoreGrade } from './engine';
export type { QMGEDimensionScore, QMGEGenomeMap, QMGEConfig, QMGEDimension, QMGEPrediction, QMGECandleInput } from './types';
export { QMGE_DIMENSION_META, GENOME_PATTERNS } from './types';
