/**
 * Quantum Market Genome Engine™ (QMGE) - Type Definitions & Data Structures
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This file contains proprietary type definitions, data structures, interfaces,
 * dimension metadata, and genome pattern classifications for the Quantum Market
 * Genome Engine™ (QMGE), exclusively owned by Alpha Unlimited Trading Company.
 *
 * PROTECTED INTELLECTUAL PROPERTY INCLUDES:
 * - QMGEDimensionScore™ data structure and scoring methodology
 * - QMGEGenomeMap™ composite genome mapping architecture
 * - QMGEPrediction™ predictive output structure
 * - QMGEConfig™ configuration schema
 * - 7-Dimension metadata definitions and classification system
 * - Genome Pattern Library™ (15+ proprietary pattern names and classifications)
 * - Sub-metric taxonomy and trend classification system
 * - Signal strength quantification methodology
 *
 * ALL RIGHTS RESERVED. NO PART OF THIS SOURCE CODE, DATA STRUCTURE, TAXONOMY,
 * NOMENCLATURE, OR CLASSIFICATION SYSTEM MAY BE COPIED, REPRODUCED, MODIFIED,
 * DISTRIBUTED, REVERSE ENGINEERED, OR USED IN ANY FORM WITHOUT THE EXPRESS
 * WRITTEN PERMISSION OF ALPHA UNLIMITED TRADING COMPANY.
 *
 * VIOLATORS WILL BE PROSECUTED TO THE MAXIMUM EXTENT OF APPLICABLE LAW.
 *
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

export interface QMGECandleInput {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: number;
}

export interface QMGEDimensionScore {
  name: string;
  key: QMGEDimension;
  score: number;
  signal: 'bullish' | 'bearish' | 'neutral';
  strength: number;
  description: string;
  subMetrics: { label: string; value: number; trend: 'up' | 'down' | 'flat' }[];
}

export type QMGEDimension =
  | 'capital_flow'
  | 'liquidity_topology'
  | 'derivatives_pressure'
  | 'whale_dna'
  | 'sentiment_velocity'
  | 'network_health'
  | 'macro_correlation';

export interface QMGEPrediction {
  direction: 'up' | 'down' | 'sideways';
  confidence: number;
  magnitude: number;
  timeHorizon: number;
  entryWindow: { start: number; end: number };
  riskLevel: 'low' | 'medium' | 'high' | 'extreme';
}

export interface QMGEGenomeMap {
  timestamp: number;
  symbol: string;
  dimensions: QMGEDimensionScore[];
  aggregateScore: number;
  aggregateSignal: 'strong_buy' | 'buy' | 'neutral' | 'sell' | 'strong_sell';
  genomePattern: string;
  prediction: QMGEPrediction;
  dominantDimension: QMGEDimension;
  convergenceIndex: number;
  mutationRate: number;
  adaptiveWeight: Record<QMGEDimension, number>;
}

export interface QMGEConfig {
  timeHorizon: 5 | 10 | 15 | 30;
  sensitivity: 'low' | 'medium' | 'high';
  dimensions: QMGEDimension[];
}

export const QMGE_DIMENSION_META: Record<QMGEDimension, { name: string; icon: string; color: string; description: string }> = {
  capital_flow: {
    name: 'Capital Flow Dynamics',
    icon: 'DollarSign',
    color: '#22c55e',
    description: 'Tracks institutional and retail money movement patterns, order book depth imbalances, and net capital inflow/outflow velocity across exchanges.',
  },
  liquidity_topology: {
    name: 'Liquidity Topology',
    icon: 'Droplets',
    color: '#3b82f6',
    description: 'Maps the 3D structure of market liquidity, identifying hidden support/resistance pools, liquidity voids, and absorption zones that traditional analysis misses.',
  },
  derivatives_pressure: {
    name: 'Derivatives Pressure',
    icon: 'Flame',
    color: '#f97316',
    description: 'Analyzes futures open interest, funding rates, options flow, and liquidation cascade probabilities to gauge directional derivatives pressure.',
  },
  whale_dna: {
    name: 'Whale Behavioral DNA',
    icon: 'Fingerprint',
    color: '#a855f7',
    description: 'Profiles and tracks whale wallet clusters using behavioral fingerprinting, identifying accumulation/distribution patterns before they impact price.',
  },
  sentiment_velocity: {
    name: 'Sentiment Velocity',
    icon: 'Gauge',
    color: '#eab308',
    description: 'Measures the rate of change in market sentiment across social media, news, and on-chain signals — not just sentiment, but how fast it\'s shifting.',
  },
  network_health: {
    name: 'Network Health',
    icon: 'Activity',
    color: '#06b6d4',
    description: 'Evaluates blockchain fundamentals including transaction throughput, active addresses, hash rate trends, staking ratios, and protocol upgrade impact.',
  },
  macro_correlation: {
    name: 'Macro Correlation Matrix',
    icon: 'Globe',
    color: '#ec4899',
    description: 'Correlates crypto movements with traditional markets (S&P 500, DXY, bonds, commodities), geopolitical events, and central bank policy shifts.',
  },
};

export const GENOME_PATTERNS = [
  'Alpha Surge',
  'Stealth Accumulation',
  'Liquidity Cascade',
  'Whale Convergence',
  'Sentiment Divergence',
  'Network Awakening',
  'Macro Decoupling',
  'Genome Mutation',
  'Adaptive Resonance',
  'Quantum Alignment',
  'Pressure Inversion',
  'Flow Reversal',
  'Silent Accumulation',
  'Volatility Genome Shift',
  'Cross-Dimensional Convergence',
] as const;
