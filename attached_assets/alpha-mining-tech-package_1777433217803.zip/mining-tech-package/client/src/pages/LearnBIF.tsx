import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { 
  ArrowLeft, Layers, Cpu, Activity, BarChart3, 
  Target, AlertTriangle, CheckCircle, XCircle, Info, Shield, Zap,
  Server, TrendingUp, TrendingDown, Clock, Download
} from "lucide-react";
import { PDF_GENERATORS } from "@/lib/pdfGenerator";
import { PageShareBar } from "@/components/PageShareBar";

export default function LearnBIF() {
  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-[#0A1628] text-white">
        <div className="max-w-5xl mx-auto px-4 py-8">
          <Link href="/alpha-trading/terminal">
            <a className="inline-flex items-center gap-2 text-gray-400 hover:text-fuchsia-400 mb-6 transition-colors" data-testid="link-back-terminal">
              <ArrowLeft size={20} />
              Back to Trading Terminal
            </a>
          </Link>

          <div className="flex justify-end mb-2">
            <PageShareBar pageTitle="Blockchain Intelligence Filter™ (BIF)" pageDescription="On-chain data analysis technology for crypto trading" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-fuchsia-500/40 to-purple-500/30 flex items-center justify-center">
                <Layers className="text-fuchsia-400" size={32} />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-fuchsia-400">Blockchain Intelligence Filter™ (BIF)</h1>
                <p className="text-gray-400">Complete Learning Guide</p>
              </div>
            </div>

            <button
              onClick={() => PDF_GENERATORS.bif.fn()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-fuchsia-500/20 to-purple-500/20 hover:from-fuchsia-500/30 hover:to-purple-500/30 rounded-xl border border-fuchsia-500/30 hover:border-fuchsia-500/50 transition-all text-sm font-bold text-fuchsia-400"
              data-testid="button-download-bif-pdf"
            >
              <Download size={16} />
              Download BIF Tutorial PDF
            </button>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-fuchsia-500/20">
              <h2 className="text-xl font-bold text-white mb-4">What is BIF?</h2>
              <p className="text-gray-300 leading-relaxed">
                The Blockchain Intelligence Filter™ analyzes <span className="text-fuchsia-400 font-semibold">real on-chain data</span> to 
                detect network health, miner behavior, and blockchain-level signals that can predict price movements. While most 
                traders only look at price charts, BIF gives you insights into what's happening on the actual blockchain — 
                information that often leads price by hours or days.
              </p>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-6">The 5 BIF Components</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-900/50 rounded-lg p-5 border-l-4 border-fuchsia-400">
                  <h3 className="text-lg font-bold text-fuchsia-400 mb-2 flex items-center gap-2">
                    <Server size={20} />
                    1. Network Congestion Analysis
                  </h3>
                  <p className="text-gray-300 mb-3">
                    Estimates blockchain congestion by analyzing volume patterns and bid-ask spreads.
                  </p>
                  <div className="bg-gray-800 rounded p-4">
                    <p className="text-sm text-gray-400 mb-3"><strong className="text-white">Congestion Levels:</strong></p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      <div className="p-2 bg-green-500/10 rounded text-center">
                        <div className="font-bold text-green-400 text-sm">LOW</div>
                        <p className="text-xs text-gray-400">Fast transactions, low fees</p>
                      </div>
                      <div className="p-2 bg-yellow-500/10 rounded text-center">
                        <div className="font-bold text-yellow-400 text-sm">MODERATE</div>
                        <p className="text-xs text-gray-400">Normal conditions</p>
                      </div>
                      <div className="p-2 bg-orange-500/10 rounded text-center">
                        <div className="font-bold text-orange-400 text-sm">HIGH</div>
                        <p className="text-xs text-gray-400">Slower, higher fees</p>
                      </div>
                      <div className="p-2 bg-red-500/10 rounded text-center">
                        <div className="font-bold text-red-400 text-sm">EXTREME</div>
                        <p className="text-xs text-gray-400">Major activity!</p>
                      </div>
                    </div>
                    <p className="text-xs text-gray-400 mt-3">
                      <strong className="text-fuchsia-400">Trading Insight:</strong> EXTREME congestion often precedes major price moves — everyone is rushing to transact!
                    </p>
                  </div>
                </div>

                <div className="bg-gray-900/50 rounded-lg p-5 border-l-4 border-purple-500">
                  <h3 className="text-lg font-bold text-purple-400 mb-2 flex items-center gap-2">
                    <Cpu size={20} />
                    2. Miner Selling Pressure
                  </h3>
                  <p className="text-gray-300 mb-3">
                    Tracks whether miners are holding (accumulating) or selling their rewards.
                  </p>
                  <div className="bg-gray-800 rounded p-4">
                    <p className="text-sm text-gray-400 mb-3"><strong className="text-white">Miner Behavior:</strong></p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 p-2 bg-green-500/10 rounded">
                        <CheckCircle className="text-green-400" size={16} />
                        <div>
                          <span className="text-green-400 font-bold">ACCUMULATING</span>
                          <span className="text-gray-400 text-sm ml-2">— Miners are holding. Bullish signal (reduced sell pressure)</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-2 bg-gray-500/10 rounded">
                        <Info className="text-gray-400" size={16} />
                        <div>
                          <span className="text-gray-400 font-bold">STABLE</span>
                          <span className="text-gray-400 text-sm ml-2">— Normal miner activity, neutral</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-2 bg-red-500/10 rounded">
                        <XCircle className="text-red-400" size={16} />
                        <div>
                          <span className="text-red-400 font-bold">DISTRIBUTING</span>
                          <span className="text-gray-400 text-sm ml-2">— Miners are selling. Bearish (increased sell pressure)</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-900/50 rounded-lg p-5 border-l-4 border-cyan-500">
                  <h3 className="text-lg font-bold text-cyan-400 mb-2 flex items-center gap-2">
                    <Activity size={20} />
                    3. Hash Rate Trend Analysis
                  </h3>
                  <p className="text-gray-300 mb-3">
                    Monitors hash rate (mining power) changes and their impact on network security and price.
                  </p>
                  <div className="bg-gray-800 rounded p-4">
                    <p className="text-sm text-gray-400 mb-3"><strong className="text-white">Hash Rate Signals:</strong></p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 bg-green-500/10 rounded">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="text-green-400" size={16} />
                          <span className="text-green-400 font-bold">RISING</span>
                        </div>
                        <span className="text-xs text-gray-400">More miners joining — bullish network health</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-gray-500/10 rounded">
                        <div className="flex items-center gap-2">
                          <Activity className="text-gray-400" size={16} />
                          <span className="text-gray-400 font-bold">STABLE</span>
                        </div>
                        <span className="text-xs text-gray-400">Consistent mining activity</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-red-500/10 rounded">
                        <div className="flex items-center gap-2">
                          <TrendingDown className="text-red-400" size={16} />
                          <span className="text-red-400 font-bold">FALLING</span>
                        </div>
                        <span className="text-xs text-gray-400">Miners leaving — potential bearish signal</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-900/50 rounded-lg p-5 border-l-4 border-yellow-500">
                  <h3 className="text-lg font-bold text-yellow-400 mb-2 flex items-center gap-2">
                    <Target size={20} />
                    4. Difficulty Adjustment Prediction
                  </h3>
                  <p className="text-gray-300 mb-3">
                    Forecasts upcoming mining difficulty adjustments and their market impact.
                  </p>
                  <div className="bg-gray-800 rounded p-4">
                    <p className="text-sm text-gray-400 mb-2"><strong className="text-white">Why This Matters:</strong></p>
                    <ul className="text-sm text-gray-300 space-y-2">
                      <li className="flex items-start gap-2">
                        <TrendingUp className="text-green-400 mt-0.5" size={14} />
                        <span><strong className="text-green-400">Difficulty increase:</strong> Network is strong, more miners competing — generally bullish</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <TrendingDown className="text-red-400 mt-0.5" size={14} />
                        <span><strong className="text-red-400">Difficulty decrease:</strong> Miners leaving due to unprofitability — watch for weakness</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="bg-gray-900/50 rounded-lg p-5 border-l-4 border-green-500">
                  <h3 className="text-lg font-bold text-green-400 mb-2 flex items-center gap-2">
                    <Clock size={20} />
                    5. Block Time Deviation
                  </h3>
                  <p className="text-gray-300 mb-3">
                    Measures network activity through block time variations.
                  </p>
                  <div className="bg-gray-800 rounded p-4">
                    <p className="text-sm text-gray-400 mb-2"><strong className="text-white">Block Time Signals:</strong></p>
                    <ul className="text-sm text-gray-300 space-y-2">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="text-green-400 mt-0.5" size={14} />
                        <span><strong className="text-green-400">Faster than target:</strong> High network activity — demand is up</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Info className="text-blue-400 mt-0.5" size={14} />
                        <span><strong className="text-blue-400">On target:</strong> Normal conditions</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <AlertTriangle className="text-orange-400 mt-0.5" size={14} />
                        <span><strong className="text-orange-400">Slower than target:</strong> Reduced activity or miner issues</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-6">Understanding BIF Output</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-900/50 rounded-lg p-5">
                  <h3 className="font-bold text-white mb-4">Health Score (0-100)</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Overall blockchain health combining all 5 components.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div className="bg-green-500 h-3 rounded-full" style={{width: '80%'}}></div>
                      </div>
                      <span className="text-green-400 font-bold text-sm w-16">80-100</span>
                    </div>
                    <p className="text-xs text-gray-400 ml-2">Excellent — Strong bullish bias</p>
                    
                    <div className="flex items-center gap-2 mt-3">
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div className="bg-yellow-500 h-3 rounded-full" style={{width: '60%'}}></div>
                      </div>
                      <span className="text-yellow-400 font-bold text-sm w-16">50-79</span>
                    </div>
                    <p className="text-xs text-gray-400 ml-2">Good — Neutral to slight bullish</p>
                    
                    <div className="flex items-center gap-2 mt-3">
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div className="bg-orange-500 h-3 rounded-full" style={{width: '40%'}}></div>
                      </div>
                      <span className="text-orange-400 font-bold text-sm w-16">30-49</span>
                    </div>
                    <p className="text-xs text-gray-400 ml-2">Caution — Some concerns</p>
                    
                    <div className="flex items-center gap-2 mt-3">
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div className="bg-red-500 h-3 rounded-full" style={{width: '25%'}}></div>
                      </div>
                      <span className="text-red-400 font-bold text-sm w-16">0-29</span>
                    </div>
                    <p className="text-xs text-gray-400 ml-2">Poor — Bearish blockchain signals</p>
                  </div>
                </div>

                <div className="bg-gray-900/50 rounded-lg p-5">
                  <h3 className="font-bold text-white mb-4">Trading Signals</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-green-500/20 rounded-lg border border-green-500/30">
                      <Zap className="text-green-400" size={20} />
                      <div>
                        <div className="font-bold text-green-400">STRONG BUY</div>
                        <p className="text-xs text-gray-400">Health 80+ with miners accumulating</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                      <CheckCircle className="text-green-400" size={20} />
                      <div>
                        <div className="font-bold text-green-400">BUY</div>
                        <p className="text-xs text-gray-400">Health 60-79 with positive trends</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-500/10 rounded-lg border border-gray-500/30">
                      <Info className="text-gray-400" size={20} />
                      <div>
                        <div className="font-bold text-gray-400">NEUTRAL</div>
                        <p className="text-xs text-gray-400">Health 40-59 or mixed signals</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-red-500/10 rounded-lg border border-red-500/20">
                      <XCircle className="text-red-400" size={20} />
                      <div>
                        <div className="font-bold text-red-400">SELL</div>
                        <p className="text-xs text-gray-400">Health 20-39 with miners distributing</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-red-500/20 rounded-lg border border-red-500/30">
                      <Zap className="text-red-400" size={20} />
                      <div>
                        <div className="font-bold text-red-400">STRONG SELL</div>
                        <p className="text-xs text-gray-400">Health below 20 with falling hash rate</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-6">Practical Examples</h2>
              
              <div className="space-y-6">
                <div className="bg-fuchsia-500/10 rounded-lg p-5 border border-fuchsia-500/30">
                  <div className="flex items-center gap-3 mb-3">
                    <CheckCircle className="text-fuchsia-400" size={24} />
                    <h3 className="font-bold text-fuchsia-400">Example: Bullish On-Chain Setup</h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Congestion</div>
                      <div className="text-yellow-400 font-bold">MODERATE</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Miners</div>
                      <div className="text-green-400 font-bold">ACCUMULATING</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Hash Rate</div>
                      <div className="text-green-400 font-bold">RISING</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Difficulty</div>
                      <div className="text-green-400 font-bold">+8% NEXT</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Block Time</div>
                      <div className="text-green-400 font-bold">FASTER</div>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm">
                    <strong>Result:</strong> Health Score: <span className="text-green-400 font-bold">87</span> | Signal: <span className="text-green-400 font-bold">STRONG BUY</span>
                  </p>
                  <p className="text-gray-400 text-sm mt-2">
                    <strong>Analysis:</strong> Miners are HODLing, hash rate is growing, difficulty increasing, and blocks are coming faster. 
                    This indicates strong network fundamentals — price should follow.
                  </p>
                </div>

                <div className="bg-red-500/10 rounded-lg p-5 border border-red-500/30">
                  <div className="flex items-center gap-3 mb-3">
                    <AlertTriangle className="text-red-400" size={24} />
                    <h3 className="font-bold text-red-400">Example: Bearish Warning Signs</h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Congestion</div>
                      <div className="text-red-400 font-bold">EXTREME</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Miners</div>
                      <div className="text-red-400 font-bold">DISTRIBUTING</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Hash Rate</div>
                      <div className="text-red-400 font-bold">FALLING</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Difficulty</div>
                      <div className="text-orange-400 font-bold">-5% NEXT</div>
                    </div>
                    <div className="bg-gray-900/50 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">Block Time</div>
                      <div className="text-orange-400 font-bold">SLOWER</div>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm">
                    <strong>Result:</strong> Health Score: <span className="text-red-400 font-bold">28</span> | Signal: <span className="text-red-400 font-bold">STRONG SELL</span>
                  </p>
                  <p className="text-gray-400 text-sm mt-2">
                    <strong>Analysis:</strong> Miners are rushing to sell (extreme congestion + distribution), hash rate dropping, 
                    difficulty decreasing. Major warning signs — consider exiting or hedging positions.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-4">Pro Tips for BIF</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-fuchsia-400 font-bold">1</span>
                  </div>
                  <p className="text-gray-300 text-sm">BIF is most useful for Bitcoin and PoW coins. For PoS chains, focus more on staking data.</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-fuchsia-400 font-bold">2</span>
                  </div>
                  <p className="text-gray-300 text-sm">Miner behavior often leads price by 1-3 days. Use it as an early warning system.</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-fuchsia-400 font-bold">3</span>
                  </div>
                  <p className="text-gray-300 text-sm">EXTREME congestion + price spike = potential local top. Smart money may be selling into the rally.</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-fuchsia-400 font-bold">4</span>
                  </div>
                  <p className="text-gray-300 text-sm">Combine BIF with ACM for best results. On-chain bullish + technical bullish = high conviction trade.</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-fuchsia-500/10 to-purple-500/10 rounded-xl p-6 border border-fuchsia-500/30">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="text-fuchsia-400" size={24} />
                <span className="text-sm text-gray-400">Blockchain Intelligence Filter™ is protected by international copyright law</span>
              </div>
              <Link href="/alpha-trading/terminal">
                <a className="inline-flex items-center gap-2 px-6 py-3 bg-fuchsia-500 text-white rounded-lg font-bold hover:bg-fuchsia-400 transition-colors" data-testid="button-back-trading">
                  <BarChart3 size={20} />
                  Return to Trading Terminal
                </a>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
