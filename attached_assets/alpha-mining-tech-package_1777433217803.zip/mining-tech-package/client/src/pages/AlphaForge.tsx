/**
 * Alpha Unlimited Token (ALPHAU) - Alpha Forge Tool
 * Copyright (c) 2024-present Alpha Unlimited Token. All Rights Reserved.
 * 
 * PROPRIETARY AND CONFIDENTIAL
 * This source code is protected under international copyright law.
 * Unauthorized copying, modification, distribution, reverse engineering,
 * or use of this code is strictly prohibited and will be prosecuted.
 * 
 * The Alpha Forge meme creation tool and all related technology are
 * exclusive intellectual property of Alpha Unlimited Token.
 */

import { useState, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Wand2, Download, RefreshCw, ChevronLeft, ChevronRight, Sparkles, Copy, Check, Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const neonSign = "/nfts/neon_sign_illuminati_suit_1766942828898.png";
const matrixCode = "/nfts/matrix_code_illuminati_suit_1766942895441.png";
const claymation = "/nfts/claymation_illuminati_suit_1766942895487.png";
const oilPainting = "/nfts/oil_painting_illuminati_eye_suit_1766942895501.png";
const steampunk = "/nfts/steampunk_illuminati_suit_1766942895518.png";
const legoBrick = "/nfts/lego_brick_illuminati_suit_1766942895536.png";
const origami = "/nfts/origami_paper_illuminati_suit_1766942895551.png";
const animeStyle = "/nfts/anime_style_illuminati_suit-1_1766942895569.png";
const popArt = "/nfts/pop_art_illuminati_suit_1766942895590.png";
const watercolor = "/nfts/watercolor_illuminati_suit_1766942895610.png";
const streetArt = "/nfts/street_art_graffiti_illuminati_suit_1766942895630.png";
const lowPoly = "/nfts/low_poly_3d_illuminati_suit_1766942895648.png";
const pixelArt = "/nfts/pixel_art_illuminati_eye_suit_1766942895668.png";
const cyberpunk = "/nfts/cyberpunk_illuminati_eye_suit_1766942895682.png";
const noirDetective = "/nfts/noir_detective_illuminati_suit_1766942895701.png";
const goldMascot = "/nfts/Screenshot_20251228-102938_Chrome_1766936074186_1766942895733.png";
const blueprint = "/nfts/blueprint_sketch_illuminati_suit-1_1766942895748.png";
const alphauCoin = "/nfts/download_1766942895766.jpg";
const graffitiLogo = "/nfts/image0~3_1766948843476.jpeg";

const MEME_TEMPLATES = [
  { id: 1, name: "Gold Mascot", image: goldMascot },
  { id: 2, name: "Neon Sign", image: neonSign },
  { id: 3, name: "Matrix Code", image: matrixCode },
  { id: 4, name: "Claymation", image: claymation },
  { id: 5, name: "Oil Painting", image: oilPainting },
  { id: 6, name: "Steampunk", image: steampunk },
  { id: 7, name: "Lego Brick", image: legoBrick },
  { id: 8, name: "Origami", image: origami },
  { id: 9, name: "Anime Style", image: animeStyle },
  { id: 10, name: "Pop Art", image: popArt },
  { id: 11, name: "Watercolor", image: watercolor },
  { id: 12, name: "Street Art", image: streetArt },
  { id: 13, name: "Low Poly 3D", image: lowPoly },
  { id: 14, name: "Pixel Art", image: pixelArt },
  { id: 15, name: "Cyberpunk", image: cyberpunk },
  { id: 16, name: "Noir Detective", image: noirDetective },
  { id: 18, name: "Blueprint", image: blueprint },
  { id: 19, name: "ALPHAU Coin", image: alphauCoin },
  { id: 20, name: "Graffiti Logo", image: graffitiLogo },
];

const MEME_CATEGORIES = [
  { id: "all", name: "All", icon: "✨" },
  { id: "token", name: "Token", icon: "🪙" },
  { id: "mining", name: "Mining", icon: "⛏️" },
  { id: "nft", name: "NFT", icon: "🖼️" },
  { id: "game", name: "Game", icon: "⚔️" },
  { id: "trading", name: "Trading", icon: "📈" },
  { id: "anime", name: "Anime", icon: "🎬" },
  { id: "crypto", name: "Crypto", icon: "💎" },
  { id: "community", name: "Squad", icon: "👥" },
  { id: "twitter", name: "Twitter", icon: "𝕏" },
  { id: "linkedin", name: "LinkedIn", icon: "💼" },
  { id: "instagram", name: "Instagram", icon: "📷" },
  { id: "tiktok", name: "TikTok", icon: "♪" },
  { id: "memeos", name: "MemeOS", icon: "👁️" },
];

const MEME_TEXT_DATABASE = {
  token: {
    top: [
      "WHEN ALPHAU GOES UP 100%",
      "ME EXPLAINING ALPHAU TO MY FAMILY",
      "BOUGHT MORE ALPHAU AT THE DIP",
      "CHECKING ALPHAU PRICE AT 3AM",
      "WHEN YOU FIRST DISCOVER ALPHAU",
      "ALPHAU HOLDERS RIGHT NOW",
      "SOLANA NETWORK: *EXISTS*",
      "MOONSHOT TRADERS BE LIKE",
      "MY PORTFOLIO BEFORE ALPHAU",
      "WHEN ALPHAU HITS A NEW ATH",
      "THEM: WHAT COIN DO YOU HOLD?",
      "GETTING PAID IN ALPHAU",
    ],
    bottom: [
      "AND IT'S JUST THE BEGINNING",
      "UNLIMITED GAINS ACTIVATED",
      "THIS IS THE WAY",
      "THEY STILL DON'T UNDERSTAND",
      "WELCOME TO THE ALPHA SQUAD",
      "SOLANA SPEED, ALPHA POWER",
      "MOONSHOT TO THE MOON",
      "VS MY PORTFOLIO NOW",
      "BEST DECISION OF MY LIFE",
      "WE'RE ALL GONNA MAKE IT",
      "ME: ALPHAU OBVIOUSLY",
      "PASSIVE INCOME UNLOCKED",
    ],
  },
  mining: {
    top: [
      "MY MINING APP RUNNING 24/7",
      "WHEN THE HASHRATE GOES BRRR",
      "ME MINING ALPHAU IN MY SLEEP",
      "PASSIVE INCOME BE LIKE",
      "CHECKING MY MINING REWARDS",
      "THE MINING COMPANION APP",
      "WHEN MINING REWARDS HIT",
      "MY PHONE: *MINING ALPHAU*",
      "ELECTRICITY BILL VS MINING GAINS",
      "MINING SINCE DAY ONE",
    ],
    bottom: [
      "MONEY PRINTER GO BRRR",
      "MAKING MONEY WHILE I SLEEP",
      "STACKING ALPHAU DAILY",
      "HASHRATE: UNLIMITED",
      "PASSIVE INCOME ACHIEVED",
      "THE GRIND NEVER STOPS",
      "REWARDS JUST HIT DIFFERENT",
      "WORTH EVERY WATT",
      "MINING PROFITS: SECURED",
      "EARLY MINER ADVANTAGE",
    ],
  },
  nft: {
    top: [
      "JUST BOUGHT A MYTHIC NFT",
      "MY NFT COLLECTION BE LIKE",
      "WHEN YOUR NFT HAS +40 DAMAGE",
      "COMMON VS MYTHIC NFT OWNERS",
      "100 UNIQUE NFTS AND I WANT THEM ALL",
      "CHECKING MY NFT RARITY",
      "THAT LEGENDARY NFT DROP",
      "MY FIRST ALPHA NFT",
      "NFT MARKETPLACE: *OPENS*",
      "WHEN THE NFT ART IS FIRE",
    ],
    bottom: [
      "RARITY: LEGENDARY",
      "BATTLE ARENA READY",
      "+40 DAMAGE BONUS SECURED",
      "MY WALLET: I'M IN DANGER",
      "GOTTA COLLECT THEM ALL",
      "WORTH EVERY SOL",
      "GAME CHANGER UNLOCKED",
      "NFT FLEXING ACTIVATED",
      "MY WALLET CRIES BUT I SMILE",
      "ART SO GOOD IT HURTS",
    ],
  },
  game: {
    top: [
      "ENTERING ALPHA BATTLE ARENA",
      "MY NFT IN THE FIGHTING GAME",
      "WHEN YOUR NFT WINS THE BATTLE",
      "BITCOIN WARRIOR: *APPEARS*",
      "CHOOSING MY FIGHTER",
      "BATTLE ARENA MODE: ACTIVATED",
      "MY MYTHIC NFT VS THEIR COMMON",
      "WHEN THE COMBO HITS",
      "ARCADE FIGHTING GAME VIBES",
      "MOBILE GAME: COMING SOON",
    ],
    bottom: [
      "FATALITY. ALPHA WINS.",
      "RARITY BONUS: TOO OP",
      "ANOTHER VICTORY FOR ALPHA",
      "ALPHA: I CHOOSE VIOLENCE",
      "EZ CLAP GG NO RE",
      "DAMAGE BONUS: ACTIVATED",
      "THEY NEVER STOOD A CHANCE",
      "PERFECT K.O.",
      "CHAMPION STATUS ACHIEVED",
      "CAN'T WAIT TO PLAY",
    ],
  },
  trading: {
    top: [
      "THE TRADING APP: COMING SOON",
      "PHASE 3: TRADING APPLICATION",
      "AI-POWERED TRADING SIGNALS",
      "WHEN BEGINNERS TRADE LIKE PROS",
      "ONE-CLICK TRADING BE LIKE",
      "NO CHARTS NEEDED",
      "THE APP THAT TRADES FOR YOU",
      "FROM ZERO TO CRYPTO HERO",
      "EXPERT RESULTS FOR BEGINNERS",
      "WAITING FOR THE TRADING APP",
    ],
    bottom: [
      "TRADING JUST GOT EASY",
      "AI DOES THE WORK",
      "PROFESSIONAL RESULTS INCOMING",
      "BEGINNERS WIN TOO NOW",
      "SMART TRADING UNLOCKED",
      "BUY AND SELL LIKE A PRO",
      "THE FUTURE OF TRADING",
      "WORTH THE WAIT",
      "PHASE 3 CAN'T COME SOON ENOUGH",
      "GAME CHANGING TECHNOLOGY",
    ],
  },
  anime: {
    top: [
      "ALPHA VS BITCOIN: EPISODE 1",
      "THE PYRAMID WARRIOR RISES",
      "BITCOIN: WHY WON'T YOU DIE",
      "ALPHA UNLEASHES FINAL FORM",
      "THE MULTI-EYED ALPHA APPEARS",
      "ALPHA: OMAE WA MOU SHINDEIRU",
      "10-PART ANIME BATTLE SERIES",
      "THE EPIC CONFRONTATION",
      "BITCOIN VILLAIN ARC",
      "ALPHA TRANSFORMATION SCENE",
    ],
    bottom: [
      "ALPHA: NANI?!",
      "BITCOIN HAS FALLEN",
      "THE APEX PREDATOR WINS",
      "UNLIMITED POWER UNLEASHED",
      "A NEW KING HAS RISEN",
      "ALPHA UNLIMITED ERA BEGINS",
      "TOTAL VICTORY ACHIEVED",
      "THIS ISN'T EVEN MY FINAL FORM",
      "BITCOIN NEVER RECOVERED",
      "ANIME PROTAGONIST ENERGY",
    ],
  },
  crypto: {
    top: [
      "DIAMOND HANDS ACTIVATED",
      "PAPER HANDS LEFT THE CHAT",
      "WHEN THE MARKET DIPS",
      "HODL GANG RISE UP",
      "THEM: CRYPTO IS A SCAM",
      "BUYING THE DIP AGAIN",
      "MY PORTFOLIO IN A BEAR MARKET",
      "WHEN THEY SAY SELL",
      "FOMO KICKING IN LIKE",
      "DEGEN HOURS: ACTIVATED",
    ],
    bottom: [
      "I HODL FOREVER",
      "THESE HANDS DON'T FOLD",
      "I BUY MORE, OBVIOUSLY",
      "WE DON'T DO THAT HERE",
      "ME: *BUYS MORE*",
      "SALE MEANS BUY",
      "STILL UP FROM ENTRY",
      "I DON'T KNOW WHAT THAT MEANS",
      "TOO LATE, I'M IN",
      "THIS IS FINANCIAL ADVICE",
    ],
  },
  community: {
    top: [
      "WELCOME TO THE ALPHA SQUAD",
      "DISCORD NOTIFICATION: *DINGS*",
      "WHEN A NEW MEMBER JOINS",
      "THE ALPHA COMMUNITY BE LIKE",
      "CHECKING DISCORD AT 2AM",
      "ALPHA UNLIMITED TWITTER POST",
      "THE MEME WEAVER TOOL",
      "CREATING MEMES FOR THE SQUAD",
      "OUR COMMUNITY VS OTHERS",
      "ALPHA SQUAD ASSEMBLE",
    ],
    bottom: [
      "WE'RE BUILT DIFFERENT",
      "BEST COMMUNITY IN CRYPTO",
      "ANOTHER ONE JOINS THE FAM",
      "LFGGGGG",
      "STRONGEST COMMUNITY ENERGY",
      "CAN'T STOP WON'T STOP",
      "SPREADING THE ALPHA WORD",
      "MEME GAME STRONG",
      "COMMUNITY OVER EVERYTHING",
      "UNITED WE HODL",
    ],
  },
  twitter: {
    top: [
      "JUST BOUGHT THE DIP",
      "POV: THE ALGORITHM KNOWS YOU",
      "HOT TAKE: PRIVACY IS OVERRATED",
      "IF YOU'RE NOT PAYING FOR THE PRODUCT",
      "DAILY REMINDER: YOUR DATA LOOKS GREAT",
      "WEB3 ISN'T THE FUTURE",
      "GM TO EVERYONE EXCEPT AD BLOCKERS",
      "SCALING THE UNSCALABLE",
      "WHY TRUST THE PROCESS",
      "JUST PUSHED TO MAIN ON FRIDAY",
      "SLEEP IS FOR THE WEAK",
      "TRANSPARENCY? WE PREFER TRANSLUCENCY",
    ],
    bottom: [
      "AND THE DIP'S DIP. #CRYPTO",
      "BETTER THAN YOU KNOW YOURSELF 👁️",
      "CONVENIENCE IS KING 👑",
      "YOU ARE THE PRODUCT 📈",
      "TODAY ✨ #ALPHAU",
      "WE ARE THE FUTURE #TECH",
      "🚫 #ALPHAUNLIMITED",
      "DISRUPTING THE UNDISRUPTABLE 🚀",
      "WHEN YOU CAN OWN THE PROCESS? 🧠",
      "FEELING DANGEROUS 🔥",
      "UPTIME IS FOR THE ELITE 💻",
      "🌫️ #ALPHAU",
    ],
  },
  linkedin: {
    top: [
      "EXCITED TO ANNOUNCE",
      "LEADERSHIP IS ABOUT WATCHING EVERYONE",
      "HUMBLED TO BE RECOGNIZED",
      "CONNECTING PEOPLE",
      "TURNING 'COMPLIANCE' INTO",
      "WHAT I LEARNED FROM WATCHING",
      "INNOVATION DISTINGUISHES",
      "CULTURE EATS STRATEGY FOR BREAKFAST",
      "GRATEFUL FOR THE OPPORTUNITY",
      "IT'S NOT SURVEILLANCE",
    ],
    bottom: [
      "I'VE SYNERGIZED OUR PARADIGM SHIFTS! 🚀",
      "ALL THE TIME. TRULY INSPIRING 💼",
      "AS 'MOST INVASIVE ALGORITHM' OF 2025! 🏆",
      "WHETHER THEY WANT TO BE OR NOT 🌐",
      "'COMPETITIVE ADVANTAGE'. LET'S CONNECT! 🤝",
      "10 MILLION USERS SIMULTANEOUSLY... 👇",
      "BETWEEN A LEADER AND FOLLOWER. WE TRACK BOTH 📊",
      "AND YOUR DATA FOR LUNCH 🍽️",
      "TO MONETIZE HUMAN BEHAVIOR 🙏",
      "IT'S 'QUALITY ASSURANCE' #BUSINESSTIPS",
    ],
  },
  instagram: {
    top: [
      "FEELING CUTE",
      "LIVING MY BEST SIMULATED LIFE",
      "NO FILTER NEEDED",
      "GOLDEN HOUR?",
      "JUST A CASUAL TUESDAY",
      "WORK HARD, PLAY HARD",
      "AESTHETICS > ETHICS",
      "POV: YOU'RE BEING WATCHED",
      "CURRENT MOOD: OMNISCIENT",
      "MANIFESTING",
    ],
    bottom: [
      "MIGHT DELETE YOUR ACCOUNT LATER ✨👁️",
      "#BLESSED #MATRIX",
      "WHEN YOU CONTROL REALITY 💅",
      "MORE LIKE GOLDEN EYE ☀️👁️",
      "DOMINATING THE DIGITAL LANDSCAPE 💁‍♂️",
      "TRACK EVERYTHING 💪",
      "🎨 #ALPHAU",
      "AND YOU LOVE IT ❤️",
      "🔮 #ALPHAUNLIMITED",
      "TOTAL CONTROL ✨",
    ],
  },
  tiktok: {
    top: [
      "TELL ME YOU'RE AN ILLUMINATI",
      "DAY IN THE LIFE",
      "SHEESH! THE DATA STREAM",
      "WE REALLY GOT TOTAL SURVEILLANCE",
      "ALGORITHM CHECK!",
      "NOT ME ACCIDENTALLY DELETING",
      "POV: THE FBI AGENT",
      "GASLIGHT, GATEKEEP, GIRLBOSS",
      "MAIN CHARACTER ENERGY?",
    ],
    bottom: [
      "WITHOUT TELLING ME... I'LL GO FIRST 👁️",
      "OF A SENTIENT ALGORITHM 🤖✨",
      "IS BUSSIN TODAY RESPECTFULLY 🔥",
      "BEFORE GTA 6 💀",
      "IF YOU SEE THIS, WE KNOW WHERE YOU LIVE 🏠",
      "THE ENTIRE ECONOMY 🤪 OOPS",
      "WATCHING MY CAMERA 👁️👄👁️",
      "THE DATABASE 💅",
      "NO, MAINFRAME ENERGY 🖥️",
    ],
  },
  memeos: {
    top: [
      "WE SEE EVERYTHING",
      "SYNERGY IS JUST A FANCY WORD",
      "YOUR PRIVACY IS OUR PRIORITY",
      "INVEST IN THE TRIANGLE",
      "DATA DOESN'T LIE",
      "THE ALL-SEEING EYE",
      "ALWAYS WATCHING",
      "TRUST THE PROCESS",
      "WE'RE DISRUPTING THE DISRUPTION",
      "THINKING OUTSIDE THE BOX?",
      "BIG BROTHER IS ACTUALLY",
      "WE DON'T PREDICT THE FUTURE",
      "THE BLOCKCHAIN REMEMBERS",
      "404: PRIVACY NOT FOUND",
      "MACHINE LEARNING?",
      "THE CLOUD IS JUST",
      "GIT COMMIT -M",
      "FEEDBACK IS A GIFT",
    ],
    bottom: [
      "ESPECIALLY YOUR BROWSER HISTORY 👁️",
      "FOR COMPLIANCE 🔺",
      "TO MONETIZE 💰",
      "IT'S THE STRONGEST SHAPE 📐",
      "BUT WE DO 😈",
      "NEEDS A COFFEE BREAK ☕",
      "ALWAYS OPTIMIZING 🔄",
      "TRUST THE TRIANGLE 🔺",
      "DISRUPTION² 💥",
      "WE OWN THE BOX 📦",
      "YOUR CEO 👔",
      "WE MANUFACTURE IT 🏭",
      "WHAT YOU DID ⛓️",
      "🚫 ERROR",
      "NO, MACHINE LEADING 🤖",
      "SOMEONE ELSE'S COMPUTER (OURS) ☁️",
      "'FIXED FREE WILL' 💻",
      "RECEIPT NOT INCLUDED 🧾",
    ],
  },
};

const getRandomText = (category: string, position: "top" | "bottom"): string => {
  if (category === "all") {
    const categories = Object.keys(MEME_TEXT_DATABASE);
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const texts = MEME_TEXT_DATABASE[randomCategory as keyof typeof MEME_TEXT_DATABASE][position];
    return texts[Math.floor(Math.random() * texts.length)];
  }
  const texts = MEME_TEXT_DATABASE[category as keyof typeof MEME_TEXT_DATABASE]?.[position] || [];
  return texts[Math.floor(Math.random() * texts.length)] || "ALPHA UNLIMITED";
};

const FONT_OPTIONS = [
  { name: "Impact", value: "Impact, sans-serif" },
  { name: "Arial Black", value: "Arial Black, sans-serif" },
  { name: "Comic Sans", value: "Comic Sans MS, cursive" },
  { name: "Orbitron", value: "Orbitron, sans-serif" },
  { name: "Bebas Neue", value: "Bebas Neue, sans-serif" },
  { name: "Bangers", value: "Bangers, cursive" },
  { name: "Permanent Marker", value: "Permanent Marker, cursive" },
  { name: "Oswald", value: "Oswald, sans-serif" },
];

const COLOR_PRESETS = [
  { name: "White", value: "#FFFFFF" },
  { name: "Gold", value: "#FFD700" },
  { name: "Red", value: "#FF0000" },
  { name: "Cyan", value: "#00D9FF" },
  { name: "Purple", value: "#9B59B6" },
  { name: "Green", value: "#00FF00" },
  { name: "Orange", value: "#FF6B00" },
  { name: "Pink", value: "#FF69B4" },
];

const STROKE_PRESETS = [
  { name: "Black", value: "#000000" },
  { name: "White", value: "#FFFFFF" },
  { name: "Gold", value: "#FFD700" },
  { name: "Dark Red", value: "#8B0000" },
  { name: "Dark Blue", value: "#00008B" },
  { name: "None", value: "transparent" },
];

export default function AlphaForge() {
  const { toast } = useToast();
  const [topText, setTopText] = useState("WHEN YOU DISCOVER ALPHAU");
  const [bottomText, setBottomText] = useState("AND REALIZE THE POTENTIAL");
  const [templateIndex, setTemplateIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const [selectedFont, setSelectedFont] = useState(FONT_OPTIONS[0].value);
  const [textColor, setTextColor] = useState("#FFFFFF");
  const [strokeColor, setStrokeColor] = useState("#000000");
  const [customTextColor, setCustomTextColor] = useState("#FFFFFF");
  const [customStrokeColor, setCustomStrokeColor] = useState("#000000");

  const selectedTemplate = MEME_TEMPLATES[templateIndex];

  const copyQuote = useCallback(() => {
    const fullQuote = `${topText} ${bottomText}`;
    navigator.clipboard.writeText(fullQuote);
    setCopied(true);
    toast({ title: "Copied!", description: "Quote copied to clipboard" });
    setTimeout(() => setCopied(false), 2000);
  }, [topText, bottomText, toast]);

  const nextTemplate = () => {
    setTemplateIndex((prev) => (prev + 1) % MEME_TEMPLATES.length);
  };

  const prevTemplate = () => {
    setTemplateIndex((prev) => (prev - 1 + MEME_TEMPLATES.length) % MEME_TEMPLATES.length);
  };

  const generateRandomMeme = useCallback(() => {
    setIsGenerating(true);
    const randomTop = getRandomText(selectedCategory, "top");
    const randomBottom = getRandomText(selectedCategory, "bottom");
    
    setTimeout(() => {
      setTopText(randomTop);
      setBottomText(randomBottom);
      setIsGenerating(false);
    }, 300);
  }, [selectedCategory]);

  const [isRandomizing, setIsRandomizing] = useState(false);

  const randomizeAll = useCallback(() => {
    setIsRandomizing(true);
    const randomTemplateIndex = Math.floor(Math.random() * MEME_TEMPLATES.length);
    const categories = Object.keys(MEME_TEXT_DATABASE);
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const randomTop = getRandomText(randomCategory, "top");
    const randomBottom = getRandomText(randomCategory, "bottom");
    
    setTimeout(() => {
      setTemplateIndex(randomTemplateIndex);
      setTopText(randomTop);
      setBottomText(randomBottom);
      setSelectedCategory(randomCategory);
      setIsRandomizing(false);
      toast({ title: "Randomized!", description: "New template, captions & category applied" });
    }, 400);
  }, [toast]);

  const getMemeDataUrl = useCallback(async (): Promise<string> => {
    return new Promise((resolve, reject) => {
      const canvas = canvasRef.current;
      if (!canvas) {
        reject("Canvas not found");
        return;
      }
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject("Context not found");
        return;
      }

      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const width = img.width || 800;
        const height = img.height || 800;
        canvas.width = width;
        canvas.height = height;

        ctx.drawImage(img, 0, 0, width, height);

        const textFontSize = Math.floor(width / 12);
        ctx.font = `bold ${textFontSize}px ${selectedFont}`;
        ctx.textAlign = "center";
        ctx.fillStyle = textColor;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeColor === "transparent" ? 0 : Math.max(3, textFontSize / 15);

        const wrapText = (text: string, maxWidth: number) => {
          const words = text.split(' ');
          const lines: string[] = [];
          let currentLine = '';

          words.forEach(word => {
            const testLine = currentLine ? `${currentLine} ${word}` : word;
            const metrics = ctx.measureText(testLine);
            if (metrics.width > maxWidth && currentLine) {
              lines.push(currentLine);
              currentLine = word;
            } else {
              currentLine = testLine;
            }
          });
          if (currentLine) lines.push(currentLine);
          return lines;
        };

        const topLines = wrapText(topText.toUpperCase(), width * 0.9);
        const bottomLines = wrapText(bottomText.toUpperCase(), width * 0.9);

        topLines.forEach((line, i) => {
          const y = textFontSize + 20 + (i * textFontSize * 1.1);
          ctx.strokeText(line, width / 2, y);
          ctx.fillText(line, width / 2, y);
        });

        bottomLines.forEach((line, i) => {
          const y = height - 30 - ((bottomLines.length - 1 - i) * textFontSize * 1.1);
          ctx.strokeText(line, width / 2, y);
          ctx.fillText(line, width / 2, y);
        });

        resolve(canvas.toDataURL("image/png"));
      };
      img.onerror = () => reject("Failed to load image");
      img.src = selectedTemplate.image;
    });
  }, [topText, bottomText, selectedTemplate, selectedFont, textColor, strokeColor]);

  const downloadMeme = useCallback(async () => {
    setIsDownloading(true);
    try {
      const dataUrl = await getMemeDataUrl();
      const filename = `alphau-meme-${Date.now()}.png`;
      
      // Create a hidden form and submit it to trigger native browser download
      const form = document.createElement("form");
      form.method = "POST";
      form.action = "/api/meme/download";
      form.style.display = "none";
      
      const imageInput = document.createElement("input");
      imageInput.type = "hidden";
      imageInput.name = "imageData";
      imageInput.value = dataUrl;
      form.appendChild(imageInput);
      
      const filenameInput = document.createElement("input");
      filenameInput.type = "hidden";
      filenameInput.name = "filename";
      filenameInput.value = filename;
      form.appendChild(filenameInput);
      
      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
      
      toast({ title: "Downloading!", description: "Check your downloads" });
    } catch (error) {
      toast({ title: "Error", description: "Download failed. Try again.", variant: "destructive" });
    }
    setIsDownloading(false);
  }, [getMemeDataUrl, toast]);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <TradingPlatformLayout>
      
      <main className="flex-1 pt-20">
        <div className="container mx-auto px-4 py-6 max-w-lg">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <h1 
              className="text-3xl md:text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600 bg-clip-text text-transparent flex items-center justify-center gap-2"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
              data-testid="text-memeweaver-title"
            >
              <Wand2 className="w-8 h-8 text-yellow-500" />
              Alpha Forge
            </h1>
            <p className="text-sm text-gray-400">
              {MEME_TEMPLATES.length} templates • Tap arrows to browse
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="relative mb-6"
          >
            <div className="relative rounded-xl overflow-hidden bg-gray-900 mx-auto max-w-[350px]">
              <img 
                src={selectedTemplate.image} 
                alt={selectedTemplate.name}
                className="w-full h-auto object-contain max-h-[70vh]"
              />
              
              <div 
                className="absolute top-3 left-0 right-0 text-center px-4"
                style={{
                  fontFamily: selectedFont,
                  fontSize: "clamp(14px, 5vw, 20px)",
                  color: textColor,
                  textShadow: strokeColor === "transparent" 
                    ? "none" 
                    : `2px 2px 0 ${strokeColor}, -2px -2px 0 ${strokeColor}, 2px -2px 0 ${strokeColor}, -2px 2px 0 ${strokeColor}`,
                  textTransform: "uppercase",
                  fontWeight: "bold",
                  wordBreak: "break-word",
                  lineHeight: 1.2,
                }}
              >
                {topText}
              </div>
              
              <div 
                className="absolute bottom-3 left-0 right-0 text-center px-4"
                style={{
                  fontFamily: selectedFont,
                  fontSize: "clamp(14px, 5vw, 20px)",
                  color: textColor,
                  textShadow: strokeColor === "transparent" 
                    ? "none" 
                    : `2px 2px 0 ${strokeColor}, -2px -2px 0 ${strokeColor}, 2px -2px 0 ${strokeColor}, -2px 2px 0 ${strokeColor}`,
                  textTransform: "uppercase",
                  fontWeight: "bold",
                  wordBreak: "break-word",
                  lineHeight: 1.2,
                }}
              >
                {bottomText}
              </div>

              <button
                onClick={prevTemplate}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center text-white transition-all"
                data-testid="button-prev-template"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextTemplate}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center text-white transition-all"
                data-testid="button-next-template"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            <p className="text-center text-sm text-gray-400 mt-2">
              {templateIndex + 1} / {MEME_TEMPLATES.length} • {selectedTemplate.name}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <div 
              className="mb-4 rounded-xl p-4 border-2"
              style={{ 
                background: '#0a0a0a', 
                borderColor: '#FFD700',
                fontFamily: "'Courier New', monospace"
              }}
            >
              <h2 className="text-lg font-bold mb-3 flex items-center gap-2" style={{ color: '#FFD700' }}>
                👁️ MEME QUOTE GENERATOR
              </h2>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full p-2.5 rounded-md mb-3 text-sm"
                style={{ 
                  background: '#1a1a1a', 
                  color: '#FFD700', 
                  border: '1px solid #FFD700' 
                }}
                data-testid="select-category"
              >
                {MEME_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </option>
                ))}
              </select>

              <button
                onClick={randomizeAll}
                disabled={isRandomizing}
                className="w-full py-3 rounded-md font-bold text-sm flex items-center justify-center gap-2 mb-3 transition-all hover:scale-[1.02]"
                style={{ 
                  background: 'linear-gradient(135deg, #9B59B6 0%, #8E44AD 50%, #6C3483 100%)', 
                  color: '#fff',
                  opacity: isRandomizing ? 0.7 : 1,
                  boxShadow: '0 4px 15px rgba(155, 89, 182, 0.4)'
                }}
                data-testid="button-randomize-all"
              >
                {isRandomizing ? (
                  <Shuffle className="w-5 h-5 animate-spin" />
                ) : (
                  <Shuffle className="w-5 h-5" />
                )}
                RANDOMIZE ALL
              </button>

              <div 
                className="rounded-lg p-4 mb-3 min-h-[80px] text-sm italic"
                style={{ background: '#1a1a1a', color: '#fff' }}
                data-testid="quote-display"
              >
                <p className="mb-1" style={{ color: '#FFD700' }}>// TOP:</p>
                <p className="mb-2">"{topText}"</p>
                <p className="mb-1" style={{ color: '#FFD700' }}>// BOTTOM:</p>
                <p>"{bottomText}"</p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={generateRandomMeme}
                  disabled={isGenerating}
                  className="flex-1 py-3 rounded-md font-bold text-sm flex items-center justify-center gap-2 transition-all"
                  style={{ 
                    background: '#FFD700', 
                    color: '#000',
                    opacity: isGenerating ? 0.7 : 1
                  }}
                  data-testid="button-generate-meme"
                >
                  {isGenerating ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    "🔄"
                  )}
                  GENERATE
                </button>
                <button
                  onClick={copyQuote}
                  className="flex-1 py-3 rounded-md font-bold text-sm flex items-center justify-center gap-2 transition-all"
                  style={{ 
                    background: 'transparent', 
                    color: '#FFD700',
                    border: '2px solid #FFD700'
                  }}
                  data-testid="button-copy-quote"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? "COPIED!" : "COPY"}
                </button>
              </div>
            </div>

            <Card className="bg-gray-900/80 border border-yellow-500/30 mb-4">
              <CardContent className="p-4">
                <h3 className="text-sm font-bold text-white mb-3">✏️ Edit Text Manually</h3>
                <div className="space-y-3">
                  <div>
                    <Label className="text-gray-400 text-xs">Top Text</Label>
                    <Input
                      value={topText}
                      onChange={(e) => setTopText(e.target.value)}
                      placeholder="Enter top text..."
                      className="bg-gray-800 border-gray-700 text-white text-sm"
                      data-testid="input-top-text"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400 text-xs">Bottom Text</Label>
                    <Input
                      value={bottomText}
                      onChange={(e) => setBottomText(e.target.value)}
                      placeholder="Enter bottom text..."
                      className="bg-gray-800 border-gray-700 text-white text-sm"
                      data-testid="input-bottom-text"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/80 border border-yellow-500/30 mb-4">
              <CardContent className="p-4">
                <h3 className="text-sm font-bold text-white mb-3">🎨 Style Customization</h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-gray-400 text-xs mb-2 block">Font Style</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {FONT_OPTIONS.map((font) => (
                        <button
                          key={font.value}
                          onClick={() => setSelectedFont(font.value)}
                          className={`py-2 px-3 rounded text-xs font-medium transition-all ${
                            selectedFont === font.value
                              ? "bg-yellow-500 text-black"
                              : "bg-gray-800 text-gray-300 hover:bg-gray-700"
                          }`}
                          style={{ fontFamily: font.value }}
                          data-testid={`font-${font.name.toLowerCase().replace(/\s/g, "-")}`}
                        >
                          {font.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-400 text-xs mb-2 block">Text Color</Label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {COLOR_PRESETS.map((color) => (
                        <button
                          key={color.value}
                          onClick={() => {
                            setTextColor(color.value);
                            setCustomTextColor(color.value);
                          }}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${
                            textColor === color.value
                              ? "border-yellow-400 scale-110"
                              : "border-gray-600 hover:border-gray-400"
                          }`}
                          style={{ backgroundColor: color.value }}
                          title={color.name}
                          data-testid={`color-text-${color.name.toLowerCase()}`}
                        />
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <Label className="text-gray-500 text-xs">Custom:</Label>
                      <input
                        type="color"
                        value={customTextColor}
                        onChange={(e) => {
                          setCustomTextColor(e.target.value);
                          setTextColor(e.target.value);
                        }}
                        className="w-8 h-8 rounded cursor-pointer border border-gray-600"
                        data-testid="input-custom-text-color"
                      />
                      <span className="text-gray-500 text-xs">{textColor}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-400 text-xs mb-2 block">Outline Color</Label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {STROKE_PRESETS.map((color) => (
                        <button
                          key={color.value}
                          onClick={() => {
                            setStrokeColor(color.value);
                            if (color.value !== "transparent") {
                              setCustomStrokeColor(color.value);
                            }
                          }}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${
                            strokeColor === color.value
                              ? "border-yellow-400 scale-110"
                              : "border-gray-600 hover:border-gray-400"
                          } ${color.value === "transparent" ? "bg-gradient-to-br from-gray-800 via-gray-600 to-gray-800" : ""}`}
                          style={{ backgroundColor: color.value === "transparent" ? undefined : color.value }}
                          title={color.name}
                          data-testid={`color-stroke-${color.name.toLowerCase().replace(/\s/g, "-")}`}
                        >
                          {color.value === "transparent" && <span className="text-red-500 text-lg">/</span>}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <Label className="text-gray-500 text-xs">Custom:</Label>
                      <input
                        type="color"
                        value={customStrokeColor}
                        onChange={(e) => {
                          setCustomStrokeColor(e.target.value);
                          setStrokeColor(e.target.value);
                        }}
                        className="w-8 h-8 rounded cursor-pointer border border-gray-600"
                        data-testid="input-custom-stroke-color"
                      />
                      <span className="text-gray-500 text-xs">{strokeColor === "transparent" ? "None" : strokeColor}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mb-4">
              <Button
                onClick={downloadMeme}
                disabled={isDownloading}
                className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 py-6 text-lg font-bold text-black"
                data-testid="button-download-meme"
              >
                {isDownloading ? (
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                ) : (
                  <Download className="w-5 h-5 mr-2" />
                )}
                Download Meme
              </Button>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Save to your phone, then share from your gallery
              </p>
            </div>

          </motion.div>

          <canvas ref={canvasRef} className="hidden" />
        </div>
      </main>

      </TradingPlatformLayout>
    </div>
  );
}
