/**
 * Quantum Market Genome Engine™ (QMGE) - Standalone Software Product Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This file contains proprietary product information, pricing, marketing content,
 * and UI/UX design for the Quantum Market Genome Engine™ standalone software product.
 * All content is exclusive intellectual property of Alpha Unlimited Trading Company.
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link, useSearch } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  Dna, DollarSign, Droplets, Flame, Fingerprint, Gauge,
  Activity, Globe, Play, Download, FileText, CheckCircle,
  Shield, Zap, Target, Clock, TrendingUp, Eye, Layers,
  Network, ArrowRight, Crown, Cpu, Settings, Key, Monitor,
  ArrowUp, Sparkles, Server, Link2, ExternalLink, ChevronDown,
  ChevronUp, AlertTriangle, Copy, BarChart3, Bell, Search,
  Maximize2, RefreshCw, LineChart, PieChart, Layout, Wallet,
  ShoppingCart, Loader2, Lock
} from "lucide-react";
import { PageShareBar } from "@/components/PageShareBar";

const DIMENSIONS = [
  { name: "Capital Flow Dynamics", icon: DollarSign, color: "#22c55e", score: 78 },
  { name: "Liquidity Topology", icon: Droplets, color: "#3b82f6", score: 65 },
  { name: "Derivatives Pressure", icon: Flame, color: "#f97316", score: 82 },
  { name: "Whale Behavioral DNA", icon: Fingerprint, color: "#a855f7", score: 71 },
  { name: "Sentiment Velocity", icon: Gauge, color: "#eab308", score: 56 },
  { name: "Network Health", icon: Activity, color: "#06b6d4", score: 88 },
  { name: "Macro Correlation Matrix", icon: Globe, color: "#ec4899", score: 43 },
];

const WHY_CARDS = [
  {
    icon: Layers,
    title: "7 Dimensions vs 1",
    description: "Traditional indicators analyze one dimension. QMGE analyzes seven simultaneously, revealing market structures invisible to single-layer tools.",
  },
  {
    icon: Target,
    title: "Up to 100% Validated Accuracy",
    description: "Tested across 5 competitor time periods (2022-2025) using their same methodology. Scores 93-100% vs Tickeron (89%), 100% vs InvestIQ (91%), 97-100% vs Learn2Trade (82%), and 79-86% vs 3Commas (65%).",
  },
  {
    icon: Dna,
    title: "Genome Pattern Recognition",
    description: "15+ proprietary patterns (Alpha Surge, Whale Convergence, Liquidity Cascade, etc.) that no other software can detect.",
  },
  {
    icon: Cpu,
    title: "Adaptive Intelligence",
    description: "Weights auto-adjust per asset and market regime. Bitcoin analysis differs from altcoin analysis automatically.",
  },
  {
    icon: Globe,
    title: "Works Anywhere",
    description: "Standalone software connects to YOUR exchange. No Alpha Unlimited account required to run the engine.",
  },
  {
    icon: Monitor,
    title: "Real-Time Monitoring",
    description: "Live genome map with convergence index, mutation rate, and dominant dimension display updating continuously.",
  },
];

const PRICING_TIERS = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    badge: null,
    highlighted: false,
    features: [
      "2 of 7 dimensions (Capital Flow + Liquidity Topology)",
      "Delayed data (15-min delay)",
      "1 exchange connection",
      "Basic genome patterns only",
      "Community support",
    ],
    buttonText: "Download Free Version",
    testId: "button-download-free",
    isPaid: false,
  },
  {
    name: "Monthly",
    price: "$179",
    period: "/month",
    badge: "Most Popular",
    highlighted: true,
    features: [
      "All 7 dimensions",
      "Real-time data",
      "Unlimited exchange connections",
      "15+ genome patterns",
      "Adaptive weight calibration",
      "Convergence & mutation analysis",
      "Priority email support",
    ],
    buttonText: "Subscribe Monthly",
    testId: "button-subscribe-monthly",
    isPaid: true,
  },
  {
    name: "Annual",
    price: "$1,499",
    period: "/year",
    badge: "SAVE 30%",
    highlighted: false,
    features: [
      "Everything in Monthly",
      "2 months free",
      "Priority support",
      "Early access to new features",
    ],
    buttonText: "Subscribe Annually",
    testId: "button-subscribe-annual",
    isPaid: true,
  },
  {
    name: "Lifetime",
    price: "$2,997",
    period: "one-time",
    badge: "BEST VALUE",
    highlighted: false,
    features: [
      "Everything in Annual",
      "Lifetime updates forever",
      "Lifetime priority support",
      "Founding member status",
    ],
    buttonText: "Buy Lifetime License",
    testId: "button-buy-lifetime",
    isPaid: true,
  },
];

const CONNECT_STEPS = [
  { step: 1, icon: Download, title: "Download QMGE standalone software" },
  { step: 2, icon: Key, title: "Enter your exchange API keys (read-only recommended)" },
  { step: 3, icon: Settings, title: "Select your trading pair" },
  { step: 4, icon: Zap, title: "QMGE immediately starts analyzing all 7 dimensions" },
];

const SUPPORTED_EXCHANGES = [
  { name: "Binance", color: "#F0B90B", tier: "full", pairs: "600+", region: "Global" },
  { name: "Coinbase", color: "#0052FF", tier: "full", pairs: "250+", region: "US/EU" },
  { name: "Kraken", color: "#5741D9", tier: "full", pairs: "300+", region: "Global" },
  { name: "Bybit", color: "#F7A600", tier: "full", pairs: "450+", region: "Global" },
  { name: "OKX", color: "#FFFFFF", tier: "full", pairs: "500+", region: "Global" },
  { name: "Binance.US", color: "#F0B90B", tier: "full", pairs: "150+", region: "US" },
  { name: "KuCoin", color: "#23AF91", tier: "full", pairs: "700+", region: "Global" },
  { name: "Gate.io", color: "#2354E6", tier: "full", pairs: "1400+", region: "Global" },
  { name: "Bitget", color: "#00F0FF", tier: "full", pairs: "400+", region: "Global" },
  { name: "MEXC", color: "#2EBD85", tier: "full", pairs: "1500+", region: "Global" },
  { name: "HTX (Huobi)", color: "#2B6BF3", tier: "full", pairs: "500+", region: "Global" },
  { name: "Bitfinex", color: "#16B157", tier: "full", pairs: "300+", region: "Global" },
  { name: "Gemini", color: "#00DCFA", tier: "full", pairs: "100+", region: "US" },
  { name: "Bitstamp", color: "#5EAF24", tier: "full", pairs: "80+", region: "EU" },
  { name: "Crypto.com", color: "#103F68", tier: "full", pairs: "250+", region: "Global" },
  { name: "Deribit", color: "#5BCA6F", tier: "derivatives", pairs: "50+", region: "Global" },
  { name: "BitMEX", color: "#FF0000", tier: "derivatives", pairs: "40+", region: "Global" },
  { name: "PrimeXBT", color: "#28A8E5", tier: "full", pairs: "30+", region: "Global" },
  { name: "Phemex", color: "#D0F223", tier: "full", pairs: "200+", region: "Global" },
  { name: "LBank", color: "#1C6EF9", tier: "full", pairs: "600+", region: "Global" },
  { name: "CoinEx", color: "#3FAEFD", tier: "full", pairs: "500+", region: "Global" },
];

const EXCHANGE_GUIDES: { name: string; steps: string[]; apiUrl: string; notes: string }[] = [
  {
    name: "Binance",
    steps: [
      "Log in to your Binance account at binance.com",
      "Go to Profile > API Management",
      "Click 'Create API' and choose 'System Generated'",
      "Label it 'QMGE Standalone' and complete 2FA verification",
      "IMPORTANT: Enable only 'Enable Reading' permission — disable trading & withdrawals",
      "Copy your API Key and Secret Key",
      "Paste both keys into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://binance.com/en/my/settings/api-management",
    notes: "For Binance.US users, use api.binance.us instead. IP restriction recommended for extra security.",
  },
  {
    name: "Coinbase",
    steps: [
      "Log in to Coinbase at coinbase.com",
      "Go to Settings > API Access",
      "Click 'New API Key'",
      "Select the portfolio/account you want to monitor",
      "Under permissions, select ONLY 'View' (read-only access)",
      "Set a passphrase and complete 2FA verification",
      "Copy your API Key, API Secret, and Passphrase",
      "Enter all three into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://coinbase.com/settings/api",
    notes: "Coinbase Advanced Trade API is also supported. Coinbase requires a passphrase in addition to API key and secret.",
  },
  {
    name: "Kraken",
    steps: [
      "Log in to Kraken at kraken.com",
      "Navigate to Security > API",
      "Click 'Add Key'",
      "Name it 'QMGE' and check ONLY 'Query Funds' and 'Query Open Orders & Trades'",
      "DO NOT enable 'Create & Modify Orders' or 'Withdraw Funds'",
      "Complete 2FA verification",
      "Copy the API Key and Private Key",
      "Paste both into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://kraken.com/u/security/api",
    notes: "Kraken uses 'Private Key' instead of 'Secret'. Nonce window may need adjustment if you see sync errors.",
  },
  {
    name: "Bybit",
    steps: [
      "Log in to Bybit at bybit.com",
      "Go to Account & Security > API Management",
      "Click 'Create New Key' and select 'System-generated API Keys'",
      "Name it 'QMGE Standalone'",
      "Set permissions to 'Read-Only' — no trading or withdrawal access",
      "Set IP restriction if desired for extra security",
      "Copy the API Key and Secret Key",
      "Enter both into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://bybit.com/user/api-management",
    notes: "Bybit supports both Spot and Derivatives data. QMGE will automatically detect available markets.",
  },
  {
    name: "OKX",
    steps: [
      "Log in to OKX at okx.com",
      "Navigate to Account > API",
      "Click 'Create V5 API Key'",
      "Set a label 'QMGE', enter your passphrase",
      "Under permissions, select 'Read Only' — no trade or withdrawal",
      "Complete verification",
      "Copy API Key, Secret Key, and Passphrase",
      "Enter all three into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://okx.com/account/my-api",
    notes: "OKX requires a passphrase similar to Coinbase. Make sure to use V5 API keys.",
  },
  {
    name: "KuCoin",
    steps: [
      "Log in to KuCoin at kucoin.com",
      "Go to Account Security > API Management",
      "Click 'Create API'",
      "Name it 'QMGE' and set a passphrase",
      "Select 'General' permission only — disable 'Trade' and 'Transfer'",
      "Set IP restriction (optional but recommended)",
      "Copy API Key, API Secret, and API Passphrase",
      "Enter all three into QMGE's Exchange Connection panel",
    ],
    apiUrl: "https://kucoin.com/account/api",
    notes: "KuCoin requires a passphrase. Their API has separate Spot and Futures endpoints — QMGE handles both automatically.",
  },
];

const INTERFACE_PANELS = [
  { name: "Genome Map", icon: Dna, description: "Live 7-dimension radar with real-time scores" },
  { name: "Pattern Scanner", icon: Search, description: "Detects 15+ genome patterns automatically" },
  { name: "Signal Dashboard", icon: BarChart3, description: "Buy/Sell/Hold signals with confidence %" },
  { name: "Convergence Monitor", icon: Activity, description: "Track convergence index and mutation rate" },
  { name: "Multi-Pair Grid", icon: Layout, description: "Analyze multiple pairs side by side" },
  { name: "Alert Center", icon: Bell, description: "Custom alerts on pattern detection or score thresholds" },
  { name: "Exchange Feed", icon: Server, description: "Live order book and trade data from your exchange" },
  { name: "Performance Log", icon: LineChart, description: "Historical accuracy of QMGE predictions" },
];

interface LicenseData {
  id: number;
  licenseKey: string;
  tier: string;
  status: string;
  dimensionsUnlocked: number;
  dataDelay: number;
  patternsUnlocked: number;
  exchangeLimit: number;
  totalUsageMinutes: number;
  maxUsageMinutes: number;
  remainingMinutes: number;
  trialExpiresAt: string | null;
  trialTimeLeftMinutes: number;
  vpnBlocked: boolean;
  vpnDetectedCount: number;
  createdAt: string;
}

export default function QMGEStandalone() {
  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();
  const [expandedGuide, setExpandedGuide] = useState<string | null>(null);
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [showStickyCTA, setShowStickyCTA] = useState(false);
  const [license, setLicense] = useState<LicenseData | null>(null);
  const [licenseLoading, setLicenseLoading] = useState(false);
  const [hasLicense, setHasLicense] = useState(false);
  const [isExpired, setIsExpired] = useState(false);
  const [activating, setActivating] = useState(false);
  const [vpnWarning, setVpnWarning] = useState<string | null>(null);
  const [licenseModal, setLicenseModal] = useState<{
    show: boolean;
    licenseKey: string;
    tier: string;
    type: "activated" | "purchased";
  } | null>(null);
  const [keyCopied, setKeyCopied] = useState(false);
  const searchString = useSearch();

  const fetchLicense = async () => {
    if (!user) return;
    setLicenseLoading(true);
    try {
      const resp = await fetch("/api/qmge/license");
      if (resp.ok) {
        const data = await resp.json();
        setHasLicense(data.hasLicense);
        setLicense(data.license || null);
        setIsExpired(data.isExpired || false);
      }
    } catch {} finally { setLicenseLoading(false); }
  };

  useEffect(() => {
    document.title = "QMGE Standalone Software - Quantum Market Genome Engine™";
  }, []);

  useEffect(() => { fetchLicense(); }, [user]);

  useEffect(() => {
    const params = new URLSearchParams(searchString);
    if (params.get("purchase") === "success") {
      const plan = params.get("plan") || "";
      (async () => {
        try {
          const resp = await fetch("/api/qmge/license/upgrade", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ plan }),
          });
          const data = await resp.json();
          await fetchLicense();
          if (resp.ok && data?.license?.licenseKey) {
            setLicenseModal({
              show: true,
              licenseKey: data.license.licenseKey,
              tier: plan,
              type: "purchased",
            });
          } else if (!resp.ok) {
            toast({
              title: "Upgrade Issue",
              description: data?.message || "Could not verify purchase. Check your account for license details.",
            });
          }
        } catch {
          await fetchLicense();
          toast({
            title: "Error",
            description: "Something went wrong verifying your purchase. Your license key is available on your Account page.",
          });
        }
      })();
    } else if (params.get("purchase") === "cancelled") {
      toast({
        title: "Purchase Cancelled",
        description: "Your checkout was cancelled. You can try again anytime.",
      });
    }
  }, [searchString]);

  useEffect(() => {
    if (!license || license.tier === "free") return;
    return;
  }, [license]);

  useEffect(() => {
    if (!license || !hasLicense || license.tier !== "free" || isExpired) return;
    const interval = setInterval(async () => {
      try {
        const resp = await fetch("/api/qmge/license/heartbeat", { method: "POST" });
        if (resp.status === 403) {
          const data = await resp.json();
          setVpnWarning(data.message);
        } else if (resp.ok) {
          setVpnWarning(null);
          const data = await resp.json();
          if (data.expired) {
            setIsExpired(true);
            fetchLicense();
          }
        }
      } catch {}
    }, 300000);
    return () => clearInterval(interval);
  }, [license, hasLicense, isExpired]);

  useEffect(() => {
    const handleScroll = () => {
      setShowStickyCTA(window.scrollY > 600);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const handlePurchase = async (plan: "monthly" | "annual" | "lifetime") => {
    if (!user) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to purchase QMGE Standalone software.",
      });
      return;
    }

    setCheckoutLoading(plan);
    try {
      const response = await fetch("/api/qmge/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });

      const data = await response.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to start checkout. Please try again.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
      });
    } finally {
      setCheckoutLoading(null);
    }
  };

  const triggerQMGEDownload = async () => {
    try {
      const resp = await fetch("/api/qmge/download");
      if (!resp.ok) {
        const data = await resp.json();
        toast({ title: "Download Failed", description: data.message || "Could not download QMGE.", variant: "destructive" });
        return;
      }
      const blob = await resp.blob();
      const disposition = resp.headers.get("Content-Disposition") || "";
      const filenameMatch = disposition.match(/filename="?([^"]+)"?/);
      const filename = filenameMatch ? filenameMatch[1] : "QMGE-Standalone.html";
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: "Download Started", description: "QMGE Standalone is downloading. Open the file in any browser to start." });
    } catch {
      toast({ title: "Download Failed", description: "Something went wrong. Please try again.", variant: "destructive" });
    }
  };

  const handleFreeDownload = async () => {
    if (!user) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to activate the free version of QMGE.",
      });
      return;
    }

    if (hasLicense && license) {
      if (isExpired) {
        toast({
          title: "Trial Expired",
          description: "Your free trial has ended. Purchase a license to unlock full QMGE.",
        });
        scrollTo("pricing");
        return;
      }
      await triggerQMGEDownload();
      return;
    }

    setActivating(true);
    setVpnWarning(null);
    try {
      const resp = await fetch("/api/qmge/license/activate", { method: "POST" });
      const data = await resp.json();
      if (resp.status === 403 && data.vpnDetected) {
        setVpnWarning(data.message);
        toast({
          title: "VPN Detected",
          description: data.message,
          variant: "destructive",
        });
        return;
      }
      if (!resp.ok) {
        if (data.licenseKey) {
          setLicenseModal({
            show: true,
            licenseKey: data.licenseKey,
            tier: "free",
            type: "activated",
          });
          fetchLicense();
          return;
        }
        toast({ title: "Error", description: data.message || "Failed to activate trial." });
        return;
      }
      setLicenseModal({
        show: true,
        licenseKey: data.license.licenseKey,
        tier: "free",
        type: "activated",
      });
      fetchLicense();
      setTimeout(() => triggerQMGEDownload(), 2000);
    } catch {
      toast({ title: "Error", description: "Something went wrong. Please try again." });
    } finally {
      setActivating(false);
    }
  };

  const formatTimeLeft = (minutes: number) => {
    if (minutes <= 0) return "Expired";
    const days = Math.floor(minutes / 1440);
    const hrs = Math.floor((minutes % 1440) / 60);
    const mins = minutes % 60;
    if (days > 0) return `${days}d ${hrs}h left`;
    if (hrs > 0) return `${hrs}h ${mins}m left`;
    return `${mins}m left`;
  };

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-gradient-to-b from-[#0A0F1C] to-[#0D1117]">
        <div className="flex justify-end px-4 pt-4">
          <PageShareBar pageTitle="QMGE Standalone Software" pageDescription="Quantum Market Genome Engine™ - Downloadable trading software" />
        </div>

        {vpnWarning && (
          <div className="mx-4 mt-4 p-4 bg-red-900/30 border border-red-500/50 rounded-xl flex items-start gap-3" data-testid="vpn-warning-banner">
            <Shield size={24} className="text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-red-400 font-bold text-lg">VPN / Proxy Detected</h3>
              <p className="text-red-300 text-sm mt-1">{vpnWarning}</p>
              <p className="text-red-400/70 text-xs mt-2">Disconnect your VPN and refresh the page to continue using QMGE.</p>
            </div>
          </div>
        )}

        {hasLicense && license && (
          <div className={`mx-4 mt-4 p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
            isExpired ? "bg-red-900/20 border-red-500/30" :
            license.tier !== "free" ? "bg-emerald-900/20 border-emerald-500/30" :
            "bg-violet-900/20 border-violet-500/30"
          }`} data-testid="license-status-banner">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isExpired ? "bg-red-500/20" : license.tier !== "free" ? "bg-emerald-500/20" : "bg-violet-500/20"}`}>
                {isExpired ? <Lock size={20} className="text-red-400" /> : <Key size={20} className={license.tier !== "free" ? "text-emerald-400" : "text-violet-400"} />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-white font-semibold text-sm">
                    {isExpired ? "Trial Expired" : license.tier === "free" ? "Free Trial Active" : `${license.tier.charAt(0).toUpperCase() + license.tier.slice(1)} License Active`}
                  </span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    isExpired ? "bg-red-500/20 text-red-400" :
                    license.tier !== "free" ? "bg-emerald-500/20 text-emerald-400" :
                    "bg-violet-500/20 text-violet-400"
                  }`}>
                    {license.tier === "free" ? `${license.dimensionsUnlocked}/7 Dimensions` : "All 7 Dimensions"}
                  </span>
                </div>
                <p className="text-gray-400 text-xs mt-0.5">
                  {isExpired
                    ? "Your free trial has ended. Purchase a plan to unlock all features."
                    : license.tier === "free"
                    ? `${formatTimeLeft(license.remainingMinutes)} usage | Trial expires: ${formatTimeLeft(license.trialTimeLeftMinutes)}`
                    : `License: ${license.licenseKey}`
                  }
                </p>
              </div>
            </div>
            {(isExpired || license.tier === "free") && (
              <button
                onClick={() => scrollTo("pricing")}
                className="px-4 py-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white text-sm font-semibold rounded-lg transition-all whitespace-nowrap"
                data-testid="button-upgrade-from-banner"
              >
                {isExpired ? "Purchase Full Version" : "Upgrade to Full"}
              </button>
            )}
          </div>
        )}

        {/* 1. Hero Section */}
        <section className="relative py-20 sm:py-28 overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-600/5 via-purple-500/5 to-violet-600/5" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-violet-500/10 to-transparent rounded-full blur-3xl" />
          </div>

          <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-sm mb-6">
                <Shield size={16} />
                <span>Patent Pending | Copyright Protected</span>
              </div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
                Quantum Market
                <br />
                <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                  Genome Engine™
                </span>
              </h1>

              <p className="text-violet-300/80 text-lg sm:text-xl max-w-3xl mx-auto mb-4 font-medium">
                The World's First 7-Dimensional Standalone Trading Intelligence Software
              </p>

              <p className="text-gray-400 text-base sm:text-lg max-w-2xl mx-auto mb-4">
                QMGE maps the complete DNA of crypto markets using seven independent data dimensions simultaneously.
                Download and run it on your own machine — no cloud dependency, no account required.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
                <span className="px-3 py-1.5 bg-green-500/10 border border-green-500/30 rounded-full text-xs text-green-400 font-medium">Up to 100% Validated Accuracy</span>
                <span className="px-3 py-1.5 bg-violet-500/10 border border-violet-500/30 rounded-full text-xs text-violet-400 font-medium">Beats Tickeron, InvestIQ, Learn2Trade</span>
                <span className="px-3 py-1.5 bg-cyan-500/10 border border-cyan-500/30 rounded-full text-xs text-cyan-400 font-medium">5 Competitor Periods Tested</span>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => scrollTo("pricing")}
                  className="px-8 py-3 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg shadow-violet-500/20"
                  data-testid="button-get-started-free"
                >
                  Get Started Free
                </button>
                <button
                  onClick={() => scrollTo("video-section")}
                  className="px-8 py-3 border border-violet-500/30 text-violet-400 hover:bg-violet-500/10 font-semibold rounded-xl text-lg transition-all flex items-center gap-2"
                  data-testid="button-watch-demo"
                >
                  <Play size={20} />
                  Watch Demo
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 2. What Is QMGE Section */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                What Is QMGE?
              </h2>
              <p className="text-gray-400 text-center max-w-3xl mx-auto mb-12 text-lg">
                QMGE maps the complete DNA of crypto markets by analyzing
                <span className="text-violet-400 font-semibold"> 7 dimensions simultaneously</span>.
                Unlike traditional single-indicator tools, QMGE fuses multiple market DNA strands into a unified genome map
                and produces actionable predictions <span className="text-violet-400 font-semibold">5-30 minutes ahead</span>.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIMENSIONS.map((dim, i) => {
                  const Icon = dim.icon;
                  return (
                    <motion.div
                      key={dim.name}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#161B22] rounded-xl p-5 border border-gray-800 flex items-center gap-4"
                    >
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${dim.color}20`, border: `1px solid ${dim.color}40` }}
                      >
                        <Icon size={24} style={{ color: dim.color }} />
                      </div>
                      <span className="text-gray-200 font-medium">{dim.name}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* 3. Why QMGE Stands Alone */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Why QMGE Stands Alone
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
                No other software combines these capabilities into a single standalone engine.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {WHY_CARDS.map((card, i) => {
                  const Icon = card.icon;
                  return (
                    <motion.div
                      key={card.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#161B22] rounded-xl p-6 border border-gray-800 hover:border-violet-500/30 transition-all"
                    >
                      <div className="w-12 h-12 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mb-4">
                        <Icon size={24} className="text-violet-400" />
                      </div>
                      <h3 className="text-white font-semibold text-lg mb-2">{card.title}</h3>
                      <p className="text-gray-400 text-sm">{card.description}</p>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Validated Performance */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Validated Against the Industry
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-10">
                QMGE was tested on the exact same time periods used by leading competitors for their published accuracy claims.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
                {[
                  { comp: 'Tickeron Gen 3', claim: '89%', ours: '93-97%', label: 'Beaten' },
                  { comp: 'InvestIQ', claim: '91%', ours: '100%', label: 'Beaten' },
                  { comp: 'Learn2Trade', claim: '79-82%', ours: '97-100%', label: 'Beaten' },
                  { comp: '3Commas', claim: '60-65%', ours: '79-86%', label: 'Beaten' },
                  { comp: 'Tickeron Gen 2', claim: '78%', ours: '87-97%', label: 'Beaten' },
                ].map((c) => (
                  <div key={c.comp} className="bg-[#161B22] rounded-xl p-4 border border-green-500/20 text-center">
                    <div className="text-xs text-gray-500 mb-1">{c.comp}</div>
                    <div className="text-xs text-gray-400">Claims <span className="text-cyan-400 font-bold">{c.claim}</span></div>
                    <div className="text-lg font-bold text-green-400 my-1">{c.ours}</div>
                    <div className="text-[10px] text-green-400/70 font-medium uppercase">{c.label}</div>
                  </div>
                ))}
              </div>

              <div className="bg-gradient-to-r from-violet-500/5 to-green-500/5 rounded-xl p-5 border border-violet-500/20 mb-4">
                <div className="flex items-start gap-3">
                  <Shield size={20} className="text-violet-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-white font-bold text-sm mb-1">Industry-Standard Methodology</h3>
                    <p className="text-gray-400 text-xs">
                      All accuracy figures are measured using the same flexible exit window methodology that Tickeron, InvestIQ, Learn2Trade, and 3Commas use to publish their claims.
                      QMGE scores 79-100% across all competitor periods, beating every competitor tested on their own data and time frames.
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <Link href="/alpha-trading/validated-combinations">
                  <span className="text-violet-400 text-sm hover:underline cursor-pointer inline-flex items-center gap-1">
                    View Full Validation Report <ArrowRight size={14} />
                  </span>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 4. Promotional Video Section */}
        <section id="video-section" className="py-16 border-t border-gray-800/50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                See QMGE in Action
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-10">
                Watch the 7-dimensional genome engine analyze live market data in real time.
              </p>

              <div className="relative rounded-2xl overflow-hidden" style={{ aspectRatio: "16/9" }}>
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 via-transparent to-purple-500/20 rounded-2xl p-[2px]">
                  <div className="w-full h-full bg-[#0D1117] rounded-2xl flex flex-col items-center justify-center">
                    <div className="w-20 h-20 rounded-full bg-violet-500/20 border border-violet-500/40 flex items-center justify-center mb-6 cursor-pointer hover:bg-violet-500/30 transition-all" data-testid="button-play-demo">
                      <Play size={36} className="text-violet-400 ml-1" />
                    </div>
                    <p className="text-white font-semibold text-xl mb-2">QMGE Standalone Software Demo</p>
                    <p className="text-gray-400 text-sm max-w-md text-center">
                      See the 7-dimensional genome engine analyze live market data in real time
                    </p>
                  </div>
                </div>
                <div className="absolute inset-0 rounded-2xl shadow-[0_0_60px_-10px_rgba(139,92,246,0.3)] pointer-events-none" />
              </div>
            </motion.div>
          </div>
        </section>

        {/* 5. Real-Time Monitoring Preview */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Real-Time Monitoring Preview
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-10">
                A glimpse of the QMGE monitoring dashboard — all 7 dimensions updating live.
              </p>

              <div className="bg-[#0D1117] rounded-2xl border border-gray-800 overflow-hidden">
                <div className="bg-[#161B22] px-6 py-3 border-b border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Dna size={20} className="text-violet-400 animate-pulse" />
                    <span className="text-white font-semibold">QMGE Monitor</span>
                    <span className="text-gray-500 text-sm">BTC/USDT</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    <span className="text-green-400 text-xs">LIVE</span>
                  </div>
                </div>

                <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-3">
                    <h3 className="text-gray-400 text-sm font-medium mb-4">7-Dimension Genome Map</h3>
                    {DIMENSIONS.map((dim) => (
                      <div key={dim.name} className="flex items-center gap-3">
                        <div className="w-32 sm:w-40 text-xs text-gray-400 truncate">{dim.name}</div>
                        <div className="flex-1 h-4 bg-[#21262D] rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${dim.score}%` }}
                            transition={{ duration: 1, delay: 0.2 }}
                            className="h-full rounded-full"
                            style={{ backgroundColor: dim.color }}
                          />
                        </div>
                        <span className="text-xs font-mono w-8 text-right" style={{ color: dim.color }}>{dim.score}</span>
                      </div>
                    ))}

                    <div className="mt-6 pt-4 border-t border-gray-800 flex flex-wrap gap-4">
                      <div className="bg-[#21262D] rounded-lg px-4 py-3 flex-1 min-w-[140px]">
                        <div className="text-gray-500 text-xs mb-1">Genome Pattern</div>
                        <div className="text-violet-400 font-semibold text-sm">Alpha Surge</div>
                      </div>
                      <div className="bg-[#21262D] rounded-lg px-4 py-3 flex-1 min-w-[140px]">
                        <div className="text-gray-500 text-xs mb-1">Convergence Index</div>
                        <div className="text-cyan-400 font-semibold text-sm">0.82 / 1.00</div>
                      </div>
                      <div className="bg-[#21262D] rounded-lg px-4 py-3 flex-1 min-w-[140px]">
                        <div className="text-gray-500 text-xs mb-1">Mutation Rate</div>
                        <div className="text-yellow-400 font-semibold text-sm">0.15 (Low)</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-[#21262D] rounded-xl p-5 border border-gray-700">
                      <div className="text-gray-500 text-xs mb-2">Aggregate Signal</div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-400" />
                        <span className="text-green-400 font-bold text-lg">STRONG BUY</span>
                      </div>
                      <div className="text-gray-500 text-xs mt-1">Score: 74.3 / 100</div>
                    </div>

                    <div className="bg-[#21262D] rounded-xl p-5 border border-gray-700">
                      <div className="text-gray-500 text-xs mb-3">Prediction</div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Direction</span>
                          <span className="text-green-400 font-semibold text-sm flex items-center gap-1">
                            <ArrowUp size={14} /> UP
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Confidence</span>
                          <span className="text-white font-semibold text-sm">78%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Time Horizon</span>
                          <span className="text-white font-semibold text-sm">15 min</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Risk Level</span>
                          <span className="text-yellow-400 font-semibold text-sm">Medium</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#21262D] rounded-xl p-5 border border-gray-700">
                      <div className="text-gray-500 text-xs mb-2">Dominant Dimension</div>
                      <div className="flex items-center gap-2">
                        <Activity size={16} className="text-cyan-400" />
                        <span className="text-cyan-400 font-semibold text-sm">Network Health</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 6. Pricing Section */}
        <section id="pricing" className="py-16 border-t border-gray-800/50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Choose Your Plan
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
                Start free with 2 dimensions, or unlock the full 7-dimensional genome engine.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {PRICING_TIERS.map((tier) => {
                  const planMap: Record<string, "monthly" | "annual" | "lifetime"> = {
                    Monthly: "monthly",
                    Annual: "annual",
                    Lifetime: "lifetime",
                  };
                  const plan = planMap[tier.name];
                  const isLoading = checkoutLoading === plan;

                  return (
                    <motion.div
                      key={tier.name}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`relative bg-[#161B22] rounded-xl border ${
                        tier.highlighted
                          ? "border-violet-500 shadow-lg shadow-violet-500/20"
                          : "border-gray-800"
                      } p-6 flex flex-col`}
                    >
                      {tier.badge && (
                        <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold ${
                          tier.highlighted
                            ? "bg-violet-500 text-white"
                            : "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                        }`}>
                          {tier.badge}
                        </div>
                      )}

                      <div className="text-center mb-6 pt-2">
                        <h3 className="text-white font-bold text-xl mb-2">{tier.name}</h3>
                        <div className="flex items-baseline justify-center gap-1">
                          <span className="text-3xl font-bold text-white">{tier.price}</span>
                          <span className="text-gray-500 text-sm">{tier.period}</span>
                        </div>
                      </div>

                      <ul className="space-y-3 mb-8 flex-1">
                        {tier.features.map((feature) => (
                          <li key={feature} className="flex items-start gap-2 text-sm">
                            <CheckCircle size={16} className="text-violet-400 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-300">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <button
                        onClick={tier.isPaid ? () => handlePurchase(plan) : handleFreeDownload}
                        disabled={isLoading || activating}
                        className={`w-full py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
                          tier.highlighted
                            ? "bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 transform hover:scale-[1.02]"
                            : tier.isPaid
                            ? "bg-violet-500/10 border border-violet-500/30 text-violet-400 hover:bg-violet-500/20 hover:border-violet-500/50"
                            : "bg-white/10 border border-white/20 text-white hover:bg-white/20"
                        } ${isLoading || activating ? 'opacity-70 cursor-not-allowed' : ''}`}
                        data-testid={tier.testId}
                      >
                        {isLoading ? (
                          <>
                            <Loader2 size={18} className="animate-spin" />
                            Processing...
                          </>
                        ) : !tier.isPaid && activating ? (
                          <>
                            <Loader2 size={18} className="animate-spin" />
                            Activating Trial...
                          </>
                        ) : !tier.isPaid && hasLicense && license?.tier === "free" && !isExpired ? (
                          <>
                            <CheckCircle size={18} />
                            Trial Active
                          </>
                        ) : !tier.isPaid && isExpired ? (
                          <>
                            <Lock size={18} />
                            Trial Expired
                          </>
                        ) : tier.isPaid ? (
                          <>
                            <ShoppingCart size={18} />
                            {tier.buttonText}
                          </>
                        ) : (
                          <>
                            <Download size={18} />
                            Activate Free Trial
                          </>
                        )}
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* 7. Download & Instructions Section */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Download & Instructions
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-10">
                Get started with QMGE in minutes. PDF instructions are included with every paid download.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
                <div className="bg-[#161B22] rounded-xl border border-violet-500/30 p-6 text-center shadow-lg shadow-violet-500/5">
                  <div className="w-16 h-16 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mx-auto mb-4">
                    {hasLicense && license?.tier === "free" && !isExpired ? (
                      <Key size={32} className="text-violet-400" />
                    ) : isExpired ? (
                      <Lock size={32} className="text-red-400" />
                    ) : (
                      <Download size={32} className="text-violet-400" />
                    )}
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-1">
                    {hasLicense && license?.tier === "free" ? (isExpired ? "Trial Expired" : "Free Trial Active") : "QMGE Free Trial"}
                  </h3>
                  <p className="text-gray-500 text-xs mb-1">2 Dimensions | 15-min Delayed Data | 7-Day Trial</p>
                  <p className="text-gray-400 text-sm mb-2">
                    {hasLicense && license?.tier === "free" && !isExpired
                      ? `${formatTimeLeft(license.remainingMinutes)} remaining`
                      : isExpired ? "Upgrade to continue" : "1,440 minutes of usage time"
                    }
                  </p>
                  {hasLicense && license?.tier === "free" && !isExpired && (
                    <div className="mb-3">
                      <div className="w-full bg-gray-700/50 rounded-full h-2">
                        <div
                          className="bg-violet-500 h-2 rounded-full transition-all"
                          style={{ width: `${Math.max(2, (license.remainingMinutes / license.maxUsageMinutes) * 100)}%` }}
                        />
                      </div>
                      <p className="text-gray-500 text-xs mt-1">{license.totalUsageMinutes}/{license.maxUsageMinutes} minutes used</p>
                    </div>
                  )}
                  <button
                    onClick={isExpired ? () => scrollTo("pricing") : handleFreeDownload}
                    disabled={activating || (hasLicense && license?.tier !== "free")}
                    className={`px-6 py-3 font-semibold rounded-xl transition-all w-full flex items-center justify-center gap-2 ${
                      isExpired ? "bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20" :
                      hasLicense && license?.tier === "free" ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400" :
                      "bg-white/10 border border-white/20 text-white hover:bg-white/20"
                    }`}
                    data-testid="button-download-qmge-free"
                  >
                    {activating ? (
                      <><Loader2 size={18} className="animate-spin" /> Activating...</>
                    ) : isExpired ? (
                      <><ArrowUp size={18} /> Upgrade Now</>
                    ) : hasLicense && license?.tier === "free" ? (
                      <><Download size={18} /> Download Free Version</>
                    ) : (
                      <><Download size={18} /> Activate Free Trial</>
                    )}
                  </button>
                </div>

                <div className="bg-[#161B22] rounded-xl border border-violet-500 p-6 text-center shadow-xl shadow-violet-500/10 relative">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold bg-violet-500 text-white">
                    MOST POPULAR
                  </div>
                  <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-violet-500/20 to-purple-500/20 border border-violet-500/30 flex items-center justify-center mx-auto mb-4">
                    <Crown size={32} className="text-violet-400" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-1">
                    {hasLicense && license?.tier !== "free" ? "QMGE Full Version" : "Purchase Full QMGE"}
                  </h3>
                  <p className="text-violet-400 text-xs mb-1 font-semibold">All 7 Dimensions | Real-Time Data</p>
                  <p className="text-gray-400 text-sm mb-4">
                    {hasLicense && license?.tier !== "free" ? `${license?.tier?.charAt(0).toUpperCase()}${license?.tier?.slice(1)} License Active` : "Starting at $179/month"}
                  </p>
                  {hasLicense && license?.tier !== "free" ? (
                    <button
                      onClick={triggerQMGEDownload}
                      className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-semibold rounded-xl transition-all w-full flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transform hover:scale-[1.02]"
                      data-testid="button-download-qmge-paid"
                    >
                      <Download size={18} /> Download Full Version
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => handlePurchase("monthly")}
                        disabled={checkoutLoading === "monthly"}
                        className="px-6 py-3 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold rounded-xl transition-all w-full flex items-center justify-center gap-2 shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 transform hover:scale-[1.02]"
                        data-testid="button-purchase-qmge"
                      >
                        {checkoutLoading === "monthly" ? (
                          <><Loader2 size={18} className="animate-spin" /> Processing...</>
                        ) : (
                          <><ShoppingCart size={18} /> Purchase & Download</>
                        )}
                      </button>
                      <button
                        onClick={() => scrollTo("pricing")}
                        className="mt-2 text-violet-400 text-xs hover:text-violet-300 transition-colors"
                      >
                        View all plans
                      </button>
                    </>
                  )}
                </div>

                <div className="bg-[#161B22] rounded-xl border border-gray-800 p-6 text-center">
                  <div className="w-16 h-16 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto mb-4">
                    <FileText size={32} className="text-cyan-400" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-1">PDF Instructions</h3>
                  <p className="text-gray-500 text-xs mb-1">Included with purchase</p>
                  <p className="text-gray-400 text-sm mb-4">Complete setup and usage guide</p>
                  <a
                    href="/downloads/QMGE-Instructions.pdf"
                    className="block px-6 py-3 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20 font-semibold rounded-xl transition-all w-full"
                    data-testid="button-download-instructions"
                  >
                    <span className="flex items-center justify-center gap-2">
                      <FileText size={18} />
                      Download PDF Instructions
                    </span>
                  </a>
                </div>
              </div>

              <div className="bg-[#161B22] rounded-xl border border-gray-800 p-6">
                <h3 className="text-white font-semibold mb-4">What's in the Instruction Manual:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    "Installation & system requirements",
                    "Exchange API key setup (step-by-step)",
                    "Understanding the 7 dimensions",
                    "Reading genome patterns",
                    "Convergence index interpretation",
                    "Mutation rate & risk management",
                    "Adaptive weight configuration",
                    "Troubleshooting & FAQ",
                  ].map((item) => (
                    <div key={item} className="flex items-center gap-2 text-sm">
                      <CheckCircle size={14} className="text-violet-400 flex-shrink-0" />
                      <span className="text-gray-300">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 8. QMGE Standalone Interface Preview */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Your Own QMGE Interface
              </h2>
              <p className="text-gray-400 text-center max-w-3xl mx-auto mb-4">
                QMGE runs as a <span className="text-violet-400 font-semibold">completely independent application</span> with its own dedicated interface.
                No Alpha Unlimited account or trading terminal needed — QMGE connects directly to your exchange.
              </p>
              <p className="text-gray-500 text-center max-w-2xl mx-auto mb-12 text-sm">
                Use it alongside any exchange's web interface, any third-party terminal, or entirely on its own.
              </p>

              <div className="bg-[#0A0F1C] rounded-2xl border border-gray-800 overflow-hidden shadow-2xl shadow-violet-500/5">
                <div className="bg-[#161B22] px-4 py-2 border-b border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-red-500/60" />
                      <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                      <div className="w-3 h-3 rounded-full bg-green-500/60" />
                    </div>
                    <span className="text-gray-400 text-xs ml-3">QMGE Standalone v2.4.1</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-green-500/10 rounded border border-green-500/20">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                      <span className="text-green-400 text-xs font-medium">Connected: Binance</span>
                    </div>
                    <Maximize2 size={14} className="text-gray-500" />
                  </div>
                </div>

                <div className="p-4">
                  <div className="grid grid-cols-12 gap-3">
                    <div className="col-span-12 lg:col-span-3 space-y-3">
                      <div className="bg-[#161B22] rounded-lg border border-gray-800 p-3">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <Server size={14} className="text-violet-400" />
                            <span className="text-white text-xs font-semibold">Exchange Feed</span>
                          </div>
                          <RefreshCw size={12} className="text-gray-500" />
                        </div>
                        <div className="space-y-1.5">
                          {["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"].map((pair, i) => (
                            <div key={pair} className={`flex justify-between items-center px-2 py-1.5 rounded text-xs ${i === 0 ? 'bg-violet-500/10 border border-violet-500/20' : 'hover:bg-[#21262D]'}`}>
                              <span className={i === 0 ? "text-violet-400 font-semibold" : "text-gray-300"}>{pair}</span>
                              <span className={i % 2 === 0 ? "text-green-400" : "text-red-400"}>
                                {i === 0 ? "$97,241" : i === 1 ? "$3,412" : i === 2 ? "$178.5" : i === 3 ? "$612.3" : "$2.41"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="bg-[#161B22] rounded-lg border border-gray-800 p-3">
                        <div className="flex items-center gap-2 mb-3">
                          <Bell size={14} className="text-yellow-400" />
                          <span className="text-white text-xs font-semibold">Alert Center</span>
                        </div>
                        <div className="space-y-2">
                          <div className="bg-green-500/5 border border-green-500/20 rounded p-2">
                            <div className="text-green-400 text-[10px] font-semibold">Alpha Surge Detected</div>
                            <div className="text-gray-500 text-[10px]">BTC/USDT - 2 min ago</div>
                          </div>
                          <div className="bg-yellow-500/5 border border-yellow-500/20 rounded p-2">
                            <div className="text-yellow-400 text-[10px] font-semibold">Convergence Index &gt; 0.8</div>
                            <div className="text-gray-500 text-[10px]">ETH/USDT - 5 min ago</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-12 lg:col-span-6">
                      <div className="bg-[#161B22] rounded-lg border border-gray-800 p-3 h-full">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <Dna size={14} className="text-violet-400 animate-pulse" />
                            <span className="text-white text-xs font-semibold">7-Dimension Genome Map</span>
                            <span className="text-gray-500 text-[10px]">BTC/USDT</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                            <span className="text-green-400 text-[10px]">LIVE</span>
                          </div>
                        </div>

                        <div className="space-y-2 mb-4">
                          {DIMENSIONS.map((dim) => (
                            <div key={dim.name} className="flex items-center gap-2">
                              <div className="w-24 text-[10px] text-gray-400 truncate">{dim.name}</div>
                              <div className="flex-1 h-3 bg-[#21262D] rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${dim.score}%` }}
                                  transition={{ duration: 1 }}
                                  className="h-full rounded-full"
                                  style={{ backgroundColor: dim.color }}
                                />
                              </div>
                              <span className="text-[10px] font-mono w-6 text-right" style={{ color: dim.color }}>{dim.score}</span>
                            </div>
                          ))}
                        </div>

                        <div className="grid grid-cols-3 gap-2 pt-3 border-t border-gray-800">
                          <div className="bg-[#21262D] rounded p-2">
                            <div className="text-gray-500 text-[10px]">Pattern</div>
                            <div className="text-violet-400 font-semibold text-xs">Alpha Surge</div>
                          </div>
                          <div className="bg-[#21262D] rounded p-2">
                            <div className="text-gray-500 text-[10px]">Convergence</div>
                            <div className="text-cyan-400 font-semibold text-xs">0.82</div>
                          </div>
                          <div className="bg-[#21262D] rounded p-2">
                            <div className="text-gray-500 text-[10px]">Mutation</div>
                            <div className="text-yellow-400 font-semibold text-xs">0.15 Low</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-12 lg:col-span-3 space-y-3">
                      <div className="bg-[#161B22] rounded-lg border border-gray-800 p-3">
                        <div className="flex items-center gap-2 mb-3">
                          <BarChart3 size={14} className="text-green-400" />
                          <span className="text-white text-xs font-semibold">Signal Output</span>
                        </div>
                        <div className="text-center py-2">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <div className="w-3 h-3 rounded-full bg-green-400" />
                            <span className="text-green-400 font-bold text-lg">BUY</span>
                          </div>
                          <div className="text-gray-500 text-xs">Score: 74.3 / 100</div>
                          <div className="text-gray-500 text-xs">Confidence: 78%</div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-gray-800 space-y-1.5">
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Direction</span>
                            <span className="text-green-400 font-semibold flex items-center gap-1"><ArrowUp size={10} /> UP</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Horizon</span>
                            <span className="text-white font-semibold">15 min</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Risk</span>
                            <span className="text-yellow-400 font-semibold">Medium</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#161B22] rounded-lg border border-gray-800 p-3">
                        <div className="flex items-center gap-2 mb-3">
                          <LineChart size={14} className="text-cyan-400" />
                          <span className="text-white text-xs font-semibold">Accuracy</span>
                        </div>
                        <div className="text-center">
                          <div className="text-cyan-400 font-bold text-xl">73.2%</div>
                          <div className="text-gray-500 text-[10px]">Last 100 predictions</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
                {INTERFACE_PANELS.map((panel, i) => {
                  const Icon = panel.icon;
                  return (
                    <motion.div
                      key={panel.name}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#161B22] rounded-lg border border-gray-800 p-4 text-center"
                    >
                      <Icon size={20} className="text-violet-400 mx-auto mb-2" />
                      <div className="text-white text-xs font-semibold mb-1">{panel.name}</div>
                      <div className="text-gray-500 text-[10px]">{panel.description}</div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* 9. Supported Exchanges */}
        <section id="supported-exchanges" className="py-16 border-t border-gray-800/50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Connect to 21+ Exchanges
              </h2>
              <p className="text-gray-400 text-center max-w-3xl mx-auto mb-4">
                QMGE standalone works with all major cryptocurrency exchanges.
                <span className="text-violet-400 font-semibold"> Use YOUR preferred exchange</span> — no need to switch platforms or use Alpha Unlimited's terminal.
              </p>
              <p className="text-gray-500 text-center max-w-2xl mx-auto mb-12 text-sm">
                Simply connect your exchange API keys (read-only) and QMGE starts analyzing your markets instantly.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                {SUPPORTED_EXCHANGES.map((exchange, i) => (
                  <motion.div
                    key={exchange.name}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.02 }}
                    className="bg-[#161B22] rounded-xl border border-gray-800 hover:border-violet-500/30 p-4 transition-all group"
                    data-testid={`exchange-card-${exchange.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                        style={{ backgroundColor: `${exchange.color}15`, border: `1px solid ${exchange.color}30`, color: exchange.color }}
                      >
                        {exchange.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-white text-sm font-semibold group-hover:text-violet-400 transition-colors">{exchange.name}</div>
                        <div className="text-gray-500 text-[10px]">{exchange.region}</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-gray-400">{exchange.pairs} pairs</span>
                      <span className={`px-1.5 py-0.5 rounded ${exchange.tier === 'derivatives' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>
                        {exchange.tier === 'derivatives' ? 'Derivatives' : 'Full Support'}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 bg-[#161B22] rounded-xl border border-gray-800 p-6 text-center">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Link2 size={18} className="text-violet-400" />
                  <span className="text-white font-semibold">Custom Exchange Connection</span>
                </div>
                <p className="text-gray-400 text-sm max-w-xl mx-auto">
                  Don't see your exchange? QMGE supports any exchange with a REST or WebSocket API.
                  Enter your custom API endpoint and credentials in the "Custom Connection" panel.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 10. How to Connect - Quick Start */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                How to Connect to Your Exchange
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
                Get up and running in 4 simple steps — works the same for every exchange.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
                {CONNECT_STEPS.map((step, i) => {
                  const Icon = step.icon;
                  return (
                    <motion.div
                      key={step.step}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="text-center"
                    >
                      <div className="w-14 h-14 rounded-full bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mx-auto mb-4">
                        <Icon size={24} className="text-violet-400" />
                      </div>
                      <div className="text-violet-400 text-sm font-bold mb-2">Step {step.step}</div>
                      <p className="text-gray-300 text-sm">{step.title}</p>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* 11. Exchange-Specific API Key Guides */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                Exchange-by-Exchange Setup Guides
              </h2>
              <p className="text-gray-400 text-center max-w-2xl mx-auto mb-4">
                Step-by-step instructions for creating read-only API keys on each supported exchange.
              </p>
              <div className="flex items-center justify-center gap-2 mb-12">
                <AlertTriangle size={14} className="text-yellow-400" />
                <p className="text-yellow-400/80 text-xs">
                  Always use read-only API keys. QMGE only needs market data access — never enable trading or withdrawal permissions.
                </p>
              </div>

              <div className="space-y-3">
                {EXCHANGE_GUIDES.map((guide) => (
                  <div
                    key={guide.name}
                    className="bg-[#161B22] rounded-xl border border-gray-800 overflow-hidden"
                    data-testid={`guide-${guide.name.toLowerCase()}`}
                  >
                    <button
                      onClick={() => setExpandedGuide(expandedGuide === guide.name ? null : guide.name)}
                      className="w-full flex items-center justify-between p-4 hover:bg-[#21262D] transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Server size={18} className="text-violet-400" />
                        <span className="text-white font-semibold">{guide.name}</span>
                        <span className="text-gray-500 text-xs">API Key Setup</span>
                      </div>
                      {expandedGuide === guide.name ? (
                        <ChevronUp size={18} className="text-gray-400" />
                      ) : (
                        <ChevronDown size={18} className="text-gray-400" />
                      )}
                    </button>

                    <AnimatePresence>
                      {expandedGuide === guide.name && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 border-t border-gray-800 pt-4">
                            <ol className="space-y-3 mb-4">
                              {guide.steps.map((step, i) => (
                                <li key={i} className="flex items-start gap-3">
                                  <div className="w-6 h-6 rounded-full bg-violet-500/10 border border-violet-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-violet-400 text-xs font-bold">{i + 1}</span>
                                  </div>
                                  <span className={`text-sm ${step.startsWith('IMPORTANT') ? 'text-yellow-400 font-semibold' : 'text-gray-300'}`}>
                                    {step}
                                  </span>
                                </li>
                              ))}
                            </ol>

                            <div className="bg-[#21262D] rounded-lg p-3 flex items-start gap-3 mb-3">
                              <AlertTriangle size={14} className="text-yellow-400 mt-0.5 flex-shrink-0" />
                              <p className="text-gray-400 text-xs">{guide.notes}</p>
                            </div>

                            <a
                              href={guide.apiUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 text-violet-400 hover:text-violet-300 text-sm transition-colors"
                            >
                              <ExternalLink size={14} />
                              Open {guide.name} API Management
                            </a>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>

              <div className="mt-6 bg-[#161B22] rounded-xl border border-gray-800 p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Shield size={18} className="text-green-400" />
                  <span className="text-white font-semibold">Security Best Practices</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    "Always use READ-ONLY permissions — no trading, no withdrawals",
                    "Enable IP restriction when your exchange supports it",
                    "Use a unique API key just for QMGE — don't reuse keys",
                    "Rotate your API keys every 90 days for maximum security",
                    "QMGE stores keys locally on your machine — never sent to our servers",
                    "Delete API keys from your exchange if you stop using QMGE",
                  ].map((tip) => (
                    <div key={tip} className="flex items-start gap-2 text-sm">
                      <CheckCircle size={14} className="text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300 text-xs">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 12. Copyright & Legal Footer */}
        <section className="py-12 border-t border-gray-800/50 bg-[#0A0F1C]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <Shield size={28} className="text-violet-400/50 mx-auto mb-4" />
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
              The Quantum Market Genome Engine™ (QMGE) and all associated technologies, algorithms, genome patterns,
              data structures, source code, documentation, and visual designs are protected by international copyright law.
              Patent Pending. Trademark Registered. Any unauthorized use, reproduction, or distribution is strictly prohibited.
            </p>
            <div className="flex items-center justify-center gap-6 text-sm">
              <Link href="/copyright">
                <span className="text-violet-400 hover:text-violet-300 cursor-pointer" data-testid="link-copyright">
                  Copyright Policy
                </span>
              </Link>
              <Link href="/disclaimer">
                <span className="text-violet-400 hover:text-violet-300 cursor-pointer" data-testid="link-disclaimer">
                  Disclaimer
                </span>
              </Link>
            </div>
          </div>
        </section>

      </div>

      <AnimatePresence>
        {showStickyCTA && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-0 left-0 right-0 z-50 bg-[#0D1117]/95 backdrop-blur-xl border-t border-violet-500/30 shadow-2xl shadow-violet-500/10"
          >
            <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
              <div className="hidden sm:flex items-center gap-3">
                <Dna size={24} className="text-violet-400 animate-pulse" />
                <div>
                  <div className="text-white font-semibold text-sm">QMGE Standalone Software</div>
                  <div className="text-gray-400 text-xs">7-Dimension Market Analysis | Works with 21+ Exchanges</div>
                </div>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                {license && license.tier !== "free" ? (
                  <span className="px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold rounded-lg text-sm flex items-center gap-2">
                    <CheckCircle size={16} />
                    <span className="hidden sm:inline">Licensed</span>
                  </span>
                ) : hasLicense && license?.tier === "free" && !isExpired ? (
                  <span className="px-4 py-2.5 bg-violet-500/10 border border-violet-500/30 text-violet-400 font-semibold rounded-lg text-sm flex items-center gap-2">
                    <Clock size={16} />
                    <span className="hidden sm:inline">{formatTimeLeft(license.remainingMinutes)}</span>
                  </span>
                ) : (
                  <button
                    onClick={handleFreeDownload}
                    disabled={activating}
                    className="px-4 py-2.5 bg-white/10 border border-white/20 text-white hover:bg-white/20 font-semibold rounded-lg transition-all text-sm flex items-center gap-2"
                    data-testid="button-sticky-download-free"
                  >
                    <Download size={16} />
                    <span className="hidden sm:inline">{isExpired ? "Expired" : "Try Free"}</span>
                  </button>
                )}
                <button
                  onClick={() => handlePurchase("monthly")}
                  disabled={checkoutLoading === "monthly"}
                  className="flex-1 sm:flex-none px-6 py-2.5 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold rounded-lg transition-all text-sm flex items-center justify-center gap-2 shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 transform hover:scale-[1.02]"
                  data-testid="button-sticky-purchase"
                >
                  {checkoutLoading === "monthly" ? (
                    <><Loader2 size={16} className="animate-spin" /> Processing...</>
                  ) : (
                    <><ShoppingCart size={16} /> Purchase QMGE — $179/mo</>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {licenseModal?.show && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
            onClick={() => setLicenseModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-[#161B22] border border-violet-500/40 rounded-2xl shadow-2xl shadow-violet-500/20 max-w-md w-full p-6 relative"
              onClick={(e) => e.stopPropagation()}
              data-testid="license-modal"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500/20 to-purple-500/20 border border-violet-500/30 flex items-center justify-center mx-auto mb-4">
                  {licenseModal.type === "activated" ? (
                    <Sparkles size={32} className="text-violet-400" />
                  ) : (
                    <Crown size={32} className="text-violet-400" />
                  )}
                </div>
                <h2 className="text-2xl font-bold text-white mb-1">
                  {licenseModal.type === "activated" ? "Free Trial Activated!" : "Purchase Successful!"}
                </h2>
                <p className="text-gray-400 text-sm">
                  {licenseModal.type === "activated"
                    ? "Your 7-day QMGE trial is now active with 2 dimensions."
                    : `Your QMGE ${licenseModal.tier} license is active. All 7 dimensions unlocked!`
                  }
                </p>
              </div>

              <div className="bg-[#0D1117] rounded-xl border border-violet-500/20 p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 text-xs font-medium uppercase tracking-wider">Your License Key</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    licenseModal.tier === "free" ? "bg-violet-500/20 text-violet-400" : "bg-emerald-500/20 text-emerald-400"
                  }`}>
                    {licenseModal.tier === "free" ? "Free Trial" : `${licenseModal.tier.charAt(0).toUpperCase() + licenseModal.tier.slice(1)} License`}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="flex-1 text-violet-300 text-xs font-mono bg-black/40 rounded-lg p-3 break-all select-all" data-testid="text-license-key-modal">
                    {licenseModal.licenseKey}
                  </code>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(licenseModal.licenseKey);
                      setKeyCopied(true);
                      setTimeout(() => setKeyCopied(false), 2000);
                    }}
                    className="p-2.5 rounded-lg bg-violet-500/10 border border-violet-500/30 text-violet-400 hover:bg-violet-500/20 transition-all flex-shrink-0"
                    data-testid="button-copy-license-key"
                    title="Copy license key"
                  >
                    {keyCopied ? <CheckCircle size={18} /> : <Copy size={18} />}
                  </button>
                </div>
                {keyCopied && (
                  <p className="text-emerald-400 text-xs mt-2 flex items-center gap-1">
                    <CheckCircle size={12} /> Copied to clipboard!
                  </p>
                )}
              </div>

              <div className="bg-violet-500/5 border border-violet-500/10 rounded-xl p-3 mb-5">
                <div className="flex items-start gap-2">
                  <Shield size={16} className="text-violet-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-gray-400">
                    <p className="mb-1">This license key is saved to your account and can be retrieved anytime from your <a href="/account" className="text-violet-400 underline hover:text-violet-300">Account page</a>.</p>
                    <p>Each key is unique and tied to your account. It cannot be used by another user.</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setLicenseModal(null)}
                  className="flex-1 py-2.5 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold rounded-xl transition-all text-sm"
                  data-testid="button-close-license-modal"
                >
                  Got It
                </button>
                <a
                  href="/account"
                  className="py-2.5 px-4 border border-violet-500/30 text-violet-400 hover:bg-violet-500/10 font-semibold rounded-xl transition-all text-sm flex items-center gap-1.5"
                  data-testid="link-view-account-licenses"
                >
                  <Key size={14} /> My Licenses
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </TradingPlatformLayout>
  );
}
