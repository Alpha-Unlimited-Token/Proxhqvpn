/**
 * Alpha Unlimited Trading - Bridge Fusion™ Technology
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved in Perpetuity.
 * 
 * PROPRIETARY AND CONFIDENTIAL
 * The Bridge Fusion™ system, including the composite indicator algorithm, filter bridging methodology,
 * compatibility validation, weighted scoring, confidence calculation, and all associated visualization
 * technology described herein, is the exclusive intellectual property of Alpha Unlimited Trading Company.
 * Protected under international copyright law indefinitely.
 * Unauthorized copying, modification, distribution, or use is prohibited for all time.
 */

import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useState } from "react";
import { 
  ArrowLeft, Zap, TrendingUp, TrendingDown, Activity, 
  Target, AlertTriangle, CheckCircle, XCircle, Info, Shield, Lock,
  Layers, GitMerge, Link2, Gauge, Sparkles, ArrowRight, ChevronDown, ChevronUp,
  Search, Filter, Combine, Infinity, Download
} from "lucide-react";
import { PDF_GENERATORS } from "@/lib/pdfGenerator";
import { PageShareBar } from "@/components/PageShareBar";

const FILTER_INFO: Record<string, { name: string; short: string; color: string; category: string; description: string }> = {
  OFI: { name: 'Order Flow Imbalance', short: 'OFI', color: '#6366f1', category: 'Momentum', description: 'Measures buying vs selling pressure from order flow data' },
  FVG: { name: 'Fair Value Gap', short: 'FVG', color: '#f59e0b', category: 'Structure', description: 'Identifies unfilled price gaps that act as support/resistance' },
  ABS: { name: 'Absorption Detector', short: 'ABS', color: '#ec4899', category: 'Momentum', description: 'Detects hidden buying/selling where large orders absorb flow' },
  FE: { name: 'Fractal Energy', short: 'FE', color: '#10b981', category: 'Structure', description: 'Measures the remaining energy in the current price movement' },
  WYK: { name: 'Wyckoff Phase', short: 'WYK', color: '#8b5cf6', category: 'Structure', description: 'Identifies institutional accumulation/distribution cycles' },
  ENT: { name: 'Entropy Regime', short: 'ENT', color: '#06b6d4', category: 'Regime', description: 'Measures market chaos/order using information theory' },
  HUR: { name: 'Hurst Regime', short: 'HUR', color: '#f97316', category: 'Regime', description: 'Determines if price will trend or mean-revert' },
  DD: { name: 'Delta Divergence', short: 'DD', color: '#ef4444', category: 'Momentum', description: 'Finds divergences between price and buying/selling delta' },
  ACM: { name: 'Alpha Convergence Matrix', short: 'ACM', color: '#FFD700', category: 'Proprietary', description: 'Multi-dimensional convergence engine (momentum, volume, smart money, trend, volatility)' },
  QFRM: { name: 'Quantum Flow Resonance', short: 'QFRM', color: '#00FFAA', category: 'Proprietary', description: 'Analyzes price jerk, resonance frequencies, and entropy gradients' },
  BIF: { name: 'Blockchain Intelligence Filter', short: 'BIF', color: '#FF6B35', category: 'Proprietary', description: 'Monitors network congestion, miner pressure, hash rate, difficulty' },
  SBPE: { name: 'Stochastic Block Prediction', short: 'SBPE', color: '#E040FB', category: 'Proprietary', description: 'Predicts next block direction via stochastic oscillator phase analysis' },
  ANCE: { name: 'Adaptive Neural Confluence', short: 'ANCE', color: '#10B981', category: 'Proprietary', description: '7-layer AI neural scoring system analyzing HMA, VWAP, RSI, MACD, Fibonacci, entropy, and volume' },
  TMDE: { name: 'Temporal Momentum Divergence', short: 'TMDE', color: '#F43F5E', category: 'Proprietary', description: 'Cross-timeframe divergence analysis across 6 timeframes with cascade classification' },
  QMGE: { name: 'Quantum Market Genome', short: 'QMGE', color: '#A855F7', category: 'Proprietary', description: '7-dimensional market DNA mapping: capital flow, liquidity, derivatives, whale DNA, sentiment, network, macro' },
  RSI: { name: 'RSI', short: 'RSI', color: '#4FC3F7', category: 'Indicator', description: 'Relative Strength Index — momentum oscillator (0-100)' },
  MACD: { name: 'MACD', short: 'MACD', color: '#81C784', category: 'Indicator', description: 'Moving Average Convergence Divergence — trend/momentum' },
  BB: { name: 'Bollinger Bands', short: 'BB', color: '#BA68C8', category: 'Indicator', description: 'Volatility bands around a moving average' },
  ADX: { name: 'ADX', short: 'ADX', color: '#FFB74D', category: 'Indicator', description: 'Average Directional Index — trend strength measurement' },
  OBV: { name: 'OBV', short: 'OBV', color: '#4DD0E1', category: 'Indicator', description: 'On-Balance Volume — cumulative volume pressure' },
  STOCH: { name: 'Stochastic', short: 'STOCH', color: '#F06292', category: 'Indicator', description: 'Stochastic oscillator — overbought/oversold momentum' },
};

interface ComboEntry {
  filters: string[];
  name: string;
  description: string;
  bestFor: string;
  dimensions: string[];
  category: string;
  rating: number;
}

const ALL_COMBOS: ComboEntry[] = [
  { filters: ['OFI', 'FVG'], name: 'Liquidity Architecture Scanner', description: 'Reveals where institutional orders are hiding by cross-referencing order flow pressure against unfilled price gaps. When OFI shows buying pressure INTO a bearish FVG, it means smart money is absorbing supply at discount — a hidden accumulation zone invisible to either filter alone.', bestFor: 'Finding hidden institutional entry points', dimensions: ['Liquidity Void Fill Rate', 'Gap-Weighted Order Pressure', 'Institutional Absorption Index'], category: 'structure', rating: 4 },
  { filters: ['OFI', 'ABS'], name: 'Invisible Hand Detector', description: 'Identifies when large players are quietly absorbing all available supply/demand without moving price. OFI shows the flow direction while ABS reveals whether that flow is being absorbed or causing movement — together they expose the "invisible hand" of market makers.', bestFor: 'Detecting market maker activity and hidden walls', dimensions: ['Stealth Accumulation Score', 'Absorption-Flow Divergence', 'Market Maker Pressure Index'], category: 'momentum', rating: 5 },
  { filters: ['OFI', 'FE'], name: 'Flow Energy Dynamics', description: 'Measures whether order flow has enough fractal energy to sustain the current move. High OFI with depleted fractal energy means the move is exhausting — a powerful reversal signal. High OFI with charged fractal energy means the trend will accelerate.', bestFor: 'Predicting trend exhaustion vs acceleration', dimensions: ['Flow Sustainability Index', 'Kinetic-Potential Energy Ratio', 'Momentum Fuel Gauge'], category: 'hybrid', rating: 4 },
  { filters: ['OFI', 'WYK'], name: 'Smart Money Phase Tracker', description: 'Identifies exactly which Wyckoff phase the market is in AND whether current order flow confirms or contradicts that phase. OFI confirmation during Wyckoff accumulation = highest probability longs.', bestFor: 'Institutional cycle timing with flow confirmation', dimensions: ['Phase-Flow Alignment Score', 'Wyckoff Conviction Index', 'Composite Man Intent Gauge'], category: 'structure', rating: 5 },
  { filters: ['OFI', 'ENT'], name: 'Order Chaos Analyzer', description: 'Determines whether order flow is organized (trending) or chaotic (random). Low entropy + strong OFI = organized directional move. High entropy + strong OFI = noise disguised as signal. Prevents trading on false breakouts.', bestFor: 'Filtering out noise from genuine signals', dimensions: ['Signal-to-Noise Ratio', 'Order Organization Index', 'Chaos-Filtered Flow Score'], category: 'regime', rating: 4 },
  { filters: ['OFI', 'HUR'], name: 'Flow Persistence Engine', description: 'Predicts whether current order flow will persist or mean-revert. Hurst >0.5 + strong OFI = flow will continue and accelerate. Hurst <0.5 + strong OFI = flow is about to reverse. A timing edge no single filter provides.', bestFor: 'Timing entries based on flow persistence probability', dimensions: ['Flow Persistence Probability', 'Mean-Reversion Risk Score', 'Hurst-Weighted Momentum'], category: 'hybrid', rating: 4 },
  { filters: ['OFI', 'DD'], name: 'Pressure Divergence Matrix', description: 'Cross-references two independent measures of buying/selling pressure. When OFI and DD agree, pressure is genuine and confirmed from multiple angles. When they diverge, one is lagging and a reversal signal has been generated.', bestFor: 'Double-confirmed pressure with divergence alerts', dimensions: ['Dual-Pressure Confirmation', 'Pressure Divergence Alert', 'Cross-Validated Momentum'], category: 'momentum', rating: 5 },
  { filters: ['FVG', 'ABS'], name: 'Gap Defense System', description: 'Reveals whether fair value gaps are being defended by absorption (hidden orders) or left unprotected. A bearish FVG with buy absorption = institutions defending the level = high probability bounce.', bestFor: 'Predicting gap fills vs gap defenses', dimensions: ['Gap Defense Strength', 'Protected Level Index', 'Absorption-at-Gap Score'], category: 'structure', rating: 4 },
  { filters: ['FVG', 'FE'], name: 'Gap Energy Resonance', description: 'Measures whether the market has enough fractal energy to fill or reject fair value gaps. Low energy near a gap = gap acts as magnet. High energy near a gap = price may blast through creating a new structural level.', bestFor: 'Gap fill probability and breakout detection', dimensions: ['Gap Fill Probability', 'Structural Breakout Energy', 'Gap Magnet Strength'], category: 'structure', rating: 3 },
  { filters: ['FVG', 'WYK'], name: 'Institutional Blueprint', description: 'Maps fair value gaps onto Wyckoff phases to reveal the institutional game plan. Gaps created during accumulation = demand zones. Gaps during distribution = supply zones. Creates a structural blueprint.', bestFor: 'Understanding institutional structural intentions', dimensions: ['Institutional Intent Score', 'Phase-Gap Alignment', 'Blueprint Confidence Level'], category: 'structure', rating: 4 },
  { filters: ['FVG', 'HUR'], name: 'Gap Trending Analysis', description: 'Determines if gap-based levels will hold based on trend persistence. High Hurst + gaps = trending market respects gaps as continuation. Low Hurst + gaps = mean-reverting market uses gaps as targets.', bestFor: 'Adapting gap strategies to market regime', dimensions: ['Gap Regime Adaptivity', 'Trend-Adjusted Gap Value', 'Persistence-Weighted Support'], category: 'hybrid', rating: 3 },
  { filters: ['FVG', 'DD'], name: 'Value-Delta Compass', description: 'Shows whether delta divergence is occurring near or away from fair value gaps. DD at a gap = strongest reversal signal. DD away from gaps = weaker signal. Adds spatial context.', bestFor: 'Adding spatial context to delta signals', dimensions: ['Spatial Delta Relevance', 'Gap-Proximate Divergence', 'Contextual Reversal Score'], category: 'hybrid', rating: 3 },
  { filters: ['ABS', 'FE'], name: 'Hidden Energy Detector', description: 'When absorption is occurring AND fractal energy is building, it means a large player is quietly accumulating energy for a massive move. Like a spring being compressed — absorption is the compression, fractal energy measures how much force is stored.', bestFor: 'Detecting coiled spring setups before breakouts', dimensions: ['Spring Compression Index', 'Stored Energy Level', 'Breakout Imminence Score'], category: 'momentum', rating: 5 },
  { filters: ['ABS', 'WYK'], name: 'Composite Man X-Ray', description: 'Looks inside Wyckoff phases to see actual absorption activity. Absorption during accumulation CONFIRMS the phase. Lack of absorption during supposed accumulation = false signal. Like an X-ray through market structure.', bestFor: 'Confirming or invalidating Wyckoff phases', dimensions: ['Phase Authenticity Score', 'Composite Man Activity Level', 'Structural Validity Index'], category: 'structure', rating: 5 },
  { filters: ['ABS', 'ENT'], name: 'Stealth Regime Detector', description: 'Identifies when absorption is happening in orderly vs chaotic conditions. Absorption in low entropy = organized institutional activity. Absorption in high entropy = market maker defending a level in chaos.', bestFor: 'Distinguishing institutional vs defensive absorption', dimensions: ['Absorption Context Score', 'Regime-Qualified Activity', 'Stealth Operation Confidence'], category: 'regime', rating: 4 },
  { filters: ['ABS', 'HUR'], name: 'Absorption Persistence Model', description: 'Predicts whether current absorption will lead to a sustained move or a brief spike. High Hurst + absorption = persistent move. Low Hurst + absorption = short-lived and reverses. Critical for position sizing.', bestFor: 'Sizing positions based on expected move persistence', dimensions: ['Move Duration Forecast', 'Post-Absorption Trend Score', 'Position Sizing Signal'], category: 'hybrid', rating: 4 },
  { filters: ['ABS', 'DD'], name: 'Hidden vs Visible Pressure', description: 'Separates hidden pressure (absorption) from visible pressure (delta). When both align = massive confirmed pressure. When they diverge = hidden players are operating counter to visible flow — the most profitable contrarian setup.', bestFor: 'Contrarian setups where hidden beats visible', dimensions: ['Hidden-Visible Ratio', 'Contrarian Opportunity Score', 'Pressure Layer Divergence'], category: 'momentum', rating: 5 },
  { filters: ['FE', 'WYK'], name: 'Structural Energy Map', description: 'Shows how much energy each Wyckoff phase has remaining. Accumulation with rising energy = markup imminent. Markup with depleting energy = distribution starting. Tells you WHERE in the cycle AND how much fuel is left.', bestFor: 'Timing Wyckoff phase transitions', dimensions: ['Phase Energy Remaining', 'Transition Imminence Score', 'Cycle Fuel Gauge'], category: 'structure', rating: 4 },
  { filters: ['FE', 'ENT'], name: 'Chaos Energy Meter', description: 'Measures whether market energy is organized (directional) or chaotic (random). High energy + low entropy = powerful organized trend. High energy + high entropy = volatile but directionless. A critical risk filter.', bestFor: 'Risk assessment and volatility classification', dimensions: ['Directional Energy Score', 'Chaos Risk Level', 'Organized Momentum Index'], category: 'regime', rating: 4 },
  { filters: ['FE', 'HUR'], name: 'Fractal Persistence Engine', description: 'Combines fractal geometry with Hurst analysis to determine if fractals are self-similar across timeframes. High fractal energy + high Hurst = strong multi-timeframe trend. Creates a persistence-weighted energy model.', bestFor: 'Multi-timeframe trend strength assessment', dimensions: ['Multi-TF Consistency Score', 'Fractal Self-Similarity Index', 'Persistence-Energy Product'], category: 'hybrid', rating: 4 },
  { filters: ['FE', 'DD'], name: 'Divergence Energy Scanner', description: 'Finds delta divergences that have the energy to follow through. Many divergences fail because they lack energy. This filters for only the divergences backed by sufficient fractal energy to produce real reversals.', bestFor: 'High-probability divergence trading', dimensions: ['Energized Divergence Score', 'Follow-Through Probability', 'Energy-Backed Reversal Signal'], category: 'momentum', rating: 4 },
  { filters: ['WYK', 'ENT'], name: 'Phase Chaos Classifier', description: 'Classifies each Wyckoff phase by its entropy level. Accumulation in low entropy = clean, tradeable setup. Accumulation in high entropy = messy, unreliable. Tells you which Wyckoff signals to trust.', bestFor: 'Quality-filtering Wyckoff signals', dimensions: ['Phase Quality Score', 'Setup Cleanliness Index', 'Tradeable Phase Confidence'], category: 'regime', rating: 4 },
  { filters: ['WYK', 'HUR'], name: 'Cycle Persistence Analyzer', description: 'Determines whether Wyckoff cycles will play out as expected or get interrupted. High Hurst during markup = markup will extend. Low Hurst during markup = premature distribution likely.', bestFor: 'Predicting cycle completion vs interruption', dimensions: ['Cycle Completion Probability', 'Phase Duration Forecast', 'Interruption Risk Level'], category: 'structure', rating: 3 },
  { filters: ['WYK', 'DD'], name: 'Institutional Flow Mapper', description: 'Maps delta divergence onto Wyckoff phases to see exactly when institutional flow contradicts the phase. DD appearing during late markup = distribution confirmed. Phase-specific divergence interpretation.', bestFor: 'Phase-specific divergence interpretation', dimensions: ['Phase-Divergence Alignment', 'Institutional Transition Alert', 'Smart Money Timing Score'], category: 'structure', rating: 4 },
  { filters: ['ENT', 'HUR'], name: 'Market DNA Profiler', description: 'Creates a fundamental fingerprint of market behavior by combining chaos measurement with persistence analysis. Low entropy + high Hurst = textbook trend. High entropy + low Hurst = mean-reverting chaos. Tells you which strategy class to deploy.', bestFor: 'Strategy selection based on market DNA', dimensions: ['Market DNA Profile', 'Strategy Selection Score', 'Regime Fingerprint Clarity'], category: 'regime', rating: 5 },
  { filters: ['ENT', 'DD'], name: 'Divergence Noise Filter', description: 'Filters delta divergences by entropy regime. Divergences in low entropy are clean and reliable. Divergences in high entropy = likely noise. Eliminates 60%+ of false divergence signals.', bestFor: 'Eliminating false divergence signals', dimensions: ['Divergence Quality Gate', 'Noise-Filtered DD Score', 'Signal Purity Index'], category: 'regime', rating: 4 },
  { filters: ['HUR', 'DD'], name: 'Persistent Divergence Engine', description: 'Identifies divergences that will persist (high Hurst) vs those that will fizzle (low Hurst). A divergence in a persistent regime = major reversal building. In a mean-reverting regime = brief pullback only.', bestFor: 'Distinguishing major reversals from minor pullbacks', dimensions: ['Reversal Magnitude Predictor', 'Divergence Persistence Score', 'Pullback vs Reversal Classifier'], category: 'hybrid', rating: 4 },
  { filters: ['OFI', 'FVG', 'ABS'], name: 'Institutional Liquidity X-Ray', description: 'Triple-dimension analysis of WHERE liquidity sits (FVG), WHO is consuming it (OFI), and WHETHER it is being hidden (ABS). Creates a complete institutional liquidity map impossible with any pair.', bestFor: 'Complete institutional liquidity mapping', dimensions: ['Liquidity Architecture Map', 'Hidden Order Topology', 'Institutional Footprint Score', 'Supply/Demand DNA'], category: 'structure', rating: 5 },
  { filters: ['OFI', 'FVG', 'WYK'], name: 'Smart Money Blueprint', description: 'Combines order flow direction with structural gaps and Wyckoff phases to create a complete institutional blueprint. See where smart money entered, where gaps exist, and current flow direction.', bestFor: 'Complete institutional game plan reconstruction', dimensions: ['Blueprint Confidence', 'Institutional Path Mapping', 'Phase-Gap-Flow Trinity Score'], category: 'structure', rating: 5 },
  { filters: ['OFI', 'ABS', 'DD'], name: 'Triple Pressure Fusion', description: 'Three independent pressure measurements fused into one omnidirectional pressure reading. OFI (flow), ABS (hidden), DD (delta) — when all three align, it is the strongest pressure signal mathematically possible.', bestFor: 'Maximum pressure confirmation for entries', dimensions: ['Omnidirectional Pressure Index', 'Triple-Confirmed Direction', 'Pressure Consensus Score'], category: 'momentum', rating: 5 },
  { filters: ['OFI', 'ENT', 'HUR'], name: 'Flow Regime Oracle', description: 'Tells you if current order flow will persist in the current chaos regime. A complete flow-regime-persistence trinity that answers: Is there flow? Is the regime stable? Will it last?', bestFor: 'Complete flow sustainability analysis', dimensions: ['Flow Regime Stability', 'Persistence-in-Regime Score', 'Oracle Confidence Level'], category: 'regime', rating: 4 },
  { filters: ['OFI', 'WYK', 'DD'], name: 'Institutional Pressure Decoder', description: 'Decodes institutional pressure by combining Wyckoff phase context with dual pressure measurements. Shows whether current pressure confirms or challenges the structural phase.', bestFor: 'Institutional phase transition detection', dimensions: ['Phase Pressure Alignment', 'Institutional Decoder Score', 'Transition Pressure Signal'], category: 'structure', rating: 4 },
  { filters: ['FVG', 'ABS', 'WYK'], name: 'Structural Defense Matrix', description: 'Identifies which structural levels (FVG) are being defended (ABS) by institutions (WYK). A triple-layered structural analysis that reveals the strongest support/resistance zones.', bestFor: 'Finding the most defended price levels', dimensions: ['Defense Matrix Score', 'Fortified Level Strength', 'Structural Hierarchy Map'], category: 'structure', rating: 5 },
  { filters: ['FE', 'ENT', 'HUR'], name: 'Market Physics Engine', description: 'Combines energy (FE), chaos (ENT), and persistence (HUR) into a complete market physics model. Like measuring temperature, pressure, and volume simultaneously — describes the complete thermodynamic state.', bestFor: 'Complete market state classification', dimensions: ['Thermodynamic State Index', 'Market Physics Score', 'State Transition Probability', 'Energy-Entropy Product'], category: 'regime', rating: 5 },
  { filters: ['ABS', 'FE', 'DD'], name: 'Coiled Reversal Detector', description: 'Finds points where absorption is compressing energy (FE) while delta diverges (DD). This triple convergence identifies the most explosive reversal setups — a spring loaded with energy about to release.', bestFor: 'Finding explosive reversal points', dimensions: ['Coil Compression Score', 'Explosive Reversal Probability', 'Spring-Loaded Energy Level'], category: 'momentum', rating: 5 },
  { filters: ['WYK', 'ENT', 'DD'], name: 'Phase Regime Divergence', description: 'Detects when Wyckoff phase transitions are occurring in specific entropy regimes with delta confirmation. Clean phase changes in low entropy = highest reliability.', bestFor: 'Highest-confidence phase transition detection', dimensions: ['Clean Transition Score', 'Regime-Phase-Delta Trinity', 'Transition Confidence Level'], category: 'structure', rating: 4 },
  { filters: ['OFI', 'FVG', 'ABS', 'DD'], name: 'Omniscient Pressure Architecture', description: 'Four-dimensional pressure-structure analysis: flow (OFI) + structure (FVG) + hidden orders (ABS) + divergence (DD). Creates a complete market pressure topology that sees everything.', bestFor: 'Complete market pressure and structure mapping', dimensions: ['Pressure Topology Map', 'Omnidirectional Architecture Score', 'Quadrature Pressure Index', 'Hidden Structure Reveal'], category: 'hybrid', rating: 5 },
  { filters: ['OFI', 'WYK', 'FE', 'DD'], name: 'Ultimate Conviction Engine', description: 'The highest-conviction bridge combining flow + institutional cycles + energy + divergence. When all four dimensions align, this produces the strongest trade signals mathematically possible on any platform.', bestFor: 'Maximum conviction trade setups', dimensions: ['Ultimate Conviction Score', 'Quad-Dimension Alignment', 'Energy-Phase-Flow Synergy', 'Maximum Signal Strength'], category: 'hybrid', rating: 5 },
  { filters: ['FVG', 'WYK', 'ENT', 'HUR'], name: 'Structural Regime Scanner', description: 'Four-way structure-regime analysis: gaps (FVG) + phases (WYK) + chaos (ENT) + persistence (HUR). Reveals which structural levels will hold based on the current regime DNA.', bestFor: 'Regime-adaptive structural analysis', dimensions: ['Regime-Structure Alignment', 'Adaptive Level Strength', 'Phase-Regime Coherence', 'Structural Regime Score'], category: 'regime', rating: 4 },
  { filters: ['ABS', 'FE', 'ENT', 'HUR'], name: 'Hidden Physics Engine', description: 'Combines hidden order detection with the complete market physics trinity. Reveals whether absorption is occurring in organized or chaotic conditions, with energy and persistence context.', bestFor: 'Physics-contextualized absorption analysis', dimensions: ['Physics-Absorption Synthesis', 'Hidden Energy-Entropy Product', 'Contextualized Stealth Score', 'Physics Engine Confidence'], category: 'regime', rating: 4 },
  { filters: ['OFI', 'FVG', 'WYK', 'ENT'], name: 'Institutional Chaos Filter', description: 'Four-way analysis filtering institutional signals (OFI+FVG+WYK) through entropy chaos measurement. Only passes institutional signals that occur in clean, low-chaos regimes.', bestFor: 'Noise-free institutional signal generation', dimensions: ['Chaos-Filtered Institutional Score', 'Clean Signal Quality Gate', 'Regime-Validated Blueprint', 'Noise Rejection Ratio'], category: 'structure', rating: 5 },

  { filters: ['ACM', 'QFRM'], name: 'Convergence-Resonance Harmonic', description: 'Bridges momentum convergence with quantum flow resonance to detect when multi-dimensional momentum aligns with harmonic price frequencies. The convergence matrix identifies momentum agreement while QFRM reveals whether that momentum rides a natural resonance wave.', bestFor: 'Detecting harmonic momentum amplification', dimensions: ['Harmonic Convergence Index', 'Resonance-Momentum Sync', 'Quantum Convergence Strength', 'Wave-Momentum Phase Lock'], category: 'meta', rating: 5 },
  { filters: ['ACM', 'BIF'], name: 'Macro-Micro Intelligence Bridge', description: 'Fuses market-level convergence signals with blockchain infrastructure health. ACM captures price/volume/smart money momentum while BIF monitors the underlying network — together they reveal whether market signals are backed by blockchain fundamentals.', bestFor: 'Validating market signals with blockchain health', dimensions: ['Market-Chain Alignment Score', 'Infrastructure-Backed Signal Quality', 'Macro-Micro Coherence Index'], category: 'meta', rating: 4 },
  { filters: ['ACM', 'SBPE'], name: 'Predictive Convergence System', description: 'Combines current multi-dimensional convergence with stochastic forward-looking predictions. ACM tells you where the market IS, SBPE predicts where it WILL BE — together they create a convergence-weighted prediction engine.', bestFor: 'Forward-looking convergence-weighted predictions', dimensions: ['Predicted Convergence Trajectory', 'Stochastic-Convergence Forecast', 'Time-Shifted Alignment Score'], category: 'meta', rating: 5 },
  { filters: ['QFRM', 'BIF'], name: 'Network Resonance Scanner', description: 'Detects when quantum flow resonance patterns align with blockchain network activity. Natural price harmonics backed by on-chain health create the most reliable trend signals in cryptocurrency markets.', bestFor: 'Finding blockchain-validated resonance events', dimensions: ['Chain-Resonance Coupling', 'Network-Harmonic Frequency Match', 'Infrastructure Resonance Confidence'], category: 'meta', rating: 4 },
  { filters: ['QFRM', 'SBPE'], name: 'Quantum Prediction Matrix', description: 'Combines quantum flow analysis with stochastic block predictions to create probability-weighted quantum forecasts. QFRM identifies current flow state while SBPE projects future direction — a temporal quantum bridge.', bestFor: 'Probability-weighted quantum flow forecasting', dimensions: ['Quantum Forecast Score', 'Flow-Prediction Coupling', 'Temporal Resonance Alignment'], category: 'meta', rating: 5 },
  { filters: ['BIF', 'SBPE'], name: 'Blockchain Prediction Engine', description: 'Directly bridges blockchain intelligence with stochastic block prediction for pure on-chain predictive power. Network health informs prediction accuracy — predictions during healthy network states are more reliable.', bestFor: 'On-chain prediction with health-adjusted confidence', dimensions: ['Health-Adjusted Prediction Score', 'Chain-Forecast Reliability', 'Block Intelligence Forecast'], category: 'meta', rating: 4 },
  { filters: ['ACM', 'QFRM', 'BIF'], name: 'Triple Technology Fusion Core', description: 'Three proprietary technologies creating a complete analysis stack: market convergence (ACM) + price harmonics (QFRM) + blockchain health (BIF). This trio covers market sentiment, natural frequencies, and infrastructure.', bestFor: 'Complete proprietary technology stack analysis', dimensions: ['Triple-Tech Convergence', 'Full-Stack Signal Quality', 'Technology Consensus Score', 'Multi-Tech Synergy Index'], category: 'meta', rating: 5 },
  { filters: ['ACM', 'QFRM', 'SBPE'], name: 'Temporal Convergence Oracle', description: 'Convergence + resonance + prediction creates a temporal oracle: where momentum agrees (ACM), at what frequency (QFRM), and where it is heading (SBPE).', bestFor: 'Three-dimensional temporal market analysis', dimensions: ['Oracle Forecast Score', 'Temporal Convergence Matrix', 'Predictive Resonance Signal', 'Time-Series Intelligence'], category: 'meta', rating: 5 },
  { filters: ['ACM', 'BIF', 'SBPE'], name: 'Infrastructure Prediction Bridge', description: 'Market convergence validated by blockchain health with forward predictions. The most comprehensive on-chain-aware prediction system.', bestFor: 'Infrastructure-validated forward predictions', dimensions: ['Chain-Validated Forecast', 'Infrastructure Prediction Confidence', 'Convergence Forecast Synthesis'], category: 'meta', rating: 4 },
  { filters: ['QFRM', 'BIF', 'SBPE'], name: 'Quantum Chain Prediction', description: 'Pure blockchain technology fusion: resonance + intelligence + prediction. Analyzes market through three different blockchain lenses simultaneously.', bestFor: 'Pure blockchain technology signal synthesis', dimensions: ['Quantum Chain Signal', 'Triple-Chain Technology Score', 'Blockchain Fusion Confidence'], category: 'meta', rating: 4 },
  { filters: ['ACM', 'QFRM', 'BIF', 'SBPE'], name: 'Omniscient Technology Matrix', description: 'The four original proprietary technologies fused into a single omniscient signal. Convergence + resonance + blockchain intelligence + prediction = the most powerful composite signal possible.', bestFor: 'Maximum technology fusion — complete analytical omniscience', dimensions: ['Omniscient Technology Score', 'Quad-Tech Synthesis Index', 'Full Technology Convergence', 'Maximum Intelligence Signal', 'Technology Singularity Score'], category: 'meta', rating: 5 },

  { filters: ['ANCE', 'TMDE'], name: 'Neural Temporal Intelligence', description: '7-layer neural confluence meets 6-timeframe temporal divergence. AI-validated temporal momentum signals with maximum dimensional coverage.', bestFor: 'AI-validated temporal momentum signals', dimensions: ['Neural-Temporal Agreement Index', 'AI Temporal Confluence Score', 'Layer-Timeframe Coherence'], category: 'meta', rating: 5 },
  { filters: ['ANCE', 'QMGE'], name: 'Neural Genome Intelligence', description: '7-layer neural AI meets 7-dimensional genome mapping. The most comprehensive AI+multi-dimensional analysis available — 14 total dimensions.', bestFor: 'Maximum AI-powered multi-dimensional analysis', dimensions: ['Neural-Genome Synthesis Score', 'AI-DNA Intelligence Index', 'Total Dimensional Coverage (14D)'], category: 'meta', rating: 5 },
  { filters: ['TMDE', 'QMGE'], name: 'Genome Temporal Engine', description: '7-dimensional genome mapping meets 6-timeframe divergence. Creates a 13-dimensional market view — the broadest perspective available.', bestFor: 'Maximum dimensional market coverage (13D)', dimensions: ['Genome-Temporal Synthesis', '13-Dimensional Market View', 'Temporal Genome Pattern Score'], category: 'meta', rating: 5 },
  { filters: ['TMDE', 'ACM'], name: 'Temporal Convergence Scanner', description: 'Cross-timeframe momentum divergence meets multi-indicator convergence. Detects momentum regime shifts with convergence confirmation.', bestFor: 'Identifying momentum regime shifts', dimensions: ['Temporal-Convergence Alignment', 'Cross-Timeframe Consensus Shift', 'Momentum Regime Transition Score'], category: 'meta', rating: 4 },
  { filters: ['QMGE', 'ACM'], name: 'Genome Convergence Matrix', description: '7-dimensional genome analysis meets multi-indicator convergence detection. Genome DNA patterns validated by broad convergence signals.', bestFor: 'Genome-validated convergence opportunities', dimensions: ['Genome-Convergence Alignment', 'DNA Pattern Convergence Score', 'Multi-Dimensional Consensus Index'], category: 'meta', rating: 5 },
  { filters: ['QMGE', 'QFRM'], name: 'Quantum Genome Resonance', description: 'Two quantum technologies working together — genome mapping meets flow resonance harmonics. Detects deep market structure at genome-frequency intersection.', bestFor: 'Deep quantum market structure analysis', dimensions: ['Dual-Quantum Resonance Index', 'Genome-Harmonic Pattern Lock', 'Quantum Structure Depth Score'], category: 'meta', rating: 5 },
  { filters: ['ANCE', 'ACM'], name: 'Neural Convergence Amplifier', description: '7-layer AI scoring meets multi-dimensional convergence. When neural intelligence confirms convergence signals, confidence multiplies.', bestFor: 'AI-amplified convergence detection', dimensions: ['Neural Convergence Score', 'AI-Validated Convergence', 'Amplified Intelligence Signal'], category: 'meta', rating: 5 },
  { filters: ['TMDE', 'QMGE', 'ANCE'], name: 'Trinity Intelligence Engine', description: 'The ultimate triple fusion: QMGE 7D genome + TMDE 6-timeframe + ANCE 7-layer neural = 20-dimensional analysis. The most comprehensive on any platform.', bestFor: 'Maximum intelligence — 20-dimensional analysis', dimensions: ['Trinity Intelligence Score', '20-Dimensional Market View', 'Triple-Tech Convergence Index', 'Ultimate Confidence Rating'], category: 'meta', rating: 5 },
  { filters: ['ACM', 'QFRM', 'BIF', 'SBPE', 'ANCE', 'TMDE', 'QMGE'], name: 'Alpha Omniscient Engine', description: 'ALL seven proprietary technologies fused into a single omniscient signal. The complete Alpha Unlimited technology stack working as one unified intelligence.', bestFor: 'Complete technology omniscience — all 7 proprietary technologies', dimensions: ['Omniscient Technology Score', 'Seven-Tech Synthesis', 'Complete Intelligence Signal', 'Total Technology Convergence', 'Alpha Unlimited Singularity Score'], category: 'meta', rating: 5 },

  { filters: ['ACM', 'OFI'], name: 'Convergence Flow Amplifier', description: 'ACM multi-dimensional convergence amplified by raw order flow data. When all ACM dimensions converge AND order flow confirms, signal strength multiplies.', bestFor: 'Flow-amplified convergence signals', dimensions: ['Convergence-Flow Product', 'Amplified Signal Strength', 'Flow-Validated Convergence'], category: 'momentum', rating: 4 },
  { filters: ['ACM', 'WYK'], name: 'Convergence Phase Engine', description: 'Maps ACM convergence onto Wyckoff institutional cycles. Convergence during accumulation = highest-probability entries.', bestFor: 'Phase-aware convergence analysis', dimensions: ['Phase-Convergence Alignment', 'Institutional Convergence Score', 'Cycle-Convergence Timing'], category: 'structure', rating: 5 },
  { filters: ['ACM', 'DD'], name: 'Convergence Divergence Detector', description: 'When ACM shows convergence but delta diverges, it creates a paradox signal — the most powerful pre-reversal indicator possible.', bestFor: 'Detecting convergence-divergence paradox reversals', dimensions: ['Paradox Signal Strength', 'Convergence-Divergence Gap', 'Paradox Resolution Direction'], category: 'momentum', rating: 5 },
  { filters: ['ACM', 'ENT'], name: 'Convergence Regime Filter', description: 'Filters ACM convergence signals through entropy regime analysis. Only convergence in low-entropy (organized) regimes passes through.', bestFor: 'Regime-filtered convergence signals', dimensions: ['Regime-Filtered Convergence', 'Organized Convergence Score', 'Entropy-Gated Signal Quality'], category: 'regime', rating: 4 },
  { filters: ['QFRM', 'FE'], name: 'Quantum Energy Resonance', description: 'Bridges quantum flow harmonics with fractal energy measurement. Resonance events with high fractal energy = maximum move potential.', bestFor: 'Energy-backed quantum resonance events', dimensions: ['Quantum Energy Product', 'Resonance Energy Level', 'Harmonic Fuel Score'], category: 'hybrid', rating: 5 },
  { filters: ['QFRM', 'ENT'], name: 'Quantum Entropy Synthesis', description: 'Two entropy-adjacent technologies bridged: QFRM entropy gradient meets ENT regime classification. Creates a dual-entropy map of market chaos.', bestFor: 'Complete chaos/order market profiling', dimensions: ['Dual-Entropy Map', 'Quantum Chaos Score', 'Entropy Synthesis Index'], category: 'regime', rating: 4 },
  { filters: ['QFRM', 'HUR'], name: 'Quantum Persistence Analyzer', description: 'Determines if quantum flow resonance events will persist or dissipate using Hurst exponent analysis.', bestFor: 'Predicting resonance event duration', dimensions: ['Resonance Persistence Score', 'Quantum Hurst Coupling', 'Event Duration Forecast'], category: 'hybrid', rating: 4 },
  { filters: ['BIF', 'OFI'], name: 'On-Chain Flow Intelligence', description: 'Bridges blockchain network intelligence with order flow to see if flow matches on-chain activity.', bestFor: 'On-chain validated order flow', dimensions: ['Chain-Flow Alignment', 'On-Chain Order Intelligence', 'Network-Flow Coherence'], category: 'hybrid', rating: 4 },
  { filters: ['BIF', 'WYK'], name: 'Blockchain Phase Detector', description: 'Maps blockchain health onto Wyckoff phases — healthy network during accumulation = strongest institutional signal.', bestFor: 'Blockchain-aware institutional analysis', dimensions: ['Chain-Phase Alignment', 'Network-Backed Phase Score', 'Blockchain Institutional Signal'], category: 'structure', rating: 4 },
  { filters: ['BIF', 'DD'], name: 'Chain Delta Intelligence', description: 'Bridges blockchain metrics with delta divergence. Delta divergence backed by network health changes = blockchain-confirmed reversals.', bestFor: 'Blockchain-confirmed delta reversals', dimensions: ['Chain-Delta Alignment', 'Network Divergence Score', 'Blockchain Reversal Signal'], category: 'momentum', rating: 4 },
  { filters: ['SBPE', 'OFI'], name: 'Predictive Flow Engine', description: 'Forward predictions enhanced by real-time order flow. Current flow direction informs prediction accuracy.', bestFor: 'Flow-enhanced forward predictions', dimensions: ['Flow-Prediction Coupling', 'Predictive Flow Score', 'Enhanced Forecast Accuracy'], category: 'momentum', rating: 4 },
  { filters: ['SBPE', 'RSI'], name: 'Stochastic Momentum Predictor', description: 'Combines block prediction with RSI momentum to create momentum-aware forecasts.', bestFor: 'Momentum-informed stochastic predictions', dimensions: ['Momentum Prediction Score', 'RSI-Forecast Alignment', 'Momentum-Weighted Prediction'], category: 'momentum', rating: 4 },
  { filters: ['SBPE', 'STOCH'], name: 'Dual Stochastic Engine', description: 'Two stochastic systems bridged: block prediction stochastics + classic stochastic oscillator. Creates a reinforced oscillation analysis.', bestFor: 'Dual-stochastic oscillation analysis', dimensions: ['Dual-Stochastic Confluence', 'Reinforced Oscillation Score', 'Cross-Stochastic Signal'], category: 'hybrid', rating: 4 },

  { filters: ['RSI', 'OFI'], name: 'Momentum Flow Validator', description: 'Classic RSI momentum validated by raw order flow. RSI overbought + negative OFI = confirmed reversal. RSI oversold + positive OFI = confirmed bounce.', bestFor: 'Classic momentum with flow confirmation', dimensions: ['Flow-Validated RSI', 'Momentum-Flow Agreement', 'Confirmed Reversal Score'], category: 'momentum', rating: 4 },
  { filters: ['RSI', 'WYK'], name: 'Phase Momentum Scanner', description: 'RSI momentum within Wyckoff context. RSI oversold during accumulation = highest probability long entry signal.', bestFor: 'Phase-contextualized momentum entries', dimensions: ['Phase-RSI Alignment', 'Contextual Momentum Score', 'Wyckoff-RSI Signal'], category: 'structure', rating: 4 },
  { filters: ['RSI', 'ENT'], name: 'Momentum Regime Gate', description: 'Gates RSI signals through entropy regime. RSI signals in low-entropy only = massive noise reduction.', bestFor: 'Regime-filtered RSI signals', dimensions: ['Regime-Gated RSI', 'Clean Momentum Score', 'Entropy-RSI Quality'], category: 'regime', rating: 4 },
  { filters: ['MACD', 'OFI'], name: 'Signal Flow Crossover', description: 'MACD crossovers confirmed by order flow direction. Bullish crossover + positive OFI = confirmed trend start.', bestFor: 'Flow-confirmed MACD crossovers', dimensions: ['Crossover-Flow Confirmation', 'Signal-Flow Product', 'Confirmed Crossover Strength'], category: 'momentum', rating: 4 },
  { filters: ['MACD', 'FE'], name: 'Signal Energy System', description: 'MACD signal backed by fractal energy — only act on crossovers with sufficient energy to follow through.', bestFor: 'Energy-backed signal crossovers', dimensions: ['Energized Signal Score', 'Crossover Energy Level', 'Follow-Through Forecast'], category: 'hybrid', rating: 4 },
  { filters: ['BB', 'ENT'], name: 'Volatility Entropy Bridge', description: 'Bollinger Band width meets entropy regime. Squeeze in low entropy = organized breakout imminent. Squeeze in high entropy = false signal.', bestFor: 'Distinguishing real squeezes from noise', dimensions: ['Squeeze Quality Score', 'Entropy-Band Coherence', 'Organized Squeeze Signal'], category: 'regime', rating: 4 },
  { filters: ['BB', 'HUR'], name: 'Band Persistence Analyzer', description: 'Predicts whether Bollinger Band touches will lead to reversals (low Hurst) or trend continuation (high Hurst).', bestFor: 'Band touch outcome prediction', dimensions: ['Band Touch Prediction', 'Persistence-Band Score', 'Touch Outcome Probability'], category: 'hybrid', rating: 3 },
  { filters: ['ADX', 'WYK'], name: 'Trend Phase Compass', description: 'ADX trend strength mapped onto Wyckoff phases. Strong ADX during markup confirms trend. Falling ADX during markup = distribution beginning.', bestFor: 'Phase-aware trend strength assessment', dimensions: ['Phase-Trend Alignment', 'Trend Phase Score', 'Phase Transition Alert'], category: 'structure', rating: 4 },
  { filters: ['OBV', 'ABS'], name: 'Volume Absorption Detector', description: 'OBV trend meets absorption detection. Rising OBV + absorption = smart money accumulating. Falling OBV + absorption = distribution being masked.', bestFor: 'Smart money volume analysis', dimensions: ['Smart Volume Score', 'Absorption-Volume Alignment', 'Hidden Volume Activity'], category: 'momentum', rating: 4 },
  { filters: ['OBV', 'DD'], name: 'Volume Delta Cross-Check', description: 'Two independent volume-based pressure measurements cross-checked. OBV and DD agreement = strongest volume confirmation.', bestFor: 'Maximum volume pressure confirmation', dimensions: ['Volume Cross-Check Score', 'Dual-Volume Agreement', 'Pressure Confirmation Level'], category: 'momentum', rating: 4 },
  { filters: ['STOCH', 'DD'], name: 'Oscillator Divergence Fusion', description: 'Stochastic oscillator extremes combined with delta divergence creates a double-divergence detector.', bestFor: 'Double divergence detection', dimensions: ['Double Divergence Score', 'Oscillator-Delta Confluence', 'Reinforced Divergence Signal'], category: 'momentum', rating: 4 },
  { filters: ['RSI', 'ACM'], name: 'Classic-Proprietary Momentum Bridge', description: 'Bridges classical RSI with proprietary ACM convergence. When both classic and proprietary agree, conviction is maximum.', bestFor: 'Cross-paradigm momentum confirmation', dimensions: ['Classic-Proprietary Agreement', 'Cross-Paradigm Score', 'Dual-System Confidence'], category: 'hybrid', rating: 5 },
  { filters: ['MACD', 'QFRM'], name: 'Signal-Quantum Resonance', description: 'MACD signal line meets quantum flow resonance. MACD crossovers at quantum resonance frequencies = most powerful crossovers.', bestFor: 'Resonance-timed signal crossovers', dimensions: ['Resonance-Timed Signal', 'Quantum-MACD Coupling', 'Harmonic Crossover Score'], category: 'hybrid', rating: 5 },
];

function ComboCard({ combo, expanded, onToggle }: { combo: ComboEntry; expanded: boolean; onToggle: () => void }) {
  const categoryColors: Record<string, string> = {
    momentum: 'from-red-500/10 to-orange-500/10 border-red-500/20',
    structure: 'from-blue-500/10 to-cyan-500/10 border-blue-500/20',
    regime: 'from-purple-500/10 to-violet-500/10 border-purple-500/20',
    hybrid: 'from-yellow-500/10 to-amber-500/10 border-yellow-500/20',
    meta: 'from-emerald-500/10 to-teal-500/10 border-emerald-500/20',
  };
  const categoryTextColors: Record<string, string> = {
    momentum: 'text-red-400',
    structure: 'text-blue-400',
    regime: 'text-purple-400',
    hybrid: 'text-yellow-400',
    meta: 'text-emerald-400',
  };

  return (
    <div className={`bg-gradient-to-r ${categoryColors[combo.category] || categoryColors.hybrid} rounded-lg border cursor-pointer hover:brightness-110 transition-all`} onClick={onToggle} data-testid={`combo-card-${combo.filters.join('-')}`}>
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className={`font-bold text-sm ${categoryTextColors[combo.category] || 'text-yellow-400'}`}>{combo.name}</h3>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800/50 text-gray-400 uppercase">{combo.category}</span>
            </div>
            <div className="flex items-center gap-1.5 mb-2">
              {combo.filters.map((f, i) => (
                <span key={f} className="flex items-center gap-1">
                  {i > 0 && <span className="text-gray-600 text-xs">+</span>}
                  <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold" style={{ backgroundColor: `${FILTER_INFO[f]?.color}20`, color: FILTER_INFO[f]?.color, border: `1px solid ${FILTER_INFO[f]?.color}40` }}>
                    {f}
                  </span>
                </span>
              ))}
              <div className="ml-auto flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className={`text-xs ${i < combo.rating ? 'text-yellow-400' : 'text-gray-700'}`}>★</span>
                ))}
              </div>
            </div>
            <p className="text-xs text-gray-400">{combo.bestFor}</p>
          </div>
          <div className="ml-2 text-gray-500">
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </div>
      </div>
      {expanded && (
        <div className="px-4 pb-4 pt-0 border-t border-gray-700/30 mt-0">
          <div className="mt-3 space-y-3">
            <div>
              <p className="text-sm text-gray-300 leading-relaxed">{combo.description}</p>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Unique Analytical Dimensions Generated</h4>
              <div className="space-y-1">
                {combo.dimensions.map((dim, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <Sparkles size={12} className="text-yellow-400 flex-shrink-0" />
                    <span className="text-white font-medium">{dim}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-gray-800/30 rounded p-2.5">
              <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Order Effect</h4>
              <p className="text-[11px] text-gray-400">
                The first filter selected becomes the <strong className="text-white">primary lens</strong> (weighted 130%), subsequent filters provide <strong className="text-white">confirmation</strong> (weighted 90% each). 
                Placing {combo.filters[0]} first emphasizes {FILTER_INFO[combo.filters[0]]?.category.toLowerCase()} analysis, while placing {combo.filters[combo.filters.length - 1]} first would shift focus to {FILTER_INFO[combo.filters[combo.filters.length - 1]]?.category.toLowerCase()}.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function LearnBridgeFusion() {
  const [expandedCombo, setExpandedCombo] = useState<string | null>(null);
  const [filterSize, setFilterSize] = useState<'all' | '2' | '3' | '4'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCombos = ALL_COMBOS.filter(c => {
    if (filterSize !== 'all' && c.filters.length !== parseInt(filterSize)) return false;
    if (filterCategory !== 'all' && c.category !== filterCategory) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.bestFor.toLowerCase().includes(q) || c.filters.some(f => f.toLowerCase().includes(q) || FILTER_INFO[f]?.name.toLowerCase().includes(q));
    }
    return true;
  });

  const stats = {
    twoPair: ALL_COMBOS.filter(c => c.filters.length === 2).length,
    threePair: ALL_COMBOS.filter(c => c.filters.length === 3).length,
    fourPair: ALL_COMBOS.filter(c => c.filters.length === 4).length,
    total: ALL_COMBOS.length,
    totalDimensions: ALL_COMBOS.reduce((s, c) => s + c.dimensions.length, 0),
    categories: ['momentum', 'structure', 'regime', 'hybrid', 'meta'].length,
    proprietaryTech: ALL_COMBOS.filter(c => c.filters.some(f => ['ACM', 'QFRM', 'BIF', 'SBPE'].includes(f))).length,
  };

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-[#0A1628] text-white">
        <div className="max-w-5xl mx-auto px-4 py-8">
          <Link href="/alpha-trading/terminal">
            <a className="inline-flex items-center gap-2 text-gray-400 hover:text-[#FFD700] mb-6 transition-colors" data-testid="link-back-terminal">
              <ArrowLeft size={20} />
              Back to Trading Terminal
            </a>
          </Link>

          <div className="flex justify-end mb-2">
            <PageShareBar pageTitle="Bridge Fusion™ Technology" pageDescription="Multi-technology composite indicator system" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-yellow-500/40 to-amber-600/30 flex items-center justify-center">
                <GitMerge className="text-yellow-400" size={32} />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-yellow-400" data-testid="text-page-title">Bridge Fusion™</h1>
                <p className="text-gray-400">Complete Guide — Every Combination, Every Dimension</p>
              </div>
            </div>

            <button
              onClick={() => PDF_GENERATORS.bridgeFusion.fn()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-yellow-500/20 to-amber-500/20 hover:from-yellow-500/30 hover:to-amber-500/30 rounded-xl border border-yellow-500/30 hover:border-yellow-500/50 transition-all text-sm font-bold text-yellow-400"
              data-testid="button-download-bridge-fusion-pdf"
            >
              <Download size={16} />
              Download Bridge Fusion Tutorial PDF
            </button>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-yellow-500/20">
              <h2 className="text-xl font-bold text-white mb-4">What is Bridge Fusion?</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                <span className="text-yellow-400 font-semibold">Bridge Fusion™</span> is Alpha Unlimited Trading's exclusive 
                technology that combines 2-4 Advanced Market Filters, Proprietary Technologies (ACM, QFRM, BIF, SBPE), and 
                standard indicators (RSI, MACD, BB, ADX, OBV, STOCH) into a single composite super-indicator. But it goes far 
                beyond simple averaging — each unique combination creates <strong className="text-white">entirely new 
                analytical dimensions</strong> that don't exist in any individual component. The system thinks for itself, determining 
                what new insights to generate based on which technologies are being fused and in what order.
              </p>
              <p className="text-gray-300 leading-relaxed mb-4">
                Like how combining hydrogen and oxygen creates water — something fundamentally different from either gas — 
                Bridge Fusion synthesizes filter data into new analytical compounds. The order matters too: placing Order Flow 
                as your primary lens creates different insights than placing Wyckoff Phase first, even with the same filters selected.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                <div className="bg-gray-900/50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-yellow-400">{stats.total}</div>
                  <div className="text-xs text-gray-500">Total Combinations</div>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-green-400">{stats.totalDimensions}</div>
                  <div className="text-xs text-gray-500">Unique Dimensions</div>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-purple-400">{stats.categories}</div>
                  <div className="text-xs text-gray-500">Categories</div>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-cyan-400">∞</div>
                  <div className="text-xs text-gray-500">Meta-Fusion Depth</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-xl p-6 border border-green-500/30">
              <div className="flex items-center gap-3 mb-2">
                <Target size={24} className="text-green-400" />
                <h2 className="text-xl font-bold text-green-400">Exhaustive Multi-Technology Fusion Rankings</h2>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Comprehensive scan: <strong className="text-white">241,977 signal events</strong>, <strong className="text-white">48 cryptocurrencies</strong>, 
                6-month holdout validation (65/35 split). <strong className="text-white">1,368 multi-tech fusions</strong> tested (87 two-way, 368 three-way, 913 four-way) 
                plus <strong className="text-white">1,579 signal-specific pairings</strong>. All results ranked by holdout accuracy on unseen coins.
              </p>

              <div className="mb-6">
                <h3 className="text-sm font-bold text-yellow-400 mb-3 flex items-center gap-2"><Layers size={16} />Top 4-Way Fusions (Ranked by Holdout Accuracy)</h3>
                <div className="space-y-2">
                  {[
                    { combo: 'SBPE+ANCE+H/S+Filters', lean: 'Strong Bearish', accuracy: 100, trAcc: 87, n: 24, tip: 'When all four technologies fire strong bearish signals simultaneously, price dropped 100% of the time in holdout validation. The ultimate bearish confirmation stack.' },
                    { combo: 'SBPE+WSI+H/S+Filters', lean: 'Strong Bearish', accuracy: 100, trAcc: 87.8, n: 20, tip: 'Stochastic prediction + whale activity + pattern detection + market filters — perfect holdout accuracy when all align bearish.' },
                    { combo: 'ACM+BIF+TMDE+Filters', lean: 'Strong Bearish', accuracy: 100, trAcc: 55, n: 17, tip: 'Convergence matrix + blockchain intelligence + temporal divergence + filters — 100% holdout when all signal strong bearish.' },
                    { combo: 'SBPE+ANCE+MFT+H/S', lean: 'Strong Bullish', accuracy: 100, trAcc: 59, n: 16, tip: 'The top bullish 4-way fusion — stochastic prediction + neural confluence + fractal trap + pattern detection all bullish = 100% holdout.' },
                    { combo: 'TMDE+QMGE+MFT+Filters', lean: 'Strong Bearish', accuracy: 100, trAcc: 76.7, n: 9, tip: 'Temporal divergence + genome engine + fractal trap + filters — 100% holdout (smaller sample, 9 events).' },
                    { combo: 'SBPE+TMDE+QMGE+ERT', lean: 'Strong Bearish', accuracy: 100, trAcc: 100, n: 7, tip: 'Four prediction engines aligned strong bearish — 100% holdout and 100% training accuracy (7 holdout events).' },
                    { combo: 'SBPE+QMGE+WSI+Filters', lean: 'Strong Bullish', accuracy: 100, trAcc: 56.6, n: 6, tip: 'Bullish 4-way: stochastic + genome + whale + filters all bullish — 100% holdout (6 events).' },
                    { combo: 'QFRM+SBPE+H/S+Filters', lean: 'Strong Bearish', accuracy: 93.1, trAcc: 94.1, n: 29, tip: 'Quantum flow + stochastic prediction + head/shoulders + filters — 93.1% holdout with strong training confirmation (94.1%).' },
                    { combo: 'SBPE+ERT+H/S+Filters', lean: 'Strong Bearish', accuracy: 90.9, trAcc: 92.7, n: 22, tip: 'Stochastic prediction + EMA ribbon + pattern detection + filters — 90.9% holdout accuracy.' },
                    { combo: 'ACM+BIF+SBPE+Filters', lean: 'Strong Bearish', accuracy: 87.5, trAcc: 60, n: 40, tip: 'Four core proprietary techs aligned bearish = 87.5% accuracy across 40 holdout events.' },
                    { combo: 'SBPE+MFT+H/S+Filters', lean: 'Strong Bearish', accuracy: 86.7, trAcc: 87, n: 15, tip: 'Stochastic prediction + fractal trap + head/shoulders + filters — 86.7% holdout.' },
                    { combo: 'BIF+SBPE+WSI+Filters', lean: 'Strong Bearish', accuracy: 84.7, trAcc: 75, n: 59, tip: 'Blockchain + stochastic + whale + filters — 84.7% holdout with strong 59-event sample.' },
                    { combo: 'SBPE+QMGE+WSI+Filters', lean: 'Strong Bearish', accuracy: 83.6, trAcc: 69.5, n: 55, tip: 'Stochastic + genome + whale + filters — 83.6% with 55 holdout events.' },
                    { combo: 'BIF+SBPE+QMGE+Filters', lean: 'Strong Bearish', accuracy: 82.5, trAcc: 55.1, n: 63, tip: 'Blockchain + stochastic + genome + filters — 82.5% with 63-event holdout.' },
                    { combo: 'QFRM+SBPE+ANCE+TMDE', lean: 'Strong Bearish', accuracy: 82.4, trAcc: 100, n: 17, tip: 'Four proprietary prediction engines aligned = 82.4% holdout, 100% training accuracy.' },
                  ].map((p, i) => (
                    <div key={i} className="bg-gray-900/60 rounded-lg p-3 border border-gray-700/50 hover:border-green-500/30 transition-colors" data-testid={`validated-4way-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-gray-600 w-7 text-right shrink-0">#{i + 1}</div>
                        <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                          {p.combo.split('+').map((t, ti) => (
                            <span key={ti} className="flex items-center gap-1">
                              {ti > 0 && <span className="text-gray-600 text-xs">+</span>}
                              <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold bg-yellow-500/10 text-yellow-400 border border-yellow-500/30">{t}</span>
                            </span>
                          ))}
                        </div>
                        <div className="shrink-0">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold tracking-wide ${p.lean.includes('Bullish') ? 'bg-green-500/20 text-green-400 border border-green-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'}`}>
                            {p.lean.includes('Bullish') ? '▲ BUY SIGNAL' : '▼ SELL SIGNAL'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs text-gray-500">n={p.n}</span>
                          <div className={`text-sm font-bold ${p.accuracy >= 90 ? 'text-green-400' : p.accuracy >= 80 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                            {p.accuracy}%
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-500 mt-1 ml-10">{p.tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-sm font-bold text-cyan-400 mb-3 flex items-center gap-2"><Layers size={16} />Top 3-Way Fusions</h3>
                <div className="space-y-2">
                  {[
                    { combo: 'SBPE+H/S+Filters', lean: 'Strong Bearish', accuracy: 93.8, trAcc: 90.3, n: 32, tip: 'Stochastic prediction + head/shoulders + filters — 93.8% holdout accuracy across 32 events. The most reliable 3-way fusion.' },
                    { combo: 'ACM+MFT+H/S', lean: 'Strong Bearish', accuracy: 83.7, trAcc: 54.3, n: 43, tip: 'Convergence matrix + fractal trap + head/shoulders — 83.7% holdout with 43-event validation.' },
                    { combo: 'QMGE+MFT+Filters', lean: 'Strong Bearish', accuracy: 77, trAcc: 63.8, n: 100, tip: 'Genome engine + fractal trap + filters — 77% accuracy with the largest 3-way sample (100 events).' },
                    { combo: 'BIF+SBPE+Filters', lean: 'Strong Bearish', accuracy: 76.7, trAcc: 65.6, n: 103, tip: 'Blockchain intelligence + stochastic prediction + filters — 76.7% with 103-event holdout.' },
                    { combo: 'TMDE+H/S+Filters', lean: 'Strong Bullish', accuracy: 76.3, trAcc: 52.9, n: 38, tip: 'Top bullish 3-way: temporal divergence + pattern detection + filters = 76.3% accuracy on upward moves.' },
                    { combo: 'ACM+TMDE+Filters', lean: 'Strong Bearish', accuracy: 74.5, trAcc: 62.5, n: 106, tip: 'Convergence matrix + temporal divergence + filters — 74.5% holdout across 106 events.' },
                    { combo: 'SBPE+ANCE+TMDE', lean: 'Strong Bearish', accuracy: 72, trAcc: 91.8, n: 25, tip: 'Three prediction engines aligned bearish — 72% holdout, 91.8% training accuracy.' },
                    { combo: 'TMDE+QMGE+Filters', lean: 'Strong Bearish', accuracy: 71, trAcc: 69.5, n: 62, tip: 'Temporal divergence + genome engine + filters — 71% holdout with 62-event sample.' },
                    { combo: 'SBPE+ANCE+TMDE', lean: 'Strong Bullish', accuracy: 70.3, trAcc: 70, n: 91, tip: 'Same trio bullish — 70.3% accuracy with strong 91-event sample. Works in both directions.' },
                  ].map((p, i) => (
                    <div key={i} className="bg-gray-900/60 rounded-lg p-3 border border-gray-700/50 hover:border-cyan-500/30 transition-colors" data-testid={`validated-3way-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-gray-600 w-7 text-right shrink-0">#{i + 1}</div>
                        <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                          {p.combo.split('+').map((t, ti) => (
                            <span key={ti} className="flex items-center gap-1">
                              {ti > 0 && <span className="text-gray-600 text-xs">+</span>}
                              <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">{t}</span>
                            </span>
                          ))}
                        </div>
                        <div className="shrink-0">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold tracking-wide ${p.lean.includes('Bullish') ? 'bg-green-500/20 text-green-400 border border-green-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'}`}>
                            {p.lean.includes('Bullish') ? '▲ BUY SIGNAL' : '▼ SELL SIGNAL'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs text-gray-500">n={p.n}</span>
                          <div className={`text-sm font-bold ${p.accuracy >= 90 ? 'text-green-400' : p.accuracy >= 75 ? 'text-emerald-400' : p.accuracy >= 65 ? 'text-yellow-400' : 'text-gray-400'}`}>
                            {p.accuracy}%
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-500 mt-1 ml-10">{p.tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-sm font-bold text-purple-400 mb-3 flex items-center gap-2"><Layers size={16} />Top 2-Way Proprietary Fusions</h3>
                <div className="space-y-2">
                  {[
                    { combo: 'MFT+Filters', lean: 'Strong Bearish', accuracy: 63, n: 300, tip: 'Fractal trap + filters — highest 2-way holdout accuracy at 63% with 300-event validation.' },
                    { combo: 'QMGE+Filters', lean: 'Strong Bearish', accuracy: 62.9, n: 342, tip: 'Genome engine + filters — 62.9% holdout across 342 events.' },
                    { combo: 'SBPE+Filters', lean: 'Strong Bearish', accuracy: 61.8, n: 251, tip: 'Stochastic prediction + filters — 61.8% holdout with 251 events.' },
                    { combo: 'SBPE+TMDE', lean: 'Strong Bearish', accuracy: 61.3, n: 651, tip: 'Stochastic prediction + temporal divergence — 61.3% holdout with a robust 651-event sample.' },
                    { combo: 'SBPE+H/S', lean: 'Bearish Lean', accuracy: 60.7, n: 476, tip: 'Stochastic prediction + head/shoulders — 60.7% holdout across 476 events.' },
                    { combo: 'BIF+SBPE', lean: 'Strong Bearish', accuracy: 60.4, n: 2244, tip: 'Blockchain intelligence + stochastic prediction — 60.4% with massive 2,244-event validation.' },
                  ].map((p, i) => (
                    <div key={i} className="bg-gray-900/60 rounded-lg p-3 border border-gray-700/50 hover:border-purple-500/30 transition-colors" data-testid={`validated-2way-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-gray-600 w-7 text-right shrink-0">#{i + 1}</div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {p.combo.split('+').map((t, ti) => (
                            <span key={ti} className="flex items-center gap-1">
                              {ti > 0 && <span className="text-gray-600 text-xs">+</span>}
                              <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold bg-purple-500/10 text-purple-400 border border-purple-500/30">{t}</span>
                            </span>
                          ))}
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-xs text-gray-500">{p.lean}</span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs text-gray-500">n={p.n.toLocaleString()}</span>
                          <div className={`text-sm font-bold ${p.accuracy >= 62 ? 'text-yellow-400' : 'text-gray-400'}`}>
                            {p.accuracy}%
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-500 mt-1 ml-10">{p.tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-sm font-bold text-orange-400 mb-3 flex items-center gap-2"><Activity size={16} />Signal-Specific Best Pairings (Tech + Indicator at Market Event)</h3>
                <p className="text-gray-500 text-xs mb-3">When a specific market condition (RSI overbought, Ichimoku cross, etc.) triggers, which proprietary tech pair confirms most accurately?</p>
                <div className="space-y-2">
                  {[
                    { signal: 'Ichimoku TK Bear Cross', combo: 'SBPE+Filters', accuracy: 90, n: 10, tip: 'When Ichimoku TK cross goes bearish and SBPE+Filters both confirm — 90% holdout accuracy.' },
                    { signal: 'VSA No Demand', combo: 'BIF+H/S', accuracy: 89.5, n: 19, tip: 'Volume Spread Analysis shows no demand + blockchain intelligence and head/shoulders confirm — 89.5% accuracy.' },
                    { signal: 'Ichimoku TK Bear Cross', combo: 'QFRM+SBPE', accuracy: 88.9, n: 18, tip: 'Ichimoku bearish TK cross + quantum flow + stochastic prediction = 88.9% holdout.' },
                    { signal: 'Stochastic Overbought', combo: 'BIF+Filters', accuracy: 82.4, n: 17, tip: 'Stochastic overbought + BIF and Filters bearish = 82.4% accuracy.' },
                    { signal: 'Stochastic Overbought', combo: 'BIF+H/S', accuracy: 81.8, n: 22, tip: 'Stochastic overbought + BIF and head/shoulders bearish = 81.8% with 22 events.' },
                    { signal: 'RSI Overbought', combo: 'SBPE+ERT', accuracy: 81.3, n: 16, tip: 'RSI overbought + stochastic prediction and EMA ribbon both bearish = 81.3% holdout.' },
                    { signal: 'RSI Overbought', combo: 'ANCE+Filters', accuracy: 77.8, n: 36, tip: 'RSI overbought + neural confluence and filters confirm bearish = 77.8% with 36 events.' },
                    { signal: 'Parabolic SAR Bearish', combo: 'SBPE+TMDE', accuracy: 77.3, n: 22, tip: 'PSAR flips bearish + stochastic prediction and temporal divergence confirm = 77.3% accuracy.' },
                    { signal: 'SuperTrend Bearish', combo: 'ACM+SBPE', accuracy: 77.8, n: 27, tip: 'SuperTrend flips bearish + convergence matrix and stochastic prediction = 77.8% accuracy.' },
                    { signal: 'ADX Bearish', combo: 'SBPE+TMDE', accuracy: 76.9, n: 13, tip: 'ADX shows bearish trend + stochastic prediction and temporal divergence = 76.9% holdout.' },
                    { signal: 'Bollinger Lower Touch', combo: 'ACM+TMDE', accuracy: 87.5, n: 8, tip: 'BB lower band touch + ACM and TMDE confirm bullish = 87.5% — strong reversal signal.' },
                    { signal: 'Stochastic Oversold', combo: 'ACM+TMDE', accuracy: 64.1, n: 78, tip: 'Stochastic oversold + ACM and TMDE both bullish = 64.1% with largest bullish sample (78 events).' },
                  ].map((p, i) => (
                    <div key={i} className="bg-gray-900/60 rounded-lg p-3 border border-gray-700/50 hover:border-orange-500/30 transition-colors" data-testid={`signal-pairing-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-gray-600 w-7 text-right shrink-0">#{i + 1}</div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-xs px-2 py-0.5 rounded font-mono font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30">{p.signal}</span>
                          <span className="text-gray-600 text-xs">+</span>
                          {p.combo.split('+').map((t, ti) => (
                            <span key={ti} className="flex items-center gap-1">
                              {ti > 0 && <span className="text-gray-600 text-xs">+</span>}
                              <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold bg-orange-500/10 text-orange-400 border border-orange-500/30">{t}</span>
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center gap-2 shrink-0 ml-auto">
                          <span className="text-xs text-gray-500">n={p.n}</span>
                          <div className={`text-sm font-bold ${p.accuracy >= 85 ? 'text-green-400' : p.accuracy >= 75 ? 'text-emerald-400' : p.accuracy >= 65 ? 'text-yellow-400' : 'text-gray-400'}`}>
                            {p.accuracy}%
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-500 mt-1 ml-10">{p.tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-4">
                <h3 className="text-sm font-bold text-gray-300 mb-3 flex items-center gap-2"><Shield size={16} />Technology Presence Analysis</h3>
                <p className="text-gray-500 text-xs mb-3">How often each proprietary technology appears in validated fusions and its average/best holdout accuracy.</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {[
                    { tech: 'SBPE', count: 496, avg: 56.9, best: 100, bestCombo: 'SBPE+ANCE+H/S+Filters', color: '#E040FB' },
                    { tech: 'QMGE', count: 495, avg: 52.9, best: 100, bestCombo: 'TMDE+QMGE+MFT+Filters', color: '#A855F7' },
                    { tech: 'MFT', count: 469, avg: 52.7, best: 100, bestCombo: 'SBPE+ANCE+MFT+H/S', color: '#F43F5E' },
                    { tech: 'H/S', count: 460, avg: 51.6, best: 100, bestCombo: 'SBPE+ANCE+H/S+Filters', color: '#F59E0B' },
                    { tech: 'ACM', count: 428, avg: 50, best: 100, bestCombo: 'ACM+BIF+TMDE+Filters', color: '#FFD700' },
                    { tech: 'Filters', count: 403, avg: 50.6, best: 100, bestCombo: 'SBPE+ANCE+H/S+Filters', color: '#6366f1' },
                    { tech: 'TMDE', count: 382, avg: 53.9, best: 100, bestCombo: 'ACM+BIF+TMDE+Filters', color: '#F43F5E' },
                    { tech: 'ANCE', count: 379, avg: 53, best: 100, bestCombo: 'SBPE+ANCE+H/S+Filters', color: '#10B981' },
                    { tech: 'BIF', count: 378, avg: 51.6, best: 100, bestCombo: 'ACM+BIF+TMDE+Filters', color: '#FF6B35' },
                    { tech: 'WSI', count: 368, avg: 51.4, best: 100, bestCombo: 'SBPE+WSI+H/S+Filters', color: '#8B5CF6' },
                    { tech: 'QFRM', count: 367, avg: 52.7, best: 93.1, bestCombo: 'QFRM+SBPE+H/S+Filters', color: '#00FFAA' },
                    { tech: 'ERT', count: 305, avg: 51.2, best: 100, bestCombo: 'SBPE+TMDE+QMGE+ERT', color: '#FF6B35' },
                  ].map((t, i) => (
                    <div key={i} className="bg-gray-900/50 rounded-lg p-2 border border-gray-700/50" data-testid={`tech-presence-${t.tech}`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold font-mono" style={{ color: t.color }}>{t.tech}</span>
                        <span className="text-[10px] text-gray-500">{t.count} fusions</span>
                      </div>
                      <div className="text-[10px] text-gray-500">
                        Avg: <span className="text-gray-300 font-bold">{t.avg}%</span> | Best: <span className="text-green-400 font-bold">{t.best}%</span>
                      </div>
                      <div className="text-[9px] text-gray-600 truncate" title={t.bestCombo}>Best: {t.bestCombo}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                <div className="bg-green-500/10 rounded-lg p-2 border border-green-500/20 text-center">
                  <div className="text-xl font-bold text-green-400">100%</div>
                  <div className="text-[10px] text-gray-500">Best Holdout Accuracy</div>
                </div>
                <div className="bg-yellow-500/10 rounded-lg p-2 border border-yellow-500/20 text-center">
                  <div className="text-xl font-bold text-yellow-400">1,368</div>
                  <div className="text-[10px] text-gray-500">Multi-Tech Fusions</div>
                </div>
                <div className="bg-purple-500/10 rounded-lg p-2 border border-purple-500/20 text-center">
                  <div className="text-xl font-bold text-purple-400">241,977</div>
                  <div className="text-[10px] text-gray-500">Signal Events</div>
                </div>
                <div className="bg-cyan-500/10 rounded-lg p-2 border border-cyan-500/20 text-center">
                  <div className="text-xl font-bold text-cyan-400">48</div>
                  <div className="text-[10px] text-gray-500">Coins Validated</div>
                </div>
              </div>

              <div className="bg-gray-900/50 rounded-lg p-3 border border-gray-700/50">
                <p className="text-[11px] text-gray-500">
                  <strong className="text-gray-400">How to use:</strong> Open Bridge Fusion in the trading terminal, select the technologies from any validated fusion above. 
                  Higher-way fusions (3-way, 4-way) produce more selective but more accurate signals. 
                  Signal-specific pairings work best when the market condition trigger (RSI overbought, Ichimoku cross, etc.) is also active.
                  All results use 1h candles with 24h forward prediction validated on 17 holdout coins not used in training.
                </p>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-6">How to Use Bridge Fusion</h2>
              <div className="space-y-4">
                <div className="bg-gray-900/50 rounded-lg p-4 border-l-4 border-yellow-500">
                  <h3 className="font-bold text-yellow-400 mb-1">Step 1: Open Bridge Fusion</h3>
                  <p className="text-gray-300 text-sm">Click the <span className="bg-gray-800 px-2 py-0.5 rounded text-yellow-400 font-mono text-sm">🔗 Bridge</span> button in the toolbar.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4 border-l-4 border-yellow-500">
                  <h3 className="font-bold text-yellow-400 mb-1">Step 2: Select Filters</h3>
                  <p className="text-gray-300 text-sm">Choose 2-4 filters for each bridge row. The system validates compatibility automatically. Use the combination guide below to pick the best combo for your trading style.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4 border-l-4 border-yellow-500">
                  <h3 className="font-bold text-yellow-400 mb-1">Step 3: Activate</h3>
                  <p className="text-gray-300 text-sm">Click Activate. The system generates unique analytical dimensions, shows the fusion identity name, and calculates resonance, interference, emergent signals, and cross-derivatives.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4 border-l-4 border-purple-500">
                  <h3 className="font-bold text-purple-400 mb-1">Step 4: Meta-Fusion (Advanced)</h3>
                  <p className="text-gray-300 text-sm">Activate 2+ bridge rows, then use the Meta-Fusion panel to fuse rows together. This creates entirely new cross-row dimensions, meta-emergent signals, and cascading analytical layers with unlimited depth.</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-yellow-500/30">
              <h2 className="text-xl font-bold text-white mb-4">Understanding Fusion Metrics</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-green-400 text-sm mb-2">Resonance</h3>
                  <p className="text-xs text-gray-400"><strong className="text-white">Constructive:</strong> Filters are phase-aligned — signal amplified exponentially like bridged amplifiers. <strong className="text-white">Destructive:</strong> Filters fighting each other — signal unreliable, wait for alignment.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-blue-400 text-sm mb-2">Interference Patterns</h3>
                  <p className="text-xs text-gray-400">Measures how filter waves overlap. Constructive wave = reinforcing signal. Destructive wave = canceling out. Standing wave = stable equilibrium.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-purple-400 text-sm mb-2">Fusion Modes</h3>
                  <p className="text-xs text-gray-400"><strong className="text-white">Cross-Correlation</strong> (2 filters), <strong className="text-white">Triangulation</strong> (3), <strong className="text-white">Quadrature</strong> (4), <strong className="text-white">Spectral</strong> (5+). Each mode creates different mathematical synthesis.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-yellow-400 text-sm mb-2">Emergent Signals</h3>
                  <p className="text-xs text-gray-400">Signals that only exist in the bridged combination — they don't appear in any individual filter. These are the most valuable outputs of Bridge Fusion.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-cyan-400 text-sm mb-2">Cross-Filter Derivatives</h3>
                  <p className="text-xs text-gray-400">Rate of change between filter pairs. Shows which filters are accelerating/decelerating relative to each other — reveals lead/lag relationships.</p>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-orange-400 text-sm mb-2">Combo Dimensions</h3>
                  <p className="text-xs text-gray-400">Entirely new analytical measurements unique to each specific combination. Each combo generates 3-4 dimensions that are impossible to see with any other combination.</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-4">Order Effect: Why Filter Position Matters</h2>
              <p className="text-gray-300 text-sm mb-4">
                The <strong className="text-white">first filter</strong> you select becomes the <strong className="text-yellow-400">primary analytical lens</strong> (weighted 130%), 
                while subsequent filters provide <strong className="text-white">confirmation</strong> (weighted 90% each). This means the same three filters 
                produce different insights depending on which one leads.
              </p>
              <div className="space-y-3">
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <div className="text-xs font-bold text-white mb-2">Example: OFI + WYK + DD</div>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-start gap-2">
                      <span className="text-yellow-400 font-mono shrink-0">OFI first:</span>
                      <span className="text-gray-400">Flow-first analysis — "Is there buying/selling pressure right now? Does the Wyckoff phase confirm it? Is delta diverging?"</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-yellow-400 font-mono shrink-0">WYK first:</span>
                      <span className="text-gray-400">Structure-first analysis — "What institutional phase are we in? Is order flow confirming? Is delta aligned with the phase?"</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-yellow-400 font-mono shrink-0">DD first:</span>
                      <span className="text-gray-400">Divergence-first analysis — "Is there a price-delta divergence? Does order flow support the divergence? Is the Wyckoff phase transitioning?"</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-500/10 to-yellow-500/10 rounded-xl p-6 border border-purple-500/30">
              <div className="flex items-center gap-3 mb-4">
                <Infinity size={24} className="text-purple-400" />
                <h2 className="text-xl font-bold text-purple-400">Meta-Fusion™ — Infinite Analytical Depth</h2>
              </div>
              <p className="text-gray-300 text-sm mb-4">
                Meta-Fusion takes Bridge Fusion to the next level by allowing you to <strong className="text-white">fuse bridge rows with each other</strong>. 
                When you have 2+ active bridge rows, you can select any combination of them to create an entirely new layer of analysis.
              </p>
              <div className="space-y-3 mb-4">
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-purple-300 text-sm mb-2">How It Works</h3>
                  <ul className="text-xs text-gray-400 space-y-2">
                    <li className="flex items-start gap-2"><Sparkles size={12} className="text-purple-400 mt-0.5 flex-shrink-0" /> Set up 2+ bridge rows with different filter combinations (e.g., Row 1: OFI+DD, Row 2: WYK+FE)</li>
                    <li className="flex items-start gap-2"><Sparkles size={12} className="text-purple-400 mt-0.5 flex-shrink-0" /> Click on rows in the Meta-Fusion panel to select which to fuse</li>
                    <li className="flex items-start gap-2"><Sparkles size={12} className="text-purple-400 mt-0.5 flex-shrink-0" /> The system generates cross-row derivatives, meta-emergent signals, and category consensus scores</li>
                    <li className="flex items-start gap-2"><Sparkles size={12} className="text-purple-400 mt-0.5 flex-shrink-0" /> Change row selections to discover unlimited new analytical dimensions</li>
                  </ul>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h3 className="font-bold text-purple-300 text-sm mb-2">What Meta-Fusion Creates</h3>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-white font-bold">Meta-Resonance Cascade:</span>
                      <span className="text-gray-400 ml-1">When all rows have constructive resonance, the signal amplifies exponentially across rows.</span>
                    </div>
                    <div>
                      <span className="text-white font-bold">Inflection Point Detector:</span>
                      <span className="text-gray-400 ml-1">When rows disagree, it reveals genuine market turning points invisible to any single bridge.</span>
                    </div>
                    <div>
                      <span className="text-white font-bold">Category Consensus:</span>
                      <span className="text-gray-400 ml-1">Averages all dimensions by category (momentum, structure, regime) across rows.</span>
                    </div>
                    <div>
                      <span className="text-white font-bold">Cross-Row Derivatives:</span>
                      <span className="text-gray-400 ml-1">Measures divergence between rows — major divergence = high-probability reversal signal.</span>
                    </div>
                  </div>
                </div>
                <div className="bg-yellow-500/10 rounded-lg p-3 border border-yellow-500/20">
                  <p className="text-xs text-yellow-300">
                    <strong>The Infinity Principle:</strong> Each unique row combination generates different meta-dimensions. With 4 bridge rows, 
                    you have 11 possible meta-fusion combinations (pairs, triples, and the full quad). Each combination produces unique cross-row 
                    interactions. Then, meta-fusion results themselves can inform new bridge configurations — creating an infinite loop of 
                    analytical discovery. No other platform offers anything like this.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Complete Combination Reference</h2>
                <span className="text-xs text-gray-500">{filteredCombos.length} of {ALL_COMBOS.length} combinations</span>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <div className="relative flex-1 min-w-[200px]">
                  <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Search combinations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 rounded-lg bg-gray-900/50 border border-gray-700 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500/50"
                    data-testid="input-combo-search"
                  />
                </div>
                <div className="flex gap-1.5">
                  {(['all', '2', '3', '4'] as const).map(s => (
                    <button
                      key={s}
                      onClick={() => setFilterSize(s)}
                      className={`px-3 py-2 rounded-lg text-xs font-bold ${filterSize === s ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' : 'bg-gray-900/50 text-gray-500 border border-gray-700 hover:text-gray-300'}`}
                      data-testid={`button-filter-size-${s}`}
                    >
                      {s === 'all' ? 'All' : `${s}-Filter`}
                    </button>
                  ))}
                </div>
                <div className="flex gap-1.5">
                  {['all', 'momentum', 'structure', 'regime', 'hybrid', 'meta'].map(c => (
                    <button
                      key={c}
                      onClick={() => setFilterCategory(c)}
                      className={`px-3 py-2 rounded-lg text-xs font-bold capitalize ${filterCategory === c ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' : 'bg-gray-900/50 text-gray-500 border border-gray-700 hover:text-gray-300'}`}
                      data-testid={`button-filter-cat-${c}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {filterSize === 'all' && filterCategory === 'all' && !searchQuery && (
                  <>
                    <h3 className="text-sm font-bold text-gray-400 mt-4 mb-2">2-Filter Combinations ({ALL_COMBOS.filter(c => c.filters.length === 2).length})</h3>
                    {ALL_COMBOS.filter(c => c.filters.length === 2).map(c => (
                      <ComboCard key={c.filters.join('+')} combo={c} expanded={expandedCombo === c.filters.join('+')} onToggle={() => setExpandedCombo(expandedCombo === c.filters.join('+') ? null : c.filters.join('+'))} />
                    ))}
                    <h3 className="text-sm font-bold text-gray-400 mt-6 mb-2">3-Filter Combinations ({ALL_COMBOS.filter(c => c.filters.length === 3).length})</h3>
                    {ALL_COMBOS.filter(c => c.filters.length === 3).map(c => (
                      <ComboCard key={c.filters.join('+')} combo={c} expanded={expandedCombo === c.filters.join('+')} onToggle={() => setExpandedCombo(expandedCombo === c.filters.join('+') ? null : c.filters.join('+'))} />
                    ))}
                    <h3 className="text-sm font-bold text-gray-400 mt-6 mb-2">4-Filter Combinations ({ALL_COMBOS.filter(c => c.filters.length === 4).length})</h3>
                    {ALL_COMBOS.filter(c => c.filters.length === 4).map(c => (
                      <ComboCard key={c.filters.join('+')} combo={c} expanded={expandedCombo === c.filters.join('+')} onToggle={() => setExpandedCombo(expandedCombo === c.filters.join('+') ? null : c.filters.join('+'))} />
                    ))}
                  </>
                )}
                {(filterSize !== 'all' || filterCategory !== 'all' || searchQuery) && filteredCombos.map(c => (
                  <ComboCard key={c.filters.join('+')} combo={c} expanded={expandedCombo === c.filters.join('+')} onToggle={() => setExpandedCombo(expandedCombo === c.filters.join('+') ? null : c.filters.join('+'))} />
                ))}
                {filteredCombos.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Filter size={32} className="mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No combinations match your filters</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-4">Quick Reference: Filter Categories</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(FILTER_INFO).map(([key, info]) => (
                  <div key={key} className="bg-gray-900/50 rounded-lg p-3 border border-gray-700">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: info.color }}></span>
                      <span className="text-xs font-bold text-white">{info.short}</span>
                      <span className="text-[10px] px-1 py-0.5 rounded bg-gray-800 text-gray-500">{info.category}</span>
                    </div>
                    <p className="text-[11px] text-gray-400">{info.name}</p>
                    <p className="text-[10px] text-gray-500 mt-1">{info.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500/10 to-[#FFD700]/10 rounded-xl p-6 border border-green-500/30 mb-6">
              <div className="flex items-center gap-3 mb-3">
                <Target size={20} className="text-green-400" />
                <h2 className="text-xl font-bold text-green-400">Validated Combination Guide</h2>
              </div>
              <p className="text-gray-300 text-sm mb-3">
                See real backtest results across 20 major cryptocurrencies — 6 months of hourly data, per-coin breakdowns, and which combinations work best for each coin.
              </p>
              <div className="flex items-center gap-3 flex-wrap">
                <Link href="/alpha-trading/validated-combinations" className="inline-flex items-center gap-2 bg-green-500/20 text-green-400 px-4 py-2 rounded-lg font-semibold text-sm hover:bg-green-500/30 transition-colors border border-green-500/30" data-testid="link-validated-combinations">
                  <ArrowRight size={14} />
                  View Full Results
                </Link>
                <button
                  onClick={() => PDF_GENERATORS.validatedCombinations.fn()}
                  className="inline-flex items-center gap-2 bg-[#FFD700]/20 text-[#FFD700] px-4 py-2 rounded-lg font-semibold text-sm hover:bg-[#FFD700]/30 transition-colors border border-[#FFD700]/30"
                  data-testid="button-download-validated-pdf"
                >
                  <Download size={14} />
                  Download PDF Guide
                </button>
              </div>
            </div>

            <div className="bg-gradient-to-r from-[#FFD700]/10 to-purple-500/10 rounded-xl p-6 border border-[#FFD700]/30">
              <h2 className="text-xl font-bold text-[#FFD700] mb-4">Why Bridge Fusion Outperforms Everything</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-red-500/5 rounded-lg p-4 border border-red-500/20">
                  <h3 className="font-bold text-red-400 text-sm mb-2">Traditional Platforms</h3>
                  <ul className="text-xs text-gray-400 space-y-1">
                    <li>• Only basic indicators (RSI, MACD, MA)</li>
                    <li>• Each indicator works in isolation</li>
                    <li>• No way to combine signals mathematically</li>
                    <li>• No unique dimensions from combinations</li>
                    <li>• No meta-fusion or cascading analysis</li>
                    <li>• No order-dependent weighting</li>
                  </ul>
                </div>
                <div className="bg-green-500/5 rounded-lg p-4 border border-green-500/20">
                  <h3 className="font-bold text-green-400 text-sm mb-2">Alpha Unlimited Bridge Fusion™</h3>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• {stats.total} documented combinations generating {stats.totalDimensions}+ unique dimensions</li>
                    <li>• Combination-specific fusion identities and analytical compounds</li>
                    <li>• Order-dependent primary lens weighting system</li>
                    <li>• Harmonic resonance, interference patterns, emergent signals</li>
                    <li>• Meta-Fusion™ for infinite-depth cascading analysis</li>
                    <li>• Cross-filter derivatives and frequency spectrum analysis</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700">
              <div className="flex items-center gap-2 mb-2">
                <Lock size={14} className="text-[#FFD700]" />
                <span className="text-xs font-bold text-[#FFD700]">PROPRIETARY TECHNOLOGY</span>
              </div>
              <p className="text-xs text-gray-500">
                Bridge Fusion™, Meta-Fusion™, including the combination intelligence engine, order-dependent weighting system,
                harmonic resonance detection, interference pattern analysis, emergent signal generation, cross-filter derivatives,
                frequency spectrum analysis, and all {stats.total} documented combination profiles with {stats.totalDimensions}+ unique 
                analytical dimensions are the exclusive intellectual property of Alpha Unlimited Trading Company. 
                © {new Date().getFullYear()} Alpha Unlimited Trading Company. All Rights Reserved in Perpetuity.
                <Link href="/copyright" className="text-[#00D4FF] underline ml-1 hover:text-[#00D4FF]/80">View Full Copyright Notice</Link>
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
