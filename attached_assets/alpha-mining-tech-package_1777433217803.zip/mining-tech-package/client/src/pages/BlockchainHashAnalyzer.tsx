import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Button } from "@/components/ui/button";
import {
  Cpu, Activity, RefreshCw, Database, Hash, Binary,
  TrendingUp, BarChart3, Zap, Shield, Loader2, AlertTriangle,
  ChevronDown, ChevronUp, Search, Layers, Fingerprint
} from "lucide-react";

interface BlockData {
  height: number;
  hash: string;
  prevHash: string;
  merkleRoot: string;
  timestamp: number;
  nonce: number;
  difficulty: number;
  size: number;
  txCount: number;
  version: number;
}

interface AnalysisResult {
  blockCount: number;
  genesisAsInteger: string;
  latestAsInteger: string;
  integerDigitCount: number;
  leadingZeros: number[];
  bitDistributions: number[];
  modularArithmetic: {
    mod3: number[];
    mod6: number[];
    mod9: number[];
    mod256: number[];
  };
  mod3Distribution: number[];
  mod9Distribution: number[];
  hexDigitFrequency: Record<string, number>;
  chiSquaredStatistic: number;
  autocorrelations: number[];
  xorPatterns: string[];
  differencesSample: string[];
  ratiosSample: number[];
  patterns: string[];
}

function formatBigNumber(numStr: string): string {
  if (numStr.length <= 20) return numStr;
  return numStr.slice(0, 8) + "..." + numStr.slice(-8) + ` (${numStr.length} digits)`;
}

export default function BlockchainHashAnalyzer() {
  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [latestHeight, setLatestHeight] = useState<number>(0);
  const [blockCount, setBlockCount] = useState(20);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastFetched, setLastFetched] = useState<Date | null>(null);
  const [expandedBlock, setExpandedBlock] = useState<number | null>(null);
  const [showAllBlocks, setShowAllBlocks] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchBlocks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/blockchain/blocks?count=${blockCount}`);
      if (!res.ok) throw new Error('Failed to fetch blocks');
      const data = await res.json();
      setBlocks(data.blocks);
      setLatestHeight(data.latestHeight);
      setLastFetched(new Date());

      if (data.blocks.length >= 2) {
        setAnalyzing(true);
        const analyzeRes = await fetch('/api/blockchain/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ hashes: data.blocks.map((b: BlockData) => b.hash) })
        });
        if (analyzeRes.ok) {
          const result = await analyzeRes.json();
          setAnalysis(result.analysis);
        }
        setAnalyzing(false);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [blockCount]);

  useEffect(() => {
    fetchBlocks();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(fetchBlocks, 60000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [autoRefresh, fetchBlocks]);

  const hexChars = '0123456789abcdef'.split('');

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-[#0a0e17] text-white">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-4 py-1.5 mb-4">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-400 text-sm font-semibold">RESEARCH LAB</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-3" data-testid="text-analyzer-title">
              Blockchain Hash <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Pattern Analyzer</span>
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto text-sm">
              Converts Bitcoin block hashes to whole numbers and runs mathematical pattern analysis
              including modular arithmetic, bit distribution, autocorrelation, XOR patterns, and Tesla 3-6-9 analysis.
            </p>
          </motion.div>

          <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
            <div className="flex items-center gap-2 bg-[#111827] border border-white/10 rounded-lg px-3 py-2">
              <Database className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Blocks:</span>
              <select
                value={blockCount}
                onChange={(e) => setBlockCount(parseInt(e.target.value))}
                className="bg-transparent text-white text-sm border-none outline-none"
                data-testid="select-block-count"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>

            <Button
              onClick={fetchBlocks}
              disabled={loading}
              className="bg-cyan-600 hover:bg-cyan-700 text-white text-sm"
              data-testid="button-fetch-blocks"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              {loading ? 'Fetching...' : 'Fetch & Analyze'}
            </Button>

            <Button
              onClick={() => setAutoRefresh(!autoRefresh)}
              variant={autoRefresh ? "default" : "outline"}
              className={autoRefresh ? "bg-green-600 hover:bg-green-700 text-sm" : "border-white/20 text-sm"}
              data-testid="button-auto-refresh"
            >
              <Activity className="w-4 h-4 mr-2" />
              {autoRefresh ? 'Auto-Refresh ON' : 'Auto-Refresh'}
            </Button>
          </div>

          {lastFetched && (
            <div className="text-center text-xs text-gray-500 mb-6">
              Last updated: {lastFetched.toLocaleTimeString()} | Latest block: #{latestHeight.toLocaleString()}
              {autoRefresh && ' | Refreshing every 60 seconds'}
            </div>
          )}

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span className="text-red-400 text-sm">{error}</span>
            </div>
          )}

          {analysis && (
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-4"
              >
                <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-cyan-500/20 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Hash className="w-5 h-5 text-cyan-400" />
                    <h3 className="font-bold text-sm">First Block as Integer</h3>
                  </div>
                  <p className="text-cyan-400 font-mono text-xs break-all" data-testid="text-genesis-integer">
                    {formatBigNumber(analysis.genesisAsInteger)}
                  </p>
                </div>

                <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-blue-500/20 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Hash className="w-5 h-5 text-blue-400" />
                    <h3 className="font-bold text-sm">Latest Block as Integer</h3>
                  </div>
                  <p className="text-blue-400 font-mono text-xs break-all" data-testid="text-latest-integer">
                    {formatBigNumber(analysis.latestAsInteger)}
                  </p>
                </div>

                <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-purple-500/20 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Binary className="w-5 h-5 text-purple-400" />
                    <h3 className="font-bold text-sm">Integer Size</h3>
                  </div>
                  <p className="text-purple-400 font-mono text-2xl font-bold" data-testid="text-digit-count">
                    {analysis.integerDigitCount} <span className="text-sm font-normal">digits</span>
                  </p>
                  <p className="text-gray-500 text-xs mt-1">256-bit number as decimal</p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-[#111827] border border-white/10 rounded-xl p-6"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Search className="w-5 h-5 text-yellow-400" />
                  <h3 className="font-bold">Pattern Detection Results</h3>
                </div>
                <div className="space-y-3">
                  {analysis.patterns.map((pattern, i) => (
                    <div
                      key={i}
                      className={`flex items-start gap-3 p-3 rounded-lg ${
                        pattern.includes('ANOMALY')
                          ? 'bg-yellow-500/10 border border-yellow-500/30'
                          : 'bg-white/5 border border-white/5'
                      }`}
                      data-testid={`text-pattern-${i}`}
                    >
                      {pattern.includes('ANOMALY') ? (
                        <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 shrink-0" />
                      ) : (
                        <Fingerprint className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
                      )}
                      <span className="text-sm text-gray-300">{pattern}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-[#111827] border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <BarChart3 className="w-5 h-5 text-green-400" />
                    <h3 className="font-bold">Hex Digit Frequency</h3>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">
                    Chi-squared: {analysis.chiSquaredStatistic.toFixed(2)} (uniform distribution expected for random hashes)
                  </p>
                  <div className="grid grid-cols-8 gap-1">
                    {hexChars.map(char => {
                      const count = analysis.hexDigitFrequency[char] || 0;
                      const maxCount = Math.max(...Object.values(analysis.hexDigitFrequency));
                      const pct = maxCount > 0 ? (count / maxCount) * 100 : 0;
                      return (
                        <div key={char} className="text-center">
                          <div className="h-16 flex items-end justify-center mb-1">
                            <div
                              className="w-full bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t"
                              style={{ height: `${pct}%`, minHeight: '4px' }}
                            />
                          </div>
                          <span className="text-xs font-mono text-cyan-400">{char}</span>
                          <div className="text-[10px] text-gray-500">{count}</div>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-[#111827] border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    <h3 className="font-bold">Tesla 3-6-9 Analysis</h3>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">Modular arithmetic distribution of hash values</p>
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-gray-400 mb-2">Mod 3 Distribution:</p>
                      <div className="flex gap-2">
                        {analysis.mod3Distribution.map((count, i) => (
                          <div key={i} className="flex-1 bg-black/40 rounded-lg p-2 text-center">
                            <div className="text-lg font-bold text-yellow-400">{count}</div>
                            <div className="text-[10px] text-gray-500">remainder {i}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 mb-2">Mod 9 Distribution:</p>
                      <div className="grid grid-cols-9 gap-1">
                        {analysis.mod9Distribution.map((count, i) => (
                          <div key={i} className="bg-black/40 rounded p-1 text-center">
                            <div className="text-sm font-bold text-orange-400">{count}</div>
                            <div className="text-[9px] text-gray-500">{i}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="bg-[#111827] border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    <h3 className="font-bold">Autocorrelation (Lag 1-10)</h3>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">Values near 0 indicate no repeating pattern. Values near 1 or -1 indicate strong patterns.</p>
                  <div className="space-y-2">
                    {analysis.autocorrelations.map((corr, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <span className="text-xs text-gray-400 w-12">Lag {i + 1}</span>
                        <div className="flex-1 h-4 bg-black/40 rounded-full overflow-hidden relative">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-px h-full bg-gray-600" />
                          </div>
                          <div
                            className={`h-full rounded-full transition-all ${
                              Math.abs(corr) > 0.1 ? 'bg-yellow-500' : 'bg-blue-500/60'
                            }`}
                            style={{
                              width: `${Math.abs(corr) * 50}%`,
                              marginLeft: corr >= 0 ? '50%' : `${50 - Math.abs(corr) * 50}%`
                            }}
                          />
                        </div>
                        <span className={`text-xs font-mono w-16 text-right ${Math.abs(corr) > 0.1 ? 'text-yellow-400' : 'text-gray-400'}`}>
                          {corr.toFixed(4)}
                        </span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="bg-[#111827] border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <Activity className="w-5 h-5 text-cyan-400" />
                    <h3 className="font-bold">Bit Distribution (1s Ratio)</h3>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">Percentage of 1-bits in each hash. Expected ~50% for random data.</p>
                  <div className="h-40 flex items-end gap-[2px]">
                    {analysis.bitDistributions.slice(0, 50).map((ratio, i) => {
                      const deviation = Math.abs(ratio - 0.5);
                      return (
                        <div
                          key={i}
                          className="flex-1 rounded-t transition-all"
                          style={{
                            height: `${ratio * 100}%`,
                            backgroundColor: deviation > 0.05
                              ? `rgba(234, 179, 8, ${0.5 + deviation * 5})`
                              : `rgba(34, 211, 238, ${0.3 + ratio * 0.7})`
                          }}
                          title={`Block ${i}: ${(ratio * 100).toFixed(1)}% ones`}
                        />
                      );
                    })}
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                    <span>First block</span>
                    <span className="text-cyan-400">50% line = perfect balance</span>
                    <span>Latest</span>
                  </div>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-[#111827] border border-white/10 rounded-xl p-6"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Layers className="w-5 h-5 text-purple-400" />
                  <h3 className="font-bold">XOR Patterns (Consecutive Block Hash Differences)</h3>
                </div>
                <p className="text-xs text-gray-500 mb-3">
                  XOR of adjacent hashes reveals which bits changed. Uniform changes indicate randomness. Clusters indicate potential structure.
                </p>
                <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                  {analysis.xorPatterns.map((xor, i) => {
                    const onesCount = xor.split('').reduce((acc, c) => {
                      const n = parseInt(c, 16);
                      let bits = 0;
                      for (let b = 0; b < 4; b++) bits += (n >> b) & 1;
                      return acc + bits;
                    }, 0);
                    return (
                      <div key={i} className="flex items-center gap-3">
                        <span className="text-xs text-gray-500 w-20 shrink-0">Block {i} XOR {i + 1}</span>
                        <code className="text-[10px] font-mono text-purple-400 break-all flex-1">
                          {xor}
                        </code>
                        <span className="text-xs text-gray-400 w-20 text-right shrink-0">
                          {onesCount}/256 bits
                        </span>
                      </div>
                    );
                  })}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-[#111827] border border-white/10 rounded-xl p-6"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="w-5 h-5 text-green-400" />
                  <h3 className="font-bold">Hash-to-Integer Conversion (Luhn Concept)</h3>
                </div>
                <p className="text-xs text-gray-500 mb-4">
                  Each hash treated as a single whole number. Differences and ratios between consecutive blocks analyzed for patterns.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-xs text-gray-400 mb-2 font-semibold">Integer Differences (first 10 pairs):</h4>
                    <div className="space-y-1">
                      {analysis.differencesSample.map((diff, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-500 w-8">#{i + 1}</span>
                          <span className="text-[10px] font-mono text-green-400 break-all">
                            {diff.length > 40 ? diff.slice(0, 20) + '...' + diff.slice(-10) : diff}
                          </span>
                          <span className="text-[10px] text-gray-500">({diff.length} digits)</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs text-gray-400 mb-2 font-semibold">Integer Ratios (first 10 pairs):</h4>
                    <div className="space-y-1">
                      {analysis.ratiosSample.map((ratio, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-500 w-8">#{i + 1}</span>
                          <span className="text-[10px] font-mono text-blue-400">
                            {ratio.toFixed(6)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}

          {blocks.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-8 bg-[#111827] border border-white/10 rounded-xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Database className="w-5 h-5 text-cyan-400" />
                  <h3 className="font-bold">Raw Block Data</h3>
                  <span className="text-xs text-gray-500">({blocks.length} blocks)</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAllBlocks(!showAllBlocks)}
                  className="text-xs border-white/20"
                  data-testid="button-toggle-blocks"
                >
                  {showAllBlocks ? <ChevronUp className="w-3 h-3 mr-1" /> : <ChevronDown className="w-3 h-3 mr-1" />}
                  {showAllBlocks ? 'Collapse' : 'Expand All'}
                </Button>
              </div>

              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {(showAllBlocks ? blocks : blocks.slice(-10)).map((block) => (
                  <div
                    key={block.height}
                    className="bg-black/30 rounded-lg border border-white/5 overflow-hidden"
                  >
                    <button
                      onClick={() => setExpandedBlock(expandedBlock === block.height ? null : block.height)}
                      className="w-full flex items-center gap-3 p-3 hover:bg-white/5 transition-colors text-left"
                      data-testid={`button-block-${block.height}`}
                    >
                      <span className="text-xs font-bold text-cyan-400 w-20">#{block.height.toLocaleString()}</span>
                      <code className="text-[10px] font-mono text-gray-400 flex-1 truncate">{block.hash}</code>
                      <span className="text-[10px] text-gray-500">{new Date(block.timestamp * 1000).toLocaleString()}</span>
                      {expandedBlock === block.height ? <ChevronUp className="w-3 h-3 text-gray-400" /> : <ChevronDown className="w-3 h-3 text-gray-400" />}
                    </button>

                    <AnimatePresence>
                      {expandedBlock === block.height && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="border-t border-white/5"
                        >
                          <div className="p-3 grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-gray-500">Hash:</span>
                              <code className="text-cyan-400 font-mono text-[10px] block break-all">{block.hash}</code>
                            </div>
                            <div>
                              <span className="text-gray-500">Previous Hash:</span>
                              <code className="text-blue-400 font-mono text-[10px] block break-all">{block.prevHash}</code>
                            </div>
                            <div>
                              <span className="text-gray-500">Merkle Root:</span>
                              <code className="text-purple-400 font-mono text-[10px] block break-all">{block.merkleRoot}</code>
                            </div>
                            <div>
                              <span className="text-gray-500">Nonce:</span>
                              <span className="text-yellow-400 font-mono"> {block.nonce.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Transactions:</span>
                              <span className="text-green-400 font-mono"> {block.txCount.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Size:</span>
                              <span className="text-gray-300 font-mono"> {(block.size / 1024).toFixed(1)} KB</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Version:</span>
                              <span className="text-gray-300 font-mono"> {block.version}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Difficulty Bits:</span>
                              <span className="text-gray-300 font-mono"> {block.difficulty}</span>
                            </div>
                            <div className="col-span-2">
                              <span className="text-gray-500">As Integer: </span>
                              <code className="text-orange-400 font-mono text-[10px] break-all">
                                {(() => {
                                  try {
                                    const n = BigInt('0x' + block.hash).toString();
                                    return n.length > 60 ? n.slice(0, 30) + '...' + n.slice(-20) + ` (${n.length} digits)` : n;
                                  } catch { return 'N/A'; }
                                })()}
                              </code>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
              {!showAllBlocks && blocks.length > 10 && (
                <p className="text-center text-xs text-gray-500 mt-3">Showing last 10 of {blocks.length} blocks</p>
              )}
            </motion.div>
          )}

          {loading && !blocks.length && (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-10 h-10 text-cyan-400 animate-spin mb-4" />
              <p className="text-gray-400">Fetching real Bitcoin block data from blockchain.info...</p>
            </div>
          )}

          {analyzing && (
            <div className="fixed bottom-4 right-4 bg-[#111827] border border-cyan-500/30 rounded-lg px-4 py-2 flex items-center gap-2 shadow-lg">
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
              <span className="text-sm text-cyan-400">Running pattern analysis...</span>
            </div>
          )}

          <div className="mt-8 bg-[#111827]/50 border border-white/5 rounded-xl p-6">
            <h3 className="text-sm font-bold text-gray-400 mb-3">How This Tool Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-gray-500">
              <div className="space-y-1">
                <p className="text-cyan-400 font-semibold">1. Data Collection</p>
                <p>Fetches real Bitcoin block headers from blockchain.info including hash, previous hash, merkle root, nonce, timestamp, and difficulty.</p>
              </div>
              <div className="space-y-1">
                <p className="text-cyan-400 font-semibold">2. Integer Conversion</p>
                <p>Converts each 64-character hex hash into a whole number (up to 77 digits). Calculates differences and ratios between consecutive blocks.</p>
              </div>
              <div className="space-y-1">
                <p className="text-cyan-400 font-semibold">3. Pattern Analysis</p>
                <p>Runs modular arithmetic (Tesla 3-6-9), bit distribution analysis, XOR patterns, hex frequency, chi-squared tests, and autocorrelation.</p>
              </div>
              <div className="space-y-1">
                <p className="text-cyan-400 font-semibold">4. Live Updates</p>
                <p>Auto-refresh mode continuously ingests new blocks and recalculates all analysis in real time as the blockchain grows.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
