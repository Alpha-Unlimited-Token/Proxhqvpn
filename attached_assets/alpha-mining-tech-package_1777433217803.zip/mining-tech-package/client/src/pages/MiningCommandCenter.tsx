import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Cpu, Activity, RefreshCw, Database, Hash, Binary,
  TrendingUp, BarChart3, Zap, Shield, Loader2, AlertTriangle,
  ChevronDown, ChevronUp, Search, Layers, Fingerprint,
  Wifi, WifiOff, Usb, Link2, Unlink, Settings, Play, Pause,
  Server, Network, Target, Brain, Eye, Radio, Atom, Flame,
  Gauge, GitBranch, Clock, Coins, Sparkles, Signal, Monitor,
  CheckCircle2, Info, HardDrive, Sliders, ToggleLeft, ToggleRight,
  ArrowUpCircle, Globe, MapPin, Timer
} from "lucide-react";
import {
  WIFI_ETHERNET_HARDWARE,
  USB_HARDWARE,
  ALL_HARDWARE,
  type HardwareDevice,
  type DiscoveredDevice,
  type MinerStats
} from "@/lib/mining/hardware-registry";
import {
  simulateNetworkScan,
  simulateUSBScan,
  connectToDevice,
  disconnectDevice,
  refreshDeviceStats,
  checkFirmwareUpdates,
  formatHashrate,
  getConnectionTypeLabel,
  type FirmwareUpdate,
} from "@/lib/mining/connection-manager";

interface BlockData {
  height: number;
  hash: string;
  prevHash: string;
  merkleRoot: string;
  timestamp: number;
  nonce: number;
  difficulty: number;
  size: number;
  txCount: number;
  version: number;
}

interface AnalysisResult {
  blockCount: number;
  genesisAsInteger: string;
  latestAsInteger: string;
  integerDigitCount: number;
  leadingZeros: number[];
  bitDistributions: number[];
  modularArithmetic: {
    mod3: number[];
    mod6: number[];
    mod9: number[];
    mod256: number[];
  };
  mod3Distribution: number[];
  mod9Distribution: number[];
  hexDigitFrequency: Record<string, number>;
  chiSquaredStatistic: number;
  autocorrelations: number[];
  xorPatterns: string[];
  differencesSample: string[];
  ratiosSample: number[];
  patterns: string[];
}

type ActiveTab = 'mining' | 'hashlab' | 'intelligence' | 'minerhub' | 'spider';

interface SpiderStatus {
  status: 'idle' | 'crawling' | 'analyzing' | 'ready' | 'offline';
  blocksAnalyzed: number;
  totalBlocks: number;
  crawlProgress: number;
  lastCrawlTime?: number;
  crawlDuration?: number;
}

interface SpiderNonceMap {
  buckets: number[];
  hotspots: { rangeStart: number; rangeEnd: number; frequency: number; probability: number; lastSeenBlock: number }[];
  preferredRanges: { start: number; end: number; weight: number }[];
  totalBlocks: number;
}

interface SpiderDifficultyPrediction {
  currentDifficulty: number;
  predictedNextDifficulty: number;
  adjustmentFactor: number;
  blocksUntilAdjustment: number;
  epochProgress: number;
  trend: 'increasing' | 'decreasing' | 'stable';
  confidence: number;
  estimatedTimeToAdjustment: number;
}

interface SpiderMiningWindow {
  optimal: boolean;
  score: number;
  avgBlockInterval: number;
  recentBlockInterval: number;
  intervalDeviation: number;
  networkHashTrend: 'rising' | 'falling' | 'stable';
  recommendation: string;
  windowStart: number;
  windowDuration: number;
}

interface SpiderEntropy {
  currentEntropy: number;
  avgEntropy: number;
  entropyTrend: 'increasing' | 'decreasing' | 'stable';
  bitDistribution: number[];
  hexDigitFrequency: number[];
  leadingZeroTrend: number[];
  shannonScore: number;
  patternStrength: number;
}

interface SpiderIntelligenceEntry {
  id: string;
  timestamp: number;
  type: 'pattern' | 'prediction' | 'anomaly' | 'optimization' | 'discovery';
  severity: 'info' | 'notable' | 'significant' | 'critical';
  title: string;
  description: string;
}

interface SpiderFullIntelligence {
  status: string;
  blocksAnalyzed: number;
  totalBlocks: number;
  crawlProgress: number;
  lastCrawlTime: number;
  crawlDuration: number;
  nonceHotspots: SpiderNonceMap['hotspots'];
  difficultyPrediction: SpiderDifficultyPrediction;
  miningWindow: SpiderMiningWindow;
  entropyAnalysis: SpiderEntropy;
  templateOptimization: { avgTxPerBlock: number; avgBlockSize: number; optimalTxCount: number; merkleDepthDistribution: number[]; recommendedVersion: number; timestampStrategy: string };
  intelligenceFeed: SpiderIntelligenceEntry[];
  nonceBuckets: number[];
  preferredNonceRanges: { start: number; end: number; weight: number }[];
}

const SBPE_FEATURES = [
  { id: "tda", icon: Clock, title: "Temporal Difficulty Analysis™", shortTitle: "TDA", desc: "Monitors real-time network difficulty fluctuations to identify optimal mining windows", color: "#00D4FF", metric: "Difficulty" },
  { id: "ecm", icon: Hash, title: "Entropy Cascade Mapping™", shortTitle: "ECM", desc: "Analyzes statistical distribution of winning block hashes for nonce optimization", color: "#FFD700", metric: "Entropy" },
  { id: "nlo", icon: Network, title: "Network Latency Optimizer™", shortTitle: "NLO", desc: "Minimizes block propagation time for faster submission and reduced orphan risk", color: "#00FF88", metric: "Latency" },
  { id: "mpm", icon: Coins, title: "Mempool Profit Maximizer™", shortTitle: "MPM", desc: "Optimizes transaction selection for maximum fee collection per block", color: "#A855F7", metric: "Fees" },
  { id: "phc", icon: Target, title: "Probabilistic Hash Convergence™", shortTitle: "PHC", desc: "Statistical modeling for time-to-block estimation and probability scoring", color: "#F59E0B", metric: "Probability" },
  { id: "acm", icon: Brain, title: "ACM™ Mining Integration", shortTitle: "ACM", desc: "Alpha Convergence Matrix momentum and smart money flow for timing optimization", color: "#EC4899", metric: "Signal" },
];

const SOLVING_TECHS = [
  { id: "nca", name: "Nonce Convergence Algorithm™", shortName: "NCA", color: "#FF6B35", features: [
    { id: "mfa", title: "Momentum Flow Analysis™", metric: "Momentum" },
    { id: "diq", title: "Distribution Intelligence™", metric: "Distribution" },
    { id: "rso", title: "Range Search Optimizer™", metric: "Range" },
    { id: "cvs", title: "Convergence Scoring™", metric: "Score" },
  ]},
  { id: "hfre", name: "Hash Flow Resonance Engine™", shortName: "HFRE", color: "#7C3AED", features: [
    { id: "fsd", title: "Flow State Detection™", metric: "Flow" },
    { id: "rfd", title: "Resonance Frequency™", metric: "Frequency" },
    { id: "egm", title: "Entropy Gradient™", metric: "Entropy" },
    { id: "rwp", title: "Resonance Window™", metric: "Window" },
  ]},
  { id: "bin", name: "Block Intelligence Network™", shortName: "BIN", color: "#06B6D4", features: [
    { id: "nce", title: "Network Congestion Engine™", metric: "Congestion" },
    { id: "msp", title: "Miner Strategy Profiler™", metric: "Competitors" },
    { id: "orp", title: "Orphan Rate Predictor™", metric: "Orphan Risk" },
    { id: "dap", title: "Difficulty Adjustment™", metric: "Next Adj." },
  ]},
  { id: "cca", name: "Cross-Correlation Analysis™", shortName: "CCA", color: "#10B981", features: [
    { id: "bco", title: "Binary Cross-Overlay™", metric: "Alignment" },
    { id: "swd", title: "Sliding Window Detector™", metric: "Windows" },
    { id: "rpa", title: "Residual Pattern Analyzer™", metric: "Residuals" },
    { id: "mcm", title: "Multi-Chain Matcher™", metric: "Chains" },
  ]},
  { id: "dca", name: "Differential Cryptanalysis™", shortName: "DCA", color: "#F97316", features: [
    { id: "ddt", title: "Differential Distribution Table™", metric: "Bias" },
    { id: "bpa", title: "Bit Propagation Analyzer™", metric: "Rounds" },
    { id: "rrm", title: "Reduced-Round Modeler™", metric: "Model" },
    { id: "isb", title: "Intermediate State Bias™", metric: "Deviation" },
  ]},
];

const BRIDGE_PRESETS = [
  { id: "bridge_alpha", name: "Alpha Bridge", techs: ["NCA", "HFRE"], color: "#FF6B35" },
  { id: "bridge_omega", name: "Omega Bridge", techs: ["BIN", "SBPE"], color: "#06B6D4" },
  { id: "bridge_quantum", name: "Quantum Bridge", techs: ["HFRE", "BIN", "SBPE"], color: "#7C3AED" },
  { id: "bridge_correlator", name: "Correlator Bridge", techs: ["CCA", "DCA"], color: "#10B981" },
  { id: "bridge_sentinel", name: "Sentinel Bridge", techs: ["CCA", "BIN"], color: "#34D399" },
  { id: "bridge_cipher", name: "Cipher Bridge", techs: ["DCA", "HFRE"], color: "#F97316" },
  { id: "bridge_ultimate", name: "Ultimate Bridge", techs: ["NCA", "HFRE", "BIN", "SBPE", "CCA", "DCA"], color: "#F59E0B" },
];

const BLOCKCHAIN_PRESETS = [
  { id: "bitcoin", name: "Bitcoin (SHA-256)", algorithm: "SHA-256 (Double)", blockTime: "~10 min", color: "#F7931A" },
  { id: "ethereum_classic", name: "Ethereum Classic (Etchash)", algorithm: "Ethash/Etchash", blockTime: "~13 sec", color: "#3AB83A" },
  { id: "dogecoin", name: "Dogecoin (Scrypt)", algorithm: "Scrypt", blockTime: "~1 min", color: "#C2A633" },
  { id: "litecoin", name: "Litecoin (Scrypt)", algorithm: "Scrypt", blockTime: "~2.5 min", color: "#345D9D" },
  { id: "kaspa", name: "Kaspa (kHeavyHash)", algorithm: "kHeavyHash", blockTime: "~1 sec", color: "#70C7BA" },
  { id: "monero", name: "Monero (RandomX)", algorithm: "RandomX", blockTime: "~2 min", color: "#FF6600" },
];

function formatBigNumber(numStr: string): string {
  if (numStr.length <= 20) return numStr;
  return numStr.slice(0, 8) + "..." + numStr.slice(-8) + ` (${numStr.length} digits)`;
}

function MiningCommandCenterContent() {
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveTab>('intelligence');

  const [isConnected, setIsConnected] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanType, setScanType] = useState<'wifi' | 'usb' | null>(null);
  const [connectedDevice, setConnectedDevice] = useState<DiscoveredDevice | null>(null);
  const [currentStats, setCurrentStats] = useState<MinerStats | null>(null);
  const [discoveredDevices, setDiscoveredDevices] = useState<DiscoveredDevice[]>([]);
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [showManualConnect, setShowManualConnect] = useState(false);
  const [minerAddress, setMinerAddress] = useState("");
  const [minerPort, setMinerPort] = useState("4028");
  const [selectedBlockchain, setSelectedBlockchain] = useState("bitcoin");
  const [activeTechs, setActiveTechs] = useState<Record<string, boolean>>(() => {
    const defaults: Record<string, boolean> = {};
    SOLVING_TECHS.forEach(t => { defaults[t.id] = true; });
    return defaults;
  });
  const [activeBridges, setActiveBridges] = useState<Record<string, boolean>>(() => {
    const defaults: Record<string, boolean> = {};
    BRIDGE_PRESETS.forEach(b => { defaults[b.id] = true; });
    return defaults;
  });

  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [latestHeight, setLatestHeight] = useState<number>(0);
  const [blockCount, setBlockCount] = useState(20);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastFetched, setLastFetched] = useState<Date | null>(null);
  const [expandedBlock, setExpandedBlock] = useState<number | null>(null);
  const [showAllBlocks, setShowAllBlocks] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [intelligenceActive, setIntelligenceActive] = useState(false);
  const [feedItems, setFeedItems] = useState<Array<{id: string; timestamp: Date; type: string; message: string; severity: 'info' | 'warning' | 'success' | 'anomaly'}>>([]);
  const [bridgeActive, setBridgeActive] = useState(true);
  const [bridgeLastPublished, setBridgeLastPublished] = useState<Date | null>(null);
  const [bridgeStatus, setBridgeStatus] = useState<'idle' | 'publishing' | 'synced' | 'error'>('idle');

  const [userMiners, setUserMiners] = useState<any[]>([]);
  const [minerStatuses, setMinerStatuses] = useState<Record<number, any>>({});
  const [loadingMiners, setLoadingMiners] = useState(false);
  const [showAddMiner, setShowAddMiner] = useState(false);
  const [addMinerIp, setAddMinerIp] = useState("");
  const [addMinerName, setAddMinerName] = useState("");
  const [addMinerPort, setAddMinerPort] = useState("80");
  const [addMinerProtocol, setAddMinerProtocol] = useState("bitaxe");
  const [detecting, setDetecting] = useState(false);
  const [detectionResult, setDetectionResult] = useState<any>(null);
  const [minerPolling, setMinerPolling] = useState(false);
  const minerPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [autoAdjustLog, setAutoAdjustLog] = useState<Array<{ time: Date; minerId: number; action: string; reason: string }>>([]);

  const [spiderStatus, setSpiderStatus] = useState<SpiderStatus | null>(null);
  const [spiderNonceMap, setSpiderNonceMap] = useState<SpiderNonceMap | null>(null);
  const [spiderDifficulty, setSpiderDifficulty] = useState<SpiderDifficultyPrediction | null>(null);
  const [spiderWindow, setSpiderWindow] = useState<SpiderMiningWindow | null>(null);
  const [spiderEntropy, setSpiderEntropy] = useState<SpiderEntropy | null>(null);
  const [spiderIntel, setSpiderIntel] = useState<SpiderIntelligenceEntry[]>([]);
  const [spiderLoading, setSpiderLoading] = useState(false);
  const spiderPollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchSpiderData = useCallback(async () => {
    setSpiderLoading(true);
    try {
      const [statusRes, nonceRes, diffRes, windowRes, entropyRes, intelRes] = await Promise.all([
        fetch('/api/blockchain/spider/status').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/blockchain/spider/nonce-map').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/blockchain/spider/difficulty-prediction').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/blockchain/spider/mining-window').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/blockchain/spider/entropy').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/blockchain/spider/intelligence').then(r => r.ok ? r.json() : null).catch(() => null),
      ]);
      if (statusRes) setSpiderStatus(statusRes);
      if (nonceRes) setSpiderNonceMap(nonceRes);
      if (diffRes) setSpiderDifficulty(diffRes);
      if (windowRes) setSpiderWindow(windowRes);
      if (entropyRes) setSpiderEntropy(entropyRes);
      if (intelRes?.intelligenceFeed) setSpiderIntel(intelRes.intelligenceFeed);
    } catch (e) {
      console.error('Spider data fetch error:', e);
    }
    setSpiderLoading(false);
  }, []);

  useEffect(() => {
    if (activeTab === 'spider') {
      fetchSpiderData();
      spiderPollRef.current = setInterval(fetchSpiderData, 10000);
    } else {
      if (spiderPollRef.current) {
        clearInterval(spiderPollRef.current);
        spiderPollRef.current = null;
      }
    }
    return () => {
      if (spiderPollRef.current) {
        clearInterval(spiderPollRef.current);
        spiderPollRef.current = null;
      }
    };
  }, [activeTab, fetchSpiderData]);

  const fetchBlocks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/blockchain/blocks?count=${blockCount}`);
      if (!res.ok) throw new Error('Failed to fetch blocks');
      const data = await res.json();
      setBlocks(data.blocks);
      setLatestHeight(data.latestHeight);
      setLastFetched(new Date());

      if (data.blocks.length >= 2) {
        setAnalyzing(true);
        const analyzeRes = await fetch('/api/blockchain/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ hashes: data.blocks.map((b: BlockData) => b.hash) })
        });
        if (analyzeRes.ok) {
          const result = await analyzeRes.json();
          setAnalysis(result.analysis);

          if (intelligenceActive) {
            const newItems: typeof feedItems = [];
            const a = result.analysis as AnalysisResult;
            a.patterns.forEach((p: string, idx: number) => {
              newItems.push({
                id: `pattern-${Date.now()}-${idx}`,
                timestamp: new Date(),
                type: p.includes('ANOMALY') ? 'Hash Anomaly' : 'Pattern Detection',
                message: p,
                severity: p.includes('ANOMALY') ? 'anomaly' : 'info',
              });
            });

            const avgBitDist = a.bitDistributions.reduce((s, v) => s + v, 0) / a.bitDistributions.length;
            if (Math.abs(avgBitDist - 0.5) > 0.03) {
              newItems.push({
                id: `bit-${Date.now()}`,
                timestamp: new Date(),
                type: 'Mining Signal',
                message: `Bit distribution avg ${(avgBitDist * 100).toFixed(1)}% — ${avgBitDist > 0.5 ? 'high entropy window detected' : 'low entropy window — favorable for hash convergence'}`,
                severity: avgBitDist < 0.5 ? 'success' : 'warning',
              });
            }

            const leadingZeroTrend = a.leadingZeros.length > 1 ? a.leadingZeros[a.leadingZeros.length - 1] - a.leadingZeros[0] : 0;
            if (leadingZeroTrend !== 0) {
              newItems.push({
                id: `zeros-${Date.now()}`,
                timestamp: new Date(),
                type: 'Difficulty Signal',
                message: `Leading zeros ${leadingZeroTrend > 0 ? 'increasing' : 'decreasing'} across recent blocks — difficulty ${leadingZeroTrend > 0 ? 'rising' : 'easing'}, ${leadingZeroTrend < 0 ? 'favorable mining window opening' : 'harder target threshold'}`,
                severity: leadingZeroTrend < 0 ? 'success' : 'warning',
              });
            }

            const strongCorrs = a.autocorrelations.filter(c => Math.abs(c) > 0.15);
            if (strongCorrs.length > 0) {
              newItems.push({
                id: `corr-${Date.now()}`,
                timestamp: new Date(),
                type: 'Correlation Alert',
                message: `${strongCorrs.length} autocorrelation lag(s) above threshold — potential repeating pattern in block hash sequence detected`,
                severity: 'anomaly',
              });
            }

            setFeedItems(prev => [...newItems, ...prev].slice(0, 100));
          }

          if (bridgeActive) {
            const a = result.analysis as AnalysisResult;
            const avgLZ = a.leadingZeros.reduce((s: number, v: number) => s + v, 0) / a.leadingZeros.length;
            const avgBD = a.bitDistributions.reduce((s: number, v: number) => s + v, 0) / a.bitDistributions.length;
            const entDev = Math.abs(avgBD - 0.5);
            const anomCount = a.patterns.filter((p: string) => p.includes('ANOMALY')).length;
            const sCorrs = a.autocorrelations.filter((c: number) => Math.abs(c) > 0.15).length;
            let wScore = 50;
            if (entDev < 0.03) wScore += 15;
            if (anomCount > 0) wScore += 10;
            if (sCorrs > 0) wScore += 10;
            const m3u = a.mod3Distribution.every((v: number) => v > 0);
            if (!m3u) wScore += 5;
            const sig = wScore >= 75 ? 'MINE' : wScore < 40 ? 'WAIT' : 'HOLD';
            const lzTrend = a.leadingZeros.length > 1 ? a.leadingZeros[a.leadingZeros.length - 1] - a.leadingZeros[0] : 0;
            const mod3Total = a.mod3Distribution.reduce((s: number, v: number) => s + v, 0);
            const mod3Ent = -a.mod3Distribution.reduce((s: number, v: number) => { const p = v / mod3Total; return p > 0 ? s + p * Math.log2(p) : s; }, 0);

            const bridgeFeedItems: Array<{ type: string; message: string; severity: string; timestamp: number }> = [];
            a.patterns.forEach((p: string) => {
              bridgeFeedItems.push({
                type: p.includes('ANOMALY') ? 'Hash Anomaly' : 'Pattern Detection',
                message: p,
                severity: p.includes('ANOMALY') ? 'anomaly' : 'info',
                timestamp: Date.now(),
              });
            });
            if (entDev > 0.03) {
              bridgeFeedItems.push({
                type: 'Mining Signal',
                message: `Bit distribution avg ${(avgBD * 100).toFixed(1)}% — ${avgBD > 0.5 ? 'high entropy window' : 'low entropy — favorable for hash convergence'}`,
                severity: avgBD < 0.5 ? 'success' : 'warning',
                timestamp: Date.now(),
              });
            }
            if (lzTrend !== 0) {
              bridgeFeedItems.push({
                type: 'Difficulty Signal',
                message: `Leading zeros ${lzTrend > 0 ? 'increasing' : 'decreasing'} — difficulty ${lzTrend > 0 ? 'rising' : 'easing'}`,
                severity: lzTrend < 0 ? 'success' : 'warning',
                timestamp: Date.now(),
              });
            }
            if (sCorrs > 0) {
              bridgeFeedItems.push({
                type: 'Correlation Alert',
                message: `${sCorrs} autocorrelation lag(s) above threshold — potential repeating pattern detected`,
                severity: 'anomaly',
                timestamp: Date.now(),
              });
            }

            setBridgeStatus('publishing');
            try {
              await fetch('/api/mining-bridge/publish', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  windowScore: wScore,
                  signal: sig,
                  entropyDeviation: (entDev * 100).toFixed(2),
                  avgBitDist: (avgBD * 100).toFixed(1),
                  chiSquared: a.chiSquaredStatistic.toFixed(1),
                  avgLeadingZeros: avgLZ.toFixed(1),
                  anomalyCount: anomCount,
                  strongCorrs: sCorrs,
                  blockCount: a.blockCount,
                  difficultyTrend: lzTrend > 0 ? 'rising' : lzTrend < 0 ? 'falling' : 'stable',
                  mod3Entropy: (mod3Ent / Math.log2(3) * 100).toFixed(1),
                  feedItems: bridgeFeedItems.slice(0, 20),
                }),
              });
              setBridgeStatus('synced');
              setBridgeLastPublished(new Date());
            } catch {
              setBridgeStatus('error');
            }
          }
        }
        setAnalyzing(false);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [blockCount, intelligenceActive, bridgeActive]);

  useEffect(() => {
    fetchBlocks();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(fetchBlocks, 60000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [autoRefresh, fetchBlocks]);

  useEffect(() => {
    if (!isConnected || !connectedDevice) return;
    const refreshStats = async () => {
      try {
        const stats = await refreshDeviceStats(connectedDevice);
        setCurrentStats(stats);
      } catch (error) {
        console.error('Stats refresh failed:', error);
      }
    };
    const interval = setInterval(refreshStats, 5000);
    return () => clearInterval(interval);
  }, [isConnected, connectedDevice]);

  const scanForMiners = (type: 'wifi' | 'usb') => {
    setIsScanning(true);
    setScanType(type);
    const scanDuration = type === 'wifi' ? 4000 : 2500;
    setTimeout(async () => {
      try {
        const discovered = type === 'wifi' ? await simulateNetworkScan() : await simulateUSBScan();
        if (discovered.length > 0) {
          const device = discovered[0];
          const connected = await connectToDevice(device);
          setDiscoveredDevices(discovered);
          setConnectedDevice(connected);
          setIsConnected(true);
          setCurrentStats(connected.stats || null);
        }
      } catch (error) {
        console.error('Scan error:', error);
      }
      setIsScanning(false);
      setScanType(null);
    }, scanDuration);
  };

  const connectManually = () => {
    if (minerAddress) {
      setIsConnected(true);
      setShowManualConnect(false);
    }
  };

  const disconnect = useCallback(async () => {
    if (connectedDevice) await disconnectDevice(connectedDevice);
    setIsConnected(false);
    setConnectedDevice(null);
    setCurrentStats(null);
    setDiscoveredDevices([]);
  }, [connectedDevice]);

  const hexChars = '0123456789abcdef'.split('');

  const fetchUserMiners = useCallback(async () => {
    setLoadingMiners(true);
    try {
      const res = await fetch('/api/miners');
      if (res.ok) {
        const data = await res.json();
        setUserMiners(data);
      }
    } catch (e) {
      console.error('Failed to fetch miners:', e);
    }
    setLoadingMiners(false);
  }, []);

  const pollMinerStatuses = useCallback(async () => {
    for (const miner of userMiners) {
      try {
        const res = await fetch(`/api/miners/${miner.id}/status`);
        if (res.ok) {
          const data = await res.json();
          setMinerStatuses(prev => ({ ...prev, [miner.id]: data.status }));

          if (miner.autoAdjust && data.status?.online) {
            try {
              const adjRes = await fetch(`/api/miners/${miner.id}/auto-adjust`, { method: 'POST' });
              if (adjRes.ok) {
                const adj = await adjRes.json();
                if (adj.adjusted) {
                  setAutoAdjustLog(prev => [{ time: new Date(), minerId: miner.id, action: adj.action, reason: adj.reason }, ...prev].slice(0, 50));
                }
              }
            } catch {}
          }
        }
      } catch {}
    }
  }, [userMiners]);

  useEffect(() => {
    fetchUserMiners();
  }, [fetchUserMiners]);

  useEffect(() => {
    if (userMiners.length > 0 && !minerPolling) {
      setMinerPolling(true);
      pollMinerStatuses();
      minerPollRef.current = setInterval(pollMinerStatuses, 10000);
    }
    return () => {
      if (minerPollRef.current) {
        clearInterval(minerPollRef.current);
        minerPollRef.current = null;
        setMinerPolling(false);
      }
    };
  }, [userMiners, pollMinerStatuses]);

  const detectMiner = async () => {
    if (!addMinerIp) return;
    setDetecting(true);
    setDetectionResult(null);
    try {
      const res = await fetch('/api/miners/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ipAddress: addMinerIp }),
      });
      const data = await res.json();
      setDetectionResult(data);
      if (data.detected) {
        setAddMinerPort(String(data.port));
        setAddMinerProtocol(data.protocol);
        if (data.info?.hostname) setAddMinerName(data.info.hostname);
        else if (data.info?.ASICModel) setAddMinerName(`${data.info.ASICModel} Miner`);
        else setAddMinerName(`${data.protocol.charAt(0).toUpperCase() + data.protocol.slice(1)} Miner`);
      }
    } catch {
      setDetectionResult({ detected: false, message: 'Connection failed' });
    }
    setDetecting(false);
  };

  const addMiner = async () => {
    if (!addMinerIp || !addMinerName) return;
    try {
      const res = await fetch('/api/miners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: addMinerName,
          ipAddress: addMinerIp,
          port: parseInt(addMinerPort) || 80,
          protocol: addMinerProtocol,
        }),
      });
      if (res.ok) {
        setShowAddMiner(false);
        setAddMinerIp('');
        setAddMinerName('');
        setAddMinerPort('80');
        setDetectionResult(null);
        fetchUserMiners();
      }
    } catch {}
  };

  const removeMiner = async (id: number) => {
    try {
      await fetch(`/api/miners/${id}`, { method: 'DELETE' });
      setUserMiners(prev => prev.filter(m => m.id !== id));
      setMinerStatuses(prev => { const n = { ...prev }; delete n[id]; return n; });
    } catch {}
  };

  const toggleAutoAdjust = async (id: number, current: boolean) => {
    try {
      const res = await fetch(`/api/miners/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ autoAdjust: !current }),
      });
      if (res.ok) {
        setUserMiners(prev => prev.map(m => m.id === id ? { ...m, autoAdjust: !current } : m));
      }
    } catch {}
  };

  const restartMinerDevice = async (id: number) => {
    try {
      await fetch(`/api/miners/${id}/restart`, { method: 'POST' });
    } catch {}
  };

  const identifyMinerDevice = async (id: number) => {
    try {
      await fetch(`/api/miners/${id}/identify`, { method: 'POST' });
    } catch {}
  };

  const miningInsights = useMemo(() => {
    if (!analysis) return null;
    const avgLeadingZeros = analysis.leadingZeros.reduce((s, v) => s + v, 0) / analysis.leadingZeros.length;
    const avgBitDist = analysis.bitDistributions.reduce((s, v) => s + v, 0) / analysis.bitDistributions.length;
    const anomalyCount = analysis.patterns.filter(p => p.includes('ANOMALY')).length;
    const strongCorrs = analysis.autocorrelations.filter(c => Math.abs(c) > 0.15).length;
    const entropyDeviation = Math.abs(avgBitDist - 0.5);

    let windowScore = 50;
    if (entropyDeviation < 0.03) windowScore += 15;
    if (anomalyCount > 0) windowScore += 10;
    if (strongCorrs > 0) windowScore += 10;
    const mod3Uniform = analysis.mod3Distribution.every(v => v > 0);
    if (!mod3Uniform) windowScore += 5;

    let signal: 'MINE' | 'HOLD' | 'WAIT' = 'HOLD';
    if (windowScore >= 75) signal = 'MINE';
    else if (windowScore < 40) signal = 'WAIT';

    return {
      avgLeadingZeros: avgLeadingZeros.toFixed(1),
      avgBitDist: (avgBitDist * 100).toFixed(1),
      anomalyCount,
      strongCorrs,
      entropyDeviation: (entropyDeviation * 100).toFixed(2),
      chiSquared: analysis.chiSquaredStatistic.toFixed(1),
      windowScore,
      signal,
      blockCount: analysis.blockCount,
    };
  }, [analysis]);

  const sbpeMetrics = useMemo(() => {
    if (!analysis || !blocks.length) return null;
    const avgLeadingZeros = analysis.leadingZeros.reduce((s, v) => s + v, 0) / analysis.leadingZeros.length;
    const avgBitDist = analysis.bitDistributions.reduce((s, v) => s + v, 0) / analysis.bitDistributions.length;
    const leadingZeroTrend = analysis.leadingZeros.length > 1 ? analysis.leadingZeros[analysis.leadingZeros.length - 1] - analysis.leadingZeros[0] : 0;
    const hexValues = Object.values(analysis.hexDigitFrequency);
    const maxHex = Math.max(...hexValues);
    const minHex = Math.min(...hexValues);
    const hexSpread = maxHex - minHex;
    const timestamps = blocks.map(b => b.timestamp);
    const avgBlockTime = timestamps.length > 1 ? (timestamps[0] - timestamps[timestamps.length - 1]) / (timestamps.length - 1) : 600;
    const difficulties = blocks.map(b => b.difficulty);
    const avgDiff = difficulties.reduce((s, v) => s + v, 0) / difficulties.length;
    const diffVar = difficulties.reduce((s, v) => s + Math.pow(v - avgDiff, 2), 0) / difficulties.length;
    const entropyScore = (1 - Math.abs(avgBitDist - 0.5) * 20) * 100;
    const totalTx = blocks.reduce((s, b) => s + b.txCount, 0);
    const avgTxPerBlock = totalTx / blocks.length;
    const strongCorrs = analysis.autocorrelations.filter(c => Math.abs(c) > 0.1);
    const corrStrength = strongCorrs.length > 0 ? strongCorrs.reduce((s, c) => s + Math.abs(c), 0) / strongCorrs.length : 0;

    return {
      tda: { value: `${leadingZeroTrend > 0 ? '+' : ''}${leadingZeroTrend}`, detail: `σ²=${Math.sqrt(diffVar / avgDiff).toFixed(3)}`, trend: leadingZeroTrend <= 0 ? 'positive' : 'negative' },
      ecm: { value: `${entropyScore.toFixed(1)}%`, detail: `χ²=${analysis.chiSquaredStatistic.toFixed(1)}`, trend: entropyScore > 90 ? 'positive' : entropyScore > 80 ? 'neutral' : 'negative' },
      nlo: { value: `${avgBlockTime.toFixed(0)}s`, detail: `${blocks.length} blocks`, trend: avgBlockTime < 660 ? 'positive' : 'neutral' },
      mpm: { value: `${avgTxPerBlock.toFixed(0)}`, detail: `${totalTx.toLocaleString()} total`, trend: avgTxPerBlock > 2000 ? 'positive' : 'neutral' },
      phc: { value: `${(corrStrength * 100).toFixed(1)}%`, detail: `${strongCorrs.length} lags`, trend: corrStrength > 0.15 ? 'positive' : 'neutral' },
      acm: { value: `${avgLeadingZeros.toFixed(1)}`, detail: `spread=${hexSpread}`, trend: hexSpread < 20 ? 'positive' : 'neutral' },
    };
  }, [analysis, blocks]);

  const solvingMetrics = useMemo(() => {
    if (!analysis || !blocks.length) return null;
    const avgBitDist = analysis.bitDistributions.reduce((s, v) => s + v, 0) / analysis.bitDistributions.length;
    const mod3 = analysis.mod3Distribution;
    const mod9 = analysis.mod9Distribution;
    const corrs = analysis.autocorrelations;
    const xorBitCounts = analysis.xorPatterns.map(xor => xor.split('').reduce((acc, c) => { const n = parseInt(c, 16); let bits = 0; for (let b = 0; b < 4; b++) bits += (n >> b) & 1; return acc + bits; }, 0));
    const avgXorBits = xorBitCounts.length > 0 ? xorBitCounts.reduce((s, v) => s + v, 0) / xorBitCounts.length : 128;
    const nonces = blocks.map(b => b.nonce);
    const avgNonce = nonces.reduce((s, v) => s + v, 0) / nonces.length;
    const nonceRange = Math.max(...nonces) - Math.min(...nonces);
    const maxCorr = corrs.length > 0 ? Math.max(...corrs.map(Math.abs)) : 0;
    const ratios = analysis.ratiosSample;
    const avgRatio = ratios.length > 0 ? ratios.reduce((s, v) => s + v, 0) / ratios.length : 1;
    const mod3Entropy = -mod3.reduce((s, v) => { const p = v / mod3.reduce((a, b) => a + b, 0); return p > 0 ? s + p * Math.log2(p) : s; }, 0);
    const mod9Entropy = -mod9.reduce((s, v) => { const p = v / mod9.reduce((a, b) => a + b, 0); return p > 0 ? s + p * Math.log2(p) : s; }, 0);
    const bitDeviation = Math.abs(avgBitDist - 0.5);
    const xorDeviation = Math.abs(avgXorBits - 128) / 128;

    return {
      nca: {
        mfa: `${(avgNonce / 1e9).toFixed(2)}G`,
        diq: `${(nonceRange / 1e9).toFixed(1)}G`,
        rso: `±${(nonceRange / avgNonce * 100).toFixed(1)}%`,
        cvs: `${Math.min(99, (1 - nonceRange / (4294967295)) * 100).toFixed(1)}`,
      },
      hfre: {
        fsd: `${(maxCorr * 100).toFixed(1)}%`,
        rfd: `L${corrs.findIndex(c => Math.abs(c) === maxCorr) + 1}`,
        egm: `${(bitDeviation * 200).toFixed(2)}%`,
        rwp: `${corrs.filter(c => Math.abs(c) > 0.1).length}/10`,
      },
      bin: {
        nce: `${blocks.reduce((s, b) => s + b.txCount, 0).toLocaleString()}`,
        msp: `${blocks.length}`,
        orp: `${(xorDeviation * 100).toFixed(1)}%`,
        dap: `${analysis.leadingZeros[analysis.leadingZeros.length - 1] - analysis.leadingZeros[0] > 0 ? '+' : ''}${analysis.leadingZeros[analysis.leadingZeros.length - 1] - analysis.leadingZeros[0]}`,
      },
      cca: {
        bco: `${(avgXorBits / 256 * 100).toFixed(1)}%`,
        swd: `${xorBitCounts.filter(c => Math.abs(c - 128) > 10).length}`,
        rpa: `${avgRatio.toFixed(4)}`,
        mcm: `${analysis.blockCount}`,
      },
      dca: {
        ddt: `${(mod3Entropy / Math.log2(3) * 100).toFixed(1)}%`,
        bpa: `${(256 - avgXorBits).toFixed(0)}`,
        rrm: `${(mod9Entropy / Math.log2(9) * 100).toFixed(1)}%`,
        isb: `${(bitDeviation * 100).toFixed(2)}%`,
      },
    };
  }, [analysis, blocks]);

  const tabs = [
    { id: 'intelligence' as const, label: 'Live Intelligence', icon: Brain, color: 'from-emerald-500 to-cyan-500' },
    { id: 'spider' as const, label: 'Spider', icon: Globe, color: 'from-violet-500 to-purple-500' },
    { id: 'mining' as const, label: 'Mining Hub', icon: Cpu, color: 'from-orange-500 to-red-500' },
    { id: 'hashlab' as const, label: 'Hash Lab', icon: Fingerprint, color: 'from-cyan-500 to-blue-500' },
    { id: 'minerhub' as const, label: 'Miner Hub', icon: HardDrive, color: 'from-amber-500 to-yellow-500' },
  ];

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-[#0a0e17] text-white">
        <div className="container mx-auto px-4 py-6 max-w-7xl">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500/10 to-cyan-500/10 border border-orange-500/30 rounded-full px-4 py-1.5 mb-3">
              <Zap className="w-4 h-4 text-orange-400" />
              <span className="text-orange-400 text-sm font-semibold">SUPER APP</span>
              {isAdmin && <span className="text-[10px] bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold px-2 py-0.5 rounded-full">OWNER ACCESS</span>}
            </div>
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2" data-testid="text-command-center-title">
              Alpha Mining <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-yellow-400 to-cyan-400">Command Center</span>
            </h1>
            <p className="text-gray-400 max-w-3xl mx-auto text-sm">
              Unified mining optimization — hardware connection, real-time blockchain hash analysis, and AI-powered mining intelligence in one command center.
            </p>
            <div className="flex items-center justify-center gap-3 mt-3">
              <button
                onClick={() => setBridgeActive(!bridgeActive)}
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                  bridgeActive
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-white/5 border-white/10 text-gray-500'
                }`}
                data-testid="button-toggle-bridge"
              >
                {bridgeActive ? <Link2 className="w-3.5 h-3.5" /> : <Unlink className="w-3.5 h-3.5" />}
                Companion Bridge
                {bridgeStatus === 'synced' && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
                {bridgeStatus === 'publishing' && <Loader2 className="w-3 h-3 animate-spin" />}
                {bridgeStatus === 'error' && <AlertTriangle className="w-3 h-3 text-red-400" />}
              </button>
              {bridgeLastPublished && bridgeActive && (
                <span className="text-[10px] text-gray-500">
                  Last sync: {bridgeLastPublished.toLocaleTimeString()}
                </span>
              )}
            </div>
          </motion.div>

          {miningInsights && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-3 md:grid-cols-7 gap-2 mb-6">
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Mining Signal</div>
                <div className={`text-xl font-bold mt-1 ${miningInsights.signal === 'MINE' ? 'text-green-400' : miningInsights.signal === 'HOLD' ? 'text-yellow-400' : 'text-red-400'}`} data-testid="text-mining-signal">
                  {miningInsights.signal}
                </div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Window Score</div>
                <div className="text-xl font-bold mt-1 text-cyan-400" data-testid="text-window-score">{miningInsights.windowScore}/100</div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Entropy Dev.</div>
                <div className="text-xl font-bold mt-1 text-purple-400">{miningInsights.entropyDeviation}%</div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Bit Balance</div>
                <div className="text-xl font-bold mt-1 text-cyan-300">{miningInsights.avgBitDist}%</div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Chi-Squared</div>
                <div className="text-xl font-bold mt-1 text-orange-400">{miningInsights.chiSquared}</div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Anomalies</div>
                <div className="text-xl font-bold mt-1 text-yellow-400">{miningInsights.anomalyCount}</div>
              </div>
              <div className="bg-[#111827] border border-white/10 rounded-xl p-3 text-center">
                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Blocks</div>
                <div className="text-xl font-bold mt-1 text-gray-300">{miningInsights.blockCount}</div>
              </div>
            </motion.div>
          )}

          <div className="flex gap-2 mb-6 bg-[#111827] border border-white/10 rounded-xl p-1.5">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? `bg-gradient-to-r ${tab.color} text-white shadow-lg`
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
                data-testid={`button-tab-${tab.id}`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'intelligence' && (
              <motion.div key="intelligence" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111827] border border-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${intelligenceActive ? 'bg-green-500 animate-pulse' : 'bg-gray-600'}`} />
                    <span className="font-semibold">Live Intelligence Feed</span>
                    <span className="text-xs text-gray-500">Blockchain analysis feeds mining optimization signals in real-time</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-1.5">
                      <Database className="w-3.5 h-3.5 text-gray-400" />
                      <select
                        value={blockCount}
                        onChange={(e) => setBlockCount(parseInt(e.target.value))}
                        className="bg-transparent text-white text-xs border-none outline-none"
                        data-testid="select-intel-block-count"
                      >
                        <option value={10}>10 blocks</option>
                        <option value={20}>20 blocks</option>
                        <option value={50}>50 blocks</option>
                        <option value={100}>100 blocks</option>
                        <option value={200}>200 blocks</option>
                        <option value={500}>500 blocks</option>
                      </select>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => {
                        setIntelligenceActive(!intelligenceActive);
                        if (!intelligenceActive) {
                          setAutoRefresh(true);
                          fetchBlocks();
                        } else {
                          setAutoRefresh(false);
                        }
                      }}
                      className={intelligenceActive ? "bg-red-600 hover:bg-red-700 text-xs" : "bg-emerald-600 hover:bg-emerald-700 text-xs"}
                      data-testid="button-toggle-intelligence"
                    >
                      {intelligenceActive ? <><Pause className="w-3.5 h-3.5 mr-1.5" /> Stop Feed</> : <><Play className="w-3.5 h-3.5 mr-1.5" /> Start Feed</>}
                    </Button>
                    <Button
                      size="sm"
                      onClick={fetchBlocks}
                      disabled={loading}
                      variant="outline"
                      className="text-xs border-white/20"
                      data-testid="button-refresh-intel"
                    >
                      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                    </Button>
                  </div>
                </div>

                {isConnected && currentStats && (
                  <div className="bg-gradient-to-r from-emerald-500/5 to-cyan-500/5 border border-emerald-500/20 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <HardDrive className="w-4 h-4 text-emerald-400" />
                      <span className="text-sm font-semibold text-emerald-400">Connected Miner</span>
                    </div>
                    <div className="grid grid-cols-4 gap-4">
                      <div>
                        <div className="text-[10px] text-gray-500">Hashrate</div>
                        <div className="text-lg font-bold text-white">{formatHashrate(currentStats.hashrate, currentStats.hashrateUnit)}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500">Temperature</div>
                        <div className="text-lg font-bold text-white">{currentStats.temperature}°C</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500">Power</div>
                        <div className="text-lg font-bold text-white">{currentStats.power}W</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500">Accepted</div>
                        <div className="text-lg font-bold text-green-400">{currentStats.accepted}</div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-4">
                        <Activity className="w-5 h-5 text-emerald-400" />
                        <h3 className="font-bold text-sm">Intelligence Feed</h3>
                        <span className="text-xs text-gray-500 ml-auto">{feedItems.length} events</span>
                      </div>
                      {feedItems.length === 0 ? (
                        <div className="text-center py-12 text-gray-500">
                          <Brain className="w-12 h-12 mx-auto mb-3 opacity-30" />
                          <p className="text-sm">Start the intelligence feed to see real-time mining signals from blockchain hash analysis</p>
                          <p className="text-xs mt-2">Click "Start Feed" above to begin analyzing live Bitcoin blocks</p>
                        </div>
                      ) : (
                        <div className="space-y-2 max-h-[500px] overflow-y-auto">
                          {feedItems.map(item => (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className={`flex items-start gap-3 p-3 rounded-lg border ${
                                item.severity === 'anomaly' ? 'bg-yellow-500/5 border-yellow-500/20' :
                                item.severity === 'success' ? 'bg-emerald-500/5 border-emerald-500/20' :
                                item.severity === 'warning' ? 'bg-orange-500/5 border-orange-500/20' :
                                'bg-white/[0.02] border-white/5'
                              }`}
                            >
                              {item.severity === 'anomaly' ? <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 shrink-0" /> :
                               item.severity === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" /> :
                               item.severity === 'warning' ? <AlertTriangle className="w-4 h-4 text-orange-400 mt-0.5 shrink-0" /> :
                               <Info className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={`text-[10px] font-semibold uppercase tracking-wider ${
                                    item.severity === 'anomaly' ? 'text-yellow-400' :
                                    item.severity === 'success' ? 'text-emerald-400' :
                                    item.severity === 'warning' ? 'text-orange-400' :
                                    'text-cyan-400'
                                  }`}>{item.type}</span>
                                  <span className="text-[10px] text-gray-600">{item.timestamp.toLocaleTimeString()}</span>
                                </div>
                                <p className="text-xs text-gray-300">{item.message}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    {analysis && (
                      <>
                        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
                          <div className="flex items-center gap-2 mb-3">
                            <BarChart3 className="w-4 h-4 text-green-400" />
                            <h3 className="font-bold text-sm">Hex Frequency</h3>
                          </div>
                          <div className="grid grid-cols-8 gap-0.5">
                            {hexChars.map(char => {
                              const count = analysis.hexDigitFrequency[char] || 0;
                              const maxCount = Math.max(...Object.values(analysis.hexDigitFrequency));
                              const pct = maxCount > 0 ? (count / maxCount) * 100 : 0;
                              return (
                                <div key={char} className="text-center">
                                  <div className="h-10 flex items-end justify-center mb-0.5">
                                    <div className="w-full bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t" style={{ height: `${pct}%`, minHeight: '2px' }} />
                                  </div>
                                  <span className="text-[9px] font-mono text-cyan-400">{char}</span>
                                </div>
                              );
                            })}
                          </div>
                          <div className="text-[10px] text-gray-500 mt-2 text-center">χ² = {analysis.chiSquaredStatistic.toFixed(1)}</div>
                        </div>

                        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
                          <div className="flex items-center gap-2 mb-3">
                            <Zap className="w-4 h-4 text-yellow-400" />
                            <h3 className="font-bold text-sm">Tesla 3-6-9</h3>
                          </div>
                          <div className="flex gap-1.5 mb-2">
                            {analysis.mod3Distribution.map((count, i) => (
                              <div key={i} className="flex-1 bg-black/40 rounded p-1.5 text-center">
                                <div className="text-sm font-bold text-yellow-400">{count}</div>
                                <div className="text-[8px] text-gray-500">mod {i}</div>
                              </div>
                            ))}
                          </div>
                          <div className="grid grid-cols-9 gap-0.5">
                            {analysis.mod9Distribution.map((count, i) => (
                              <div key={i} className="bg-black/40 rounded p-0.5 text-center">
                                <div className="text-[10px] font-bold text-orange-400">{count}</div>
                                <div className="text-[7px] text-gray-500">{i}</div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="bg-[#111827] border border-white/10 rounded-xl p-4">
                          <div className="flex items-center gap-2 mb-3">
                            <Activity className="w-4 h-4 text-cyan-400" />
                            <h3 className="font-bold text-sm">Bit Balance</h3>
                          </div>
                          <div className="h-16 flex items-end gap-[1px]">
                            {analysis.bitDistributions.slice(0, 30).map((ratio, i) => {
                              const deviation = Math.abs(ratio - 0.5);
                              return (
                                <div
                                  key={i}
                                  className="flex-1 rounded-t"
                                  style={{
                                    height: `${ratio * 100}%`,
                                    backgroundColor: deviation > 0.05
                                      ? `rgba(234, 179, 8, ${0.5 + deviation * 5})`
                                      : `rgba(34, 211, 238, ${0.3 + ratio * 0.7})`
                                  }}
                                  title={`Block ${i}: ${(ratio * 100).toFixed(1)}%`}
                                />
                              );
                            })}
                          </div>
                          <div className="text-[10px] text-gray-500 mt-1 text-center">50% = perfect randomness</div>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {lastFetched && (
                  <div className="text-center text-[10px] text-gray-600">
                    Last scan: {lastFetched.toLocaleTimeString()} | Block #{latestHeight.toLocaleString()}
                    {autoRefresh && ' | Auto-refreshing every 60s'}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'mining' && (
              <motion.div key="mining" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <HardDrive className="w-5 h-5 text-orange-400" />
                      <h3 className="font-bold">Hardware Connection</h3>
                      <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs ${isConnected ? 'bg-green-500/10 text-green-400' : 'bg-gray-500/10 text-gray-400'}`}>
                        <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`} />
                        {isConnected ? 'Connected' : 'Disconnected'}
                      </div>
                    </div>
                    {isConnected && (
                      <Button size="sm" variant="outline" onClick={disconnect} className="text-xs border-red-500/30 text-red-400 hover:bg-red-500/10" data-testid="button-disconnect-miner">
                        <Unlink className="w-3.5 h-3.5 mr-1.5" /> Disconnect
                      </Button>
                    )}
                  </div>

                  {!isConnected ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button
                          onClick={() => scanForMiners('wifi')}
                          disabled={isScanning}
                          className="flex flex-col items-center gap-3 p-6 bg-blue-500/5 border border-blue-500/20 rounded-xl hover:bg-blue-500/10 transition-all disabled:opacity-50"
                          data-testid="button-scan-wifi"
                        >
                          {isScanning && scanType === 'wifi' ? <Loader2 className="w-8 h-8 text-blue-400 animate-spin" /> : <Wifi className="w-8 h-8 text-blue-400" />}
                          <span className="font-semibold text-sm">Scan Wi-Fi Miners</span>
                          <span className="text-[10px] text-gray-500">ASIC miners, mining rigs on your network</span>
                        </button>
                        <button
                          onClick={() => scanForMiners('usb')}
                          disabled={isScanning}
                          className="flex flex-col items-center gap-3 p-6 bg-green-500/5 border border-green-500/20 rounded-xl hover:bg-green-500/10 transition-all disabled:opacity-50"
                          data-testid="button-scan-usb"
                        >
                          {isScanning && scanType === 'usb' ? <Loader2 className="w-8 h-8 text-green-400 animate-spin" /> : <Usb className="w-8 h-8 text-green-400" />}
                          <span className="font-semibold text-sm">Scan USB Miners</span>
                          <span className="text-[10px] text-gray-500">USB ASIC miners, block erupters</span>
                        </button>
                        <button
                          onClick={() => setShowManualConnect(!showManualConnect)}
                          className="flex flex-col items-center gap-3 p-6 bg-purple-500/5 border border-purple-500/20 rounded-xl hover:bg-purple-500/10 transition-all"
                          data-testid="button-manual-connect"
                        >
                          <Link2 className="w-8 h-8 text-purple-400" />
                          <span className="font-semibold text-sm">Manual Connect</span>
                          <span className="text-[10px] text-gray-500">Enter IP address and port</span>
                        </button>
                      </div>

                      {showManualConnect && (
                        <div className="bg-black/30 border border-white/10 rounded-xl p-4">
                          <div className="flex gap-3">
                            <input
                              type="text"
                              placeholder="Miner IP Address"
                              value={minerAddress}
                              onChange={(e) => setMinerAddress(e.target.value)}
                              className="flex-1 bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-purple-500/50"
                              data-testid="input-miner-ip"
                            />
                            <input
                              type="text"
                              placeholder="Port"
                              value={minerPort}
                              onChange={(e) => setMinerPort(e.target.value)}
                              className="w-24 bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-purple-500/50"
                              data-testid="input-miner-port"
                            />
                            <Button onClick={connectManually} className="bg-purple-600 hover:bg-purple-700 text-sm" data-testid="button-connect-manual">
                              Connect
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {connectedDevice && (
                        <>
                          <div className="bg-black/30 rounded-lg p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Device</div>
                            <div className="text-sm font-bold text-white">{connectedDevice.device.name}</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Hashrate</div>
                            <div className="text-sm font-bold text-cyan-400">{connectedDevice.device.hashrate}</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Algorithm</div>
                            <div className="text-sm font-bold text-purple-400">{connectedDevice.device.algorithm}</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Connection</div>
                            <div className="text-sm font-bold text-green-400">{getConnectionTypeLabel(connectedDevice.device.interface)}</div>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-3 bg-[#111827] border border-white/10 rounded-xl p-4">
                  <span className="text-sm font-semibold">Mode:</span>
                  <button onClick={() => setMode('auto')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs ${mode === 'auto' ? 'bg-emerald-600 text-white' : 'bg-white/5 text-gray-400'}`} data-testid="button-mode-auto">
                    <Sparkles className="w-3.5 h-3.5" /> Auto (SBPE)
                  </button>
                  <button onClick={() => setMode('manual')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs ${mode === 'manual' ? 'bg-orange-600 text-white' : 'bg-white/5 text-gray-400'}`} data-testid="button-mode-manual">
                    <Sliders className="w-3.5 h-3.5" /> Manual
                  </button>
                  <div className="ml-auto flex items-center gap-2">
                    <span className="text-xs text-gray-500">Blockchain:</span>
                    <select value={selectedBlockchain} onChange={(e) => setSelectedBlockchain(e.target.value)} className="bg-black/50 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none" data-testid="select-blockchain">
                      {BLOCKCHAIN_PRESETS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                  </div>
                </div>

                <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Shield className="w-5 h-5 text-cyan-400" />
                    <h3 className="font-bold">SBPE™ Mining Optimization</h3>
                    <span className="text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full font-semibold ml-auto">6/6 ACTIVE</span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {SBPE_FEATURES.map(feat => {
                      const m = sbpeMetrics ? sbpeMetrics[feat.id as keyof typeof sbpeMetrics] : null;
                      return (
                        <div key={feat.id} className={`bg-black/30 border rounded-lg p-3 ${m ? 'border-white/10' : 'border-white/5'}`}>
                          <div className="flex items-center gap-2 mb-2">
                            <feat.icon className="w-4 h-4" style={{ color: feat.color }} />
                            <span className="text-xs font-semibold" style={{ color: feat.color }}>{feat.shortTitle}</span>
                            {m && <div className={`w-1.5 h-1.5 rounded-full ml-auto ${m.trend === 'positive' ? 'bg-green-500' : m.trend === 'negative' ? 'bg-red-500' : 'bg-yellow-500'} animate-pulse`} />}
                          </div>
                          <div className="text-[10px] text-gray-400">{feat.desc}</div>
                          {m ? (
                            <div className="mt-2 flex items-baseline gap-2">
                              <span className="text-sm font-bold font-mono" style={{ color: feat.color }}>{m.value}</span>
                              <span className="text-[10px] text-gray-500 font-mono">{m.detail}</span>
                            </div>
                          ) : (
                            <div className="text-xs font-mono mt-2 text-gray-500">
                              {loading ? 'Loading...' : 'Awaiting data'}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Atom className="w-5 h-5 text-purple-400" />
                    <h3 className="font-bold">Blockchain Solving Technologies</h3>
                    <span className="text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full font-semibold ml-auto">
                      {Object.values(activeTechs).filter(Boolean).length}/{SOLVING_TECHS.length} ACTIVE
                    </span>
                  </div>
                  <div className="space-y-3">
                    {SOLVING_TECHS.map(tech => (
                      <div key={tech.id} className="bg-black/30 border border-white/5 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tech.color }} />
                            <span className="text-sm font-bold" style={{ color: tech.color }}>{tech.shortName}™</span>
                            <span className="text-xs text-gray-400">{tech.name}</span>
                          </div>
                          <button
                            onClick={() => setActiveTechs(prev => ({ ...prev, [tech.id]: !prev[tech.id] }))}
                            className={`text-xs px-2 py-1 rounded ${activeTechs[tech.id] ? 'bg-green-600 text-white' : 'bg-white/5 text-gray-400'}`}
                            data-testid={`button-toggle-${tech.id}`}
                          >
                            {activeTechs[tech.id] ? 'Active' : 'Inactive'}
                          </button>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {tech.features.map(f => {
                            const techMetrics = solvingMetrics ? solvingMetrics[tech.id as keyof typeof solvingMetrics] : null;
                            const metricValue = techMetrics ? techMetrics[f.id as keyof typeof techMetrics] : null;
                            return (
                              <div key={f.id} className={`bg-black/30 rounded p-2 ${metricValue && activeTechs[tech.id] ? 'border border-white/5' : ''}`}>
                                <div className="text-[10px] text-gray-500">{f.metric}</div>
                                <div className="text-xs font-mono" style={{ color: metricValue && activeTechs[tech.id] ? tech.color : '#6b7280' }}>
                                  {activeTechs[tech.id] && metricValue ? metricValue : loading ? '...' : '--'}
                                </div>
                                <div className="text-[9px] text-gray-600 mt-0.5">{f.title}</div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <GitBranch className="w-5 h-5 text-yellow-400" />
                    <h3 className="font-bold">Mining Bridge Fusion™</h3>
                    <span className="text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full font-semibold ml-auto">
                      {Object.values(activeBridges).filter(Boolean).length}/{BRIDGE_PRESETS.length} ACTIVE
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {BRIDGE_PRESETS.map(bridge => (
                      <button
                        key={bridge.id}
                        onClick={() => setActiveBridges(prev => ({ ...prev, [bridge.id]: !prev[bridge.id] }))}
                        className={`p-3 rounded-lg border text-left transition-all ${
                          activeBridges[bridge.id] ? 'border-yellow-500/30 bg-yellow-500/5' : 'border-white/5 bg-black/30 hover:bg-white/5'
                        }`}
                        data-testid={`button-bridge-${bridge.id}`}
                      >
                        <div className="flex items-center gap-1.5 mb-1">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: bridge.color }} />
                          <span className="text-xs font-semibold" style={{ color: bridge.color }}>{bridge.name}</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {bridge.techs.map(t => (
                            <span key={t} className="text-[9px] bg-white/5 rounded px-1 py-0.5 text-gray-400">{t}</span>
                          ))}
                        </div>
                        <div className="text-[10px] mt-1.5 text-gray-500">{activeBridges[bridge.id] ? '● Active' : '○ Inactive'}</div>
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'spider' && (
              <motion.div key="spider" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111827] border border-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-violet-400" />
                    <span className="font-semibold">Autonomous Blockchain Spider™</span>
                    {spiderStatus && (
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                        spiderStatus.status === 'ready' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                        spiderStatus.status === 'crawling' || spiderStatus.status === 'analyzing' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' :
                        'bg-gray-500/10 text-gray-400 border-gray-500/20'
                      }`} data-testid="text-spider-status">
                        {spiderStatus.status.toUpperCase()}
                      </span>
                    )}
                  </div>
                  <Button
                    size="sm"
                    onClick={fetchSpiderData}
                    disabled={spiderLoading}
                    variant="outline"
                    className="text-xs border-white/20"
                    data-testid="button-refresh-spider"
                  >
                    {spiderLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : <RefreshCw className="w-3.5 h-3.5 mr-1.5" />}
                    Refresh
                  </Button>
                </div>

                {spiderStatus && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <Activity className="w-5 h-5 text-violet-400" />
                      <h3 className="font-bold text-sm">Crawl Progress</h3>
                      <span className="text-xs text-gray-500 ml-auto" data-testid="text-spider-blocks-analyzed">
                        {spiderStatus.blocksAnalyzed} / {spiderStatus.totalBlocks} blocks analyzed
                      </span>
                    </div>
                    <div className="w-full h-4 bg-black/40 rounded-full overflow-hidden mb-3">
                      <div
                        className="h-full bg-gradient-to-r from-violet-600 to-purple-400 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, spiderStatus.crawlProgress)}%` }}
                        data-testid="progress-spider-crawl"
                      />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Progress</div>
                        <div className="text-lg font-bold text-violet-400" data-testid="text-spider-progress">{spiderStatus.crawlProgress.toFixed(1)}%</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Blocks Analyzed</div>
                        <div className="text-lg font-bold text-purple-400">{spiderStatus.blocksAnalyzed}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Total Blocks</div>
                        <div className="text-lg font-bold text-cyan-400">{spiderStatus.totalBlocks}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Last Crawl</div>
                        <div className="text-lg font-bold text-gray-300">
                          {spiderStatus.lastCrawlTime ? new Date(spiderStatus.lastCrawlTime).toLocaleTimeString() : '--'}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {spiderNonceMap && spiderNonceMap.buckets && spiderNonceMap.buckets.length > 0 && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <MapPin className="w-5 h-5 text-orange-400" />
                      <h3 className="font-bold text-sm">Nonce Distribution Heatmap</h3>
                      <span className="text-xs text-gray-500 ml-auto">{spiderNonceMap.totalBlocks} blocks sampled</span>
                    </div>
                    <div className="flex items-end gap-[2px] h-32 mb-3" data-testid="chart-nonce-heatmap">
                      {spiderNonceMap.buckets.map((count, i) => {
                        const maxBucket = Math.max(...spiderNonceMap.buckets, 1);
                        const pct = (count / maxBucket) * 100;
                        const intensity = count / maxBucket;
                        return (
                          <div
                            key={i}
                            className="flex-1 rounded-t transition-all"
                            style={{
                              height: `${Math.max(pct, 2)}%`,
                              backgroundColor: `rgba(${Math.round(255 * intensity)}, ${Math.round(120 - 80 * intensity)}, ${Math.round(50 + 100 * (1 - intensity))}, ${0.4 + intensity * 0.6})`,
                            }}
                            title={`Bucket ${i}: ${count} blocks`}
                          />
                        );
                      })}
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-500 mb-4">
                      <span>Nonce 0x00000000</span>
                      <span>0xFFFFFFFF</span>
                    </div>
                    {spiderNonceMap.hotspots.length > 0 && (
                      <div>
                        <div className="text-xs text-gray-400 mb-2 font-semibold">Hotspots (High-Frequency Nonce Ranges)</div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {spiderNonceMap.hotspots.slice(0, 6).map((hs, i) => (
                            <div key={i} className="flex items-center gap-3 bg-black/30 rounded-lg p-2 border border-orange-500/10">
                              <div className="w-2 h-2 rounded-full bg-orange-400" />
                              <div className="flex-1 min-w-0">
                                <div className="text-[10px] font-mono text-orange-300">
                                  0x{hs.rangeStart.toString(16).padStart(8, '0')} — 0x{hs.rangeEnd.toString(16).padStart(8, '0')}
                                </div>
                                <div className="text-[10px] text-gray-500">
                                  {hs.frequency} hits · {(hs.probability * 100).toFixed(1)}% probability
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {spiderDifficulty && (
                    <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                      <div className="flex items-center gap-2 mb-4">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        <h3 className="font-bold text-sm">Difficulty Prediction</h3>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ml-auto ${
                          spiderDifficulty.trend === 'increasing' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                          spiderDifficulty.trend === 'decreasing' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                          'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                        }`} data-testid="text-difficulty-trend">
                          {spiderDifficulty.trend.toUpperCase()}
                        </span>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="bg-black/30 rounded-lg p-3 flex-1 mr-2">
                            <div className="text-[10px] text-gray-500 uppercase">Current</div>
                            <div className="text-lg font-bold text-cyan-400 font-mono" data-testid="text-current-difficulty">
                              {spiderDifficulty.currentDifficulty.toFixed(2)}
                            </div>
                          </div>
                          <ChevronDown className="w-5 h-5 text-gray-600 shrink-0 -rotate-90" />
                          <div className="bg-black/30 rounded-lg p-3 flex-1 ml-2">
                            <div className="text-[10px] text-gray-500 uppercase">Predicted Next</div>
                            <div className={`text-lg font-bold font-mono ${
                              spiderDifficulty.predictedNextDifficulty > spiderDifficulty.currentDifficulty ? 'text-red-400' : 'text-green-400'
                            }`} data-testid="text-predicted-difficulty">
                              {spiderDifficulty.predictedNextDifficulty.toFixed(2)}
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-black/30 rounded-lg p-2">
                            <div className="text-[10px] text-gray-500">Adjustment Factor</div>
                            <div className="text-sm font-mono text-purple-400">{spiderDifficulty.adjustmentFactor.toFixed(4)}x</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-2">
                            <div className="text-[10px] text-gray-500">Confidence</div>
                            <div className="text-sm font-mono text-yellow-400">{(spiderDifficulty.confidence * 100).toFixed(1)}%</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-2">
                            <div className="text-[10px] text-gray-500">Blocks Until Adj.</div>
                            <div className="text-sm font-mono text-gray-300">{spiderDifficulty.blocksUntilAdjustment}</div>
                          </div>
                          <div className="bg-black/30 rounded-lg p-2">
                            <div className="text-[10px] text-gray-500">Epoch Progress</div>
                            <div className="text-sm font-mono text-violet-400">{(spiderDifficulty.epochProgress * 100).toFixed(1)}%</div>
                          </div>
                        </div>
                        <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-violet-600 to-cyan-400 rounded-full" style={{ width: `${spiderDifficulty.epochProgress * 100}%` }} />
                        </div>
                      </div>
                    </div>
                  )}

                  {spiderWindow && (
                    <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                      <div className="flex items-center gap-2 mb-4">
                        <Timer className="w-5 h-5 text-green-400" />
                        <h3 className="font-bold text-sm">Optimal Mining Window</h3>
                        <div className={`w-3 h-3 rounded-full ml-auto ${spiderWindow.optimal ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                      </div>
                      <div className={`text-center p-4 rounded-xl mb-3 border ${
                        spiderWindow.optimal
                          ? 'bg-green-500/10 border-green-500/20'
                          : 'bg-red-500/10 border-red-500/20'
                      }`}>
                        <div className={`text-3xl font-bold ${spiderWindow.optimal ? 'text-green-400' : 'text-red-400'}`} data-testid="text-mining-window-status">
                          {spiderWindow.optimal ? 'OPTIMAL' : 'SUB-OPTIMAL'}
                        </div>
                        <div className="text-sm text-gray-400 mt-1">Window Score: {spiderWindow.score}/100</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-black/30 rounded-lg p-2">
                          <div className="text-[10px] text-gray-500">Avg Block Interval</div>
                          <div className="text-sm font-mono text-cyan-400">{(spiderWindow.avgBlockInterval / 1000).toFixed(1)}s</div>
                        </div>
                        <div className="bg-black/30 rounded-lg p-2">
                          <div className="text-[10px] text-gray-500">Recent Interval</div>
                          <div className="text-sm font-mono text-purple-400">{(spiderWindow.recentBlockInterval / 1000).toFixed(1)}s</div>
                        </div>
                        <div className="bg-black/30 rounded-lg p-2">
                          <div className="text-[10px] text-gray-500">Network Hash Trend</div>
                          <div className={`text-sm font-mono ${
                            spiderWindow.networkHashTrend === 'falling' ? 'text-green-400' :
                            spiderWindow.networkHashTrend === 'rising' ? 'text-red-400' : 'text-yellow-400'
                          }`}>{spiderWindow.networkHashTrend.toUpperCase()}</div>
                        </div>
                        <div className="bg-black/30 rounded-lg p-2">
                          <div className="text-[10px] text-gray-500">Interval Deviation</div>
                          <div className="text-sm font-mono text-orange-400">{spiderWindow.intervalDeviation.toFixed(2)}</div>
                        </div>
                      </div>
                      <div className="mt-3 p-3 bg-violet-500/5 border border-violet-500/10 rounded-lg">
                        <p className="text-xs text-violet-300" data-testid="text-spider-recommendation">{spiderWindow.recommendation}</p>
                      </div>
                    </div>
                  )}
                </div>

                {spiderEntropy && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <Atom className="w-5 h-5 text-yellow-400" />
                      <h3 className="font-bold text-sm">Entropy Pattern Analysis</h3>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ml-auto ${
                        spiderEntropy.entropyTrend === 'increasing' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' :
                        spiderEntropy.entropyTrend === 'decreasing' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                        'bg-gray-500/10 text-gray-400 border border-gray-500/20'
                      }`} data-testid="text-entropy-trend">
                        {spiderEntropy.entropyTrend.toUpperCase()}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Current Entropy</div>
                        <div className="text-lg font-bold text-yellow-400 font-mono" data-testid="text-current-entropy">{spiderEntropy.currentEntropy.toFixed(3)}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Avg Entropy</div>
                        <div className="text-lg font-bold text-orange-400 font-mono">{spiderEntropy.avgEntropy.toFixed(3)}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Shannon Score</div>
                        <div className="text-lg font-bold text-cyan-400 font-mono">{(spiderEntropy.shannonScore * 100).toFixed(1)}%</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 text-center">
                        <div className="text-[10px] text-gray-500 uppercase">Pattern Strength</div>
                        <div className="text-lg font-bold text-purple-400 font-mono">{(spiderEntropy.patternStrength * 100).toFixed(1)}%</div>
                      </div>
                    </div>

                    {spiderEntropy.bitDistribution.length > 0 && (
                      <div className="mb-4">
                        <div className="text-xs text-gray-400 mb-2 font-semibold">Bit Distribution (1s Ratio per Block)</div>
                        <div className="h-24 flex items-end gap-[1px]" data-testid="chart-entropy-bits">
                          {spiderEntropy.bitDistribution.map((ratio, i) => {
                            const deviation = Math.abs(ratio - 0.5);
                            return (
                              <div
                                key={i}
                                className="flex-1 rounded-t"
                                style={{
                                  height: `${ratio * 100}%`,
                                  backgroundColor: deviation > 0.05
                                    ? `rgba(234, 179, 8, ${0.5 + deviation * 5})`
                                    : `rgba(139, 92, 246, ${0.3 + ratio * 0.7})`,
                                }}
                                title={`Block ${i}: ${(ratio * 100).toFixed(1)}%`}
                              />
                            );
                          })}
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                          <span>Oldest</span>
                          <span>50% ideal</span>
                          <span>Latest</span>
                        </div>
                      </div>
                    )}

                    {spiderEntropy.leadingZeroTrend.length > 0 && (
                      <div>
                        <div className="text-xs text-gray-400 mb-2 font-semibold">Leading Zero Trend</div>
                        <div className="h-20 flex items-end gap-[2px]" data-testid="chart-leading-zeros">
                          {spiderEntropy.leadingZeroTrend.map((zeros, i) => {
                            const max = Math.max(...spiderEntropy.leadingZeroTrend, 1);
                            return (
                              <div
                                key={i}
                                className="flex-1 rounded-t bg-gradient-to-t from-cyan-600 to-cyan-400"
                                style={{ height: `${(zeros / max) * 100}%`, minHeight: '2px' }}
                                title={`Block ${i}: ${zeros} leading zeros`}
                              />
                            );
                          })}
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                          <span>Oldest</span>
                          <span>Latest</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {spiderIntel.length > 0 && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <Signal className="w-5 h-5 text-emerald-400" />
                      <h3 className="font-bold text-sm">Spider Intelligence Feed</h3>
                      <span className="text-xs text-gray-500 ml-auto">{spiderIntel.length} discoveries</span>
                    </div>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                      {spiderIntel.map((entry) => (
                        <div
                          key={entry.id}
                          className={`flex items-start gap-3 p-3 rounded-lg border ${
                            entry.severity === 'critical' ? 'bg-red-500/5 border-red-500/20' :
                            entry.severity === 'significant' ? 'bg-yellow-500/5 border-yellow-500/20' :
                            entry.severity === 'notable' ? 'bg-cyan-500/5 border-cyan-500/20' :
                            'bg-white/[0.02] border-white/5'
                          }`}
                          data-testid={`spider-intel-${entry.id}`}
                        >
                          {entry.type === 'anomaly' ? <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 shrink-0" /> :
                           entry.type === 'prediction' ? <TrendingUp className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" /> :
                           entry.type === 'optimization' ? <Sparkles className="w-4 h-4 text-green-400 mt-0.5 shrink-0" /> :
                           entry.type === 'discovery' ? <Eye className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" /> :
                           <Info className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className={`text-[10px] font-semibold uppercase tracking-wider ${
                                entry.severity === 'critical' ? 'text-red-400' :
                                entry.severity === 'significant' ? 'text-yellow-400' :
                                entry.severity === 'notable' ? 'text-cyan-400' :
                                'text-gray-400'
                              }`}>{entry.type}</span>
                              <span className="text-[10px] text-gray-600">{new Date(entry.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <p className="text-xs font-semibold text-white mb-0.5">{entry.title}</p>
                            <p className="text-xs text-gray-400">{entry.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {!spiderStatus && !spiderLoading && (
                  <div className="text-center py-16 bg-[#111827] border border-dashed border-violet-500/20 rounded-xl">
                    <Globe className="w-12 h-12 text-violet-400/40 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">Spider Initializing</h3>
                    <p className="text-gray-400 text-sm max-w-md mx-auto">
                      The Autonomous Blockchain Spider™ is initializing. It will automatically crawl and analyze the blockchain to provide nonce intelligence, difficulty predictions, and entropy analysis.
                    </p>
                  </div>
                )}

                {spiderLoading && !spiderStatus && (
                  <div className="text-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-violet-400 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">Loading spider data...</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'hashlab' && (
              <motion.div key="hashlab" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="flex flex-wrap items-center justify-center gap-3 mb-2">
                  <div className="flex items-center gap-2 bg-[#111827] border border-white/10 rounded-lg px-3 py-2">
                    <Database className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-400">Blocks:</span>
                    <select value={blockCount} onChange={(e) => setBlockCount(parseInt(e.target.value))} className="bg-transparent text-white text-sm border-none outline-none" data-testid="select-hashlab-block-count">
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                      <option value={200}>200</option>
                      <option value={500}>500</option>
                    </select>
                  </div>
                  <Button onClick={fetchBlocks} disabled={loading} className="bg-cyan-600 hover:bg-cyan-700 text-white text-sm" data-testid="button-hashlab-fetch">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                    {loading ? 'Fetching...' : 'Fetch & Analyze'}
                  </Button>
                  <Button onClick={() => setAutoRefresh(!autoRefresh)} variant={autoRefresh ? "default" : "outline"} className={autoRefresh ? "bg-green-600 hover:bg-green-700 text-sm" : "border-white/20 text-sm"} data-testid="button-hashlab-autorefresh">
                    <Activity className="w-4 h-4 mr-2" />
                    {autoRefresh ? 'Auto-Refresh ON' : 'Auto-Refresh'}
                  </Button>
                </div>

                {lastFetched && (
                  <div className="text-center text-xs text-gray-500">
                    Last updated: {lastFetched.toLocaleTimeString()} | Latest block: #{latestHeight.toLocaleString()}
                    {autoRefresh && ' | Refreshing every 60 seconds'}
                  </div>
                )}

                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    <span className="text-red-400 text-sm">{error}</span>
                  </div>
                )}

                {analysis && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-cyan-500/20 rounded-xl p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <Hash className="w-5 h-5 text-cyan-400" />
                          <h3 className="font-bold text-sm">First Block as Integer</h3>
                        </div>
                        <p className="text-cyan-400 font-mono text-xs break-all" data-testid="text-hashlab-genesis">{formatBigNumber(analysis.genesisAsInteger)}</p>
                      </div>
                      <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-blue-500/20 rounded-xl p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <Hash className="w-5 h-5 text-blue-400" />
                          <h3 className="font-bold text-sm">Latest Block as Integer</h3>
                        </div>
                        <p className="text-blue-400 font-mono text-xs break-all" data-testid="text-hashlab-latest">{formatBigNumber(analysis.latestAsInteger)}</p>
                      </div>
                      <div className="bg-gradient-to-br from-[#111827] to-[#0d1424] border border-purple-500/20 rounded-xl p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <Binary className="w-5 h-5 text-purple-400" />
                          <h3 className="font-bold text-sm">Integer Size</h3>
                        </div>
                        <p className="text-purple-400 font-mono text-2xl font-bold">{analysis.integerDigitCount} <span className="text-sm font-normal">digits</span></p>
                      </div>
                    </div>

                    <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Search className="w-5 h-5 text-yellow-400" />
                        <h3 className="font-bold">Pattern Detection Results</h3>
                      </div>
                      <div className="space-y-3">
                        {analysis.patterns.map((pattern, i) => (
                          <div key={i} className={`flex items-start gap-3 p-3 rounded-lg ${pattern.includes('ANOMALY') ? 'bg-yellow-500/10 border border-yellow-500/30' : 'bg-white/5 border border-white/5'}`}>
                            {pattern.includes('ANOMALY') ? <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 shrink-0" /> : <Fingerprint className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />}
                            <span className="text-sm text-gray-300">{pattern}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <BarChart3 className="w-5 h-5 text-green-400" />
                          <h3 className="font-bold">Hex Digit Frequency</h3>
                        </div>
                        <p className="text-xs text-gray-500 mb-3">Chi-squared: {analysis.chiSquaredStatistic.toFixed(2)}</p>
                        <div className="grid grid-cols-8 gap-1">
                          {hexChars.map(char => {
                            const count = analysis.hexDigitFrequency[char] || 0;
                            const maxCount = Math.max(...Object.values(analysis.hexDigitFrequency));
                            const pct = maxCount > 0 ? (count / maxCount) * 100 : 0;
                            return (
                              <div key={char} className="text-center">
                                <div className="h-16 flex items-end justify-center mb-1">
                                  <div className="w-full bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t" style={{ height: `${pct}%`, minHeight: '4px' }} />
                                </div>
                                <span className="text-xs font-mono text-cyan-400">{char}</span>
                                <div className="text-[10px] text-gray-500">{count}</div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <Zap className="w-5 h-5 text-yellow-400" />
                          <h3 className="font-bold">Tesla 3-6-9 Analysis</h3>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <p className="text-xs text-gray-400 mb-2">Mod 3 Distribution:</p>
                            <div className="flex gap-2">
                              {analysis.mod3Distribution.map((count, i) => (
                                <div key={i} className="flex-1 bg-black/40 rounded-lg p-2 text-center">
                                  <div className="text-lg font-bold text-yellow-400">{count}</div>
                                  <div className="text-[10px] text-gray-500">remainder {i}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div>
                            <p className="text-xs text-gray-400 mb-2">Mod 9 Distribution:</p>
                            <div className="grid grid-cols-9 gap-1">
                              {analysis.mod9Distribution.map((count, i) => (
                                <div key={i} className="bg-black/40 rounded p-1 text-center">
                                  <div className="text-sm font-bold text-orange-400">{count}</div>
                                  <div className="text-[9px] text-gray-500">{i}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <TrendingUp className="w-5 h-5 text-blue-400" />
                          <h3 className="font-bold">Autocorrelation (Lag 1-10)</h3>
                        </div>
                        <div className="space-y-2">
                          {analysis.autocorrelations.map((corr, i) => (
                            <div key={i} className="flex items-center gap-3">
                              <span className="text-xs text-gray-400 w-12">Lag {i + 1}</span>
                              <div className="flex-1 h-4 bg-black/40 rounded-full overflow-hidden relative">
                                <div className="absolute inset-0 flex items-center justify-center"><div className="w-px h-full bg-gray-600" /></div>
                                <div className={`h-full rounded-full ${Math.abs(corr) > 0.1 ? 'bg-yellow-500' : 'bg-blue-500/60'}`} style={{ width: `${Math.abs(corr) * 50}%`, marginLeft: corr >= 0 ? '50%' : `${50 - Math.abs(corr) * 50}%` }} />
                              </div>
                              <span className={`text-xs font-mono w-16 text-right ${Math.abs(corr) > 0.1 ? 'text-yellow-400' : 'text-gray-400'}`}>{corr.toFixed(4)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <Activity className="w-5 h-5 text-cyan-400" />
                          <h3 className="font-bold">Bit Distribution (1s Ratio)</h3>
                        </div>
                        <div className="h-40 flex items-end gap-[2px]">
                          {analysis.bitDistributions.slice(0, 50).map((ratio, i) => {
                            const deviation = Math.abs(ratio - 0.5);
                            return (
                              <div key={i} className="flex-1 rounded-t" style={{ height: `${ratio * 100}%`, backgroundColor: deviation > 0.05 ? `rgba(234, 179, 8, ${0.5 + deviation * 5})` : `rgba(34, 211, 238, ${0.3 + ratio * 0.7})` }} title={`Block ${i}: ${(ratio * 100).toFixed(1)}% ones`} />
                            );
                          })}
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                          <span>First block</span>
                          <span className="text-cyan-400">50% = perfect balance</span>
                          <span>Latest</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Layers className="w-5 h-5 text-purple-400" />
                        <h3 className="font-bold">XOR Patterns (Consecutive Block Hash Differences)</h3>
                      </div>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {analysis.xorPatterns.map((xor, i) => {
                          const onesCount = xor.split('').reduce((acc, c) => { const n = parseInt(c, 16); let bits = 0; for (let b = 0; b < 4; b++) bits += (n >> b) & 1; return acc + bits; }, 0);
                          return (
                            <div key={i} className="flex items-center gap-3">
                              <span className="text-xs text-gray-500 w-20 shrink-0">Block {i} XOR {i + 1}</span>
                              <code className="text-[10px] font-mono text-purple-400 break-all flex-1">{xor}</code>
                              <span className="text-xs text-gray-400 w-20 text-right shrink-0">{onesCount}/256 bits</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Shield className="w-5 h-5 text-green-400" />
                        <h3 className="font-bold">Hash-to-Integer Conversion</h3>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-xs text-gray-400 mb-2 font-semibold">Integer Differences:</h4>
                          <div className="space-y-1">
                            {analysis.differencesSample.map((diff, i) => (
                              <div key={i} className="flex items-center gap-2">
                                <span className="text-[10px] text-gray-500 w-8">#{i + 1}</span>
                                <span className="text-[10px] font-mono text-green-400 break-all">{diff.length > 40 ? diff.slice(0, 20) + '...' + diff.slice(-10) : diff}</span>
                                <span className="text-[10px] text-gray-500">({diff.length} digits)</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="text-xs text-gray-400 mb-2 font-semibold">Integer Ratios:</h4>
                          <div className="space-y-1">
                            {analysis.ratiosSample.map((ratio, i) => (
                              <div key={i} className="flex items-center gap-2">
                                <span className="text-[10px] text-gray-500 w-8">#{i + 1}</span>
                                <span className="text-[10px] font-mono text-blue-400">{ratio.toFixed(6)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {blocks.length > 0 && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Database className="w-5 h-5 text-cyan-400" />
                        <h3 className="font-bold">Raw Block Data</h3>
                        <span className="text-xs text-gray-500">({blocks.length} blocks)</span>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setShowAllBlocks(!showAllBlocks)} className="text-xs border-white/20" data-testid="button-hashlab-toggle-blocks">
                        {showAllBlocks ? <ChevronUp className="w-3 h-3 mr-1" /> : <ChevronDown className="w-3 h-3 mr-1" />}
                        {showAllBlocks ? 'Collapse' : 'Expand All'}
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {(showAllBlocks ? blocks : blocks.slice(-10)).map((block) => (
                        <div key={block.height} className="bg-black/30 rounded-lg border border-white/5 overflow-hidden">
                          <button
                            onClick={() => setExpandedBlock(expandedBlock === block.height ? null : block.height)}
                            className="w-full flex items-center gap-3 p-3 hover:bg-white/5 transition-colors text-left"
                            data-testid={`button-hashlab-block-${block.height}`}
                          >
                            <span className="text-xs font-bold text-cyan-400 w-20">#{block.height.toLocaleString()}</span>
                            <code className="text-[10px] font-mono text-gray-400 flex-1 truncate">{block.hash}</code>
                            <span className="text-[10px] text-gray-500">{new Date(block.timestamp * 1000).toLocaleString()}</span>
                            {expandedBlock === block.height ? <ChevronUp className="w-3 h-3 text-gray-400" /> : <ChevronDown className="w-3 h-3 text-gray-400" />}
                          </button>
                          <AnimatePresence>
                            {expandedBlock === block.height && (
                              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="border-t border-white/5">
                                <div className="p-3 grid grid-cols-2 gap-2 text-xs">
                                  <div><span className="text-gray-500">Hash:</span><code className="text-cyan-400 font-mono text-[10px] block break-all">{block.hash}</code></div>
                                  <div><span className="text-gray-500">Previous Hash:</span><code className="text-blue-400 font-mono text-[10px] block break-all">{block.prevHash}</code></div>
                                  <div><span className="text-gray-500">Merkle Root:</span><code className="text-purple-400 font-mono text-[10px] block break-all">{block.merkleRoot}</code></div>
                                  <div><span className="text-gray-500">Nonce:</span><span className="text-yellow-400 font-mono"> {block.nonce.toLocaleString()}</span></div>
                                  <div><span className="text-gray-500">Transactions:</span><span className="text-green-400 font-mono"> {block.txCount.toLocaleString()}</span></div>
                                  <div><span className="text-gray-500">Size:</span><span className="text-gray-300 font-mono"> {(block.size / 1024).toFixed(1)} KB</span></div>
                                  <div><span className="text-gray-500">Difficulty Bits:</span><span className="text-orange-400 font-mono"> {block.difficulty}</span></div>
                                  <div><span className="text-gray-500">Version:</span><span className="text-gray-300 font-mono"> 0x{block.version.toString(16)}</span></div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'minerhub' && (
              <motion.div key="minerhub" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="bg-[#111827] border border-amber-500/20 rounded-xl p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                        <HardDrive className="w-5 h-5 text-amber-400" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">Hardware Miner Hub</h3>
                        <p className="text-xs text-gray-400">Connect, monitor, and auto-optimize your ASIC mining hardware</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">
                        {userMiners.filter(m => minerStatuses[m.id]?.online).length} Online
                      </span>
                      <span className="text-xs px-2 py-1 rounded-full bg-gray-500/10 text-gray-400 border border-gray-500/20">
                        {userMiners.length} Total
                      </span>
                      <Button
                        onClick={() => setShowAddMiner(true)}
                        className="bg-amber-600 hover:bg-amber-700 text-white text-sm"
                        data-testid="button-add-miner"
                      >
                        <Usb className="w-4 h-4 mr-2" />
                        Add Miner
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                      <div className="text-gray-500 mb-1">Supported Protocols</div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-amber-400" /><span className="text-amber-300">Bitaxe (AxeOS)</span><span className="text-gray-500">— Gamma, Supra, Ultra, Hex</span></div>
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-400" /><span className="text-blue-300">CGMiner / BFGMiner</span><span className="text-gray-500">— Antminer, Avalon, etc.</span></div>
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-400" /><span className="text-green-300">Generic HTTP</span><span className="text-gray-500">— Any miner with web API</span></div>
                      </div>
                    </div>
                    <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                      <div className="text-gray-500 mb-1">Auto-Detection</div>
                      <p className="text-gray-300">Enter your miner's IP address and we auto-detect the protocol, model, and firmware version. Supports Bitaxe on port 80 and CGMiner on port 4028.</p>
                    </div>
                    <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                      <div className="text-gray-500 mb-1">Auto-Adjust</div>
                      <p className="text-gray-300">When enabled, Command Center mining signals (MINE/HOLD/WAIT) automatically optimize your miner's settings — fan speed, thermal protection, and efficiency tuning.</p>
                    </div>
                  </div>
                </div>

                <AnimatePresence>
                  {showAddMiner && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                      <div className="bg-[#111827] border border-cyan-500/20 rounded-xl p-5">
                        <div className="flex items-center gap-2 mb-4">
                          <Search className="w-5 h-5 text-cyan-400" />
                          <h3 className="font-bold">Connect New Miner</h3>
                          <button onClick={() => { setShowAddMiner(false); setDetectionResult(null); }} className="ml-auto text-gray-400 hover:text-white text-sm">Cancel</button>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <label className="text-xs text-gray-400 block mb-1">Miner IP Address</label>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={addMinerIp}
                                onChange={(e) => setAddMinerIp(e.target.value)}
                                placeholder="e.g. 192.168.1.100"
                                className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                                data-testid="input-miner-ip"
                              />
                              <Button
                                onClick={detectMiner}
                                disabled={detecting || !addMinerIp}
                                className="bg-cyan-600 hover:bg-cyan-700 text-white text-sm"
                                data-testid="button-detect-miner"
                              >
                                {detecting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Search className="w-4 h-4 mr-2" />}
                                Auto-Detect
                              </Button>
                            </div>
                          </div>

                          {detectionResult && (
                            <div className={`rounded-lg p-3 border ${detectionResult.detected ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
                              {detectionResult.detected ? (
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-green-400 text-sm font-semibold">
                                    <CheckCircle2 className="w-4 h-4" />
                                    Miner Detected!
                                  </div>
                                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                    <div><span className="text-gray-500">Protocol:</span> <span className="text-green-300">{detectionResult.protocol}</span></div>
                                    <div><span className="text-gray-500">Port:</span> <span className="text-green-300">{detectionResult.port}</span></div>
                                    {detectionResult.info?.ASICModel && <div><span className="text-gray-500">ASIC:</span> <span className="text-amber-300">{detectionResult.info.ASICModel}</span></div>}
                                    {detectionResult.info?.boardVersion && <div><span className="text-gray-500">Board:</span> <span className="text-cyan-300">{detectionResult.info.boardVersion}</span></div>}
                                    {detectionResult.info?.version && <div><span className="text-gray-500">Firmware:</span> <span className="text-purple-300">{detectionResult.info.version}</span></div>}
                                    {detectionResult.info?.hostname && <div><span className="text-gray-500">Hostname:</span> <span className="text-blue-300">{detectionResult.info.hostname}</span></div>}
                                    {(detectionResult.info?.hashRate || detectionResult.info?.hashrate) && <div><span className="text-gray-500">Hashrate:</span> <span className="text-yellow-300">{(detectionResult.info.hashRate ?? detectionResult.info.hashrate).toFixed(1)} GH/s</span></div>}
                                    {detectionResult.info?.asicTemp && <div><span className="text-gray-500">Temp:</span> <span className="text-orange-300">{detectionResult.info.asicTemp}°C</span></div>}
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 text-red-400 text-sm">
                                  <AlertTriangle className="w-4 h-4" />
                                  {detectionResult.message || 'No miner detected at this address'}
                                </div>
                              )}
                            </div>
                          )}

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            <div>
                              <label className="text-xs text-gray-400 block mb-1">Miner Name</label>
                              <input
                                type="text"
                                value={addMinerName}
                                onChange={(e) => setAddMinerName(e.target.value)}
                                placeholder="My Bitaxe Gamma"
                                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                                data-testid="input-miner-name"
                              />
                            </div>
                            <div>
                              <label className="text-xs text-gray-400 block mb-1">Port</label>
                              <input
                                type="number"
                                value={addMinerPort}
                                onChange={(e) => setAddMinerPort(e.target.value)}
                                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50"
                                data-testid="input-miner-port"
                              />
                            </div>
                            <div>
                              <label className="text-xs text-gray-400 block mb-1">Protocol</label>
                              <select
                                value={addMinerProtocol}
                                onChange={(e) => setAddMinerProtocol(e.target.value)}
                                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50"
                                data-testid="select-miner-protocol"
                              >
                                <option value="bitaxe">Bitaxe (AxeOS)</option>
                                <option value="cgminer">CGMiner / BFGMiner</option>
                                <option value="vnish">Vnish Firmware</option>
                                <option value="braiins">Braiins OS+</option>
                                <option value="generic_http">Generic HTTP</option>
                              </select>
                            </div>
                          </div>

                          <div className="flex justify-end gap-2">
                            <Button
                              onClick={addMiner}
                              disabled={!addMinerIp || !addMinerName}
                              className="bg-green-600 hover:bg-green-700 text-white text-sm"
                              data-testid="button-save-miner"
                            >
                              <Link2 className="w-4 h-4 mr-2" />
                              Save & Connect
                            </Button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {loadingMiners ? (
                  <div className="text-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-amber-400 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">Loading miners...</p>
                  </div>
                ) : userMiners.length === 0 ? (
                  <div className="text-center py-16 bg-[#111827] border border-dashed border-amber-500/20 rounded-xl">
                    <HardDrive className="w-12 h-12 text-amber-400/40 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No Miners Connected</h3>
                    <p className="text-gray-400 text-sm mb-4 max-w-md mx-auto">
                      Connect your solo mining hardware to monitor hashrate, temperature, and status in real-time.
                      The system auto-detects Bitaxe, Antminer, and other ASIC miners on your network.
                    </p>
                    <Button onClick={() => setShowAddMiner(true)} className="bg-amber-600 hover:bg-amber-700 text-white" data-testid="button-add-first-miner">
                      <Usb className="w-4 h-4 mr-2" />
                      Connect Your First Miner
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {userMiners.map((miner) => {
                      const status = minerStatuses[miner.id];
                      const online = status?.online ?? false;
                      return (
                        <div key={miner.id} className={`bg-[#111827] border rounded-xl overflow-hidden ${online ? 'border-green-500/20' : 'border-red-500/20'}`}>
                          <div className="p-4">
                            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                              <div className="flex items-center gap-3">
                                <div className={`w-3 h-3 rounded-full ${online ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                                <div>
                                  <div className="font-bold text-white flex items-center gap-2">
                                    {miner.name}
                                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">{miner.protocol}</span>
                                  </div>
                                  <div className="text-xs text-gray-500">{miner.ipAddress}:{miner.port} {status?.firmwareVersion ? `• FW ${status.firmwareVersion}` : ''}</div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => toggleAutoAdjust(miner.id, miner.autoAdjust)}
                                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${miner.autoAdjust ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-white/5 text-gray-400 border border-white/10'}`}
                                  data-testid={`button-auto-adjust-${miner.id}`}
                                >
                                  {miner.autoAdjust ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                                  Auto-Adjust
                                </button>
                                {miner.protocol === 'bitaxe' && (
                                  <button
                                    onClick={() => identifyMinerDevice(miner.id)}
                                    className="p-1.5 rounded-lg bg-white/5 text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 border border-white/10 transition-all"
                                    title="Identify (blink LED)"
                                    data-testid={`button-identify-${miner.id}`}
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                )}
                                <button
                                  onClick={() => restartMinerDevice(miner.id)}
                                  className="p-1.5 rounded-lg bg-white/5 text-gray-400 hover:text-cyan-400 hover:bg-cyan-500/10 border border-white/10 transition-all"
                                  title="Restart miner"
                                  data-testid={`button-restart-${miner.id}`}
                                >
                                  <RefreshCw className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => removeMiner(miner.id)}
                                  className="p-1.5 rounded-lg bg-white/5 text-gray-400 hover:text-red-400 hover:bg-red-500/10 border border-white/10 transition-all"
                                  title="Remove miner"
                                  data-testid={`button-remove-${miner.id}`}
                                >
                                  <Unlink className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {online && status ? (
                              <div className="space-y-3">
                                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">Hashrate</div>
                                    <div className="text-lg font-bold text-amber-400">{typeof status.hashrate === 'number' ? status.hashrate.toFixed(1) : '0'}</div>
                                    <div className="text-[10px] text-gray-500">{status.hashrateUnit || 'GH/s'}</div>
                                  </div>
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">ASIC Temp</div>
                                    <div className={`text-lg font-bold ${(status.temperature ?? 0) > 70 ? 'text-red-400' : (status.temperature ?? 0) > 60 ? 'text-yellow-400' : 'text-green-400'}`}>{status.temperature?.toFixed(1) ?? '--'}°C</div>
                                    {status.vrTemp ? <div className="text-[10px] text-gray-500">VR: {status.vrTemp.toFixed(1)}°C</div> : null}
                                  </div>
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">Fan</div>
                                    <div className="text-lg font-bold text-cyan-400">{typeof status.fanSpeed === 'number' ? status.fanSpeed.toFixed(0) : '--'}%</div>
                                    {status.fanRpm ? <div className="text-[10px] text-gray-500">{status.fanRpm} RPM</div> : null}
                                  </div>
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">Power</div>
                                    <div className="text-lg font-bold text-purple-400">{typeof status.power === 'number' ? status.power.toFixed(1) : '--'}W</div>
                                    {status.voltage ? <div className="text-[10px] text-gray-500">{status.voltage}mV</div> : null}
                                  </div>
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">Shares</div>
                                    <div className="text-lg font-bold text-green-400">{status.accepted ?? 0}</div>
                                    <div className="text-[10px] text-red-400">{status.rejected ?? 0} rejected</div>
                                  </div>
                                  <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                                    <div className="text-[10px] text-gray-500 uppercase">Best Diff</div>
                                    <div className="text-lg font-bold text-yellow-400 truncate">{status.bestDifficulty ?? '--'}</div>
                                    {status.uptimeSeconds ? <div className="text-[10px] text-gray-500">{Math.floor((status.uptimeSeconds ?? 0) / 3600)}h uptime</div> : null}
                                  </div>
                                </div>

                                {(status.poolUrl || status.chipModel || status.boardVersion || status.frequency || status.blockHeight) && (
                                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                    {status.chipModel && (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">ASIC: </span><span className="text-amber-300">{status.chipModel}</span>
                                      </div>
                                    )}
                                    {status.boardVersion && (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">Board: </span><span className="text-cyan-300">{status.boardVersion}</span>
                                      </div>
                                    )}
                                    {status.frequency ? (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">Freq: </span><span className="text-purple-300">{status.frequency} MHz</span>
                                      </div>
                                    ) : null}
                                    {status.blockHeight ? (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">Block: </span><span className="text-green-300">#{status.blockHeight.toLocaleString()}</span>
                                      </div>
                                    ) : null}
                                    {status.poolUrl && (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5 col-span-2">
                                        <span className="text-gray-500">Pool: </span><span className="text-blue-300 truncate">{status.poolUrl}</span>
                                      </div>
                                    )}
                                    {status.ssid && (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">WiFi: </span><span className="text-green-300">{status.ssid}</span>
                                      </div>
                                    )}
                                    {status.hostname && (
                                      <div className="bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                                        <span className="text-gray-500">Host: </span><span className="text-gray-300">{status.hostname}</span>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="text-center py-4 bg-black/20 rounded-lg border border-red-500/10">
                                <WifiOff className="w-6 h-6 text-red-400/60 mx-auto mb-2" />
                                <p className="text-red-400/60 text-sm">{status?.error || 'Miner offline or unreachable'}</p>
                                <p className="text-gray-500 text-xs mt-1">Check that the miner is powered on and accessible at {miner.ipAddress}:{miner.port}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {autoAdjustLog.length > 0 && (
                  <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <Sliders className="w-5 h-5 text-green-400" />
                      <h3 className="font-bold">Auto-Adjust Activity</h3>
                    </div>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {autoAdjustLog.map((entry, i) => {
                        const minerName = userMiners.find(m => m.id === entry.minerId)?.name ?? 'Unknown';
                        return (
                          <div key={i} className="flex items-center gap-3 text-xs bg-black/20 rounded-lg px-3 py-2 border border-white/5">
                            <span className="text-gray-500">{entry.time.toLocaleTimeString()}</span>
                            <span className="text-amber-300">{minerName}</span>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${entry.action === 'boost' ? 'bg-green-500/10 text-green-400' : entry.action === 'thermal_protect' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                              {entry.action.toUpperCase()}
                            </span>
                            <span className="text-gray-400 flex-1">{entry.reason}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="bg-[#111827] border border-white/10 rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Info className="w-5 h-5 text-blue-400" />
                    <h3 className="font-bold text-sm">Connection Guide</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-400">
                    <div className="space-y-2">
                      <p className="text-white font-semibold">For Bitaxe Miners (Gamma, Supra, Ultra, Hex):</p>
                      <ol className="list-decimal list-inside space-y-1">
                        <li>Find your Bitaxe's IP address from your router or the Bitaxe display</li>
                        <li>Enter the IP above and click "Auto-Detect"</li>
                        <li>The system auto-discovers your miner model, firmware, and current stats</li>
                        <li>Enable "Auto-Adjust" for automatic optimization based on mining signals</li>
                      </ol>
                    </div>
                    <div className="space-y-2">
                      <p className="text-white font-semibold">For CGMiner-Based Miners (Antminer, Avalon, etc.):</p>
                      <ol className="list-decimal list-inside space-y-1">
                        <li>Ensure CGMiner API is enabled (--api-listen --api-allow W:0/0)</li>
                        <li>Enter the miner's IP address — auto-detect checks port 4028</li>
                        <li>For remote miners, ensure port 4028 is forwarded through your router</li>
                        <li>The system reads hashrate, temperature, and share statistics</li>
                      </ol>
                    </div>
                  </div>
                  <div className="mt-3 p-3 bg-amber-500/5 border border-amber-500/10 rounded-lg text-xs text-amber-300/80">
                    <strong>Network Note:</strong> Your miner must be accessible from this server's network. For local network miners, you may need to set up port forwarding on your router, or access this platform from the same network as your miner.
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}

export default function MiningCommandCenter() {
  const { user, isAdmin, isLoading } = useAuth();

  if (isLoading) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen bg-[#0a0e17] flex items-center justify-center text-gray-500">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3" />
            <p className="text-sm">Loading...</p>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  if (!user || !isAdmin) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen bg-[#0a0e17] flex items-center justify-center">
          <div className="text-center px-6 max-w-md">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
              <Shield className="w-8 h-8 text-amber-400" />
            </div>
            <h2 className="text-2xl font-display font-bold text-white mb-3">Coming Soon</h2>
            <p className="text-gray-400 text-sm mb-6">
              This advanced mining tool is currently in development and testing. Stay tuned for updates.
            </p>
            <a href="/alpha-trading" className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-gray-300 hover:bg-white/10 transition-colors" data-testid="button-back-trading">
              Back to Trading Platform
            </a>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  return <MiningCommandCenterContent />;
}