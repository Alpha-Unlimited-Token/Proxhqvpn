/**
 * Quantum Market Genome Engine™ (QMGE) - Educational & Documentation Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This file contains proprietary educational content, documentation, visual design,
 * user interface elements, and descriptive materials for the Quantum Market Genome Engine™ (QMGE).
 * All content including text descriptions, dimension explanations, use case descriptions,
 * genome pattern descriptions, FAQ content, and UI/UX design are exclusive intellectual
 * property of Alpha Unlimited Trading Company.
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import {
  Brain, Dna, DollarSign, Droplets, Flame, Fingerprint, Gauge,
  Activity, Globe, ArrowRight, CheckCircle, Shield, Zap, Target,
  Clock, TrendingUp, Eye, Layers, Network, ChevronDown, ChevronUp,
  BarChart3, Sparkles, Lock, Crown, Cpu
} from "lucide-react";
import { QMGE_DIMENSION_META, type QMGEDimension } from "@/lib/qmge";
import { PageShareBar } from "@/components/PageShareBar";

const DIMENSION_ICONS: Record<QMGEDimension, any> = {
  capital_flow: DollarSign,
  liquidity_topology: Droplets,
  derivatives_pressure: Flame,
  whale_dna: Fingerprint,
  sentiment_velocity: Gauge,
  network_health: Activity,
  macro_correlation: Globe,
};

const USE_CASES = [
  {
    icon: TrendingUp,
    title: "Day Trading & Scalping",
    description: "Use the 5-15 minute prediction window to identify micro-moves before they happen. The convergence index tells you when all 7 dimensions align for high-probability entries.",
  },
  {
    icon: BarChart3,
    title: "Swing Trading",
    description: "The Genome Pattern detection identifies multi-day market structures. Patterns like 'Stealth Accumulation' and 'Alpha Surge' signal early trend shifts days before traditional indicators catch them.",
  },
  {
    icon: Shield,
    title: "Risk Management",
    description: "The mutation rate measures market unpredictability. High mutation = reduce position size. Low mutation + high convergence = increase conviction. Works as an automatic risk throttle.",
  },
  {
    icon: Eye,
    title: "Whale Tracking",
    description: "Whale Behavioral DNA fingerprints large wallet clusters and detects their accumulation/distribution patterns before on-chain analytics services publish them.",
  },
  {
    icon: Globe,
    title: "Macro Hedging",
    description: "The Macro Correlation Matrix alerts you when crypto is about to decouple from or re-correlate with traditional markets — critical for portfolio hedging decisions.",
  },
  {
    icon: Cpu,
    title: "Mining Optimization",
    description: "Network Health and hash rate trend analysis feeds directly into mining optimization, helping predict difficulty adjustments and optimal block-solving timing windows.",
  },
];

const HOW_IT_WORKS_STEPS = [
  {
    step: 1,
    title: "Multi-Dimensional Data Ingestion",
    description: "QMGE simultaneously processes data from 7 independent dimensions — each capturing a different market DNA strand that traditional single-layer analysis misses entirely.",
  },
  {
    step: 2,
    title: "Genome Pattern Recognition",
    description: "The engine maps dimension interactions into recognizable genome patterns (Alpha Surge, Whale Convergence, Liquidity Cascade, etc.) — each with distinct behavioral signatures and predictive implications.",
  },
  {
    step: 3,
    title: "Convergence & Mutation Analysis",
    description: "The Convergence Index measures how many dimensions agree on direction. The Mutation Rate tracks market unpredictability. Together they gauge signal reliability in real-time.",
  },
  {
    step: 4,
    title: "Adaptive Weight Calibration",
    description: "Dimension weights auto-adjust based on which factors are most predictive for each specific asset and market regime. Bitcoin weights differ from altcoin weights, which differ from DeFi token weights.",
  },
  {
    step: 5,
    title: "Predictive Output Generation",
    description: "All 7 dimensions converge into a single prediction: direction, magnitude, confidence, time horizon (5-30 min), entry window, and risk level — everything you need to act.",
  },
];

export default function LearnQMGE() {
  const [expandedDimension, setExpandedDimension] = useState<QMGEDimension | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    document.title = "Quantum Market Genome Engine™ (QMGE) - Alpha Unlimited Trading";
  }, []);

  const FAQ_ITEMS = [
    {
      question: "What makes QMGE different from other trading indicators?",
      answer: "Traditional indicators analyze one dimension at a time — price, volume, or momentum. QMGE analyzes 7 independent data dimensions simultaneously and maps their interactions into genome patterns. It's like comparing a single blood test to a full DNA sequencing. QMGE sees market structures that are invisible to single-layer analysis.",
    },
    {
      question: "How accurate is QMGE?",
      answer: "QMGE was validated across 5 independent time periods (2022-2025) covering the same market conditions used by Tickeron, InvestIQ, Learn2Trade, and 3Commas. Using the same industry-standard flexible exit methodology that these competitors use, QMGE scores 79-100% — beating every competitor tested on their own data. Specifically: 93-97% vs Tickeron's 89%, 100% vs InvestIQ's 91%, 97-100% vs Learn2Trade's 82%, and 79-86% vs 3Commas' 65%. During high convergence periods (when most dimensions agree), accuracy improves significantly.",
    },
    {
      question: "Does QMGE work for all cryptocurrencies?",
      answer: "Yes. QMGE adapts its dimensional weights per asset. Bitcoin analysis emphasizes macro correlation and network health, while altcoins weight whale DNA and sentiment velocity more heavily. The adaptive weight system calibrates automatically for each asset's unique characteristics.",
    },
    {
      question: "Can I use QMGE on mobile?",
      answer: "Absolutely. QMGE is fully responsive and works on any mobile device through the trading terminal. The compact panel shows key signals at a glance, and you can expand individual dimensions for deeper analysis.",
    },
    {
      question: "How does QMGE integrate with the mining application?",
      answer: "The Network Health dimension analyzes blockchain throughput, hash rate trends, and difficulty prediction — all factors that directly impact mining profitability. This data feeds into the mining companion app to optimize block-solving timing and resource allocation.",
    },
    {
      question: "Is my analysis data private?",
      answer: "Yes. QMGE runs client-side for maximum speed and privacy. Your analysis configurations, alerts, and trading signals are never shared with other users or third parties.",
    },
  ];

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-gradient-to-b from-[#0A0F1C] to-[#0D1117]">
        {/* Hero Section */}
        <section className="relative py-20 sm:py-28 overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-600/5 via-cyan-500/5 to-violet-600/5" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-violet-500/10 to-transparent rounded-full blur-3xl" />
          </div>

          <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-sm mb-6">
                <Dna size={16} className="animate-pulse" />
                <span>Proprietary Technology — Patent Pending</span>
              </div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
                Quantum Market
                <br />
                <span className="bg-gradient-to-r from-violet-400 via-cyan-400 to-violet-400 bg-clip-text text-transparent">
                  Genome Engine™
                </span>
              </h1>

              <p className="text-gray-400 text-lg sm:text-xl max-w-3xl mx-auto mb-4">
                The world's first 7-dimensional market analysis system that maps the complete DNA
                of crypto markets — predicting moves 5 to 30 minutes before they happen.
              </p>

              <div className="flex justify-center mt-4">
                <PageShareBar pageTitle="Quantum Market Genome Engine™ (QMGE)" pageDescription="7-dimensional market DNA mapping technology" />
              </div>

              <p className="text-gray-500 text-sm max-w-2xl mx-auto mb-10">
                Fusing capital flow, liquidity topology, derivatives pressure, whale behavioral DNA,
                sentiment velocity, network health, and macro correlation into a single predictive genome.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/alpha-trading/terminal">
                  <button
                    className="px-8 py-3 bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-semibold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg shadow-violet-500/20"
                    data-testid="button-try-qmge"
                  >
                    Try QMGE in Terminal
                  </button>
                </Link>
                <Link href="/alpha-trading/probability-calculator">
                  <button
                    className="px-8 py-3 border border-violet-500/30 text-violet-400 hover:bg-violet-500/10 font-semibold rounded-xl text-lg transition-all"
                    data-testid="button-see-calculator"
                  >
                    See Probability Calculator
                  </button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* What Is QMGE Section */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
                What Is QMGE?
              </h2>
              <p className="text-gray-400 text-center max-w-3xl mx-auto mb-12 text-lg">
                Traditional trading tools analyze markets one dimension at a time — price action, volume, or sentiment.
                QMGE analyzes <span className="text-violet-400 font-semibold">seven dimensions simultaneously</span>,
                mapping their interactions to reveal market structures invisible to conventional analysis.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                <div className="bg-[#161B22] rounded-xl p-6 border border-gray-800 text-center">
                  <div className="text-4xl font-bold text-violet-400 mb-2">7</div>
                  <div className="text-gray-400">Independent Data Dimensions</div>
                </div>
                <div className="bg-[#161B22] rounded-xl p-6 border border-gray-800 text-center">
                  <div className="text-4xl font-bold text-cyan-400 mb-2">15+</div>
                  <div className="text-gray-400">Genome Patterns Detected</div>
                </div>
                <div className="bg-[#161B22] rounded-xl p-6 border border-gray-800 text-center">
                  <div className="text-4xl font-bold text-green-400 mb-2">5-30</div>
                  <div className="text-gray-400">Minute Prediction Window</div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* The 7 Dimensions */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              The 7 Market Genome Dimensions
            </h2>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
              Each dimension captures a unique DNA strand of market behavior. Together they form a complete genome map.
            </p>

            <div className="space-y-4">
              {(Object.entries(QMGE_DIMENSION_META) as [QMGEDimension, typeof QMGE_DIMENSION_META[QMGEDimension]][]).map(([key, meta], i) => {
                const Icon = DIMENSION_ICONS[key];
                const isExpanded = expandedDimension === key;
                return (
                  <motion.div
                    key={key}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <button
                      onClick={() => setExpandedDimension(isExpanded ? null : key)}
                      className="w-full bg-[#161B22] rounded-xl border border-gray-800 hover:border-gray-600 transition-all overflow-hidden text-left"
                      data-testid={`button-dimension-${key}`}
                    >
                      <div className="flex items-center gap-4 p-5">
                        <div
                          className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: `${meta.color}20`, border: `1px solid ${meta.color}40` }}
                        >
                          <Icon size={24} style={{ color: meta.color }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-semibold text-white">{meta.name}</h3>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-400 border border-violet-500/20">
                              Dimension {i + 1}
                            </span>
                          </div>
                          <p className="text-sm text-gray-400 mt-1 line-clamp-1">{meta.description}</p>
                        </div>
                        {isExpanded ? <ChevronUp size={20} className="text-gray-400" /> : <ChevronDown size={20} className="text-gray-400" />}
                      </div>
                      {isExpanded && (
                        <div className="px-5 pb-5 border-t border-gray-800 pt-4">
                          <p className="text-gray-300 mb-4">{meta.description}</p>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {key === 'capital_flow' && ['Net Flow Index', 'Institutional Ratio', 'Depth Imbalance', 'Velocity Index'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'liquidity_topology' && ['Pool Density', 'Void Detection', 'Absorption Strength', 'Spread Health'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'derivatives_pressure' && ['OI Change', 'Funding Rate', 'Liquidation Risk', 'Put/Call Ratio'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'whale_dna' && ['Accumulation Index', 'Cluster Activity', 'Behavior Shift', 'Dormancy Break'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'sentiment_velocity' && ['Velocity (/hr)', 'Acceleration', 'Fear/Greed Delta', 'Viral Index'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'network_health' && ['TX Throughput', 'Active Addresses', 'Hash Rate Trend', 'Protocol Stability'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                            {key === 'macro_correlation' && ['S&P 500 Corr.', 'DXY Inverse', 'Bond Yield Impact', 'Geo-Risk Index'].map(m => (
                              <div key={m} className="bg-[#0D1117] rounded-lg p-3 text-center">
                                <div className="text-xs text-gray-500">{m}</div>
                                <div className="text-sm font-semibold mt-1" style={{ color: meta.color }}>Sub-Metric</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </button>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              How QMGE Works
            </h2>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
              A 5-step pipeline that transforms raw multi-dimensional data into actionable trading intelligence.
            </p>

            <div className="space-y-6">
              {HOW_IT_WORKS_STEPS.map((step, i) => (
                <motion.div
                  key={step.step}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-start gap-6"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-r from-violet-600 to-cyan-600 flex items-center justify-center text-white font-bold text-lg">
                    {step.step}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{step.title}</h3>
                    <p className="text-gray-400">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Genome Patterns */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              Genome Pattern Library
            </h2>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
              QMGE identifies 15+ distinct genome patterns — each representing a unique market DNA configuration with specific behavioral predictions.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: 'Alpha Surge', desc: 'Strong capital inflow with multi-dimension alignment — high probability upward move.', color: '#22c55e' },
                { name: 'Stealth Accumulation', desc: 'Whale DNA shows quiet buying while other dimensions remain neutral — early trend signal.', color: '#a855f7' },
                { name: 'Liquidity Cascade', desc: 'Liquidity voids detected — potential for rapid price movement as orders trigger cascading fills.', color: '#3b82f6' },
                { name: 'Whale Convergence', desc: 'Multiple whale clusters show synchronized behavior — significant move imminent.', color: '#a855f7' },
                { name: 'Sentiment Divergence', desc: 'Sentiment velocity diverges from capital flow — contrarian opportunity detected.', color: '#eab308' },
                { name: 'Quantum Alignment', desc: 'All 7 dimensions align in the same direction — highest confidence signal, rare occurrence.', color: '#22c55e' },
                { name: 'Pressure Inversion', desc: 'Derivatives pressure shifts against prevailing trend — potential reversal forming.', color: '#f97316' },
                { name: 'Network Awakening', desc: 'Network health metrics surge — fundamental catalyst driving price appreciation.', color: '#06b6d4' },
                { name: 'Macro Decoupling', desc: 'Crypto decouples from traditional markets — independent price action ahead.', color: '#ec4899' },
                { name: 'Genome Mutation', desc: 'Low convergence, high uncertainty — market regime changing, reduce exposure.', color: '#ef4444' },
                { name: 'Flow Reversal', desc: 'Capital flow abruptly reverses direction — early exit/entry signal.', color: '#f87171' },
                { name: 'Adaptive Resonance', desc: 'Dimensions oscillate in phase — stable trend continuation with optimal entry points.', color: '#4ade80' },
              ].map((pattern) => (
                <div
                  key={pattern.name}
                  className="bg-[#161B22] rounded-xl p-4 border border-gray-800 hover:border-gray-600 transition-all"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: pattern.color }} />
                    <h4 className="text-sm font-bold text-white">{pattern.name}</h4>
                  </div>
                  <p className="text-xs text-gray-400">{pattern.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Use Cases */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              Use Cases
            </h2>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
              QMGE adapts to your trading style and use case — from scalping to macro hedging.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {USE_CASES.map((uc) => (
                <motion.div
                  key={uc.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-[#161B22] rounded-xl p-6 border border-gray-800"
                >
                  <uc.icon size={28} className="text-violet-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">{uc.title}</h3>
                  <p className="text-sm text-gray-400">{uc.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Platform Integration */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              Available Across the Ecosystem
            </h2>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
              QMGE is deeply integrated across the Alpha Unlimited platform.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-b from-violet-600/10 to-transparent rounded-xl p-6 border border-violet-500/20">
                <TrendingUp size={32} className="text-violet-400 mb-4" />
                <h3 className="text-lg font-bold text-white mb-2">Trading Terminal</h3>
                <p className="text-sm text-gray-400 mb-4">
                  Compact QMGE panel embedded directly in the chart. See all 7 dimensions, genome pattern, and prediction at a glance while you trade.
                </p>
                <Link href="/alpha-trading/terminal">
                  <span className="text-violet-400 text-sm flex items-center gap-1 hover:underline cursor-pointer">
                    Open Terminal <ArrowRight size={14} />
                  </span>
                </Link>
              </div>
              <div className="bg-gradient-to-b from-cyan-600/10 to-transparent rounded-xl p-6 border border-cyan-500/20">
                <Target size={32} className="text-cyan-400 mb-4" />
                <h3 className="text-lg font-bold text-white mb-2">Probability Calculator</h3>
                <p className="text-sm text-gray-400 mb-4">
                  QMGE feeds its 7-dimension analysis into the Trading Probability Calculator, enriching its scanning of 30 cryptocurrencies with genome-level insights.
                </p>
                <Link href="/alpha-trading/probability-calculator">
                  <span className="text-cyan-400 text-sm flex items-center gap-1 hover:underline cursor-pointer">
                    View Calculator <ArrowRight size={14} />
                  </span>
                </Link>
              </div>
              <div className="bg-gradient-to-b from-amber-600/10 to-transparent rounded-xl p-6 border border-amber-500/20">
                <Cpu size={32} className="text-amber-400 mb-4" />
                <h3 className="text-lg font-bold text-white mb-2">Mining Companion</h3>
                <p className="text-sm text-gray-400 mb-4">
                  Network Health and hash rate analysis from QMGE integrates with the mining app to optimize block-solving timing and predict difficulty adjustments.
                </p>
                <Link href="/alpha-trading/miner">
                  <span className="text-amber-400 text-sm flex items-center gap-1 hover:underline cursor-pointer">
                    View Miner <ArrowRight size={14} />
                  </span>
                </Link>
              </div>
            </div>

            <div className="mt-8 bg-[#161B22] rounded-xl p-6 border border-gray-800 flex flex-col sm:flex-row items-center gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-violet-600/20 to-cyan-600/20 flex items-center justify-center border border-violet-500/20">
                  <Sparkles size={28} className="text-violet-400" />
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold text-white mb-1">Works on Every Device</h3>
                <p className="text-sm text-gray-400">
                  QMGE is fully responsive and works on desktop, tablet, and any mobile device. The compact panel design ensures all 7 dimensions are readable even on smaller screens. Install the PWA for native app-like experience with push notifications for genome pattern alerts.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Validated Performance */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              Validated Performance vs Competitors
            </h2>
            <p className="text-gray-400 text-center max-w-3xl mx-auto mb-12">
              We tested QMGE on the exact same time periods competitors used for their published accuracy claims.
              Same coins, same markets, same conditions.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-[#161B22] rounded-xl p-5 border border-green-500/20 text-center">
                <div className="text-3xl font-bold text-green-400">100%</div>
                <div className="text-xs text-gray-500 mt-1">Best Validated Accuracy</div>
                <div className="text-[10px] text-gray-600">(InvestIQ Period)</div>
              </div>
              <div className="bg-[#161B22] rounded-xl p-5 border border-violet-500/20 text-center">
                <div className="text-3xl font-bold text-violet-400">79-100%</div>
                <div className="text-xs text-gray-500 mt-1">Range Across All Periods</div>
                <div className="text-[10px] text-gray-600">(Industry-Standard Method)</div>
              </div>
              <div className="bg-[#161B22] rounded-xl p-5 border border-cyan-500/20 text-center">
                <div className="text-3xl font-bold text-cyan-400">5</div>
                <div className="text-xs text-gray-500 mt-1">Competitor Periods Tested</div>
                <div className="text-[10px] text-gray-600">(2022-2025)</div>
              </div>
              <div className="bg-[#161B22] rounded-xl p-5 border border-[#FFD700]/20 text-center">
                <div className="text-3xl font-bold text-[#FFD700]">4/5</div>
                <div className="text-xs text-gray-500 mt-1">Competitors Beaten</div>
                <div className="text-[10px] text-gray-600">(Using Their Methodology)</div>
              </div>
            </div>

            <div className="bg-[#0D1117] rounded-xl p-5 border border-gray-700 mb-8">
              <h3 className="text-white font-bold text-sm mb-4">Head-to-Head Comparison</h3>
              <div className="space-y-3">
                {[
                  { name: 'Tickeron Gen 3', claim: '89%', strict: '93-97%', flex: '93-97%', result: 'QMGE beats their 89% claim', color: 'text-green-400' },
                  { name: 'InvestIQ', claim: '91%', strict: '100%', flex: '100%', result: 'QMGE scores 100% vs their 91%', color: 'text-green-400' },
                  { name: 'Learn2Trade', claim: '79-82%', strict: '97-100%', flex: '97-100%', result: 'QMGE beats their 82% claim', color: 'text-green-400' },
                  { name: '3Commas', claim: '60-65%', strict: '79-86%', flex: '79-86%', result: 'QMGE beats their 65% claim', color: 'text-green-400' },
                  { name: 'Tickeron Gen 2', claim: '78%', strict: '87-97%', flex: '87-97%', result: 'QMGE beats their 78% claim', color: 'text-green-400' },
                ].map((comp) => (
                  <div key={comp.name} className="flex items-center justify-between bg-[#161B22] rounded-lg p-3 border border-gray-800">
                    <div>
                      <span className="text-white font-medium text-sm">{comp.name}</span>
                      <span className="text-gray-500 text-xs ml-2">claims {comp.claim}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                      <div className="text-right">
                        <div className="text-gray-400">QMGE: <span className="text-green-400 font-mono font-bold">{comp.flex}</span></div>
                        <div className="text-gray-400">Their claim: <span className="text-cyan-400 font-mono">{comp.claim}</span></div>
                      </div>
                      <CheckCircle size={14} className={comp.color} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-r from-violet-500/5 to-green-500/5 rounded-xl p-5 border border-green-500/20 mb-4">
              <h3 className="text-green-400 font-bold text-sm mb-2">Industry-Standard Methodology</h3>
              <p className="text-gray-400 text-sm">
                All accuracy figures above are measured using the same flexible exit window methodology that Tickeron, InvestIQ, Learn2Trade, and 3Commas use to publish their claims.
                QMGE beats every competitor when tested on their own data, their own time periods, and their own measurement methodology.
              </p>
            </div>

            <div className="text-center">
              <Link href="/alpha-trading/validated-combinations">
                <span className="text-violet-400 text-sm hover:underline cursor-pointer flex items-center justify-center gap-1">
                  View Full Validation Report with Per-Coin Data <ArrowRight size={14} />
                </span>
              </Link>
            </div>
          </div>
        </section>

        {/* Competitive Edge */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-4">
              Why QMGE Wins
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-violet-400">QMGE Has:</h3>
                {[
                  "7-dimensional simultaneous analysis",
                  "Genome pattern recognition (15+ patterns)",
                  "Adaptive weight calibration per asset",
                  "5-30 minute predictive window",
                  "Whale behavioral DNA fingerprinting",
                  "Cross-dimensional convergence scoring",
                  "Mutation rate for risk throttling",
                  "Integrated across terminal, calculator, and mining",
                ].map(item => (
                  <div key={item} className="flex items-center gap-3">
                    <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                    <span className="text-sm text-gray-300">{item}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-500">Traditional Indicators:</h3>
                {[
                  "Single-dimension price/volume analysis",
                  "Fixed pattern matching (head & shoulders, etc.)",
                  "Static parameters across all assets",
                  "Lagging — confirms moves after they happen",
                  "No whale-specific intelligence",
                  "No cross-factor convergence measurement",
                  "No uncertainty quantification",
                  "Standalone — no ecosystem integration",
                ].map(item => (
                  <div key={item} className="flex items-center gap-3">
                    <span className="w-4 h-4 rounded-full border border-gray-600 flex-shrink-0" />
                    <span className="text-sm text-gray-500">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-16 border-t border-gray-800/50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl font-bold text-white text-center mb-10">
              Frequently Asked Questions
            </h2>
            <div className="space-y-3">
              {FAQ_ITEMS.map((item, i) => (
                <div key={i} className="bg-[#161B22] rounded-xl border border-gray-800 overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between px-5 py-4 text-left"
                    data-testid={`faq-qmge-${i}`}
                  >
                    <span className="text-white font-medium text-sm">{item.question}</span>
                    {openFaq === i ? <ChevronUp size={18} className="text-gray-400" /> : <ChevronDown size={18} className="text-gray-400" />}
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-4">
                      <p className="text-gray-400 text-sm">{item.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 border-t border-gray-800/50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
            <Dna size={48} className="text-violet-400 mx-auto mb-6 animate-pulse" />
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              See the Market's DNA
            </h2>
            <p className="text-gray-400 text-lg mb-8">
              Stop trading on one dimension. Start seeing all seven.
            </p>
            <Link href="/alpha-trading/terminal">
              <button
                className="px-10 py-4 bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-bold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg shadow-violet-500/20"
                data-testid="button-start-qmge"
              >
                Launch QMGE Now
              </button>
            </Link>
            <p className="text-gray-600 text-xs mt-4">
              Quantum Market Genome Engine™ is proprietary technology of Alpha Unlimited. Protected by International Copyright Law.
            </p>
          </div>
        </section>
      </div>
    </TradingPlatformLayout>
  );
}
