import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Button } from "@/components/ui/button";
import {
  Download, Smartphone, Apple, Chrome, Share, Plus, MoreVertical,
  Dna, Zap, Shield, Check, Layers, Globe, Activity, Cpu,
  DollarSign, Droplets, Flame, Fingerprint, Gauge, Monitor,
  Target, Clock, Eye, BarChart3, Bell, Search, Server,
  LineChart, Layout, ArrowRight, Lock, Signal, Battery, RefreshCw,
  Wifi, Key, Settings, ShoppingCart, ExternalLink
} from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const QMGE_FEATURES = [
  { icon: Dna, title: "7-Dimension Genome Mapping", description: "Analyze Capital Flow, Liquidity, Derivatives, Whale DNA, Sentiment, Network Health & Macro Correlation simultaneously", color: "text-purple-400" },
  { icon: Target, title: "Up to 100% Validated Accuracy", description: "Tested across 5 competitor time periods (2022-2025) using their same methodology. Beats Tickeron (89%), InvestIQ (91%), Learn2Trade (82%), and 3Commas (65%) on their own data", color: "text-green-400" },
  { icon: Clock, title: "5-30 Min Predictions", description: "Actionable short-term predictions with confidence scores and risk levels for every output", color: "text-blue-400" },
  { icon: Activity, title: "Live Convergence Index", description: "Monitor convergence scoring, mutation rate, and dominant dimension with continuous updates", color: "text-cyan-400" },
  { icon: Cpu, title: "Adaptive Weight Calibration", description: "Engine auto-adjusts weights per asset and market regime — BTC analysis differs from altcoin analysis", color: "text-yellow-400" },
  { icon: Globe, title: "21+ Exchange Connections", description: "Connect to Binance, Coinbase, Kraken, Bybit, OKX, KuCoin, and many more exchanges", color: "text-orange-400" },
];

const DIMENSIONS = [
  { name: "Capital Flow Dynamics", icon: DollarSign, color: "#22c55e", description: "Track institutional and retail money flows" },
  { name: "Liquidity Topology", icon: Droplets, color: "#3b82f6", description: "Map order book depth and liquidity pools" },
  { name: "Derivatives Pressure", icon: Flame, color: "#f97316", description: "Analyze futures/options market pressure" },
  { name: "Whale Behavioral DNA", icon: Fingerprint, color: "#a855f7", description: "Fingerprint large holder behavior patterns" },
  { name: "Sentiment Velocity", icon: Gauge, color: "#eab308", description: "Measure rate of sentiment change across markets" },
  { name: "Network Health", icon: Activity, color: "#06b6d4", description: "Monitor blockchain network metrics" },
  { name: "Macro Correlation", icon: Globe, color: "#ec4899", description: "Cross-market correlation with traditional finance" },
];

const INTERFACE_PANELS = [
  { name: "Genome Map", icon: Dna, description: "Live 7-dimension radar with real-time scores" },
  { name: "Pattern Scanner", icon: Search, description: "Detects 15+ genome patterns automatically" },
  { name: "Signal Dashboard", icon: BarChart3, description: "Buy/Sell/Hold signals with confidence %" },
  { name: "Convergence Monitor", icon: Activity, description: "Track convergence index and mutation rate" },
  { name: "Multi-Pair Grid", icon: Layout, description: "Analyze multiple pairs side by side" },
  { name: "Alert Center", icon: Bell, description: "Custom alerts on pattern detection or score thresholds" },
  { name: "Exchange Feed", icon: Server, description: "Live order book and trade data from your exchange" },
  { name: "Performance Log", icon: LineChart, description: "Historical accuracy of QMGE predictions" },
];

export default function GetQMGEApp() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [activeTab, setActiveTab] = useState<'install' | 'features' | 'dimensions'>('install');

  useEffect(() => {
    document.title = "Get QMGE App - Quantum Market Genome Engine™";
  }, []);

  useEffect(() => {
    const checkInstalled = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isIOSStandalone = (window.navigator as any).standalone === true;
      setIsInstalled(isStandalone || isIOSStandalone);
    };
    checkInstalled();
    setIsIOS(/iPad|iPhone|iPod/.test(navigator.userAgent));
    setIsAndroid(/Android/.test(navigator.userAgent));

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setIsInstalled(true);
    setDeferredPrompt(null);
  };

  return (
    <TradingPlatformLayout>
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">

            <div className="text-center mb-10">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br from-purple-500/20 to-cyan-500/20 border border-purple-500/30 mb-6"
              >
                <Dna className="w-12 h-12 text-purple-400" />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-5xl font-display font-bold mb-4"
              >
                Get the <span className="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">QMGE</span> App
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-xl text-gray-400 max-w-2xl mx-auto"
              >
                Install the Quantum Market Genome Engine™ on your device. 
                7-dimensional market analysis at your fingertips, anywhere, anytime.
              </motion.p>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="flex items-center justify-center gap-3 mt-4"
              >
                <span className="px-3 py-1 bg-purple-500/10 border border-purple-500/30 rounded-full text-sm text-purple-400">7 Dimensions</span>
                <span className="px-3 py-1 bg-green-500/10 border border-green-500/30 rounded-full text-sm text-green-400">Up to 100% Validated Accuracy</span>
                <span className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded-full text-sm text-cyan-400">Beats 4 Competitors</span>
              </motion.div>
            </div>

            <div className="flex justify-center gap-2 mb-8">
              {[
                { key: 'install' as const, icon: Download, label: 'Install App' },
                { key: 'features' as const, icon: Layers, label: 'Features' },
                { key: 'dimensions' as const, icon: Dna, label: '7 Dimensions' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-6 py-3 rounded-xl font-medium transition-all ${
                    activeTab === tab.key 
                      ? 'bg-gradient-to-r from-purple-500 to-cyan-500 text-white' 
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                  data-testid={`tab-qmge-${tab.key}`}
                >
                  <tab.icon className="w-4 h-4 inline mr-2" />
                  {tab.label}
                </button>
              ))}
            </div>

            {activeTab === 'install' && (
              <>
                {isInstalled ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-green-500/10 border border-green-500/30 rounded-2xl p-8 text-center mb-12"
                  >
                    <div className="w-16 h-16 mx-auto mb-4 bg-green-500/20 rounded-full flex items-center justify-center">
                      <Check className="w-8 h-8 text-green-400" />
                    </div>
                    <h2 className="text-2xl font-bold text-green-400 mb-2" data-testid="text-qmge-installed">App Already Installed!</h2>
                    <p className="text-gray-400 mb-4">
                      QMGE is installed on your device. Open it from your home screen to start analyzing markets.
                    </p>
                    <Link href="/qmge-standalone">
                      <Button className="bg-purple-500 hover:bg-purple-600 text-white" data-testid="link-qmge-standalone">
                        <Key className="w-4 h-4 mr-2" /> Manage License
                      </Button>
                    </Link>
                  </motion.div>
                ) : deferredPrompt ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-2xl p-8 text-center mb-12"
                  >
                    <h2 className="text-2xl font-bold mb-4">Install QMGE Now</h2>
                    <p className="text-gray-400 mb-6">
                      Add the Quantum Market Genome Engine™ to your device for instant access to 7-dimensional market analysis.
                    </p>
                    <Button 
                      onClick={handleInstall}
                      className="bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600 text-white font-bold px-8 py-4 text-lg"
                      data-testid="button-install-qmge"
                    >
                      <Download className="mr-2" /> Install QMGE App
                    </Button>
                  </motion.div>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="grid md:grid-cols-2 gap-8 mb-12"
                  >
                    {isIOS ? (
                      <div className="bg-gray-900/50 border border-gray-700 rounded-2xl p-6 md:col-span-2 max-w-lg mx-auto w-full">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                            <Apple className="w-6 h-6" />
                          </div>
                          <div>
                            <h3 className="font-bold text-lg">iPhone / iPad</h3>
                            <p className="text-sm text-gray-400">Install via Safari</p>
                          </div>
                        </div>
                        <ol className="space-y-4 text-gray-300">
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">1</span>
                            <span>Open this page in <strong>Safari</strong> browser</span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">2</span>
                            <span className="flex items-center gap-2">
                              Tap the <Share className="w-5 h-5 text-blue-400" /> Share button at the bottom
                            </span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">3</span>
                            <span className="flex items-center gap-2">
                              Scroll down and tap <Plus className="w-5 h-5" /> <strong>"Add to Home Screen"</strong>
                            </span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">4</span>
                            <span>Tap <strong>"Add"</strong> to confirm</span>
                          </li>
                        </ol>
                      </div>
                    ) : isAndroid ? (
                      <div className="bg-gray-900/50 border border-gray-700 rounded-2xl p-6 md:col-span-2 max-w-lg mx-auto w-full">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                            <Chrome className="w-6 h-6 text-green-400" />
                          </div>
                          <div>
                            <h3 className="font-bold text-lg">Android</h3>
                            <p className="text-sm text-gray-400">Install via Chrome</p>
                          </div>
                        </div>
                        <ol className="space-y-4 text-gray-300">
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">1</span>
                            <span>Open this page in <strong>Chrome</strong> browser</span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">2</span>
                            <span className="flex items-center gap-2">
                              Tap the <MoreVertical className="w-5 h-5" /> menu (three dots) in the top right
                            </span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">3</span>
                            <span>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong></span>
                          </li>
                          <li className="flex items-start gap-3">
                            <span className="w-6 h-6 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-sm font-bold shrink-0">4</span>
                            <span>Tap <strong>"Install"</strong> to confirm</span>
                          </li>
                        </ol>
                      </div>
                    ) : (
                      <>
                        <div className="bg-gray-900/50 border border-gray-700 rounded-2xl p-6">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                              <Apple className="w-6 h-6" />
                            </div>
                            <div>
                              <h3 className="font-bold text-lg">iPhone / iPad</h3>
                              <p className="text-sm text-gray-400">Install via Safari</p>
                            </div>
                          </div>
                          <ol className="space-y-3 text-gray-300 text-sm">
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">1</span>
                              <span>Open in Safari</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">2</span>
                              <span>Tap Share button</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">3</span>
                              <span>Add to Home Screen</span>
                            </li>
                          </ol>
                        </div>

                        <div className="bg-gray-900/50 border border-gray-700 rounded-2xl p-6">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                              <Chrome className="w-6 h-6 text-green-400" />
                            </div>
                            <div>
                              <h3 className="font-bold text-lg">Android / Desktop</h3>
                              <p className="text-sm text-gray-400">Install via Chrome</p>
                            </div>
                          </div>
                          <ol className="space-y-3 text-gray-300 text-sm">
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">1</span>
                              <span>Open in Chrome</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">2</span>
                              <span>Tap menu (&#x22EE;) or click install icon in address bar</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="w-5 h-5 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0">3</span>
                              <span>Install app</span>
                            </li>
                          </ol>
                        </div>
                      </>
                    )}
                  </motion.div>
                )}

                <div className="mb-12">
                  <h2 className="text-2xl font-bold text-center mb-8">Why Install the QMGE App?</h2>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { icon: Zap, title: 'Instant Access', description: 'Launch QMGE from your home screen instantly — no browser needed' },
                      { icon: Wifi, title: 'Offline Cached Data', description: 'View cached genome maps and analysis results even without connection' },
                      { icon: Shield, title: 'Secure & Private', description: 'No app store required — install directly with full security' },
                      { icon: Bell, title: 'Pattern Alerts', description: 'Get notified when genome patterns or convergence thresholds trigger' },
                    ].map((feature, i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="bg-gray-900/50 border border-gray-700 rounded-xl p-4 text-center hover:border-purple-500/50 transition-colors"
                      >
                        <div className="w-12 h-12 mx-auto mb-3 bg-purple-500/10 rounded-xl flex items-center justify-center">
                          <feature.icon className="w-6 h-6 text-purple-400" />
                        </div>
                        <h3 className="font-bold mb-2">{feature.title}</h3>
                        <p className="text-sm text-gray-400">{feature.description}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/20 rounded-xl p-6 mb-8">
                  <h3 className="text-lg font-bold text-purple-400 mb-3 flex items-center gap-2">
                    <Smartphone className="w-5 h-5" /> How It Works
                  </h3>
                  <div className="grid md:grid-cols-4 gap-4">
                    {[
                      { step: 1, title: "Install the App", desc: "Add QMGE to your home screen from this page" },
                      { step: 2, title: "Sign In", desc: "Log in with your Alpha Unlimited account" },
                      { step: 3, title: "Connect Exchange", desc: "Add your exchange API keys (read-only)" },
                      { step: 4, title: "Analyze Markets", desc: "Start 7-dimensional genome analysis instantly" },
                    ].map((s) => (
                      <div key={s.step} className="flex items-start gap-3">
                        <span className="w-8 h-8 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center font-bold shrink-0">{s.step}</span>
                        <div>
                          <p className="font-medium text-white">{s.title}</p>
                          <p className="text-sm text-gray-400">{s.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'features' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {QMGE_FEATURES.map((feature, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-gray-900/50 border border-gray-700 rounded-xl p-5 hover:border-purple-500/30 transition-colors"
                      data-testid={`qmge-feature-${i}`}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                          <feature.icon className={`w-5 h-5 ${feature.color}`} />
                        </div>
                        <h3 className="font-bold text-sm">{feature.title}</h3>
                      </div>
                      <p className="text-sm text-gray-400">{feature.description}</p>
                    </motion.div>
                  ))}
                </div>

                <div className="bg-[#161B22] border border-white/10 rounded-xl p-8">
                  <h3 className="text-xl font-bold text-center mb-6">QMGE Interface Panels</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {INTERFACE_PANELS.map((panel, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="bg-gray-800/50 rounded-lg p-3 text-center hover:bg-gray-800 transition-colors"
                        data-testid={`qmge-panel-${i}`}
                      >
                        <panel.icon className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                        <p className="text-sm font-medium text-white">{panel.name}</p>
                        <p className="text-xs text-gray-500 mt-1">{panel.description}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#161B22] border border-white/10 rounded-xl p-8">
                  <h3 className="text-xl font-bold text-center mb-6">Mobile Advantages</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { icon: Monitor, label: 'Full Dashboard', desc: 'Complete genome map', color: 'text-purple-400' },
                      { icon: Battery, label: 'Battery Efficient', desc: 'Optimized rendering', color: 'text-yellow-400' },
                      { icon: Signal, label: 'Low Data Usage', desc: 'Works on cellular', color: 'text-blue-400' },
                      { icon: Clock, label: '24/7 Analysis', desc: 'Always scanning', color: 'text-green-400' },
                      { icon: RefreshCw, label: 'Auto Sync', desc: 'Real-time updates', color: 'text-cyan-400' },
                      { icon: Eye, label: 'Pattern Alerts', desc: 'Instant detection', color: 'text-orange-400' },
                      { icon: Lock, label: 'Encrypted', desc: 'Secure sessions', color: 'text-red-400' },
                      { icon: Zap, label: 'Instant Load', desc: 'Sub-second startup', color: 'text-purple-400' },
                    ].map((item, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="bg-gray-800/50 rounded-lg p-3 text-center hover:bg-gray-800 transition-colors"
                        data-testid={`qmge-advantage-${i}`}
                      >
                        <item.icon className={`w-6 h-6 ${item.color} mx-auto mb-2`} />
                        <p className="text-sm font-medium text-white">{item.label}</p>
                        <p className="text-xs text-gray-500">{item.desc}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'dimensions' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-gradient-to-br from-purple-500/10 via-blue-500/5 to-cyan-500/10 border border-purple-500/20 rounded-2xl p-8">
                  <h2 className="text-2xl font-bold text-center mb-2">The 7 Genome Dimensions</h2>
                  <p className="text-gray-400 text-center mb-8 max-w-2xl mx-auto">
                    QMGE simultaneously analyzes all 7 dimensions of market structure that traditional tools cannot see.
                  </p>

                  <div className="grid md:grid-cols-2 gap-4">
                    {DIMENSIONS.map((dim, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.08 }}
                        className="bg-[#161B22] border border-white/10 rounded-xl p-5 hover:border-purple-500/30 transition-colors"
                        data-testid={`qmge-dimension-${i}`}
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${dim.color}20` }}>
                            <dim.icon className="w-5 h-5" style={{ color: dim.color }} />
                          </div>
                          <div>
                            <h3 className="font-bold">{dim.name}</h3>
                            <div className="w-24 h-1.5 bg-gray-700 rounded-full mt-1">
                              <motion.div
                                className="h-full rounded-full"
                                style={{ backgroundColor: dim.color }}
                                initial={{ width: 0 }}
                                animate={{ width: `${60 + Math.random() * 35}%` }}
                                transition={{ delay: i * 0.1, duration: 1 }}
                              />
                            </div>
                          </div>
                        </div>
                        <p className="text-sm text-gray-400 ml-[52px]">{dim.description}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#161B22] border border-white/10 rounded-xl p-6">
                  <h3 className="text-lg font-bold mb-4 text-center">Genome Patterns Detected</h3>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {[
                      'Alpha Surge', 'Whale Convergence', 'Liquidity Cascade', 'Sentiment Flip',
                      'Derivatives Compression', 'Network Pulse', 'Macro Divergence', 'Capital Rotation',
                      'Momentum Genome', 'Volatility Expansion', 'Correlation Breakdown', 'Accumulation Phase',
                      'Distribution Signal', 'Smart Money Flow', 'Adaptive Resonance'
                    ].map((pattern, i) => (
                      <span
                        key={i}
                        className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-full text-sm text-gray-300 hover:border-purple-500/50 hover:text-purple-300 transition-colors cursor-default"
                        data-testid={`qmge-pattern-${i}`}
                      >
                        {pattern}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            <div className="grid md:grid-cols-2 gap-4 mt-8">
              <Link href="/qmge-standalone">
                <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 border border-purple-500/30 rounded-2xl p-6 hover:border-purple-400/50 transition-colors cursor-pointer" data-testid="card-qmge-standalone">
                  <div className="flex items-center gap-3 mb-3">
                    <ShoppingCart className="w-6 h-6 text-purple-400" />
                    <h3 className="text-lg font-bold">QMGE Standalone Software</h3>
                  </div>
                  <p className="text-gray-400 text-sm mb-3">
                    Get the full standalone QMGE software with licensing, exchange connections, and all 7 dimensions unlocked.
                  </p>
                  <div className="flex items-center text-purple-400 text-sm font-medium">
                    View Plans & Pricing <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </Link>

              <Link href="/get-app">
                <div className="bg-gradient-to-r from-primary/10 to-blue-500/10 border border-primary/30 rounded-2xl p-6 hover:border-primary/50 transition-colors cursor-pointer" data-testid="card-main-app">
                  <div className="flex items-center gap-3 mb-3">
                    <Smartphone className="w-6 h-6 text-primary" />
                    <h3 className="text-lg font-bold">Alpha Unlimited Trading App</h3>
                  </div>
                  <p className="text-gray-400 text-sm mb-3">
                    Install the full trading platform with all features — terminal, arbitrage, AI bots, portfolio, and more.
                  </p>
                  <div className="flex items-center text-primary text-sm font-medium">
                    Get the Full App <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </Link>
            </div>

          </div>
        </div>
      </main>
    </TradingPlatformLayout>
  );
}
