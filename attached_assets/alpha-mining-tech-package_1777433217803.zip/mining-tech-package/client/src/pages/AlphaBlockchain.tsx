import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Boxes, Cpu, Wallet, ArrowRightLeft, BarChart3, Shield, Clock,
  Hash, ChevronRight, Copy, Check, RefreshCw, Pickaxe, Send,
  Plus, Eye, EyeOff, AlertTriangle, TrendingUp, Database,
  Layers, Activity, Zap, Lock, Globe, Search, Network, HardDrive
} from 'lucide-react';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import aucLogo from '@/assets/images/auc-logo-brand1.png';

interface BlockchainStats {
  coinName: string;
  ticker: string;
  chainHeight: number;
  totalBlocks: number;
  totalTransactions: number;
  totalSupply: number;
  maxSupply: number;
  currentDifficulty: number;
  currentTarget: string;
  currentReward: number;
  mempoolSize: number;
  uniqueAddresses: number;
  averageBlockTime: number;
  latestBlockHash: string;
  latestBlockTime: number;
  genesisHash: string;
  isValid: boolean;
  founderAddress: string;
  founderBalance: number;
  founderAllocation: number;
  burnAddress: string;
  totalBurned: number;
  circulatingSupply: number;
}

interface BlockSummary {
  index: number;
  hash: string;
  previousHash: string;
  timestamp: number;
  difficulty: number;
  nonce: number;
  merkleRoot: string;
  transactionCount: number;
  size: number;
}

interface WalletInfo {
  address: string;
  publicKey: string;
  privateKey: string;
}

interface MiningResult {
  message: string;
  block: BlockSummary;
  reward: number;
  ticker: string;
}

type TabType = 'overview' | 'blocks' | 'mine' | 'wallet' | 'send' | 'search' | 'network' | 'pool';

export default function AlphaBlockchain() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [stats, setStats] = useState<BlockchainStats | null>(null);
  const [blocks, setBlocks] = useState<BlockSummary[]>([]);
  const [wallet, setWallet] = useState<WalletInfo | null>(null);
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [showPrivateKey, setShowPrivateKey] = useState(false);
  const [mining, setMining] = useState(false);
  const [miningResult, setMiningResult] = useState<MiningResult | null>(null);
  const [sendTo, setSendTo] = useState('');
  const [sendAmount, setSendAmount] = useState('');
  const [sendStatus, setSendStatus] = useState('');
  const [copied, setCopied] = useState('');
  const [loading, setLoading] = useState(true);
  const [minedBlocks, setMinedBlocks] = useState<MiningResult[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<any>(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [networkStats, setNetworkStats] = useState<any>(null);
  const [poolStats, setPoolStats] = useState<any>(null);
  const [richList, setRichList] = useState<any>(null);

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/blockchain/stats');
      if (res.ok) setStats(await res.json());
    } catch {}
  }, []);

  const fetchBlocks = useCallback(async () => {
    try {
      const res = await fetch('/api/blockchain/blocks?count=20');
      if (res.ok) setBlocks(await res.json());
    } catch {}
  }, []);

  const fetchBalance = useCallback(async () => {
    if (!wallet) return;
    try {
      const res = await fetch(`/api/blockchain/address/${wallet.address}`);
      if (res.ok) {
        const data = await res.json();
        setWalletBalance(data.balance);
      }
    } catch {}
  }, [wallet]);

  useEffect(() => {
    fetchStats().then(() => setLoading(false));
    fetchBlocks();
  }, []);

  useEffect(() => {
    if (wallet) fetchBalance();
  }, [wallet, miningResult]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchStats();
      fetchBlocks();
      if (wallet) fetchBalance();
    }, 10000);
    return () => clearInterval(interval);
  }, [wallet]);

  const createWallet = async () => {
    try {
      const res = await fetch('/api/blockchain/wallet/create', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setWallet(data);
        setActiveTab('wallet');
      }
    } catch {}
  };

  const mineBlock = async () => {
    if (!wallet || mining) return;
    setMining(true);
    setMiningResult(null);
    try {
      const res = await fetch('/api/blockchain/mine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ minerAddress: wallet.address }),
      });
      if (res.ok) {
        const result = await res.json();
        setMiningResult(result);
        setMinedBlocks(prev => [result, ...prev]);
        fetchStats();
        fetchBlocks();
        fetchBalance();
      }
    } catch {} finally {
      setMining(false);
    }
  };

  const sendTransaction = async () => {
    if (!wallet || !sendTo || !sendAmount) return;
    setSendStatus('sending');
    try {
      const res = await fetch('/api/blockchain/transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromAddress: wallet.address,
          toAddress: sendTo,
          amount: parseFloat(sendAmount),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setSendStatus('success');
        setSendTo('');
        setSendAmount('');
        fetchStats();
        setTimeout(() => setSendStatus(''), 3000);
      } else {
        setSendStatus(data.error || 'Failed');
        setTimeout(() => setSendStatus(''), 5000);
      }
    } catch {
      setSendStatus('Network error');
      setTimeout(() => setSendStatus(''), 5000);
    }
  };

  const searchBlockchain = async () => {
    if (!searchQuery.trim()) return;
    setSearchLoading(true);
    setSearchResult(null);
    try {
      const res = await fetch(`/api/blockchain/explorer/search?q=${encodeURIComponent(searchQuery.trim())}`);
      if (res.ok) setSearchResult(await res.json());
    } catch {} finally { setSearchLoading(false); }
  };

  const fetchNetworkStats = useCallback(async () => {
    try {
      const res = await fetch('/api/blockchain/network');
      if (res.ok) setNetworkStats(await res.json());
    } catch {}
  }, []);

  const fetchPoolStats = useCallback(async () => {
    try {
      const res = await fetch('/api/blockchain/mining/pool');
      if (res.ok) setPoolStats(await res.json());
    } catch {}
  }, []);

  const fetchRichList = useCallback(async () => {
    try {
      const res = await fetch('/api/blockchain/explorer/richlist');
      if (res.ok) setRichList(await res.json());
    } catch {}
  }, []);

  useEffect(() => {
    if (activeTab === 'network') fetchNetworkStats();
    if (activeTab === 'pool') fetchPoolStats();
    if (activeTab === 'search' && !richList) fetchRichList();
  }, [activeTab]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(''), 2000);
  };

  const formatHash = (hash: string) => `${hash.substring(0, 8)}...${hash.substring(hash.length - 8)}`;
  const formatTime = (ts: number) => new Date(ts).toLocaleString();

  if (loading) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen flex items-center justify-center bg-[#0a0a0f]">
          <div className="flex flex-col items-center gap-4">
            <Boxes className="w-12 h-12 text-amber-500 animate-pulse" />
            <span className="text-gray-400">Initializing Alpha Blockchain...</span>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  const tabs: { id: TabType; label: string; icon: any }[] = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'blocks', label: 'Blocks', icon: Boxes },
    { id: 'search', label: 'Explorer', icon: Search },
    { id: 'network', label: 'Network', icon: Network },
    { id: 'pool', label: 'Mining Pool', icon: HardDrive },
    { id: 'mine', label: 'Mine', icon: Pickaxe },
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'send', label: 'Send', icon: Send },
  ];

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen bg-[#0a0a0f] text-white p-4 md:p-6" data-testid="blockchain-page">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-2">
              <img src={aucLogo} alt="Alpha Unlimited Coin" className="w-12 h-12 rounded-full object-cover" />
              <div>
                <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                  Alpha Unlimited Coin
                </h1>
                <p className="text-gray-500 text-sm">AUC Blockchain Explorer & Mining Dashboard</p>
              </div>
            </div>

            {stats && (
              <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${stats.isValid ? 'bg-green-500' : 'bg-red-500'}`} />
                  Chain {stats.isValid ? 'Valid' : 'Invalid'}
                </span>
                <span>Height: {stats.chainHeight}</span>
                <span>Difficulty: {stats.currentDifficulty}</span>
                {wallet && <span className="text-amber-400">Balance: {walletBalance.toFixed(4)} AUC</span>}
              </div>
            )}
          </motion.div>

          {/* Tabs */}
          <div className="flex gap-1 mb-6 bg-[#111118] rounded-lg p-1 overflow-x-auto" data-testid="blockchain-tabs">
            {tabs.map(tab => (
              <button
                key={tab.id}
                data-testid={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                }`}
              >
                <tab.icon size={16} />
                {tab.label}
              </button>
            ))}
            {!wallet && (
              <button
                data-testid="btn-create-wallet"
                onClick={createWallet}
                className="ml-auto flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30 transition-all whitespace-nowrap"
              >
                <Plus size={16} />
                Create Wallet
              </button>
            )}
          </div>

          {/* Overview Tab */}
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && stats && (
              <motion.div key="overview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {/* Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                  {[
                    { label: 'Chain Height', value: stats.chainHeight.toLocaleString(), icon: Layers, color: 'from-blue-500 to-blue-700' },
                    { label: 'Total Supply', value: `${stats.totalSupply.toLocaleString()} AUC`, icon: Database, color: 'from-amber-500 to-orange-600' },
                    { label: 'Max Supply', value: `${stats.maxSupply.toLocaleString()} AUC`, icon: Lock, color: 'from-purple-500 to-purple-700' },
                    { label: 'Block Reward', value: `${stats.currentReward} AUC`, icon: Zap, color: 'from-green-500 to-green-700' },
                    { label: 'Difficulty', value: stats.currentDifficulty.toString(), icon: Activity, color: 'from-red-500 to-red-700' },
                    { label: 'Transactions', value: stats.totalTransactions.toLocaleString(), icon: ArrowRightLeft, color: 'from-cyan-500 to-cyan-700' },
                    { label: 'Addresses', value: stats.uniqueAddresses.toLocaleString(), icon: Globe, color: 'from-pink-500 to-pink-700' },
                    { label: 'Mempool', value: stats.mempoolSize.toString(), icon: Clock, color: 'from-yellow-500 to-yellow-700' },
                  ].map((stat, i) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#111118] border border-gray-800 rounded-lg p-4"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-8 h-8 rounded-md bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                          <stat.icon size={14} className="text-white" />
                        </div>
                        <span className="text-xs text-gray-500">{stat.label}</span>
                      </div>
                      <p className="text-lg font-bold text-white" data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, '-')}`}>{stat.value}</p>
                    </motion.div>
                  ))}
                </div>

                {/* Supply Progress */}
                <div className="bg-[#111118] border border-gray-800 rounded-lg p-5 mb-6">
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Supply Progress</h3>
                  <div className="w-full bg-gray-800 rounded-full h-3 mb-2">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-3 rounded-full transition-all"
                      style={{ width: `${Math.min((stats.totalSupply / stats.maxSupply) * 100, 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>{stats.totalSupply.toLocaleString()} AUC mined</span>
                    <span>{((stats.totalSupply / stats.maxSupply) * 100).toFixed(6)}%</span>
                    <span>{stats.maxSupply.toLocaleString()} AUC max</span>
                  </div>
                </div>

                {/* Chain Info */}
                <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Chain Information</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Coin Name</span>
                      <span className="text-amber-400 font-medium">{stats.coinName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Ticker</span>
                      <span>{stats.ticker}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Consensus</span>
                      <span>Proof of Work (SHA-256 Double Hash)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Signing Algorithm</span>
                      <span>ECDSA secp256k1</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Halving Interval</span>
                      <span>Every 210,000 blocks</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">Genesis Hash</span>
                      <button onClick={() => copyToClipboard(stats.genesisHash, 'genesis')} className="flex items-center gap-1 text-xs hover:text-amber-400 transition-colors">
                        <span className="font-mono">{formatHash(stats.genesisHash)}</span>
                        {copied === 'genesis' ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
                      </button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">Latest Block Hash</span>
                      <button onClick={() => copyToClipboard(stats.latestBlockHash, 'latest')} className="flex items-center gap-1 text-xs hover:text-amber-400 transition-colors">
                        <span className="font-mono">{formatHash(stats.latestBlockHash)}</span>
                        {copied === 'latest' ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
                      </button>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Chain Valid</span>
                      <span className={stats.isValid ? 'text-green-400' : 'text-red-400'}>
                        {stats.isValid ? 'Yes' : 'No'}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Blocks Tab */}
            {activeTab === 'blocks' && (
              <motion.div key="blocks" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold">Recent Blocks</h2>
                  <button onClick={() => { fetchBlocks(); fetchStats(); }} className="flex items-center gap-1 text-xs text-gray-500 hover:text-amber-400">
                    <RefreshCw size={12} /> Refresh
                  </button>
                </div>
                <div className="space-y-2">
                  {blocks.map((block, i) => (
                    <motion.div
                      key={block.index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="bg-[#111118] border border-gray-800 rounded-lg p-4 hover:border-amber-500/30 transition-all"
                      data-testid={`block-${block.index}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
                            <Boxes size={18} className="text-amber-400" />
                          </div>
                          <div>
                            <span className="text-amber-400 font-bold">Block #{block.index}</span>
                            <p className="text-xs text-gray-500 font-mono">{formatHash(block.hash)}</p>
                          </div>
                        </div>
                        <div className="text-right text-xs text-gray-500">
                          <p>{formatTime(block.timestamp)}</p>
                          <p>{block.transactionCount} tx{block.transactionCount !== 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      <div className="flex gap-4 text-xs text-gray-500 mt-2 pt-2 border-t border-gray-800/50">
                        <span>Nonce: {block.nonce.toLocaleString()}</span>
                        <span>Difficulty: {block.difficulty}</span>
                        <span>Size: {block.size} bytes</span>
                      </div>
                    </motion.div>
                  ))}
                  {blocks.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <Boxes size={48} className="mx-auto mb-3 opacity-30" />
                      <p>No blocks yet. Start mining to create new blocks!</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Mine Tab */}
            {activeTab === 'mine' && (
              <motion.div key="mine" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl mx-auto">
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-6 mb-6">
                    <div className="text-center mb-6">
                      <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-3">
                        <Pickaxe size={32} className="text-white" />
                      </div>
                      <h2 className="text-xl font-bold mb-1">Mine AUC Blocks</h2>
                      <p className="text-gray-500 text-sm">Solve Proof of Work puzzles to earn {stats?.currentReward || 50} AUC per block</p>
                    </div>

                    {!wallet ? (
                      <div className="text-center py-6">
                        <AlertTriangle size={24} className="mx-auto mb-2 text-yellow-500" />
                        <p className="text-gray-400 mb-3">Create a wallet first to start mining</p>
                        <button
                          data-testid="btn-mine-create-wallet"
                          onClick={createWallet}
                          className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-black font-bold rounded-lg transition-colors"
                        >
                          Create Wallet
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="bg-[#0a0a0f] rounded-lg p-4 mb-4 text-sm">
                          <div className="flex justify-between mb-1">
                            <span className="text-gray-500">Mining to</span>
                            <span className="font-mono text-xs text-amber-400">{formatHash(wallet.address)}</span>
                          </div>
                          <div className="flex justify-between mb-1">
                            <span className="text-gray-500">Current Balance</span>
                            <span className="font-bold">{walletBalance.toFixed(4)} AUC</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Block Reward</span>
                            <span className="text-green-400">{stats?.currentReward || 50} AUC</span>
                          </div>
                        </div>

                        <button
                          data-testid="btn-mine-block"
                          onClick={mineBlock}
                          disabled={mining}
                          className={`w-full py-4 rounded-lg font-bold text-lg transition-all ${
                            mining
                              ? 'bg-amber-500/20 text-amber-400 cursor-not-allowed animate-pulse'
                              : 'bg-gradient-to-r from-amber-500 to-orange-600 text-black hover:from-amber-400 hover:to-orange-500'
                          }`}
                        >
                          {mining ? (
                            <span className="flex items-center justify-center gap-2">
                              <Cpu size={20} className="animate-spin" />
                              Mining... Solving Proof of Work
                            </span>
                          ) : (
                            <span className="flex items-center justify-center gap-2">
                              <Pickaxe size={20} />
                              Mine New Block
                            </span>
                          )}
                        </button>
                      </>
                    )}
                  </div>

                  {/* Mining Results */}
                  {miningResult && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-green-500/10 border border-green-500/30 rounded-lg p-5 mb-6"
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <Check size={20} className="text-green-400" />
                        <h3 className="font-bold text-green-400">Block Mined Successfully!</h3>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Block</span>
                          <span className="text-amber-400">#{miningResult.block.index}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Hash</span>
                          <span className="font-mono text-xs">{formatHash(miningResult.block.hash)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Nonce</span>
                          <span>{miningResult.block.nonce.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Reward</span>
                          <span className="text-green-400 font-bold">+{miningResult.reward} AUC</span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Mining History */}
                  {minedBlocks.length > 1 && (
                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-4">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Mining History</h3>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {minedBlocks.slice(1).map((mb, i) => (
                          <div key={i} className="flex items-center justify-between text-xs bg-[#0a0a0f] rounded p-2">
                            <span className="text-amber-400">Block #{mb.block.index}</span>
                            <span className="font-mono text-gray-500">{formatHash(mb.block.hash)}</span>
                            <span className="text-green-400">+{mb.reward} AUC</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Wallet Tab */}
            {activeTab === 'wallet' && (
              <motion.div key="wallet" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl mx-auto">
                  {!wallet ? (
                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-8 text-center">
                      <Wallet size={48} className="mx-auto mb-4 text-amber-500 opacity-50" />
                      <h2 className="text-xl font-bold mb-2">No Wallet Created</h2>
                      <p className="text-gray-500 mb-6">Create a new AUC wallet to start mining and transacting on the Alpha Unlimited blockchain</p>
                      <button
                        data-testid="btn-wallet-create"
                        onClick={createWallet}
                        className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-black font-bold rounded-lg hover:from-amber-400 hover:to-orange-500 transition-all"
                      >
                        Generate New Wallet
                      </button>
                    </div>
                  ) : (
                    <>
                      {/* Balance Card */}
                      <div className="bg-gradient-to-br from-[#1a1520] to-[#111118] border border-amber-500/20 rounded-xl p-6 mb-6">
                        <p className="text-gray-500 text-sm mb-1">Total Balance</p>
                        <h2 className="text-4xl font-bold mb-1" data-testid="wallet-balance">
                          <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
                            {walletBalance.toFixed(4)}
                          </span>
                          <span className="text-lg text-gray-500 ml-2">AUC</span>
                        </h2>
                        <div className="flex gap-2 mt-4">
                          <button
                            onClick={fetchBalance}
                            className="px-3 py-1.5 text-xs bg-white/5 rounded-md text-gray-400 hover:text-white transition-colors flex items-center gap-1"
                          >
                            <RefreshCw size={12} /> Refresh
                          </button>
                          <button
                            onClick={() => setActiveTab('mine')}
                            className="px-3 py-1.5 text-xs bg-amber-500/20 rounded-md text-amber-400 hover:bg-amber-500/30 transition-colors flex items-center gap-1"
                          >
                            <Pickaxe size={12} /> Mine
                          </button>
                          <button
                            onClick={() => setActiveTab('send')}
                            className="px-3 py-1.5 text-xs bg-blue-500/20 rounded-md text-blue-400 hover:bg-blue-500/30 transition-colors flex items-center gap-1"
                          >
                            <Send size={12} /> Send
                          </button>
                        </div>
                      </div>

                      {/* Wallet Details */}
                      <div className="bg-[#111118] border border-gray-800 rounded-lg p-5 space-y-4">
                        <h3 className="text-sm font-medium text-gray-400">Wallet Details</h3>

                        <div>
                          <label className="text-xs text-gray-500 block mb-1">Address</label>
                          <div className="flex items-center gap-2 bg-[#0a0a0f] rounded-lg p-3">
                            <code className="text-xs text-amber-400 flex-1 break-all" data-testid="wallet-address">{wallet.address}</code>
                            <button onClick={() => copyToClipboard(wallet.address, 'addr')} className="p-1 hover:text-amber-400">
                              {copied === 'addr' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500 block mb-1">Public Key</label>
                          <div className="flex items-center gap-2 bg-[#0a0a0f] rounded-lg p-3">
                            <code className="text-xs text-gray-400 flex-1 break-all">{wallet.publicKey.substring(0, 60)}...</code>
                            <button onClick={() => copyToClipboard(wallet.publicKey, 'pub')} className="p-1 hover:text-amber-400">
                              {copied === 'pub' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500 block mb-1">Private Key</label>
                          <div className="flex items-center gap-2 bg-[#0a0a0f] rounded-lg p-3">
                            {showPrivateKey ? (
                              <code className="text-xs text-red-400 flex-1 break-all">{wallet.privateKey}</code>
                            ) : (
                              <span className="text-xs text-gray-600 flex-1">{"*".repeat(40)}</span>
                            )}
                            <button onClick={() => setShowPrivateKey(!showPrivateKey)} className="p-1 hover:text-amber-400">
                              {showPrivateKey ? <EyeOff size={14} /> : <Eye size={14} />}
                            </button>
                            <button onClick={() => copyToClipboard(wallet.privateKey, 'priv')} className="p-1 hover:text-amber-400">
                              {copied === 'priv' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                            </button>
                          </div>
                          <p className="text-xs text-red-400/70 mt-1 flex items-center gap-1">
                            <AlertTriangle size={10} /> Never share your private key. Anyone with it can access your funds.
                          </p>
                        </div>

                        <div className="pt-2 border-t border-gray-800">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500 text-xs">Key Algorithm</span>
                              <p className="font-medium">ECDSA secp256k1</p>
                            </div>
                            <div>
                              <span className="text-gray-500 text-xs">Address Format</span>
                              <p className="font-medium">ALPHA_[RIPEMD160+Checksum]</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </motion.div>
            )}

            {/* Send Tab */}
            {activeTab === 'send' && (
              <motion.div key="send" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl mx-auto">
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-6">
                    <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <Send size={20} className="text-blue-400" /> Send AUC
                    </h2>

                    {!wallet ? (
                      <div className="text-center py-6">
                        <AlertTriangle size={24} className="mx-auto mb-2 text-yellow-500" />
                        <p className="text-gray-400 mb-3">Create a wallet first to send transactions</p>
                        <button onClick={createWallet} className="px-6 py-2 bg-amber-500 text-black font-bold rounded-lg">
                          Create Wallet
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <label className="text-xs text-gray-500 block mb-1">From</label>
                          <div className="bg-[#0a0a0f] rounded-lg p-3">
                            <code className="text-xs text-amber-400">{wallet.address}</code>
                            <p className="text-xs text-gray-500 mt-1">Balance: {walletBalance.toFixed(4)} AUC</p>
                          </div>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500 block mb-1">To Address</label>
                          <input
                            data-testid="input-send-to"
                            type="text"
                            value={sendTo}
                            onChange={e => setSendTo(e.target.value)}
                            placeholder="ALPHA_..."
                            className="w-full bg-[#0a0a0f] border border-gray-700 rounded-lg p-3 text-sm focus:border-amber-500/50 outline-none transition-colors"
                          />
                        </div>

                        <div>
                          <label className="text-xs text-gray-500 block mb-1">Amount (AUC)</label>
                          <input
                            data-testid="input-send-amount"
                            type="number"
                            value={sendAmount}
                            onChange={e => setSendAmount(e.target.value)}
                            placeholder="0.0000"
                            step="0.0001"
                            min="0"
                            className="w-full bg-[#0a0a0f] border border-gray-700 rounded-lg p-3 text-sm focus:border-amber-500/50 outline-none transition-colors"
                          />
                          {sendAmount && (
                            <p className="text-xs text-gray-500 mt-1">
                              Fee: {Math.max(parseFloat(sendAmount || '0') * 0.001, 0.0001).toFixed(4)} AUC | 
                              Total: {(parseFloat(sendAmount || '0') + Math.max(parseFloat(sendAmount || '0') * 0.001, 0.0001)).toFixed(4)} AUC
                            </p>
                          )}
                        </div>

                        <button
                          data-testid="btn-send-transaction"
                          onClick={sendTransaction}
                          disabled={!sendTo || !sendAmount || sendStatus === 'sending'}
                          className={`w-full py-3 rounded-lg font-bold transition-all ${
                            !sendTo || !sendAmount
                              ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                              : 'bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-400 hover:to-blue-500'
                          }`}
                        >
                          {sendStatus === 'sending' ? 'Sending...' : 'Send Transaction'}
                        </button>

                        {sendStatus && sendStatus !== 'sending' && (
                          <div className={`p-3 rounded-lg text-sm ${
                            sendStatus === 'success'
                              ? 'bg-green-500/10 border border-green-500/30 text-green-400'
                              : 'bg-red-500/10 border border-red-500/30 text-red-400'
                          }`}>
                            {sendStatus === 'success' ? 'Transaction submitted to mempool. Mine a block to confirm it.' : sendStatus}
                          </div>
                        )}

                        <div className="pt-3 border-t border-gray-800 text-xs text-gray-500">
                          <p>Transactions are added to the mempool and confirmed when included in a mined block. Transaction fee: 0.1% (min 0.0001 AUC).</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'search' && (
              <motion.div key="search" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="bg-[#111118] border border-gray-800 rounded-lg p-5 mb-6">
                  <h2 className="text-lg font-bold mb-4">Blockchain Explorer</h2>
                  <div className="flex gap-2">
                    <input
                      data-testid="input-explorer-search"
                      type="text"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && searchBlockchain()}
                      placeholder="Search by block number, hash, address, or transaction ID..."
                      className="flex-1 bg-[#0a0a0f] border border-gray-700 rounded-lg p-3 text-sm focus:border-amber-500/50 outline-none"
                    />
                    <button
                      data-testid="btn-search"
                      onClick={searchBlockchain}
                      disabled={searchLoading}
                      className="px-6 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg hover:bg-amber-500/30 transition-all font-medium"
                    >
                      {searchLoading ? <RefreshCw size={16} className="animate-spin" /> : <Search size={16} />}
                    </button>
                  </div>
                </div>

                {searchResult && (
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-5 mb-6">
                    {searchResult.type === 'not_found' && (
                      <p className="text-gray-400 text-center py-8">No results found for "{searchQuery}"</p>
                    )}
                    {searchResult.type === 'block' && searchResult.data && (
                      <div>
                        <h3 className="text-amber-400 font-bold mb-3">Block #{searchResult.data.index}</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between"><span className="text-gray-500">Hash</span><span className="font-mono text-xs break-all">{searchResult.data.hash}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Previous Hash</span><span className="font-mono text-xs break-all">{searchResult.data.header?.previousHash}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Timestamp</span><span>{formatTime(searchResult.data.header?.timestamp)}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Difficulty</span><span>{searchResult.data.header?.difficulty}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Nonce</span><span>{searchResult.data.header?.nonce?.toLocaleString()}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Transactions</span><span>{searchResult.data.transactions?.length}</span></div>
                        </div>
                        {searchResult.data.transactions?.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-sm font-medium text-gray-400 mb-2">Transactions</h4>
                            {searchResult.data.transactions.map((tx: any) => (
                              <div key={tx.id} className="bg-[#0a0a0f] p-3 rounded mb-1 text-xs">
                                <span className="text-amber-400 font-mono">{tx.id?.substring(0, 24)}...</span>
                                <span className="text-gray-500 ml-2">[{tx.type}]</span>
                                <span className="text-green-400 ml-2">{tx.outputs?.[0]?.amount} AUC</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                    {searchResult.type === 'address' && searchResult.data && (
                      <div>
                        <h3 className="text-amber-400 font-bold mb-3">Address</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between"><span className="text-gray-500">Address</span><span className="font-mono text-xs">{searchResult.data.address}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Balance</span><span className="text-green-400 font-bold">{searchResult.data.balance} AUC</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Transactions</span><span>{searchResult.data.transactionCount}</span></div>
                        </div>
                      </div>
                    )}
                    {searchResult.type === 'transaction' && searchResult.data && (
                      <div>
                        <h3 className="text-amber-400 font-bold mb-3">Transaction</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between"><span className="text-gray-500">ID</span><span className="font-mono text-xs break-all">{searchResult.data.transaction?.id}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Type</span><span>{searchResult.data.transaction?.type}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Block</span><span>#{searchResult.data.blockIndex}</span></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {richList && (
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold">Rich List</h3>
                      <span className="text-xs text-gray-500">{richList.totalAddresses} total addresses | {richList.totalSupply?.toFixed(4)} AUC in circulation</span>
                    </div>
                    <div className="space-y-1">
                      {richList.richlist?.map((entry: any, i: number) => (
                        <div key={entry.address} className="flex items-center justify-between bg-[#0a0a0f] p-3 rounded text-sm hover:bg-amber-500/5 transition-colors">
                          <div className="flex items-center gap-3">
                            <span className="text-gray-600 w-6 text-right">#{i + 1}</span>
                            <span className="font-mono text-xs text-gray-300">{entry.address.substring(0, 30)}...</span>
                          </div>
                          <span className="text-amber-400 font-bold">{entry.balance.toFixed(4)} AUC</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'network' && (
              <motion.div key="network" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold">P2P Network Status</h2>
                  <button onClick={fetchNetworkStats} className="flex items-center gap-1 text-xs text-gray-500 hover:text-amber-400">
                    <RefreshCw size={12} /> Refresh
                  </button>
                </div>
                {networkStats ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { label: 'Status', value: networkStats.status === 'online' ? 'Online' : 'Offline', color: networkStats.status === 'online' ? 'text-green-400' : 'text-red-400' },
                        { label: 'Node ID', value: networkStats.nodeId?.substring(0, 16) || 'N/A' },
                        { label: 'Connected Peers', value: networkStats.peerCount?.toString() || '0' },
                        { label: 'Network', value: 'AUC Mainnet' },
                      ].map(item => (
                        <div key={item.label} className="bg-[#111118] border border-gray-800 rounded-lg p-4">
                          <span className="text-xs text-gray-500 block mb-1">{item.label}</span>
                          <span className={`text-lg font-bold ${(item as any).color || 'text-white'}`}>{item.value}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Network Information</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-500">Protocol</span><span>WebSocket P2P</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">P2P Port</span><span>6001</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Consensus</span><span>Proof of Work</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Hash Algorithm</span><span>SHA-256 Double Hash</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Block Time Target</span><span>10 minutes</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Difficulty Adjustment</span><span>Every 2,016 blocks</span></div>
                      </div>
                    </div>

                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Seed Nodes</h3>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 bg-[#0a0a0f] p-3 rounded text-sm">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                          <span className="font-mono text-xs">wss://alphaunlimitedtrading.com/ws/p2p</span>
                          <span className="text-xs text-gray-500 ml-auto">Primary Seed Node</span>
                        </div>
                      </div>
                    </div>

                    {networkStats.peers?.length > 0 && (
                      <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Connected Peers ({networkStats.peers.length})</h3>
                        <div className="space-y-1">
                          {networkStats.peers.map((peer: any) => (
                            <div key={peer.id} className="flex items-center justify-between bg-[#0a0a0f] p-3 rounded text-xs">
                              <span className="font-mono text-gray-300">{peer.id?.substring(0, 20)}</span>
                              <span className="text-gray-500">Height: {peer.chainHeight || 'unknown'}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-8 text-center">
                    <Network size={48} className="mx-auto text-gray-600 mb-3" />
                    <p className="text-gray-400">Loading network status...</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'pool' && (
              <motion.div key="pool" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold">Stratum Mining Pool</h2>
                  <button onClick={fetchPoolStats} className="flex items-center gap-1 text-xs text-gray-500 hover:text-amber-400">
                    <RefreshCw size={12} /> Refresh
                  </button>
                </div>
                {poolStats ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { label: 'Pool Status', value: poolStats.status === 'online' ? 'Online' : 'Offline', color: poolStats.status === 'online' ? 'text-green-400' : 'text-yellow-400' },
                        { label: 'Connected Miners', value: (poolStats.connectedMiners || 0).toString() },
                        { label: 'Total Shares', value: (poolStats.totalShares || 0).toLocaleString() },
                        { label: 'Blocks Found', value: (poolStats.totalBlocks || 0).toString() },
                      ].map(item => (
                        <div key={item.label} className="bg-[#111118] border border-gray-800 rounded-lg p-4">
                          <span className="text-xs text-gray-500 block mb-1">{item.label}</span>
                          <span className={`text-lg font-bold ${(item as any).color || 'text-white'}`}>{item.value}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Connection Details</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-500">Protocol</span><span>Stratum v1</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Host</span><span className="font-mono">alphaunlimitedtrading.com</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Port</span><span className="font-mono">3333</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Worker Format</span><span className="font-mono">ALPHA_ADDRESS.worker_name</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">Password</span><span className="font-mono">x</span></div>
                      </div>
                    </div>

                    <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Supported Hardware</h3>
                      <div className="space-y-2">
                        {[
                          { name: 'NerdOCTaxe Solo Miner', hashrate: '9.6 TH/s', algo: 'SHA-256', status: 'Compatible' },
                          { name: 'Bitaxe (AxeOS)', hashrate: 'Variable', algo: 'SHA-256', status: 'Compatible' },
                          { name: 'CGMiner / BFGMiner', hashrate: 'Variable', algo: 'SHA-256', status: 'Compatible' },
                          { name: 'CPU Mining (Node CLI)', hashrate: 'Variable', algo: 'SHA-256', status: 'Built-in' },
                        ].map(hw => (
                          <div key={hw.name} className="flex items-center justify-between bg-[#0a0a0f] p-3 rounded text-sm">
                            <div>
                              <span className="text-gray-200">{hw.name}</span>
                              <span className="text-xs text-gray-500 ml-2">{hw.hashrate}</span>
                            </div>
                            <span className="text-xs text-green-400">{hw.status}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {poolStats.currentJob && (
                      <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Current Job</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between"><span className="text-gray-500">Job ID</span><span className="font-mono">{poolStats.currentJob.id}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Block Height</span><span>{poolStats.currentJob.height}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Difficulty</span><span>{poolStats.currentJob.difficulty}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Pending TXs</span><span>{poolStats.currentJob.pendingTxs}</span></div>
                        </div>
                      </div>
                    )}

                    {poolStats.miners?.length > 0 && (
                      <div className="bg-[#111118] border border-gray-800 rounded-lg p-5">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Connected Miners ({poolStats.miners.length})</h3>
                        <div className="space-y-1">
                          {poolStats.miners.map((miner: any) => (
                            <div key={miner.id} className="flex items-center justify-between bg-[#0a0a0f] p-3 rounded text-xs">
                              <div>
                                <span className="text-gray-300 font-mono">{miner.worker}</span>
                                <span className="text-gray-500 ml-2">{miner.address?.substring(0, 20)}...</span>
                              </div>
                              <div className="flex items-center gap-4">
                                <span className="text-green-400">{miner.sharesAccepted} accepted</span>
                                {miner.sharesRejected > 0 && <span className="text-red-400">{miner.sharesRejected} rejected</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-[#111118] border border-gray-800 rounded-lg p-8 text-center">
                    <HardDrive size={48} className="mx-auto text-gray-600 mb-3" />
                    <p className="text-gray-400">Loading mining pool status...</p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
