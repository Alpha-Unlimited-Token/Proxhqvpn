/**
 * Alpha Mining Technology — Express route handlers (extracted from main monolith)
 * 
 * These are every mining/blockchain/forge/QMGE/AACC route from the production
 * Alpha Unlimited Trading platform. Drop into your new project's Express app via:
 * 
 *     import { registerMiningRoutes } from './mining-routes';
 *     registerMiningRoutes(app, { isAuthenticated, miningDataRateLimit, downloadRateLimit, proprietaryRateLimit });
 * 
 * Imports referenced inside the handlers (storage, services) point to relative
 * paths in the original codebase — the relevant files are bundled in this same
 * package under server/services/, server/blockchain/, etc. Adjust the imports
 * to match your destination project's directory structure.
 */
import type { Express, Request, Response } from 'express';

interface RouteDeps {
  isAuthenticated: any;
  miningDataRateLimit?: any;
  downloadRateLimit?: any;
  proprietaryRateLimit?: any;
}

export function registerMiningRoutes(app: Express, deps: RouteDeps) {
  const { isAuthenticated, miningDataRateLimit, downloadRateLimit, proprietaryRateLimit } = deps;

    app.post("/api/qmge/checkout", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        const user = await storage.getUser(userId);
        if (!user) return res.status(401).json({ message: "Unauthorized" });
  
        const { plan } = req.body;
        if (!plan || !["monthly", "annual", "lifetime"].includes(plan)) {
          return res.status(400).json({ message: "Valid plan required: monthly, annual, or lifetime" });
        }
  
        const stripe = await getUncachableStripeClient();
  
        let customerId = user.stripeCustomerId;
        if (!customerId) {
          const customer = await stripe.customers.create({
            email: user.email || undefined,
            metadata: { userId },
          });
          await storage.updateUserStripeInfo(userId, { stripeCustomerId: customer.id });
          customerId = customer.id;
        }
  
        const planConfig: Record<string, { name: string; amount: number; mode: 'subscription' | 'payment'; interval?: 'month' | 'year' }> = {
          monthly: { name: "QMGE Standalone - Monthly", amount: 17900, mode: "subscription", interval: "month" },
          annual: { name: "QMGE Standalone - Annual", amount: 149900, mode: "subscription", interval: "year" },
          lifetime: { name: "QMGE Standalone - Lifetime License", amount: 299700, mode: "payment" },
        };
  
        const config = planConfig[plan];
  
        const priceData: any = {
          currency: "usd",
          unit_amount: config.amount,
          product_data: {
            name: config.name,
            metadata: { type: "qmge_standalone", plan },
          },
        };
        if (config.mode === "subscription" && config.interval) {
          priceData.recurring = { interval: config.interval };
        }
  
        const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`;
        const session = await stripe.checkout.sessions.create({
          customer: customerId,
          payment_method_types: ['card'],
          line_items: [{ price_data: priceData, quantity: 1 }],
          mode: config.mode,
          success_url: `${baseUrl}/qmge-standalone?purchase=success&plan=${plan}`,
          cancel_url: `${baseUrl}/qmge-standalone?purchase=cancelled`,
          metadata: { userId, type: "qmge_standalone", plan },
          ...(config.mode === "subscription" ? { subscription_data: { metadata: { userId, type: "qmge_standalone", plan } } } : {}),
        });
  
        res.json({ url: session.url, sessionId: session.id });
      } catch (error: any) {
        console.error("Error creating QMGE checkout:", error?.message || error);
        res.status(500).json({ message: "Failed to create checkout session" });
      }
    });

    app.get("/api/qmge/license", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        if (isAdmin(userId)) {
          return res.json({
            hasLicense: true,
            license: {
              id: -1,
              licenseKey: "ADMIN-QMGE-FULL-ACCESS",
              tier: "alpha",
              status: "active",
              dimensionsUnlocked: 7,
              dataDelay: 0,
              patternsUnlocked: 999,
              exchangeLimit: 99,
              totalUsageMinutes: 0,
              maxUsageMinutes: 999999,
              remainingMinutes: 999999,
              trialExpiresAt: null,
              trialTimeLeftMinutes: null,
              vpnBlocked: false,
              vpnDetectedCount: 0,
              createdAt: new Date().toISOString(),
            },
            isExpired: false,
            canUpgrade: false,
          });
        }
  
        const license = await storage.getQmgeLicense(userId);
        if (!license) {
          return res.json({ hasLicense: false, canActivateTrial: true });
        }
  
        const now = new Date();
        const isTrialExpired = license.tier === "free" && license.trialExpiresAt && now > license.trialExpiresAt;
        const isUsageExhausted = license.tier === "free" && license.totalUsageMinutes >= license.maxUsageMinutes;
        const isExpired = isTrialExpired || isUsageExhausted;
  
        const remainingMinutes = Math.max(0, license.maxUsageMinutes - license.totalUsageMinutes);
        const trialTimeLeft = license.trialExpiresAt ? Math.max(0, Math.floor((license.trialExpiresAt.getTime() - now.getTime()) / 60000)) : 0;
  
        res.json({
          hasLicense: true,
          license: {
            id: license.id,
            licenseKey: license.licenseKey,
            tier: license.tier,
            status: isExpired && license.tier === "free" ? "expired" : license.status,
            dimensionsUnlocked: license.dimensionsUnlocked,
            dataDelay: license.dataDelay,
            patternsUnlocked: license.patternsUnlocked,
            exchangeLimit: license.exchangeLimit,
            totalUsageMinutes: license.totalUsageMinutes,
            maxUsageMinutes: license.maxUsageMinutes,
            remainingMinutes,
            trialExpiresAt: license.trialExpiresAt,
            trialTimeLeftMinutes: trialTimeLeft,
            vpnBlocked: license.vpnBlocked,
            vpnDetectedCount: license.vpnDetectedCount,
            createdAt: license.createdAt,
          },
          isExpired,
          canUpgrade: license.tier === "free",
        });
      } catch (error: any) {
        console.error("License check error:", error?.message);
        res.status(500).json({ message: "Failed to check license" });
      }
    });

    app.post("/api/qmge/license/activate", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        const existing = await storage.getQmgeLicense(userId);
        if (existing) {
          return res.status(400).json({ message: "You already have a QMGE license", licenseKey: existing.licenseKey });
        }
  
        const ip = getClientIp(req);
        const userAgent = req.headers["user-agent"] || "";
        const fingerprint = createIpFingerprint(ip, userAgent);
  
        const vpnResult = await detectVpn(ip);
        if (vpnResult.isVpn) {
          return res.status(403).json({
            message: "VPN or proxy detected. QMGE cannot be activated while using a VPN. Please disconnect your VPN and try again.",
            vpnDetected: true,
            reason: vpnResult.reason,
          });
        }
  
        const now = new Date();
        const trialExpiry = new Date(now.getTime() + QMGE_FREE_LIMITS.trialDays * 24 * 60 * 60 * 1000);
        const licenseKey = generateLicenseKey(userId, "free");
  
        const license = await storage.createQmgeLicense({
          userId,
          licenseKey,
          tier: "free",
          status: "active",
          activatedIp: ip,
          lastVerifiedIp: ip,
          ipFingerprint: fingerprint,
          trialStartedAt: now,
          trialExpiresAt: trialExpiry,
          maxUsageMinutes: QMGE_FREE_LIMITS.maxUsageMinutes,
          dimensionsUnlocked: QMGE_FREE_LIMITS.dimensionsUnlocked,
          dataDelay: QMGE_FREE_LIMITS.dataDelaySeconds,
          patternsUnlocked: QMGE_FREE_LIMITS.patternsUnlocked,
          exchangeLimit: QMGE_FREE_LIMITS.exchangeLimit,
        });
  
        await storage.logQmgeLicenseEvent({
          licenseId: license.id,
          userId,
          eventType: "trial_activated",
          ip,
          details: { fingerprint, trialExpiry: trialExpiry.toISOString(), userAgent: userAgent.substring(0, 100) },
        });
  
        res.json({
          message: "Free trial activated successfully",
          license: {
            licenseKey: license.licenseKey,
            tier: "free",
            trialExpiresAt: trialExpiry,
            maxUsageMinutes: QMGE_FREE_LIMITS.maxUsageMinutes,
            dimensionsUnlocked: QMGE_FREE_LIMITS.dimensionsUnlocked,
            dataDelay: QMGE_FREE_LIMITS.dataDelaySeconds,
          },
        });
      } catch (error: any) {
        console.error("License activation error:", error?.message);
        res.status(500).json({ message: "Failed to activate trial" });
      }
    });

    app.post("/api/qmge/license/validate", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        const license = await storage.getQmgeLicense(userId);
        if (!license) return res.status(404).json({ valid: false, message: "No license found" });
  
        const ip = getClientIp(req);
        const userAgent = req.headers["user-agent"] || "";
        const fingerprint = createIpFingerprint(ip, userAgent);
  
        const vpnResult = await detectVpn(ip);
        if (vpnResult.isVpn) {
          await storage.updateQmgeLicense(license.id, {
            vpnDetectedCount: license.vpnDetectedCount + 1,
            vpnBlocked: true,
          });
          await storage.logQmgeLicenseEvent({
            licenseId: license.id,
            userId,
            eventType: "vpn_blocked",
            ip,
            vpnDetected: true,
            details: { reason: vpnResult.reason, provider: vpnResult.provider },
          });
          return res.status(403).json({
            valid: false,
            message: "VPN or proxy detected. QMGE cannot run while a VPN is active. Please disconnect your VPN to continue.",
            vpnDetected: true,
          });
        }
  
        if (license.vpnBlocked) {
          await storage.updateQmgeLicense(license.id, { vpnBlocked: false });
        }
  
        if (license.tier === "free") {
          const now = new Date();
          if (license.trialExpiresAt && now > license.trialExpiresAt) {
            await storage.logQmgeLicenseEvent({
              licenseId: license.id, userId, eventType: "trial_expired_time", ip,
              details: { trialExpiresAt: license.trialExpiresAt.toISOString() },
            });
            return res.json({
              valid: false,
              expired: true,
              reason: "trial_time_expired",
              message: "Your 7-day free trial has expired. Purchase a license to continue using QMGE.",
            });
          }
  
          if (license.totalUsageMinutes >= license.maxUsageMinutes) {
            await storage.logQmgeLicenseEvent({
              licenseId: license.id, userId, eventType: "trial_expired_usage", ip,
              details: { totalUsageMinutes: license.totalUsageMinutes, maxUsageMinutes: license.maxUsageMinutes },
            });
            return res.json({
              valid: false,
              expired: true,
              reason: "usage_limit_reached",
              message: `You've used all ${license.maxUsageMinutes} minutes of your free trial. Purchase a license to continue.`,
            });
          }
        }
  
        await storage.updateQmgeLicense(license.id, {
          lastVerifiedIp: ip,
          ipFingerprint: fingerprint,
          lastHeartbeat: new Date(),
        });
  
        res.json({
          valid: true,
          tier: license.tier,
          dimensionsUnlocked: license.dimensionsUnlocked,
          dataDelay: license.dataDelay,
          patternsUnlocked: license.patternsUnlocked,
          exchangeLimit: license.exchangeLimit,
          remainingMinutes: license.tier === "free" ? Math.max(0, license.maxUsageMinutes - license.totalUsageMinutes) : null,
          trialTimeLeftMinutes: license.tier === "free" && license.trialExpiresAt
            ? Math.max(0, Math.floor((license.trialExpiresAt.getTime() - Date.now()) / 60000)) : null,
        });
      } catch (error: any) {
        console.error("License validation error:", error?.message);
        res.status(500).json({ message: "Failed to validate license" });
      }
    });

    app.post("/api/qmge/license/heartbeat", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        const license = await storage.getQmgeLicense(userId);
        if (!license) return res.status(404).json({ message: "No license found" });
  
        const ip = getClientIp(req);
        const vpnResult = await detectVpn(ip);
        if (vpnResult.isVpn) {
          await storage.updateQmgeLicense(license.id, {
            vpnDetectedCount: license.vpnDetectedCount + 1,
            vpnBlocked: true,
          });
          return res.status(403).json({ blocked: true, message: "VPN detected. Session paused." });
        }
  
        const now = new Date();
        let minutesToAdd = 5;
        if (license.lastHeartbeat) {
          const elapsed = (now.getTime() - license.lastHeartbeat.getTime()) / 60000;
          minutesToAdd = Math.min(Math.round(elapsed), 10);
        }
  
        const newUsage = license.totalUsageMinutes + minutesToAdd;
  
        if (license.tier === "free" && newUsage >= license.maxUsageMinutes) {
          await storage.updateQmgeLicense(license.id, {
            totalUsageMinutes: license.maxUsageMinutes,
            lastHeartbeat: now,
            status: "expired",
          });
          return res.json({
            active: false,
            expired: true,
            message: "Free trial usage limit reached. Purchase to continue.",
            totalUsageMinutes: license.maxUsageMinutes,
          });
        }
  
        if (license.tier === "free" && license.trialExpiresAt && now > license.trialExpiresAt) {
          await storage.updateQmgeLicense(license.id, { lastHeartbeat: now, status: "expired" });
          return res.json({ active: false, expired: true, message: "Free trial period has ended." });
        }
  
        await storage.updateQmgeLicense(license.id, {
          totalUsageMinutes: newUsage,
          lastHeartbeat: now,
          lastVerifiedIp: ip,
        });
  
        res.json({
          active: true,
          totalUsageMinutes: newUsage,
          remainingMinutes: license.tier === "free" ? Math.max(0, license.maxUsageMinutes - newUsage) : null,
        });
      } catch (error: any) {
        console.error("Heartbeat error:", error?.message);
        res.status(500).json({ message: "Heartbeat failed" });
      }
    });

    app.post("/api/qmge/license/upgrade", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        const { plan } = req.body;
        if (!plan || !["monthly", "annual", "lifetime"].includes(plan)) {
          return res.status(400).json({ message: "Valid plan required" });
        }
  
        const stripe = await getUncachableStripeClient();
        const sessions = await stripe.checkout.sessions.list({
          limit: 10,
        });
  
        const validSession = sessions.data.find(s =>
          s.metadata?.userId === userId &&
          s.metadata?.type === "qmge_standalone" &&
          s.metadata?.plan === plan &&
          (s.payment_status === "paid" || s.status === "complete")
        );
  
        if (!validSession) {
          return res.status(403).json({
            message: "No verified payment found. Please complete a purchase first.",
            paymentRequired: true,
          });
        }
  
        const license = await storage.getQmgeLicense(userId);
        if (license && license.tier !== "free" && license.stripePaymentId === validSession.id) {
          return res.json({
            message: "License already upgraded.",
            license: {
              licenseKey: license.licenseKey,
              tier: license.tier,
              dimensionsUnlocked: license.dimensionsUnlocked,
              dataDelay: license.dataDelay,
              patternsUnlocked: license.patternsUnlocked,
              exchangeLimit: license.exchangeLimit,
            },
          });
        }
  
        const newKey = generateLicenseKey(userId, plan);
        const upgradeData: Partial<any> = {
          tier: plan,
          status: "active",
          licenseKey: newKey,
          dimensionsUnlocked: QMGE_PAID_LIMITS.dimensionsUnlocked,
          dataDelay: QMGE_PAID_LIMITS.dataDelaySeconds,
          patternsUnlocked: QMGE_PAID_LIMITS.patternsUnlocked,
          exchangeLimit: QMGE_PAID_LIMITS.exchangeLimit,
          maxUsageMinutes: 999999,
          stripePaymentId: validSession.id,
          stripeSubscriptionId: validSession.subscription ? String(validSession.subscription) : null,
        };
  
        let updated;
        if (license) {
          updated = await storage.updateQmgeLicense(license.id, upgradeData);
          await storage.logQmgeLicenseEvent({
            licenseId: license.id,
            userId,
            eventType: "upgraded",
            ip: getClientIp(req),
            details: { fromTier: license.tier, toPlan: plan, stripeSessionId: validSession.id, paymentVerified: true },
          });
        } else {
          const ip = getClientIp(req);
          updated = await storage.createQmgeLicense({
            userId,
            licenseKey: newKey,
            ...upgradeData,
            activatedIp: ip,
            lastVerifiedIp: ip,
            ipFingerprint: createIpFingerprint(ip, req.headers["user-agent"] || ""),
          });
          await storage.logQmgeLicenseEvent({
            licenseId: updated.id,
            userId,
            eventType: "purchased",
            ip,
            details: { plan, stripeSessionId: validSession.id, paymentVerified: true },
          });
        }
  
        res.json({
          message: `QMGE upgraded to ${plan} successfully! All 7 dimensions are now unlocked.`,
          license: {
            licenseKey: updated!.licenseKey,
            tier: plan,
            dimensionsUnlocked: QMGE_PAID_LIMITS.dimensionsUnlocked,
            dataDelay: QMGE_PAID_LIMITS.dataDelaySeconds,
            patternsUnlocked: QMGE_PAID_LIMITS.patternsUnlocked,
            exchangeLimit: QMGE_PAID_LIMITS.exchangeLimit,
          },
        });
      } catch (error: any) {
        console.error("License upgrade error:", error?.message);
        res.status(500).json({ message: "Failed to upgrade license" });
      }
    });

    app.get("/api/qmge/license/events", isAuthenticated, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        const license = await storage.getQmgeLicense(userId);
        if (!license) return res.json({ events: [] });
  
        const events = await storage.getQmgeLicenseEvents(license.id, 20);
        res.json({ events });
      } catch (error: any) {
        res.status(500).json({ message: "Failed to get events" });
      }
    });

    app.get("/api/qmge/download", isAuthenticated, downloadRateLimit, async (req, res) => {
      try {
        const userId = (req.user as any)?.claims?.sub;
        if (!userId) return res.status(401).json({ message: "Unauthorized" });
  
        let licenseKey: string;
        let licenseTier: string;
        let licenseId: number;
        let maxMinutes: number;
  
        if (isAdmin(userId)) {
          licenseKey = "ADMIN-QMGE-FULL-ACCESS";
          licenseTier = "lifetime";
          licenseId = -1;
          maxMinutes = 999999;
        } else {
          const license = await storage.getQmgeLicense(userId);
          if (!license) return res.status(404).json({ message: "No QMGE license found. Please activate a free trial or purchase a license first." });
          licenseKey = license.licenseKey;
          licenseTier = license.tier;
          licenseId = license.id;
          maxMinutes = license.maxUsageMinutes;
  
          const ip = getClientIp(req);
          await storage.logQmgeLicenseEvent({
            licenseId: license.id,
            userId,
            eventType: "download",
            ip,
            details: { tier: license.tier, licenseKey: license.licenseKey },
          });
        }
  
        const fs = await import("fs");
        const path = await import("path");
        const filePath = path.resolve("public/downloads/QMGE-Standalone.html");
  
        if (!fs.existsSync(filePath)) {
          return res.status(500).json({ message: "Download file not available. Please contact support." });
        }
  
        let html = fs.readFileSync(filePath, "utf-8");
  
        const licensePayload = JSON.stringify({
          key: licenseKey,
          tier: licenseTier,
          userId: userId,
          maxMinutes: maxMinutes,
          issued: new Date().toISOString(),
        });
        const encodedLicense = Buffer.from(licensePayload).toString("base64");
  
        html = html.replace(
          "<!--LICENSE_INJECTION_POINT-->",
          `<script>window.__QMGE_LICENSE__=${JSON.stringify(encodedLicense)};</script>`
        );
  
        res.setHeader("Content-Type", "text/html");
        res.setHeader("Content-Disposition", `attachment; filename="QMGE-Standalone-${licenseTier.toUpperCase()}.html"`);
        res.setHeader("Cache-Control", "no-store");
        res.send(html);
      } catch (error: any) {
        console.error("QMGE download error:", error);
        res.status(500).json({ message: "Download failed. Please try again." });
      }
    });

    app.get("/api/qmge/mining-data", miningDataRateLimit, async (req, res) => {
      try {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        const allowedSymbols = ["BTCUSDT", "ETHUSDT", "LTCUSDT", "DOGEUSDT", "XMRUSDT"];
        const rawSymbol = (req.query.symbol as string) || "BTCUSDT";
        const symbol = allowedSymbols.includes(rawSymbol) ? rawSymbol : "BTCUSDT";
        
        const cached = qmgeMiningCache[symbol];
        if (cached && Date.now() - cached.ts < QMGE_MINING_CACHE_TTL) {
          return res.json(cached.data);
        }
        
        const qmgeBinanceEndpoints = [
          `https://data-api.binance.vision/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=5m&limit=50`,
          `https://api.binance.us/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=5m&limit=50`,
        ];
  
        let klines: any[] | null = null;
        for (const endpoint of qmgeBinanceEndpoints) {
          try {
            const binanceRes = await rateLimitedFetch(endpoint, { signal: AbortSignal.timeout(6000) });
            if (binanceRes.ok) {
              klines = await binanceRes.json() as any[];
              if (Array.isArray(klines) && klines.length > 0) break;
            }
          } catch {
            continue;
          }
          klines = null;
        }
        
        if (!klines || klines.length === 0) {
          const cached = qmgeMiningCache[symbol];
          if (cached && Date.now() - cached.ts < 120000) {
            return res.json({ ...cached.data, stale: true });
          }
          return res.json({
            version: "1.0.0",
            type: "qmge_mining_intelligence",
            source: "alpha_unlimited_trading",
            status: "offline",
            message: "Market data temporarily unavailable",
            timestamp: Date.now(),
          });
        }
        
        const candles = klines.map((k: any) => ({
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
          time: k[0],
        }));
        
        const closes = candles.map(c => c.close);
        const volumes = candles.map(c => c.volume);
        const avgVol = volumes.reduce((a, b) => a + b, 0) / volumes.length;
        const recentVol = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
        const priceChange = closes.length > 1 ? (closes[closes.length - 1] - closes[0]) / closes[0] : 0;
        const volRatio = avgVol > 0 ? recentVol / avgVol : 1;
        
        const networkHealthScore = Math.max(0, Math.min(100, 50 + priceChange * 500));
        const capitalFlowScore = Math.max(0, Math.min(100, volRatio * 50));
        const convergenceIndex = Math.max(0.1, Math.min(0.95, 0.5 + priceChange * 2));
        const mutationRate = Math.max(0.05, Math.min(0.9, Math.abs(priceChange) * 10 + 0.2));
        
        const mCur = closes[closes.length - 1];
        const mSma20 = closes.slice(-20).reduce((a: number, b: number) => a + b, 0) / Math.min(20, closes.length);
        const mPcChg = closes.length > 20 ? ((mCur - closes[closes.length - 21]) / closes[closes.length - 21]) * 100 : 0;
        const mDown = mPcChg < -1.5 && mCur < mSma20;
        const mUp = mPcChg > 1.5 && mCur > mSma20;
        let profitSignal = capitalFlowScore >= 75 ? "highly_profitable" : capitalFlowScore >= 55 ? "profitable" : capitalFlowScore < 35 ? "unprofitable" : "neutral";
        if (mDown && (profitSignal === "highly_profitable" || profitSignal === "profitable")) profitSignal = "neutral";
        
        const diffDirection = networkHealthScore > 65 ? "increasing" : networkHealthScore < 40 ? "decreasing" : "stable";
        const isOptimalWindow = diffDirection === "decreasing" || (diffDirection === "stable" && networkHealthScore < 55);
        const windowScore = (isOptimalWindow ? 30 : 0) + (capitalFlowScore / 100) * 30 + ((100 - Math.max(0, 100 - networkHealthScore)) / 100) * 20 + (convergenceIndex) * 20;
        
        let recommendation = "mine_reduced";
        let reason = "Moderate conditions detected";
        if (windowScore >= 80 && !mDown) { recommendation = "mine_full_power"; reason = "Favorable network conditions: low difficulty pressure, high profitability"; }
        else if (windowScore < 40) { recommendation = "hold"; reason = "Unfavorable conditions detected by QMGE analysis"; }
        
        const baseNonce = Math.floor(convergenceIndex * 4294967295);
        const range = Math.floor((1 - mutationRate) * 2000000) + 500000;
        
        const responseData = {
          version: "1.0.0",
          type: "qmge_mining_intelligence",
          source: "alpha_unlimited_trading",
          status: "online",
          timestamp: Date.now(),
          payload: {
            timestamp: Date.now(),
            symbol,
            difficultyPrediction: {
              direction: diffDirection,
              magnitude: Math.abs(networkHealthScore - 50) / 50,
              confidence: Math.min(100, convergenceIndex * 60 + 40),
              optimalWindow: isOptimalWindow,
            },
            chainProfitability: {
              score: capitalFlowScore,
              signal: profitSignal,
              hashRateMigrationRisk: Math.max(0, 50 - capitalFlowScore) * 0.5,
              revenueProjection: capitalFlowScore / 100,
            },
            networkIntelligence: {
              congestionLevel: Math.max(0, Math.min(100, 100 - networkHealthScore)),
              hashRateStability: Math.min(100, convergenceIndex * 80 + 20),
              orphanRiskFactor: networkHealthScore < 30 ? 40 : 10,
              blockPropagationScore: Math.max(0, Math.min(100, networkHealthScore * 0.7 + 30)),
            },
            miningWindow: {
              isOptimal: isOptimalWindow,
              windowScore,
              timeRemaining: Math.max(60, Math.floor((1 - mutationRate) * 1800)),
              recommendation,
              reason,
            },
            hashOptimization: {
              nonceRangeHint: { start: Math.max(0, baseNonce - range), end: Math.min(4294967295, baseNonce + range) },
              resonanceFrequency: Math.round(networkHealthScore * 0.01 * (1 + convergenceIndex * 0.5) * 1000) / 1000,
              entropyGradient: Math.round((mutationRate * 0.8 + (1 - convergenceIndex) * 0.2) * 1000) / 1000,
              convergenceTarget: Math.round(convergenceIndex * 10000) / 10000,
            },
            aggregateScore: Math.round((networkHealthScore * 0.4 + capitalFlowScore * 0.35 + convergenceIndex * 25) * 100) / 100,
            genomePattern: convergenceIndex > 0.7 ? "Quantum Alignment" : mutationRate > 0.6 ? "Genome Mutation" : "Adaptive Resonance",
          },
        };
        
        qmgeMiningCache[symbol] = { data: responseData, ts: Date.now() };
        res.json(responseData);
      } catch (error: any) {
        console.error("QMGE mining data error:", error);
        res.json({
          version: "1.0.0",
          type: "qmge_mining_intelligence",
          source: "alpha_unlimited_trading",
          status: "error",
          message: "Failed to generate mining intelligence",
          timestamp: Date.now(),
        });
      }
    });

    app.options("/api/qmge/mining-data", (req, res) => {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
      res.sendStatus(204);
    });

    app.get("/api/blockchain/blocks", isAuthenticated, async (req, res) => {
      try {
        const count = Math.min(parseInt(req.query.count as string) || 50, 200);
        const startHeight = req.query.startHeight as string;
        
        const latestRes = await fetch('https://blockchain.info/latestblock', {
          headers: { 'User-Agent': 'AlphaUnlimitedTrading/1.0' },
          signal: AbortSignal.timeout(10000)
        });
        if (!latestRes.ok) throw new Error('Failed to fetch latest block');
        const latest = await latestRes.json() as any;
        
        const height = startHeight ? parseInt(startHeight) : latest.height;
        
        const blocks: any[] = [];
        
        const concurrency = 5;
        for (let batch = 0; batch < Math.ceil(count / concurrency); batch++) {
          const fetches = [];
          for (let j = 0; j < concurrency && (batch * concurrency + j) < count; j++) {
            const h = height - (batch * concurrency + j);
            if (h < 0) continue;
            fetches.push(
              fetch(`https://blockchain.info/block-height/${h}?format=json`, {
                headers: { 'User-Agent': 'AlphaUnlimitedTrading/1.0' },
                signal: AbortSignal.timeout(15000)
              })
              .then(r => r.ok ? r.json() : null)
              .then((data: any) => {
                if (data?.blocks?.[0]) {
                  const block = data.blocks[0];
                  return {
                    height: block.height,
                    hash: block.hash,
                    prevHash: block.prev_block,
                    merkleRoot: block.mrkl_root,
                    timestamp: block.time,
                    nonce: block.nonce,
                    difficulty: block.bits,
                    size: block.size,
                    txCount: block.n_tx,
                    version: block.ver,
                  };
                }
                return null;
              })
              .catch(() => null)
            );
          }
          const results = await Promise.all(fetches);
          for (const block of results) {
            if (block) blocks.push(block);
          }
          if (blocks.length >= count) break;
          if (batch < Math.ceil(count / concurrency) - 1) {
            await new Promise(r => setTimeout(r, 500));
          }
        }
        
        res.json({
          latestHeight: latest.height,
          latestHash: latest.hash,
          blocks: blocks.sort((a: any, b: any) => a.height - b.height),
          fetchedAt: Date.now()
        });
      } catch (error: any) {
        console.error("Blockchain data fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch blockchain data' });
      }
    });

    app.post("/api/blockchain/analyze", isAuthenticated, proprietaryRateLimit, async (req, res) => {
      try {
        const { hashes } = req.body;
        if (!Array.isArray(hashes) || hashes.length < 2) {
          return res.status(400).json({ message: 'Need at least 2 hashes to analyze' });
        }
        if (hashes.length > 500) {
          return res.status(400).json({ message: 'Maximum 500 hashes allowed per request' });
        }
        const hexRegex = /^[0-9a-fA-F]{1,128}$/;
        for (const h of hashes) {
          if (typeof h !== 'string' || !hexRegex.test(h)) {
            return res.status(400).json({ message: 'Invalid hash format — hex strings only' });
          }
        }
        
        const bigInts = hashes.map((h: string) => BigInt('0x' + h));
        
        const differences: string[] = [];
        const ratios: number[] = [];
        const leadingZeros: number[] = [];
        const bitDistributions: number[] = [];
        const modResults: { mod3: number[]; mod6: number[]; mod9: number[]; mod256: number[] } = {
          mod3: [], mod6: [], mod9: [], mod256: []
        };
        
        for (let i = 0; i < bigInts.length; i++) {
          const h = hashes[i];
          let zeros = 0;
          for (const c of h) { if (c === '0') zeros++; else break; }
          leadingZeros.push(zeros);
          
          let ones = 0;
          const binStr = bigInts[i].toString(2);
          for (const b of binStr) { if (b === '1') ones++; }
          bitDistributions.push(ones / 256);
          
          modResults.mod3.push(Number(bigInts[i] % BigInt(3)));
          modResults.mod6.push(Number(bigInts[i] % BigInt(6)));
          modResults.mod9.push(Number(bigInts[i] % BigInt(9)));
          modResults.mod256.push(Number(bigInts[i] % BigInt(256)));
        }
        
        for (let i = 1; i < bigInts.length; i++) {
          const diff = bigInts[i] > bigInts[i - 1]
            ? bigInts[i] - bigInts[i - 1]
            : bigInts[i - 1] - bigInts[i];
          differences.push(diff.toString());
          
          if (bigInts[i - 1] !== BigInt(0)) {
            const r = Number((bigInts[i] * BigInt(10000)) / bigInts[i - 1]) / 10000;
            ratios.push(r);
          }
        }
        
        const xorPatterns: string[] = [];
        for (let i = 1; i < bigInts.length && i <= 20; i++) {
          const xorResult = bigInts[i] ^ bigInts[i - 1];
          const xorHex = xorResult.toString(16).padStart(64, '0');
          xorPatterns.push(xorHex);
        }
        
        const digitFrequency: Record<string, number> = {};
        for (const h of hashes) {
          for (const c of h) {
            digitFrequency[c] = (digitFrequency[c] || 0) + 1;
          }
        }
        const totalChars = hashes.length * 64;
        const expectedFreq = totalChars / 16;
        const chiSquared = Object.values(digitFrequency).reduce(
          (sum, freq) => sum + Math.pow(freq - expectedFreq, 2) / expectedFreq, 0
        );
        
        const mod3Freq = [0, 0, 0];
        modResults.mod3.forEach(v => mod3Freq[v]++);
        const mod9Freq = new Array(9).fill(0);
        modResults.mod9.forEach(v => mod9Freq[v]++);
        
        const autocorrelations: number[] = [];
        const numericValues = bigInts.map(b => Number(b % BigInt(1000000)));
        for (let lag = 1; lag <= Math.min(10, Math.floor(numericValues.length / 2)); lag++) {
          const mean = numericValues.reduce((a, b) => a + b, 0) / numericValues.length;
          let num = 0, den = 0;
          for (let i = 0; i < numericValues.length - lag; i++) {
            num += (numericValues[i] - mean) * (numericValues[i + lag] - mean);
          }
          for (let i = 0; i < numericValues.length; i++) {
            den += (numericValues[i] - mean) ** 2;
          }
          autocorrelations.push(den !== 0 ? num / den : 0);
        }
  
        const genesisInt = bigInts[0].toString();
        const latestInt = bigInts[bigInts.length - 1].toString();
  
        const patterns: string[] = [];
        
        if (chiSquared < 20) {
          patterns.push('Hex digit distribution is close to uniform (expected for SHA-256)');
        } else if (chiSquared > 30) {
          patterns.push('ANOMALY: Hex digit distribution shows unexpected deviation from uniform');
        }
        
        const avgBitRatio = bitDistributions.reduce((a, b) => a + b, 0) / bitDistributions.length;
        if (Math.abs(avgBitRatio - 0.5) < 0.02) {
          patterns.push(`Bit distribution is near-balanced: ${(avgBitRatio * 100).toFixed(2)}% ones (expected ~50%)`);
        } else {
          patterns.push(`ANOMALY: Bit distribution skewed: ${(avgBitRatio * 100).toFixed(2)}% ones`);
        }
        
        const leadingZeroTrend = leadingZeros.length > 1 ? 
          (leadingZeros[leadingZeros.length - 1] - leadingZeros[0]) / leadingZeros.length : 0;
        if (Math.abs(leadingZeroTrend) > 0.01) {
          patterns.push(`Leading zero trend detected: ${leadingZeroTrend > 0 ? 'increasing' : 'decreasing'} (reflects difficulty adjustments)`);
        }
        
        const significantCorrelations = autocorrelations.filter(c => Math.abs(c) > 0.1);
        if (significantCorrelations.length > 0) {
          patterns.push(`Potential autocorrelation detected at ${significantCorrelations.length} lag(s) - requires deeper investigation`);
        } else {
          patterns.push('No significant autocorrelation found between consecutive hash values');
        }
        
        const mod3Uniform = mod3Freq.every(f => Math.abs(f - hashes.length / 3) < hashes.length * 0.15);
        if (!mod3Uniform) {
          patterns.push(`Tesla 3-6-9: Mod-3 distribution shows non-uniform pattern: [${mod3Freq.join(', ')}]`);
        }
  
        res.json({
          analysis: {
            blockCount: hashes.length,
            genesisAsInteger: genesisInt,
            latestAsInteger: latestInt,
            integerDigitCount: latestInt.length,
            leadingZeros,
            bitDistributions,
            modularArithmetic: modResults,
            mod3Distribution: mod3Freq,
            mod9Distribution: mod9Freq,
            hexDigitFrequency: digitFrequency,
            chiSquaredStatistic: chiSquared,
            autocorrelations,
            xorPatterns,
            differencesSample: differences.slice(0, 10),
            ratiosSample: ratios.slice(0, 10),
            patterns,
          }
        });
      } catch (error: any) {
        console.error("Blockchain analysis error:", error.message);
        res.status(500).json({ message: 'Analysis failed' });
      }
    });

    app.post("/api/mining-bridge/publish", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = (req.user as any).id;
        const data = req.body;
        miningSignalStore.set(String(userId), {
          timestamp: Date.now(),
          windowScore: data.windowScore ?? 0,
          signal: data.signal ?? 'HOLD',
          entropyDeviation: data.entropyDeviation ?? '0',
          avgBitDist: data.avgBitDist ?? '0',
          chiSquared: data.chiSquared ?? '0',
          avgLeadingZeros: data.avgLeadingZeros ?? '0',
          anomalyCount: data.anomalyCount ?? 0,
          strongCorrs: data.strongCorrs ?? 0,
          blockCount: data.blockCount ?? 0,
          sbpeMetrics: data.sbpeMetrics ?? null,
          solvingMetrics: data.solvingMetrics ?? null,
          feedItems: (data.feedItems ?? []).slice(0, 20),
          difficultyTrend: data.difficultyTrend ?? 'stable',
          mod3Entropy: data.mod3Entropy ?? '0',
        });
        const store = getUserFusionStore(String(userId));
        store.set('command_center', { timestamp: Date.now(), appType: 'command_center', data });
        res.json({ success: true, timestamp: Date.now() });
      } catch (error: any) {
        console.error("Mining bridge publish error:", error.message);
        res.status(500).json({ message: 'Failed to publish signals' });
      }
    });

    app.get("/api/mining-bridge/signals", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const data = miningSignalStore.get(userId);
        if (!data) {
          return res.json({ connected: false, data: null });
        }
        const age = Date.now() - data.timestamp;
        if (age > SIGNAL_TTL) {
          return res.json({ connected: false, stale: true, lastUpdate: data.timestamp, data: null });
        }
        res.json({ connected: true, age, lastUpdate: data.timestamp, data });
      } catch (error: any) {
        console.error("Mining bridge signals fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch signals' });
      }
    });

    app.get("/api/mining-bridge/status", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const userId = String((req.user as any).id);
      const data = miningSignalStore.get(userId);
      res.json({
        hasSignals: !!data,
        lastUpdate: data?.timestamp ?? null,
        age: data ? Date.now() - data.timestamp : null,
        isStale: data ? (Date.now() - data.timestamp) > SIGNAL_TTL : true,
      });
    });

    app.post("/api/mining-bridge/fusion/publish", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const { appType, data } = req.body;
        if (!appType || !VALID_APP_TYPES.includes(appType)) {
          return res.status(400).json({ message: `Invalid appType. Must be one of: ${VALID_APP_TYPES.join(', ')}` });
        }
        const store = getUserFusionStore(userId);
        store.set(appType, { timestamp: Date.now(), appType, data: data || {} });
        if (appType === 'command_center' && data) {
          miningSignalStore.set(userId, {
            timestamp: Date.now(),
            windowScore: data.windowScore ?? 0,
            signal: data.signal ?? 'HOLD',
            entropyDeviation: data.entropyDeviation ?? '0',
            avgBitDist: data.avgBitDist ?? '0',
            chiSquared: data.chiSquared ?? '0',
            avgLeadingZeros: data.avgLeadingZeros ?? '0',
            anomalyCount: data.anomalyCount ?? 0,
            strongCorrs: data.strongCorrs ?? 0,
            blockCount: data.blockCount ?? 0,
            sbpeMetrics: data.sbpeMetrics ?? null,
            solvingMetrics: data.solvingMetrics ?? null,
            feedItems: (data.feedItems ?? []).slice(0, 20),
            difficultyTrend: data.difficultyTrend ?? 'stable',
            mod3Entropy: data.mod3Entropy ?? '0',
          });
        }
        res.json({ success: true, timestamp: Date.now(), appType });
      } catch (error: any) {
        console.error("Fusion signal publish error:", error.message);
        res.status(500).json({ message: 'Failed to publish fusion signal' });
      }
    });

    app.get("/api/mining-bridge/fusion/signals", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const fromApp = req.query.from as BridgeAppType | undefined;
        const store = getUserFusionStore(userId);
        const now = Date.now();
        const signals: Record<string, any> = {};
        let activeCount = 0;
        const entries = Array.from(store.entries());
        for (const [app, entry] of entries) {
          if (fromApp && app === fromApp) continue;
          const age = now - entry.timestamp;
          if (age > SIGNAL_TTL) {
            signals[app] = { connected: false, stale: true, lastUpdate: entry.timestamp };
          } else {
            signals[app] = { connected: true, age, lastUpdate: entry.timestamp, data: entry.data };
            activeCount++;
          }
        }
        res.json({ fusionActive: activeCount >= 2, activeApps: activeCount, totalApps: store.size, signals });
      } catch (error: any) {
        console.error("Fusion signals fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch fusion signals' });
      }
    });

    app.post("/api/mining-bridge/fusion/heartbeat", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const { appType, status, metrics } = req.body;
        if (!appType || !VALID_APP_TYPES.includes(appType)) {
          return res.status(400).json({ message: "Invalid appType" });
        }
        const hbStore = getUserHeartbeatStore(userId);
        hbStore.set(appType, { timestamp: Date.now(), status: status || 'active', metrics: metrics || {} });
        res.json({ success: true, timestamp: Date.now() });
      } catch (error: any) {
        console.error("Fusion heartbeat error:", error.message);
        res.status(500).json({ message: 'Failed to send heartbeat' });
      }
    });

    app.get("/api/mining-bridge/fusion/heartbeats", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const hbStore = getUserHeartbeatStore(userId);
        const now = Date.now();
        const heartbeats: Record<string, any> = {};
        const hbEntries = Array.from(hbStore.entries());
        for (const [app, hb] of hbEntries) {
          const age = now - hb.timestamp;
          heartbeats[app] = {
            ...hb,
            age,
            alive: age < 10000,
            warning: age >= 6000 && age < 10000,
            dead: age >= 10000,
          };
        }
        res.json({ heartbeats, timestamp: now });
      } catch (error: any) {
        console.error("Fusion heartbeats fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch heartbeats' });
      }
    });

    app.post("/api/mining-bridge/fusion/conflict", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const { apps, conflictType, resolution, resolvedBy } = req.body;
        const log = getUserConflictLog(userId);
        const entry = { timestamp: Date.now(), apps: apps || [], conflictType: conflictType || 'unknown', resolution: resolution || '', resolvedBy: resolvedBy || 'guardian' };
        log.push(entry);
        if (log.length > 100) log.splice(0, log.length - 100);
        res.json({ success: true, logged: entry });
      } catch (error: any) {
        console.error("Fusion conflict log error:", error.message);
        res.status(500).json({ message: 'Failed to log conflict' });
      }
    });

    app.get("/api/mining-bridge/fusion/conflicts", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const log = getUserConflictLog(userId);
        const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);
        res.json({ conflicts: log.slice(-limit), total: log.length });
      } catch (error: any) {
        console.error("Fusion conflicts fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch conflicts' });
      }
    });

    app.get("/api/mining-bridge/fusion/status", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      try {
        const userId = String((req.user as any).id);
        const signalStore = getUserFusionStore(userId);
        const hbStore = getUserHeartbeatStore(userId);
        const conflictLog = getUserConflictLog(userId);
        const now = Date.now();
        const apps: Record<string, any> = {};
        for (let i = 0; i < VALID_APP_TYPES.length; i++) {
          const appType = VALID_APP_TYPES[i];
          const signal = signalStore.get(appType);
          const hb = hbStore.get(appType);
          const signalAge = signal ? now - signal.timestamp : null;
          const hbAge = hb ? now - hb.timestamp : null;
          apps[appType] = {
            signalActive: signal ? signalAge! < SIGNAL_TTL : false,
            heartbeatAlive: hb ? hbAge! < 10000 : false,
            lastSignal: signal?.timestamp ?? null,
            lastHeartbeat: hb?.timestamp ?? null,
            status: hb?.status ?? 'offline',
          };
        }
        const activeApps = Object.values(apps).filter((a: any) => a.signalActive || a.heartbeatAlive).length;
        const fusionMode = activeApps >= 4 ? 'full' : activeApps >= 3 ? 'partial' : activeApps >= 2 ? 'dual' : 'standalone';
        res.json({
          fusionMode,
          activeApps,
          totalApps: VALID_APP_TYPES.length,
          apps,
          recentConflicts: conflictLog.slice(-5).length,
          bridgeHealth: activeApps >= 4 ? 'optimal' : activeApps >= 2 ? 'good' : 'degraded',
        });
      } catch (error: any) {
        console.error("Fusion status fetch error:", error.message);
        res.status(500).json({ message: 'Failed to fetch fusion status' });
      }
    });

    app.get("/api/miners", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const miners = await db.select().from(connectedMiners).where(eq(connectedMiners.userId, userId));
        res.json(miners);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const { name, ipAddress, port, protocol } = req.body;
        if (!name || !ipAddress) return res.status(400).json({ message: "Name and IP address required" });
        const ipCheck = validateMinerIP(ipAddress);
        if (!ipCheck.valid) return res.status(400).json({ message: ipCheck.error });
        const [miner] = await db.insert(connectedMiners).values({
          userId,
          name,
          ipAddress,
          port: port || 80,
          protocol: protocol || "bitaxe",
          isActive: true,
          autoAdjust: false,
        }).returning();
        res.json(miner);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.delete("/api/miners/:id", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        await db.delete(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        res.json({ success: true });
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.patch("/api/miners/:id", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const updates = req.body;
        const [updated] = await db.update(connectedMiners)
          .set(updates)
          .where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)))
          .returning();
        res.json(updated);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/detect", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const { ipAddress } = req.body;
        if (!ipAddress) return res.status(400).json({ message: "IP address required" });
        const ipCheck = validateMinerIP(ipAddress);
        if (!ipCheck.valid) return res.status(400).json({ message: ipCheck.error });
        const result = await autoDetectMiner(ipAddress);
        if (result) {
          res.json({ detected: true, ...result });
        } else {
          res.json({ detected: false, message: "No miner detected at this address" });
        }
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/scan", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const { baseIp, startOctet, endOctet } = req.body;
        if (!baseIp) return res.status(400).json({ message: "Base IP required" });
        const ipCheck = validateMinerIP(baseIp);
        if (!ipCheck.valid) return res.status(400).json({ message: ipCheck.error });
        const start = startOctet ?? 1;
        const end = Math.min(endOctet ?? 254, start + 50);
        const results = await scanSubnet(baseIp, start, end);
        res.json(results);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.get("/api/miners/:id/status", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const [miner] = await db.select().from(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        if (!miner) return res.status(404).json({ message: "Miner not found" });
        const status = await getMinerStatus(miner.ipAddress, miner.port, miner.protocol as any);
        if (status.online) {
          await db.update(connectedMiners).set({
            lastSeen: new Date(),
            model: status.boardVersion || status.chipModel || miner.model,
            firmwareVersion: status.firmwareVersion || miner.firmwareVersion,
          }).where(eq(connectedMiners.id, minerId));
        }
        res.json({ miner, status });
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/:id/adjust", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const [miner] = await db.select().from(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        if (!miner) return res.status(404).json({ message: "Miner not found" });
        const settings = req.body;
        const result = await adjustBitaxe(miner.ipAddress, miner.port, settings);
        res.json(result);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/:id/restart", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const [miner] = await db.select().from(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        if (!miner) return res.status(404).json({ message: "Miner not found" });
        const result = await restartMiner(miner.ipAddress, miner.port, miner.protocol as any);
        res.json(result);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/:id/identify", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const [miner] = await db.select().from(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        if (!miner) return res.status(404).json({ message: "Miner not found" });
        const result = await identifyMiner(miner.ipAddress, miner.port, miner.protocol as any);
        res.json(result);
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });

    app.post("/api/miners/:id/auto-adjust", async (req, res) => {
      if (!req.isAuthenticated() || !req.user) return res.status(401).json({ message: "Unauthorized" });
      try {
        const userId = String((req.user as any).id);
        const minerId = parseInt(req.params.id);
        const [miner] = await db.select().from(connectedMiners).where(and(eq(connectedMiners.id, minerId), eq(connectedMiners.userId, userId)));
        if (!miner) return res.status(404).json({ message: "Miner not found" });
  
        const bridgeData = miningSignalStore.get(userId);
        if (!bridgeData || (Date.now() - bridgeData.timestamp) > 600000) {
          return res.json({ adjusted: false, reason: "No active Command Center signals" });
        }
  
        const status = await getMinerStatus(miner.ipAddress, miner.port, miner.protocol as any);
        if (!status.online) {
          return res.json({ adjusted: false, reason: "Miner is offline" });
        }
  
        const adjustment = computeAutoAdjustSettings(bridgeData.signal, bridgeData.windowScore, status, miner.protocol as any);
        if (!adjustment) {
          return res.json({ adjusted: false, reason: "No adjustment needed for current conditions" });
        }
  
        if (adjustment.settings) {
          await adjustBitaxe(miner.ipAddress, miner.port, adjustment.settings);
        }
        res.json({ adjusted: true, ...adjustment });
      } catch (e: any) {
        res.status(500).json({ message: e.message });
      }
    });
}
