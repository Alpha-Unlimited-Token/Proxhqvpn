# Wiring Guide — Plugging the Mining Stack into a New Project

This walks you through every connection point you need to fix when you move
the package out of its parent app.

---

## Step 1 — Drop the package in

Unzip into the root of your destination project:

```
your-project/
├── client/
├── server/
├── package.json
└── mining-tech-package/    ← unzipped here
```

You can either keep `mining-tech-package/` as a sub-directory or merge its
contents into your existing `client/` and `server/` trees. The instructions
below assume you keep it as a sub-directory (cleanest separation).

---

## Step 2 — Install dependencies

```bash
npm install \
  ethers@^6.13.4 \
  express \
  drizzle-orm pg \
  ws \
  node-fetch@^3 \
  crypto-js \
  solc \
  @sendgrid/mail
```

If you'll run the deploy scripts you also need:

```bash
npm install --save-dev tsx typescript @types/node @types/express
```

The exact versions used in production are listed in `package.deps.json`.

---

## Step 3 — Environment variables

Copy `ENV_TEMPLATE.env` to your `.env` and fill in:

```dotenv
# REQUIRED
ALCHEMY_API_KEY=...                # multi-chain RPC (EVM + SOL)
DATABASE_URL=postgres://...        # Postgres for miners/blocks/etc.

# REQUIRED for on-chain ATC / DAUv2 deploy & broadcast
ATC_DEPLOYER_PRIVATE_KEY=0x...     # funded ETH wallet (mainnet or Sepolia)

# OPTIONAL — only if you keep the email alerts wired
SENDGRID_API_KEY=SG....

# OPTIONAL — only if you keep the proprietary guard active
ALPHA_LICENSE_PATH=./private/security/.alpha_license.json
```

---

## Step 4 — Fix import paths

Every file in this package uses paths relative to the parent project's layout
(`server/services/...`, `@shared/schema`, etc.). When you move them, update:

### 4a. Server-side files

The mining services import these from the parent project:

```typescript
// FROM (parent project):
import { storage } from '../storage';
import { db } from '../db';
import { miners, blocks } from '@shared/schema';

// TO (your new project):
import { storage } from '<your-storage-module>';
import { db } from '<your-db-module>';
import { miners, blocks } from '<your-schema-module>';
```

A quick `rg` to find every import you'll need to fix:

```bash
rg -n "from '\.\./|from '@shared|from '@/" mining-tech-package/server/
```

### 4b. Frontend files

```typescript
// FROM:
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// TO:
import { Button } from '<your-button>';
import { useToast } from '<your-toast-hook>';
import { apiRequest } from '<your-fetch-wrapper>';
```

The pages depend on shadcn/ui (Button, Card, Tabs, Input, …) and TanStack
Query. If your destination project uses a different UI library, the pages are
the most surgical to migrate — most state and logic is already factored into
`client/src/lib/mining/` and `client/src/lib/qmge/` which have **no UI deps**.

---

## Step 5 — Mount the routes

```typescript
// your-project/server/index.ts
import express from 'express';
import { registerMiningRoutes } from '../mining-tech-package/routes-extracted/mining-routes';

const app = express();
app.use(express.json());

// Whatever auth middleware you use:
function isAuthenticated(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'unauthorized' });
  next();
}

// Optional rate-limiters — pass `undefined` to skip
import rateLimit from 'express-rate-limit';
const downloadRateLimit    = rateLimit({ windowMs: 60_000, max: 10 });
const miningDataRateLimit  = rateLimit({ windowMs: 1_000, max: 30 });
const proprietaryRateLimit = rateLimit({ windowMs: 60_000, max: 60 });

registerMiningRoutes(app, {
  isAuthenticated,
  downloadRateLimit,
  miningDataRateLimit,
  proprietaryRateLimit,
});

app.listen(5000);
```

---

## Step 6 — Boot the L1 chain (optional)

Only do this if you want to run the **own custom blockchain** — you can also
use only the external-chain adapters and skip the L1.

```typescript
import { initBlockchain } from '../mining-tech-package/server/blockchain';
import { startStratumServer } from '../mining-tech-package/server/blockchain/stratum';
import { startP2PNode } from '../mining-tech-package/server/blockchain/p2p';

await initBlockchain();                      // load chain from DB, start mempool
startStratumServer({ port: 3333 });          // accept miners on tcp/3333
startP2PNode({ port: 6000, peers: [...] }); // gossip with other nodes
```

Add a workflow / process-manager entry so it stays up:

```bash
# replit.toml / Procfile / pm2:
node --import tsx ./your-project/server/index.ts
```

---

## Step 7 — Run the on-chain listeners (optional)

If you're keeping ATC / DAUv2 forensic events flowing in:

```bash
# In its own long-running process:
npx tsx mining-tech-package/contracts/atc/listener.ts        &
npx tsx mining-tech-package/contracts/atc/DAUv2_Listener.ts  &
```

You can re-deploy the contracts to your own addresses with:

```bash
npx tsx mining-tech-package/contracts/atc/compile.ts         # produces artifacts
npx tsx mining-tech-package/contracts/atc/deploy.ts          # uses ATC_DEPLOYER_PRIVATE_KEY
```

After deployment, update the addresses in `contracts/atc/deployments/*.json`
so the listeners point at your contracts.

---

## Step 8 — Mount the frontend pages

```typescript
// wouter:
import { Route } from 'wouter';
import MiningCommandCenter from '../mining-tech-package/client/src/pages/MiningCommandCenter';
import AlphaForge          from '../mining-tech-package/client/src/pages/AlphaForge';
import AlphaBlockchain     from '../mining-tech-package/client/src/pages/AlphaBlockchain';
import QMGEStandalone      from '../mining-tech-package/client/src/pages/QMGEStandalone';

<Route path="/mining"     component={MiningCommandCenter} />
<Route path="/forge"      component={AlphaForge} />
<Route path="/blockchain" component={AlphaBlockchain} />
<Route path="/qmge"       component={QMGEStandalone} />
```

For QMGE PWA:

```html
<!-- public/index.html -->
<link rel="manifest" href="/manifest-miner.json" />
```

Copy `client/public/manifest-miner.json` to your `public/` directory.

---

## Step 9 — Schema migration

If you use Drizzle, append these tables to your `shared/schema.ts`:

```typescript
import { pgTable, serial, varchar, integer, bigint, text, timestamp, boolean, jsonb } from 'drizzle-orm/pg-core';

export const miners = pgTable('miners', {
  id:            serial('id').primaryKey(),
  userId:        varchar('user_id'),
  name:          varchar('name', { length: 64 }),
  hardwareSpec:  jsonb('hardware_spec'),
  address:       varchar('address', { length: 64 }),
  status:        varchar('status', { length: 16 }),  // active|paused|offline
  createdAt:     timestamp('created_at').defaultNow(),
});

export const blocks = pgTable('blocks', {
  height:    integer('height').primaryKey(),
  hash:      varchar('hash', { length: 66 }),
  prevHash:  varchar('prev_hash', { length: 66 }),
  miner:     varchar('miner', { length: 64 }),
  txCount:   integer('tx_count'),
  ts:        timestamp('ts'),
  raw:       jsonb('raw'),
});

export const transactions = pgTable('transactions', {
  hash:        varchar('hash', { length: 66 }).primaryKey(),
  blockHeight: integer('block_height'),
  fromAddr:    varchar('from_addr', { length: 64 }),
  toAddr:      varchar('to_addr', { length: 64 }),
  value:       bigint('value', { mode: 'bigint' }),
  fee:         bigint('fee',   { mode: 'bigint' }),
  ts:          timestamp('ts'),
});

export const beacons = pgTable('beacons', {
  id:          serial('id').primaryKey(),
  minerId:     integer('miner_id'),
  blockHeight: integer('block_height'),
  sig:         text('sig'),
  anchored:    boolean('anchored').default(false),
  ts:          timestamp('ts').defaultNow(),
});

export const spiderEvents = pgTable('spider_events', {
  id:          serial('id').primaryKey(),
  kind:        varchar('kind', { length: 32 }),    // reorg|orphan|equivocation
  blockHeight: integer('block_height'),
  detail:      jsonb('detail'),
  severity:    integer('severity'),
  ts:          timestamp('ts').defaultNow(),
});

export const qmgeLicenses = pgTable('qmge_licenses', {
  userId:     varchar('user_id').primaryKey(),
  licenseKey: varchar('license_key', { length: 64 }),
  tier:       varchar('tier', { length: 16 }),
  status:     varchar('status', { length: 16 }),
  expiresAt:  timestamp('expires_at'),
});
```

Then `npm run db:push` (or your equivalent) to materialize them.

---

## Step 10 — Smoke test

```bash
# 1. Server boots
curl http://localhost:5000/api/blockchain/blocks | jq .

# 2. Add a miner
curl -X POST http://localhost:5000/api/miners \
  -H 'content-type: application/json' \
  -d '{"name":"test-rig","hardwareSpec":{"gpu":"RTX 4090"}}'

# 3. Stratum server up
nc -v localhost 3333
# expect: stratum welcome handshake

# 4. Mining-bridge accepts signals
curl -X POST http://localhost:5000/api/mining-bridge/publish \
  -H 'content-type: application/json' \
  -d '{"signal":"test","ts":1234567890}'
```

If all four return non-error responses, you're wired up.

---

## Replace-an-engine recipes

### Recipe A — Use Alpha mining infra to drive an *AI inference* engine

Treat each "share" as a tiny model evaluation, each "block" as an aggregated
result.

1. Edit `server/blockchain/consensus.ts`:
   - Replace `validateBlockProof` with `validateInferenceResult(block)` that
     verifies a signed inference batch against expected outputs.
2. Edit `server/blockchain/stratum.ts`:
   - On `mining.submit`, instead of computing `sha256` and checking against a
     target, validate the inference output and pay out per-correct-result.
3. Edit `client/src/lib/mining/coordinator.ts`:
   - Replace the nonce loop with a call to your local model
     (`onnxruntime-web`, `transformers.js`, etc.).

Everything else (DB, payouts, UI dashboards, P2P gossip, on-chain anchoring)
keeps working unchanged.

### Recipe B — Use the chain-adapter layer for a forensic-only project

If you don't need the L1 chain or stratum pool, just lift `chain-adapters/`:

```typescript
import { getAdapter } from './mining-tech-package/server/services/chain-adapters';

const eth = getAdapter('ethereum');
const sol = getAdapter('solana');

const ethTxs = await eth.getTransactions('0x...');
const solTxs = await sol.getTransactions('Abc...');
```

That's a 7-file, 35-KB self-contained multi-chain client.

### Recipe C — Use QMGE as a mempool-fee optimizer

`client/src/lib/qmge/engine.ts` already takes a list of pending txs and
returns an optimized ordering. Wrap it with your own job-template input and
you have a generic block-template builder.
