# ProxhqVPN Installer Technical Audit

Scope: Windows, macOS, Linux, Android, iOS installer/setup files from `ProxhqVPN-Installer-Code.zip`.

## Architecture-level inconsistencies across all 5 installers

| Severity | Finding | Fix |
|---|---|---|
| Critical | Windows installs all tunnels through `wireguard.exe /installtunnel`, but macOS/Linux use `wg-quick up` during install. That leaves multiple tunnels active or partly active and does not provide the same “install all, connect one, switch later” model. | Save all configs, stop all ProxhqVPN tunnels, then activate only one selected/default tunnel. On Linux optionally enable only the active tunnel's `wg-quick@name` service. |
| Critical | Split-tunnel rewriting is inconsistent and can corrupt configs. Linux removes the `AllowedIPs` line then appends outside the `[Peer]` block; macOS sed can leave malformed or empty values. | Replace exactly the peer `AllowedIPs` line with `AllowedIPs = 10.8.0.0/24`; if absent, insert within `[Peer]`. Keep IPv6 handling explicit. |
| Warning | Windows writes `config.json`; macOS writes malformed JSON for installed tunnels; Linux does not write `config.json` at all. | Write valid JSON on all desktop platforms with `tunnelMode`, `hostname`, `version`, `configDir`, `installedTunnels`, and `activeTunnel`. |
| Warning | Windows creates Add/Remove Programs entry and shortcuts; macOS/Linux only create desktop launchers. Linux has no desktop switcher `.desktop` file, no config metadata, and no clean uninstall script. | Add Linux config metadata, app/switcher `.desktop` launchers, and an optional uninstall script or package-uninstall instructions. macOS should create a local app folder copy plus desktop `.command`. |
| Warning | Windows has a live Done-screen switcher. macOS/Linux only provide terminal switchers. | Acceptable platform difference, but finish screen should clearly point to switcher and validate it was created. |
| Suggestion | Mobile HTML flows are only guide pages, not true equivalents to the 6-step installer flow. | Label as manual mobile setup. Add error/help states, a fixed 6-step structure, and direct dashboard/config links. |

---

## Windows/Install.ps1

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Critical | Done-card click handler is built with `scriptblock::Create("SwitchOnDone '$sname' '$spath'")`. A tunnel name/path containing a quote can break the script block; it is also unnecessary dynamic code. | 350-353 | Attach data to the card and use a closure/click handler, like `SwitchServer.ps1` does. |
| Warning | `Start-Process -ArgumentList "/uninstalltunnel $tn"` does not quote tunnel names. It will break if a generated config name contains spaces or unexpected characters. | 375, 604 | Quote argument values or pass an array. |
| Warning | Existing `proxhqvpn-all-servers.zip` is not ignored despite `$existingZip` being calculated. A stale zip in Downloads can be silently installed. | 515 | Record original file timestamp/length and require a newer completed download, or prompt before using existing zip. |
| Warning | Fallback `.NET` extraction uses `ExtractToDirectory($zipPath,$WG_DIR)` without overwrite handling, so it can fail after `Expand-Archive` partially extracts files. | 565 | Extract to a temp folder first, then copy verified `.conf` files into `WG_DIR`. |
| Warning | Split-tunnel regex only rewrites `0.0.0.0/0`; if a config has IPv6-only `::/0` or a different AllowedIPs format, it may not be normalized. | 593-597 | Use a config-aware `Set-AllowedIPs` function. |
| Warning | Add/Remove Programs registration lacks `UninstallString`, so it appears without a working uninstall action. | 471-477 | Add an uninstall script and set `UninstallString`. |
| Warning | Desktop shortcut target is a URL; Windows Shell shortcuts to URLs are more reliable as `.url` files or `explorer.exe <url>`. | 460-462 | Use `explorer.exe` with arguments or create `.url`. |
| Suggestion | `WebClient` is obsolete, though still functional in Windows PowerShell. | 419 | Prefer `Invoke-WebRequest` first, keep WebClient fallback for legacy hosts. |
| Suggestion | No zip authenticity/integrity check. | 557 | At minimum verify files are `.conf`, contain `[Interface]` and `[Peer]`, and do not write outside target directory. |

### Corrected code blocks

#### Safe Done-card click handling
```powershell
# Replace lines 350-353 in BuildDoneGrid
$card | Add-Member -NotePropertyName "_server" -NotePropertyValue $s -Force
$card.Add_Click({ SwitchOnDone $this._server.name $this._server.path })
foreach($child in $card.Controls){
    $child | Add-Member -NotePropertyName "_card" -NotePropertyValue $card -Force
    $child.Add_Click({ SwitchOnDone $this._card._server.name $this._card._server.path })
}
```

#### Quote WireGuard arguments safely
```powershell
function Invoke-WireGuard($Arguments) {
    if (-not (Test-Path $WG_EXE)) { throw "wireguard.exe not found at $WG_EXE" }
    $p = Start-Process -FilePath $WG_EXE -ArgumentList $Arguments -PassThru -Wait -ErrorAction Stop
    return $p.ExitCode
}

# Uninstall
[void](Invoke-WireGuard @('/uninstalltunnel', $tn))

# Install
$exit = Invoke-WireGuard @('/installtunnel', $cf.FullName)
```

#### Robust split-tunnel rewrite for Windows
```powershell
function Set-ProxhqAllowedIPs([string]$Path, [string]$Mode) {
    $text = [IO.File]::ReadAllText($Path)
    if ($Mode -eq 'split') { $allowed = '10.8.0.0/24' } else { $allowed = '0.0.0.0/0, ::/0' }

    if ($text -match '(?m)^AllowedIPs\s*=') {
        $text = [regex]::Replace($text, '(?m)^AllowedIPs\s*=.*$', "AllowedIPs = $allowed")
    } elseif ($text -match '(?m)^\[Peer\]\s*$') {
        $text = [regex]::Replace($text, '(?m)^\[Peer\]\s*$', "[Peer]`r`nAllowedIPs = $allowed", 1)
    } else {
        throw "No [Peer] section found in $Path"
    }
    [IO.File]::WriteAllText($Path, $text, [Text.UTF8Encoding]::new($false))
}
```

#### Avoid stale zip reuse
```powershell
$zipPath = Join-Path $dlDir $zipTarget
$baseline = $null
if (Test-Path $zipPath) { $baseline = Get-Item $zipPath }

# inside loop after Test-Path
$item = Get-Item $zipPath -ErrorAction SilentlyContinue
if ($item -and (-not $baseline -or $item.LastWriteTimeUtc -gt $baseline.LastWriteTimeUtc -or $item.Length -ne $baseline.Length)) {
    $sz1 = $item.Length
    Start-Sleep -Milliseconds 1000
    $item2 = Get-Item $zipPath -ErrorAction SilentlyContinue
    if ($item2 -and $item2.Length -eq $sz1 -and $sz1 -gt 0) { $foundZip = $zipPath; break }
}
```

#### Working uninstall registry entry
```powershell
$uninstallPs1 = Join-Path $INSTALL 'Uninstall-ProxhqVPN.ps1'
@"
`$wg = '$WG_EXE'
`$confDir = '$WG_DIR'
if (Test-Path `$wg) {
  Get-ChildItem `$confDir -Filter 'proxhqvpn-*.conf' -ErrorAction SilentlyContinue | ForEach-Object {
    Start-Process -FilePath `$wg -ArgumentList @('/uninstalltunnel', `$_.BaseName) -Wait -ErrorAction SilentlyContinue
  }
}
Remove-Item '$INSTALL' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ProxhqVPN' -Recurse -Force -ErrorAction SilentlyContinue
"@ | Set-Content -Path $uninstallPs1 -Encoding UTF8
Set-ItemProperty $reg 'UninstallString' "powershell.exe -ExecutionPolicy Bypass -File `"$uninstallPs1`""
```

---

## Windows/SwitchServer.ps1

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Warning | `/uninstalltunnel $($s2.name)` argument is not safely quoted. | 143 | Use an argument array. |
| Warning | Active tunnel detection returns the first WireGuard interface, not necessarily a ProxhqVPN tunnel. | 60-66 | Filter to `proxhqvpn-*`. |
| Warning | `$clickFn` is declared but unused. | 180 | Remove dead code. |
| Suggestion | No disconnect-only button in GUI. | whole file | Add a “Disconnect” button for parity with Linux/macOS switchers. |

### Corrected code blocks
```powershell
function GetActiveTunnel {
    if (-not (Test-Path $WG_EXE)) { return $null }
    try {
        $out = & $WG_EXE /show 2>&1
        foreach ($line in $out) {
            if ($line -match '^interface:\s*(proxhqvpn-.+)$') { return $Matches[1].Trim() }
        }
    } catch {}
    return $null
}

function Invoke-Wg($args) {
    $p = Start-Process -FilePath $WG_EXE -ArgumentList $args -PassThru -Wait -ErrorAction Stop
    return $p.ExitCode
}

# Stop all
foreach ($s2 in $servers) { try { [void](Invoke-Wg @('/uninstalltunnel', $s2.name)) } catch {} }

# Start selected
$ok = ((Invoke-Wg @('/installtunnel', $server.path)) -eq 0)
```

---

## Windows/Launch-ProxhqVPN-Setup.vbs

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Suggestion | Hidden PowerShell window can obscure errors if script fails before GUI loads. | 5 | Use normal window during debugging or write errors to a log. |
| Suggestion | No check that `Install.ps1` exists. | 3-5 | Show a message if missing. |

### Corrected code block
```vbscript
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = dir & "\Install.ps1"
If Not fso.FileExists(ps1) Then
  MsgBox "Install.ps1 was not found next to this launcher.", 16, "ProxhqVPN Setup"
  WScript.Quit 1
End If
cmd = "powershell.exe -ExecutionPolicy Bypass -File """ & ps1 & """"
sh.Run cmd, 1, False
```

---

## macOS/Install-macOS.sh

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Critical | `dlg`, `dlg2`, `choose` interpolate user-controlled strings into AppleScript without escaping. Hostname/paths/messages containing quotes can break the osascript command. | 36-42 | Use `osascript` argv and `on run argv` blocks. |
| Critical | `mapfile` is not available in the default Bash 3.2 shipped with macOS. | 272 | Replace with `while IFS= read -r`. |
| Critical | Homebrew-installed `wireguard-tools` is CLI-only. `wg-quick up` on macOS often requires `wireguard-go`/utun support and may fail silently; fallback to WireGuard.app is not actually imported. | 305-317 | Save configs and give explicit WireGuard.app import path if CLI activation fails. |
| Warning | `WG_QUICK="${WG_BIN%wg}wg-quick"` returns `app-quick` when `WG_BIN="app"`. | 186 | Only derive `WG_QUICK` when `WG_BIN` is a path ending in `/wg`. |
| Warning | Split tunnel `sed -i ''` can remove the value and leave invalid `AllowedIPs =`. It also appends outside `[Peer]`. | 292-295 | Use a config-aware function. |
| Warning | `config.json` generation is malformed: `installedTunnels` uses a pipe-delimited `name|path` string and a fragile `printf|sed|xargs` expression. | 325-331 | Generate JSON with Python or `osascript -l JavaScript`; include structured objects. |
| Warning | Zip is extracted to temp, but config file validation is minimal. | 267-279 | Validate file extension, basename, and `[Interface]`/`[Peer]`. |
| Warning | `open "$SIGNIN_URL"` exit status is not checked. | 208 | If `open` fails, print URL and continue. |
| Suggestion | Directly downloading `WireGuard-macos.dmg` from `download.wireguard.com/mac-client/` may be brittle. The official App Store app does not guarantee CLI tools. | 158-166 | Prefer Homebrew CLI route; otherwise tell user to install WireGuard.app manually and import configs. |
| Suggestion | `xattr -d` removes only one attribute; launcher uses `xattr -cr`. | 341, 351 | Use `xattr -cr` consistently. |

### Corrected code blocks

#### Safe osascript helpers
```bash
osascript_dialog() {
  local message=$1 primary=${2:-Continue} secondary=${3:-}
  if [[ -n "$secondary" ]]; then
    osascript "$@" <<'OSA'
on run argv
  set msg to item 1 of argv
  set b1 to item 2 of argv
  set b2 to item 3 of argv
  display dialog msg buttons {b1, b2} default button b1 cancel button b2 with title "ProxhqVPN Setup" with icon note
end run
OSA
  else
    osascript "$message" "$primary" <<'OSA'
on run argv
  display dialog (item 1 of argv) buttons {(item 2 of argv)} default button (item 2 of argv) with title "ProxhqVPN Setup" with icon note
end run
OSA
  fi
}
notify() {
  osascript "$1" <<'OSA' 2>/dev/null || true
on run argv
  display notification (item 1 of argv) with title "ProxhqVPN"
end run
OSA
}
```

#### Bash 3.2-compatible file collection
```bash
CONF_FILES=()
while IFS= read -r -d '' file; do
  CONF_FILES+=("$file")
done < <(find "$TMP_EXTRACT" -type f -name 'proxhqvpn-*.conf' -print0 2>/dev/null)
```

#### Robust macOS/Linux AllowedIPs function
```bash
set_allowed_ips() {
  local file=$1 mode=$2 allowed
  if [[ "$mode" == "split" ]]; then allowed="10.8.0.0/24"; else allowed="0.0.0.0/0, ::/0"; fi
  python3 - "$file" "$allowed" <<'PY'
import pathlib, re, sys
path = pathlib.Path(sys.argv[1])
allowed = sys.argv[2]
text = path.read_text()
if '[Peer]' not in text:
    raise SystemExit(f'No [Peer] section in {path}')
if re.search(r'(?m)^AllowedIPs\s*=', text):
    text = re.sub(r'(?m)^AllowedIPs\s*=.*$', f'AllowedIPs = {allowed}', text)
else:
    text = re.sub(r'(?m)^\[Peer\]\s*$', f'[Peer]\nAllowedIPs = {allowed}', text, count=1)
path.write_text(text)
PY
}
```

#### Valid `config.json` writer
```bash
write_config_json() {
  mkdir -p "$INSTALL"
  python3 - "$INSTALL/config.json" "$TUNNEL_MODE" "$(hostname -s)" "$WG_CONF_DIR" "$ACTIVE_TUNNEL" "${CONFS_INSTALLED[@]}" <<'PY'
import json, sys
out, mode, host, confdir, active, *items = sys.argv[1:]
tunnels=[]
for item in items:
    name, _, path = item.partition('|')
    tunnels.append({'name': name, 'path': path})
with open(out, 'w', encoding='utf-8') as f:
    json.dump({'tunnelMode': mode, 'hostname': host, 'version': '5.0', 'configDir': confdir, 'activeTunnel': active, 'installedTunnels': tunnels}, f, indent=2)
PY
}
```

---

## macOS/SwitchServer-macOS.sh

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Critical | Uses `mapfile`, not available in default macOS Bash 3.2. | 32 | Replace with `while read` array collection. |
| Warning | Only checks `/usr/local/bin` then `/opt/homebrew/bin`; Apple Silicon Homebrew should be checked first. | 22 | Check `/opt/homebrew/bin` before `/usr/local/bin`; also use `command -v`. |
| Warning | If installer saved configs under `~/Library/Application Support/ProxhqVPN/tunnels`, paths with spaces are fine in `find`, but `wg-quick down "$N"` may fail if the tunnel was started by path and not name. | 103 | Use config path for down where possible, or use interface names from `wg show interfaces`. |
| Warning | `osascript` notification interpolates `$SEL_NAME` unsafely. | 110 | Use argv-based osascript. |
| Suggestion | Error says “administrator,” Windows wording. | 113 | Use “administrator/root password” or “sudo permission.” |

### Corrected code blocks
```bash
WG_QUICK="$(command -v wg-quick || true)"
for loc in /opt/homebrew/bin/wg-quick /usr/local/bin/wg-quick /usr/bin/wg-quick; do
  [[ -z "$WG_QUICK" && -x "$loc" ]] && WG_QUICK="$loc"
done

CONFIGS=()
while IFS= read -r -d '' file; do CONFIGS+=("$file"); done < <(find "$WG_CONF_DIR" -type f -name 'proxhqvpn-*.conf' -print0 2>/dev/null | sort -z)

notify_connected() {
  osascript "$1" <<'OSA' 2>/dev/null || true
on run argv
  display notification ("Connected to " & item 1 of argv) with title "ProxhqVPN"
end run
OSA
}
```

---

## macOS/Launch-ProxhqVPN-Setup.command

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Warning | Removes quarantine recursively from the entire folder. That is convenient but overly broad. | 10 | Limit to ProxhqVPN scripts, or keep but disclose. |
| Suggestion | No existence check for `Install-macOS.sh`. | 13-16 | Show a readable error if missing. |

### Corrected code block
```bash
#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALLER="$DIR/Install-macOS.sh"
if [[ ! -f "$INSTALLER" ]]; then
  osascript -e 'display dialog "Install-macOS.sh was not found next to this launcher." buttons {"Close"} with icon stop' 2>/dev/null || echo "Install-macOS.sh missing."
  exit 1
fi
xattr -d com.apple.quarantine "$INSTALLER" "$DIR/SwitchServer-macOS.sh" 2>/dev/null || true
chmod +x "$INSTALLER" "$DIR/SwitchServer-macOS.sh" 2>/dev/null || true
clear 2>/dev/null || true
exec /bin/bash "$INSTALLER"
```

---

## Linux/Install-Linux.sh

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Critical | If `/etc/wireguard` is not writable, script switches to `~/.config/wireguard`, then still runs `sudo wg-quick up "$DEST"`. This may not integrate with systemd and can produce confusing permissions. | 252-285 | Use `/etc/wireguard` when sudo is available; otherwise clearly run user-local/manual mode. |
| Critical | Loop starts every tunnel with `wg-quick up`; multiple full-tunnel configs can fight routes. Windows installs all and activates one. | 283-288 | Save all configs, stop all ProxhqVPN tunnels, then start only the first or selected tunnel. |
| Warning | Split tunnel sed deletes `AllowedIPs` and then `grep -q AllowedIPs` still sees the empty line, so no replacement is appended; configs can become invalid. | 274-276 | Use `set_allowed_ips` function above. |
| Warning | No `config.json` written, unlike Windows/macOS. | whole file | Add `~/.config/ProxhqVPN/config.json`. |
| Warning | `mapfile` requires Bash 4+. Some enterprise distros or BusyBox shells may not have it. | 259 | Use `while read` collection. |
| Warning | `sudo sysctl -w net.ipv4.ip_forward=1` is not needed for a VPN client and modifies system networking state. | 181-183 | Remove unless acting as a router/gateway. |
| Warning | `systemctl enable wg-quick@FIRST_TN` can fail if configs are not in `/etc/wireguard`; script still prints success. | 330-331 | Only enable when config is in `/etc/wireguard` and check exit code. |
| Warning | Assumes `~/Desktop` exists. Minimal/server Linux systems may not have it. | 303, 310 | Create it or fall back to install dir. |
| Warning | `xdg-open` may be absent; desktop shortcut still uses it. | 315 | Use a small launcher script that checks browser commands. |
| Suggestion | Source-build fallback clones live code with no pinned tag or signature verification. | 139-145 | Remove fallback or pin/verifiably package. |

### Corrected code blocks

#### Desktop/install directories and config metadata
```bash
INSTALL_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/ProxhqVPN"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"
mkdir -p "$INSTALL_DIR" "$DESKTOP_DIR"
```

#### Install all configs but activate only one
```bash
CONFS_INSTALLED=()
ACTIVE_TUNNEL=""
for CF in "${CONF_FILES[@]}"; do
  TN=$(basename "$CF" .conf)
  [[ "$TN" =~ ^proxhqvpn-[A-Za-z0-9._-]+$ ]] || { warn "Skipping unsafe tunnel name: $TN"; continue; }
  validate_conf "$CF" || { warn "Skipping invalid config: $CF"; continue; }
  set_allowed_ips "$CF" "$TUNNEL_MODE"
  DEST="$WG_CONF_DIR/$TN.conf"
  sudo install -m 600 "$CF" "$DEST"
  CONFS_INSTALLED+=("$TN|$DEST")
done

# Activate only first tunnel, matching Windows behavior.
if command -v wg-quick >/dev/null 2>&1 && [[ ${#CONFS_INSTALLED[@]} -gt 0 ]]; then
  for entry in "${CONFS_INSTALLED[@]}"; do sudo wg-quick down "${entry%%|*}" >/dev/null 2>&1 || true; done
  FIRST="${CONFS_INSTALLED[0]}"; FIRST_NAME="${FIRST%%|*}"; FIRST_PATH="${FIRST#*|}"
  if sudo wg-quick up "$FIRST_PATH"; then ACTIVE_TUNNEL="$FIRST_NAME"; fi
fi
```

#### Validate conf before installing
```bash
validate_conf() {
  local file=$1
  [[ -f "$file" ]] || return 1
  grep -q '^\[Interface\]' "$file" || return 1
  grep -q '^\[Peer\]' "$file" || return 1
  return 0
}
```

#### Safe systemd enable
```bash
if command -v systemctl >/dev/null 2>&1 && [[ "$WG_CONF_DIR" == "/etc/wireguard" && -n "$ACTIVE_TUNNEL" ]]; then
  if sudo systemctl enable "wg-quick@${ACTIVE_TUNNEL}" >/dev/null 2>&1; then
    ok "wg-quick@${ACTIVE_TUNNEL} enabled for startup"
  else
    warn "Could not enable startup service; VPN still installed."
  fi
fi
```

---

## Linux/SwitchServer-Linux.sh

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Warning | Uses `mapfile`, requiring Bash 4+. | 25 | Use portable `while read`. |
| Warning | Active tunnel detection can include any interface containing `proxhqvpn`; acceptable, but should anchor to `^proxhqvpn-`. | 31 | Use `grep '^proxhqvpn-'`. |
| Warning | No `set -euo pipefail`, so failures can continue. | top | Add strict mode but guard interactive commands. |
| Suggestion | Does not update `config.json` active tunnel after switching. | whole file | Update metadata after successful switch. |

### Corrected code block
```bash
set -euo pipefail
CONFIGS=()
while IFS= read -r -d '' file; do CONFIGS+=("$file"); done < <(find "$WG_CONF_DIR" -type f -name 'proxhqvpn-*.conf' -print0 2>/dev/null | sort -z)
ACTIVE=$(sudo wg show interfaces 2>/dev/null | tr ' ' '\n' | grep '^proxhqvpn-' | head -1 || true)
```

---

## Linux/Launch-ProxhqVPN-Setup.sh

### Issues

| Severity | Issue | Corrective action |
|---|---|---|
| Warning | No existence check for `Install-Linux.sh`. | Add check and readable error. |
| Suggestion | Does not chmod switcher as well as installer. | Chmod both scripts. |

### Corrected full file
```bash
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALLER="$DIR/Install-Linux.sh"
if [[ ! -f "$INSTALLER" ]]; then
  echo "Install-Linux.sh was not found next to this launcher." >&2
  exit 1
fi
chmod +x "$INSTALLER" "$DIR/SwitchServer-Linux.sh" 2>/dev/null || true
exec bash "$INSTALLER"
```

---

## Android/ProxhqVPN-Android-Setup.html

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Warning | The flow is 5 steps, not the 6-step desktop flow. It lacks license/tunnel-mode choice and automatic download watch because mobile cannot run an installer. | 66-72 | Label as “manual mobile setup” or add a 6-step visual flow with license/tunnel explanation. |
| Warning | “Everything is automatic after you sign in” is misleading on Android; user must import manually. | 78 | Change copy to “Your configs generate after sign-in; import them manually into WireGuard.” |
| Warning | “Exclude Private IPs for split tunnel” is not a kill switch. It is inaccurate and could confuse users. | 182 | Explain Always-on VPN / Block connections without VPN in Android settings. |
| Warning | Step navigation permits skipping directly to Done without completing prior steps. | JS | Add simple state checks or keep but label steps as guide pages. |
| Suggestion | External links with `target="_blank"` should include `rel="noopener noreferrer"`. | all anchors | Add rel attribute. |
| Suggestion | Buttons lack ARIA current status and progress semantics. | step bar | Add `role="tablist"`, `aria-selected`, and `aria-current`. |

### Corrected code blocks
```html
<p>Set up ProxhqVPN on your Android phone or tablet in a few minutes. Your configs generate after sign-in; Android imports them manually through the WireGuard app.</p>
```

```html
<div class="feature-row"><div class="feature-icon">🛡</div><div class="feature-text"><strong>Kill switch:</strong> Android Settings → Network &amp; internet → VPN → WireGuard gear → enable <em>Always-on VPN</em> and <em>Block connections without VPN</em>.</div></div>
```

```js
function go(n){
  if(!Number.isInteger(n) || n < 0 || n > 4) return;
  document.getElementById('page'+cur).className='page';
  document.getElementById('page'+n).className='page show';
  document.querySelectorAll('.step').forEach(function(el,i){
    el.className='step'+(i===n?' active':i<n?' done':'');
    el.setAttribute('aria-selected', i===n ? 'true' : 'false');
    if(i===n) el.setAttribute('aria-current','step'); else el.removeAttribute('aria-current');
  });
  cur=n; window.scrollTo({top:0, behavior:'smooth'});
}
```

---

## iOS/ProxhqVPN-iPhone-Setup.html

### Issues

| Severity | Issue | Location | Corrective action |
|---|---|---:|---|
| Warning | The flow is 5 steps, not desktop 6-step parity. This is acceptable only if labeled as a manual setup guide. | 66-72 | Rename as “manual iPhone/iPad setup.” |
| Warning | Claims “Everything is automatic after you sign in,” but import is manual via QR or Files. | 78 | Correct the wording. |
| Warning | “Connect On Demand” is presented as a WireGuard setting path but wording may not match iOS/WireGuard UI consistently. | 176 | Use generic “WireGuard tunnel settings → On-Demand Activation.” |
| Suggestion | External links need `rel="noopener noreferrer"`. | anchors | Add rel attribute. |
| Suggestion | JS lacks bounds checks and ARIA updates. | 187-199 | Use same corrected JS block as Android. |

### Corrected code blocks
```html
<p>Set up ProxhqVPN on your iPhone or iPad in a few minutes. Your configs generate after sign-in; you import them manually with QR codes or Files.</p>
```

```html
<div class="feature-row"><div class="feature-icon">🛡</div><div class="feature-text"><strong>On-demand VPN:</strong> Open WireGuard → tunnel settings → enable On-Demand Activation if you want iOS to reconnect automatically.</div></div>
```

---

## Summary table

| File | Critical | Warning | Suggestion |
|---|---:|---:|---:|
| Windows/Install.ps1 | 1 | 6 | 2 |
| Windows/SwitchServer.ps1 | 0 | 3 | 1 |
| Windows/Launch-ProxhqVPN-Setup.vbs | 0 | 0 | 2 |
| macOS/Install-macOS.sh | 3 | 6 | 2 |
| macOS/SwitchServer-macOS.sh | 1 | 4 | 1 |
| macOS/Launch-ProxhqVPN-Setup.command | 0 | 1 | 1 |
| Linux/Install-Linux.sh | 2 | 7 | 1 |
| Linux/SwitchServer-Linux.sh | 0 | 3 | 1 |
| Linux/Launch-ProxhqVPN-Setup.sh | 0 | 1 | 1 |
| Android/ProxhqVPN-Android-Setup.html | 0 | 4 | 3 |
| iOS/ProxhqVPN-iPhone-Setup.html | 0 | 3 | 2 |
| **Total** | **7** | **38** | **18** |

## Highest-priority fix order

1. Fix split-tunnel rewriting on Windows/macOS/Linux.
2. Change macOS/Linux to “install/save all configs, activate one tunnel only.”
3. Remove macOS `mapfile` usage for default Bash compatibility.
4. Write valid `config.json` on macOS/Linux.
5. Quote WireGuard tunnel arguments everywhere.
6. Add stale-download protection for `proxhqvpn-all-servers.zip`.
7. Correct Android/iOS wording so users know mobile import is manual.
