================================================================================
  Alpha Vulnerability Verifier(TM) - Windows Edition
  PRIVATE / AUTHORIZED USE ONLY
  (C) 2026 Alpha Unlimited Technologies LLC
================================================================================

WHAT THIS TOOL DOES
-------------------
Reads an Alpha External Scanner(TM) HTML report and actively probes each
finding against the live target to show EXACTLY what an attacker would see.
Outputs JSON, TXT, and HTML exposure reports.

CONTENTS
--------
  alpha_vuln_verifier.py   The tool (pure Python, stdlib only)
  run_vuln_verifier.bat    Double-click launcher
  README-Windows.txt       This file
  USER-GUIDE.txt           Full documentation

REQUIREMENTS
------------
  Windows 7, 8, 10, or 11.
  Python 3.8 or newer (https://www.python.org/downloads/).

  When installing Python:
    - Tick "Add python.exe to PATH" on the first screen.
    - Otherwise the launcher will not find it.

INSTALL
-------
  1. Install Python 3.8+ from python.org if you don't have it.
  2. Extract this ZIP to a folder (e.g. C:\Tools\AlphaVulnVerifier).
  3. Done.

  If SmartScreen blocks the .bat:
    - Click "More info" -> "Run anyway".
    - Or right-click the .bat -> Properties -> tick "Unblock" -> OK.

LAUNCH
------
  INTERACTIVE (no arguments):
    Double-click run_vuln_verifier.bat
    The tool will prompt for the report path and target.

  WITH A REPORT FILE (drag-and-drop):
    Drag your scan report HTML onto run_vuln_verifier.bat.

  COMMAND LINE:
    run_vuln_verifier.bat path\to\scan-report.html
    run_vuln_verifier.bat path\to\scan-report.html -o C:\Users\You\Desktop
    run_vuln_verifier.bat path\to\scan-report.html --target https://mysite.com

OUTPUT
------
The tool writes three files into the chosen output directory (default = current):
  exposure_<host>_<timestamp>.json   Machine-readable findings
  exposure_<host>_<timestamp>.txt    Human-readable text
  exposure_<host>_<timestamp>.html   Color-coded interactive report

AUTHORIZATION WARNING
---------------------
Run this tool only against systems you own or have explicit written
authorization to test. Unauthorized use may be illegal in your jurisdiction.

LICENSE
-------
Proprietary - PRIVATE / AUTHORIZED USE ONLY.
See USER-GUIDE.txt for full feature documentation.
