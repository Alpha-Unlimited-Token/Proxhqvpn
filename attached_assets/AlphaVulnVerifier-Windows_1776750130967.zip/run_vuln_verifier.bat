@echo off
REM ============================================================
REM  Alpha Vulnerability Verifier(TM) - Windows Launcher
REM  Double-click to run, or pass a scan-report HTML as an arg.
REM ============================================================
setlocal
set "HERE=%~dp0"
set "TOOL=%HERE%alpha_vuln_verifier.py"

echo ============================================================
echo  Alpha Vulnerability Verifier v2.0.0
echo  (C) 2026 Alpha Unlimited Technologies LLC
echo ============================================================
echo.

if not exist "%TOOL%" (
  echo [ERROR] alpha_vuln_verifier.py not found next to this launcher.
  pause
  exit /b 1
)

where python3 >nul 2>&1
if not errorlevel 1 (
  python3 "%TOOL%" %*
  goto :end
)
where python >nul 2>&1
if not errorlevel 1 (
  python "%TOOL%" %*
  goto :end
)

echo [ERROR] Python 3.8+ not found.
echo Install Python from https://www.python.org/downloads/
echo During install, tick "Add python.exe to PATH".
pause
exit /b 1

:end
pause
