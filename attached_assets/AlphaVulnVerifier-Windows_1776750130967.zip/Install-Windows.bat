@echo off
REM ============================================================
REM  Alpha Vulnerability Verifier(TM) v2.0.0 - Windows Installer
REM  Copies tool to %LOCALAPPDATA%\AlphaVulnVerifier and
REM  creates Start Menu + Desktop shortcuts via PowerShell.
REM ============================================================
setlocal
set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\AlphaVulnVerifier"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
set "DESKTOP=%USERPROFILE%\Desktop"
set "SM_LNK=%STARTMENU%\Alpha Vulnerability Verifier.lnk"
set "DT_LNK=%DESKTOP%\Alpha Vulnerability Verifier.lnk"

echo ============================================================
echo  Alpha Vulnerability Verifier v2.0.0 - Installer
echo ============================================================
echo.
echo  Install destination: %DEST%
echo.

if exist "%DEST%" (
  echo  [INFO] Existing install found - it will be overwritten.
  rmdir /s /q "%DEST%" 2>nul
)

mkdir "%DEST%" 2>nul

copy /y "%SRC%alpha_vuln_verifier.py"   "%DEST%\" >nul
copy /y "%SRC%run_vuln_verifier.bat"    "%DEST%\" >nul
copy /y "%SRC%README-Windows.txt"       "%DEST%\" >nul
copy /y "%SRC%USER-GUIDE.txt"           "%DEST%\" >nul
copy /y "%SRC%INSTALL-GUIDE.txt"        "%DEST%\" >nul

REM -- Build Uninstall.bat with literal absolute paths --
REM    Uses the (goto) 2^>nul self-delete idiom which lets cmd.exe
REM    safely delete the running batch file's containing folder.
> "%DEST%\Uninstall.bat" echo @echo off
>> "%DEST%\Uninstall.bat" echo REM Alpha Vulnerability Verifier - Uninstaller
>> "%DEST%\Uninstall.bat" echo echo Removing Alpha Vulnerability Verifier...
>> "%DEST%\Uninstall.bat" echo cd /d "%%TEMP%%"
>> "%DEST%\Uninstall.bat" echo del /f /q "%SM_LNK%" 2^>nul
>> "%DEST%\Uninstall.bat" echo del /f /q "%DT_LNK%" 2^>nul
>> "%DEST%\Uninstall.bat" echo echo Removed shortcuts.
>> "%DEST%\Uninstall.bat" echo echo Removing install folder: %DEST%
>> "%DEST%\Uninstall.bat" echo (goto) 2^>nul ^& rmdir /s /q "%DEST%"

powershell -NoProfile -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$s1 = $ws.CreateShortcut('%SM_LNK%');" ^
  "$s1.TargetPath = '%DEST%\run_vuln_verifier.bat';" ^
  "$s1.WorkingDirectory = '%DEST%';" ^
  "$s1.Description = 'Alpha Vulnerability Verifier v2.0.0';" ^
  "$s1.Save();" ^
  "$s2 = $ws.CreateShortcut('%DT_LNK%');" ^
  "$s2.TargetPath = '%DEST%\run_vuln_verifier.bat';" ^
  "$s2.WorkingDirectory = '%DEST%';" ^
  "$s2.Description = 'Alpha Vulnerability Verifier v2.0.0';" ^
  "$s2.Save();"

echo.
echo  [DONE] Installed.
echo    - Start Menu:  Alpha Vulnerability Verifier
echo    - Desktop:     Alpha Vulnerability Verifier
echo    - Uninstall:   %DEST%\Uninstall.bat
echo                   (removes both shortcuts and the install folder)
echo.
pause
