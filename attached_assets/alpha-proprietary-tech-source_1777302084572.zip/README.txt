ALPHA UNLIMITED — PROPRIETARY TECHNOLOGY SOURCE BUNDLE
========================================================

This archive contains the source code for every proprietary technology
deployed across the Alpha Unlimited Token / Trading platforms.

LAYOUT
------
  contracts/atc/                  ATC + DAUv2 Solidity contracts, listeners, traces
  server/services/                Forensic + trading + security engines (46 modules)
  server/services/chain-adapters/ UCAL — universal chain adapter layer (EVM/SOL/BTC/TRON/TON/XRPL)
  server/blockchain/              Proprietary chain core (SafeSend, SafeAsset, Spider, etc.)
  server/scripts/                 Forensic email + report builders
  private/forensics/              Flow Diagram Visualizer + auto-emit helper
  private/security/               Alpha Proprietary Software Guard + license generator
  private/tools/                  Operator CLI tools (TS forensic runners + Python scanners)
  private/tech-docs/              Architectural PDFs per technology
  client/src/pages/trading-platform/      Trading-platform tech UI pages
  client/src/components/trading-platform/ Trading-platform tech UI components
  client/src/pages/standalone/    Standalone tech apps (AACC, BridgeFusion, etc.)
  shared/schema.ts + shared/models/        Drizzle ORM schema + shared types
  package.json, replit.md, tsconfig.json   Project root config

NOTE
----
- node_modules, build artifacts, large JSON trace dumps, and pre-built scanner
  ZIP bundles are intentionally EXCLUDED to keep this archive focused on
  reviewable source code.
- The .alpha_license.json secret is intentionally EXCLUDED.
