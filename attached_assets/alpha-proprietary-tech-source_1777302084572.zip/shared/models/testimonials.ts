import { pgTable, serial, text, integer, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role"),
  email: text("email"),
  rating: integer("rating").notNull().default(5),
  content: text("content").notNull(),
  service: text("service"),
  isApproved: boolean("is_approved").notNull().default(false),
  isFeatured: boolean("is_featured").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_testimonials_approved").on(table.isApproved),
  index("idx_testimonials_created").on(table.createdAt),
]);

export const insertTestimonialSchema = createInsertSchema(testimonials)
  .omit({ id: true, createdAt: true, isApproved: true, isFeatured: true })
  .extend({
    name: z.string().trim().min(2).max(80),
    role: z.string().trim().max(120).optional().nullable(),
    email: z.string().trim().email().max(200).optional().nullable(),
    rating: z.number().int().min(1).max(5),
    content: z.string().trim().min(20).max(1500),
    service: z.string().trim().max(120).optional().nullable(),
  });

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
