import { pgTable, varchar, timestamp, text, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const securityLogs = pgTable("security_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  eventType: varchar("event_type", { length: 50 }).notNull(),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  success: boolean("success").default(true),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userSessions = pgTable("user_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  sessionId: varchar("session_id").notNull(),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true),
});

export const securityAlerts = pgTable("security_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  alertType: varchar("alert_type", { length: 50 }).notNull(),
  severity: varchar("severity", { length: 20 }).notNull().default("medium"),
  message: text("message").notNull(),
  metadata: jsonb("metadata"),
  acknowledged: boolean("acknowledged").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export type SecurityLog = typeof securityLogs.$inferSelect;
export type InsertSecurityLog = typeof securityLogs.$inferInsert;
export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserSession = typeof userSessions.$inferInsert;
export type SecurityAlert = typeof securityAlerts.$inferSelect;
export type InsertSecurityAlert = typeof securityAlerts.$inferInsert;

export const SECURITY_EVENTS = {
  LOGIN_SUCCESS: "login_success",
  LOGIN_FAILED: "login_failed",
  LOGOUT: "logout",
  SESSION_CREATED: "session_created",
  SESSION_EXPIRED: "session_expired",
  SESSION_TERMINATED: "session_terminated",
  RATE_LIMIT_EXCEEDED: "rate_limit_exceeded",
  SUSPICIOUS_ACTIVITY: "suspicious_activity",
  IP_CHANGE_DETECTED: "ip_change_detected",
  CONCURRENT_SESSION_BLOCKED: "concurrent_session_blocked",
  IDLE_TIMEOUT: "idle_timeout",
  API_KEY_ACCESS: "api_key_access",
  PROFILE_UPDATED: "profile_updated",
  PASSWORD_RESET_REQUEST: "password_reset_request",
  EXCHANGE_CONNECTED: "exchange_connected",
  EXCHANGE_DISCONNECTED: "exchange_disconnected",
  TRADE_EXECUTED: "trade_executed",
  WALLET_CONNECTED: "wallet_connected",
  SUBSCRIPTION_CHANGED: "subscription_changed",
  MFA_ENABLED: "mfa_enabled",
  MFA_DISABLED: "mfa_disabled",
  MFA_VERIFIED: "mfa_verified",
  MFA_FAILED: "mfa_failed",
  MFA_BACKUP_USED: "mfa_backup_used",
} as const;

export const ALERT_TYPES = {
  BRUTE_FORCE_ATTEMPT: "brute_force_attempt",
  UNUSUAL_LOCATION: "unusual_location",
  MULTIPLE_FAILED_LOGINS: "multiple_failed_logins",
  SUSPICIOUS_API_USAGE: "suspicious_api_usage",
  ACCOUNT_COMPROMISE: "account_compromise",
  SESSION_HIJACKING: "session_hijacking",
  RAPID_REQUESTS: "rapid_requests",
} as const;

export const SEVERITY_LEVELS = {
  LOW: "low",
  MEDIUM: "medium",
  HIGH: "high",
  CRITICAL: "critical",
} as const;

export type SecurityEventType = (typeof SECURITY_EVENTS)[keyof typeof SECURITY_EVENTS];
export type AlertType = (typeof ALERT_TYPES)[keyof typeof ALERT_TYPES];
export type SeverityLevel = (typeof SEVERITY_LEVELS)[keyof typeof SEVERITY_LEVELS];
