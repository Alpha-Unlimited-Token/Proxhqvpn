/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Intelligence Engine™ — Data Models & Schema
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Database schema for the Forensic Intelligence Engine™ ecosystem including:
 * forensic cases, monitored wallets, alerts, freeze requests, phantom vaults,
 * customer phantom vaults, and customer subscriptions.
 *
 * AUT_ModuleHash: AUT_4d9a6456f1dd958d49b9b41a
 * ALPHA_INTEGRITY_SEAL: FORENSIC_MODELS_v2.1_PROTECTED
 */

import { pgTable, varchar, timestamp, boolean, text, integer, jsonb, real } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const forensicCases = pgTable("forensic_cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseName: varchar("case_name", { length: 255 }).notNull(),
  victimAddress: varchar("victim_address", { length: 255 }),
  victimHandle: varchar("victim_handle", { length: 100 }),
  description: text("description"),
  status: varchar("status", { length: 50 }).notNull().default("active"),
  totalStolenUsd: real("total_stolen_usd"),
  totalRecoveredUsd: real("total_recovered_usd").default(0),
  chains: text("chains").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const monitoredWallets = pgTable("monitored_wallets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  address: varchar("address", { length: 255 }).notNull(),
  chain: varchar("chain", { length: 50 }).notNull().default("ethereum"),
  role: varchar("role", { length: 100 }),
  label: varchar("label", { length: 255 }),
  lastKnownBalanceEth: real("last_known_balance_eth"),
  lastKnownBalanceUsd: real("last_known_balance_usd"),
  lastKnownTokens: jsonb("last_known_tokens"),
  lastChecked: timestamp("last_checked"),
  lastActivity: timestamp("last_activity"),
  status: varchar("status", { length: 50 }).notNull().default("monitoring"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const forensicAlerts = pgTable("forensic_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  walletId: varchar("wallet_id"),
  alertType: varchar("alert_type", { length: 50 }).notNull(),
  message: text("message").notNull(),
  details: jsonb("details"),
  severity: varchar("severity", { length: 20 }).notNull().default("medium"),
  acknowledged: boolean("acknowledged").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertForensicCaseSchema = createInsertSchema(forensicCases).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMonitoredWalletSchema = createInsertSchema(monitoredWallets).omit({ id: true, createdAt: true, lastChecked: true, lastActivity: true });
export const freezeRequests = pgTable("freeze_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  walletId: varchar("wallet_id"),
  exchangeName: varchar("exchange_name", { length: 100 }).notNull(),
  exchangeEmail: varchar("exchange_email", { length: 255 }),
  walletAddress: varchar("wallet_address", { length: 255 }).notNull(),
  chain: varchar("chain", { length: 50 }).notNull().default("ethereum"),
  estimatedValueUsd: real("estimated_value_usd"),
  status: varchar("status", { length: 50 }).notNull().default("pending"),
  bountyPercentage: real("bounty_percentage").default(10),
  bountyEstimateUsd: real("bounty_estimate_usd"),
  bountyWalletAddress: varchar("bounty_wallet_address", { length: 255 }),
  traceEvidence: jsonb("trace_evidence"),
  requestBody: text("request_body"),
  frozenAt: timestamp("frozen_at"),
  responseNotes: text("response_notes"),
  notified: boolean("notified").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const phantomVaults = pgTable("phantom_vaults", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id"),
  vaultName: varchar("vault_name", { length: 255 }).notNull(),
  decoyAddress: varchar("decoy_address", { length: 255 }).notNull(),
  chain: varchar("chain", { length: 50 }).notNull().default("ethereum"),
  decoyTokenType: varchar("decoy_token_type", { length: 50 }).notNull().default("USDC"),
  decoyAmount: real("decoy_amount").notNull().default(0),
  decoyAmountUsd: real("decoy_amount_usd").notNull().default(0),
  expirationHours: integer("expiration_hours").notNull().default(24),
  status: varchar("status", { length: 50 }).notNull().default("armed"),
  beaconActive: boolean("beacon_active").notNull().default(true),
  beaconHits: integer("beacon_hits").notNull().default(0),
  triggeredAt: timestamp("triggered_at"),
  triggeredByAddress: varchar("triggered_by_address", { length: 255 }),
  expiresAt: timestamp("expires_at"),
  disintegratedAt: timestamp("disintegrated_at"),
  discoveredAddresses: jsonb("discovered_addresses").default([]),
  interactionLog: jsonb("interaction_log").default([]),
  spiderTraceActive: boolean("spider_trace_active").notNull().default(false),
  spiderTracePaused: boolean("spider_trace_paused").notNull().default(false),
  securityProtocol: jsonb("security_protocol").default({}),
  contractSpec: jsonb("contract_spec").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const customerPhantomVaults = pgTable("customer_phantom_vaults", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  vaultName: varchar("vault_name", { length: 255 }).notNull(),
  walletAddress: varchar("wallet_address", { length: 255 }).notNull(),
  chain: varchar("chain", { length: 50 }).notNull().default("ethereum"),
  decoyTokenType: varchar("decoy_token_type", { length: 50 }).notNull().default("USDC"),
  decoyAmount: real("decoy_amount").notNull().default(0),
  expirationHours: integer("expiration_hours").notNull().default(24),
  status: varchar("status", { length: 50 }).notNull().default("armed"),
  walletIcon: text("wallet_icon"),
  walletSplash: text("wallet_splash"),
  walletTheme: jsonb("wallet_theme").default({}),
  beaconActive: boolean("beacon_active").notNull().default(true),
  beaconHits: integer("beacon_hits").notNull().default(0),
  triggeredAt: timestamp("triggered_at"),
  triggeredByAddress: varchar("triggered_by_address", { length: 255 }),
  expiresAt: timestamp("expires_at"),
  discoveredAddresses: jsonb("discovered_addresses").default([]),
  interactionLog: jsonb("interaction_log").default([]),
  disclaimerAccepted: boolean("disclaimer_accepted").notNull().default(false),
  disclaimerAcceptedAt: timestamp("disclaimer_accepted_at"),
  securityProtocol: jsonb("security_protocol").default({}),
  contractSpec: jsonb("contract_spec").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const customerPhantomSubscriptions = pgTable("customer_phantom_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  plan: varchar("plan", { length: 50 }).notNull().default("monthly"),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  status: varchar("status", { length: 50 }).notNull().default("active"),
  maxVaults: integer("max_vaults").notNull().default(3),
  vaultsUsed: integer("vaults_used").notNull().default(0),
  currentPeriodEnd: timestamp("current_period_end"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const bountyAgreements = pgTable("bounty_agreements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  clientName: varchar("client_name", { length: 255 }),
  clientEmail: varchar("client_email", { length: 255 }),
  clientWalletAddress: varchar("client_wallet_address", { length: 255 }),
  bountyPercentage: real("bounty_percentage").notNull().default(10),
  agreementText: text("agreement_text").notNull(),
  status: varchar("status", { length: 50 }).notNull().default("pending"),
  signedAt: timestamp("signed_at"),
  signatureHash: varchar("signature_hash", { length: 255 }),
  signerName: varchar("signer_name", { length: 255 }),
  signerIp: varchar("signer_ip", { length: 100 }),
  signerUserAgent: text("signer_user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const recoveryEvents = pgTable("recovery_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  walletAddress: varchar("wallet_address", { length: 255 }),
  chain: varchar("chain", { length: 50 }).default("ethereum"),
  amountRecoveredNative: real("amount_recovered_native"),
  amountRecoveredUsd: real("amount_recovered_usd").notNull().default(0),
  source: varchar("source", { length: 100 }),
  bountyOwed: real("bounty_owed").default(0),
  bountyPaid: boolean("bounty_paid").default(false),
  notes: text("notes"),
  recoveredAt: timestamp("recovered_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tracedTransactions = pgTable("traced_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  walletId: varchar("wallet_id"),
  txHash: varchar("tx_hash", { length: 100 }).notNull(),
  chain: varchar("chain", { length: 50 }).notNull().default("ethereum"),
  fromAddress: varchar("from_address", { length: 255 }).notNull(),
  toAddress: varchar("to_address", { length: 255 }).notNull(),
  direction: varchar("direction", { length: 20 }).notNull(),
  tokenSymbol: varchar("token_symbol", { length: 50 }),
  amount: real("amount"),
  amountUsd: real("amount_usd"),
  txType: varchar("tx_type", { length: 50 }),
  exchangeName: varchar("exchange_name", { length: 100 }),
  blockNumber: integer("block_number"),
  timestamp: timestamp("timestamp"),
  fromLabel: varchar("from_label", { length: 255 }),
  toLabel: varchar("to_label", { length: 255 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTracedTransactionSchema = createInsertSchema(tracedTransactions).omit({ id: true, createdAt: true });

export const insertForensicAlertSchema = createInsertSchema(forensicAlerts).omit({ id: true, createdAt: true });
export const insertFreezeRequestSchema = createInsertSchema(freezeRequests).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPhantomVaultSchema = createInsertSchema(phantomVaults).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCustomerPhantomVaultSchema = createInsertSchema(customerPhantomVaults).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCustomerPhantomSubscriptionSchema = createInsertSchema(customerPhantomSubscriptions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertBountyAgreementSchema = createInsertSchema(bountyAgreements).omit({ id: true, createdAt: true, updatedAt: true });
export const insertRecoveryEventSchema = createInsertSchema(recoveryEvents).omit({ id: true, createdAt: true });

export type ForensicCase = typeof forensicCases.$inferSelect;
export type InsertForensicCase = z.infer<typeof insertForensicCaseSchema>;
export type MonitoredWallet = typeof monitoredWallets.$inferSelect;
export type InsertMonitoredWallet = z.infer<typeof insertMonitoredWalletSchema>;
export type ForensicAlert = typeof forensicAlerts.$inferSelect;
export type InsertForensicAlert = z.infer<typeof insertForensicAlertSchema>;
export type FreezeRequest = typeof freezeRequests.$inferSelect;
export type InsertFreezeRequest = z.infer<typeof insertFreezeRequestSchema>;
export type PhantomVault = typeof phantomVaults.$inferSelect;
export type InsertPhantomVault = z.infer<typeof insertPhantomVaultSchema>;
export type CustomerPhantomVault = typeof customerPhantomVaults.$inferSelect;
export type InsertCustomerPhantomVault = z.infer<typeof insertCustomerPhantomVaultSchema>;
export type CustomerPhantomSubscription = typeof customerPhantomSubscriptions.$inferSelect;
export type InsertCustomerPhantomSubscription = z.infer<typeof insertCustomerPhantomSubscriptionSchema>;
export type BountyAgreement = typeof bountyAgreements.$inferSelect;
export type InsertBountyAgreement = z.infer<typeof insertBountyAgreementSchema>;
export type RecoveryEvent = typeof recoveryEvents.$inferSelect;
export type InsertRecoveryEvent = z.infer<typeof insertRecoveryEventSchema>;
export type TracedTransaction = typeof tracedTransactions.$inferSelect;
export type InsertTracedTransaction = z.infer<typeof insertTracedTransactionSchema>;

export const teamMembers = pgTable("team_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  role: varchar("role", { length: 100 }).notNull().default("investigator"),
  accessCode: varchar("access_code", { length: 255 }).notNull(),
  status: varchar("status", { length: 50 }).notNull().default("active"),
  sessionToken: varchar("session_token", { length: 255 }),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const codeSubmissions = pgTable("code_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamMemberId: varchar("team_member_id").notNull(),
  teamMemberName: varchar("team_member_name", { length: 255 }).notNull(),
  technologyName: varchar("technology_name", { length: 255 }).notNull(),
  fileName: varchar("file_name", { length: 500 }).notNull(),
  description: text("description").notNull(),
  submittedCode: text("submitted_code").notNull(),
  status: varchar("status", { length: 50 }).notNull().default("pending"),
  adminNotes: text("admin_notes"),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({ id: true, createdAt: true, updatedAt: true, sessionToken: true, lastLoginAt: true });
export const insertCodeSubmissionSchema = createInsertSchema(codeSubmissions).omit({ id: true, createdAt: true, reviewedAt: true, adminNotes: true, status: true });

export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type CodeSubmission = typeof codeSubmissions.$inferSelect;
export type InsertCodeSubmission = z.infer<typeof insertCodeSubmissionSchema>;
