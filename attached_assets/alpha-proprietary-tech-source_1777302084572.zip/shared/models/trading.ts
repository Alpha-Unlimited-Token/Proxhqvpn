/**
 * Alpha Unlimited Token (ALPHAU) - Trading Data Models
 * Copyright (c) 2024-present Alpha Unlimited Token. All Rights Reserved.
 * 
 * This source code is protected under copyright law. Unauthorized copying,
 * modification, distribution, or use of this code is strictly prohibited.
 */

import { pgTable, serial, text, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tradingBotTiers = pgTable("trading_bot_tiers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: integer("price").notNull(),
  tradesPerDay: integer("trades_per_day").notNull(),
  indicators: json("indicators").$type<string[]>().notNull(),
  features: json("features").$type<string[]>().notNull(),
  exchangeLimit: integer("exchange_limit").notNull(),
  botStrategies: json("bot_strategies").$type<string[]>().notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const userExchangeConnections = pgTable("user_exchange_connections", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  exchangeName: text("exchange_name").notNull(),
  apiKeyEncrypted: text("api_key_encrypted").notNull(),
  apiSecretEncrypted: text("api_secret_encrypted").notNull(),
  passphraseEncrypted: text("passphrase_encrypted"),
  permissions: json("permissions").$type<string[]>().notNull(),
  apiBaseUrl: text("api_base_url"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUsed: timestamp("last_used"),
});

export const userBotSubscriptions = pgTable("user_bot_subscriptions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  tierId: integer("tier_id").notNull(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  status: text("status").notNull().default("active"),
  tradesUsedToday: integer("trades_used_today").notNull().default(0),
  lastTradeReset: timestamp("last_trade_reset").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const cryptoPayments = pgTable("crypto_payments", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  orderId: text("order_id").notNull().unique(),
  invoiceId: text("invoice_id"),
  paymentId: text("payment_id"),
  tierId: text("tier_id").notNull(),
  priceAmount: real("price_amount").notNull(),
  priceCurrency: text("price_currency").notNull().default("usd"),
  payCurrency: text("pay_currency").notNull(),
  payAmount: real("pay_amount"),
  payAddress: text("pay_address"),
  actuallyPaid: real("actually_paid"),
  status: text("status").notNull().default("pending"),
  invoiceUrl: text("invoice_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertCryptoPaymentSchema = createInsertSchema(cryptoPayments).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCryptoPayment = z.infer<typeof insertCryptoPaymentSchema>;
export type CryptoPayment = typeof cryptoPayments.$inferSelect;

export const tradeSignals = pgTable("trade_signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  signalType: text("signal_type").notNull(),
  indicator: text("indicator").notNull(),
  strength: real("strength").notNull(),
  price: real("price").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  metadata: json("metadata").$type<Record<string, any>>(),
});

export const userTrades = pgTable("user_trades", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // 'buy' or 'sell'
  quantity: real("quantity").notNull(),
  entryPrice: real("entry_price").notNull(),
  exitPrice: real("exit_price"),
  realizedPnl: real("realized_pnl"),
  pnlPercent: real("pnl_percent"),
  exchange: text("exchange").notNull(),
  status: text("status").notNull().default("open"), // 'open', 'closed', 'cancelled'
  strategy: text("strategy"), // 'manual', 'dca', 'grid', etc.
  signalStrength: real("signal_strength"),
  entryAt: timestamp("entry_at").notNull().defaultNow(),
  exitAt: timestamp("exit_at"),
  metadata: json("metadata").$type<Record<string, any>>(),
});

export const insertTradingBotTierSchema = createInsertSchema(tradingBotTiers).omit({ id: true });
export const insertUserExchangeConnectionSchema = createInsertSchema(userExchangeConnections).omit({ id: true, createdAt: true, lastUsed: true });
export const insertUserBotSubscriptionSchema = createInsertSchema(userBotSubscriptions).omit({ id: true, createdAt: true, tradesUsedToday: true, lastTradeReset: true });
export const insertTradeSignalSchema = createInsertSchema(tradeSignals).omit({ id: true, timestamp: true });
export const insertUserTradeSchema = createInsertSchema(userTrades).omit({ id: true, entryAt: true });

export type TradingBotTier = typeof tradingBotTiers.$inferSelect;
export type InsertTradingBotTier = z.infer<typeof insertTradingBotTierSchema>;
export type UserExchangeConnection = typeof userExchangeConnections.$inferSelect;
export type InsertUserExchangeConnection = z.infer<typeof insertUserExchangeConnectionSchema>;
export type UserBotSubscription = typeof userBotSubscriptions.$inferSelect;
export type InsertUserBotSubscription = z.infer<typeof insertUserBotSubscriptionSchema>;
export type TradeSignal = typeof tradeSignals.$inferSelect;
export type InsertTradeSignal = z.infer<typeof insertTradeSignalSchema>;
export type UserTrade = typeof userTrades.$inferSelect;
export type InsertUserTrade = z.infer<typeof insertUserTradeSchema>;

export const EXCHANGE_CATEGORIES = {
  global: 'Global Leaders',
  us: 'US Exchanges', 
  derivatives: 'Derivatives & Futures',
  defi: 'DeFi & DEX',
  regional: 'Regional Exchanges',
  traditional: 'Traditional Brokers',
} as const;

export const SUPPORTED_EXCHANGES = [
  // Global Leaders - High Volume
  { id: 'binance', name: 'Binance', logo: '🟡', region: 'Global (not US)', category: 'global', volume: '76B', features: ['Spot', 'Futures', 'Staking'], apiDocs: 'https://binance-docs.github.io/apidocs/' },
  { id: 'bybit', name: 'Bybit', logo: '🟠', region: 'Global (not US)', category: 'global', volume: '12B', features: ['Spot', 'Derivatives', 'Copy Trading'], apiDocs: 'https://bybit-exchange.github.io/docs/' },
  { id: 'okx', name: 'OKX', logo: '⚪', region: 'Global (not US)', category: 'global', volume: '8B', features: ['Spot', 'Futures', 'DeFi'], apiDocs: 'https://www.okx.com/docs-v5/' },
  { id: 'gateio', name: 'Gate.io', logo: '🔴', region: 'Global', category: 'global', volume: '4B', features: ['Spot', '1400+ coins'], apiDocs: 'https://www.gate.io/docs/apiv4/' },
  { id: 'bitget', name: 'Bitget', logo: '🔷', region: 'Global', category: 'global', volume: '3B', features: ['Copy Trading', 'Futures'], apiDocs: 'https://bitgetlimited.github.io/apidoc/' },
  { id: 'kucoin', name: 'KuCoin', logo: '🟢', region: 'Global', category: 'global', volume: '2B', features: ['Spot', 'Trading Bots'], apiDocs: 'https://docs.kucoin.com/' },
  { id: 'mexc', name: 'MEXC', logo: '🟦', region: 'Global', category: 'global', volume: '1.5B', features: ['0% Maker Fees', 'Spot'], apiDocs: 'https://mxcdevelop.github.io/apidocs/' },
  { id: 'htx', name: 'HTX (Huobi)', logo: '🔶', region: 'Global', category: 'global', volume: '1.2B', features: ['Spot', 'Margin', 'Futures'], apiDocs: 'https://huobiapi.github.io/docs/' },
  { id: 'bitfinex', name: 'Bitfinex', logo: '🌿', region: 'Global', category: 'global', volume: '800M', features: ['Margin', 'Lending'], apiDocs: 'https://docs.bitfinex.com/' },
  { id: 'bitstamp', name: 'Bitstamp', logo: '🟩', region: 'Global', category: 'global', volume: '400M', features: ['Fiat On-ramp', 'Low Fees'], apiDocs: 'https://www.bitstamp.net/api/' },
  
  // US-Focused Exchanges
  { id: 'coinbase', name: 'Coinbase', logo: '🔵', region: 'US/Global', category: 'us', volume: '2.5B', features: ['FDIC Insured', 'Regulated'], apiDocs: 'https://docs.cloud.coinbase.com/' },
  { id: 'binanceus', name: 'Binance.US', logo: '🟡', region: 'US', category: 'us', volume: '200M', features: ['Spot', 'Staking'], apiDocs: 'https://docs.binance.us/' },
  { id: 'kraken', name: 'Kraken', logo: '🟣', region: 'US/Global', category: 'us', volume: '1.5B', features: ['High Security', 'Futures'], apiDocs: 'https://docs.kraken.com/' },
  { id: 'gemini', name: 'Gemini', logo: '🌀', region: 'US', category: 'us', volume: '300M', features: ['SOC Certified', 'Regulated'], apiDocs: 'https://docs.gemini.com/' },
  { id: 'cryptocom', name: 'Crypto.com', logo: '💙', region: 'US/Global', category: 'us', volume: '1B', features: ['Visa Card', 'DeFi Wallet'], apiDocs: 'https://exchange-docs.crypto.com/' },
  { id: 'robinhood', name: 'Robinhood', logo: '🪶', region: 'US', category: 'us', volume: '500M', features: ['Commission Free', 'Stocks+Crypto'], apiDocs: 'https://robinhood.com/us/en/about/crypto/' },
  { id: 'coinbasepro', name: 'Coinbase Advanced', logo: '🔵', region: 'US/Global', category: 'us', volume: '1B', features: ['Advanced Trading', 'Low Fees'], apiDocs: 'https://docs.cloud.coinbase.com/advanced-trade-api/' },
  
  // Derivatives & Futures Focused
  { id: 'deribit', name: 'Deribit', logo: '🔳', region: 'Global (not US)', category: 'derivatives', volume: '2B', features: ['Options', 'Futures'], apiDocs: 'https://docs.deribit.com/' },
  { id: 'bitmex', name: 'BitMEX', logo: '🔺', region: 'Global (not US)', category: 'derivatives', volume: '500M', features: ['Perpetuals', 'High Leverage'], apiDocs: 'https://www.bitmex.com/api/explorer/' },
  { id: 'primexbt', name: 'PrimeXBT', logo: '🔶', region: 'Global (not US)', category: 'derivatives', volume: '300M', features: ['500x Leverage', 'Multi-Asset'], apiDocs: 'https://primexbt.com/api' },
  { id: 'phemex', name: 'Phemex', logo: '🟡', region: 'Global (not US)', category: 'derivatives', volume: '400M', features: ['Contract Trading', 'Spot'], apiDocs: 'https://github.com/phemex/phemex-api-docs' },
  
  // DeFi & DEX Aggregators
  { id: 'uniswap', name: 'Uniswap', logo: '🦄', region: 'DeFi', category: 'defi', volume: '3B', features: ['DEX', 'Ethereum'], apiDocs: 'https://docs.uniswap.org/' },
  { id: 'jupiter', name: 'Jupiter', logo: '🪐', region: 'DeFi/Solana', category: 'defi', volume: '1B', features: ['DEX Aggregator', 'Solana'], apiDocs: 'https://station.jup.ag/docs/' },
  { id: 'raydium', name: 'Raydium', logo: '💜', region: 'DeFi/Solana', category: 'defi', volume: '500M', features: ['AMM', 'Solana'], apiDocs: 'https://raydium.gitbook.io/' },
  { id: 'pancakeswap', name: 'PancakeSwap', logo: '🥞', region: 'DeFi/BSC', category: 'defi', volume: '800M', features: ['DEX', 'BSC'], apiDocs: 'https://docs.pancakeswap.finance/' },
  
  // Regional Exchanges
  { id: 'bitflyer', name: 'bitFlyer', logo: '🔵', region: 'Japan/US', category: 'regional', volume: '200M', features: ['Regulated Japan', 'Spot'], apiDocs: 'https://lightning.bitflyer.com/docs' },
  { id: 'bithumb', name: 'Bithumb', logo: '🟧', region: 'Korea', category: 'regional', volume: '400M', features: ['Top Korean Exchange'], apiDocs: 'https://apidocs.bithumb.com/' },
  { id: 'upbit', name: 'Upbit', logo: '🔵', region: 'Korea', category: 'regional', volume: '1.5B', features: ['Largest Korean Exchange'], apiDocs: 'https://docs.upbit.com/' },
  { id: 'lbank', name: 'LBank', logo: '🔷', region: 'Global', category: 'regional', volume: '300M', features: ['Altcoins', 'Spot'], apiDocs: 'https://www.lbank.info/api/' },
  { id: 'coinex', name: 'CoinEx', logo: '🟢', region: 'Global', category: 'regional', volume: '200M', features: ['AMM', 'Spot'], apiDocs: 'https://viabtc.github.io/coinex_api_en_doc/' },
  
  // Traditional Brokers with Crypto
  { id: 'etoro', name: 'eToro', logo: '🟢', region: 'Global', category: 'traditional', volume: '1B', features: ['Copy Trading', 'Stocks+Crypto'], apiDocs: 'https://api.etoro.com/' },
  { id: 'interactive', name: 'Interactive Brokers', logo: '🔴', region: 'US/Global', category: 'traditional', volume: '500M', features: ['Multi-Asset', 'Professional'], apiDocs: 'https://interactivebrokers.github.io/tws-api/' },
] as const;

export const BOT_TIERS = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    tradesPerDay: 15,
    indicators: ['SMA', 'EMA', 'RSI'],
    features: ['8 Bots (Grid/DCA/Trailing/Rebalancing/Infinity Grid/Reverse Grid/Auto-Invest/Spot-Futures Arbitrage)', '15 real trades per day', '35 bots per trading pair', 'No portfolio size cap', 'Demo sandbox with $10k simulated funds', 'Connect 2 exchanges', 'Backtesting with historical data', 'Portfolio tracking & overview', 'AI parameter suggestions', 'Real-time market data', 'Copy bot leaderboard preview', 'Basic price alerts', 'Basic candlestick charts', 'Email alerts', 'No KYC required', '450 API requests/second'],
    exchangeLimit: 2,
    botStrategies: ['Grid Bot', 'DCA Bot', 'Trailing Stop Bot', 'Rebalancing Bot', 'Infinity Grid Bot', 'Reverse Grid Bot', 'Auto-Invest Bot', 'Spot-Futures Arbitrage Bot'],
    aiBots: 8,
    aiFeatures: ['basic_patterns', 'basic_sentiment', 'ai_suggestions'],
    thirdPartyBots: false,
    color: '#9CA3AF',
    maxBotsPerPair: 35,
    apiRateLimit: 450,
    aiSentiment: false,
    alphaVisionCreditsPerMonth: 0,
  },
  {
    id: 'basic',
    name: 'Basic',
    price: 2900,
    tradesPerDay: 80,
    indicators: ['SMA', 'EMA', 'RSI', 'MACD', 'Bollinger Bands', 'Stochastic'],
    features: ['All Free features', '80 signals per day', '5 AI Trading Bots', 'TWAP & Signal Bots', '3 exchange connections', 'Telegram & email alerts', 'Strategy Designer (basic)', 'Backtesting', 'Multi-pair support'],
    exchangeLimit: 3,
    botStrategies: ['Grid Bot', 'DCA Bot', 'Trailing Stop Bot', 'TWAP Bot', 'Signal Bot'],
    aiBots: 5,
    aiFeatures: ['full_patterns', 'sentiment_trending', 'basic_alerts', 'strategy_designer'],
    thirdPartyBots: false,
    color: '#3B82F6',
    aiSentiment: false,
    alphaVisionCreditsPerMonth: 0,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 6900,
    tradesPerDay: 200,
    indicators: ['All Basic indicators', 'Stochastic RSI', 'ADX', 'OBV', 'VWAP', 'Ichimoku Cloud', 'ATR', 'Williams %R'],
    features: ['All Basic features', '200 signals per day', '15 AI Trading Bots + 10 Proprietary Technologies', 'All 11 Bot Types', 'SmartTrade Terminal', 'TradingView Webhooks', 'Copy Trading', 'Leveraged Grid Bot', 'Rebalancing Bot', 'Strategy Marketplace', '7 exchange connections', 'Priority support', 'Conditional automation', 'AI News Sentiment Analysis'],
    exchangeLimit: 7,
    botStrategies: ['All Bot Types', 'SmartTrade', 'Leveraged Grid', 'Rebalancing', 'Spot-Futures Arbitrage'],
    aiBots: 15,
    aiFeatures: ['full_patterns', 'ai_support_resistance', 'full_sentiment', 'breakout_probability', 'third_party_bots', 'strategy_marketplace', 'tradingview_webhooks', 'conditional_automation'],
    thirdPartyBots: true,
    color: '#A855F7',
    aiSentiment: true,
    alphaVisionCreditsPerMonth: 0,
  },
  {
    id: 'platinum',
    name: 'Platinum',
    price: 9900,
    tradesPerDay: 500,
    indicators: ['All Premium indicators', 'Fibonacci Retracements', 'Elliott Wave', 'Market Cipher', 'Hull MA'],
    features: ['All Premium features', '500 signals per day', '25 AI Trading Bots + 15 Proprietary Technologies', 'AI Strategy Selection', 'Futures Trading', 'Multi-pair bot support', 'Position scaling', '10 exchange connections', 'Advanced analytics', 'Strategy templates library', 'Priority execution', 'AI News Sentiment Analysis', '10 Alpha Vision™ credits/month'],
    exchangeLimit: 10,
    botStrategies: ['All strategies', 'AI-Optimized Strategies', 'Futures Bot'],
    aiBots: 25,
    aiFeatures: ['all'],
    thirdPartyBots: true,
    color: '#EC4899',
    aiSentiment: true,
    alphaVisionCreditsPerMonth: 10,
  },
  {
    id: 'alpha',
    name: 'Alpha',
    price: 14900,
    tradesPerDay: -1,
    indicators: ['All Platinum indicators', 'Custom indicator builder', '130+ indicators'],
    features: ['All Platinum features', 'Unlimited signals', 'Unlimited AI Trading Bots + All 18 Proprietary Technologies', 'Custom Bot Builder', 'Custom Strategy Designer', 'All exchanges', 'API access', 'White-label options', 'Dedicated account manager', 'AI auto-optimization', 'Sell strategies on Marketplace', 'AI News Sentiment Analysis', '50 Alpha Vision™ credits/month'],
    exchangeLimit: -1,
    botStrategies: ['All strategies', 'Custom Bot Builder', 'AI-Powered Trading', 'White-label Bots'],
    aiBots: -1,
    aiFeatures: ['all'],
    thirdPartyBots: true,
    color: '#FFD700',
    aiSentiment: true,
    alphaVisionCreditsPerMonth: 50,
  },
] as const;

export const PREMIUM_ADDONS = [
  {
    id: 'signals_pro',
    name: 'Premium Signals',
    price: 1200,
    description: 'Real-time ANCE™ & ANCE²™ AI trading signals with instant alerts',
    features: [
      'Real-time ANCE™ 7-layer AI signals',
      'ANCE²™ Meta-Intelligence alerts',
      'Multi-timeframe signal analysis',
      'Signal strength scoring',
      'Push & email signal notifications',
      'Historical signal performance',
    ],
    icon: 'brain',
    color: '#8B5CF6',
    stripeMetadataKey: 'signals_pro',
  },
  {
    id: 'arbitrage_pro',
    name: 'Arbitrage Scanner Pro',
    price: 900,
    description: 'Full exchange coverage with real-time arbitrage alerts',
    features: [
      'Scan all 10+ exchanges simultaneously',
      'Real-time price discrepancy alerts',
      'Multi-pair arbitrage detection',
      'Fee-adjusted profit calculation',
      'Historical arbitrage opportunities',
      'Custom alert thresholds',
    ],
    icon: 'shuffle',
    color: '#06B6D4',
    stripeMetadataKey: 'arbitrage_pro',
  },
  {
    id: 'whale_alerts',
    name: 'Whale Alert Premium',
    price: 700,
    description: 'Customizable whale movement tracking and instant notifications',
    features: [
      'Custom whale threshold settings',
      'Real-time whale transaction alerts',
      'Historical whale movement data',
      'Whale wallet tracking',
      'Exchange flow analysis',
      'Push & email whale notifications',
    ],
    icon: 'activity',
    color: '#3B82F6',
    stripeMetadataKey: 'whale_alerts',
  },
  {
    id: 'backtesting_pro',
    name: 'Backtesting Pro',
    price: 800,
    description: 'Unlimited strategy backtests with extended historical data',
    features: [
      'Unlimited backtests per month',
      '5+ years historical data',
      'Advanced performance metrics',
      'Multi-pair strategy testing',
      'Custom indicator backtesting',
      'Strategy comparison tools',
    ],
    icon: 'clock',
    color: '#F59E0B',
    stripeMetadataKey: 'backtesting_pro',
  },
  {
    id: 'copy_trading',
    name: 'Copy Trading Access',
    price: 1500,
    description: 'Copy top-performing traders and replicate their strategies',
    features: [
      'Access top trader leaderboard',
      'One-click trade copying',
      'Adjustable position sizing',
      'Risk management controls',
      'Trader performance analytics',
      'Real-time copy notifications',
    ],
    icon: 'users',
    color: '#EC4899',
    stripeMetadataKey: 'copy_trading',
  },
] as const;

export const userAddonSubscriptions = pgTable("user_addon_subscriptions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  addonId: text("addon_id").notNull(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  status: text("status").notNull().default("active"),
  currentPeriodEnd: timestamp("current_period_end"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserAddonSubscriptionSchema = createInsertSchema(userAddonSubscriptions).omit({ id: true, createdAt: true });
export type InsertUserAddonSubscription = z.infer<typeof insertUserAddonSubscriptionSchema>;
export type UserAddonSubscription = typeof userAddonSubscriptions.$inferSelect;

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  tradingSignals: boolean("trading_signals").notNull().default(true),
  priceAlerts: boolean("price_alerts").notNull().default(true),
  portfolioChanges: boolean("portfolio_changes").notNull().default(true),
  securityAlerts: boolean("security_alerts").notNull().default(true),
  newsUpdates: boolean("news_updates").notNull().default(false),
});

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({ id: true, createdAt: true });
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;
export type PushSubscription = typeof pushSubscriptions.$inferSelect;

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({ id: true });
export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;

// ============================================
// Watchlist / Price Alerts System
// ============================================

export const watchlistAlerts = pgTable("watchlist_alerts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  symbol: text("symbol").notNull(),
  targetPrice: real("target_price").notNull(),
  direction: text("direction").notNull(), // 'above' or 'below'
  isActive: boolean("is_active").notNull().default(true),
  triggeredAt: timestamp("triggered_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const emailNotificationLog = pgTable("email_notification_log", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  emailType: text("email_type").notNull(),
  referenceId: text("reference_id"),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
});

export const insertWatchlistAlertSchema = createInsertSchema(watchlistAlerts).omit({ id: true, createdAt: true, triggeredAt: true });
export type InsertWatchlistAlert = z.infer<typeof insertWatchlistAlertSchema>;
export type WatchlistAlert = typeof watchlistAlerts.$inferSelect;

export const insertEmailNotificationLogSchema = createInsertSchema(emailNotificationLog).omit({ id: true, sentAt: true });
export type InsertEmailNotificationLog = z.infer<typeof insertEmailNotificationLogSchema>;
export type EmailNotificationLog = typeof emailNotificationLog.$inferSelect;

// ============================================
// Wallet & Platform Integration System
// ============================================

export const connectedIntegrations = pgTable("connected_integrations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  providerType: text("provider_type").notNull(), // 'wallet' or 'exchange'
  providerId: text("provider_id").notNull(), // e.g., 'phantom', 'binance', 'jupiter'
  providerName: text("provider_name").notNull(),
  walletAddress: text("wallet_address"), // For wallets
  publicKey: text("public_key"), // For wallet signing
  accessTokenEncrypted: text("access_token_encrypted"), // OAuth token (encrypted)
  refreshTokenEncrypted: text("refresh_token_encrypted"), // OAuth refresh (encrypted)
  tokenExpiry: timestamp("token_expiry"), // When access token expires
  sessionTopic: text("session_topic"), // WalletConnect session topic
  permissions: json("permissions").$type<string[]>().notNull().default([]),
  chainId: text("chain_id"), // e.g., 'solana', 'ethereum', 'bsc'
  isActive: boolean("is_active").notNull().default(true),
  lastPing: timestamp("last_ping"), // Heartbeat timestamp
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const integrationCommands = pgTable("integration_commands", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  integrationId: integer("integration_id").notNull(),
  commandType: text("command_type").notNull(), // 'trade', 'switch_pair', 'get_balance', etc.
  payload: json("payload").$type<Record<string, any>>().notNull(),
  status: text("status").notNull().default("pending"), // 'pending', 'sent', 'completed', 'failed'
  response: json("response").$type<Record<string, any>>(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const integrationCallbacks = pgTable("integration_callbacks", {
  id: serial("id").primaryKey(),
  state: text("state").notNull().unique(), // CSRF state token
  userId: text("user_id"),
  providerId: text("provider_id").notNull(),
  redirectUrl: text("redirect_url").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertConnectedIntegrationSchema = createInsertSchema(connectedIntegrations).omit({ 
  id: true, createdAt: true, updatedAt: true, lastPing: true 
});
export const insertIntegrationCommandSchema = createInsertSchema(integrationCommands).omit({ 
  id: true, createdAt: true, completedAt: true 
});
export const insertIntegrationCallbackSchema = createInsertSchema(integrationCallbacks).omit({ 
  id: true, createdAt: true 
});

export type ConnectedIntegration = typeof connectedIntegrations.$inferSelect;
export type InsertConnectedIntegration = z.infer<typeof insertConnectedIntegrationSchema>;
export type IntegrationCommand = typeof integrationCommands.$inferSelect;
export type InsertIntegrationCommand = z.infer<typeof insertIntegrationCommandSchema>;
export type IntegrationCallback = typeof integrationCallbacks.$inferSelect;
export type InsertIntegrationCallback = z.infer<typeof insertIntegrationCallbackSchema>;

// Wallet categories and supported wallets
export const WALLET_CATEGORIES = {
  popular: 'Most Popular',
  solana: 'Solana',
  evm: 'EVM/Ethereum',
  bitcoin: 'Bitcoin',
  multichain: 'Multi-Chain',
  cosmos: 'Cosmos/IBC',
  cardano: 'Cardano',
  hardware: 'Hardware',
  other: 'Other Chains',
} as const;

export const SUPPORTED_WALLETS = [
  // Most Popular
  { id: 'phantom', name: 'Phantom', chain: 'solana', category: 'popular', deepLink: 'phantom://', installUrl: 'https://phantom.app/', supportsConnect: true },
  { id: 'solflare', name: 'Solflare', chain: 'solana', category: 'popular', deepLink: 'solflare://', installUrl: 'https://solflare.com/', supportsConnect: true },
  { id: 'metamask', name: 'MetaMask', chain: 'ethereum', category: 'popular', deepLink: 'metamask://', installUrl: 'https://metamask.io/', supportsConnect: true },
  { id: 'trust', name: 'Trust Wallet', chain: 'multi', category: 'popular', deepLink: 'trust://', installUrl: 'https://trustwallet.com/', supportsConnect: true },
  { id: 'coinbase-wallet', name: 'Coinbase Wallet', chain: 'multi', category: 'popular', deepLink: 'cbwallet://', installUrl: 'https://www.coinbase.com/wallet', supportsConnect: true },
  { id: 'okx-wallet', name: 'OKX Wallet', chain: 'multi', category: 'popular', deepLink: 'okx://', installUrl: 'https://www.okx.com/web3', supportsConnect: true },
  
  // Solana
  { id: 'backpack', name: 'Backpack', chain: 'solana', category: 'solana', deepLink: 'backpack://', installUrl: 'https://backpack.app/', supportsConnect: true },
  { id: 'glow', name: 'Glow', chain: 'solana', category: 'solana', deepLink: 'glow://', installUrl: 'https://glow.app/', supportsConnect: true },
  
  // EVM
  { id: 'rabby', name: 'Rabby', chain: 'ethereum', category: 'evm', deepLink: null, installUrl: 'https://rabby.io/', supportsConnect: false },
  { id: 'rainbow', name: 'Rainbow', chain: 'ethereum', category: 'evm', deepLink: 'rainbow://', installUrl: 'https://rainbow.me/', supportsConnect: true },
  
  // Hardware
  { id: 'ledger', name: 'Ledger', chain: 'multi', category: 'hardware', deepLink: 'ledgerlive://', installUrl: 'https://www.ledger.com/', supportsConnect: true },
  { id: 'trezor', name: 'Trezor', chain: 'multi', category: 'hardware', deepLink: null, installUrl: 'https://trezor.io/', supportsConnect: false },
] as const;

// Command types for the integration broker
export const COMMAND_TYPES = {
  TRADE: 'trade',
  SWITCH_PAIR: 'switch_pair',
  GET_BALANCE: 'get_balance',
  GET_POSITIONS: 'get_positions',
  CANCEL_ORDER: 'cancel_order',
  SIGN_TRANSACTION: 'sign_transaction',
} as const;

// ============================================
// Strategy Backtesting System
// ============================================

export const backtestStrategies = pgTable("backtest_strategies", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  strategyType: text("strategy_type").notNull(), // 'ma_crossover', 'rsi_reversal', 'macd_signal', 'bollinger_bounce', 'breakout', 'custom'
  parameters: json("parameters").$type<Record<string, any>>().notNull(),
  isPublic: boolean("is_public").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const backtestResults = pgTable("backtest_results", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  strategyId: integer("strategy_id"),
  strategyName: text("strategy_name").notNull(),
  symbol: text("symbol").notNull(),
  timeframe: text("timeframe").notNull(), // '1h', '4h', '1d', '1w'
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  initialCapital: real("initial_capital").notNull(),
  finalCapital: real("final_capital").notNull(),
  totalReturn: real("total_return").notNull(),
  totalReturnPercent: real("total_return_percent").notNull(),
  maxDrawdown: real("max_drawdown").notNull(),
  maxDrawdownPercent: real("max_drawdown_percent").notNull(),
  sharpeRatio: real("sharpe_ratio"),
  winRate: real("win_rate").notNull(),
  totalTrades: integer("total_trades").notNull(),
  winningTrades: integer("winning_trades").notNull(),
  losingTrades: integer("losing_trades").notNull(),
  avgWin: real("avg_win"),
  avgLoss: real("avg_loss"),
  profitFactor: real("profit_factor"),
  equityCurve: json("equity_curve").$type<{ time: number; equity: number }[]>().notNull(),
  trades: json("trades").$type<{
    entryTime: number;
    exitTime: number;
    side: 'long' | 'short';
    entryPrice: number;
    exitPrice: number;
    quantity: number;
    pnl: number;
    pnlPercent: number;
  }[]>().notNull(),
  parameters: json("parameters").$type<Record<string, any>>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBacktestStrategySchema = createInsertSchema(backtestStrategies).omit({ 
  id: true, createdAt: true, updatedAt: true 
});
export const insertBacktestResultSchema = createInsertSchema(backtestResults).omit({ 
  id: true, createdAt: true 
});

export type BacktestStrategy = typeof backtestStrategies.$inferSelect;
export type InsertBacktestStrategy = z.infer<typeof insertBacktestStrategySchema>;
export type BacktestResult = typeof backtestResults.$inferSelect;
export type InsertBacktestResult = z.infer<typeof insertBacktestResultSchema>;

export const BACKTEST_STRATEGIES = [
  {
    id: 'ma_crossover',
    name: 'Moving Average Crossover',
    description: 'Buy when fast MA crosses above slow MA, sell when it crosses below',
    parameters: {
      fastPeriod: { type: 'number', default: 9, min: 2, max: 50, label: 'Fast MA Period' },
      slowPeriod: { type: 'number', default: 21, min: 5, max: 200, label: 'Slow MA Period' },
      maType: { type: 'select', default: 'EMA', options: ['SMA', 'EMA'], label: 'MA Type' },
    },
  },
  {
    id: 'rsi_reversal',
    name: 'RSI Reversal',
    description: 'Buy when RSI crosses above oversold level, sell when it crosses below overbought',
    parameters: {
      period: { type: 'number', default: 14, min: 2, max: 50, label: 'RSI Period' },
      oversold: { type: 'number', default: 30, min: 10, max: 40, label: 'Oversold Level' },
      overbought: { type: 'number', default: 70, min: 60, max: 90, label: 'Overbought Level' },
    },
  },
  {
    id: 'macd_signal',
    name: 'MACD Signal',
    description: 'Buy when MACD crosses above signal line, sell when it crosses below',
    parameters: {
      fastPeriod: { type: 'number', default: 12, min: 5, max: 30, label: 'Fast Period' },
      slowPeriod: { type: 'number', default: 26, min: 15, max: 50, label: 'Slow Period' },
      signalPeriod: { type: 'number', default: 9, min: 3, max: 20, label: 'Signal Period' },
    },
  },
  {
    id: 'bollinger_bounce',
    name: 'Bollinger Bounce',
    description: 'Buy when price touches lower band, sell when it touches upper band',
    parameters: {
      period: { type: 'number', default: 20, min: 10, max: 50, label: 'BB Period' },
      stdDev: { type: 'number', default: 2, min: 1, max: 3, label: 'Std Deviation' },
    },
  },
  {
    id: 'breakout',
    name: 'Breakout Strategy',
    description: 'Buy when price breaks above resistance with volume confirmation',
    parameters: {
      lookbackPeriod: { type: 'number', default: 20, min: 5, max: 100, label: 'Lookback Period' },
      volumeMultiplier: { type: 'number', default: 1.5, min: 1, max: 5, label: 'Volume Multiplier' },
    },
  },
] as const;

export const promoCodes = pgTable("promo_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  ownerUserId: text("owner_user_id").notNull(),
  ownerDisplayName: text("owner_display_name"),
  discountPercent: integer("discount_percent").notNull().default(10),
  commissionPercent: integer("commission_percent").notNull().default(10),
  maxRedemptions: integer("max_redemptions"),
  currentRedemptions: integer("current_redemptions").notNull().default(0),
  totalEarnings: real("total_earnings").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPromoCodeSchema = createInsertSchema(promoCodes).omit({ id: true, createdAt: true, currentRedemptions: true, totalEarnings: true });
export type InsertPromoCode = z.infer<typeof insertPromoCodeSchema>;
export type PromoCode = typeof promoCodes.$inferSelect;

export const promoRedemptions = pgTable("promo_redemptions", {
  id: serial("id").primaryKey(),
  promoCodeId: integer("promo_code_id").notNull(),
  promoCode: text("promo_code").notNull(),
  redeemerUserId: text("redeemer_user_id").notNull(),
  referrerUserId: text("referrer_user_id").notNull(),
  stripeSessionId: text("stripe_session_id"),
  purchaseType: text("purchase_type").notNull(),
  purchaseAmount: real("purchase_amount").notNull(),
  discountAmount: real("discount_amount").notNull(),
  commissionAmount: real("commission_amount").notNull(),
  commissionPaid: boolean("commission_paid").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPromoRedemptionSchema = createInsertSchema(promoRedemptions).omit({ id: true, createdAt: true });
export type InsertPromoRedemption = z.infer<typeof insertPromoRedemptionSchema>;
export type PromoRedemption = typeof promoRedemptions.$inferSelect;

export const qmgeLicenses = pgTable("qmge_licenses", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  licenseKey: text("license_key").notNull().unique(),
  tier: text("tier").notNull().default("free"),
  status: text("status").notNull().default("active"),
  activatedIp: text("activated_ip"),
  lastVerifiedIp: text("last_verified_ip"),
  ipFingerprint: text("ip_fingerprint"),
  hardwareFingerprint: text("hardware_fingerprint"),
  trialStartedAt: timestamp("trial_started_at"),
  trialExpiresAt: timestamp("trial_expires_at"),
  totalUsageMinutes: integer("total_usage_minutes").notNull().default(0),
  maxUsageMinutes: integer("max_usage_minutes").notNull().default(1440),
  lastSessionStart: timestamp("last_session_start"),
  lastHeartbeat: timestamp("last_heartbeat"),
  vpnDetectedCount: integer("vpn_detected_count").notNull().default(0),
  vpnBlocked: boolean("vpn_blocked").notNull().default(false),
  stripePaymentId: text("stripe_payment_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  dimensionsUnlocked: integer("dimensions_unlocked").notNull().default(2),
  dataDelay: integer("data_delay_seconds").notNull().default(900),
  patternsUnlocked: integer("patterns_unlocked").notNull().default(3),
  exchangeLimit: integer("exchange_limit").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertQmgeLicenseSchema = createInsertSchema(qmgeLicenses).omit({ id: true, createdAt: true, updatedAt: true, totalUsageMinutes: true, vpnDetectedCount: true });
export type InsertQmgeLicense = z.infer<typeof insertQmgeLicenseSchema>;
export type QmgeLicense = typeof qmgeLicenses.$inferSelect;

export const qmgeLicenseEvents = pgTable("qmge_license_events", {
  id: serial("id").primaryKey(),
  licenseId: integer("license_id").notNull(),
  userId: text("user_id").notNull(),
  eventType: text("event_type").notNull(),
  ip: text("ip"),
  vpnDetected: boolean("vpn_detected").notNull().default(false),
  details: json("details").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type QmgeLicenseEvent = typeof qmgeLicenseEvents.$inferSelect;

export const softwareProducts = pgTable("software_products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  description: text("description").notNull(),
  priceCents: integer("price_cents").notNull(),
  category: text("category").notNull().default("indicator"),
  features: json("features").$type<string[]>().notNull(),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const insertSoftwareProductSchema = createInsertSchema(softwareProducts).omit({ id: true });
export type InsertSoftwareProduct = z.infer<typeof insertSoftwareProductSchema>;
export type SoftwareProduct = typeof softwareProducts.$inferSelect;

export const softwarePackagePurchases = pgTable("software_package_purchases", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  productIds: json("product_ids").$type<number[]>().notNull(),
  subtotalCents: integer("subtotal_cents").notNull(),
  discountPercent: integer("discount_percent").notNull().default(0),
  discountCents: integer("discount_cents").notNull().default(0),
  totalCents: integer("total_cents").notNull(),
  stripeSessionId: text("stripe_session_id"),
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  status: text("status").notNull().default("pending"),
  licenseKeys: json("license_keys").$type<Record<string, string>>(),
  purchasedAt: timestamp("purchased_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSoftwarePackagePurchaseSchema = createInsertSchema(softwarePackagePurchases).omit({ id: true, createdAt: true });
export type InsertSoftwarePackagePurchase = z.infer<typeof insertSoftwarePackagePurchaseSchema>;
export type SoftwarePackagePurchase = typeof softwarePackagePurchases.$inferSelect;

export const technologyEntitlements = pgTable("technology_entitlements", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  technologySlug: text("technology_slug").notNull(),
  tier: text("tier").notNull().default("standard"),
  status: text("status").notNull().default("active"),
  licenseKey: text("license_key").notNull(),
  activatedIp: text("activated_ip"),
  lastVerifiedIp: text("last_verified_ip"),
  deviceFingerprint: text("device_fingerprint"),
  hardwareHash: text("hardware_hash"),
  sessionToken: text("session_token"),
  tokenExpiresAt: timestamp("token_expires_at"),
  lastHeartbeat: timestamp("last_heartbeat"),
  heartbeatCount: integer("heartbeat_count").notNull().default(0),
  missedHeartbeats: integer("missed_heartbeats").notNull().default(0),
  vpnDetectedCount: integer("vpn_detected_count").notNull().default(0),
  vpnBlocked: boolean("vpn_blocked").notNull().default(false),
  tamperScore: integer("tamper_score").notNull().default(0),
  tamperEvents: json("tamper_events").$type<string[]>(),
  maxConcurrentDevices: integer("max_concurrent_devices").notNull().default(1),
  activeDeviceCount: integer("active_device_count").notNull().default(0),
  totalUsageMinutes: integer("total_usage_minutes").notNull().default(0),
  lastUsedAt: timestamp("last_used_at"),
  purchaseId: integer("purchase_id"),
  stripePaymentId: text("stripe_payment_id"),
  expiresAt: timestamp("expires_at"),
  revokedAt: timestamp("revoked_at"),
  revokeReason: text("revoke_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertTechnologyEntitlementSchema = createInsertSchema(technologyEntitlements).omit({ id: true, createdAt: true, updatedAt: true, heartbeatCount: true, missedHeartbeats: true, vpnDetectedCount: true, tamperScore: true, activeDeviceCount: true, totalUsageMinutes: true });
export type InsertTechnologyEntitlement = z.infer<typeof insertTechnologyEntitlementSchema>;
export type TechnologyEntitlement = typeof technologyEntitlements.$inferSelect;

export const softwareSecurityEvents = pgTable("software_security_events", {
  id: serial("id").primaryKey(),
  userId: text("user_id"),
  technologySlug: text("technology_slug"),
  entitlementId: integer("entitlement_id"),
  eventType: text("event_type").notNull(),
  severity: text("severity").notNull().default("info"),
  ip: text("ip"),
  deviceFingerprint: text("device_fingerprint"),
  userAgent: text("user_agent"),
  vpnDetected: boolean("vpn_detected").notNull().default(false),
  details: json("details").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type SoftwareSecurityEvent = typeof softwareSecurityEvents.$inferSelect;

export const downloadTokens = pgTable("download_tokens", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  userId: text("user_id").notNull(),
  productSlug: text("product_slug").notNull(),
  purchaseId: integer("purchase_id"),
  entitlementId: integer("entitlement_id"),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  usedCount: integer("used_count").notNull().default(0),
  maxUses: integer("max_uses").notNull().default(3),
  ip: text("ip"),
  revoked: boolean("revoked").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertDownloadTokenSchema = createInsertSchema(downloadTokens).omit({ id: true, createdAt: true, usedCount: true });
export type InsertDownloadToken = z.infer<typeof insertDownloadTokenSchema>;
export type DownloadToken = typeof downloadTokens.$inferSelect;

export const TECHNOLOGY_PRODUCTS = [
  { slug: "qmge", name: "Quantum Market Genome Engine™ (QMGE)", shortName: "QMGE", priceCents: 299700, category: "engine", sortOrder: 1, description: "Full 7-dimension market analysis with genome pattern recognition, convergence scoring, and adaptive weight calibration. 5-30 minute predictions.", features: ["7-dimension analysis", "15+ genome patterns", "Adaptive weight calibration", "Convergence & mutation analysis", "5-30 min predictions"] },
  { slug: "ance", name: "Adaptive Neural Confluence Engine™ (ANCE)", shortName: "ANCE", priceCents: 199700, category: "engine", sortOrder: 2, description: "7-layer AI scoring system combining RSI, moving averages, volume, and momentum for precise signal generation.", features: ["7-layer neural scoring", "RSI + MA confluence", "Volume-weighted signals", "Triple MA alignment", "Composite scoring"] },
  { slug: "ance2", name: "ANCE² Meta-Intelligence Layer", shortName: "ANCE²", priceCents: 149700, category: "engine", sortOrder: 3, description: "Analyzes all primary technology outputs to produce meta-signals with convergence analysis and adaptive boosting.", features: ["Meta-signal generation", "Cross-technology analysis", "Convergence index", "Adaptive boosting", "Signal momentum tracking"] },
  { slug: "tmde", name: "Temporal Momentum Divergence Engine™ (TMDE)", shortName: "TMDE", priceCents: 129700, category: "engine", sortOrder: 4, description: "Cross-timeframe divergence analysis across 6 timeframes with compression/expansion/alignment cascade classification.", features: ["6-timeframe analysis", "Divergence classification", "Momentum velocity", "Compression detection", "Alignment cascade"] },
  { slug: "bridge-fusion", name: "Bridge Fusion™ Composite Indicator", shortName: "Bridge Fusion", priceCents: 99700, category: "indicator", sortOrder: 5, description: "Combines all 8 advanced market filters into a single composite signal with confidence scoring.", features: ["8-filter composite", "Confidence scoring", "Weighted aggregation", "Signal consensus", "Market regime detection"] },
  { slug: "acm", name: "Alpha Convergence Matrix™ (ACM)", shortName: "ACM", priceCents: 79900, category: "indicator", sortOrder: 6, description: "RSI momentum, volume flow, and trend alignment matrix for convergence-based entry and exit signals.", features: ["RSI momentum analysis", "Volume flow tracking", "Trend alignment", "Convergence scoring", "Entry/exit signals"] },
  { slug: "qfrm", name: "Quantum Flow Resonance Matrix™ (QFRM)", shortName: "QFRM", priceCents: 79900, category: "indicator", sortOrder: 7, description: "Returns variance analysis, flow strength measurement, and harmonic oscillation detection for market resonance patterns.", features: ["Flow strength analysis", "Harmonic oscillations", "Variance tracking", "Resonance patterns", "Stability scoring"] },
  { slug: "bif", name: "Blockchain Intelligence Filter™ (BIF)", shortName: "BIF", priceCents: 69900, category: "indicator", sortOrder: 8, description: "Network health analysis via volume patterns and price consistency checks for blockchain-native intelligence.", features: ["Network health scoring", "Volume pattern analysis", "Price consistency", "Blockchain metrics", "Health indicators"] },
  { slug: "sbpe", name: "Stochastic Block Prediction Engine™ (SBPE)", shortName: "SBPE", priceCents: 69900, category: "indicator", sortOrder: 9, description: "Stochastic oscillator with mean reversion analysis and drift detection for block-level price prediction.", features: ["Stochastic K analysis", "Mean reversion", "Drift detection", "Block prediction", "Reversal signals"] },
  { slug: "advanced-filters", name: "8 Advanced Market Filters™ — Bearish Lean Confirmation", shortName: "Advanced Filters", priceCents: 59900, category: "filter", sortOrder: 10, description: "Bearish Lean Confirmation layer — 8 microstructure filters that validate sell signals from other technologies. Validated: 56.5% holdout accuracy with MFT pairing across 48 coins.", features: ["Order Flow Imbalance", "Fair Value Gap", "Absorption Filter", "Fractal Energy", "Wyckoff Phase", "Entropy Regime", "Hurst Regime", "Delta Divergence"] },
  { slug: "probability-calculator", name: "Trading Probability Calculator", shortName: "Probability Calc", priceCents: 49900, category: "tool", sortOrder: 11, description: "Runs all technologies simultaneously, computes weighted profit probability, risk/reward ratio, and confidence scores.", features: ["Multi-technology analysis", "Weighted scoring", "Profit probability", "Risk/reward ratio", "Confidence scoring"] },
  { slug: "quantum-shield", name: "Alpha Quantum Shield Protocol™", shortName: "QSP", priceCents: 349700, category: "quantum-security", sortOrder: 12, description: "Post-quantum cryptographic defense layer with ML-KEM-1024 key encapsulation, real-time quantum threat detection, and automatic transaction blocking. NIST FIPS 203/204/205 compliant.", features: ["ML-KEM-1024 key encapsulation", "Real-time quantum threat detection", "Automatic threat blocking", "NIST Level 5 security", "Mempool-level protection"] },
  { slug: "quantum-scanner", name: "Quantum Vulnerability Scanner™", shortName: "QVS", priceCents: 199700, category: "quantum-security", sortOrder: 13, description: "ECDSA quantum exposure analysis and post-quantum readiness assessment. Scans wallets and contracts for quantum-vulnerable cryptographic operations.", features: ["ECDSA exposure analysis", "Contract risk assessment", "Quantum readiness scoring", "Vulnerability database", "Nonce pattern detection"] },
  { slug: "quantum-migration", name: "Alpha Quantum Migration Engine™", shortName: "QME", priceCents: 249700, category: "quantum-security", sortOrder: 14, description: "Zero-downtime post-quantum cryptographic migration with hybrid transition support. Generates step-by-step migration plans to NIST-approved algorithms.", features: ["Zero-downtime migration", "Hybrid ECDSA+ML-DSA transition", "Gas-optimized execution", "Automatic rollback", "Multi-algorithm support"] },
  { slug: "quantum-forensics", name: "Quantum Forensic Intelligence Module™", shortName: "QFIM", priceCents: 299700, category: "quantum-security", sortOrder: 15, description: "Post-quantum signature forensic deconstruction, quantum key extraction trace, and lattice-based evidence verification for court-admissible blockchain forensics.", features: ["Signature deconstruction", "Quantum key extraction trace", "Lattice-based evidence proofs", "Court admissibility", "Attack classification"] },
  { slug: "quantum-wrap", name: "SafeSend Quantum Wrap™", shortName: "SQW", priceCents: 149700, category: "quantum-security", sortOrder: 16, description: "ML-KEM transaction encapsulation that wraps every outgoing transaction in quantum-resistant key encapsulation with mempool protection and address binding.", features: ["ML-KEM encapsulation", "Mempool front-run protection", "Address binding verification", "256-bit quantum resistance", "Post-quantum lattice proofs"] },
] as const;

export const BUNDLE_DISCOUNT_TIERS = [
  { minItems: 2, maxItems: 3, discountPercent: 10, label: "10% Bundle Discount" },
  { minItems: 4, maxItems: 6, discountPercent: 15, label: "15% Bundle Discount" },
  { minItems: 7, maxItems: 9, discountPercent: 20, label: "20% Bundle Discount" },
  { minItems: 10, maxItems: 99, discountPercent: 25, label: "25% Ultimate Bundle" },
] as const;

export function getBundleDiscount(itemCount: number): { discountPercent: number; label: string } {
  for (const tier of BUNDLE_DISCOUNT_TIERS) {
    if (itemCount >= tier.minItems && itemCount <= tier.maxItems) {
      return { discountPercent: tier.discountPercent, label: tier.label };
    }
  }
  return { discountPercent: 0, label: "No discount" };
}

export const ALPHA_VISION_PACKAGES = [
  { id: "av_starter", name: "Starter Pack", credits: 10, priceUSD: 7.99, popular: false },
  { id: "av_standard", name: "Standard Pack", credits: 30, priceUSD: 19.99, popular: true },
  { id: "av_pro", name: "Pro Pack", credits: 75, priceUSD: 39.99, popular: false },
  { id: "av_elite", name: "Elite Pack", credits: 200, priceUSD: 79.99, popular: false },
] as const;

export const alphaVisionCredits = pgTable("alpha_vision_credits", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  packageId: text("package_id").notNull(),
  totalCredits: integer("total_credits").notNull(),
  remainingCredits: integer("remaining_credits").notNull(),
  stripePaymentId: text("stripe_payment_id"),
  stripeSessionId: text("stripe_session_id"),
  status: text("status").notNull().default("active"),
  purchasedAt: timestamp("purchased_at").notNull().defaultNow(),
});

export const alphaVisionUsage = pgTable("alpha_vision_usage", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  creditId: integer("credit_id").notNull(),
  symbol: text("symbol").notNull(),
  interval: text("interval").notNull(),
  analysisType: text("analysis_type").notNull().default("full"),
  indicatorsUsed: json("indicators_used").$type<string[]>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAlphaVisionCreditSchema = createInsertSchema(alphaVisionCredits).omit({ id: true, purchasedAt: true });
export const insertAlphaVisionUsageSchema = createInsertSchema(alphaVisionUsage).omit({ id: true, createdAt: true });

export type AlphaVisionCredit = typeof alphaVisionCredits.$inferSelect;
export type InsertAlphaVisionCredit = z.infer<typeof insertAlphaVisionCreditSchema>;
export type AlphaVisionUsage = typeof alphaVisionUsage.$inferSelect;
export type InsertAlphaVisionUsage = z.infer<typeof insertAlphaVisionUsageSchema>;

export const ambassadorApplications = pgTable("ambassador_applications", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  displayName: text("display_name").notNull(),
  organization: text("organization"),
  bio: text("bio").notNull(),
  websiteUrl: text("website_url"),
  profileImageUrl: text("profile_image_url"),
  categories: json("categories").$type<string[]>().default([]),
  followerCount: text("follower_count"),
  promoCode: text("promo_code").unique(),
  totalReferrals: integer("total_referrals").notNull().default(0),
  totalRevenue: real("total_revenue").notNull().default(0),
  totalClicks: integer("total_clicks").notNull().default(0),
  rank: integer("rank"),
  complianceAck: boolean("compliance_ack").notNull().default(false),
  status: text("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  reviewedBy: text("reviewed_by"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
  approvedAt: timestamp("approved_at"),
  probationEndsAt: timestamp("probation_ends_at"),
  probationStatus: text("probation_status").default("none"),
  warningCount: integer("warning_count").notNull().default(0),
  lastWarningAt: timestamp("last_warning_at"),
  featureAccess: json("feature_access").$type<string[]>().default([]),
  terminatedAt: timestamp("terminated_at"),
  terminationReason: text("termination_reason"),
});

export const ambassadorSocialLinks = pgTable("ambassador_social_links", {
  id: serial("id").primaryKey(),
  ambassadorId: integer("ambassador_id").notNull(),
  platform: text("platform").notNull(),
  handle: text("handle").notNull(),
  url: text("url").notNull(),
  followerCount: text("follower_count"),
  status: text("status").notNull().default("pending"),
  reviewedBy: text("reviewed_by"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const ambassadorMedia = pgTable("ambassador_media", {
  id: serial("id").primaryKey(),
  ambassadorId: integer("ambassador_id").notNull(),
  mediaType: text("media_type").notNull().default("video"),
  title: text("title").notNull(),
  description: text("description"),
  fileUrl: text("file_url"),
  embedUrl: text("embed_url"),
  thumbnailUrl: text("thumbnail_url"),
  status: text("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  reviewedBy: text("reviewed_by"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const ambassadorReferrals = pgTable("ambassador_referrals", {
  id: serial("id").primaryKey(),
  ambassadorId: integer("ambassador_id").notNull(),
  promoCode: text("promo_code").notNull(),
  visitorIp: text("visitor_ip"),
  referredUserId: text("referred_user_id"),
  action: text("action").notNull().default("click"),
  revenueGenerated: real("revenue_generated").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAmbassadorApplicationSchema = createInsertSchema(ambassadorApplications).omit({ id: true, submittedAt: true, reviewedAt: true, promoCode: true, totalReferrals: true, totalRevenue: true, totalClicks: true, rank: true, approvedAt: true, probationEndsAt: true, probationStatus: true, warningCount: true, lastWarningAt: true, featureAccess: true, terminatedAt: true, terminationReason: true });
export const insertAmbassadorSocialLinkSchema = createInsertSchema(ambassadorSocialLinks).omit({ id: true, submittedAt: true, reviewedAt: true });
export const insertAmbassadorMediaSchema = createInsertSchema(ambassadorMedia).omit({ id: true, submittedAt: true, reviewedAt: true });
export const insertAmbassadorReferralSchema = createInsertSchema(ambassadorReferrals).omit({ id: true, createdAt: true });

export type AmbassadorApplication = typeof ambassadorApplications.$inferSelect;
export type InsertAmbassadorApplication = z.infer<typeof insertAmbassadorApplicationSchema>;
export type AmbassadorSocialLink = typeof ambassadorSocialLinks.$inferSelect;
export type InsertAmbassadorSocialLink = z.infer<typeof insertAmbassadorSocialLinkSchema>;
export type AmbassadorMedia = typeof ambassadorMedia.$inferSelect;
export type InsertAmbassadorMedia = z.infer<typeof insertAmbassadorMediaSchema>;
export type AmbassadorReferral = typeof ambassadorReferrals.$inferSelect;
export type InsertAmbassadorReferral = z.infer<typeof insertAmbassadorReferralSchema>;

export const ambassadorSocialPosts = pgTable("ambassador_social_posts", {
  id: serial("id").primaryKey(),
  ambassadorId: integer("ambassador_id").notNull(),
  platform: text("platform").notNull(),
  postUrl: text("post_url").notNull(),
  embedHtml: text("embed_html"),
  caption: text("caption"),
  status: text("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  reviewedBy: text("reviewed_by"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const insertAmbassadorSocialPostSchema = createInsertSchema(ambassadorSocialPosts).omit({ id: true, submittedAt: true, reviewedAt: true });
export type AmbassadorSocialPost = typeof ambassadorSocialPosts.$inferSelect;
export type InsertAmbassadorSocialPost = z.infer<typeof insertAmbassadorSocialPostSchema>;

export const promoCodeClaims = pgTable("promo_code_claims", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  promoCode: text("promo_code").notNull(),
  ambassadorId: integer("ambassador_id").notNull(),
  ipAddress: text("ip_address").notNull(),
  used: boolean("used").notNull().default(false),
  usedAt: timestamp("used_at"),
  stripeSessionId: text("stripe_session_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPromoCodeClaimSchema = createInsertSchema(promoCodeClaims).omit({ id: true, createdAt: true, used: true, usedAt: true, stripeSessionId: true });
export type PromoCodeClaim = typeof promoCodeClaims.$inferSelect;
export type InsertPromoCodeClaim = z.infer<typeof insertPromoCodeClaimSchema>;

export const AMBASSADOR_SOCIAL_PLATFORMS = [
  "twitter", "instagram", "tiktok", "youtube", "facebook", "linkedin", "twitch", "discord", "telegram", "reddit"
] as const;

export const userActivityLog = pgTable("user_activity_log", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  action: text("action").notNull(),
  category: text("category").notNull(),
  metadata: json("metadata"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserActivityLogSchema = createInsertSchema(userActivityLog).omit({ id: true, createdAt: true });
export type UserActivityLog = typeof userActivityLog.$inferSelect;
export type InsertUserActivityLog = z.infer<typeof insertUserActivityLogSchema>;

export const trialCodes = pgTable("trial_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  technologySlug: text("technology_slug").notNull(),
  durationDays: integer("duration_days").notNull().default(30),
  maxUses: integer("max_uses").notNull().default(1),
  usedCount: integer("used_count").notNull().default(0),
  redeemedByUserId: text("redeemed_by_user_id"),
  redeemedAt: timestamp("redeemed_at"),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").notNull().default(true),
  createdByAdminId: text("created_by_admin_id"),
  note: text("note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTrialCodeSchema = createInsertSchema(trialCodes).omit({ id: true, createdAt: true, usedCount: true });
export type TrialCode = typeof trialCodes.$inferSelect;
export type InsertTrialCode = z.infer<typeof insertTrialCodeSchema>;

export const serverBots = pgTable("server_bots", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  pair: text("pair").notNull(),
  exchange: text("exchange").notNull(),
  status: text("status").notNull().default("paused"),
  settings: json("settings").$type<Record<string, any>>().notNull(),
  activeTech: json("active_tech").$type<string[]>().notNull().default([]),
  activeFilters: json("active_filters").$type<string[]>().notNull().default([]),
  lastSignalData: json("last_signal_data").$type<Record<string, any>>(),
  lastTradeAt: timestamp("last_trade_at"),
  totalTrades: integer("total_trades").notNull().default(0),
  totalPnl: real("total_pnl").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertServerBotSchema = createInsertSchema(serverBots).omit({ id: true, createdAt: true, updatedAt: true, totalTrades: true, totalPnl: true });
export type ServerBot = typeof serverBots.$inferSelect;
export type InsertServerBot = z.infer<typeof insertServerBotSchema>;

export const serverBotLogs = pgTable("server_bot_logs", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").notNull(),
  userId: text("user_id").notNull(),
  logType: text("log_type").notNull(),
  message: text("message").notNull(),
  data: json("data").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertServerBotLogSchema = createInsertSchema(serverBotLogs).omit({ id: true, createdAt: true });
export type ServerBotLog = typeof serverBotLogs.$inferSelect;
export type InsertServerBotLog = z.infer<typeof insertServerBotLogSchema>;

export const commandCenterConfigs = pgTable("command_center_configs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  exchange: text("exchange").notNull().default("kraken"),
  isActive: boolean("is_active").notNull().default(false),
  settings: json("settings").$type<{
    scanIntervalSeconds: number;
    minOpportunityScore: number;
    maxManagedBots: number;
    rotationCooldownMinutes: number;
    minHoldMinutes: number;
    riskLevel: 'conservative' | 'moderate' | 'aggressive';
    investmentPerBot: number;
    profitLockThreshold: number;
    underperformMinutes: number;
    autoTechSelection: boolean;
    paperTrading: boolean;
    totalCapital: number;
  }>().notNull().default({
    scanIntervalSeconds: 30,
    minOpportunityScore: 70,
    maxManagedBots: 5,
    rotationCooldownMinutes: 5,
    minHoldMinutes: 10,
    riskLevel: 'moderate',
    investmentPerBot: 100,
    profitLockThreshold: 3,
    underperformMinutes: 15,
    autoTechSelection: true,
    paperTrading: false,
    totalCapital: 1000,
  }),
  managedBotIds: json("managed_bot_ids").$type<number[]>().notNull().default([]),
  allocatedCapital: real("allocated_capital").notNull().default(0),
  totalRotations: integer("total_rotations").notNull().default(0),
  totalProfit: real("total_profit").notNull().default(0),
  lastScanAt: timestamp("last_scan_at"),
  lastRotationAt: timestamp("last_rotation_at"),
  currentOpportunities: json("current_opportunities").$type<any[]>().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCommandCenterConfigSchema = createInsertSchema(commandCenterConfigs).omit({ id: true, createdAt: true, updatedAt: true, totalRotations: true, totalProfit: true });
export type CommandCenterConfig = typeof commandCenterConfigs.$inferSelect;
export type InsertCommandCenterConfig = z.infer<typeof insertCommandCenterConfigSchema>;

export const commandCenterLogs = pgTable("command_center_logs", {
  id: serial("id").primaryKey(),
  configId: integer("config_id").notNull(),
  userId: text("user_id").notNull(),
  logType: text("log_type").notNull(),
  message: text("message").notNull(),
  data: json("data").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCommandCenterLogSchema = createInsertSchema(commandCenterLogs).omit({ id: true, createdAt: true });
export type CommandCenterLog = typeof commandCenterLogs.$inferSelect;
export type InsertCommandCenterLog = z.infer<typeof insertCommandCenterLogSchema>;
