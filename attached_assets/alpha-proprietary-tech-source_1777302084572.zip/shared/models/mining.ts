import { pgTable, serial, text, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const connectedMiners = pgTable("connected_miners", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  ipAddress: text("ip_address").notNull(),
  port: integer("port").notNull().default(80),
  protocol: text("protocol").notNull().default("bitaxe"),
  model: text("model"),
  firmwareVersion: text("firmware_version"),
  isActive: boolean("is_active").notNull().default(true),
  autoAdjust: boolean("auto_adjust").notNull().default(false),
  lastSeen: timestamp("last_seen"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertConnectedMinerSchema = createInsertSchema(connectedMiners).omit({
  id: true,
  createdAt: true,
});

export type ConnectedMiner = typeof connectedMiners.$inferSelect;
export type InsertConnectedMiner = z.infer<typeof insertConnectedMinerSchema>;

export const minerStatusSchema = z.object({
  online: z.boolean(),
  hashrate: z.number().optional(),
  hashrateUnit: z.string().optional(),
  temperature: z.number().optional(),
  vrTemp: z.number().optional(),
  fanSpeed: z.number().optional(),
  fanRpm: z.number().optional(),
  power: z.number().optional(),
  voltage: z.number().optional(),
  frequency: z.number().optional(),
  accepted: z.number().optional(),
  rejected: z.number().optional(),
  difficulty: z.number().optional(),
  bestDifficulty: z.string().optional(),
  uptimeSeconds: z.number().optional(),
  poolUrl: z.string().optional(),
  poolUser: z.string().optional(),
  boardVersion: z.string().optional(),
  firmwareVersion: z.string().optional(),
  chipModel: z.string().optional(),
  blockHeight: z.number().optional(),
  networkDifficulty: z.number().optional(),
  freeHeap: z.number().optional(),
  ssid: z.string().optional(),
  macAddress: z.string().optional(),
  hostname: z.string().optional(),
  sharesPerMinute: z.number().optional(),
  bestSessionDifficulty: z.string().optional(),
  error: z.string().optional(),
  rawData: z.any().optional(),
});

export type MinerStatus = z.infer<typeof minerStatusSchema>;

export const MINER_PROTOCOLS = {
  bitaxe: {
    name: "Bitaxe (AxeOS)",
    defaultPort: 80,
    description: "Bitaxe solo miners (Gamma 601, Supra, Ultra, etc.)",
    transport: "http",
  },
  cgminer: {
    name: "CGMiner / BFGMiner",
    defaultPort: 4028,
    description: "Antminer, AvalonMiner, and other CGMiner-based ASICs",
    transport: "tcp",
  },
  vnish: {
    name: "Vnish Firmware",
    defaultPort: 80,
    description: "Miners running Vnish custom firmware",
    transport: "http",
  },
  braiins: {
    name: "Braiins OS+",
    defaultPort: 80,
    description: "Miners running Braiins OS+ firmware",
    transport: "http",
  },
  generic_http: {
    name: "Generic HTTP Miner",
    defaultPort: 80,
    description: "Any miner with an HTTP API",
    transport: "http",
  },
} as const;

export type MinerProtocol = keyof typeof MINER_PROTOCOLS;
