import { pgTable, serial, text, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./auth";

export const SUPPORTED_BLOCKCHAINS = [
  { id: "sol", name: "Solana", symbol: "SOL", icon: "◎" },
  { id: "eth", name: "Ethereum", symbol: "ETH", icon: "Ξ" },
  { id: "bnbbsc", name: "BNB Smart Chain", symbol: "BNB", icon: "◆" },
  { id: "matic", name: "Polygon", symbol: "MATIC", icon: "⬡" },
  { id: "avax", name: "Avalanche", symbol: "AVAX", icon: "▲" },
  { id: "ada", name: "Cardano", symbol: "ADA", icon: "₳" },
  { id: "dot", name: "Polkadot", symbol: "DOT", icon: "●" },
  { id: "trx", name: "TRON", symbol: "TRX", icon: "◈" },
  { id: "btc", name: "Bitcoin", symbol: "BTC", icon: "₿" },
  { id: "ltc", name: "Litecoin", symbol: "LTC", icon: "Ł" },
  { id: "xrp", name: "XRP", symbol: "XRP", icon: "✕" },
  { id: "doge", name: "Dogecoin", symbol: "DOGE", icon: "Ð" },
  { id: "arb", name: "Arbitrum", symbol: "ARB", icon: "◇" },
  { id: "op", name: "Optimism", symbol: "OP", icon: "⊙" },
  { id: "near", name: "NEAR Protocol", symbol: "NEAR", icon: "Ⓝ" },
  { id: "atom", name: "Cosmos", symbol: "ATOM", icon: "⚛" },
  { id: "ftm", name: "Fantom", symbol: "FTM", icon: "◬" },
  { id: "algo", name: "Algorand", symbol: "ALGO", icon: "Å" },
  { id: "hbar", name: "Hedera", symbol: "HBAR", icon: "ℏ" },
  { id: "apt", name: "Aptos", symbol: "APT", icon: "⬢" },
  { id: "sui", name: "Sui", symbol: "SUI", icon: "💧" },
  { id: "base", name: "Base", symbol: "ETH", icon: "🔵" },
  { id: "zksync", name: "zkSync Era", symbol: "ETH", icon: "⟠" },
  { id: "ton", name: "TON", symbol: "TON", icon: "💎" },
  { id: "kas", name: "Kaspa", symbol: "KAS", icon: "⟁" },
  { id: "sei", name: "Sei", symbol: "SEI", icon: "🌊" },
] as const;

export const PAYOUT_CURRENCIES = [
  { id: "sol", name: "Solana", symbol: "SOL", icon: "◎", addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, placeholder: "e.g. 5KQb5... (32-44 chars, Base58)" },
  { id: "eth", name: "Ethereum", symbol: "ETH", icon: "Ξ", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "btc", name: "Bitcoin", symbol: "BTC", icon: "₿", addressPattern: /^(1[1-9A-HJ-NP-Za-km-z]{25,34}|3[1-9A-HJ-NP-Za-km-z]{25,34}|bc1[0-9a-z]{39,59})$/, placeholder: "e.g. 1A1zP... or bc1q..." },
  { id: "bnbbsc", name: "BNB Smart Chain", symbol: "BNB", icon: "◆", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "matic", name: "Polygon", symbol: "MATIC", icon: "⬡", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "avax", name: "Avalanche", symbol: "AVAX", icon: "▲", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "ada", name: "Cardano", symbol: "ADA", icon: "₳", addressPattern: /^(addr1|Ae2|DdzFF)[0-9a-zA-Z]{20,120}$/, placeholder: "e.g. addr1q... (Bech32 format)" },
  { id: "dot", name: "Polkadot", symbol: "DOT", icon: "●", addressPattern: /^[1-9A-HJ-NP-Za-km-z]{46,48}$/, placeholder: "e.g. 1FRMM... (SS58 format, 46-48 chars)" },
  { id: "trx", name: "TRON", symbol: "TRX", icon: "◈", addressPattern: /^T[1-9A-HJ-NP-Za-km-z]{33}$/, placeholder: "e.g. TJYzQ... (starts with T, 34 chars)" },
  { id: "ltc", name: "Litecoin", symbol: "LTC", icon: "Ł", addressPattern: /^(L[1-9A-HJ-NP-Za-km-z]{26,33}|M[1-9A-HJ-NP-Za-km-z]{26,33}|ltc1[0-9a-z]{39,59})$/, placeholder: "e.g. L1234... or ltc1q..." },
  { id: "xrp", name: "XRP", symbol: "XRP", icon: "✕", addressPattern: /^r[1-9A-HJ-NP-Za-km-z]{24,34}$/, placeholder: "e.g. rN7v9... (starts with r)" },
  { id: "doge", name: "Dogecoin", symbol: "DOGE", icon: "Ð", addressPattern: /^D[1-9A-HJ-NP-Za-km-z]{25,34}$/, placeholder: "e.g. DRSqE... (starts with D)" },
  { id: "arb", name: "Arbitrum", symbol: "ARB", icon: "◇", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "op", name: "Optimism", symbol: "OP", icon: "⊙", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "near", name: "NEAR Protocol", symbol: "NEAR", icon: "Ⓝ", addressPattern: /^[a-z0-9._-]{2,64}(\.near)?$/, placeholder: "e.g. alice.near or account-id" },
  { id: "atom", name: "Cosmos", symbol: "ATOM", icon: "⚛", addressPattern: /^cosmos1[0-9a-z]{38}$/, placeholder: "e.g. cosmos1... (Bech32 format)" },
  { id: "ftm", name: "Fantom", symbol: "FTM", icon: "◬", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "algo", name: "Algorand", symbol: "ALGO", icon: "Å", addressPattern: /^[A-Z2-7]{58}$/, placeholder: "e.g. ABCD... (58 uppercase chars)" },
  { id: "hbar", name: "Hedera", symbol: "HBAR", icon: "ℏ", addressPattern: /^0\.0\.\d{1,10}$/, placeholder: "e.g. 0.0.12345" },
  { id: "apt", name: "Aptos", symbol: "APT", icon: "⬢", addressPattern: /^0x[0-9a-fA-F]{64}$/, placeholder: "e.g. 0x1234... (66 chars, starts with 0x)" },
  { id: "sui", name: "Sui", symbol: "SUI", icon: "💧", addressPattern: /^0x[0-9a-fA-F]{64}$/, placeholder: "e.g. 0x1234... (66 chars, starts with 0x)" },
  { id: "base", name: "Base", symbol: "ETH", icon: "🔵", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "zksync", name: "zkSync Era", symbol: "ETH", icon: "⟠", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (42 chars, starts with 0x)" },
  { id: "ton", name: "TON", symbol: "TON", icon: "💎", addressPattern: /^(EQ|UQ)[0-9a-zA-Z_-]{46}$/, placeholder: "e.g. EQ... or UQ... (48 chars)" },
  { id: "kas", name: "Kaspa", symbol: "KAS", icon: "⟁", addressPattern: /^kaspa:[0-9a-z]{61,63}$/, placeholder: "e.g. kaspa:qr... (starts with kaspa:)" },
  { id: "sei", name: "Sei", symbol: "SEI", icon: "🌊", addressPattern: /^sei1[0-9a-z]{38}$/, placeholder: "e.g. sei1... (Bech32 format)" },
  { id: "usdttrc20", name: "USDT (TRC20)", symbol: "USDT", icon: "₮", addressPattern: /^T[1-9A-HJ-NP-Za-km-z]{33}$/, placeholder: "e.g. TJYzQ... (TRON address, starts with T)" },
  { id: "usdterc20", name: "USDT (ERC20)", symbol: "USDT", icon: "₮", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "usdc", name: "USD Coin", symbol: "USDC", icon: "$", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "usdcsol", name: "USDC (Solana)", symbol: "USDC", icon: "$", addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, placeholder: "e.g. 5KQb5... (Solana address)" },
  { id: "shib", name: "Shiba Inu", symbol: "SHIB", icon: "🐕", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "link", name: "Chainlink", symbol: "LINK", icon: "⬡", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "uni", name: "Uniswap", symbol: "UNI", icon: "🦄", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "pepe", name: "Pepe", symbol: "PEPE", icon: "🐸", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
  { id: "bonk", name: "Bonk", symbol: "BONK", icon: "🐶", addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, placeholder: "e.g. 5KQb5... (Solana address)" },
  { id: "wif", name: "dogwifhat", symbol: "WIF", icon: "🎩", addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, placeholder: "e.g. 5KQb5... (Solana address)" },
  { id: "floki", name: "Floki", symbol: "FLOKI", icon: "⚔️", addressPattern: /^0x[0-9a-fA-F]{40}$/, placeholder: "e.g. 0x1234... (Ethereum address)" },
] as const;

export function validateWalletAddress(currencyId: string, address: string): { valid: boolean; message: string } {
  const currency = PAYOUT_CURRENCIES.find(c => c.id === currencyId);
  if (!currency) return { valid: false, message: "Unsupported cryptocurrency selected" };
  if (!address.trim()) return { valid: false, message: "Wallet address is required" };
  if (currency.addressPattern.test(address.trim())) return { valid: true, message: "" };
  return { valid: false, message: `Invalid ${currency.name} (${currency.symbol}) wallet address. Expected format: ${currency.placeholder}` };
}

export const STAKING_APY_BY_RARITY: Record<string, number> = {
  Common: 5,
  Uncommon: 8,
  Rare: 12,
  Epic: 18,
  Legendary: 25,
  Mythic: 35,
};

export const nfts = pgTable("nfts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  imageIndex: integer("image_index").notNull().default(0),
  rarity: text("rarity").notNull(),
  element: text("element"),
  background: text("background"),
  accessory: text("accessory"),
  style: text("style"),
  priceSOL: real("price_sol").notNull(),
  priceUSD: real("price_usd").notNull(),
  edition: integer("edition").notNull(),
  totalEditions: integer("total_editions").notNull().default(1),
  traits: json("traits").$type<string[]>().notNull(),
  isSold: boolean("is_sold").notNull().default(false),
  isListed: boolean("is_listed").notNull().default(true),
  listPriceUSD: real("list_price_usd"),
  blockchain: text("blockchain").notNull().default("sol"),
  creatorId: text("creator_id"),
  creatorUsername: text("creator_username"),
  creatorWallet: text("creator_wallet"),
  ownerId: text("owner_id"),
  ownerUsername: text("owner_username"),
  ownerWallet: text("owner_wallet"),
  payoutCurrency: text("payout_currency"),
  payoutWallet: text("payout_wallet"),
  likes: integer("likes").notNull().default(0),
  views: integer("views").notNull().default(0),
  isUserCreated: boolean("is_user_created").notNull().default(false),
  mintStatus: text("mint_status").notNull().default("unminted"),
  mintTransactionHash: text("mint_transaction_hash"),
  mintedAt: timestamp("minted_at"),
  tokenAddress: text("token_address"),
  metadataUri: text("metadata_uri"),
  ipfsImageCid: text("ipfs_image_cid"),
  ipfsMetadataCid: text("ipfs_metadata_cid"),
  onChainId: text("on_chain_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const nftPurchases = pgTable("nft_purchases", {
  id: serial("id").primaryKey(),
  nftId: integer("nft_id").notNull(),
  sellerId: text("seller_id"),
  buyerId: text("buyer_id"),
  buyerWallet: text("buyer_wallet"),
  paymentMethod: text("payment_method").notNull(),
  transactionHash: text("transaction_hash"),
  stripePaymentId: text("stripe_payment_id"),
  nowpaymentsInvoiceId: text("nowpayments_invoice_id"),
  amountPaid: text("amount_paid").notNull(),
  currency: text("currency").notNull(),
  blockchain: text("blockchain"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const nftWatchlist = pgTable("nft_watchlist", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  nftId: integer("nft_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const nftLikes = pgTable("nft_likes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  nftId: integer("nft_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNftSchema = createInsertSchema(nfts).omit({ id: true, createdAt: true });
export const insertNftPurchaseSchema = createInsertSchema(nftPurchases).omit({ id: true, createdAt: true });

export const NFT_CATEGORIES = [
  { id: "warriors", name: "Warriors & Heroes", elements: ["Shadow", "Void"], icon: "Sword" },
  { id: "nature", name: "Nature & Elements", elements: ["Nature", "Ocean", "Ice", "Crystal"], icon: "Leaf" },
  { id: "cosmic", name: "Cosmic & Sci-Fi", elements: ["Cosmic", "Electric", "Solar", "Cyber"], icon: "Sparkles" },
  { id: "mystic", name: "Mystic & Dark", elements: ["Fire", "Toxic"], icon: "Flame" },
] as const;

export type NFT = typeof nfts.$inferSelect;
export type InsertNFT = {
  name: string;
  description: string;
  imageUrl?: string | null;
  imageIndex?: number;
  rarity: string;
  element?: string | null;
  background?: string | null;
  accessory?: string | null;
  style?: string | null;
  priceSOL: number;
  priceUSD: number;
  edition: number;
  totalEditions?: number;
  traits: string[];
  isSold?: boolean;
  isListed?: boolean;
  listPriceUSD?: number | null;
  blockchain?: string;
  creatorId?: string | null;
  creatorUsername?: string | null;
  creatorWallet?: string | null;
  ownerId?: string | null;
  ownerUsername?: string | null;
  ownerWallet?: string | null;
  payoutCurrency?: string | null;
  payoutWallet?: string | null;
  likes?: number;
  views?: number;
  isUserCreated?: boolean;
};
export type NFTPurchase = typeof nftPurchases.$inferSelect;
export type InsertNFTPurchase = z.infer<typeof insertNftPurchaseSchema>;

export const AI_NFT_PACKAGES = [
  { id: "ai_nft_10", name: "Starter Pack", credits: 10, priceUSD: 9.99, description: "Generate 10 unique AI-powered NFT artworks with up to 3 prompt retries each" },
  { id: "ai_nft_25", name: "Creator Pack", credits: 25, priceUSD: 19.99, description: "Generate 25 unique AI-powered NFT artworks with up to 3 prompt retries each" },
  { id: "ai_nft_50", name: "Artist Pack", credits: 50, priceUSD: 34.99, description: "Generate 50 unique AI-powered NFT artworks with up to 3 prompt retries each" },
  { id: "ai_nft_100", name: "Pro Collection", credits: 100, priceUSD: 59.99, description: "Generate 100 unique AI-powered NFT artworks with up to 3 prompt retries each" },
] as const;

export const AI_NFT_MAX_RETRIES = 3;

export const aiNftCredits = pgTable("ai_nft_credits", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  packageId: text("package_id").notNull(),
  totalCredits: integer("total_credits").notNull(),
  remainingCredits: integer("remaining_credits").notNull(),
  stripePaymentId: text("stripe_payment_id"),
  stripeSessionId: text("stripe_session_id"),
  status: text("status").notNull().default("active"),
  purchasedAt: timestamp("purchased_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const aiNftGenerations = pgTable("ai_nft_generations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  creditId: integer("credit_id").notNull(),
  nftId: integer("nft_id"),
  prompt: text("prompt").notNull(),
  imageUrl: text("image_url"),
  status: text("status").notNull().default("pending"),
  attemptsRemaining: integer("attempts_remaining").notNull().default(3),
  characterId: text("character_id"),
  variationId: text("variation_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAiNftCreditSchema = createInsertSchema(aiNftCredits).omit({ id: true, purchasedAt: true });
export const insertAiNftGenerationSchema = createInsertSchema(aiNftGenerations).omit({ id: true, createdAt: true });

export type AiNftCredit = typeof aiNftCredits.$inferSelect;
export type InsertAiNftCredit = z.infer<typeof insertAiNftCreditSchema>;
export type AiNftGeneration = typeof aiNftGenerations.$inferSelect;
export type InsertAiNftGeneration = z.infer<typeof insertAiNftGenerationSchema>;

export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  nftId: integer("nft_id").notNull(),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export const insertCartItemSchema = createInsertSchema(cartItems).omit({ id: true, addedAt: true });
export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;

export const nftStakes = pgTable("nft_stakes", {
  id: serial("id").primaryKey(),
  nftId: integer("nft_id").notNull(),
  userId: text("user_id").notNull(),
  apyRate: real("apy_rate").notNull(),
  accruedRewards: real("accrued_rewards").notNull().default(0),
  lastClaimedAt: timestamp("last_claimed_at"),
  status: text("status").notNull().default("active"),
  stakedAt: timestamp("staked_at").notNull().defaultNow(),
  unstakedAt: timestamp("unstaked_at"),
});

export const insertNftStakeSchema = createInsertSchema(nftStakes).omit({ id: true, stakedAt: true });
export type NftStake = typeof nftStakes.$inferSelect;
export type InsertNftStake = z.infer<typeof insertNftStakeSchema>;

export const nftAssessments = pgTable("nft_assessments", {
  id: serial("id").primaryKey(),
  nftId: integer("nft_id").notNull(),
  userId: text("user_id"),
  rarityScore: real("rarity_score").notNull(),
  estimatedValueUSD: real("estimated_value_usd").notNull(),
  confidenceLevel: real("confidence_level").notNull(),
  traitAnalysis: json("trait_analysis").$type<Record<string, any>>(),
  marketComparison: json("market_comparison").$type<Record<string, any>>(),
  recommendation: text("recommendation"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNftAssessmentSchema = createInsertSchema(nftAssessments).omit({ id: true, createdAt: true });
export type NftAssessment = typeof nftAssessments.$inferSelect;
export type InsertNftAssessment = z.infer<typeof insertNftAssessmentSchema>;

export const tradingStrategies = pgTable("trading_strategies", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  nodes: json("nodes").$type<any[]>().notNull(),
  edges: json("edges").$type<any[]>().notNull(),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertTradingStrategySchema = createInsertSchema(tradingStrategies).omit({ id: true, createdAt: true, updatedAt: true });
export type TradingStrategy = typeof tradingStrategies.$inferSelect;
export type InsertTradingStrategy = z.infer<typeof insertTradingStrategySchema>;

export const nftFractions = pgTable("nft_fractions", {
  id: serial("id").primaryKey(),
  nftId: integer("nft_id").notNull(),
  userId: text("user_id").notNull(),
  shares: real("shares").notNull(),
  purchasePriceUSD: real("purchase_price_usd").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNftFractionSchema = createInsertSchema(nftFractions).omit({ id: true, createdAt: true });
export type NftFraction = typeof nftFractions.$inferSelect;
export type InsertNftFraction = z.infer<typeof insertNftFractionSchema>;

export const gamifiedRewards = pgTable("gamified_rewards", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  action: text("action").notNull(),
  xpEarned: integer("xp_earned").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertGamifiedRewardSchema = createInsertSchema(gamifiedRewards).omit({ id: true, createdAt: true });
export type GamifiedReward = typeof gamifiedRewards.$inferSelect;

export const forumPosts = pgTable("forum_posts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  category: text("category").notNull().default("general"),
  title: text("title").notNull(),
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  replies: integer("replies").notNull().default(0),
  isPinned: boolean("is_pinned").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const forumReplies = pgTable("forum_replies", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertForumPostSchema = createInsertSchema(forumPosts).omit({ id: true, createdAt: true, likes: true, replies: true, isPinned: true });
export const insertForumReplySchema = createInsertSchema(forumReplies).omit({ id: true, createdAt: true, likes: true });
export type ForumPost = typeof forumPosts.$inferSelect;
export type ForumReply = typeof forumReplies.$inferSelect;
export type InsertForumPost = z.infer<typeof insertForumPostSchema>;
export type InsertForumReply = z.infer<typeof insertForumReplySchema>;

export const REWARD_XP_TABLE: Record<string, number> = {
  nft_purchase: 50,
  nft_sale: 75,
  nft_create: 30,
  nft_stake: 20,
  daily_login: 10,
  forum_post: 15,
  forum_reply: 5,
  strategy_create: 25,
  trade_execute: 40,
  refer_friend: 100,
};

export const LEVEL_THRESHOLDS = [
  { level: 1, xp: 0, title: "Rookie" },
  { level: 2, xp: 100, title: "Apprentice" },
  { level: 3, xp: 300, title: "Trader" },
  { level: 4, xp: 600, title: "Expert" },
  { level: 5, xp: 1000, title: "Master" },
  { level: 6, xp: 1500, title: "Alpha Elite" },
  { level: 7, xp: 2500, title: "Diamond" },
  { level: 8, xp: 4000, title: "Legend" },
  { level: 9, xp: 6000, title: "Mythic" },
  { level: 10, xp: 10000, title: "Alpha God" },
];

export const DEX_PROTOCOLS = [
  { id: "uniswap", name: "Uniswap", chain: "eth", icon: "U", color: "#FF007A" },
  { id: "jupiter", name: "Jupiter", chain: "sol", icon: "J", color: "#00D4AA" },
  { id: "raydium", name: "Raydium", chain: "sol", icon: "R", color: "#5AC2FF" },
  { id: "pancakeswap", name: "PancakeSwap", chain: "bnb", icon: "P", color: "#D1884F" },
  { id: "sushiswap", name: "SushiSwap", chain: "eth", icon: "S", color: "#FA52A0" },
  { id: "curve", name: "Curve", chain: "eth", icon: "C", color: "#FF6B6B" },
  { id: "1inch", name: "1inch", chain: "eth", icon: "1", color: "#94A3B8" },
  { id: "orca", name: "Orca", chain: "sol", icon: "O", color: "#FFD700" },
] as const;
