import { pgTable, serial, text, integer, boolean, timestamp, real, json, index, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const socialProfiles = pgTable("social_profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  displayName: text("display_name"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  shareTradesPublic: boolean("share_trades_public").notNull().default(false),
  sharePerformance: boolean("share_performance").notNull().default(false),
  shareWatchlist: boolean("share_watchlist").notNull().default(false),
  allowMessages: boolean("allow_messages").notNull().default(true),
  profileVisibility: text("profile_visibility").notNull().default("followers"),
  totalTrades: integer("total_trades").notNull().default(0),
  winRate: real("win_rate").default(0),
  totalPnl: real("total_pnl").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("idx_social_profiles_user").on(table.userId),
]);

export const sharedTrades = pgTable("shared_trades", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  tradeId: integer("trade_id"),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(),
  entryPrice: real("entry_price").notNull(),
  exitPrice: real("exit_price"),
  pnlPercent: real("pnl_percent"),
  commentary: text("commentary"),
  visibility: text("visibility").notNull().default("public"),
  likesCount: integer("likes_count").notNull().default(0),
  commentsCount: integer("comments_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_shared_trades_user").on(table.userId),
  index("idx_shared_trades_visibility").on(table.visibility),
  index("idx_shared_trades_created").on(table.createdAt),
]);

export const tradeComments = pgTable("trade_comments", {
  id: serial("id").primaryKey(),
  sharedTradeId: integer("shared_trade_id").notNull(),
  userId: text("user_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_trade_comments_trade").on(table.sharedTradeId),
]);

export const tradeLikes = pgTable("trade_likes", {
  id: serial("id").primaryKey(),
  sharedTradeId: integer("shared_trade_id").notNull(),
  userId: text("user_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_trade_likes_trade").on(table.sharedTradeId),
  index("idx_trade_likes_user").on(table.userId),
]);

export const followRelationships = pgTable("follow_relationships", {
  id: serial("id").primaryKey(),
  followerId: text("follower_id").notNull(),
  followingId: text("following_id").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_follow_follower").on(table.followerId),
  index("idx_follow_following").on(table.followingId),
]);

export const directConversations = pgTable("direct_conversations", {
  id: serial("id").primaryKey(),
  participantOneId: text("participant_one_id").notNull(),
  participantTwoId: text("participant_two_id").notNull(),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_conversations_p1").on(table.participantOneId),
  index("idx_conversations_p2").on(table.participantTwoId),
]);

export const directMessages = pgTable("direct_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  senderId: text("sender_id").notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_messages_conversation").on(table.conversationId),
  index("idx_messages_sender").on(table.senderId),
]);

export const userBlocks = pgTable("user_blocks", {
  id: serial("id").primaryKey(),
  blockerId: text("blocker_id").notNull(),
  blockedId: text("blocked_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_blocks_blocker").on(table.blockerId),
]);

export const insertSocialProfileSchema = createInsertSchema(socialProfiles).omit({ id: true, createdAt: true, updatedAt: true });
export const insertSharedTradeSchema = createInsertSchema(sharedTrades).omit({ id: true, createdAt: true, likesCount: true, commentsCount: true });
export const insertTradeCommentSchema = createInsertSchema(tradeComments).omit({ id: true, createdAt: true });
export const insertTradeLikeSchema = createInsertSchema(tradeLikes).omit({ id: true, createdAt: true });
export const insertFollowRelationshipSchema = createInsertSchema(followRelationships).omit({ id: true, createdAt: true });
export const insertDirectConversationSchema = createInsertSchema(directConversations).omit({ id: true, createdAt: true, lastMessageAt: true });
export const insertDirectMessageSchema = createInsertSchema(directMessages).omit({ id: true, createdAt: true, isRead: true });
export const insertUserBlockSchema = createInsertSchema(userBlocks).omit({ id: true, createdAt: true });

export type SocialProfile = typeof socialProfiles.$inferSelect;
export type InsertSocialProfile = z.infer<typeof insertSocialProfileSchema>;
export type SharedTrade = typeof sharedTrades.$inferSelect;
export type InsertSharedTrade = z.infer<typeof insertSharedTradeSchema>;
export type TradeComment = typeof tradeComments.$inferSelect;
export type InsertTradeComment = z.infer<typeof insertTradeCommentSchema>;
export type TradeLike = typeof tradeLikes.$inferSelect;
export type InsertTradeLike = z.infer<typeof insertTradeLikeSchema>;
export type FollowRelationship = typeof followRelationships.$inferSelect;
export type InsertFollowRelationship = z.infer<typeof insertFollowRelationshipSchema>;
export type DirectConversation = typeof directConversations.$inferSelect;
export type InsertDirectConversation = z.infer<typeof insertDirectConversationSchema>;
export type DirectMessage = typeof directMessages.$inferSelect;
export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;
export type UserBlock = typeof userBlocks.$inferSelect;
export type InsertUserBlock = z.infer<typeof insertUserBlockSchema>;

export const sharedStrategies = pgTable("shared_strategies", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  strategyType: text("strategy_type").notNull(),
  parameters: json("parameters").$type<Record<string, any>>().notNull(),
  assets: text("assets").array().notNull().default([]),
  timeframe: text("timeframe"),
  riskLevel: text("risk_level").default("medium"),
  visibility: text("visibility").notNull().default("public"),
  likesCount: integer("likes_count").notNull().default(0),
  commentsCount: integer("comments_count").notNull().default(0),
  viewsCount: integer("views_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_shared_strategies_user").on(table.userId),
  index("idx_shared_strategies_visibility").on(table.visibility),
  index("idx_shared_strategies_created").on(table.createdAt),
]);

export const sharedBacktestResults = pgTable("shared_backtest_results", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  backtestResultId: integer("backtest_result_id"),
  strategyName: text("strategy_name").notNull(),
  strategyType: text("strategy_type").notNull(),
  symbol: text("symbol").notNull(),
  timeframe: text("timeframe").notNull(),
  totalReturnPercent: real("total_return_percent").notNull(),
  winRate: real("win_rate").notNull(),
  sharpeRatio: real("sharpe_ratio"),
  maxDrawdownPercent: real("max_drawdown_percent").notNull(),
  totalTrades: integer("total_trades").notNull(),
  profitFactor: real("profit_factor"),
  initialCapital: real("initial_capital").notNull(),
  finalCapital: real("final_capital").notNull(),
  equityCurve: json("equity_curve").$type<{ time: number; equity: number }[]>(),
  parameters: json("parameters").$type<Record<string, any>>().notNull(),
  commentary: text("commentary"),
  visibility: text("visibility").notNull().default("public"),
  likesCount: integer("likes_count").notNull().default(0),
  commentsCount: integer("comments_count").notNull().default(0),
  viewsCount: integer("views_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_shared_backtests_user").on(table.userId),
  index("idx_shared_backtests_visibility").on(table.visibility),
  index("idx_shared_backtests_created").on(table.createdAt),
]);

export const socialLikes = pgTable("social_likes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  contentType: text("content_type").notNull(),
  contentId: integer("content_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_social_likes_content").on(table.contentType, table.contentId),
  index("idx_social_likes_user").on(table.userId),
  uniqueIndex("idx_social_likes_unique").on(table.userId, table.contentType, table.contentId),
]);

export const socialComments = pgTable("social_comments", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  contentType: text("content_type").notNull(),
  contentId: integer("content_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_social_comments_content").on(table.contentType, table.contentId),
]);

export const insertSharedStrategySchema = createInsertSchema(sharedStrategies).omit({ id: true, createdAt: true, likesCount: true, commentsCount: true, viewsCount: true });
export const insertSharedBacktestResultSchema = createInsertSchema(sharedBacktestResults).omit({ id: true, createdAt: true, likesCount: true, commentsCount: true, viewsCount: true });
export const insertSocialLikeSchema = createInsertSchema(socialLikes).omit({ id: true, createdAt: true });
export const insertSocialCommentSchema = createInsertSchema(socialComments).omit({ id: true, createdAt: true });

export type SharedStrategy = typeof sharedStrategies.$inferSelect;
export type InsertSharedStrategy = z.infer<typeof insertSharedStrategySchema>;
export type SharedBacktestResult = typeof sharedBacktestResults.$inferSelect;
export type InsertSharedBacktestResult = z.infer<typeof insertSharedBacktestResultSchema>;
export type SocialLike = typeof socialLikes.$inferSelect;
export type InsertSocialLike = z.infer<typeof insertSocialLikeSchema>;
export type SocialComment = typeof socialComments.$inferSelect;
export type InsertSocialComment = z.infer<typeof insertSocialCommentSchema>;

export const updateSocialProfileSchema = z.object({
  displayName: z.string().optional(),
  bio: z.string().optional(),
  avatarUrl: z.string().optional(),
  shareTradesPublic: z.boolean().optional(),
  sharePerformance: z.boolean().optional(),
  shareWatchlist: z.boolean().optional(),
  allowMessages: z.boolean().optional(),
  profileVisibility: z.enum(["public", "followers", "private"]).optional(),
});

export type UpdateSocialProfile = z.infer<typeof updateSocialProfileSchema>;
