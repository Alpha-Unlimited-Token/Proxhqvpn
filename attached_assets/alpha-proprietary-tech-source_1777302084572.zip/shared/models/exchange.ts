import { pgTable, serial, text, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const exchangeAccounts = pgTable("exchange_accounts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  aucBalance: real("auc_balance").notNull().default(0),
  usdBalance: real("usd_balance").notNull().default(0),
  aucLocked: real("auc_locked").notNull().default(0),
  usdLocked: real("usd_locked").notNull().default(0),
  totalFeesGenerated: real("total_fees_generated").notNull().default(0),
  aucWalletAddress: text("auc_wallet_address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeOrders = pgTable("exchange_orders", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  side: text("side").notNull(), // 'buy' or 'sell'
  orderType: text("order_type").notNull(), // 'limit' or 'market'
  price: real("price"), // null for market orders
  amount: real("amount").notNull(), // AUC amount
  filled: real("filled").notNull().default(0),
  remaining: real("remaining").notNull(),
  status: text("status").notNull().default("open"), // open, partial, filled, cancelled
  fee: real("fee").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const exchangeTrades = pgTable("exchange_trades", {
  id: serial("id").primaryKey(),
  buyOrderId: integer("buy_order_id").notNull(),
  sellOrderId: integer("sell_order_id").notNull(),
  buyerId: text("buyer_id").notNull(),
  sellerId: text("seller_id").notNull(),
  price: real("price").notNull(),
  amount: real("amount").notNull(),
  buyerFee: real("buyer_fee").notNull(),
  sellerFee: real("seller_fee").notNull(),
  totalValue: real("total_value").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeDeposits = pgTable("exchange_deposits", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  type: text("type").notNull(), // 'usd' or 'auc'
  amount: real("amount").notNull(),
  fee: real("fee").notNull().default(0),
  status: text("status").notNull().default("pending"), // pending, completed, failed
  paymentId: text("payment_id"),
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeWithdrawals = pgTable("exchange_withdrawals", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  type: text("type").notNull(), // 'usd' or 'auc'
  amount: real("amount").notNull(),
  fee: real("fee").notNull().default(0),
  status: text("status").notNull().default("pending"),
  destination: text("destination").notNull(),
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeStats = pgTable("exchange_stats", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(),
  volume24h: real("volume_24h").notNull().default(0),
  trades24h: integer("trades_24h").notNull().default(0),
  highPrice: real("high_price").notNull().default(0),
  lowPrice: real("low_price").notNull().default(0),
  openPrice: real("open_price").notNull().default(0),
  closePrice: real("close_price").notNull().default(0),
  feesCollected: real("fees_collected").notNull().default(0),
});

export const AUC_DISCOUNT_PERCENT = 15;

export const aucPurchases = pgTable("auc_purchases", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  purchaseType: text("purchase_type").notNull(), // 'subscription', 'technology', 'addon'
  referenceId: text("reference_id"), // tier ID, product IDs, etc.
  usdPriceCents: integer("usd_price_cents").notNull(),
  discountPercent: integer("discount_percent").notNull().default(AUC_DISCOUNT_PERCENT),
  discountedUsdCents: integer("discounted_usd_cents").notNull(),
  aucPricePerUnit: real("auc_price_per_unit").notNull(),
  aucAmount: real("auc_amount").notNull(),
  status: text("status").notNull().default("completed"), // completed, refunded
  metadata: text("metadata"), // JSON string for extra info
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAucPurchaseSchema = createInsertSchema(aucPurchases).omit({ id: true, createdAt: true });
export type AucPurchase = typeof aucPurchases.$inferSelect;
export type InsertAucPurchase = z.infer<typeof insertAucPurchaseSchema>;

export const exchangeReferrals = pgTable("exchange_referrals", {
  id: serial("id").primaryKey(),
  referrerId: text("referrer_id").notNull(),
  referredId: text("referred_id").notNull().unique(),
  referralCode: text("referral_code").notNull(),
  feeSharePercent: real("fee_share_percent").notNull().default(20),
  totalEarnings: real("total_earnings").notNull().default(0),
  totalTrades: integer("total_trades").notNull().default(0),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeReferralCodes = pgTable("exchange_referral_codes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  code: text("code").notNull().unique(),
  totalReferrals: integer("total_referrals").notNull().default(0),
  totalEarnings: real("total_earnings").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const exchangeReferralEarnings = pgTable("exchange_referral_earnings", {
  id: serial("id").primaryKey(),
  referrerId: text("referrer_id").notNull(),
  referredId: text("referred_id").notNull(),
  tradeId: integer("trade_id").notNull(),
  feeAmount: real("fee_amount").notNull(),
  earningAmount: real("earning_amount").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertExchangeReferralCodeSchema = createInsertSchema(exchangeReferralCodes).omit({ id: true, createdAt: true, totalReferrals: true, totalEarnings: true });
export const insertExchangeReferralSchema = createInsertSchema(exchangeReferrals).omit({ id: true, createdAt: true, totalEarnings: true, totalTrades: true });
export type ExchangeReferralCode = typeof exchangeReferralCodes.$inferSelect;
export type ExchangeReferral = typeof exchangeReferrals.$inferSelect;
export type ExchangeReferralEarning = typeof exchangeReferralEarnings.$inferSelect;

export const insertExchangeAccountSchema = createInsertSchema(exchangeAccounts).omit({ id: true, createdAt: true });
export const insertExchangeOrderSchema = createInsertSchema(exchangeOrders).omit({ id: true, createdAt: true, updatedAt: true });
export const insertExchangeTradeSchema = createInsertSchema(exchangeTrades).omit({ id: true, createdAt: true });
export const insertExchangeDepositSchema = createInsertSchema(exchangeDeposits).omit({ id: true, createdAt: true });
export const insertExchangeWithdrawalSchema = createInsertSchema(exchangeWithdrawals).omit({ id: true, createdAt: true });

export type ExchangeAccount = typeof exchangeAccounts.$inferSelect;
export type InsertExchangeAccount = z.infer<typeof insertExchangeAccountSchema>;
export type ExchangeOrder = typeof exchangeOrders.$inferSelect;
export type InsertExchangeOrder = z.infer<typeof insertExchangeOrderSchema>;
export type ExchangeTrade = typeof exchangeTrades.$inferSelect;
export type ExchangeDeposit = typeof exchangeDeposits.$inferSelect;
export type ExchangeWithdrawal = typeof exchangeWithdrawals.$inferSelect;
