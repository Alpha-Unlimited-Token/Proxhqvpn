/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Alpha Forensic Flow Visualizer™ — Auto-Emit Helper.
 *
 * One-line integration for any trace tool. After writing your JSON report,
 * call: await autoEmitFlowDiagram(jsonPath, { title, caseId, chain, direction })
 * It writes <jsonPath-without-ext>_FlowDiagram.svg and .html.
 *
 * Forgiving: catches all errors, never throws — report writes are never
 * blocked by visualization failures.
 */
import * as fs from 'fs';
import * as path from 'path';
import {
  renderFlowDiagram,
  renderFlowDiagramHtml,
  type FlowDiagramInput,
  type FlowEdge,
  type FlowNodeMeta,
  type FlowDirection,
} from './flowDiagramVisualizer.js';

export interface AutoEmitOpts {
  title?: string;
  caseId?: string;
  chain?: string;
  direction?: FlowDirection;
  roots?: string[];
  outBase?: string;
  silent?: boolean;
}

function normalize(raw: any): { nodes: FlowNodeMeta[]; edges: FlowEdge[] } {
  const nodes: FlowNodeMeta[] = [];
  const edges: FlowEdge[] = [];
  const pushNode = (a: any) => {
    if (!a) return;
    const addr = a.address || a.wallet || a.id || a.addr;
    if (!addr || typeof addr !== 'string') return;
    nodes.push({ address: addr, label: a.label || a.tag || a.name, kind: a.kind });
  };
  for (const arrKey of ['nodes','wallets','walletsVisited','reports','attackerWallets','roots','walletReports','dumpers','allWallets']) {
    if (Array.isArray(raw?.[arrKey])) raw[arrKey].forEach(pushNode);
  }

  const buckets = [raw?.edges, raw?.transfers, raw?.transactions, raw?.hops, raw?.flows];
  if (Array.isArray(raw?.traces)) {
    for (const t of raw.traces) {
      if (Array.isArray(t?.transfers)) buckets.push(t.transfers);
      if (Array.isArray(t?.edges)) buckets.push(t.edges);
      if (Array.isArray(t?.hops)) buckets.push(t.hops);
    }
  }
  if (Array.isArray(raw?.dumpers)) {
    for (const d of raw.dumpers) {
      if (Array.isArray(d?.transfers)) buckets.push(d.transfers);
      if (Array.isArray(d?.outflows)) buckets.push(d.outflows);
      if (Array.isArray(d?.hops)) buckets.push(d.hops);
    }
  }
  // DAU v2 shape: allWallets[] with discoveredVia prefix → resolve to full address by prefix
  if (Array.isArray(raw?.allWallets)) {
    const synth: any[] = [];
    const prefixMap = new Map<string, string>();
    for (const w of raw.allWallets) if (w?.address) prefixMap.set(String(w.address).slice(0, 10).toLowerCase(), w.address);
    for (const w of raw.allWallets) {
      if (!w?.address || !w?.discoveredVia || w.discoveredVia === 'origin') continue;
      const m = String(w.discoveredVia).match(/0x[0-9a-fA-F]+/);
      if (!m) continue;
      const fromFull = prefixMap.get(m[0].slice(0, 10).toLowerCase()) || m[0];
      synth.push({ from: fromFull, to: w.address, delta: w.totalInbound, asset: 'ETH', dir: 'out' });
    }
    if (synth.length) buckets.push(synth);
  }
  // RAVEDAO dump_analysis shape: dumpers[].sentTo[] (strings) + backTrace.hopNSources
  if (Array.isArray(raw?.dumpers)) {
    const synth: any[] = [];
    for (const d of raw.dumpers) {
      if (!d?.address) continue;
      if (Array.isArray(d.sentTo)) {
        for (const dest of d.sentTo) {
          if (typeof dest === 'string') synth.push({ from: d.address, to: dest, delta: d.tokensSold, asset: 'RAVE', dir: 'out' });
          else if (dest?.address) synth.push({ from: d.address, to: dest.address, delta: dest.amount ?? d.tokensSold, asset: dest.asset || 'RAVE', dir: 'out' });
        }
      }
      const bt = d.backTrace;
      if (bt) {
        for (const key of ['hop1Sources','hop2Sources']) {
          const arr = bt[key];
          if (Array.isArray(arr)) for (const src of arr) {
            const srcAddr = typeof src === 'string' ? src : src?.address;
            if (srcAddr) synth.push({ from: srcAddr, to: d.address, dir: 'in' });
          }
        }
      }
    }
    if (synth.length) buckets.push(synth);
  }
  // SillyTuna backtrace shape: reports[].backTraceNodes[].fundedBy[] → backward edges
  if (Array.isArray(raw?.reports)) {
    const synth: any[] = [];
    for (const rep of raw.reports) {
      if (Array.isArray(rep?.backTraceNodes)) {
        for (const n of rep.backTraceNodes) {
          if (!n?.address) continue;
          if (Array.isArray(n.fundedBy)) for (const f of n.fundedBy) {
            const fAddr = typeof f === 'string' ? f : f?.address;
            if (fAddr) synth.push({ from: fAddr, to: n.address, dir: 'in', asset: 'native' });
          }
        }
      }
      if (Array.isArray(rep?.kycChokepoints)) for (const k of rep.kycChokepoints) {
        const kAddr = typeof k === 'string' ? k : k?.address;
        if (kAddr && rep.address) synth.push({ from: kAddr, to: rep.address, dir: 'in', asset: 'native', rootLabel: 'KYC' });
      }
    }
    if (synth.length) buckets.push(synth);
  }
  // Comprehensive case shape: walletReports[].chains[].topCounterparties → edges
  if (Array.isArray(raw?.walletReports)) {
    const synth: any[] = [];
    for (const w of raw.walletReports) {
      const from = w?.address;
      if (!from) continue;
      if (Array.isArray(w.chains)) {
        for (const ch of w.chains) {
          const asset = ch?.nativeSymbol || ch?.chain;
          if (Array.isArray(ch?.topCounterparties)) {
            for (const cp of ch.topCounterparties) {
              if (cp?.address) synth.push({ from, to: cp.address, delta: cp.count, asset, ts: undefined, dir: 'out' });
            }
          }
          if (Array.isArray(ch?.transfers)) {
            for (const t of ch.transfers) synth.push({ ...t, asset: t.asset || asset });
          }
        }
      }
      if (Array.isArray(w.transfers)) for (const t of w.transfers) synth.push(t);
    }
    if (synth.length) buckets.push(synth);
  }
  for (const bucket of buckets) {
    if (!Array.isArray(bucket)) continue;
    for (const e of bucket) {
      const from = e.from || e.source || e.sender || e.fromAddress;
      const to = e.to || e.target || e.recipient || e.toAddress;
      if (!from || !to) continue;
      const delta = e.delta ?? e.value ?? e.amount ?? e.tokenValue;
      const ts = e.ts ?? e.timestamp ?? e.time ?? e.blockTime;
      edges.push({
        from, to,
        delta: typeof delta === 'number' ? delta : (delta != null ? Number(delta) : undefined),
        asset: e.asset || e.token || e.symbol || e.tokenSymbol,
        ts: typeof ts === 'number'
          ? ts
          : (ts != null ? Math.floor(new Date(ts).getTime() / 1000) || undefined : undefined),
        hash: e.hash || e.txHash || e.signature,
        dir: e.dir || e.direction,
        rootLabel: e.rootLabel,
      });
    }
  }
  return { nodes, edges };
}

function autoDetectRoots(nodes: FlowNodeMeta[], edges: FlowEdge[]): string[] {
  const declared = nodes.filter(n => n.kind === 'root').map(n => n.address);
  if (declared.length) return declared;
  const incoming = new Set(edges.map(e => e.to));
  const outgoing = new Set(edges.map(e => e.from));
  const roots = Array.from(outgoing).filter(a => !incoming.has(a));
  if (roots.length) return roots;
  return Array.from(outgoing).slice(0, 1);
}

/**
 * Reads a trace JSON, generates a TRM-style flow diagram, writes .svg + .html
 * siblings. Never throws — failures are logged (unless silent) and swallowed.
 */
export async function autoEmitFlowDiagram(jsonPath: string, opts: AutoEmitOpts = {}): Promise<{ svgPath?: string; htmlPath?: string; nodes?: number; edges?: number; error?: string }> {
  try {
    if (!jsonPath || !fs.existsSync(jsonPath)) {
      return { error: `JSON not found: ${jsonPath}` };
    }
    const raw = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
    const { nodes, edges } = normalize(raw);
    if (!edges.length) {
      if (!opts.silent) console.log(`  ⚠️ Flow diagram skipped (no edges in ${path.basename(jsonPath)})`);
      return { error: 'no edges' };
    }
    const roots = (opts.roots && opts.roots.length) ? opts.roots : autoDetectRoots(nodes, edges);
    const labelMap: Record<string, string> = {};
    for (const n of nodes) if (n.label) labelMap[n.address] = n.label;

    const input: FlowDiagramInput = {
      title: opts.title || `Forensic Flow — ${path.basename(jsonPath, path.extname(jsonPath))}`,
      caseId: opts.caseId,
      ecosystem: opts.chain,
      direction: opts.direction || 'forward',
      rootAddresses: roots,
      nodes,
      edges,
      addressLabels: labelMap,
      generatedAt: new Date().toISOString(),
    };

    const base = opts.outBase || path.join(path.dirname(jsonPath), path.basename(jsonPath, path.extname(jsonPath)) + '_FlowDiagram');
    const svgPath = base + '.svg';
    const htmlPath = base + '.html';
    fs.writeFileSync(svgPath, renderFlowDiagram(input));
    fs.writeFileSync(htmlPath, renderFlowDiagramHtml(input));
    if (!opts.silent) console.log(`  ✅ Flow diagram → ${path.basename(svgPath)} + ${path.basename(htmlPath)}  (${nodes.length || new Set([...edges.map(e=>e.from), ...edges.map(e=>e.to)]).size} nodes, ${edges.length} edges, ${roots.length} roots)`);
    return { svgPath, htmlPath, nodes: nodes.length, edges: edges.length };
  } catch (e: any) {
    if (!opts.silent) console.log(`  ⚠️ Flow diagram emission failed: ${e?.message || e}`);
    return { error: String(e?.message || e) };
  }
}
