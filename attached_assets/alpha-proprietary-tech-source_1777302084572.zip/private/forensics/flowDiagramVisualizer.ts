/*
 * ════════════════════════════════════════════════════════════════════════════
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Alpha Forensic Flow Visualizer™ — PROPRIETARY AND CONFIDENTIAL.
 * Unauthorized use, reproduction, modification, distribution, or reverse
 * engineering is a violation of US copyright law (Title 17), the DMCA, the
 * CFAA, and the DTSA. Owner: alphaunlimitedtoken@gmail.com
 * ════════════════════════════════════════════════════════════════════════════
 *
 * Renders TRM-Labs / Chainalysis-Reactor-style flow diagrams for any forensic
 * trace: forward, backward, or bidirectional. Pure SVG, zero deps.
 */
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Forensic Flow Visualizer™');

export type FlowDirection = 'forward' | 'backward' | 'bidirectional';

export interface FlowEdge {
  from: string;
  to: string;
  delta?: number;
  asset?: string;
  ts?: number;
  hash?: string;
  dir?: 'forward' | 'backward';
  rootLabel?: string;
}

export interface FlowNodeMeta {
  address: string;
  label?: string;
  kind?: 'root' | 'intermediary' | 'exchange' | 'mixer' | 'bridge' | 'attacker' | 'victim';
}

export interface FlowDiagramInput {
  title: string;
  caseId?: string;
  ecosystem?: string;
  direction?: FlowDirection;
  rootAddresses: string[];
  nodes?: FlowNodeMeta[];
  edges: FlowEdge[];
  addressLabels?: Record<string, string>;
  assetSymbols?: Record<string, string>;
  generatedAt?: string;
  maxLevels?: number;
}

const COLORS = {
  bg: '#0a0e14',
  panel: '#0f1620',
  gold: '#d4af37',
  cyan: '#00d4ff',
  white: '#e8eef5',
  dim: '#6b7785',
  rootFill: '#1e3a5f', rootStroke: '#00d4ff',
  intermFill: '#3d1e1e', intermStroke: '#e74c3c',
  exchFill: '#1e3d2e', exchStroke: '#27ae60',
  mixerFill: '#3d2e1e', mixerStroke: '#e67e22',
  bridgeFill: '#2e1e3d', bridgeStroke: '#9b59b6',
  forwardEdge: '#00d4ff',
  backwardEdge: '#e74c3c',
  edgeLabel: '#a8b2bf',
};

function shortAddr(a: string): string {
  if (!a) return '';
  if (a.length <= 12) return a;
  return `${a.slice(0, 6)}…${a.slice(-4)}`;
}

function fmtAmount(n: number | undefined): string {
  if (n === undefined || n === null || !isFinite(n)) return '';
  const abs = Math.abs(n);
  if (abs >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (abs >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (abs >= 1e3) return (n / 1e3).toFixed(2) + 'K';
  if (abs >= 1) return n.toFixed(3);
  if (abs >= 0.001) return n.toFixed(5);
  return n.toExponential(2);
}

function fmtAsset(asset: string | undefined, map: Record<string, string>): string {
  if (!asset) return '';
  if (map[asset]) return map[asset];
  if (asset.length <= 8) return asset;
  return `TOK:${asset.slice(-4)}`;
}

function fmtTs(ts: number | undefined): string {
  if (!ts) return '';
  const d = new Date(ts * (ts < 1e12 ? 1000 : 1));
  return d.toISOString().slice(0, 16).replace('T', ' ');
}

function escXml(s: string): string {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]!));
}

interface LayoutNode {
  address: string;
  label?: string;
  kind: NonNullable<FlowNodeMeta['kind']>;
  level: number;
  row: number;
  x: number;
  y: number;
}

function classifyKind(addr: string, roots: Set<string>, providedKind?: FlowNodeMeta['kind'], label?: string): LayoutNode['kind'] {
  if (providedKind) return providedKind;
  if (roots.has(addr)) return 'root';
  const L = (label || '').toLowerCase();
  if (/binance|coinbase|kraken|bybit|okx|gate|kucoin|exchange|cex/.test(L)) return 'exchange';
  if (/mixer|tornado|wasabi|samourai|sinbad/.test(L)) return 'mixer';
  if (/bridge|stargate|wormhole|hop|across|synapse/.test(L)) return 'bridge';
  return 'intermediary';
}

function computeLevels(roots: string[], edges: FlowEdge[], maxLevels: number): Map<string, number> {
  const adj = new Map<string, Set<string>>();
  const adjBack = new Map<string, Set<string>>();
  for (const e of edges) {
    if (!adj.has(e.from)) adj.set(e.from, new Set());
    adj.get(e.from)!.add(e.to);
    if (!adjBack.has(e.to)) adjBack.set(e.to, new Set());
    adjBack.get(e.to)!.add(e.from);
  }
  const level = new Map<string, number>();
  const queue: Array<[string, number]> = roots.map(r => [r, 0]);
  for (const r of roots) level.set(r, 0);
  while (queue.length) {
    const [node, lvl] = queue.shift()!;
    if (lvl >= maxLevels) continue;
    const isBackwardLayer = lvl < 0;
    const next = (adj.get(node) || new Set());
    const prev = (adjBack.get(node) || new Set());
    for (const n of next) {
      if (!level.has(n) || lvl + 1 < (level.get(n) ?? Infinity)) {
        level.set(n, lvl + 1);
        queue.push([n, lvl + 1]);
      }
    }
    if (isBackwardLayer || roots.includes(node)) {
      for (const p of prev) {
        if (!level.has(p)) {
          level.set(p, lvl - 1);
          queue.push([p, lvl - 1]);
        }
      }
    }
  }
  for (const e of edges) {
    if (!level.has(e.from)) level.set(e.from, 0);
    if (!level.has(e.to)) {
      const fl = level.get(e.from)!;
      level.set(e.to, fl + (e.dir === 'backward' ? -1 : 1));
    }
  }
  return level;
}

export function renderFlowDiagram(input: FlowDiagramInput): string {
  const direction = input.direction || 'forward';
  const maxLevels = input.maxLevels ?? 8;
  const rootSet = new Set(input.rootAddresses);
  const labels = { ...(input.addressLabels || {}) };
  const assetMap = { ...(input.assetSymbols || {}) };

  const allAddrs = new Set<string>();
  for (const e of input.edges) { allAddrs.add(e.from); allAddrs.add(e.to); }
  for (const n of (input.nodes || [])) { allAddrs.add(n.address); if (n.label) labels[n.address] = n.label; }
  for (const r of input.rootAddresses) allAddrs.add(r);

  const nodeMetaMap = new Map<string, FlowNodeMeta>();
  for (const n of (input.nodes || [])) nodeMetaMap.set(n.address, n);

  const levelMap = computeLevels(input.rootAddresses, input.edges, maxLevels);
  const minLvl = Math.min(0, ...Array.from(levelMap.values()));
  const maxLvl = Math.max(0, ...Array.from(levelMap.values()));

  const levelGroups = new Map<number, string[]>();
  for (const a of allAddrs) {
    const lvl = levelMap.get(a) ?? 0;
    if (!levelGroups.has(lvl)) levelGroups.set(lvl, []);
    levelGroups.get(lvl)!.push(a);
  }
  for (const [, list] of levelGroups) list.sort();

  const COL_W = 280;
  const ROW_H = 88;
  const PAD_X = 60;
  const PAD_TOP = 140;
  const PAD_BOT = 80;
  const NODE_R = 26;

  const totalCols = (maxLvl - minLvl) + 1;
  const maxRows = Math.max(1, ...Array.from(levelGroups.values()).map(l => l.length));
  const W = PAD_X * 2 + totalCols * COL_W;
  const H = PAD_TOP + PAD_BOT + maxRows * ROW_H;

  const layout = new Map<string, LayoutNode>();
  for (const [lvl, list] of levelGroups) {
    const colIdx = lvl - minLvl;
    const x = PAD_X + colIdx * COL_W + COL_W / 2;
    const verticalSpan = list.length * ROW_H;
    const startY = PAD_TOP + (maxRows * ROW_H - verticalSpan) / 2 + ROW_H / 2;
    list.forEach((addr, i) => {
      const meta = nodeMetaMap.get(addr);
      const lbl = labels[addr] || meta?.label;
      const kind = classifyKind(addr, rootSet, meta?.kind, lbl);
      layout.set(addr, { address: addr, label: lbl, kind, level: lvl, row: i, x, y: startY + i * ROW_H });
    });
  }

  const out: string[] = [];
  out.push(`<?xml version="1.0" encoding="UTF-8"?>`);
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI,Roboto,Arial,sans-serif">`);
  out.push(`<defs>`);
  out.push(`<marker id="arrowF" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="${COLORS.forwardEdge}"/></marker>`);
  out.push(`<marker id="arrowB" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="${COLORS.backwardEdge}"/></marker>`);
  out.push(`<linearGradient id="bgGrad" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#0a0e14"/><stop offset="100%" stop-color="#101822"/></linearGradient>`);
  out.push(`</defs>`);
  out.push(`<rect width="100%" height="100%" fill="url(#bgGrad)"/>`);

  out.push(`<text x="${W / 2}" y="38" text-anchor="middle" font-size="22" font-weight="700" fill="${COLORS.gold}">${escXml(input.title)}</text>`);
  const subtitle = [
    input.caseId ? `Case ${input.caseId}` : '',
    input.ecosystem ? `Chain: ${input.ecosystem}` : '',
    `Direction: ${direction}`,
    input.generatedAt ? `Generated: ${input.generatedAt}` : '',
  ].filter(Boolean).join(' · ');
  out.push(`<text x="${W / 2}" y="62" text-anchor="middle" font-size="12" fill="${COLORS.dim}">${escXml(subtitle)}</text>`);
  out.push(`<text x="${W / 2}" y="82" text-anchor="middle" font-size="11" fill="${COLORS.cyan}">Alpha Forensic Flow Visualizer™ — PROPRIETARY · Owner: alphaunlimitedtoken@gmail.com</text>`);

  for (let lvl = minLvl; lvl <= maxLvl; lvl++) {
    const x = PAD_X + (lvl - minLvl) * COL_W + COL_W / 2;
    const lblTxt = lvl === 0 ? 'ROOT' : (lvl > 0 ? `HOP +${lvl}` : `HOP ${lvl}`);
    out.push(`<text x="${x}" y="108" text-anchor="middle" font-size="11" font-weight="600" fill="${COLORS.dim}" letter-spacing="2">${lblTxt}</text>`);
    out.push(`<line x1="${x}" y1="115" x2="${x}" y2="${H - 40}" stroke="${COLORS.panel}" stroke-width="1" stroke-dasharray="2,4"/>`);
  }

  for (const e of input.edges) {
    const a = layout.get(e.from); const b = layout.get(e.to);
    if (!a || !b) continue;
    const isBack = e.dir === 'backward';
    const stroke = isBack ? COLORS.backwardEdge : COLORS.forwardEdge;
    const marker = isBack ? 'url(#arrowB)' : 'url(#arrowF)';
    const dx = b.x - a.x;
    const ctrl = Math.abs(dx) * 0.35;
    const x1 = a.x + (dx >= 0 ? NODE_R : -NODE_R);
    const x2 = b.x - (dx >= 0 ? NODE_R + 4 : -(NODE_R + 4));
    const path = `M ${x1} ${a.y} C ${x1 + (dx >= 0 ? ctrl : -ctrl)} ${a.y}, ${x2 - (dx >= 0 ? ctrl : -ctrl)} ${b.y}, ${x2} ${b.y}`;
    out.push(`<path d="${path}" fill="none" stroke="${stroke}" stroke-width="1.4" stroke-opacity="0.75" marker-end="${marker}"/>`);
    const midX = (x1 + x2) / 2;
    const midY = (a.y + b.y) / 2 - 8;
    const amtTxt = fmtAmount(e.delta !== undefined ? Math.abs(e.delta) : undefined);
    const assetTxt = fmtAsset(e.asset, assetMap);
    const tsTxt = fmtTs(e.ts);
    const lbl = [amtTxt, assetTxt].filter(Boolean).join(' ');
    if (lbl) {
      const lblW = Math.max(60, lbl.length * 6.5 + 12);
      out.push(`<rect x="${midX - lblW / 2}" y="${midY - 11}" width="${lblW}" height="14" rx="3" fill="${COLORS.panel}" stroke="${stroke}" stroke-opacity="0.4"/>`);
      out.push(`<text x="${midX}" y="${midY}" text-anchor="middle" font-size="10" fill="${COLORS.white}">${escXml(lbl)}</text>`);
      if (tsTxt) out.push(`<text x="${midX}" y="${midY + 12}" text-anchor="middle" font-size="8" fill="${COLORS.edgeLabel}">${escXml(tsTxt)}</text>`);
    }
  }

  for (const node of layout.values()) {
    let fill = COLORS.intermFill, stroke = COLORS.intermStroke;
    if (node.kind === 'root') { fill = COLORS.rootFill; stroke = COLORS.rootStroke; }
    else if (node.kind === 'exchange') { fill = COLORS.exchFill; stroke = COLORS.exchStroke; }
    else if (node.kind === 'mixer') { fill = COLORS.mixerFill; stroke = COLORS.mixerStroke; }
    else if (node.kind === 'bridge') { fill = COLORS.bridgeFill; stroke = COLORS.bridgeStroke; }
    if (node.kind === 'root') {
      const r = NODE_R;
      const pts = Array.from({ length: 6 }, (_, i) => {
        const ang = (Math.PI / 3) * i - Math.PI / 6;
        return `${node.x + r * Math.cos(ang)},${node.y + r * Math.sin(ang)}`;
      }).join(' ');
      out.push(`<polygon points="${pts}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`);
    } else {
      out.push(`<circle cx="${node.x}" cy="${node.y}" r="${NODE_R}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`);
    }
    const ico = node.kind === 'exchange' ? '⇋' : node.kind === 'mixer' ? '✶' : node.kind === 'bridge' ? '⇄' : node.kind === 'root' ? '◆' : '●';
    out.push(`<text x="${node.x}" y="${node.y + 5}" text-anchor="middle" font-size="14" fill="${COLORS.white}">${ico}</text>`);
    out.push(`<text x="${node.x}" y="${node.y + NODE_R + 14}" text-anchor="middle" font-size="10" font-weight="600" fill="${COLORS.white}">${escXml(shortAddr(node.address))}</text>`);
    if (node.label) {
      const trunc = node.label.length > 28 ? node.label.slice(0, 26) + '…' : node.label;
      out.push(`<text x="${node.x}" y="${node.y + NODE_R + 26}" text-anchor="middle" font-size="9" fill="${COLORS.gold}">${escXml(trunc)}</text>`);
    }
  }

  const legendY = H - 20;
  const items: Array<[string, string, string]> = [
    ['◆ ROOT', COLORS.rootStroke, 'Subject wallet(s)'],
    ['● HOP', COLORS.intermStroke, 'Intermediary'],
    ['⇋ EXCH', COLORS.exchStroke, 'Exchange / CEX'],
    ['✶ MIX', COLORS.mixerStroke, 'Mixer'],
    ['⇄ BRG', COLORS.bridgeStroke, 'Bridge'],
  ];
  let lx = PAD_X;
  for (const [lbl, col, desc] of items) {
    out.push(`<text x="${lx}" y="${legendY}" font-size="10" fill="${col}" font-weight="700">${escXml(lbl)}</text>`);
    out.push(`<text x="${lx + 56}" y="${legendY}" font-size="10" fill="${COLORS.dim}">${escXml(desc)}</text>`);
    lx += 180;
  }
  out.push(`<text x="${W - PAD_X}" y="${legendY}" text-anchor="end" font-size="9" fill="${COLORS.dim}">© Alpha Unlimited Trading Co. — Confidential Forensic Output</text>`);

  out.push(`</svg>`);
  return out.join('\n');
}

export function renderFlowDiagramHtml(input: FlowDiagramInput): string {
  const svg = renderFlowDiagram(input);
  const hdr = proprietaryHeader('Alpha Forensic Flow Visualizer™');
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>${escXml(input.title)} — Alpha Forensic Flow Visualizer™</title>
<style>
  body{margin:0;background:#0a0e14;color:#e8eef5;font-family:Segoe UI,Roboto,Arial,sans-serif;padding:24px}
  .hdr{font-size:11px;color:#6b7785;border-bottom:1px solid #1a2230;padding-bottom:10px;margin-bottom:14px;word-break:break-all}
  .wrap{overflow-x:auto;background:#0f1620;border:1px solid #1a2230;border-radius:8px;padding:8px}
  svg{display:block;max-width:100%;height:auto}
  .ftr{margin-top:14px;font-size:10px;color:#6b7785;text-align:center}
</style></head><body>
<div class="hdr">${escXml(hdr)}</div>
<div class="wrap">${svg}</div>
<div class="ftr">Alpha Forensic Flow Visualizer™ — © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.</div>
</body></html>`;
}

export { proprietaryHeader as _proprietaryHeader };
