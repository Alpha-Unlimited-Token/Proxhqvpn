/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 *
 * Re-runs the MAGA $44k sell case through the now-Solana-capable Alpha Universal
 * Forensics Engine™ to demonstrate the closed chain-coverage gap.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
import {
  traceWalletUniversal,
  runSpiderTraceUniversal,
  pivotSurveillanceUniversal,
  correlateAmountUniversal,
  detectChainsForAddress,
  SUPPORTED_CHAINS,
} from '../../server/services/universalForensics.js';
import fs from 'node:fs';

enforceProprietaryLicense('MAGA-RAVEDAO Universal Re-Trace');

const SELLER = 'GQ3NnM7tqZURAJNnncuXB3ttPkoFfejs24sYpUDm8sYC';
const HOP_A  = '8h6SVSCdsxhYBCZyWYKyt77pPPhgbeSwK5DqDrr1cZWJ'; // best-effort placeholder; we will discover real hops
const TARGET_SOL = 514.75;
const CASE_ID = 'MAGA-RAVEDAO-2026-04-22';

const banner = (s: string) => `\n${'═'.repeat(80)}\n  ${s}\n${'═'.repeat(80)}`;

(async () => {
  console.log(proprietaryHeader('Alpha Universal Forensics Engine™'));
  console.log(banner('UCAL — supported chains'));
  console.log(SUPPORTED_CHAINS.join(', '));

  console.log(banner(`Auto-detect chain for ${SELLER}`));
  const detected = detectChainsForAddress(SELLER);
  console.log('Address shape matches:', detected);

  console.log(banner(`Multi-Chain Wallet Tracer™ (Universal) — ${SELLER}`));
  const trace = await traceWalletUniversal(SELLER, 'solana', { transferLimit: 10, counterpartyLimit: 10 });
  console.log(`Chain        : ${trace.chain}`);
  console.log(`Native bal   : ${trace.profile.nativeBalance.toFixed(4)} SOL`);
  console.log(`Tokens held  : ${trace.profile.tokens.length}`);
  console.log(`Last seen    : ${trace.profile.lastSeen ? new Date(trace.profile.lastSeen * 1000).toISOString() : 'n/a'}`);
  console.log(`Counterparties (top 10):`);
  for (const cp of trace.counterparties.slice(0, 10)) {
    console.log(`  • ${cp.address.slice(0, 8)}…  txs=${cp.count}  in=${cp.inboundValueNative.toFixed(4)} SOL  out=${cp.outboundValueNative.toFixed(4)} SOL`);
  }

  console.log(banner(`Forensic Spider™ (Universal) — depth=2 from ${SELLER}`));
  const spider = await runSpiderTraceUniversal(SELLER, 'solana', { maxDepth: 2, perHopLimit: 4 });
  console.log(`Total nodes  : ${spider.totalNodes}`);
  console.log(`Total edges  : ${spider.totalEdges}`);
  console.log(`Notes        : ${spider.notes.length ? spider.notes.join(' | ') : '(none)'}`);
  console.log('Top 8 spider nodes by depth/balance:');
  for (const n of spider.nodes.slice(0, 8)) {
    console.log(`  d${n.depth}  ${n.address.slice(0, 10)}…  bal=${n.nativeBalance.toFixed(2)} SOL  txs=${n.txCount}`);
  }

  console.log(banner(`Auto-Pivot Surveillance Engine™ (Universal) — ${SELLER}`));
  const pivot = await pivotSurveillanceUniversal(SELLER, 'solana', { limit: 50 });
  console.log(`Outbound pivots (top 5):`);
  for (const p of pivot.outboundPivots.slice(0, 5)) {
    console.log(`  → ${p.counterparty?.slice(0, 10)}…  total=${p.totalSent.toFixed(4)} SOL  last=${new Date(p.lastSeen * 1000).toISOString()}`);
  }
  console.log(`Swap events detected: ${pivot.swapEvents.length}`);

  console.log(banner(`Amount Correlation Scanner™ (Universal) — find ${TARGET_SOL} SOL ±0.5%`));
  // Scan seller + each top counterparty for a transfer of exactly the cashout amount
  const candidates = [SELLER, ...trace.counterparties.slice(0, 10).map(c => c.address)];
  const corr = await correlateAmountUniversal(candidates, TARGET_SOL, 'SOL', 'solana', { tolerancePct: 0.5, perAddrLimit: 50 });
  console.log(`Scanned addresses : ${corr.scanned}`);
  console.log(`Matches           : ${corr.matches.length}`);
  for (const m of corr.matches.slice(0, 8)) {
    console.log(`  • ${m.address.slice(0, 10)}…  ${m.amount.toFixed(4)} ${m.asset}  Δ=${m.deltaPct.toFixed(3)}%  tx=${m.hash.slice(0, 12)}…`);
  }

  // Persist machine-readable artifact
  const outPath = `attached_assets/forensic_reports/MAGA_Universal_Rerun_${CASE_ID}.json`;
  fs.mkdirSync('attached_assets/forensic_reports', { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify({
    proprietaryHeader: proprietaryHeader('Alpha Universal Forensics Engine™'),
    caseId: CASE_ID,
    seller: SELLER,
    chain: 'solana',
    trace,
    spider,
    pivot,
    correlation: corr,
  }, null, 2));
  console.log(banner(`✓ Universal re-trace complete — JSON written to ${outPath}`));
  try { const { autoEmitFlowDiagram } = await import('../forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(outPath, { title: `MAGA Universal Re-Trace — ${CASE_ID}`, caseId: CASE_ID, chain: 'solana', direction: 'forward', roots: [SELLER] }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }
})().catch((e) => { console.error('FAIL:', e); process.exit(1); });
