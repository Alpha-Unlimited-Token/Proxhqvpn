/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Solana On-Chain Rug-Risk Scorer™ + MAGA 3-Hop / 100-Wallet Trace
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
import fs from 'node:fs';

enforceProprietaryLicense('Alpha Solana On-Chain Rug-Risk Scorer™');
enforceProprietaryLicense('MAGA 3-Hop / 100-Wallet Combined Trace');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';
const RPC = `https://solana-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

/* ========== Constants ========== */
const MAGA_MINT = 'Hon2rHAiqkcDtUzL5gA2vjXPr7T1MPCK2UT2AHKCpump';
const SELLER    = 'GQ3NnM7tqZURAJNnncuXB3ttPkoFfejs24sYpUDm8sYC';
const SELL_TS   = Math.floor(Date.parse('2026-04-22T01:47:44Z') / 1000);
const POST_SELL_DESTS = [
  '8h6SVSCdsxhYBCZyWYKyt77pPPhgbeSwK5DqDrr1cZWJ',
  '4kWFa6VSFTjbNCCrtBJqwWE2dRWxfawcrTVWb2hHqEZL',
];
const DEV_CLUSTER = [
  { owner: 'EpEPwSwfR34Puadp7H2vTCWkFbpmMFfgbEsPwHrZuawk', tag: 'TOKEN CREATOR' },
  { owner: '7krzWQqfJ4b8tbKJMmBFyUkM7oW5C5Hy5eM2fqCUsJqk', tag: 'Holder #1 (22.1M)' },
  { owner: 'Bu4mcHDKKL5eaks8CWDr1boFQN5RCkS9E5jQiKrvypeY', tag: 'Holder #2 (20M round)' },
  { owner: '9jxPzF1PLgLDPabXVVCLohf3NrXrgrNuYh8rCwLVqXiB', tag: 'Holder #3 (20M round)' },
  { owner: 'NCvLfg6ErPPXVqPt7g9GC1snvm5BgEJnK6JVgDEh1S2',  tag: 'Holder #4 (20M round)' },
  { owner: 'GmBvDo82unnqSV7Te9TLryHAkrU3odMfsAA65KZnMw3h', tag: 'Holder #5 (20M round)' },
  { owner: 'DQJEMN1pyHoqTyweNvFh3kh4XYeLy6gcAS63ktq6tGYV', tag: 'Holder #6 (20M round)' },
  { owner: 'C1qmmu7ATmx6VLkjyAqyAiAnSciv3FHFD4dV6Hx1XDvL', tag: 'Holder #7 (19.7M)' },
];

const SKIP = new Set([
  '11111111111111111111111111111111',                                // System
  'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',                    // SPL Token
  'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL',                   // ATA
  'ComputeBudget111111111111111111111111111111',
  'SysvarRent111111111111111111111111111111111',
  '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P',                    // Pump.fun program
  'pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA',                    // PumpSwap AMM
  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',                   // Raydium V4
  'CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK',                   // Raydium CPMM
  'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',                    // Jupiter v6
  'JUP4Fb2cqiRUcaTHdrPC8h2gNsA2ETXiPDD33WcGuJB',                    // Jupiter v4
  MAGA_MINT,
]);

/* ========== Throttled Solana RPC ========== */
let lastCall = 0;
let chain: Promise<any> = Promise.resolve();
const MIN_DELAY = 220; // ~4.5 req/sec safe under Alchemy free tier

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

function srpc(method: string, params: any[]): Promise<any> {
  const job = chain.then(async () => {
    const elapsed = Date.now() - lastCall;
    if (elapsed < MIN_DELAY) await sleep(MIN_DELAY - elapsed);
    lastCall = Date.now();
    let lastErr: any = null;
    for (let attempt = 0; attempt < 6; attempt++) {
      try {
        const r = await fetch(RPC, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        });
        if (r.status === 429 || r.status >= 500) {
          lastErr = new Error(`HTTP ${r.status}`);
          await sleep(700 * Math.pow(2, attempt));
          continue;
        }
        const txt = await r.text();
        if (!txt) { lastErr = new Error('empty body'); await sleep(500); continue; }
        const j = JSON.parse(txt);
        if (j.error) {
          lastErr = new Error(`${method}: ${j.error.message || JSON.stringify(j.error)}`);
          if (j.error.code === -32429 || /rate/i.test(j.error.message || '')) { await sleep(700 * Math.pow(2, attempt)); continue; }
          // Non-retryable RPC error → return null instead of throwing to keep script alive
          console.error(`     ⚠ srpc ${method} non-retryable: ${lastErr.message}`);
          return null;
        }
        return j.result;
      } catch (e: any) {
        lastErr = e;
        await sleep(400 * (attempt + 1));
      }
    }
    console.error(`     ⚠ srpc ${method} exhausted retries: ${lastErr?.message || lastErr}`);
    return null;
  });
  chain = job.catch(() => null); // continue chain even on error
  return job;
}

/* ========== Rug-Pull Score ========== */
interface RugReport {
  mint: string;
  totalSupply: number;
  decimals: number;
  mintAuthority: string | null;
  freezeAuthority: string | null;
  top10ConcentrationPct: number;
  topHolders: { account: string; ownerHint?: string; uiAmount: number; pct: number }[];
  score: number;          // 0–100
  verdict: string;        // human label
  factors: { factor: string; weight: number; note: string }[];
}

async function computeRugScore(): Promise<RugReport> {
  const mintInfo: any = await srpc('getAccountInfo', [MAGA_MINT, { encoding: 'jsonParsed' }]);
  const info = mintInfo?.value?.data?.parsed?.info;
  const decimals = info?.decimals ?? 6;
  const totalSupply = Number(info?.supply ?? 0) / 10 ** decimals;
  const mintAuth = info?.mintAuthority || null;
  const freezeAuth = info?.freezeAuthority || null;
  const top: any = await srpc('getTokenLargestAccounts', [MAGA_MINT]);
  const topRaw = (top?.value || []).slice(0, 10);
  const topHolders = topRaw.map((t: any) => ({
    account: t.address,
    uiAmount: Number(t.uiAmount ?? 0),
    pct: totalSupply ? (Number(t.uiAmount ?? 0) / totalSupply) * 100 : 0,
  }));
  const top10Pct = topHolders.reduce((s, t) => s + t.pct, 0);

  let score = 0;
  const factors: RugReport['factors'] = [];

  if (mintAuth) {
    score += 35;
    factors.push({ factor: 'Mint authority STILL ACTIVE', weight: 35, note: `Authority: ${mintAuth} — can mint unlimited new supply at any moment.` });
  } else {
    factors.push({ factor: 'Mint authority renounced', weight: 0, note: 'No address can inflate supply — strong positive signal.' });
  }
  if (freezeAuth) {
    score += 25;
    factors.push({ factor: 'Freeze authority STILL ACTIVE', weight: 25, note: `Authority: ${freezeAuth} — can freeze any holder's tokens, blocking sells.` });
  } else {
    factors.push({ factor: 'Freeze authority renounced', weight: 0, note: 'No wallet can be frozen — strong positive signal.' });
  }
  if (top10Pct >= 80)      { score += 30; factors.push({ factor: 'Top-10 holder concentration EXTREME', weight: 30, note: `${top10Pct.toFixed(1)}% concentrated in top 10 wallets — coordinated dump risk.` }); }
  else if (top10Pct >= 60) { score += 20; factors.push({ factor: 'Top-10 holder concentration HIGH',    weight: 20, note: `${top10Pct.toFixed(1)}% concentrated in top 10.` }); }
  else if (top10Pct >= 40) { score += 10; factors.push({ factor: 'Top-10 holder concentration moderate', weight: 10, note: `${top10Pct.toFixed(1)}% in top 10.` }); }
  else                     {              factors.push({ factor: 'Top-10 holder concentration low',     weight: 0,  note: `${top10Pct.toFixed(1)}% in top 10.` }); }

  // Pump.fun mint suffix indicates this token NEVER graduated to a permanent Raydium pool
  // if the mint still ends in "pump"; that means liquidity sits in the bonding curve and
  // can disappear when bonding curve completes/migrates.
  const isPumpFunBonding = MAGA_MINT.endsWith('pump');
  if (isPumpFunBonding) {
    score += 10;
    factors.push({ factor: 'Pump.fun bonding-curve token (suffix "pump")', weight: 10, note: 'Mint did not graduate to permanent Raydium pool yet — bonding-curve liquidity is fragile.' });
  }

  const verdict =
    score >= 70 ? 'EXTREME RUG RISK' :
    score >= 50 ? 'HIGH RUG RISK' :
    score >= 30 ? 'MODERATE RUG RISK' :
    score >= 15 ? 'LOW RUG RISK' :
                  'MINIMAL RUG RISK';

  return {
    mint: MAGA_MINT,
    totalSupply,
    decimals,
    mintAuthority: mintAuth,
    freezeAuthority: freezeAuth,
    top10ConcentrationPct: top10Pct,
    topHolders,
    score: Math.min(100, score),
    verdict,
    factors,
  };
}

/* ========== Resolve top 5 holder OWNERS ========== */
async function resolveOwners(holderAccts: { account: string }[]): Promise<{ account: string; owner: string | null }[]> {
  const out: { account: string; owner: string | null }[] = [];
  for (const h of holderAccts.slice(0, 5)) {
    try {
      const info: any = await srpc('getAccountInfo', [h.account, { encoding: 'jsonParsed' }]);
      out.push({ account: h.account, owner: info?.value?.data?.parsed?.info?.owner ?? null });
    } catch (e: any) {
      console.error(`     ⚠ resolveOwner failed for ${h.account}: ${e?.message || e}`);
      out.push({ account: h.account, owner: null });
    }
  }
  return out;
}

/* ========== BFS — bidirectional, 100 wallet global budget ========== */
interface Sighting { depth: number; sourceRoot: string; via: string | null; ts: number; dir: 'forward' | 'backward'; }
interface VisitedNode { sightings: Sighting[]; }
interface Edge { from: string; to: string; hash: string; delta: number; asset: 'SOL' | string; ts: number; rootLabel: string; dir: 'forward' | 'backward'; }

async function bfsRoot(
  rootAddr: string,
  rootLabel: string,
  dir: 'forward' | 'backward',
  budget: number,
  globalVisited: Map<string, VisitedNode>,
  edges: Edge[],
): Promise<void> {
  if (budget <= 0) return;
  const local = new Set<string>([rootAddr]);
  const rootSighting: Sighting = { depth: 0, sourceRoot: rootLabel, via: null, ts: SELL_TS, dir };
  if (!globalVisited.has(rootAddr)) globalVisited.set(rootAddr, { sightings: [rootSighting] });
  else globalVisited.get(rootAddr)!.sightings.push(rootSighting);
  const queue: { addr: string; depth: number }[] = [{ addr: rootAddr, depth: 0 }];
  let added = 0;
  while (queue.length && added < budget) {
    const { addr, depth } = queue.shift()!;
    if (depth >= 3) continue;
    let sigs: any[] | null = null;
    try { sigs = await srpc('getSignaturesForAddress', [addr, { limit: 30 }]); } catch (e: any) { console.error(`     ⚠ getSigs ${addr.slice(0,8)}: ${e?.message}`); continue; }
    if (!Array.isArray(sigs)) continue;
    const filtered = sigs
      .filter(s => s?.blockTime != null)
      .filter(s => dir === 'forward' ? s.blockTime >= SELL_TS : s.blockTime <= SELL_TS)
      .slice(0, 6);
    for (const sig of filtered) {
      if (added >= budget) break;
      let tx: any = null;
      try { tx = await srpc('getTransaction', [sig.signature, { maxSupportedTransactionVersion: 0, encoding: 'jsonParsed' }]); } catch (e: any) { continue; }
      if (!tx?.meta || !tx.transaction) continue;
      const accts: string[] = tx.transaction.message.accountKeys.map((k: any) => typeof k === 'string' ? k : k.pubkey);
      const myIdx = accts.indexOf(addr);
      if (myIdx === -1) continue;

      // Build per-account delta map across SOL + every SPL mint encountered
      // Map<accountAddress, { sol: number, tokens: Map<mint, number> }>
      const deltas = new Map<string, { sol: number; tokens: Map<string, number> }>();
      const ensure = (a: string) => { if (!deltas.has(a)) deltas.set(a, { sol: 0, tokens: new Map() }); return deltas.get(a)!; };
      for (let j = 0; j < accts.length; j++) {
        const sol = ((tx.meta.postBalances[j] ?? 0) - (tx.meta.preBalances[j] ?? 0)) / 1e9;
        if (sol !== 0) ensure(accts[j]).sol = sol;
      }
      const pre = tx.meta.preTokenBalances || [];
      const post = tx.meta.postTokenBalances || [];
      // Build owner maps from pre/post (token accts → owner)
      const collect = (rows: any[], side: 'pre' | 'post') => {
        for (const r of rows) {
          const owner = r.owner; const mint = r.mint;
          const amt = Number(r.uiTokenAmount?.uiAmount ?? 0);
          if (!owner) continue;
          const d = ensure(owner);
          d.tokens.set(mint, (d.tokens.get(mint) ?? 0) + (side === 'post' ? amt : -amt));
        }
      };
      collect(pre, 'pre'); collect(post, 'post');

      const myD = deltas.get(addr) || { sol: 0, tokens: new Map() };
      // Determine my "primary movement": prefer SPL token of interest, then SOL
      let myPrimaryDelta = myD.sol;
      let myPrimaryAsset: 'SOL' | string = 'SOL';
      for (const [mint, amt] of myD.tokens) {
        if (Math.abs(amt) > Math.abs(myPrimaryDelta)) { myPrimaryDelta = amt; myPrimaryAsset = mint; }
      }
      if (myPrimaryDelta === 0) continue;

      // Find best counterparty: largest opposite-sign delta in the same asset
      let cp: string | null = null; let bestAbs = 0; let bestDelta = 0;
      for (const [a, d] of deltas) {
        if (a === addr || SKIP.has(a)) continue;
        const cand = myPrimaryAsset === 'SOL' ? d.sol : (d.tokens.get(myPrimaryAsset) ?? 0);
        if (cand === 0) continue;
        if (Math.sign(cand) !== Math.sign(myPrimaryDelta) && Math.abs(cand) > bestAbs) {
          bestAbs = Math.abs(cand); bestDelta = cand; cp = a;
        }
      }
      // Fallback: largest opposite-sign SOL delta from any non-program acct
      if (!cp) {
        for (const [a, d] of deltas) {
          if (a === addr || SKIP.has(a)) continue;
          if (Math.sign(d.sol) !== Math.sign(myPrimaryDelta) && Math.abs(d.sol) > bestAbs) {
            bestAbs = Math.abs(d.sol); bestDelta = d.sol; cp = a; myPrimaryAsset = 'SOL';
          }
        }
      }

      if (!cp || local.has(cp) || SKIP.has(cp)) continue;
      local.add(cp);
      edges.push({ from: dir === 'backward' ? cp : addr, to: dir === 'backward' ? addr : cp, hash: sig.signature, delta: bestDelta, asset: myPrimaryAsset, ts: sig.blockTime, rootLabel, dir });
      const sighting: Sighting = { depth: depth + 1, sourceRoot: rootLabel, via: addr, ts: sig.blockTime, dir };
      if (!globalVisited.has(cp)) globalVisited.set(cp, { sightings: [sighting] });
      else globalVisited.get(cp)!.sightings.push(sighting);
      added++;
      if (depth + 1 < 3) queue.push({ addr: cp, depth: depth + 1 });
    }
  }
}

/* ========== Cross-reference ========== */
interface Match {
  address: string;
  classified: string;
  sightings: { sourceRoot: string; depth: number; via: string | null; dir: string; ts: number }[];
}

function classify(addr: string, top5Owners: string[]): string | null {
  if (addr === SELLER) return 'SELLER';
  if (POST_SELL_DESTS.includes(addr)) return `POST-SELL DESTINATION ($44k recipient)`;
  const dev = DEV_CLUSTER.find(d => d.owner === addr);
  if (dev) return `DEV CLUSTER — ${dev.tag}`;
  const tIdx = top5Owners.indexOf(addr);
  if (tIdx !== -1) return `TOP-5 HOLDER #${tIdx + 1}`;
  return null;
}

function rootLabelOf(addr: string, top5Owners: string[]): string | null {
  if (addr === SELLER) return 'SELLER';
  const t = top5Owners.indexOf(addr); if (t !== -1) return `TOP-${t + 1} HOLDER`;
  const p = POST_SELL_DESTS.indexOf(addr); if (p !== -1) return `POST-SELL DEST ${p + 1}`;
  return null;
}

/* ========== Main ========== */
(async () => {
  console.log(proprietaryHeader('Alpha Solana On-Chain Rug-Risk Scorer™'));
  console.log(proprietaryHeader('MAGA 3-Hop / 100-Wallet Combined Trace'));

  console.log('\n[1/4] Computing on-chain rug-pull risk score for MAGA…');
  const rug = await computeRugScore();
  console.log(`     → Rug score: ${rug.score}/100 (${rug.verdict})`);
  console.log(`     → Mint auth: ${rug.mintAuthority || 'RENOUNCED'}`);
  console.log(`     → Freeze auth: ${rug.freezeAuthority || 'RENOUNCED'}`);
  console.log(`     → Top-10 concentration: ${rug.top10ConcentrationPct.toFixed(2)}%`);

  console.log('\n[2/4] Resolving top-5 MAGA holder OWNERS (token accts → real wallets)…');
  const top5 = await resolveOwners(rug.topHolders);
  for (let i = 0; i < top5.length; i++) {
    console.log(`     → #${i + 1}  acct=${top5[i].account.slice(0, 10)}…  owner=${top5[i].owner?.slice(0, 10) ?? '?'}…`);
  }
  const top5Owners = top5.map(t => t.owner).filter((x): x is string => !!x);

  // 8 roots: seller + 5 top holders + 2 post-sell destinations
  const ROOTS: { addr: string; label: string; dir: 'both' | 'backward' }[] = [
    { addr: SELLER, label: 'SELLER', dir: 'both' },
    ...top5Owners.map((a, i) => ({ addr: a, label: `TOP-${i + 1} HOLDER`, dir: 'both' as const })),
    ...POST_SELL_DESTS.map((a, i) => ({ addr: a, label: `POST-SELL DEST ${i + 1}`, dir: 'both' as const })),
  ];
  // Each root gets ~ (100 / (roots * 2 directions)) wallets per direction
  const directions = ROOTS.length * 2;
  const perBfs = Math.max(3, Math.floor(100 / directions));
  console.log(`\n[3/4] BFS 3-hop bidirectional trace — ${ROOTS.length} roots × 2 dirs, budget=${perBfs} wallets/dir (≤${perBfs * directions} total)`);

  const globalVisited = new Map<string, VisitedNode>();
  const edges: Edge[] = [];
  for (const root of ROOTS) {
    process.stdout.write(`     • ${root.label.padEnd(22)} backward… `);
    await bfsRoot(root.addr, root.label, 'backward', perBfs, globalVisited, edges);
    process.stdout.write(`${edges.filter(e => e.rootLabel === root.label && e.dir === 'backward').length} edges. `);
    process.stdout.write('forward… ');
    await bfsRoot(root.addr, root.label, 'forward', perBfs, globalVisited, edges);
    console.log(`${edges.filter(e => e.rootLabel === root.label && e.dir === 'forward').length} edges.`);
  }
  console.log(`     → Total wallets visited: ${globalVisited.size} / 100 budget`);
  console.log(`     → Total edges captured:  ${edges.length}`);

  console.log('\n[4/4] Cross-referencing every visited wallet against dev cluster + top-5 + seller + post-sell dests…');
  // Two distinct overlap classes:
  //   (A) NODE overlap: a known entity appears as a NON-root sighting under another root
  //   (B) EDGE overlap: any edge endpoint is a known entity reached from a DIFFERENT root
  const matches: Match[] = [];
  for (const [addr, meta] of globalVisited) {
    const cls = classify(addr, top5Owners);
    if (!cls) continue;
    const ownRoot = rootLabelOf(addr, top5Owners); // root label this address IS, if any
    const foreignSightings = meta.sightings.filter(s => s.depth > 0 && s.sourceRoot !== ownRoot);
    if (foreignSightings.length === 0) continue;
    matches.push({
      address: addr,
      classified: cls,
      sightings: foreignSightings.map(s => ({ sourceRoot: s.sourceRoot, depth: s.depth, via: s.via, dir: s.dir, ts: s.ts })),
    });
  }
  // Edge overlaps not already captured by a node match: edges where the OTHER endpoint is a known entity
  const edgeOverlaps: { rootLabel: string; dir: string; from: string; to: string; knownSide: string; knownClass: string; hash: string; delta: number; asset: string; ts: number }[] = [];
  for (const e of edges) {
    for (const side of ['from', 'to'] as const) {
      const a = e[side];
      const cls = classify(a, top5Owners);
      if (!cls) continue;
      const ownRoot = rootLabelOf(a, top5Owners);
      if (ownRoot === e.rootLabel) continue; // same root, expected
      edgeOverlaps.push({ rootLabel: e.rootLabel, dir: e.dir, from: e.from, to: e.to, knownSide: side, knownClass: cls, hash: e.hash, delta: e.delta, asset: e.asset, ts: e.ts });
    }
  }
  console.log(`     → Node overlaps: ${matches.length}, edge overlaps: ${edgeOverlaps.length}`);
  for (const m of matches) console.log(`       ★ NODE  ${m.address}  =  ${m.classified}  (sightings: ${m.sightings.map(s => `${s.sourceRoot}:h${s.depth}/${s.dir}`).join(', ')})`);
  for (const e of edgeOverlaps) console.log(`       ★ EDGE  ${e.rootLabel}/${e.dir}: ${e.from.slice(0,10)}…→${e.to.slice(0,10)}…  (${e.knownClass} on ${e.knownSide})  ${e.delta.toFixed(4)} ${e.asset === 'SOL' ? 'SOL' : 'tok'}`);

  /* ===== Build report ===== */
  const ts = new Date().toISOString();
  const txtLines: string[] = [];
  const W = (s = '') => txtLines.push(s);

  W('═'.repeat(82));
  W('  ALPHA UNLIMITED FORENSICS — MAGA Combined Rug-Score + 100-Wallet 3-Hop Trace');
  W('═'.repeat(82));
  W();
  W(proprietaryHeader('Alpha Solana On-Chain Rug-Risk Scorer™'));
  W(proprietaryHeader('MAGA 3-Hop / 100-Wallet Combined Trace'));
  W();
  W(`Generated:        ${ts}`);
  W(`Token mint:       ${MAGA_MINT}`);
  W(`Seller:           ${SELLER}`);
  W(`Sell timestamp:   ${new Date(SELL_TS * 1000).toISOString()}`);
  W();

  W('─'.repeat(82));
  W('  SECTION A — RUG-PULL RISK ANALYSIS  (on-chain, real-time)');
  W('─'.repeat(82));
  W();
  W(`  RUG SCORE:        ${rug.score} / 100`);
  W(`  VERDICT:          ${rug.verdict}`);
  W();
  W(`  Mint authority:    ${rug.mintAuthority || 'RENOUNCED ✓'}`);
  W(`  Freeze authority:  ${rug.freezeAuthority || 'RENOUNCED ✓'}`);
  W(`  Total supply:      ${rug.totalSupply.toLocaleString()} MAGA`);
  W(`  Top-10 concentration: ${rug.top10ConcentrationPct.toFixed(2)}%`);
  W();
  W('  Scoring breakdown:');
  for (const f of rug.factors) {
    W(`    [+${String(f.weight).padStart(2, ' ')}]  ${f.factor}`);
    W(`           ${f.note}`);
  }
  W();
  W('  Top-10 holders (current):');
  W(`    #  Token Account                                  Balance MAGA          % of Supply`);
  for (let i = 0; i < rug.topHolders.length; i++) {
    const h = rug.topHolders[i];
    W(`    ${(i + 1).toString().padStart(2)}  ${h.account}  ${h.uiAmount.toLocaleString().padStart(18)}  ${h.pct.toFixed(2).padStart(7)}%`);
  }
  W();
  W('  HONEST DISCLOSURE: The original Alpha Web Archive Forensic Snapshotter™ is built');
  W('  for project-website Wayback-archive scoring (HTML site rug-pulls). For a pump.fun');
  W('  Solana memecoin with no project site, on-chain authority + concentration analysis');
  W('  is the correct tool — that is what this section uses.');
  W();

  W('─'.repeat(82));
  W('  SECTION B — TOP-5 HOLDER OWNERS  (resolved from token accounts)');
  W('─'.repeat(82));
  W();
  for (let i = 0; i < top5.length; i++) {
    W(`  #${i + 1}  Token acct: ${top5[i].account}`);
    W(`      Owner wallet: ${top5[i].owner ?? '(unresolved)'}`);
  }
  W();

  W('─'.repeat(82));
  W('  SECTION C — 3-HOP BIDIRECTIONAL TRACE  (100-wallet budget, evenly spread)');
  W('─'.repeat(82));
  W();
  W(`  Roots probed:        ${ROOTS.length}  (Seller + Top-5 holders + 2 post-sell destinations)`);
  W(`  Per-root budget:     ${perBfs} wallets per direction (× 2 directions)`);
  W(`  Wallets visited:     ${globalVisited.size} / 100`);
  W(`  Edges captured:      ${edges.length}`);
  W();
  W('  Per-root results:');
  for (const root of ROOTS) {
    const back = edges.filter(e => e.rootLabel === root.label && e.dir === 'backward').length;
    const fwd  = edges.filter(e => e.rootLabel === root.label && e.dir === 'forward').length;
    W(`    • ${root.label.padEnd(22)} ${root.addr}   backward=${back}  forward=${fwd}`);
  }
  W();

  W('─'.repeat(82));
  W('  SECTION D — CROSS-REFERENCE MATCHES  (any visited wallet that is a known entity)');
  W('─'.repeat(82));
  W();
  if (matches.length === 0 && edgeOverlaps.length === 0) {
    W('  ✗ NO crossover detected. Within the 100-wallet 3-hop budget:');
    W('    – No top-5 holder appeared in the seller\'s hop network.');
    W('    – No dev-cluster wallet appeared in any root\'s hop network.');
    W('    – No post-sell destination appeared in any holder\'s back-trace.');
    W('    – No edge crossed from one root\'s subgraph into another known entity.');
    W();
    W('    Interpretation: Within the surveyed graph slice, the seller, top-5 holders,');
    W('    and dev cluster operate as independent wallet networks. This is consistent');
    W('    with the prior finding that the seller was a swing trader, not an insider.');
    W();
    W('    Caveat: 100 wallets × 3 hops is a meaningful slice but not exhaustive.');
    W('    A full census of all interactions would require thousands of additional');
    W('    RPC calls — feasible but beyond this scan budget.');
  } else {
    W(`  ★ Node-level overlaps: ${matches.length}`);
    for (const m of matches) {
      W(`    • Wallet:    ${m.address}`);
      W(`      Identity:  ${m.classified}`);
      W(`      Foreign sightings:`);
      for (const s of m.sightings) {
        W(`        - root=${s.sourceRoot}  hop=${s.depth}  dir=${s.dir}  via=${s.via ?? '(root)'}  @${new Date(s.ts * 1000).toISOString()}`);
      }
      W();
    }
    W(`  ★ Edge-level overlaps: ${edgeOverlaps.length}`);
    for (const e of edgeOverlaps) {
      W(`    • ${e.rootLabel} (${e.dir}): ${e.from} → ${e.to}`);
      W(`      Known entity: ${e.knownClass}  (on ${e.knownSide} side)`);
      W(`      Tx: ${e.hash}`);
      W(`      Δ ${e.delta.toFixed(6)} ${e.asset === 'SOL' ? 'SOL' : 'token=' + e.asset}  @${new Date(e.ts * 1000).toISOString()}`);
      W();
    }
  }
  W();

  W('─'.repeat(82));
  W('  SECTION E — DEV CLUSTER REFERENCE');
  W('─'.repeat(82));
  W();
  for (const d of DEV_CLUSTER) W(`    ${d.owner}   ${d.tag}`);
  W();

  W('═'.repeat(82));
  W('  END OF REPORT');
  W('═'.repeat(82));

  fs.mkdirSync('attached_assets/forensic_reports', { recursive: true });
  const txt = txtLines.join('\n');
  fs.writeFileSync('attached_assets/forensic_reports/MAGA_RugScore_and_100Wallet_Trace.txt', txt);

  // Quick HTML wrap
  const html = `<!doctype html><meta charset="utf-8"><title>MAGA Combined Forensic Report</title>
<style>body{background:#0b0b10;color:#e8e8ee;font-family:ui-monospace,Menlo,Consolas,monospace;padding:32px;max-width:1100px;margin:0 auto}
h1{color:#d4af37;font-family:system-ui;text-align:center}
.score{font-size:42px;color:${rug.score >= 70 ? '#ff5050' : rug.score >= 50 ? '#ff9b3a' : rug.score >= 30 ? '#ffd84d' : '#3fb950'};text-align:center;font-weight:700}
.verdict{text-align:center;color:#d4af37;font-size:18px;margin-bottom:24px}
pre{white-space:pre-wrap;word-break:break-all;line-height:1.45;font-size:12.5px}
.legend{font-size:11px;color:#888;text-align:center;margin-top:24px}</style>
<h1>MAGA — On-Chain Rug-Score + 100-Wallet 3-Hop Trace</h1>
<div class="score">${rug.score}/100</div>
<div class="verdict">${rug.verdict}</div>
<pre>${txt.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</pre>
<div class="legend">© 2024-2026 Alpha Unlimited Trading Company — PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA</div>`;
  fs.writeFileSync('attached_assets/forensic_reports/MAGA_RugScore_and_100Wallet_Trace.html', html);

  // JSON evidence pack
  fs.writeFileSync('attached_assets/forensic_reports/MAGA_RugScore_and_100Wallet_Trace.json', JSON.stringify({
    proprietaryHeader: proprietaryHeader('Alpha Solana On-Chain Rug-Risk Scorer™'),
    generatedAt: ts,
    rug,
    top5: top5,
    roots: ROOTS,
    walletsVisited: [...globalVisited.entries()].map(([addr, meta]) => ({ addr, sightings: meta.sightings })),
    edges,
    crossReferenceMatches: matches,
    edgeOverlaps,
    devCluster: DEV_CLUSTER,
  }, null, 2));

  // ─── Alpha Forensic Flow Visualizer™ — auto-emit TRM-style flow diagram ───
  try {
    const { renderFlowDiagram, renderFlowDiagramHtml } = await import('../forensics/flowDiagramVisualizer.js');
    const flowNodes = [...globalVisited.keys()].map(addr => ({
      address: addr,
      label: ROOTS.find(r => r.addr === addr)?.label,
      kind: ROOTS.find(r => r.addr === addr) ? 'root' as const : 'intermediary' as const,
    }));
    const flowInput = {
      title: 'MAGA $44k Sell — 100-Wallet 3-Hop Trace',
      caseId: 'MAGA-44K',
      ecosystem: 'Solana',
      direction: 'bidirectional' as const,
      rootAddresses: ROOTS.map(r => r.addr),
      nodes: flowNodes,
      edges: edges as any,
      generatedAt: ts,
    };
    fs.writeFileSync('attached_assets/forensic_reports/MAGA_RugScore_and_100Wallet_Trace_FlowDiagram.svg', renderFlowDiagram(flowInput));
    fs.writeFileSync('attached_assets/forensic_reports/MAGA_RugScore_and_100Wallet_Trace_FlowDiagram.html', renderFlowDiagramHtml(flowInput));
    console.log('  ✅ Flow diagram emitted (.svg + .html) via Alpha Forensic Flow Visualizer™');
  } catch (e: any) {
    console.log(`  ⚠️ Flow diagram emission skipped: ${e?.message || e}`);
  }

  console.log('\n✓ Report files written to attached_assets/forensic_reports/');
  console.log('  • MAGA_RugScore_and_100Wallet_Trace.txt');
  console.log('  • MAGA_RugScore_and_100Wallet_Trace.html');
  console.log('  • MAGA_RugScore_and_100Wallet_Trace.json');
})().catch(e => { console.error('FAIL:', e?.stack || e?.message || e); process.exit(1); });

process.on('uncaughtException', e => { console.error('UNCAUGHT:', e?.stack || e); });
process.on('unhandledRejection', e => { console.error('UNHANDLED REJECTION:', (e as any)?.stack || e); });
