/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Authorized Use Only.
 * Title 17 (US Copyright) | DMCA | CFAA | DTSA
 * Owner: alphaunlimitedtoken@gmail.com
 *
 * Alpha Multi-Chain Wallet Tracer™ — recent-movement snapshot of the
 * SillyTuna attacker network (post-Apr 11, 2026 alert), checking outbound
 * activity from the primary cashout, the OTC relay, and looking for any
 * NEW Binance deposit endpoints used by the attacker since the last report.
 */
import { enforceProprietaryLicense } from '../security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha Multi-Chain Wallet Tracer™');

import * as fs from 'fs';
import * as path from 'path';

const KEY = process.env.ALCHEMY_API_KEY;
if (!KEY) { console.error('ALCHEMY_API_KEY missing'); process.exit(1); }
const URL = `https://eth-mainnet.g.alchemy.com/v2/${KEY}`;

const SINCE_BLOCK_HEX = '0x14F0000'; // ~ April 11, 2026 (≈ block 21889024) — conservative lower bound

const ATTACKER_WALLETS: Record<string,string> = {
  '0x8e04af7f7c76daa9ab429b1340e0327b5b835748': 'Cashout Primary',
  '0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73': 'OTC/Bridge Relay (deposits to Binance HW14)',
};

const KNOWN_BINANCE: Record<string,string> = {
  '0x28c6c06298d514db089934071355e5743bf21d60': 'Binance Hot Wallet 14 (KYC)',
  '0x21a31ee1afc51d94c2efccaa2092ad1028285549': 'Binance 36',
  '0x56eddb7aa87536c09ccc2793473599fd21a8b17f': 'Binance 16',
  '0xdfd5293d8e347dfe59e90efd55b2956a1343963d': 'Binance 15',
};
const KNOWN_OTHER_CEX: Record<string,string> = {
  '0xf89d7b9c864f589bbf53a82105107622b35eaa40': 'Bybit',
  '0x46340b20830761efd32832a74d7169b29feb9758': 'Crypto.com 2',
  '0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23': 'Gate.io',
  '0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0': 'Kraken',
  '0xa7efae728d2936e78bda97dc267687568dd593f3': 'OKX 3',
};

async function rpc(method: string, params: any[]) {
  const r = await fetch(URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
  });
  return (await r.json()).result;
}

async function getTransfers(opts: { from?: string; to?: string; since: string; categories?: string[] }) {
  const params: any = {
    fromBlock: opts.since,
    toBlock: 'latest',
    category: opts.categories || ['external','erc20'],
    withMetadata: true,
    excludeZeroValue: true,
    maxCount: '0x3e8'
  };
  if (opts.from) params.fromAddress = opts.from;
  if (opts.to)   params.toAddress   = opts.to;
  const out: any[] = [];
  let pageKey: string | undefined;
  do {
    const r = await rpc('alchemy_getAssetTransfers', [{ ...params, ...(pageKey ? { pageKey } : {}) }]);
    if (!r) break;
    out.push(...(r.transfers || []));
    pageKey = r.pageKey;
  } while (pageKey && out.length < 2000);
  return out;
}

function classify(addr: string): string | null {
  const a = (addr || '').toLowerCase();
  if (KNOWN_BINANCE[a])   return `BINANCE → ${KNOWN_BINANCE[a]}`;
  if (KNOWN_OTHER_CEX[a]) return `CEX → ${KNOWN_OTHER_CEX[a]}`;
  return null;
}

async function main() {
  const balances: Record<string, string> = {};
  for (const w of Object.keys(ATTACKER_WALLETS)) {
    balances[w] = await rpc('eth_getBalance', [w, 'latest']);
  }

  const outbound: Record<string, any[]> = {};
  for (const w of Object.keys(ATTACKER_WALLETS)) {
    console.log(`[trace] outbound from ${w} ...`);
    outbound[w] = await getTransfers({ from: w, since: SINCE_BLOCK_HEX });
  }

  // Tag each transfer by exchange landing if applicable
  const cexHits: any[] = [];
  for (const [w, txs] of Object.entries(outbound)) {
    for (const t of txs) {
      const dest = (t.to || '').toLowerCase();
      const tag  = classify(dest);
      if (tag) {
        cexHits.push({
          source: w,
          sourceLabel: ATTACKER_WALLETS[w],
          to: dest,
          dest: tag,
          asset: t.asset || 'ETH',
          value: t.value,
          hash: t.hash,
          ts: t.metadata?.blockTimestamp,
        });
      }
    }
  }

  // Find any *new* deposit endpoints used (recurring outflow targets that look like CEX deposit addresses)
  const dstCounts: Record<string, { count: number; totalValue: number; asset: string; firstTs?: string; lastTs?: string }> = {};
  for (const txs of Object.values(outbound)) {
    for (const t of txs) {
      const d = (t.to || '').toLowerCase();
      if (!d) continue;
      const v = Number(t.value || 0);
      const cur = dstCounts[d] || { count: 0, totalValue: 0, asset: t.asset || 'ETH' };
      cur.count++;
      cur.totalValue += v;
      const ts = t.metadata?.blockTimestamp;
      if (ts) {
        if (!cur.firstTs || ts < cur.firstTs) cur.firstTs = ts;
        if (!cur.lastTs  || ts > cur.lastTs)  cur.lastTs  = ts;
      }
      dstCounts[d] = cur;
    }
  }
  const topDestinations = Object.entries(dstCounts)
    .sort((a,b) => b[1].totalValue - a[1].totalValue)
    .slice(0, 25)
    .map(([addr, info]) => ({ addr, ...info, knownTag: classify(addr) }));

  const summary = {
    generatedAt: new Date().toISOString(),
    sinceBlock: SINCE_BLOCK_HEX,
    wallets: Object.entries(ATTACKER_WALLETS).map(([addr,label]) => ({
      addr, label,
      outboundCount: outbound[addr].length,
      currentBalanceWei: balances[addr],
      currentBalanceEth: balances[addr] ? (parseInt(balances[addr],16) / 1e18).toFixed(4) : null,
    })),
    cexLandings: cexHits,
    topOutboundDestinations: topDestinations,
  };

  const outDir = path.join('private','exports','sillytuna-recent-movement');
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir,'summary.json'), JSON.stringify(summary, null, 2));
  fs.writeFileSync(path.join(outDir,'raw_outbound.json'), JSON.stringify(outbound, null, 2));

  console.log('=== SillyTuna Recent Movement Summary ===');
  console.log(JSON.stringify(summary, null, 2));
  console.log(`\nWritten: ${outDir}/summary.json`);
}

main().catch(e => { console.error(e); process.exit(1); });
