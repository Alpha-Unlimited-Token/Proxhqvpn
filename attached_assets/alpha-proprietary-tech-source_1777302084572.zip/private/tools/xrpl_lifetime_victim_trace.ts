/*
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide.
 * Alpha XRPL Lifetime Victim-Trace Engine™ — Patent Pending. Trade Secret Protected.
 * Protected by 17 U.S.C. (Copyright), DMCA, CFAA, DTSA, and international treaty.
 * Unauthorized copying, modification, distribution, or reverse engineering prohibited.
 * AUTHORIZED USE ONLY — Alpha Unlimited Trading internal forensic operations.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha XRPL Lifetime Victim-Trace Engine™');

import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import archiver from 'archiver';
import { autoEmitFlowDiagram } from '../forensics/autoEmitFlowDiagram.js';

const TECH = 'Alpha XRPL Lifetime Victim-Trace Engine™';
const VICTIM = process.argv[2] || 'rB47R6YQDEcNQszwRrb8JvAhgDXRncFTcT';
const CASE_ID = `XRPL-Lifetime-${VICTIM.slice(0,8)}-${new Date().toISOString().slice(0,10)}`;
const OUT_DIR = path.resolve('private/exports/xrpl-lifetime-trace');
const ZIP_PATH = path.resolve(`private/exports/XRPL-Lifetime-${VICTIM.slice(0,8)}-Victim-Trace.zip`);

const RPC_URLS = ['https://xrplcluster.com/', 'https://s1.ripple.com:51234/', 'https://s2.ripple.com:51234/'];
const XRPSCAN = 'https://api.xrpscan.com/api/v1';
const RIPPLE_EPOCH = 946684800;

fs.rmSync(OUT_DIR, { recursive: true, force: true });
fs.mkdirSync(OUT_DIR, { recursive: true });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
let rpcIdx = 0;
async function rpc(method: string, params: any): Promise<any> {
  for (let attempt = 0; attempt < 4; attempt++) {
    const url = RPC_URLS[rpcIdx % RPC_URLS.length];
    try {
      const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ method, params:[params] }) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const j: any = await r.json();
      if (j.result?.status === 'error') throw new Error(j.result.error_message || j.result.error);
      return j.result;
    } catch {
      rpcIdx++; await sleep(200 * (attempt+1));
      if (attempt === 3) return null;
    }
  }
  return null;
}

async function xrpscanLabel(addr: string): Promise<{ name?: string; account_category?: string } | null> {
  try {
    const r = await fetch(`${XRPSCAN}/account/${addr}`);
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

interface Tx {
  hash: string;
  ledger: number;
  iso: string;
  unix: number;
  type: string;
  source: string;
  destination?: string;
  destTag?: number;
  sourceTag?: number;
  amount: number;
  asset: string;
  issuer: string;
  result: string;
  direction: 'in'|'out'|'self'|'meta';
  counterparty: string;
  raw?: any;
}

function parseAmount(a: any): { amount: number; asset: string; issuer: string } {
  if (a == null) return { amount: 0, asset: '', issuer: '' };
  if (typeof a === 'string') return { amount: parseInt(a,10)/1e6, asset: 'XRP', issuer: '' };
  return { amount: parseFloat(a.value || '0'), asset: a.currency || 'IOU', issuer: a.issuer || '' };
}
function decodeCurrency(hex: string): string {
  if (!hex || hex.length !== 40) return hex;
  try {
    const buf = Buffer.from(hex, 'hex');
    const s = buf.toString('utf8').replace(/\0+$/,'').trim();
    if (/^[\x20-\x7E]+$/.test(s) && s.length > 0) return s;
  } catch {}
  return hex;
}

async function fetchAllTxs(addr: string): Promise<Tx[]> {
  const out: Tx[] = [];
  let marker: any = undefined;
  for (let page = 0; page < 100; page++) { // up to 20,000 tx
    const params: any = { account: addr, ledger_index_min: -1, ledger_index_max: -1, limit: 200, forward: true };
    if (marker) params.marker = marker;
    const r = await rpc('account_tx', params);
    const txs = r?.transactions || [];
    for (const item of txs) {
      const tx = item.tx || item.tx_json || {};
      const meta = item.meta || {};
      const dateUnix = (tx.date || 0) + RIPPLE_EPOCH;
      const iso = new Date(dateUnix*1000).toISOString();
      const ledger = item.ledger_index || tx.ledger_index || 0;
      const result = meta.TransactionResult || 'unknown';
      const type = tx.TransactionType || 'unknown';

      if (type === 'Payment') {
        const delivered = meta.delivered_amount ?? meta.DeliveredAmount ?? tx.Amount;
        const { amount, asset, issuer } = parseAmount(delivered);
        const direction: 'in'|'out'|'self' = tx.Account === addr && tx.Destination === addr ? 'self' : tx.Account === addr ? 'out' : 'in';
        out.push({
          hash: tx.hash || item.hash, ledger, iso, unix: dateUnix, type,
          source: tx.Account, destination: tx.Destination, destTag: tx.DestinationTag, sourceTag: tx.SourceTag,
          amount, asset: decodeCurrency(asset), issuer, result, direction,
          counterparty: direction === 'in' ? tx.Account : (tx.Destination || ''),
        });
      } else {
        // All other tx types: TrustSet, OfferCreate, OfferCancel, AccountSet, NFTokenMint/Accept/Burn, etc.
        const direction: 'out'|'meta' = tx.Account === addr ? 'out' : 'meta';
        let cpAddr = '';
        let amt = 0; let asset = ''; let issuer = '';
        if (type === 'TrustSet' && tx.LimitAmount) { ({ amount: amt, asset, issuer } = parseAmount(tx.LimitAmount)); cpAddr = issuer; asset = decodeCurrency(asset); }
        else if (type === 'OfferCreate') {
          const ta = parseAmount(tx.TakerGets);
          const tp = parseAmount(tx.TakerPays);
          asset = `${decodeCurrency(ta.asset)}→${decodeCurrency(tp.asset)}`;
          amt = ta.amount;
          cpAddr = ta.issuer || tp.issuer || '';
        }
        out.push({
          hash: tx.hash || item.hash, ledger, iso, unix: dateUnix, type,
          source: tx.Account, destination: tx.Destination || '', destTag: tx.DestinationTag, sourceTag: tx.SourceTag,
          amount: amt, asset, issuer, result, direction, counterparty: cpAddr,
        });
      }
    }
    if (!r?.marker) break;
    marker = r.marker;
    await sleep(120);
  }
  return out;
}

function csvEscape(v: any) { if (v == null) return ''; const s = String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s; }
function writeCsv(file: string, rows: any[]) {
  if (!rows.length) return fs.writeFileSync(file, '');
  const cols = Object.keys(rows[0]);
  fs.writeFileSync(file, [cols.join(','), ...rows.map(r => cols.map(c => csvEscape(r[c])).join(','))].join('\n'));
}

const KYC_HINTS = /uphold|kucoin|hitbtc|binance|kraken|bitstamp|coinbase|gatehub|gate\.io|bitfinex|bybit|okx|bitrue|crypto\.com|huobi|mexc|bitvavo/i;
const SCAM_HINTS = /scam|phish|hack|stolen|fraud|laund|mixer|tornado|sanction|seizure/i;

(async () => {
  console.log(`[${TECH}] Lifetime trace for ${VICTIM}`);
  console.log(`[${TECH}] Pulling full XRPL transaction history (paginated, forward-walk from genesis)…`);
  const txs = await fetchAllTxs(VICTIM);
  console.log(`[${TECH}]   → ${txs.length} payment transactions retrieved`);

  const subjectInfo = await xrpscanLabel(VICTIM);
  console.log(`[${TECH}] Subject XRPSCAN tag: ${subjectInfo?.name || '— (untagged self-custody)'}`);

  // Per-asset totals
  const assetTotals = new Map<string, { asset:string; issuer:string; inAmt:number; outAmt:number; inCount:number; outCount:number }>();
  // Counterparty aggregation (across ALL assets, with per-asset breakdown stored)
  const cpMap = new Map<string, { addr:string; inXrp:number; outXrp:number; inCount:number; outCount:number; first:string; last:string; assetBreakdown: Map<string, { in:number; out:number }>; sampleTxs: { hash:string; iso:string; amt:number; asset:string; dir:string; destTag?:number }[]; }>();
  for (const t of txs) {
    // Asset totals (count every Payment, including IOUs)
    if (t.type === 'Payment' && t.amount > 0) {
      const akey = `${t.asset}|${t.issuer || ''}`;
      const a = assetTotals.get(akey) || { asset: t.asset, issuer: t.issuer, inAmt:0, outAmt:0, inCount:0, outCount:0 };
      if (t.direction === 'in') { a.inAmt += t.amount; a.inCount++; }
      else if (t.direction === 'out') { a.outAmt += t.amount; a.outCount++; }
      assetTotals.set(akey, a);
    }
    if (!t.counterparty) continue;
    const e = cpMap.get(t.counterparty) || { addr: t.counterparty, inXrp:0, outXrp:0, inCount:0, outCount:0, first: t.iso, last: t.iso, assetBreakdown: new Map(), sampleTxs: [] };
    if (t.type === 'Payment' && t.asset === 'XRP') {
      if (t.direction === 'in') { e.inXrp += t.amount; e.inCount++; }
      else if (t.direction === 'out') { e.outXrp += t.amount; e.outCount++; }
    } else if (t.type === 'Payment' && t.amount > 0) {
      const akey = `${t.asset}|${t.issuer || ''}`;
      const ab = e.assetBreakdown.get(akey) || { in:0, out:0 };
      if (t.direction === 'in') { ab.in += t.amount; e.inCount++; }
      else if (t.direction === 'out') { ab.out += t.amount; e.outCount++; }
      e.assetBreakdown.set(akey, ab);
    } else {
      // TrustSet / OfferCreate / etc. — count as activity but no amount
      if (t.direction === 'in') e.inCount++; else if (t.direction === 'out') e.outCount++;
    }
    if (t.iso < e.first) e.first = t.iso;
    if (t.iso > e.last)  e.last  = t.iso;
    if (e.sampleTxs.length < 3) e.sampleTxs.push({ hash: t.hash, iso: t.iso, amt: t.amount, asset: t.asset || t.type, dir: t.direction, destTag: t.destTag });
    cpMap.set(t.counterparty, e);
  }
  const counterparties = Array.from(cpMap.values())
    .map(c => ({ ...c, assetBreakdownJson: JSON.stringify(Array.from(c.assetBreakdown.entries()).map(([k,v]) => ({ key:k, ...v }))) }))
    .sort((a,b) => (b.inXrp+b.outXrp+b.inCount+b.outCount) - (a.inXrp+a.outXrp+a.inCount+a.outCount));

  console.log(`[${TECH}] Distinct assets touched: ${assetTotals.size}`);
  for (const [k, a] of assetTotals) {
    console.log(`  • ${a.asset}${a.issuer ? ' (issuer ' + a.issuer.slice(0,10) + '…)' : ''}  IN ${a.inAmt.toFixed(4)} (${a.inCount} tx)  OUT ${a.outAmt.toFixed(4)} (${a.outCount} tx)`);
  }

  // Label every counterparty via XRPSCAN (top 30 only — polite to public API)
  console.log(`[${TECH}] Labelling top ${Math.min(30, counterparties.length)} counterparties via XRPSCAN…`);
  const labelled: Array<typeof counterparties[number] & { label: string; category: string; isKyc: boolean; isScam: boolean }> = [];
  for (let i = 0; i < counterparties.length; i++) {
    const cp = counterparties[i];
    let label = ''; let category = '';
    if (i < 30) {
      const info = await xrpscanLabel(cp.addr);
      label = info?.name || '';
      category = info?.account_category || '';
      await sleep(200);
    }
    labelled.push({ ...cp, label, category, isKyc: KYC_HINTS.test(label), isScam: SCAM_HINTS.test(label+' '+category) });
  }

  const totalIn  = labelled.reduce((s,c) => s + c.inXrp, 0);
  const totalOut = labelled.reduce((s,c) => s + c.outXrp, 0);
  const firstTx  = txs.length ? txs[0] : null;
  const lastTx   = txs.length ? txs[txs.length-1] : null;

  // Period buckets
  const periods = ['2022','2023','2024','2025','2026'];
  const byPeriod: Record<string, { in:number; out:number; count:number }> = {};
  for (const p of periods) byPeriod[p] = { in:0, out:0, count:0 };
  for (const t of txs) {
    const y = t.iso.slice(0,4);
    if (!byPeriod[y]) byPeriod[y] = { in:0, out:0, count:0 };
    byPeriod[y].count++;
    if (t.direction === 'in') byPeriod[y].in += t.amountXrp; else byPeriod[y].out += t.amountXrp;
  }

  // Suspect classification
  const kycExchanges = labelled.filter(c => c.isKyc);
  const flaggedScams = labelled.filter(c => c.isScam);
  // suspect-scammer = unlabelled counterparty receiving significant XRP from victim, with no label
  const suspectScammers = labelled.filter(c => !c.label && c.outXrp >= 5 && c.inCount === 0)
    .sort((a,b) => b.outXrp - a.outXrp);
  // suspect-funder = unlabelled counterparty that funded victim
  const suspectFunders = labelled.filter(c => !c.label && c.inXrp >= 5 && c.outCount === 0)
    .sort((a,b) => b.inXrp - a.inXrp);

  console.log(`[${TECH}] KYC exchanges: ${kycExchanges.length}  |  Flagged scam labels: ${flaggedScams.length}  |  Unlabelled suspected scammer wallets (received): ${suspectScammers.length}  |  Suspect funders: ${suspectFunders.length}`);

  // CSVs
  const csvRow = (c: any) => ({
    address: c.addr,
    label: c.label || '',
    category: c.category || '',
    inbound_xrp: (c.inXrp||0).toFixed(4),
    outbound_xrp: (c.outXrp||0).toFixed(4),
    in_tx_count: c.inCount,
    out_tx_count: c.outCount,
    first_iso: c.first,
    last_iso: c.last,
    is_kyc_exchange: c.isKyc,
    is_flagged_scam: c.isScam,
    iou_asset_breakdown: c.assetBreakdownJson || '',
  });
  writeCsv(path.join(OUT_DIR, '01_All_Counterparties.csv'), labelled.map(csvRow));
  writeCsv(path.join(OUT_DIR, '02_KYC_Exchanges.csv'), kycExchanges.map(csvRow));
  writeCsv(path.join(OUT_DIR, '03_Flagged_Scam_Labels.csv'), flaggedScams.map(csvRow));
  writeCsv(path.join(OUT_DIR, '04_Suspected_Scammer_Wallets.csv'), suspectScammers.map(csvRow));
  writeCsv(path.join(OUT_DIR, '05_Suspect_Funders.csv'), suspectFunders.map(csvRow));
  writeCsv(path.join(OUT_DIR, '06_All_Transactions.csv'), txs.map(t => ({
    iso: t.iso, tx_type: t.type, direction: t.direction, source: t.source, destination: t.destination || '', counterparty: t.counterparty,
    amount: (t.amount || 0).toFixed(8), asset: t.asset || '', issuer: t.issuer || '',
    dest_tag: t.destTag || '', source_tag: t.sourceTag || '', tx_hash: t.hash, ledger: t.ledger, result: t.result,
  })));

  // JSON evidence bundle
  fs.writeFileSync(path.join(OUT_DIR, 'trace.json'), JSON.stringify({
    _proprietaryHeader: proprietaryHeader(TECH),
    caseReference: CASE_ID,
    generatedAt: new Date().toISOString(),
    chain: 'xrpl',
    victim: VICTIM,
    subjectXrpscanTag: subjectInfo?.name || null,
    queryWindow: { requested: 'Jan 2022 → Present', actual: { firstTx: firstTx?.iso || null, lastTx: lastTx?.iso || null } },
    totals: { totalInXrp: totalIn, totalOutXrp: totalOut, totalTx: txs.length },
    assetTotals: Array.from(assetTotals.values()),
    byPeriod,
    counterparties: labelled,
    classifications: {
      kycExchanges, flaggedScams, suspectScammers, suspectFunders,
    },
  }, null, 2));

  // PDF
  const pdfPath = path.join(OUT_DIR, 'XRPL_Victim_Lifetime_Trace.pdf');
  await new Promise<void>(resolve => {
    const doc = new PDFDocument({ size: 'LETTER', margin: 56, info: { Title: 'XRPL Victim Lifetime Trace', Author: 'Alpha Unlimited Trading' } });
    const ws = fs.createWriteStream(pdfPath);
    doc.pipe(ws);
    doc.fontSize(7).fillColor('#666').text(proprietaryHeader(TECH));
    doc.moveDown(0.5).fillColor('black');
    doc.font('Helvetica-Bold').fontSize(16).fillColor('#0a2540').text('XRPL Wallet — Lifetime Victim Trace');
    doc.moveDown(0.3).fillColor('black').font('Helvetica').fontSize(10);
    doc.font('Helvetica-Bold').text('Subject Wallet: ', { continued:true }).font('Helvetica').text(VICTIM);
    doc.font('Helvetica-Bold').text('Chain: ', { continued:true }).font('Helvetica').text('XRP Ledger (XRPL)');
    doc.font('Helvetica-Bold').text('Case Reference: ', { continued:true }).font('Helvetica').text(CASE_ID);
    doc.font('Helvetica-Bold').text('XRPSCAN Entity Tag: ', { continued:true }).font('Helvetica').text(subjectInfo?.name || '— (untagged, self-custody)');
    doc.font('Helvetica-Bold').text('Query Window Requested: ', { continued:true }).font('Helvetica').text('January 2022 → Present (' + new Date().toISOString().slice(0,10) + ')');
    doc.font('Helvetica-Bold').text('Actual Activity Window: ', { continued:true }).font('Helvetica').text(`${firstTx?.iso?.slice(0,10) || 'n/a'} → ${lastTx?.iso?.slice(0,10) || 'n/a'}`);
    doc.moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Important Note on Window Coverage');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    if (!firstTx || firstTx.iso > '2022-12-31') {
      doc.text(`The wallet had no on-chain activity in 2022. The earliest payment transaction recorded on the XRP Ledger for this address is ${firstTx?.iso || 'n/a'}. The "January 2022 → Present" window therefore reduces in practice to "${firstTx?.iso?.slice(0,10) || 'n/a'} → present" — there is no earlier history to trace.`);
    } else {
      doc.text(`The wallet was active starting ${firstTx.iso}. Full lifetime coverage from genesis through ${lastTx?.iso}.`);
    }
    doc.moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Lifetime Totals');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text(`• Total payment transactions: ${txs.length}`);
    doc.text(`• Total XRP received: ${totalIn.toFixed(2)}`);
    doc.text(`• Total XRP sent: ${totalOut.toFixed(2)}`);
    doc.text(`• Unique counterparties: ${counterparties.length}`);
    doc.moveDown(0.3);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Activity by Year');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    for (const p of Object.keys(byPeriod).sort()) {
      const b = byPeriod[p];
      doc.text(`  ${p}:  ${b.count} tx   IN ${b.in.toFixed(2)} XRP   OUT ${b.out.toFixed(2)} XRP`);
    }
    doc.moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`KYC-Regulated Exchange Counterparties (${kycExchanges.length})`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    if (kycExchanges.length === 0) doc.text('  None of the labelled counterparties match a KYC-exchange entity tag.');
    for (const c of kycExchanges.slice(0, 15)) {
      doc.font('Helvetica-Bold').text(`• ${c.label}`).font('Helvetica');
      doc.fontSize(9).text(`    address: ${c.addr}`);
      doc.text(`    received from victim: ${c.outXrp.toFixed(2)} XRP   |   paid victim: ${c.inXrp.toFixed(2)} XRP`);
      doc.text(`    first: ${c.first.slice(0,10)}   last: ${c.last.slice(0,10)}`).fontSize(10);
      doc.moveDown(0.15);
    }
    doc.moveDown(0.3);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`Flagged-Label Counterparties (Scam / Mixer / Sanctioned) — ${flaggedScams.length}`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    if (flaggedScams.length === 0) doc.text('  No counterparty carries a public scam/mixer/sanctions tag in XRPSCAN.');
    else for (const c of flaggedScams) {
      doc.font('Helvetica-Bold').text(`• ${c.label} [${c.category}]`).font('Helvetica');
      doc.fontSize(9).text(`    ${c.addr}   IN ${c.inXrp.toFixed(2)} OUT ${c.outXrp.toFixed(2)} XRP`).fontSize(10);
    }
    doc.moveDown(0.3);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`Suspected Scammer Wallets — Unlabelled, Received from Victim (${suspectScammers.length})`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text('Wallets that received ≥ 5 XRP from the subject and have no XRPSCAN entity tag (i.e. not a known exchange/bridge/service). These are the strongest candidates for "suspected scammer / off-ramp burner" investigation. Sorted by amount received.');
    doc.moveDown(0.2).fontSize(9);
    if (suspectScammers.length === 0) doc.text('  None detected.');
    for (const c of suspectScammers.slice(0, 25)) {
      doc.font('Helvetica-Bold').text(`• ${c.addr}`).font('Helvetica');
      doc.text(`    received ${(c.outXrp||0).toFixed(2)} XRP across ${c.outCount} tx   |   first ${c.first.slice(0,10)}   last ${c.last.slice(0,10)}`);
      if (c.sampleTxs.length) {
        for (const s of c.sampleTxs.slice(0, 2)) {
          doc.text(`    – ${s.iso.slice(0,19)}  ${(s.amt||0).toFixed(2)} ${s.asset||''}  ${s.dir==='out'?'→':'←'}  tx ${s.hash.slice(0,16)}…${s.destTag ? `  destTag ${s.destTag}` : ''}`);
        }
      }
      doc.moveDown(0.15);
    }
    if (suspectScammers.length > 25) doc.text(`  …+ ${suspectScammers.length - 25} more in 04_Suspected_Scammer_Wallets.csv`);
    doc.moveDown(0.3).fontSize(10);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`Suspect Funders — Unlabelled, Sent to Victim (${suspectFunders.length})`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text('Unlabelled wallets that funded the victim. May be co-conspirators, additional victim accounts, or staging wallets.');
    doc.moveDown(0.2).fontSize(9);
    if (suspectFunders.length === 0) doc.text('  None detected.');
    for (const c of suspectFunders.slice(0, 15)) {
      doc.font('Helvetica-Bold').text(`• ${c.addr}`).font('Helvetica');
      doc.text(`    sent ${c.inXrp.toFixed(2)} XRP across ${c.inCount} tx   |   first ${c.first.slice(0,10)}   last ${c.last.slice(0,10)}`);
    }
    doc.moveDown(0.4).fontSize(10);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Top 25 Counterparties (All)');
    doc.moveDown(0.2).font('Helvetica').fontSize(9).fillColor('black');
    for (const c of labelled.slice(0, 25)) {
      doc.text(`  ${(c.inXrp+c.outXrp).toFixed(2).padStart(10)} XRP total   ${c.addr}   ${c.label ? '['+c.label+']' : ''}`);
    }
    doc.fontSize(10).moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Recommended Next Steps');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    const steps: string[] = [];
    if (kycExchanges.length) steps.push(`Issue preservation/freeze letters to the ${kycExchanges.length} KYC exchange(s) identified — see 02_KYC_Exchanges.csv.`);
    if (suspectScammers.length) steps.push(`Run a 1-hop forward trace on the top ${Math.min(10, suspectScammers.length)} suspected scammer wallet(s) — most will terminate at a KYC exchange, providing additional identity anchors.`);
    if (suspectFunders.length) steps.push(`Run a 1-hop backward trace on the top suspect funder(s) to identify the original on-ramp.`);
    if (flaggedScams.length) steps.push(`Cross-reference the ${flaggedScams.length} flagged-label counterparty(ies) with OFAC SDN list and Chainabuse.`);
    steps.push('Add the subject wallet and all suspected scammer wallets to ongoing surveillance via the case monitoring loop.');
    doc.list(steps);

    doc.end();
    ws.on('finish', () => resolve());
  });

  // Flow diagram (top suspects + KYC nodes)
  try {
    const flowNodes: any[] = [{ id: VICTIM, label: 'SUBJECT WALLET', kind: 'root', chain: 'xrpl' }];
    const flowEdges: any[] = [];
    const top = [...kycExchanges, ...suspectScammers.slice(0, 10), ...suspectFunders.slice(0, 5)];
    for (const c of top) {
      flowNodes.push({ id: c.addr, label: c.label || (c.outXrp > c.inXrp ? 'Suspect (recipient)' : 'Suspect (funder)'), kind: c.isKyc ? 'exchange' : 'intermediary', chain: 'xrpl' });
      if (c.outXrp > 0) flowEdges.push({ from: VICTIM, to: c.addr, amount: c.outXrp, asset: 'XRP', timestamp: c.last });
      if (c.inXrp  > 0) flowEdges.push({ from: c.addr, to: VICTIM, amount: c.inXrp,  asset: 'XRP', timestamp: c.first });
    }
    fs.writeFileSync(path.join(OUT_DIR, '_flow_input.json'), JSON.stringify({ nodes: flowNodes, edges: flowEdges }, null, 2));
    await autoEmitFlowDiagram(path.join(OUT_DIR, '_flow_input.json'), {
      title: `XRPL Victim Lifetime — ${VICTIM.slice(0,10)}…`,
      caseId: CASE_ID, chain: 'xrpl', direction: 'bidirectional', outDir: OUT_DIR,
    });
  } catch (e: any) {
    console.warn(`[${TECH}] Flow diagram warning: ${e.message}`);
  }

  // README
  fs.writeFileSync(path.join(OUT_DIR, '00_README.txt'),
`${proprietaryHeader(TECH)}

ALPHA UNLIMITED TRADING — XRPL VICTIM LIFETIME TRACE
====================================================
Case Reference : ${CASE_ID}
Subject Wallet : ${VICTIM}  (XRP Ledger)
Generated      : ${new Date().toISOString()}
Window         : Jan 2022 → ${new Date().toISOString().slice(0,10)} (full lifetime)
Actual Activity: ${firstTx?.iso || 'n/a'} → ${lastTx?.iso || 'n/a'}

CONTENTS
--------
  00_README.txt                          — this file
  XRPL_Victim_Lifetime_Trace.pdf         — full PDF audit
  01_All_Counterparties.csv              — every counterparty (all-time)
  02_KYC_Exchanges.csv                   — KYC-regulated exchange counterparties
  03_Flagged_Scam_Labels.csv             — counterparties tagged scam/mixer/sanctioned
  04_Suspected_Scammer_Wallets.csv       — UNLABELLED wallets that received from victim (PRIORITY)
  05_Suspect_Funders.csv                 — UNLABELLED wallets that funded victim
  06_All_Transactions.csv                — full payment-transaction log
  trace.json                             — machine-readable evidence bundle
  XRPL-Victim-Lifetime-*.svg + .html     — visual flow diagram (auto-emitted)

EVIDENCE BASIS
--------------
All on-chain facts sourced live from the XRP Ledger via xrplcluster.com
JSON-RPC nodes (account_tx forward-walk, paginated). Counterparty entity tags
sourced from XRPSCAN's public entity database. Independently reproducible.
`);

  // Zip
  await new Promise<void>((resolve, reject) => {
    const out = fs.createWriteStream(ZIP_PATH);
    const archive = archiver('zip', { zlib: { level: 9 } });
    out.on('close', () => resolve());
    archive.on('error', reject);
    archive.pipe(out);
    archive.directory(OUT_DIR, false);
    archive.finalize();
  });

  console.log(`[${TECH}] ✅ Package built: ${ZIP_PATH}`);
})().catch(e => { console.error(`[${TECH}] FATAL:`, e); process.exit(1); });
