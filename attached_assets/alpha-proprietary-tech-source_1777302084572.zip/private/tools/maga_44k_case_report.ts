/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 U.S. Code · DMCA · CFAA · DTSA
 * Unauthorized reproduction, reverse engineering, or commercial use prohibited.
 * Protected by international copyright and trade secret laws.
 *
 * Alpha Solana Sell-Trace Case Output — RAVEDAO Casefile: MAGA $44k Sell
 * (Case-output document; consumes Alpha proprietary engines where applicable.)
 */

import * as fs from 'fs';
import * as path from 'path';
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
import { amountCorrelationScanner } from '../../server/services/amountCorrelationScanner.js';

enforceProprietaryLicense('Alpha Solana Sell-Trace Case Output — MAGA $44k Sell');

const TECH_NAME = 'Alpha Solana Sell-Trace Case Output — MAGA $44k Sell';
const CASE_ID = 'MAGA-RAVEDAO-2026-04-22';

// ─── CASE INPUTS ─────────────────────────────────────────────────────────
const TOKEN_MINT = 'Hon2rHAiqkcDtUzL5gA2vjXPr7T1MPCK2UT2AHKCpump';
const TOKEN_NAME = 'Make Aliens Great Again (MAGA)';
const TOKEN_CREATOR = 'EpEPwSwfR34Puadp7H2vTCWkFbpmMFfgbEsPwHrZuawk';
const PUMPSWAP_PAIR = 'HVimk99ygSSDnWz9eSqumdThrFz4DADE7j6phmFms6at';
const SELLER = 'GQ3NnM7tqZURAJNnncuXB3ttPkoFfejs24sYpUDm8sYC';
const SELLER_TOKEN_ACCT = 'H2okYRRDTbCnFB9h3NhBQBZHRbS5dEzVAJ53CmYrVvvF';
const SELL_TX = '5aARrxGc2BzZ7u55PCwbaPer1eRVW7jfPDix6Y6NoCmv8wfVtsnwJq4rCVqQYqLXt4VyUsBD2TyycxcTacok3K3E';
const SELL_TIME_ISO = '2026-04-22T01:47:44Z';
const SELL_MAGA = 2_606_901.71234;
const SELL_SOL_OUT = 514.754565712;
const SELL_USD = 44_398;
const PRICE_USD = 0.01870;

const DEV_CLUSTER: Array<{ owner: string; tag: string; amt: number }> = [
  { owner: 'EpEPwSwfR34Puadp7H2vTCWkFbpmMFfgbEsPwHrZuawk', tag: 'TOKEN CREATOR', amt: 0 },
  { owner: '7krzWQqfJ4b8tbKJMmBFyUkM7oW5C5Hy5eM2fqCUsJqk', tag: 'Holder #1',           amt: 22_124_700 },
  { owner: 'Bu4mcHDKKL5eaks8CWDr1boFQN5RCkS9E5jQiKrvypeY', tag: 'Holder #2 round-20M', amt: 20_000_000 },
  { owner: '9jxPzF1PLgLDPabXVVCLohf3NrXrgrNuYh8rCwLVqXiB', tag: 'Holder #3 round-20M', amt: 20_000_000 },
  { owner: 'NCvLfg6ErPPXVqPt7g9GC1snvm5BgEJnK6JVgDEh1S2',  tag: 'Holder #4 round-20M', amt: 20_000_000 },
  { owner: 'GmBvDo82unnqSV7Te9TLryHAkrU3odMfsAA65KZnMw3h', tag: 'Holder #5 round-20M', amt: 20_000_000 },
  { owner: 'DQJEMN1pyHoqTyweNvFh3kh4XYeLy6gcAS63ktq6tGYV', tag: 'Holder #6 round-20M', amt: 20_000_000 },
  { owner: 'C1qmmu7ATmx6VLkjyAqyAiAnSciv3FHFD4dV6Hx1XDvL', tag: 'Holder #7 (19.7M)',   amt: 19_700_000 },
];

const POST_SELL_HOPS = [
  { ts: '2026-04-22T01:59:23Z', dest: '8h6SVSCdsqim53QYcN85bdFCbhYiBnhFknwerejbZ7ZZ', sol: 0.012,  note: 'Probe transfer' },
  { ts: '2026-04-22T02:01:27Z', dest: '8h6SVSCdsqim53QYcN85bdFCbhYiBnhFknwerejbZ7ZZ', sol: 8.700,  note: 'Likely owner-controlled or CEX deposit (same dest as probe)' },
  { ts: '2026-04-22T02:04:33Z', dest: '4kWFa6VSFThBFvfnf5Dh3xpABWMhusmX5NVuK7X2k5TT', sol: 20.000, note: 'Independent destination' },
];

const SELLER_INFLOWS = [
  { ts: '2026-04-17T19:27:59Z', maga:    73_040.606, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T19:28:59Z', maga:   353_116.190, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T19:29:16Z', maga:   467_022.316, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T19:31:20Z', maga:   243_381.045, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T22:59:49Z', maga:   326_247.732, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T22:59:58Z', maga:   232_004.794, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:00:11Z', maga:   284_180.905, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:00:44Z', maga:   278_988.982, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:01:06Z', maga:   271_880.095, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:05:28Z', maga: 1_949_762.544, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:05:55Z', maga:   378_837.716, src: PUMPSWAP_PAIR },
  { ts: '2026-04-17T23:06:07Z', maga:   401_870.892, src: PUMPSWAP_PAIR },
  { ts: '2026-04-20T02:15:41Z', maga:    57_171.040, src: PUMPSWAP_PAIR },
  { ts: '2026-04-20T02:16:16Z', maga:    73_046.112, src: PUMPSWAP_PAIR },
  { ts: '2026-04-20T02:16:54Z', maga:   105_655.091, src: PUMPSWAP_PAIR },
];

// ─── ALPHA AMOUNT CORRELATION SCANNER™ — cross-chain cashout fingerprint ───
async function runAmountCorrelation() {
  const SOL_PRICE_USD = SELL_USD / SELL_SOL_OUT; // ≈ 86.25
  // If proceeds bridge out to EVM, what's the expected receive range?
  const usdcRange = await amountCorrelationScanner.calculateExpectedOutput(SELL_SOL_OUT * SOL_PRICE_USD, 'USDC', 'USDC');
  const ethRange  = await amountCorrelationScanner.calculateExpectedOutput(SELL_SOL_OUT * SOL_PRICE_USD, 'USDC', 'ETH');
  const xmrRange  = await amountCorrelationScanner.calculateExpectedOutput(SELL_SOL_OUT * SOL_PRICE_USD, 'USDC', 'XMR');

  // Register both immediate Solana hop destinations as monitored under this case
  // (mainly to put them in the surveillance queue; EVM scanner won't index Solana
  // addresses but the case-id is captured for cross-engine reporting.)
  amountCorrelationScanner.addMonitoredWallet(POST_SELL_HOPS[1].dest, 'MAGA-44k Hop A (8.71 SOL)', CASE_ID);
  amountCorrelationScanner.addMonitoredWallet(POST_SELL_HOPS[2].dest, 'MAGA-44k Hop B (20.00 SOL)', CASE_ID);
  amountCorrelationScanner.addMonitoredWallet(SELLER, 'MAGA-44k Seller Wallet', CASE_ID);

  return { usdcRange, ethRange, xmrRange, solPriceUsd: SOL_PRICE_USD };
}

// ─── REPORT GENERATION ───────────────────────────────────────────────────
function buildText(corr: Awaited<ReturnType<typeof runAmountCorrelation>>): string {
  const HDR = proprietaryHeader(TECH_NAME);
  const lines: string[] = [];
  const sep  = '═'.repeat(78);
  const sep2 = '─'.repeat(78);

  lines.push(sep);
  lines.push('  ALPHA UNLIMITED FORENSICS — SOLANA SELL-TRACE CASE OUTPUT');
  lines.push(`  Case: ${CASE_ID}`);
  lines.push(`  Subject: $44k MAGA token sell on PumpSwap`);
  lines.push(sep);
  lines.push('');
  lines.push(`Header: ${HDR}`);
  lines.push('');
  lines.push('  COPYRIGHT / LEGAL NOTICE');
  lines.push('  ────────────────────────');
  lines.push('  © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.');
  lines.push('  This document is PROPRIETARY AND CONFIDENTIAL.');
  lines.push('  Protected by Title 17 U.S. Code (Copyright), 17 U.S.C. § 1201 (DMCA),');
  lines.push('  18 U.S.C. § 1030 (CFAA), 18 U.S.C. § 1836 (DTSA), and applicable');
  lines.push('  international copyright treaties.');
  lines.push('  Unauthorized reproduction or distribution is strictly prohibited.');
  lines.push('  Owner contact: alphaunlimitedtoken@gmail.com');
  lines.push('');
  lines.push(sep);
  lines.push('  EXECUTIVE SUMMARY');
  lines.push(sep);
  lines.push('');
  lines.push(`Token:           ${TOKEN_NAME}`);
  lines.push(`Mint:            ${TOKEN_MINT}`);
  lines.push(`Chain:           Solana mainnet-beta`);
  lines.push(`Token creator:   ${TOKEN_CREATOR}`);
  lines.push(`Top liquidity:   PumpSwap pair ${PUMPSWAP_PAIR}`);
  lines.push(`Spot price:      $${PRICE_USD.toFixed(5)} USD`);
  lines.push('');
  lines.push(`Subject sell:    ${SELL_USD.toLocaleString()} USD`);
  lines.push(`                 ${SELL_MAGA.toLocaleString()} MAGA → ${SELL_SOL_OUT.toFixed(4)} SOL`);
  lines.push(`Time (UTC):      ${SELL_TIME_ISO}`);
  lines.push(`Seller wallet:   ${SELLER}`);
  lines.push(`Seller MAGA-ATA: ${SELLER_TOKEN_ACCT}`);
  lines.push(`Sell tx hash:    ${SELL_TX}`);
  lines.push('');
  lines.push('FINDING (DEV LINKAGE):  NO direct on-chain connection between the seller');
  lines.push('and the token creator or any of the 7 round-number "dev cluster" wallets.');
  lines.push('All 5,501,789 MAGA that ever entered the seller\'s account came from open-');
  lines.push('market BUYS on the PumpSwap AMM between 2026-04-17 and 2026-04-20.');
  lines.push('This wallet behaves as a SWING TRADER / SNIPER, not as a developer alt.');
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 1 — SUBJECT SELLER WALLET PROFILE');
  lines.push(sep);
  lines.push('');
  lines.push(`Address:                ${SELLER}`);
  lines.push(`Account owner program:  System Program (regular wallet, non-PDA, non-program)`);
  lines.push(`Current SOL balance:    934.7919 SOL`);
  lines.push(`Wallet first activity:  2026-02-14 15:35:54 UTC`);
  lines.push(`Token creation date:    2026-02-20 03:35:04 UTC`);
  lines.push(`Wallet age vs token:    Wallet predates token by 6 days, 12 hours`);
  lines.push(`Total signatures:       ≥5,000 (cap reached on enumeration)`);
  lines.push(`MAGA-specific txs:      28`);
  lines.push(`First MAGA contact:     2026-04-17 19:27:59 UTC (open-market buy)`);
  lines.push(`Last MAGA contact:      2026-04-22 01:47:44 UTC (this $44k sell)`);
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 2 — FORWARD TRACE (PROCEEDS DISTRIBUTION)');
  lines.push(sep);
  lines.push('');
  lines.push('Of the 514.75 SOL received, 28.71 SOL was moved within ~17 minutes of');
  lines.push('the sale; ~486 SOL remains in the seller wallet at report time.');
  lines.push('');
  lines.push('Hops:');
  for (const h of POST_SELL_HOPS) {
    lines.push(`  ${h.ts}   ${h.sol.toFixed(4).padStart(8)} SOL  →  ${h.dest}`);
    lines.push(`      ${h.note}`);
  }
  lines.push('');
  lines.push(`Aggregated outflow:        28.7121 SOL  (≈ $${Math.round(28.7121 * corr.solPriceUsd).toLocaleString()})`);
  lines.push(`Retained in seller wallet: ~486 SOL    (≈ $${Math.round(486 * corr.solPriceUsd).toLocaleString()})`);
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 3 — BACKWARD TRACE (PROVENANCE OF MAGA TOKENS)');
  lines.push(sep);
  lines.push('');
  lines.push('All MAGA inflows to the seller account, oldest → newest:');
  lines.push('');
  lines.push('  Timestamp                       MAGA acquired    Source');
  lines.push(sep2);
  for (const e of SELLER_INFLOWS) {
    lines.push(`  ${e.ts}   ${('+' + e.maga.toLocaleString()).padStart(15)}    ${e.src}  (PumpSwap pool — open-market BUY)`);
  }
  const total = SELLER_INFLOWS.reduce((s, e) => s + e.maga, 0);
  lines.push(sep2);
  lines.push(`  TOTAL inflows shown:              +${total.toLocaleString()} MAGA  (all PumpSwap buys)`);
  lines.push('');
  lines.push(`Direct token transfers from creator (${TOKEN_CREATOR}):  0`);
  lines.push(`Direct token transfers from any "dev cluster" wallet:                     0`);
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 4 — DEV-CLUSTER REFERENCE (NOT IMPLICATED IN THIS SELL)');
  lines.push(sep);
  lines.push('');
  lines.push('The following round-number holders look like a coordinated insider/sniper');
  lines.push('cluster from launch and are recorded here as a separate intelligence item');
  lines.push('— NONE of them transacted with the subject seller.');
  lines.push('');
  lines.push('  Holder                                          Balance MAGA      Tag');
  lines.push(sep2);
  for (const d of DEV_CLUSTER) {
    lines.push(`  ${d.owner}   ${(d.amt ? d.amt.toLocaleString() : '— (creator EOA)').padStart(14)}    ${d.tag}`);
  }
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 5 — ALPHA AMOUNT CORRELATION SCANNER™ — CASHOUT FINGERPRINT');
  lines.push(sep);
  lines.push('');
  lines.push('Engine: Alpha Amount Correlation Scanner™  (server/services/amountCorrelationScanner.ts)');
  lines.push('Mode:   Pre-registered cashout watch — case-id ' + CASE_ID);
  lines.push('');
  lines.push(`Source amount:    ${SELL_SOL_OUT.toFixed(4)} SOL  (≈ $${SELL_USD.toLocaleString()} USD at $${corr.solPriceUsd.toFixed(2)}/SOL)`);
  lines.push('');
  lines.push('If proceeds bridge to EVM and are received as USDC, expected receive range:');
  lines.push(`  USDC:  ${corr.usdcRange.min.toFixed(2)} — ${corr.usdcRange.max.toFixed(2)}   (mid ${corr.usdcRange.midpoint.toFixed(2)})`);
  lines.push('');
  lines.push('If swapped to ETH on the destination chain:');
  lines.push(`  ETH:   ${corr.ethRange.min.toFixed(6)} — ${corr.ethRange.max.toFixed(6)}   (mid ${corr.ethRange.midpoint.toFixed(6)})`);
  lines.push('');
  lines.push('If on-ramped to Monero (privacy laundering):');
  lines.push(`  XMR:   ${corr.xmrRange.min.toFixed(6)} — ${corr.xmrRange.max.toFixed(6)}   (mid ${corr.xmrRange.midpoint.toFixed(6)})`);
  lines.push('');
  lines.push('Wallets registered for ongoing surveillance under this case:');
  lines.push(`  ${SELLER}   (seller)`);
  lines.push(`  ${POST_SELL_HOPS[1].dest}   (Hop A — 8.71 SOL)`);
  lines.push(`  ${POST_SELL_HOPS[2].dest}   (Hop B — 20.00 SOL)`);
  lines.push('');
  lines.push(sep);
  lines.push('  SECTION 6 — METHODOLOGY & TECHNOLOGY STACK USED');
  lines.push(sep);
  lines.push('');
  lines.push('Engines invoked:');
  lines.push('  ✅  Alpha Proprietary Software Guard™      (license enforcement, this script)');
  lines.push('  ✅  Alpha Amount Correlation Scanner™       (cashout-range fingerprint above)');
  lines.push('');
  lines.push('Engines NOT invoked (out of scope — Solana not supported):');
  lines.push('  ⚠️  Alpha Multi-Chain Wallet Tracer™         (EVM-only: ETH/POLY/ARB/OP/BASE)');
  lines.push('  ⚠️  Alpha Auto-Pivot Surveillance Engine™    (EVM-only)');
  lines.push('  ⚠️  Autonomous Blockchain Spider™            (EVM-only)');
  lines.push('  ⚠️  Cross-Chain Bridge Tracer™               (EVM-only)');
  lines.push('  ⚠️  Alpha Smart-Money Flow Signal™           (EVM-only)');
  lines.push('  ⚠️  Alpha Bridge Capital-Rotation Signal™    (EVM L1↔L2)');
  lines.push('  ⚠️  Monero Cross-Chain Correlation Engine™   (EVM↔XMR)');
  lines.push('');
  lines.push('Solana-side data acquisition (acquired through licensed pipeline):');
  lines.push('  • Alchemy Solana mainnet-beta RPC           (premium tier; ALCHEMY_API_KEY)');
  lines.push('  • GeckoTerminal public pool-trades API      (free tier, attribution: GeckoTerminal)');
  lines.push('  • DexScreener public token API              (free tier, attribution: DexScreener)');
  lines.push('  • pump.fun public coin-info endpoint        (free tier)');
  lines.push('');
  lines.push('PRODUCT-GAP NOTE: A future "Alpha Solana On-Chain Trace Engine™" should be');
  lines.push('added to the proprietary stack to give Solana parity with the existing EVM');
  lines.push('engines. Until that ships, Solana traces are produced via this case-output');
  lines.push('script which still passes through the proprietary licensing/header system.');
  lines.push('');
  lines.push(sep);
  lines.push('  END OF REPORT');
  lines.push(sep);
  return lines.join('\n');
}

function buildHtml(text: string): string {
  const HDR = proprietaryHeader(TECH_NAME);
  const escHtml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escHtml(TECH_NAME)} — ${CASE_ID}</title>
<meta name="generator" content="Alpha Unlimited Forensics" />
<meta name="proprietary-header" content="${escHtml(HDR)}" />
<style>
  :root { --gold:#d4af37; --bg:#0e0e10; --panel:#161618; --muted:#8a8a8a; --text:#e7e7e7; --warn:#f0a500; --ok:#3fbf7f; --bad:#e34d4d; }
  body  { font-family: 'Roboto Mono', ui-monospace, Menlo, monospace; background:var(--bg); color:var(--text); margin:0; padding:32px; line-height:1.55; }
  h1,h2 { color:var(--gold); border-bottom:1px solid #333; padding-bottom:8px; }
  h1    { font-size:22px; }
  h2    { font-size:16px; margin-top:32px; }
  pre   { background:var(--panel); border:1px solid #2a2a2a; border-radius:8px; padding:16px; overflow-x:auto; white-space:pre; font-size:12px; }
  .hdr  { background:linear-gradient(180deg,#1a1a1d,#0e0e10); border:1px solid var(--gold); border-radius:10px; padding:14px 18px; margin-bottom:24px; font-size:11px; color:var(--muted); }
  .hdr b{ color:var(--gold); }
  .stamp{ display:inline-block; padding:4px 10px; border-radius:4px; background:#2a1d00; color:var(--gold); border:1px solid var(--gold); font-size:11px; letter-spacing:1px; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin:14px 0; }
  .card { background:var(--panel); border:1px solid #2a2a2a; border-radius:8px; padding:14px; font-size:12px; }
  .card b { color:var(--gold); display:block; font-size:11px; margin-bottom:4px; letter-spacing:.5px; }
  .ok   { color:var(--ok); } .warn{ color:var(--warn); } .bad{ color:var(--bad); }
  table { width:100%; border-collapse:collapse; font-size:12px; margin-top:8px; }
  th,td { text-align:left; padding:6px 10px; border-bottom:1px solid #2a2a2a; }
  th    { color:var(--gold); font-weight:normal; text-transform:uppercase; font-size:10px; letter-spacing:1px; }
  code  { color:#9ad; }
  .footer { margin-top:32px; padding-top:16px; border-top:1px solid #2a2a2a; font-size:10px; color:var(--muted); text-align:center; }
</style>
</head>
<body>

<div class="hdr">
  <div><span class="stamp">PROPRIETARY · CONFIDENTIAL · CASE OUTPUT</span></div>
  <div style="margin-top:8px;"><b>Header:</b> ${escHtml(HDR)}</div>
</div>

<h1>Alpha Unlimited Forensics — Solana Sell-Trace Case Output</h1>

<div class="grid">
  <div class="card"><b>CASE ID</b>${CASE_ID}</div>
  <div class="card"><b>SUBJECT</b>$${SELL_USD.toLocaleString()} MAGA sell on PumpSwap</div>
  <div class="card"><b>TOKEN</b>${TOKEN_NAME}<br/><code>${TOKEN_MINT}</code></div>
  <div class="card"><b>SELLER WALLET</b><code>${SELLER}</code></div>
  <div class="card"><b>SELL TIME (UTC)</b>${SELL_TIME_ISO}</div>
  <div class="card"><b>SELL TX</b><code style="word-break:break-all">${SELL_TX}</code></div>
  <div class="card"><b>AMOUNT MAGA</b>${SELL_MAGA.toLocaleString()}</div>
  <div class="card"><b>SOL RECEIVED</b>${SELL_SOL_OUT.toFixed(4)} SOL  ≈ $${SELL_USD.toLocaleString()}</div>
</div>

<h2>Verdict — Dev Linkage</h2>
<div class="card">
  <span class="ok">✅ NO direct on-chain connection between the seller and the token creator or any "dev cluster" wallet.</span><br/>
  Every MAGA token that ever entered the seller's account came from open-market BUYS on the PumpSwap AMM between Apr 17–20.
  Behavior profile: <b>swing trader / sniper</b>, not a developer alt.
</div>

<h2>Full Report</h2>
<pre>${escHtml(text)}</pre>

<div class="footer">
  ${escHtml(HDR)}
</div>
</body>
</html>`;
}

async function main() {
  console.log(`[${TECH_NAME}] starting...`);
  const corr = await runAmountCorrelation();
  const txt  = buildText(corr);
  const html = buildHtml(txt);

  const reportDir = path.resolve('private/forensic-reports');
  const downloadDir = path.resolve('attached_assets/forensic_reports');
  fs.mkdirSync(reportDir, { recursive: true });
  fs.mkdirSync(downloadDir, { recursive: true });

  const baseName = 'MAGA_RAVEDAO_44k_Sell_Trace';
  const txtPath  = path.join(reportDir, baseName + '.txt');
  const htmlPath = path.join(reportDir, baseName + '.html');
  const txtDl    = path.join(downloadDir, baseName + '.txt');
  const htmlDl   = path.join(downloadDir, baseName + '.html');

  fs.writeFileSync(txtPath,  txt);
  fs.writeFileSync(htmlPath, html);
  fs.writeFileSync(txtDl,    txt);
  fs.writeFileSync(htmlDl,   html);

  // Sidecar JSON + auto-emit flow diagram
  try {
    const sidecarPath = path.join(reportDir, baseName + '.json');
    const SOL_USD = SELL_USD / SELL_SOL_OUT;
    const sellTs = Math.floor(new Date(SELL_TIME_ISO).getTime() / 1000);
    const sidecar = {
      proprietaryHeader: proprietaryHeader(TECH_NAME),
      caseId: CASE_ID,
      seller: SELLER,
      tokenMint: TOKEN_MINT,
      tokenName: TOKEN_NAME,
      pumpswapPair: PUMPSWAP_PAIR,
      nodes: [
        { address: SELLER, label: 'Seller', kind: 'root' },
        { address: PUMPSWAP_PAIR, label: 'PumpSwap Pair', kind: 'pool' },
        { address: TOKEN_CREATOR, label: 'Token Creator', kind: 'creator' },
        ...DEV_CLUSTER.map(d => ({ address: d.owner, label: d.tag })),
        ...POST_SELL_HOPS.map(h => ({ address: h.dest, label: h.note })),
      ],
      edges: [
        { from: SELLER, to: PUMPSWAP_PAIR, delta: SELL_MAGA, asset: 'MAGA', ts: sellTs, hash: SELL_TX, dir: 'out' },
        { from: PUMPSWAP_PAIR, to: SELLER, delta: SELL_SOL_OUT, asset: 'SOL', ts: sellTs, hash: SELL_TX, dir: 'in' },
        ...POST_SELL_HOPS.map(h => ({
          from: SELLER, to: h.dest, delta: h.sol, asset: 'SOL',
          ts: Math.floor(new Date(h.ts).getTime() / 1000),
          dir: 'out' as const,
        })),
      ],
    };
    fs.writeFileSync(sidecarPath, JSON.stringify(sidecar, null, 2));
    const { autoEmitFlowDiagram } = await import('../forensics/autoEmitFlowDiagram.js');
    await autoEmitFlowDiagram(sidecarPath, { title: `MAGA $44k Sell — Forensic Flow`, caseId: CASE_ID, chain: 'solana', direction: 'forward', roots: [SELLER] });
  } catch (e: any) {
    console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`);
  }

  console.log(`[${TECH_NAME}] wrote:`);
  console.log(`  ${txtPath}   (${fs.statSync(txtPath).size} bytes)`);
  console.log(`  ${htmlPath}  (${fs.statSync(htmlPath).size} bytes)`);
  console.log(`  ${txtDl}     (download copy)`);
  console.log(`  ${htmlDl}    (download copy)`);
  console.log(`[${TECH_NAME}] done.`);
}

await main();
