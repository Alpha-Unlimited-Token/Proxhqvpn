/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Alpha Forensic Flow Visualizer™ — CLI runner.
 *
 * Usage:
 *   npx tsx private/tools/generateFlowDiagram.ts <traceJsonPath> [options]
 * Options:
 *   --title="..."         Diagram title (default: derived from filename)
 *   --case=<id>           Case ID
 *   --chain=<eth|sol|...> Ecosystem label
 *   --direction=<forward|backward|bidirectional>  (default: forward)
 *   --roots=addr1,addr2   Comma-separated root addresses (overrides auto-detect)
 *   --out=<basename>      Output basename (default: same dir as input)
 *
 * Accepts:
 *   - {nodes:[{address,label?,sightings?}], edges:[{from,to,delta,asset,ts,dir,rootLabel?}]}
 *   - {wallets:[{address,label?}], transfers:[{from,to,value,asset,ts}]}
 *   - {edges:[...]}  (roots auto-detected as nodes with no inbound edges)
 */
import * as fs from 'fs';
import * as path from 'path';
import { enforceProprietaryLicense } from '../security/alpha_proprietary_guard.js';
import {
  renderFlowDiagram,
  renderFlowDiagramHtml,
  type FlowDiagramInput,
  type FlowEdge,
  type FlowNodeMeta,
} from '../forensics/flowDiagramVisualizer.js';

enforceProprietaryLicense('Alpha Forensic Flow Visualizer™ (CLI)');

function parseArgs(argv: string[]): { input: string; opts: Record<string, string> } {
  const opts: Record<string, string> = {};
  let input = '';
  for (const a of argv) {
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      if (eq > 0) opts[a.slice(2, eq)] = a.slice(eq + 1);
      else opts[a.slice(2)] = 'true';
    } else if (!input) {
      input = a;
    }
  }
  return { input, opts };
}

function normalize(raw: any): { nodes: FlowNodeMeta[]; edges: FlowEdge[] } {
  const nodes: FlowNodeMeta[] = [];
  const edges: FlowEdge[] = [];
  if (Array.isArray(raw.nodes)) {
    for (const n of raw.nodes) {
      const addr = n.address || n.wallet || n.id;
      if (!addr) continue;
      nodes.push({ address: addr, label: n.label, kind: n.kind });
    }
  }
  if (Array.isArray(raw.wallets)) {
    for (const w of raw.wallets) {
      const addr = w.address || w.wallet;
      if (!addr) continue;
      nodes.push({ address: addr, label: w.label, kind: w.kind });
    }
  }
  const rawEdges = raw.edges || raw.transfers || raw.transactions || [];
  for (const e of rawEdges) {
    const from = e.from || e.source || e.sender;
    const to = e.to || e.target || e.recipient;
    if (!from || !to) continue;
    const delta = e.delta !== undefined ? e.delta : (e.value !== undefined ? e.value : e.amount);
    const ts = e.ts !== undefined ? e.ts : (e.timestamp !== undefined ? e.timestamp : e.time);
    edges.push({
      from, to,
      delta: typeof delta === 'number' ? delta : (delta != null ? Number(delta) : undefined),
      asset: e.asset || e.token || e.symbol,
      ts: typeof ts === 'number' ? ts : (ts != null ? Math.floor(new Date(ts).getTime() / 1000) : undefined),
      hash: e.hash || e.txHash || e.signature,
      dir: e.dir || e.direction,
      rootLabel: e.rootLabel,
    });
  }
  return { nodes, edges };
}

function autoDetectRoots(nodes: FlowNodeMeta[], edges: FlowEdge[], explicitRoots?: string[]): string[] {
  if (explicitRoots && explicitRoots.length) return explicitRoots;
  const declared = nodes.filter(n => n.kind === 'root').map(n => n.address);
  if (declared.length) return declared;
  const incoming = new Set(edges.map(e => e.to));
  const outgoing = new Set(edges.map(e => e.from));
  const roots = Array.from(outgoing).filter(a => !incoming.has(a));
  if (roots.length) return roots;
  return Array.from(outgoing).slice(0, 1);
}

async function main() {
  const { input, opts } = parseArgs(process.argv.slice(2));
  if (!input) {
    console.error('Usage: npx tsx private/tools/generateFlowDiagram.ts <traceJsonPath> [--title=... --case=... --chain=... --direction=... --roots=... --out=...]');
    process.exit(1);
  }
  const abs = path.resolve(process.cwd(), input);
  if (!fs.existsSync(abs)) { console.error(`File not found: ${abs}`); process.exit(1); }
  const raw = JSON.parse(fs.readFileSync(abs, 'utf-8'));

  const { nodes, edges } = normalize(raw);
  if (!edges.length) { console.error('No edges/transfers/transactions found in input.'); process.exit(1); }

  const explicitRoots = opts.roots ? opts.roots.split(',').map(s => s.trim()).filter(Boolean) : undefined;
  const roots = autoDetectRoots(nodes, edges, explicitRoots);
  const title = opts.title || `Forensic Flow — ${path.basename(input, path.extname(input))}`;
  const direction = (opts.direction || 'forward') as FlowDiagramInput['direction'];

  const labelMap: Record<string, string> = {};
  for (const n of nodes) if (n.label) labelMap[n.address] = n.label;

  const inputDoc: FlowDiagramInput = {
    title,
    caseId: opts.case,
    ecosystem: opts.chain,
    direction,
    rootAddresses: roots,
    nodes,
    edges,
    addressLabels: labelMap,
    generatedAt: new Date().toISOString(),
  };

  const outBase = opts.out
    ? path.resolve(process.cwd(), opts.out)
    : path.resolve(path.dirname(abs), path.basename(input, path.extname(input)) + '_FlowDiagram');

  const svg = renderFlowDiagram(inputDoc);
  const html = renderFlowDiagramHtml(inputDoc);
  fs.writeFileSync(outBase + '.svg', svg);
  fs.writeFileSync(outBase + '.html', html);

  console.log(`✅ Alpha Forensic Flow Visualizer™ — diagram generated`);
  console.log(`   Nodes: ${new Set([...edges.map(e => e.from), ...edges.map(e => e.to)]).size}  Edges: ${edges.length}  Roots: ${roots.length}`);
  console.log(`   SVG : ${outBase}.svg`);
  console.log(`   HTML: ${outBase}.html`);
}

main().catch(e => { console.error(e); process.exit(1); });
