/*
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide.
 * Alpha New-Suspect Discovery Engine™ — Patent Pending. Trade Secret Protected.
 * Protected by 17 U.S.C. (Copyright), DMCA, CFAA, DTSA, and international treaty.
 * Unauthorized copying, modification, distribution, or reverse engineering prohibited.
 * AUTHORIZED USE ONLY — Alpha Unlimited Trading internal forensic operations.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha New-Suspect Discovery Engine™');

import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import archiver from 'archiver';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';

const TECH = 'Alpha New-Suspect Discovery Engine™';
const VICTIM = '0x6fe0fab2164d8e0d03ad6a628e2af78624060322';
const KEY = (process.env.ALCHEMY_API_KEY || '').trim();
const URL_ETH = `https://eth-mainnet.g.alchemy.com/v2/${KEY}`;
const CASE_ID = `SillyTuna-NewSuspects-${new Date().toISOString().slice(0,10)}`;
const OUT_DIR = path.resolve('private/exports/sillytuna-new-suspects');
const ZIP_PATH = path.resolve('private/exports/SillyTuna-NewSuspects-Discovery.zip');

// Hack date is 2026-03-04. Pull a wide window: Jan 1 - April 24 2026 to catch any
// pre-hack staging/test tx and post-hack laundering.
const FROM_BLOCK = '0x16ad6c0'; // ~Jan 1 2026
const TO_BLOCK   = 'latest';

fs.rmSync(OUT_DIR, { recursive: true, force: true });
fs.mkdirSync(OUT_DIR, { recursive: true });

async function rpc(method: string, params: any) {
  const r = await fetch(URL_ETH, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({jsonrpc:'2.0',id:1,method,params}) });
  const j: any = await r.json();
  if (j.error) throw new Error(JSON.stringify(j.error));
  return j.result;
}

async function fetchAllTransfers(direction: 'from'|'to'): Promise<any[]> {
  const cats = ['external','internal','erc20','erc721','erc1155'];
  const out: any[] = [];
  let pageKey: string | undefined;
  for (let page = 0; page < 8; page++) {
    const params: any = {
      fromBlock: FROM_BLOCK,
      toBlock: TO_BLOCK,
      category: cats,
      withMetadata: true,
      maxCount: '0x3e8',
    };
    if (direction === 'from') params.fromAddress = VICTIM; else params.toAddress = VICTIM;
    if (pageKey) params.pageKey = pageKey;
    const result = await rpc('alchemy_getAssetTransfers', [params]);
    const ts = result?.transfers || [];
    out.push(...ts);
    if (!result?.pageKey || ts.length === 0) break;
    pageKey = result.pageKey;
  }
  return out;
}

function csvEscape(v: any) { if (v == null) return ''; const s = String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s; }
function writeCsv(file: string, rows: any[]) {
  if (!rows.length) return fs.writeFileSync(file, '');
  const cols = Object.keys(rows[0]);
  fs.writeFileSync(file, [cols.join(','), ...rows.map(r => cols.map(c => csvEscape(r[c])).join(','))].join('\n'));
}

function loadKnownSuspects(): Set<string> {
  const known = new Set<string>();
  const FILES = [
    'SillyTuna_Forensic/forensic_all_wallets.json',
    'SillyTuna_Forensic/spider_swarm_results.json',
    'contracts/atc/DAUv2_full_trace_results.json',
    'contracts/atc/sillytuna_backtrace_mapping.json',
  ];
  for (const f of FILES) {
    try {
      const text = fs.readFileSync(path.resolve(f), 'utf8');
      const matches = text.match(/0x[a-fA-F0-9]{40}/g) || [];
      for (const m of matches) known.add(m.toLowerCase());
    } catch {}
  }
  return known;
}

(async () => {
  console.log(`[${TECH}] Starting wide-window discovery scan for victim ${VICTIM}`);
  const known = loadKnownSuspects();
  console.log(`[${TECH}] Loaded ${known.size} known wallets from existing case files.`);

  console.log(`[${TECH}] Fetching all OUTBOUND transfers (Jan 2026 → now)…`);
  const outs = await fetchAllTransfers('from');
  console.log(`[${TECH}]   → ${outs.length} outbound transfers`);

  console.log(`[${TECH}] Fetching all INBOUND transfers (Jan 2026 → now)…`);
  const ins = await fetchAllTransfers('to');
  console.log(`[${TECH}]   → ${ins.length} inbound transfers`);

  // Aggregate counterparties
  const cpMap = new Map<string, {
    address: string;
    asInbound: number;   // tx count where they sent TO victim
    asOutbound: number;  // tx count where they received FROM victim
    totalUsdishIn: number;   // crude USD-ish sum (treats stablecoins as 1:1)
    totalUsdishOut: number;
    assets: Set<string>;
    firstSeen: string;
    lastSeen: string;
    sampleTx: { hash: string; iso: string; direction: string; asset: string; value: number }[];
  }>();

  function valueUsd(t: any): number {
    const v = parseFloat(t.value) || 0;
    const a = (t.asset || '').toUpperCase();
    if (['USDC','USDT','DAI','BUSD','TUSD','FRAX','USDP','LUSD','GUSD','AETHUSDC','AUSDC','AUSDT'].includes(a)) return v;
    if (a === 'ETH' || a === 'WETH' || a === 'AETHWETH') return v * 3500;
    if (a === 'WBTC' || a === 'BTC') return v * 65000;
    return 0;
  }

  for (const t of outs) {
    if (!t.to) continue;
    const addr = t.to.toLowerCase();
    if (addr === VICTIM) continue;
    const e = cpMap.get(addr) || { address: addr, asInbound:0, asOutbound:0, totalUsdishIn:0, totalUsdishOut:0, assets:new Set<string>(), firstSeen:'', lastSeen:'', sampleTx:[] };
    e.asOutbound++;
    e.totalUsdishOut += valueUsd(t);
    e.assets.add(t.asset || 'unknown');
    const iso = t.metadata?.blockTimestamp || '';
    if (!e.firstSeen || iso < e.firstSeen) e.firstSeen = iso;
    if (!e.lastSeen  || iso > e.lastSeen)  e.lastSeen  = iso;
    if (e.sampleTx.length < 3) e.sampleTx.push({ hash: t.hash, iso, direction: 'OUT (victim → them)', asset: t.asset, value: parseFloat(t.value)||0 });
    cpMap.set(addr, e);
  }
  for (const t of ins) {
    if (!t.from) continue;
    const addr = t.from.toLowerCase();
    if (addr === VICTIM) continue;
    if (addr === '0x0000000000000000000000000000000000000000') continue; // mints (Aave aToken supply mechanics)
    const e = cpMap.get(addr) || { address: addr, asInbound:0, asOutbound:0, totalUsdishIn:0, totalUsdishOut:0, assets:new Set<string>(), firstSeen:'', lastSeen:'', sampleTx:[] };
    e.asInbound++;
    e.totalUsdishIn += valueUsd(t);
    e.assets.add(t.asset || 'unknown');
    const iso = t.metadata?.blockTimestamp || '';
    if (!e.firstSeen || iso < e.firstSeen) e.firstSeen = iso;
    if (!e.lastSeen  || iso > e.lastSeen)  e.lastSeen  = iso;
    if (e.sampleTx.length < 3) e.sampleTx.push({ hash: t.hash, iso, direction: 'IN (them → victim)', asset: t.asset, value: parseFloat(t.value)||0 });
    cpMap.set(addr, e);
  }

  console.log(`[${TECH}] Aggregated ${cpMap.size} unique counterparties total.`);

  // Classify each counterparty
  const counterparties = Array.from(cpMap.values()).map(cp => {
    const lab = lookupAddress(cp.address);
    return {
      ...cp,
      assets: Array.from(cp.assets).join('|'),
      label: lab?.label || '',
      category: lab?.category || '',
      knownInCase: known.has(cp.address),
      isWellKnownInfra: !!(lab && ['exchange','bridge','mixer','defi','contract','infrastructure'].includes(lab.category || '')),
    };
  });

  // NEW SUSPECTS = received funds from victim, not in known case file, not labelled infra
  const newSuspects = counterparties
    .filter(c => c.asOutbound > 0 && !c.knownInCase && !c.isWellKnownInfra)
    .sort((a,b) => b.totalUsdishOut - a.totalUsdishOut);

  // KNOWN-but-confirmed (already in case file, victim sent to them in this window)
  const knownSuspectsConfirmed = counterparties
    .filter(c => c.asOutbound > 0 && c.knownInCase)
    .sort((a,b) => b.totalUsdishOut - a.totalUsdishOut);

  // Pre-hack inbound (potential staging) — funds came IN before the hack
  const preHackFunders = counterparties
    .filter(c => c.asInbound > 0 && c.firstSeen && c.firstSeen < '2026-03-04T17:00:00Z')
    .sort((a,b) => b.totalUsdishIn - a.totalUsdishIn);

  console.log(`[${TECH}] NEW suspect wallets (not in existing case file): ${newSuspects.length}`);
  console.log(`[${TECH}] Known suspects re-confirmed: ${knownSuspectsConfirmed.length}`);
  console.log(`[${TECH}] Pre-hack funders (potential grooming/staging): ${preHackFunders.length}`);

  // Write CSVs
  const csvRow = (c: any) => ({
    address: c.address,
    role: c.asOutbound > 0 && c.asInbound > 0 ? 'BIDIRECTIONAL' : c.asOutbound > 0 ? 'RECEIVED-FROM-VICTIM' : 'SENT-TO-VICTIM',
    out_tx_count: c.asOutbound,
    in_tx_count: c.asInbound,
    usd_received_from_victim: c.totalUsdishOut.toFixed(2),
    usd_sent_to_victim: c.totalUsdishIn.toFixed(2),
    assets: c.assets,
    label: c.label,
    category: c.category,
    known_in_case: c.knownInCase,
    is_infra: c.isWellKnownInfra,
    first_seen: c.firstSeen,
    last_seen: c.lastSeen,
  });
  writeCsv(path.join(OUT_DIR, '01_NEW_Suspect_Wallets.csv'), newSuspects.map(csvRow));
  writeCsv(path.join(OUT_DIR, '02_Known_Suspects_ReConfirmed.csv'), knownSuspectsConfirmed.map(csvRow));
  writeCsv(path.join(OUT_DIR, '03_Pre-Hack_Funders.csv'), preHackFunders.map(csvRow));
  writeCsv(path.join(OUT_DIR, '04_All_Counterparties.csv'), counterparties.sort((a,b)=>b.totalUsdishOut+b.totalUsdishIn-(a.totalUsdishOut+a.totalUsdishIn)).map(csvRow));

  // Raw evidence
  fs.writeFileSync(path.join(OUT_DIR, 'raw_outbound.json'), JSON.stringify(outs, null, 2));
  fs.writeFileSync(path.join(OUT_DIR, 'raw_inbound.json'),  JSON.stringify(ins, null, 2));

  // Audit JSON
  fs.writeFileSync(path.join(OUT_DIR, 'trace.json'), JSON.stringify({
    _proprietaryHeader: proprietaryHeader(TECH),
    caseReference: CASE_ID,
    generatedAt: new Date().toISOString(),
    chain: 'ethereum',
    victim: VICTIM,
    queryWindow: { fromBlock: FROM_BLOCK, toBlock: TO_BLOCK, fromIsoApprox: '2026-01-01', toIsoApprox: new Date().toISOString() },
    knownWalletsLoaded: known.size,
    transfers: { inbound: ins.length, outbound: outs.length },
    counterpartyCounts: {
      total: counterparties.length,
      newSuspects: newSuspects.length,
      knownSuspectsReConfirmed: knownSuspectsConfirmed.length,
      preHackFunders: preHackFunders.length,
    },
    newSuspects,
    knownSuspectsConfirmed,
    preHackFunders,
  }, null, 2));

  // PDF Report
  const pdfPath = path.join(OUT_DIR, 'SillyTuna_NewSuspects_Report.pdf');
  await new Promise<void>(resolve => {
    const doc = new PDFDocument({ size: 'LETTER', margin: 56, info: { Title: 'SillyTuna New-Suspect Discovery Report', Author: 'Alpha Unlimited Trading' } });
    const ws = fs.createWriteStream(pdfPath);
    doc.pipe(ws);
    doc.fontSize(7).fillColor('#666').text(proprietaryHeader(TECH));
    doc.moveDown(0.5).fillColor('black');
    doc.font('Helvetica-Bold').fontSize(16).fillColor('#0a2540').text('SillyTuna Case — New-Suspect Wallet Discovery Report');
    doc.moveDown(0.4).fillColor('black').font('Helvetica').fontSize(10);
    doc.font('Helvetica-Bold').text('Victim: ', { continued: true }).font('Helvetica').text(VICTIM);
    doc.font('Helvetica-Bold').text('Case Reference: ', { continued: true }).font('Helvetica').text(CASE_ID);
    doc.font('Helvetica-Bold').text('Query window: ', { continued: true }).font('Helvetica').text(`Jan 1 2026 → ${new Date().toISOString().slice(0,10)} (full pre-hack + post-hack window)`);
    doc.font('Helvetica-Bold').text('Hack date (first-ever activity): ', { continued: true }).font('Helvetica').text('2026-03-04 17:13 UTC');
    doc.moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Important Finding About User\'s Original Question');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text(`The victim wallet had ZERO on-chain activity in January 2022 — or in any month before 2026-03-04. The wallet appears to have been opened (or at minimum first funded) on the day of the theft itself, suggesting it was either a fresh deposit account or a previously-dormant key that was activated at the moment of compromise. There is no January-2022 timeline to trace because no transactions exist in that period.`);
    doc.moveDown(0.4);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`NEW Suspect Wallets — ${newSuspects.length}`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text('Wallets that received funds from the victim and are NOT in the existing SillyTuna case file or labelled as known infrastructure (exchange/bridge/mixer/contract/DEX). These are the strongest candidates for new investigative attention.');
    doc.moveDown(0.3).fontSize(9);
    if (newSuspects.length === 0) {
      doc.text('  No new outbound suspects detected — every wallet that received funds from the victim is either already catalogued or is well-known infrastructure (exchange, bridge, DeFi contract).');
    } else {
      for (const s of newSuspects.slice(0, 25)) {
        doc.font('Helvetica-Bold').text(`• ${s.address}  $${s.totalUsdishOut.toFixed(0)}  (${s.asOutbound} txs)`).font('Helvetica');
        if (s.label) doc.text(`    label: ${s.label} [${s.category}]`);
        doc.text(`    assets: ${s.assets}   first→last: ${s.firstSeen?.slice(0,10) || '?'} → ${s.lastSeen?.slice(0,10) || '?'}`);
        doc.moveDown(0.2);
      }
      if (newSuspects.length > 25) doc.text(`  …+ ${newSuspects.length - 25} more in 01_NEW_Suspect_Wallets.csv`);
    }
    doc.moveDown(0.4).fontSize(10);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`Known Suspects Re-Confirmed — ${knownSuspectsConfirmed.length}`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text('Wallets already in the existing case file that received funds from the victim in this window. Each one is a re-confirmation of prior evidence.');
    doc.moveDown(0.3).fontSize(9);
    for (const s of knownSuspectsConfirmed.slice(0, 15)) {
      doc.text(`• ${s.address}  $${s.totalUsdishOut.toFixed(0)}  (${s.asOutbound} txs)  ${s.label ? `[${s.label}]` : ''}`);
    }
    doc.moveDown(0.4).fontSize(10);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text(`Pre-Hack Funders — ${preHackFunders.length}`);
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.text('Wallets that sent funds to the victim BEFORE 2026-03-04 17:00 UTC. These could indicate grooming, test transactions, or pre-positioning by the attacker.');
    doc.moveDown(0.3).fontSize(9);
    if (preHackFunders.length === 0) doc.text('  No inbound transactions before the hack window. The wallet went from zero balance to drained in a single transaction sequence — consistent with an instant-compromise / fresh-key scenario.');
    else for (const s of preHackFunders.slice(0, 15)) doc.text(`• ${s.address}  $${s.totalUsdishIn.toFixed(0)}  ${s.firstSeen}  ${s.label ? `[${s.label}]` : ''}`);
    doc.moveDown(0.4).fontSize(10);

    doc.font('Helvetica-Bold').fontSize(13).fillColor('#0a2540').text('Recommended Next Steps');
    doc.moveDown(0.2).font('Helvetica').fontSize(10).fillColor('black');
    doc.list([
      newSuspects.length > 0
        ? `Add the ${newSuspects.length} new suspect wallet(s) above to the case monitoring set and run a multi-chain trace on each via the existing register-and-trace tooling.`
        : 'No new outbound suspect wallets — the existing case file is already exhaustive for the in-window outbound flows.',
      preHackFunders.length > 0
        ? `Investigate the ${preHackFunders.length} pre-hack funder(s) for grooming / pre-positioning patterns.`
        : 'No pre-hack inbound activity — the wallet was effectively dormant until the moment of compromise.',
      'Cross-reference all new suspect wallets against the OFAC SDN list, Chainabuse, and the Polygon/Arbitrum/Base sister-chain trace data.',
      'Re-run the comprehensive case forensics tool to generate fresh KYC-exposure exports for any new exchanges identified.',
    ]);

    doc.end();
    ws.on('finish', () => resolve());
  });

  // README
  fs.writeFileSync(path.join(OUT_DIR, '00_README.txt'),
`${proprietaryHeader(TECH)}

ALPHA UNLIMITED TRADING — SILLYTUNA NEW-SUSPECT DISCOVERY
=========================================================
Case Reference : ${CASE_ID}
Victim Wallet  : ${VICTIM}
Generated      : ${new Date().toISOString()}

ANSWER TO THE ORIGINAL QUESTION
-------------------------------
The victim wallet had ZERO activity in January 2022 (or any earlier January).
First-ever transaction: 2026-03-04 17:13 UTC — the day of the theft itself.

The wallet was either freshly opened on the hack day, or was a previously-
dormant key that was activated at the moment of compromise. There is no
January-2022 timeline to trace.

CONTENTS
--------
  00_README.txt                          — this file
  SillyTuna_NewSuspects_Report.pdf       — full PDF report
  01_NEW_Suspect_Wallets.csv             — wallets that received from victim and are NOT in case file
  02_Known_Suspects_ReConfirmed.csv      — known wallets that received from victim (re-confirmation)
  03_Pre-Hack_Funders.csv                — wallets that funded victim BEFORE the hack (grooming/staging)
  04_All_Counterparties.csv              — every counterparty in the window
  raw_outbound.json                      — raw Alchemy outbound transfer log
  raw_inbound.json                       — raw Alchemy inbound transfer log
  trace.json                             — machine-readable evidence bundle

EVIDENCE BASIS
--------------
All on-chain facts sourced live from Ethereum mainnet via Alchemy
(alchemy_getAssetTransfers across external/internal/erc20/erc721/erc1155
categories). Counterparty labels from the proprietary Alpha Address Label
Database. Cross-reference performed against:
  - SillyTuna_Forensic/forensic_all_wallets.json
  - SillyTuna_Forensic/spider_swarm_results.json
  - contracts/atc/DAUv2_full_trace_results.json
  - contracts/atc/sillytuna_backtrace_mapping.json
(${known.size} known wallets total).
`);

  // Zip
  await new Promise<void>((resolve, reject) => {
    const out = fs.createWriteStream(ZIP_PATH);
    const archive = archiver('zip', { zlib: { level: 9 } });
    out.on('close', () => resolve());
    archive.on('error', reject);
    archive.pipe(out);
    archive.directory(OUT_DIR, false);
    archive.finalize();
  });
  console.log(`[${TECH}] ✅ Package built: ${ZIP_PATH}`);
})().catch(e => { console.error(`[${TECH}] FATAL:`, e); process.exit(1); });
