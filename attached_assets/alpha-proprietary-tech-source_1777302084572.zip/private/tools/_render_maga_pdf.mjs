import PDFDocument from 'pdfkit';
import fs from 'node:fs';
import path from 'node:path';

const TXT  = fs.readFileSync('attached_assets/forensic_reports/MAGA_RAVEDAO_44k_Sell_Trace.txt', 'utf-8');
const OUT  = 'attached_assets/forensic_reports/MAGA_RAVEDAO_44k_Sell_Trace.pdf';

const doc = new PDFDocument({ size: 'LETTER', margin: 48 });
const stream = fs.createWriteStream(OUT);
doc.pipe(stream);

doc.fillColor('#d4af37').fontSize(16).font('Helvetica-Bold')
   .text('ALPHA UNLIMITED FORENSICS', { align: 'center' });
doc.fillColor('#d4af37').fontSize(11).font('Helvetica')
   .text('Solana Sell-Trace Case Output — Case MAGA-RAVEDAO-2026-04-22', { align: 'center' });
doc.moveDown(0.4);
doc.strokeColor('#d4af37').lineWidth(0.7)
   .moveTo(48, doc.y).lineTo(564, doc.y).stroke();
doc.moveDown(0.6);
doc.fillColor('#666').fontSize(8).font('Helvetica-Oblique')
   .text('PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA — © 2024-2026 Alpha Unlimited Trading Company', { align: 'center' });
doc.moveDown(0.8);

doc.fillColor('#111').fontSize(8.5).font('Courier');
doc.text(TXT, { lineGap: 1.1, align: 'left' });

doc.end();
await new Promise((resolve) => stream.on('finish', resolve));
console.log(`Wrote ${OUT} (${fs.statSync(OUT).size} bytes)`);
