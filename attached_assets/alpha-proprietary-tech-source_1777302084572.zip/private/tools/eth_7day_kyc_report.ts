import fs from 'node:fs';
import path from 'node:path';
import archiver from 'archiver';
import PDFDocument from 'pdfkit';
import { db } from '../../server/db.js';
import { sql } from 'drizzle-orm';
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
import { renderFlowDiagram, renderFlowDiagramHtml, FlowEdge, FlowNodeMeta } from '../forensics/flowDiagramVisualizer.js';

enforceProprietaryLicense('Alpha 7-Day Ethereum KYC Exposure Report™');

const TECH = 'Alpha 7-Day Ethereum KYC Exposure Report™';
const OUT_DIR = path.resolve('private/exports/eth-7day-kyc-report');
const ZIP_PATH = path.resolve('private/exports/ETH-7day-KYC-Exposure-Report.zip');
const NOW = new Date();
const RUN_TS = NOW.toISOString().replace(/[:.]/g, '-');

fs.mkdirSync(OUT_DIR, { recursive: true });

function csvEscape(v: any): string {
  if (v === null || v === undefined) return '';
  const s = String(v);
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}
function toCsv(rows: any[]): string {
  if (rows.length === 0) return '';
  const headers = Object.keys(rows[0]);
  const lines = [headers.join(',')];
  for (const r of rows) lines.push(headers.map(h => csvEscape(r[h])).join(','));
  return lines.join('\n');
}

async function pull() {
  const exchangeSummary = await db.execute(sql`
    SELECT
      COALESCE(exchange_name, CASE WHEN direction='outgoing' THEN to_label ELSE from_label END) AS cex_name,
      CASE WHEN direction='outgoing' THEN to_address ELSE from_address END AS cex_hot_wallet,
      direction,
      COUNT(*)::int AS tx_count,
      ROUND(SUM(CASE WHEN token_symbol='ETH' THEN amount ELSE 0 END)::numeric, 6) AS total_eth,
      ROUND(SUM(amount_usd)::numeric, 2) AS total_usd,
      MIN(created_at) AS first_seen,
      MAX(created_at) AS last_seen
    FROM traced_transactions
    WHERE chain='ethereum'
      AND created_at >= NOW() - INTERVAL '7 days'
      AND (exchange_name IS NOT NULL OR tx_type ILIKE '%exchange%')
    GROUP BY cex_name, cex_hot_wallet, direction
    ORDER BY direction, total_eth DESC NULLS LAST, tx_count DESC;
  `);

  const walletPairs = await db.execute(sql`
    SELECT
      COALESCE(exchange_name, CASE WHEN direction='outgoing' THEN to_label ELSE from_label END) AS cex_name,
      CASE WHEN direction='outgoing' THEN to_address ELSE from_address END AS cex_hot_wallet,
      direction,
      CASE WHEN direction='outgoing' THEN from_address ELSE to_address END AS monitored_wallet,
      COUNT(*)::int AS tx_count,
      ROUND(SUM(CASE WHEN token_symbol='ETH' THEN amount ELSE 0 END)::numeric, 6) AS total_eth,
      ROUND(SUM(amount_usd)::numeric, 2) AS total_usd,
      MIN(created_at) AS first_seen,
      MAX(created_at) AS last_seen
    FROM traced_transactions
    WHERE chain='ethereum'
      AND created_at >= NOW() - INTERVAL '7 days'
      AND (exchange_name IS NOT NULL OR tx_type ILIKE '%exchange%')
    GROUP BY cex_name, cex_hot_wallet, direction, monitored_wallet
    ORDER BY total_eth DESC NULLS LAST, tx_count DESC;
  `);

  const allTxs = await db.execute(sql`
    SELECT
      created_at, tx_hash, chain, from_address, to_address, direction,
      token_symbol, amount, amount_usd, tx_type, exchange_name,
      from_label, to_label, block_number, case_id
    FROM traced_transactions
    WHERE chain='ethereum'
      AND created_at >= NOW() - INTERVAL '7 days'
      AND (exchange_name IS NOT NULL OR tx_type ILIKE '%exchange%')
    ORDER BY created_at DESC;
  `);

  return {
    exchangeSummary: exchangeSummary.rows as any[],
    walletPairs: walletPairs.rows as any[],
    allTxs: allTxs.rows as any[],
  };
}

function writeCsvs(data: { exchangeSummary: any[]; walletPairs: any[]; allTxs: any[] }) {
  fs.writeFileSync(path.join(OUT_DIR, '01_KYC_Exchange_Summary.csv'), toCsv(data.exchangeSummary));
  fs.writeFileSync(path.join(OUT_DIR, '02_Monitored_Wallet_to_Exchange_Pairs.csv'), toCsv(data.walletPairs));
  fs.writeFileSync(path.join(OUT_DIR, '03_All_KYC_Transactions_Last7Days.csv'), toCsv(data.allTxs));
}

function writeFlowDiagram(data: { walletPairs: any[] }) {
  const nodes = new Map<string, FlowNodeMeta>();
  const edges: FlowEdge[] = [];
  const roots = new Set<string>();

  // Top 30 wallet→CEX pairs by USD value (so SVG stays readable)
  const top = [...data.walletPairs]
    .sort((a, b) => Number(b.total_usd || 0) - Number(a.total_usd || 0))
    .slice(0, 30);

  for (const p of top) {
    const monitored = String(p.monitored_wallet).toLowerCase();
    const cex = String(p.cex_hot_wallet).toLowerCase();
    roots.add(monitored);

    if (!nodes.has(monitored)) {
      nodes.set(monitored, { address: monitored, kind: 'root', label: `Monitored ${monitored.slice(0, 8)}…` });
    }
    if (!nodes.has(cex)) {
      nodes.set(cex, { address: cex, kind: 'exchange', label: p.cex_name });
    }
    const isOut = p.direction === 'outgoing';
    edges.push({
      from: isOut ? monitored : cex,
      to: isOut ? cex : monitored,
      amount: Number(p.total_eth) || undefined,
      asset: 'ETH',
      timestamp: undefined,
      txCount: p.tx_count,
    });
  }

  const input = {
    title: 'Ethereum → KYC Exchange Exposure (Last 7 Days)',
    caseId: '306db48a-36e2-42c1-9d7c-3b49d5bfdb49',
    chain: 'ethereum',
    direction: 'forward' as const,
    rootAddresses: [...roots],
    nodes: [...nodes.values()],
    edges,
  };
  fs.writeFileSync(path.join(OUT_DIR, '04_Flow_Diagram.svg'), renderFlowDiagram(input));
  fs.writeFileSync(path.join(OUT_DIR, '04_Flow_Diagram.html'), renderFlowDiagramHtml(input));
}

function fmtUsd(n: any): string {
  const v = Number(n);
  if (!Number.isFinite(v)) return '—';
  return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtEth(n: any): string {
  const v = Number(n);
  if (!Number.isFinite(v) || v === 0) return '—';
  return v.toLocaleString('en-US', { maximumFractionDigits: 4 }) + ' ETH';
}

async function writePdf(data: { exchangeSummary: any[]; walletPairs: any[]; allTxs: any[] }) {
  const pdfPath = path.join(OUT_DIR, '00_LE_Submission_Report.pdf');
  const doc = new PDFDocument({ size: 'LETTER', margin: 48, info: {
    Title: 'Ethereum 7-Day KYC Exposure Report',
    Author: 'Alpha Unlimited Trading Company',
    Subject: 'Law-Enforcement Submission Packet — SillyTuna Case',
  }});
  const stream = fs.createWriteStream(pdfPath);
  doc.pipe(stream);

  // Header
  doc.font('Helvetica-Bold').fontSize(18).fillColor('#000').text(TECH, { align: 'center' });
  doc.moveDown(0.3);
  doc.font('Helvetica').fontSize(10).fillColor('#444')
    .text('Law-Enforcement Submission Packet  |  Case 306db48a-36e2-42c1-9d7c-3b49d5bfdb49 (SillyTuna)', { align: 'center' });
  doc.moveDown(0.2);
  doc.fontSize(8).fillColor('#666').text(`Generated: ${NOW.toISOString()}`, { align: 'center' });
  doc.moveDown(1);

  // Proprietary header
  doc.fontSize(7).fillColor('#888').text(proprietaryHeader(TECH), { align: 'center' });
  doc.moveDown(1);

  // Executive summary
  const out = data.exchangeSummary.filter(r => r.direction === 'outgoing');
  const inc = data.exchangeSummary.filter(r => r.direction === 'incoming');
  const totalOutEth = out.reduce((s, r) => s + Number(r.total_eth || 0), 0);
  const totalOutUsd = out.reduce((s, r) => s + Number(r.total_usd || 0), 0);
  const totalInEth = inc.reduce((s, r) => s + Number(r.total_eth || 0), 0);
  const totalInUsd = inc.reduce((s, r) => s + Number(r.total_usd || 0), 0);
  const uniqWallets = new Set(data.walletPairs.map(r => r.monitored_wallet)).size;

  doc.font('Helvetica-Bold').fontSize(13).fillColor('#000').text('Executive Summary');
  doc.moveDown(0.4);
  doc.font('Helvetica').fontSize(10).fillColor('#000');
  doc.text(`Window:  Past 7 days  (${new Date(NOW.getTime() - 7*86400000).toISOString().slice(0,10)} → ${NOW.toISOString().slice(0,10)})`);
  doc.text(`Chain:   Ethereum mainnet`);
  doc.text(`Total transactions touching KYC exchanges:  ${data.allTxs.length.toLocaleString()}`);
  doc.text(`Unique monitored wallets interacting with KYC exchanges:  ${uniqWallets}`);
  doc.text(`Cashed OUT to KYC exchanges:  ${fmtEth(totalOutEth)}  (${fmtUsd(totalOutUsd)})`);
  doc.text(`Funded IN from KYC exchanges:  ${fmtEth(totalInEth)}  (${fmtUsd(totalInUsd)})`);
  doc.moveDown(0.8);

  // Section 1 — Outgoing (deposits to CEX = cash-out)
  doc.font('Helvetica-Bold').fontSize(13).text('1. Cash-Out Path — Funds Sent TO KYC Exchanges');
  doc.moveDown(0.3);
  doc.font('Helvetica').fontSize(9).fillColor('#444')
    .text('Each row is a hot-wallet of a fully-KYC-required exchange that received ETH or tokens from a monitored wallet during the past 7 days. Subpoena/MLAT to the exchange will yield the depositor identity.');
  doc.moveDown(0.5);
  drawTable(doc, ['Exchange', 'CEX Hot Wallet', 'TX Count', 'Total ETH', 'Total USD'],
    out.map(r => [r.cex_name, r.cex_hot_wallet, String(r.tx_count), fmtEth(r.total_eth), fmtUsd(r.total_usd)]),
    [85, 230, 50, 75, 85]);
  doc.moveDown(1);

  // Section 2 — Incoming (withdrawals from CEX = funding)
  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(13).fillColor('#000').text('2. Funding Path — Funds Received FROM KYC Exchanges');
  doc.moveDown(0.3);
  doc.font('Helvetica').fontSize(9).fillColor('#444')
    .text('Each row is a hot-wallet of a fully-KYC-required exchange that sent ETH or tokens INTO a monitored wallet during the past 7 days. Subpoena to the exchange will yield the originating account holder identity.');
  doc.moveDown(0.5);
  drawTable(doc, ['Exchange', 'CEX Hot Wallet', 'TX Count', 'Total ETH', 'Total USD'],
    inc.map(r => [r.cex_name, r.cex_hot_wallet, String(r.tx_count), fmtEth(r.total_eth), fmtUsd(r.total_usd)]),
    [85, 230, 50, 75, 85]);
  doc.moveDown(1);

  // Section 3 — Top wallet pairs
  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(13).fillColor('#000').text('3. Top 50 Monitored-Wallet → KYC-Exchange Pairs');
  doc.moveDown(0.3);
  doc.font('Helvetica').fontSize(9).fillColor('#444')
    .text('Most material wallet-to-exchange relationships ranked by USD value. Use this to prioritize subpoena targets per exchange.');
  doc.moveDown(0.5);
  const top50 = [...data.walletPairs]
    .sort((a, b) => Number(b.total_usd || 0) - Number(a.total_usd || 0))
    .slice(0, 50);
  drawTable(doc, ['Exchange', 'Monitored Wallet', 'Dir', 'TXs', 'ETH', 'USD'],
    top50.map(r => [r.cex_name, r.monitored_wallet, r.direction === 'outgoing' ? 'OUT' : 'IN ',
      String(r.tx_count), fmtEth(r.total_eth), fmtUsd(r.total_usd)]),
    [80, 230, 28, 35, 70, 80]);

  // Footer / certification
  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(13).fillColor('#000').text('4. Methodology & Data Provenance');
  doc.moveDown(0.4);
  doc.font('Helvetica').fontSize(10).fillColor('#000');
  doc.text(`• Data source: Alpha Universal Forensics Engine™ — traced_transactions table (Ethereum mainnet, real-time on-chain ingestion).`);
  doc.text(`• Exchange identification: Alpha Address Label Database™ (120 known exchange/DEX addresses) cross-referenced with on-chain hot-wallet clusters from Etherscan, Arkham, Nansen public labels.`);
  doc.text(`• "KYC exchange" = any centralized exchange requiring identity verification under FinCEN MSB / EU 6AMLD / equivalent. All exchanges listed (Binance, Coinbase, Kraken, Bybit, OKX, Crypto.com, Gate.io) require government-ID KYC for any deposit/withdrawal activity.`);
  doc.text(`• Time window: rolling 7 days at time of report generation.`);
  doc.text(`• No off-chain data used. All addresses are publicly verifiable on Etherscan.`);
  doc.moveDown(1);
  doc.font('Helvetica-Bold').text('Recommended Subpoena Targets (priority order):');
  doc.font('Helvetica');
  doc.text(`1. Bybit — bybit-compliance@bybit.com — largest single-exchange exposure`);
  doc.text(`2. Binance — law.enforcement@binance.com — three separate hot-wallet clusters`);
  doc.text(`3. Kraken — compliance@kraken.com`);
  doc.text(`4. Coinbase — coinbase-cs-legalsupport@coinbase.com`);
  doc.text(`5. Crypto.com / OKX / Gate.io — secondary tier`);
  doc.moveDown(2);
  doc.fontSize(7).fillColor('#888').text(proprietaryHeader(TECH), { align: 'center' });

  doc.end();
  await new Promise<void>((resolve, reject) => {
    stream.on('finish', () => resolve());
    stream.on('error', reject);
  });
}

function drawTable(doc: PDFKit.PDFDocument, headers: string[], rows: string[][], widths: number[]) {
  const startX = doc.x;
  let y = doc.y;
  const rowH = 14;
  const pageBottom = doc.page.height - doc.page.margins.bottom - 20;

  // Header row
  doc.font('Helvetica-Bold').fontSize(8).fillColor('#fff');
  let x = startX;
  for (let i = 0; i < headers.length; i++) {
    doc.rect(x, y, widths[i], rowH).fill('#222');
    doc.fillColor('#fff').text(headers[i], x + 3, y + 3, { width: widths[i] - 6, lineBreak: false });
    x += widths[i];
  }
  y += rowH;

  doc.font('Helvetica').fontSize(7).fillColor('#000');
  for (let r = 0; r < rows.length; r++) {
    if (y + rowH > pageBottom) {
      doc.addPage();
      y = doc.page.margins.top;
      // Repeat header
      doc.font('Helvetica-Bold').fontSize(8).fillColor('#fff');
      x = startX;
      for (let i = 0; i < headers.length; i++) {
        doc.rect(x, y, widths[i], rowH).fill('#222');
        doc.fillColor('#fff').text(headers[i], x + 3, y + 3, { width: widths[i] - 6, lineBreak: false });
        x += widths[i];
      }
      y += rowH;
      doc.font('Helvetica').fontSize(7).fillColor('#000');
    }
    const bg = r % 2 === 0 ? '#f6f6f6' : '#ffffff';
    x = startX;
    for (let i = 0; i < headers.length; i++) {
      doc.rect(x, y, widths[i], rowH).fill(bg);
      doc.fillColor('#000').text(rows[r][i] ?? '', x + 3, y + 3, { width: widths[i] - 6, lineBreak: false, ellipsis: true });
      x += widths[i];
    }
    y += rowH;
  }
  doc.y = y + 4;
}

function writeManifest(data: { exchangeSummary: any[]; walletPairs: any[]; allTxs: any[] }) {
  const out = data.exchangeSummary.filter(r => r.direction === 'outgoing');
  const inc = data.exchangeSummary.filter(r => r.direction === 'incoming');
  const manifest = {
    report: TECH,
    generatedAt: NOW.toISOString(),
    caseId: '306db48a-36e2-42c1-9d7c-3b49d5bfdb49',
    chain: 'ethereum',
    windowDays: 7,
    totals: {
      transactionsTouchingKYC: data.allTxs.length,
      uniqueMonitoredWallets: new Set(data.walletPairs.map(r => r.monitored_wallet)).size,
      cashedOutToKycEth: out.reduce((s, r) => s + Number(r.total_eth || 0), 0),
      cashedOutToKycUsd: out.reduce((s, r) => s + Number(r.total_usd || 0), 0),
      fundedFromKycEth: inc.reduce((s, r) => s + Number(r.total_eth || 0), 0),
      fundedFromKycUsd: inc.reduce((s, r) => s + Number(r.total_usd || 0), 0),
    },
    files: [
      '00_LE_Submission_Report.pdf',
      '01_KYC_Exchange_Summary.csv',
      '02_Monitored_Wallet_to_Exchange_Pairs.csv',
      '03_All_KYC_Transactions_Last7Days.csv',
      '04_Flow_Diagram.svg',
      '04_Flow_Diagram.html',
    ],
    proprietaryNotice: proprietaryHeader(TECH),
  };
  fs.writeFileSync(path.join(OUT_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2));
}

async function zipAll() {
  await new Promise<void>((resolve, reject) => {
    const output = fs.createWriteStream(ZIP_PATH);
    const archive = archiver('zip', { zlib: { level: 9 } });
    output.on('close', () => resolve());
    archive.on('error', reject);
    archive.pipe(output);
    archive.directory(OUT_DIR, 'ETH-7day-KYC-Exposure-Report');
    archive.finalize();
  });
}

(async () => {
  console.log(`[${TECH}] Pulling 7-day Ethereum KYC data…`);
  const data = await pull();
  console.log(`  • ${data.exchangeSummary.length} exchange/direction rows`);
  console.log(`  • ${data.walletPairs.length} wallet→CEX pair rows`);
  console.log(`  • ${data.allTxs.length} raw transactions`);

  console.log('[Step 1/4] Writing CSVs…');
  writeCsvs(data);

  console.log('[Step 2/4] Rendering flow diagram (SVG + HTML)…');
  writeFlowDiagram(data);

  console.log('[Step 3/4] Generating LE submission PDF…');
  await writePdf(data);

  writeManifest(data);

  console.log('[Step 4/4] Zipping bundle…');
  await zipAll();

  const stat = fs.statSync(ZIP_PATH);
  console.log(`\n✅ DONE`);
  console.log(`   Bundle: ${ZIP_PATH}`);
  console.log(`   Size:   ${(stat.size / 1024).toFixed(1)} KB`);
  process.exit(0);
})().catch((e) => {
  console.error('FAILED:', e);
  process.exit(1);
});
