#!/usr/bin/env python3
"""
Alpha External Vulnerability Scanner™ v2.0.0
(C) 2026 Alpha Unlimited Technologies LLC
All Rights Reserved — Proprietary and Confidential

Comprehensive external website & application vulnerability scanner.
Tests live URLs from outside for real vulnerabilities across 30+ categories.
Maximum 3 attempts per vulnerability type. Full scan log with all responses.

Usage:
  python3 alpha_external_scanner.py https://example.com
  python3 alpha_external_scanner.py https://site1.com https://site2.com
  python3 alpha_external_scanner.py https://example.com --deep
  python3 alpha_external_scanner.py https://example.com -o ~/reports/
  python3 alpha_external_scanner.py  (interactive mode)
"""

import os
import re
import sys
import json
import ssl
import socket
import time
import hashlib
import base64
import argparse
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime
from pathlib import Path
from collections import defaultdict

VERSION = "2.1.0"
MAX_ATTEMPTS = 3
TIMEOUT = 10
DEFAULT_MAX_PAGES = 50
CRAWL_TIMEOUT = 120

BANNER = f"""
\033[33m╔══════════════════════════════════════════════════════════════╗
║   Alpha External Vulnerability Scanner™ v{VERSION}              ║
║   (C) 2026 Alpha Unlimited Technologies LLC                  ║
║   Proprietary and Confidential                               ║
║                                                              ║
║   30+ Test Categories | Max {MAX_ATTEMPTS} Attempts Per Vuln           ║
║   Full Scan Log | Connection Analysis | HTML Report          ║
╚══════════════════════════════════════════════════════════════╝\033[0m
"""

SEV_CRIT = "CRITICAL"
SEV_HIGH = "HIGH"
SEV_MED = "MEDIUM"
SEV_LOW = "LOW"
SEV_INFO = "INFO"

SEV_COLORS_TERM = {
    SEV_CRIT: "\033[91m",
    SEV_HIGH: "\033[93m",
    SEV_MED: "\033[33m",
    SEV_LOW: "\033[94m",
    SEV_INFO: "\033[90m",
}
SEV_COLORS_HTML = {
    SEV_CRIT: "#ff2222",
    SEV_HIGH: "#ff8800",
    SEV_MED: "#ffcc00",
    SEV_LOW: "#4488ff",
    SEV_INFO: "#888888",
}
RESET = "\033[0m"


class Finding:
    __slots__ = ("fid", "category", "name", "severity", "description",
                 "evidence", "response", "cwe", "fix", "timestamp",
                 "connected", "connection_chains")

    def __init__(self, fid, category, name, severity, description,
                 evidence="", response="", cwe="", fix=""):
        self.fid = fid
        self.category = category
        self.name = name
        self.severity = severity
        self.description = description
        self.evidence = evidence
        self.response = response
        self.cwe = cwe
        self.fix = fix
        self.timestamp = datetime.now().isoformat()
        self.connected = False
        self.connection_chains = []


class ScanLog:
    def __init__(self):
        self.entries = []

    def add(self, test_name, url, method, status, response_snippet, is_vuln=False):
        self.entries.append({
            "time": datetime.now().strftime("%H:%M:%S.%f")[:12],
            "test": str(test_name),
            "url": str(url)[:150],
            "method": str(method),
            "status": int(status) if isinstance(status, (int, float)) else 0,
            "response": str(response_snippet)[:800] if response_snippet else "",
            "vulnerable": bool(is_vuln),
        })


class PageCrawler:
    def __init__(self, base_url, max_pages=DEFAULT_MAX_PAGES, verbose=False):
        self.base_url = base_url.rstrip("/")
        self.max_pages = max_pages
        self.verbose = verbose
        parsed = urllib.parse.urlparse(self.base_url)
        self.hostname = parsed.hostname or ""
        self.scheme = parsed.scheme or "https"
        self.base_origin = f"{self.scheme}://{self.hostname}"
        if parsed.port:
            self.base_origin += f":{parsed.port}"
        self.visited = set()
        self.discovered = []
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Accept": "text/html,*/*",
        }

    def _fetch(self, url):
        try:
            req = urllib.request.Request(url, headers=self.headers)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            resp = urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx)
            body = resp.read(200000).decode("utf-8", errors="ignore")
            return body
        except:
            return ""

    def _normalize(self, href, current_url):
        href = href.strip()
        if not href or href.startswith(("#", "javascript:", "mailto:", "tel:", "data:")):
            return None
        if href.startswith("//"):
            href = self.scheme + ":" + href
        elif href.startswith("/"):
            href = self.base_origin + href
        elif not href.startswith("http"):
            base = current_url.rsplit("/", 1)[0]
            href = base + "/" + href

        parsed = urllib.parse.urlparse(href)
        if parsed.hostname and parsed.hostname != self.hostname:
            return None

        clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        clean = clean.rstrip("/")

        skip_ext = (".jpg", ".jpeg", ".png", ".gif", ".svg", ".webp", ".ico",
                    ".css", ".js", ".woff", ".woff2", ".ttf", ".eot",
                    ".pdf", ".zip", ".tar", ".gz", ".mp3", ".mp4",
                    ".avi", ".mov", ".doc", ".docx", ".xls", ".xlsx")
        if any(parsed.path.lower().endswith(ext) for ext in skip_ext):
            return None

        return clean

    def crawl(self):
        print(f"\n  \033[33m── CRAWLING: Discovering subpages (max {self.max_pages}) ──\033[0m")
        start_time = time.time()
        queue = [self.base_url]
        self.visited.add(self.base_url.rstrip("/"))
        self.discovered.append(self.base_url)

        while queue and len(self.discovered) < self.max_pages:
            if time.time() - start_time > CRAWL_TIMEOUT:
                print(f"  Crawl timeout ({CRAWL_TIMEOUT}s) reached.")
                break

            current = queue.pop(0)
            body = self._fetch(current)
            if not body:
                continue

            hrefs = re.findall(r'(?:href|src|action)=["\']([^"\'#]+)["\']', body, re.IGNORECASE)
            route_hrefs = re.findall(r'(?:to|path|route|href):\s*["\']([^"\'#]+)["\']', body)
            all_hrefs = set(hrefs + route_hrefs)

            for href in all_hrefs:
                if len(self.discovered) >= self.max_pages:
                    break
                normalized = self._normalize(href, current)
                if normalized and normalized not in self.visited:
                    self.visited.add(normalized)
                    self.discovered.append(normalized)
                    queue.append(normalized)
                    if self.verbose:
                        print(f"    \033[32m+\033[0m {normalized}")

        elapsed = time.time() - start_time
        print(f"  Discovered \033[33m{len(self.discovered)}\033[0m pages in {elapsed:.1f}s\n")

        for i, page in enumerate(self.discovered):
            print(f"    [{i+1:3d}] {page}")
        print()

        return self.discovered


class ExternalScanner:
    def __init__(self, target_url, deep=False, verbose=False):
        self.target_url = target_url.rstrip("/")
        self.deep = deep
        self.verbose = verbose
        self.findings = []
        self.log = ScanLog()
        self._fid_counter = 0
        self.base_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "identity",
        }
        parsed = urllib.parse.urlparse(self.target_url)
        self.hostname = parsed.hostname or ""
        self.scheme = parsed.scheme or "https"
        self.port = parsed.port or (443 if self.scheme == "https" else 80)
        self.base_resp = None
        self.stats = {"total_tests": 0, "total_requests": 0, "vulnerabilities": 0,
                      "connections": 0, "start": time.time(), "end": 0}

    def _next_fid(self, prefix="EXT"):
        self._fid_counter += 1
        return f"{prefix}-{self._fid_counter:03d}"

    def _parse_headers(self, raw_headers):
        result = {}
        raw_items = []
        if raw_headers:
            raw_items = raw_headers.items() if hasattr(raw_headers, 'items') else []
        for k, v in raw_items:
            lk = k
            if lk in result:
                result[lk] = result[lk] + ", " + v
            else:
                result[lk] = v
        return result

    def _get_all_set_cookies(self, raw_headers):
        cookies = []
        if raw_headers and hasattr(raw_headers, '_headers'):
            for k, v in raw_headers._headers:
                if k.lower() == 'set-cookie':
                    cookies.append(v)
        elif raw_headers:
            sc = raw_headers.get_all('Set-Cookie') if hasattr(raw_headers, 'get_all') else None
            if sc:
                cookies = sc
            else:
                val = raw_headers.get('Set-Cookie', '')
                if val:
                    cookies = [val]
        return cookies

    def _req(self, url, method="GET", headers=None, data=None, follow_redirects=True):
        hdrs = dict(self.base_headers)
        if headers:
            hdrs.update(headers)
        self.stats["total_requests"] += 1
        try:
            if data and isinstance(data, str):
                data = data.encode("utf-8")
            req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            if not follow_redirects:
                class NoRedirect(urllib.request.HTTPRedirectHandler):
                    def redirect_request(self, req, fp, code, msg, headers, newurl):
                        raise urllib.error.HTTPError(newurl, code, msg, headers, fp)
                opener = urllib.request.build_opener(NoRedirect, urllib.request.HTTPSHandler(context=ctx))
                resp = opener.open(req, timeout=TIMEOUT)
            else:
                resp = urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx)
            body = resp.read(80000).decode("utf-8", errors="ignore")
            parsed = self._parse_headers(resp.headers)
            return {"status": resp.status, "headers": parsed,
                    "raw_headers": resp.headers,
                    "body": body, "url": resp.url, "error": None}
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read(80000).decode("utf-8", errors="ignore")
            except:
                pass
            parsed = self._parse_headers(e.headers) if e.headers else {}
            return {"status": e.code, "headers": parsed,
                    "raw_headers": e.headers,
                    "body": body, "url": url, "error": str(e)}
        except Exception as e:
            return {"status": 0, "headers": {}, "raw_headers": None,
                    "body": "", "url": url, "error": str(e)}

    def _add(self, prefix, category, name, severity, desc, evidence="",
             response="", cwe="", fix=""):
        fid = self._next_fid(prefix)
        f = Finding(fid, category, name, severity, desc, evidence, response, cwe, fix)
        self.findings.append(f)
        self.stats["vulnerabilities"] += 1
        if self.verbose:
            sym = {"CRITICAL": "!!!", "HIGH": "!!", "MEDIUM": "!", "LOW": "~", "INFO": "i"}
            c = SEV_COLORS_TERM.get(severity, "")
            print(f"\n      {c}[{sym.get(severity,'?')}] {fid}: {name}{RESET}", end="")
        return f

    def scan_subpage(self, page_url):
        page_path = urllib.parse.urlparse(page_url).path or "/"
        resp = self._req(page_url)
        if resp["status"] == 0:
            self.log.add(f"Subpage({page_path})", page_url, "GET", 0, "Unreachable")
            return
        self.log.add(f"Subpage({page_path})", page_url, "GET", resp["status"], f"len={len(resp['body'])}")

        h = {k.lower(): v for k, v in resp["headers"].items()}
        body = resp["body"]
        bl = body.lower()

        csp = h.get("content-security-policy", "")
        if not csp:
            self._add("PG-CSP", "Page Security", f"No CSP on {page_path}", SEV_MED,
                f"Page {page_path} has no Content-Security-Policy header.",
                f"URL: {page_url}", "", "CWE-693",
                "Add CSP header to all pages.")

        cookies_raw = self._get_all_set_cookies(resp.get("raw_headers"))
        for ck in cookies_raw:
            name = ck.split("=")[0].strip() if "=" in ck else "unknown"
            cl = ck.lower()
            if "secure" not in cl and self.scheme == "https":
                self._add("PG-COOKIE", "Page Cookie", f"'{name}' No Secure on {page_path}", SEV_MED,
                    f"Cookie '{name}' set on {page_path} without Secure flag.",
                    f"Set-Cookie: {ck[:200]}", "", "CWE-614", "Add Secure flag.")
                break

        forms = re.findall(r'(<form[^>]*>)(.*?)</form>', body, re.DOTALL | re.IGNORECASE)
        for form_tag, form_body in forms[:3]:
            action_m = re.search(r'action=["\']([^"\']*)["\']', form_tag, re.IGNORECASE)
            if action_m and action_m.group(1).startswith("http://") and self.scheme == "https":
                self._add("PG-FORM", "Page Form", f"HTTP Form Action on {page_path}", SEV_HIGH,
                    f"Form on {page_path} submits over HTTP.",
                    f"Action: {action_m.group(1)}", "", "CWE-319",
                    "Use HTTPS for form actions.")
            method_m = re.search(r'method=["\']post["\']', form_tag, re.IGNORECASE)
            if method_m:
                if not re.search(r'(?:csrf|_token|authenticity_token)', form_body, re.IGNORECASE):
                    self._add("PG-FORM", "Page Form", f"No CSRF Token on {page_path}", SEV_MED,
                        f"POST form on {page_path} has no CSRF protection.",
                        f"URL: {page_url}", "", "CWE-352",
                        "Add CSRF token to all forms.")
                    break

        sqli_payloads = ["'", "1 OR 1=1--"]
        sql_errors = ["sql", "syntax", "mysql", "postgresql", "sqlite", "SQLSTATE"]
        for payload in sqli_payloads[:2]:
            test_url = f"{page_url}?q={urllib.parse.quote(payload)}"
            r = self._req(test_url)
            rbl = r["body"].lower()
            found = [e for e in sql_errors if e.lower() in rbl]
            if found:
                self._add("PG-SQLI", "Page SQL Injection", f"SQLi on {page_path}", SEV_HIGH,
                    f"SQL error triggered on {page_path}.",
                    f"Payload: {payload}\nIndicators: {', '.join(found)}",
                    r["body"][:500], "CWE-89",
                    "Use parameterized queries.")
                break

        xss_payload = '<script>alert(1)</script>'
        xss_url = f"{page_url}?q={urllib.parse.quote(xss_payload)}"
        xss_r = self._req(xss_url)
        if xss_payload in xss_r["body"]:
            self._add("PG-XSS", "Page XSS", f"Reflected XSS on {page_path}", SEV_HIGH,
                f"XSS payload reflected unescaped on {page_path}.",
                f"Payload reflected in response", xss_r["body"][:500], "CWE-79",
                "HTML-encode all output.")

        sensitive_comments = []
        for comment in re.findall(r'<!--(.*?)-->', body, re.DOTALL):
            c = comment.strip().lower()
            if any(w in c for w in ["password", "secret", "key", "token", "todo", "fixme",
                                     "hack", "bug", "admin", "debug", "api"]) and len(comment.strip()) > 5:
                sensitive_comments.append(comment.strip()[:100])
        if sensitive_comments:
            self._add("PG-LEAK", "Page Info Leak", f"Sensitive Comments on {page_path}", SEV_LOW,
                f"{len(sensitive_comments)} sensitive HTML comments on {page_path}.",
                "\n".join(sensitive_comments[:5]), "", "CWE-615",
                "Remove sensitive comments from HTML.")

        js_secrets = re.findall(
            r'(?:api[_-]?key|apiKey|token|secret|password|auth)\s*[:=]\s*["\']([^"\']{8,})["\']', body)
        if js_secrets:
            self._add("PG-JS", "Page JS Secrets", f"Hardcoded Secrets on {page_path}", SEV_HIGH,
                f"{len(js_secrets)} potential secrets in JavaScript on {page_path}.",
                f"Found {len(js_secrets)} secrets", "", "CWE-798",
                "Move secrets to server-side environment variables.")

        for method in ["PUT", "DELETE"]:
            mr = self._req(page_url, method=method)
            if mr["status"] in (200, 201, 204):
                self._add("PG-HTTP", "Page Methods", f"{method} Accepted on {page_path}", SEV_MED,
                    f"{method} method accepted on {page_path}.",
                    f"{method} {page_url} → {mr['status']}", "", "CWE-749",
                    f"Disable {method} on {page_path} or require authentication.")
                break

        cors_r = self._req(page_url, headers={"Origin": "https://evil-attacker.com"})
        acao = cors_r["headers"].get("Access-Control-Allow-Origin",
               cors_r["headers"].get("access-control-allow-origin", ""))
        if acao == "https://evil-attacker.com":
            acac = cors_r["headers"].get("Access-Control-Allow-Credentials",
                   cors_r["headers"].get("access-control-allow-credentials", ""))
            sev = SEV_HIGH if acac.lower() == "true" else SEV_MED
            self._add("PG-CORS", "Page CORS", f"CORS Reflects Origin on {page_path}", sev,
                f"Arbitrary origin reflected on {page_path}." +
                (" With credentials." if acac.lower() == "true" else ""),
                f"ACAO: {acao}", "", "CWE-942",
                "Whitelist specific trusted origins.")

    def run_all(self, subpages=None):
        print(f"\n  Target:      {self.target_url}")
        print(f"  Hostname:    {self.hostname}")
        print(f"  Mode:        {'Deep' if self.deep else 'Standard'} Scan")
        print(f"  Max retries: {MAX_ATTEMPTS} per vulnerability type")
        if subpages:
            print(f"  Subpages:    {len(subpages)} discovered pages")
        print()

        self.base_resp = self._req(self.target_url)

        checks = [
            ("SSL/TLS Certificate & Protocol", self._check_ssl),
            ("TLS Cipher Strength", self._check_tls_ciphers),
            ("HTTP Security Headers", self._check_security_headers),
            ("Content Security Policy (CSP)", self._check_csp_deep),
            ("HSTS Configuration", self._check_hsts),
            ("Server Information Disclosure", self._check_server_info),
            ("Technology Stack Fingerprinting", self._check_tech_fingerprint),
            ("Cookie Security Flags", self._check_cookies),
            ("CORS Misconfiguration", self._check_cors),
            ("Directory Traversal / Path Manipulation", self._check_directory_traversal),
            ("Local File Inclusion (LFI)", self._check_lfi),
            ("SQL Injection Probes", self._check_sqli),
            ("NoSQL Injection Probes", self._check_nosqli),
            ("Cross-Site Scripting (XSS)", self._check_xss),
            ("DOM-Based XSS Indicators", self._check_dom_xss),
            ("Open Redirect", self._check_open_redirect),
            ("Server-Side Request Forgery (SSRF)", self._check_ssrf),
            ("Command Injection Indicators", self._check_command_injection),
            ("XML External Entity (XXE)", self._check_xxe),
            ("Sensitive File Exposure", self._check_sensitive_files),
            ("Git Repository Exposure", self._check_git_exposure),
            ("Environment File Exposure", self._check_env_exposure),
            ("Backup & Archive Files", self._check_backup_files),
            ("Debug & Log File Exposure", self._check_debug_logs),
            ("HTTP Method Tampering", self._check_http_methods),
            ("HTTP Verb Tunneling", self._check_verb_tunneling),
            ("Authentication Bypass", self._check_auth_bypass),
            ("Default/Admin Credential Probes", self._check_default_creds),
            ("Session Security", self._check_session_security),
            ("API Endpoint Discovery", self._check_api_endpoints),
            ("API Documentation Exposure", self._check_api_docs),
            ("GraphQL Introspection", self._check_graphql),
            ("Error Handling & Stack Traces", self._check_error_handling),
            ("Information Leakage in HTML", self._check_html_leaks),
            ("JavaScript Security Issues", self._check_js_security),
            ("Rate Limiting", self._check_rate_limiting),
            ("Clickjacking / Framing", self._check_clickjacking),
            ("Host Header Injection", self._check_host_header),
            ("HTTP Request Smuggling", self._check_request_smuggling),
            ("Cache Poisoning", self._check_cache_poisoning),
            ("HTTPS Enforcement", self._check_https_enforcement),
            ("Cross-Domain Policy", self._check_crossdomain),
            ("MIME Type Security", self._check_mime),
            ("Subresource Integrity", self._check_sri),
            ("Form Security", self._check_form_security),
            ("Email Header Injection", self._check_email_injection),
            ("CRLF Injection", self._check_crlf),
            ("HTTP Parameter Pollution", self._check_hpp),
            ("Insecure Deserialization Indicators", self._check_deserialization),
            ("WordPress / CMS Detection", self._check_cms),
        ]

        if self.deep:
            checks.extend([
                ("Port Scan (30 Common Ports)", self._deep_port_scan),
                ("DNS Record Analysis", self._deep_dns),
                ("Subdomain Enumeration (Common)", self._deep_subdomains),
                ("Web Application Firewall (WAF) Detection", self._deep_waf_detect),
                ("HTTP/2 & Protocol Support", self._deep_protocol),
                ("Security.txt & Robots.txt Analysis", self._deep_security_txt),
                ("Sitemap Analysis", self._deep_sitemap),
                ("Third-Party Script Risk", self._deep_third_party),
                ("Mixed Content Detection", self._deep_mixed_content),
                ("Database Port Exposure", self._deep_db_ports),
            ])

        total = len(checks)
        for i, (name, func) in enumerate(checks, 1):
            print(f"  [{i:2d}/{total}] {name}...", end="", flush=True)
            try:
                func()
                print(" \033[32mdone\033[0m")
            except Exception as e:
                print(f" \033[31merror: {str(e)[:50]}\033[0m")
            self.stats["total_tests"] += 1

        if subpages and len(subpages) > 1:
            extra_pages = [p for p in subpages if p.rstrip("/") != self.target_url.rstrip("/")]
            if extra_pages:
                print(f"\n  \033[33m── SCANNING {len(extra_pages)} SUBPAGES ──\033[0m\n")
                for idx, page_url in enumerate(extra_pages, 1):
                    page_path = urllib.parse.urlparse(page_url).path or "/"
                    print(f"  [{idx:3d}/{len(extra_pages)}] {page_path}...", end="", flush=True)
                    try:
                        self.scan_subpage(page_url)
                        print(" \033[32mdone\033[0m")
                    except Exception as e:
                        print(f" \033[31merror: {str(e)[:50]}\033[0m")
                    self.stats["total_tests"] += 1

        self._analyze_connections()
        self.stats["end"] = time.time()
        self.stats["pages_scanned"] = len(subpages) if subpages else 1
        return self.findings

    # ── SSL/TLS ──────────────────────────────────────────────────
    def _check_ssl(self):
        if self.scheme != "https":
            self._add("SSL", "SSL/TLS", "No HTTPS", SEV_HIGH,
                "Site does not use HTTPS. All traffic transmitted in cleartext.",
                f"Scheme: {self.scheme}", "", "CWE-319",
                "Enable HTTPS with a valid TLS certificate from a trusted CA.")
            return
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((self.hostname, self.port), timeout=TIMEOUT) as sock:
                with ctx.wrap_socket(sock, server_hostname=self.hostname) as ssock:
                    cert = ssock.getpeercert()
                    ver = ssock.version()
                    ciph = ssock.cipher()

                    if ver and ver in ("SSLv2", "SSLv3", "TLSv1", "TLSv1.1"):
                        self._add("SSL", "SSL/TLS", f"Deprecated Protocol: {ver}", SEV_HIGH,
                            f"Server negotiated {ver}, which has known vulnerabilities (POODLE, BEAST, etc.).",
                            f"Protocol: {ver}, Cipher: {ciph}", "", "CWE-326",
                            "Disable SSLv2, SSLv3, TLSv1.0, TLSv1.1. Require TLSv1.2+.")

                    if cert:
                        na = cert.get("notAfter", "")
                        if na:
                            try:
                                from email.utils import parsedate_to_datetime
                                exp = parsedate_to_datetime(na)
                                days = (exp - datetime.now(exp.tzinfo)).days
                                if days < 0:
                                    self._add("SSL", "SSL/TLS", "Expired Certificate", SEV_CRIT,
                                        f"SSL certificate expired {abs(days)} days ago.",
                                        f"Expiry: {na}", "", "CWE-295",
                                        "Renew immediately.")
                                elif days < 14:
                                    self._add("SSL", "SSL/TLS", f"Certificate Expiring ({days}d)", SEV_MED,
                                        f"Certificate expires in {days} days.",
                                        f"Expiry: {na}", "", "CWE-295", "Renew certificate.")
                            except:
                                pass

                        san = cert.get("subjectAltName", ())
                        names = [v for t, v in san if t == "DNS"]
                        if names and self.hostname not in names and not any(
                            n.startswith("*.") and self.hostname.endswith(n[1:]) for n in names
                        ):
                            self._add("SSL", "SSL/TLS", "Hostname Mismatch", SEV_HIGH,
                                f"Certificate does not cover {self.hostname}.",
                                f"SANs: {', '.join(names)}", "", "CWE-295",
                                "Issue certificate that includes the correct hostname.")

                    self.log.add("SSL/TLS", self.target_url, "CONNECT",
                        200, f"Protocol={ver} Cipher={ciph}")
        except ssl.SSLCertVerificationError as e:
            self._add("SSL", "SSL/TLS", "Certificate Verification Failed", SEV_HIGH,
                "SSL certificate failed validation (self-signed, wrong host, or untrusted CA).",
                str(e), "", "CWE-295", "Use a certificate from a trusted CA.")
        except Exception as e:
            self.log.add("SSL/TLS", self.target_url, "CONNECT", 0, str(e))

    def _check_tls_ciphers(self):
        if self.scheme != "https":
            return
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((self.hostname, self.port), timeout=TIMEOUT) as sock:
                with ctx.wrap_socket(sock, server_hostname=self.hostname) as ssock:
                    ciph = ssock.cipher()
                    if ciph:
                        cn = ciph[0]
                        bits = ciph[2] if len(ciph) > 2 else 0
                        weak = ["RC4", "DES", "3DES", "NULL", "EXPORT", "anon", "MD5", "RC2"]
                        for w in weak:
                            if w.lower() in cn.lower():
                                self._add("SSL", "Cipher Strength", f"Weak Cipher: {cn}", SEV_MED,
                                    f"Weak cipher {cn} negotiated ({bits} bits).",
                                    f"Cipher: {ciph}", "", "CWE-327",
                                    "Disable weak ciphers. Use AES-GCM or ChaCha20.")
                                break
                        if bits and bits < 128:
                            self._add("SSL", "Cipher Strength", f"Low Key Length: {bits}-bit", SEV_MED,
                                f"Cipher key length only {bits} bits.",
                                f"Cipher: {cn}", "", "CWE-326",
                                "Use 128-bit or 256-bit cipher suites.")
                        self.log.add("Cipher Check", self.target_url, "TLS",
                            200, f"{cn} {bits}bits")
        except:
            pass

    # ── HEADERS ──────────────────────────────────────────────────
    def _check_security_headers(self):
        resp = self.base_resp or self._req(self.target_url)
        if resp["status"] == 0:
            return
        h = {k.lower(): v for k, v in resp["headers"].items()}
        self.log.add("Headers", self.target_url, "GET", resp["status"],
            json.dumps({k: v for k, v in h.items()
                        if any(x in k for x in ["security", "x-", "strict", "content-security",
                                                 "referrer", "permission", "feature"])}, indent=2))

        required = {
            "strict-transport-security": ("HSTS Missing", SEV_MED, "CWE-319",
                "No HSTS. Browsers won't enforce HTTPS-only.",
                "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains"),
            "x-content-type-options": ("X-Content-Type-Options Missing", SEV_LOW, "CWE-693",
                "MIME sniffing not prevented.", "Add: X-Content-Type-Options: nosniff"),
            "x-frame-options": ("X-Frame-Options Missing", SEV_MED, "CWE-1021",
                "Clickjacking not blocked via X-Frame-Options.",
                "Add: X-Frame-Options: DENY"),
            "referrer-policy": ("Referrer-Policy Missing", SEV_LOW, "CWE-200",
                "No referrer policy. URLs leak to third-party sites.",
                "Add: Referrer-Policy: strict-origin-when-cross-origin"),
            "permissions-policy": ("Permissions-Policy Missing", SEV_LOW, "CWE-693",
                "Camera, microphone, geolocation not restricted.",
                "Add Permissions-Policy to restrict browser features."),
            "x-permitted-cross-domain-policies": ("X-Permitted-Cross-Domain Missing", SEV_LOW, "CWE-942",
                "Flash/PDF cross-domain policy not restricted.",
                "Add: X-Permitted-Cross-Domain-Policies: none"),
        }
        for hdr, (name, sev, cwe, desc, fix) in required.items():
            if hdr not in h:
                self._add("HDR", "Security Headers", name, sev, desc,
                    f"Missing: {hdr}", "", cwe, fix)

    def _check_csp_deep(self):
        resp = self.base_resp or self._req(self.target_url)
        h = {k.lower(): v for k, v in resp["headers"].items()}
        csp = h.get("content-security-policy", "")
        if not csp:
            self._add("CSP", "Content Security Policy", "No CSP Header", SEV_MED,
                "No Content-Security-Policy. XSS attacks not mitigated by browser policy.",
                "Header missing", "", "CWE-693",
                "Implement a strict Content-Security-Policy.")
            return

        if "'unsafe-inline'" in csp:
            self._add("CSP", "CSP", "CSP Allows unsafe-inline", SEV_MED,
                "Inline scripts/styles allowed, weakening XSS protection.",
                f"CSP: {csp[:300]}", "", "CWE-79",
                "Use nonce-based or hash-based CSP instead of unsafe-inline.")
        if "'unsafe-eval'" in csp:
            self._add("CSP", "CSP", "CSP Allows unsafe-eval", SEV_MED,
                "eval() permitted by CSP. Enables dynamic code execution.",
                f"CSP: {csp[:300]}", "", "CWE-79",
                "Remove unsafe-eval. Refactor code to avoid eval().")
        if "data:" in csp:
            self._add("CSP", "CSP", "CSP Allows data: URIs", SEV_LOW,
                "data: URIs allowed in CSP. Can be used for XSS payloads.",
                f"CSP: {csp[:300]}", "", "CWE-79",
                "Remove data: from script-src and object-src directives.")
        if "*" in csp.split("script-src")[1] if "script-src" in csp else "":
            self._add("CSP", "CSP", "CSP script-src Wildcard", SEV_HIGH,
                "Wildcard in script-src allows scripts from any domain.",
                f"CSP: {csp[:300]}", "", "CWE-79",
                "Restrict script-src to specific trusted domains.")

    def _check_hsts(self):
        resp = self.base_resp or self._req(self.target_url)
        h = {k.lower(): v for k, v in resp["headers"].items()}
        hsts = h.get("strict-transport-security", "")
        if not hsts:
            return
        ma = re.search(r'max-age=(\d+)', hsts)
        if ma:
            age = int(ma.group(1))
            if age < 15768000:
                self._add("HDR", "HSTS", f"HSTS max-age Too Short ({age}s)", SEV_LOW,
                    f"HSTS max-age is only {age} seconds ({age//86400} days). Should be 1 year+.",
                    f"HSTS: {hsts}", "", "CWE-319",
                    "Set max-age=31536000 (1 year) minimum.")
        if "includesubdomains" not in hsts.lower():
            self._add("HDR", "HSTS", "HSTS Missing includeSubDomains", SEV_LOW,
                "HSTS does not cover subdomains. Subdomain traffic may be unencrypted.",
                f"HSTS: {hsts}", "", "CWE-319",
                "Add includeSubDomains to HSTS header.")

    def _check_server_info(self):
        resp = self.base_resp or self._req(self.target_url)
        h = {k.lower(): v for k, v in resp["headers"].items()}
        server = h.get("server", "")
        if server and re.search(r'[\d.]+', server):
            self._add("INFO", "Information Disclosure", f"Server Version: {server}", SEV_LOW,
                "Server header reveals software version.",
                f"Server: {server}", "", "CWE-200",
                "Remove version from Server header.")
        xpb = h.get("x-powered-by", "")
        if xpb:
            self._add("INFO", "Information Disclosure", f"X-Powered-By: {xpb}", SEV_LOW,
                "Technology stack exposed via header.",
                f"X-Powered-By: {xpb}", "", "CWE-200",
                "Remove X-Powered-By header.")
        asp = h.get("x-aspnet-version", "")
        if asp:
            self._add("INFO", "Information Disclosure", f"ASP.NET Version: {asp}", SEV_LOW,
                "ASP.NET version disclosed.", f"X-AspNet-Version: {asp}", "", "CWE-200",
                "Remove X-AspNet-Version header.")

    def _check_tech_fingerprint(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        techs_found = []

        patterns = [
            (r'<meta[^>]+name=["\']generator["\'][^>]+content=["\'](.*?)["\']', "Generator Meta"),
            (r'wp-content/', "WordPress"),
            (r'wp-includes/', "WordPress"),
            (r'/joomla', "Joomla"),
            (r'drupal\.js', "Drupal"),
            (r'shopify\.com', "Shopify"),
            (r'react', "React"),
            (r'__next', "Next.js"),
            (r'__nuxt', "Nuxt.js"),
            (r'ng-version', "Angular"),
            (r'vue\.js|vue\.min\.js|__vue__', "Vue.js"),
            (r'jquery[\-.]?\d', "jQuery"),
            (r'bootstrap[\-.]?\d', "Bootstrap"),
            (r'laravel', "Laravel"),
            (r'django', "Django"),
            (r'express', "Express.js"),
            (r'phpmyadmin', "phpMyAdmin"),
        ]

        for pattern, tech in patterns:
            if re.search(pattern, body, re.IGNORECASE):
                techs_found.append(tech)

        if techs_found:
            self._add("INFO", "Technology Fingerprint",
                f"Stack Detected: {', '.join(set(techs_found))}", SEV_INFO,
                "Technology stack identified from HTML/headers. Aids targeted attacks.",
                f"Technologies: {', '.join(set(techs_found))}", "", "CWE-200",
                "Minimize technology disclosure in HTML source.")
            self.log.add("Tech Fingerprint", self.target_url, "GET",
                resp["status"], f"Found: {', '.join(set(techs_found))}")

    # ── COOKIES ──────────────────────────────────────────────────
    def _check_cookies(self):
        resp = self._req(self.target_url)
        raw = self._get_all_set_cookies(resp.get("raw_headers"))
        if not raw:
            return

        for cookie_str in raw:
            parts = cookie_str.split(";")
            name_part = parts[0].strip()
            name = name_part.split("=")[0].strip() if "=" in name_part else "unknown"
            lower = cookie_str.lower()

            if "secure" not in lower and self.scheme == "https":
                self._add("COOKIE", "Cookie Security", f"'{name}' Missing Secure", SEV_MED,
                    f"Cookie '{name}' sent over HTTP. Can be intercepted on unencrypted connections.",
                    f"Set-Cookie: {cookie_str[:200]}", "", "CWE-614",
                    "Add Secure flag.")
            if "httponly" not in lower and any(x in name.lower() for x in
                    ["sess", "token", "auth", "sid", "jwt", "id", "login"]):
                self._add("COOKIE", "Cookie Security", f"'{name}' Missing HttpOnly", SEV_MED,
                    f"Session-like cookie '{name}' accessible via JavaScript. XSS can steal it.",
                    f"Set-Cookie: {cookie_str[:200]}", "", "CWE-1004",
                    "Add HttpOnly flag to session cookies.")
            if "samesite" not in lower:
                self._add("COOKIE", "Cookie Security", f"'{name}' Missing SameSite", SEV_LOW,
                    f"Cookie '{name}' lacks SameSite. May enable CSRF attacks.",
                    f"Set-Cookie: {cookie_str[:200]}", "", "CWE-352",
                    "Add SameSite=Lax or SameSite=Strict.")
            if "__host-" in name.lower() and "secure" not in lower:
                self._add("COOKIE", "Cookie Security", f"'{name}' __Host- Prefix Violation", SEV_MED,
                    "__Host- prefixed cookie must have Secure flag.",
                    f"Set-Cookie: {cookie_str[:200]}", "", "CWE-614",
                    "Ensure __Host- cookies have Secure and Path=/.")

        self.log.add("Cookies", self.target_url, "GET", resp["status"],
            "; ".join(raw)[:500])

    # ── CORS ─────────────────────────────────────────────────────
    def _check_cors(self):
        origins = ["https://evil-attacker.com", "null", self.target_url]
        for origin in origins[:MAX_ATTEMPTS]:
            resp = self._req(self.target_url, headers={"Origin": origin})
            acao = resp["headers"].get("Access-Control-Allow-Origin",
                   resp["headers"].get("access-control-allow-origin", ""))
            acac = resp["headers"].get("Access-Control-Allow-Credentials",
                   resp["headers"].get("access-control-allow-credentials", ""))
            self.log.add("CORS", self.target_url, "GET", resp["status"],
                f"Origin={origin} ACAO={acao} ACAC={acac}",
                acao == "*" or (acao == origin and origin != self.target_url))

            if acao == "*" and acac.lower() == "true":
                self._add("CORS", "CORS", "Wildcard + Credentials", SEV_CRIT,
                    "Any site can make authenticated cross-origin requests. Full data theft possible.",
                    f"ACAO: * with ACAC: true", "", "CWE-942",
                    "Never combine * with credentials.")
                return
            if acao == origin and origin == "https://evil-attacker.com":
                sev = SEV_HIGH if acac.lower() == "true" else SEV_MED
                self._add("CORS", "CORS", "Reflects Arbitrary Origin", sev,
                    "Server mirrors any Origin header." +
                    (" With credentials — full account takeover." if acac.lower() == "true" else ""),
                    f"Origin: {origin} → ACAO: {acao}", "", "CWE-942",
                    "Whitelist specific trusted origins only.")
                return
            if acao == "null":
                self._add("CORS", "CORS", "Allows null Origin", SEV_MED,
                    "Server accepts null origin. Sandboxed pages can make cross-origin requests.",
                    f"ACAO: null", "", "CWE-942",
                    "Do not allow null origin in CORS.")
                return

    # ── INJECTION ATTACKS ────────────────────────────────────────
    def _check_directory_traversal(self):
        payloads = [
            ("../../../etc/passwd", "root:"),
            ("..\\..\\..\\windows\\win.ini", "[fonts]"),
            ("....//....//....//etc/passwd", "root:"),
        ]
        for payload, indicator in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/{payload}"
            resp = self._req(url)
            hit = indicator in resp["body"] and resp["status"] == 200
            self.log.add("Path Traversal", url, "GET", resp["status"],
                resp["body"][:200], hit)
            if hit:
                self._add("TRAV", "Path Traversal", "File Read via Traversal", SEV_CRIT,
                    "System files readable via path traversal. Full file system access possible.",
                    f"Payload: {payload}\nIndicator: {indicator}", resp["body"][:500],
                    "CWE-22", "Sanitize paths. Use os.path.realpath() and validate against root.")
                return

    def _check_lfi(self):
        payloads = [
            "php://filter/convert.base64-encode/resource=index",
            "/proc/self/environ",
            "....//....//....//etc/shadow",
        ]
        for payload in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?file={urllib.parse.quote(payload)}"
            resp = self._req(url)
            body = resp["body"]
            hit = any(x in body for x in ["root:", "HOME=", "PATH=", "PD9waH"]) and resp["status"] == 200
            self.log.add("LFI", url, "GET", resp["status"], body[:200], hit)
            if hit:
                self._add("LFI", "Local File Inclusion", "LFI Detected", SEV_CRIT,
                    "Local files included via parameter. Can read source code, credentials, system files.",
                    f"Payload: {payload}", body[:500], "CWE-98",
                    "Never use user input in file paths. Whitelist allowed files.")
                return

    def _check_sqli(self):
        sql_errors = ["sql", "syntax", "mysql", "postgresql", "sqlite", "oracle",
                      "ORA-", "PG::", "SQLSTATE", "ODBC", "unclosed quotation",
                      "quoted string not properly terminated", "sql server"]
        payloads = ["'", "1 OR 1=1--", "' UNION SELECT NULL--"]
        params = ["id", "q", "search", "user", "page", "item"]

        for payload in payloads[:MAX_ATTEMPTS]:
            for param in params[:2]:
                url = f"{self.target_url}/?{param}={urllib.parse.quote(payload)}"
                resp = self._req(url)
                bl = resp["body"].lower()
                found = [e for e in sql_errors if e.lower() in bl]
                self.log.add("SQLi", url, "GET", resp["status"], resp["body"][:300], bool(found))
                if found:
                    self._add("SQLI", "SQL Injection", f"SQL Error Disclosure ({param}=)", SEV_HIGH,
                        f"SQL error triggered by '{payload}'. Parameter '{param}' may be injectable.",
                        f"Indicators: {', '.join(found)}", resp["body"][:500], "CWE-89",
                        "Use parameterized queries. Never concatenate user input into SQL.")
                    return

    def _check_nosqli(self):
        payloads = [
            ("[$ne]=1", ["error", "castError", "ObjectId"]),
            ("[$gt]=", ["MongoError", "mongo", "bson"]),
            ('{"$where":"sleep(100)"}', ["MongoError", "mongo"]),
        ]
        for payload, indicators in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?id{payload}"
            resp = self._req(url)
            bl = resp["body"].lower()
            found = [i for i in indicators if i.lower() in bl]
            self.log.add("NoSQLi", url, "GET", resp["status"], resp["body"][:200], bool(found))
            if found:
                self._add("NOSQL", "NoSQL Injection", "NoSQL Error Disclosure", SEV_HIGH,
                    "NoSQL error messages returned. MongoDB/NoSQL injection may be possible.",
                    f"Indicators: {', '.join(found)}", resp["body"][:500], "CWE-943",
                    "Sanitize NoSQL query inputs. Use parameterized queries.")
                return

    def _check_xss(self):
        payloads = [
            '<script>alert("XSS")</script>',
            '"><img src=x onerror=alert(1)>',
            "'-alert(1)-'",
        ]
        for payload in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?q={urllib.parse.quote(payload)}"
            resp = self._req(url)
            reflected = payload in resp["body"]
            self.log.add("XSS", url, "GET", resp["status"], resp["body"][:300], reflected)
            if reflected:
                self._add("XSS", "Cross-Site Scripting", "Reflected XSS", SEV_HIGH,
                    "Input reflected unescaped in HTML. Script injection possible.",
                    f"Payload reflected: {payload}", resp["body"][:500], "CWE-79",
                    "HTML-encode all output. Implement strict CSP.")
                return

    def _check_dom_xss(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        sinks = [
            (r'\.innerHTML\s*=', "innerHTML"),
            (r'document\.write\s*\(', "document.write"),
            (r'\.outerHTML\s*=', "outerHTML"),
            (r'eval\s*\(', "eval()"),
            (r'setTimeout\s*\(\s*["\']', "setTimeout with string"),
            (r'setInterval\s*\(\s*["\']', "setInterval with string"),
            (r'location\s*=', "location assignment"),
            (r'\.insertAdjacentHTML\s*\(', "insertAdjacentHTML"),
        ]
        found_sinks = []
        for pattern, name in sinks:
            if re.search(pattern, body):
                found_sinks.append(name)
        if found_sinks:
            self._add("XSS", "DOM XSS", f"DOM XSS Sinks: {', '.join(found_sinks[:5])}", SEV_LOW,
                "JavaScript DOM manipulation sinks found. If user input reaches these, DOM XSS is possible.",
                f"Sinks: {', '.join(found_sinks)}", "", "CWE-79",
                "Use textContent instead of innerHTML. Avoid eval() and document.write().")

    def _check_open_redirect(self):
        targets = ["https://evil-attacker.com", "//evil-attacker.com", "/\\evil-attacker.com"]
        params = ["url", "redirect", "next", "return", "returnUrl", "goto", "dest", "continue"]
        for target in targets[:MAX_ATTEMPTS]:
            for param in params[:3]:
                url = f"{self.target_url}/?{param}={urllib.parse.quote(target)}"
                resp = self._req(url)
                loc = resp["headers"].get("Location", resp["headers"].get("location", ""))
                self.log.add("OpenRedirect", url, "GET", resp["status"], f"Location: {loc}",
                    "evil-attacker" in loc)
                if "evil-attacker" in loc:
                    self._add("REDIR", "Open Redirect", "Open Redirect", SEV_MED,
                        f"Redirect to external domain via '{param}' parameter. Enables phishing.",
                        f"{param}={target} → {loc}", "", "CWE-601",
                        "Validate redirect URLs against an allowlist.")
                    return

    def _check_ssrf(self):
        payloads = [
            f"{self.target_url}/?url=http://169.254.169.254/latest/meta-data/",
            f"{self.target_url}/?url=http://127.0.0.1:22",
            f"{self.target_url}/?url=http://[::1]/",
        ]
        cloud_indicators = ["ami-id", "instance-id", "iam", "metadata", "security-credentials"]
        for url in payloads[:MAX_ATTEMPTS]:
            resp = self._req(url)
            bl = resp["body"].lower()
            found = [i for i in cloud_indicators if i in bl]
            self.log.add("SSRF", url, "GET", resp["status"], resp["body"][:200], bool(found))
            if found:
                self._add("SSRF", "SSRF", "Cloud Metadata Accessible", SEV_CRIT,
                    "Server fetches internal URLs. Cloud instance metadata exposed (AWS/GCP/Azure keys).",
                    f"Indicators: {', '.join(found)}", resp["body"][:500], "CWE-918",
                    "Block internal/cloud IPs. Validate and whitelist fetch targets.")
                return

    def _check_command_injection(self):
        payloads = [
            (";id", ["uid=", "gid="]),
            ("|id", ["uid=", "gid="]),
            ("$(id)", ["uid=", "gid="]),
        ]
        for payload, indicators in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?cmd={urllib.parse.quote(payload)}"
            resp = self._req(url)
            found = [i for i in indicators if i in resp["body"]]
            self.log.add("CmdInj", url, "GET", resp["status"], resp["body"][:200], bool(found))
            if found:
                self._add("CMDI", "Command Injection", "OS Command Execution", SEV_CRIT,
                    "Server executes OS commands from user input. Full system compromise.",
                    f"Payload: {payload}", resp["body"][:500], "CWE-78",
                    "Never pass user input to system commands. Use safe APIs.")
                return

    def _check_xxe(self):
        xxe_payload = '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>'
        resp = self._req(self.target_url, method="POST", data=xxe_payload,
            headers={"Content-Type": "application/xml"})
        self.log.add("XXE", self.target_url, "POST", resp["status"], resp["body"][:300],
            "root:" in resp["body"])
        if "root:" in resp["body"]:
            self._add("XXE", "XML External Entity", "XXE — File Read", SEV_CRIT,
                "XML parser processes external entities. System files readable.",
                "Entity resolved: /etc/passwd", resp["body"][:500], "CWE-611",
                "Disable external entity processing in XML parsers.")

    # ── FILE EXPOSURE ────────────────────────────────────────────
    def _check_sensitive_files(self):
        files = [
            ("robots.txt", ["Disallow", "Allow"], SEV_INFO, "Robots.txt reveals hidden paths."),
            (".well-known/security.txt", ["Contact"], SEV_INFO, "Security contact info found."),
            ("package.json", ['"dependencies"', '"name"'], SEV_LOW, "Package manifest exposed."),
            ("composer.json", ['"require"'], SEV_LOW, "PHP dependencies exposed."),
            ("Gemfile", ["gem "], SEV_LOW, "Ruby dependencies exposed."),
            ("requirements.txt", ["=="], SEV_LOW, "Python dependencies exposed."),
            ("web.config", ["configuration"], SEV_MED, "IIS config exposed."),
            ("crossdomain.xml", ["allow-access"], SEV_MED, "Flash cross-domain policy found."),
            ("phpinfo.php", ["PHP Version"], SEV_HIGH, "phpinfo() exposed — full server details."),
            ("server-status", ["Apache Server Status"], SEV_HIGH, "Apache status page exposed."),
            ("server-info", ["Apache Server Information"], SEV_HIGH, "Apache info page exposed."),
            ("elmah.axd", ["Error Log"], SEV_HIGH, "ELMAH error log exposed."),
            (".htpasswd", [":$"], SEV_CRIT, "Password hash file exposed."),
            ("wp-config.php.bak", ["DB_PASSWORD"], SEV_CRIT, "WordPress config backup exposed."),
            ("config.php.bak", ["password"], SEV_CRIT, "Config backup exposed."),
            ("dump.sql", ["INSERT INTO"], SEV_CRIT, "Database dump publicly accessible."),
            ("database.sql", ["CREATE TABLE"], SEV_CRIT, "Database file publicly accessible."),
            (".npmrc", ["//registry"], SEV_HIGH, "NPM config with tokens exposed."),
            (".dockerenv", [], SEV_LOW, "Running in Docker container."),
            ("Dockerfile", ["FROM"], SEV_MED, "Dockerfile exposed — build process revealed."),
            ("docker-compose.yml", ["services"], SEV_MED, "Docker Compose exposed."),
            (".aws/credentials", ["aws_access"], SEV_CRIT, "AWS credentials file exposed."),
            ("wp-login.php", ["WordPress"], SEV_INFO, "WordPress login page found."),
            ("admin/", ["admin", "login", "dashboard"], SEV_INFO, "Admin panel detected."),
            ("_debug/", ["debug"], SEV_MED, "Debug endpoint detected."),
        ]
        for fpath, indicators, severity, desc in files:
            url = f"{self.target_url}/{fpath}"
            resp = self._req(url)
            if resp["status"] == 200 and len(resp["body"]) > 10:
                bl = resp["body"].lower()
                found = [i for i in indicators if i.lower() in bl]
                if found or (severity in (SEV_CRIT, SEV_HIGH) and len(resp["body"]) > 20):
                    self._add("FILE", "Sensitive File", f"Exposed: {fpath}", severity, desc,
                        f"URL: {url}\nMatched: {', '.join(found) if found else 'file accessible'}",
                        resp["body"][:500], "CWE-538",
                        f"Block access to {fpath}. Remove from web root.")
                    self.log.add("File Exposure", url, "GET", resp["status"],
                        resp["body"][:200], True)
                else:
                    self.log.add("File Exposure", url, "GET", resp["status"], "No match", False)
            else:
                self.log.add("File Exposure", url, "GET", resp["status"], "Not found", False)

    def _check_git_exposure(self):
        git_paths = [".git/config", ".git/HEAD", ".git/index"]
        for gp in git_paths[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/{gp}"
            resp = self._req(url)
            hit = resp["status"] == 200 and any(x in resp["body"]
                for x in ["[core]", "ref:", "repositoryformatversion", "DIRC"])
            self.log.add("Git", url, "GET", resp["status"], resp["body"][:200], hit)
            if hit:
                self._add("GIT", "Git Exposure", f"Git Repository Exposed: {gp}", SEV_CRIT,
                    "Git repository is publicly accessible. Entire source code can be downloaded.",
                    f"URL: {url}", resp["body"][:500], "CWE-538",
                    "Block access to .git/ directory. Add to server config deny rules.")
                return

    def _check_env_exposure(self):
        env_files = [".env", ".env.local", ".env.production", ".env.backup",
                     ".env.development", ".env.staging", ".env.old"]
        env_indicators = ["DB_", "API_KEY", "SECRET", "PASSWORD", "TOKEN", "PRIVATE",
                          "AWS_", "STRIPE", "SENDGRID", "REDIS", "MONGO"]
        for ef in env_files[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/{ef}"
            resp = self._req(url)
            if resp["status"] == 200:
                found = [i for i in env_indicators if i in resp["body"].upper()]
                if found:
                    self._add("ENV", "Env File Exposure", f"Exposed: {ef}", SEV_CRIT,
                        f"Environment file contains secrets: {', '.join(found)}. Full credential theft.",
                        f"URL: {url}\nKeys: {', '.join(found)}", resp["body"][:500],
                        "CWE-256", f"Block access to {ef}. Rotate all exposed credentials.")
                    self.log.add("Env", url, "GET", resp["status"], "EXPOSED", True)
                    return
            self.log.add("Env", url, "GET", resp["status"], "Not found", False)

    def _check_backup_files(self):
        targets = [
            "/index.html.bak", "/index.php.bak", "/index.php~",
            "/config.bak", "/app.bak", "/database.bak",
            "/site.tar.gz", "/backup.tar.gz", "/backup.zip",
            "/www.zip", "/public.zip", "/htdocs.zip",
        ]
        for path in targets[:MAX_ATTEMPTS]:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200 and len(resp["body"]) > 50:
                self._add("BAK", "Backup File", f"Backup Accessible: {path}", SEV_HIGH,
                    "Backup/archive file publicly accessible. May contain source code and credentials.",
                    f"URL: {url}", "", "CWE-530",
                    "Remove backup files from web root.")
                self.log.add("Backup", url, "GET", resp["status"], "Found", True)
                return
            self.log.add("Backup", url, "GET", resp["status"], "Not found", False)

    def _check_debug_logs(self):
        logs = ["/debug.log", "/error.log", "/access.log", "/app.log",
                "/logs/error.log", "/log/error.log", "/tmp/logs/",
                "/trace.axd", "/debug/vars", "/actuator/env"]
        for path in logs[:MAX_ATTEMPTS]:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200 and len(resp["body"]) > 50:
                bl = resp["body"].lower()
                if any(x in bl for x in ["error", "exception", "stack", "trace",
                                          "warning", "debug", "log"]):
                    self._add("LOG", "Debug/Log Exposure", f"Log File: {path}", SEV_MED,
                        "Log file publicly accessible. May contain errors, IPs, credentials.",
                        f"URL: {url}", resp["body"][:500], "CWE-532",
                        f"Block access to {path}.")
                    self.log.add("Logs", url, "GET", resp["status"], "Exposed", True)
                    return
            self.log.add("Logs", url, "GET", resp["status"], "Not found", False)

    # ── HTTP METHODS ─────────────────────────────────────────────
    def _check_http_methods(self):
        resp_options = self._req(self.target_url, method="OPTIONS")
        allow = resp_options["headers"].get("Allow", resp_options["headers"].get("allow", ""))
        self.log.add("Methods", self.target_url, "OPTIONS", resp_options["status"], f"Allow: {allow}")

        for method in ["PUT", "DELETE", "TRACE"][:MAX_ATTEMPTS]:
            resp = self._req(self.target_url, method=method)
            self.log.add("Methods", self.target_url, method, resp["status"], resp["body"][:200],
                resp["status"] in (200, 201, 204))
            if method == "TRACE" and resp["status"] == 200 and "TRACE" in resp["body"]:
                self._add("HTTP", "HTTP Methods", "TRACE Enabled", SEV_MED,
                    "TRACE method enabled. Enables Cross-Site Tracing (XST) — cookie theft via XSS.",
                    f"TRACE returned {resp['status']}", resp["body"][:300], "CWE-693",
                    "Disable TRACE method.")
            elif method == "PUT" and resp["status"] in (200, 201, 204):
                self._add("HTTP", "HTTP Methods", "PUT Accepted", SEV_HIGH,
                    "PUT method accepted. Arbitrary file upload may be possible.",
                    f"PUT returned {resp['status']}", "", "CWE-749",
                    "Disable PUT or require authentication.")
            elif method == "DELETE" and resp["status"] in (200, 204):
                self._add("HTTP", "HTTP Methods", "DELETE Accepted", SEV_HIGH,
                    "DELETE method accepted. Resources may be deletable without auth.",
                    f"DELETE returned {resp['status']}", "", "CWE-749",
                    "Disable DELETE or require authentication.")

    def _check_verb_tunneling(self):
        resp = self._req(self.target_url, method="POST",
            headers={"X-HTTP-Method-Override": "DELETE"})
        self.log.add("Verb Tunnel", self.target_url, "POST+Override", resp["status"],
            resp["body"][:200], resp["status"] in (200, 204))
        if resp["status"] in (200, 204):
            base = self._req(self.target_url, method="POST")
            if base["status"] != resp["status"]:
                self._add("HTTP", "HTTP Verb Tunneling", "Method Override Accepted", SEV_MED,
                    "X-HTTP-Method-Override converts POST to DELETE. Can bypass method restrictions.",
                    f"POST + X-HTTP-Method-Override: DELETE → {resp['status']}",
                    "", "CWE-749",
                    "Ignore X-HTTP-Method-Override header or validate it.")

    # ── AUTH ─────────────────────────────────────────────────────
    def _check_auth_bypass(self):
        admin_paths = ["/admin", "/dashboard", "/api/admin", "/management", "/admin/config"]
        bypass_headers = [
            ({"X-Forwarded-For": "127.0.0.1"}, "X-Forwarded-For spoof"),
            ({"X-Original-URL": "/admin"}, "X-Original-URL override"),
            ({"X-Custom-IP-Authorization": "127.0.0.1"}, "X-Custom-IP-Auth"),
        ]
        for path in admin_paths[:2]:
            url = f"{self.target_url}{path}"
            base = self._req(url)
            if base["status"] not in (401, 403):
                continue
            for hdrs, technique in bypass_headers[:MAX_ATTEMPTS]:
                resp = self._req(url, headers=hdrs)
                bypassed = (resp["status"] == 200 and
                           len(resp["body"]) > len(base["body"]) + 100)
                self.log.add("AuthBypass", url, "GET", resp["status"],
                    f"{technique}: {base['status']}→{resp['status']}", bypassed)
                if bypassed:
                    self._add("AUTH", "Auth Bypass", f"Bypass via {technique}", SEV_CRIT,
                        f"{path} accessible by spoofing {technique}.",
                        f"Normal: {base['status']} → With header: {resp['status']}",
                        resp["body"][:300], "CWE-287",
                        "Implement server-side auth. Don't trust proxy headers for access control.")
                    return

    def _check_default_creds(self):
        login_paths = ["/admin", "/login", "/wp-login.php", "/administrator",
                       "/user/login", "/api/login"]
        found_login = None
        for path in login_paths[:MAX_ATTEMPTS]:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200:
                bl = resp["body"].lower()
                if any(x in bl for x in ["password", "login", "sign in", "username",
                                          "email", "authenticate"]):
                    found_login = (path, url, resp)
                    self._add("AUTH", "Login Page", f"Login Page Found: {path}", SEV_INFO,
                        "Login page publicly accessible. Target for brute force attacks.",
                        f"URL: {url}", "", "CWE-307",
                        "Implement account lockout, CAPTCHA, and rate limiting on login.")
                    self.log.add("Login", url, "GET", resp["status"], "Login form found", True)
                    break

        if found_login:
            path, url, resp = found_login
            default_creds = [
                ("admin", "admin"), ("admin", "password"), ("admin", "123456"),
            ]
            for username, password in default_creds[:MAX_ATTEMPTS]:
                cred_resp = self._req(url, method="POST",
                    data=urllib.parse.urlencode({"username": username, "password": password,
                                                 "email": username, "login": username}),
                    headers={"Content-Type": "application/x-www-form-urlencoded"})
                bl = cred_resp["body"].lower()
                success = (cred_resp["status"] in (200, 302) and
                          any(x in bl for x in ["dashboard", "welcome", "logout", "profile",
                                                 "successfully", "logged in"]) and
                          not any(x in bl for x in ["invalid", "incorrect", "failed", "wrong",
                                                     "error", "denied"]))
                self.log.add("DefaultCreds", url, "POST", cred_resp["status"],
                    f"{username}:{password} → success={success}", success)
                if success:
                    self._add("AUTH", "Default Credentials", f"Default Login: {username}/{password}", SEV_CRIT,
                        f"Default credentials {username}:{password} accepted. Full account takeover.",
                        f"URL: {url}\nCredentials: {username}:{password}",
                        "", "CWE-798",
                        "Change default credentials immediately. Enforce strong passwords.")
                    return

    def _check_session_security(self):
        resp = self._req(self.target_url)
        cookies = resp["headers"].get("Set-Cookie", "")
        if not cookies:
            return

        session_patterns = ["sess", "jsessionid", "phpsessid", "asp.net_sessionid",
                           "connect.sid", "sid=", "token"]
        for pat in session_patterns:
            if pat.lower() in cookies.lower():
                if re.search(r'(?:sess|sid|token)[^=]*=([a-f0-9]{16,})', cookies, re.IGNORECASE):
                    match = re.search(r'(?:sess|sid|token)[^=]*=([a-f0-9]{16,})', cookies, re.IGNORECASE)
                    token = match.group(1)
                    if len(token) < 32:
                        self._add("SESS", "Session Security", "Short Session Token", SEV_MED,
                            f"Session token only {len(token)} hex chars. May be brute-forceable.",
                            f"Token length: {len(token)}", "", "CWE-330",
                            "Use 128+ bit session tokens (32+ hex chars).")
                break

    # ── API ──────────────────────────────────────────────────────
    def _check_api_endpoints(self):
        api_paths = ["/api", "/api/v1", "/api/v2", "/api/health",
                     "/api/status", "/api/config", "/api/users",
                     "/api/admin", "/api/debug", "/api/internal",
                     "/api/test", "/api/dev"]
        for path in api_paths:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200 and len(resp["body"]) > 20:
                self.log.add("API", url, "GET", resp["status"], resp["body"][:200], True)
                if path in ("/api/config", "/api/internal", "/api/debug"):
                    self._add("API", "API Exposure", f"Sensitive API: {path}", SEV_HIGH,
                        f"Internal API endpoint {path} publicly accessible.",
                        f"URL: {url}", resp["body"][:500], "CWE-200",
                        f"Restrict {path} to authenticated users.")
                elif path in ("/api/users", "/api/admin"):
                    self._add("API", "API Exposure", f"User/Admin API: {path}", SEV_MED,
                        f"API endpoint {path} accessible without authentication.",
                        f"URL: {url}", resp["body"][:500], "CWE-284",
                        f"Require authentication for {path}.")
            else:
                self.log.add("API", url, "GET", resp["status"], "Not found", False)

    def _check_api_docs(self):
        doc_paths = ["/swagger.json", "/openapi.json", "/api-docs",
                     "/swagger-ui.html", "/swagger/", "/redoc",
                     "/.well-known/openid-configuration"]
        for path in doc_paths[:MAX_ATTEMPTS]:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200 and len(resp["body"]) > 50:
                self._add("API", "API Documentation", f"API Docs Exposed: {path}", SEV_MED,
                    "API documentation publicly accessible. Reveals all endpoints and parameters.",
                    f"URL: {url}", resp["body"][:500], "CWE-200",
                    "Restrict API documentation to authenticated users.")
                self.log.add("API Docs", url, "GET", resp["status"], "Exposed", True)
                return
            self.log.add("API Docs", url, "GET", resp["status"], "Not found", False)

    def _check_graphql(self):
        gql_paths = ["/graphql", "/api/graphql", "/gql"]
        introspection = '{"query":"{ __schema { types { name } } }"}'
        for path in gql_paths[:MAX_ATTEMPTS]:
            url = f"{self.target_url}{path}"
            resp = self._req(url, method="POST", data=introspection,
                headers={"Content-Type": "application/json"})
            if resp["status"] == 200 and "__schema" in resp["body"]:
                self._add("GQL", "GraphQL", "GraphQL Introspection Enabled", SEV_MED,
                    "GraphQL introspection enabled. Entire API schema discoverable.",
                    f"URL: {url}", resp["body"][:500], "CWE-200",
                    "Disable introspection in production.")
                self.log.add("GraphQL", url, "POST", resp["status"], "Introspection enabled", True)
                return
            self.log.add("GraphQL", url, "POST", resp["status"], "Not found", False)

    # ── ERROR HANDLING ───────────────────────────────────────────
    def _check_error_handling(self):
        triggers = [
            f"{self.target_url}/{'A' * 5000}",
            f"{self.target_url}/%00",
            f"{self.target_url}/?id=1'",
        ]
        stack_words = ["stack trace", "traceback", "at line", "exception",
                       "fatal error", "unhandled", "node_modules", "at Object.",
                       "at Module.", "stacktrace", "NullPointerException",
                       "java.lang.", "System.Exception", "Microsoft.AspNetCore",
                       "in /var/www", "on line ", "syntax error"]
        for url in triggers[:MAX_ATTEMPTS]:
            resp = self._req(url)
            bl = resp["body"].lower()
            found = [w for w in stack_words if w.lower() in bl]
            self.log.add("ErrorHandling", url[:80], "GET", resp["status"],
                resp["body"][:300], bool(found))
            if found and resp["status"] >= 400:
                self._add("ERR", "Error Handling", "Stack Trace Leaked", SEV_MED,
                    "Error reveals internal details: file paths, line numbers, framework versions.",
                    f"Indicators: {', '.join(found[:5])}", resp["body"][:500], "CWE-209",
                    "Use custom error pages. Never show stack traces in production.")
                return

    # ── HTML/JS ANALYSIS ─────────────────────────────────────────
    def _check_html_leaks(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        leaks = []

        comments = re.findall(r'<!--(.*?)-->', body, re.DOTALL)
        for comment in comments:
            c = comment.strip()
            sensitive = ["password", "secret", "key", "token", "api", "todo", "fixme",
                         "hack", "bug", "admin", "debug", "test", "credential"]
            for s in sensitive:
                if s in c.lower() and len(c) > 5:
                    leaks.append(f"HTML Comment: ...{c[:100]}...")
                    break

        email_pattern = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', body)
        for email in email_pattern[:3]:
            if not any(x in email for x in ["example.com", "test.com", "placeholder"]):
                leaks.append(f"Email: {email}")

        ip_pattern = re.findall(r'\b(?:10|172\.(?:1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}\b', body)
        for ip in ip_pattern[:3]:
            leaks.append(f"Internal IP: {ip}")

        if leaks:
            self._add("HTML", "HTML Information Leaks",
                f"{len(leaks)} Leaks in HTML Source", SEV_LOW,
                "Sensitive information found in HTML source code.",
                "\n".join(leaks[:10]), "", "CWE-615",
                "Remove sensitive comments, emails, and internal IPs from HTML.")

    def _check_js_security(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]

        scripts = re.findall(r'<script[^>]*src=["\'](.*?)["\']', body)
        http_scripts = [s for s in scripts if s.startswith("http://")]
        if http_scripts and self.scheme == "https":
            self._add("JS", "JavaScript Security", "HTTP Script on HTTPS Page", SEV_MED,
                "Scripts loaded over HTTP on HTTPS page. Man-in-the-middle can inject code.",
                f"HTTP scripts: {', '.join(http_scripts[:5])}", "", "CWE-829",
                "Load all scripts over HTTPS.")

        js_secrets = re.findall(
            r'(?:api[_-]?key|apiKey|token|secret|password|auth)\s*[:=]\s*["\']([^"\']{8,})["\']',
            body)
        if js_secrets:
            self._add("JS", "JavaScript Security", f"Hardcoded Secrets in JS ({len(js_secrets)})", SEV_HIGH,
                "API keys, tokens, or secrets hardcoded in client-side JavaScript.",
                f"Found {len(js_secrets)} potential secrets", "", "CWE-798",
                "Move secrets to server-side. Use environment variables.")

        if "sourceMappingURL" in body:
            self._add("JS", "JavaScript Security", "Source Maps Exposed", SEV_LOW,
                "JavaScript source maps available. Original source code recoverable.",
                "sourceMappingURL found", "", "CWE-540",
                "Remove source maps from production builds.")

    # ── RATE LIMITING ────────────────────────────────────────────
    def _check_rate_limiting(self):
        statuses = []
        for _ in range(MAX_ATTEMPTS):
            resp = self._req(self.target_url)
            statuses.append(resp["status"])
            rl = {k: v for k, v in resp["headers"].items()
                  if "ratelimit" in k.lower() or "retry-after" in k.lower()}
            self.log.add("RateLimit", self.target_url, "GET", resp["status"],
                json.dumps(rl) if rl else "No rate limit headers")

        if all(s == 200 for s in statuses):
            has_rl = any("ratelimit" in k.lower() for k in resp["headers"])
            if not has_rl:
                self._add("RATE", "Rate Limiting", "No Rate Limiting Detected", SEV_LOW,
                    "No rate limit headers. Brute force and DDoS attacks not mitigated.",
                    f"{MAX_ATTEMPTS} requests all returned 200", "", "CWE-770",
                    "Implement rate limiting with X-RateLimit headers.")

    # ── FRAMING / CLICKJACKING ───────────────────────────────────
    def _check_clickjacking(self):
        resp = self.base_resp or self._req(self.target_url)
        h = {k.lower(): v for k, v in resp["headers"].items()}
        xfo = "x-frame-options" in h
        csp_fa = "frame-ancestors" in h.get("content-security-policy", "")
        if not xfo and not csp_fa:
            self._add("FRAME", "Clickjacking", "No Frame Protection", SEV_MED,
                "Site can be embedded in iframes. Clickjacking attacks possible.",
                "Missing X-Frame-Options AND CSP frame-ancestors", "", "CWE-1021",
                "Add X-Frame-Options: DENY or CSP frame-ancestors 'none'.")

    # ── HOST HEADER ──────────────────────────────────────────────
    def _check_host_header(self):
        tests = [
            ({"Host": "evil-attacker.com"}, "Host"),
            ({"X-Forwarded-Host": "evil-attacker.com"}, "X-Forwarded-Host"),
            ({"Host": f"{self.hostname}\r\nX-Injected: true"}, "Host CRLF"),
        ]
        for hdrs, technique in tests[:MAX_ATTEMPTS]:
            resp = self._req(self.target_url, headers=hdrs)
            reflected = "evil-attacker" in resp["body"]
            self.log.add("HostHeader", self.target_url, "GET", resp["status"],
                f"{technique}: reflected={reflected}", reflected)
            if reflected:
                self._add("HOST", "Host Header Injection", f"Reflected via {technique}", SEV_MED,
                    f"Injected {technique} reflected in page. Enables cache poisoning and password reset hijacking.",
                    f"{technique}: evil-attacker.com reflected", resp["body"][:300],
                    "CWE-644", "Validate Host header. Use server name for URL generation.")
                return

    # ── SMUGGLING / POISONING ────────────────────────────────────
    def _check_request_smuggling(self):
        smuggle_tests = [
            ("CL.TE",
             f"POST / HTTP/1.1\r\nHost: {self.hostname}\r\n"
             f"Content-Length: 6\r\nTransfer-Encoding: chunked\r\n\r\n"
             f"0\r\n\r\nX"),
            ("TE.CL",
             f"POST / HTTP/1.1\r\nHost: {self.hostname}\r\n"
             f"Transfer-Encoding: chunked\r\nContent-Length: 4\r\n\r\n"
             f"1\r\nZ\r\n0\r\n\r\n"),
            ("TE.TE",
             f"POST / HTTP/1.1\r\nHost: {self.hostname}\r\n"
             f"Transfer-Encoding: chunked\r\nTransfer-Encoding: identity\r\n"
             f"Content-Length: 4\r\n\r\n0\r\n\r\n"),
        ]
        for technique, payload in smuggle_tests[:MAX_ATTEMPTS]:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                if self.scheme == "https":
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    sock = ctx.wrap_socket(sock, server_hostname=self.hostname)
                sock.connect((self.hostname, self.port))
                sock.sendall(payload.encode())
                start = time.time()
                data = sock.recv(4096).decode("utf-8", errors="ignore")
                elapsed = time.time() - start
                sock.close()

                anomaly = elapsed > 8 or "400" not in data[:20]
                self.log.add("Smuggling", self.target_url, technique, 0,
                    f"elapsed={elapsed:.1f}s response={data[:150]}", anomaly)

                if elapsed > 8:
                    self._add("SMUG", "Request Smuggling", f"Possible {technique} Smuggling", SEV_HIGH,
                        f"Server timeout ({elapsed:.1f}s) on {technique} probe. May indicate request smuggling vulnerability.",
                        f"Technique: {technique}\nDelay: {elapsed:.1f}s",
                        data[:300], "CWE-444",
                        "Normalize Transfer-Encoding handling. Use HTTP/2 end-to-end.")
                    return
            except Exception as e:
                self.log.add("Smuggling", self.target_url, technique, 0, str(e)[:100])

    def _check_cache_poisoning(self):
        tests = [
            {"X-Forwarded-Host": "evil-attacker.com"},
            {"X-Forwarded-Scheme": "nothttps"},
            {"X-Original-URL": "/evil-cache"},
        ]
        for hdrs in tests[:MAX_ATTEMPTS]:
            resp = self._req(self.target_url, headers=hdrs)
            key = list(hdrs.keys())[0]
            reflected = "evil" in resp["body"]
            self.log.add("CachePoison", self.target_url, "GET", resp["status"],
                f"{key}: reflected={reflected}", reflected)
            if reflected:
                self._add("CACHE", "Cache Poisoning", f"Poisonable via {key}", SEV_HIGH,
                    f"{key} header reflected. CDN/proxy cache can be poisoned with malicious content.",
                    f"{key} → reflected in response", resp["body"][:300], "CWE-444",
                    f"Ignore {key}. Configure cache to exclude unkeyed headers.")
                return

    # ── HTTPS ────────────────────────────────────────────────────
    def _check_https_enforcement(self):
        if self.scheme != "https":
            return
        http_url = self.target_url.replace("https://", "http://")
        try:
            req = urllib.request.Request(http_url, headers=self.base_headers)
            resp = urllib.request.urlopen(req, timeout=TIMEOUT)
            if "https" not in resp.url:
                self._add("HTTPS", "HTTPS", "No HTTP→HTTPS Redirect", SEV_MED,
                    "HTTP requests not redirected to HTTPS. Users may connect insecurely.",
                    f"http:// serves content without redirect", "", "CWE-319",
                    "Add HTTP 301 redirect to HTTPS.")
        except urllib.error.HTTPError as e:
            if 300 <= e.code < 400:
                loc = e.headers.get("Location", "")
                if "https" in loc:
                    self.log.add("HTTPS", http_url, "GET", e.code, f"→ {loc}", False)
        except:
            pass

    # ── CROSSDOMAIN / MIME / SRI ─────────────────────────────────
    def _check_crossdomain(self):
        url = f"{self.target_url}/crossdomain.xml"
        resp = self._req(url)
        if resp["status"] == 200 and "allow-access-from" in resp["body"]:
            if 'domain="*"' in resp["body"]:
                self._add("XDOM", "Cross-Domain Policy", "Wildcard crossdomain.xml", SEV_MED,
                    "Flash cross-domain policy allows any domain. Data theft via Flash/Silverlight.",
                    f"domain=\"*\"", resp["body"][:300], "CWE-942",
                    "Restrict to specific trusted domains or remove crossdomain.xml.")

    def _check_mime(self):
        resp = self.base_resp or self._req(self.target_url)
        h = {k.lower(): v for k, v in resp["headers"].items()}
        xcto = h.get("x-content-type-options", "")
        ct = h.get("content-type", "")

        if xcto.lower() != "nosniff":
            self._add("MIME", "MIME Security", "X-Content-Type-Options Not Set to nosniff", SEV_LOW,
                "Browser may MIME-sniff responses, treating uploads as executable scripts.",
                f"X-Content-Type-Options: {xcto or '(missing)'}\nContent-Type: {ct}",
                "", "CWE-693",
                "Add header: X-Content-Type-Options: nosniff")

        if not ct:
            self._add("MIME", "MIME Security", "No Content-Type Header", SEV_LOW,
                "Missing Content-Type header. Browser guesses content type, enabling attacks.",
                "Content-Type header absent", "", "CWE-693",
                "Set explicit Content-Type header on all responses.")
        elif "charset" not in ct.lower() and "html" in ct.lower():
            self._add("MIME", "MIME Security", "Content-Type Missing Charset", SEV_LOW,
                "HTML served without charset declaration. May enable encoding-based XSS.",
                f"Content-Type: {ct}", "", "CWE-79",
                "Add charset=utf-8 to Content-Type header.")

    def _check_sri(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        ext_scripts = re.findall(r'<script[^>]+src=["\']https?://(?!(?:' +
            re.escape(self.hostname) + r'))[^"\']+["\'][^>]*>', body)
        no_integrity = [s for s in ext_scripts if "integrity=" not in s]
        if no_integrity and len(no_integrity) >= 2:
            self._add("SRI", "Subresource Integrity", f"{len(no_integrity)} External Scripts Without SRI",
                SEV_LOW,
                "External scripts loaded without integrity hashes. CDN compromise injects code.",
                f"Scripts without SRI: {len(no_integrity)}",
                "\n".join(no_integrity[:3]), "CWE-829",
                "Add integrity= and crossorigin= attributes to external scripts.")

    # ── FORM SECURITY ────────────────────────────────────────────
    def _check_form_security(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]

        forms_full = re.findall(r'(<form[^>]*>)(.*?)</form>', body, re.DOTALL | re.IGNORECASE)
        for form_tag, form_body in forms_full[:3]:
            form_all = form_tag + form_body

            if re.search(r'type=["\']password["\']', form_all, re.IGNORECASE):
                if 'autocomplete="off"' not in form_all.lower() and 'autocomplete="new-password"' not in form_all.lower():
                    self._add("FORM", "Form Security", "Password Autocomplete Enabled", SEV_LOW,
                        "Password field allows browser autocomplete. Shared computers at risk.",
                        "Password input without autocomplete=off", "", "CWE-522",
                        "Add autocomplete=\"off\" to password fields.")

            action_match = re.search(r'action=["\']([^"\']*)["\']', form_tag, re.IGNORECASE)
            if action_match and action_match.group(1).startswith("http://") and self.scheme == "https":
                self._add("FORM", "Form Security", "Form Submits Over HTTP", SEV_HIGH,
                    "Form on HTTPS page submits data over HTTP. Credentials sent in cleartext.",
                    f"Form action: {action_match.group(1)}", "", "CWE-319",
                    "Use HTTPS for all form actions.")

            method_match = re.search(r'method=["\']post["\']', form_tag, re.IGNORECASE)
            if method_match:
                csrf_tokens = re.search(
                    r'(?:csrf|_token|authenticity_token|__RequestVerificationToken|csrfmiddlewaretoken)',
                    form_body, re.IGNORECASE)
                if not csrf_tokens:
                    self._add("FORM", "Form Security", "No CSRF Token in POST Form", SEV_MED,
                        "POST form without CSRF token. Cross-site request forgery possible.",
                        f"Form action: {action_match.group(1) if action_match else '(default)'}",
                        "", "CWE-352",
                        "Add CSRF tokens to all state-changing forms.")
                    break

    # ── INJECTION EXTRAS ─────────────────────────────────────────
    def _check_email_injection(self):
        payloads = [
            ("test@test.com%0ABcc:attacker@evil.com", ["bcc", "cc", "to"]),
            ("test@test.com%0d%0aSubject:Injected", ["subject", "injected"]),
            ("test@test.com\r\nBcc:attacker@evil.com", ["bcc"]),
        ]
        for payload, indicators in payloads[:MAX_ATTEMPTS]:
            for param in ["email", "to", "from", "contact"]:
                url = f"{self.target_url}/?{param}={urllib.parse.quote(payload)}"
                resp = self._req(url)
                bl = resp["body"].lower()
                h_lower = " ".join(f"{k}:{v}" for k, v in resp["headers"].items()).lower()
                found = [i for i in indicators if i in bl or i in h_lower]
                hit = bool(found) and resp["status"] in (200, 302)
                self.log.add("EmailInj", url, "GET", resp["status"],
                    resp["body"][:200], hit)
                if hit and any(i in h_lower for i in indicators):
                    self._add("EMAIL", "Email Header Injection", "Email Header Injection", SEV_HIGH,
                        "Email headers injected via user input. Spam/phishing can be sent from your server.",
                        f"Param: {param}\nPayload: {payload}\nIndicators: {', '.join(found)}",
                        "", "CWE-93",
                        "Strip newlines and carriage returns from all email-related inputs.")
                    return

    def _check_crlf(self):
        payloads = [
            "%0d%0aSet-Cookie:crlf=injected",
            "%0d%0aX-Injected:true",
            "\\r\\nX-Injected:true",
        ]
        for payload in payloads[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?redirect={payload}"
            resp = self._req(url)
            injected = ("crlf=injected" in resp["headers"].get("Set-Cookie", "") or
                       "X-Injected" in resp["headers"])
            self.log.add("CRLF", url, "GET", resp["status"],
                json.dumps({k: v for k, v in resp["headers"].items()
                           if "inject" in k.lower() or "crlf" in v.lower()}) if injected else "Clean",
                injected)
            if injected:
                self._add("CRLF", "CRLF Injection", "Header Injection via CRLF", SEV_HIGH,
                    "CRLF characters inject arbitrary HTTP headers. Cookie theft, cache poisoning.",
                    f"Payload: {payload}", "", "CWE-93",
                    "Strip \\r\\n from all user input used in headers or redirects.")
                return

    def _check_hpp(self):
        test_cases = [
            ("id=1&id=2", "Duplicate parameter"),
            ("role=user&role=admin", "Role escalation"),
            ("action=view&action=delete", "Action override"),
        ]
        for params, technique in test_cases[:MAX_ATTEMPTS]:
            url = f"{self.target_url}/?{params}"
            resp = self._req(url)
            base = self._req(f"{self.target_url}/?{params.split('&')[0]}")
            diff = abs(len(resp["body"]) - len(base["body"])) > 50 or resp["status"] != base["status"]
            self.log.add("HPP", url, "GET", resp["status"],
                f"{technique}: base_status={base['status']} dup_status={resp['status']} diff={diff}", diff)
            if diff and "admin" in params and resp["status"] == 200:
                self._add("HPP", "HTTP Parameter Pollution", f"HPP: {technique}", SEV_MED,
                    "Duplicate parameters processed differently. May bypass security controls.",
                    f"Params: {params}\nBase status: {base['status']}, Dup status: {resp['status']}",
                    "", "CWE-235",
                    "Use strict parameter parsing. Reject duplicate parameters.")
                return

    def _check_deserialization(self):
        payloads = [
            ('O:8:"stdClass":0:{}', "application/x-php-serialized"),
            ('{"@type":"java.lang.Runtime"}', "application/json"),
        ]
        for payload, ct in payloads[:MAX_ATTEMPTS]:
            resp = self._req(self.target_url, method="POST", data=payload,
                headers={"Content-Type": ct})
            bl = resp["body"].lower()
            danger = any(x in bl for x in ["unserialize", "java.lang", "classnotfound",
                                            "deserialization", "objectinputstream"])
            self.log.add("Deser", self.target_url, "POST", resp["status"],
                resp["body"][:200], danger)
            if danger:
                self._add("DESER", "Insecure Deserialization", "Deserialization Error Leaked", SEV_HIGH,
                    "Deserialization error messages exposed. May enable remote code execution.",
                    f"Content-Type: {ct}", resp["body"][:500], "CWE-502",
                    "Never deserialize untrusted data. Use safe formats like JSON.")
                return

    def _check_cms(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]

        if "wp-content" in body or "wp-includes" in body:
            readme = self._req(f"{self.target_url}/readme.html")
            if readme["status"] == 200 and "wordpress" in readme["body"].lower():
                self._add("CMS", "CMS Detection", "WordPress readme.html Exposed", SEV_LOW,
                    "WordPress readme.html reveals version. Target for known CVEs.",
                    f"URL: {self.target_url}/readme.html", readme["body"][:300],
                    "CWE-200", "Remove readme.html from WordPress root.")

            xmlrpc = self._req(f"{self.target_url}/xmlrpc.php", method="POST",
                data='<?xml version="1.0"?><methodCall><methodName>system.listMethods</methodName></methodCall>',
                headers={"Content-Type": "text/xml"})
            if xmlrpc["status"] == 200 and "methodResponse" in xmlrpc["body"]:
                self._add("CMS", "WordPress", "XML-RPC Enabled", SEV_MED,
                    "WordPress XML-RPC enabled. Allows brute force and DDoS amplification.",
                    f"URL: {self.target_url}/xmlrpc.php", xmlrpc["body"][:300],
                    "CWE-307", "Disable XML-RPC or restrict access.")

    # ── DEEP SCAN ────────────────────────────────────────────────
    def _deep_port_scan(self):
        ports = [
            (21, "FTP"), (22, "SSH"), (23, "Telnet"), (25, "SMTP"),
            (53, "DNS"), (80, "HTTP"), (110, "POP3"), (111, "rpcbind"),
            (135, "MSRPC"), (139, "NetBIOS"), (143, "IMAP"),
            (443, "HTTPS"), (445, "SMB"), (993, "IMAPS"),
            (995, "POP3S"), (1433, "MSSQL"), (1521, "Oracle"),
            (2049, "NFS"), (3306, "MySQL"), (3389, "RDP"),
            (5432, "PostgreSQL"), (5900, "VNC"), (5985, "WinRM"),
            (6379, "Redis"), (8080, "HTTP-Alt"), (8443, "HTTPS-Alt"),
            (9200, "Elasticsearch"), (9300, "ES-Transport"),
            (11211, "Memcached"), (27017, "MongoDB"),
        ]
        risky = {21, 23, 25, 111, 135, 139, 445, 1433, 1521, 2049, 3306,
                 3389, 5432, 5900, 5985, 6379, 9200, 9300, 11211, 27017}
        open_ports = []
        for port, svc in ports:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(2)
                r = s.connect_ex((self.hostname, port))
                s.close()
                if r == 0:
                    open_ports.append((port, svc))
                    self.log.add("Port", f"{self.hostname}:{port}", "TCP", 200, f"OPEN: {svc}",
                        port in risky)
                    if port in risky:
                        self._add("PORT", "Open Ports", f"Risky Port: {port}/{svc}", SEV_HIGH,
                            f"Port {port} ({svc}) open from internet. Direct attack surface.",
                            f"{self.hostname}:{port} OPEN", "", "CWE-284",
                            f"Close port {port} or restrict via firewall/security group.")
            except:
                pass
        if open_ports:
            self.log.add("Port Summary", self.hostname, "TCP", 200,
                f"Open: {', '.join(f'{p}/{s}' for p, s in open_ports)}")

    def _deep_dns(self):
        try:
            addrs = socket.getaddrinfo(self.hostname, None)
            ips = list(set(a[4][0] for a in addrs))
            ipv4 = [ip for ip in ips if ":" not in ip]
            ipv6 = [ip for ip in ips if ":" in ip]
            self.log.add("DNS", self.hostname, "DNS", 200,
                f"IPv4: {', '.join(ipv4)} IPv6: {', '.join(ipv6)}")

            for ip in ipv4:
                if ip.startswith(("10.", "172.16.", "172.17.", "172.18.", "172.19.",
                                  "172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
                                  "172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
                                  "172.30.", "172.31.", "192.168.")):
                    self._add("DNS", "DNS", f"Internal IP in DNS: {ip}", SEV_MED,
                        "DNS resolves to internal/private IP address. May indicate misconfiguration.",
                        f"IP: {ip}", "", "CWE-200",
                        "DNS should resolve to public IPs only.")
        except:
            pass

    def _deep_subdomains(self):
        common = ["www", "mail", "ftp", "admin", "api", "dev", "staging",
                   "test", "beta", "cdn", "app", "m", "blog", "shop"]
        found = []
        for sub in common:
            fqdn = f"{sub}.{self.hostname}"
            try:
                socket.getaddrinfo(fqdn, None)
                found.append(fqdn)
            except:
                pass
        if found:
            self.log.add("Subdomains", self.hostname, "DNS", 200,
                f"Found: {', '.join(found)}")
            dev_subs = [s for s in found if any(x in s for x in
                ["dev", "staging", "test", "beta"])]
            if dev_subs:
                self._add("SUB", "Subdomains", f"Dev Subdomains: {', '.join(dev_subs)}", SEV_LOW,
                    "Development/staging subdomains found. May have weaker security.",
                    f"Subdomains: {', '.join(dev_subs)}", "", "CWE-200",
                    "Restrict access to dev/staging subdomains.")

    def _deep_waf_detect(self):
        waf_payload = f"{self.target_url}/?q=<script>alert(1)</script>&id=1' OR 1=1--"
        resp = self._req(waf_payload)
        waf_indicators = {
            "cloudflare": ["cf-ray", "__cfduid", "cloudflare"],
            "aws-waf": ["x-amzn-requestid", "awselb"],
            "akamai": ["akamai", "x-akamai"],
            "sucuri": ["sucuri", "x-sucuri"],
            "mod_security": ["mod_security", "modsecurity"],
            "imperva": ["incap_ses", "x-iinfo"],
            "f5-bigip": ["x-cnection", "bigipserver"],
        }
        detected = []
        h_lower = {k.lower(): v.lower() for k, v in resp["headers"].items()}
        all_headers = " ".join(f"{k}={v}" for k, v in h_lower.items())
        for waf, indicators in waf_indicators.items():
            for ind in indicators:
                if ind in all_headers or ind in resp["body"].lower():
                    detected.append(waf)
                    break
        if detected:
            self._add("WAF", "WAF Detection", f"WAF Detected: {', '.join(detected)}", SEV_INFO,
                "Web Application Firewall identified. Provides additional protection layer.",
                f"WAFs: {', '.join(detected)}", "", "",
                "WAF is a positive security measure. Ensure it's properly configured.")
        if resp["status"] == 403:
            self.log.add("WAF", waf_payload[:80], "GET", resp["status"], "Blocked", False)

    def _deep_protocol(self):
        resp = self.base_resp or self._req(self.target_url)
        alt_svc = resp["headers"].get("Alt-Svc", resp["headers"].get("alt-svc", ""))
        if alt_svc:
            self.log.add("Protocol", self.target_url, "GET", resp["status"],
                f"Alt-Svc: {alt_svc}")
        if "h3" in alt_svc:
            self.log.add("Protocol", self.target_url, "INFO", 200, "HTTP/3 supported")

    def _deep_security_txt(self):
        for path in ["/.well-known/security.txt", "/security.txt"]:
            url = f"{self.target_url}{path}"
            resp = self._req(url)
            if resp["status"] == 200 and "contact" in resp["body"].lower():
                self.log.add("SecurityTxt", url, "GET", resp["status"], resp["body"][:300])
                return
        self._add("SEC", "Security.txt", "No security.txt", SEV_INFO,
            "No security.txt file. Researchers can't easily report vulnerabilities.",
            "Missing /.well-known/security.txt", "", "",
            "Create a security.txt with Contact and Expires fields.")

    def _deep_sitemap(self):
        url = f"{self.target_url}/sitemap.xml"
        resp = self._req(url)
        if resp["status"] == 200 and "<url>" in resp["body"].lower():
            urls_found = re.findall(r'<loc>(.*?)</loc>', resp["body"])
            admin_urls = [u for u in urls_found if any(x in u.lower()
                for x in ["admin", "login", "dashboard", "internal", "debug"])]
            if admin_urls:
                self._add("MAP", "Sitemap", f"Admin Paths in Sitemap ({len(admin_urls)})", SEV_LOW,
                    "Sitemap reveals admin/internal paths.",
                    f"Paths: {', '.join(admin_urls[:5])}", "", "CWE-200",
                    "Exclude admin paths from sitemap.xml.")
            self.log.add("Sitemap", url, "GET", resp["status"],
                f"{len(urls_found)} URLs found")

    def _deep_third_party(self):
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        ext = re.findall(r'(?:src|href)=["\']https?://([^/"\']+)', body)
        ext_domains = set(d for d in ext if self.hostname not in d)
        if len(ext_domains) > 10:
            self._add("3RD", "Third-Party Dependencies", f"{len(ext_domains)} External Domains", SEV_LOW,
                f"Page loads resources from {len(ext_domains)} external domains. Large attack surface.",
                f"Domains: {', '.join(list(ext_domains)[:10])}", "", "CWE-829",
                "Minimize third-party dependencies. Use SRI for external scripts.")
        self.log.add("ThirdParty", self.target_url, "GET", 200,
            f"{len(ext_domains)} external domains")

    def _deep_mixed_content(self):
        if self.scheme != "https":
            return
        resp = self.base_resp or self._req(self.target_url)
        body = resp["body"]
        http_res = re.findall(r'(?:src|href|action)=["\']http://[^"\']+["\']', body)
        if http_res:
            self._add("MIX", "Mixed Content", f"{len(http_res)} HTTP Resources on HTTPS Page", SEV_MED,
                "HTTPS page loads resources over HTTP. Content can be tampered with.",
                f"HTTP resources: {', '.join(http_res[:5])}", "", "CWE-319",
                "Use HTTPS for all resources. Use protocol-relative URLs.")

    def _deep_db_ports(self):
        db_ports = [(3306, "MySQL"), (5432, "PostgreSQL"), (1433, "MSSQL"),
                    (27017, "MongoDB"), (6379, "Redis"), (9200, "Elasticsearch"),
                    (5984, "CouchDB"), (8529, "ArangoDB")]
        for port, db in db_ports:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(2)
                r = s.connect_ex((self.hostname, port))
                s.close()
                if r == 0:
                    self._add("DB", "Database Exposure", f"{db} Port {port} Open", SEV_CRIT,
                        f"Database port {port} ({db}) accessible from internet. Direct data theft possible.",
                        f"{self.hostname}:{port} OPEN", "", "CWE-284",
                        f"Block port {port}. Databases must never be internet-facing.")
            except:
                pass

    # ── CONNECTION ANALYSIS ──────────────────────────────────────
    def _analyze_connections(self):
        if len(self.findings) < 2:
            return
        print(f"\n  Analyzing vulnerability connections ({len(self.findings)} findings)...", end="", flush=True)

        chain_rules = [
            (["XSS", "Cross-Site Scripting"], ["Cookie Security"],
             "XSS steals cookies missing HttpOnly flag → session hijack"),
            (["XSS", "Cross-Site Scripting", "DOM XSS"], ["CSP", "Content Security Policy"],
             "Missing/weak CSP allows XSS exploitation → script injection"),
            (["CORS"], ["Cookie Security", "Auth", "Session"],
             "CORS misconfiguration + weak cookies → cross-origin credential theft"),
            (["SQL Injection", "NoSQL Injection"], ["Error Handling"],
             "Error messages leak DB structure → aids injection attacks"),
            (["SQL Injection", "NoSQL Injection"], ["API Exposure"],
             "Injectable API endpoints → direct database access"),
            (["Open Redirect"], ["Auth", "Login"],
             "Redirect chains with login pages → phishing for credentials"),
            (["Path Traversal", "Local File Inclusion", "LFI"], ["Sensitive File", "Env File", "Git"],
             "Path traversal reaches exposed files → credential theft"),
            (["Information Disclosure", "Technology Fingerprint"], ["*HIGH*"],
             "Leaked tech stack info aids exploitation of high-severity vulns"),
            (["SSL/TLS", "Cipher"], ["Cookie Security"],
             "Weak TLS + insecure cookies → session hijacking via MITM"),
            (["CRLF Injection"], ["Cookie Security", "Cache"],
             "CRLF injects Set-Cookie headers → session fixation"),
            (["Host Header"], ["Cache Poisoning"],
             "Host header injection enables cache poisoning → mass user impact"),
            (["Open Ports", "Database Exposure"], ["SQL Injection", "Auth"],
             "Open DB port + SQL injection → direct data exfiltration"),
            (["HTTP Methods"], ["Auth", "API"],
             "Dangerous HTTP methods + weak auth → unauthorized data modification"),
            (["SSRF"], ["Open Ports", "Database", "API"],
             "SSRF chains with internal services → server-side data access"),
            (["Command Injection"], ["Information Disclosure"],
             "OS command execution + info disclosure → full system compromise"),
            (["Clickjacking", "Frame"], ["Form Security", "Auth"],
             "Clickjacking + login form → UI redress credential theft"),
            (["JavaScript Security"], ["XSS", "Cross-Site Scripting"],
             "Client-side secrets + XSS → API key theft"),
            (["Rate Limiting"], ["Auth", "Login", "Default"],
             "No rate limiting + login page → brute force attacks"),
            (["Mixed Content"], ["JavaScript Security"],
             "Mixed content + JS resources → MITM code injection"),
        ]

        seen_pairs = set()
        for f in self.findings:
            for src_cats, dst_cats, reason in chain_rules:
                src_match = any(sc.lower() in f.category.lower() or sc.lower() in f.name.lower()
                    for sc in src_cats)
                if not src_match:
                    continue
                for f2 in self.findings:
                    if f2 is f:
                        continue
                    pair_key = (f.fid, f2.fid, reason)
                    rev_key = (f2.fid, f.fid, reason)
                    if pair_key in seen_pairs or rev_key in seen_pairs:
                        continue
                    matched = False
                    if "*HIGH*" in dst_cats:
                        if f2.severity in (SEV_CRIT, SEV_HIGH):
                            matched = True
                    else:
                        dst_match = any(dc.lower() in f2.category.lower() or dc.lower() in f2.name.lower()
                            for dc in dst_cats)
                        if dst_match:
                            matched = True
                    if matched:
                        seen_pairs.add(pair_key)
                        f.connected = True
                        f.connection_chains.append(reason)
                        f2.connected = True
                        f2.connection_chains.append(reason)
                        self.stats["connections"] += 1

        for f in self.findings:
            f.connection_chains = list(set(f.connection_chains))

        print(" \033[32mdone\033[0m")


# ═══════════════════════════════════════════════════════════════
# REPORT GENERATOR
# ═══════════════════════════════════════════════════════════════

class ReportGenerator:
    def _e(self, text):
        if not text:
            return ""
        return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))

    def generate(self, target_url, findings, scan_log, stats, output_path):
        sev_order = [SEV_CRIT, SEV_HIGH, SEV_MED, SEV_LOW, SEV_INFO]
        sc = defaultdict(int)
        for f in findings:
            sc[f.severity] += 1
        connected = [f for f in findings if f.connected]
        cats = defaultdict(int)
        for f in findings:
            cats[f.category] += 1

        elapsed = stats["end"] - stats["start"]

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Alpha External Scan — {self._e(target_url)}</title>
<style>
*{{box-sizing:border-box;}}
body{{background:#0a0a0a;color:#e0e0e0;font-family:'Segoe UI',system-ui,Arial,sans-serif;padding:0;margin:0;line-height:1.6;}}
.wrap{{max-width:1500px;margin:0 auto;padding:20px;}}
::-webkit-scrollbar{{width:8px;}}
::-webkit-scrollbar-track{{background:#111;}}
::-webkit-scrollbar-thumb{{background:#333;border-radius:4px;}}
h1{{margin:0;font-size:26px;}}
h2{{margin:30px 0 12px;padding-bottom:8px;font-size:18px;}}
details>summary{{font-weight:bold;cursor:pointer;padding:6px 0;color:#ccc;}}
details>summary:hover{{color:#d4a017;}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:16px 0;}}
.stat{{background:#111;padding:14px 10px;border-radius:8px;text-align:center;border:1px solid #222;}}
.stat .n{{font-size:26px;font-weight:bold;}}
.stat .l{{color:#888;font-size:11px;margin-top:2px;}}
.finding{{background:#111;border-left:4px solid;padding:14px 16px;margin:8px 0;border-radius:4px;}}
.badge{{padding:2px 10px;border-radius:12px;font-size:11px;font-weight:bold;display:inline-block;}}
.conn-box{{background:#1a0000;border:1px solid #ff444466;padding:10px;border-radius:4px;margin-top:8px;}}
.log-table{{width:100%;border-collapse:collapse;font-size:11px;}}
.log-table th{{text-align:left;padding:7px;color:#d4a017;border-bottom:2px solid #333;position:sticky;top:0;background:#0a0a0a;}}
.log-table td{{padding:5px 7px;border-bottom:1px solid #151515;font-family:'Courier New',monospace;}}
.log-table tr:hover{{background:#141414;}}
.vuln-row{{background:#1a0000!important;}}
pre{{background:#050505;padding:10px;border-radius:4px;font-size:12px;overflow-x:auto;white-space:pre-wrap;word-break:break-all;color:#888;margin:6px 0;max-height:200px;overflow-y:auto;}}
.cat-bar{{display:flex;gap:4px;margin:8px 0;flex-wrap:wrap;}}
.cat-tag{{background:#1a1a1a;padding:4px 10px;border-radius:12px;font-size:11px;color:#ccc;}}
@media print{{body{{background:#fff;color:#000;}} .finding{{border:1px solid #ccc;}} pre{{background:#f5f5f5;color:#333;}}}}
</style>
</head>
<body>
<div class="wrap">

<div style="text-align:center;border-bottom:2px solid #d4a017;padding-bottom:18px;margin-bottom:24px;">
<div style="font-size:10px;color:#d4a017;letter-spacing:5px;margin-bottom:6px;">ALPHA UNLIMITED TECHNOLOGIES LLC — PROPRIETARY AND CONFIDENTIAL</div>
<h1>Alpha External Vulnerability Scan Report</h1>
<div style="color:#888;font-size:14px;margin:6px 0;">Target: <span style="color:#4ade80;font-family:monospace;">{self._e(target_url)}</span></div>
<div style="color:#555;font-size:12px;">
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |
Duration: {elapsed:.1f}s |
Tests: {stats['total_tests']} |
Requests: {stats['total_requests']} |
Vulnerabilities: {stats['vulnerabilities']} |
Connections: {stats['connections']}
</div>
</div>

<div class="grid">
<div class="stat"><div class="n" style="color:#4ade80;">{stats['total_tests']}</div><div class="l">Tests Run</div></div>
<div class="stat"><div class="n" style="color:#88ccff;">{stats['total_requests']}</div><div class="l">Requests</div></div>
<div class="stat" style="border-color:#ff2222;"><div class="n" style="color:#ff2222;">{sc.get(SEV_CRIT,0)}</div><div class="l">Critical</div></div>
<div class="stat" style="border-color:#ff8800;"><div class="n" style="color:#ff8800;">{sc.get(SEV_HIGH,0)}</div><div class="l">High</div></div>
<div class="stat" style="border-color:#ffcc00;"><div class="n" style="color:#ffcc00;">{sc.get(SEV_MED,0)}</div><div class="l">Medium</div></div>
<div class="stat" style="border-color:#4488ff;"><div class="n" style="color:#4488ff;">{sc.get(SEV_LOW,0)}</div><div class="l">Low</div></div>
<div class="stat"><div class="n" style="color:#888;">{sc.get(SEV_INFO,0)}</div><div class="l">Info</div></div>
<div class="stat" style="border-color:#d4a017;"><div class="n" style="color:#d4a017;">{len(connected)}</div><div class="l">Connected</div></div>
</div>

<div class="cat-bar">"""
        for cat, count in sorted(cats.items(), key=lambda x: -x[1]):
            html += f'<span class="cat-tag">{self._e(cat)}: {count}</span>'
        html += "</div>"

        if connected:
            html += """<h2 style="color:#ff4444;border-bottom:1px solid #ff444466;">VULNERABILITY CONNECTIONS</h2>
<p style="color:#888;font-size:12px;">These vulnerabilities are connected — one enables or amplifies another, creating attack chains.</p>"""
            seen_chains = set()
            for f in connected:
                for chain in f.connection_chains:
                    if chain not in seen_chains:
                        seen_chains.add(chain)
                        linked = [f2 for f2 in connected if chain in f2.connection_chains]
                        names = list(set(f2.name for f2 in linked))[:4]
                        html += f"""<div class="conn-box">
<div style="color:#ff8800;font-weight:bold;font-size:13px;">⚡ {self._e(chain)}</div>
<div style="color:#888;font-size:11px;margin-top:4px;">Linked: {self._e(' ↔ '.join(names))}</div>
</div>"""

        for severity in sev_order:
            sf = [f for f in findings if f.severity == severity]
            if not sf:
                continue
            color = SEV_COLORS_HTML[severity]
            html += f'<h2 style="color:{color};border-bottom:1px solid {color}44;">{severity} — {len(sf)} finding{"s" if len(sf)!=1 else ""}</h2>'

            for f in sf:
                conn_html = ""
                if f.connected and f.connection_chains:
                    chains = "".join(f'<div style="color:#ff8800;font-size:11px;margin:2px 0;">⚡ {self._e(c)}</div>'
                        for c in f.connection_chains[:5])
                    conn_html = f'<div class="conn-box"><div style="color:#ff4444;font-weight:bold;font-size:11px;">CONNECTED VULNERABILITIES:</div>{chains}</div>'

                html += f"""<div class="finding" style="border-color:{color};">
<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
<div><span style="color:#555;font-family:monospace;font-size:11px;">[{self._e(f.fid)}]</span> <span style="font-weight:bold;color:{color};font-size:14px;">[{self._e(f.category)}] {self._e(f.name)}</span></div>
<span class="badge" style="background:{color}22;color:{color};white-space:nowrap;">{severity}</span>
</div>
<div style="color:#666;font-size:11px;font-family:monospace;margin:4px 0;">{self._e(f.cwe)}{' | ' + f.timestamp if f.cwe else f.timestamp}</div>
<div style="color:#ccc;font-size:13px;margin:6px 0;">{self._e(f.description)}</div>
{'<pre>' + self._e(f.evidence) + '</pre>' if f.evidence else ''}
{'<details><summary style="font-size:12px;">Response Data</summary><pre style="color:#555;">' + self._e(f.response) + '</pre></details>' if f.response else ''}
<div style="color:#d4a017;font-size:12px;margin-top:6px;"><strong>Fix:</strong> {self._e(f.fix)}</div>
{conn_html}
</div>"""

        html += f"""<h2 style="color:#d4a017;border-bottom:1px solid #333;">FULL SCAN LOG — {len(scan_log.entries)} entries</h2>
<p style="color:#666;font-size:11px;">Every request and response recorded during the scan. Vulnerable entries highlighted in red.</p>
<div style="overflow-x:auto;">
<table class="log-table">
<tr><th>#</th><th>Time</th><th>Test</th><th>URL</th><th>Method</th><th>Status</th><th>Vuln?</th><th>Response</th></tr>"""

        for i, entry in enumerate(scan_log.entries, 1):
            rc = ' class="vuln-row"' if entry["vulnerable"] else ""
            vuln = '<span style="color:#ff2222;font-weight:bold;">YES</span>' if entry["vulnerable"] else '<span style="color:#4ade8066;">no</span>'
            status = entry["status"]
            sc_color = "#ff2222" if status >= 500 else "#ffcc00" if status >= 400 else "#4ade80" if status > 0 else "#555"
            html += f"""<tr{rc}>
<td style="color:#333;">{i}</td>
<td style="color:#555;">{entry['time']}</td>
<td style="color:#d4a017;">{self._e(entry['test'])}</td>
<td style="color:#666;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{self._e(entry['url'])}</td>
<td>{entry['method']}</td>
<td style="color:{sc_color};">{status}</td>
<td>{vuln}</td>
<td style="color:#444;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;">{self._e(entry['response'][:200])}</td>
</tr>"""

        html += f"""</table>
</div>

<div style="text-align:center;border-top:1px solid #222;padding:20px 0;margin-top:40px;">
<div style="color:#d4a017;font-size:12px;">Alpha External Vulnerability Scanner™ v{VERSION}</div>
<div style="color:#555;font-size:11px;">(C) 2026 Alpha Unlimited Technologies LLC — All Rights Reserved</div>
<div style="color:#444;font-size:11px;margin-top:4px;">
{stats['total_tests']} tests | {stats['total_requests']} requests | {stats.get('pages_scanned',1)} pages | {stats['vulnerabilities']} findings | {stats['connections']} connections | {elapsed:.1f}s
</div>
</div>
</div></body></html>"""

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding="utf-8")
        return str(out)


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════

def print_results(hostname, findings, stats, report_path):
    crit = sum(1 for f in findings if f.severity == SEV_CRIT)
    high = sum(1 for f in findings if f.severity == SEV_HIGH)
    med = sum(1 for f in findings if f.severity == SEV_MED)
    low = sum(1 for f in findings if f.severity == SEV_LOW)
    info = sum(1 for f in findings if f.severity == SEV_INFO)
    conn = sum(1 for f in findings if f.connected)
    elapsed = stats["end"] - stats["start"]
    pages = stats.get("pages_scanned", 1)

    print(f"""
  \033[33m┌──────────────────────────────────────────────────┐
  │  SCAN RESULTS: {hostname[:30]:<30s}    │
  ├──────────────────────────────────────────────────┤\033[0m
  │  \033[91mCritical:    {crit:>4}\033[0m                               │
  │  \033[93mHigh:        {high:>4}\033[0m                               │
  │  \033[33mMedium:      {med:>4}\033[0m                               │
  │  \033[94mLow:         {low:>4}\033[0m                               │
  │  \033[90mInfo:        {info:>4}\033[0m                               │
  │  \033[33mConnected:   {conn:>4}\033[0m                               │
  │  Total:       {len(findings):>4}                               │
  │  Pages:       {pages:>4}                               │
  │  Requests:    {stats['total_requests']:>4}                               │
  │  Duration:    {elapsed:>5.1f}s                              │
  \033[33m├──────────────────────────────────────────────────┤
  │\033[0m  Report: {report_path[:38]:<38s}  \033[33m│
  └──────────────────────────────────────────────────┘\033[0m
""")


def run_interactive():
    print(BANNER)
    print("  Enter URLs to scan (websites and/or applications).")
    print("  One per line. Empty line to start scanning.\n")

    urls = []
    while True:
        url = input("  URL> ").strip()
        if not url:
            break
        if not url.startswith("http"):
            url = "https://" + url
        urls.append(url)

    if not urls:
        print("  No URLs provided. Exiting.")
        return

    crawl = input("\n  Crawl subpages? (scan all linked pages) [Y/n]: ").strip().lower() != "n"
    max_pages = DEFAULT_MAX_PAGES
    if crawl:
        mp = input(f"  Max pages to crawl [{DEFAULT_MAX_PAGES}]: ").strip()
        if mp.isdigit():
            max_pages = int(mp)
    deep = input("  Deep scan? (ports, DNS, subdomains, WAF) [y/N]: ").strip().lower() == "y"
    out_dir = input("  Output directory [current]: ").strip() or "."
    out_dir = os.path.expanduser(out_dir)

    for url in urls:
        print(f"\n{'='*62}")
        print(f"  SCANNING: {url}")
        print(f"{'='*62}")

        subpages = None
        if crawl:
            crawler = PageCrawler(url, max_pages=max_pages, verbose=True)
            subpages = crawler.crawl()

        scanner = ExternalScanner(url, deep=deep, verbose=True)
        findings = scanner.run_all(subpages=subpages)

        hostname = urllib.parse.urlparse(url).hostname or "unknown"
        safe = re.sub(r'[^\w\-.]', '_', hostname)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_file = os.path.join(out_dir, f"scan_{safe}_{ts}.html")

        gen = ReportGenerator()
        gen.generate(url, findings, scanner.log, scanner.stats, out_file)
        print_results(hostname, findings, scanner.stats, out_file)


def main():
    parser = argparse.ArgumentParser(
        description="Alpha External Vulnerability Scanner™ — Comprehensive live URL & application scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 alpha_external_scanner.py https://mysite.com
  python3 alpha_external_scanner.py https://mysite.com --crawl
  python3 alpha_external_scanner.py https://mysite.com --crawl --max-pages 100
  python3 alpha_external_scanner.py https://mysite.com --deep --crawl
  python3 alpha_external_scanner.py https://site1.com https://app.example.com:3000
  python3 alpha_external_scanner.py https://mysite.com -o ~/reports/ -v
  python3 alpha_external_scanner.py  (interactive mode)
        """)
    parser.add_argument("urls", nargs="*", help="URLs to scan (websites or applications)")
    parser.add_argument("-o", "--output", default=".", help="Output directory")
    parser.add_argument("--deep", action="store_true", help="Deep scan (ports, DNS, subdomains, WAF)")
    parser.add_argument("--crawl", action="store_true", help="Crawl and scan all linked subpages")
    parser.add_argument("--max-pages", type=int, default=DEFAULT_MAX_PAGES,
        help=f"Max pages to crawl (default: {DEFAULT_MAX_PAGES})")
    parser.add_argument("--no-crawl", action="store_true", help="Skip crawling (scan only the submitted URL)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")

    args = parser.parse_args()
    if not args.urls:
        run_interactive()
        return

    print(BANNER)
    out_dir = os.path.expanduser(args.output)
    os.makedirs(out_dir, exist_ok=True)

    do_crawl = args.crawl and not args.no_crawl

    for url in args.urls:
        if not url.startswith("http"):
            url = "https://" + url

        print(f"\n{'='*62}")
        print(f"  SCANNING: {url}")
        print(f"{'='*62}")

        subpages = None
        if do_crawl:
            crawler = PageCrawler(url, max_pages=args.max_pages, verbose=args.verbose)
            subpages = crawler.crawl()

        scanner = ExternalScanner(url, deep=args.deep, verbose=args.verbose)
        findings = scanner.run_all(subpages=subpages)

        hostname = urllib.parse.urlparse(url).hostname or "unknown"
        safe = re.sub(r'[^\w\-.]', '_', hostname)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_file = os.path.join(out_dir, f"scan_{safe}_{ts}.html")

        gen = ReportGenerator()
        gen.generate(url, findings, scanner.log, scanner.stats, out_file)
        print_results(hostname, findings, scanner.stats, out_file)


if __name__ == "__main__":
    main()
