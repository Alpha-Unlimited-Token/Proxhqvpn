import fs from 'node:fs';
import path from 'node:path';
import archiver from 'archiver';
import PDFDocument from 'pdfkit';
import { db } from '../../server/db.js';
import { sql } from 'drizzle-orm';
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
import { getAdapter, probeAddressOnAllChains, SUPPORTED_CHAINS } from '../../server/services/chain-adapters/index.js';
import type { ChainKey } from '../../server/services/chain-adapters/types.js';

enforceProprietaryLicense('Alpha SillyTuna Multi-Chain Registration & Forward Trace™');

const TECH = 'Alpha SillyTuna Multi-Chain Registration & Forward Trace™';
const CASE_ID = '306db48a-36e2-42c1-9d7c-3b49d5bfdb49';
const VICTIM = '0x6fe0fab2164d8e0d03ad6a628e2af78624060322';
const OUT_DIR = path.resolve('private/exports/sillytuna-registration-and-trace');
const ZIP_PATH = path.resolve('private/exports/SillyTuna-Registration-and-MultiChain-Trace.zip');
const NOW = new Date();
const TRANSFER_LIMIT = 250;
const COUNTERPARTY_LIMIT = 100;
// Trace across every chain UCAL supports — including XRPL, Solana, Bitcoin, Tron, TON.
// probeAddressOnAllChains already filters by address shape, so EVM-only suspects naturally
// only register on EVM chains, XRPL r-addresses only on XRPL, etc.
const TRACE_CHAINS: ChainKey[] = SUPPORTED_CHAINS;

fs.rmSync(OUT_DIR, { recursive: true, force: true });
fs.mkdirSync(OUT_DIR, { recursive: true });

// ---------- well-known KYC-required CEX hot wallets ----------
// Public information (Etherscan public labels). Most apply across every EVM chain
// because the same EOA is used by the exchange on Polygon/Arbitrum/Optimism/Base too.
const KNOWN_CEX_HOT_WALLETS: Record<string, string> = {
  // Binance
  '0x28c6c06298d514db089934071355e5743bf21d60': 'Binance Hot 14',
  '0x21a31ee1afc51d94c2efccaa2092ad1028285549': 'Binance 36',
  '0xdfd5293d8e347dfe59e90efd55b2956a1343963d': 'Binance 15',
  '0x56eddb7aa87536c09ccc2793473599fd21a8b17f': 'Binance 16',
  '0x9696f59e4d72e237be84ffd425dcad154bf96976': 'Binance 17',
  '0x4976a4a02f38326660d17bf34b431dc6e2eb2327': 'Binance 27',
  '0xbe0eb53f46cd790cd13851d5eff43d12404d33e8': 'Binance 7',
  '0xf977814e90da44bfa03b6295a0616a897441acec': 'Binance 8',
  // Bybit
  '0xf89d7b9c864f589bbf53a82105107622b35eaa40': 'Bybit Hot',
  '0xa7efae728d2936e78bda97dc267687568dd593f3': 'Bybit Cold',
  // OKX
  '0x6cc5f688a315f3dc28a7781717a9a798a59fda7b': 'OKX Hot',
  '0x236f233dbf78341d25fb0f1bd14cb2ba4b8a777c': 'OKX 2',
  '0x868dab0b8e21ec0a48b76a7dbb66dcdb83a3f31e': 'OKX 3',
  // Coinbase
  '0x71660c4005ba85c37ccec55d0c4493e66fe775d3': 'Coinbase 1',
  '0x503828976d22510aad0201ac7ec88293211d23da': 'Coinbase 2',
  '0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740': 'Coinbase 3',
  '0x3cd751e6b0078be393132286c442345e5dc49699': 'Coinbase 4',
  '0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511': 'Coinbase 5',
  '0xeb2629a2734e272bcc07bda959863f316f4bd4cf': 'Coinbase 6',
  '0xa090e606e30bd747d4e6245a1517ebe430f0057e': 'Coinbase 10',
  // Kraken
  '0x2910543af39aba0cd09dbb2d50200b3e800a63d2': 'Kraken 1',
  '0x0a869d79a7052c7f1b55a8ebabbea3420f0d1e13': 'Kraken 2',
  '0xe853c56864a2ebe4576a807d26fdc4a0ada51919': 'Kraken 3',
  '0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0': 'Kraken 4',
  // Crypto.com
  '0x46340b20830761efd32832a74d7169b29feb9758': 'Crypto.com 2',
  '0x72a53cdbbcc1b9efa39c834a540550e23463aacb': 'Crypto.com 3',
  '0x6262998ced04146fa42253a5c0af90ca02dfd2a3': 'Crypto.com 1',
  // Gate.io
  '0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c': 'Gate.io 1',
  '0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23': 'Gate.io 2',
  // KuCoin
  '0x2b5634c42055806a59e9107ed44d43c426e58258': 'KuCoin 1',
  '0x689c56aef474df92d44a1b70850f808488f9769c': 'KuCoin 2',
  // HTX (Huobi)
  '0xab5c66752a9e8167967685f1450532fb96d5d24f': 'HTX 1',
  '0xe93381fb4c4f14bda253907b18fad305d799241a': 'HTX 2',
  // Bitfinex
  '0x1151314c646ce4e0efd76d1af4760ae66a9fe30f': 'Bitfinex 5',
  '0x876eabf441b2ee5b5b0554fd502a8e0600950cfa': 'Bitfinex MultiSig',
  // MEXC
  '0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88': 'MEXC',
  '0x9642b23ed1e01df1092b92641051881a322f5d4e': 'MEXC 2',
};

// ---------- helpers ----------
function csv(rows: any[]): string {
  if (rows.length === 0) return 'no_data\n';
  const h = Object.keys(rows[0]);
  const esc = (v: any) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return [h.join(','), ...rows.map(r => h.map(k => esc(r[k])).join(','))].join('\n');
}
function fmtUsd(n: any) { const v = Number(n); return Number.isFinite(v) && v !== 0 ? '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—'; }
function fmtNum(n: any, dp = 6) { const v = Number(n); return Number.isFinite(v) ? v.toLocaleString('en-US', { maximumFractionDigits: dp }) : '—'; }
function lc(s: string | null | undefined) { return (s || '').toLowerCase(); }

// Build full CEX hot-wallet map: built-in + dynamic from existing case data
async function buildCexMap(): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  for (const [addr, name] of Object.entries(KNOWN_CEX_HOT_WALLETS)) map.set(addr.toLowerCase(), name);
  console.log(`  • starting CEX map with ${map.size} well-known hot wallets`);
  // Augment from case-derived hot wallets
  const dyn = (await db.execute(sql`
    WITH cex AS (
      SELECT direction,
             CASE WHEN direction='outgoing' THEN to_address ELSE from_address END AS hw,
             COALESCE(exchange_name, CASE WHEN direction='outgoing' THEN to_label ELSE from_label END) AS name
      FROM traced_transactions
      WHERE case_id = ${CASE_ID}
        AND (exchange_name IS NOT NULL OR tx_type ILIKE '%exchange%')
    )
    SELECT hw, MIN(name) AS name, COUNT(*)::int AS hits
    FROM cex GROUP BY hw ORDER BY hits DESC LIMIT 500;
  `)).rows as any[];
  for (const r of dyn) if (r.hw && !map.has(lc(r.hw))) map.set(lc(r.hw), r.name || 'CEX (case-derived)');
  console.log(`  • CEX map enriched to ${map.size} hot wallets`);
  return map;
}

async function getSuspects(): Promise<{ wallet: string; eth_kyc_usd: number; eth_kyc_tx_count: number; }[]> {
  const rows = (await db.execute(sql`
    WITH s AS (
      SELECT CASE WHEN direction='outgoing' THEN from_address ELSE to_address END AS wallet,
             amount_usd
      FROM traced_transactions
      WHERE case_id = ${CASE_ID}
        AND chain='ethereum'
        AND (exchange_name IS NOT NULL OR tx_type ILIKE '%exchange%')
    )
    SELECT wallet,
           COUNT(*)::int AS eth_kyc_tx_count,
           ROUND(SUM(CASE WHEN amount_usd>0 AND amount_usd<1e9 THEN amount_usd ELSE 0 END)::numeric, 2)::float AS eth_kyc_usd
    FROM s
    GROUP BY wallet
    ORDER BY eth_kyc_usd DESC NULLS LAST
    LIMIT 25;
  `)).rows as any[];
  return rows.map(r => ({ wallet: lc(r.wallet), eth_kyc_usd: Number(r.eth_kyc_usd) || 0, eth_kyc_tx_count: Number(r.eth_kyc_tx_count) || 0 }));
}

async function getExistingMonitored(): Promise<Set<string>> {
  const rows = (await db.execute(sql`
    SELECT LOWER(address) || '|' || LOWER(chain) AS key
    FROM monitored_wallets
    WHERE case_id = ${CASE_ID};
  `)).rows as any[];
  return new Set(rows.map((r: any) => r.key));
}

interface RegistrationRow { wallet: string; chain: ChainKey; was_already_registered: boolean; native_balance: number; tx_count: number; last_seen: string | null; }
interface KycHitRow { suspect: string; chain: ChainKey; cex_name: string; cex_hot_wallet: string; direction: string; tx_hash: string; block_time: string; asset: string; amount: number; value_usd: number | null; }
interface TransferRow { suspect: string; chain: ChainKey; tx_hash: string; block_time: string; direction: string; counterparty: string; counterparty_label: string; asset: string; amount: number; value_usd: number | null; }
interface CounterpartyRow { suspect: string; chain: ChainKey; counterparty: string; cex_label: string; tx_count: number; inbound_native: number; outbound_native: number; first_seen: string | null; last_seen: string | null; }

async function probeAndTrace(suspects: { wallet: string }[], cexMap: Map<string, string>) {
  const registrations: RegistrationRow[] = [];
  const transfers: TransferRow[] = [];
  const kycHits: KycHitRow[] = [];
  const counterparties: CounterpartyRow[] = [];
  const existingMonitored = await getExistingMonitored();

  for (let i = 0; i < suspects.length; i++) {
    const s = suspects[i];
    process.stdout.write(`  [${i + 1}/${suspects.length}] ${s.wallet}\n`);

    // Step 1 — probe across all UCAL chains to get active set (parallel internally)
    const profiles = await probeAddressOnAllChains(s.wallet);
    const activeChains = profiles.map(p => p.chain).filter(c => TRACE_CHAINS.includes(c as ChainKey)) as ChainKey[];
    process.stdout.write(`      active on: ${activeChains.join(', ') || '(none)'}\n`);

    // Step 2 — register every active (wallet, chain) into monitored_wallets if absent
    for (const c of activeChains) {
      const key = `${s.wallet}|${c}`;
      const already = existingMonitored.has(key);
      const profile = profiles.find(p => p.chain === c)!.profile;
      if (!already) {
        const meta = JSON.stringify({ registeredBy: TECH, txCount: profile.txCount, tokenCount: profile.tokens?.length || 0 });
        await db.execute(sql`
          INSERT INTO monitored_wallets (case_id, address, chain, role, label, last_known_balance_eth, last_activity, status, metadata)
          SELECT ${CASE_ID}, ${s.wallet}, ${c}, 'sillytuna_attacker_network',
                 ${`Suspect (top-25 ETH KYC funneler) — registered ${NOW.toISOString().slice(0,10)}`},
                 ${profile.nativeBalance || 0},
                 ${profile.lastSeen ? new Date(profile.lastSeen * 1000).toISOString() : null},
                 'monitoring', ${meta}::jsonb
          WHERE NOT EXISTS (
            SELECT 1 FROM monitored_wallets
            WHERE case_id = ${CASE_ID} AND LOWER(address) = ${s.wallet} AND LOWER(chain) = ${c}
          );
        `);
      }
      registrations.push({
        wallet: s.wallet, chain: c, was_already_registered: already,
        native_balance: profile.nativeBalance, tx_count: profile.txCount,
        last_seen: profile.lastSeen ? new Date(profile.lastSeen * 1000).toISOString() : null,
      });
    }

    // Step 3 — for each active chain, pull transfers + counterparties via UCAL
    for (const c of activeChains) {
      const adapter = getAdapter(c);
      let txList: any[] = [];
      let cpList: any[] = [];
      try {
        txList = await adapter.getTransfers(s.wallet, { limit: TRANSFER_LIMIT });
      } catch (e: any) { process.stdout.write(`        ${c} getTransfers err: ${e.message}\n`); }
      try {
        cpList = await adapter.getCounterparties(s.wallet, { limit: COUNTERPARTY_LIMIT });
      } catch (e: any) { process.stdout.write(`        ${c} getCounterparties err: ${e.message}\n`); }
      process.stdout.write(`        ${c}: ${txList.length} transfers, ${cpList.length} counterparties\n`);

      // Record raw transfers
      for (const t of txList) {
        const cp = lc(t.counterparty);
        const cexLabel = cexMap.get(cp);
        transfers.push({
          suspect: s.wallet, chain: c, tx_hash: t.hash,
          block_time: t.blockTime ? new Date(t.blockTime * 1000).toISOString() : '',
          direction: t.direction, counterparty: cp,
          counterparty_label: cexLabel || '', asset: t.asset, amount: t.amount,
          value_usd: t.valueUsd ?? null,
        });
        // KYC hit?
        if (cexLabel) {
          kycHits.push({
            suspect: s.wallet, chain: c, cex_name: cexLabel, cex_hot_wallet: cp,
            direction: t.direction, tx_hash: t.hash,
            block_time: t.blockTime ? new Date(t.blockTime * 1000).toISOString() : '',
            asset: t.asset, amount: t.amount, value_usd: t.valueUsd ?? null,
          });
          // Insert alert if this is a fresh discovery (chain != ethereum means new finding)
          if (c !== 'ethereum') {
            try {
              const det = JSON.stringify({ suspect: s.wallet, chain: c, cex_name: cexLabel, cex_hot_wallet: cp, tx_hash: t.hash, asset: t.asset, amount: t.amount, valueUsd: t.valueUsd, blockTime: t.blockTime, source: TECH });
              await db.execute(sql`
                INSERT INTO forensic_alerts (case_id, alert_type, severity, message, details)
                SELECT ${CASE_ID}, 'cross_chain_kyc_exposure', 'critical',
                       ${`Suspect ${s.wallet} → ${cexLabel} on ${c} (${t.direction}) ${t.amount} ${t.asset}`},
                       ${det}::jsonb
                WHERE NOT EXISTS (
                  SELECT 1 FROM forensic_alerts
                  WHERE case_id = ${CASE_ID}
                    AND alert_type = 'cross_chain_kyc_exposure'
                    AND details->>'tx_hash' = ${t.hash}
                    AND details->>'cex_hot_wallet' = ${cp}
                );
              `);
            } catch { /* non-fatal */ }
          }
        }
      }

      // Aggregate counterparties
      for (const cp of cpList) {
        const addr = lc(cp.address);
        counterparties.push({
          suspect: s.wallet, chain: c, counterparty: addr,
          cex_label: cexMap.get(addr) || cp.entityLabel || '',
          tx_count: cp.count,
          inbound_native: cp.inboundValueNative, outbound_native: cp.outboundValueNative,
          first_seen: cp.firstSeen ? new Date(cp.firstSeen * 1000).toISOString() : null,
          last_seen: cp.lastSeen ? new Date(cp.lastSeen * 1000).toISOString() : null,
        });
      }
    }
  }
  return { registrations, transfers, kycHits, counterparties };
}

function aggregateKycHits(hits: KycHitRow[]) {
  const map = new Map<string, { suspect: string; chain: ChainKey; cex_name: string; cex_hot_wallet: string; direction: string; tx_count: number; total_amount_native: number; total_value_usd: number; first_block_time: string; last_block_time: string; assets: Set<string>; }>();
  for (const h of hits) {
    const key = `${h.suspect}|${h.chain}|${h.cex_name}|${h.direction}`;
    const cur = map.get(key) || {
      suspect: h.suspect, chain: h.chain, cex_name: h.cex_name, cex_hot_wallet: h.cex_hot_wallet,
      direction: h.direction, tx_count: 0, total_amount_native: 0, total_value_usd: 0,
      first_block_time: h.block_time, last_block_time: h.block_time, assets: new Set<string>(),
    };
    cur.tx_count++;
    cur.total_amount_native += Number(h.amount) || 0;
    cur.total_value_usd += Number(h.value_usd) || 0;
    cur.assets.add(h.asset);
    if (h.block_time && h.block_time < cur.first_block_time) cur.first_block_time = h.block_time;
    if (h.block_time && h.block_time > cur.last_block_time) cur.last_block_time = h.block_time;
    map.set(key, cur);
  }
  return [...map.values()].map(v => ({
    suspect: v.suspect, chain: v.chain, cex_name: v.cex_name, cex_hot_wallet: v.cex_hot_wallet,
    direction: v.direction, tx_count: v.tx_count,
    assets: [...v.assets].join('+'),
    total_amount: v.total_amount_native,
    total_value_usd: v.total_value_usd,
    first_block_time: v.first_block_time, last_block_time: v.last_block_time,
  })).sort((a, b) => b.total_value_usd - a.total_value_usd || b.tx_count - a.tx_count);
}

function writePdf(args: { suspects: any[]; registrations: RegistrationRow[]; transfers: TransferRow[]; kycHits: KycHitRow[]; kycAgg: any[]; cexMapSize: number; }) {
  const { suspects, registrations, transfers, kycHits, kycAgg, cexMapSize } = args;
  const pdfPath = path.join(OUT_DIR, '00_Master_Report.pdf');
  const doc = new PDFDocument({ size: 'LETTER', margin: 48 });
  const stream = fs.createWriteStream(pdfPath);
  doc.pipe(stream);

  // Cover
  doc.font('Helvetica-Bold').fontSize(20).text('@sillytuna $26M Theft', { align: 'center' });
  doc.fontSize(13).fillColor('#444').text('Multi-Chain Registration & Forward-Trace Report', { align: 'center' });
  doc.moveDown(0.3);
  doc.fontSize(9).fillColor('#666')
    .text(`Case ID:  ${CASE_ID}`, { align: 'center' })
    .text(`Generated: ${NOW.toISOString()}`, { align: 'center' });
  doc.moveDown(1);

  // Stats
  const newRegs = registrations.filter(r => !r.was_already_registered).length;
  const chainsTouched = new Set(registrations.map(r => r.chain));
  const kycByChain: Record<string, { hits: number; usd: number; }> = {};
  for (const h of kycHits) {
    kycByChain[h.chain] ??= { hits: 0, usd: 0 };
    kycByChain[h.chain].hits++;
    kycByChain[h.chain].usd += Number(h.value_usd) || 0;
  }
  const cexHitNames = new Set(kycHits.map(h => h.cex_name));

  doc.font('Helvetica-Bold').fontSize(13).fillColor('#000').text('Executive Summary');
  doc.font('Helvetica').fontSize(10).moveDown(0.2);
  doc.text(`Suspect wallets processed:           ${suspects.length}`);
  doc.text(`(wallet, chain) pairs registered:    ${registrations.length}  (${newRegs} new, ${registrations.length - newRegs} already monitored)`);
  doc.text(`Chains touched by suspects:          ${[...chainsTouched].join(', ')}`);
  doc.text(`Forward-trace transfers analyzed:    ${transfers.length}`);
  doc.text(`KYC-exchange hot-wallet matches:     ${kycHits.length}  (across ${cexHitNames.size} distinct exchanges)`);
  doc.text(`CEX hot-wallet lookup map size:      ${cexMapSize}`);
  doc.moveDown(0.4);
  doc.font('Helvetica-Bold').text('What this report does:');
  doc.font('Helvetica');
  doc.text('1. Registers each of the top 25 suspect wallets — across every UCAL chain on which they have measurable activity — into the persistent monitored_wallets table for this case. Going forward they will be picked up by the active surveillance loop on every chain they touch.');
  doc.text('2. Runs a one-time forward-trace on each (wallet, chain) pair using UCAL.getTransfers(), pulling up to 250 transfers per pair newest-first.');
  doc.text('3. Cross-references every transfer\'s counterparty against a KYC-required exchange hot-wallet lookup map by exact address-equality (well-known public Binance/Bybit/OKX/Coinbase/Kraken/Crypto.com/Gate.io/KuCoin/HTX/Bitfinex/MEXC addresses + every CEX hot wallet already labeled in this case file). A "match" means the suspect transferred funds to or from a labeled exchange hot wallet — it is direct address-adjacency evidence, NOT proof of account ownership; the depositor identity behind the suspect wallet is identified via subpoena/MLAT to the matched exchange.');
  doc.text('4. For every match, records a transfer-level KYC-exposure row. For matches found on a chain other than Ethereum (chains that fell outside the original case scope), inserts a critical-severity forensic_alerts row — deduplicated by (case, alert_type, tx_hash, hot_wallet) so re-runs do not duplicate evidence.');

  // Section: per-chain KYC summary
  const drawTable = (headers: string[], rows: string[][], widths: number[]) => {
    let y = doc.y; const startX = doc.x; const rowH = 13;
    const draw = () => {
      doc.font('Helvetica-Bold').fontSize(8).fillColor('#fff');
      let x = startX;
      for (let i = 0; i < headers.length; i++) {
        doc.rect(x, y, widths[i], rowH).fill('#222');
        doc.fillColor('#fff').text(headers[i], x + 3, y + 3, { width: widths[i] - 6, lineBreak: false });
        x += widths[i];
      }
      y += rowH;
    };
    draw();
    doc.font('Helvetica').fontSize(7).fillColor('#000');
    for (let r = 0; r < rows.length; r++) {
      if (y + rowH > doc.page.height - doc.page.margins.bottom - 20) { doc.addPage(); y = doc.page.margins.top; draw(); doc.font('Helvetica').fontSize(7).fillColor('#000'); }
      const bg = r % 2 === 0 ? '#f6f6f6' : '#ffffff';
      let x = startX;
      for (let i = 0; i < headers.length; i++) {
        doc.rect(x, y, widths[i], rowH).fill(bg);
        doc.fillColor('#000').text(rows[r][i] ?? '', x + 3, y + 3, { width: widths[i] - 6, lineBreak: false, ellipsis: true });
        x += widths[i];
      }
      y += rowH;
    }
    doc.y = y + 6;
  };

  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(14).text('1. KYC Exposure — Per-Chain Rollup');
  doc.moveDown(0.3);
  drawTable(['Chain', 'KYC TX Hits', 'Sum USD (where priced)'],
    Object.entries(kycByChain).sort((a, b) => b[1].hits - a[1].hits)
      .map(([c, v]) => [c.toUpperCase(), String(v.hits), fmtUsd(v.usd)]),
    [120, 100, 200]);

  doc.moveDown(0.6);
  doc.font('Helvetica-Bold').fontSize(14).text('2. KYC Exposure — Per-Exchange Rollup');
  doc.moveDown(0.3);
  const byCex: Record<string, { hits: number; usd: number; chains: Set<string>; }> = {};
  for (const h of kycHits) {
    byCex[h.cex_name] ??= { hits: 0, usd: 0, chains: new Set() };
    byCex[h.cex_name].hits++;
    byCex[h.cex_name].usd += Number(h.value_usd) || 0;
    byCex[h.cex_name].chains.add(h.chain);
  }
  drawTable(['Exchange', 'TX Hits', 'Sum USD', 'Chains seen on'],
    Object.entries(byCex).sort((a, b) => b[1].hits - a[1].hits)
      .map(([n, v]) => [n, String(v.hits), fmtUsd(v.usd), [...v.chains].join(', ')]),
    [140, 60, 110, 200]);

  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(14).text('3. KYC Exposure — Aggregated by (Suspect × Chain × Exchange × Direction)');
  doc.font('Helvetica').fontSize(9).moveDown(0.2);
  doc.text('Top 60 rows shown; full list in 03_KYC_Aggregated.csv. "OUT" = funds DEPOSITED to the CEX (subpoena targets); "IN" = funds WITHDRAWN from the CEX (funding-source identification).');
  doc.moveDown(0.3);
  drawTable(['Suspect (last8)', 'Chain', 'Exchange', 'Dir', 'TXs', 'Asset(s)', 'Sum USD'],
    kycAgg.slice(0, 60).map((r: any) => [
      '…' + r.suspect.slice(-8),
      r.chain.toUpperCase(),
      r.cex_name,
      r.direction === 'out' ? 'OUT' : r.direction === 'in' ? 'IN' : r.direction.toUpperCase(),
      String(r.tx_count),
      r.assets,
      fmtUsd(r.total_value_usd),
    ]),
    [80, 55, 110, 35, 35, 80, 90]);

  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(14).text('4. Per-Suspect Per-Chain Registration & Activity');
  doc.moveDown(0.2);
  doc.font('Helvetica').fontSize(9);
  doc.text('Every (suspect, chain) pair where measurable activity was found. Wallets marked NEW were registered into the persistent multi-chain watcher by this run.');
  doc.moveDown(0.3);
  drawTable(['Suspect (last8)', 'Chain', 'Status', 'Native Bal', 'TX Count', 'Last Seen'],
    registrations.map(r => [
      '…' + r.wallet.slice(-8),
      r.chain.toUpperCase(),
      r.was_already_registered ? 'existing' : 'NEW',
      fmtNum(r.native_balance, 6),
      String(r.tx_count),
      r.last_seen ? r.last_seen.slice(0, 10) : '—',
    ]),
    [80, 60, 60, 80, 60, 80]);

  doc.addPage();
  doc.font('Helvetica-Bold').fontSize(14).text('5. Methodology, Scope & Limitations');
  doc.font('Helvetica').fontSize(10).moveDown(0.3);
  doc.text(`• Suspect set: top 25 wallets (by Ethereum-side KYC USD volume) from the existing case trace store.`);
  doc.text(`• Chains traced: ${TRACE_CHAINS.join(', ')} — i.e. every chain in UCAL (EVM + Solana + Bitcoin + Tron + TON + XRPL). probeAddressOnAllChains gates each lookup by adapter-specific isValidAddress(), so EVM (0x…) suspects naturally only register on EVM rails, Solana base58 keys only on Solana, XRPL r-addresses only on the XRP Ledger, etc. If the attacker bridged out of EVM, the receiving wallet on the target ecosystem is automatically picked up via the chain-native counterparty / pivot tooling — see the Multi-Chain Exposure Addendum and bridge-operator subpoena recommendations.`);
  doc.text(`• Per-chain depth: up to ${TRANSFER_LIMIT} most-recent transfers + up to ${COUNTERPARTY_LIMIT} aggregated counterparties per (wallet, chain).`);
  doc.text(`• KYC matching: address-equality lookup against ${cexMapSize} known CEX hot wallets (built-in well-known list + dynamic enrichment from this case's existing trace data). A match is a confirmed deposit-or-withdrawal between the suspect and that exchange's hot wallet.`);
  doc.text(`• Persistent surveillance: each new (wallet, chain) pair is INSERTed into the case's monitored_wallets table with status='monitoring'. The active surveillance loop will pick them up automatically on its next iteration.`);
  doc.text(`• Cross-chain alerts: every KYC hit on a chain OTHER than Ethereum (i.e. previously-unseen evidence) is recorded as a 'cross_chain_kyc_exposure' alert at severity='critical' in forensic_alerts for this case.`);
  doc.text(`• What this report does NOT do: it does not deduplicate against historical alerts, does not deep-trace beyond the first hop, and does not run a full BFS forward-trace through every intermediary. Those are follow-on actions available in the existing forensic toolset.`);
  doc.moveDown(0.6);
  doc.fontSize(7).fillColor('#888').text(proprietaryHeader(TECH), { align: 'center' });

  doc.end();
  return new Promise<void>((resolve, reject) => { stream.on('finish', () => resolve()); stream.on('error', reject); });
}

(async () => {
  console.log(`[${TECH}] Starting…`);
  console.log('[Step 1/5] Building CEX hot-wallet map');
  const cexMap = await buildCexMap();

  console.log('[Step 2/5] Loading top 25 suspect wallets');
  const suspects = await getSuspects();
  console.log(`  • ${suspects.length} suspects loaded`);

  console.log('[Step 3/5] Probe + Register + Forward-trace per suspect (this is the long step)');
  const { registrations, transfers, kycHits, counterparties } = await probeAndTrace(suspects, cexMap);
  const kycAgg = aggregateKycHits(kycHits);
  console.log(`  • registrations: ${registrations.length}`);
  console.log(`  • transfers analyzed: ${transfers.length}`);
  console.log(`  • KYC hits: ${kycHits.length}  (aggregated to ${kycAgg.length} relationships)`);
  console.log(`  • counterparties captured: ${counterparties.length}`);

  console.log('[Step 4/5] Writing CSVs + per-suspect dossiers');
  fs.writeFileSync(path.join(OUT_DIR, '01_Suspect_Registrations.csv'), csv(registrations));
  fs.writeFileSync(path.join(OUT_DIR, '02_KYC_Exposure_Per_Transfer.csv'), csv(kycHits));
  fs.writeFileSync(path.join(OUT_DIR, '03_KYC_Aggregated.csv'), csv(kycAgg));
  fs.writeFileSync(path.join(OUT_DIR, '04_All_Transfers_Captured.csv'), csv(transfers));
  fs.writeFileSync(path.join(OUT_DIR, '05_All_Counterparties_Captured.csv'), csv(counterparties));

  // per-suspect dossiers
  const dossierDir = path.join(OUT_DIR, 'per-suspect-dossiers');
  fs.mkdirSync(dossierDir, { recursive: true });
  for (const s of suspects) {
    const t = transfers.filter(x => x.suspect === s.wallet);
    const k = kycHits.filter(x => x.suspect === s.wallet);
    const r = registrations.filter(x => x.wallet === s.wallet);
    const c = counterparties.filter(x => x.suspect === s.wallet);
    fs.writeFileSync(path.join(dossierDir, `${s.wallet}_summary.json`), JSON.stringify({
      wallet: s.wallet,
      ethKycBaseline: { txCount: s.eth_kyc_tx_count, usd: s.eth_kyc_usd },
      registrations: r,
      kycHitCount: k.length,
      kycExchangesHit: [...new Set(k.map(x => x.cex_name))],
      transferCount: t.length,
      counterpartyCount: c.length,
    }, null, 2));
    fs.writeFileSync(path.join(dossierDir, `${s.wallet}_transfers.csv`), csv(t));
    fs.writeFileSync(path.join(dossierDir, `${s.wallet}_kyc_hits.csv`), csv(k));
  }

  await writePdf({ suspects, registrations, transfers, kycHits, kycAgg, cexMapSize: cexMap.size });

  // manifest
  const manifest = {
    report: TECH,
    generatedAt: NOW.toISOString(),
    case: { id: CASE_ID, victim: VICTIM, victimHandle: '@sillytuna' },
    chainsTraced: TRACE_CHAINS,
    cexMapSize: cexMap.size,
    counts: {
      suspects: suspects.length,
      registrations: registrations.length,
      newRegistrations: registrations.filter(r => !r.was_already_registered).length,
      transfers: transfers.length,
      kycHits: kycHits.length,
      kycRelationships: kycAgg.length,
      counterparties: counterparties.length,
    },
    proprietaryNotice: proprietaryHeader(TECH),
  };
  fs.writeFileSync(path.join(OUT_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2));

  console.log('[Step 5/5] Zipping bundle');
  await new Promise<void>((resolve, reject) => {
    const o = fs.createWriteStream(ZIP_PATH);
    const a = archiver('zip', { zlib: { level: 9 } });
    o.on('close', () => resolve()); a.on('error', reject);
    a.pipe(o); a.directory(OUT_DIR, 'SillyTuna-Registration-and-MultiChain-Trace'); a.finalize();
  });
  const stat = fs.statSync(ZIP_PATH);
  console.log(`\n✅ DONE`);
  console.log(`   Bundle: ${ZIP_PATH}`);
  console.log(`   Size:   ${(stat.size / 1024).toFixed(1)} KB`);
  process.exit(0);
})().catch((e) => { console.error('FAILED:', e); process.exit(1); });
