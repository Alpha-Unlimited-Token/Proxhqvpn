#!/usr/bin/env python3
"""
Alpha Scan Data Extractor™ v1.0.0
(C) 2026 Alpha Unlimited Technologies LLC — All Rights Reserved
Proprietary and Confidential

Parses Alpha External Vulnerability Scanner™ HTML reports and extracts
ALL vulnerability data, scan logs, connection chains, and metadata into
structured export formats: JSON, CSV, SQL dump, and plain-text summary.

Usage:
  python3 alpha_scan_extractor.py report.html
  python3 alpha_scan_extractor.py report.html --format json
  python3 alpha_scan_extractor.py report.html --format csv
  python3 alpha_scan_extractor.py report.html --format sql
  python3 alpha_scan_extractor.py report.html --format all
  python3 alpha_scan_extractor.py report.html --format all -o ~/exports/
  python3 alpha_scan_extractor.py  (interactive mode)

No external dependencies — stdlib only.
"""

import os
import sys
import re
import json
import csv
import html
import argparse
import io
from datetime import datetime
from pathlib import Path
from html.parser import HTMLParser

VERSION = "1.0.0"

BANNER = """
\033[33m╔══════════════════════════════════════════════════════════════╗
║   Alpha Scan Data Extractor™ v{ver:<28s}║
║   (C) 2026 Alpha Unlimited Technologies LLC                  ║
║   Proprietary and Confidential                               ║
║                                                              ║
║   Parse HTML Reports → JSON / CSV / SQL / Summary            ║
║   Full Vulnerability Data + Scan Logs + Connections          ║
╚══════════════════════════════════════════════════════════════╝\033[0m
""".format(ver=VERSION)


class Finding:
    def __init__(self):
        self.finding_id = ""
        self.category = ""
        self.title = ""
        self.severity = ""
        self.cwe = ""
        self.timestamp = ""
        self.description = ""
        self.evidence = ""
        self.response_data = ""
        self.fix = ""
        self.connected = False
        self.connection_chains = []


class ScanLogEntry:
    def __init__(self):
        self.seq = 0
        self.time = ""
        self.test = ""
        self.url = ""
        self.method = ""
        self.status = ""
        self.vuln = ""
        self.response = ""


class ConnectionChain:
    def __init__(self):
        self.description = ""
        self.linked_findings = ""


class ScanMetadata:
    def __init__(self):
        self.target = ""
        self.generated = ""
        self.duration = ""
        self.tests = 0
        self.requests = 0
        self.vulnerabilities = 0
        self.connections = 0
        self.pages_scanned = 0
        self.critical = 0
        self.high = 0
        self.medium = 0
        self.low = 0
        self.info = 0
        self.categories = {}


def decode_html(text):
    text = html.unescape(text)
    text = re.sub(r'<[^>]+>', '', text)
    return text.strip()


def extract_text(html_str):
    return decode_html(html_str).strip()


class ReportParser:

    def __init__(self, html_content):
        self.raw = html_content
        self.metadata = ScanMetadata()
        self.findings = []
        self.scan_log = []
        self.connection_chains = []

    def parse(self):
        self._parse_metadata()
        self._parse_categories()
        self._parse_connection_chains()
        self._parse_findings()
        self._parse_scan_log()
        return self

    def _parse_metadata(self):
        m = re.search(r'Target:\s*<span[^>]*>(.*?)</span>', self.raw)
        if m:
            self.metadata.target = decode_html(m.group(1))

        info_line = re.search(r'Generated:\s*([\d\-: ]+)\s*\|', self.raw)
        if info_line:
            self.metadata.generated = info_line.group(1).strip()

        dur = re.search(r'Duration:\s*([\d.]+)s', self.raw)
        if dur:
            self.metadata.duration = dur.group(1) + "s"

        tests = re.search(r'Tests:\s*(\d+)', self.raw)
        if tests:
            self.metadata.tests = int(tests.group(1))

        reqs = re.search(r'Requests:\s*(\d+)', self.raw)
        if reqs:
            self.metadata.requests = int(reqs.group(1))

        vulns = re.search(r'Vulnerabilities:\s*(\d+)', self.raw)
        if vulns:
            self.metadata.vulnerabilities = int(vulns.group(1))

        conns = re.search(r'Connections:\s*(\d+)', self.raw)
        if conns:
            self.metadata.connections = int(conns.group(1))

        pages = re.search(r'Pages:\s*(\d+)', self.raw)
        if pages:
            self.metadata.pages_scanned = int(pages.group(1))

        for sev, attr in [("critical", "critical"), ("high", "high"), ("medium", "medium"),
                          ("low", "low"), ("info", "info")]:
            stat_match = re.search(
                r'<div class="stat"[^>]*>.*?<div class="n"[^>]*>(\d+)</div>\s*<div class="l">' + sev.capitalize(),
                self.raw, re.DOTALL | re.IGNORECASE)
            if stat_match:
                setattr(self.metadata, attr, int(stat_match.group(1)))

    def _parse_categories(self):
        for m in re.finditer(r'<span class="cat-tag">(.*?)</span>', self.raw):
            text = decode_html(m.group(1))
            parts = text.rsplit(":", 1)
            if len(parts) == 2:
                self.metadata.categories[parts[0].strip()] = int(parts[1].strip())

    def _parse_connection_chains(self):
        conn_section = re.search(
            r'These vulnerabilities are connected.*?(?=<h2)',
            self.raw, re.DOTALL
        )
        if not conn_section:
            return

        section = conn_section.group(0)
        for m in re.finditer(
            r'<div class="conn-box">\s*'
            r'<div[^>]*>(.*?)</div>\s*'
            r'<div[^>]*>(.*?)</div>\s*'
            r'</div>',
            section, re.DOTALL
        ):
            chain = ConnectionChain()
            chain.description = decode_html(m.group(1)).lstrip("⚡ ").strip()
            chain.linked_findings = decode_html(m.group(2)).replace("Linked:", "").strip()
            self.connection_chains.append(chain)

    def _parse_findings(self):
        finding_blocks = re.finditer(
            r'<div class="finding"[^>]*>(.*?)</div>\s*(?=<div class="finding"|<h2|<div style="text-align:center)',
            self.raw, re.DOTALL
        )

        for block_m in finding_blocks:
            block = block_m.group(1)
            f = Finding()

            fid = re.search(r'\[([A-Z\-]+\d+(?:-\d+)?)\]', block)
            if fid:
                f.finding_id = fid.group(1)

            cat_title = re.search(
                r'\[' + re.escape(f.finding_id) + r'\].*?\[([^\]]+)\]\s*(.*?)</span>',
                block, re.DOTALL
            )
            if cat_title:
                f.category = cat_title.group(1)
                f.title = decode_html(cat_title.group(2))
            else:
                alt = re.search(r'\[([^\]]+)\]\s*(.*?)</span>', block)
                if alt:
                    f.category = alt.group(1)
                    f.title = decode_html(alt.group(2))

            badge = re.search(r'class="badge"[^>]*>(.*?)</span>', block)
            if badge:
                f.severity = decode_html(badge.group(1)).strip()

            cwe_ts = re.search(r'(CWE-\d+)\s*\|\s*([\d\-T:.]+)', block)
            if cwe_ts:
                f.cwe = cwe_ts.group(1)
                f.timestamp = cwe_ts.group(2)
            else:
                ts_only = re.search(r'font-family:monospace[^>]*>([\d\-T:.]+)', block)
                if ts_only:
                    f.timestamp = ts_only.group(1)

            desc = re.search(r'font-size:13px[^>]*>(.*?)</div>', block, re.DOTALL)
            if desc:
                f.description = decode_html(desc.group(1))

            evidence = re.search(r'<pre>(.*?)</pre>', block, re.DOTALL)
            if evidence:
                f.evidence = decode_html(evidence.group(1))

            resp_data = re.search(r'<details>.*?<pre[^>]*>(.*?)</pre>\s*</details>', block, re.DOTALL)
            if resp_data:
                f.response_data = decode_html(resp_data.group(1))

            fix = re.search(r'<strong>Fix:</strong>\s*(.*?)</div>', block, re.DOTALL)
            if fix:
                f.fix = decode_html(fix.group(1))

            if 'CONNECTED VULNERABILITIES' in block:
                f.connected = True
                for chain_m in re.finditer(r'⚡\s*(.*?)</div>', block):
                    f.connection_chains.append(decode_html(chain_m.group(1)))

            self.findings.append(f)

    def _parse_scan_log(self):
        log_section = re.search(r'<table class="log-table">(.*?)</table>', self.raw, re.DOTALL)
        if not log_section:
            return

        rows = re.finditer(r'<tr[^>]*>\s*(.*?)\s*</tr>', log_section.group(1), re.DOTALL)
        for row in rows:
            cells = re.findall(r'<td[^>]*>(.*?)</td>', row.group(1), re.DOTALL)
            if len(cells) < 8:
                continue

            entry = ScanLogEntry()
            seq_text = decode_html(cells[0])
            if seq_text.isdigit():
                entry.seq = int(seq_text)
            else:
                continue
            entry.time = decode_html(cells[1])
            entry.test = decode_html(cells[2])
            entry.url = decode_html(cells[3])
            entry.method = decode_html(cells[4])
            entry.status = decode_html(cells[5])
            vuln_text = decode_html(cells[6])
            entry.vuln = "YES" if "yes" in vuln_text.lower() else "NO"
            entry.response = decode_html(cells[7])
            self.scan_log.append(entry)


class DataExporter:

    def __init__(self, parser: ReportParser):
        self.p = parser

    def to_json(self, output_path):
        data = {
            "scan_metadata": {
                "target": self.p.metadata.target,
                "generated": self.p.metadata.generated,
                "duration": self.p.metadata.duration,
                "tests_run": self.p.metadata.tests,
                "requests_sent": self.p.metadata.requests,
                "pages_scanned": self.p.metadata.pages_scanned,
                "total_vulnerabilities": self.p.metadata.vulnerabilities,
                "total_connections": self.p.metadata.connections,
                "severity_breakdown": {
                    "critical": self.p.metadata.critical,
                    "high": self.p.metadata.high,
                    "medium": self.p.metadata.medium,
                    "low": self.p.metadata.low,
                    "info": self.p.metadata.info,
                },
                "categories": self.p.metadata.categories,
            },
            "connection_chains": [
                {"description": c.description, "linked_findings": c.linked_findings}
                for c in self.p.connection_chains
            ],
            "findings": [
                {
                    "id": f.finding_id,
                    "category": f.category,
                    "title": f.title,
                    "severity": f.severity,
                    "cwe": f.cwe,
                    "timestamp": f.timestamp,
                    "description": f.description,
                    "evidence": f.evidence,
                    "response_data": f.response_data,
                    "fix": f.fix,
                    "connected": f.connected,
                    "connection_chains": f.connection_chains,
                }
                for f in self.p.findings
            ],
            "scan_log": [
                {
                    "seq": e.seq,
                    "time": e.time,
                    "test": e.test,
                    "url": e.url,
                    "method": e.method,
                    "status": e.status,
                    "vuln": e.vuln,
                    "response_snippet": e.response[:500],
                }
                for e in self.p.scan_log
            ],
        }

        with open(output_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
        print(f"  \033[32m[JSON]\033[0m {output_path}  ({len(self.p.findings)} findings, {len(self.p.scan_log)} log entries)")
        return output_path

    def to_csv(self, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        safe = re.sub(r'[^\w\-.]', '_', self.p.metadata.target.replace("https://", "").replace("http://", ""))
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        findings_path = os.path.join(output_dir, f"findings_{safe}_{ts}.csv")
        with open(findings_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["ID", "Category", "Title", "Severity", "CWE", "Timestamp",
                         "Description", "Evidence", "Response Data", "Fix",
                         "Connected", "Connection Chains"])
            for f in self.p.findings:
                w.writerow([
                    f.finding_id, f.category, f.title, f.severity, f.cwe,
                    f.timestamp, f.description, f.evidence, f.response_data,
                    f.fix, "YES" if f.connected else "NO",
                    " | ".join(f.connection_chains)
                ])
        print(f"  \033[32m[CSV]\033[0m {findings_path}  ({len(self.p.findings)} findings)")

        log_path = os.path.join(output_dir, f"scanlog_{safe}_{ts}.csv")
        with open(log_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["Seq", "Time", "Test", "URL", "Method", "Status", "Vuln", "Response"])
            for e in self.p.scan_log:
                w.writerow([e.seq, e.time, e.test, e.url, e.method, e.status, e.vuln, e.response[:500]])
        print(f"  \033[32m[CSV]\033[0m {log_path}  ({len(self.p.scan_log)} log entries)")

        chains_path = os.path.join(output_dir, f"chains_{safe}_{ts}.csv")
        with open(chains_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["Description", "Linked Findings"])
            for c in self.p.connection_chains:
                w.writerow([c.description, c.linked_findings])
        print(f"  \033[32m[CSV]\033[0m {chains_path}  ({len(self.p.connection_chains)} chains)")

        return [findings_path, log_path, chains_path]

    def to_sql(self, output_path):
        def esc(val):
            if val is None:
                return "NULL"
            s = str(val).replace("'", "''").replace("\\", "\\\\")
            return f"'{s}'"

        lines = []
        lines.append("-- Alpha Scan Data Extractor™ v{} — SQL Dump".format(VERSION))
        lines.append("-- (C) 2026 Alpha Unlimited Technologies LLC")
        lines.append("-- Target: {}".format(self.p.metadata.target))
        lines.append("-- Generated: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        lines.append("")

        lines.append("DROP TABLE IF EXISTS scan_metadata;")
        lines.append("DROP TABLE IF EXISTS findings;")
        lines.append("DROP TABLE IF EXISTS finding_connections;")
        lines.append("DROP TABLE IF EXISTS scan_log;")
        lines.append("DROP TABLE IF EXISTS connection_chains;")
        lines.append("")

        lines.append("""CREATE TABLE scan_metadata (
  id INT AUTO_INCREMENT PRIMARY KEY,
  target VARCHAR(500) NOT NULL,
  scan_date VARCHAR(50),
  duration VARCHAR(20),
  tests_run INT DEFAULT 0,
  requests_sent INT DEFAULT 0,
  pages_scanned INT DEFAULT 0,
  total_vulnerabilities INT DEFAULT 0,
  total_connections INT DEFAULT 0,
  critical_count INT DEFAULT 0,
  high_count INT DEFAULT 0,
  medium_count INT DEFAULT 0,
  low_count INT DEFAULT 0,
  info_count INT DEFAULT 0
);""")
        lines.append("")

        lines.append("""CREATE TABLE findings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  finding_id VARCHAR(30) NOT NULL,
  category VARCHAR(100),
  title VARCHAR(500),
  severity ENUM('CRITICAL','HIGH','MEDIUM','LOW','INFO') NOT NULL,
  cwe VARCHAR(20),
  discovered_at VARCHAR(50),
  description TEXT,
  evidence TEXT,
  response_data LONGTEXT,
  fix TEXT,
  is_connected BOOLEAN DEFAULT FALSE
);""")
        lines.append("")

        lines.append("""CREATE TABLE finding_connections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  finding_id VARCHAR(30) NOT NULL,
  chain_description TEXT,
  FOREIGN KEY (finding_id) REFERENCES findings(finding_id)
);""")
        lines.append("")

        lines.append("""CREATE TABLE connection_chains (
  id INT AUTO_INCREMENT PRIMARY KEY,
  description TEXT,
  linked_findings TEXT
);""")
        lines.append("")

        lines.append("""CREATE TABLE scan_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seq INT NOT NULL,
  log_time VARCHAR(20),
  test_name VARCHAR(100),
  url VARCHAR(2000),
  method VARCHAR(10),
  status_code VARCHAR(10),
  is_vuln VARCHAR(5),
  response_snippet TEXT
);""")
        lines.append("")

        lines.append("-- ═══════════════════════════════════════════════")
        lines.append("-- SCAN METADATA")
        lines.append("-- ═══════════════════════════════════════════════")
        lines.append(
            f"INSERT INTO scan_metadata (target, scan_date, duration, tests_run, requests_sent, "
            f"pages_scanned, total_vulnerabilities, total_connections, critical_count, high_count, "
            f"medium_count, low_count, info_count) VALUES ("
            f"{esc(self.p.metadata.target)}, {esc(self.p.metadata.generated)}, "
            f"{esc(self.p.metadata.duration)}, {self.p.metadata.tests}, {self.p.metadata.requests}, "
            f"{self.p.metadata.pages_scanned}, {self.p.metadata.vulnerabilities}, "
            f"{self.p.metadata.connections}, {self.p.metadata.critical}, {self.p.metadata.high}, "
            f"{self.p.metadata.medium}, {self.p.metadata.low}, {self.p.metadata.info});"
        )
        lines.append("")

        lines.append("-- ═══════════════════════════════════════════════")
        lines.append(f"-- FINDINGS ({len(self.p.findings)} vulnerabilities)")
        lines.append("-- ═══════════════════════════════════════════════")
        for f in self.p.findings:
            lines.append(
                f"INSERT INTO findings (finding_id, category, title, severity, cwe, discovered_at, "
                f"description, evidence, response_data, fix, is_connected) VALUES ("
                f"{esc(f.finding_id)}, {esc(f.category)}, {esc(f.title)}, {esc(f.severity)}, "
                f"{esc(f.cwe)}, {esc(f.timestamp)}, {esc(f.description)}, {esc(f.evidence)}, "
                f"{esc(f.response_data[:2000])}, {esc(f.fix)}, {'TRUE' if f.connected else 'FALSE'});"
            )
        lines.append("")

        lines.append("-- ═══════════════════════════════════════════════")
        lines.append("-- FINDING CONNECTION CHAINS")
        lines.append("-- ═══════════════════════════════════════════════")
        for f in self.p.findings:
            for chain in f.connection_chains:
                lines.append(
                    f"INSERT INTO finding_connections (finding_id, chain_description) VALUES ("
                    f"{esc(f.finding_id)}, {esc(chain)});"
                )
        lines.append("")

        lines.append("-- ═══════════════════════════════════════════════")
        lines.append(f"-- CONNECTION CHAINS ({len(self.p.connection_chains)} attack chains)")
        lines.append("-- ═══════════════════════════════════════════════")
        for c in self.p.connection_chains:
            lines.append(
                f"INSERT INTO connection_chains (description, linked_findings) VALUES ("
                f"{esc(c.description)}, {esc(c.linked_findings)});"
            )
        lines.append("")

        lines.append("-- ═══════════════════════════════════════════════")
        lines.append(f"-- SCAN LOG ({len(self.p.scan_log)} entries)")
        lines.append("-- ═══════════════════════════════════════════════")
        for e in self.p.scan_log:
            lines.append(
                f"INSERT INTO scan_log (seq, log_time, test_name, url, method, status_code, "
                f"is_vuln, response_snippet) VALUES ("
                f"{e.seq}, {esc(e.time)}, {esc(e.test)}, {esc(e.url)}, {esc(e.method)}, "
                f"{esc(e.status)}, {esc(e.vuln)}, {esc(e.response[:500])});"
            )
        lines.append("")
        lines.append("-- END OF DUMP")

        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))
        print(f"  \033[32m[SQL]\033[0m {output_path}  ({len(self.p.findings)} findings, {len(self.p.scan_log)} log entries)")
        return output_path

    def to_summary(self, output_path=None):
        buf = io.StringIO()
        m = self.p.metadata

        buf.write("=" * 70 + "\n")
        buf.write("  ALPHA SCAN DATA EXTRACTOR™ — FULL VULNERABILITY DUMP\n")
        buf.write("  (C) 2026 Alpha Unlimited Technologies LLC\n")
        buf.write("=" * 70 + "\n\n")

        buf.write(f"  TARGET:           {m.target}\n")
        buf.write(f"  SCAN DATE:        {m.generated}\n")
        buf.write(f"  DURATION:         {m.duration}\n")
        buf.write(f"  TESTS RUN:        {m.tests}\n")
        buf.write(f"  REQUESTS SENT:    {m.requests}\n")
        if m.pages_scanned:
            buf.write(f"  PAGES SCANNED:    {m.pages_scanned}\n")
        buf.write(f"\n  SEVERITY BREAKDOWN:\n")
        buf.write(f"    Critical:       {m.critical}\n")
        buf.write(f"    High:           {m.high}\n")
        buf.write(f"    Medium:         {m.medium}\n")
        buf.write(f"    Low:            {m.low}\n")
        buf.write(f"    Info:           {m.info}\n")
        buf.write(f"    Total:          {m.vulnerabilities}\n")
        buf.write(f"    Connected:      {m.connections}\n")

        if m.categories:
            buf.write(f"\n  CATEGORIES:\n")
            for cat, count in m.categories.items():
                buf.write(f"    {cat}: {count}\n")

        if self.p.connection_chains:
            buf.write(f"\n{'='*70}\n")
            buf.write(f"  ATTACK CHAINS ({len(self.p.connection_chains)})\n")
            buf.write(f"{'='*70}\n\n")
            for i, c in enumerate(self.p.connection_chains, 1):
                buf.write(f"  [{i}] {c.description}\n")
                buf.write(f"      Linked: {c.linked_findings}\n\n")

        buf.write(f"\n{'='*70}\n")
        buf.write(f"  ALL FINDINGS ({len(self.p.findings)})\n")
        buf.write(f"{'='*70}\n")

        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            sev_findings = [f for f in self.p.findings if f.severity == sev]
            if not sev_findings:
                continue
            buf.write(f"\n  ── {sev} ({len(sev_findings)}) {'─'*40}\n\n")
            for f in sev_findings:
                buf.write(f"  [{f.finding_id}] {f.title}\n")
                buf.write(f"    Severity:    {f.severity}\n")
                buf.write(f"    Category:    {f.category}\n")
                if f.cwe:
                    buf.write(f"    CWE:         {f.cwe}\n")
                buf.write(f"    Timestamp:   {f.timestamp}\n")
                buf.write(f"    Description: {f.description}\n")
                if f.evidence:
                    buf.write(f"    Evidence:    {f.evidence}\n")
                if f.response_data:
                    snippet = f.response_data[:300].replace("\n", " ")
                    buf.write(f"    Response:    {snippet}...\n")
                buf.write(f"    Fix:         {f.fix}\n")
                if f.connected:
                    buf.write(f"    Connected:   YES\n")
                    for chain in f.connection_chains:
                        buf.write(f"      -> {chain}\n")
                buf.write("\n")

        buf.write(f"\n{'='*70}\n")
        buf.write(f"  FULL SCAN LOG ({len(self.p.scan_log)} entries)\n")
        buf.write(f"{'='*70}\n\n")

        buf.write(f"  {'#':>4}  {'Time':<14} {'Test':<22} {'Method':<7} {'Status':<7} {'Vuln':<5} URL\n")
        buf.write(f"  {'─'*4}  {'─'*14} {'─'*22} {'─'*7} {'─'*7} {'─'*5} {'─'*40}\n")
        for e in self.p.scan_log:
            vuln_marker = " !!!" if e.vuln == "YES" else "    "
            url_short = e.url[:60] + ("..." if len(e.url) > 60 else "")
            buf.write(f"  {e.seq:>4}  {e.time:<14} {e.test:<22} {e.method:<7} {e.status:<7} {e.vuln:<5}{vuln_marker} {url_short}\n")

        vuln_entries = [e for e in self.p.scan_log if e.vuln == "YES"]
        if vuln_entries:
            buf.write(f"\n  ── VULNERABLE REQUESTS DETAIL ({len(vuln_entries)}) ──\n\n")
            for e in vuln_entries:
                buf.write(f"  [{e.seq}] {e.test} — {e.method} {e.url}\n")
                buf.write(f"    Status: {e.status}\n")
                if e.response:
                    resp_short = e.response[:300].replace("\n", " ")
                    buf.write(f"    Response: {resp_short}\n")
                buf.write("\n")

        buf.write(f"\n{'='*70}\n")
        buf.write(f"  END OF DUMP — {m.vulnerabilities} vulnerabilities across {m.tests} tests\n")
        buf.write(f"{'='*70}\n")

        text = buf.getvalue()

        if output_path:
            with open(output_path, "w", encoding="utf-8") as fh:
                fh.write(text)
            print(f"  \033[32m[TXT]\033[0m {output_path}  ({len(self.p.findings)} findings, {len(self.p.scan_log)} log entries)")
        else:
            print(text)

        return text


def process_report(html_path, fmt="all", output_dir="."):
    html_path = os.path.expanduser(html_path)
    output_dir = os.path.expanduser(output_dir)

    if not os.path.isfile(html_path):
        print(f"  \033[31mERROR:\033[0m File not found: {html_path}")
        return

    with open(html_path, "r", encoding="utf-8", errors="replace") as fh:
        content = fh.read()

    print(f"\n  Parsing: {html_path}")
    print(f"  Size:    {len(content):,} bytes")

    parser = ReportParser(content)
    parser.parse()

    m = parser.metadata
    print(f"\n  Target:  {m.target}")
    print(f"  Found:   {len(parser.findings)} findings, {len(parser.scan_log)} log entries, "
          f"{len(parser.connection_chains)} attack chains")
    print(f"  Severity: {m.critical}C / {m.high}H / {m.medium}M / {m.low}L / {m.info}I\n")

    os.makedirs(output_dir, exist_ok=True)
    safe = re.sub(r'[^\w\-.]', '_', m.target.replace("https://", "").replace("http://", "").rstrip("/"))
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    exporter = DataExporter(parser)
    outputs = []

    if fmt in ("json", "all"):
        path = os.path.join(output_dir, f"dump_{safe}_{ts}.json")
        exporter.to_json(path)
        outputs.append(path)

    if fmt in ("csv", "all"):
        csv_paths = exporter.to_csv(output_dir)
        outputs.extend(csv_paths)

    if fmt in ("sql", "all"):
        path = os.path.join(output_dir, f"dump_{safe}_{ts}.sql")
        exporter.to_sql(path)
        outputs.append(path)

    if fmt in ("summary", "txt", "all"):
        path = os.path.join(output_dir, f"dump_{safe}_{ts}.txt")
        exporter.to_summary(path)
        outputs.append(path)

    if fmt == "print":
        exporter.to_summary()

    return outputs


def run_interactive():
    print(BANNER)
    print("  Enter the path to an Alpha Scan HTML report.\n")

    html_path = input("  Report file: ").strip()
    if not html_path:
        print("  No file provided. Exiting.")
        return

    if not os.path.isfile(os.path.expanduser(html_path)):
        print(f"  \033[31mERROR:\033[0m File not found: {html_path}")
        return

    print("\n  Export formats:")
    print("    1) JSON       — Structured data with all fields")
    print("    2) CSV        — Spreadsheet-ready (findings + log + chains)")
    print("    3) SQL        — MySQL dump (CREATE TABLE + INSERT statements)")
    print("    4) Summary    — Plain-text full vulnerability dump")
    print("    5) All        — Export all formats at once")
    print("    6) Print      — Print summary to terminal only\n")

    choice = input("  Format [5]: ").strip()
    fmt_map = {"1": "json", "2": "csv", "3": "sql", "4": "summary", "5": "all", "6": "print"}
    fmt = fmt_map.get(choice, "all")

    out_dir = input("  Output directory [current]: ").strip() or "."
    out_dir = os.path.expanduser(out_dir)

    process_report(html_path, fmt=fmt, output_dir=out_dir)

    print(f"\n  \033[32mDone.\033[0m All exports saved to: {out_dir}")


def main():
    parser = argparse.ArgumentParser(
        description="Alpha Scan Data Extractor™ — Parse HTML scan reports into structured data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 alpha_scan_extractor.py report.html
  python3 alpha_scan_extractor.py report.html --format json
  python3 alpha_scan_extractor.py report.html --format csv
  python3 alpha_scan_extractor.py report.html --format sql
  python3 alpha_scan_extractor.py report.html --format all -o ~/exports/
  python3 alpha_scan_extractor.py report.html --format print
  python3 alpha_scan_extractor.py  (interactive mode)
        """)
    parser.add_argument("report", nargs="?", help="Path to Alpha Scan HTML report")
    parser.add_argument("--format", "-f", default="all",
        choices=["json", "csv", "sql", "summary", "txt", "all", "print"],
        help="Export format (default: all)")
    parser.add_argument("-o", "--output", default=".", help="Output directory")

    args = parser.parse_args()
    if not args.report:
        run_interactive()
        return

    print(BANNER)
    process_report(args.report, fmt=args.format, output_dir=args.output)
    print(f"\n  \033[32mDone.\033[0m")


if __name__ == "__main__":
    main()
