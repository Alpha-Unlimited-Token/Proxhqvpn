═══════════════════════════════════════════════════════════════
   ALPHA UNIVERSAL SCANNER™ v3.0.0
   © 2024-2026 Alpha Unlimited Technologies
   PROPRIETARY AND CONFIDENTIAL — CONTAINS TRADE SECRETS
═══════════════════════════════════════════════════════════════

REQUIREMENTS:
  - Python 3.8 or higher
  - No external packages needed (uses only Python standard library)

INSTALLATION:
  1. Extract this zip to any folder on your computer
  2. Open a terminal/command prompt in that folder

═══════════════════════════════════════════════════════════════
   QUICK START — INTERACTIVE MODE
═══════════════════════════════════════════════════════════════

Just run with no arguments to get the interactive menu:

  python alpha_scanner.py

It will ask you what you want to scan and walk you through it.
You can point it at:
  - Any FOLDER on your computer
  - Any ZIP file (it auto-extracts and scans)
  - Any TAR.GZ / TAR.BZ2 file (it auto-extracts and scans)
  - Any single file

═══════════════════════════════════════════════════════════════
   COMMAND-LINE USAGE
═══════════════════════════════════════════════════════════════

SCAN EVERYTHING (all modules at once):
  python alpha_scanner.py /path/to/codebase --all

SCAN A ZIP FILE (auto-extracts):
  python alpha_scanner.py /path/to/code.zip --all

SCAN WITH EXPLOITS ONLY:
  python alpha_scanner.py /path/to/codebase --exploits

FULL CODE + EXPLOIT SCAN:
  python alpha_scanner.py /path/to/codebase --deep --exploits

SCAN SPECIFIC LANGUAGE (e.g., C++ only):
  python alpha_scanner.py /path/to/monero --lang cpp --deep --exploits

NETWORK-ONLY SCAN (ports, MAC addresses, services):
  python alpha_scanner.py --network-only --target-ip 192.168.1.1

SECURITY AUDIT ONLY:
  python alpha_scanner.py --security-only /path/to/project

CUSTOM PORT RANGE:
  python alpha_scanner.py /path/to/code --network --ports 1-65535

SAVE REPORT:
  python alpha_scanner.py /path/to/code -o my_report.html
  python alpha_scanner.py /path/to/code -o my_report.json

═══════════════════════════════════════════════════════════════
   HOW TO SCAN DOWNLOADED CODE (e.g., Monero from GitHub)
═══════════════════════════════════════════════════════════════

1. Go to https://github.com/monero-project/monero
2. Click "Code" → "Download ZIP"
3. Save the file (e.g., monero-master.zip)
4. Run the scanner on it:

   python alpha_scanner.py monero-master.zip --all

   OR extract it yourself first and point to the folder:

   python alpha_scanner.py /path/to/monero-master --lang cpp --deep --exploits

═══════════════════════════════════════════════════════════════
   WHAT IT SCANS
═══════════════════════════════════════════════════════════════

CODE ANALYSIS (35+ languages):
  C/C++, Python, JavaScript, TypeScript, Java, C#, PHP, Ruby,
  Rust, Go, Solidity, Swift, Kotlin, Scala, Perl, Lua, R,
  Shell/Bash, PowerShell, HTML, CSS/SCSS/SASS/LESS, SQL,
  YAML, XML, JSON, TOML, Dockerfile, Makefile, CMake,
  Assembly, Objective-C, Dart, Elixir, Haskell, Zig, Nim, V

  200+ vulnerability patterns including:
  - Buffer overflows, memory leaks, use-after-free
  - SQL injection, command injection, XSS
  - Hardcoded credentials, private keys, API keys, JWT tokens
  - Weak cryptography (MD5, SHA-1, DES, RC4)
  - Format string vulnerabilities
  - Unsafe deserialization (pickle, yaml, unserialize)
  - Race conditions (TOCTOU, shared memory)
  - Integer overflow, null pointer dereference
  - Prototype pollution, mass assignment
  - SSRF, XXE, SSTI, open redirects
  - ReDoS, NoSQL injection
  - And many more with CWE classification codes

EXPLOIT DETECTION:
  - Stack/heap buffer overflow exploit vectors
  - Use-after-free exploitable patterns
  - Format string write primitives
  - Integer overflow → heap overflow chains
  - Command injection via system()/popen()
  - Double free heap exploits
  - TOCTOU race condition exploits
  - Uninitialized memory information leaks
  - Type confusion via unsafe casts
  - Reentrancy attacks (Solidity)
  - Flash loan price manipulation
  - Missing access control exploits
  - Delegatecall proxy takeover
  - Prototype pollution → RCE chains
  - DOM XSS, SSTI, deserialization RCE
  - JWT algorithm confusion bypass
  - MULTI-STEP EXPLOIT CHAINS detected automatically

NETWORK SCANNING:
  - Open port detection (all 65535 or common ports)
  - Service identification and banner grabbing
  - Risky port flagging (Telnet, SMB, RDP, Redis, MongoDB, etc.)
  - ARP table / MAC address inspection
  - Routing table analysis
  - Listening services enumeration
  - System information gathering

SECURITY AUDIT:
  - File permission checks (world-writable files)
  - Sensitive file detection (.env, keys, configs)
  - Git credential exposure
  - SSH/private key detection
  - Certificate file scanning
  - Log file secret leakage
  - Backup file exposure
  - Package dependency audit recommendations

═══════════════════════════════════════════════════════════════
   REPORT FEATURES
═══════════════════════════════════════════════════════════════

EVERY FINDING INCLUDES:
  - Exact file path and LINE NUMBER
  - The EXACT CODE that has the bug (highlighted)
  - 3-5 lines of context BEFORE and AFTER the bug
  - CWE vulnerability classification
  - Severity rating (CRITICAL / HIGH / MEDIUM / LOW / INFO)
  - Description of the risk
  - Attack vector (how it would be exploited)
  - Impact assessment
  - Exploitability rating
  - Specific fix recommendation

BUG CONNECTIONS:
  - Detects when bugs are LINKED to each other
  - Adjacent bugs (within 15 lines of each other)
  - Same-file escalation chains
  - Import chain connections
  - Multi-step exploit chains with step-by-step breakdown

WIRING MAP:
  - Shows how ALL files are connected via imports/includes
  - Full dependency tree visualization

OUTPUT FORMATS:
  - Rich HTML report (dark theme, interactive, print-friendly)
  - JSON report (machine-readable)
  - Console output with summary

═══════════════════════════════════════════════════════════════
   ACCEPTED INPUT FORMATS
═══════════════════════════════════════════════════════════════
  - Any folder / directory
  - .zip files (auto-extracted)
  - .tar.gz / .tar.bz2 / .tar.xz files (auto-extracted)
  - .tgz files (auto-extracted)
  - Individual source code files
  - GitHub repository downloads ("Download ZIP")

═══════════════════════════════════════════════════════════════
   EXIT CODES
═══════════════════════════════════════════════════════════════
  0 = No critical vulnerabilities found
  2 = CRITICAL vulnerabilities detected

═══════════════════════════════════════════════════════════════
  All Rights Reserved Worldwide in Perpetuity. Patent Pending.
═══════════════════════════════════════════════════════════════
