#!/usr/bin/env python3
"""
Alpha Vulnerability Verifier v1.0.0
(C) 2026 Alpha Unlimited Technologies LLC
All Rights Reserved - Proprietary and Confidential

Parses Alpha Universal Scanner reports, re-examines source code,
and determines whether findings are TRUE vulnerabilities or false positives.

Usage:
  python3 alpha_verifier.py <report.html> <source_directory> [options]
  python3 alpha_verifier.py report.html /path/to/monero-master --severity critical,high
  python3 alpha_verifier.py report.html /path/to/monero-master --exploits-only
  python3 alpha_verifier.py report.html /path/to/monero-master --id CPP-005
"""

import os
import re
import sys
import json
import html
import time
import hashlib
import argparse
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

VERSION = "1.0.0"
BANNER = f"""
╔══════════════════════════════════════════════════════════════╗
║     Alpha Vulnerability Verifier™ v{VERSION}                    ║
║     (C) 2026 Alpha Unlimited Technologies LLC                ║
║     Proprietary and Confidential                             ║
╚══════════════════════════════════════════════════════════════╝
"""

VERDICT_TRUE = "TRUE_POSITIVE"
VERDICT_FALSE = "FALSE_POSITIVE"
VERDICT_LIKELY_TRUE = "LIKELY_TRUE"
VERDICT_LIKELY_FALSE = "LIKELY_FALSE"
VERDICT_NEEDS_REVIEW = "NEEDS_MANUAL_REVIEW"
VERDICT_UNABLE = "UNABLE_TO_VERIFY"


class Finding:
    def __init__(self):
        self.id = ""
        self.name = ""
        self.severity = ""
        self.file = ""
        self.line = 0
        self.cwe = ""
        self.code_context = ""
        self.description = ""
        self.fix = ""
        self.connected_bugs = 0
        self.is_exploit = False
        self.exploit_name = ""


class VerificationResult:
    def __init__(self, finding, verdict, confidence, reason, evidence=""):
        self.finding = finding
        self.verdict = verdict
        self.confidence = confidence
        self.reason = reason
        self.evidence = evidence


class ReportParser:
    def parse(self, html_path):
        with open(html_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        findings = []
        finding_blocks = re.finditer(
            r'<div style="background:#111;border-left:4px solid #([a-f0-9]+);padding:14px;margin:10px 0;border-radius:4px;">(.*?)</div>\s*(?=<div style="background:#111;border-left|<h2|$)',
            content,
            re.DOTALL
        )

        for block in finding_blocks:
            f = Finding()
            block_html = block.group(2)

            id_match = re.search(r'\[([A-Z]+-\d+)\]\s*(?:EXPLOIT:\s*)?(.+?)(?:</div>|<)', block_html)
            if id_match:
                f.id = id_match.group(1)
                f.name = html.unescape(id_match.group(2).strip())
                f.is_exploit = "EXPLOIT:" in block_html[:200]
                if f.is_exploit:
                    f.exploit_name = f.name

            sev_match = re.search(r'>(CRITICAL|HIGH|MEDIUM|LOW|INFO)<', block_html)
            if sev_match:
                f.severity = sev_match.group(1)

            file_match = re.search(r'📁\s*([^\s<]+)\s*.*?line\s*(\d+)', block_html)
            if file_match:
                f.file = html.unescape(file_match.group(1).strip())
                f.line = int(file_match.group(2))

            cwe_match = re.search(r'CWE:\s*(CWE-\d+)', block_html)
            if cwe_match:
                f.cwe = cwe_match.group(1)

            code_match = re.search(
                r'<div style="background:#0a0a0a;padding:10px;border-radius:4px;margin:8px 0;font-family.*?>(.*?)</div>',
                block_html, re.DOTALL
            )
            if code_match:
                code_html = code_match.group(1)
                code_text = re.sub(r'<[^>]+>', ' ', code_html)
                code_text = html.unescape(code_text)
                f.code_context = code_text.strip()

            desc_match = re.search(
                r'<div style="color:#ccc;font-size:13px;margin:6px 0;">(.*?)</div>',
                block_html, re.DOTALL
            )
            if desc_match:
                f.description = html.unescape(re.sub(r'<[^>]+>', '', desc_match.group(1))).strip()

            fix_match = re.search(r'⚡ Fix:</strong>\s*(.*?)</div>', block_html, re.DOTALL)
            if fix_match:
                f.fix = html.unescape(re.sub(r'<[^>]+>', '', fix_match.group(1))).strip()

            conn_match = re.search(r'CONNECTED BUGS \((\d+)\)', block_html)
            if conn_match:
                f.connected_bugs = int(conn_match.group(1))

            if f.id and f.file:
                findings.append(f)

        return findings


class VulnerabilityVerifier:
    def __init__(self, source_dir=None, verbose=False, report_only=False):
        self.source_dir = Path(source_dir) if source_dir else None
        self.verbose = verbose
        self.report_only = report_only
        self.file_cache = {}
        self.results = []
        self.stats = Counter()

    def _read_file(self, rel_path, context_lines=30):
        if self.report_only or not self.source_dir:
            return None

        if rel_path in self.file_cache:
            return self.file_cache[rel_path]

        fpath = self.source_dir / rel_path
        if not fpath.exists():
            for p in self.source_dir.rglob(Path(rel_path).name):
                if str(p.relative_to(self.source_dir)).endswith(rel_path) or rel_path.endswith(str(p.relative_to(self.source_dir))):
                    fpath = p
                    break

        if not fpath.exists():
            return None

        try:
            content = fpath.read_text(errors="ignore")
            self.file_cache[rel_path] = content
            return content
        except:
            return None

    def _get_context(self, f):
        content = self._read_file(f.file)
        if content:
            lines, idx = self._get_lines(content, f.line)
            if 0 <= idx < len(lines):
                return lines, idx, lines[idx]

        if f.code_context:
            lines = f.code_context.split("\n")
            target_line = ""
            target_idx = 0
            for i, line in enumerate(lines):
                stripped = re.sub(r'^\d+:\s*', '', line).strip()
                line_num_match = re.match(r'^(\d+):', line)
                if line_num_match and int(line_num_match.group(1)) == f.line:
                    target_line = stripped
                    target_idx = i
                    break

            if not target_line and lines:
                mid = len(lines) // 2
                target_line = re.sub(r'^\d+:\s*', '', lines[mid]).strip()
                target_idx = mid

            clean_lines = [re.sub(r'^\d+:\s*', '', l).strip() for l in lines]
            return clean_lines, target_idx, target_line

        return None, -1, ""

    def _get_lines(self, content, target_line, before=15, after=15):
        lines = content.split("\n")
        start = max(0, target_line - 1 - before)
        end = min(len(lines), target_line + after)
        return lines[start:end], target_line - 1 - start

    def _verify_format_string(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        if re.search(r'(?:printf|fprintf|sprintf|snprintf|syslog)\s*\([^,]*,\s*"[^"]*%', target):
            return VerificationResult(f, VERDICT_FALSE, 90,
                "Format string is a hardcoded literal, not user-controlled",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:printf|fprintf|sprintf|snprintf)\s*\([^,]*,\s*sizeof\([^)]+\)\s*(?:,\s*-\s*1)?\s*,\s*"', target):
            return VerificationResult(f, VERDICT_FALSE, 92,
                "snprintf with literal format string and size-bounded buffer",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:MLOG|LOG_PRINT|MDEBUG|MINFO|MWARNING|MERROR|MCLOG|GULPS)', target):
            return VerificationResult(f, VERDICT_FALSE, 85,
                "Logging macro with internal format handling — not exploitable",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:printf|fprintf|sprintf)\s*\(\s*\w+\s*[,)]', target):
            nearby = "\n".join(lines[max(0,idx-5):idx+1])
            if re.search(r'(?:user|input|request|argv|param|query|data|recv|read)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_TRUE, 80,
                    "Variable format string with possible user-controlled input nearby",
                    f"Line {f.line}: {target.strip()}")
            else:
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                    "Variable format string but no user input detected in surrounding context",
                    f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_LIKELY_FALSE, 60,
            "Pattern match detected but likely safe usage with literal format string",
            f"Line {f.line}: {target.strip()}")

    def _verify_null_deref(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        ptr_match = re.search(r'(\w+)\s*->', target) or re.search(r'\*(\w+)', target)
        if not ptr_match:
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 60,
                "No pointer dereference found at indicated line",
                f"Line {f.line}: {target.strip()}")

        ptr_name = ptr_match.group(1)
        pre_context = "\n".join(lines[max(0,idx-15):idx])

        if re.search(rf'if\s*\(\s*!?\s*{re.escape(ptr_name)}\s*\)', pre_context):
            return VerificationResult(f, VERDICT_FALSE, 85,
                f"Null check for '{ptr_name}' found before dereference",
                f"Null-guarded pointer dereference at line {f.line}")

        if re.search(rf'(?:assert|ASSERT|CHECK|VERIFY)\s*\(\s*{re.escape(ptr_name)}\s*\)', pre_context):
            return VerificationResult(f, VERDICT_FALSE, 80,
                f"Assert/check for '{ptr_name}' found before dereference",
                f"Assert-guarded at line {f.line}")

        if re.search(rf'{re.escape(ptr_name)}\s*!=\s*(?:nullptr|NULL|0)', pre_context):
            return VerificationResult(f, VERDICT_FALSE, 85,
                f"Explicit null comparison for '{ptr_name}' before dereference",
                f"Null-compared at line {f.line}")

        if re.search(rf'(?:if|while|for)\s*\([^)]*{re.escape(ptr_name)}\s*(?:!=|==|&&|\|\|)', pre_context):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                f"'{ptr_name}' appears in a conditional before use — possible guard",
                f"Conditional use at line {f.line}")

        if re.search(r'(?:this|self)\s*->', target):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 75,
                "this/self pointer dereference — rarely null in valid object context",
                f"Line {f.line}: {target.strip()}")

        if re.search(rf'{re.escape(ptr_name)}\s*=\s*(?:new|make_|create|alloc|get)', pre_context):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                f"'{ptr_name}' is assigned from a constructor/factory — unlikely null without error",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_LIKELY_TRUE, 60,
            f"Pointer '{ptr_name}' dereferenced without visible null check in preceding {20} lines",
            f"Line {f.line}: {target.strip()}")

    def _verify_buffer_overflow(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        if re.search(r'\b(?:strncpy|strncat|snprintf|memcpy_s|strncpy_s)\b', target):
            return VerificationResult(f, VERDICT_FALSE, 85,
                "Uses bounds-checked string function (strncpy/snprintf)",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'\b(?:strcpy|strcat|sprintf|gets)\s*\(', target):
            nearby = "\n".join(lines[max(0,idx-10):idx+5])
            if re.search(r'\b(?:strlen|sizeof|strnlen)\b', nearby):
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                    "Unsafe function used but size checks present nearby",
                    f"Line {f.line}: {target.strip()}")

            if re.search(r'(?:user|input|argv|param|recv|read|fgets|getenv)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_TRUE, 85,
                    "Unsafe string function with user-controlled input nearby — exploitable buffer overflow",
                    f"Line {f.line}: {target.strip()}")

            return VerificationResult(f, VERDICT_LIKELY_TRUE, 70,
                "Unsafe string function without visible bounds checking",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'\bmemcpy\s*\(', target):
            nearby = "\n".join(lines[max(0,idx-5):idx+3])
            if re.search(r'sizeof\s*\(', nearby):
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                    "memcpy with sizeof — likely properly bounded",
                    f"Line {f.line}: {target.strip()}")
            return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
                "memcpy without visible sizeof — needs manual size verification",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "Buffer operation detected — needs context analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_integer_overflow(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        nearby = "\n".join(lines[max(0,idx-10):idx+5]) if lines else target

        if re.search(r'(?:static_cast|safe_|check_|overflow|OVERFLOW|MAX_|SIZE_MAX|UINT_MAX|INT_MAX)', nearby):
            return VerificationResult(f, VERDICT_FALSE, 80,
                "Overflow guards or safe casts present in context",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:assert|throw|return.*error|if\s*\(.*[<>=])', nearby):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                "Boundary checks or error handling present nearby",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:size_t|uint\d+_t|unsigned)\s+\w+\s*=\s*\w+\s*[\*\+\-]', target):
            if re.search(r'(?:user|input|argv|param|request)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_TRUE, 75,
                    "Arithmetic on unsigned type with possible user input — overflow risk",
                    f"Line {f.line}: {target.strip()}")
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 55,
                "Unchecked arithmetic on unsigned type",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 45,
            "Integer arithmetic detected — needs manual overflow analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_memory_leak(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        post_context = "\n".join(lines[idx:min(len(lines), idx+30)]) if lines else target

        new_match = re.search(r'(?:new\s+\w+|malloc|calloc|realloc)\b', target)
        if not new_match:
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 60,
                "No allocation found at indicated line",
                f"Line {f.line}: {target.strip()}")

        assign_match = re.search(r'(\w+)\s*(?:=|\.reset\()', target)
        var_name = assign_match.group(1) if assign_match else None

        if re.search(r'(?:unique_ptr|shared_ptr|auto_ptr|scoped_ptr|RAII|smart)', target):
            return VerificationResult(f, VERDICT_FALSE, 90,
                "Allocation wrapped in smart pointer — no leak",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:unique_ptr|shared_ptr)\s*<', target) or re.search(r'\.reset\s*\(', target):
            return VerificationResult(f, VERDICT_FALSE, 90,
                "Smart pointer reset — memory managed automatically",
                f"Line {f.line}: {target.strip()}")

        if var_name and re.search(rf'(?:delete|free)\s*(?:\[\])?\s*{re.escape(var_name)}', post_context):
            return VerificationResult(f, VERDICT_FALSE, 85,
                f"'{var_name}' is freed/deleted within the same scope",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'return\s+(?:new|malloc|calloc)', target):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                "Allocation returned to caller — ownership transferred (caller responsible)",
                f"Line {f.line}: {target.strip()}")

        if var_name and re.search(rf'(?:push_back|emplace|insert|append)\s*\(\s*{re.escape(var_name)}', post_context):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                f"'{var_name}' stored in container — container manages lifetime",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_LIKELY_TRUE, 55,
            "Raw allocation without visible smart pointer or delete in scope",
            f"Line {f.line}: {target.strip()}")

    def _verify_unsafe_cast(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        if re.search(r'static_cast\s*<', target):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 75,
                "Uses static_cast (compile-time checked) — lower risk than reinterpret_cast",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'dynamic_cast\s*<', target):
            return VerificationResult(f, VERDICT_FALSE, 90,
                "Uses dynamic_cast (runtime-checked) — safe type conversion",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'reinterpret_cast\s*<', target):
            if re.search(r'reinterpret_cast\s*<\s*(?:const\s+)?(?:char|uint8_t|unsigned\s+char|void)\s*\*', target):
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                    "reinterpret_cast to byte/char pointer — common serialization pattern",
                    f"Line {f.line}: {target.strip()}")
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 65,
                "reinterpret_cast to non-trivial type — potential type confusion",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'\(\s*(?:(?:const\s+)?(?:char|uint8_t|void)\s*\*)\s*\)', target):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                "C-style cast to byte/void pointer — common pattern, usually safe",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'\(\s*\w+\s*\*\s*\)', target):
            nearby = "\n".join(lines[max(0,idx-5):idx+3])
            if re.search(r'(?:serialize|deserialize|pack|unpack|wire|network|protocol)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 60,
                    "C-style cast in serialization context — intentional low-level access",
                    f"Line {f.line}: {target.strip()}")
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 60,
                "C-style pointer cast — potential type confusion without runtime check",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "Cast pattern detected — needs manual type analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_path_traversal(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        nearby = "\n".join(lines[max(0,idx-10):idx+5]) if lines else target

        if re.search(r'(?:sanitize|normalize|realpath|abspath|resolve|canonical|clean)', nearby, re.IGNORECASE):
            return VerificationResult(f, VERDICT_FALSE, 80,
                "Path sanitization/normalization found in context",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:\.\.|\.\.\/|\.\.\\)', nearby):
            if re.search(r'(?:check|valid|assert|deny|reject|block)', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_FALSE, 75,
                    "Path traversal pattern with validation check",
                    f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:os\.path\.join|Path\(|pathlib)', target):
            if re.search(r'(?:user|input|request|argv|param|query)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_LIKELY_TRUE, 70,
                    "Path constructed from user input without visible sanitization",
                    f"Line {f.line}: {target.strip()}")
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                "Path construction without user input in immediate context",
                f"Line {f.line}: {target.strip()}")

        if "test" in f.file.lower() or "test" in nearby.lower():
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                "Finding is in test code — lower risk in production",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "Path operation detected — needs manual input source analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_rop_gadget(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        nearby = "\n".join(lines[max(0,idx-5):idx+5]) if lines else target

        if re.search(r'(?:memcpy|strcpy|sprintf|gets|scanf)\s*\(', nearby):
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 65,
                "ROP gadget near unsafe memory operation — exploitable if input-controlled",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:virtual|override|vtable)\b', nearby):
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 60,
                "ROP gadget near virtual function dispatch — potential hijack target",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_LIKELY_FALSE, 55,
            "ROP gadget surface exists but requires separate memory corruption to exploit",
            f"Line {f.line}: {target.strip()}")

    def _verify_null_byte_injection(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        nearby = "\n".join(lines[max(0,idx-8):idx+5]) if lines else target

        if re.search(r'\.(?:data|c_str|size|length)\s*\(\s*\)', target):
            if re.search(r'(?:memcmp|memcpy|memmove)\b', nearby):
                return VerificationResult(f, VERDICT_LIKELY_FALSE, 70,
                    "Binary data access with length-aware functions — intentional",
                    f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:std::string|string_view|basic_string)', nearby):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 65,
                "C++ std::string handles embedded nulls — lower injection risk",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:strlen|strcmp|strstr|strchr)\s*\(', target):
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 65,
                "C string function that stops at null — truncation possible",
                f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "String/byte operation — needs manual null-handling analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_shell_injection(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        nearby = "\n".join(lines[max(0,idx-5):idx+3]) if lines else target

        if re.search(r'(?:subprocess\.call|system|popen|exec|eval)\s*\(', target):
            if re.search(r'(?:shlex\.quote|pipes\.quote|escapeshellarg|shell=False)', nearby):
                return VerificationResult(f, VERDICT_FALSE, 80,
                    "Shell command with proper input escaping",
                    f"Line {f.line}: {target.strip()}")

            if re.search(r'(?:user|input|argv|request|param|query)\b', nearby, re.IGNORECASE):
                return VerificationResult(f, VERDICT_TRUE, 85,
                    "Shell command with user-controlled input — command injection risk",
                    f"Line {f.line}: {target.strip()}")

            if re.search(r'f".*\{|\.format\(|%\s', target):
                return VerificationResult(f, VERDICT_LIKELY_TRUE, 70,
                    "Shell command with string interpolation — injection possible",
                    f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "Shell-related operation — needs input source analysis",
            f"Line {f.line}: {target.strip()}")

    def _verify_hardcoded_creds(self, f):
        lines, idx, target = self._get_context(f)
        if not target:
            return VerificationResult(f, VERDICT_UNABLE, 0, "No source context available")

        if "test" in f.file.lower() or "mock" in f.file.lower() or "example" in f.file.lower():
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 75,
                "Credential in test/mock/example file — not production code",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:TODO|FIXME|placeholder|dummy|example|changeme|xxxx)\b', target, re.IGNORECASE):
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 80,
                "Placeholder/dummy credential — not a real secret",
                f"Line {f.line}: {target.strip()}")

        if re.search(r'(?:password|secret|key|token)\s*[=:]\s*["\'][A-Za-z0-9+/=_\-]{16,}["\']', target, re.IGNORECASE):
            entropy = self._shannon_entropy(re.search(r'["\']([A-Za-z0-9+/=_\-]{16,})["\']', target).group(1))
            if entropy > 4.0:
                return VerificationResult(f, VERDICT_TRUE, 85,
                    f"High-entropy string ({entropy:.1f} bits) in credential assignment — likely real secret",
                    f"Line {f.line}: {target.strip()}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 50,
            "Potential hardcoded credential — needs manual review",
            f"Line {f.line}: {target.strip()}")

    def _verify_deep_finding(self, f):
        if "Long Function" in f.name or "DEEP-003" in f.id:
            match = re.search(r'(\d+)\s*lines', f.name)
            if match:
                line_count = int(match.group(1))
                if line_count > 500:
                    return VerificationResult(f, VERDICT_TRUE, 80,
                        f"Function is {line_count} lines — exceeds recommended maximum of 100-200 lines",
                        f"Complexity issue in {f.file}")
                elif line_count > 200:
                    return VerificationResult(f, VERDICT_LIKELY_TRUE, 65,
                        f"Function is {line_count} lines — moderately long",
                        f"Code quality concern in {f.file}")
            return VerificationResult(f, VERDICT_LIKELY_TRUE, 55,
                "Long function detected",
                f"Code quality concern in {f.file}")

        if "Complexity" in f.name or "DEEP-001" in f.id:
            return VerificationResult(f, VERDICT_TRUE, 70,
                "High cyclomatic complexity confirmed — increases bug probability",
                f"Complexity issue in {f.file}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 45,
            "Deep analysis finding — needs manual code review",
            f"In {f.file}")

    def _verify_generic(self, f):
        if "test" in f.file.lower():
            return VerificationResult(f, VERDICT_LIKELY_FALSE, 60,
                "Finding in test code — lower production risk",
                f"File: {f.file}")

        return VerificationResult(f, VERDICT_NEEDS_REVIEW, 40,
            f"Automatic verification not available for {f.id} — manual review needed",
            f"File: {f.file}:{f.line}")

    def _shannon_entropy(self, data):
        if not data:
            return 0
        freq = defaultdict(int)
        for c in data:
            freq[c] += 1
        import math
        entropy = 0.0
        for count in freq.values():
            p = count / len(data)
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def verify(self, finding):
        verifiers = {
            "CPP-005": self._verify_format_string,
            "CPP-007": self._verify_null_deref,
            "CPP-001": self._verify_buffer_overflow,
            "CPP-004": self._verify_integer_overflow,
            "CPP-002": self._verify_memory_leak,
            "CPP-011": self._verify_unsafe_cast,
            "CPP-003": self._verify_buffer_overflow,
            "PY-009": self._verify_path_traversal,
            "PY-001": self._verify_shell_injection,
            "PY-002": self._verify_shell_injection,
            "SH-001": self._verify_shell_injection,
            "SH-002": self._verify_shell_injection,
            "CPP-008": self._verify_hardcoded_creds,
            "EXP-CPP-004": self._verify_format_string,
            "EXP-CPP-010": self._verify_rop_gadget,
            "EXP-CPP-011": self._verify_unsafe_cast,
            "EXP-CPP-013": self._verify_null_byte_injection,
            "EXP-PY-005": self._verify_path_traversal,
            "DEEP-001": self._verify_deep_finding,
            "DEEP-003": self._verify_deep_finding,
            "DEEP-006": self._verify_deep_finding,
        }

        base_id = finding.id
        verifier = verifiers.get(base_id, self._verify_generic)
        return verifier(finding)

    def verify_all(self, findings, max_per_type=None):
        total = len(findings)
        processed = 0
        type_counts = Counter()

        for f in findings:
            if max_per_type and type_counts[f.id] >= max_per_type:
                continue

            type_counts[f.id] += 1
            processed += 1
            result = self.verify(f)
            self.results.append(result)
            self.stats[result.verdict] += 1

            if self.verbose and processed % 100 == 0:
                print(f"  [{processed}/{total}] verified...", flush=True)

        return self.results


class ReportGenerator:
    def generate_html(self, results, output_path, original_report=""):
        true_pos = [r for r in results if r.verdict in (VERDICT_TRUE, VERDICT_LIKELY_TRUE)]
        false_pos = [r for r in results if r.verdict in (VERDICT_FALSE, VERDICT_LIKELY_FALSE)]
        review = [r for r in results if r.verdict == VERDICT_NEEDS_REVIEW]
        unable = [r for r in results if r.verdict == VERDICT_UNABLE]

        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        true_pos.sort(key=lambda r: (sev_order.get(r.finding.severity, 5), -r.confidence))

        verdict_colors = {
            VERDICT_TRUE: "#ff2222",
            VERDICT_LIKELY_TRUE: "#ff6644",
            VERDICT_FALSE: "#4ade80",
            VERDICT_LIKELY_FALSE: "#88cc88",
            VERDICT_NEEDS_REVIEW: "#ffcc00",
            VERDICT_UNABLE: "#888888",
        }

        verdict_labels = {
            VERDICT_TRUE: "CONFIRMED TRUE",
            VERDICT_LIKELY_TRUE: "LIKELY TRUE",
            VERDICT_FALSE: "CONFIRMED FALSE POSITIVE",
            VERDICT_LIKELY_FALSE: "LIKELY FALSE POSITIVE",
            VERDICT_NEEDS_REVIEW: "NEEDS MANUAL REVIEW",
            VERDICT_UNABLE: "UNABLE TO VERIFY",
        }

        sev_colors = {
            "CRITICAL": "#ff2222",
            "HIGH": "#ff8800",
            "MEDIUM": "#ffcc00",
            "LOW": "#4488ff",
            "INFO": "#888888",
        }

        html_parts = [f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alpha Vulnerability Verification Report</title>
<style>
body {{ background:#0a0a0a; color:#fff; font-family:'Segoe UI',Arial,sans-serif; padding:20px; max-width:1400px; margin:0 auto; line-height:1.6; }}
details > summary {{ font-weight:bold; cursor:pointer; padding:8px 0; }}
details > summary:hover {{ color:#d4a017; }}
::-webkit-scrollbar {{ width:8px; }}
::-webkit-scrollbar-track {{ background:#111; }}
::-webkit-scrollbar-thumb {{ background:#333; border-radius:4px; }}
.card {{ background:#111; border-radius:8px; padding:16px; margin:8px 0; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:20px 0; }}
.stat {{ background:#111; padding:18px; border-radius:8px; text-align:center; border:1px solid #222; }}
.stat .num {{ font-size:28px; font-weight:bold; }}
.stat .label {{ color:#888; font-size:12px; }}
.finding {{ border-left:4px solid; padding:12px; margin:6px 0; border-radius:4px; background:#111; }}
.badge {{ padding:2px 10px; border-radius:12px; font-size:11px; font-weight:bold; display:inline-block; }}
code {{ background:#0a0a0a; padding:2px 6px; border-radius:3px; font-family:'Courier New',monospace; font-size:12px; }}
.progress {{ width:100%; height:24px; background:#222; border-radius:12px; overflow:hidden; margin:10px 0; }}
.progress-bar {{ height:100%; border-radius:12px; transition:width 0.3s; }}
@media print {{ body {{ background:#fff; color:#000; }} }}
</style>
</head>
<body>

<div style="text-align:center;border-bottom:2px solid #d4a017;padding-bottom:20px;margin-bottom:30px;">
<div style="font-size:11px;color:#d4a017;letter-spacing:4px;margin-bottom:8px;">ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY AND CONFIDENTIAL</div>
<h1 style="margin:10px 0;font-size:28px;">Alpha Vulnerability Verification Report</h1>
<div style="color:#888;font-size:14px;">Automated True/False Positive Analysis</div>
<div style="color:#666;font-size:12px;margin-top:8px;">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Findings Verified: {len(results)}</div>
</div>
"""]

        total = len(results)
        tp = len(true_pos)
        fp = len(false_pos)
        rev = len(review)
        una = len(unable)
        tp_pct = (tp / total * 100) if total else 0
        fp_pct = (fp / total * 100) if total else 0

        html_parts.append(f"""
<div class="grid">
<div class="stat"><div class="num" style="color:#4ade80;">{total}</div><div class="label">Total Verified</div></div>
<div class="stat" style="border-color:#ff2222;"><div class="num" style="color:#ff2222;">{tp}</div><div class="label">True Positives</div></div>
<div class="stat" style="border-color:#4ade80;"><div class="num" style="color:#4ade80;">{fp}</div><div class="label">False Positives</div></div>
<div class="stat" style="border-color:#ffcc00;"><div class="num" style="color:#ffcc00;">{rev}</div><div class="label">Needs Review</div></div>
<div class="stat"><div class="num" style="color:#888;">{una}</div><div class="label">Unable to Verify</div></div>
<div class="stat" style="border-color:#ff4444;"><div class="num" style="color:#ff4444;">{tp_pct:.1f}%</div><div class="label">True Positive Rate</div></div>
<div class="stat" style="border-color:#4ade80;"><div class="num" style="color:#4ade80;">{fp_pct:.1f}%</div><div class="label">False Positive Rate</div></div>
</div>

<div style="margin:20px 0;">
<div style="color:#d4a017;font-weight:bold;margin-bottom:8px;">Verification Distribution</div>
<div class="progress">
<div class="progress-bar" style="width:{tp_pct}%;background:#ff4444;float:left;" title="True Positives: {tp}"></div>
<div class="progress-bar" style="width:{fp_pct}%;background:#4ade80;float:left;" title="False Positives: {fp}"></div>
<div class="progress-bar" style="width:{rev/total*100 if total else 0}%;background:#ffcc00;float:left;" title="Needs Review: {rev}"></div>
<div class="progress-bar" style="width:{una/total*100 if total else 0}%;background:#555;float:left;" title="Unable: {una}"></div>
</div>
<div style="font-size:12px;color:#888;">
<span style="color:#ff4444;">■</span> True Positives ({tp})
<span style="margin-left:15px;color:#4ade80;">■</span> False Positives ({fp})
<span style="margin-left:15px;color:#ffcc00;">■</span> Needs Review ({rev})
<span style="margin-left:15px;color:#555;">■</span> Unable ({una})
</div>
</div>
""")

        type_stats = defaultdict(lambda: defaultdict(int))
        for r in results:
            type_stats[r.finding.id][r.verdict] += 1

        html_parts.append("""
<h2 style="color:#d4a017;margin-top:30px;border-bottom:1px solid #333;padding-bottom:8px;">VERIFICATION BY FINDING TYPE</h2>
<table style="width:100%;border-collapse:collapse;margin:10px 0;">
<tr style="border-bottom:2px solid #333;">
<th style="text-align:left;padding:8px;color:#d4a017;">Finding ID</th>
<th style="text-align:center;padding:8px;color:#ff4444;">True</th>
<th style="text-align:center;padding:8px;color:#4ade80;">False</th>
<th style="text-align:center;padding:8px;color:#ffcc00;">Review</th>
<th style="text-align:center;padding:8px;color:#888;">Unable</th>
<th style="text-align:center;padding:8px;color:#d4a017;">Total</th>
</tr>
""")
        for fid in sorted(type_stats.keys()):
            stats = type_stats[fid]
            tp_c = stats.get(VERDICT_TRUE, 0) + stats.get(VERDICT_LIKELY_TRUE, 0)
            fp_c = stats.get(VERDICT_FALSE, 0) + stats.get(VERDICT_LIKELY_FALSE, 0)
            rev_c = stats.get(VERDICT_NEEDS_REVIEW, 0)
            una_c = stats.get(VERDICT_UNABLE, 0)
            tot_c = tp_c + fp_c + rev_c + una_c
            html_parts.append(f"""<tr style="border-bottom:1px solid #222;">
<td style="padding:6px;font-family:monospace;color:#fff;">{fid}</td>
<td style="text-align:center;padding:6px;color:#ff4444;">{tp_c}</td>
<td style="text-align:center;padding:6px;color:#4ade80;">{fp_c}</td>
<td style="text-align:center;padding:6px;color:#ffcc00;">{rev_c}</td>
<td style="text-align:center;padding:6px;color:#888;">{una_c}</td>
<td style="text-align:center;padding:6px;color:#d4a017;font-weight:bold;">{tot_c}</td>
</tr>""")

        html_parts.append("</table>")

        sections = [
            ("CONFIRMED TRUE POSITIVES — Action Required", true_pos, "#ff2222"),
            ("NEEDS MANUAL REVIEW", review, "#ffcc00"),
            ("CONFIRMED FALSE POSITIVES", false_pos, "#4ade80"),
            ("UNABLE TO VERIFY", unable, "#888888"),
        ]

        for title, items, color in sections:
            if not items:
                continue
            html_parts.append(f"""
<h2 style="color:{color};margin-top:30px;border-bottom:1px solid {color};padding-bottom:8px;">{title} — {len(items)} findings</h2>
""")
            for r in items:
                sev_color = sev_colors.get(r.finding.severity, "#888")
                v_color = verdict_colors.get(r.verdict, "#888")
                v_label = verdict_labels.get(r.verdict, r.verdict)
                html_parts.append(f"""
<div class="finding" style="border-color:{sev_color};">
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
<div style="font-weight:bold;color:{sev_color};">
[{r.finding.id}] {self._esc(r.finding.name)[:100]}
{' <span style="color:#ff4444;font-size:11px;">★ EXPLOIT</span>' if r.finding.is_exploit else ''}
</div>
<div>
<span class="badge" style="background:{sev_color}22;color:{sev_color};">{r.finding.severity}</span>
<span class="badge" style="background:{v_color}22;color:{v_color};margin-left:4px;">{v_label}</span>
<span class="badge" style="background:#33333322;color:#888;margin-left:4px;">{r.confidence}% conf</span>
</div>
</div>
<div style="color:#888;font-size:12px;margin:4px 0;font-family:monospace;">
{self._esc(r.finding.file)} : line {r.finding.line} | {r.finding.cwe}
</div>
<div style="color:#ccc;font-size:13px;margin:6px 0;">
<strong style="color:{v_color};">Verdict:</strong> {self._esc(r.reason)}
</div>
{f'<div style="background:#0a0a0a;padding:8px;border-radius:4px;margin:6px 0;font-family:monospace;font-size:11px;color:#aaa;overflow-x:auto;">{self._esc(r.evidence)}</div>' if r.evidence else ''}
{f'<div style="color:#d4a017;font-size:12px;">Fix: {self._esc(r.finding.fix)}</div>' if r.finding.fix and r.verdict in (VERDICT_TRUE, VERDICT_LIKELY_TRUE) else ''}
</div>
""")

        html_parts.append(f"""
<div style="text-align:center;border-top:1px solid #333;padding-top:20px;margin-top:40px;color:#555;font-size:12px;">
Alpha Vulnerability Verifier v{VERSION} | Alpha Unlimited Technologies LLC<br>
Generated {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
</div>
</body></html>""")

        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text("".join(html_parts), encoding="utf-8")
        return str(output)

    def generate_json(self, results, output_path):
        data = {
            "version": VERSION,
            "generated": datetime.now().isoformat(),
            "total_verified": len(results),
            "summary": {
                "true_positives": len([r for r in results if r.verdict in (VERDICT_TRUE, VERDICT_LIKELY_TRUE)]),
                "false_positives": len([r for r in results if r.verdict in (VERDICT_FALSE, VERDICT_LIKELY_FALSE)]),
                "needs_review": len([r for r in results if r.verdict == VERDICT_NEEDS_REVIEW]),
                "unable": len([r for r in results if r.verdict == VERDICT_UNABLE]),
            },
            "results": []
        }

        for r in results:
            data["results"].append({
                "finding_id": r.finding.id,
                "finding_name": r.finding.name,
                "severity": r.finding.severity,
                "file": r.finding.file,
                "line": r.finding.line,
                "cwe": r.finding.cwe,
                "is_exploit": r.finding.is_exploit,
                "verdict": r.verdict,
                "confidence": r.confidence,
                "reason": r.reason,
                "evidence": r.evidence,
            })

        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return str(output)

    def _esc(self, text):
        if not text:
            return ""
        return (str(text)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))


def main():
    parser = argparse.ArgumentParser(
        description="Alpha Vulnerability Verifier - Verify scanner findings against source code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 alpha_verifier.py report.html /path/to/source
  python3 alpha_verifier.py report.html --report-only
  python3 alpha_verifier.py report.html /path/to/source --severity critical,high
  python3 alpha_verifier.py report.html /path/to/source --exploits-only
  python3 alpha_verifier.py report.html /path/to/source --id CPP-005,CPP-007
  python3 alpha_verifier.py report.html /path/to/source --max-per-type 50
  python3 alpha_verifier.py report.html /path/to/source -o ~/Desktop/verified.html
        """
    )

    parser.add_argument("report", help="Path to Alpha Universal Scanner HTML report")
    parser.add_argument("source", nargs="?", default=None, help="Path to source code directory (optional with --report-only)")
    parser.add_argument("-o", "--output", help="Output file path (default: verification_report.html)")
    parser.add_argument("--json", action="store_true", help="Also generate JSON output")
    parser.add_argument("--report-only", action="store_true", help="Verify using only the code context embedded in the report (no source needed)")
    parser.add_argument("--severity", help="Filter by severity: critical,high,medium,low,info")
    parser.add_argument("--exploits-only", action="store_true", help="Only verify exploit findings")
    parser.add_argument("--id", help="Only verify specific finding IDs (comma-separated)")
    parser.add_argument("--max-per-type", type=int, default=None, help="Max findings to verify per type")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")

    args = parser.parse_args()

    print(BANNER)

    report_path = os.path.expanduser(args.report)
    report_only = args.report_only or args.source is None
    source_path = os.path.expanduser(args.source) if args.source else None

    if not os.path.isfile(report_path):
        print(f"  [ERROR] Report not found: {report_path}")
        sys.exit(1)
    if source_path and not os.path.isdir(source_path):
        print(f"  [ERROR] Source directory not found: {source_path}")
        sys.exit(1)

    print(f"  Report:  {report_path}")
    if report_only:
        print(f"  Mode:    Report-Only (using embedded code context)")
    else:
        print(f"  Source:  {source_path}")
    print()

    print("  [1/4] Parsing scanner report...", flush=True)
    rparser = ReportParser()
    findings = rparser.parse(report_path)
    print(f"         Found {len(findings)} findings in report")

    if args.severity:
        sevs = [s.strip().upper() for s in args.severity.split(",")]
        findings = [f for f in findings if f.severity in sevs]
        print(f"         Filtered to {len(findings)} findings by severity: {', '.join(sevs)}")

    if args.exploits_only:
        findings = [f for f in findings if f.is_exploit]
        print(f"         Filtered to {len(findings)} exploit findings")

    if args.id:
        ids = [i.strip().upper() for i in args.id.split(",")]
        findings = [f for f in findings if f.id in ids]
        print(f"         Filtered to {len(findings)} findings matching IDs: {', '.join(ids)}")

    if not findings:
        print("  [!] No findings to verify after filters")
        sys.exit(0)

    mode_label = "code context from report" if report_only else "source code"
    print(f"\n  [2/4] Verifying {len(findings)} findings against {mode_label}...", flush=True)
    start = time.time()
    verifier = VulnerabilityVerifier(source_dir=source_path, verbose=args.verbose, report_only=report_only)
    results = verifier.verify_all(findings, max_per_type=args.max_per_type)
    elapsed = time.time() - start
    print(f"         Verified {len(results)} findings in {elapsed:.1f}s")

    tp = len([r for r in results if r.verdict in (VERDICT_TRUE, VERDICT_LIKELY_TRUE)])
    fp = len([r for r in results if r.verdict in (VERDICT_FALSE, VERDICT_LIKELY_FALSE)])
    rev = len([r for r in results if r.verdict == VERDICT_NEEDS_REVIEW])
    una = len([r for r in results if r.verdict == VERDICT_UNABLE])

    print(f"""
  ┌──────────────────────────────────────────┐
  │        VERIFICATION SUMMARY              │
  ├──────────────────────────────────────────┤
  │  TRUE POSITIVES:   {tp:>6}  ({tp/len(results)*100:.1f}%)         │
  │  FALSE POSITIVES:  {fp:>6}  ({fp/len(results)*100:.1f}%)         │
  │  NEEDS REVIEW:     {rev:>6}  ({rev/len(results)*100:.1f}%)         │
  │  UNABLE TO VERIFY: {una:>6}  ({una/len(results)*100:.1f}%)         │
  │  TOTAL VERIFIED:   {len(results):>6}                │
  └──────────────────────────────────────────┘
""")

    out_base = args.output or "verification_report.html"
    out_base = os.path.expanduser(out_base)

    print(f"  [3/4] Generating HTML report...", flush=True)
    gen = ReportGenerator()
    html_path = gen.generate_html(results, out_base)
    print(f"         Saved: {html_path}")

    if args.json:
        json_path = out_base.replace(".html", ".json")
        print(f"  [4/4] Generating JSON report...", flush=True)
        gen.generate_json(results, json_path)
        print(f"         Saved: {json_path}")
    else:
        print(f"  [4/4] JSON output skipped (use --json to enable)")

    print(f"\n  Done! Open {html_path} in your browser to review.")
    print()


if __name__ == "__main__":
    main()
