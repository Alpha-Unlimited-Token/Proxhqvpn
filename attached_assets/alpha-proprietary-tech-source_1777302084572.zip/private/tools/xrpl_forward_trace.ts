/*
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide.
 * Alpha XRPL Forensic Tracer™ — Patent Pending. Trade Secret Protected.
 * Protected by 17 U.S.C. (Copyright), DMCA, CFAA, DTSA, and international treaty.
 * Unauthorized copying, modification, distribution, or reverse engineering prohibited.
 * AUTHORIZED USE ONLY — Alpha Unlimited Trading internal forensic operations.
 */
import { enforceProprietaryLicense, proprietaryHeader } from '../security/alpha_proprietary_guard.js';
enforceProprietaryLicense('Alpha XRPL Forensic Tracer™');

import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import archiver from 'archiver';
import { autoEmitFlowDiagram } from '../forensics/autoEmitFlowDiagram.js';

const TECH = 'Alpha XRPL Forensic Tracer™';
const SEED = process.argv[2] || 'rB47R6YQDEcNQszwRrb8JvAhgDXRncFTcT';
const START_ISO = '2023-08-01T00:00:00Z';
const END_ISO   = '2023-09-01T00:00:00Z';
const RIPPLE_EPOCH = 946684800; // 2000-01-01 UTC
const startUnix = Date.parse(START_ISO) / 1000;
const endUnix   = Date.parse(END_ISO)   / 1000;
const startRipple = startUnix - RIPPLE_EPOCH;
const endRipple   = endUnix   - RIPPLE_EPOCH;

const OUT_DIR = path.resolve('private/exports/xrpl-trace');
fs.mkdirSync(OUT_DIR, { recursive: true });

const RPC_URLS = ['https://xrplcluster.com/', 'https://s1.ripple.com:51234/', 'https://s2.ripple.com:51234/'];
const XRPSCAN = 'https://api.xrpscan.com/api/v1';
const MAX_HOPS = 3;
const MAX_TX_PAGES_PER_ADDR = 8;       // 8 * 200 = 1600 txs cap per addr
const TOP_DESTS_HOP1 = 50;
const TOP_DESTS_HOP2 = 30;
const TOP_DESTS_HOP3 = 20;
const POLITE_MS = 180;

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

let rpcIdx = 0;
async function rpc(method: string, params: any): Promise<any> {
  for (let attempt = 0; attempt < 4; attempt++) {
    const url = RPC_URLS[rpcIdx % RPC_URLS.length];
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, params: [params] }),
      });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const j = await r.json();
      if (j.result?.status === 'error') throw new Error(j.result.error_message || j.result.error);
      return j.result;
    } catch (e: any) {
      rpcIdx++;
      await sleep(POLITE_MS * (attempt + 1));
      if (attempt === 3) throw e;
    }
  }
}

interface TxEntry {
  hash: string;
  ledger: number;
  date: number;          // ripple-epoch seconds
  dateUnix: number;
  iso: string;
  type: string;          // tx.TransactionType
  source: string;
  destination?: string;
  destTag?: number;
  amountXrp?: number;
  amountIou?: { currency: string; issuer: string; value: string };
  fee: number;
  result: string;
  memos?: string[];
}

const labelCache = new Map<string, { name?: string; tags?: string[]; inception?: string }>();
async function labelOf(addr: string) {
  if (labelCache.has(addr)) return labelCache.get(addr)!;
  try {
    const r = await fetch(`${XRPSCAN}/account/${addr}`, { headers: { 'User-Agent': 'AlphaXRPLForensicTracer/1.0' } });
    if (r.ok) {
      const j: any = await r.json();
      const out = { name: j?.accountName?.name || j?.accountName?.desc, tags: j?.accountName?.tags || [], inception: j?.inception };
      labelCache.set(addr, out);
      await sleep(POLITE_MS);
      return out;
    }
  } catch {}
  const empty = {};
  labelCache.set(addr, empty);
  return empty;
}

async function fetchAccountTxs(account: string): Promise<TxEntry[]> {
  const out: TxEntry[] = [];
  let marker: any = undefined;
  for (let page = 0; page < MAX_TX_PAGES_PER_ADDR; page++) {
    const params: any = { account, limit: 200, forward: false, ledger_index_min: -1, ledger_index_max: -1 };
    if (marker) params.marker = marker;
    let res: any;
    try { res = await rpc('account_tx', params); } catch { break; }
    const rows = res?.transactions || [];
    if (!rows.length) break;
    for (const r of rows) {
      const tx = r.tx || r.tx_json || {};
      const meta = r.meta || {};
      const date = tx.date as number | undefined;
      if (typeof date !== 'number') continue;
      if (date < startRipple || date >= endRipple) continue;
      const amt = tx.Amount;
      const e: TxEntry = {
        hash: tx.hash,
        ledger: r.ledger_index || tx.ledger_index || 0,
        date,
        dateUnix: date + RIPPLE_EPOCH,
        iso: new Date((date + RIPPLE_EPOCH) * 1000).toISOString(),
        type: tx.TransactionType,
        source: tx.Account,
        destination: tx.Destination,
        destTag: tx.DestinationTag,
        fee: typeof tx.Fee === 'string' ? parseInt(tx.Fee) / 1e6 : 0,
        result: meta.TransactionResult || 'unknown',
      };
      if (typeof amt === 'string') e.amountXrp = parseInt(amt) / 1e6;
      else if (amt && typeof amt === 'object') e.amountIou = { currency: amt.currency, issuer: amt.issuer, value: amt.value };
      if (Array.isArray(tx.Memos)) {
        e.memos = tx.Memos.map((m: any) => {
          const d = m?.Memo?.MemoData;
          try { return d ? Buffer.from(d, 'hex').toString('utf8') : ''; } catch { return ''; }
        }).filter(Boolean);
      }
      out.push(e);
    }
    marker = res.marker;
    if (!marker) break;
    // Optimization: oldest tx in this page is older than window → stop
    const oldest = rows[rows.length - 1]?.tx?.date;
    if (typeof oldest === 'number' && oldest < startRipple) break;
    await sleep(POLITE_MS);
  }
  return out;
}

interface NodeRec {
  address: string;
  hop: number;
  parent?: string;
  totalReceivedXrpInWindow: number;
  totalSentXrpInWindow: number;
  txCountIn: number;
  txCountOut: number;
  uniqueSources: Set<string>;
  uniqueDests: Set<string>;
  firstSeen?: string;
  lastSeen?: string;
  label?: { name?: string; tags?: string[]; inception?: string };
  scamScore: number;
  scamReasons: string[];
  outboundPayments: TxEntry[];
}

const nodes = new Map<string, NodeRec>();
const allEdges: { from: string; to: string; amountXrp: number; hash: string; iso: string; hop: number; }[] = [];
const fetched = new Set<string>();

function ensureNode(addr: string, hop: number, parent?: string): NodeRec {
  let n = nodes.get(addr);
  if (!n) {
    n = {
      address: addr, hop, parent,
      totalReceivedXrpInWindow: 0, totalSentXrpInWindow: 0,
      txCountIn: 0, txCountOut: 0,
      uniqueSources: new Set(), uniqueDests: new Set(),
      scamScore: 0, scamReasons: [], outboundPayments: [],
    };
    nodes.set(addr, n);
  } else if (hop < n.hop) {
    n.hop = hop; n.parent = parent;
  }
  return n;
}

async function processAddress(addr: string, hop: number, parent?: string): Promise<{ to: string; xrp: number }[]> {
  const n = ensureNode(addr, hop, parent);
  if (fetched.has(addr)) {
    const dests: Record<string, number> = {};
    n.outboundPayments.forEach(t => { if (t.destination && t.amountXrp) dests[t.destination] = (dests[t.destination] || 0) + t.amountXrp; });
    return Object.entries(dests).map(([to, xrp]) => ({ to, xrp })).sort((a, b) => b.xrp - a.xrp);
  }
  fetched.add(addr);

  const txs = await fetchAccountTxs(addr);
  const lbl = await labelOf(addr);
  n.label = lbl;

  for (const t of txs) {
    if (!t.iso) continue;
    if (!n.firstSeen || t.iso < n.firstSeen) n.firstSeen = t.iso;
    if (!n.lastSeen  || t.iso > n.lastSeen)  n.lastSeen  = t.iso;

    if (t.type === 'Payment' && t.result === 'tesSUCCESS' && typeof t.amountXrp === 'number') {
      if (t.source === addr && t.destination) {
        n.totalSentXrpInWindow += t.amountXrp;
        n.txCountOut++;
        n.uniqueDests.add(t.destination);
        n.outboundPayments.push(t);
        allEdges.push({ from: addr, to: t.destination, amountXrp: t.amountXrp, hash: t.hash, iso: t.iso, hop });
      } else if (t.destination === addr && t.source) {
        n.totalReceivedXrpInWindow += t.amountXrp;
        n.txCountIn++;
        n.uniqueSources.add(t.source);
      }
    }
  }

  // Scam scoring
  const reasons: string[] = [];
  let score = 0;
  if (lbl?.tags && lbl.tags.length) {
    const tags = lbl.tags.map(s => s.toLowerCase());
    if (tags.some(t => /scam|phish|hack|fraud|theft|stolen|drainer/i.test(t))) { score += 80; reasons.push(`XRPSCAN tag: ${lbl.tags.join(', ')}`); }
    if (tags.some(t => /exchange|cex/i.test(t))) { score += 5; reasons.push(`Labeled exchange: ${lbl.name || lbl.tags.join(',')} (off-ramp KYC point)`); }
    if (tags.some(t => /gateway|mixer|tumbl/i.test(t))) { score += 50; reasons.push(`Labeled mixer/gateway: ${lbl.tags.join(',')}`); }
  }
  if (lbl?.inception) {
    const incUnix = Date.parse(lbl.inception) / 1000;
    if (incUnix > startUnix - 30 * 86400 && incUnix < endUnix) { score += 20; reasons.push(`Fresh wallet — created ${lbl.inception} (within 30d of trace window)`); }
  }
  // High velocity: > 5 outbound to >5 unique dests in window
  if (n.txCountOut >= 5 && n.uniqueDests.size >= 5) { score += 10; reasons.push(`High dispersion: ${n.txCountOut} out → ${n.uniqueDests.size} unique destinations`); }
  // Pass-through: in ~ out within 5%
  if (n.totalReceivedXrpInWindow > 0 && n.totalSentXrpInWindow > 0) {
    const ratio = Math.min(n.totalReceivedXrpInWindow, n.totalSentXrpInWindow) / Math.max(n.totalReceivedXrpInWindow, n.totalSentXrpInWindow);
    if (ratio > 0.95 && n.totalSentXrpInWindow > 100) { score += 25; reasons.push(`Pass-through pattern — IN ${n.totalReceivedXrpInWindow.toFixed(2)} ≈ OUT ${n.totalSentXrpInWindow.toFixed(2)} XRP`); }
  }
  // Fan-in funnel: many sources → few dests
  if (n.uniqueSources.size >= 10 && n.uniqueDests.size <= 3 && n.totalSentXrpInWindow > 50) { score += 30; reasons.push(`Funnel pattern — ${n.uniqueSources.size} sources → ${n.uniqueDests.size} dests`); }
  n.scamScore = score; n.scamReasons = reasons;

  // Aggregate destinations for next hop
  const dests: Record<string, number> = {};
  for (const t of n.outboundPayments) if (t.destination && t.amountXrp) dests[t.destination] = (dests[t.destination] || 0) + t.amountXrp;
  return Object.entries(dests).map(([to, xrp]) => ({ to, xrp })).sort((a, b) => b.xrp - a.xrp);
}

async function main() {
  console.log(`\n${TECH}`);
  console.log(`Seed: ${SEED}`);
  console.log(`Window: ${START_ISO} → ${END_ISO}`);
  console.log(`Depth: ${MAX_HOPS} hops forward\n`);

  console.log(`[Hop 0] Fetching seed wallet...`);
  const hop1 = await processAddress(SEED, 0);
  console.log(`  outbound payments → ${hop1.length} unique destinations, total ${hop1.reduce((s, x) => s + x.xrp, 0).toFixed(2)} XRP`);

  const hop1Targets = hop1.slice(0, TOP_DESTS_HOP1).map(x => x.to);
  console.log(`[Hop 1] Processing ${hop1Targets.length} destinations...`);
  let i = 0;
  const hop2Pool: Map<string, number> = new Map();
  for (const a of hop1Targets) {
    i++; process.stdout.write(`  [${i}/${hop1Targets.length}] ${a.slice(0, 14)}...`);
    const ds = await processAddress(a, 1, SEED);
    process.stdout.write(` → ${ds.length} dests\n`);
    for (const d of ds.slice(0, TOP_DESTS_HOP2)) hop2Pool.set(d.to, (hop2Pool.get(d.to) || 0) + d.xrp);
  }

  const hop2Targets = [...hop2Pool.entries()].sort((a, b) => b[1] - a[1]).slice(0, 80).map(([a]) => a).filter(a => a !== SEED);
  console.log(`[Hop 2] Processing ${hop2Targets.length} addresses...`);
  i = 0;
  const hop3Pool: Map<string, number> = new Map();
  for (const a of hop2Targets) {
    i++; process.stdout.write(`  [${i}/${hop2Targets.length}] ${a.slice(0, 14)}...`);
    const ds = await processAddress(a, 2);
    process.stdout.write(` → ${ds.length} dests\n`);
    for (const d of ds.slice(0, TOP_DESTS_HOP3)) hop3Pool.set(d.to, (hop3Pool.get(d.to) || 0) + d.xrp);
  }

  const hop3Targets = [...hop3Pool.entries()].sort((a, b) => b[1] - a[1]).slice(0, 60).map(([a]) => a).filter(a => a !== SEED);
  console.log(`[Hop 3] Processing ${hop3Targets.length} addresses...`);
  i = 0;
  for (const a of hop3Targets) {
    i++; process.stdout.write(`  [${i}/${hop3Targets.length}] ${a.slice(0, 14)}...`);
    await processAddress(a, 3);
    process.stdout.write(` ✓\n`);
  }

  // ─── EXPORT ────────────────────────────────────────────────
  console.log(`\n[Export] Writing CSVs, JSON, PDF, flow diagram...`);

  const allNodes = [...nodes.values()].sort((a, b) => b.scamScore - a.scamScore);
  const suspects = allNodes.filter(n => n.scamScore >= 30 && n.address !== SEED);

  // ─ CSV: all_nodes.csv
  const nodeCsv = ['address,hop,parent,totalReceivedXRP,totalSentXRP,txIn,txOut,uniqueSources,uniqueDests,firstSeen,lastSeen,label,tags,inception,scamScore,scamReasons'];
  for (const n of allNodes) {
    nodeCsv.push([
      n.address, n.hop, n.parent || '',
      n.totalReceivedXrpInWindow.toFixed(6), n.totalSentXrpInWindow.toFixed(6),
      n.txCountIn, n.txCountOut, n.uniqueSources.size, n.uniqueDests.size,
      n.firstSeen || '', n.lastSeen || '',
      `"${(n.label?.name || '').replace(/"/g, "''")}"`,
      `"${(n.label?.tags || []).join(';')}"`,
      n.label?.inception || '',
      n.scamScore,
      `"${n.scamReasons.join(' | ').replace(/"/g, "''")}"`,
    ].join(','));
  }
  fs.writeFileSync(path.join(OUT_DIR, 'all_nodes.csv'), nodeCsv.join('\n'));

  // ─ CSV: all_edges.csv (every payment)
  const edgeCsv = ['hop,from,to,amountXRP,txHash,iso'];
  for (const e of allEdges) edgeCsv.push([e.hop, e.from, e.to, e.amountXrp.toFixed(6), e.hash, e.iso].join(','));
  fs.writeFileSync(path.join(OUT_DIR, 'all_payments.csv'), edgeCsv.join('\n'));

  // ─ Per-hop CSVs
  for (const h of [0, 1, 2, 3]) {
    const lines = ['from,to,amountXRP,txHash,iso'];
    for (const e of allEdges.filter(e => e.hop === h)) lines.push([e.from, e.to, e.amountXrp.toFixed(6), e.hash, e.iso].join(','));
    fs.writeFileSync(path.join(OUT_DIR, `hop${h}_payments.csv`), lines.join('\n'));
  }

  // ─ JSON
  const traceJson = {
    proprietary: proprietaryHeader(TECH),
    tech: TECH,
    seed: SEED,
    window: { start: START_ISO, end: END_ISO },
    depth: MAX_HOPS,
    generatedAt: new Date().toISOString(),
    stats: { addressesFetched: fetched.size, totalNodes: nodes.size, totalPayments: allEdges.length, suspects: suspects.length },
    nodes: allNodes.map(n => ({ ...n, uniqueSources: [...n.uniqueSources], uniqueDests: [...n.uniqueDests], outboundPayments: undefined })),
    edges: allEdges,
    suspects: suspects.slice(0, 50).map(n => ({ address: n.address, hop: n.hop, score: n.scamScore, label: n.label?.name, tags: n.label?.tags, reasons: n.scamReasons, totalReceivedXRP: n.totalReceivedXrpInWindow, totalSentXRP: n.totalSentXrpInWindow })),
  };
  const jsonPath = path.join(OUT_DIR, 'trace.json');
  fs.writeFileSync(jsonPath, JSON.stringify(traceJson, null, 2));

  // ─ Flow diagram (auto-detects {nodes,edges})
  try {
    await autoEmitFlowDiagram(jsonPath, {
      title: `XRPL Forward Trace — ${SEED.slice(0, 10)}…`,
      caseName: 'XRPL_Forward_Trace_Aug2023',
      chain: 'xrpl',
      direction: 'forward',
      outDir: OUT_DIR,
    });
  } catch (e: any) { console.warn('  flow diagram skipped:', e.message); }

  // ─ PDF master report
  const pdfPath = path.join(OUT_DIR, 'XRPL-Forward-Trace-Report.pdf');
  await new Promise<void>((resolve) => {
    const doc = new PDFDocument({ size: 'LETTER', margin: 50, info: { Title: `XRPL Forward Trace ${SEED}`, Author: 'Alpha XRPL Forensic Tracer' } });
    doc.pipe(fs.createWriteStream(pdfPath)).on('finish', () => resolve());
    doc.font('Helvetica-Bold').fontSize(8).fillColor('#666').text(proprietaryHeader(TECH), { align: 'left' });
    doc.moveDown(0.5);
    doc.fontSize(20).fillColor('#000').text('XRPL Forward Trace — Forensic Audit', { align: 'center' });
    doc.fontSize(10).fillColor('#666').text(`${TECH} • Generated ${new Date().toUTCString()}`, { align: 'center' });
    doc.moveDown();
    doc.fontSize(11).fillColor('#000').font('Helvetica-Bold').text('Subject Wallet:'); doc.font('Helvetica').text(SEED);
    doc.font('Helvetica-Bold').text('Trace Window:'); doc.font('Helvetica').text(`${START_ISO}  →  ${END_ISO}  (UTC)`);
    doc.font('Helvetica-Bold').text('Direction:'); doc.font('Helvetica').text('FORWARD — follow outbound XRP payments');
    doc.font('Helvetica-Bold').text('Depth:'); doc.font('Helvetica').text(`${MAX_HOPS} hops`);
    doc.font('Helvetica-Bold').text('Data Source:'); doc.font('Helvetica').text('Public XRPL JSON-RPC (xrplcluster.com), XRPSCAN labels');
    doc.moveDown();

    doc.font('Helvetica-Bold').fontSize(13).text('Executive Summary');
    doc.font('Helvetica').fontSize(10);
    doc.text(`Addresses fetched: ${fetched.size}`);
    doc.text(`Total nodes mapped: ${nodes.size}`);
    doc.text(`Total payments captured (in-window): ${allEdges.length}`);
    doc.text(`Total XRP volume traced (in-window, sum of edges): ${allEdges.reduce((s, e) => s + e.amountXrp, 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} XRP`);
    doc.text(`High-risk suspect wallets (score ≥30): ${suspects.length}`);
    doc.moveDown();

    // Seed summary
    const seedNode = nodes.get(SEED);
    if (seedNode) {
      doc.font('Helvetica-Bold').fontSize(13).text('Seed Wallet Activity (in window)');
      doc.font('Helvetica').fontSize(10);
      doc.text(`Outbound payments: ${seedNode.txCountOut}`);
      doc.text(`Total XRP sent: ${seedNode.totalSentXrpInWindow.toFixed(2)}`);
      doc.text(`Unique direct destinations: ${seedNode.uniqueDests.size}`);
      doc.text(`Inbound payments: ${seedNode.txCountIn}`);
      doc.text(`Total XRP received: ${seedNode.totalReceivedXrpInWindow.toFixed(2)}`);
      doc.text(`First activity in window: ${seedNode.firstSeen || 'n/a'}`);
      doc.text(`Last activity in window:  ${seedNode.lastSeen || 'n/a'}`);
      doc.moveDown();
    }

    // Top hop-1 destinations
    doc.font('Helvetica-Bold').fontSize(13).text('Top 25 Direct (Hop 1) Destinations');
    doc.font('Helvetica').fontSize(9);
    const hop1Sorted = [...allEdges.filter(e => e.from === SEED).reduce((m, e) => { m.set(e.to, (m.get(e.to) || 0) + e.amountXrp); return m; }, new Map<string, number>()).entries()].sort((a, b) => b[1] - a[1]).slice(0, 25);
    for (const [addr, xrp] of hop1Sorted) {
      const lbl = nodes.get(addr)?.label;
      const sc = nodes.get(addr)?.scamScore ?? 0;
      doc.text(`${addr}  —  ${xrp.toFixed(2)} XRP  ${lbl?.name ? `[${lbl.name}]` : ''}  ${sc >= 30 ? `⚠ score ${sc}` : ''}`);
    }
    doc.moveDown();

    // Suspects
    doc.addPage();
    doc.font('Helvetica-Bold').fontSize(8).fillColor('#666').text(proprietaryHeader(TECH));
    doc.moveDown(0.5);
    doc.fontSize(15).fillColor('#000').text('High-Risk Suspect Wallets');
    doc.fontSize(9).fillColor('#666').text('Scoring: XRPSCAN scam/phish/hack tags = +80, mixer/gateway = +50, fan-in funnel = +30, pass-through = +25, fresh wallet = +20, high dispersion = +10, exchange = +5');
    doc.moveDown();
    doc.fillColor('#000').fontSize(10);
    if (!suspects.length) {
      doc.text('No nodes scored ≥30. Review all_nodes.csv for the full ranked list.');
    } else {
      for (const s of suspects.slice(0, 40)) {
        doc.font('Helvetica-Bold').text(`[hop ${s.hop}] ${s.address}  —  score ${s.scamScore}`);
        doc.font('Helvetica').fontSize(9);
        if (s.label?.name) doc.text(`  Label: ${s.label.name}${s.label.tags?.length ? ' (' + s.label.tags.join(', ') + ')' : ''}`);
        doc.text(`  IN: ${s.totalReceivedXrpInWindow.toFixed(2)} XRP from ${s.uniqueSources.size} sources  |  OUT: ${s.totalSentXrpInWindow.toFixed(2)} XRP to ${s.uniqueDests.size} dests`);
        if (s.firstSeen) doc.text(`  Window activity: ${s.firstSeen} → ${s.lastSeen}`);
        for (const r of s.scamReasons) doc.text(`  • ${r}`);
        doc.fontSize(10).moveDown(0.3);
      }
    }

    // Methodology + caveats
    doc.addPage();
    doc.font('Helvetica-Bold').fontSize(8).fillColor('#666').text(proprietaryHeader(TECH));
    doc.moveDown(0.5);
    doc.fillColor('#000').fontSize(15).text('Methodology, Caveats & Recommended Next Steps');
    doc.fontSize(10).font('Helvetica');
    doc.moveDown();
    doc.font('Helvetica-Bold').text('Methodology');
    doc.font('Helvetica').text(
      `1. Pulled all transactions for the seed wallet via the public XRPL JSON-RPC method "account_tx" and filtered to the time window ${START_ISO} → ${END_ISO} UTC.\n` +
      `2. Identified every successful outbound XRP "Payment" (Hop 1 destinations).\n` +
      `3. For each Hop 1 destination, repeated steps 1–2 to discover Hop 2 destinations. Then again for Hop 3.\n` +
      `4. Capped per-hop branching at the top ${TOP_DESTS_HOP1} / ${TOP_DESTS_HOP2} / ${TOP_DESTS_HOP3} addresses by XRP volume to keep the trace tractable.\n` +
      `5. Each address was cross-checked against XRPSCAN public account labels (known exchanges, scammers, gateways).\n` +
      `6. Behavioural heuristics applied: pass-through pattern, fan-in funnel, fresh-wallet inception, high dispersion.`
    );
    doc.moveDown();
    doc.font('Helvetica-Bold').text('Caveats');
    doc.font('Helvetica').text(
      `• "Suspect" scoring is investigative — a high score is a strong reason to subpoena the receiving exchange or open a deeper trace, not a finding of guilt.\n` +
      `• XRP IOU (issued-currency) transfers are recorded in the JSON but only native XRP amounts contribute to flow totals here.\n` +
      `• Branching caps mean very small streams beyond the top ${TOP_DESTS_HOP3} destinations per node are not pursued. Re-run with higher caps if needed.\n` +
      `• Exchange labels are tagged from XRPSCAN public dataset; absence of a label is NOT evidence the address is not an exchange.`
    );
    doc.moveDown();
    doc.font('Helvetica-Bold').text('Recommended Next Steps');
    doc.font('Helvetica').text(
      `• For each labeled exchange in the suspect list, prepare a subpoena/MLAT request listing the inbound tx hashes and destination tags from "all_payments.csv".\n` +
      `• For unlabeled high-score nodes, run a backward trace to identify their funding sources and a forward trace beyond hop 3.\n` +
      `• Cross-check destination tags against the exchange's deposit-tag map to identify the receiving account.`
    );

    doc.end();
  });

  // ─ Zip bundle
  const zipPath = path.resolve('private/exports/XRPL-ForwardTrace-rB47R6Y-Aug2023.zip');
  await new Promise<void>((resolve, reject) => {
    const out = fs.createWriteStream(zipPath);
    const arc = archiver('zip', { zlib: { level: 9 } });
    out.on('close', () => resolve()); arc.on('error', reject);
    arc.pipe(out);
    arc.directory(OUT_DIR, false);
    arc.append(JSON.stringify({
      proprietary: proprietaryHeader(TECH),
      bundle: 'XRPL Forward Trace',
      seed: SEED,
      window: { start: START_ISO, end: END_ISO },
      depth: MAX_HOPS,
      generatedAt: new Date().toISOString(),
      files: fs.readdirSync(OUT_DIR),
    }, null, 2), { name: 'manifest.json' });
    arc.finalize();
  });

  console.log(`\n✅ DONE`);
  console.log(`   Bundle: ${zipPath}`);
  console.log(`   Size:   ${(fs.statSync(zipPath).size / 1024).toFixed(1)} KB`);
  console.log(`   Suspects ≥30: ${suspects.length}`);
}

main().catch(e => { console.error('FATAL:', e); process.exit(1); });
