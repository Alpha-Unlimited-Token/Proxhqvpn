/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * License Generator — issues a valid Alpha Proprietary License for an
 * authorized environment. Run this script (one time, by the owner) to
 * create private/security/.alpha_license.json. The license is HMAC-signed
 * with a key derived from the authorized owner identity, so it cannot be
 * forged without access to this source code.
 *
 * Re-run this script to renew the license (default 365 days).
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const AUTHORIZED_REPL_OWNERS = ['alphaunlimitedt', 'alphaunlimitedtoken'];
const AUTHORIZED_OWNER_EMAILS = ['alphaunlimitedtoken@gmail.com'];
const AUTHORIZED_REPL_IDS = ['9b36b0f5-7126-49eb-bd38-5ca9ea7d5c45'];

function deriveLicenseKey(): string {
  const seed = `ALPHA_UNLIMITED::${AUTHORIZED_REPL_OWNERS.join(',')}::${AUTHORIZED_OWNER_EMAILS.join(',')}::v1`;
  return crypto.createHash('sha256').update(seed).digest('hex');
}

const VALID_DAYS = 365;
const license = {
  licensee: 'Alpha Unlimited Trading Company',
  ownerEmail: 'alphaunlimitedtoken@gmail.com',
  ownerPhone: '+1 (419) 376-6224',
  issuedAt: new Date().toISOString(),
  expiresAt: new Date(Date.now() + VALID_DAYS * 24 * 60 * 60 * 1000).toISOString(),
  authorizedReplOwners: AUTHORIZED_REPL_OWNERS,
  authorizedReplIds: AUTHORIZED_REPL_IDS,
  scope: 'ALL_ALPHA_PROPRIETARY_TECHNOLOGIES',
  notice: 'PROPRIETARY AND CONFIDENTIAL — © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved. Unauthorized use is a violation of US copyright law (Title 17), the DMCA (17 U.S.C. § 1201), the CFAA (18 U.S.C. § 1030), and the Defend Trade Secrets Act (18 U.S.C. § 1836).',
  signature: '',
};

const payload = JSON.stringify({
  licensee: license.licensee,
  ownerEmail: license.ownerEmail,
  issuedAt: license.issuedAt,
  expiresAt: license.expiresAt,
  authorizedReplOwners: license.authorizedReplOwners,
  authorizedReplIds: license.authorizedReplIds,
});
license.signature = crypto.createHmac('sha256', deriveLicenseKey()).update(payload).digest('hex');

const out = path.resolve('private/security/.alpha_license.json');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(license, null, 2));
console.log(`✅ License issued and signed.`);
console.log(`   File: ${out}`);
console.log(`   Expires: ${license.expiresAt}`);
console.log(`   Owner: ${license.ownerEmail}`);
console.log(`   Scope: ${license.scope}`);
