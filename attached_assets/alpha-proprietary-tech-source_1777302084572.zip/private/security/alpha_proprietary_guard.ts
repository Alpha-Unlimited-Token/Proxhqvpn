/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║   ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY SOFTWARE GUARD              ║
 * ║                                                                          ║
 * ║   © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.      ║
 * ║                                                                          ║
 * ║   This file is the central license-enforcement and anti-tamper module    ║
 * ║   for ALL Alpha Unlimited Technologies™. Every proprietary script must   ║
 * ║   call enforceProprietaryLicense() at startup. If the license check      ║
 * ║   fails (unauthorized environment, missing/invalid license, expired,     ║
 * ║   tampered files, etc.) the software refuses to run.                     ║
 * ║                                                                          ║
 * ║   Unauthorized copying, distribution, modification, reverse engineering, ║
 * ║   or use of this software is a violation of US copyright law (Title 17), ║
 * ║   the DMCA (17 U.S.C. § 1201), the Computer Fraud and Abuse Act          ║
 * ║   (18 U.S.C. § 1030), the Defend Trade Secrets Act (18 U.S.C. § 1836),   ║
 * ║   and applicable international treaties.                                 ║
 * ║                                                                          ║
 * ║   All access attempts (success or failure) are logged with environment   ║
 * ║   fingerprints for forensic enforcement.                                 ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';

// ─── AUTHORIZED ENVIRONMENT BINDING ────────────────────────────────────────
const AUTHORIZED_REPL_OWNERS = ['alphaunlimitedt', 'alphaunlimitedtoken'];
const AUTHORIZED_REPL_IDS = [
  '9b36b0f5-7126-49eb-bd38-5ca9ea7d5c45', // dev workspace
];
const AUTHORIZED_OWNER_EMAILS = ['alphaunlimitedtoken@gmail.com'];
const ADMIN_USER_IDS = ['50777126', '50891186']; // dev, prod auth IDs

// ─── EMBEDDED SOURCE-TAMPER VALIDATION HASH ────────────────────────────────
// SHA-256 of "VALIDATE::" + the canonical derived license key. After
// deriveLicenseKey() runs, we hash its output and compare against this
// constant. If anyone modifies AUTHORIZED_REPL_OWNERS or
// AUTHORIZED_OWNER_EMAILS to forge a license for a different identity,
// the resulting key will produce a different hash, this check will fail,
// and the kill-switch fires.
const LICENSE_SOURCE_VALIDATION_HASH = 'e3712dcf9e0e04fc333fb47ae74735c308af4d9346bc3326b7399753725bf9c3';
const LICENSE_FILE = path.resolve('private/security/.alpha_license.json');
const ACCESS_LOG_FILE = path.resolve('private/security/access.log');
const KILL_DELAY_MS = 1500;

// ─── INTERNAL: LICENSE-SECRET DERIVATION ───────────────────────────────────
// Derives the runtime HMAC key from environment + embedded constants. If any
// component is missing or the resulting hash doesn't match LICENSE_SECRET_HASH,
// the script refuses to run.
function deriveLicenseKey(): string {
  const seed = `ALPHA_UNLIMITED::${AUTHORIZED_REPL_OWNERS.join(',')}::${AUTHORIZED_OWNER_EMAILS.join(',')}::v1`;
  return crypto.createHash('sha256').update(seed).digest('hex');
}

// Verifies the source has not been tampered with — if any of the authorized-
// identity constants above were edited to forge a license for a different
// owner, the derived key will produce a different hash and this returns false.
function verifySourceIntegrity(): boolean {
  const key = deriveLicenseKey();
  const validation = crypto.createHash('sha256').update('VALIDATE::' + key).digest('hex');
  return validation === LICENSE_SOURCE_VALIDATION_HASH;
}

// ─── INTERNAL: ENVIRONMENT FINGERPRINT ─────────────────────────────────────
function fingerprint(): string {
  const parts = [
    process.env.REPL_OWNER || 'no-owner',
    process.env.REPL_ID || 'no-repl-id',
    process.env.REPL_SLUG || 'no-slug',
    os.hostname(),
    os.userInfo().username,
    process.platform,
  ];
  return crypto.createHash('sha256').update(parts.join('::')).digest('hex').slice(0, 32);
}

// ─── INTERNAL: ACCESS LOGGING ──────────────────────────────────────────────
function logAccess(scriptName: string, status: 'GRANTED' | 'DENIED', reason: string): void {
  try {
    const line = JSON.stringify({
      ts: new Date().toISOString(),
      script: scriptName,
      status,
      reason,
      env: {
        replOwner: process.env.REPL_OWNER || null,
        replId: process.env.REPL_ID || null,
        replSlug: process.env.REPL_SLUG || null,
        host: os.hostname(),
        user: os.userInfo().username,
        platform: process.platform,
      },
      fingerprint: fingerprint(),
    }) + '\n';
    fs.mkdirSync(path.dirname(ACCESS_LOG_FILE), { recursive: true });
    fs.appendFileSync(ACCESS_LOG_FILE, line);
  } catch { /* never throw from logger */ }
}

// ─── INTERNAL: KILL SWITCH ─────────────────────────────────────────────────
function refuseToRun(scriptName: string, reason: string): never {
  const banner = [
    '',
    '╔════════════════════════════════════════════════════════════════════════════╗',
    '║   ⛔  ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY SOFTWARE GUARD            ║',
    '╠════════════════════════════════════════════════════════════════════════════╣',
    `║   Script:  ${scriptName.padEnd(64)}║`,
    `║   Reason:  ${reason.padEnd(64)}║`,
    `║   Env FP:  ${fingerprint().padEnd(64)}║`,
    '║                                                                            ║',
    '║   This software is the EXCLUSIVE PROPERTY of                               ║',
    '║   Alpha Unlimited Trading Company.                                         ║',
    '║                                                                            ║',
    '║   Owner:   alphaunlimitedtoken@gmail.com                                   ║',
    '║   Phone:   +1 (419) 376-6224                                               ║',
    '║                                                                            ║',
    '║   Unauthorized copying, distribution, modification, reverse                ║',
    '║   engineering, or use is a VIOLATION of:                                   ║',
    '║     • US Copyright Law (Title 17)                                          ║',
    '║     • Digital Millennium Copyright Act (17 U.S.C. § 1201)                  ║',
    '║     • Computer Fraud and Abuse Act (18 U.S.C. § 1030)                      ║',
    '║     • Defend Trade Secrets Act (18 U.S.C. § 1836)                          ║',
    '║                                                                            ║',
    '║   This access attempt has been LOGGED with environment fingerprint.        ║',
    '║   Civil and criminal enforcement will be pursued.                          ║',
    '╚════════════════════════════════════════════════════════════════════════════╝',
    '',
  ].join('\n');
  console.error(banner);
  logAccess(scriptName, 'DENIED', reason);
  // Wipe sensitive globals before kill
  try { (global as any).__alpha_runtime__ = null; } catch { /* ignore */ }
  setTimeout(() => process.exit(1), KILL_DELAY_MS);
  throw new Error('ALPHA_PROPRIETARY_GUARD_REJECTED');
}

// ─── PUBLIC: enforceProprietaryLicense ─────────────────────────────────────
/**
 * Call this at the top of every Alpha proprietary script.
 *
 *   import { enforceProprietaryLicense } from '../../private/security/alpha_proprietary_guard.js';
 *   enforceProprietaryLicense('My Tech Name™');
 *
 * If anything is wrong with the environment or license, the script will
 * print a proprietary-notice banner, log the violation, and exit(1).
 */
export function enforceProprietaryLicense(scriptName: string): void {
  // FAST-PATH — Replit production deployment of THIS Repl. Only the
  // authorized owner can click "Publish" in the Replit workspace, so a
  // process running with REPLIT_DEPLOYMENT=1 is by definition authorized.
  // This avoids crash-looping in Cloud Run where REPL_OWNER may be unset
  // and REPL_ID is the deployment's ID (not the dev workspace ID).
  if (process.env.REPLIT_DEPLOYMENT === '1') {
    logAccess(scriptName, 'GRANTED', 'Replit deployment environment (REPLIT_DEPLOYMENT=1)');
    console.log(`[License] ✅ ${scriptName} — proprietary license verified (Replit deployment)`);
    return;
  }

  // CHECK 0 — Source-code integrity (detects forged license-key derivation)
  if (!verifySourceIntegrity()) {
    refuseToRun(scriptName, 'Source integrity check FAILED — alpha_proprietary_guard.ts has been modified');
  }

  // CHECK 1 — Environment binding
  const owner = (process.env.REPL_OWNER || '').toLowerCase();
  const replId = (process.env.REPL_ID || '').toLowerCase();
  const ownerOk = AUTHORIZED_REPL_OWNERS.some(o => owner === o.toLowerCase()) || owner.startsWith('alphaunlimited');
  const replIdOk = AUTHORIZED_REPL_IDS.length === 0 || AUTHORIZED_REPL_IDS.some(r => r.toLowerCase() === replId);
  if (!ownerOk && !replIdOk) {
    refuseToRun(scriptName, `Unauthorized environment owner='${owner}' replId='${replId}'`);
  }

  // CHECK 2 — License file present
  if (!fs.existsSync(LICENSE_FILE)) {
    refuseToRun(scriptName, `License file missing: ${LICENSE_FILE}`);
  }

  let license: any;
  try {
    license = JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf-8'));
  } catch (e) {
    refuseToRun(scriptName, `License file unreadable: ${(e as Error).message}`);
  }

  // CHECK 3 — License HMAC integrity
  const licenseKey = deriveLicenseKey();
  const payload = JSON.stringify({
    licensee: license.licensee,
    ownerEmail: license.ownerEmail,
    issuedAt: license.issuedAt,
    expiresAt: license.expiresAt,
    authorizedReplOwners: license.authorizedReplOwners,
    authorizedReplIds: license.authorizedReplIds,
  });
  const expectedSig = crypto.createHmac('sha256', licenseKey).update(payload).digest('hex');
  if (license.signature !== expectedSig) {
    refuseToRun(scriptName, 'License HMAC signature INVALID — file tampered or unauthorized');
  }

  // CHECK 4 — Owner email
  if (!AUTHORIZED_OWNER_EMAILS.includes((license.ownerEmail || '').toLowerCase())) {
    refuseToRun(scriptName, `License owner '${license.ownerEmail}' not authorized`);
  }

  // CHECK 5 — License expiry
  const exp = new Date(license.expiresAt).getTime();
  if (!Number.isFinite(exp) || exp < Date.now()) {
    refuseToRun(scriptName, `License expired or invalid expiry: ${license.expiresAt}`);
  }

  // CHECK 6 — License REPL_ID binding
  if (Array.isArray(license.authorizedReplIds) && license.authorizedReplIds.length > 0) {
    const lr = license.authorizedReplIds.map((x: string) => x.toLowerCase());
    if (replId && !lr.includes(replId)) {
      refuseToRun(scriptName, `License does NOT authorize REPL_ID '${replId}'`);
    }
  }

  // ALL GOOD
  logAccess(scriptName, 'GRANTED', `License valid until ${license.expiresAt}`);
  console.log(`[License] ✅ ${scriptName} — proprietary license verified (${license.licensee}, exp ${license.expiresAt.slice(0, 10)})`);
}

/**
 * Returns the proprietary copyright header used in HTML/JSON outputs of
 * Alpha proprietary technologies. Embed this in every report file.
 */
export function proprietaryHeader(scriptName: string): string {
  return `© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved. | ${scriptName} is PROPRIETARY AND CONFIDENTIAL. Unauthorized use is a violation of US copyright law and the DMCA. | Owner: alphaunlimitedtoken@gmail.com | Generated: ${new Date().toISOString()} | Env-FP: ${fingerprint()}`;
}
