/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha ThemeConfigurator™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_e236fd29c6c792b3f8069339
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Palette, Sun, Moon, Monitor, Check, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";

interface ThemeConfig {
  mode: 'dark' | 'light' | 'system';
  accentColor: string;
  chartStyle: 'modern' | 'classic' | 'minimal';
  fontSize: number;
}

const ACCENT_COLORS = [
  { name: 'Electric Blue', value: '#00D4FF', gradient: 'from-cyan-400 to-blue-500' },
  { name: 'Neon Green', value: '#10B981', gradient: 'from-green-400 to-emerald-500' },
  { name: 'Purple Haze', value: '#8B5CF6', gradient: 'from-purple-400 to-violet-500' },
  { name: 'Sunset Orange', value: '#F97316', gradient: 'from-orange-400 to-red-500' },
  { name: 'Hot Pink', value: '#EC4899', gradient: 'from-pink-400 to-rose-500' },
  { name: 'Gold', value: '#FFD700', gradient: 'from-yellow-400 to-amber-500' },
];

const CHART_STYLES = [
  { id: 'modern', name: 'Modern', desc: 'Gradient fills, smooth animations' },
  { id: 'classic', name: 'Classic', desc: 'Traditional candlestick look' },
  { id: 'minimal', name: 'Minimal', desc: 'Clean lines, no distractions' },
];

interface ThemeConfiguratorProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ThemeConfigurator({ isOpen, onClose }: ThemeConfiguratorProps) {
  const [config, setConfig] = useState<ThemeConfig>(() => {
    const saved = localStorage.getItem('trading-theme-config');
    return saved ? JSON.parse(saved) : {
      mode: 'dark',
      accentColor: '#00D4FF',
      chartStyle: 'modern',
      fontSize: 14,
    };
  });

  useEffect(() => {
    localStorage.setItem('trading-theme-config', JSON.stringify(config));
    
    document.documentElement.style.setProperty('--tp-accent', config.accentColor);
    document.documentElement.style.setProperty('--tp-font-size', `${config.fontSize}px`);
  }, [config]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-lg"
          >
            <Card className="bg-[#152238] border-[#223350] shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                    <Palette className="w-5 h-5 text-white" />
                  </div>
                  <CardTitle className="text-white">Theme Settings</CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              
              <CardContent className="pt-6 space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Appearance Mode</h3>
                  <div className="flex gap-2">
                    {[
                      { id: 'dark', icon: Moon, label: 'Dark' },
                      { id: 'light', icon: Sun, label: 'Light' },
                      { id: 'system', icon: Monitor, label: 'System' },
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => setConfig({ ...config, mode: mode.id as ThemeConfig['mode'] })}
                        className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border transition-all ${
                          config.mode === mode.id
                            ? 'bg-[#00D4FF]/10 border-[#00D4FF] text-[#00D4FF]'
                            : 'bg-[#1A2942] border-white/10 text-gray-400 hover:border-white/20'
                        }`}
                      >
                        <mode.icon className="w-4 h-4" />
                        <span className="text-sm font-medium">{mode.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Accent Color</h3>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {ACCENT_COLORS.map((color) => (
                      <button
                        key={color.value}
                        onClick={() => setConfig({ ...config, accentColor: color.value })}
                        className={`relative w-full aspect-square rounded-lg bg-gradient-to-br ${color.gradient} transition-transform hover:scale-110 ${
                          config.accentColor === color.value ? 'ring-2 ring-white ring-offset-2 ring-offset-[#152238]' : ''
                        }`}
                        title={color.name}
                      >
                        {config.accentColor === color.value && (
                          <Check className="absolute inset-0 m-auto w-4 h-4 text-white" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Chart Style</h3>
                  <div className="space-y-2">
                    {CHART_STYLES.map((style) => (
                      <button
                        key={style.id}
                        onClick={() => setConfig({ ...config, chartStyle: style.id as ThemeConfig['chartStyle'] })}
                        className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                          config.chartStyle === style.id
                            ? 'bg-[#00D4FF]/10 border-[#00D4FF]'
                            : 'bg-[#1A2942] border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className="text-left">
                          <p className={`font-medium ${config.chartStyle === style.id ? 'text-[#00D4FF]' : 'text-white'}`}>
                            {style.name}
                          </p>
                          <p className="text-xs text-gray-500">{style.desc}</p>
                        </div>
                        {config.chartStyle === style.id && (
                          <Check className="w-5 h-5 text-[#00D4FF]" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-medium text-gray-400">Font Size</h3>
                    <span className="text-sm text-[#00D4FF]">{config.fontSize}px</span>
                  </div>
                  <Slider
                    value={[config.fontSize]}
                    onValueChange={([value]) => setConfig({ ...config, fontSize: value })}
                    min={12}
                    max={18}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/10">
                  <Button
                    variant="outline"
                    className="flex-1 border-white/10 text-gray-400 hover:text-white hover:bg-white/5"
                    onClick={() => setConfig({
                      mode: 'dark',
                      accentColor: '#00D4FF',
                      chartStyle: 'modern',
                      fontSize: 14,
                    })}
                  >
                    Reset to Default
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-400 hover:to-blue-500"
                    onClick={onClose}
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Apply Theme
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
