/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha DashboardBuilder™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_1e11a9f9af0dbf1159855d17
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import {
  Layout, Plus, X, Settings, Save, RotateCcw, Eye, EyeOff,
  Grip, Maximize2, Minimize2, Lock, Unlock, Palette, ChevronDown,
  BarChart3, LineChart, PieChart, TrendingUp, Wallet, Bell, Activity,
  Globe, Zap, Users, BookOpen, Clock, DollarSign, Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

interface DashboardWidget {
  id: string;
  type: WidgetType;
  title: string;
  size: 'small' | 'medium' | 'large' | 'full';
  visible: boolean;
  locked: boolean;
  config?: Record<string, any>;
}

type WidgetType = 
  | 'price_chart' | 'portfolio_summary' | 'watchlist' | 'order_book'
  | 'recent_trades' | 'price_alerts' | 'news_feed' | 'social_sentiment'
  | 'whale_tracker' | 'ai_signals' | 'arbitrage_scanner' | 'market_overview'
  | 'performance_chart' | 'quick_trade' | 'learning_progress' | 'calendar';

interface WidgetTemplate {
  type: WidgetType;
  title: string;
  description: string;
  icon: React.ReactNode;
  defaultSize: DashboardWidget['size'];
  category: 'trading' | 'portfolio' | 'social' | 'tools';
}

const WIDGET_TEMPLATES: WidgetTemplate[] = [
  { type: 'price_chart', title: 'Price Chart', description: 'Real-time price charts with indicators', icon: <LineChart className="w-5 h-5" />, defaultSize: 'large', category: 'trading' },
  { type: 'portfolio_summary', title: 'Portfolio Summary', description: 'Overview of your holdings and P&L', icon: <PieChart className="w-5 h-5" />, defaultSize: 'medium', category: 'portfolio' },
  { type: 'watchlist', title: 'Watchlist', description: 'Track your favorite assets', icon: <Eye className="w-5 h-5" />, defaultSize: 'medium', category: 'trading' },
  { type: 'order_book', title: 'Order Book', description: 'Live order book depth', icon: <BarChart3 className="w-5 h-5" />, defaultSize: 'medium', category: 'trading' },
  { type: 'recent_trades', title: 'Recent Trades', description: 'Your latest trading activity', icon: <Activity className="w-5 h-5" />, defaultSize: 'medium', category: 'trading' },
  { type: 'price_alerts', title: 'Price Alerts', description: 'Active price notifications', icon: <Bell className="w-5 h-5" />, defaultSize: 'small', category: 'tools' },
  { type: 'news_feed', title: 'News Feed', description: 'Latest crypto news', icon: <Globe className="w-5 h-5" />, defaultSize: 'medium', category: 'social' },
  { type: 'social_sentiment', title: 'Social Sentiment', description: 'Market sentiment analysis', icon: <Users className="w-5 h-5" />, defaultSize: 'medium', category: 'social' },
  { type: 'whale_tracker', title: 'Whale Tracker', description: 'Large transaction alerts', icon: <Wallet className="w-5 h-5" />, defaultSize: 'medium', category: 'social' },
  { type: 'ai_signals', title: 'AI Signals', description: 'AI-powered trading signals', icon: <Zap className="w-5 h-5" />, defaultSize: 'medium', category: 'trading' },
  { type: 'arbitrage_scanner', title: 'Arbitrage Scanner', description: 'Cross-exchange opportunities', icon: <Target className="w-5 h-5" />, defaultSize: 'medium', category: 'trading' },
  { type: 'market_overview', title: 'Market Overview', description: 'Global market stats', icon: <TrendingUp className="w-5 h-5" />, defaultSize: 'large', category: 'trading' },
  { type: 'performance_chart', title: 'Performance', description: 'Track your trading performance', icon: <BarChart3 className="w-5 h-5" />, defaultSize: 'medium', category: 'portfolio' },
  { type: 'quick_trade', title: 'Quick Trade', description: 'Fast buy/sell widget', icon: <DollarSign className="w-5 h-5" />, defaultSize: 'small', category: 'trading' },
  { type: 'learning_progress', title: 'Learning Progress', description: 'Your education stats', icon: <BookOpen className="w-5 h-5" />, defaultSize: 'small', category: 'tools' },
  { type: 'calendar', title: 'Events Calendar', description: 'Upcoming crypto events', icon: <Clock className="w-5 h-5" />, defaultSize: 'medium', category: 'tools' },
];

const DEFAULT_LAYOUT: DashboardWidget[] = [
  { id: 'w1', type: 'market_overview', title: 'Market Overview', size: 'full', visible: true, locked: false },
  { id: 'w2', type: 'price_chart', title: 'Price Chart', size: 'large', visible: true, locked: false },
  { id: 'w3', type: 'portfolio_summary', title: 'Portfolio', size: 'medium', visible: true, locked: false },
  { id: 'w4', type: 'watchlist', title: 'Watchlist', size: 'medium', visible: true, locked: false },
  { id: 'w5', type: 'ai_signals', title: 'AI Signals', size: 'medium', visible: true, locked: false },
];

const STORAGE_KEY = 'alpha-dashboard-layout';

const SIZE_CLASSES = {
  small: 'col-span-1',
  medium: 'col-span-1 md:col-span-2',
  large: 'col-span-1 md:col-span-2 lg:col-span-3',
  full: 'col-span-1 md:col-span-2 lg:col-span-4',
};

export function DashboardBuilder() {
  const [widgets, setWidgets] = useState<DashboardWidget[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [showAddWidget, setShowAddWidget] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showDemo, setShowDemo] = useState(false);

  const [hasSavedLayout, setHasSavedLayout] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) {
          setHasSavedLayout(true);
        }
      } catch {
        // Invalid saved data, ignore
      }
    }
  }, []);

  const loadSavedLayout = useCallback(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setWidgets(JSON.parse(saved));
        setShowDemo(true);
        toast.success('Saved layout loaded');
      } catch {
        setWidgets([]);
      }
    }
  }, []);

  useEffect(() => {
    if (widgets.length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(widgets));
    }
  }, [widgets]);

  const loadDefaultLayout = useCallback(() => {
    setWidgets(DEFAULT_LAYOUT);
    setShowDemo(true);
    toast.success('Default layout loaded');
  }, []);

  const addWidget = (template: WidgetTemplate) => {
    const newWidget: DashboardWidget = {
      id: `w_${Date.now()}`,
      type: template.type,
      title: template.title,
      size: template.defaultSize,
      visible: true,
      locked: false,
    };
    setWidgets(prev => [...prev, newWidget]);
    setShowAddWidget(false);
    toast.success(`Added ${template.title}`);
  };

  const removeWidget = (id: string) => {
    setWidgets(prev => prev.filter(w => w.id !== id));
    toast.success('Widget removed');
  };

  const toggleVisibility = (id: string) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, visible: !w.visible } : w
    ));
  };

  const toggleLock = (id: string) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, locked: !w.locked } : w
    ));
  };

  const changeSize = (id: string, size: DashboardWidget['size']) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, size } : w
    ));
  };

  const resetLayout = () => {
    setWidgets([]);
    localStorage.removeItem(STORAGE_KEY);
    setShowDemo(false);
    setHasSavedLayout(false);
    toast.success('Layout reset');
  };

  const getWidgetIcon = (type: WidgetType) => {
    const template = WIDGET_TEMPLATES.find(t => t.type === type);
    return template?.icon || <Layout className="w-5 h-5" />;
  };

  const filteredTemplates = selectedCategory === 'all'
    ? WIDGET_TEMPLATES
    : WIDGET_TEMPLATES.filter(t => t.category === selectedCategory);

  if (!showDemo && widgets.length === 0) {
    return (
      <div className="tp-card p-6">
        <div className="flex items-center gap-2 mb-6">
          <Layout className="w-5 h-5 text-[#00D4FF]" />
          <h3 className="text-lg font-semibold text-white">Custom Dashboard Builder</h3>
        </div>
        <div className="text-center py-8">
          <Palette className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 mb-2">Create your personalized trading dashboard</p>
          <p className="text-sm text-gray-500 mb-6">
            Drag, drop, and resize widgets to build your perfect trading workspace
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            {hasSavedLayout && (
              <Button
                onClick={loadSavedLayout}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Load Saved Layout
              </Button>
            )}
            <Button
              onClick={loadDefaultLayout}
              className="bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black"
            >
              <Layout className="w-4 h-4 mr-2" />
              Use Default Layout
            </Button>
            <Button
              onClick={() => {
                setShowDemo(true);
                setIsEditing(true);
                setShowAddWidget(true);
              }}
              variant="outline"
              className="border-white/10 text-gray-300 hover:bg-white/5"
            >
              <Plus className="w-4 h-4 mr-2" />
              Start From Scratch
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="tp-card p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Layout className="w-5 h-5 text-[#00D4FF]" />
          <h3 className="text-lg font-semibold text-white">Dashboard</h3>
          {showDemo && (
            <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs rounded">
              Customizable
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isEditing && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAddWidget(true)}
                className="text-[#00D4FF] hover:bg-[#00D4FF]/10"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Widget
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={resetLayout}
                className="text-gray-400 hover:text-white"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
            className={isEditing ? 'text-[#00D4FF]' : 'text-gray-400 hover:text-white'}
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {showAddWidget && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <div className="p-4 bg-[#0A1628]/50 rounded-lg border border-white/5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-medium text-white">Add Widget</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAddWidget(false)}
                  className="text-gray-400 hover:text-white h-6 w-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex gap-2 mb-3">
                {['all', 'trading', 'portfolio', 'social', 'tools'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 text-xs rounded capitalize ${
                      selectedCategory === cat
                        ? 'bg-[#00D4FF] text-black'
                        : 'bg-white/5 text-gray-400 hover:bg-white/10'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-48 overflow-y-auto">
                {filteredTemplates.map(template => {
                  const isAdded = widgets.some(w => w.type === template.type);
                  return (
                    <button
                      key={template.type}
                      onClick={() => !isAdded && addWidget(template)}
                      disabled={isAdded}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        isAdded
                          ? 'border-white/5 bg-white/5 opacity-50 cursor-not-allowed'
                          : 'border-white/10 hover:border-[#00D4FF]/50 hover:bg-[#00D4FF]/5'
                      }`}
                    >
                      <div className="flex items-center gap-2 text-[#00D4FF] mb-1">
                        {template.icon}
                        <span className="text-xs text-gray-400 uppercase">{template.category}</span>
                      </div>
                      <div className="text-white text-sm font-medium">{template.title}</div>
                      <div className="text-gray-500 text-xs mt-1 line-clamp-1">{template.description}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {widgets.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500">Click "Add Widget" to start building your dashboard</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {widgets.filter(w => w.visible).map((widget) => (
            <motion.div
              key={widget.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`${SIZE_CLASSES[widget.size]} min-h-[120px] p-3 bg-[#0A1628]/50 rounded-lg border border-white/5 relative group`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {isEditing && !widget.locked && (
                    <Grip className="w-4 h-4 text-gray-600 cursor-grab" />
                  )}
                  <span className="text-[#00D4FF]">{getWidgetIcon(widget.type)}</span>
                  <span className="text-white text-sm font-medium">{widget.title}</span>
                </div>
                {isEditing && (
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => toggleLock(widget.id)}
                      className="p-1 text-gray-500 hover:text-white"
                    >
                      {widget.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                    </button>
                    <select
                      value={widget.size}
                      onChange={(e) => changeSize(widget.id, e.target.value as DashboardWidget['size'])}
                      className="bg-transparent text-xs text-gray-400 border-none cursor-pointer"
                    >
                      <option value="small">S</option>
                      <option value="medium">M</option>
                      <option value="large">L</option>
                      <option value="full">XL</option>
                    </select>
                    <button
                      onClick={() => removeWidget(widget.id)}
                      className="p-1 text-gray-500 hover:text-red-400"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
              <div className="h-16 flex items-center justify-center text-gray-600 text-xs">
                {widget.type.replace(/_/g, ' ')} widget placeholder
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {widgets.some(w => !w.visible) && (
        <div className="mt-4 pt-4 border-t border-white/5">
          <div className="text-xs text-gray-500 mb-2">Hidden Widgets</div>
          <div className="flex flex-wrap gap-2">
            {widgets.filter(w => !w.visible).map(widget => (
              <button
                key={widget.id}
                onClick={() => toggleVisibility(widget.id)}
                className="flex items-center gap-1 px-2 py-1 bg-white/5 rounded text-xs text-gray-400 hover:bg-white/10"
              >
                <EyeOff className="w-3 h-3" />
                {widget.title}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
