/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Entity Intelligence Dashboard™ — Forensic Wallet Analysis
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * AUT_ModuleHash: AUT_e2b94c38d5e9f3a012345678
 * ALPHA_INTEGRITY_SEAL: ENTITY_DASHBOARD_v1.0_PROTECTED
 * Calibration: ENTITY_ENGINE_SEALED
 */

import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

interface EntityDashboardProps {
  wallet: {
    id: string;
    address: string;
    chain: string;
    role: string | null;
    label: string | null;
    lastKnownBalanceEth: number | null;
    lastKnownBalanceUsd: number | null;
    lastKnownTokens: Record<string, number> | null;
    lastChecked: string | null;
    status: string;
  };
  caseId: string;
  onClose: () => void;
  explorerLink: (chain: string, type: "address" | "tx", value: string) => string;
}

const CHAIN_SYMBOLS: Record<string, string> = {
  ethereum: "ETH", bitcoin: "BTC", bsc: "BNB", polygon: "MATIC", solana: "SOL",
  tron: "TRX", arbitrum: "ETH", optimism: "ETH", base: "ETH", avalanche: "AVAX",
};

function formatUsd(val: number | null | undefined): string {
  if (!val) return "$0.00";
  if (val >= 1000000) return "$" + (val / 1000000).toFixed(2) + "M";
  if (val >= 1000) return "$" + (val / 1000).toFixed(1) + "K";
  return "$" + val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function shortenAddr(addr: string): string {
  if (!addr || addr.length < 12) return addr;
  return addr.slice(0, 8) + "..." + addr.slice(-6);
}

export default function EntityDashboard({ wallet, caseId, onClose, explorerLink }: EntityDashboardProps) {
  const [activeSection, setActiveSection] = useState<"portfolio" | "transfers" | "counterparties" | "exchanges">("portfolio");

  const { data: detail, isLoading, isError } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/wallet-detail", wallet.id],
    queryFn: () => fetch(`/api/forensic/command-center/wallet-detail/${wallet.id}?caseId=${caseId}`, { credentials: "include" }).then(r => { if (!r.ok) throw new Error("Failed to load"); return r.json(); }),
    refetchInterval: 60000,
    retry: 1,
  });

  const tokenHoldings = useMemo(() => {
    const tokens = wallet.lastKnownTokens || {};
    const entries = Object.entries(tokens).map(([symbol, amount]) => {
      const priceData = detail?.tokenPrices?.[symbol];
      const price = priceData?.price || 0;
      const value = (amount as number) * price;
      const change24h = priceData?.change24h || 0;
      return { symbol, amount: amount as number, price, value, change24h };
    });
    entries.sort((a, b) => b.value - a.value);
    return entries;
  }, [wallet.lastKnownTokens, detail?.tokenPrices]);

  const totalPortfolioValue = useMemo(() => {
    const nativeVal = wallet.lastKnownBalanceUsd || 0;
    const tokenVal = tokenHoldings.reduce((s, t) => s + t.value, 0);
    return nativeVal + tokenVal;
  }, [wallet.lastKnownBalanceUsd, tokenHoldings]);

  const chainBreakdown = useMemo(() => {
    if (!detail?.chainBreakdown) return [];
    return Object.entries(detail.chainBreakdown).map(([chain, data]: [string, any]) => ({
      chain,
      value: data.value || 0,
      txCount: data.txCount || 0,
    })).sort((a, b) => b.value - a.value);
  }, [detail?.chainBreakdown]);

  const transfers = detail?.transfers || [];
  const counterparties = detail?.counterparties || [];
  const exchanges = detail?.exchanges || [];

  const nativeSym = CHAIN_SYMBOLS[wallet.chain] || "ETH";

  return (
    <div className="bg-[#0d1117] rounded-xl border border-gray-700/50 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-gray-800/50 bg-gradient-to-r from-[#0d1117] to-[#161b22]">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold ${
            wallet.role === "victim" ? "bg-cyan-900/50 text-cyan-400 border border-cyan-700/50" :
            wallet.role === "attacker" || wallet.role === "drainer" ? "bg-red-900/50 text-red-400 border border-red-700/50" :
            wallet.role === "exchange" ? "bg-yellow-900/50 text-yellow-400 border border-yellow-700/50" :
            wallet.role === "bridge" ? "bg-purple-900/50 text-purple-400 border border-purple-700/50" :
            "bg-gray-800/50 text-gray-400 border border-gray-700/50"
          }`}>
            {(wallet.label || wallet.role || "W")[0].toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white" data-testid="text-entity-label">{wallet.label || shortenAddr(wallet.address)}</h3>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                wallet.role === "victim" ? "bg-cyan-600/20 text-cyan-400" :
                wallet.role === "attacker" ? "bg-red-600/20 text-red-400" :
                wallet.role === "exchange" ? "bg-yellow-600/20 text-yellow-400" :
                "bg-gray-600/20 text-gray-400"
              }`}>
                {(wallet.role || "unknown").toUpperCase()}
              </span>
            </div>
            <a
              href={explorerLink(wallet.chain, "address", wallet.address)}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-xs text-cyan-500 hover:text-cyan-300 hover:underline"
              data-testid="link-entity-address"
            >
              {wallet.address}
            </a>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-lg font-bold text-white" data-testid="text-entity-total-value">{formatUsd(totalPortfolioValue)}</div>
            <div className="text-[10px] text-gray-500">Total Value · {wallet.chain}</div>
          </div>
          <button
            data-testid="button-close-entity"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-400 hover:text-white border border-gray-700/50"
          >×</button>
        </div>
      </div>

      <div className="flex border-b border-gray-800/50 bg-[#0a0e14]">
        {[
          { id: "portfolio" as const, label: "Portfolio" },
          { id: "transfers" as const, label: `Transfers${transfers.length ? ` (${transfers.length})` : ""}` },
          { id: "counterparties" as const, label: `Counterparties${counterparties.length ? ` (${counterparties.length})` : ""}` },
          { id: "exchanges" as const, label: `Exchanges${exchanges.length ? ` (${exchanges.length})` : ""}` },
        ].map(tab => (
          <button
            key={tab.id}
            data-testid={`button-entity-tab-${tab.id}`}
            onClick={() => setActiveSection(tab.id)}
            className={`px-4 py-2 text-xs font-medium transition-colors ${
              activeSection === tab.id
                ? "text-cyan-400 border-b-2 border-cyan-400 bg-cyan-900/10"
                : "text-gray-500 hover:text-gray-300"
            }`}
          >{tab.label}</button>
        ))}
      </div>

      {isLoading && (
        <div className="p-8 text-center">
          <div className="inline-block w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <div className="text-gray-500 text-sm mt-2">Loading entity data...</div>
        </div>
      )}

      {isError && (
        <div className="p-6 text-center">
          <div className="text-red-400 text-sm mb-1">Failed to load entity data</div>
          <div className="text-gray-600 text-xs">The wallet detail API returned an error. Data shown below is from cached wallet state only.</div>
        </div>
      )}

      {!isLoading && activeSection === "portfolio" && (
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <div className="bg-[#161b22] rounded-lg border border-gray-800/50 overflow-hidden">
                <div className="px-4 py-2 border-b border-gray-800/30">
                  <h4 className="text-xs font-bold text-gray-400">PORTFOLIO</h4>
                </div>
                <table className="w-full text-xs" data-testid="table-entity-portfolio">
                  <thead>
                    <tr className="border-b border-gray-800/30 text-gray-500">
                      <th className="px-4 py-2 text-left">Asset</th>
                      <th className="px-4 py-2 text-right">Price</th>
                      <th className="px-4 py-2 text-right">Holdings</th>
                      <th className="px-4 py-2 text-right">Value</th>
                      <th className="px-4 py-2 text-right">24h</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-800/20 hover:bg-gray-800/20">
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-blue-600/20 flex items-center justify-center text-[10px] text-blue-400 font-bold">{nativeSym[0]}</div>
                          <div>
                            <div className="text-gray-200 font-medium">{nativeSym}</div>
                            <div className="text-gray-600 text-[10px]">{wallet.chain}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-2 text-right text-gray-300">{detail?.nativePrice ? `$${detail.nativePrice.toLocaleString()}` : "-"}</td>
                      <td className="px-4 py-2 text-right text-gray-300 font-mono">{(wallet.lastKnownBalanceEth || 0).toFixed(6)}</td>
                      <td className="px-4 py-2 text-right text-green-400 font-medium">{formatUsd(wallet.lastKnownBalanceUsd)}</td>
                      <td className="px-4 py-2 text-right text-gray-500">-</td>
                    </tr>
                    {tokenHoldings.map(t => (
                      <tr key={t.symbol} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                        <td className="px-4 py-2">
                          <div className="flex items-center gap-2">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                              t.symbol === "USDC" || t.symbol === "USDT" ? "bg-green-600/20 text-green-400" :
                              t.symbol === "DAI" ? "bg-yellow-600/20 text-yellow-400" :
                              t.symbol === "WETH" ? "bg-purple-600/20 text-purple-400" :
                              "bg-gray-600/20 text-gray-400"
                            }`}>{t.symbol[0]}</div>
                            <span className="text-gray-200 font-medium">{t.symbol}</span>
                          </div>
                        </td>
                        <td className="px-4 py-2 text-right text-gray-300">{t.price > 0 ? `$${t.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}` : "-"}</td>
                        <td className="px-4 py-2 text-right text-gray-300 font-mono">
                          {t.amount >= 1000 ? `${(t.amount / 1000).toFixed(1)}K` : t.amount.toFixed(t.amount < 1 ? 6 : 2)}
                        </td>
                        <td className="px-4 py-2 text-right text-green-400 font-medium">{t.value > 0 ? formatUsd(t.value) : "-"}</td>
                        <td className={`px-4 py-2 text-right ${t.change24h >= 0 ? "text-green-400" : "text-red-400"}`}>
                          {t.change24h !== 0 ? `${t.change24h >= 0 ? "+" : ""}${t.change24h.toFixed(1)}%` : "-"}
                        </td>
                      </tr>
                    ))}
                    {tokenHoldings.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-4 py-4 text-center text-gray-600">No token holdings detected</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-[#161b22] rounded-lg border border-gray-800/50 p-4">
                <h4 className="text-xs font-bold text-gray-400 mb-3">HOLDINGS BY CHAIN</h4>
                {chainBreakdown.length > 0 ? (
                  <div className="space-y-2">
                    {chainBreakdown.map(cb => (
                      <div key={cb.chain} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: cb.chain === "ethereum" ? "#627eea" : cb.chain === "arbitrum" ? "#28a0f0" : cb.chain === "bsc" ? "#f0b90b" : "#6b7280" }} />
                          <span className="text-xs text-gray-300 capitalize">{cb.chain}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs text-green-400">{formatUsd(cb.value)}</span>
                          <span className="text-[10px] text-gray-600 ml-2">{cb.txCount} txs</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-gray-600">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500" />
                        <span className="text-gray-300 capitalize">{wallet.chain}</span>
                      </div>
                      <span className="text-green-400">{formatUsd(totalPortfolioValue)}</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-[#161b22] rounded-lg border border-gray-800/50 p-4">
                <h4 className="text-xs font-bold text-gray-400 mb-3">WALLET INFO</h4>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Status</span>
                    <span className={`font-medium ${wallet.status === "monitoring" ? "text-green-400" : "text-gray-400"}`}>{wallet.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Last Checked</span>
                    <span className="text-gray-300">{timeAgo(wallet.lastChecked)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Total Txs Traced</span>
                    <span className="text-cyan-400">{detail?.totalTraced || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Alerts</span>
                    <span className="text-orange-400">{detail?.alertCount || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {!isLoading && activeSection === "transfers" && (
        <div className="p-4">
          <div className="bg-[#161b22] rounded-lg border border-gray-800/50 overflow-hidden">
            <div className="px-4 py-2 border-b border-gray-800/30 flex items-center justify-between">
              <h4 className="text-xs font-bold text-gray-400">TRANSFERS</h4>
              <span className="text-[10px] text-gray-600">{transfers.length} transactions</span>
            </div>
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
              <table className="w-full text-xs" data-testid="table-entity-transfers">
                <thead className="sticky top-0 bg-[#161b22]">
                  <tr className="border-b border-gray-800/30 text-gray-500">
                    <th className="px-3 py-2 text-left">Time</th>
                    <th className="px-3 py-2 text-left">From</th>
                    <th className="px-3 py-2 text-center">Dir</th>
                    <th className="px-3 py-2 text-left">To</th>
                    <th className="px-3 py-2 text-right">Amount</th>
                    <th className="px-3 py-2 text-left">Token</th>
                    <th className="px-3 py-2 text-right">Value</th>
                    <th className="px-3 py-2 text-left">TX</th>
                  </tr>
                </thead>
                <tbody>
                  {transfers.map((tx: any, i: number) => {
                    const isInbound = tx.direction === "inbound" || tx.toAddress?.toLowerCase() === wallet.address.toLowerCase();
                    return (
                      <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                        <td className="px-3 py-2 text-gray-500 whitespace-nowrap">{tx.timestamp ? timeAgo(tx.timestamp) : "-"}</td>
                        <td className="px-3 py-2">
                          <div>
                            <span className="font-mono text-cyan-400">{shortenAddr(tx.fromAddress || "")}</span>
                            {tx.fromLabel && <div className="text-[10px] text-gray-600">{tx.fromLabel}</div>}
                          </div>
                        </td>
                        <td className="px-3 py-2 text-center">
                          <span className={`text-sm ${isInbound ? "text-green-400" : "text-red-400"}`}>
                            {isInbound ? "←" : "→"}
                          </span>
                        </td>
                        <td className="px-3 py-2">
                          <div>
                            <span className="font-mono text-cyan-400">{shortenAddr(tx.toAddress || "")}</span>
                            {tx.toLabel && <div className="text-[10px] text-gray-600">{tx.toLabel}</div>}
                          </div>
                        </td>
                        <td className="px-3 py-2 text-right text-gray-200 font-mono">
                          {parseFloat(tx.amount || "0") >= 1000
                            ? `${(parseFloat(tx.amount) / 1000).toFixed(1)}K`
                            : parseFloat(tx.amount || "0").toFixed(4)
                          }
                        </td>
                        <td className="px-3 py-2">
                          <span className="px-1.5 py-0.5 bg-gray-800/50 rounded text-gray-300">{tx.tokenSymbol || nativeSym}</span>
                        </td>
                        <td className={`px-3 py-2 text-right font-medium ${isInbound ? "text-green-400" : "text-red-400"}`}>
                          {tx.amountUsd ? `${isInbound ? "+" : "-"}${formatUsd(parseFloat(tx.amountUsd))}` : "-"}
                        </td>
                        <td className="px-3 py-2">
                          {tx.txHash ? (
                            <a
                              href={explorerLink(tx.chain || wallet.chain, "tx", tx.txHash)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono text-blue-400 hover:underline"
                            >{tx.txHash.slice(0, 10)}...</a>
                          ) : <span className="text-gray-600">-</span>}
                        </td>
                      </tr>
                    );
                  })}
                  {transfers.length === 0 && (
                    <tr><td colSpan={8} className="px-4 py-8 text-center text-gray-600">No traced transactions found for this wallet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {!isLoading && activeSection === "counterparties" && (
        <div className="p-4">
          <div className="bg-[#161b22] rounded-lg border border-gray-800/50 overflow-hidden">
            <div className="px-4 py-2 border-b border-gray-800/30">
              <h4 className="text-xs font-bold text-gray-400">TOP COUNTERPARTIES</h4>
            </div>
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
              <table className="w-full text-xs" data-testid="table-entity-counterparties">
                <thead className="sticky top-0 bg-[#161b22]">
                  <tr className="border-b border-gray-800/30 text-gray-500">
                    <th className="px-4 py-2 text-left">Address</th>
                    <th className="px-4 py-2 text-left">Label</th>
                    <th className="px-4 py-2 text-center">Interactions</th>
                    <th className="px-4 py-2 text-right">Total Inflow</th>
                    <th className="px-4 py-2 text-right">Total Outflow</th>
                    <th className="px-4 py-2 text-right">Net Flow</th>
                  </tr>
                </thead>
                <tbody>
                  {counterparties.map((cp: any, i: number) => {
                    const net = (cp.totalInflow || 0) - (cp.totalOutflow || 0);
                    return (
                      <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                        <td className="px-4 py-2 font-mono text-cyan-400">
                          <a href={explorerLink(wallet.chain, "address", cp.address)} target="_blank" rel="noopener noreferrer" className="hover:underline">
                            {shortenAddr(cp.address)}
                          </a>
                        </td>
                        <td className="px-4 py-2 text-gray-300">{cp.label || "-"}</td>
                        <td className="px-4 py-2 text-center text-gray-400">{cp.txCount || 0}</td>
                        <td className="px-4 py-2 text-right text-green-400">{cp.totalInflow ? formatUsd(cp.totalInflow) : "-"}</td>
                        <td className="px-4 py-2 text-right text-red-400">{cp.totalOutflow ? formatUsd(cp.totalOutflow) : "-"}</td>
                        <td className={`px-4 py-2 text-right font-medium ${net >= 0 ? "text-green-400" : "text-red-400"}`}>
                          {net !== 0 ? `${net >= 0 ? "+" : ""}${formatUsd(Math.abs(net))}` : "-"}
                        </td>
                      </tr>
                    );
                  })}
                  {counterparties.length === 0 && (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-gray-600">No counterparties identified yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {!isLoading && activeSection === "exchanges" && (
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#161b22] rounded-lg border border-gray-800/50 p-4">
              <h4 className="text-xs font-bold text-gray-400 mb-3">EXCHANGE USAGE</h4>
              {exchanges.length > 0 ? (
                <div className="space-y-3">
                  {exchanges.map((ex: any, i: number) => {
                    const total = exchanges.reduce((s: number, e: any) => s + (e.totalVolume || 0), 0);
                    const pct = total > 0 ? ((ex.totalVolume || 0) / total * 100) : 0;
                    return (
                      <div key={i}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-gray-300">{ex.exchangeName}</span>
                          <div className="text-right">
                            <span className="text-xs text-green-400">{formatUsd(ex.totalVolume || 0)}</span>
                            <span className="text-[10px] text-gray-600 ml-2">({pct.toFixed(0)}%)</span>
                          </div>
                        </div>
                        <div className="w-full bg-gray-800 rounded-full h-1.5">
                          <div
                            className="h-1.5 rounded-full bg-gradient-to-r from-cyan-600 to-blue-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-gray-600 mt-0.5">
                          <span>Deposits: {formatUsd(ex.deposits || 0)}</span>
                          <span>Withdrawals: {formatUsd(ex.withdrawals || 0)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-xs text-gray-600 py-4 text-center">No exchange interactions detected</div>
              )}
            </div>

            <div className="bg-[#161b22] rounded-lg border border-gray-800/50 p-4">
              <h4 className="text-xs font-bold text-gray-400 mb-3">EXCHANGE SUMMARY</h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Exchanges Used</span>
                  <span className="text-gray-300">{exchanges.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Deposits</span>
                  <span className="text-green-400">{formatUsd(exchanges.reduce((s: number, e: any) => s + (e.deposits || 0), 0))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Withdrawals</span>
                  <span className="text-red-400">{formatUsd(exchanges.reduce((s: number, e: any) => s + (e.withdrawals || 0), 0))}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-gray-800/50">
                  <span className="text-gray-500">Total Volume</span>
                  <span className="text-white font-medium">{formatUsd(exchanges.reduce((s: number, e: any) => s + (e.totalVolume || 0), 0))}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
