/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PriceAlerts™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_a2efebf5cc9b38b81126a733
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, BellRing, Plus, Trash2, TrendingUp, TrendingDown, 
  Volume2, AlertTriangle, Check, X, Settings, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface PriceAlert {
  id: string;
  symbol: string;
  name: string;
  type: 'above' | 'below' | 'change_up' | 'change_down' | 'volume';
  targetPrice?: number;
  targetPercent?: number;
  targetVolume?: number;
  currentPrice: number;
  createdAt: Date;
  triggered: boolean;
  enabled: boolean;
}

const POPULAR_COINS = [
  { symbol: 'BTC', name: 'Bitcoin', price: 84200 },
  { symbol: 'ETH', name: 'Ethereum', price: 3150 },
  { symbol: 'SOL', name: 'Solana', price: 142 },
  { symbol: 'DOGE', name: 'Dogecoin', price: 0.12 },
  { symbol: 'XRP', name: 'Ripple', price: 0.62 },
  { symbol: 'PEPE', name: 'Pepe', price: 0.0000018 },
];

export function PriceAlerts() {
  const { toast } = useToast();
  const [alerts, setAlerts] = useState<PriceAlert[]>(() => {
    const saved = localStorage.getItem('trading-price-alerts');
    return saved ? JSON.parse(saved).map((a: any) => ({ ...a, createdAt: new Date(a.createdAt) })) : [];
  });
  const [showCreate, setShowCreate] = useState(false);
  const [selectedCoin, setSelectedCoin] = useState(POPULAR_COINS[0]);
  const [alertType, setAlertType] = useState<PriceAlert['type']>('above');
  const [targetValue, setTargetValue] = useState('');

  useEffect(() => {
    localStorage.setItem('trading-price-alerts', JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    const checkAlerts = async () => {
      const activeAlertsList = alerts.filter(a => !a.triggered && a.enabled);
      if (activeAlertsList.length === 0) return;

      const symbols = [...new Set(activeAlertsList.map(a => a.symbol))];
      const prices: Record<string, number> = {};

      await Promise.all(symbols.map(async (symbol) => {
        try {
          const res = await fetch(`/api/trading/ticker/${symbol}USDT`);
          if (res.ok) {
            const data = await res.json();
            prices[symbol] = typeof data.price === 'string' ? parseFloat(data.price) : data.price;
          }
        } catch {}
      }));

      setAlerts(prev => prev.map(alert => {
        if (alert.triggered || !alert.enabled) return alert;
        const newPrice = prices[alert.symbol];
        if (newPrice === undefined) return alert;

        const percentChange = ((newPrice - alert.currentPrice) / alert.currentPrice) * 100;

        let shouldTrigger = false;
        let triggerMessage = '';

        if (alert.type === 'above' && alert.targetPrice && newPrice >= alert.targetPrice) {
          shouldTrigger = true;
          triggerMessage = `Price above $${alert.targetPrice.toLocaleString()}`;
        } else if (alert.type === 'below' && alert.targetPrice && newPrice <= alert.targetPrice) {
          shouldTrigger = true;
          triggerMessage = `Price below $${alert.targetPrice.toLocaleString()}`;
        } else if (alert.type === 'change_up' && alert.targetPercent && percentChange >= alert.targetPercent) {
          shouldTrigger = true;
          triggerMessage = `Price increased by ${percentChange.toFixed(2)}%`;
        } else if (alert.type === 'change_down' && alert.targetPercent && percentChange <= -alert.targetPercent) {
          shouldTrigger = true;
          triggerMessage = `Price decreased by ${Math.abs(percentChange).toFixed(2)}%`;
        }

        if (shouldTrigger) {
          toast({
            title: `Price Alert Triggered!`,
            description: `${alert.symbol}: ${triggerMessage}`,
          });
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(`${alert.symbol} Alert`, {
              body: triggerMessage,
              icon: '/icon-192.png'
            });
          }
        }

        return { ...alert, currentPrice: newPrice, triggered: shouldTrigger };
      }));
    };

    const interval = setInterval(checkAlerts, 15000);
    checkAlerts();
    
    return () => clearInterval(interval);
  }, [toast, alerts.length]);

  const createAlert = () => {
    if (!targetValue) return;
    
    const newAlert: PriceAlert = {
      id: `alert_${Date.now()}`,
      symbol: selectedCoin.symbol,
      name: selectedCoin.name,
      type: alertType,
      targetPrice: alertType === 'above' || alertType === 'below' ? parseFloat(targetValue) : undefined,
      targetPercent: alertType === 'change_up' || alertType === 'change_down' ? parseFloat(targetValue) : undefined,
      targetVolume: alertType === 'volume' ? parseFloat(targetValue) : undefined,
      currentPrice: selectedCoin.price,
      createdAt: new Date(),
      triggered: false,
      enabled: true,
    };
    
    setAlerts([...alerts, newAlert]);
    setShowCreate(false);
    setTargetValue('');
    toast({ title: 'Alert Created', description: `You'll be notified when ${selectedCoin.symbol} reaches your target` });
  };

  const deleteAlert = (id: string) => {
    setAlerts(alerts.filter(a => a.id !== id));
  };

  const toggleAlert = (id: string) => {
    setAlerts(alerts.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        toast({ title: 'Notifications Enabled', description: 'You will receive push notifications for alerts' });
      }
    }
  };

  const activeAlerts = alerts.filter(a => !a.triggered && a.enabled);
  const triggeredAlerts = alerts.filter(a => a.triggered);

  return (
    <div className="space-y-4" data-testid="price-alerts">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Price Alerts</h2>
            <p className="text-xs text-gray-500">Get notified on price changes and volume spikes</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={requestNotificationPermission}
            variant="outline"
            size="sm"
            className="border-gray-700"
            data-testid="button-enable-notifications"
          >
            <BellRing size={14} className="mr-1" /> Enable Push
          </Button>
          <Button
            onClick={() => setShowCreate(true)}
            className="bg-cyan-500 hover:bg-cyan-600"
            size="sm"
            data-testid="button-create-alert"
          >
            <Plus size={14} className="mr-1" /> New Alert
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg text-center">
          <div className="text-2xl font-bold text-cyan-400">{activeAlerts.length}</div>
          <div className="text-xs text-gray-500">Active</div>
        </div>
        <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg text-center">
          <div className="text-2xl font-bold text-green-400">{triggeredAlerts.length}</div>
          <div className="text-xs text-gray-500">Triggered</div>
        </div>
        <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg text-center">
          <div className="text-2xl font-bold text-yellow-400">{alerts.length}</div>
          <div className="text-xs text-gray-500">Total</div>
        </div>
      </div>

      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-gray-900/50 border border-cyan-500/30 rounded-lg space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-white">Create New Alert</h3>
                <button onClick={() => setShowCreate(false)} className="text-gray-500 hover:text-white">
                  <X size={16} />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Cryptocurrency</label>
                  <select
                    value={selectedCoin.symbol}
                    onChange={(e) => setSelectedCoin(POPULAR_COINS.find(c => c.symbol === e.target.value) || POPULAR_COINS[0])}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                    data-testid="select-coin"
                  >
                    {POPULAR_COINS.map(coin => (
                      <option key={coin.symbol} value={coin.symbol}>{coin.symbol} - {coin.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Current Price</label>
                  <div className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm">
                    ${selectedCoin.price.toLocaleString()}
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-500 mb-2 block">Alert Type</label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: 'above', label: 'Price Above', icon: TrendingUp },
                    { id: 'below', label: 'Price Below', icon: TrendingDown },
                    { id: 'change_up', label: '% Increase', icon: TrendingUp },
                    { id: 'change_down', label: '% Decrease', icon: TrendingDown },
                    { id: 'volume', label: 'Volume Spike', icon: Volume2 },
                  ].map(type => (
                    <button
                      key={type.id}
                      onClick={() => setAlertType(type.id as PriceAlert['type'])}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        alertType === type.id
                          ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                          : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <type.icon size={12} /> {type.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-500 mb-1 block">
                  {alertType === 'volume' ? 'Target Volume (USD)' : alertType.includes('change') ? 'Target Percentage' : 'Target Price (USD)'}
                </label>
                <Input
                  type="number"
                  value={targetValue}
                  onChange={(e) => setTargetValue(e.target.value)}
                  placeholder={alertType === 'volume' ? '1000000' : alertType.includes('change') ? '5' : selectedCoin.price.toString()}
                  className="bg-gray-800 border-gray-700"
                  data-testid="input-target-value"
                />
              </div>

              <Button onClick={createAlert} className="w-full bg-cyan-500 hover:bg-cyan-600" data-testid="button-confirm-alert">
                <Bell size={14} className="mr-2" /> Create Alert
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {alerts.length === 0 ? (
        <div className="text-center py-8 bg-gray-900/50 rounded-lg border border-gray-800">
          <Bell size={40} className="mx-auto text-gray-600 mb-3" />
          <p className="text-gray-400 font-medium">No alerts yet</p>
          <p className="text-sm text-gray-500">Create your first alert to get notified on price changes</p>
        </div>
      ) : (
        <div className="space-y-2">
          {alerts.map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`p-3 rounded-lg border flex items-center justify-between ${
                alert.triggered
                  ? 'bg-green-500/10 border-green-500/30'
                  : alert.enabled
                    ? 'bg-gray-900/50 border-gray-800'
                    : 'bg-gray-900/30 border-gray-800/50 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  alert.triggered ? 'bg-green-500/20 text-green-400' : 'bg-gray-800 text-gray-400'
                }`}>
                  {alert.triggered ? <Check size={16} /> : alert.type === 'above' || alert.type === 'change_up' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-white">{alert.symbol}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      alert.type === 'above' || alert.type === 'change_up' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {alert.type === 'above' ? 'Above' : alert.type === 'below' ? 'Below' : alert.type === 'change_up' ? '+%' : alert.type === 'change_down' ? '-%' : 'Vol'}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">
                    Target: ${alert.targetPrice?.toLocaleString() || alert.targetPercent + '%' || alert.targetVolume?.toLocaleString()}
                    <span className="mx-2">|</span>
                    Current: ${alert.currentPrice.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {alert.triggered && (
                  <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded">Triggered</span>
                )}
                <button
                  onClick={() => toggleAlert(alert.id)}
                  className={`p-1.5 rounded ${alert.enabled ? 'text-cyan-400 hover:bg-cyan-500/20' : 'text-gray-600 hover:bg-gray-800'}`}
                  data-testid={`button-toggle-alert-${alert.id}`}
                >
                  {alert.enabled ? <Bell size={14} /> : <Bell size={14} />}
                </button>
                <button
                  onClick={() => deleteAlert(alert.id)}
                  className="p-1.5 rounded text-red-400 hover:bg-red-500/20"
                  data-testid={`button-delete-alert-${alert.id}`}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
