/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha CrossPlatformTrading™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_ed33297e0ce39af41f32a4c5
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowRightLeft, Wallet, Building2, Link2, AlertCircle, 
  CheckCircle, TrendingUp, Zap, ArrowRight, RefreshCw,
  ChevronDown, ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ConnectedWallet, ChainType } from '@/contexts/WalletContext';

interface ConnectedPlatform {
  id: string;
  name: string;
  type: 'wallet' | 'exchange';
  chain?: ChainType;
  icon: string;
}

interface CrossPlatformTradingProps {
  connectedWallets: ConnectedWallet[];
  connectedExchanges: string[];
  onExecuteTrade?: (params: CrossPlatformTradeParams) => void;
}

export interface CrossPlatformTradeParams {
  fromPlatform: ConnectedPlatform;
  toPlatform: ConnectedPlatform;
  asset: string;
  amount: number;
  action: 'transfer' | 'arbitrage';
}

const EXCHANGE_INFO: Record<string, { name: string; icon: string }> = {
  binance: { name: 'Binance', icon: '🟡' },
  bybit: { name: 'Bybit', icon: '🟠' },
  okx: { name: 'OKX', icon: '⚫' },
  coinbase: { name: 'Coinbase', icon: '🔵' },
  kraken: { name: 'Kraken', icon: '🟣' },
  kucoin: { name: 'KuCoin', icon: '🟢' },
  gate: { name: 'Gate.io', icon: '🔴' },
  mexc: { name: 'MEXC', icon: '🟤' },
  bitget: { name: 'Bitget', icon: '🔷' },
  htx: { name: 'HTX', icon: '🔶' },
};

const WALLET_INFO: Record<string, { icon: string }> = {
  phantom: { icon: '👻' },
  solflare: { icon: '☀️' },
  metamask: { icon: '🦊' },
  trust: { icon: '🛡️' },
  coinbase: { icon: '🔵' },
  okx: { icon: '⚫' },
};

const TRADEABLE_ASSETS = [
  { symbol: 'BTC', name: 'Bitcoin', chain: 'multi' },
  { symbol: 'ETH', name: 'Ethereum', chain: 'evm' },
  { symbol: 'SOL', name: 'Solana', chain: 'solana' },
  { symbol: 'USDT', name: 'Tether', chain: 'multi' },
  { symbol: 'USDC', name: 'USD Coin', chain: 'multi' },
  { symbol: 'XRP', name: 'Ripple', chain: 'multi' },
  { symbol: 'DOGE', name: 'Dogecoin', chain: 'multi' },
  { symbol: 'ADA', name: 'Cardano', chain: 'multi' },
];

export function CrossPlatformTrading({ 
  connectedWallets, 
  connectedExchanges,
  onExecuteTrade 
}: CrossPlatformTradingProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [fromPlatformId, setFromPlatformId] = useState<string>('');
  const [toPlatformId, setToPlatformId] = useState<string>('');
  const [selectedAsset, setSelectedAsset] = useState('USDT');
  const [amount, setAmount] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  const connectedPlatforms = useMemo<ConnectedPlatform[]>(() => {
    const platforms: ConnectedPlatform[] = [];
    
    connectedWallets.forEach(wallet => {
      platforms.push({
        id: `wallet-${wallet.id}`,
        name: wallet.name,
        type: 'wallet',
        chain: wallet.chain,
        icon: WALLET_INFO[wallet.type]?.icon || '💳',
      });
    });
    
    connectedExchanges.forEach(exchangeId => {
      const info = EXCHANGE_INFO[exchangeId];
      if (info) {
        platforms.push({
          id: `exchange-${exchangeId}`,
          name: info.name,
          type: 'exchange',
          icon: info.icon,
        });
      }
    });
    
    return platforms;
  }, [connectedWallets, connectedExchanges]);

  const hasMultiplePlatforms = connectedPlatforms.length >= 2;
  const fromPlatform = connectedPlatforms.find(p => p.id === fromPlatformId);
  const toPlatform = connectedPlatforms.find(p => p.id === toPlatformId);

  const handleSwapPlatforms = () => {
    const temp = fromPlatformId;
    setFromPlatformId(toPlatformId);
    setToPlatformId(temp);
  };

  const handleExecute = async () => {
    if (!fromPlatform || !toPlatform || !amount) return;
    
    setIsExecuting(true);
    
    const params: CrossPlatformTradeParams = {
      fromPlatform,
      toPlatform,
      asset: selectedAsset,
      amount: parseFloat(amount),
      action: 'transfer',
    };
    
    if (onExecuteTrade) {
      onExecuteTrade(params);
    }
    
    setTimeout(() => {
      setIsExecuting(false);
      setAmount('');
    }, 1500);
  };

  const canExecute = fromPlatform && toPlatform && amount && parseFloat(amount) > 0 && fromPlatformId !== toPlatformId;

  if (connectedPlatforms.length === 0) {
    return null;
  }

  return (
    <div className="bg-[#0D1A2D] border border-[#1A2942] rounded-xl overflow-hidden" data-testid="cross-platform-trading">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-[#152238] transition-colors"
        data-testid="toggle-cross-platform"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00D4FF]/20 to-[#00D4FF]/5 flex items-center justify-center">
            <ArrowRightLeft className="w-4 h-4 text-[#00D4FF]" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-semibold text-white">Cross-Platform Trading</h3>
            <p className="text-xs text-gray-500">
              {connectedPlatforms.length} platform{connectedPlatforms.length !== 1 ? 's' : ''} connected
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {hasMultiplePlatforms && (
            <span className="px-2 py-0.5 text-xs bg-green-500/20 text-green-400 rounded-full">
              Ready
            </span>
          )}
          {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
        </div>
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-[#1A2942]">
              <div className="mt-4 mb-3">
                <div className="flex flex-wrap gap-2 mb-4">
                  {connectedPlatforms.map(platform => (
                    <div
                      key={platform.id}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border ${
                        platform.type === 'wallet' 
                          ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
                          : 'bg-blue-500/10 border-blue-500/30 text-blue-400'
                      }`}
                    >
                      <span>{platform.icon}</span>
                      <span>{platform.name}</span>
                      {platform.chain && platform.chain !== 'none' && (
                        <span className="text-[10px] opacity-70">({platform.chain})</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {!hasMultiplePlatforms ? (
                <div className="flex items-center gap-3 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-yellow-400 font-medium">Connect More Platforms</p>
                    <p className="text-xs text-gray-400 mt-1">
                      Connect at least 2 platforms (wallets or exchanges) to enable cross-platform trading and arbitrage.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-center">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">From Platform</label>
                      <select
                        value={fromPlatformId}
                        onChange={(e) => setFromPlatformId(e.target.value)}
                        className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none"
                        data-testid="select-from-platform"
                      >
                        <option value="">Select source</option>
                        {connectedPlatforms.filter(p => p.id !== toPlatformId).map(platform => (
                          <option key={platform.id} value={platform.id}>
                            {platform.icon} {platform.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      onClick={handleSwapPlatforms}
                      className="mt-5 p-2 rounded-full bg-[#152238] hover:bg-[#1A2942] border border-[#1A2942] transition-colors"
                      data-testid="button-swap-platforms"
                    >
                      <ArrowRightLeft className="w-4 h-4 text-[#00D4FF]" />
                    </button>

                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">To Platform</label>
                      <select
                        value={toPlatformId}
                        onChange={(e) => setToPlatformId(e.target.value)}
                        className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none"
                        data-testid="select-to-platform"
                      >
                        <option value="">Select destination</option>
                        {connectedPlatforms.filter(p => p.id !== fromPlatformId).map(platform => (
                          <option key={platform.id} value={platform.id}>
                            {platform.icon} {platform.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Asset</label>
                      <select
                        value={selectedAsset}
                        onChange={(e) => setSelectedAsset(e.target.value)}
                        className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none"
                        data-testid="select-asset"
                      >
                        {TRADEABLE_ASSETS.map(asset => (
                          <option key={asset.symbol} value={asset.symbol}>
                            {asset.symbol} - {asset.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Amount</label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="bg-[#152238] border-[#1A2942] text-white"
                        data-testid="input-cross-amount"
                      />
                    </div>
                  </div>

                  {fromPlatform && toPlatform && amount && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-[#152238] rounded-lg border border-[#1A2942]"
                    >
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Transfer Preview</span>
                        <span className="text-[#00D4FF]">
                          {amount} {selectedAsset}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          {fromPlatform.icon} {fromPlatform.name}
                        </span>
                        <ArrowRight className="w-3 h-3" />
                        <span className="flex items-center gap-1">
                          {toPlatform.icon} {toPlatform.name}
                        </span>
                      </div>
                    </motion.div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      onClick={handleExecute}
                      disabled={!canExecute || isExecuting}
                      className="flex-1 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] hover:from-[#00B8E6] hover:to-[#0088BB] text-white font-semibold"
                      data-testid="button-execute-cross-trade"
                    >
                      {isExecuting ? (
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <ArrowRightLeft className="w-4 h-4 mr-2" />
                      )}
                      {isExecuting ? 'Executing...' : 'Transfer'}
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={() => {
                        setFromPlatformId('');
                        setToPlatformId('');
                        setAmount('');
                      }}
                      className="border-[#1A2942] text-gray-400 hover:text-white hover:bg-[#1A2942]"
                      data-testid="button-reset-cross-trade"
                    >
                      Reset
                    </Button>
                  </div>

                  <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <Zap className="w-4 h-4 text-green-400" />
                    <p className="text-xs text-green-400">
                      Tip: Check the <span className="font-semibold">Arbitrage Scanner</span> for price differences between your connected platforms!
                    </p>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
