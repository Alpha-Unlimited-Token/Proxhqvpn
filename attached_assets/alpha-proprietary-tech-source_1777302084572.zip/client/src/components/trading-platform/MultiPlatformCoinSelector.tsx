/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha MultiPlatformCoinSelector™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_d66e7cb9d8ef320ff7b13050
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { ChevronDown, RefreshCw, AlertTriangle, TrendingUp, Zap, Lock, ExternalLink, Clock, Search, X, Plus, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTrendingCoins, TrendingCoin, TRENDING_SOURCES } from '@/hooks/useTrendingCoins';
import { toast } from 'sonner';

interface CryptoPair {
  symbol: string;
  name: string;
  icon: string;
  category: string;
}

interface ConnectedExchange {
  id: string;
  name: string;
  type: 'exchange' | 'wallet' | 'platform';
}

interface CustomToken {
  symbol: string;
  name: string;
  icon: string;
  category: string;
  platform: string;
  contractAddress: string;
  chain: string;
}

interface MultiPlatformCoinSelectorProps {
  internalCoins: CryptoPair[];
  customTokens?: CustomToken[];
  connectedExchanges: ConnectedExchange[];
  selectedPair: CryptoPair;
  onSelectPair: (pair: CryptoPair) => void;
  onTradeAttempt?: (symbol: string, tradable: boolean) => void;
  variant?: 'main' | 'trading-platform';
  compact?: boolean;
}

const CRYPTO_CATEGORIES: Record<string, { name: string; icon: string }> = {
  major: { name: '🏆 Major', icon: '🏆' },
  layer1: { name: '⛓️ Layer 1', icon: '⛓️' },
  layer2: { name: '🔗 Layer 2', icon: '🔗' },
  defi: { name: '📊 DeFi', icon: '📊' },
  meme: { name: '🐸 Meme', icon: '🐸' },
  gaming: { name: '🎮 Gaming', icon: '🎮' },
  ai: { name: '🤖 AI', icon: '🤖' },
  infra: { name: '🏗️ Infrastructure', icon: '🏗️' },
  privacy: { name: '🔒 Privacy', icon: '🔒' },
  exchange: { name: '🏛️ Exchange', icon: '🏛️' },
  rwa: { name: '🏠 RWA', icon: '🏠' },
  socialfi: { name: '👥 SocialFi', icon: '👥' },
  dex: { name: '🔄 DEX', icon: '🔄' },
  stable: { name: '💵 Stablecoins', icon: '💵' },
  nft: { name: '🖼️ NFT', icon: '🖼️' },
  trending: { name: '🔥 Trending', icon: '🔥' },
  pump: { name: '🚀 Pump.fun', icon: '🚀' },
  gmgn: { name: '📈 GMGN', icon: '📈' },
  'gmgn-four': { name: '4️⃣ GMGN Four', icon: '4️⃣' },
  'gmgn-flap': { name: '🦅 GMGN Flap', icon: '🦅' },
  'gmgn-pump': { name: '🚀 GMGN Pump', icon: '🚀' },
  'gmgn-bonk': { name: '🦴 GMGN Bonk', icon: '🦴' },
  'gmgn-bags': { name: '💰 GMGN Bags', icon: '💰' },
  custom: { name: '⭐ Custom Added', icon: '⭐' },
};

export function MultiPlatformCoinSelector({
  internalCoins,
  customTokens = [],
  connectedExchanges,
  selectedPair,
  onSelectPair,
  onTradeAttempt,
  variant = 'trading-platform',
  compact = false,
}: MultiPlatformCoinSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'trending' | string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUntradableError, setShowUntradableError] = useState<string | null>(null);
  const [showAddByAddress, setShowAddByAddress] = useState(false);
  const [addressInput, setAddressInput] = useState('');
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });

  const updateDropdownPos = useCallback(() => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setDropdownPos({
        top: rect.bottom + 8,
        left: rect.left,
      });
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      updateDropdownPos();
      window.addEventListener('scroll', updateDropdownPos, true);
      window.addEventListener('resize', updateDropdownPos);
      return () => {
        window.removeEventListener('scroll', updateDropdownPos, true);
        window.removeEventListener('resize', updateDropdownPos);
      };
    }
  }, [isOpen, updateDropdownPos]);
  const [addingCoin, setAddingCoin] = useState(false);
  const [selectedChain, setSelectedChain] = useState<string>('auto');

  const SUPPORTED_CHAINS = [
    { id: 'auto', name: 'Auto-detect', icon: '🔍', addressPattern: /^.+$/, minLen: 10, maxLen: 128 },
    // EVM-compatible chains (0x prefix, 40 hex chars)
    { id: 'ethereum', name: 'Ethereum', icon: '⟠', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'bsc', name: 'BNB Chain', icon: '🔶', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'base', name: 'Base', icon: '🅱️', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'arbitrum', name: 'Arbitrum', icon: '🔵', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'polygon', name: 'Polygon', icon: '🟣', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'optimism', name: 'Optimism', icon: '🔴', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'avalanche', name: 'Avalanche', icon: '🔺', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'fantom', name: 'Fantom', icon: '👻', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'cronos', name: 'Cronos', icon: '💎', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'zksync', name: 'zkSync Era', icon: '⚡', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'linea', name: 'Linea', icon: '📐', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'scroll', name: 'Scroll', icon: '📜', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'mantle', name: 'Mantle', icon: '🏔️', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'manta', name: 'Manta Pacific', icon: '🐙', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'blast', name: 'Blast', icon: '💥', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'mode', name: 'Mode', icon: '🟡', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'zora', name: 'Zora', icon: '🌈', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'pulsechain', name: 'PulseChain', icon: '💓', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'celo', name: 'Celo', icon: '🟢', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'moonbeam', name: 'Moonbeam', icon: '🌙', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'moonriver', name: 'Moonriver', icon: '🌕', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'metis', name: 'Metis', icon: '🏛️', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'gnosis', name: 'Gnosis', icon: '🦉', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'aurora', name: 'Aurora', icon: '🌌', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'harmony', name: 'Harmony', icon: '🎵', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'kava', name: 'Kava', icon: '🌋', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'klaytn', name: 'Klaytn', icon: '🔷', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'evmos', name: 'Evmos', icon: '🌀', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'filecoin', name: 'Filecoin EVM', icon: '📁', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'worldchain', name: 'World Chain', icon: '🌍', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'zkevm', name: 'Polygon zkEVM', icon: '🔮', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'opbnb', name: 'opBNB', icon: '🟧', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'taiko', name: 'Taiko', icon: '🥁', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'berachain', name: 'Berachain', icon: '🐻', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'sei', name: 'Sei EVM', icon: '🌊', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'immutablex', name: 'Immutable X', icon: '🎮', addressPattern: /^0x[a-fA-F0-9]{40}$/, minLen: 42, maxLen: 42 },
    { id: 'starknet', name: 'StarkNet', icon: '⭐', addressPattern: /^0x[a-fA-F0-9]{63,64}$/, minLen: 65, maxLen: 66 },
    // Move-based chains (longer hex addresses)
    { id: 'sui', name: 'Sui', icon: '🌊', addressPattern: /^0x[a-fA-F0-9]{62,66}$/, minLen: 64, maxLen: 68 },
    { id: 'aptos', name: 'Aptos', icon: '🍎', addressPattern: /^0x[a-fA-F0-9]{62,66}$/, minLen: 64, maxLen: 68 },
    { id: 'movement', name: 'Movement', icon: '🏃', addressPattern: /^0x[a-fA-F0-9]{62,66}$/, minLen: 64, maxLen: 68 },
    // Solana and SPL tokens (Base58, 32-44 chars)
    { id: 'solana', name: 'Solana', icon: '◎', addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, minLen: 32, maxLen: 44 },
    { id: 'eclipse', name: 'Eclipse', icon: '🌑', addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/, minLen: 32, maxLen: 44 },
    // TON (48 chars, base64url)
    { id: 'ton', name: 'TON', icon: '💠', addressPattern: /^[a-zA-Z0-9_-]{48}$/, minLen: 48, maxLen: 48 },
    // TRON (T prefix, 34 chars base58)
    { id: 'tron', name: 'TRON', icon: '♦️', addressPattern: /^T[a-zA-Z0-9]{33}$/, minLen: 34, maxLen: 34 },
    // Stellar (G prefix for public keys, 56 chars)
    { id: 'stellar', name: 'Stellar', icon: '✦', addressPattern: /^G[A-Z2-7]{55}$/, minLen: 56, maxLen: 56 },
    // Ripple/XRP (r prefix)
    { id: 'xrp', name: 'XRP Ledger', icon: '✕', addressPattern: /^r[a-zA-Z0-9]{24,34}$/, minLen: 25, maxLen: 35 },
    // Cardano (addr1 prefix for Shelley era)
    { id: 'cardano', name: 'Cardano', icon: '₳', addressPattern: /^addr1[a-z0-9]{53,}$/, minLen: 58, maxLen: 120 },
    // Bitcoin and variants (various prefixes)
    { id: 'bitcoin', name: 'Bitcoin', icon: '₿', addressPattern: /^(1|3|bc1)[a-zA-HJ-NP-Z0-9]{25,62}$/, minLen: 26, maxLen: 64 },
    { id: 'litecoin', name: 'Litecoin', icon: 'Ł', addressPattern: /^(L|M|ltc1)[a-zA-HJ-NP-Z0-9]{25,62}$/, minLen: 26, maxLen: 64 },
    { id: 'dogecoin', name: 'Dogecoin', icon: '🐕', addressPattern: /^D[a-zA-HJ-NP-Z0-9]{33,34}$/, minLen: 34, maxLen: 35 },
    { id: 'bitcoincash', name: 'Bitcoin Cash', icon: '💵', addressPattern: /^(bitcoincash:)?[qp][a-z0-9]{41}$/, minLen: 42, maxLen: 55 },
    // Cosmos ecosystem (various prefixes)
    { id: 'cosmos', name: 'Cosmos Hub', icon: '⚛️', addressPattern: /^cosmos1[a-z0-9]{38}$/, minLen: 45, maxLen: 45 },
    { id: 'osmosis', name: 'Osmosis', icon: '🧪', addressPattern: /^osmo1[a-z0-9]{38}$/, minLen: 43, maxLen: 43 },
    { id: 'injective', name: 'Injective', icon: '💉', addressPattern: /^inj1[a-z0-9]{38}$/, minLen: 42, maxLen: 42 },
    { id: 'terra', name: 'Terra', icon: '🌍', addressPattern: /^terra1[a-z0-9]{38}$/, minLen: 44, maxLen: 44 },
    { id: 'juno', name: 'Juno', icon: '🏛️', addressPattern: /^juno1[a-z0-9]{38}$/, minLen: 43, maxLen: 43 },
    { id: 'secret', name: 'Secret Network', icon: '🔐', addressPattern: /^secret1[a-z0-9]{38}$/, minLen: 45, maxLen: 45 },
    { id: 'celestia', name: 'Celestia', icon: '🌌', addressPattern: /^celestia1[a-z0-9]{38}$/, minLen: 47, maxLen: 47 },
    { id: 'dymension', name: 'Dymension', icon: '🎲', addressPattern: /^dym1[a-z0-9]{38}$/, minLen: 42, maxLen: 42 },
    // Polkadot ecosystem
    { id: 'polkadot', name: 'Polkadot', icon: '●', addressPattern: /^1[a-zA-Z0-9]{47}$/, minLen: 48, maxLen: 48 },
    { id: 'kusama', name: 'Kusama', icon: '🐦', addressPattern: /^[A-HJ-NP-Za-km-z1-9]{47,48}$/, minLen: 47, maxLen: 48 },
    // Near Protocol
    { id: 'near', name: 'NEAR', icon: '🔗', addressPattern: /^[a-z0-9._-]{2,64}\.near$|^[a-f0-9]{64}$/, minLen: 7, maxLen: 69 },
    // Algorand
    { id: 'algorand', name: 'Algorand', icon: '🔷', addressPattern: /^[A-Z2-7]{58}$/, minLen: 58, maxLen: 58 },
    // Hedera
    { id: 'hedera', name: 'Hedera', icon: 'ℏ', addressPattern: /^0\.0\.[0-9]+$/, minLen: 5, maxLen: 20 },
    // Tezos
    { id: 'tezos', name: 'Tezos', icon: 'ꜩ', addressPattern: /^(tz1|tz2|tz3|KT1)[a-zA-Z0-9]{33}$/, minLen: 36, maxLen: 36 },
    // Flow
    { id: 'flow', name: 'Flow', icon: '🌊', addressPattern: /^0x[a-fA-F0-9]{16}$/, minLen: 18, maxLen: 18 },
    // Elrond/MultiversX
    { id: 'multiversx', name: 'MultiversX', icon: '⚡', addressPattern: /^erd1[a-z0-9]{58}$/, minLen: 62, maxLen: 62 },
    // Kaspa
    { id: 'kaspa', name: 'Kaspa', icon: '⛏️', addressPattern: /^kaspa:[a-z0-9]{61,63}$/, minLen: 67, maxLen: 70 },
    // Internet Computer
    { id: 'icp', name: 'Internet Computer', icon: '🌐', addressPattern: /^[a-z0-9-]{5,63}$/, minLen: 5, maxLen: 63 },
    // Chia
    { id: 'chia', name: 'Chia', icon: '🌱', addressPattern: /^xch1[a-z0-9]{58}$/, minLen: 62, maxLen: 62 },
    // Radix
    { id: 'radix', name: 'Radix', icon: '☢️', addressPattern: /^rdx1[a-z0-9]{58,}$/, minLen: 62, maxLen: 120 },
    // Monero
    { id: 'monero', name: 'Monero', icon: 'ɱ', addressPattern: /^4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}$/, minLen: 95, maxLen: 95 },
    // Sologenic/XRP Tokens
    { id: 'xrp-token', name: 'XRP Token', icon: '💱', addressPattern: /^[A-F0-9]{40}$/, minLen: 40, maxLen: 40 },
    // Generic hex (for unknown chains)
    { id: 'hex-generic', name: 'Hex Address', icon: '🔢', addressPattern: /^(0x)?[a-fA-F0-9]{40,66}$/, minLen: 40, maxLen: 68 },
  ];
  
  const exchangeIds = useMemo(() => 
    connectedExchanges.filter(e => e.type === 'exchange').map(e => e.id),
    [connectedExchanges]
  );
  
  const { 
    trendingCoins, 
    exchangeCoins, 
    liveExchangeCoins,
    loading, 
    lastUpdate, 
    refresh,
    isCoinTradable,
    getCoinDetails,
    addCoinByAddress
  } = useTrendingCoins(exchangeIds);

  const isValidAddress = (addr: string): boolean => {
    const trimmed = addr.trim();
    
    // In auto mode, accept virtually any address format (min 10 chars)
    // Let the API decide if it's valid - we don't want to block any potential formats
    if (selectedChain === 'auto') {
      // Accept any address that is at least 10 chars and doesn't contain obviously invalid characters
      return trimmed.length >= 10 && /^[a-zA-Z0-9.:_\-]+$/.test(trimmed);
    }
    
    const chain = SUPPORTED_CHAINS.find(c => c.id === selectedChain);
    if (!chain) {
      // If chain not found, still accept if it looks like a valid address
      return trimmed.length >= 10 && /^[a-zA-Z0-9.:_\-]+$/.test(trimmed);
    }
    
    return trimmed.length >= chain.minLen && 
           trimmed.length <= chain.maxLen && 
           chain.addressPattern.test(trimmed);
  };

  const getDetectedChain = (addr: string): string | null => {
    const trimmed = addr.trim();
    for (const chain of SUPPORTED_CHAINS) {
      if (chain.id === 'auto') continue;
      if (trimmed.length >= chain.minLen && 
          trimmed.length <= chain.maxLen && 
          chain.addressPattern.test(trimmed)) {
        return chain.name;
      }
    }
    return null;
  };

  const handleAddCoinByAddress = async () => {
    const trimmedAddress = addressInput.trim();
    
    if (!trimmedAddress) {
      toast.error('Please enter a contract address');
      return;
    }
    
    if (!isValidAddress(trimmedAddress)) {
      const chainInfo = selectedChain === 'auto' 
        ? 'Address must be at least 20 characters and contain only letters, numbers, hyphens, or underscores'
        : `Address doesn't match ${SUPPORTED_CHAINS.find(c => c.id === selectedChain)?.name || selectedChain} format`;
      toast.error('Invalid contract address format', {
        description: chainInfo,
        duration: 5000,
      });
      return;
    }
    
    setAddingCoin(true);
    const detectedChainName = getDetectedChain(trimmedAddress);
    
    try {
      const newCoin = await addCoinByAddress(trimmedAddress, selectedChain);
      
      if (newCoin) {
        toast.success(`Added ${newCoin.name} (${newCoin.symbol.replace('USDT', '')})`, {
          description: `${detectedChainName ? `Chain: ${detectedChainName} | ` : ''}Price: $${newCoin.price?.toLocaleString() || 'N/A'} | Liquidity: $${newCoin.liquidity?.toLocaleString() || 'N/A'}`,
          duration: 5000,
        });
        setAddressInput('');
        setShowAddByAddress(false);
        setSearchQuery('');
        setSelectedChain('auto');
      } else {
        const supportedChainsList = 'Ethereum, Solana, BSC, Base, Arbitrum, Polygon, etc.';
        toast.error('Token not found on DexScreener', {
          description: `This could mean: 1) The token doesn't have DEX liquidity, 2) The address is incorrect, or 3) The blockchain isn't indexed. Supported chains: ${supportedChainsList}`,
          duration: 8000,
        });
      }
    } catch (err) {
      console.error('Add coin error:', err);
      toast.error('Failed to add token', {
        description: 'Could not fetch token data. The token may not have DEX liquidity or the chain may not be indexed by DexScreener.',
        duration: 6000,
      });
    } finally {
      setAddingCoin(false);
    }
  };

  const primaryColor = variant === 'trading-platform' ? '#00D4FF' : '#FFD700';

  const allCoins = useMemo(() => {
    const coinMap = new Map<string, CryptoPair & { tradable?: boolean; source?: string }>();
    
    internalCoins.forEach(coin => {
      coinMap.set(coin.symbol, { ...coin, tradable: true, source: 'internal' });
    });
    
    trendingCoins.forEach(coin => {
      if (!coinMap.has(coin.symbol)) {
        coinMap.set(coin.symbol, {
          symbol: coin.symbol,
          name: coin.name,
          icon: coin.icon,
          category: coin.category,
          tradable: coin.tradable,
          source: coin.source
        });
      }
    });
    
    return Array.from(coinMap.values());
  }, [internalCoins, trendingCoins]);

  const filteredCoins = useMemo(() => {
    let coins = allCoins;
    
    if (activeTab === 'trending') {
      coins = trendingCoins.map(c => ({
        symbol: c.symbol,
        name: c.name,
        icon: c.icon,
        category: c.category,
        tradable: c.tradable,
        source: c.source
      }));
    } else if (activeTab !== 'all' && exchangeCoins[activeTab]) {
      coins = exchangeCoins[activeTab].map(c => ({
        symbol: c.symbol,
        name: c.name,
        icon: c.icon,
        category: c.category,
        tradable: c.tradable,
        source: c.source
      }));
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase().trim();
      coins = coins.filter(c => {
        const matchesSymbol = c.symbol.toLowerCase().includes(query);
        const matchesName = c.name.toLowerCase().includes(query);
        const details = getCoinDetails(c.symbol);
        const matchesAddress = details?.contractAddress?.toLowerCase().includes(query);
        return matchesSymbol || matchesName || matchesAddress;
      });
    }
    
    return coins;
  }, [allCoins, trendingCoins, exchangeCoins, activeTab, searchQuery]);

  const groupedCoins = useMemo(() => {
    const groups: Record<string, typeof filteredCoins> = {};
    
    filteredCoins.forEach(coin => {
      const cat = coin.category || 'other';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(coin);
    });
    
    return groups;
  }, [filteredCoins]);

  const handleSelectCoin = (coin: typeof allCoins[0]) => {
    const tradable = coin.tradable !== false && isCoinTradable(coin.symbol);
    
    if (!tradable) {
      setShowUntradableError(coin.symbol);
      toast.error(`${coin.name} is not tradable yet`, {
        description: 'This is a new token that hasn\'t reached sufficient liquidity. You can view it but cannot trade it.',
        duration: 5000,
        action: {
          label: 'View Details',
          onClick: () => {
            const details = getCoinDetails(coin.symbol);
            if (details?.contractAddress) {
              window.open(`https://dexscreener.com/solana/${details.contractAddress}`, '_blank', 'noopener,noreferrer');
            }
          }
        }
      });
      
      if (onTradeAttempt) {
        onTradeAttempt(coin.symbol, false);
      }
      
      setTimeout(() => setShowUntradableError(null), 3000);
      return;
    }
    
    onSelectPair({
      symbol: coin.symbol,
      name: coin.name,
      icon: coin.icon,
      category: coin.category
    });
    setIsOpen(false);
    setSearchQuery('');
    
    if (onTradeAttempt) {
      onTradeAttempt(coin.symbol, true);
    }
  };

  const tabs = useMemo(() => {
    const baseTabs = [
      { id: 'all', name: 'All Coins', icon: '🪙', count: allCoins.length },
      { id: 'trending', name: 'Trending', icon: '🔥', count: trendingCoins.length },
    ];
    
    connectedExchanges
      .filter(e => e.type === 'exchange')
      .forEach(exchange => {
        const coins = exchangeCoins[exchange.id] || [];
        baseTabs.push({
          id: exchange.id,
          name: exchange.name,
          icon: '🏛️',
          count: coins.length
        });
      });
    
    return baseTabs;
  }, [allCoins, trendingCoins, connectedExchanges, exchangeCoins]);

  return (
    <div className="relative" data-testid="multi-platform-coin-selector">
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
          compact ? 'text-sm' : ''
        }`}
        style={{
          borderColor: `${primaryColor}40`,
          backgroundColor: 'rgba(0,0,0,0.4)',
        }}
        data-testid="button-coin-selector"
      >
        <span className="text-lg">{selectedPair.icon}</span>
        <span className="font-bold" style={{ color: primaryColor }}>
          {selectedPair.symbol.replace('USDT', '/USDT')}
        </span>
        <ChevronDown 
          className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          style={{ color: primaryColor }}
        />
        {loading && <RefreshCw className="w-3 h-3 animate-spin text-gray-400" />}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
          <div className="fixed inset-0" style={{ zIndex: 9998 }} onClick={() => setIsOpen(false)} />
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="fixed w-[420px] max-h-[500px] bg-[#0A1628]/98 backdrop-blur-xl border rounded-xl shadow-2xl overflow-hidden"
            style={{ borderColor: `${primaryColor}30`, top: dropdownPos.top, left: dropdownPos.left, zIndex: 9999 }}
            data-testid="coin-selector-dropdown"
          >
            <div className="p-3 border-b" style={{ borderColor: `${primaryColor}20` }}>
              <div className="flex items-center gap-2 mb-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by ticker, name, or contract address..."
                    className="w-full pl-9 pr-8 py-2.5 bg-black/40 border rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1"
                    style={{ borderColor: `${primaryColor}30`, '--tw-ring-color': primaryColor } as any}
                    data-testid="input-coin-search"
                    autoFocus
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <button
                  onClick={refresh}
                  disabled={loading}
                  className="p-2 rounded-lg border transition-all hover:bg-white/5"
                  style={{ borderColor: `${primaryColor}30` }}
                  title="Refresh trending coins"
                  data-testid="button-refresh-coins"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} style={{ color: primaryColor }} />
                </button>
              </div>

              <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-thin">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                      activeTab === tab.id
                        ? 'text-white'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                    style={{
                      backgroundColor: activeTab === tab.id ? `${primaryColor}20` : 'transparent',
                      borderColor: activeTab === tab.id ? primaryColor : 'transparent',
                    }}
                    data-testid={`tab-${tab.id}`}
                  >
                    <span>{tab.icon}</span>
                    <span>{tab.name}</span>
                    <span className="text-gray-500">({tab.count})</span>
                  </button>
                ))}
              </div>

              {lastUpdate && (
                <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>Updated {new Date(lastUpdate).toLocaleTimeString()}</span>
                </div>
              )}
            </div>

            <div className="max-h-[350px] overflow-y-auto p-2">
              {activeTab === 'trending' && (
                <div className="flex flex-wrap gap-1 mb-3 px-1">
                  {TRENDING_SOURCES.map(source => (
                    <span 
                      key={source.id}
                      className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                      style={{ backgroundColor: `${source.color}20`, color: source.color }}
                    >
                      <span>{source.icon}</span>
                      <span>{source.name}</span>
                    </span>
                  ))}
                </div>
              )}

              {/* Added Tokens Section - Organized by Blockchain */}
              {customTokens.length > 0 && activeTab === 'all' && (
                <div className="mb-4 border-b border-purple-500/30 pb-3">
                  <div className="flex items-center gap-2 px-2 py-1 text-xs uppercase tracking-wider" style={{ color: primaryColor }}>
                    <span>⭐</span>
                    <span className="font-bold">Added Tokens</span>
                    <span className="text-gray-500">({customTokens.length})</span>
                  </div>
                  
                  {/* Group custom tokens by blockchain */}
                  {(() => {
                    const tokensByChain: Record<string, typeof customTokens> = {};
                    customTokens.forEach(token => {
                      const chain = token.chain || 'Unknown';
                      if (!tokensByChain[chain]) tokensByChain[chain] = [];
                      tokensByChain[chain].push(token);
                    });
                    
                    const chainIcons: Record<string, string> = {
                      'Solana': '◎',
                      'Ethereum': '⟠',
                      'BNB Chain': '🔶',
                      'Base': '🅱️',
                      'Arbitrum': '🔵',
                      'Polygon': '🟣',
                      'Avalanche': '🔺',
                      'Bitcoin': '₿',
                      'TON': '💠',
                      'TRON': '♦️',
                      'Sui': '🌊',
                      'Aptos': '🍎',
                      'Unknown': '❓',
                    };
                    
                    return Object.entries(tokensByChain).map(([chain, tokens]) => (
                      <div key={chain} className="ml-2 mb-2">
                        <div className="flex items-center gap-1 px-2 py-0.5 text-[10px] text-gray-500 uppercase">
                          <span>{chainIcons[chain] || '🔗'}</span>
                          <span>{chain}</span>
                          <span className="text-gray-600">({tokens.length})</span>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          {tokens.filter(token => 
                            !searchQuery || 
                            token.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            token.symbol.toLowerCase().includes(searchQuery.toLowerCase())
                          ).map(token => {
                            const isSelected = selectedPair.symbol === token.symbol;
                            return (
                              <button
                                key={token.symbol}
                                onClick={() => {
                                  onSelectPair({
                                    symbol: token.symbol,
                                    name: token.name,
                                    icon: token.icon,
                                    category: 'custom'
                                  });
                                  setIsOpen(false);
                                  setSearchQuery('');
                                }}
                                className={`flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-all ${
                                  isSelected
                                    ? 'ring-1 ring-purple-500 bg-purple-500/15'
                                    : 'hover:bg-purple-500/10'
                                }`}
                                data-testid={`custom-token-${token.symbol}`}
                              >
                                <span className="text-base">{token.icon}</span>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1">
                                    <span className={`font-medium text-xs truncate ${isSelected ? 'text-purple-400' : 'text-white'}`}>
                                      {token.symbol.replace('USDT', '').replace('-USDT', '')}
                                    </span>
                                    <span className="px-1 py-0.5 rounded bg-purple-500/20 text-purple-400 text-[9px]">
                                      ⭐
                                    </span>
                                  </div>
                                  <span className="text-[10px] text-gray-500 truncate block">
                                    {token.name}
                                  </span>
                                </div>
                                <span className="text-[9px] px-1 py-0.5 rounded bg-gray-700/50 text-gray-400">
                                  {token.platform || 'DEX'}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              )}

              {activeTab === 'all' && connectedExchanges.filter(e => e.type === 'exchange').length > 0 && (
                <>
                  {connectedExchanges.filter(e => e.type === 'exchange').map(exchange => {
                    const exCoins = exchangeCoins[exchange.id] || liveExchangeCoins;
                    const filtered = searchQuery 
                      ? exCoins.filter(c => 
                          c.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.name.toLowerCase().includes(searchQuery.toLowerCase())
                        )
                      : exCoins;
                    if (filtered.length === 0) return null;
                    return (
                      <div key={`exchange-${exchange.id}`} className="mb-4 border-b pb-3" style={{ borderColor: `${primaryColor}20` }}>
                        <div className="flex items-center gap-2 px-2 py-1.5 text-xs uppercase tracking-wider">
                          <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ backgroundColor: `${primaryColor}20`, color: primaryColor }}>
                            {exchange.name.charAt(0)}
                          </span>
                          <span className="font-bold" style={{ color: primaryColor }}>{exchange.name}</span>
                          <span className="text-gray-500">({filtered.length} coins)</span>
                          <span className="ml-auto text-[9px] px-1.5 py-0.5 rounded-full bg-green-500/20 text-green-400">Connected</span>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          {filtered.slice(0, searchQuery ? 100 : 20).map(coin => {
                            const isSelected = selectedPair.symbol === coin.symbol;
                            return (
                              <button
                                key={`${exchange.id}-${coin.symbol}`}
                                onClick={() => handleSelectCoin({ ...coin, category: coin.category || 'other' })}
                                className={`flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-all ${
                                  isSelected ? 'ring-1' : 'hover:bg-white/5'
                                }`}
                                style={{
                                  backgroundColor: isSelected ? `${primaryColor}15` : undefined,
                                  ...(isSelected ? { '--tw-ring-color': primaryColor } as any : {}),
                                }}
                                data-testid={`coin-${exchange.id}-${coin.symbol}`}
                              >
                                <span className="text-base">{coin.icon}</span>
                                <div className="flex-1 min-w-0">
                                  <span className="font-medium text-xs truncate block" style={{ color: isSelected ? primaryColor : 'white' }}>
                                    {coin.symbol.replace('USDT', '')}
                                  </span>
                                  <span className="text-[10px] text-gray-500 truncate block">{coin.name}</span>
                                </div>
                                <span className="text-[8px] px-1 py-0.5 rounded" style={{ backgroundColor: `${primaryColor}15`, color: primaryColor }}>
                                  {exchange.name.slice(0, 3).toUpperCase()}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                        {!searchQuery && filtered.length > 20 && (
                          <button
                            onClick={() => setActiveTab(exchange.id)}
                            className="w-full mt-1 py-1 text-xs text-center hover:bg-white/5 rounded transition-all"
                            style={{ color: primaryColor }}
                          >
                            View all {filtered.length} {exchange.name} coins →
                          </button>
                        )}
                      </div>
                    );
                  })}
                </>
              )}

              {Object.entries(groupedCoins).filter(([category]) => category !== 'custom').map(([category, coins]) => (
                <div key={category} className="mb-3">
                  <div className="flex items-center gap-2 px-2 py-1 text-xs text-gray-400 uppercase tracking-wider">
                    <span>{CRYPTO_CATEGORIES[category]?.icon || '🪙'}</span>
                    <span>{CRYPTO_CATEGORIES[category]?.name || category}</span>
                    <span className="text-gray-600">({coins.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-1">
                    {coins.map(coin => {
                      const isSelected = selectedPair.symbol === coin.symbol;
                      const tradable = coin.tradable !== false;
                      const isError = showUntradableError === coin.symbol;
                      
                      return (
                        <button
                          key={coin.symbol}
                          onClick={() => handleSelectCoin(coin)}
                          className={`flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-all ${
                            isSelected
                              ? 'ring-1 ring-[#00D4FF]'
                              : 'hover:bg-white/5'
                          } ${isError ? 'ring-1 ring-red-500 bg-red-500/10' : ''}`}
                          style={{
                            backgroundColor: isSelected ? `${primaryColor}15` : undefined,
                          }}
                          data-testid={`coin-${coin.symbol}`}
                        >
                          <span className="text-base">{coin.icon}</span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1">
                              <span 
                                className="font-medium text-xs truncate"
                                style={{ color: isSelected ? primaryColor : 'white' }}
                              >
                                {coin.symbol.replace('USDT', '').replace('-USDT', '').replace('_USDT', '')}
                              </span>
                              {!tradable && (
                                <span className="flex items-center gap-0.5 px-1 py-0.5 rounded bg-yellow-500/20 text-yellow-400 text-[10px]">
                                  <Lock className="w-2 h-2" />
                                  NEW
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-gray-500 truncate block">
                              {coin.name}
                            </span>
                          </div>
                          {coin.source && coin.source !== 'internal' && (
                            <span 
                              className="text-[9px] px-1 py-0.5 rounded"
                              style={{ 
                                backgroundColor: `${
                                  coin.source === 'pump' ? '#FF6B6B' :
                                  coin.source === 'gmgn' ? '#4CAF50' :
                                  coin.source === 'dexscreener' ? '#00D4FF' :
                                  coin.source === 'exchange' ? '#FFD700' :
                                  '#888'
                                }20`,
                                color: coin.source === 'pump' ? '#FF6B6B' :
                                  coin.source === 'gmgn' ? '#4CAF50' :
                                  coin.source === 'dexscreener' ? '#00D4FF' :
                                  coin.source === 'exchange' ? '#FFD700' :
                                  '#888'
                              }}
                            >
                              {coin.source === 'dexscreener' ? 'DEX' : 
                               coin.source === 'pump' ? 'PUMP' :
                               coin.source === 'gmgn' ? 'GMGN' :
                               coin.source === 'exchange' ? 'CEX' :
                               coin.source.toUpperCase()}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              {filteredCoins.length === 0 && (
                <div className="text-center py-6 text-gray-400">
                  <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="font-medium">No coins found for "{searchQuery}"</p>
                  <p className="text-sm mt-1 text-gray-500">Can't find your token? Add it by contract address!</p>
                  
                  {!showAddByAddress ? (
                    <button
                      onClick={() => setShowAddByAddress(true)}
                      className="mt-4 flex items-center gap-2 mx-auto px-4 py-2 rounded-lg border transition-all hover:bg-white/5"
                      style={{ borderColor: `${primaryColor}50`, color: primaryColor }}
                      data-testid="button-show-add-by-address"
                    >
                      <Plus className="w-4 h-4" />
                      Add Coin by Address
                    </button>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 p-3 bg-black/40 rounded-lg border text-left"
                      style={{ borderColor: `${primaryColor}30` }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-400" title="For address validation - chain auto-detected from address">
                          Blockchain (optional)
                        </label>
                        <select
                          value={selectedChain}
                          onChange={(e) => setSelectedChain(e.target.value)}
                          className="px-2 py-1 bg-black/60 border rounded text-xs text-white focus:outline-none"
                          style={{ borderColor: `${primaryColor}30` }}
                          data-testid="select-chain"
                        >
                          {SUPPORTED_CHAINS.map(chain => (
                            <option key={chain.id} value={chain.id}>
                              {chain.icon} {chain.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={addressInput}
                          onChange={(e) => setAddressInput(e.target.value)}
                          placeholder="Paste contract address..."
                          className="flex-1 px-3 py-2 bg-black/60 border rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1"
                          style={{ borderColor: `${primaryColor}30`, '--tw-ring-color': primaryColor } as any}
                          data-testid="input-coin-address"
                          disabled={addingCoin}
                        />
                        <button
                          onClick={handleAddCoinByAddress}
                          disabled={addingCoin || !addressInput.trim()}
                          className="px-4 py-2 rounded-lg font-medium text-sm transition-all disabled:opacity-50"
                          style={{ 
                            backgroundColor: primaryColor, 
                            color: '#000'
                          }}
                          data-testid="button-add-coin"
                        >
                          {addingCoin ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            'Add'
                          )}
                        </button>
                      </div>
                      {addressInput && selectedChain === 'auto' && getDetectedChain(addressInput) && (
                        <p className="mt-1 text-[10px] text-green-400">
                          Detected: {getDetectedChain(addressInput)}
                        </p>
                      )}
                      <div className="flex items-center justify-between mt-2">
                        <button
                          onClick={() => {
                            setShowAddByAddress(false);
                            setAddressInput('');
                            setSelectedChain('auto');
                          }}
                          className="text-xs text-gray-500 hover:text-gray-300"
                        >
                          Cancel
                        </button>
                        <p className="text-[10px] text-gray-600">
                          {SUPPORTED_CHAINS.length - 1} chains via DexScreener
                        </p>
                      </div>
                      <p className="mt-1 text-[9px] text-gray-700 text-center">
                        Token must have DEX liquidity to be indexed
                      </p>
                    </motion.div>
                  )}
                </div>
              )}
              
              {filteredCoins.length > 0 && searchQuery && (
                <div className="border-t mt-3 pt-3 text-center" style={{ borderColor: `${primaryColor}20` }}>
                  <p className="text-xs text-gray-500 mb-2">Can't find your token in the results?</p>
                  {!showAddByAddress ? (
                    <button
                      onClick={() => setShowAddByAddress(true)}
                      className="flex items-center gap-2 mx-auto px-3 py-1.5 rounded-lg border text-xs transition-all hover:bg-white/5"
                      style={{ borderColor: `${primaryColor}40`, color: primaryColor }}
                      data-testid="button-add-by-address-alt"
                    >
                      <Plus className="w-3 h-3" />
                      Add by Contract Address
                    </button>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-black/40 rounded-lg border text-left"
                      style={{ borderColor: `${primaryColor}30` }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs text-gray-400" title="For address validation">Blockchain</label>
                        <select
                          value={selectedChain}
                          onChange={(e) => setSelectedChain(e.target.value)}
                          className="px-2 py-1 bg-black/60 border rounded text-xs text-white focus:outline-none"
                          style={{ borderColor: `${primaryColor}30` }}
                          data-testid="select-chain-alt"
                        >
                          {SUPPORTED_CHAINS.map(chain => (
                            <option key={chain.id} value={chain.id}>
                              {chain.icon} {chain.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={addressInput}
                          onChange={(e) => setAddressInput(e.target.value)}
                          placeholder="Paste contract address..."
                          className="flex-1 px-3 py-2 bg-black/60 border rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none"
                          style={{ borderColor: `${primaryColor}30` }}
                          data-testid="input-coin-address-alt"
                          disabled={addingCoin}
                        />
                        <button
                          onClick={handleAddCoinByAddress}
                          disabled={addingCoin || !addressInput.trim()}
                          className="px-3 py-2 rounded-lg font-medium text-xs transition-all disabled:opacity-50"
                          style={{ backgroundColor: primaryColor, color: '#000' }}
                        >
                          {addingCoin ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Add'}
                        </button>
                        <button
                          onClick={() => {
                            setShowAddByAddress(false);
                            setAddressInput('');
                            setSelectedChain('auto');
                          }}
                          className="px-2 text-gray-500 hover:text-gray-300"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      {addressInput && selectedChain === 'auto' && getDetectedChain(addressInput) && (
                        <p className="mt-1 text-[10px] text-green-400">
                          Detected: {getDetectedChain(addressInput)}
                        </p>
                      )}
                    </motion.div>
                  )}
                </div>
              )}
            </div>

            <div className="p-2 border-t text-xs text-center text-gray-500" style={{ borderColor: `${primaryColor}20` }}>
              <div className="flex items-center justify-center gap-4">
                <span className="flex items-center gap-1">
                  <Zap className="w-3 h-3 text-green-400" />
                  {allCoins.filter(c => c.tradable !== false).length} Tradable
                </span>
                <span className="flex items-center gap-1">
                  <Lock className="w-3 h-3 text-yellow-400" />
                  {trendingCoins.filter(c => !c.tradable).length} New (View Only)
                </span>
              </div>
            </div>
          </motion.div>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showUntradableError && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute left-0 top-full mt-14 w-80 p-3 bg-red-900/90 backdrop-blur border border-red-500/50 rounded-lg shadow-xl z-60"
            data-testid="untradable-error"
          >
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-200">Token Not Tradable</p>
                <p className="text-sm text-red-300 mt-1">
                  This is a new token that hasn't reached sufficient liquidity or hasn't been listed on major exchanges yet.
                </p>
                <p className="text-xs text-red-400 mt-2">
                  You can view this token but cannot trade it until it becomes tradable.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function UntradableTokenModal({
  isOpen,
  onClose,
  tokenSymbol,
  tokenDetails,
}: {
  isOpen: boolean;
  onClose: () => void;
  tokenSymbol: string;
  tokenDetails?: TrendingCoin | null;
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-[#0A1628] border border-red-500/30 rounded-xl p-6 max-w-md mx-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-red-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Token Not Tradable</h3>
            <p className="text-sm text-gray-400">{tokenSymbol}</p>
          </div>
        </div>

        <div className="space-y-3 text-sm text-gray-300">
          <p>
            This token is <span className="text-yellow-400 font-medium">newly discovered</span> and is not yet available for trading on our platform.
          </p>
          
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
            <p className="text-yellow-300 font-medium mb-1">Why can't I trade this?</p>
            <ul className="text-xs text-yellow-200/80 space-y-1 list-disc list-inside">
              <li>Token may have low liquidity</li>
              <li>Not listed on major exchanges yet</li>
              <li>Still in early launch phase</li>
              <li>Risk assessment pending</li>
            </ul>
          </div>

          {tokenDetails && (
            <div className="bg-white/5 rounded-lg p-3 space-y-2">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Token Info</p>
              {tokenDetails.source && (
                <p><span className="text-gray-500">Source:</span> {tokenDetails.source}</p>
              )}
              {tokenDetails.chain && (
                <p><span className="text-gray-500">Chain:</span> {tokenDetails.chain}</p>
              )}
              {tokenDetails.contractAddress && (
                <p className="flex items-center gap-1">
                  <span className="text-gray-500">Contract:</span>
                  <code className="text-xs bg-black/40 px-1 rounded">
                    {tokenDetails.contractAddress.slice(0, 8)}...{tokenDetails.contractAddress.slice(-6)}
                  </code>
                </p>
              )}
            </div>
          )}
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 py-2 px-4 bg-white/10 hover:bg-white/20 rounded-lg text-white font-medium transition-colors"
          >
            Close
          </button>
          {tokenDetails?.contractAddress && (
            <button
              onClick={() => {
                window.open(`https://dexscreener.com/solana/${tokenDetails.contractAddress}`, '_blank', 'noopener,noreferrer');
              }}
              className="flex-1 py-2 px-4 bg-[#00D4FF]/20 hover:bg-[#00D4FF]/30 rounded-lg text-[#00D4FF] font-medium transition-colors flex items-center justify-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              View on DEX
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
