/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AINFTGenerator™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_52e0a0a79803d9494007a9e7
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useCallback, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import {
  Wand2, Sparkles, RefreshCw, AlertTriangle, ShoppingCart,
  CheckCircle, Lock, Eye, RotateCcw, Zap, ShieldAlert
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  useAiNftCredits, useAiNftCheckout, useAiNftPackages
} from "@/hooks/useNFTMarketplace";
import { apiRequest } from "@/lib/queryClient";
import { useQueryClient } from "@tanstack/react-query";
import { AI_NFT_MAX_RETRIES, SUPPORTED_BLOCKCHAINS } from "@shared/models/nft";

const BLOCKCHAIN_OPTIONS = SUPPORTED_BLOCKCHAINS.slice(0, 10);

interface AINFTGeneratorProps {
  onNFTCreated: () => void;
  showPackages: () => void;
}

function DRMPreviewCanvas({ imageUrl, alt }: { imageUrl: string; alt: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [captureDetected, setCaptureDetected] = useState(false);
  const captureTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const triggerProtection = useCallback(() => {
    setCaptureDetected(true);
    if (captureTimeoutRef.current) clearTimeout(captureTimeoutRef.current);
    captureTimeoutRef.current = setTimeout(() => setCaptureDetected(false), 2000);
  }, []);

  useEffect(() => {
    if (!imageUrl || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const gl = canvas.getContext("webgl", {
      preserveDrawingBuffer: false,
      antialias: true,
      alpha: true,
    });
    if (!gl) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      const vsSource = `
        attribute vec2 a_position;
        attribute vec2 a_texCoord;
        varying vec2 v_texCoord;
        void main() {
          gl_Position = vec4(a_position, 0.0, 1.0);
          v_texCoord = a_texCoord;
        }
      `;
      const fsSource = `
        precision mediump float;
        varying vec2 v_texCoord;
        uniform sampler2D u_image;
        void main() {
          gl_FragColor = texture2D(u_image, v_texCoord);
        }
      `;

      const vs = gl.createShader(gl.VERTEX_SHADER)!;
      gl.shaderSource(vs, vsSource);
      gl.compileShader(vs);
      const fs = gl.createShader(gl.FRAGMENT_SHADER)!;
      gl.shaderSource(fs, fsSource);
      gl.compileShader(fs);
      const program = gl.createProgram()!;
      gl.attachShader(program, vs);
      gl.attachShader(program, fs);
      gl.linkProgram(program);
      gl.useProgram(program);

      const posBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
        -1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1
      ]), gl.STATIC_DRAW);
      const posLoc = gl.getAttribLocation(program, "a_position");
      gl.enableVertexAttribArray(posLoc);
      gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);

      const texBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, texBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
        0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0
      ]), gl.STATIC_DRAW);
      const texLoc = gl.getAttribLocation(program, "a_texCoord");
      gl.enableVertexAttribArray(texLoc);
      gl.vertexAttribPointer(texLoc, 2, gl.FLOAT, false, 0, 0);

      const texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);

      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    };
    img.src = imageUrl;
  }, [imageUrl]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) triggerProtection();
    };
    const handleBlur = () => triggerProtection();

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleBlur);

    let mediaDevicesCleanup: (() => void) | null = null;
    if (navigator.mediaDevices) {
      const origGetDisplayMedia = navigator.mediaDevices.getDisplayMedia;
      if (origGetDisplayMedia) {
        navigator.mediaDevices.getDisplayMedia = function (options?: DisplayMediaStreamOptions) {
          triggerProtection();
          return origGetDisplayMedia.call(this, options);
        };
        mediaDevicesCleanup = () => {
          navigator.mediaDevices.getDisplayMedia = origGetDisplayMedia;
        };
      }
    }

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleBlur);
      if (mediaDevicesCleanup) mediaDevicesCleanup();
      if (captureTimeoutRef.current) clearTimeout(captureTimeoutRef.current);
    };
  }, [triggerProtection]);

  return (
    <div
      ref={containerRef}
      className="aspect-square rounded-xl overflow-hidden border border-[#1A2942] bg-[#0D1117] relative"
      onContextMenu={e => e.preventDefault()}
      style={{ WebkitTouchCallout: "none", WebkitUserSelect: "none", userSelect: "none" }}
      data-testid="drm-preview-container"
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full object-contain"
        draggable={false}
        onDragStart={e => e.preventDefault()}
        data-testid="canvas-ai-generated"
      />
      <div className="absolute inset-0 pointer-events-none" />
      {captureDetected && (
        <div
          className="absolute inset-0 bg-black z-50 flex items-center justify-center"
          data-testid="drm-capture-overlay"
        >
          <div className="text-center">
            <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-2" />
            <p className="text-red-500 text-sm font-bold">Screen Capture Detected</p>
            <p className="text-red-400 text-xs">Content protected by DRM</p>
          </div>
        </div>
      )}
    </div>
  );
}

export function AINFTGenerator({ onNFTCreated, showPackages }: AINFTGeneratorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: aiCreditsData } = useAiNftCredits();
  const aiCreditsRemaining = aiCreditsData?.totalRemaining ?? 0;

  const [nftName, setNftName] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");
  const [blockchain, setBlockchain] = useState("sol");

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedNFT, setGeneratedNFT] = useState<any>(null);
  const [generatedImageUrl, setGeneratedImageUrl] = useState("");
  const [serverAttemptsLeft, setServerAttemptsLeft] = useState(AI_NFT_MAX_RETRIES);
  const [currentGenerationId, setCurrentGenerationId] = useState<number | null>(null);
  const [generationAccepted, setGenerationAccepted] = useState(false);

  const hasActiveGeneration = !!currentGenerationId;
  const canRetry = hasActiveGeneration && serverAttemptsLeft > 0 && !generationAccepted;
  const retriesRemaining = serverAttemptsLeft;

  const handleGenerate = useCallback(async () => {
    if (!nftName.trim()) {
      toast({ title: "Name required", description: "Please enter a name for your NFT.", variant: "destructive" });
      return;
    }
    const isRetry = hasActiveGeneration;
    if (aiCreditsRemaining <= 0 && !isRetry) {
      toast({ title: "No credits", description: "Purchase an AI credit package to generate NFTs.", variant: "destructive" });
      showPackages();
      return;
    }
    if (isRetry && serverAttemptsLeft <= 0) {
      toast({ title: "No retries left", description: "You've used all retry attempts for this generation.", variant: "destructive" });
      return;
    }

    setIsGenerating(true);
    try {
      const res = await apiRequest("POST", "/api/ai-nft/generate", {
        name: nftName.trim(),
        blockchain,
        customPrompt: customPrompt || undefined,
        generationId: currentGenerationId,
        isRetry,
      });

      const data = await res.json();
      if (data.success) {
        setGeneratedNFT(data.nft);
        setGeneratedImageUrl(data.nft.imageUrl);
        setCurrentGenerationId(data.generationId || data.nft.id);
        setServerAttemptsLeft(data.attemptsRemaining ?? 0);
        setGenerationAccepted(false);
        queryClient.invalidateQueries({ queryKey: ["/api/ai-nft/credits"] });
        const remaining = data.attemptsRemaining ?? 0;
        toast({
          title: "NFT Generated!",
          description: `${data.message}. ${remaining > 0 ? `You have ${remaining} prompt change(s) remaining.` : "This was your last attempt."}`,
        });
      } else {
        toast({ title: "Generation failed", description: data.message, variant: "destructive" });
      }
    } catch (err: any) {
      const msg = err?.message || "Failed to generate AI NFT";
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setIsGenerating(false);
    }
  }, [nftName, aiCreditsRemaining, customPrompt, blockchain, currentGenerationId, hasActiveGeneration, serverAttemptsLeft, showPackages, toast, queryClient]);

  const handleAccept = useCallback(() => {
    setGenerationAccepted(true);
    toast({ title: "NFT Accepted!", description: `"${nftName}" has been added to your collection.` });
    onNFTCreated();
    setGeneratedNFT(null);
    setGeneratedImageUrl("");
    setServerAttemptsLeft(AI_NFT_MAX_RETRIES);
    setCurrentGenerationId(null);
    setNftName("");
    setCustomPrompt("");
  }, [nftName, onNFTCreated, toast]);

  const handleRetry = useCallback(() => {
    if (!canRetry) return;
    setGeneratedNFT(null);
    setGeneratedImageUrl("");
    toast({
      title: "Ready to retry",
      description: `Change your prompt and generate again. ${retriesRemaining} prompt change(s) remaining.`,
    });
  }, [canRetry, retriesRemaining, toast]);

  const resetAll = useCallback(() => {
    setGeneratedNFT(null);
    setGeneratedImageUrl("");
    setServerAttemptsLeft(AI_NFT_MAX_RETRIES);
    setCurrentGenerationId(null);
    setGenerationAccepted(false);
    setNftName("");
    setCustomPrompt("");
  }, []);

  return (
    <div className="space-y-4" data-testid="ai-nft-generator">
      <div className="bg-gradient-to-r from-[#FFD700]/10 to-[#00D4FF]/10 border border-[#FFD700]/20 rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-white font-bold text-lg flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-[#FFD700]" /> AI NFT Generator
          </h2>
          <div className="flex items-center gap-2">
            <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-1.5 flex items-center gap-2" data-testid="display-credits">
              <Zap className="w-3.5 h-3.5 text-[#FFD700]" />
              <span className="text-white text-sm font-bold" data-testid="text-credits-count">{aiCreditsRemaining}</span>
              <span className="text-[#64748B] text-xs">credits</span>
            </div>
            <Button
              onClick={showPackages}
              className="bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-semibold text-xs px-3 py-1.5 rounded-lg hover:opacity-90"
              data-testid="button-buy-credits"
            >
              <ShoppingCart className="w-3 h-3 mr-1" /> Buy Credits
            </Button>
          </div>
        </div>
        <p className="text-[#94A3B8] text-sm">
          Create unique AI-generated NFT artwork. Each credit generates one NFT with up to {AI_NFT_MAX_RETRIES} prompt changes to get exactly what you want.
        </p>
      </div>

      {generatedImageUrl ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm flex items-center gap-2 mb-3">
              <Eye className="w-4 h-4 text-[#00D4FF]" /> Generated NFT Preview
            </h3>
            <DRMPreviewCanvas imageUrl={generatedImageUrl} alt={nftName} />
            <div className="mt-3 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-[#64748B]">Attempts:</span>
                <div className="flex gap-0.5">
                  {Array.from({ length: AI_NFT_MAX_RETRIES }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2 h-2 rounded-full ${
                        i < (AI_NFT_MAX_RETRIES - serverAttemptsLeft) ? "bg-[#FFD700]" : "bg-[#1A2942]"
                      }`}
                      data-testid={`indicator-attempt-${i}`}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-[#94A3B8]" data-testid="text-retries-left">{retriesRemaining} left</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
              <h3 className="text-white font-semibold text-sm mb-3">What would you like to do?</h3>
              <div className="space-y-2">
                <Button
                  onClick={handleAccept}
                  className="w-full bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-black font-bold py-3 text-sm rounded-lg"
                  data-testid="button-accept-nft"
                >
                  <CheckCircle className="w-4 h-4 mr-2" /> Accept This NFT
                </Button>

                {canRetry && retriesRemaining > 0 && (
                  <Button
                    onClick={handleRetry}
                    className="w-full bg-[#1A2942] text-[#FFD700] border border-[#FFD700]/30 font-semibold py-3 text-sm rounded-lg hover:bg-[#FFD700]/10"
                    data-testid="button-retry-prompt"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" /> Change Prompt ({retriesRemaining} retries left)
                  </Button>
                )}

                {!canRetry && !generationAccepted && (
                  <p className="text-yellow-400 text-xs text-center flex items-center justify-center gap-1" data-testid="text-no-retries">
                    <AlertTriangle className="w-3 h-3" /> No retries remaining. Accept or start a new NFT.
                  </p>
                )}

                <Button
                  onClick={resetAll}
                  className="w-full bg-[#0D1117] text-[#64748B] border border-[#1A2942] font-medium py-2 text-xs rounded-lg hover:text-white"
                  data-testid="button-start-new"
                >
                  Start New NFT (uses new credit)
                </Button>
              </div>
            </div>

            {generatedNFT && (
              <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
                <h4 className="text-[#64748B] text-xs font-medium mb-2">NFT Details</h4>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs px-2 py-1 bg-[#0D1117] rounded" data-testid="detail-name">
                    <span className="text-[#94A3B8]">Name</span>
                    <span className="text-white">{generatedNFT.name}</span>
                  </div>
                  <div className="flex justify-between text-xs px-2 py-1 bg-[#0D1117] rounded" data-testid="detail-blockchain">
                    <span className="text-[#94A3B8]">Blockchain</span>
                    <span className="text-white">
                      {BLOCKCHAIN_OPTIONS.find(b => b.id === blockchain)?.name || blockchain.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-[#FFD700]" /> NFT Configuration
            </h3>
            <div className="space-y-2.5">
              <div>
                <label className="text-[10px] text-[#94A3B8] mb-0.5 block">NFT Name *</label>
                <input
                  type="text"
                  value={nftName}
                  onChange={e => setNftName(e.target.value)}
                  placeholder="Enter a name for your NFT..."
                  className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-[#00D4FF]/50"
                  data-testid="input-ai-nft-name"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#94A3B8] mb-0.5 block">Prompt *</label>
                <textarea
                  value={customPrompt}
                  onChange={e => setCustomPrompt(e.target.value)}
                  placeholder="Describe your character: hair color, eye color, outfit, pose, background scene, art style (anime, cyberpunk, realistic, pixel art)..."
                  rows={4}
                  className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-[#00D4FF]/50 resize-none"
                  data-testid="input-ai-prompt"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#94A3B8] mb-0.5 block">Blockchain</label>
                <select
                  value={blockchain}
                  onChange={e => setBlockchain(e.target.value)}
                  className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-2 py-2 text-white text-xs focus:outline-none focus:border-[#00D4FF]/50"
                  data-testid="select-blockchain"
                >
                  {BLOCKCHAIN_OPTIONS.map(bc => (
                    <option key={bc.id} value={bc.id}>{bc.icon} {bc.name} ({bc.symbol})</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm">Generate</h3>
              <div className="flex items-center gap-1 text-[10px]">
                <span className="text-[#64748B]">Cost: 1 credit</span>
                <span className="text-[#3A4A5A]">·</span>
                <span className="text-[#FFD700]">Up to {AI_NFT_MAX_RETRIES} prompt changes</span>
              </div>
            </div>

            {aiCreditsRemaining > 0 || hasActiveGeneration ? (
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !nftName.trim()}
                className="w-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold py-3 text-sm rounded-lg disabled:opacity-50"
                data-testid="button-generate-ai-nft"
              >
                {isGenerating ? (
                  <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating with AI...</>
                ) : hasActiveGeneration ? (
                  <><RotateCcw className="w-4 h-4 mr-2" /> Retry Generation ({retriesRemaining} left)</>
                ) : (
                  <><Wand2 className="w-4 h-4 mr-2" /> Generate AI NFT</>
                )}
              </Button>
            ) : (
              <div className="text-center py-3">
                <Lock className="w-6 h-6 text-[#1A2942] mx-auto mb-2" />
                <p className="text-[#94A3B8] text-sm mb-2">Purchase credits to start generating</p>
                <Button
                  onClick={showPackages}
                  className="bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-semibold text-xs px-4 py-2 rounded-lg hover:opacity-90"
                  data-testid="button-buy-credits-cta"
                >
                  <ShoppingCart className="w-3 h-3 mr-1" /> View Credit Packages
                </Button>
              </div>
            )}
          </div>

          <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-3">
            <h4 className="text-[#64748B] text-xs font-medium mb-2 flex items-center gap-1.5">
              <Lock className="w-3 h-3" /> How It Works
            </h4>
            <div className="space-y-1 text-[10px] text-[#94A3B8]">
              <p>1. Enter a name and describe your NFT artwork using the prompt</p>
              <p>2. Choose your preferred style, rarity, background, and blockchain</p>
              <p>3. Generate your NFT — each credit allows up to {AI_NFT_MAX_RETRIES} prompt adjustments</p>
              <p>4. Accept the result or tweak your prompt and regenerate</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
