/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha NFTCommunityFeatures™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_65cd73799a574c3f6c98fb9b
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  useUserXP, useForumPosts, useForumPost, useCreateForumPost,
  useCreateForumReply, useLikeForumPost, useDexProtocols,
  useNftFractions, useBuyFraction, useUserFractions,
  usePurchaseP2P, usePlatformWallets, useNFTCheckoutNowPayments, useNFTPaymentStatus,
} from "@/hooks/useNFTMarketplace";
import { useAuth } from "@/hooks/use-auth";
import type { NFT } from "@shared/models/nft";
import {
  Trophy, Star, Zap, MessageSquare, Heart, Send, ChevronRight,
  Award, TrendingUp, Users, PieChart, Lock, Globe, ArrowRight,
  Shield, Sparkles, Crown, Gem, Target, Gift, Percent, Wallet,
  Copy, QrCode, Download, ExternalLink, CheckCircle, AlertTriangle,
} from "lucide-react";

export function GamifiedRewardsPanel() {
  const { data: xpData, isLoading } = useUserXP();
  const { user } = useAuth();

  if (!user) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-[#161B22] to-[#0D1117] rounded-2xl border border-white/10 p-6"
        data-testid="rewards-panel-locked">
        <div className="text-center py-8">
          <Lock className="w-12 h-12 text-[#FFD700]/50 mx-auto mb-3" />
          <h3 className="text-white font-bold text-lg mb-2">Sign in to Track Rewards</h3>
          <p className="text-gray-400 text-sm">Earn XP for every action and level up your profile</p>
        </div>
      </motion.div>
    );
  }

  const totalXP = xpData?.totalXP || 0;
  const currentLevel = xpData?.currentLevel || { level: 1, name: "Rookie", xp: 0 };
  const nextLevel = xpData?.nextLevel;
  const progress = nextLevel ? ((totalXP - currentLevel.xp) / (nextLevel.xp - currentLevel.xp)) * 100 : 100;

  const LEVEL_ICONS: Record<string, any> = {
    Rookie: Shield, Explorer: Star, Collector: Gem, Trader: TrendingUp,
    "Power Trader": Zap, Expert: Target, Master: Award,
    "Grand Master": Crown, Legend: Sparkles, "Alpha God": Trophy,
  };

  const LevelIcon = LEVEL_ICONS[currentLevel.name] || Trophy;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-[#161B22] to-[#0D1117] rounded-2xl border border-[#FFD700]/20 p-6"
      data-testid="rewards-panel">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-white font-bold text-lg flex items-center gap-2">
          <Trophy className="w-5 h-5 text-[#FFD700]" />
          Your Rewards
        </h3>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#FFD700]/10 rounded-full border border-[#FFD700]/30">
          <LevelIcon className="w-4 h-4 text-[#FFD700]" />
          <span className="text-[#FFD700] text-sm font-bold">Lvl {currentLevel.level}</span>
        </div>
      </div>

      <div className="text-center mb-6">
        <div className="relative w-24 h-24 mx-auto mb-3">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" fill="none" stroke="#21262D" strokeWidth="8" />
            <circle cx="50" cy="50" r="42" fill="none" stroke="#FFD700" strokeWidth="8"
              strokeDasharray={`${progress * 2.64} 264`} strokeLinecap="round" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <LevelIcon className="w-8 h-8 text-[#FFD700]" />
          </div>
        </div>
        <h4 className="text-white font-bold text-xl">{currentLevel.name}</h4>
        <p className="text-[#FFD700] font-bold text-2xl mt-1">{totalXP.toLocaleString()} XP</p>
        {nextLevel && (
          <p className="text-gray-400 text-xs mt-1">
            {(nextLevel.xp - totalXP).toLocaleString()} XP to {nextLevel.name}
          </p>
        )}
      </div>

      <div className="w-full bg-[#21262D] rounded-full h-2 mb-4">
        <div className="bg-gradient-to-r from-[#FFD700] to-[#00D4FF] h-2 rounded-full transition-all"
          style={{ width: `${Math.min(progress, 100)}%` }} />
      </div>

      <div className="space-y-2">
        <h4 className="text-white text-sm font-semibold mb-2">XP Actions</h4>
        {[
          { action: "Purchase NFT", xp: 50, icon: "🛒" },
          { action: "Create NFT", xp: 25, icon: "🎨" },
          { action: "Sell NFT", xp: 75, icon: "💰" },
          { action: "Stake NFT", xp: 30, icon: "📈" },
          { action: "Forum Post", xp: 15, icon: "💬" },
          { action: "Refer Friend", xp: 100, icon: "👥" },
        ].map((item) => (
          <div key={item.action} className="flex items-center justify-between p-2 bg-[#21262D]/50 rounded-lg">
            <div className="flex items-center gap-2">
              <span>{item.icon}</span>
              <span className="text-gray-300 text-xs">{item.action}</span>
            </div>
            <span className="text-[#FFD700] text-xs font-bold">+{item.xp} XP</span>
          </div>
        ))}
      </div>

      {xpData?.recentRewards && xpData.recentRewards.length > 0 && (
        <div className="mt-4 pt-4 border-t border-white/10">
          <h4 className="text-white text-sm font-semibold mb-2">Recent Rewards</h4>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {xpData.recentRewards.slice(0, 5).map((r: any, i: number) => (
              <div key={i} className="flex items-center justify-between py-1">
                <span className="text-gray-400 text-xs truncate flex-1">{r.description}</span>
                <span className="text-[#FFD700] text-xs font-bold ml-2">+{r.xpEarned} XP</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}

export function CommunityForum() {
  const [category, setCategory] = useState<string>("all");
  const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
  const [showNewPost, setShowNewPost] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [replyContent, setReplyContent] = useState("");
  const { user } = useAuth();

  const { data: posts, isLoading } = useForumPosts(category === "all" ? undefined : category);
  const { data: postDetail } = useForumPost(selectedPostId || 0);
  const createPost = useCreateForumPost();
  const createReply = useCreateForumReply();
  const likePost = useLikeForumPost();

  const categories = [
    { id: "all", label: "All", icon: Globe },
    { id: "general", label: "General", icon: MessageSquare },
    { id: "trading", label: "Trading", icon: TrendingUp },
    { id: "nft", label: "NFTs", icon: Gem },
    { id: "strategies", label: "Strategies", icon: Target },
  ];

  const handleCreatePost = () => {
    if (!newTitle.trim() || !newContent.trim()) return;
    createPost.mutate({ title: newTitle, content: newContent, category }, {
      onSuccess: () => { setNewTitle(""); setNewContent(""); setShowNewPost(false); },
    });
  };

  const handleReply = () => {
    if (!replyContent.trim() || !selectedPostId) return;
    createReply.mutate({ postId: selectedPostId, content: replyContent }, {
      onSuccess: () => setReplyContent(""),
    });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-[#161B22] to-[#0D1117] rounded-2xl border border-white/10 p-6"
      data-testid="community-forum">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-white font-bold text-lg flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-[#00D4FF]" />
          Community Forum
        </h3>
        {user && !selectedPostId && (
          <Button size="sm" onClick={() => setShowNewPost(!showNewPost)}
            className="bg-[#FFD700] text-black hover:bg-[#FFD700]/80 text-xs"
            data-testid="btn-new-post">
            + New Post
          </Button>
        )}
        {selectedPostId && (
          <Button size="sm" variant="outline" onClick={() => setSelectedPostId(null)}
            className="border-white/20 text-white text-xs" data-testid="btn-back-forum">
            Back
          </Button>
        )}
      </div>

      {!selectedPostId && (
        <>
          <div className="flex gap-2 mb-4 flex-wrap">
            {categories.map((cat) => (
              <button key={cat.id} onClick={() => setCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all flex items-center gap-1 ${
                  category === cat.id
                    ? "bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/40"
                    : "bg-[#21262D] text-gray-400 hover:text-white border border-white/5"
                }`} data-testid={`category-${cat.id}`}>
                <cat.icon className="w-3 h-3" />
                {cat.label}
              </button>
            ))}
          </div>

          <AnimatePresence>
            {showNewPost && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }} className="overflow-hidden mb-4">
                <div className="bg-[#21262D] rounded-xl p-4 space-y-3">
                  <input type="text" value={newTitle} onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Post title..." data-testid="input-post-title"
                    className="w-full bg-[#0D1117] border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-[#FFD700]/50" />
                  <textarea value={newContent} onChange={(e) => setNewContent(e.target.value)}
                    placeholder="Write your post..." rows={3} data-testid="input-post-content"
                    className="w-full bg-[#0D1117] border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-[#FFD700]/50 resize-none" />
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="ghost" onClick={() => setShowNewPost(false)}
                      className="text-gray-400 text-xs">Cancel</Button>
                    <Button size="sm" onClick={handleCreatePost} disabled={createPost.isPending}
                      className="bg-[#FFD700] text-black hover:bg-[#FFD700]/80 text-xs"
                      data-testid="btn-submit-post">
                      {createPost.isPending ? "Posting..." : "Post"}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {isLoading ? (
              <div className="text-center py-8 text-gray-400">Loading posts...</div>
            ) : !posts?.length ? (
              <div className="text-center py-8">
                <MessageSquare className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">No posts yet. Be the first!</p>
              </div>
            ) : (
              posts.map((post: any) => (
                <motion.div key={post.id} whileHover={{ scale: 1.01 }}
                  onClick={() => setSelectedPostId(post.id)}
                  className="bg-[#21262D] rounded-xl p-4 cursor-pointer hover:border-[#FFD700]/30 border border-white/5 transition-all"
                  data-testid={`forum-post-${post.id}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        {post.isPinned && <span className="text-[#FFD700] text-xs">📌</span>}
                        <h4 className="text-white font-semibold text-sm">{post.title}</h4>
                      </div>
                      <p className="text-gray-400 text-xs line-clamp-2">{post.content}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                        <span>@{post.username}</span>
                        <span className="flex items-center gap-1"><Heart className="w-3 h-3" />{post.likes}</span>
                        <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" />{post.replies}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-500 flex-shrink-0 mt-1" />
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </>
      )}

      {selectedPostId && postDetail && (
        <div className="space-y-4">
          <div className="bg-[#21262D] rounded-xl p-4">
            <h4 className="text-white font-bold text-base mb-2">{postDetail.post.title}</h4>
            <p className="text-gray-300 text-sm whitespace-pre-wrap">{postDetail.post.content}</p>
            <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
              <span>@{postDetail.post.username}</span>
              <button onClick={(e) => { e.stopPropagation(); likePost.mutate(selectedPostId); }}
                className="flex items-center gap-1 hover:text-red-400 transition-colors"
                data-testid="btn-like-post">
                <Heart className="w-3 h-3" />{postDetail.post.likes}
              </button>
            </div>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {postDetail.replies?.map((reply: any) => (
              <div key={reply.id} className="bg-[#0D1117] rounded-lg p-3 ml-4 border-l-2 border-[#00D4FF]/30">
                <p className="text-gray-300 text-sm">{reply.content}</p>
                <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                  <span>@{reply.username}</span>
                  <span>{new Date(reply.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>

          {user && (
            <div className="flex gap-2">
              <input value={replyContent} onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Write a reply..." data-testid="input-reply"
                className="flex-1 bg-[#21262D] border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-[#00D4FF]/50"
                onKeyDown={(e) => e.key === "Enter" && handleReply()} />
              <Button size="sm" onClick={handleReply} disabled={createReply.isPending}
                className="bg-[#00D4FF] text-black hover:bg-[#00D4FF]/80" data-testid="btn-submit-reply">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

export function FractionalOwnershipCard({ nft, onClose }: { nft: NFT; onClose: () => void }) {
  const [shares, setShares] = useState(10);
  const [step, setStep] = useState<"select" | "pay">("select");
  const [transactionHash, setTransactionHash] = useState("");
  const { data: fractionData } = useNftFractions(nft.id);
  const buyFraction = useBuyFraction();
  const { user } = useAuth();

  const pricePerShare = nft.priceUSD / 100;
  const totalCost = pricePerShare * shares;
  const available = fractionData?.available ?? 100;
  const sellerWallet = nft.ownerWallet || nft.creatorWallet || "";
  const chain = nft.blockchain || "sol";
  const chainInfo = BLOCKCHAIN_DETAILS[chain] || BLOCKCHAIN_DETAILS.sol;

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
      className="bg-[#161B22] rounded-2xl border border-[#FFD700]/20 p-6 relative"
      data-testid="fractional-ownership-card">
      <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-white">✕</button>
      
      <div className="flex items-center gap-2 mb-4">
        <PieChart className="w-5 h-5 text-[#FFD700]" />
        <h3 className="text-white font-bold">Buy Fractional Shares</h3>
      </div>

      <div className="bg-[#21262D] rounded-xl p-4 mb-4">
        <div className="flex items-center gap-3">
          {nft.imageUrl && (
            <img src={nft.imageUrl} alt={nft.name} className="w-14 h-14 rounded-lg object-cover" />
          )}
          <div>
            <h4 className="text-white font-semibold text-sm">{nft.name}</h4>
            <p className="text-[#FFD700] font-bold">${nft.priceUSD.toFixed(2)}</p>
            <p className="text-gray-400 text-xs">{available}% available</p>
          </div>
        </div>
      </div>

      {step === "select" && (
        <>
          <div className="mb-4">
            <label className="text-gray-400 text-xs mb-1 block">Shares to Buy (1% each)</label>
            <div className="flex items-center gap-3">
              <input type="range" min={1} max={Math.min(available, 100)} value={shares}
                onChange={(e) => setShares(parseInt(e.target.value))}
                className="flex-1 accent-[#FFD700]" data-testid="input-shares-slider" />
              <span className="text-white font-bold text-lg w-12 text-center">{shares}%</span>
            </div>
          </div>

          <div className="bg-[#0D1117] rounded-xl p-3 mb-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Price per share</span>
              <span className="text-white">${pricePerShare.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Shares</span>
              <span className="text-white">{shares}%</span>
            </div>
            <div className="border-t border-white/10 pt-2 flex justify-between text-sm font-bold">
              <span className="text-gray-300">Total</span>
              <span className="text-[#FFD700]">${totalCost.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 mb-4">
            <p className="text-yellow-400 text-xs font-medium">P2P Payment Only</p>
            <p className="text-gray-400 text-xs mt-1">You'll send crypto directly to the seller's wallet. No money goes through the platform.</p>
          </div>

          {fractionData && fractionData.fractions.length > 0 && (
            <div className="mb-4">
              <h4 className="text-gray-400 text-xs mb-2">Current Owners</h4>
              <div className="space-y-1">
                {fractionData.fractions.slice(0, 5).map((f: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs">
                    <span className="text-gray-400">Owner {i + 1}</span>
                    <span className="text-white">{f.shares}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Button onClick={() => setStep("pay")}
            disabled={!user || shares > available}
            className="w-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold hover:opacity-90"
            data-testid="btn-buy-fraction">
            Continue to Payment — ${totalCost.toFixed(2)}
          </Button>
        </>
      )}

      {step === "pay" && (
        <>
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-4 space-y-3">
            <p className="text-blue-400 text-sm font-bold">Step 1: Send Crypto to Seller</p>
            <div className="bg-[#0D1117] rounded-lg p-3">
              <p className="text-gray-400 text-xs mb-1">Seller's {chainInfo.name} Wallet</p>
              <p className="text-white text-xs font-mono break-all select-all">{sellerWallet}</p>
            </div>
            <p className="text-gray-400 text-xs">
              Send <span className="text-[#FFD700] font-bold">${totalCost.toFixed(2)}</span> worth of {chainInfo.name} using {chainInfo.walletApp}
            </p>
          </div>

          <div className="mb-4">
            <p className="text-blue-400 text-sm font-bold mb-2">Step 2: Paste Transaction Hash</p>
            <input
              type="text"
              value={transactionHash}
              onChange={(e) => setTransactionHash(e.target.value)}
              placeholder="Enter transaction hash..."
              className="w-full bg-[#0D1117] text-white border border-white/20 rounded-lg px-3 py-2 text-sm font-mono focus:border-[#FFD700]/50 focus:outline-none"
              data-testid="input-fraction-tx-hash"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={() => setStep("select")} variant="outline"
              className="flex-1 border-white/20 text-gray-300 hover:bg-white/5">
              Back
            </Button>
            <Button onClick={() => buyFraction.mutate({ nftId: nft.id, shares, pricePerShare, transactionHash })}
              disabled={!transactionHash || transactionHash.length < 10 || buyFraction.isPending}
              className="flex-1 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold hover:opacity-90"
              data-testid="btn-confirm-fraction">
              {buyFraction.isPending ? "Processing..." : "Confirm Purchase"}
            </Button>
          </div>
        </>
      )}
    </motion.div>
  );
}

const BLOCKCHAIN_DETAILS: Record<string, { name: string; walletApp: string; networkName: string; scanUrl: string }> = {
  eth: { name: "Ethereum", walletApp: "MetaMask, Trust Wallet, or Coinbase Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  bnbbsc: { name: "BNB Smart Chain", walletApp: "MetaMask (BSC network), Trust Wallet", networkName: "BNB Smart Chain", scanUrl: "https://bscscan.com/tx/" },
  matic: { name: "Polygon", walletApp: "MetaMask (Polygon network), Trust Wallet", networkName: "Polygon Mainnet", scanUrl: "https://polygonscan.com/tx/" },
  avax: { name: "Avalanche", walletApp: "MetaMask (Avalanche network), Core Wallet", networkName: "Avalanche C-Chain", scanUrl: "https://snowtrace.io/tx/" },
  sol: { name: "Solana", walletApp: "Phantom, Solflare, or Backpack", networkName: "Solana Mainnet", scanUrl: "https://solscan.io/tx/" },
  arb: { name: "Arbitrum", walletApp: "MetaMask (Arbitrum network)", networkName: "Arbitrum One", scanUrl: "https://arbiscan.io/tx/" },
  op: { name: "Optimism", walletApp: "MetaMask (Optimism network)", networkName: "Optimism Mainnet", scanUrl: "https://optimistic.etherscan.io/tx/" },
  base: { name: "Base", walletApp: "MetaMask (Base network), Coinbase Wallet", networkName: "Base Mainnet", scanUrl: "https://basescan.org/tx/" },
  btc: { name: "Bitcoin", walletApp: "Xverse, Leather, or UniSat", networkName: "Bitcoin Mainnet", scanUrl: "https://mempool.space/tx/" },
  ada: { name: "Cardano", walletApp: "Nami, Eternl, or Yoroi", networkName: "Cardano Mainnet", scanUrl: "https://cardanoscan.io/transaction/" },
  dot: { name: "Polkadot", walletApp: "Polkadot.js, SubWallet", networkName: "Polkadot Relay Chain", scanUrl: "https://polkadot.subscan.io/extrinsic/" },
  trx: { name: "TRON", walletApp: "TronLink or Trust Wallet", networkName: "TRON Mainnet", scanUrl: "https://tronscan.org/#/transaction/" },
  ltc: { name: "Litecoin", walletApp: "Litewallet or Trust Wallet", networkName: "Litecoin Mainnet", scanUrl: "https://blockchair.com/litecoin/transaction/" },
  xrp: { name: "XRP", walletApp: "Xumm or Trust Wallet", networkName: "XRP Ledger", scanUrl: "https://xrpscan.com/tx/" },
  doge: { name: "Dogecoin", walletApp: "Dogecoin Core or Trust Wallet", networkName: "Dogecoin Mainnet", scanUrl: "https://blockchair.com/dogecoin/transaction/" },
  near: { name: "NEAR Protocol", walletApp: "NEAR Wallet or MyNearWallet", networkName: "NEAR Mainnet", scanUrl: "https://nearblocks.io/txns/" },
  atom: { name: "Cosmos", walletApp: "Keplr or Cosmostation", networkName: "Cosmos Hub", scanUrl: "https://www.mintscan.io/cosmos/txs/" },
  ftm: { name: "Fantom", walletApp: "MetaMask (Fantom network)", networkName: "Fantom Opera", scanUrl: "https://ftmscan.com/tx/" },
  algo: { name: "Algorand", walletApp: "Pera Wallet or Defly", networkName: "Algorand Mainnet", scanUrl: "https://algoexplorer.io/tx/" },
  hbar: { name: "Hedera", walletApp: "HashPack or Blade", networkName: "Hedera Mainnet", scanUrl: "https://hashscan.io/mainnet/transaction/" },
  apt: { name: "Aptos", walletApp: "Petra or Pontem", networkName: "Aptos Mainnet", scanUrl: "https://explorer.aptoslabs.com/txn/" },
  sui: { name: "Sui", walletApp: "Sui Wallet or Suiet", networkName: "Sui Mainnet", scanUrl: "https://suiscan.xyz/mainnet/tx/" },
  zksync: { name: "zkSync Era", walletApp: "MetaMask (zkSync network)", networkName: "zkSync Era Mainnet", scanUrl: "https://explorer.zksync.io/tx/" },
  ton: { name: "TON", walletApp: "Tonkeeper or MyTonWallet", networkName: "TON Mainnet", scanUrl: "https://tonscan.org/tx/" },
  kas: { name: "Kaspa", walletApp: "Kaspa Web Wallet", networkName: "Kaspa Mainnet", scanUrl: "https://explorer.kaspa.org/txs/" },
  sei: { name: "Sei", walletApp: "Compass Wallet", networkName: "Sei Mainnet", scanUrl: "https://www.seiscan.app/pacific-1/txs/" },
  usdttrc20: { name: "USDT (TRC20)", walletApp: "TronLink or Trust Wallet", networkName: "TRON Mainnet", scanUrl: "https://tronscan.org/#/transaction/" },
  usdterc20: { name: "USDT (ERC20)", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  usdc: { name: "USD Coin (ERC20)", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  usdcsol: { name: "USDC (Solana)", walletApp: "Phantom, Solflare", networkName: "Solana Mainnet", scanUrl: "https://solscan.io/tx/" },
  shib: { name: "Shiba Inu", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  link: { name: "Chainlink", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  uni: { name: "Uniswap", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  pepe: { name: "Pepe", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
  bonk: { name: "Bonk", walletApp: "Phantom, Solflare", networkName: "Solana Mainnet", scanUrl: "https://solscan.io/tx/" },
  wif: { name: "dogwifhat", walletApp: "Phantom, Solflare", networkName: "Solana Mainnet", scanUrl: "https://solscan.io/tx/" },
  floki: { name: "Floki", walletApp: "MetaMask, Trust Wallet", networkName: "Ethereum Mainnet", scanUrl: "https://etherscan.io/tx/" },
};

export function P2PBuyModal({ nft, onClose }: { nft: NFT; onClose: () => void }) {
  const [buyerWallet, setBuyerWallet] = useState("");
  const [selectedCrypto, setSelectedCrypto] = useState<string>("");
  const [invoiceData, setInvoiceData] = useState<any>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const checkoutMutation = useNFTCheckoutNowPayments();
  const { data: paymentStatus } = useNFTPaymentStatus(orderId);
  const { user } = useAuth();
  const { data: platformWallets } = usePlatformWallets();
  const queryClient = useQueryClient();

  const isPlatformNFT = nft.creatorId === "system" || nft.creatorUsername === "AlphaGenesis";
  const payoutCrypto = isPlatformNFT ? (selectedCrypto || "") : (nft.payoutCurrency || nft.blockchain || "eth");
  const chain = payoutCrypto;
  const chainInfo = BLOCKCHAIN_DETAILS[chain] || BLOCKCHAIN_DETAILS[nft.blockchain || "eth"] || BLOCKCHAIN_DETAILS.eth;
  const priceUSD = nft.listPriceUSD || nft.priceUSD;
  const feeAmount = (priceUSD * 0.005).toFixed(2);
  const sellerReceives = (priceUSD - parseFloat(feeAmount)).toFixed(2);

  useEffect(() => {
    if (paymentStatus?.status === "completed") {
      queryClient.invalidateQueries({ queryKey: ["/api/nfts/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/nfts/owned"] });
      queryClient.invalidateQueries({ queryKey: ["/api/nfts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/xp"] });
    }
  }, [paymentStatus?.status, queryClient]);

  const handleCheckout = () => {
    if (!selectedCrypto && isPlatformNFT) return;
    const payCurrency = isPlatformNFT ? selectedCrypto : payoutCrypto;
    checkoutMutation.mutate({
      nftId: nft.id,
      payCurrency,
      buyerWallet: buyerWallet || undefined,
    }, {
      onSuccess: (data: any) => {
        setInvoiceData(data);
        setOrderId(data.orderId);
      },
    });
  };

  const isCompleted = paymentStatus?.status === "completed";

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
      className="bg-[#161B22] rounded-2xl border border-[#00D4FF]/20 p-6 max-w-lg w-full relative max-h-[90vh] overflow-y-auto"
      data-testid="p2p-buy-modal">
      <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-white z-10">✕</button>

      {isCompleted ? (
        <div className="text-center">
          <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h3 className="text-white font-bold text-lg mb-2">Purchase Complete!</h3>
          <p className="text-gray-400 text-sm mb-4">Payment confirmed. NFT ownership has been transferred to your account.</p>
          <Button onClick={onClose} className="bg-[#21262D] text-white hover:bg-[#2D333B]">
            Close
          </Button>
        </div>
      ) : invoiceData ? (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-5 h-5 text-[#FFD700]" />
            <h3 className="text-white font-bold text-lg">Complete Payment</h3>
          </div>

          <div className="bg-[#21262D] rounded-xl p-4">
            <h4 className="text-white font-semibold mb-2">{nft.name}</h4>
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Price</span>
                <span className="text-white font-semibold">${priceUSD.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Send</span>
                <span className="text-[#00D4FF] font-semibold">{invoiceData.payAmount} {invoiceData.payCurrency}</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0D1117] rounded-xl p-4 border border-[#00D4FF]/20">
            <p className="text-gray-400 text-xs mb-3">Click below to complete your payment securely through NOWPayments:</p>
            <a href={invoiceData.invoiceUrl} target="_blank" rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold rounded-lg py-3 hover:opacity-90 transition-opacity"
              data-testid="link-nowpayments-invoice">
              <ExternalLink className="w-4 h-4" /> Pay with NOWPayments
            </a>
          </div>

          <div className="bg-[#0D1117]/60 rounded-lg p-3 flex items-center gap-2">
            <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
            <p className="text-gray-400 text-xs">Waiting for payment confirmation... This page will update automatically.</p>
          </div>

          <div className="bg-[#0D1117] rounded-xl p-3 border border-[#FFD700]/20">
            <div className="flex items-start gap-2">
              <Percent className="w-4 h-4 text-[#FFD700] flex-shrink-0 mt-0.5" />
              <p className="text-gray-400 text-xs leading-relaxed">
                <span className="text-[#FFD700] font-semibold">Transaction Fee Notice:</span> A 0.5% transaction fee (${feeAmount}) is applied by <span className="text-white font-medium">NOWPayments</span> (the third-party payment processor) and deducted from the total amount received by the seller. This fee is <span className="text-white font-medium">NOT</span> charged by Alpha Unlimited Trading.
              </p>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-2 mb-4">
            <Wallet className="w-5 h-5 text-[#FFD700]" />
            <h3 className="text-white font-bold text-lg">Buy with Crypto</h3>
          </div>

          <div className="bg-[#21262D] rounded-xl p-4 mb-4">
            <div className="flex items-center gap-3">
              {nft.imageUrl && <img src={nft.imageUrl} alt={nft.name} className="w-14 h-14 rounded-lg object-cover" />}
              <div className="flex-1">
                <h4 className="text-white font-semibold">{nft.name}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[#FFD700] font-bold text-lg">${priceUSD.toFixed(2)}</span>
                  {!isPlatformNFT && (
                    <span className="text-gray-500 text-xs bg-[#0D1117] px-2 py-0.5 rounded">{chainInfo.name}</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0D1117] rounded-xl p-4 mb-4 border border-[#FFD700]/20">
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-[#00D4FF] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[#00D4FF] text-xs font-semibold mb-1">Secure Payment via NOWPayments</p>
                <p className="text-gray-400 text-xs">
                  Payments are processed securely through NOWPayments. Select your preferred cryptocurrency and you'll be redirected to complete payment.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3 mb-4">
            <div className="rounded-xl p-4 border bg-[#21262D] border-[#00D4FF]/30">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#00D4FF] text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">1</span>
                <span className="text-white text-sm font-semibold">Choose your payment crypto</span>
              </div>
              <div className="ml-7 grid grid-cols-3 gap-2">
                {(isPlatformNFT ? platformWallets : [
                  { id: nft.payoutCurrency || nft.blockchain || "eth", symbol: chainInfo.name, name: chainInfo.name, icon: "" }
                ])?.map(crypto => (
                  <button
                    key={crypto.id}
                    onClick={() => setSelectedCrypto(crypto.id)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border transition-all text-left ${
                      selectedCrypto === crypto.id
                        ? 'bg-[#FFD700]/10 border-[#FFD700]/50 ring-1 ring-[#FFD700]/30'
                        : 'bg-[#0D1117] border-white/10 hover:border-[#FFD700]/30 hover:bg-[#0D1117]/80'
                    }`}
                    data-testid={`crypto-select-${crypto.symbol.toLowerCase()}`}
                  >
                    <span className="text-lg">{crypto.icon}</span>
                    <div className="min-w-0">
                      <p className={`text-xs font-bold truncate ${selectedCrypto === crypto.id ? 'text-[#FFD700]' : 'text-white'}`}>{crypto.symbol}</p>
                      <p className="text-[10px] text-gray-500 truncate">{crypto.name}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl p-4 border bg-[#21262D] border-[#00D4FF]/30">
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-[#00D4FF] text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">2</span>
                <span className="text-white text-sm font-semibold">Your wallet address (optional)</span>
              </div>
              <div className="ml-7">
                <input value={buyerWallet} onChange={(e) => setBuyerWallet(e.target.value)}
                  placeholder="Your wallet address for records" data-testid="input-buyer-wallet"
                  className="w-full bg-[#0D1117] border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-[#00D4FF]/50" />
              </div>
            </div>
          </div>

          <div className="bg-[#0D1117] rounded-xl p-3 mb-4 border border-[#FFD700]/20">
            <div className="flex items-start gap-2">
              <Percent className="w-4 h-4 text-[#FFD700] flex-shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed">
                <p className="text-[#FFD700] font-semibold mb-1">Transaction Fee Disclosure</p>
                <p className="text-gray-400">
                  A <span className="text-white font-medium">0.5% transaction fee</span> (approx. ${feeAmount}) is applied by <span className="text-white font-medium">NOWPayments</span>, the third-party payment processor, and is deducted from the amount received by the seller. The seller will receive approximately <span className="text-green-400 font-medium">${sellerReceives}</span>. This fee is <span className="text-white font-medium">NOT</span> charged by Alpha Unlimited Trading.
                </p>
              </div>
            </div>
          </div>

          <Button onClick={handleCheckout}
            disabled={!user || !selectedCrypto || checkoutMutation.isPending}
            className="w-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold py-5 hover:opacity-90"
            data-testid="btn-confirm-p2p">
            {checkoutMutation.isPending ? "Creating Payment..." : `Proceed to Payment`}
          </Button>
          {checkoutMutation.isError && (
            <p className="text-red-400 text-xs text-center mt-2">{(checkoutMutation.error as any)?.message || "Failed to create payment"}</p>
          )}

          <p className="text-gray-500 text-[10px] text-center mt-3 leading-relaxed">
            By proceeding, you acknowledge the 0.5% transaction fee charged by NOWPayments (not Alpha Unlimited Trading) will be deducted from the seller's received amount. See our <a href="/disclaimer" className="text-[#00D4FF] hover:underline">Disclaimer</a> for full details.
          </p>
        </>
      )}
    </motion.div>
  );
}

export function DEXProtocolsSection() {
  const { data: protocols, isLoading } = useDexProtocols();

  const protocolMeta: Record<string, { emoji: string; desc: string; chains: string[]; fee: string }> = {
    uniswap: { emoji: "🦄", desc: "Leading Ethereum DEX with automated liquidity", chains: ["Ethereum", "Polygon", "Arbitrum", "Optimism"], fee: "0.3%" },
    jupiter: { emoji: "🪐", desc: "Best swap aggregator on Solana", chains: ["Solana"], fee: "0.1%" },
    raydium: { emoji: "⚡", desc: "Hybrid AMM on Solana with order book", chains: ["Solana"], fee: "0.25%" },
    pancakeswap: { emoji: "🥞", desc: "Top DEX on BNB Chain", chains: ["BNB Chain", "Ethereum", "Aptos"], fee: "0.25%" },
    sushiswap: { emoji: "🍣", desc: "Multi-chain DEX with yield farming", chains: ["Ethereum", "Polygon", "Arbitrum"], fee: "0.3%" },
    curve: { emoji: "📈", desc: "Optimized for stablecoin swaps", chains: ["Ethereum", "Polygon", "Avalanche"], fee: "0.04%" },
    "1inch": { emoji: "🔮", desc: "DEX aggregator finding best rates", chains: ["Ethereum", "BSC", "Polygon", "Arbitrum"], fee: "Variable" },
    orca: { emoji: "🐋", desc: "User-friendly Solana DEX", chains: ["Solana"], fee: "0.2%" },
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-[#161B22] to-[#0D1117] rounded-2xl border border-white/10 p-6"
      data-testid="dex-protocols-section">
      <div className="flex items-center gap-2 mb-6">
        <Globe className="w-5 h-5 text-[#00D4FF]" />
        <h3 className="text-white font-bold text-lg">DEX Protocol Integration</h3>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-[#21262D] rounded-xl p-4 animate-pulse h-28" />
          ))
        ) : (
          protocols?.map((protocol: any) => {
            const meta = protocolMeta[protocol.id] || { emoji: "🔗", desc: "Decentralized exchange", chains: [protocol.chain], fee: "0.3%" };
            return (
              <motion.div key={protocol.id} whileHover={{ scale: 1.02 }}
                className="bg-[#21262D] rounded-xl p-4 border border-white/5 hover:border-[#00D4FF]/30 transition-all"
                data-testid={`dex-protocol-${protocol.id}`}>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl">{meta.emoji}</span>
                  <div>
                    <h4 className="text-white font-semibold text-sm">{protocol.name}</h4>
                    <div className="flex items-center gap-1 flex-wrap">
                      {meta.chains.slice(0, 3).map((chain: string) => (
                        <span key={chain} className="text-[10px] bg-[#0D1117] text-gray-400 px-1.5 py-0.5 rounded">
                          {chain}
                        </span>
                      ))}
                      {meta.chains.length > 3 && (
                        <span className="text-[10px] text-gray-500">+{meta.chains.length - 3}</span>
                      )}
                    </div>
                  </div>
                </div>
                <p className="text-gray-400 text-xs mb-2">{meta.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400">
                    Active
                  </span>
                  <span className="text-gray-500 text-xs">Fee: {meta.fee}</span>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </motion.div>
  );
}

export function UserFractionsPanel() {
  const { data: fractions, isLoading } = useUserFractions();
  const { user } = useAuth();

  if (!user) return null;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-[#161B22] to-[#0D1117] rounded-2xl border border-white/10 p-6"
      data-testid="user-fractions-panel">
      <div className="flex items-center gap-2 mb-4">
        <PieChart className="w-5 h-5 text-[#FFD700]" />
        <h3 className="text-white font-bold text-lg">My Fractional Shares</h3>
      </div>

      {isLoading ? (
        <div className="text-center py-4 text-gray-400">Loading...</div>
      ) : !fractions?.length ? (
        <div className="text-center py-6">
          <PieChart className="w-10 h-10 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No fractional shares yet.</p>
          <p className="text-gray-500 text-xs">Buy partial ownership of high-value NFTs</p>
        </div>
      ) : (
        <div className="space-y-2">
          {fractions.map((f: any, i: number) => (
            <div key={i} className="bg-[#21262D] rounded-xl p-3 flex items-center justify-between border border-white/5">
              <div>
                <p className="text-white text-sm font-semibold">NFT #{f.nftId}</p>
                <p className="text-gray-400 text-xs">{f.shares}% ownership</p>
              </div>
              <div className="text-right">
                <p className="text-[#FFD700] text-sm font-bold">${Number(f.purchasePriceUSD).toFixed(2)}</p>
                <p className="text-gray-500 text-xs">{new Date(f.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}