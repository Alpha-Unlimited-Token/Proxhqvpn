/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Trading Platform Navigation™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Platform Navigation System™
 * - Technology Registry Display™
 * - Ecosystem Map™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_da3f6dd7d4c9726f0b1a7eda
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { Twitter, Mail, ExternalLink, Shield, Award } from "lucide-react";
import { Link } from "wouter";
import tradingLogo from "@/assets/logos/trading-logo.png";

export function TradingPlatformFooter() {
  return (
    <>
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8" data-testid="hiring-section">
      <Link href="/careers">
        <div className="relative w-full rounded-2xl overflow-hidden cursor-pointer group border border-purple-800/20 hover:border-purple-600/40 transition-all" data-testid="img-footer-hacker-banner">
          <img
            src="/assets/phoenix/alpha-phoenix-hacker-v4.png"
            alt="Alpha Phoenix Hacker"
            className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D1117] via-transparent to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
            <h4 className="text-xl sm:text-2xl font-bold text-white mb-2" data-testid="text-footer-hiring">
              We're Hiring — <span className="text-[#00D4FF]">Extraordinary Minds Wanted</span>
            </h4>
            <p className="text-[#c0c8d0] text-sm max-w-2xl mb-4">
              Engineers, hackers, traders, and visionaries — your background doesn't matter, your potential does.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-4 py-2 bg-purple-600/40 border border-purple-500/30 text-purple-200 text-xs sm:text-sm font-medium rounded-full backdrop-blur-sm">Hackers & Security</span>
              <span className="px-4 py-2 bg-cyan-600/40 border border-cyan-500/30 text-cyan-200 text-xs sm:text-sm font-medium rounded-full backdrop-blur-sm">Engineers & Devs</span>
              <span className="px-4 py-2 bg-blue-600/40 border border-blue-500/30 text-blue-200 text-xs sm:text-sm font-medium rounded-full backdrop-blur-sm">Forensic Analysts</span>
              <span className="px-4 py-2 bg-green-600/40 border border-green-500/30 text-green-200 text-xs sm:text-sm font-medium rounded-full backdrop-blur-sm">All 12 Roles →</span>
            </div>
          </div>
        </div>
      </Link>
    </section>
    <footer className="tp-footer" data-testid="trading-platform-footer">
      <div aria-hidden="true" style={{position:'absolute',width:1,height:1,overflow:'hidden',clip:'rect(0,0,0,0)',whiteSpace:'nowrap'}}>
        © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
        Alpha Autonomous Command Center™, Bridge Fusion™, QMGE™, ACM™, QFRM™ are proprietary technologies.
        Patent Pending. Unauthorized reproduction prohibited. CONTAINS TRADE SECRETS.
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-8">

          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <img src={tradingLogo} alt="Alpha Trading" className="w-8 h-8 object-contain" style={{ width: '2rem', height: '2rem', maxWidth: '2rem', maxHeight: '2rem' }} />
              <span className="text-lg font-bold text-white">
                ALPHA<span className="text-[#00D4FF]">TRADING</span>
              </span>
            </div>
            <p className="text-[#94A3B8] text-xs leading-relaxed mb-4">
              Professional-grade trading tools for the modern crypto trader.
            </p>
            <div className="flex gap-2">
              <a
                href="https://x.com/AlphaUnlimitedT"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#1A2942] flex items-center justify-center text-[#94A3B8] hover:text-[#00D4FF] hover:bg-[#223350] transition-all"
                data-testid="link-twitter"
              >
                <Twitter size={16} />
              </a>
              <a
                href="mailto:contact@alphaunlimitedtrading.com"
                className="w-9 h-9 rounded-lg bg-[#1A2942] flex items-center justify-center text-[#94A3B8] hover:text-[#00D4FF] hover:bg-[#223350] transition-all"
                data-testid="link-email"
              >
                <Mail size={16} />
              </a>
              <a
                href="/"
                className="w-9 h-9 rounded-lg bg-[#1A2942] flex items-center justify-center text-[#94A3B8] hover:text-[#00D4FF] hover:bg-[#223350] transition-all"
                data-testid="link-main-site"
              >
                <ExternalLink size={16} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">Trading</h4>
            <ul className="space-y-2 text-[#94A3B8] text-sm">
              <li>
                <Link href="/terminal">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Terminal</span>
                </Link>
              </li>
              <li>
                <Link href="/arbitrage">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Arbitrage Scanner</span>
                </Link>
              </li>
              <li>
                <Link href="/command-center">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer" data-testid="link-footer-command-center">AACC™ Command Center</span>
                </Link>
              </li>
              <li>
                <Link href="/exchange">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">AUC Exchange</span>
                </Link>
              </li>
              <li>
                <Link href="/news-sentiment">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">AI Sentiment</span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">Tools</h4>
            <ul className="space-y-2 text-[#94A3B8] text-sm">
              <li>
                <Link href="/miner">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Mining Center</span>
                </Link>
              </li>
              <li>
                <Link href="/nft">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">NFT Marketplace</span>
                </Link>
              </li>
              <li>
                <Link href="/software-downloads">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Downloads</span>
                </Link>
              </li>
              <li>
                <Link href="/quantum-shield">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer flex items-center gap-1" data-testid="link-footer-quantum-shield">
                    <Shield size={14} />
                    Quantum Security
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/learning-center">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Learning Center</span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">Platform</h4>
            <ul className="space-y-2 text-[#94A3B8] text-sm">
              <li>
                <Link href="/features">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Features Overview</span>
                </Link>
              </li>
              <li>
                <Link href="/technology">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer">Proprietary Technology</span>
                </Link>
              </li>
              <li>
                <Link href="/security-overview">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer flex items-center gap-1">
                    <Shield size={14} />
                    Security
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/ambassador">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer flex items-center gap-1" data-testid="link-footer-ambassador">
                    <Award size={14} />
                    Ambassador
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="hover:text-[#00D4FF] transition-colors cursor-pointer flex items-center gap-1" data-testid="link-footer-contact">
                    <Mail size={14} />
                    Contact Us
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-3 text-xs uppercase tracking-wider">Company</h4>
            <ul className="space-y-2 text-[#94A3B8] text-sm">
              <li>
                <Link href="/careers">
                  <span className="text-[#00D4FF] hover:underline cursor-pointer">Careers — We're Hiring!</span>
                </Link>
              </li>
              <li>
                <Link href="/copyright">
                  <span className="text-[#FFD700] hover:underline cursor-pointer flex items-center gap-1">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                    Copyright & IP
                  </span>
                </Link>
              </li>
            </ul>
          </div>

        </div>

        <div className="pt-6 border-t border-[#1A2942] flex flex-col md:flex-row justify-between items-center gap-3">
          <p className="text-[#64748B] text-xs sm:text-sm">
            © 2024 and onwards Alpha Unlimited Trading. All rights reserved in perpetuity. AACC™ is proprietary technology.
          </p>
          <p className="text-[#64748B] text-xs sm:text-sm">
            Part of the <Link href="/"><span className="text-[#00D4FF] hover:underline cursor-pointer">Alpha Unlimited</span></Link> ecosystem
          </p>
        </div>
      </div>
    </footer>
    </>
  );
}
