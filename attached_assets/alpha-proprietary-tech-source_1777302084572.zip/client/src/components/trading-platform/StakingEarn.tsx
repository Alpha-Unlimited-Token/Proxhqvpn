/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha StakingEarn™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_1808b17a0cabde9e632983a3
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Coins, TrendingUp, Lock, Unlock, Clock, Shield, Zap, RefreshCw,
  ExternalLink, AlertTriangle, CheckCircle, Star, Search, Filter,
  ArrowUpDown, ChevronDown, ChevronUp, Info, Globe, Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface YieldPool {
  id: string;
  chain: string;
  project: string;
  symbol: string;
  tvlUsd: number;
  apy: number;
  apyBase: number | null;
  apyReward: number | null;
  stablecoin: boolean;
  exposure: string;
  poolMeta: string | null;
  ilRisk: string;
  apyMean30d: number | null;
  volumeUsd7d: number | null;
}

const CHAIN_INFO: Record<string, { icon: string; color: string; name: string; stakingUrl: string }> = {
  Ethereum: { icon: '💎', color: '#627EEA', name: 'Ethereum', stakingUrl: 'https://ethereum.org/staking' },
  Solana: { icon: '☀️', color: '#9945FF', name: 'Solana', stakingUrl: 'https://solana.com/staking' },
  BSC: { icon: '🟡', color: '#F3BA2F', name: 'BNB Chain', stakingUrl: 'https://www.bnbchain.org/en/staking' },
  Avalanche: { icon: '🔺', color: '#E84142', name: 'Avalanche', stakingUrl: 'https://www.avax.network/' },
  Polygon: { icon: '🟣', color: '#8247E5', name: 'Polygon', stakingUrl: 'https://polygon.technology/staking' },
  Arbitrum: { icon: '🔵', color: '#28A0F0', name: 'Arbitrum', stakingUrl: 'https://arbitrum.io/' },
  Optimism: { icon: '🔴', color: '#FF0420', name: 'Optimism', stakingUrl: 'https://www.optimism.io/' },
  Base: { icon: '🔷', color: '#0052FF', name: 'Base', stakingUrl: 'https://base.org/' },
  Sui: { icon: '💧', color: '#4DA2FF', name: 'Sui', stakingUrl: 'https://sui.io/' },
  Aptos: { icon: '🌊', color: '#2DD8A3', name: 'Aptos', stakingUrl: 'https://aptoslabs.com/' },
  Cosmos: { icon: '⚛️', color: '#2E3148', name: 'Cosmos', stakingUrl: 'https://cosmos.network/learn/staking' },
  Near: { icon: '🌐', color: '#00EC97', name: 'NEAR', stakingUrl: 'https://near.org/' },
  Tron: { icon: '⚡', color: '#FF0013', name: 'Tron', stakingUrl: 'https://tronscan.org/' },
  Mantle: { icon: '🟢', color: '#000000', name: 'Mantle', stakingUrl: 'https://www.mantle.xyz/' },
};

const PROJECT_INFO: Record<string, { name: string; url: string; type: string; audited: boolean }> = {
  'lido': { name: 'Lido', url: 'https://lido.fi', type: 'Liquid Staking', audited: true },
  'rocket-pool': { name: 'Rocket Pool', url: 'https://rocketpool.net', type: 'Decentralized Staking', audited: true },
  'aave-v3': { name: 'Aave V3', url: 'https://app.aave.com', type: 'Lending', audited: true },
  'aave-v2': { name: 'Aave V2', url: 'https://app.aave.com', type: 'Lending', audited: true },
  'compound-v3': { name: 'Compound V3', url: 'https://app.compound.finance', type: 'Lending', audited: true },
  'compound-v2': { name: 'Compound V2', url: 'https://app.compound.finance', type: 'Lending', audited: true },
  'maker': { name: 'MakerDAO', url: 'https://makerdao.com', type: 'CDP/Lending', audited: true },
  'curve-dex': { name: 'Curve', url: 'https://curve.fi', type: 'DEX/Yield', audited: true },
  'convex-finance': { name: 'Convex', url: 'https://www.convexfinance.com', type: 'Yield Optimizer', audited: true },
  'eigenlayer': { name: 'EigenLayer', url: 'https://www.eigenlayer.xyz', type: 'Restaking', audited: true },
  'jito': { name: 'Jito', url: 'https://www.jito.network', type: 'Liquid Staking', audited: true },
  'marinade': { name: 'Marinade', url: 'https://marinade.finance', type: 'Liquid Staking', audited: true },
  'binance-staked-eth': { name: 'Binance Staked ETH', url: 'https://www.binance.com/en/eth2', type: 'CEX Staking', audited: true },
  'coinbase-wrapped-staked-eth': { name: 'Coinbase cbETH', url: 'https://www.coinbase.com/cbeth', type: 'CEX Staking', audited: true },
  'spark': { name: 'Spark', url: 'https://spark.fi', type: 'Lending', audited: true },
  'morpho': { name: 'Morpho', url: 'https://morpho.org', type: 'Lending Optimizer', audited: true },
  'pendle': { name: 'Pendle', url: 'https://www.pendle.finance', type: 'Yield Trading', audited: true },
  'gmx': { name: 'GMX', url: 'https://gmx.io', type: 'Perp DEX', audited: true },
  'etherfi': { name: 'Ether.fi', url: 'https://www.ether.fi', type: 'Liquid Restaking', audited: true },
  'renzo': { name: 'Renzo', url: 'https://www.renzoprotocol.com', type: 'Liquid Restaking', audited: true },
  'kelp-dao': { name: 'Kelp DAO', url: 'https://www.kelpdao.xyz', type: 'Liquid Restaking', audited: true },
  'swell': { name: 'Swell', url: 'https://www.swellnetwork.io', type: 'Liquid Staking', audited: true },
  'frax-ether': { name: 'Frax ETH', url: 'https://app.frax.finance/frxeth/mint', type: 'Liquid Staking', audited: true },
  'yearn-finance': { name: 'Yearn', url: 'https://yearn.fi', type: 'Yield Optimizer', audited: true },
  'beefy': { name: 'Beefy', url: 'https://beefy.com', type: 'Yield Optimizer', audited: true },
  'venus-core-pool': { name: 'Venus', url: 'https://venus.io', type: 'Lending', audited: true },
  'jupiter-perps': { name: 'Jupiter Perps', url: 'https://jup.ag', type: 'Perp DEX', audited: true },
  'kamino-lend': { name: 'Kamino', url: 'https://app.kamino.finance', type: 'Lending', audited: true },
  'drift-protocol': { name: 'Drift', url: 'https://www.drift.trade', type: 'Perp DEX', audited: true },
  'raydium': { name: 'Raydium', url: 'https://raydium.io', type: 'DEX/Yield', audited: true },
  'orca': { name: 'Orca', url: 'https://www.orca.so', type: 'DEX', audited: true },
  'aerodrome': { name: 'Aerodrome', url: 'https://aerodrome.finance', type: 'DEX/Yield', audited: true },
  'uniswap-v3': { name: 'Uniswap V3', url: 'https://app.uniswap.org', type: 'DEX', audited: true },
  'pancakeswap-amm-v3': { name: 'PancakeSwap', url: 'https://pancakeswap.finance', type: 'DEX', audited: true },
  'ankr': { name: 'Ankr', url: 'https://www.ankr.com/staking', type: 'Liquid Staking', audited: true },
  'stader': { name: 'Stader', url: 'https://www.staderlabs.com', type: 'Liquid Staking', audited: true },
  'mantle-staked-eth': { name: 'Mantle Staked ETH', url: 'https://www.mantle.xyz/meth', type: 'Liquid Staking', audited: true },
  'stakewise-v3': { name: 'StakeWise', url: 'https://app.stakewise.io', type: 'Liquid Staking', audited: true },
  'origin-ether': { name: 'Origin Ether', url: 'https://www.oeth.com', type: 'Yield Aggregator', audited: true },
  'radiant-v2': { name: 'Radiant V2', url: 'https://radiant.capital', type: 'Lending', audited: true },
  'benqi-staked-avax': { name: 'BENQI', url: 'https://staking.benqi.fi', type: 'Liquid Staking', audited: true },
};

type SortKey = 'apy' | 'tvlUsd' | 'apyMean30d' | 'risk';
type FilterType = 'all' | 'staking' | 'lending' | 'dex' | 'stablecoin';

function getRiskScore(pool: YieldPool): { score: number; label: string; color: string } {
  let score = 0;
  if (pool.tvlUsd > 500_000_000) score += 0;
  else if (pool.tvlUsd > 100_000_000) score += 1;
  else if (pool.tvlUsd > 10_000_000) score += 2;
  else score += 3;

  if (pool.exposure === 'single') score += 0;
  else score += 2;

  if (pool.ilRisk === 'yes') score += 2;
  if (pool.stablecoin) score -= 1;
  if (pool.apy > 50) score += 2;
  else if (pool.apy > 20) score += 1;

  const info = PROJECT_INFO[pool.project];
  if (info?.audited) score -= 1;

  score = Math.max(1, Math.min(10, score));

  if (score <= 3) return { score, label: 'Low', color: 'text-green-400' };
  if (score <= 6) return { score, label: 'Medium', color: 'text-yellow-400' };
  return { score, label: 'High', color: 'text-red-400' };
}

function formatTVL(value: number): string {
  if (value >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(1)}B`;
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(0)}K`;
  return `$${value}`;
}

export function StakingEarn() {
  const [pools, setPools] = useState<YieldPool[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<SortKey>('tvlUsd');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [filter, setFilter] = useState<FilterType>('all');
  const [chainFilter, setChainFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedPool, setExpandedPool] = useState<string | null>(null);
  const [showChainDropdown, setShowChainDropdown] = useState(false);
  const [isStale, setIsStale] = useState(false);
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchYields = useCallback(async () => {
    try {
      const res = await fetch('/api/staking/yields');
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setPools(data.pools || []);
      setLastUpdated(data.updatedAt);
      setIsStale(data.stale || false);
      setError(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchYields();
    refreshTimerRef.current = setInterval(fetchYields, 30_000);
    return () => {
      if (refreshTimerRef.current) clearInterval(refreshTimerRef.current);
    };
  }, [fetchYields]);

  const uniqueChains = Array.from(new Set(pools.map(p => p.chain))).sort();

  const filteredPools = pools
    .filter(p => {
      if (chainFilter !== 'all' && p.chain !== chainFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return p.symbol.toLowerCase().includes(q) || p.project.toLowerCase().includes(q) || p.chain.toLowerCase().includes(q);
      }
      if (filter === 'stablecoin') return p.stablecoin;
      if (filter === 'staking') {
        const info = PROJECT_INFO[p.project];
        return info?.type.toLowerCase().includes('staking') || info?.type.toLowerCase().includes('restaking');
      }
      if (filter === 'lending') {
        const info = PROJECT_INFO[p.project];
        return info?.type.toLowerCase().includes('lend') || info?.type.toLowerCase().includes('cdp');
      }
      if (filter === 'dex') {
        const info = PROJECT_INFO[p.project];
        return info?.type.toLowerCase().includes('dex') || info?.type.toLowerCase().includes('yield');
      }
      return true;
    })
    .sort((a, b) => {
      let valA: number, valB: number;
      if (sortBy === 'risk') {
        valA = getRiskScore(a).score;
        valB = getRiskScore(b).score;
      } else {
        valA = (a as any)[sortBy] ?? 0;
        valB = (b as any)[sortBy] ?? 0;
      }
      return sortDir === 'desc' ? valB - valA : valA - valB;
    });

  const handleSort = (key: SortKey) => {
    if (sortBy === key) setSortDir(d => d === 'desc' ? 'asc' : 'desc');
    else { setSortBy(key); setSortDir('desc'); }
  };

  const topByApy = [...pools].sort((a, b) => b.apy - a.apy).slice(0, 3);
  const topByTvl = [...pools].sort((a, b) => b.tvlUsd - a.tvlUsd).slice(0, 3);
  const topStable = [...pools].filter(p => p.stablecoin).sort((a, b) => b.apy - a.apy).slice(0, 3);

  if (loading) {
    return (
      <div className="space-y-4" data-testid="staking-earn">
        <div className="flex items-center gap-3">
          <Coins className="text-yellow-400 animate-pulse" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Staking & Earn Recommendations</h2>
            <p className="text-xs text-gray-500">Loading live yield data from DeFi protocols...</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[1,2,3].map(i => (
            <div key={i} className="h-20 bg-gray-800/50 rounded-lg animate-pulse" />
          ))}
        </div>
        <div className="space-y-2">
          {[1,2,3,4,5].map(i => (
            <div key={i} className="h-14 bg-gray-800/50 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="staking-earn">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Coins className="text-yellow-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Staking & Earn Recommendations</h2>
            <p className="text-xs text-gray-500">Live yields from {pools.length} pools across DeFi protocols</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isStale && (
            <span className="text-[9px] text-orange-400 flex items-center gap-1">
              <AlertTriangle size={10} /> Cached data
            </span>
          )}
          {lastUpdated && (
            <span className="text-[9px] text-gray-500">
              Updated {new Date(lastUpdated).toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={() => { setLoading(true); fetchYields(); }}
            className="p-1.5 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 transition-colors"
            title="Refresh data"
            data-testid="button-refresh-yields"
          >
            <RefreshCw size={12} className="text-gray-400" />
          </button>
        </div>
      </div>

      <div className="p-3 bg-green-500/5 border border-green-500/20 rounded-lg flex items-start gap-2" data-testid="staking-non-custodial-notice">
        <Shield size={16} className="text-green-400 mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-xs text-green-400 font-semibold">Non-Custodial Recommendations</p>
          <p className="text-[10px] text-gray-400 mt-0.5">
            We show real-time yield data to help you find the best opportunities. When you're ready to stake, you'll go directly to the protocol's website. No funds ever pass through Alpha Unlimited.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center gap-2">
          <AlertTriangle size={16} className="text-red-400" />
          <span className="text-xs text-red-400">{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg">
          <div className="text-[10px] text-gray-400 mb-1 flex items-center gap-1"><TrendingUp size={10} /> Top APY</div>
          {topByApy.map((p, i) => (
            <div key={p.id} className="flex items-center justify-between text-xs py-0.5">
              <span className="text-gray-300 truncate mr-2">{i+1}. {p.symbol}</span>
              <span className="text-green-400 font-bold font-mono">{p.apy}%</span>
            </div>
          ))}
        </div>
        <div className="p-3 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-lg">
          <div className="text-[10px] text-gray-400 mb-1 flex items-center gap-1"><Shield size={10} /> Highest TVL</div>
          {topByTvl.map((p, i) => (
            <div key={p.id} className="flex items-center justify-between text-xs py-0.5">
              <span className="text-gray-300 truncate mr-2">{i+1}. {p.symbol}</span>
              <span className="text-blue-400 font-bold font-mono">{formatTVL(p.tvlUsd)}</span>
            </div>
          ))}
        </div>
        <div className="p-3 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg">
          <div className="text-[10px] text-gray-400 mb-1 flex items-center gap-1"><Coins size={10} /> Best Stablecoin</div>
          {topStable.length > 0 ? topStable.map((p, i) => (
            <div key={p.id} className="flex items-center justify-between text-xs py-0.5">
              <span className="text-gray-300 truncate mr-2">{i+1}. {p.symbol}</span>
              <span className="text-yellow-400 font-bold font-mono">{p.apy}%</span>
            </div>
          )) : <span className="text-[10px] text-gray-500">No stablecoin pools found</span>}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search token, protocol, or chain..."
            className="w-full pl-8 pr-3 py-1.5 bg-gray-800 border border-gray-700 rounded text-xs text-white placeholder-gray-500"
            data-testid="input-search-yields"
          />
        </div>

        <div className="flex gap-1">
          {([
            { key: 'all', label: 'All' },
            { key: 'staking', label: 'Staking' },
            { key: 'lending', label: 'Lending' },
            { key: 'dex', label: 'DEX/LP' },
            { key: 'stablecoin', label: 'Stablecoin' },
          ] as const).map(f => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-2.5 py-1 rounded text-[10px] font-medium transition-colors ${
                filter === f.key
                  ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50'
                  : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-gray-600'
              }`}
              data-testid={`button-filter-${f.key}`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="relative">
          <button
            onClick={() => setShowChainDropdown(!showChainDropdown)}
            className="flex items-center gap-1 px-2.5 py-1 bg-gray-800 border border-gray-700 rounded text-[10px] text-gray-400 hover:border-gray-600"
            data-testid="button-chain-filter"
          >
            <Globe size={10} />
            {chainFilter === 'all' ? 'All Chains' : chainFilter}
            <ChevronDown size={10} />
          </button>
          {showChainDropdown && (
            <div className="absolute right-0 top-full mt-1 bg-gray-900 border border-gray-700 rounded-lg shadow-xl z-50 max-h-48 overflow-y-auto w-40">
              <button
                onClick={() => { setChainFilter('all'); setShowChainDropdown(false); }}
                className={`w-full text-left px-3 py-1.5 text-xs hover:bg-gray-800 ${chainFilter === 'all' ? 'text-yellow-400' : 'text-gray-300'}`}
                data-testid="button-chain-all"
              >
                All Chains
              </button>
              {uniqueChains.map(chain => (
                <button
                  key={chain}
                  onClick={() => { setChainFilter(chain); setShowChainDropdown(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs hover:bg-gray-800 flex items-center gap-1.5 ${chainFilter === chain ? 'text-yellow-400' : 'text-gray-300'}`}
                  data-testid={`button-chain-${chain.toLowerCase()}`}
                >
                  <span>{CHAIN_INFO[chain]?.icon || '🔗'}</span>
                  {chain}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="text-xs text-gray-500 flex items-center justify-between">
        <span>{filteredPools.length} pool{filteredPools.length !== 1 ? 's' : ''} found</span>
        <span className="text-[9px] flex items-center gap-1">
          <RefreshCw size={8} className="animate-spin" style={{ animationDuration: '3s' }} /> Auto-refreshes every 30s
        </span>
      </div>

      <div className="bg-gray-900/30 border border-gray-800 rounded-lg overflow-hidden">
        <div className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr_80px] gap-1 px-3 py-2 bg-gray-800/50 border-b border-gray-700 text-[10px] text-gray-400 font-medium">
          <span>Pool / Protocol</span>
          <button onClick={() => handleSort('apy')} className="flex items-center gap-0.5 hover:text-white transition-colors" data-testid="sort-apy">
            APY <ArrowUpDown size={8} className={sortBy === 'apy' ? 'text-yellow-400' : ''} />
          </button>
          <button onClick={() => handleSort('apyMean30d')} className="flex items-center gap-0.5 hover:text-white transition-colors" data-testid="sort-30d">
            30d Avg <ArrowUpDown size={8} className={sortBy === 'apyMean30d' ? 'text-yellow-400' : ''} />
          </button>
          <button onClick={() => handleSort('tvlUsd')} className="flex items-center gap-0.5 hover:text-white transition-colors" data-testid="sort-tvl">
            TVL <ArrowUpDown size={8} className={sortBy === 'tvlUsd' ? 'text-yellow-400' : ''} />
          </button>
          <button onClick={() => handleSort('risk')} className="flex items-center gap-0.5 hover:text-white transition-colors" data-testid="sort-risk">
            Risk <ArrowUpDown size={8} className={sortBy === 'risk' ? 'text-yellow-400' : ''} />
          </button>
          <span className="text-center">Action</span>
        </div>

        <div className="max-h-[400px] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
          <AnimatePresence>
            {filteredPools.map((pool, i) => {
              const risk = getRiskScore(pool);
              const projectInfo = PROJECT_INFO[pool.project];
              const chainInfo = CHAIN_INFO[pool.chain];
              const isExpanded = expandedPool === pool.id;

              return (
                <motion.div
                  key={pool.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: Math.min(i * 0.02, 0.5) }}
                  className="border-b border-gray-800/50 last:border-b-0"
                >
                  <div
                    className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr_80px] gap-1 px-3 py-2 hover:bg-gray-800/30 cursor-pointer transition-colors items-center"
                    onClick={() => setExpandedPool(isExpanded ? null : pool.id)}
                    data-testid={`pool-row-${pool.id}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-sm flex-shrink-0">{chainInfo?.icon || '🔗'}</span>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white truncate">{pool.symbol}</div>
                        <div className="text-[9px] text-gray-500 truncate flex items-center gap-1">
                          {projectInfo?.name || pool.project}
                          <span className="text-gray-600">•</span>
                          {pool.chain}
                          {projectInfo?.audited && <CheckCircle size={8} className="text-green-500 flex-shrink-0" />}
                        </div>
                      </div>
                    </div>

                    <div>
                      <span className={`text-xs font-bold font-mono ${pool.apy > 10 ? 'text-green-400' : pool.apy > 5 ? 'text-yellow-400' : 'text-gray-300'}`}>
                        {pool.apy}%
                      </span>
                      {pool.apyReward && pool.apyReward > 0 && (
                        <div className="text-[8px] text-purple-400">+{pool.apyReward}% rewards</div>
                      )}
                    </div>

                    <div className="text-xs text-gray-400 font-mono">
                      {pool.apyMean30d ? `${pool.apyMean30d}%` : '—'}
                    </div>

                    <div className="text-xs text-gray-300 font-mono">{formatTVL(pool.tvlUsd)}</div>

                    <div className="flex items-center gap-1">
                      <div className={`w-1.5 h-1.5 rounded-full ${risk.label === 'Low' ? 'bg-green-400' : risk.label === 'Medium' ? 'bg-yellow-400' : 'bg-red-400'}`} />
                      <span className={`text-[10px] ${risk.color}`}>{risk.label}</span>
                    </div>

                    <div className="flex justify-center">
                      {projectInfo?.url ? (
                        <a
                          href={projectInfo.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={e => e.stopPropagation()}
                          className="flex items-center gap-1 px-2 py-1 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 text-[10px] font-medium rounded border border-yellow-500/30 transition-colors"
                          data-testid={`button-stake-${pool.id}`}
                        >
                          Stake <ExternalLink size={8} />
                        </a>
                      ) : (
                        <span className="text-[10px] text-gray-600">—</span>
                      )}
                    </div>
                  </div>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-3 pb-3 pt-1 bg-gray-800/20 border-t border-gray-800/50">
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            <div>
                              <div className="text-[9px] text-gray-500 mb-0.5">Protocol</div>
                              <div className="text-xs text-white">{projectInfo?.name || pool.project}</div>
                              <div className="text-[9px] text-gray-400">{projectInfo?.type || 'DeFi'}</div>
                            </div>
                            <div>
                              <div className="text-[9px] text-gray-500 mb-0.5">Chain</div>
                              <div className="text-xs text-white flex items-center gap-1">
                                {chainInfo?.icon} {chainInfo?.name || pool.chain}
                              </div>
                            </div>
                            <div>
                              <div className="text-[9px] text-gray-500 mb-0.5">APY Breakdown</div>
                              <div className="text-xs">
                                {pool.apyBase !== null && <span className="text-gray-300">Base: {pool.apyBase}%</span>}
                                {pool.apyReward !== null && <span className="text-purple-400 ml-2">Reward: {pool.apyReward}%</span>}
                              </div>
                            </div>
                            <div>
                              <div className="text-[9px] text-gray-500 mb-0.5">Risk Assessment</div>
                              <div className="flex items-center gap-1">
                                <div className="flex gap-0.5">
                                  {Array.from({ length: 10 }).map((_, j) => (
                                    <div key={j} className={`w-1.5 h-3 rounded-sm ${j < risk.score ? (risk.label === 'Low' ? 'bg-green-400' : risk.label === 'Medium' ? 'bg-yellow-400' : 'bg-red-400') : 'bg-gray-700'}`} />
                                  ))}
                                </div>
                                <span className={`text-[10px] ml-1 ${risk.color}`}>{risk.score}/10</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 mt-3 pt-2 border-t border-gray-800/50">
                            <div className="flex items-center gap-1 flex-wrap text-[9px]">
                              {pool.stablecoin && <span className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 rounded">Stablecoin</span>}
                              {pool.exposure === 'single' && <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 rounded">Single Asset</span>}
                              {pool.exposure === 'multi' && <span className="px-1.5 py-0.5 bg-orange-500/20 text-orange-400 rounded">Multi Asset</span>}
                              {pool.ilRisk === 'yes' && <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 rounded flex items-center gap-0.5"><AlertTriangle size={7} /> IL Risk</span>}
                              {projectInfo?.audited && <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 rounded flex items-center gap-0.5"><CheckCircle size={7} /> Audited</span>}
                              {pool.poolMeta && <span className="px-1.5 py-0.5 bg-gray-700 text-gray-300 rounded">{pool.poolMeta}</span>}
                            </div>
                            <div className="ml-auto flex items-center gap-2">
                              {projectInfo?.url && (
                                <a
                                  href={projectInfo.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1 px-3 py-1.5 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 text-xs font-medium rounded border border-yellow-500/30 transition-colors"
                                  data-testid={`button-go-stake-${pool.id}`}
                                >
                                  Go to {projectInfo.name} <ExternalLink size={10} />
                                </a>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {filteredPools.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-gray-500">
              <Search size={24} className="mb-2" />
              <span className="text-sm">No pools match your filters</span>
              <button onClick={() => { setSearchQuery(''); setFilter('all'); setChainFilter('all'); }} className="mt-2 text-xs text-yellow-400 hover:underline" data-testid="button-clear-filters">
                Clear filters
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg">
        <div className="flex items-start gap-2">
          <Info size={14} className="text-gray-500 mt-0.5 flex-shrink-0" />
          <div className="text-[10px] text-gray-500 leading-relaxed">
            <p className="font-semibold text-gray-400 mb-1">How This Works</p>
            <p>Yield data is sourced from DeFi Llama's aggregated on-chain data across {uniqueChains.length}+ blockchains. APY rates change constantly based on market conditions. "Stake" buttons link directly to each protocol's official website where you maintain full control of your funds. Alpha Unlimited does not endorse any specific protocol — always do your own research (DYOR) before staking.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
