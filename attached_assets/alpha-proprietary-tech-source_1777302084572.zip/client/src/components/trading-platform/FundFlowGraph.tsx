/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Fund Flow Visualization™ — Interactive Forensic Graph Engine
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * AUT_ModuleHash: AUT_f1a93b27c4d8e2f901234567
 * ALPHA_INTEGRITY_SEAL: FUND_FLOW_GRAPH_v1.0_PROTECTED
 * Calibration: GRAPH_ENGINE_SEALED
 */

import { useState, useRef, useCallback, useMemo, useEffect } from "react";

interface FlowNode {
  address: string;
  label: string;
  balance: string;
  balanceUSD: string;
  role: string;
  riskLevel: string;
  depth: number;
  txCount: number;
  chain?: string;
  riskIndicators?: string[];
}

interface FlowEdge {
  from: string;
  to: string;
  value: string;
  txHash?: string;
  timestamp?: string;
  token?: string;
}

interface FundFlowGraphProps {
  nodes: FlowNode[];
  edges: FlowEdge[];
  chain: string;
  onNodeClick?: (address: string) => void;
}

const ROLE_COLORS: Record<string, { bg: string; border: string; text: string; glow: string }> = {
  victim: { bg: "#0e2f3d", border: "#22d3ee", text: "#67e8f9", glow: "rgba(34,211,238,0.3)" },
  exchange: { bg: "#2d2306", border: "#eab308", text: "#fde047", glow: "rgba(234,179,8,0.3)" },
  exchange_deposit: { bg: "#2d2306", border: "#eab308", text: "#fde047", glow: "rgba(234,179,8,0.3)" },
  mixer: { bg: "#3d0e0e", border: "#ef4444", text: "#fca5a5", glow: "rgba(239,68,68,0.3)" },
  drainer: { bg: "#3d0e0e", border: "#ef4444", text: "#fca5a5", glow: "rgba(239,68,68,0.3)" },
  bridge: { bg: "#2a0e3d", border: "#a855f7", text: "#d8b4fe", glow: "rgba(168,85,247,0.3)" },
  splitter: { bg: "#3d2206", border: "#f97316", text: "#fdba74", glow: "rgba(249,115,22,0.3)" },
  relay: { bg: "#0e1f3d", border: "#3b82f6", text: "#93c5fd", glow: "rgba(59,130,246,0.3)" },
  defi: { bg: "#0e3d1f", border: "#22c55e", text: "#86efac", glow: "rgba(34,197,94,0.3)" },
  default: { bg: "#1a1f2e", border: "#4b5563", text: "#9ca3af", glow: "rgba(75,85,99,0.2)" },
};

function getRoleColor(role: string) {
  return ROLE_COLORS[role] || ROLE_COLORS.default;
}

function formatValue(val: string | number): string {
  const n = typeof val === "string" ? parseFloat(val) : val;
  if (isNaN(n) || n === 0) return "";
  if (n >= 1000000) return `$${(n / 1000000).toFixed(2)}M`;
  if (n >= 1000) return `$${(n / 1000).toFixed(1)}K`;
  if (n >= 1) return `$${n.toFixed(2)}`;
  return n.toFixed(4);
}

function truncateLabel(label: string, maxLen = 20): string {
  if (label.length <= maxLen) return label;
  return label.slice(0, maxLen - 2) + "..";
}

const NODE_W = 200;
const NODE_H = 70;
const COL_GAP = 280;
const ROW_GAP = 90;
const PADDING = 60;

export default function FundFlowGraph({ nodes, edges, chain, onNodeClick }: FundFlowGraphProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [hoveredEdge, setHoveredEdge] = useState<number | null>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  const layout = useMemo(() => {
    if (!nodes || nodes.length === 0) return { positions: new Map<string, { x: number; y: number }>(), width: 800, height: 400 };

    const byDepth: Record<number, FlowNode[]> = {};
    nodes.forEach(n => {
      const d = n.depth ?? 0;
      if (!byDepth[d]) byDepth[d] = [];
      byDepth[d].push(n);
    });

    const depths = Object.keys(byDepth).map(Number).sort((a, b) => a - b);
    const positions = new Map<string, { x: number; y: number }>();
    let maxY = 0;

    depths.forEach((depth, colIdx) => {
      const colNodes = byDepth[depth];
      const colX = PADDING + colIdx * COL_GAP;
      const totalH = colNodes.length * NODE_H + (colNodes.length - 1) * ROW_GAP;
      const startY = PADDING;

      colNodes.forEach((node, rowIdx) => {
        const y = startY + rowIdx * (NODE_H + ROW_GAP);
        positions.set(node.address.toLowerCase(), { x: colX, y });
        if (y + NODE_H > maxY) maxY = y + NODE_H;
      });
    });

    const width = PADDING * 2 + depths.length * COL_GAP;
    const height = maxY + PADDING;
    return { positions, width: Math.max(width, 800), height: Math.max(height, 400) };
  }, [nodes]);

  useEffect(() => {
    if (containerRef.current && layout.width > 0) {
      const cw = containerRef.current.clientWidth;
      const ch = containerRef.current.clientHeight || 600;
      const scaleX = cw / layout.width;
      const scaleY = ch / layout.height;
      const s = Math.min(scaleX, scaleY, 1) * 0.9;
      setTransform({ x: (cw - layout.width * s) / 2, y: 20, scale: s });
    }
  }, [layout]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setTransform(t => ({
      ...t,
      scale: Math.max(0.1, Math.min(3, t.scale * delta)),
    }));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setDragging(true);
    setDragStart({ x: e.clientX - transform.x, y: e.clientY - transform.y });
  }, [transform]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragging) return;
    setTransform(t => ({ ...t, x: e.clientX - dragStart.x, y: e.clientY - dragStart.y }));
  }, [dragging, dragStart]);

  const handleMouseUp = useCallback(() => setDragging(false), []);

  const connectedToSelected = useMemo(() => {
    if (!selectedNode) return new Set<string>();
    const s = new Set<string>();
    edges.forEach(e => {
      if (e.from.toLowerCase() === selectedNode.toLowerCase()) s.add(e.to.toLowerCase());
      if (e.to.toLowerCase() === selectedNode.toLowerCase()) s.add(e.from.toLowerCase());
    });
    return s;
  }, [selectedNode, edges]);

  const edgePaths = useMemo(() => {
    return edges.map((edge, idx) => {
      const fromPos = layout.positions.get(edge.from.toLowerCase());
      const toPos = layout.positions.get(edge.to.toLowerCase());
      if (!fromPos || !toPos) return null;

      const x1 = fromPos.x + NODE_W;
      const y1 = fromPos.y + NODE_H / 2;
      const x2 = toPos.x;
      const y2 = toPos.y + NODE_H / 2;

      const dx = x2 - x1;
      const cpx1 = x1 + dx * 0.4;
      const cpx2 = x2 - dx * 0.4;
      const path = `M ${x1} ${y1} C ${cpx1} ${y1}, ${cpx2} ${y2}, ${x2} ${y2}`;

      const fromNode = nodes.find(n => n.address.toLowerCase() === edge.from.toLowerCase());
      const toNode = nodes.find(n => n.address.toLowerCase() === edge.to.toLowerCase());
      const color = getRoleColor(toNode?.role || "default");

      const midX = (x1 + x2) / 2;
      const midY = (y1 + y2) / 2;
      const val = parseFloat(edge.value || "0");

      const isHighlighted = selectedNode &&
        (edge.from.toLowerCase() === selectedNode.toLowerCase() || edge.to.toLowerCase() === selectedNode.toLowerCase());
      const isDimmed = selectedNode && !isHighlighted;

      return { path, x1, y1, x2, y2, midX, midY, val, color, edge, idx, fromNode, toNode, isHighlighted, isDimmed };
    }).filter(Boolean);
  }, [edges, layout, nodes, selectedNode]);

  if (!nodes || nodes.length === 0) {
    return (
      <div className="bg-[#0d1117] rounded-xl border border-gray-800/50 p-8 text-center">
        <div className="text-gray-500 text-sm">No fund flow data available. Run a Spider Trace to generate the visual graph.</div>
      </div>
    );
  }

  return (
    <div className="bg-[#0d1117] rounded-xl border border-gray-800/50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-bold text-cyan-400">FUND FLOW VISUALIZATION</h3>
          <span className="text-[10px] text-gray-500">{nodes.length} wallets · {edges.length} flows</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            data-testid="button-zoom-in"
            onClick={() => setTransform(t => ({ ...t, scale: Math.min(3, t.scale * 1.2) }))}
            className="w-7 h-7 flex items-center justify-center bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-400 text-sm border border-gray-700/50"
          >+</button>
          <button
            data-testid="button-zoom-out"
            onClick={() => setTransform(t => ({ ...t, scale: Math.max(0.1, t.scale * 0.8) }))}
            className="w-7 h-7 flex items-center justify-center bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-400 text-sm border border-gray-700/50"
          >−</button>
          <button
            data-testid="button-zoom-fit"
            onClick={() => {
              if (containerRef.current) {
                const cw = containerRef.current.clientWidth;
                const ch = containerRef.current.clientHeight;
                const s = Math.min(cw / layout.width, ch / layout.height, 1) * 0.9;
                setTransform({ x: (cw - layout.width * s) / 2, y: 20, scale: s });
              }
            }}
            className="px-2 h-7 flex items-center justify-center bg-gray-800/50 hover:bg-gray-700/50 rounded text-gray-400 text-[10px] border border-gray-700/50"
          >Fit</button>
          {selectedNode && (
            <button
              data-testid="button-clear-selection"
              onClick={() => setSelectedNode(null)}
              className="px-2 h-7 flex items-center justify-center bg-cyan-800/30 hover:bg-cyan-700/30 rounded text-cyan-400 text-[10px] border border-cyan-700/50"
            >Clear Selection</button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 px-4 py-1.5 border-b border-gray-800/30 bg-[#0a0e14]">
        {[
          { role: "victim", label: "Victim" },
          { role: "exchange", label: "Exchange" },
          { role: "bridge", label: "Bridge" },
          { role: "mixer", label: "Mixer" },
          { role: "splitter", label: "Splitter" },
          { role: "relay", label: "Relay" },
          { role: "defi", label: "DeFi" },
        ].map(({ role, label }) => {
          const c = getRoleColor(role);
          return (
            <div key={role} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: c.border }} />
              <span className="text-[10px] text-gray-500">{label}</span>
            </div>
          );
        })}
      </div>

      <div
        ref={containerRef}
        className="relative select-none"
        style={{ height: "600px", cursor: dragging ? "grabbing" : "grab" }}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          style={{ position: "absolute", top: 0, left: 0 }}
        >
          <defs>
            {Object.entries(ROLE_COLORS).map(([role, colors]) => (
              <marker
                key={`arrow-${role}`}
                id={`arrowhead-${role}`}
                markerWidth="8"
                markerHeight="6"
                refX="8"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 8 3, 0 6" fill={colors.border} opacity="0.7" />
              </marker>
            ))}
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g transform={`translate(${transform.x}, ${transform.y}) scale(${transform.scale})`}>
            {edgePaths.map((ep: any) => {
              if (!ep) return null;
              const roleKey = ep.toNode?.role || "default";
              const isHovered = hoveredEdge === ep.idx;
              const opacity = ep.isDimmed ? 0.1 : (isHovered || ep.isHighlighted) ? 0.9 : 0.4;
              const strokeWidth = (isHovered || ep.isHighlighted) ? 2.5 : 1.5;

              return (
                <g key={`edge-${ep.idx}`}>
                  <path
                    d={ep.path}
                    fill="none"
                    stroke={ep.color.border}
                    strokeWidth={strokeWidth}
                    strokeOpacity={opacity}
                    markerEnd={`url(#arrowhead-${roleKey})`}
                    className="transition-all duration-200"
                    onMouseEnter={() => setHoveredEdge(ep.idx)}
                    onMouseLeave={() => setHoveredEdge(null)}
                    style={{ cursor: "pointer" }}
                    strokeDasharray={ep.toNode?.role === "mixer" ? "6 3" : undefined}
                  />
                  {ep.val > 0 && (isHovered || ep.isHighlighted || !selectedNode) && (
                    <g transform={`translate(${ep.midX}, ${ep.midY - 8})`}>
                      <rect
                        x={-30}
                        y={-8}
                        width={60}
                        height={16}
                        rx={4}
                        fill="#0d1117"
                        stroke={ep.color.border}
                        strokeWidth={0.5}
                        strokeOpacity={0.5}
                      />
                      <text
                        textAnchor="middle"
                        dominantBaseline="central"
                        fill={ep.color.text}
                        fontSize={9}
                        fontFamily="monospace"
                      >
                        {ep.val >= 1 ? ep.val.toFixed(2) : ep.val.toFixed(4)}
                      </text>
                    </g>
                  )}
                </g>
              );
            })}

            {nodes.map(node => {
              const pos = layout.positions.get(node.address.toLowerCase());
              if (!pos) return null;
              const colors = getRoleColor(node.role);
              const isHovered = hoveredNode === node.address;
              const isSelected = selectedNode === node.address.toLowerCase();
              const isConnected = connectedToSelected.has(node.address.toLowerCase());
              const isDimmed = selectedNode && !isSelected && !isConnected;
              const opacity = isDimmed ? 0.15 : 1;
              const usdVal = parseFloat(node.balanceUSD || "0");

              return (
                <g
                  key={node.address}
                  transform={`translate(${pos.x}, ${pos.y})`}
                  opacity={opacity}
                  className="transition-opacity duration-200"
                  style={{ cursor: "pointer" }}
                  onMouseEnter={() => setHoveredNode(node.address)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isSelected) {
                      setSelectedNode(null);
                    } else {
                      setSelectedNode(node.address.toLowerCase());
                      onNodeClick?.(node.address);
                    }
                  }}
                  data-testid={`flow-node-${node.address.slice(0, 8)}`}
                >
                  {(isHovered || isSelected) && (
                    <rect
                      x={-3}
                      y={-3}
                      width={NODE_W + 6}
                      height={NODE_H + 6}
                      rx={10}
                      fill="none"
                      stroke={colors.border}
                      strokeWidth={1.5}
                      opacity={0.4}
                      filter="url(#glow)"
                    />
                  )}
                  <rect
                    x={0}
                    y={0}
                    width={NODE_W}
                    height={NODE_H}
                    rx={8}
                    fill={colors.bg}
                    stroke={colors.border}
                    strokeWidth={isSelected ? 2 : isHovered ? 1.5 : 1}
                    strokeOpacity={isSelected ? 1 : 0.6}
                  />
                  <rect
                    x={0}
                    y={0}
                    width={4}
                    height={NODE_H}
                    rx={2}
                    fill={colors.border}
                    opacity={0.8}
                  />
                  <text x={12} y={18} fill={colors.text} fontSize={11} fontWeight="bold">
                    {truncateLabel(node.label || "Unknown")}
                  </text>
                  <text x={12} y={33} fill="#6b7280" fontSize={9} fontFamily="monospace">
                    {node.address.slice(0, 8)}...{node.address.slice(-6)}
                  </text>
                  <text x={12} y={50} fill={usdVal > 0 ? "#4ade80" : "#6b7280"} fontSize={10} fontWeight="600">
                    {usdVal > 0 ? formatValue(usdVal) : `${parseFloat(node.balance || "0").toFixed(4)} ${node.chain ? node.chain.toUpperCase().slice(0, 3) : "ETH"}`}
                  </text>
                  {usdVal > 0 && (
                    <text x={12} y={62} fill="#4b5563" fontSize={8}>
                      {parseFloat(node.balance || "0").toFixed(4)} native
                    </text>
                  )}
                  <rect
                    x={NODE_W - 50}
                    y={4}
                    width={44}
                    height={14}
                    rx={3}
                    fill={colors.border}
                    opacity={0.2}
                  />
                  <text x={NODE_W - 28} y={14} textAnchor="middle" fill={colors.text} fontSize={8} fontWeight="bold">
                    {(node.role || "UNKNOWN").toUpperCase().slice(0, 8)}
                  </text>
                  {node.txCount > 0 && (
                    <>
                      <text x={NODE_W - 8} y={50} textAnchor="end" fill="#4b5563" fontSize={8}>
                        {node.txCount} txs
                      </text>
                    </>
                  )}
                </g>
              );
            })}
          </g>
        </svg>

        {hoveredNode && (() => {
          const node = nodes.find(n => n.address === hoveredNode);
          if (!node) return null;
          const pos = layout.positions.get(node.address.toLowerCase());
          if (!pos) return null;
          const inEdges = edges.filter(e => e.to.toLowerCase() === node.address.toLowerCase());
          const outEdges = edges.filter(e => e.from.toLowerCase() === node.address.toLowerCase());
          const totalIn = inEdges.reduce((s, e) => s + parseFloat(e.value || "0"), 0);
          const totalOut = outEdges.reduce((s, e) => s + parseFloat(e.value || "0"), 0);

          const screenX = pos.x * transform.scale + transform.x + NODE_W * transform.scale + 10;
          const screenY = pos.y * transform.scale + transform.y;

          return (
            <div
              className="absolute z-50 bg-[#161b22] border border-gray-700 rounded-lg p-3 shadow-2xl pointer-events-none"
              style={{ left: screenX, top: screenY, minWidth: 220, maxWidth: 300 }}
            >
              <div className="text-xs font-bold text-white mb-1">{node.label}</div>
              <div className="font-mono text-[10px] text-cyan-400 mb-2 break-all">{node.address}</div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px]">
                <span className="text-gray-500">Chain:</span>
                <span className="text-gray-300">{node.chain || chain}</span>
                <span className="text-gray-500">Role:</span>
                <span className="text-gray-300">{node.role}</span>
                <span className="text-gray-500">Risk:</span>
                <span className={node.riskLevel === "critical" ? "text-red-400" : node.riskLevel === "high" ? "text-orange-400" : "text-gray-300"}>{node.riskLevel}</span>
                <span className="text-gray-500">Balance:</span>
                <span className="text-green-400">{formatValue(node.balanceUSD || "0")}</span>
                <span className="text-gray-500">Inflows:</span>
                <span className="text-cyan-400">{inEdges.length} ({totalIn.toFixed(4)})</span>
                <span className="text-gray-500">Outflows:</span>
                <span className="text-orange-400">{outEdges.length} ({totalOut.toFixed(4)})</span>
              </div>
              {node.riskIndicators && node.riskIndicators.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {node.riskIndicators.map(ri => (
                    <span key={ri} className="text-[9px] px-1 py-0.5 bg-red-900/30 border border-red-600/20 rounded text-red-400">
                      {ri.replace(/_/g, " ")}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })()}
      </div>
    </div>
  );
}
