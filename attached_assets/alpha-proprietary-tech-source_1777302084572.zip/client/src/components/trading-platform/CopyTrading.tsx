/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha CopyTrading™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_76551629007f37cea8c30f8e
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, Copy, TrendingUp, TrendingDown, Star, Crown, Shield,
  BarChart3, Eye, UserPlus, UserMinus, Settings, AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface TopTrader {
  id: string;
  name: string;
  avatar: string;
  winRate: number;
  totalPnl: number;
  pnlPercent: number;
  followers: number;
  trades30d: number;
  maxDrawdown: number;
  avgHoldTime: string;
  riskLevel: 'low' | 'medium' | 'high';
  isVerified: boolean;
  specialties: string[];
  dataSource?: string;
}

export function CopyTrading({ userTier = 'free' }: { userTier?: string }) {
  const { toast } = useToast();
  const [traders, setTraders] = useState<TopTrader[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [following, setFollowing] = useState<string[]>([]);
  const [filter, setFilter] = useState<'all' | 'low' | 'medium' | 'high'>('all');
  const [sortBy, setSortBy] = useState<'pnl' | 'winRate' | 'followers'>('pnl');
  const [selectedTrader, setSelectedTrader] = useState<TopTrader | null>(null);
  const [copySettings, setCopySettings] = useState({ maxInvestment: 1000, copyRatio: 100 });

  const isPremiumPlus = userTier === 'premium' || userTier === 'platinum' || userTier === 'alpha';

  useEffect(() => {
    const saved = localStorage.getItem('alpha-copy-trading');
    if (saved) {
      setFollowing(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('alpha-copy-trading', JSON.stringify(following));
  }, [following]);

  useEffect(() => {
    async function fetchLeaderboard() {
      try {
        setLoading(true);
        const res = await fetch('/api/copy-trading/leaderboard');
        if (!res.ok) throw new Error('Failed to fetch leaderboard');
        const data = await res.json();
        const mapped = (data.traders || []).map((t: any) => ({
          ...t,
          totalPnl: t.totalPnl ?? t.totalPnL ?? 0,
        }));
        setTraders(mapped);
        setLastUpdated(data.lastUpdated || null);
      } catch (err: any) {
        toast({ title: 'Error', description: err.message || 'Failed to load trader leaderboard', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }
    fetchLeaderboard();
  }, []);

  const filteredTraders = traders
    .filter(t => filter === 'all' || t.riskLevel === filter)
    .sort((a, b) => {
      if (sortBy === 'pnl') return b.pnlPercent - a.pnlPercent;
      if (sortBy === 'winRate') return b.winRate - a.winRate;
      return b.followers - a.followers;
    });

  const handleFollow = (traderId: string) => {
    if (!isPremiumPlus) {
      toast({ title: 'Pro Required', description: 'Copy trading requires Pro tier or higher', variant: 'destructive' });
      return;
    }

    if (following.includes(traderId)) {
      setFollowing(following.filter(id => id !== traderId));
      toast({ title: 'Unfollowed', description: 'You are no longer copying this trader' });
    } else {
      setFollowing([...following, traderId]);
      toast({ title: 'Following!', description: 'You are now copying this trader\'s positions' });
    }
  };

  const getRiskColor = (risk: string) => {
    if (risk === 'low') return 'text-green-400 bg-green-500/20';
    if (risk === 'medium') return 'text-yellow-400 bg-yellow-500/20';
    return 'text-red-400 bg-red-500/20';
  };

  return (
    <div className="space-y-4" data-testid="copy-trading">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Copy Trading</h2>
            <p className="text-xs text-gray-500">Follow and copy top performing traders</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-gray-400">Following:</span>
          <span className="text-cyan-400 font-bold">{following.length}</span>
        </div>
      </div>

      {!isPremiumPlus && (
        <div className="p-4 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-lg">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <Crown className="text-yellow-400 flex-shrink-0" size={24} />
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white">Unlock Copy Trading</div>
              <div className="text-sm text-gray-400">Automatically copy trades from top performers with Pro tier</div>
            </div>
            <Button className="bg-purple-500 hover:bg-purple-600 flex-shrink-0 w-full sm:w-auto" size="sm">Upgrade</Button>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex gap-1">
          {(['all', 'low', 'medium', 'high'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                filter === f 
                  ? f === 'low' ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                    : f === 'medium' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50'
                    : f === 'high' ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                    : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                  : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-gray-600'
              }`}
            >
              {f === 'all' ? 'All Risk' : f.charAt(0).toUpperCase() + f.slice(1) + ' Risk'}
            </button>
          ))}
        </div>
        <div className="ml-auto flex gap-1">
          {(['pnl', 'winRate', 'followers'] as const).map(s => (
            <button
              key={s}
              onClick={() => setSortBy(s)}
              className={`px-2 py-1 rounded text-xs ${
                sortBy === s ? 'bg-gray-700 text-white' : 'text-gray-500 hover:text-gray-400'
              }`}
            >
              {s === 'pnl' ? 'P&L' : s === 'winRate' ? 'Win Rate' : 'Followers'}
            </button>
          ))}
        </div>
      </div>

      {lastUpdated && (
        <div className="flex items-center gap-2 text-[10px] text-gray-500" data-testid="text-data-source">
          <BarChart3 size={10} />
          <span>Data source: Binance Market Data</span>
          <span>·</span>
          <span>Updated: {new Date(lastUpdated).toLocaleString()}</span>
        </div>
      )}

      <div className="max-h-[400px] overflow-y-auto overflow-x-hidden space-y-3 pr-2 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg animate-pulse">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gray-700 rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-700 rounded w-24" />
                  <div className="h-3 bg-gray-700 rounded w-32" />
                </div>
                <div className="h-6 bg-gray-700 rounded w-16" />
              </div>
            </div>
          ))
        ) : filteredTraders.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-sm" data-testid="text-no-traders">No traders found</div>
        ) : filteredTraders.map((trader, index) => (
          <motion.div
            key={trader.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-3 sm:p-4 bg-gray-900/50 border rounded-lg transition-all ${
              following.includes(trader.id) 
                ? 'border-cyan-500/50 bg-cyan-500/5' 
                : 'border-gray-800 hover:border-gray-700'
            }`}
          >
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <div className="relative flex-shrink-0">
                  <div className="text-2xl sm:text-3xl">{trader.avatar}</div>
                  {trader.isVerified && (
                    <Shield size={12} className="absolute -bottom-1 -right-1 text-blue-400" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-white text-sm sm:text-base">{trader.name}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${getRiskColor(trader.riskLevel)}`}>
                      {trader.riskLevel}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] sm:text-xs text-gray-500 mt-1">
                    <span>{trader.followers.toLocaleString()} followers</span>
                    <span>{trader.trades30d} trades/30d</span>
                  </div>
                  <div className="text-[10px] text-gray-500 mt-0.5">Avg hold: {trader.avgHoldTime}</div>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {trader.specialties.map(s => (
                      <span key={s} className="px-1.5 py-0.5 bg-gray-800 text-gray-400 text-[10px] rounded">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1 flex-shrink-0 text-right">
                  <div className={`text-sm sm:text-lg font-bold font-mono tabular-nums ${trader.pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {trader.pnlPercent >= 0 ? '+' : ''}{trader.pnlPercent}%
                  </div>
                  <div className="text-[10px] text-gray-500">All-time P&L</div>
                  <div className="text-[10px] sm:text-sm text-white font-mono tabular-nums">${(trader.totalPnl ?? 0).toLocaleString()}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-gray-800/50">
                <div className="flex items-center gap-3">
                  <div className="text-center">
                    <div className="text-sm sm:text-base font-bold text-cyan-400 font-mono tabular-nums">{trader.winRate}%</div>
                    <div className="text-[10px] text-gray-500">Win Rate</div>
                  </div>
                  <div className="w-px h-6 bg-gray-700" />
                  <div className="text-center">
                    <div className="text-sm sm:text-base font-bold text-red-400 font-mono tabular-nums">-{trader.maxDrawdown}%</div>
                    <div className="text-[10px] text-gray-500">Drawdown</div>
                  </div>
                </div>

                <Button
                  onClick={() => handleFollow(trader.id)}
                  variant={following.includes(trader.id) ? 'outline' : 'default'}
                  size="sm"
                  className={`flex-shrink-0 text-xs px-3 ${following.includes(trader.id) 
                    ? 'border-cyan-500 text-cyan-400' 
                    : 'bg-cyan-500 hover:bg-cyan-600'
                  }`}
                >
                  {following.includes(trader.id) ? (
                    <><UserMinus size={12} className="mr-1" /> Unfollow</>
                  ) : (
                    <><UserPlus size={12} className="mr-1" /> Copy</>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>


      {following.length > 0 && isPremiumPlus && (
        <div className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg">
          <h3 className="font-medium text-white mb-3 flex items-center gap-2">
            <Settings size={16} className="text-gray-400" />
            Copy Settings
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Max Investment per Trade</label>
              <input
                type="number"
                value={copySettings.maxInvestment}
                onChange={e => setCopySettings({ ...copySettings, maxInvestment: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Copy Ratio (%)</label>
              <input
                type="number"
                value={copySettings.copyRatio}
                onChange={e => setCopySettings({ ...copySettings, copyRatio: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm"
              />
            </div>
          </div>
          <div className="mt-3 p-2 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-400 flex items-center gap-2">
            <AlertCircle size={14} />
            Copy trading involves risk. Past performance doesn't guarantee future results.
          </div>
        </div>
      )}
    </div>
  );
}
