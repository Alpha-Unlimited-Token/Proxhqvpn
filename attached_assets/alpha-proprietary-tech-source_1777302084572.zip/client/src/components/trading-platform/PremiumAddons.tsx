/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PremiumAddons™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_bf7a5d3eaf0065d4c6d3f4ac
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Brain, Shuffle, Activity, Clock, Users,
  CheckCircle, Loader2, Sparkles, Zap, X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useUserAddons } from "@/hooks/useUserAddons";
import { PromoCodeInput } from "@/components/PromoCodeInput";

const ICON_MAP: Record<string, React.ReactNode> = {
  brain: <Brain size={24} />,
  shuffle: <Shuffle size={24} />,
  activity: <Activity size={24} />,
  clock: <Clock size={24} />,
  users: <Users size={24} />,
};

type Addon = {
  id: string;
  name: string;
  price: number;
  description: string;
  features: readonly string[];
  icon: string;
  color: string;
  stripeMetadataKey: string;
};

export function PremiumAddons() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { userAddons } = useUserAddons();
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [cancelConfirm, setCancelConfirm] = useState<string | null>(null);
  const [addonPromoCode, setAddonPromoCode] = useState<string | null>(null);

  const { data: addons = [] } = useQuery<Addon[]>({
    queryKey: ["/api/addons"],
    queryFn: () => fetch("/api/addons").then(r => r.json()),
  });

  const cancelMutation = useMutation({
    mutationFn: async (addonId: string) => {
      const res = await apiRequest("POST", "/api/addons/cancel", { addonId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/addons"] });
      setCancelConfirm(null);
    },
  });

  const handleCheckout = async (addon: Addon) => {
    if (!user) {
      window.location.href = "/api/login";
      return;
    }
    setCheckoutLoading(addon.id);
    try {
      const res = await apiRequest("POST", "/api/addons/checkout", {
        addonId: addon.id,
        promoCode: addonPromoCode,
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (err) {
      console.error("Checkout error:", err);
    } finally {
      setCheckoutLoading(null);
    }
  };

  const isActive = (addonId: string) =>
    userAddons.some(a => a.addonId === addonId && a.status === "active");

  return (
    <div>
      <div className="mb-4 max-w-sm">
        <PromoCodeInput onPromoApplied={(code) => setAddonPromoCode(code)} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {addons.map((addon, index) => {
          const active = isActive(addon.id);
          return (
            <motion.div
              key={addon.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * index }}
              className={`relative rounded-2xl p-5 border-2 transition-all flex flex-col ${
                active
                  ? "border-green-500/50 bg-green-500/5"
                  : "border-gray-700 bg-gray-900/50 hover:border-gray-600"
              }`}
              data-testid={`card-addon-${addon.id}`}
            >
              {active && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                  <CheckCircle size={12} /> ACTIVE
                </div>
              )}

              <div className="flex items-center gap-3 mb-3">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${addon.color}20`, color: addon.color }}
                >
                  {ICON_MAP[addon.icon] || <Sparkles size={24} />}
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{addon.name}</h4>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-bold" style={{ color: addon.color }}>
                      ${(addon.price / 100).toFixed(0)}
                    </span>
                    <span className="text-gray-400 text-xs">/mo</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-400 mb-3">{addon.description}</p>

              <ul className="space-y-1.5 mb-4 flex-1">
                {addon.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-xs text-gray-300">
                    <Zap size={10} className="mt-0.5 shrink-0" style={{ color: addon.color }} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {active ? (
                cancelConfirm === addon.id ? (
                  <div className="space-y-2">
                    <p className="text-xs text-red-400 text-center">Cancel this add-on?</p>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="destructive"
                        className="flex-1 text-xs"
                        onClick={() => cancelMutation.mutate(addon.id)}
                        disabled={cancelMutation.isPending}
                        data-testid={`button-confirm-cancel-addon-${addon.id}`}
                      >
                        {cancelMutation.isPending ? <Loader2 size={12} className="animate-spin" /> : "Yes, Cancel"}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 text-xs border-gray-600"
                        onClick={() => setCancelConfirm(null)}
                        data-testid={`button-dismiss-cancel-addon-${addon.id}`}
                      >
                        Keep
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full border-gray-600 text-gray-400 text-xs"
                    onClick={() => setCancelConfirm(addon.id)}
                    data-testid={`button-cancel-addon-${addon.id}`}
                  >
                    <X size={12} className="mr-1" /> Cancel Add-on
                  </Button>
                )
              ) : (
                <Button
                  size="sm"
                  className="w-full text-xs font-bold"
                  style={{ backgroundColor: addon.color, color: "#000" }}
                  onClick={() => handleCheckout(addon)}
                  disabled={checkoutLoading === addon.id}
                  data-testid={`button-subscribe-addon-${addon.id}`}
                >
                  {checkoutLoading === addon.id ? (
                    <Loader2 size={12} className="animate-spin mr-1" />
                  ) : (
                    <Sparkles size={12} className="mr-1" />
                  )}
                  {checkoutLoading === addon.id ? "Processing..." : "Subscribe"}
                </Button>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}


