/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha SocialTradingPanel™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_e5854a10447b92deda0a5436
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Users, Trophy, Copy, TrendingUp, TrendingDown, Star, Eye, UserPlus, Check, Search, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

interface TopTrader {
  id: string;
  name: string;
  address: string;
  avatar: string;
  winRate: number;
  totalPnL: number;
  pnlPercent: number;
  followers: number;
  trades: number;
  isFollowing: boolean;
  rank: number;
  riskLevel: 'low' | 'medium' | 'high';
  specialties: string[];
  longShortRatio: number;
  primaryPair: string;
  dataSource: string;
}

interface RecentTrade {
  id: string;
  trader: string;
  traderAddress: string;
  pair: string;
  side: 'buy' | 'sell';
  price: number;
  pnl: number;
  timestamp: string;
}

export function SocialTradingPanel() {
  const [traders, setTraders] = useState<TopTrader[]>([]);
  const [trades, setTrades] = useState<RecentTrade[]>([]);
  const [copiedTraders, setCopiedTraders] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [favoriteAddresses, setFavoriteAddresses] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('alpha-social-favorites');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem('alpha-social-favorites', JSON.stringify(favoriteAddresses));
  }, [favoriteAddresses]);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const res = await fetch('/api/copy-trading/leaderboard');
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        const mapped: TopTrader[] = (data.traders || []).map((t: any, i: number) => ({
          id: t.id,
          name: t.username || t.name,
          address: t.address || '',
          avatar: t.avatar,
          winRate: t.winRate,
          totalPnL: t.totalPnl || t.totalPnL || 0,
          pnlPercent: t.pnlPercent || 0,
          followers: t.followers,
          trades: t.trades30d || t.trades || 0,
          isFollowing: favoriteAddresses.includes(t.address || t.id),
          rank: i + 1,
          riskLevel: t.riskLevel,
          specialties: t.specialties || [],
          longShortRatio: t.longShortRatio || 0,
          primaryPair: t.primaryPair || '',
          dataSource: t.dataSource || 'Binance Market Data',
        }));
        setTraders(mapped);

        const liveTrades: RecentTrade[] = mapped.slice(0, 5).map((t: TopTrader, i: number) => ({
          id: `trade-${t.id}-${i}`,
          trader: t.name,
          traderAddress: t.address,
          pair: t.primaryPair ? t.primaryPair.replace('USDT', '/USDT') : 'BTC/USDT',
          side: (t.longShortRatio > 1 ? 'buy' : 'sell') as 'buy' | 'sell',
          price: t.totalPnL > 0 ? Math.abs(t.totalPnL * 0.01) : Math.abs(t.totalPnL * 0.005),
          pnl: t.totalPnL > 0 ? Math.round(t.totalPnL * 0.02) : -Math.round(Math.abs(t.totalPnL) * 0.01),
          timestamp: `${(i + 1) * 3}m ago`,
        }));
        setTrades(liveTrades);
      } catch {
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleFollow = (traderAddr: string) => {
    if (favoriteAddresses.includes(traderAddr)) {
      setFavoriteAddresses(prev => prev.filter(a => a !== traderAddr));
      setTraders(traders.map(t => t.address === traderAddr ? { ...t, isFollowing: false } : t));
    } else {
      setFavoriteAddresses(prev => [...prev, traderAddr]);
      setTraders(traders.map(t => t.address === traderAddr ? { ...t, isFollowing: true } : t));
    }
  };

  const handleCopyTrade = (traderId: string) => {
    if (copiedTraders.includes(traderId)) {
      setCopiedTraders(copiedTraders.filter(id => id !== traderId));
    } else {
      setCopiedTraders([...copiedTraders, traderId]);
    }
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'from-yellow-400 to-amber-500';
    if (rank === 2) return 'from-gray-300 to-gray-400';
    if (rank === 3) return 'from-orange-400 to-orange-600';
    return '';
  };

  const filteredTraders = searchQuery
    ? traders.filter(t => t.address.toLowerCase().includes(searchQuery.toLowerCase()) || t.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : traders;

  return (
    <Card className="bg-[#152238] border-[#223350]">
      <CardHeader className="border-b border-white/10 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <CardTitle className="text-white">Social Trading</CardTitle>
          </div>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
            Live
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-gray-500 mt-2">
          <BarChart3 size={10} />
          <span>Real-time data from Binance Market Data</span>
        </div>
      </CardHeader>

      <CardContent className="pt-4">
        <div className="relative mb-4">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="Search by wallet address (0x...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-4 py-2 bg-[#0A1628] border border-[#223350] rounded-lg text-sm text-white placeholder-gray-500 focus:border-cyan-500 focus:outline-none"
            data-testid="input-social-trader-search"
          />
        </div>

        <Tabs defaultValue="leaderboard" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-[#0A1628] mb-4">
            <TabsTrigger value="leaderboard" className="data-[state=active]:bg-[#1A2942] data-[state=active]:text-cyan-400">
              <Trophy className="w-4 h-4 mr-2" />
              Leaderboard
            </TabsTrigger>
            <TabsTrigger value="copy" className="data-[state=active]:bg-[#1A2942] data-[state=active]:text-cyan-400">
              <Copy className="w-4 h-4 mr-2" />
              Copy Trading
            </TabsTrigger>
            <TabsTrigger value="feed" className="data-[state=active]:bg-[#1A2942] data-[state=active]:text-cyan-400">
              <Eye className="w-4 h-4 mr-2" />
              Live Feed
            </TabsTrigger>
          </TabsList>

          <TabsContent value="leaderboard" className="space-y-3">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-[#1A2942] border border-white/5 animate-pulse">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-700 rounded-full" />
                    <div className="w-10 h-10 bg-gray-700 rounded-full" />
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-700 rounded w-24" />
                      <div className="h-3 bg-gray-700 rounded w-32" />
                    </div>
                  </div>
                </div>
              ))
            ) : filteredTraders.length === 0 ? (
              <div className="text-center py-6 text-gray-500 text-sm">No traders found matching that address</div>
            ) : (
              <>
                {favoriteAddresses.length > 0 && !searchQuery && (
                  <div className="mb-2">
                    <p className="text-[10px] uppercase tracking-wider text-yellow-400 font-medium mb-1 flex items-center gap-1">
                      <Star size={10} fill="currentColor" /> Favorites
                    </p>
                    {traders.filter(t => favoriteAddresses.includes(t.address)).map((trader, i) => (
                      <motion.div
                        key={`fav-${trader.id}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center justify-between p-3 rounded-lg bg-[#1A2942] border border-yellow-500/30 hover:border-yellow-400/50 transition-all mb-2"
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">{trader.avatar}</div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-white font-mono text-sm">{trader.name}</p>
                              <Star className="w-3 h-3 text-yellow-400" fill="currentColor" />
                            </div>
                            <p className="text-[10px] text-gray-500 font-mono">{trader.address}</p>
                            <div className="flex gap-2 text-[10px] text-gray-400 mt-0.5">
                              <span>L/S: <span className="text-cyan-400">{trader.longShortRatio.toFixed(2)}</span></span>
                              {trader.specialties.slice(0, 2).map(s => (
                                <span key={s} className="px-1 bg-gray-800 rounded text-gray-400">{s}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className={`text-sm font-medium ${trader.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              {trader.totalPnL >= 0 ? '+' : ''}${Math.abs(trader.totalPnL).toLocaleString()}
                            </p>
                            <p className="text-xs text-gray-500">{trader.winRate}% win</p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleFollow(trader.address)}
                            className="border-yellow-500 text-yellow-400 hover:bg-yellow-500/10 text-xs"
                          >
                            Remove
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                {filteredTraders.map((trader, i) => (
                  <motion.div
                    key={trader.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center justify-between p-3 rounded-lg bg-[#1A2942] border border-white/5 hover:border-cyan-500/30 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                          trader.rank <= 3
                            ? `bg-gradient-to-br ${getRankColor(trader.rank)} text-black`
                            : 'bg-[#0A1628] text-gray-400'
                        }`}>
                          #{trader.rank}
                        </div>
                      </div>
                      <div className="text-2xl">{trader.avatar}</div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-white font-mono text-sm">{trader.name}</p>
                          <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                            trader.riskLevel === 'low' ? 'bg-green-500/20 text-green-400' :
                            trader.riskLevel === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {trader.riskLevel}
                          </span>
                          {favoriteAddresses.includes(trader.address) && <Star className="w-3 h-3 text-yellow-400" fill="currentColor" />}
                        </div>
                        <p className="text-[10px] text-gray-500 font-mono">{trader.address}</p>
                        <div className="flex gap-2 text-[10px] text-gray-400 mt-0.5">
                          <span>L/S: <span className="text-cyan-400">{trader.longShortRatio.toFixed(2)}</span></span>
                          <span>{trader.followers.toLocaleString()} followers</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className={`text-sm font-medium ${trader.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {trader.totalPnL >= 0 ? '+' : ''}${Math.abs(trader.totalPnL).toLocaleString()}
                        </p>
                        <p className="text-xs text-gray-500">{trader.winRate}% win rate</p>
                      </div>
                      <Button
                        size="sm"
                        variant={favoriteAddresses.includes(trader.address) ? "outline" : "default"}
                        onClick={() => handleFollow(trader.address)}
                        className={favoriteAddresses.includes(trader.address) 
                          ? "border-yellow-500 text-yellow-400 hover:bg-yellow-500/10" 
                          : "bg-cyan-500 hover:bg-cyan-600 text-black"
                        }
                        data-testid={`button-save-trader-${trader.id}`}
                      >
                        <Star className="w-4 h-4" fill={favoriteAddresses.includes(trader.address) ? 'currentColor' : 'none'} />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </>
            )}
          </TabsContent>

          <TabsContent value="copy" className="space-y-3">
            <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 mb-4">
              <h4 className="font-medium text-white mb-1">Copy Trading</h4>
              <p className="text-sm text-gray-400">Automatically mirror the trades of top performers. Start with as little as $100.</p>
            </div>
            {loading ? (
              <div className="text-center py-4 text-gray-500 text-sm">Loading traders...</div>
            ) : traders.slice(0, 5).map((trader, i) => (
              <motion.div
                key={trader.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center justify-between p-4 rounded-lg bg-[#1A2942] border border-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="text-3xl">{trader.avatar}</div>
                  <div>
                    <p className="font-medium text-white font-mono text-sm">{trader.name}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <span className="text-green-400">{trader.winRate}% win</span>
                      <span>·</span>
                      <span>{trader.trades} trades</span>
                    </div>
                    {trader.specialties.length > 0 && (
                      <div className="flex gap-1 mt-1">
                        {trader.specialties.slice(0, 2).map(s => (
                          <span key={s} className="px-1 bg-gray-800 text-gray-400 text-[10px] rounded">{s}</span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleCopyTrade(trader.id)}
                  className={copiedTraders.includes(trader.id)
                    ? "bg-green-500 hover:bg-green-600 text-white"
                    : "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white"
                  }
                >
                  {copiedTraders.includes(trader.id) ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      Copying
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </motion.div>
            ))}
          </TabsContent>

          <TabsContent value="feed" className="space-y-2">
            {loading ? (
              <div className="text-center py-4 text-gray-500 text-sm">Loading live trades...</div>
            ) : trades.map((trade, i) => (
              <motion.div
                key={trade.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center justify-between p-3 rounded-lg bg-[#1A2942] border border-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    trade.side === 'buy' ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}>
                    {trade.side === 'buy' 
                      ? <TrendingUp className="w-4 h-4 text-green-400" />
                      : <TrendingDown className="w-4 h-4 text-red-400" />
                    }
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white font-mono text-sm">{trade.trader}</span>
                      <Badge variant="outline" className={`text-xs ${trade.side === 'buy' ? 'border-green-500/30 text-green-400' : 'border-red-500/30 text-red-400'}`}>
                        {trade.side.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-500">{trade.pair}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-medium ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toLocaleString()} USDT
                  </p>
                  <p className="text-xs text-gray-500">{trade.timestamp}</p>
                </div>
              </motion.div>
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
