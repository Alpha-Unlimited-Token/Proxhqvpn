/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AUCTerminalPanel™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_986dacdbc7c062ea79daf9d0
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import {
  TrendingUp, TrendingDown, DollarSign, ArrowUpDown,
  Wallet, ArrowDownToLine, ArrowUpFromLine, X, Shield,
  Download, Trophy, BarChart3, Users, Activity, Layers,
  ChevronDown, RefreshCw, AlertTriangle, CheckCircle2, Flame
} from 'lucide-react';

interface AUCAccount {
  aucBalance: number;
  usdBalance: number;
  aucLocked: number;
  usdLocked: number;
}

interface OrderLevel {
  price: number;
  amount: number;
  total: number;
  orders: number;
}

interface AUCOrder {
  id: number;
  side: string;
  orderType: string;
  price: number | null;
  amount: number;
  filled: number;
  remaining: number;
  status: string;
  fee: number;
  createdAt: string;
}

interface FeeTier {
  currentTier: string;
  makerFee: string;
  takerFee: string;
  volume30d: number;
  allTiers: Array<{ tier: string; minVolume: number; maker: number; taker: number }>;
}

interface DepthData {
  bids: Array<{ price: number; amount: number; total: number }>;
  asks: Array<{ price: number; amount: number; total: number }>;
  spread: number;
}

interface ReservesData {
  timestamp: string;
  accounts: number;
  auc: { reserve: number; liability: number; ratio: number; totalDeposits: number; totalWithdrawals: number; locked: number };
  usd: { reserve: number; liability: number; ratio: number; totalDeposits: number; totalWithdrawals: number; locked: number };
  verified: boolean;
}

interface LeaderboardEntry {
  rank: number;
  userId: string;
  volume: number;
  trades: number;
  fees: number;
}

interface ReferralStats {
  code: string;
  totalReferrals: number;
  totalEarnings: number;
  feeSharePercent: number;
  referrals: Array<{ referredId: string; trades: number; earnings: number; joinedAt: string }>;
  hasReferrer: boolean;
  recentEarnings: Array<{ amount: number; fromFee: number; date: string }>;
}

type PanelView = 'trade' | 'orders' | 'wallet' | 'depth' | 'leaderboard' | 'reserves' | 'fees' | 'referral';

export function AUCTerminalPanel({ currentPrice }: { currentPrice: number | null }) {
  const [account, setAccount] = useState<AUCAccount | null>(null);
  const [orderBook, setOrderBook] = useState<{ bids: OrderLevel[]; asks: OrderLevel[]; spread: number } | null>(null);
  const [userOrders, setUserOrders] = useState<AUCOrder[]>([]);
  const [feeTier, setFeeTier] = useState<FeeTier | null>(null);
  const [depth, setDepth] = useState<DepthData | null>(null);
  const [reserves, setReserves] = useState<ReservesData | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [leaderboardPeriod, setLeaderboardPeriod] = useState('30d');
  const [referralStats, setReferralStats] = useState<ReferralStats | null>(null);
  const [referralCodeInput, setReferralCodeInput] = useState('');
  const [referralMsg, setReferralMsg] = useState<string | null>(null);
  const [codeCopied, setCodeCopied] = useState(false);

  const [activeView, setActiveView] = useState<PanelView>('trade');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'limit' | 'market'>('limit');
  const [price, setPrice] = useState('');
  const [amount, setAmount] = useState('');
  const [orderStatus, setOrderStatus] = useState<string | null>(null);

  const [showDeposit, setShowDeposit] = useState(false);
  const [depositType, setDepositType] = useState<'usd' | 'auc'>('usd');
  const [depositAmount, setDepositAmount] = useState('');
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawType, setWithdrawType] = useState<'auc' | 'usd'>('auc');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawDest, setWithdrawDest] = useState('');

  const fetchAccount = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/account', { credentials: 'include' });
      if (res.ok) setAccount(await res.json());
    } catch {}
  }, []);

  const fetchOrderBook = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/orderbook?limit=10');
      if (res.ok) setOrderBook(await res.json());
    } catch {}
  }, []);

  const fetchOrders = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/orders', { credentials: 'include' });
      if (res.ok) setUserOrders(await res.json());
    } catch {}
  }, []);

  const fetchFeeTier = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/fee-tier', { credentials: 'include' });
      if (res.ok) setFeeTier(await res.json());
    } catch {}
  }, []);

  const fetchDepth = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/depth?limit=50');
      if (res.ok) setDepth(await res.json());
    } catch {}
  }, []);

  const fetchReserves = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/proof-of-reserves');
      if (res.ok) setReserves(await res.json());
    } catch {}
  }, []);

  const fetchLeaderboard = useCallback(async () => {
    try {
      const res = await fetch(`/api/exchange/leaderboard?period=${leaderboardPeriod}`);
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data.leaderboard || []);
      }
    } catch {}
  }, [leaderboardPeriod]);

  const fetchReferral = useCallback(async () => {
    try {
      const res = await fetch('/api/exchange/referral', { credentials: 'include' });
      if (res.ok) setReferralStats(await res.json());
    } catch {}
  }, []);

  useEffect(() => {
    fetchAccount();
    fetchOrderBook();
    const interval = setInterval(() => { fetchOrderBook(); fetchAccount(); }, 5000);
    return () => clearInterval(interval);
  }, [fetchAccount, fetchOrderBook]);

  useEffect(() => {
    if (activeView === 'orders') fetchOrders();
    if (activeView === 'fees') fetchFeeTier();
    if (activeView === 'depth') fetchDepth();
    if (activeView === 'reserves') fetchReserves();
    if (activeView === 'leaderboard') fetchLeaderboard();
    if (activeView === 'referral') fetchReferral();
  }, [activeView, fetchOrders, fetchFeeTier, fetchDepth, fetchReserves, fetchLeaderboard, fetchReferral]);

  useEffect(() => {
    if (currentPrice && !price) setPrice(currentPrice.toFixed(4));
  }, [currentPrice]);

  const placeOrder = async () => {
    try {
      setOrderStatus('Placing order...');
      const body: any = { side, orderType, amount: parseFloat(amount) };
      if (orderType === 'limit') body.price = parseFloat(price);
      const res = await fetch('/api/exchange/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (res.ok) {
        setOrderStatus('Order placed!');
        setAmount('');
        fetchAccount();
        fetchOrderBook();
        setTimeout(() => setOrderStatus(null), 3000);
      } else {
        setOrderStatus(data.error || 'Order failed');
        setTimeout(() => setOrderStatus(null), 5000);
      }
    } catch {
      setOrderStatus('Network error');
      setTimeout(() => setOrderStatus(null), 5000);
    }
  };

  const cancelOrder = async (orderId: number) => {
    try {
      const res = await fetch(`/api/exchange/order/${orderId}`, { method: 'DELETE', credentials: 'include' });
      if (res.ok) { fetchOrders(); fetchAccount(); fetchOrderBook(); }
    } catch {}
  };

  const handleDeposit = async () => {
    if (depositType === 'usd') {
      try {
        const res = await fetch('/api/exchange/deposit/usd/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ amount: parseFloat(depositAmount) }),
        });
        const data = await res.json();
        if (data.url) window.location.href = data.url;
      } catch {}
    } else {
      try {
        await fetch('/api/exchange/deposit/auc', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ amount: parseFloat(depositAmount) }),
        });
        fetchAccount();
        setShowDeposit(false);
        setDepositAmount('');
      } catch {}
    }
  };

  const handleWithdraw = async () => {
    try {
      const endpoint = withdrawType === 'auc' ? '/api/exchange/withdraw/auc' : '/api/exchange/withdraw/usd';
      await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ amount: parseFloat(withdrawAmount), destination: withdrawDest }),
      });
      fetchAccount();
      setShowWithdraw(false);
      setWithdrawAmount('');
      setWithdrawDest('');
    } catch {}
  };

  const exportTrades = async () => {
    try {
      const res = await fetch('/api/exchange/export/trades', { credentials: 'include' });
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'auc-trades.csv';
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch {}
  };

  const totalEst = orderType === 'market'
    ? (currentPrice && amount ? (currentPrice * parseFloat(amount || '0')).toFixed(2) : '0.00')
    : (price && amount ? (parseFloat(price) * parseFloat(amount || '0')).toFixed(2) : '0.00');

  const navItems: Array<{ id: PanelView; label: string; icon: any }> = [
    { id: 'trade', label: 'Trade', icon: ArrowUpDown },
    { id: 'orders', label: 'Orders', icon: Activity },
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'depth', label: 'Depth', icon: BarChart3 },
    { id: 'fees', label: 'Fees', icon: Layers },
    { id: 'leaderboard', label: 'Board', icon: Trophy },
    { id: 'reserves', label: 'Reserves', icon: Shield },
    { id: 'referral', label: 'Refer', icon: Users },
  ];

  return (
    <div className="bg-[#0d0d14] border border-amber-500/20 rounded-lg overflow-hidden text-[11px]" data-testid="auc-terminal-panel">
      <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/5 border-b border-amber-500/20 px-3 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-amber-400 font-bold text-sm">AUC</span>
          <span className="text-gray-400">/USD</span>
          {currentPrice && (
            <span className="text-white font-bold">${currentPrice.toFixed(4)}</span>
          )}
        </div>
        <button onClick={exportTrades} className="text-gray-500 hover:text-amber-400 transition-colors" title="Export trades CSV" data-testid="btn-export-trades">
          <Download size={14} />
        </button>
      </div>

      <div className="flex border-b border-gray-800 overflow-x-auto">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            data-testid={`tab-${item.id}`}
            className={`flex items-center gap-1 px-2 py-1.5 text-[10px] font-medium whitespace-nowrap transition-colors ${
              activeView === item.id ? 'text-amber-400 border-b border-amber-400 bg-amber-500/5' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <item.icon size={11} />
            {item.label}
          </button>
        ))}
      </div>

      <div className="p-3 max-h-[600px] overflow-y-auto">
        {activeView === 'trade' && (
          <div>
            <div className="flex gap-1 mb-3">
              <button onClick={() => setSide('buy')} data-testid="btn-buy-side"
                className={`flex-1 py-1.5 rounded text-[10px] font-bold transition-colors ${side === 'buy' ? 'bg-green-600 text-white' : 'bg-gray-800 text-gray-500'}`}>BUY</button>
              <button onClick={() => setSide('sell')} data-testid="btn-sell-side"
                className={`flex-1 py-1.5 rounded text-[10px] font-bold transition-colors ${side === 'sell' ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-500'}`}>SELL</button>
            </div>

            <div className="flex gap-1 mb-3">
              <button onClick={() => setOrderType('limit')} data-testid="btn-limit-type"
                className={`flex-1 py-1 rounded text-[10px] ${orderType === 'limit' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-gray-800 text-gray-500'}`}>Limit</button>
              <button onClick={() => setOrderType('market')} data-testid="btn-market-type"
                className={`flex-1 py-1 rounded text-[10px] ${orderType === 'market' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-gray-800 text-gray-500'}`}>Market</button>
            </div>

            {orderType === 'limit' && (
              <div className="mb-2">
                <label className="text-gray-500 text-[10px] mb-0.5 block">Price (USD)</label>
                <input type="number" step="0.0001" value={price} onChange={e => setPrice(e.target.value)} data-testid="input-price"
                  className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-white text-[11px] focus:border-amber-500/50 outline-none" />
              </div>
            )}

            <div className="mb-2">
              <label className="text-gray-500 text-[10px] mb-0.5 block">Amount (AUC)</label>
              <input type="number" step="0.001" value={amount} onChange={e => setAmount(e.target.value)} data-testid="input-amount"
                className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-white text-[11px] focus:border-amber-500/50 outline-none" />
              {account && (
                <div className="flex gap-1 mt-1">
                  {[25, 50, 75, 100].map(pct => (
                    <button key={pct} data-testid={`btn-pct-${pct}`}
                      onClick={() => {
                        const available = side === 'buy'
                          ? (price ? ((account.usdBalance - account.usdLocked) / parseFloat(price)) : 0)
                          : (account.aucBalance - account.aucLocked);
                        setAmount((available * pct / 100).toFixed(4));
                      }}
                      className="flex-1 py-0.5 bg-gray-800 hover:bg-gray-700 rounded text-[9px] text-gray-400">{pct}%</button>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-gray-900/50 rounded p-2 mb-3 text-[10px]">
              <div className="flex justify-between text-gray-400">
                <span>Total</span>
                <span className="text-white">${totalEst}</span>
              </div>
              {feeTier && (
                <div className="flex justify-between text-gray-500 mt-0.5">
                  <span>Fee ({side === 'buy' ? feeTier.takerFee : feeTier.makerFee})</span>
                  <span className="text-amber-400/60">{feeTier.currentTier}</span>
                </div>
              )}
            </div>

            <button onClick={placeOrder} data-testid="btn-place-order"
              disabled={!amount || parseFloat(amount) <= 0 || (orderType === 'limit' && (!price || parseFloat(price) <= 0))}
              className={`w-full py-2 rounded font-bold text-[11px] transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${
                side === 'buy' ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-red-600 hover:bg-red-500 text-white'
              }`}>
              {side === 'buy' ? 'Buy AUC' : 'Sell AUC'}
            </button>

            {orderStatus && (
              <div className={`mt-2 text-center text-[10px] ${orderStatus.includes('placed') ? 'text-green-400' : orderStatus.includes('error') || orderStatus.includes('failed') ? 'text-red-400' : 'text-amber-400'}`}>
                {orderStatus}
              </div>
            )}

            {orderBook && (
              <div className="mt-3">
                <div className="text-[10px] text-gray-500 mb-1 font-medium">Order Book</div>
                <div className="space-y-px">
                  {orderBook.asks.slice(0, 5).reverse().map((ask, i) => (
                    <div key={`a${i}`} className="flex justify-between text-[10px] px-1 py-0.5 relative">
                      <div className="absolute inset-0 bg-red-500/10 rounded" style={{ width: `${Math.min((ask.amount / (orderBook.asks[0]?.amount || 1)) * 100, 100)}%`, right: 0, left: 'auto' }} />
                      <span className="text-red-400 relative z-10">{ask.price.toFixed(4)}</span>
                      <span className="text-gray-400 relative z-10">{ask.amount.toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="flex justify-center py-1 text-[10px] border-y border-gray-800">
                    <span className="text-amber-400 font-bold">{currentPrice?.toFixed(4) || '---'}</span>
                    <span className="text-gray-600 ml-2">spread: {orderBook.spread.toFixed(4)}</span>
                  </div>
                  {orderBook.bids.slice(0, 5).map((bid, i) => (
                    <div key={`b${i}`} className="flex justify-between text-[10px] px-1 py-0.5 relative">
                      <div className="absolute inset-0 bg-green-500/10 rounded" style={{ width: `${Math.min((bid.amount / (orderBook.bids[0]?.amount || 1)) * 100, 100)}%`, right: 0, left: 'auto' }} />
                      <span className="text-green-400 relative z-10">{bid.price.toFixed(4)}</span>
                      <span className="text-gray-400 relative z-10">{bid.amount.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeView === 'orders' && (
          <div>
            <div className="text-gray-400 text-[10px] mb-2 font-medium">Your Orders</div>
            {userOrders.length === 0 ? (
              <div className="text-gray-600 text-center py-4 text-[10px]">No orders yet</div>
            ) : (
              <div className="space-y-1">
                {userOrders.slice(0, 20).map(order => (
                  <div key={order.id} className="bg-gray-900/50 rounded p-2 flex items-center justify-between" data-testid={`order-${order.id}`}>
                    <div>
                      <span className={`text-[10px] font-bold ${order.side === 'buy' ? 'text-green-400' : 'text-red-400'}`}>
                        {order.side.toUpperCase()} {order.orderType.toUpperCase()}
                      </span>
                      <div className="text-[9px] text-gray-500">
                        {order.amount.toFixed(4)} AUC @ ${order.price?.toFixed(4) || 'MKT'}
                      </div>
                      <div className="text-[9px] text-gray-600">
                        Filled: {order.filled.toFixed(4)} | {order.status}
                      </div>
                    </div>
                    {order.status === 'open' && (
                      <button onClick={() => cancelOrder(order.id)} className="text-red-500 hover:text-red-400" data-testid={`btn-cancel-${order.id}`}>
                        <X size={12} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeView === 'wallet' && (
          <div>
            {account ? (
              <>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="bg-gray-900/50 rounded p-2">
                    <div className="text-[9px] text-gray-500">AUC Balance</div>
                    <div className="text-amber-400 font-bold text-sm" data-testid="text-auc-balance">{account.aucBalance.toFixed(4)}</div>
                    {account.aucLocked > 0 && <div className="text-[9px] text-gray-600">Locked: {account.aucLocked.toFixed(4)}</div>}
                  </div>
                  <div className="bg-gray-900/50 rounded p-2">
                    <div className="text-[9px] text-gray-500">USD Balance</div>
                    <div className="text-green-400 font-bold text-sm" data-testid="text-usd-balance">${account.usdBalance.toFixed(2)}</div>
                    {account.usdLocked > 0 && <div className="text-[9px] text-gray-600">Locked: ${account.usdLocked.toFixed(2)}</div>}
                  </div>
                </div>
                {currentPrice && (
                  <div className="bg-amber-500/5 border border-amber-500/20 rounded p-2 mb-3 text-center">
                    <div className="text-[9px] text-gray-500">Portfolio Value</div>
                    <div className="text-white font-bold" data-testid="text-portfolio-value">
                      ${(account.usdBalance + account.aucBalance * currentPrice).toFixed(2)}
                    </div>
                  </div>
                )}
                <div className="flex gap-2">
                  <button onClick={() => setShowDeposit(true)} data-testid="btn-deposit"
                    className="flex-1 py-1.5 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded text-[10px] font-medium flex items-center justify-center gap-1">
                    <ArrowDownToLine size={11} /> Deposit
                  </button>
                  <button onClick={() => setShowWithdraw(true)} data-testid="btn-withdraw"
                    className="flex-1 py-1.5 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded text-[10px] font-medium flex items-center justify-center gap-1">
                    <ArrowUpFromLine size={11} /> Withdraw
                  </button>
                </div>

                {showDeposit && (
                  <div className="mt-3 bg-gray-900/80 border border-gray-700 rounded p-3">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300 text-[10px] font-medium">Deposit</span>
                      <button onClick={() => setShowDeposit(false)} className="text-gray-500"><X size={12} /></button>
                    </div>
                    <div className="flex gap-1 mb-2">
                      <button onClick={() => setDepositType('usd')} className={`flex-1 py-1 rounded text-[10px] ${depositType === 'usd' ? 'bg-green-600/20 text-green-400' : 'bg-gray-800 text-gray-500'}`}>USD (Stripe)</button>
                      <button onClick={() => setDepositType('auc')} className={`flex-1 py-1 rounded text-[10px] ${depositType === 'auc' ? 'bg-amber-600/20 text-amber-400' : 'bg-gray-800 text-gray-500'}`}>AUC</button>
                    </div>
                    <input type="number" value={depositAmount} onChange={e => setDepositAmount(e.target.value)} placeholder="Amount"
                      className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-white text-[11px] mb-2 outline-none focus:border-amber-500/50" />
                    <button onClick={handleDeposit} disabled={!depositAmount || parseFloat(depositAmount) <= 0}
                      className="w-full py-1.5 bg-green-600 hover:bg-green-500 disabled:opacity-40 rounded text-[10px] font-bold text-white">Deposit</button>
                  </div>
                )}

                {showWithdraw && (
                  <div className="mt-3 bg-gray-900/80 border border-gray-700 rounded p-3">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300 text-[10px] font-medium">Withdraw</span>
                      <button onClick={() => setShowWithdraw(false)} className="text-gray-500"><X size={12} /></button>
                    </div>
                    <div className="flex gap-1 mb-2">
                      <button onClick={() => setWithdrawType('auc')} className={`flex-1 py-1 rounded text-[10px] ${withdrawType === 'auc' ? 'bg-amber-600/20 text-amber-400' : 'bg-gray-800 text-gray-500'}`}>AUC</button>
                      <button onClick={() => setWithdrawType('usd')} className={`flex-1 py-1 rounded text-[10px] ${withdrawType === 'usd' ? 'bg-green-600/20 text-green-400' : 'bg-gray-800 text-gray-500'}`}>USD</button>
                    </div>
                    <input type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)} placeholder="Amount"
                      className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-white text-[11px] mb-2 outline-none focus:border-amber-500/50" />
                    <input type="text" value={withdrawDest} onChange={e => setWithdrawDest(e.target.value)} placeholder={withdrawType === 'auc' ? 'AUC Wallet Address' : 'Bank/PayPal'}
                      className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-white text-[11px] mb-2 outline-none focus:border-amber-500/50" />
                    <div className="text-[9px] text-gray-600 mb-2">Fee: {withdrawType === 'auc' ? '0.5 AUC' : '$2.00'}</div>
                    <button onClick={handleWithdraw} disabled={!withdrawAmount || parseFloat(withdrawAmount) <= 0 || !withdrawDest}
                      className="w-full py-1.5 bg-red-600 hover:bg-red-500 disabled:opacity-40 rounded text-[10px] font-bold text-white">Withdraw</button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-4">
                <div className="text-gray-500 text-[10px] mb-2">Log in to view your wallet</div>
              </div>
            )}
          </div>
        )}

        {activeView === 'depth' && (
          <div>
            <div className="text-gray-400 text-[10px] mb-2 font-medium flex items-center gap-1">
              <BarChart3 size={11} /> Market Depth
            </div>
            {depth ? (
              <div>
                <div className="relative h-32 mb-3 bg-gray-900/50 rounded overflow-hidden">
                  <svg viewBox="0 0 400 120" className="w-full h-full" preserveAspectRatio="none">
                    {(() => {
                      const maxBidTotal = Math.max(...depth.bids.map(b => b.total), 1);
                      const maxAskTotal = Math.max(...depth.asks.map(a => a.total), 1);
                      const maxTotal = Math.max(maxBidTotal, maxAskTotal);
                      const bidPoints = depth.bids.map((b, i) => {
                        const x = 200 - (i / depth.bids.length) * 200;
                        const y = 120 - (b.total / maxTotal) * 110;
                        return `${x},${y}`;
                      }).join(' ');
                      const askPoints = depth.asks.map((a, i) => {
                        const x = 200 + (i / depth.asks.length) * 200;
                        const y = 120 - (a.total / maxTotal) * 110;
                        return `${x},${y}`;
                      }).join(' ');
                      return (
                        <>
                          <polygon points={`200,120 ${bidPoints} ${200 - (depth.bids.length > 0 ? 200 : 0)},120`} fill="rgba(34,197,94,0.15)" stroke="rgba(34,197,94,0.5)" strokeWidth="1" />
                          <polygon points={`200,120 ${askPoints} ${200 + (depth.asks.length > 0 ? 200 : 0)},120`} fill="rgba(239,68,68,0.15)" stroke="rgba(239,68,68,0.5)" strokeWidth="1" />
                          <line x1="200" y1="0" x2="200" y2="120" stroke="rgba(251,191,36,0.3)" strokeWidth="1" strokeDasharray="3,3" />
                        </>
                      );
                    })()}
                  </svg>
                  <div className="absolute bottom-1 left-2 text-[9px] text-green-400/60">Bids</div>
                  <div className="absolute bottom-1 right-2 text-[9px] text-red-400/60">Asks</div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[9px]">
                  <div>
                    <div className="text-green-400 font-medium mb-1">Buy Wall</div>
                    {depth.bids.slice(0, 5).map((b, i) => (
                      <div key={i} className="flex justify-between text-gray-400">
                        <span>${b.price.toFixed(4)}</span>
                        <span>{b.total.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                  <div>
                    <div className="text-red-400 font-medium mb-1">Sell Wall</div>
                    {depth.asks.slice(0, 5).map((a, i) => (
                      <div key={i} className="flex justify-between text-gray-400">
                        <span>${a.price.toFixed(4)}</span>
                        <span>{a.total.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-gray-600 text-center py-4">Loading depth data...</div>
            )}
          </div>
        )}

        {activeView === 'fees' && (
          <div>
            <div className="text-gray-400 text-[10px] mb-2 font-medium flex items-center gap-1">
              <Layers size={11} /> Fee Tiers (Maker/Taker)
            </div>
            {feeTier ? (
              <>
                <div className="bg-amber-500/5 border border-amber-500/20 rounded p-2 mb-3">
                  <div className="text-[9px] text-gray-500">Your Tier</div>
                  <div className="text-amber-400 font-bold text-sm">{feeTier.currentTier}</div>
                  <div className="text-[9px] text-gray-400">Maker: {feeTier.makerFee} | Taker: {feeTier.takerFee}</div>
                  <div className="text-[9px] text-gray-500">30d Volume: ${feeTier.volume30d.toLocaleString()}</div>
                </div>
                <div className="space-y-1">
                  {feeTier.allTiers.map(t => (
                    <div key={t.tier} className={`flex items-center justify-between p-1.5 rounded text-[10px] ${
                      t.tier === feeTier.currentTier ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-gray-900/30'
                    }`}>
                      <div>
                        <span className={t.tier === feeTier.currentTier ? 'text-amber-400 font-bold' : 'text-gray-300'}>{t.tier}</span>
                        <span className="text-gray-600 ml-1">≥${t.minVolume.toLocaleString()}</span>
                      </div>
                      <div className="text-gray-400">
                        {t.maker}% / {t.taker}%
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="text-gray-600 text-center py-4">Log in to view fee tier</div>
            )}
          </div>
        )}

        {activeView === 'leaderboard' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-400 text-[10px] font-medium flex items-center gap-1">
                <Trophy size={11} /> Trading Leaderboard
              </div>
              <div className="flex gap-1">
                {['24h', '7d', '30d'].map(p => (
                  <button key={p} onClick={() => setLeaderboardPeriod(p)} data-testid={`btn-lb-${p}`}
                    className={`px-1.5 py-0.5 rounded text-[9px] ${leaderboardPeriod === p ? 'bg-amber-500/20 text-amber-400' : 'bg-gray-800 text-gray-500'}`}>{p}</button>
                ))}
              </div>
            </div>
            {leaderboard.length === 0 ? (
              <div className="text-gray-600 text-center py-4 text-[10px]">No trading activity in this period</div>
            ) : (
              <div className="space-y-1">
                {leaderboard.map(entry => (
                  <div key={entry.rank} className={`flex items-center justify-between p-1.5 rounded text-[10px] ${
                    entry.rank <= 3 ? 'bg-amber-500/5 border border-amber-500/10' : 'bg-gray-900/30'
                  }`} data-testid={`lb-entry-${entry.rank}`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-5 text-center font-bold ${
                        entry.rank === 1 ? 'text-yellow-400' : entry.rank === 2 ? 'text-gray-300' : entry.rank === 3 ? 'text-amber-600' : 'text-gray-500'
                      }`}>{entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `#${entry.rank}`}</span>
                      <span className="text-gray-300 font-mono">{entry.userId}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-white font-medium">${entry.volume.toLocaleString()}</div>
                      <div className="text-[9px] text-gray-500">{entry.trades} trades</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeView === 'reserves' && (
          <div>
            <div className="text-gray-400 text-[10px] mb-2 font-medium flex items-center gap-1">
              <Shield size={11} /> Proof of Reserves
            </div>
            {reserves ? (
              <>
                <div className={`flex items-center gap-2 p-2 rounded mb-3 ${reserves.verified ? 'bg-green-500/10 border border-green-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
                  {reserves.verified ? <CheckCircle2 size={14} className="text-green-400" /> : <AlertTriangle size={14} className="text-red-400" />}
                  <div>
                    <div className={`text-[10px] font-bold ${reserves.verified ? 'text-green-400' : 'text-red-400'}`}>
                      {reserves.verified ? 'Reserves Verified' : 'Unverified'}
                    </div>
                    <div className="text-[9px] text-gray-500">{new Date(reserves.timestamp).toLocaleString()}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="bg-gray-900/50 rounded p-2">
                    <div className="text-amber-400 text-[10px] font-bold mb-1">AUC Reserves</div>
                    <div className="grid grid-cols-2 gap-1 text-[9px]">
                      <div><span className="text-gray-500">Reserve:</span> <span className="text-white">{reserves.auc.reserve.toLocaleString()}</span></div>
                      <div><span className="text-gray-500">Liability:</span> <span className="text-white">{reserves.auc.liability.toLocaleString()}</span></div>
                      <div><span className="text-gray-500">Ratio:</span> <span className={reserves.auc.ratio >= 1 ? 'text-green-400' : 'text-red-400'}>{(reserves.auc.ratio * 100).toFixed(1)}%</span></div>
                      <div><span className="text-gray-500">Locked:</span> <span className="text-gray-300">{reserves.auc.locked.toLocaleString()}</span></div>
                    </div>
                  </div>

                  <div className="bg-gray-900/50 rounded p-2">
                    <div className="text-green-400 text-[10px] font-bold mb-1">USD Reserves</div>
                    <div className="grid grid-cols-2 gap-1 text-[9px]">
                      <div><span className="text-gray-500">Reserve:</span> <span className="text-white">${reserves.usd.reserve.toLocaleString()}</span></div>
                      <div><span className="text-gray-500">Liability:</span> <span className="text-white">${reserves.usd.liability.toLocaleString()}</span></div>
                      <div><span className="text-gray-500">Ratio:</span> <span className={reserves.usd.ratio >= 1 ? 'text-green-400' : 'text-red-400'}>{(reserves.usd.ratio * 100).toFixed(1)}%</span></div>
                      <div><span className="text-gray-500">Locked:</span> <span className="text-gray-300">${reserves.usd.locked.toLocaleString()}</span></div>
                    </div>
                  </div>

                  <div className="bg-gray-900/30 rounded p-2 text-center">
                    <div className="text-[9px] text-gray-500">Total Accounts</div>
                    <div className="text-white font-bold text-sm" data-testid="text-reserve-accounts">{reserves.accounts}</div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-gray-600 text-center py-4">Loading reserves data...</div>
            )}
          </div>
        )}
        {activeView === 'referral' && (
          <div>
            <div className="text-gray-400 text-[10px] mb-2 font-medium flex items-center gap-1">
              <Users size={11} /> Referral Program
            </div>
            <div className="bg-amber-500/5 border border-amber-500/20 rounded p-2 mb-3">
              <div className="text-[9px] text-gray-500 mb-0.5">Earn 20% of trading fees from referred users</div>
              <div className="text-amber-400 text-[10px] font-bold">Share your code, earn every time they trade</div>
            </div>

            {referralStats ? (
              <>
                <div className="bg-gray-900/50 rounded p-2 mb-3">
                  <div className="text-[9px] text-gray-500 mb-1">Your Referral Code</div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold text-sm font-mono tracking-wider" data-testid="text-referral-code">{referralStats.code}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(referralStats.code);
                        setCodeCopied(true);
                        setTimeout(() => setCodeCopied(false), 2000);
                      }}
                      className="text-[9px] px-2 py-0.5 bg-amber-500/20 text-amber-400 rounded hover:bg-amber-500/30"
                      data-testid="btn-copy-referral"
                    >
                      {codeCopied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1 mb-3">
                  <div className="bg-gray-900/50 rounded p-2 text-center">
                    <div className="text-[9px] text-gray-500">Referrals</div>
                    <div className="text-white font-bold" data-testid="text-total-referrals">{referralStats.totalReferrals}</div>
                  </div>
                  <div className="bg-gray-900/50 rounded p-2 text-center">
                    <div className="text-[9px] text-gray-500">Earned</div>
                    <div className="text-green-400 font-bold" data-testid="text-total-earnings">${referralStats.totalEarnings.toFixed(2)}</div>
                  </div>
                  <div className="bg-gray-900/50 rounded p-2 text-center">
                    <div className="text-[9px] text-gray-500">Fee Share</div>
                    <div className="text-amber-400 font-bold">{referralStats.feeSharePercent}%</div>
                  </div>
                </div>

                {!referralStats.hasReferrer && (
                  <div className="bg-gray-900/50 rounded p-2 mb-3">
                    <div className="text-[9px] text-gray-500 mb-1">Enter a Referral Code</div>
                    <div className="flex gap-1">
                      <input
                        type="text"
                        value={referralCodeInput}
                        onChange={e => setReferralCodeInput(e.target.value.toUpperCase())}
                        placeholder="AUC..."
                        className="flex-1 bg-gray-900 border border-gray-700 rounded px-2 py-1 text-white text-[10px] outline-none focus:border-amber-500/50 font-mono"
                        data-testid="input-referral-code"
                      />
                      <button
                        onClick={async () => {
                          try {
                            const res = await fetch('/api/exchange/referral/apply', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              credentials: 'include',
                              body: JSON.stringify({ code: referralCodeInput }),
                            });
                            const data = await res.json();
                            if (res.ok) {
                              setReferralMsg('Referral code applied!');
                              setReferralCodeInput('');
                              fetchReferral();
                            } else {
                              setReferralMsg(data.error || 'Invalid code');
                            }
                            setTimeout(() => setReferralMsg(null), 4000);
                          } catch {
                            setReferralMsg('Network error');
                            setTimeout(() => setReferralMsg(null), 4000);
                          }
                        }}
                        disabled={!referralCodeInput}
                        className="px-3 py-1 bg-amber-500/20 text-amber-400 rounded text-[10px] font-bold hover:bg-amber-500/30 disabled:opacity-40"
                        data-testid="btn-apply-referral"
                      >
                        Apply
                      </button>
                    </div>
                    {referralMsg && (
                      <div className={`text-[9px] mt-1 ${referralMsg.includes('applied') ? 'text-green-400' : 'text-red-400'}`}>{referralMsg}</div>
                    )}
                  </div>
                )}

                {referralStats.referrals.length > 0 && (
                  <div className="mb-3">
                    <div className="text-[9px] text-gray-500 mb-1 font-medium">Your Referrals</div>
                    <div className="space-y-1">
                      {referralStats.referrals.map((r, i) => (
                        <div key={i} className="bg-gray-900/30 rounded p-1.5 flex justify-between items-center">
                          <div>
                            <span className="text-gray-300 font-mono text-[10px]">{r.referredId}</span>
                            <div className="text-[9px] text-gray-600">{r.trades} trades</div>
                          </div>
                          <span className="text-green-400 text-[10px] font-bold">${r.earnings.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {referralStats.recentEarnings.length > 0 && (
                  <div>
                    <div className="text-[9px] text-gray-500 mb-1 font-medium">Recent Earnings</div>
                    <div className="space-y-0.5">
                      {referralStats.recentEarnings.slice(0, 10).map((e, i) => (
                        <div key={i} className="flex justify-between text-[9px] px-1">
                          <span className="text-gray-500">{new Date(e.date).toLocaleDateString()}</span>
                          <span className="text-green-400">+${e.amount.toFixed(4)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-gray-600 text-center py-4 text-[10px]">Sign in to access referrals</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
