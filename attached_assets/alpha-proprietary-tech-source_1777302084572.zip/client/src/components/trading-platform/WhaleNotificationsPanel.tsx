/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha WhaleNotificationsPanel™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_c37c0e69a52ea174c8a497f1
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell, BellRing, Wallet, TrendingUp, TrendingDown, AlertTriangle,
  Settings, X, Check, Volume2, VolumeX, Filter, ChevronRight,
  ExternalLink, Eye, EyeOff, Zap, DollarSign, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

interface WhaleAlert {
  id: string;
  type: 'buy' | 'sell' | 'transfer' | 'accumulation' | 'distribution';
  token: string;
  tokenIcon: string;
  amount: number;
  value: number;
  walletAddress: string;
  walletLabel?: string;
  timestamp: Date;
  txHash: string;
  chain: string;
  isSmartMoney: boolean;
  significance: 'low' | 'medium' | 'high' | 'critical';
}

interface NotificationSettings {
  enabled: boolean;
  minValue: number;
  types: {
    buy: boolean;
    sell: boolean;
    transfer: boolean;
    accumulation: boolean;
    distribution: boolean;
  };
  chains: string[];
  smartMoneyOnly: boolean;
  soundEnabled: boolean;
}

const CHAINS = ['Ethereum', 'Solana', 'BSC', 'Polygon', 'Arbitrum', 'Base', 'Bitcoin'];

const STORAGE_KEY = 'alpha-whale-notification-settings';

export function WhaleNotificationsPanel() {
  const [alerts, setAlerts] = useState<WhaleAlert[]>([]);
  const [showDemo, setShowDemo] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);
  const [settings, setSettings] = useState<NotificationSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return getDefaultSettings();
      }
    }
    return getDefaultSettings();
  });

  function getDefaultSettings(): NotificationSettings {
    return {
      enabled: true,
      minValue: 100000,
      types: {
        buy: true,
        sell: true,
        transfer: true,
        accumulation: true,
        distribution: true,
      },
      chains: CHAINS,
      smartMoneyOnly: false,
      soundEnabled: true,
    };
  }

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  const loadDemoAlerts = useCallback(() => {
    const demoAlerts: WhaleAlert[] = [
      {
        id: '1',
        type: 'buy',
        token: 'ETH',
        tokenIcon: '⟠',
        amount: 5000,
        value: 15000000,
        walletAddress: '0x28C6...a9E2',
        walletLabel: 'Jump Trading',
        timestamp: new Date(Date.now() - 120000),
        txHash: '0xabc123...',
        chain: 'Ethereum',
        isSmartMoney: true,
        significance: 'critical',
      },
      {
        id: '2',
        type: 'accumulation',
        token: 'SOL',
        tokenIcon: '◎',
        amount: 250000,
        value: 8500000,
        walletAddress: 'DRpb...kF7x',
        walletLabel: 'Alameda Research',
        timestamp: new Date(Date.now() - 300000),
        txHash: '5xyz789...',
        chain: 'Solana',
        isSmartMoney: true,
        significance: 'high',
      },
      {
        id: '3',
        type: 'sell',
        token: 'PEPE',
        tokenIcon: '🐸',
        amount: 50000000000,
        value: 450000,
        walletAddress: '0x7f3D...b4C1',
        timestamp: new Date(Date.now() - 600000),
        txHash: '0xdef456...',
        chain: 'Ethereum',
        isSmartMoney: false,
        significance: 'medium',
      },
      {
        id: '4',
        type: 'transfer',
        token: 'BTC',
        tokenIcon: '₿',
        amount: 500,
        value: 22500000,
        walletAddress: 'bc1q...m8v2',
        walletLabel: 'Unknown Whale',
        timestamp: new Date(Date.now() - 900000),
        txHash: 'abc...xyz',
        chain: 'Bitcoin',
        isSmartMoney: false,
        significance: 'critical',
      },
      {
        id: '5',
        type: 'distribution',
        token: 'ARB',
        tokenIcon: '🔵',
        amount: 2000000,
        value: 1800000,
        walletAddress: '0x9aB3...d7E4',
        walletLabel: 'VC Fund',
        timestamp: new Date(Date.now() - 1200000),
        txHash: '0xghi789...',
        chain: 'Arbitrum',
        isSmartMoney: true,
        significance: 'high',
      },
    ];
    setAlerts(demoAlerts);
    setUnreadCount(demoAlerts.length);
    setShowDemo(true);
    toast.success('Demo whale alerts loaded');
  }, []);

  const getTypeIcon = (type: WhaleAlert['type']) => {
    switch (type) {
      case 'buy': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'sell': return <TrendingDown className="w-4 h-4 text-red-400" />;
      case 'transfer': return <Wallet className="w-4 h-4 text-blue-400" />;
      case 'accumulation': return <Activity className="w-4 h-4 text-purple-400" />;
      case 'distribution': return <AlertTriangle className="w-4 h-4 text-orange-400" />;
    }
  };

  const getSignificanceColor = (sig: WhaleAlert['significance']) => {
    switch (sig) {
      case 'critical': return 'border-red-500/50 bg-red-500/10';
      case 'high': return 'border-orange-500/50 bg-orange-500/10';
      case 'medium': return 'border-yellow-500/50 bg-yellow-500/10';
      case 'low': return 'border-gray-500/50 bg-gray-500/10';
    }
  };

  const formatValue = (value: number) => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  };

  const formatTimeAgo = (date: Date) => {
    const minutes = Math.floor((Date.now() - date.getTime()) / 60000);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const markAllRead = () => {
    setUnreadCount(0);
    toast.success('All alerts marked as read');
  };

  const clearAlerts = () => {
    setAlerts([]);
    setUnreadCount(0);
    setShowDemo(false);
    toast.success('Alerts cleared');
  };

  if (alerts.length === 0 && !showDemo) {
    return (
      <div className="tp-card p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#00D4FF]" />
            <h3 className="text-lg font-semibold text-white">Whale Notifications</h3>
          </div>
        </div>
        <div className="text-center py-8">
          <BellRing className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 mb-2">No whale alerts yet</p>
          <p className="text-sm text-gray-500 mb-4">
            Get real-time notifications when whales and smart money make significant moves
          </p>
          <Button
            onClick={loadDemoAlerts}
            className="bg-[#00D4FF]/20 hover:bg-[#00D4FF]/30 text-[#00D4FF]"
          >
            <Eye className="w-4 h-4 mr-2" />
            View Demo Alerts
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="tp-card p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Bell className="w-5 h-5 text-[#00D4FF]" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center text-white">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </div>
          <h3 className="text-lg font-semibold text-white">Whale Alerts</h3>
          {showDemo && (
            <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs rounded">
              Demo
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllRead}
              className="text-xs text-gray-400 hover:text-white"
            >
              <Check className="w-3 h-3 mr-1" />
              Mark Read
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSettings(!showSettings)}
            className="text-gray-400 hover:text-white"
          >
            <Settings className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAlerts}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mb-4 p-3 bg-[#0A1628]/50 rounded-lg border border-white/5"
          >
            <h4 className="text-sm font-medium text-white mb-3">Notification Settings</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Notifications Enabled</span>
                <Switch
                  checked={settings.enabled}
                  onCheckedChange={(enabled) => setSettings({ ...settings, enabled })}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Sound Alerts</span>
                <Switch
                  checked={settings.soundEnabled}
                  onCheckedChange={(soundEnabled) => setSettings({ ...settings, soundEnabled })}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Smart Money Only</span>
                <Switch
                  checked={settings.smartMoneyOnly}
                  onCheckedChange={(smartMoneyOnly) => setSettings({ ...settings, smartMoneyOnly })}
                />
              </div>
              <div>
                <span className="text-sm text-gray-400 block mb-2">Min Transaction Value</span>
                <div className="flex gap-2">
                  {[50000, 100000, 500000, 1000000].map(val => (
                    <button
                      key={val}
                      onClick={() => setSettings({ ...settings, minValue: val })}
                      className={`px-2 py-1 text-xs rounded ${
                        settings.minValue === val
                          ? 'bg-[#00D4FF] text-black'
                          : 'bg-white/5 text-gray-400 hover:bg-white/10'
                      }`}
                    >
                      {formatValue(val)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-sm text-gray-400 block mb-2">Alert Types</span>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(settings.types).map(([type, enabled]) => (
                    <button
                      key={type}
                      onClick={() => setSettings({
                        ...settings,
                        types: { ...settings.types, [type]: !enabled }
                      })}
                      className={`px-2 py-1 text-xs rounded capitalize ${
                        enabled
                          ? 'bg-[#00D4FF]/20 text-[#00D4FF]'
                          : 'bg-white/5 text-gray-500'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-2 max-h-80 overflow-y-auto">
        {alerts
          .filter(alert => {
            if (settings.smartMoneyOnly && !alert.isSmartMoney) return false;
            if (alert.value < settings.minValue) return false;
            if (!settings.types[alert.type]) return false;
            return true;
          })
          .map((alert, idx) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className={`p-3 rounded-lg border ${getSignificanceColor(alert.significance)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{alert.tokenIcon}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      {getTypeIcon(alert.type)}
                      <span className="text-white font-medium capitalize">{alert.type}</span>
                      <span className="text-gray-400">{alert.token}</span>
                      {alert.isSmartMoney && (
                        <span className="px-1.5 py-0.5 bg-purple-500/20 text-purple-400 text-[10px] rounded flex items-center gap-1">
                          <Zap className="w-2.5 h-2.5" /> Smart Money
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500 mt-0.5">
                      {alert.walletLabel || alert.walletAddress} • {alert.chain}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">{formatValue(alert.value)}</div>
                  <div className="text-xs text-gray-500">{formatTimeAgo(alert.timestamp)}</div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                <span className="text-xs text-gray-500">
                  {alert.amount.toLocaleString()} {alert.token}
                </span>
                <a
                  href={`https://etherscan.io/tx/${alert.txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#00D4FF] hover:underline flex items-center gap-1"
                >
                  View TX <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </motion.div>
          ))}
      </div>
    </div>
  );
}
