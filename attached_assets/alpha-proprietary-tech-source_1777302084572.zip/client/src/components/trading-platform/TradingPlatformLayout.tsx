/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TradingPlatformLayout™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_1493c30a535e313ef5d020fb
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { ReactNode, useRef, useEffect, useCallback, useState, lazy, Suspense } from "react";
import { TradingPlatformNavbar } from "./TradingPlatformNavbar";
const TradingPlatformFooter = lazy(() => import("./TradingPlatformFooter").then(m => ({ default: m.TradingPlatformFooter })));
import "@/styles/trading-platform.css";

const PWAInstallPrompt = lazy(() => import("./PWAInstallPrompt"));
const VoiceCommandWidget = lazy(() => import("./VoiceCommandWidget").then(m => ({ default: m.VoiceCommandWidget })));

const COLORS = {
  gold: { r: 255, g: 215, b: 0 },
  cyan: { r: 0, g: 212, b: 255 },
  purple: { r: 168, g: 85, b: 247 },
};
const COLOR_LIST = [COLORS.gold, COLORS.cyan, COLORS.purple];
const MATRIX_CHARS = "ALPHAUNLIMITED∞01αΩ∑πΔ₿◊⬡⟁";

function TradingCosmicCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const timeRef = useRef(0);
  const particlesRef = useRef<any[]>([]);
  const matrixRef = useRef<any[]>([]);
  const ringsRef = useRef<any[]>([]);

  const initParticles = useCallback((w: number, h: number) => {
    const particles: any[] = [];
    const count = Math.min(Math.floor((w * h) / 20000), 60);
    for (let i = 0; i < count; i++) {
      const c = COLOR_LIST[Math.floor(Math.random() * 3)];
      const type = Math.random() < 0.8 ? "star" : "energy";
      particles.push({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.2, vy: (Math.random() - 0.5) * 0.2,
        size: type === "energy" ? 2 + Math.random() * 3 : 0.5 + Math.random() * 1.5,
        opacity: 0.3 + Math.random() * 0.5,
        r: c.r, g: c.g, b: c.b, life: Math.random() * 1000, maxLife: 500 + Math.random() * 1000, type,
      });
    }
    particlesRef.current = particles;
  }, []);

  const initMatrix = useCallback((w: number, h: number) => {
    const chars: any[] = [];
    const count = Math.min(Math.floor(w / 60), 15);
    for (let i = 0; i < count; i++) {
      chars.push({
        x: Math.random() * w, y: Math.random() * h,
        char: MATRIX_CHARS[Math.floor(Math.random() * MATRIX_CHARS.length)],
        speed: 0.3 + Math.random() * 0.8, opacity: 0, fadeSpeed: 0.005 + Math.random() * 0.01,
        size: 10 + Math.random() * 6,
      });
    }
    matrixRef.current = chars;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    if (!ctx) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = window.innerWidth + "px";
      canvas.style.height = window.innerHeight + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      initParticles(window.innerWidth, window.innerHeight);
      initMatrix(window.innerWidth, window.innerHeight);
    };

    const startDelay = setTimeout(() => {
      resize();
      window.addEventListener("resize", resize);
      startAnimation();
    }, 100);

    function startAnimation() {

    const draw = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      timeRef.current++;
      ctx.clearRect(0, 0, w, h);

      for (const mc of matrixRef.current) {
        mc.y += mc.speed;
        mc.opacity += mc.fadeSpeed;
        if (mc.opacity > 1) mc.fadeSpeed = -Math.abs(mc.fadeSpeed);
        if (mc.opacity < 0 || mc.y > h) {
          mc.y = -20; mc.x = Math.random() * w; mc.opacity = 0;
          mc.fadeSpeed = Math.abs(mc.fadeSpeed);
          mc.char = MATRIX_CHARS[Math.floor(Math.random() * MATRIX_CHARS.length)];
        }
        ctx.font = `${mc.size}px monospace`;
        ctx.fillStyle = `rgba(255,215,0,${mc.opacity * 0.15})`;
        ctx.fillText(mc.char, mc.x, mc.y);
      }

      for (const p of particlesRef.current) {
        p.x += p.vx; p.y += p.vy; p.life++;
        if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
        if (p.type === "energy") {
          const pulse = 0.5 + Math.sin(timeRef.current * 0.05 + p.life) * 0.5;
          ctx.fillStyle = `rgba(${p.r},${p.g},${p.b},${pulse * 0.6})`;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * 1.5, 0, Math.PI * 2); ctx.fill();
        } else {
          const twinkle = 0.3 + Math.sin(p.x * 0.01 + timeRef.current * 0.03) * 0.3;
          ctx.fillStyle = `rgba(255,255,255,${twinkle})`;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
        }
      }

      if (timeRef.current % 180 === 0) {
        const c = COLOR_LIST[Math.floor(Math.random() * 3)];
        ringsRef.current.push({ x: Math.random() * w, y: Math.random() * h, radius: 0, opacity: 0.2, r: c.r, g: c.g, b: c.b, speed: 0.4 + Math.random() * 0.4 });
      }
      ringsRef.current = ringsRef.current.filter(ring => {
        ring.radius += ring.speed; ring.opacity *= 0.98;
        if (ring.opacity < 0.01) return false;
        ctx.strokeStyle = `rgba(${ring.r},${ring.g},${ring.b},${ring.opacity})`;
        ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(ring.x, ring.y, ring.radius, 0, Math.PI * 2); ctx.stroke();
        return true;
      });

      animRef.current = requestAnimationFrame(draw);
    };
    animRef.current = requestAnimationFrame(draw);
    }

    return () => { clearTimeout(startDelay); cancelAnimationFrame(animRef.current); window.removeEventListener("resize", resize); };
  }, [initParticles, initMatrix]);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none" style={{ zIndex: 1, background: "transparent" }} />;
}

interface TradingPlatformLayoutProps {
  children: ReactNode;
  hideFooter?: boolean;
}

export function TradingPlatformLayout({ children, hideFooter }: TradingPlatformLayoutProps) {
  const [showCanvas, setShowCanvas] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowCanvas(true), 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="trading-platform overflow-x-hidden relative">
      <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 0 }}>
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(-45deg, #0a0e1a, #0D1117, #0f1923, #0D1117)", backgroundSize: "400% 400%", animation: "alphaGradientShift 20s ease infinite" }} />
        <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,215,0,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,215,0,0.04) 1px, transparent 1px)", backgroundSize: "60px 60px", animation: "alphaGridMove 30s linear infinite" }} />
        <div style={{ position: "absolute", top: "10%", left: "20%", width: "40vw", height: "40vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(255,215,0,0.06) 0%, transparent 70%)", animation: "alphaFloat1 12s ease-in-out infinite" }} />
        <div style={{ position: "absolute", bottom: "15%", right: "10%", width: "35vw", height: "35vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(0,212,255,0.05) 0%, transparent 70%)", animation: "alphaFloat2 15s ease-in-out infinite" }} />
        <div style={{ position: "absolute", top: "50%", left: "60%", width: "30vw", height: "30vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(168,85,247,0.04) 0%, transparent 70%)", animation: "alphaFloat3 18s ease-in-out infinite" }} />
      </div>
      {showCanvas && <TradingCosmicCanvas />}
      <style>{`
        @keyframes alphaGradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        @keyframes alphaGridMove { 0% { transform: translate(0, 0); } 100% { transform: translate(60px, 60px); } }
        @keyframes alphaFloat1 { 0%, 100% { transform: translate(0, 0) scale(1); } 33% { transform: translate(30px, -20px) scale(1.1); } 66% { transform: translate(-20px, 15px) scale(0.95); } }
        @keyframes alphaFloat2 { 0%, 100% { transform: translate(0, 0) scale(1); } 33% { transform: translate(-25px, 20px) scale(1.05); } 66% { transform: translate(15px, -30px) scale(1.1); } }
        @keyframes alphaFloat3 { 0%, 100% { transform: translate(0, 0) scale(1); } 50% { transform: translate(20px, -15px) scale(1.08); } }
      `}</style>
      <div className="relative" style={{ zIndex: 2 }}>
        <TradingPlatformNavbar />
        <main className="min-h-screen px-3 sm:px-4 md:px-6 lg:px-8 pt-16 sm:pt-20">
          {children}
        </main>
        {!hideFooter && <Suspense fallback={null}><TradingPlatformFooter /></Suspense>}
        <Suspense fallback={null}>
          <PWAInstallPrompt />
          <VoiceCommandWidget />
        </Suspense>
      </div>
    </div>
  );
}
