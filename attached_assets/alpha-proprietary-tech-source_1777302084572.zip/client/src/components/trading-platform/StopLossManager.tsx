/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha StopLossManager™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_5b6a7b05f88d2946b0c7dc4a
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Shield, ShieldAlert, ShieldCheck, X, ChevronDown, ChevronUp,
  TrendingDown, TrendingUp, Target, Clock, AlertTriangle,
  DollarSign, Percent, Activity, BarChart3, Zap, Lock,
  ArrowDown, ArrowUp, Bell, BellRing, Minus, Plus, RefreshCw,
  Eye, EyeOff, Settings, Info, CheckCircle2, GripVertical
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

type StopType = "fixed" | "trailing" | "breakeven" | "time_based";
type StopStatus = "active" | "triggered" | "cancelled" | "expired" | "moved_to_breakeven";

interface StopLossOrder {
  id: string;
  positionId?: string;
  symbol: string;
  side: "long" | "short";
  entryPrice: number;
  stopPrice: number;
  stopType: StopType;
  trailPercent?: number;
  trailAmount?: number;
  highestPrice?: number;
  lowestPrice?: number;
  breakevenTriggerPercent?: number;
  breakevenActivated?: boolean;
  timeExpiryMs?: number;
  createdAt: number;
  status: StopStatus;
  amount: number;
  maxLossUsd: number;
  riskPercent: number;
  alertEnabled: boolean;
  notes?: string;
}

interface StopLossManagerProps {
  currentPrice: number | null;
  selectedPair: { symbol: string; name: string };
  candleData: Array<{ open: number; high: number; low: number; close: number; volume?: number; time: any }>;
  isVisible: boolean;
  onClose: () => void;
  chartSeriesRef?: React.MutableRefObject<any>;
  clickedPrice?: number | null;
}

const STOP_TYPES: { id: StopType; name: string; description: string; icon: React.ReactNode; color: string }[] = [
  { id: "fixed", name: "Fixed Price", description: "Stop at a specific price level", icon: <Target size={14} />, color: "text-red-400" },
  { id: "trailing", name: "Trailing Stop", description: "Follows price movement, locks in profits", icon: <TrendingDown size={14} />, color: "text-amber-400" },
  { id: "breakeven", name: "Break-Even", description: "Auto-moves stop to entry when profitable", icon: <ShieldCheck size={14} />, color: "text-green-400" },
  { id: "time_based", name: "Time-Based", description: "Automatically triggers after set duration", icon: <Clock size={14} />, color: "text-blue-400" },
];

const QUICK_PERCENTAGES = [0.5, 1, 2, 3, 5, 10];

const TIME_PRESETS = [
  { label: "5m", ms: 5 * 60 * 1000 },
  { label: "15m", ms: 15 * 60 * 1000 },
  { label: "1h", ms: 60 * 60 * 1000 },
  { label: "4h", ms: 4 * 60 * 60 * 1000 },
  { label: "24h", ms: 24 * 60 * 60 * 1000 },
];

function calculateATR(candles: Array<{ high: number; low: number; close: number }>, period: number = 14): number {
  if (candles.length < period + 1) return 0;
  const recent = candles.slice(-(period + 1));
  let trSum = 0;
  for (let i = 1; i < recent.length; i++) {
    const tr = Math.max(
      recent[i].high - recent[i].low,
      Math.abs(recent[i].high - recent[i - 1].close),
      Math.abs(recent[i].low - recent[i - 1].close)
    );
    trSum += tr;
  }
  return trSum / period;
}

function generateId(): string {
  return `sl-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

export default function StopLossManager({
  currentPrice,
  selectedPair,
  candleData,
  isVisible,
  onClose,
  chartSeriesRef,
  clickedPrice,
}: StopLossManagerProps) {
  const { toast } = useToast();
  const [stops, setStops] = useState<StopLossOrder[]>(() => {
    try {
      const saved = localStorage.getItem("alpha_stop_losses");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeTab, setActiveTab] = useState<"create" | "active" | "history">("create");
  const [selectedStopType, setSelectedStopType] = useState<StopType>("fixed");
  const [side, setSide] = useState<"long" | "short">("long");
  const [entryPrice, setEntryPrice] = useState("");
  const [stopPrice, setStopPrice] = useState("");

  useEffect(() => {
    if (clickedPrice && clickedPrice > 0 && isVisible) {
      setStopPrice(clickedPrice.toFixed(2));
      setActiveTab("create");
    }
  }, [clickedPrice]);
  const [amount, setAmount] = useState("");
  const [trailPercent, setTrailPercent] = useState("2");
  const [breakevenTrigger, setBreakevenTrigger] = useState("1.5");
  const [timePreset, setTimePreset] = useState(2);
  const [alertEnabled, setAlertEnabled] = useState(true);
  const [notes, setNotes] = useState("");
  const [showRiskCalc, setShowRiskCalc] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [accountEquity, setAccountEquity] = useState("10000");
  const [riskPercentInput, setRiskPercentInput] = useState("2");

  const stopLinesRef = useRef<Map<string, any[]>>(new Map());
  const prevStopsRef = useRef<string>("");

  useEffect(() => {
    localStorage.setItem("alpha_stop_losses", JSON.stringify(stops));
  }, [stops]);

  useEffect(() => {
    if (currentPrice) {
      setEntryPrice(currentPrice.toFixed(2));
      const defaultStop = side === "long"
        ? (currentPrice * 0.98).toFixed(2)
        : (currentPrice * 1.02).toFixed(2);
      setStopPrice(defaultStop);
    }
  }, [selectedPair.symbol]);

  const atr = useMemo(() => calculateATR(candleData), [candleData]);
  const atrPercent = useMemo(() => {
    if (!currentPrice || !atr) return 0;
    return (atr / currentPrice) * 100;
  }, [atr, currentPrice]);

  const suggestedStops = useMemo(() => {
    if (!currentPrice || !atr) return [];
    const multipliers = [1, 1.5, 2, 2.5, 3];
    return multipliers.map(m => {
      const distance = atr * m;
      const longStop = currentPrice - distance;
      const shortStop = currentPrice + distance;
      return {
        multiplier: m,
        label: `${m}x ATR`,
        longStop: parseFloat(longStop.toFixed(2)),
        shortStop: parseFloat(shortStop.toFixed(2)),
        distance: parseFloat(distance.toFixed(2)),
        percent: parseFloat(((distance / currentPrice) * 100).toFixed(2)),
      };
    });
  }, [currentPrice, atr]);

  const riskCalc = useMemo(() => {
    const entry = parseFloat(entryPrice);
    const stop = parseFloat(stopPrice);
    const qty = parseFloat(amount);
    const equity = parseFloat(accountEquity);
    const riskPct = parseFloat(riskPercentInput);
    if (!entry || !stop || entry <= 0 || stop <= 0) return null;

    const riskPerUnit = Math.abs(entry - stop);
    const riskPercent = (riskPerUnit / entry) * 100;

    if (equity > 0 && riskPct > 0) {
      const maxRiskUsd = equity * (riskPct / 100);
      const suggestedSize = maxRiskUsd / riskPerUnit;
      const suggestedUsd = suggestedSize * entry;
      return {
        riskPerUnit,
        riskPercent: parseFloat(riskPercent.toFixed(2)),
        maxLossUsd: qty ? parseFloat((qty / entry * riskPerUnit).toFixed(2)) : 0,
        suggestedPositionSize: parseFloat(suggestedSize.toFixed(6)),
        suggestedPositionUsd: parseFloat(suggestedUsd.toFixed(2)),
        riskRewardAt2x: parseFloat((riskPerUnit * 2).toFixed(2)),
        riskRewardAt3x: parseFloat((riskPerUnit * 3).toFixed(2)),
      };
    }

    return {
      riskPerUnit,
      riskPercent: parseFloat(riskPercent.toFixed(2)),
      maxLossUsd: qty ? parseFloat((qty / entry * riskPerUnit).toFixed(2)) : 0,
      suggestedPositionSize: 0,
      suggestedPositionUsd: 0,
      riskRewardAt2x: parseFloat((riskPerUnit * 2).toFixed(2)),
      riskRewardAt3x: parseFloat((riskPerUnit * 3).toFixed(2)),
    };
  }, [entryPrice, stopPrice, amount, accountEquity, riskPercentInput]);

  const applyQuickPercent = useCallback((pct: number) => {
    if (!currentPrice) return;
    const newStop = side === "long"
      ? currentPrice * (1 - pct / 100)
      : currentPrice * (1 + pct / 100);
    setStopPrice(newStop.toFixed(2));
    setEntryPrice(currentPrice.toFixed(2));
  }, [currentPrice, side]);

  const applySuggestion = useCallback((stop: number) => {
    setStopPrice(stop.toFixed(2));
    if (currentPrice) setEntryPrice(currentPrice.toFixed(2));
  }, [currentPrice]);

  const createStop = useCallback(() => {
    const entry = parseFloat(entryPrice);
    const stop = parseFloat(stopPrice);
    const qty = parseFloat(amount);

    if (!entry || !stop || !qty || entry <= 0 || stop <= 0 || qty <= 0) {
      toast({ title: "Invalid Input", description: "Please fill in all required fields with valid values.", variant: "destructive" });
      return;
    }

    if (side === "long" && stop >= entry) {
      toast({ title: "Invalid Stop", description: "For long positions, stop price must be below entry price.", variant: "destructive" });
      return;
    }
    if (side === "short" && stop <= entry) {
      toast({ title: "Invalid Stop", description: "For short positions, stop price must be above entry price.", variant: "destructive" });
      return;
    }

    const riskPerUnit = Math.abs(entry - stop);
    const riskPct = (riskPerUnit / entry) * 100;
    const maxLoss = (qty / entry) * riskPerUnit;

    const newStop: StopLossOrder = {
      id: generateId(),
      symbol: selectedPair.symbol,
      side,
      entryPrice: entry,
      stopPrice: stop,
      stopType: selectedStopType,
      createdAt: Date.now(),
      status: "active",
      amount: qty,
      maxLossUsd: parseFloat(maxLoss.toFixed(2)),
      riskPercent: parseFloat(riskPct.toFixed(2)),
      alertEnabled,
      notes: notes || undefined,
    };

    if (selectedStopType === "trailing") {
      newStop.trailPercent = parseFloat(trailPercent);
      newStop.trailAmount = entry * (parseFloat(trailPercent) / 100);
      newStop.highestPrice = side === "long" ? entry : undefined;
      newStop.lowestPrice = side === "short" ? entry : undefined;
    }

    if (selectedStopType === "breakeven") {
      newStop.breakevenTriggerPercent = parseFloat(breakevenTrigger);
      newStop.breakevenActivated = false;
    }

    if (selectedStopType === "time_based") {
      newStop.timeExpiryMs = Date.now() + TIME_PRESETS[timePreset].ms;
    }

    setStops(prev => [...prev, newStop]);
    setActiveTab("active");
    toast({
      title: "Stop-Loss Created",
      description: `${STOP_TYPES.find(t => t.id === selectedStopType)?.name} at $${stop.toLocaleString()} for ${selectedPair.name}`,
    });
  }, [entryPrice, stopPrice, amount, side, selectedStopType, trailPercent, breakevenTrigger, timePreset, alertEnabled, notes, selectedPair, toast]);

  const cancelStop = useCallback((id: string) => {
    setStops(prev => prev.map(s => s.id === id ? { ...s, status: "cancelled" as const } : s));
    toast({ title: "Stop Cancelled", description: "Stop-loss order has been cancelled." });
  }, [toast]);

  const clearHistory = useCallback(() => {
    setStops(prev => prev.filter(s => s.status === "active"));
  }, []);

  const processStopMonitoring = useCallback((price: number, symbol: string) => {
    setStops(prev => {
      let changed = false;
      const updated = prev.map(stop => {
        if (stop.status !== "active" && stop.status !== "moved_to_breakeven") return stop;
        if (stop.symbol !== symbol) return stop;

        if (stop.stopType === "time_based" && stop.timeExpiryMs && Date.now() >= stop.timeExpiryMs) {
          changed = true;
          if (stop.alertEnabled) {
            toast({ title: "Time-Based Stop Expired", description: `${stop.symbol} stop expired after time limit at $${price.toLocaleString()}`, variant: "destructive" });
          }
          return { ...stop, status: "expired" as const };
        }

        if (stop.stopType === "trailing") {
          const newStop = { ...stop };
          if (stop.side === "long") {
            if (price > (stop.highestPrice || stop.entryPrice)) {
              newStop.highestPrice = price;
              const newStopPrice = price * (1 - (stop.trailPercent || 2) / 100);
              if (newStopPrice > stop.stopPrice) {
                newStop.stopPrice = parseFloat(newStopPrice.toFixed(2));
                changed = true;
              }
            }
            if (price <= stop.stopPrice) {
              changed = true;
              if (stop.alertEnabled) {
                toast({ title: "Trailing Stop Triggered!", description: `${stop.symbol} LONG hit trailing stop at $${stop.stopPrice.toLocaleString()}`, variant: "destructive" });
              }
              return { ...newStop, status: "triggered" as const };
            }
          } else {
            if (price < (stop.lowestPrice || stop.entryPrice)) {
              newStop.lowestPrice = price;
              const newStopPrice = price * (1 + (stop.trailPercent || 2) / 100);
              if (newStopPrice < stop.stopPrice) {
                newStop.stopPrice = parseFloat(newStopPrice.toFixed(2));
                changed = true;
              }
            }
            if (price >= stop.stopPrice) {
              changed = true;
              if (stop.alertEnabled) {
                toast({ title: "Trailing Stop Triggered!", description: `${stop.symbol} SHORT hit trailing stop at $${stop.stopPrice.toLocaleString()}`, variant: "destructive" });
              }
              return { ...newStop, status: "triggered" as const };
            }
          }
          if (newStop.highestPrice !== stop.highestPrice || newStop.lowestPrice !== stop.lowestPrice || newStop.stopPrice !== stop.stopPrice) {
            changed = true;
          }
          return newStop;
        }

        if (stop.stopType === "breakeven" && !stop.breakevenActivated && stop.status === "active") {
          const triggerPct = stop.breakevenTriggerPercent || 1.5;
          const profitPct = stop.side === "long"
            ? ((price - stop.entryPrice) / stop.entryPrice) * 100
            : ((stop.entryPrice - price) / stop.entryPrice) * 100;

          if (profitPct >= triggerPct) {
            changed = true;
            if (stop.alertEnabled) {
              toast({ title: "Break-Even Activated", description: `${stop.symbol} stop moved to entry $${stop.entryPrice.toLocaleString()}` });
            }
            return { ...stop, stopPrice: stop.entryPrice, breakevenActivated: true, status: "moved_to_breakeven" as const };
          }
        }

        const triggered = stop.side === "long"
          ? price <= stop.stopPrice
          : price >= stop.stopPrice;

        if (triggered) {
          changed = true;
          if (stop.alertEnabled) {
            toast({
              title: "Stop-Loss Triggered!",
              description: `${stop.symbol} ${stop.side.toUpperCase()} hit stop at $${stop.stopPrice.toLocaleString()}`,
              variant: "destructive",
            });
          }
          return { ...stop, status: "triggered" as const };
        }

        return stop;
      });

      return changed ? updated : prev;
    });
  }, [toast]);

  useEffect(() => {
    if (!currentPrice || currentPrice <= 0) return;
    processStopMonitoring(currentPrice, selectedPair.symbol);
  }, [currentPrice, selectedPair.symbol, processStopMonitoring]);

  useEffect(() => {
    const hasTimeBasedStops = stops.some(s =>
      s.status === "active" && s.stopType === "time_based" && s.timeExpiryMs
    );
    if (!hasTimeBasedStops) return;

    const interval = setInterval(() => {
      if (currentPrice && currentPrice > 0) {
        processStopMonitoring(currentPrice, selectedPair.symbol);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [stops, currentPrice, selectedPair.symbol, processStopMonitoring]);

  useEffect(() => {
    if (!chartSeriesRef?.current) return;
    stopLinesRef.current.forEach((lines) => {
      lines.forEach(pl => { try { chartSeriesRef.current?.removePriceLine(pl); } catch (e) {} });
    });
    stopLinesRef.current.clear();

    const activeStops = stops.filter(s =>
      (s.status === "active" || s.status === "moved_to_breakeven") && s.symbol === selectedPair.symbol
    );

    activeStops.forEach(stop => {
      const lines: any[] = [];
      try {
        const slLine = chartSeriesRef.current.createPriceLine({
          price: stop.stopPrice,
          color: stop.stopType === "trailing" ? "#f59e0b" : stop.status === "moved_to_breakeven" ? "#22c55e" : "#ef4444",
          lineWidth: 2,
          lineStyle: stop.stopType === "trailing" ? 1 : 2,
          axisLabelVisible: true,
          title: `SL ${stop.stopType === "trailing" ? "TRAIL" : stop.status === "moved_to_breakeven" ? "BE" : ""} $${stop.stopPrice.toFixed(2)}`,
        });
        lines.push(slLine);

        if (stop.stopType !== "trailing" && stop.stopType !== "breakeven") {
          const entryLine = chartSeriesRef.current.createPriceLine({
            price: stop.entryPrice,
            color: "#6366f1",
            lineWidth: 1,
            lineStyle: 2,
            axisLabelVisible: true,
            title: `ENTRY $${stop.entryPrice.toFixed(2)}`,
          });
          lines.push(entryLine);
        }
      } catch (e) {}
      stopLinesRef.current.set(stop.id, lines);
    });
  }, [stops, selectedPair.symbol, chartSeriesRef]);

  const activeStops = stops.filter(s => (s.status === "active" || s.status === "moved_to_breakeven") && s.symbol === selectedPair.symbol);
  const historyStops = stops.filter(s => s.status !== "active" && s.status !== "moved_to_breakeven");

  const dragConstraintsRef = useRef<{ top: number; left: number; right: number; bottom: number }>({ top: 0, left: 0, right: 0, bottom: 0 });

  useEffect(() => {
    if (!isVisible) return;
    const updateConstraints = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const panelW = Math.min(380, w - 16);
      const panelH = Math.min(h * 0.85, 700);
      dragConstraintsRef.current = {
        top: -(h - panelH - 80),
        left: -(w - panelW - 16),
        right: w - panelW - 16,
        bottom: h - 80 - 20,
      };
    };
    updateConstraints();
    window.addEventListener('resize', updateConstraints);
    return () => window.removeEventListener('resize', updateConstraints);
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <motion.div
      drag
      dragMomentum={false}
      dragElastic={0}
      dragConstraints={dragConstraintsRef.current}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-20 right-4 z-[9999] w-[380px] max-w-[calc(100vw-16px)] max-h-[85vh] bg-[#1a1f2e] rounded-xl border border-red-500/30 shadow-2xl shadow-red-500/10 overflow-hidden flex flex-col touch-none"
      data-testid="panel-stop-loss-manager"
    >
      <div className="bg-gradient-to-r from-red-600/20 to-orange-600/20 px-4 py-3 flex items-center justify-between border-b border-red-500/20 flex-shrink-0 cursor-grab active:cursor-grabbing select-none">
        <div className="flex items-center gap-2">
          <GripVertical size={16} className="text-gray-500 flex-shrink-0" />
          <ShieldAlert size={18} className="text-red-400" />
          <div>
            <span className="text-sm font-bold text-white">Stop-Loss Manager</span>
            <span className="text-[10px] text-gray-400 ml-2">{selectedPair.name}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {activeStops.length > 0 && (
            <span className="text-[10px] px-1.5 py-0.5 bg-red-500/20 text-red-400 rounded font-medium">
              {activeStops.length} active
            </span>
          )}
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors" data-testid="button-close-stop-loss">
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="flex border-b border-gray-800 flex-shrink-0">
        {(["create", "active", "history"] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 px-3 py-2 text-xs font-medium transition-colors ${
              activeTab === tab
                ? "text-white border-b-2 border-red-400 bg-gray-800/30"
                : "text-gray-500 hover:text-gray-300"
            }`}
            data-testid={`tab-sl-${tab}`}
          >
            {tab === "create" ? "New Stop" : tab === "active" ? `Active (${activeStops.length})` : `History (${historyStops.length})`}
          </button>
        ))}
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-hide" onPointerDownCapture={(e) => e.stopPropagation()}>
        {activeTab === "create" && (
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Current: <span className="text-white font-mono">${currentPrice?.toLocaleString() || "—"}</span></span>
              {atr > 0 && <span>ATR(14): <span className="text-amber-400 font-mono">${atr.toFixed(2)}</span> <span className="text-gray-500">({atrPercent.toFixed(1)}%)</span></span>}
            </div>

            <div className="flex gap-1">
              <button
                onClick={() => setSide("long")}
                className={`flex-1 py-1.5 rounded text-xs font-medium transition-colors ${
                  side === "long" ? "bg-green-500/20 text-green-400 border border-green-500/40" : "bg-gray-800 text-gray-500 border border-transparent"
                }`}
                data-testid="button-sl-long"
              >
                <TrendingUp size={12} className="inline mr-1" /> Long
              </button>
              <button
                onClick={() => setSide("short")}
                className={`flex-1 py-1.5 rounded text-xs font-medium transition-colors ${
                  side === "short" ? "bg-red-500/20 text-red-400 border border-red-500/40" : "bg-gray-800 text-gray-500 border border-transparent"
                }`}
                data-testid="button-sl-short"
              >
                <TrendingDown size={12} className="inline mr-1" /> Short
              </button>
            </div>

            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Stop Type</label>
              <div className="grid grid-cols-2 gap-1.5">
                {STOP_TYPES.map(type => (
                  <button
                    key={type.id}
                    onClick={() => setSelectedStopType(type.id)}
                    className={`px-2 py-2 rounded text-left transition-all ${
                      selectedStopType === type.id
                        ? "bg-gray-700/60 border border-red-500/40 shadow-sm"
                        : "bg-gray-800/60 border border-transparent hover:border-gray-600"
                    }`}
                    data-testid={`button-stop-type-${type.id}`}
                  >
                    <div className={`flex items-center gap-1.5 text-xs font-medium ${selectedStopType === type.id ? type.color : "text-gray-400"}`}>
                      {type.icon} {type.name}
                    </div>
                    <div className="text-[9px] text-gray-500 mt-0.5">{type.description}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Entry Price ($)</label>
                <input
                  type="number"
                  step="any"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(e.target.value)}
                  className="w-full bg-gray-800/80 border border-gray-700 rounded px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none font-mono"
                  data-testid="input-sl-entry-price"
                />
              </div>
              <div>
                <label className="text-xs text-red-400 mb-1 block">Stop Price ($)</label>
                <input
                  type="number"
                  step="any"
                  value={stopPrice}
                  onChange={(e) => setStopPrice(e.target.value)}
                  className="w-full bg-gray-800/80 border border-red-900/50 rounded px-3 py-2 text-sm text-white focus:border-red-500 focus:outline-none font-mono"
                  data-testid="input-sl-stop-price"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-gray-400 mb-1 block">Position Size (USD)</label>
              <input
                type="number"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="e.g. 1000"
                className="w-full bg-gray-800/80 border border-gray-700 rounded px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none font-mono"
                data-testid="input-sl-amount"
              />
            </div>

            <div>
              <label className="text-[10px] text-gray-500 mb-1 block">Quick Stop %</label>
              <div className="flex gap-1 flex-wrap">
                {QUICK_PERCENTAGES.map(pct => (
                  <button
                    key={pct}
                    onClick={() => applyQuickPercent(pct)}
                    className="px-2 py-1 bg-gray-800 hover:bg-red-500/20 hover:text-red-400 text-gray-400 text-[10px] rounded border border-gray-700 hover:border-red-500/30 transition-colors font-mono"
                    data-testid={`button-quick-sl-${pct}`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {selectedStopType === "trailing" && (
              <div>
                <label className="text-xs text-amber-400 mb-1 block">Trail Distance (%)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="50"
                    value={trailPercent}
                    onChange={(e) => setTrailPercent(e.target.value)}
                    className="flex-1 bg-gray-800/80 border border-amber-900/40 rounded px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none font-mono"
                    data-testid="input-sl-trail-percent"
                  />
                  <span className="text-xs text-gray-500">%</span>
                </div>
                <p className="text-[9px] text-gray-500 mt-1">Stop follows {side === "long" ? "upward" : "downward"} price movement, maintaining {trailPercent}% distance</p>
              </div>
            )}

            {selectedStopType === "breakeven" && (
              <div>
                <label className="text-xs text-green-400 mb-1 block">Break-Even Trigger (%)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="50"
                    value={breakevenTrigger}
                    onChange={(e) => setBreakevenTrigger(e.target.value)}
                    className="flex-1 bg-gray-800/80 border border-green-900/40 rounded px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none font-mono"
                    data-testid="input-sl-breakeven-trigger"
                  />
                  <span className="text-xs text-gray-500">% profit</span>
                </div>
                <p className="text-[9px] text-gray-500 mt-1">When price moves {breakevenTrigger}% in your favor, stop auto-moves to entry price</p>
              </div>
            )}

            {selectedStopType === "time_based" && (
              <div>
                <label className="text-xs text-blue-400 mb-1 block">Auto-Close After</label>
                <div className="flex gap-1">
                  {TIME_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTimePreset(idx)}
                      className={`flex-1 py-1.5 rounded text-xs font-medium transition-colors ${
                        timePreset === idx
                          ? "bg-blue-500/20 text-blue-400 border border-blue-500/40"
                          : "bg-gray-800 text-gray-500 border border-transparent hover:border-gray-600"
                      }`}
                      data-testid={`button-time-preset-${idx}`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
                <p className="text-[9px] text-gray-500 mt-1">Position will auto-close after {TIME_PRESETS[timePreset].label}</p>
              </div>
            )}

            {showSuggestions && suggestedStops.length > 0 && (
              <div className="bg-gray-800/40 rounded-lg p-2.5 border border-gray-700/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-amber-400 font-medium flex items-center gap-1">
                    <Activity size={10} /> ATR-Based Suggestions
                  </span>
                  <button onClick={() => setShowSuggestions(false)} className="text-gray-600 hover:text-gray-400">
                    <EyeOff size={10} />
                  </button>
                </div>
                <div className="space-y-1">
                  {suggestedStops.slice(0, 4).map((s, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between text-[10px] py-1 px-1.5 rounded hover:bg-gray-700/30 cursor-pointer transition-colors"
                      onClick={() => applySuggestion(side === "long" ? s.longStop : s.shortStop)}
                      data-testid={`suggestion-atr-${i}`}
                    >
                      <span className="text-gray-400">{s.label}</span>
                      <span className="text-gray-500">-{s.percent}%</span>
                      <span className="text-red-400 font-mono">${(side === "long" ? s.longStop : s.shortStop).toLocaleString()}</span>
                      <span className="text-blue-400 underline text-[9px]">Apply</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => setShowRiskCalc(!showRiskCalc)}
              className="w-full flex items-center justify-between text-xs text-gray-400 hover:text-white py-1.5 px-2 rounded bg-gray-800/40 transition-colors"
              data-testid="button-toggle-risk-calc"
            >
              <span className="flex items-center gap-1.5">
                <BarChart3 size={12} /> Risk Calculator
              </span>
              {showRiskCalc ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            </button>

            <AnimatePresence>
              {showRiskCalc && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700/50 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-gray-500 block mb-0.5">Account Equity ($)</label>
                        <input
                          type="number"
                          value={accountEquity}
                          onChange={(e) => setAccountEquity(e.target.value)}
                          className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-xs text-white focus:outline-none font-mono"
                          data-testid="input-account-equity"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-gray-500 block mb-0.5">Max Risk (%)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={riskPercentInput}
                          onChange={(e) => setRiskPercentInput(e.target.value)}
                          className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-xs text-white focus:outline-none font-mono"
                          data-testid="input-max-risk-percent"
                        />
                      </div>
                    </div>

                    {riskCalc && (
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-500">Risk per unit:</span>
                          <span className="text-white font-mono">${riskCalc.riskPerUnit.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-500">Risk %:</span>
                          <span className={`font-mono ${riskCalc.riskPercent > 5 ? "text-red-400" : riskCalc.riskPercent > 2 ? "text-amber-400" : "text-green-400"}`}>
                            {riskCalc.riskPercent}%
                          </span>
                        </div>
                        {riskCalc.maxLossUsd > 0 && (
                          <div className="flex justify-between text-[10px]">
                            <span className="text-gray-500">Max loss (current size):</span>
                            <span className="text-red-400 font-mono">-${riskCalc.maxLossUsd.toLocaleString()}</span>
                          </div>
                        )}
                        {riskCalc.suggestedPositionUsd > 0 && (
                          <div className="flex justify-between text-[10px] bg-indigo-500/10 px-2 py-1 rounded">
                            <span className="text-indigo-300">Suggested size ({riskPercentInput}% risk):</span>
                            <button
                              onClick={() => setAmount(riskCalc.suggestedPositionUsd.toFixed(2))}
                              className="text-indigo-400 font-mono underline hover:text-indigo-300"
                              data-testid="button-apply-suggested-size"
                            >
                              ${riskCalc.suggestedPositionUsd.toLocaleString()}
                            </button>
                          </div>
                        )}
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-500">TP at 2:1 R/R:</span>
                          <span className="text-green-400 font-mono">
                            ${side === "long"
                              ? (parseFloat(entryPrice) + riskCalc.riskRewardAt2x).toFixed(2)
                              : (parseFloat(entryPrice) - riskCalc.riskRewardAt2x).toFixed(2)
                            }
                          </span>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-500">TP at 3:1 R/R:</span>
                          <span className="text-green-400 font-mono">
                            ${side === "long"
                              ? (parseFloat(entryPrice) + riskCalc.riskRewardAt3x).toFixed(2)
                              : (parseFloat(entryPrice) - riskCalc.riskRewardAt3x).toFixed(2)
                            }
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs text-gray-400 cursor-pointer" data-testid="toggle-alert">
                <input
                  type="checkbox"
                  checked={alertEnabled}
                  onChange={(e) => setAlertEnabled(e.target.checked)}
                  className="rounded bg-gray-800 border-gray-600 text-red-500 focus:ring-red-500"
                />
                <Bell size={12} /> Alert on trigger
              </label>
            </div>

            <div>
              <label className="text-[10px] text-gray-500 mb-1 block">Notes (optional)</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Support level break..."
                className="w-full bg-gray-800/80 border border-gray-700 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
                data-testid="input-sl-notes"
              />
            </div>

            <Button
              onClick={createStop}
              className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold py-2.5 rounded-lg text-sm shadow-lg shadow-red-500/20"
              data-testid="button-create-stop-loss"
            >
              <Shield size={14} className="mr-2" />
              Set Stop-Loss
            </Button>
          </div>
        )}

        {activeTab === "active" && (
          <div className="p-3">
            {activeStops.length === 0 ? (
              <div className="text-center py-8">
                <ShieldCheck size={32} className="mx-auto text-gray-600 mb-2" />
                <p className="text-sm text-gray-400">No active stop-losses</p>
                <p className="text-[10px] text-gray-600 mt-1">Create one in the "New Stop" tab</p>
              </div>
            ) : (
              <div className="space-y-2">
                {activeStops.map(stop => {
                  const distancePercent = currentPrice
                    ? (Math.abs(currentPrice - stop.stopPrice) / currentPrice * 100).toFixed(2)
                    : "—";
                  const isClose = currentPrice ? Math.abs(currentPrice - stop.stopPrice) / currentPrice < 0.01 : false;

                  return (
                    <div
                      key={stop.id}
                      className={`bg-gray-800/50 rounded-lg p-3 border ${
                        isClose ? "border-red-500/50 animate-pulse" : stop.status === "moved_to_breakeven" ? "border-green-500/30" : "border-gray-700/50"
                      }`}
                      data-testid={`active-stop-${stop.id}`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                            stop.stopType === "trailing" ? "bg-amber-500/20 text-amber-400" :
                            stop.stopType === "breakeven" ? "bg-green-500/20 text-green-400" :
                            stop.stopType === "time_based" ? "bg-blue-500/20 text-blue-400" :
                            "bg-red-500/20 text-red-400"
                          }`}>
                            {STOP_TYPES.find(t => t.id === stop.stopType)?.name}
                          </span>
                          <span className={`text-[10px] ${stop.side === "long" ? "text-green-400" : "text-red-400"}`}>
                            {stop.side.toUpperCase()}
                          </span>
                          {stop.status === "moved_to_breakeven" && (
                            <span className="text-[9px] px-1 py-0.5 bg-green-500/10 text-green-400 rounded">BE</span>
                          )}
                        </div>
                        <button
                          onClick={() => cancelStop(stop.id)}
                          className="text-gray-500 hover:text-red-400 transition-colors"
                          data-testid={`button-cancel-stop-${stop.id}`}
                        >
                          <X size={14} />
                        </button>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-[10px]">
                        <div>
                          <span className="text-gray-500 block">Entry</span>
                          <span className="text-white font-mono">${stop.entryPrice.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-gray-500 block">Stop</span>
                          <span className={`font-mono ${isClose ? "text-red-400 font-bold" : "text-red-400"}`}>
                            ${stop.stopPrice.toLocaleString()}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500 block">Distance</span>
                          <span className={`font-mono ${isClose ? "text-red-400" : "text-gray-300"}`}>
                            {distancePercent}%
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-2 text-[9px] text-gray-500">
                        <span>Size: ${stop.amount.toLocaleString()}</span>
                        <span className="text-red-400">Max loss: -${stop.maxLossUsd.toLocaleString()}</span>
                        {stop.stopType === "trailing" && stop.highestPrice && (
                          <span className="text-amber-400">High: ${stop.highestPrice.toLocaleString()}</span>
                        )}
                        {stop.stopType === "time_based" && stop.timeExpiryMs && (
                          <span className="text-blue-400">
                            Expires: {new Date(stop.timeExpiryMs).toLocaleTimeString()}
                          </span>
                        )}
                      </div>
                      {stop.notes && <div className="text-[9px] text-gray-500 mt-1 italic">"{stop.notes}"</div>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === "history" && (
          <div className="p-3">
            {historyStops.length === 0 ? (
              <div className="text-center py-8">
                <Clock size={32} className="mx-auto text-gray-600 mb-2" />
                <p className="text-sm text-gray-400">No stop-loss history</p>
              </div>
            ) : (
              <>
                <div className="flex justify-end mb-2">
                  <button
                    onClick={clearHistory}
                    className="text-[10px] text-gray-500 hover:text-red-400 transition-colors"
                    data-testid="button-clear-sl-history"
                  >
                    Clear History
                  </button>
                </div>
                <div className="space-y-1.5">
                  {historyStops.slice(-20).reverse().map(stop => (
                    <div
                      key={stop.id}
                      className={`bg-gray-800/30 rounded-lg p-2.5 border ${
                        stop.status === "triggered" ? "border-red-500/20" :
                        stop.status === "cancelled" ? "border-gray-600/20" :
                        "border-gray-700/20"
                      } opacity-70`}
                      data-testid={`history-stop-${stop.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] px-1 py-0.5 rounded ${
                            stop.status === "triggered" ? "bg-red-500/20 text-red-400" :
                            stop.status === "cancelled" ? "bg-gray-600/20 text-gray-400" :
                            "bg-amber-500/20 text-amber-400"
                          }`}>
                            {stop.status.toUpperCase().replace("_", " ")}
                          </span>
                          <span className="text-[10px] text-gray-400">{stop.symbol.replace("USDT", "/USDT")}</span>
                        </div>
                        <span className="text-[9px] text-gray-600">
                          {new Date(stop.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex gap-4 mt-1 text-[9px] text-gray-500">
                        <span>Entry: ${stop.entryPrice.toLocaleString()}</span>
                        <span className="text-red-400">Stop: ${stop.stopPrice.toLocaleString()}</span>
                        <span>-${stop.maxLossUsd}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}