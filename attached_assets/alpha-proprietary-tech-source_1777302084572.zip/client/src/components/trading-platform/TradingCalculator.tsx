/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TradingCalculator™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_2d12e020f110b541b0eb6384
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useMemo, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, TrendingUp, TrendingDown, Percent, DollarSign, Target, Shield, Layers, ArrowRightLeft, BarChart3, Zap, Radio } from "lucide-react";

type CalculatorMode = 'position' | 'pnl' | 'risk' | 'leverage' | 'breakeven' | 'roi' | 'fibonacci' | 'compound';

interface CalculationResult {
  label: string;
  value: string;
  color?: string;
  highlight?: boolean;
}

export function TradingCalculator({ currentPrice = 0 }: { currentPrice?: number }) {
  const [mode, setMode] = useState<CalculatorMode>('position');
  
  const [accountBalance, setAccountBalance] = useState('10000');
  const [riskPercent, setRiskPercent] = useState('2');
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [takeProfit, setTakeProfit] = useState('');
  const [positionSize, setPositionSize] = useState('1000');
  const [leverage, setLeverage] = useState('10');
  const [exitPrice, setExitPrice] = useState('');
  const [initialInvestment, setInitialInvestment] = useState('1000');
  const [monthlyReturn, setMonthlyReturn] = useState('5');
  const [months, setMonths] = useState('12');
  const [fibHigh, setFibHigh] = useState('');
  const [fibLow, setFibLow] = useState('');
  const [entryManuallySet, setEntryManuallySet] = useState(false);
  const [useLiveExit, setUseLiveExit] = useState(false);
  const prevPrice = useRef(0);

  useEffect(() => {
    if (currentPrice > 0 && !entryManuallySet) {
      setEntryPrice(currentPrice.toString());
    }
    if (currentPrice > 0 && useLiveExit) {
      setExitPrice(currentPrice.toString());
    }
    prevPrice.current = currentPrice;
  }, [currentPrice, entryManuallySet, useLiveExit]);

  const handleEntryChange = (val: string) => {
    setEntryPrice(val);
    setEntryManuallySet(true);
  };

  const handleExitChange = (val: string) => {
    setExitPrice(val);
    setUseLiveExit(false);
  };

  const modes: { id: CalculatorMode; label: string; icon: any; desc: string }[] = [
    { id: 'position', label: 'Position Size', icon: Target, desc: 'Calculate optimal position' },
    { id: 'pnl', label: 'Profit/Loss', icon: DollarSign, desc: 'Calculate P&L' },
    { id: 'risk', label: 'Risk/Reward', icon: Shield, desc: 'Analyze risk ratio' },
    { id: 'leverage', label: 'Leverage', icon: Layers, desc: 'Leverage calculator' },
    { id: 'breakeven', label: 'Break-Even', icon: ArrowRightLeft, desc: 'Find break-even price' },
    { id: 'roi', label: 'ROI', icon: Percent, desc: 'Return on investment' },
    { id: 'fibonacci', label: 'Fibonacci', icon: BarChart3, desc: 'Fib retracement levels' },
    { id: 'compound', label: 'Compound', icon: TrendingUp, desc: 'Compound interest' },
  ];

  const results = useMemo<CalculationResult[]>(() => {
    const entry = parseFloat(entryPrice) || 0;
    const sl = parseFloat(stopLoss) || 0;
    const tp = parseFloat(takeProfit) || 0;
    const balance = parseFloat(accountBalance) || 0;
    const risk = parseFloat(riskPercent) || 0;
    const size = parseFloat(positionSize) || 0;
    const lev = parseFloat(leverage) || 1;
    const exit = parseFloat(exitPrice) || 0;
    const initial = parseFloat(initialInvestment) || 0;
    const monthly = parseFloat(monthlyReturn) || 0;
    const period = parseInt(months) || 0;
    const fHigh = parseFloat(fibHigh) || 0;
    const fLow = parseFloat(fibLow) || 0;

    switch (mode) {
      case 'position': {
        if (!entry || !sl || !balance || !risk) return [];
        const riskAmount = balance * (risk / 100);
        const priceDiff = Math.abs(entry - sl);
        const riskPerUnit = priceDiff / entry;
        const optimalSize = riskAmount / riskPerUnit;
        const units = optimalSize / entry;
        return [
          { label: 'Risk Amount ($)', value: `$${riskAmount.toFixed(2)}`, color: 'text-red-400' },
          { label: 'Price Difference', value: `$${priceDiff.toFixed(2)} (${(riskPerUnit * 100).toFixed(2)}%)` },
          { label: 'Optimal Position Size', value: `$${optimalSize.toFixed(2)}`, highlight: true, color: 'text-primary' },
          { label: 'Units to Buy', value: units.toFixed(6) },
          { label: 'Max Loss at Stop', value: `$${riskAmount.toFixed(2)}`, color: 'text-red-400' },
        ];
      }
      
      case 'pnl': {
        if (!entry || !size) return [];
        const effectiveExit = exit || currentPrice;
        if (!effectiveExit) return [];
        const isLong = effectiveExit > entry;
        const priceDiff = effectiveExit - entry;
        const percentChange = (priceDiff / entry) * 100;
        const pnl = (priceDiff / entry) * size;
        const pnlWithLeverage = pnl * lev;
        const usingLive = !exit && currentPrice > 0;
        return [
          { label: 'Entry Price', value: `$${entry.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` },
          { label: usingLive ? 'Exit Price (Live)' : 'Exit Price', value: `$${effectiveExit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: usingLive ? 'text-cyan-400' : undefined },
          { label: 'Price Change', value: `${priceDiff >= 0 ? '+' : ''}$${priceDiff.toFixed(2)} (${percentChange >= 0 ? '+' : ''}${percentChange.toFixed(2)}%)`, color: isLong ? 'text-green-400' : 'text-red-400' },
          { label: 'P&L (1x)', value: `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`, color: pnl >= 0 ? 'text-green-400' : 'text-red-400' },
          { label: `P&L (${lev}x Leverage)`, value: `${pnlWithLeverage >= 0 ? '+' : ''}$${pnlWithLeverage.toFixed(2)}`, highlight: true, color: pnlWithLeverage >= 0 ? 'text-green-400' : 'text-red-400' },
          { label: 'ROI', value: `${(pnlWithLeverage / size * 100).toFixed(2)}%`, color: pnlWithLeverage >= 0 ? 'text-green-400' : 'text-red-400' },
        ];
      }
      
      case 'risk': {
        if (!entry || !sl || !tp) return [];
        const riskDistance = Math.abs(entry - sl);
        const rewardDistance = Math.abs(tp - entry);
        const riskRewardRatio = rewardDistance / riskDistance;
        const winRateNeeded = (1 / (1 + riskRewardRatio)) * 100;
        const riskPercent = (riskDistance / entry) * 100;
        const rewardPercent = (rewardDistance / entry) * 100;
        return [
          { label: 'Risk Distance', value: `$${riskDistance.toFixed(2)} (${riskPercent.toFixed(2)}%)`, color: 'text-red-400' },
          { label: 'Reward Distance', value: `$${rewardDistance.toFixed(2)} (${rewardPercent.toFixed(2)}%)`, color: 'text-green-400' },
          { label: 'Risk:Reward Ratio', value: `1:${riskRewardRatio.toFixed(2)}`, highlight: true, color: riskRewardRatio >= 2 ? 'text-green-400' : riskRewardRatio >= 1 ? 'text-yellow-400' : 'text-red-400' },
          { label: 'Min Win Rate Needed', value: `${winRateNeeded.toFixed(1)}%` },
          { label: 'Trade Quality', value: riskRewardRatio >= 3 ? 'Excellent' : riskRewardRatio >= 2 ? 'Good' : riskRewardRatio >= 1 ? 'Fair' : 'Poor', color: riskRewardRatio >= 2 ? 'text-green-400' : riskRewardRatio >= 1 ? 'text-yellow-400' : 'text-red-400' },
        ];
      }
      
      case 'leverage': {
        if (!size || !lev) return [];
        const effectivePosition = size * lev;
        const liquidationLong = entry * (1 - (1 / lev) + 0.005);
        const liquidationShort = entry * (1 + (1 / lev) - 0.005);
        const marginRequired = size;
        const maxLoss = size;
        return [
          { label: 'Margin (Collateral)', value: `$${marginRequired.toFixed(2)}` },
          { label: 'Leverage', value: `${lev}x` },
          { label: 'Effective Position', value: `$${effectivePosition.toFixed(2)}`, highlight: true, color: 'text-primary' },
          { label: 'Liquidation (Long)', value: entry > 0 ? `$${liquidationLong.toFixed(2)}` : 'Enter price', color: 'text-red-400' },
          { label: 'Liquidation (Short)', value: entry > 0 ? `$${liquidationShort.toFixed(2)}` : 'Enter price', color: 'text-red-400' },
          { label: 'Max Loss', value: `$${maxLoss.toFixed(2)} (100%)`, color: 'text-red-400' },
        ];
      }
      
      case 'breakeven': {
        if (!entry || !size) return [];
        const tradingFee = 0.001;
        const totalFees = size * tradingFee * 2;
        const feePercent = tradingFee * 2 * 100;
        const breakevenLong = entry * (1 + (tradingFee * 2));
        const breakevenShort = entry * (1 - (tradingFee * 2));
        return [
          { label: 'Entry Price', value: `$${entry.toFixed(2)}` },
          { label: 'Position Size', value: `$${size.toFixed(2)}` },
          { label: 'Est. Trading Fees', value: `$${totalFees.toFixed(2)} (${feePercent.toFixed(2)}%)`, color: 'text-yellow-400' },
          { label: 'Break-Even (Long)', value: `$${breakevenLong.toFixed(2)}`, highlight: true, color: 'text-green-400' },
          { label: 'Break-Even (Short)', value: `$${breakevenShort.toFixed(2)}`, highlight: true, color: 'text-red-400' },
        ];
      }
      
      case 'roi': {
        if (!entry || !size) return [];
        const effectiveExit = exit || currentPrice;
        if (!effectiveExit) return [];
        const pnl = ((effectiveExit - entry) / entry) * size;
        const roi = ((effectiveExit - entry) / entry) * 100;
        const annualizedRoi = roi * 12;
        const usingLive = !exit && currentPrice > 0;
        return [
          { label: 'Investment', value: `$${size.toFixed(2)}` },
          { label: 'Entry Price', value: `$${entry.toFixed(2)}` },
          { label: usingLive ? 'Exit Price (Live)' : 'Exit Price', value: `$${effectiveExit.toFixed(2)}`, color: usingLive ? 'text-cyan-400' : undefined },
          { label: 'Profit/Loss', value: `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`, color: pnl >= 0 ? 'text-green-400' : 'text-red-400' },
          { label: 'ROI', value: `${roi >= 0 ? '+' : ''}${roi.toFixed(2)}%`, highlight: true, color: roi >= 0 ? 'text-green-400' : 'text-red-400' },
          { label: 'Annualized ROI', value: `${annualizedRoi >= 0 ? '+' : ''}${annualizedRoi.toFixed(2)}%`, color: annualizedRoi >= 0 ? 'text-green-400' : 'text-red-400' },
        ];
      }
      
      case 'fibonacci': {
        if (!fHigh || !fLow) return [];
        const diff = fHigh - fLow;
        const levels = [
          { level: '0%', price: fHigh },
          { level: '23.6%', price: fHigh - (diff * 0.236) },
          { level: '38.2%', price: fHigh - (diff * 0.382) },
          { level: '50%', price: fHigh - (diff * 0.5) },
          { level: '61.8%', price: fHigh - (diff * 0.618) },
          { level: '78.6%', price: fHigh - (diff * 0.786) },
          { level: '100%', price: fLow },
        ];
        return levels.map((l, i) => ({
          label: `Fib ${l.level}`,
          value: `$${l.price.toFixed(2)}`,
          highlight: l.level === '61.8%',
          color: i === 0 ? 'text-green-400' : i === levels.length - 1 ? 'text-red-400' : l.level === '61.8%' ? 'text-primary' : undefined,
        }));
      }
      
      case 'compound': {
        if (!initial || !monthly || !period) return [];
        let balance = initial;
        const monthlyRate = monthly / 100;
        for (let i = 0; i < period; i++) {
          balance *= (1 + monthlyRate);
        }
        const totalGain = balance - initial;
        const totalReturn = ((balance - initial) / initial) * 100;
        return [
          { label: 'Initial Investment', value: `$${initial.toFixed(2)}` },
          { label: 'Monthly Return', value: `${monthly}%` },
          { label: 'Time Period', value: `${period} months` },
          { label: 'Final Balance', value: `$${balance.toFixed(2)}`, highlight: true, color: 'text-green-400' },
          { label: 'Total Gain', value: `+$${totalGain.toFixed(2)}`, color: 'text-green-400' },
          { label: 'Total Return', value: `+${totalReturn.toFixed(2)}%`, color: 'text-green-400' },
        ];
      }
      
      default:
        return [];
    }
  }, [mode, accountBalance, riskPercent, entryPrice, stopLoss, takeProfit, positionSize, leverage, exitPrice, initialInvestment, monthlyReturn, months, fibHigh, fibLow, currentPrice]);

  const getMissingFields = (): string[] => {
    const entry = parseFloat(entryPrice) || 0;
    const sl = parseFloat(stopLoss) || 0;
    const tp = parseFloat(takeProfit) || 0;
    const balance = parseFloat(accountBalance) || 0;
    const risk = parseFloat(riskPercent) || 0;
    const size = parseFloat(positionSize) || 0;
    const exit = parseFloat(exitPrice) || 0;
    const fHigh = parseFloat(fibHigh) || 0;
    const fLow = parseFloat(fibLow) || 0;

    switch (mode) {
      case 'position': {
        const missing: string[] = [];
        if (!entry) missing.push('Entry Price');
        if (!sl) missing.push('Stop Loss');
        if (!balance) missing.push('Account Balance');
        if (!risk) missing.push('Risk %');
        return missing;
      }
      case 'pnl': {
        const missing: string[] = [];
        if (!entry) missing.push('Entry Price');
        if (!exit && !currentPrice) missing.push('Exit Price');
        if (!size) missing.push('Position Size');
        return missing;
      }
      case 'risk': {
        const missing: string[] = [];
        if (!entry) missing.push('Entry Price');
        if (!sl) missing.push('Stop Loss');
        if (!tp) missing.push('Take Profit');
        return missing;
      }
      case 'leverage': {
        const missing: string[] = [];
        if (!size) missing.push('Position Size');
        return missing;
      }
      case 'breakeven': {
        const missing: string[] = [];
        if (!entry) missing.push('Entry Price');
        if (!size) missing.push('Position Size');
        return missing;
      }
      case 'roi': {
        const missing: string[] = [];
        if (!entry) missing.push('Entry Price');
        if (!exit && !currentPrice) missing.push('Exit Price');
        if (!size) missing.push('Investment');
        return missing;
      }
      case 'fibonacci': {
        const missing: string[] = [];
        if (!fHigh) missing.push('Swing High');
        if (!fLow) missing.push('Swing Low');
        return missing;
      }
      case 'compound': {
        const missing: string[] = [];
        if (!parseFloat(initialInvestment)) missing.push('Initial Investment');
        if (!parseFloat(monthlyReturn)) missing.push('Monthly Return');
        if (!parseInt(months)) missing.push('Months');
        return missing;
      }
      default:
        return [];
    }
  };

  const renderInputs = () => {
    const inputClass = "w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white focus:border-primary outline-none";
    const labelClass = "text-xs text-gray-400 mb-1 block";
    const liveTag = (
      <span className="inline-flex items-center gap-1 ml-1 text-cyan-400">
        <Radio size={8} className="animate-pulse" /> Live
      </span>
    );

    switch (mode) {
      case 'position':
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>Account Balance ($)</label>
              <input type="number" value={accountBalance} onChange={(e) => setAccountBalance(e.target.value)} className={inputClass} placeholder="10000" data-testid="calc-account-balance" />
            </div>
            <div>
              <label className={labelClass}>Risk Per Trade (%)</label>
              <input type="number" value={riskPercent} onChange={(e) => setRiskPercent(e.target.value)} className={inputClass} placeholder="2" data-testid="calc-risk-percent" />
            </div>
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? currentPrice.toString() : "Entry price"} data-testid="calc-entry-price" />
            </div>
            <div>
              <label className={labelClass}>Stop Loss ($)</label>
              <input type="number" value={stopLoss} onChange={(e) => setStopLoss(e.target.value)} className={inputClass} placeholder="Stop loss price" data-testid="calc-stop-loss" />
            </div>
          </div>
        );
      
      case 'pnl':
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? currentPrice.toString() : "Entry price"} data-testid="calc-entry-price" />
            </div>
            <div>
              <label className={labelClass}>
                Exit Price ($)
                {!exitPrice && currentPrice > 0 && (
                  <span className="text-cyan-400 ml-1 text-[10px]">(using live price)</span>
                )}
              </label>
              <div className="relative">
                <input type="number" value={exitPrice} onChange={(e) => handleExitChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? `Live: ${currentPrice.toLocaleString()}` : "Exit price"} data-testid="calc-exit-price" />
                {currentPrice > 0 && !useLiveExit && (
                  <button
                    onClick={() => { setUseLiveExit(true); setExitPrice(currentPrice.toString()); }}
                    className="absolute right-1 top-1/2 -translate-y-1/2 text-[9px] px-1.5 py-0.5 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30 hover:bg-cyan-500/30 transition-colors"
                    data-testid="calc-use-live-exit"
                  >
                    Live
                  </button>
                )}
              </div>
            </div>
            <div>
              <label className={labelClass}>Position Size ($)</label>
              <input type="number" value={positionSize} onChange={(e) => setPositionSize(e.target.value)} className={inputClass} placeholder="1000" data-testid="calc-position-size" />
            </div>
            <div>
              <label className={labelClass}>Leverage (x)</label>
              <input type="number" value={leverage} onChange={(e) => setLeverage(e.target.value)} className={inputClass} placeholder="10" data-testid="calc-leverage" />
            </div>
          </div>
        );
      
      case 'risk':
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? currentPrice.toString() : "Entry"} data-testid="calc-entry-price" />
            </div>
            <div>
              <label className={labelClass}>Stop Loss ($)</label>
              <input type="number" value={stopLoss} onChange={(e) => setStopLoss(e.target.value)} className={inputClass} placeholder="Stop loss" data-testid="calc-stop-loss" />
            </div>
            <div>
              <label className={labelClass}>Take Profit ($)</label>
              <input type="number" value={takeProfit} onChange={(e) => setTakeProfit(e.target.value)} className={inputClass} placeholder="Take profit" data-testid="calc-take-profit" />
            </div>
          </div>
        );
      
      case 'leverage':
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelClass}>Margin/Collateral ($)</label>
              <input type="number" value={positionSize} onChange={(e) => setPositionSize(e.target.value)} className={inputClass} placeholder="1000" data-testid="calc-position-size" />
            </div>
            <div>
              <label className={labelClass}>Leverage (x)</label>
              <input type="number" value={leverage} onChange={(e) => setLeverage(e.target.value)} className={inputClass} placeholder="10" data-testid="calc-leverage" />
            </div>
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder="Entry price" data-testid="calc-entry-price" />
            </div>
          </div>
        );
      
      case 'breakeven':
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? currentPrice.toString() : "Entry price"} data-testid="calc-entry-price" />
            </div>
            <div>
              <label className={labelClass}>Position Size ($)</label>
              <input type="number" value={positionSize} onChange={(e) => setPositionSize(e.target.value)} className={inputClass} placeholder="1000" data-testid="calc-position-size" />
            </div>
          </div>
        );
      
      case 'roi':
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelClass}>Entry Price ($) {!entryManuallySet && currentPrice > 0 && liveTag}</label>
              <input type="number" value={entryPrice} onChange={(e) => handleEntryChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? currentPrice.toString() : "Entry"} data-testid="calc-entry-price" />
            </div>
            <div>
              <label className={labelClass}>
                Exit Price ($)
                {!exitPrice && currentPrice > 0 && (
                  <span className="text-cyan-400 ml-1 text-[10px]">(using live)</span>
                )}
              </label>
              <div className="relative">
                <input type="number" value={exitPrice} onChange={(e) => handleExitChange(e.target.value)} className={inputClass} placeholder={currentPrice > 0 ? `Live: ${currentPrice.toLocaleString()}` : "Exit"} data-testid="calc-exit-price" />
                {currentPrice > 0 && !useLiveExit && (
                  <button
                    onClick={() => { setUseLiveExit(true); setExitPrice(currentPrice.toString()); }}
                    className="absolute right-1 top-1/2 -translate-y-1/2 text-[9px] px-1.5 py-0.5 bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30 hover:bg-cyan-500/30 transition-colors"
                    data-testid="calc-use-live-exit-roi"
                  >
                    Live
                  </button>
                )}
              </div>
            </div>
            <div>
              <label className={labelClass}>Investment ($)</label>
              <input type="number" value={positionSize} onChange={(e) => setPositionSize(e.target.value)} className={inputClass} placeholder="1000" data-testid="calc-position-size" />
            </div>
          </div>
        );
      
      case 'fibonacci':
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>Swing High ($)</label>
              <input type="number" value={fibHigh} onChange={(e) => setFibHigh(e.target.value)} className={inputClass} placeholder="High price" data-testid="calc-fib-high" />
            </div>
            <div>
              <label className={labelClass}>Swing Low ($)</label>
              <input type="number" value={fibLow} onChange={(e) => setFibLow(e.target.value)} className={inputClass} placeholder="Low price" data-testid="calc-fib-low" />
            </div>
          </div>
        );
      
      case 'compound':
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelClass}>Initial Investment ($)</label>
              <input type="number" value={initialInvestment} onChange={(e) => setInitialInvestment(e.target.value)} className={inputClass} placeholder="1000" data-testid="calc-initial-investment" />
            </div>
            <div>
              <label className={labelClass}>Monthly Return (%)</label>
              <input type="number" value={monthlyReturn} onChange={(e) => setMonthlyReturn(e.target.value)} className={inputClass} placeholder="5" data-testid="calc-monthly-return" />
            </div>
            <div>
              <label className={labelClass}>Months</label>
              <input type="number" value={months} onChange={(e) => setMonths(e.target.value)} className={inputClass} placeholder="12" data-testid="calc-months" />
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  const missingFields = results.length === 0 ? getMissingFields() : [];

  return (
    <Card className="bg-gray-900/90 border-gray-800">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Calculator className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-white">Alpha Trading Calculator</h3>
          {currentPrice > 0 && (
            <span className="ml-auto flex items-center gap-1 text-xs text-cyan-400">
              <Radio size={10} className="animate-pulse" /> Live
            </span>
          )}
          <span className={`${currentPrice > 0 ? '' : 'ml-auto'} text-xs text-gray-500`}>Pro Tool</span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-1 mb-4">
          {modes.map((m) => (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`p-2 rounded-lg text-center transition-all ${
                mode === m.id
                  ? 'bg-primary/20 border border-primary/50 text-primary'
                  : 'bg-gray-800 border border-gray-700 text-gray-400 hover:text-white hover:border-gray-600'
              }`}
              title={m.desc}
              data-testid={`calc-mode-${m.id}`}
            >
              <m.icon size={16} className="mx-auto mb-1" />
              <span className="text-[9px] block truncate">{m.label}</span>
            </button>
          ))}
        </div>

        <div className="mb-4">
          {renderInputs()}
        </div>

        {results.length > 0 && (
          <div className="bg-gray-800/50 rounded-lg border border-gray-700 p-3 space-y-2">
            <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
              <Zap size={12} className="text-primary" /> Results
              {currentPrice > 0 && (
                <span className="ml-auto flex items-center gap-1 text-cyan-400 text-[10px]">
                  <Radio size={8} className="animate-pulse" /> Updates with market
                </span>
              )}
            </div>
            {results.map((r, i) => (
              <div
                key={i}
                className={`flex items-center justify-between py-1.5 px-2 rounded ${r.highlight ? 'bg-primary/10 border border-primary/30' : ''}`}
                data-testid={`calc-result-${i}`}
              >
                <span className="text-sm text-gray-400">{r.label}</span>
                <span className={`text-sm font-bold ${r.color || 'text-white'}`}>{r.value}</span>
              </div>
            ))}
          </div>
        )}

        {results.length === 0 && (
          <div className="bg-gray-800/50 rounded-lg border border-gray-700 p-4 text-center">
            <Calculator className="w-8 h-8 text-gray-600 mx-auto mb-2" />
            {missingFields.length > 0 ? (
              <p className="text-sm text-gray-500">
                Fill in: <span className="text-gray-400">{missingFields.join(', ')}</span>
              </p>
            ) : (
              <p className="text-sm text-gray-500">Enter values above to calculate</p>
            )}
          </div>
        )}

        {currentPrice > 0 && (
          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-gray-500 flex items-center gap-1">
              <Radio size={10} className="text-cyan-400 animate-pulse" />
              Market: ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <div className="flex gap-2">
              {entryManuallySet && (
                <Button
                  size="sm"
                  variant="outline"
                  className="h-6 text-xs border-cyan-700 text-cyan-400 hover:text-white hover:bg-cyan-500/20"
                  onClick={() => { setEntryPrice(currentPrice.toString()); setEntryManuallySet(false); }}
                  data-testid="calc-sync-entry"
                >
                  Sync Entry
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                className="h-6 text-xs border-gray-700 text-gray-400 hover:text-white"
                onClick={() => { setEntryPrice(currentPrice.toString()); setEntryManuallySet(true); }}
                data-testid="calc-use-price"
              >
                Use ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
