/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha AACC Dashboard™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain, Play, Pause, Settings, Activity, TrendingUp, TrendingDown,
  BarChart3, Zap, Target, RefreshCw, ChevronDown, ChevronUp,
  AlertTriangle, CheckCircle, XCircle, ArrowRightLeft, Bot,
  Scan, Shield, Eye, Clock, DollarSign, Percent, Grid3X3,
  Repeat, Layers, ArrowDown, ArrowUp, Scale, Crosshair
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

const _commandCenterUiSeal = 'AUT_cc9a3d5f7b1e4c8a2e6d0f3b5c7a9e1d4f2b8c6e';
if (!_commandCenterUiSeal) throw new Error('Module integrity compromised');

interface Opportunity {
  pair: string;
  baseAsset: string;
  score: number;
  price: number;
  change1h: number;
  change24h: number;
  volume24h: number;
  volatility: number;
  momentum: number;
  rsiEstimate: number;
  trendDirection: 'bullish' | 'bearish' | 'neutral';
  reason: string;
}

interface ManagedBot {
  botId: number;
  pair: string;
  type: string;
  status: string;
  pnl: number;
  pnlPercent: number;
  holdTimeMinutes: number;
  lastTradeMinutesAgo: number;
  isUnderperforming: boolean;
  signalStrength: number;
}

interface CCConfig {
  id: number;
  exchange: string;
  settings: {
    scanIntervalSeconds: number;
    minOpportunityScore: number;
    maxManagedBots: number;
    rotationCooldownMinutes: number;
    minHoldMinutes: number;
    riskLevel: 'conservative' | 'moderate' | 'aggressive';
    investmentPerBot: number;
    profitLockThreshold: number;
    underperformMinutes: number;
    autoTechSelection: boolean;
    paperTrading: boolean;
    totalCapital: number;
  };
  allocatedCapital: number;
  totalRotations: number;
  totalProfit: number;
  lastScanAt: string | null;
  lastRotationAt: string | null;
}

interface CCStatus {
  active: boolean;
  config: CCConfig | null;
  managedBots: ManagedBot[];
  opportunities: Opportunity[];
  marketCondition: string;
  botTypesActive: string[];
  botEngineRunning: boolean;
  connectedExchanges?: string[];
  multiExchangeEnabled?: boolean;
  arbitrageEnabled?: boolean;
}

interface CCLog {
  id: number;
  logType: string;
  message: string;
  data: any;
  createdAt: string;
}

const EXCHANGES = [
  { id: 'binance', name: 'Binance' },
  { id: 'binanceus', name: 'Binance.US' },
  { id: 'kraken', name: 'Kraken' },
  { id: 'coinbase', name: 'Coinbase' },
  { id: 'bybit', name: 'Bybit' },
  { id: 'okx', name: 'OKX' },
  { id: 'kucoin', name: 'KuCoin' },
  { id: 'bitget', name: 'Bitget' },
  { id: 'gateio', name: 'Gate.io' },
  { id: 'mexc', name: 'MEXC' },
];

const BOT_TYPE_LABELS: Record<string, string> = {
  signal: 'AI Signal', grid: 'Grid', dca: 'DCA', infinity_grid: 'Infinity Grid',
  reverse_grid: 'Reverse Grid', twap: 'TWAP', trailing_stop: 'Trailing Stop',
  smart_trade: 'Smart Trade', rebalancing: 'Rebalance', auto_invest: 'Auto Invest',
  arbitrage: 'Arbitrage', martingale: 'Martingale', leveraged_grid: 'Leveraged Grid',
  spot_futures_arb: 'Spot-Futures Arb'
};

const MARKET_CONDITION_LABELS: Record<string, { label: string; color: string }> = {
  trending_up: { label: 'Trending Up', color: 'text-green-400' },
  trending_down: { label: 'Trending Down', color: 'text-red-400' },
  ranging: { label: 'Range-Bound', color: 'text-blue-400' },
  volatile: { label: 'High Volatility', color: 'text-orange-400' },
  breakout: { label: 'Breakout', color: 'text-yellow-400' },
};

interface CCAnalytics {
  liveAnalytics: {
    totalSignals: number;
    completedTracking: number;
    avgProfitPotential5m: number | null;
    avgProfitPotential15m: number | null;
    avgProfitPotential30m: number | null;
    avgProfitPotential60m: number | null;
    winRate5m: number | null;
    winRate15m: number | null;
    winRate30m: number | null;
    winRate60m: number | null;
    bestSignal: { pair: string; score: number; profit60m: number; botType: string } | null;
    worstSignal: { pair: string; score: number; profit60m: number; botType: string } | null;
    byBotType: Record<string, any>;
    byMarketCondition: Record<string, any>;
    byScoreRange: Record<string, any>;
    recentOutcomes: any[];
  };
  dbAnalytics: {
    totalScans: number;
    totalRotations: number;
    totalBotsCreated: number;
    totalPriceTracked: number;
    profitableSignals: number;
    unprofitableSignals: number;
    dbWinRate: number | null;
    avgSignalProfit: number;
  };
  recentPriceTracking: Array<{ message: string; data: any; time: string }>;
}

export function CommandCenter() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [status, setStatus] = useState<CCStatus | null>(null);
  const [logs, setLogs] = useState<CCLog[]>([]);
  const [analytics, setAnalytics] = useState<CCAnalytics | null>(null);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showLogs, setShowLogs] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showOpportunities, setShowOpportunities] = useState(true);
  const [allocationRec, setAllocationRec] = useState<any>(null);
  const [loadingRec, setLoadingRec] = useState(false);
  const [connectedExchanges, setConnectedExchanges] = useState<string[]>([]);
  const [smartAllocations, setSmartAllocations] = useState<any>(null);
  const [loadingSmartAlloc, setLoadingSmartAlloc] = useState(false);
  const [showSmartAlloc, setShowSmartAlloc] = useState(false);
  const [arbitrageData, setArbitrageData] = useState<any>(null);
  const [loadingArbitrage, setLoadingArbitrage] = useState(false);
  const [showArbitrage, setShowArbitrage] = useState(false);
  const [settingsForm, setSettingsForm] = useState<CCConfig['settings']>({
    scanIntervalSeconds: 30,
    minOpportunityScore: 70,
    maxManagedBots: 5,
    rotationCooldownMinutes: 5,
    minHoldMinutes: 10,
    riskLevel: 'moderate',
    investmentPerBot: 100,
    profitLockThreshold: 2,
    underperformMinutes: 15,
    autoTechSelection: true,
    paperTrading: false,
    totalCapital: 1000,
  });

  useEffect(() => {
    if (!_commandCenterUiSeal?.startsWith('AUT_')) throw new Error('Module integrity compromised');
  }, []);

  const fetchStatus = useCallback(async (forceSync = false) => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/command-center/status');
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
        if (data.config?.settings && (forceSync || !showSettings)) {
          setSettingsForm(data.config.settings);
        }
      }
    } catch {} finally {
      setLoading(false);
    }
  }, [isAuthenticated, showSettings]);

  const fetchLogs = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/command-center/logs?limit=50');
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch {}
  }, [isAuthenticated]);

  const fetchAnalytics = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/command-center/analytics');
      if (res.ok) {
        const data = await res.json();
        if (data.error) {
          setAnalyticsError(data.error);
        } else {
          setAnalytics(data);
          setAnalyticsError(null);
        }
      } else {
        setAnalyticsError('Failed to load analytics');
      }
    } catch {
      setAnalyticsError('Network error loading analytics');
    }
  }, [isAuthenticated]);

  const fetchSmartAllocations = useCallback(async () => {
    if (!isAuthenticated) return;
    setLoadingSmartAlloc(true);
    try {
      const res = await fetch('/api/command-center/smart-allocations');
      if (res.ok) setSmartAllocations(await res.json());
    } catch {} finally { setLoadingSmartAlloc(false); }
  }, [isAuthenticated]);

  const fetchArbitrage = useCallback(async () => {
    if (!isAuthenticated) return;
    setLoadingArbitrage(true);
    try {
      const res = await fetch('/api/command-center/arbitrage');
      if (res.ok) setArbitrageData(await res.json());
    } catch {} finally { setLoadingArbitrage(false); }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchStatus(true);
    fetchLogs();
    fetch('/api/trading/exchanges', { credentials: 'include' })
      .then(r => r.ok ? r.json() : [])
      .then(data => {
        const names = (Array.isArray(data) ? data : [])
          .filter((c: any) => c.isActive)
          .map((c: any) => c.exchangeName?.toLowerCase())
          .filter(Boolean);
        setConnectedExchanges([...new Set(names)] as string[]);
      })
      .catch(() => {});
  }, [fetchStatus, fetchLogs]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const interval = setInterval(() => {
      fetchStatus();
      if (showLogs) fetchLogs();
      if (showAnalytics) fetchAnalytics();
    }, 10000);
    return () => clearInterval(interval);
  }, [isAuthenticated, fetchStatus, fetchLogs, fetchAnalytics, showLogs, showAnalytics]);

  const toggleCC = async () => {
    const wasStopping = status?.active;
    setStarting(true);
    try {
      const endpoint = wasStopping ? '/api/command-center/stop' : '/api/command-center/start';
      const res = await fetch(endpoint, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' } });
      if (res.ok) {
        if (wasStopping) {
          setStatus((prev: any) => prev ? { ...prev, active: false } : prev);
        }
        toast({ title: wasStopping ? 'Command Center deactivated' : 'Command Center activated' });
        await fetchStatus();
        await fetchLogs();
      } else {
        let errMsg = `Request failed (${res.status})`;
        try { const err = await res.json(); errMsg = err.message || errMsg; } catch {}
        toast({ title: 'Error', description: errMsg, variant: 'destructive' });
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Network error', variant: 'destructive' });
    } finally {
      setStarting(false);
    }
  };

  const saveSettings = async () => {
    try {
      const res = await fetch('/api/command-center/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsForm),
      });
      if (res.ok) {
        toast({ title: 'Settings saved' });
        setShowSettings(false);
        await fetchStatus(true);
      }
    } catch {}
  };

  const changeExchange = async (exchange: string) => {
    try {
      const res = await fetch('/api/command-center/exchange', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exchange }),
      });
      if (res.ok) {
        toast({ title: `Exchange changed to ${exchange}` });
        await fetchStatus();
      }
    } catch {}
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    if (score >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-500/20 border-green-500/30';
    if (score >= 60) return 'bg-yellow-500/20 border-yellow-500/30';
    if (score >= 40) return 'bg-orange-500/20 border-orange-500/30';
    return 'bg-red-500/20 border-red-500/30';
  };

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'scan': return <Scan className="w-3.5 h-3.5 text-blue-400" />;
      case 'rotation': return <ArrowRightLeft className="w-3.5 h-3.5 text-yellow-400" />;
      case 'create': return <Bot className="w-3.5 h-3.5 text-green-400" />;
      case 'pause': return <Pause className="w-3.5 h-3.5 text-orange-400" />;
      case 'start': return <Play className="w-3.5 h-3.5 text-cyan-400" />;
      case 'stop': return <XCircle className="w-3.5 h-3.5 text-red-400" />;
      case 'error': return <AlertTriangle className="w-3.5 h-3.5 text-red-400" />;
      case 'settings': return <Settings className="w-3.5 h-3.5 text-gray-400" />;
      case 'fee_analysis': return <Scale className="w-3.5 h-3.5 text-yellow-400" />;
      case 'rotation_skipped': return <XCircle className="w-3.5 h-3.5 text-orange-400" />;
      case 'smart_allocation': return <Target className="w-3.5 h-3.5 text-purple-400" />;
      case 'arbitrage': return <ArrowRightLeft className="w-3.5 h-3.5 text-cyan-400" />;
      case 'capital': return <DollarSign className="w-3.5 h-3.5 text-green-400" />;
      default: return <Activity className="w-3.5 h-3.5 text-gray-400" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-8 text-center" data-testid="cc-login-prompt">
        <Brain className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
        <h3 className="text-lg font-semibold text-white mb-2">Alpha Autonomous Command Center™</h3>
        <p className="text-gray-400 text-sm">Log in to activate the AACC™</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-8 text-center">
        <RefreshCw className="w-8 h-8 text-yellow-400 mx-auto mb-3 animate-spin" />
        <p className="text-gray-400 text-sm">Loading Command Center...</p>
      </div>
    );
  }

  const config = status?.config;
  const isActive = status?.active || false;
  const managedBots = status?.managedBots || [];
  const opportunities = status?.opportunities || [];

  return (
    <div className="space-y-4" data-testid="command-center">
      <div aria-hidden="true" style={{position:'absolute',width:1,height:1,overflow:'hidden',clip:'rect(0,0,0,0)',whiteSpace:'nowrap'}}>
        © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
        Alpha Autonomous Command Center™, Bridge Fusion™, QMGE™, ACM™, QFRM™ are proprietary technologies.
        Patent Pending. Unauthorized reproduction prohibited. CONTAINS TRADE SECRETS.
      </div>
      <div className="bg-gradient-to-r from-gray-900/80 via-yellow-900/10 to-gray-900/80 border border-yellow-500/20 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${isActive ? 'bg-green-500/20' : 'bg-gray-800'}`}>
              <Brain className={`w-6 h-6 ${isActive ? 'text-green-400' : 'text-gray-500'}`} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2" data-testid="cc-title">
                Alpha Autonomous Command Center™
                {isActive && (
                  <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full animate-pulse">ACTIVE</span>
                )}
              </h2>
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-xs text-gray-400">
                  {isActive
                    ? `Scanning ${config?.exchange || 'market'} every ${config?.settings?.scanIntervalSeconds || 30}s`
                    : 'Autonomous AI multi-strategy bot management & capital rotation'}
                </p>
                {isActive && status?.marketCondition && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full border border-gray-700 ${MARKET_CONDITION_LABELS[status.marketCondition]?.color || 'text-gray-400'}`} data-testid="cc-market-condition">
                    {MARKET_CONDITION_LABELS[status.marketCondition]?.label || status.marketCondition}
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowSettings(!showSettings)}
              className="border-gray-700 text-gray-300 text-xs"
              data-testid="cc-settings-toggle"
            >
              <Settings className="w-3.5 h-3.5 mr-1" /> Settings
            </Button>
            <Button
              size="sm"
              onClick={toggleCC}
              disabled={starting}
              className={isActive ? 'bg-red-600 hover:bg-red-700 text-xs' : 'bg-green-600 hover:bg-green-700 text-xs'}
              data-testid="cc-toggle"
            >
              {starting ? <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" /> : isActive ? <Pause className="w-3.5 h-3.5 mr-1" /> : <Play className="w-3.5 h-3.5 mr-1" />}
              {isActive ? 'Stop' : 'Activate'}
            </Button>
          </div>
        </div>

        {isActive && config && (
          <>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-3">
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Managed Bots</p>
                <p className="text-lg font-bold text-white" data-testid="cc-managed-count">{managedBots.length}/{config.settings?.maxManagedBots || 5}</p>
              </div>
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Strategies</p>
                <p className="text-sm font-bold text-cyan-400" data-testid="cc-strategies">
                  {(status?.botTypesActive || []).length > 0
                    ? (status?.botTypesActive || []).map(t => BOT_TYPE_LABELS[t] || t).join(', ')
                    : 'None'}
                </p>
              </div>
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Rotations</p>
                <p className="text-lg font-bold text-yellow-400" data-testid="cc-rotations">{config.totalRotations}</p>
              </div>
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Total P&L</p>
                <p className={`text-lg font-bold ${config.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`} data-testid="cc-total-pnl">
                  ${config.totalProfit.toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Risk Level</p>
                <p className={`text-lg font-bold ${config.settings?.riskLevel === 'aggressive' ? 'text-red-400' : config.settings?.riskLevel === 'conservative' ? 'text-blue-400' : 'text-yellow-400'}`}>
                  {(config.settings?.riskLevel || 'moderate').charAt(0).toUpperCase() + (config.settings?.riskLevel || 'moderate').slice(1)}
                </p>
              </div>
              <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                <p className="text-[10px] text-gray-500 uppercase">Last Scan</p>
                <p className="text-sm font-bold text-gray-300">
                  {config.lastScanAt ? new Date(config.lastScanAt).toLocaleTimeString() : 'Pending'}
                </p>
              </div>
            </div>

            {(() => {
              const totalCapital = Math.max(1, config.settings?.totalCapital || 1000);
              const allocated = config.allocatedCapital || 0;
              const available = Math.max(0, totalCapital - allocated);
              const utilization = Math.min(100, (allocated / totalCapital) * 100);
              return (
                <div className="mt-3 bg-gray-800/60 rounded-lg p-3" data-testid="cc-capital-display">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-[10px] text-gray-500 uppercase flex items-center gap-1">
                      <DollarSign className="w-3 h-3" /> Capital Allocation
                    </p>
                    <p className="text-[10px] text-gray-400">{utilization.toFixed(1)}% utilized</p>
                  </div>
                  <div className="w-full bg-gray-700/50 rounded-full h-2.5 mb-2">
                    <div
                      className={`h-2.5 rounded-full transition-all duration-500 ${utilization > 80 ? 'bg-red-500' : utilization > 50 ? 'bg-yellow-500' : 'bg-green-500'}`}
                      style={{ width: `${utilization}%` }}
                      data-testid="cc-capital-bar"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="text-[10px] text-gray-500">Total Capital</p>
                      <p className="text-sm font-bold text-white" data-testid="cc-total-capital-display">${totalCapital.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-500">Allocated</p>
                      <p className="text-sm font-bold text-yellow-400" data-testid="cc-allocated-capital">${allocated.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-500">Available</p>
                      <p className="text-sm font-bold text-green-400" data-testid="cc-available-capital">${available.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              );
            })()}
          </>
        )}
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-gray-900/70 border border-gray-800 rounded-xl p-4 overflow-hidden"
          >
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Settings className="w-4 h-4 text-yellow-400" /> Command Center Settings
            </h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Exchange</label>
                    <select
                      value={config?.exchange || 'binance'}
                      onChange={e => changeExchange(e.target.value)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-exchange-select"
                    >
                      {EXCHANGES.map(ex => (
                        <option key={ex.id} value={ex.id}>
                          {ex.name}{connectedExchanges.includes(ex.id) ? ' ✓' : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Risk Level</label>
                    <select
                      value={settingsForm.riskLevel}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, riskLevel: e.target.value as any } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-risk-select"
                    >
                      <option value="conservative">Conservative</option>
                      <option value="moderate">Moderate</option>
                      <option value="aggressive">Aggressive</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Max Bots</label>
                    <input
                      type="number" min={1} max={20}
                      value={settingsForm.maxManagedBots}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, maxManagedBots: parseInt(e.target.value) || 5 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-max-bots"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Investment Per Bot ($)</label>
                    <input
                      type="number" min={1} step={1}
                      value={settingsForm.investmentPerBot || ''}
                      onChange={e => {
                        const val = e.target.value;
                        setSettingsForm(prev => prev ? { ...prev, investmentPerBot: val === '' ? 0 : parseFloat(val) } : prev);
                      }}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-investment"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        setLoadingRec(true);
                        try {
                          const res = await fetch('/api/command-center/recommend-allocation', { credentials: 'include' });
                          if (res.ok) {
                            const data = await res.json();
                            setAllocationRec(data);
                            if (data.optimal) {
                              setSettingsForm(prev => prev ? { ...prev, investmentPerBot: data.optimal.investmentPerBot } : prev);
                            }
                          }
                        } catch {}
                        setLoadingRec(false);
                      }}
                      className="mt-1 w-full text-[10px] py-1 px-2 bg-yellow-600/20 hover:bg-yellow-600/40 border border-yellow-600/30 text-yellow-400 rounded-lg transition-colors flex items-center justify-center gap-1"
                      data-testid="cc-smart-allocate"
                    >
                      <Zap className="w-3 h-3" />
                      {loadingRec ? 'Calculating...' : 'Smart Allocate (Fee-Optimized)'}
                    </button>
                    {allocationRec?.optimal && (
                      <div className="mt-1 p-2 bg-yellow-900/20 border border-yellow-700/30 rounded-lg" data-testid="cc-allocation-rec">
                        <p className="text-[10px] text-yellow-400 font-medium">
                          Recommended: ${allocationRec.optimal.investmentPerBot}/bot
                          <span className="text-gray-400"> • {allocationRec.optimal.effectiveBots} bots • {allocationRec.optimal.capitalUtilization}% utilized</span>
                        </p>
                        <p className="text-[9px] text-gray-500 mt-0.5">
                          {allocationRec.exchange} fees: {(allocationRec.exchangeFees.roundTrip * 100).toFixed(2)}% round-trip
                          • Break-even: {allocationRec.optimal.breakEvenMove}% move
                        </p>
                        <p className="text-[9px] text-green-400/70 mt-0.5">{allocationRec.optimal.recommendation}</p>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Capital Reserve (%)</label>
                    <input
                      type="number" min={0} max={80} step={5}
                      value={(settingsForm as any).reservePercent || 20}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, reservePercent: parseInt(e.target.value) || 20 } as any : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-reserve-percent"
                    />
                    <p className="text-[9px] text-gray-500 mt-0.5">Keeps {(settingsForm as any).reservePercent || 20}% in reserve for new opportunities</p>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Min Opportunity Score</label>
                    <input
                      type="number" min={30} max={95}
                      value={settingsForm.minOpportunityScore}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, minOpportunityScore: parseInt(e.target.value) || 70 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-min-score"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Scan Interval (sec)</label>
                    <input
                      type="number" min={10} max={300}
                      value={settingsForm.scanIntervalSeconds}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, scanIntervalSeconds: parseInt(e.target.value) || 30 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-scan-interval"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Rotation Cooldown (min)</label>
                    <input
                      type="number" min={1} max={60}
                      value={settingsForm.rotationCooldownMinutes}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, rotationCooldownMinutes: parseInt(e.target.value) || 5 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-cooldown"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Min Hold Time (min)</label>
                    <input
                      type="number" min={1} max={120}
                      value={settingsForm.minHoldMinutes}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, minHoldMinutes: parseInt(e.target.value) || 10 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-min-hold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Underperform Timeout (min)</label>
                    <input
                      type="number" min={5} max={120}
                      value={settingsForm.underperformMinutes}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, underperformMinutes: parseInt(e.target.value) || 15 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-underperform-timeout"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Profit Lock Threshold (%)</label>
                    <input
                      type="number" min={0.1} max={50} step={0.1}
                      value={settingsForm.profitLockThreshold}
                      onChange={e => setSettingsForm(prev => prev ? { ...prev, profitLockThreshold: parseFloat(e.target.value) || 2 } : prev)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-profit-lock"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 block mb-1">Total Capital ($)</label>
                    <input
                      type="number" min={1} step={1}
                      value={settingsForm.totalCapital || ''}
                      onChange={e => {
                        const val = e.target.value;
                        setSettingsForm(prev => prev ? { ...prev, totalCapital: val === '' ? 0 : parseFloat(val) } : prev);
                      }}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-xs"
                      data-testid="cc-total-capital"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const ex = config?.exchange || 'binance';
                          const res = await fetch(`/api/exchange/balance?exchangeId=${encodeURIComponent(ex)}`, { credentials: 'include' });
                          if (res.ok) {
                            const data = await res.json();
                            if (data.error) {
                              toast({ title: 'Sync failed', description: data.error, variant: 'destructive' });
                              return;
                            }
                            const balance = Math.floor(data.usd * 100) / 100;
                            setSettingsForm(prev => prev ? { ...prev, totalCapital: balance } : prev);
                            toast({ title: `Synced from ${ex}: $${balance.toFixed(2)}` });
                          } else {
                            const err = await res.json().catch(() => null);
                            toast({ title: 'Sync failed', description: err?.message || `HTTP ${res.status}`, variant: 'destructive' });
                          }
                        } catch (e: any) {
                          toast({ title: 'Sync failed', description: e.message || 'Network error', variant: 'destructive' });
                        }
                      }}
                      className="mt-1 w-full text-[10px] py-1 px-2 bg-blue-600/20 hover:bg-blue-600/40 border border-blue-600/30 text-blue-400 rounded-lg transition-colors flex items-center justify-center gap-1"
                      data-testid="cc-sync-balance"
                    >
                      <RefreshCw className="w-3 h-3" /> Sync from Exchange Balance
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-4 mt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300">
                    <input type="checkbox" checked={settingsForm.paperTrading} onChange={e => setSettingsForm(prev => prev ? { ...prev, paperTrading: e.target.checked } : prev)} className="rounded" data-testid="cc-paper-trading" />
                    Paper Trading Mode
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300">
                    <input type="checkbox" checked={settingsForm.autoTechSelection} onChange={e => setSettingsForm(prev => prev ? { ...prev, autoTechSelection: e.target.checked } : prev)} className="rounded" data-testid="cc-auto-tech" />
                    Auto-Select Technologies
                  </label>
                </div>
                <Button size="sm" onClick={saveSettings} className="bg-yellow-600 hover:bg-yellow-700 text-xs mt-2" data-testid="cc-save-settings">
                  Save Settings
                </Button>
              </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
        <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
          <Bot className="w-4 h-4 text-cyan-400" /> Managed Bots ({managedBots.length})
        </h3>
        {managedBots.length === 0 ? (
          <p className="text-xs text-gray-500 text-center py-4" data-testid="cc-no-bots">
            {isActive ? 'Scanning for opportunities to deploy bots...' : 'Activate Command Center to auto-manage bots'}
          </p>
        ) : (
          <div className="space-y-2">
            {managedBots.map(bot => (
              <div
                key={bot.botId}
                className={`flex items-center justify-between bg-gray-800/60 rounded-lg p-3 border ${bot.isUnderperforming ? 'border-red-500/30' : 'border-gray-700/50'}`}
                data-testid={`cc-bot-${bot.botId}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${bot.status === 'running' ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-white">{bot.pair}</p>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-gray-700 text-cyan-400">{BOT_TYPE_LABELS[bot.type] || bot.type}</span>
                    </div>
                    <p className="text-[10px] text-gray-500">
                      Hold: {bot.holdTimeMinutes}m | Signal: {bot.signalStrength}%
                      {bot.isUnderperforming && <span className="text-red-400 ml-1">(Underperforming)</span>}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className={`text-sm font-bold ${bot.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      ${bot.pnl.toFixed(2)}
                    </p>
                    <p className={`text-[10px] ${bot.pnlPercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {bot.pnlPercent >= 0 ? '+' : ''}{bot.pnlPercent}%
                    </p>
                  </div>
                  {bot.isUnderperforming && (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
        <button
          onClick={() => { setShowSmartAlloc(!showSmartAlloc); if (!smartAllocations && !showSmartAlloc) fetchSmartAllocations(); }}
          className="w-full flex items-center justify-between text-sm font-semibold text-white mb-2"
          data-testid="cc-smart-alloc-toggle"
        >
          <span className="flex items-center gap-2">
            <Target className="w-4 h-4 text-purple-400" /> Smart Capital Allocation™
            {smartAllocations?.smartAllocations?.length > 0 && <span className="text-xs text-purple-400">({smartAllocations.smartAllocations.length} positions)</span>}
          </span>
          {showSmartAlloc ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        <AnimatePresence>
          {showSmartAlloc && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              {loadingSmartAlloc ? (
                <div className="flex items-center justify-center py-4"><RefreshCw className="w-4 h-4 animate-spin text-purple-400 mr-2" /> <span className="text-xs text-gray-400">Analyzing top coins...</span></div>
              ) : !smartAllocations ? (
                <div className="text-center py-3">
                  <Button size="sm" onClick={fetchSmartAllocations} className="bg-purple-600 hover:bg-purple-700 text-xs" data-testid="cc-load-smart-alloc">
                    <Target className="w-3 h-3 mr-1" /> Analyze Top 5 → Top 3
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="grid grid-cols-3 gap-2 text-[10px]">
                    <div className="bg-gray-800/60 rounded p-2 text-center">
                      <p className="text-gray-500">Available</p>
                      <p className="text-white font-bold">${smartAllocations.availableCapital?.toFixed(2)}</p>
                    </div>
                    <div className="bg-gray-800/60 rounded p-2 text-center">
                      <p className="text-gray-500">Deploying</p>
                      <p className="text-purple-400 font-bold">${smartAllocations.totalDeploying?.toFixed(2)}</p>
                    </div>
                    <div className="bg-gray-800/60 rounded p-2 text-center">
                      <p className="text-gray-500">Reserve ({smartAllocations.reservePercent}%)</p>
                      <p className="text-yellow-400 font-bold">${smartAllocations.reserveAmount?.toFixed(2)}</p>
                    </div>
                  </div>

                  {smartAllocations.top5Coins?.length > 0 && (
                    <div className="border border-gray-700/50 rounded-lg p-2">
                      <p className="text-[10px] text-gray-500 mb-1">Top 5 Scanned → Top {smartAllocations.smartAllocations?.length || 0} Selected</p>
                      {smartAllocations.top5Coins.map((c: any, i: number) => {
                        const isSelected = smartAllocations.smartAllocations?.some((a: any) => a.pair === c.pair);
                        return (
                          <div key={c.pair} className={`flex items-center justify-between py-0.5 text-[10px] ${isSelected ? 'text-white' : 'text-gray-600 line-through'}`}>
                            <span>{i + 1}. {c.pair} ({c.score}%)</span>
                            <span>{c.suggestedBotType.toUpperCase()}{isSelected ? ' ✓' : ''}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {smartAllocations.smartAllocations?.map((alloc: any, i: number) => (
                    <div key={alloc.pair} className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-2.5" data-testid={`cc-smart-alloc-${i}`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-semibold text-white">{alloc.pair}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">{(BOT_TYPE_LABELS[alloc.botType] || alloc.botType).toUpperCase()}</span>
                      </div>
                      <div className="text-xs text-purple-300 font-bold mb-1">${alloc.investment} total investment</div>
                      {alloc.gridLevels && (
                        <p className="text-[10px] text-gray-400">{alloc.gridLevels} grids × ${alloc.perGridAmount?.toFixed(2)}/grid</p>
                      )}
                      {alloc.safetyOrders && (
                        <p className="text-[10px] text-gray-400">Base: ${(alloc.investment * 0.3).toFixed(2)} + {alloc.safetyOrders} safety orders × ${alloc.perOrderAmount?.toFixed(2)}/order</p>
                      )}
                      <p className="text-[9px] text-gray-500 mt-0.5">{alloc.allocationReason}</p>
                    </div>
                  ))}

                  <Button size="sm" onClick={fetchSmartAllocations} variant="outline" className="w-full text-xs border-purple-500/30 text-purple-400 hover:bg-purple-500/10" data-testid="cc-refresh-smart-alloc">
                    <RefreshCw className="w-3 h-3 mr-1" /> Refresh Analysis
                  </Button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {(status?.connectedExchanges?.length || 0) >= 2 && (
        <div className="bg-gray-900/50 border border-cyan-800/50 rounded-xl p-4">
          <button
            onClick={() => { setShowArbitrage(!showArbitrage); if (!arbitrageData && !showArbitrage) fetchArbitrage(); }}
            className="w-full flex items-center justify-between text-sm font-semibold text-white mb-2"
            data-testid="cc-arbitrage-toggle"
          >
            <span className="flex items-center gap-2">
              <ArrowRightLeft className="w-4 h-4 text-cyan-400" /> Cross-Exchange Arbitrage™
              {arbitrageData?.profitableOpportunities > 0 && (
                <span className="text-xs px-1.5 py-0.5 rounded bg-green-500/20 text-green-400 font-bold animate-pulse">{arbitrageData.profitableOpportunities} profitable</span>
              )}
            </span>
            {showArbitrage ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          <AnimatePresence>
            {showArbitrage && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                {loadingArbitrage ? (
                  <div className="flex items-center justify-center py-4"><RefreshCw className="w-4 h-4 animate-spin text-cyan-400 mr-2" /> <span className="text-xs text-gray-400">Scanning across {status?.connectedExchanges?.length} exchanges...</span></div>
                ) : !arbitrageData ? (
                  <div className="text-center py-3">
                    <Button size="sm" onClick={fetchArbitrage} className="bg-cyan-600 hover:bg-cyan-700 text-xs" data-testid="cc-load-arbitrage">
                      <ArrowRightLeft className="w-3 h-3 mr-1" /> Scan Arbitrage Opportunities
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-[10px] text-gray-400 mb-1">
                      <span>Exchanges: {arbitrageData.connectedExchanges?.join(', ')}</span>
                      <span>|</span>
                      <span>{arbitrageData.totalOpportunities} scanned</span>
                      <span>|</span>
                      <span className="text-green-400">{arbitrageData.profitableOpportunities} profitable (after ALL fees)</span>
                    </div>
                    {arbitrageData.opportunities?.filter((a: any) => a.profitable).length === 0 && (
                      <p className="text-xs text-gray-500 text-center py-2">No profitable arbitrage found after accounting for trading fees, withdrawal fees, and transfer costs</p>
                    )}
                    {arbitrageData.opportunities?.filter((a: any) => a.profitable).slice(0, 5).map((arb: any, i: number) => (
                      <div key={`${arb.pair}-${i}`} className="bg-cyan-900/20 border border-cyan-500/30 rounded-lg p-2.5" data-testid={`cc-arb-${i}`}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-semibold text-white">{arb.pair}</span>
                          <span className="text-xs text-green-400 font-bold">+${arb.netProfitUsd} ({arb.netProfitPercent}%)</span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px]">
                          <span className="text-green-400">BUY {arb.buyExchange}</span>
                          <span className="text-gray-500">@${arb.buyPrice < 1 ? arb.buyPrice.toFixed(6) : arb.buyPrice.toFixed(2)}</span>
                          <ArrowRightLeft className="w-2.5 h-2.5 text-gray-500" />
                          <span className="text-red-400">SELL {arb.sellExchange}</span>
                          <span className="text-gray-500">@${arb.sellPrice < 1 ? arb.sellPrice.toFixed(6) : arb.sellPrice.toFixed(2)}</span>
                        </div>
                        <p className="text-[9px] text-gray-500 mt-1">Spread: {arb.spreadPercent}% | Trade: ${arb.tradeAmount} | {arb.feeBreakdown}</p>
                      </div>
                    ))}
                    <Button size="sm" onClick={fetchArbitrage} variant="outline" className="w-full text-xs border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10" data-testid="cc-refresh-arbitrage">
                      <RefreshCw className="w-3 h-3 mr-1" /> Rescan Arbitrage
                    </Button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
        <button
          onClick={() => setShowOpportunities(!showOpportunities)}
          className="w-full flex items-center justify-between text-sm font-semibold text-white mb-2"
          data-testid="cc-opportunities-toggle"
        >
          <span className="flex items-center gap-2">
            <Target className="w-4 h-4 text-yellow-400" /> Top Opportunities
            {opportunities.length > 0 && <span className="text-xs text-gray-500">({opportunities.length})</span>}
          </span>
          {showOpportunities ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        <AnimatePresence>
          {showOpportunities && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              {opportunities.length === 0 ? (
                <p className="text-xs text-gray-500 text-center py-4">
                  {isActive ? 'Scanning for opportunities...' : 'Activate Command Center to scan'}
                </p>
              ) : (
                <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
                  {opportunities.slice(0, 15).map((op, i) => (
                    <div key={op.pair} className={`flex items-center justify-between p-2 rounded-lg border ${getScoreBg(op.score)}`} data-testid={`cc-opportunity-${i}`}>
                      <div className="flex items-center gap-2">
                        <span className={`text-lg font-bold w-8 text-center ${getScoreColor(op.score)}`}>{op.score}</span>
                        <div>
                          <p className="text-sm font-medium text-white">{op.pair}</p>
                          <p className="text-[10px] text-gray-400">{op.reason}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-right">
                        <div>
                          <p className="text-xs text-gray-300">${op.price < 1 ? op.price.toFixed(6) : op.price.toFixed(2)}</p>
                          <p className={`text-[10px] ${op.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {op.change24h >= 0 ? '+' : ''}{op.change24h.toFixed(1)}%
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-gray-500">Vol: {(op.volume24h / 1000000).toFixed(1)}M</p>
                          <p className="text-[10px] text-gray-500">RSI: {op.rsiEstimate}</p>
                        </div>
                        <div className={`w-2 h-2 rounded-full ${op.trendDirection === 'bullish' ? 'bg-green-400' : op.trendDirection === 'bearish' ? 'bg-red-400' : 'bg-gray-400'}`} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
        <button
          onClick={() => { setShowAnalytics(!showAnalytics); if (!showAnalytics) fetchAnalytics(); }}
          className="w-full flex items-center justify-between text-sm font-semibold text-white mb-2"
          data-testid="cc-analytics-toggle"
        >
          <span className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-green-400" /> Performance Analytics
            {analytics?.liveAnalytics?.totalSignals ? (
              <span className="text-[10px] text-gray-500">({analytics.liveAnalytics.totalSignals} signals tracked)</span>
            ) : null}
          </span>
          {showAnalytics ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        <AnimatePresence>
          {showAnalytics && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              {analyticsError ? (
                <div className="text-xs text-center py-4">
                  <p className="text-yellow-400">{analyticsError}</p>
                  <button onClick={fetchAnalytics} className="text-cyan-400 underline mt-1" data-testid="cc-analytics-retry">Retry</button>
                </div>
              ) : !analytics ? (
                <p className="text-xs text-gray-500 text-center py-4">Loading analytics...</p>
              ) : (
                <div className="space-y-3 mt-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Signals Tracked</p>
                      <p className="text-lg font-bold text-white" data-testid="cc-total-signals">{analytics.liveAnalytics.totalSignals}</p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Win Rate (5m)</p>
                      <p className={`text-lg font-bold ${(analytics.liveAnalytics.winRate5m || 0) >= 50 ? 'text-green-400' : 'text-red-400'}`} data-testid="cc-win-rate-5m">
                        {analytics.liveAnalytics.winRate5m !== null ? `${analytics.liveAnalytics.winRate5m}%` : '—'}
                      </p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Win Rate (30m)</p>
                      <p className={`text-lg font-bold ${(analytics.liveAnalytics.winRate30m || 0) >= 50 ? 'text-green-400' : 'text-red-400'}`} data-testid="cc-win-rate-30m">
                        {analytics.liveAnalytics.winRate30m !== null ? `${analytics.liveAnalytics.winRate30m}%` : '—'}
                      </p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Win Rate (60m)</p>
                      <p className={`text-lg font-bold ${(analytics.liveAnalytics.winRate60m || 0) >= 50 ? 'text-green-400' : 'text-red-400'}`} data-testid="cc-win-rate-60m">
                        {analytics.liveAnalytics.winRate60m !== null ? `${analytics.liveAnalytics.winRate60m}%` : '—'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Avg Profit 5m</p>
                      <p className={`text-sm font-bold ${(analytics.liveAnalytics.avgProfitPotential5m || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {analytics.liveAnalytics.avgProfitPotential5m !== null ? `${analytics.liveAnalytics.avgProfitPotential5m}%` : '—'}
                      </p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Avg Profit 15m</p>
                      <p className={`text-sm font-bold ${(analytics.liveAnalytics.avgProfitPotential15m || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {analytics.liveAnalytics.avgProfitPotential15m !== null ? `${analytics.liveAnalytics.avgProfitPotential15m}%` : '—'}
                      </p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Avg Profit 30m</p>
                      <p className={`text-sm font-bold ${(analytics.liveAnalytics.avgProfitPotential30m || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {analytics.liveAnalytics.avgProfitPotential30m !== null ? `${analytics.liveAnalytics.avgProfitPotential30m}%` : '—'}
                      </p>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2 text-center">
                      <p className="text-[10px] text-gray-500 uppercase">Avg Profit 60m</p>
                      <p className={`text-sm font-bold ${(analytics.liveAnalytics.avgProfitPotential60m || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {analytics.liveAnalytics.avgProfitPotential60m !== null ? `${analytics.liveAnalytics.avgProfitPotential60m}%` : '—'}
                      </p>
                    </div>
                  </div>

                  {analytics.liveAnalytics.bestSignal && (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-2">
                        <p className="text-[10px] text-green-500 uppercase">Best Signal</p>
                        <p className="text-sm font-bold text-green-400">{analytics.liveAnalytics.bestSignal.pair}</p>
                        <p className="text-[10px] text-gray-400">Score: {analytics.liveAnalytics.bestSignal.score} | Profit: {analytics.liveAnalytics.bestSignal.profit60m}% | Type: {BOT_TYPE_LABELS[analytics.liveAnalytics.bestSignal.botType] || analytics.liveAnalytics.bestSignal.botType}</p>
                      </div>
                      {analytics.liveAnalytics.worstSignal && (
                        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2">
                          <p className="text-[10px] text-red-500 uppercase">Worst Signal</p>
                          <p className="text-sm font-bold text-red-400">{analytics.liveAnalytics.worstSignal.pair}</p>
                          <p className="text-[10px] text-gray-400">Score: {analytics.liveAnalytics.worstSignal.score} | Profit: {analytics.liveAnalytics.worstSignal.profit60m}% | Type: {BOT_TYPE_LABELS[analytics.liveAnalytics.worstSignal.botType] || analytics.liveAnalytics.worstSignal.botType}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {Object.keys(analytics.liveAnalytics.byBotType).length > 0 && (
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Performance by Strategy</p>
                      <div className="space-y-1">
                        {Object.entries(analytics.liveAnalytics.byBotType).map(([type, stats]: [string, any]) => (
                          <div key={type} className="flex items-center justify-between bg-gray-800/40 rounded p-1.5 text-xs">
                            <span className="text-cyan-400">{BOT_TYPE_LABELS[type] || type}</span>
                            <div className="flex items-center gap-3 text-gray-300">
                              <span>{stats.count} signals</span>
                              <span className={stats.winRate30m >= 50 ? 'text-green-400' : 'text-red-400'}>
                                WR: {stats.winRate30m !== null ? `${stats.winRate30m}%` : '—'}
                              </span>
                              <span className={stats.avgProfit30m >= 0 ? 'text-green-400' : 'text-red-400'}>
                                Avg: {stats.avgProfit30m !== null ? `${stats.avgProfit30m}%` : '—'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {Object.keys(analytics.liveAnalytics.byScoreRange).length > 0 && (
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Performance by Score Range</p>
                      <div className="space-y-1">
                        {Object.entries(analytics.liveAnalytics.byScoreRange).map(([range, stats]: [string, any]) => (
                          <div key={range} className="flex items-center justify-between bg-gray-800/40 rounded p-1.5 text-xs">
                            <span className="text-yellow-400">Score {range}</span>
                            <div className="flex items-center gap-3 text-gray-300">
                              <span>{stats.count} signals</span>
                              <span className={stats.winRate30m >= 50 ? 'text-green-400' : 'text-red-400'}>
                                WR: {stats.winRate30m !== null ? `${stats.winRate30m}%` : '—'}
                              </span>
                              <span className={stats.avgProfit30m >= 0 ? 'text-green-400' : 'text-red-400'}>
                                Avg: {stats.avgProfit30m !== null ? `${stats.avgProfit30m}%` : '—'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {analytics.dbAnalytics && (
                    <div className="bg-gray-800/40 rounded-lg p-2">
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Database Statistics (Persisted)</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-gray-300">
                        <div>Scans: <span className="text-white font-medium">{analytics.dbAnalytics.totalScans}</span></div>
                        <div>Rotations: <span className="text-white font-medium">{analytics.dbAnalytics.totalRotations}</span></div>
                        <div>Bots Created: <span className="text-white font-medium">{analytics.dbAnalytics.totalBotsCreated}</span></div>
                        <div>Prices Tracked: <span className="text-white font-medium">{analytics.dbAnalytics.totalPriceTracked}</span></div>
                        <div>Profitable: <span className="text-green-400 font-medium">{analytics.dbAnalytics.profitableSignals}</span></div>
                        <div>Unprofitable: <span className="text-red-400 font-medium">{analytics.dbAnalytics.unprofitableSignals}</span></div>
                        <div>DB Win Rate: <span className={`font-medium ${(analytics.dbAnalytics.dbWinRate || 0) >= 50 ? 'text-green-400' : 'text-red-400'}`}>{analytics.dbAnalytics.dbWinRate !== null ? `${analytics.dbAnalytics.dbWinRate}%` : '—'}</span></div>
                        <div>Avg Profit: <span className={`font-medium ${analytics.dbAnalytics.avgSignalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>{analytics.dbAnalytics.avgSignalProfit}%</span></div>
                      </div>
                    </div>
                  )}

                  {analytics.recentPriceTracking && analytics.recentPriceTracking.length > 0 && (
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Recent Price Tracking</p>
                      <div className="space-y-1 max-h-[200px] overflow-y-auto">
                        {analytics.recentPriceTracking.slice(0, 15).map((pt, i) => (
                          <div key={i} className="flex items-center justify-between bg-gray-800/40 rounded p-1.5 text-[11px]">
                            <span className="text-gray-300 truncate flex-1">{pt.data?.pair}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">{pt.data?.minutesAfter}m</span>
                              <span className={`font-medium ${(pt.data?.profitPercent || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                {pt.data?.profitPercent >= 0 ? '+' : ''}{pt.data?.profitPercent}%
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
        <button
          onClick={() => { setShowLogs(!showLogs); if (!showLogs) fetchLogs(); }}
          className="w-full flex items-center justify-between text-sm font-semibold text-white mb-2"
          data-testid="cc-logs-toggle"
        >
          <span className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" /> Activity Log
          </span>
          {showLogs ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        <AnimatePresence>
          {showLogs && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              {logs.length === 0 ? (
                <p className="text-xs text-gray-500 text-center py-4">No activity yet</p>
              ) : (
                <div className="space-y-1 max-h-[300px] overflow-y-auto">
                  {logs.map(log => (
                    <div key={log.id} className="flex items-start gap-2 p-2 bg-gray-800/40 rounded-lg" data-testid={`cc-log-${log.id}`}>
                      {getLogIcon(log.logType)}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-300 break-words">{log.message}</p>
                        {(log.logType === 'rotation' || log.logType === 'fee_analysis' || log.logType === 'rotation_skipped') && (log.data?.feeBreakdown || log.data?.feeAnalysis?.feeBreakdown) && (
                          <p className="text-[10px] text-yellow-400/80 mt-0.5" data-testid={`cc-log-fee-${log.id}`}>
                            <Scale className="w-3 h-3 inline mr-1" />
                            {log.data.feeBreakdown || log.data.feeAnalysis?.feeBreakdown}
                            {(log.data.totalFees ?? log.data.feeAnalysis?.totalFees) !== undefined && ` • Fees: $${Number(log.data.totalFees ?? log.data.feeAnalysis?.totalFees).toFixed(2)}`}
                            {(log.data.estimatedNetGain ?? log.data.feeAnalysis?.estimatedNetGain) !== undefined && ` • Est. Net: $${Number(log.data.estimatedNetGain ?? log.data.feeAnalysis?.estimatedNetGain).toFixed(2)}`}
                          </p>
                        )}
                        <p className="text-[10px] text-gray-600">{new Date(log.createdAt).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="text-center space-y-1">
        <p className="text-[10px] text-gray-600">
          Alpha Autonomous Command Center™ (AACC™) is proprietary technology of Alpha Unlimited Trading.
        </p>
        <p className="text-[10px] text-gray-600">
          Proprietary Technology • Patent Pending
        </p>
      </div>
    </div>
  );
}
