/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha VoiceCommandWidget™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_6c25693d71ca2fed2e989c54
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, X, Volume2, ChevronUp, ChevronDown } from 'lucide-react';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

interface VoiceCommand {
  patterns: string[];
  action: (args: string, navigate: (path: string) => void) => string;
  description: string;
  category: string;
}

const COMMANDS: VoiceCommand[] = [
  {
    patterns: ['show bitcoin', 'bitcoin price', 'btc price', 'what is bitcoin'],
    action: (_, nav) => { nav('/terminal?symbol=BTCUSDT'); return 'Opening Bitcoin on terminal'; },
    description: 'Show Bitcoin price chart',
    category: 'Trading',
  },
  {
    patterns: ['show ethereum', 'ethereum price', 'eth price', 'what is ethereum'],
    action: (_, nav) => { nav('/terminal?symbol=ETHUSDT'); return 'Opening Ethereum on terminal'; },
    description: 'Show Ethereum price chart',
    category: 'Trading',
  },
  {
    patterns: ['show solana', 'solana price', 'sol price'],
    action: (_, nav) => { nav('/terminal?symbol=SOLUSDT'); return 'Opening Solana on terminal'; },
    description: 'Show Solana price chart',
    category: 'Trading',
  },
  {
    patterns: ['open terminal', 'go to terminal', 'trading terminal', 'show terminal'],
    action: (_, nav) => { nav('/terminal'); return 'Opening trading terminal'; },
    description: 'Open the trading terminal',
    category: 'Navigation',
  },
  {
    patterns: ['open arbitrage', 'go to arbitrage', 'arbitrage scanner', 'show arbitrage'],
    action: (_, nav) => { nav('/arbitrage'); return 'Opening arbitrage scanner'; },
    description: 'Open arbitrage scanner',
    category: 'Navigation',
  },
  {
    patterns: ['market sentiment', 'news sentiment', 'show sentiment', 'how is the market'],
    action: (_, nav) => { nav('/news-sentiment'); return 'Opening AI sentiment analysis'; },
    description: 'Show market sentiment',
    category: 'Data',
  },
  {
    patterns: ['go home', 'home page', 'main page', 'go to home'],
    action: (_, nav) => { nav('/'); return 'Going to home page'; },
    description: 'Navigate to home',
    category: 'Navigation',
  },
  {
    patterns: ['my account', 'open account', 'show account', 'profile', 'my profile'],
    action: (_, nav) => { nav('/account'); return 'Opening your account'; },
    description: 'Open account page',
    category: 'Navigation',
  },
  {
    patterns: ['show bots', 'my bots', 'trading bots', 'open bots', 'ai bots'],
    action: (_, nav) => { nav('/terminal'); return 'Opening trading terminal with bots'; },
    description: 'Show trading bots',
    category: 'Trading',
  },
  {
    patterns: ['portfolio', 'my portfolio', 'portfolio health', 'show portfolio'],
    action: (_, nav) => { nav('/portfolio-health'); return 'Opening portfolio health'; },
    description: 'Show portfolio health',
    category: 'Data',
  },
  {
    patterns: ['learn', 'learning center', 'education', 'teach me', 'learn trading', 'crypto education'],
    action: (_, nav) => { nav('/learning-center'); return 'Opening learning center'; },
    description: 'Open the learning center',
    category: 'Navigation',
  },
  {
    patterns: ['whale watch', 'show whales', 'whale activity'],
    action: (_, nav) => { nav('/features'); return 'Opening features with whale watch'; },
    description: 'Show whale activity',
    category: 'Data',
  },
  {
    patterns: ['exchange', 'auc exchange', 'open exchange'],
    action: (_, nav) => { nav('/exchange'); return 'Opening AUC Exchange'; },
    description: 'Open AUC Exchange',
    category: 'Navigation',
  },
  {
    patterns: ['show xrp', 'xrp price', 'ripple price'],
    action: (_, nav) => { nav('/terminal?symbol=XRPUSDT'); return 'Opening XRP on terminal'; },
    description: 'Show XRP price chart',
    category: 'Trading',
  },
  {
    patterns: ['show doge', 'dogecoin price', 'doge price'],
    action: (_, nav) => { nav('/terminal?symbol=DOGEUSDT'); return 'Opening Dogecoin on terminal'; },
    description: 'Show Dogecoin price chart',
    category: 'Trading',
  },
  {
    patterns: ['show bnb', 'bnb price', 'binance coin'],
    action: (_, nav) => { nav('/terminal?symbol=BNBUSDT'); return 'Opening BNB on terminal'; },
    description: 'Show BNB price chart',
    category: 'Trading',
  },
  {
    patterns: ['mining', 'open mining', 'mining center'],
    action: (_, nav) => { nav('/mining-command-center'); return 'Opening mining command center'; },
    description: 'Open mining center',
    category: 'Navigation',
  },
  {
    patterns: ['forensic', 'forensics', 'open forensics', 'command center'],
    action: (_, nav) => { nav('/forensic-command-center'); return 'Opening forensic command center'; },
    description: 'Open forensic center',
    category: 'Navigation',
  },
];

export function VoiceCommandWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [supported, setSupported] = useState(true);
  const recognitionRef = useRef<any>(null);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      const current = Array.from(event.results)
        .map((r: any) => r[0].transcript)
        .join('');
      setTranscript(current);

      if (event.results[0].isFinal) {
        processCommand(current.toLowerCase().trim());
      }
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'aborted') {
        setFeedback('Could not hear you. Try again.');
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
  }, []);

  const processCommand = useCallback((text: string) => {
    for (const cmd of COMMANDS) {
      for (const pattern of cmd.patterns) {
        if (text.includes(pattern)) {
          const result = cmd.action(text, setLocation);
          setFeedback(result);
          toast.success(result);
          return;
        }
      }
    }

    const coinMatch = text.match(/(?:show|price of|open|what is)\s+(\w+)/i);
    if (coinMatch) {
      const coin = coinMatch[1].toUpperCase();
      setLocation(`/terminal?symbol=${coin}USDT`);
      setFeedback(`Trying ${coin} on terminal`);
      toast.info(`Trying ${coin} on terminal`);
      return;
    }

    setFeedback(`Didn't recognize: "${text}". Try "help" for commands.`);
  }, [setLocation]);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.abort();
      setIsListening(false);
    } else {
      setTranscript('');
      setFeedback('');
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch {
        setFeedback('Microphone access needed.');
      }
    }
  }, [isListening]);

  if (!supported) return null;

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-20 right-4 z-50 w-12 h-12 rounded-full bg-gradient-to-br from-[#00D4FF] to-[#0099CC] text-[#0A1628] shadow-lg shadow-[#00D4FF]/20 flex items-center justify-center hover:scale-110 transition-transform"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        data-testid="button-voice-toggle"
        title="Voice Commands"
      >
        <Mic size={20} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-36 right-4 z-50 w-80 bg-[#0D1117] border border-[#1A2942] rounded-2xl shadow-2xl overflow-hidden"
            data-testid="panel-voice-commands"
          >
            <div className="p-4 border-b border-[#1A2942] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 size={16} className="text-[#00D4FF]" />
                <span className="text-sm font-semibold text-white">Voice Commands</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-[#8899A6] hover:text-white">
                <X size={16} />
              </button>
            </div>

            <div className="p-4 space-y-3">
              <div className="text-center">
                <motion.button
                  onClick={toggleListening}
                  className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto transition-all ${
                    isListening
                      ? 'bg-red-500/20 border-2 border-red-500 text-red-400'
                      : 'bg-[#00D4FF]/10 border-2 border-[#00D4FF]/30 text-[#00D4FF] hover:border-[#00D4FF]'
                  }`}
                  animate={isListening ? { scale: [1, 1.1, 1] } : {}}
                  transition={isListening ? { repeat: Infinity, duration: 1.5 } : {}}
                  data-testid="button-voice-listen"
                >
                  {isListening ? <MicOff size={24} /> : <Mic size={24} />}
                </motion.button>
                <p className="text-xs text-[#8899A6] mt-2">
                  {isListening ? 'Listening... speak now' : 'Tap to start listening'}
                </p>
              </div>

              {transcript && (
                <div className="p-2.5 bg-[#161b22] rounded-lg" data-testid="text-voice-transcript">
                  <p className="text-[10px] text-[#8899A6] mb-1">You said:</p>
                  <p className="text-sm text-white">{transcript}</p>
                </div>
              )}

              {feedback && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-2.5 bg-[#00D4FF]/5 border border-[#00D4FF]/20 rounded-lg"
                  data-testid="text-voice-feedback"
                >
                  <p className="text-xs text-[#00D4FF]">{feedback}</p>
                </motion.div>
              )}

              <button
                onClick={() => setShowHelp(!showHelp)}
                className="w-full flex items-center justify-between text-xs text-[#8899A6] hover:text-white py-1"
                data-testid="button-voice-help"
              >
                <span>Available commands</span>
                {showHelp ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
              </button>

              <AnimatePresence>
                {showHelp && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                      {['Navigation', 'Trading', 'Data'].map(cat => {
                        const cmds = COMMANDS.filter(c => c.category === cat);
                        return (
                          <div key={cat}>
                            <p className="text-[10px] text-[#8899A6] font-semibold mb-1">{cat}</p>
                            {cmds.map((cmd, i) => (
                              <div key={i} className="flex items-center gap-2 py-0.5">
                                <span className="text-[10px] text-[#00D4FF] font-mono">"{cmd.patterns[0]}"</span>
                                <span className="text-[10px] text-[#8899A6]">— {cmd.description}</span>
                              </div>
                            ))}
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}