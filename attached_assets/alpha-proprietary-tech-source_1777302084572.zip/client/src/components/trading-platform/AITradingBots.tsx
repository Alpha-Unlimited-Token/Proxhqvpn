/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AI Trading Bot Interface™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - AI Trading Bot Engine™
 * - Multi-Strategy Bot Framework™
 * - Real-Time Signal Processing™
 * - Autonomous Trade Execution™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_da0725e2b98f660b02a62734
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bot, Grid3X3, TrendingDown, Play, Pause, Settings, Trash2,
  Plus, DollarSign, Percent, AlertTriangle, Check, X, Zap,
  BarChart3, Activity, RefreshCw, Lock, Crown, Star, ArrowUpDown,
  Target, TrendingUp, Timer, Radio, Layers, Infinity, ChevronDown,
  ChevronUp, Info, Shield, Brain, LineChart, PieChart, Award,
  Clock, Wallet, AlertCircle, Cpu, Sparkles, Waves, ExternalLink,
  ToggleLeft, ToggleRight, Sliders, Filter, Gauge, Eye, Shuffle,
  FileText, CircleDot, GitMerge, Pencil, Save
} from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

type BotType = 'grid' | 'dca' | 'trailing_stop' | 'twap' | 'signal' | 'arbitrage' | 'martingale' | 'infinity_grid' | 'leveraged_grid' | 'rebalancing' | 'smart_trade' | 'reverse_grid' | 'auto_invest' | 'spot_futures_arb';
type TierLevel = 'free' | 'basic' | 'premium' | 'platinum' | 'alpha';
type BridgeMode = 'off' | 'manual' | 'auto';

interface ProprietaryTechConfig {
  id: string;
  name: string;
  shortName: string;
  description: string;
  color: string;
  minTier: TierLevel;
  boostFactor: number;
}

interface AdvancedFilterConfig {
  id: string;
  name: string;
  description: string;
  color: string;
  minTier: TierLevel;
  boostFactor: number;
}

interface BridgeFusionState {
  enabled: boolean;
  mode: BridgeMode;
  selectedFilters: string[];
  autoAdjust: boolean;
  fusionStrength: number;
}

type CommandType = 'BUY' | 'SELL' | 'TAKE_PROFIT' | 'STOP_LOSS' | 'TRAILING_STOP' | 'DCA_BUY' | 'GRID_BUY' | 'GRID_SELL';
type CommandStatus = 'SENT' | 'FILLED' | 'PENDING' | 'CANCELLED' | 'FAILED';

interface TradeCommand {
  id: string;
  type: CommandType;
  price: number;
  quantity: number;
  timestamp: Date;
  status: CommandStatus;
  exchange: string;
  pair: string;
  pnl?: number;
}

interface TradingBot {
  id: string;
  type: BotType;
  name: string;
  pair: string;
  status: 'running' | 'paused' | 'stopped';
  profit: number;
  profitPercent: number;
  trades: number;
  winRate: number;
  sharpeRatio: number;
  maxDrawdown: number;
  createdAt: Date;
  settings: BotSettings;
  isDemo: boolean;
  activeTech: string[];
  activeFilters: string[];
  bridgeFusion: BridgeFusionState;
  dailyTrades: number;
  dailyLoss: number;
  lastTradeTime: number;
  signalQuality: number;
  connectedExchange: string;
  commandLog: TradeCommand[];
}

interface BotSettings {
  investment: number;
  upperPrice?: number;
  lowerPrice?: number;
  gridCount?: number;
  leverage?: number;
  orderAmount?: number;
  frequency?: 'hourly' | 'daily' | 'weekly' | '4hourly';
  maxOrders?: number;
  takeProfit?: number;
  stopLoss?: number;
  trailingPercent?: number;
  activationPrice?: number;
  safetyOrders?: number;
  safetyOrderSize?: number;
  safetyOrderStep?: number;
  takeProfitLevels?: { price: number; percent: number }[];
  trailingTakeProfit?: boolean;
  trailingStopLoss?: boolean;
  signalSource?: 'rsi' | 'macd' | 'bollinger' | 'ai' | 'custom' | 'acm' | 'ance';
  signalThreshold?: number;
  exchanges?: string[];
  minSpread?: number;
  martingaleMultiplier?: number;
  maxMartingaleSteps?: number;
  ocoEnabled?: boolean;
  cooldownSeconds?: number;
  maxDailyTrades?: number;
  maxDailyLossPercent?: number;
  paperTrading?: boolean;
  positionSizePercent?: number;
}

interface BotTypeConfig {
  id: BotType;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  minTier: TierLevel;
  features: string[];
}

const PROPRIETARY_TECH: ProprietaryTechConfig[] = [
  {
    id: 'acm',
    name: 'Alpha Convergence Matrix™',
    shortName: 'ACM',
    description: 'Multi-dimensional indicator analyzing momentum, volume, smart money flow, trend strength, and volatility',
    color: '#FFD700',
    minTier: 'premium',
    boostFactor: 0.08
  },
  {
    id: 'qfrm',
    name: 'Quantum Flow Resonance Matrix™',
    shortName: 'QFRM',
    description: 'Analyzes price movement jerk, resonance frequencies, and entropy gradients for quantum-level precision',
    color: '#00D4FF',
    minTier: 'premium',
    boostFactor: 0.07
  },
  {
    id: 'bif',
    name: 'Blockchain Intelligence Filter™',
    shortName: 'BIF',
    description: 'Network congestion, miner selling pressure, hash rate momentum, and block time deviation analysis',
    color: '#A855F7',
    minTier: 'premium',
    boostFactor: 0.06
  },
  {
    id: 'sbpe',
    name: 'Stochastic Block Prediction Engine™',
    shortName: 'SBPE',
    description: 'Predicts next block direction using stochastic oscillator phase analysis and mean reversion',
    color: '#22C55E',
    minTier: 'premium',
    boostFactor: 0.05
  },
  {
    id: 'ance',
    name: 'Adaptive Neural Confluence Engine™',
    shortName: 'ANCE',
    description: '7-layer AI scoring: Hull MA, VWAP, RSI Confluence, MACD, Fibonacci, Shannon Entropy, Volume — requires 4+ layer agreement',
    color: '#F97316',
    minTier: 'platinum',
    boostFactor: 0.12
  },
  {
    id: 'ance2',
    name: 'ANCE² Meta-Intelligence Layer™',
    shortName: 'ANCE²',
    description: 'Second intelligence layer analyzing ANCE output: Signal Momentum, Layer Convergence, Adaptive Weights, Pattern Memory, Trend Persistence',
    color: '#EF4444',
    minTier: 'alpha',
    boostFactor: 0.15
  }
];

const ADVANCED_FILTERS: AdvancedFilterConfig[] = [
  { id: 'order_flow', name: 'Order Flow Imbalance', description: 'Detects aggressive buying/selling pressure from order book imbalances', color: '#3B82F6', minTier: 'premium', boostFactor: 0.03 },
  { id: 'fair_value_gap', name: 'Fair Value Gap', description: 'Identifies price inefficiencies where price moved too fast, leaving gaps to fill', color: '#8B5CF6', minTier: 'premium', boostFactor: 0.03 },
  { id: 'absorption', name: 'Absorption Detector', description: 'Detects large limit orders absorbing market orders without price movement', color: '#06B6D4', minTier: 'premium', boostFactor: 0.025 },
  { id: 'fractal_energy', name: 'Fractal Energy', description: 'Measures market energy state using fractal dimension analysis for trend/consolidation detection', color: '#10B981', minTier: 'premium', boostFactor: 0.025 },
  { id: 'wyckoff', name: 'Wyckoff Phase Detector', description: 'Identifies accumulation, distribution, markup, and markdown phases', color: '#F59E0B', minTier: 'platinum', boostFactor: 0.035 },
  { id: 'entropy', name: 'Entropy Regime', description: 'Shannon entropy-based regime detection for market randomness vs. structure', color: '#EC4899', minTier: 'platinum', boostFactor: 0.03 },
  { id: 'hurst', name: 'Hurst Regime', description: 'Hurst exponent analysis distinguishing trending, mean-reverting, and random walk markets', color: '#14B8A6', minTier: 'platinum', boostFactor: 0.03 },
  { id: 'delta_divergence', name: 'Delta Divergence', description: 'Tracks cumulative volume delta divergence from price for reversal signals', color: '#F43F5E', minTier: 'platinum', boostFactor: 0.035 }
];

const BOT_TYPES: BotTypeConfig[] = [
  { id: 'grid', name: 'Grid Bot', description: 'Place orders at preset intervals to profit from volatility', icon: <Grid3X3 size={20} />, color: 'blue', bgColor: 'bg-blue-500/20', minTier: 'free', features: ['Spot & Futures', 'Auto grid calculation', 'AI-assisted parameters'] },
  { id: 'dca', name: 'DCA Bot', description: 'Dollar-cost average with safety orders', icon: <TrendingDown size={20} />, color: 'purple', bgColor: 'bg-purple-500/20', minTier: 'free', features: ['Safety orders', 'Multiple TP levels', 'Trailing stop-loss'] },
  { id: 'trailing_stop', name: 'Trailing Stop', description: 'Auto-adjust stop-loss to lock in profits', icon: <Target size={20} />, color: 'green', bgColor: 'bg-green-500/20', minTier: 'free', features: ['Trailing take-profit', 'Activation threshold', 'Gap customization'] },
  { id: 'twap', name: 'TWAP Bot', description: 'Execute large orders over time to reduce impact', icon: <Timer size={20} />, color: 'cyan', bgColor: 'bg-cyan-500/20', minTier: 'basic', features: ['Order slicing', 'Time windows', 'Stealth execution'] },
  { id: 'signal', name: 'Signal Bot', description: 'Trade based on technical indicators & AI signals', icon: <Radio size={20} />, color: 'yellow', bgColor: 'bg-yellow-500/20', minTier: 'basic', features: ['RSI, MACD, Bollinger', 'AI predictions', 'Custom webhooks'] },
  { id: 'arbitrage', name: 'Arbitrage Bot', description: 'Exploit price differences across exchanges', icon: <ArrowUpDown size={20} />, color: 'pink', bgColor: 'bg-pink-500/20', minTier: 'premium', features: ['Cross-exchange', 'Spot-futures', 'Auto execution'] },
  { id: 'martingale', name: 'Martingale Bot', description: 'Increase position size after losses', icon: <Layers size={20} />, color: 'orange', bgColor: 'bg-orange-500/20', minTier: 'premium', features: ['Configurable multiplier', 'Max steps limit', 'Risk controls'] },
  { id: 'infinity_grid', name: 'Infinity Grid', description: 'Grid that follows price trends automatically', icon: <Infinity size={20} />, color: 'indigo', bgColor: 'bg-indigo-500/20', minTier: 'free', features: ['Auto-adjusting range', 'Trend following', 'No upper limit'] },
  { id: 'leveraged_grid', name: 'Leveraged Grid', description: 'Grid trading with 1.2x-3x leverage for amplified returns', icon: <TrendingUp size={20} />, color: 'red', bgColor: 'bg-red-500/20', minTier: 'premium', features: ['1.2x-3x leverage', 'Margin management', 'Auto-liquidation protection'] },
  { id: 'rebalancing', name: 'Rebalancing Bot', description: 'Auto-adjust portfolio allocations to target weights', icon: <PieChart size={20} />, color: 'teal', bgColor: 'bg-teal-500/20', minTier: 'free', features: ['Target allocation %', 'Threshold rebalancing', 'Multi-asset support'] },
  { id: 'smart_trade', name: 'SmartTrade Bot', description: 'Enhanced manual trading with simultaneous TP/SL & trailing', icon: <Sparkles size={20} />, color: 'emerald', bgColor: 'bg-emerald-500/20', minTier: 'premium', features: ['Simultaneous TP & SL', 'Incremental selling', 'Conditional orders'] },
  { id: 'reverse_grid', name: 'Reverse Grid', description: 'Profit from falling markets by selling high and buying low', icon: <TrendingDown size={20} />, color: 'rose', bgColor: 'bg-rose-500/20', minTier: 'free', features: ['Bear market profits', 'Auto grid spacing', 'Downtrend optimization'] },
  { id: 'auto_invest', name: 'Auto-Invest', description: 'Scheduled recurring buys to build positions over time', icon: <Clock size={20} />, color: 'sky', bgColor: 'bg-sky-500/20', minTier: 'free', features: ['Hourly/daily/weekly', 'Multi-asset scheduling', 'Set & forget'] },
  { id: 'spot_futures_arb', name: 'Spot-Futures Arb', description: 'Exploit funding rate differences between spot and futures', icon: <ArrowUpDown size={20} />, color: 'amber', bgColor: 'bg-amber-500/20', minTier: 'free', features: ['Funding rate capture', 'Delta-neutral', 'Low-risk returns'] }
];

const BOT_TIERS: Record<TierLevel, {
  maxBots: number;
  botTypes: BotType[];
  features: string[];
  name: string;
  color: string;
  description: string;
  techAccess: string[];
  filterAccess: string[];
  bridgeAccess: BridgeMode[];
  maxFiltersInBridge: number;
}> = {
  free: { 
    maxBots: 8, 
    botTypes: ['grid', 'dca', 'trailing_stop', 'rebalancing', 'infinity_grid', 'reverse_grid', 'auto_invest', 'spot_futures_arb'],
    features: ['basic_settings', 'manual_parameters', 'ai_suggestions_basic', 'paper_trading', 'portfolio_tracking', 'demo_exchange', 'backtesting_basic', 'copy_bots_view', 'price_alerts_basic', 'market_overview', 'real_trading_limited'],
    name: 'Free', color: 'gray',
    description: '8 bots, 15 trades/day, 35 bots/pair, no portfolio cap, 2 exchanges, 450 req/s API',
    techAccess: [],
    filterAccess: [],
    bridgeAccess: ['off'],
    maxFiltersInBridge: 0
  },
  basic: { 
    maxBots: 5, 
    botTypes: ['grid', 'dca', 'trailing_stop', 'twap', 'signal'],
    features: ['basic_settings', 'safety_orders', 'ai_suggestions', 'ai_suggestions_basic', 'trailing_sl', 'backtesting', 'multi_pair', 'strategy_designer'],
    name: 'Basic', color: 'blue',
    description: '5 bots, Strategy Designer, backtesting, multi-pair',
    techAccess: [],
    filterAccess: [],
    bridgeAccess: ['off'],
    maxFiltersInBridge: 0
  },
  premium: { 
    maxBots: 15, 
    botTypes: ['grid', 'dca', 'trailing_stop', 'twap', 'signal', 'arbitrage', 'martingale', 'infinity_grid', 'leveraged_grid', 'rebalancing', 'smart_trade'],
    features: ['all_settings', 'ai_optimization', 'backtesting', 'multi_tp', 'trailing_sl', 'trailing_tp', 'oco', 'cooldown', 'max_daily', 'paper_trading', 'tradingview_webhooks', 'strategy_marketplace', 'conditional_automation', 'copy_trading', 'multi_pair'],
    name: 'Premium', color: 'purple',
    description: '15 bots, all 11 types, SmartTrade, TradingView, 4 techs',
    techAccess: ['acm', 'qfrm', 'bif', 'sbpe'],
    filterAccess: ['order_flow', 'fair_value_gap', 'absorption', 'fractal_energy'],
    bridgeAccess: ['off'],
    maxFiltersInBridge: 0
  },
  platinum: { 
    maxBots: 25, 
    botTypes: ['grid', 'dca', 'trailing_stop', 'twap', 'signal', 'arbitrage', 'martingale', 'infinity_grid', 'leveraged_grid', 'rebalancing', 'smart_trade'],
    features: ['all', 'priority_execution', 'custom_strategies', 'trailing_sl', 'trailing_tp', 'oco', 'cooldown', 'max_daily', 'paper_trading', 'position_sizing', 'ai_strategy_selection', 'futures_trading', 'strategy_templates'],
    name: 'Platinum', color: 'pink',
    description: '25 bots, ANCE, AI strategy selection, Bridge Fusion',
    techAccess: ['acm', 'qfrm', 'bif', 'sbpe', 'ance'],
    filterAccess: ['order_flow', 'fair_value_gap', 'absorption', 'fractal_energy', 'wyckoff', 'entropy', 'hurst', 'delta_divergence'],
    bridgeAccess: ['off', 'manual'],
    maxFiltersInBridge: 8
  },
  alpha: { 
    maxBots: -1, 
    botTypes: ['grid', 'dca', 'trailing_stop', 'twap', 'signal', 'arbitrage', 'martingale', 'infinity_grid', 'leveraged_grid', 'rebalancing', 'smart_trade'],
    features: ['all', 'priority_execution', 'custom_strategies', 'api_access', 'trailing_sl', 'trailing_tp', 'oco', 'cooldown', 'max_daily', 'paper_trading', 'position_sizing', 'custom_bot_builder', 'ai_auto_optimization', 'sell_strategies', 'white_label'],
    name: 'Alpha', color: 'gold',
    description: 'Unlimited bots, ANCE², auto Bridge Fusion, Custom Builder',
    techAccess: ['acm', 'qfrm', 'bif', 'sbpe', 'ance', 'ance2'],
    filterAccess: ['order_flow', 'fair_value_gap', 'absorption', 'fractal_energy', 'wyckoff', 'entropy', 'hurst', 'delta_divergence'],
    bridgeAccess: ['off', 'manual', 'auto'],
    maxFiltersInBridge: 8
  }
};

const TRADING_PAIRS = [
  'BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'XRP/USDT',
  'ADA/USDT', 'DOGE/USDT', 'AVAX/USDT', 'DOT/USDT', 'MATIC/USDT',
  'LINK/USDT', 'UNI/USDT', 'ATOM/USDT', 'LTC/USDT', 'FIL/USDT'
];

const TIER_ORDER: TierLevel[] = ['free', 'basic', 'premium', 'platinum', 'alpha'];

function getTierIndex(tier: TierLevel): number {
  return TIER_ORDER.indexOf(tier);
}

function calculateSignalBoost(activeTech: string[], activeFilters: string[], bridgeFusion: BridgeFusionState): number {
  let boost = 0;
  activeTech.forEach(techId => {
    const tech = PROPRIETARY_TECH.find(t => t.id === techId);
    if (tech) boost += tech.boostFactor;
  });
  activeFilters.forEach(filterId => {
    const filter = ADVANCED_FILTERS.find(f => f.id === filterId);
    if (filter) boost += filter.boostFactor;
  });
  if (bridgeFusion.enabled && bridgeFusion.selectedFilters.length >= 2) {
    const fusionBonus = bridgeFusion.selectedFilters.length * 0.02;
    const modeMultiplier = bridgeFusion.mode === 'auto' ? 1.5 : 1.0;
    boost += fusionBonus * modeMultiplier * (bridgeFusion.fusionStrength / 100);
  }
  return Math.min(boost, 0.65);
}

export function AITradingBots({ userTier = 'free' }: { userTier?: string }) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedBotType, setSelectedBotType] = useState<BotType>('grid');
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');
  const [showPerformance, setShowPerformance] = useState<string | null>(null);
  const [showCommandLog, setShowCommandLog] = useState<string | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [createStep, setCreateStep] = useState<'type' | 'settings' | 'tech' | 'filters' | 'bridge' | 'exchange' | 'advanced'>('type');
  const [selectedExchange, setSelectedExchange] = useState('binance');
  const [editingBotId, setEditingBotId] = useState<string | null>(null);
  
  const [selectedTech, setSelectedTech] = useState<string[]>([]);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [bridgeConfig, setBridgeConfig] = useState<BridgeFusionState>({
    enabled: false, mode: 'off', selectedFilters: [], autoAdjust: false, fusionStrength: 75
  });
  
  const tierKey = (userTier as TierLevel) || 'free';
  const tierConfig = BOT_TIERS[tierKey] || BOT_TIERS.free;
  const canCreateBot = tierConfig.maxBots === -1 || bots.length < tierConfig.maxBots;

  const [serverTradeUsage, setServerTradeUsage] = useState<{ tradesUsed: number; maxTrades: number } | null>(null);
  const fetchTradeUsage = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/trading/usage');
      if (res.ok) {
        const data = await res.json();
        setServerTradeUsage({ tradesUsed: data.tradesUsed, maxTrades: data.maxTrades });
      }
    } catch {}
  }, [isAuthenticated]);

  useEffect(() => { fetchTradeUsage(); }, [fetchTradeUsage]);

  const isAdminUnlimited = serverTradeUsage?.maxTrades === -1;
  const totalRealTrades = isAdminUnlimited ? 0 : (serverTradeUsage?.tradesUsed ?? bots.filter(b => !b.settings.paperTrading && b.connectedExchange !== 'demo').reduce((sum, b) => sum + b.trades, 0));
  const maxDailyTrades = isAdminUnlimited ? Infinity : ((serverTradeUsage?.maxTrades && serverTradeUsage.maxTrades > 0) ? serverTradeUsage.maxTrades : 10);
  
  const [botSettings, setBotSettings] = useState<BotSettings>({
    investment: 1000, upperPrice: 90000, lowerPrice: 80000, gridCount: 10,
    leverage: 1, orderAmount: 100, frequency: 'daily', maxOrders: 30,
    takeProfit: 15, stopLoss: 10, trailingPercent: 2, activationPrice: 0,
    safetyOrders: 3, safetyOrderSize: 50, safetyOrderStep: 2,
    takeProfitLevels: [{ price: 5, percent: 25 }, { price: 10, percent: 50 }, { price: 15, percent: 25 }],
    trailingTakeProfit: false, trailingStopLoss: false,
    signalSource: 'ai', signalThreshold: 70,
    exchanges: ['binance', 'okx'], minSpread: 0.5,
    martingaleMultiplier: 2, maxMartingaleSteps: 5,
    ocoEnabled: false, cooldownSeconds: 0,
    maxDailyTrades: 0, maxDailyLossPercent: 0,
    paperTrading: false, positionSizePercent: 100
  });

  const SUPPORTED_EXCHANGES = [
    { id: 'demo', name: 'Demo Sandbox', color: '#9CA3AF' },
    { id: 'binance', name: 'Binance', color: '#F0B90B' },
    { id: 'bybit', name: 'Bybit', color: '#F7A600' },
    { id: 'okx', name: 'OKX', color: '#FFFFFF' },
    { id: 'coinbase', name: 'Coinbase', color: '#0052FF' },
    { id: 'kraken', name: 'Kraken', color: '#5741D9' },
    { id: 'kucoin', name: 'KuCoin', color: '#23AF91' },
    { id: 'gate', name: 'Gate.io', color: '#2354E6' },
    { id: 'bitget', name: 'Bitget', color: '#00F0FF' },
    { id: 'mexc', name: 'MEXC', color: '#1CE8B5' },
    { id: 'htx', name: 'HTX', color: '#2B6AFF' },
  ];

  useEffect(() => {
    const savedBots = localStorage.getItem('alpha-trading-bots-v3');
    if (savedBots) {
      try {
        setBots(JSON.parse(savedBots).map((b: any) => ({
          ...b,
          createdAt: new Date(b.createdAt),
          connectedExchange: b.connectedExchange || 'binance',
          commandLog: (b.commandLog || []).map((c: any) => ({ ...c, timestamp: new Date(c.timestamp) }))
        })));
      } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('alpha-trading-bots-v3', JSON.stringify(bots));
  }, [bots]);

  const [livePrices, setLivePrices] = useState<Record<string, { price: number; change: number; changePercent: number }>>({});
  const [botSignals, setBotSignals] = useState<Record<string, { direction: 'BUY' | 'SELL' | 'HOLD'; strength: number; confidence: number; timestamp: number }>>({});
  const botsRef = useRef(bots);
  botsRef.current = bots;

  useEffect(() => {
    const runningBots = bots.filter(b => b.status === 'running' && !b.settings.paperTrading && b.connectedExchange !== 'demo');
    if (runningBots.length === 0) return;

    const pairs = [...new Set(runningBots.map(b => b.pair.replace('/', '')))];

    const fetchPrices = async () => {
      const newPrices: Record<string, { price: number; change: number; changePercent: number }> = {};
      await Promise.all(pairs.map(async (symbol) => {
        try {
          const res = await fetch(`/api/trading/ticker/${symbol}`);
          if (res.ok) {
            const data = await res.json();
            newPrices[symbol] = { price: data.price, change: data.priceChange || 0, changePercent: data.priceChangePercent || 0 };
          }
        } catch {}
      }));
      if (Object.keys(newPrices).length > 0) setLivePrices(prev => ({ ...prev, ...newPrices }));
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 15000);
    return () => clearInterval(interval);
  }, [bots.map(b => `${b.id}-${b.status}-${b.connectedExchange}`).join(',')]);

  useEffect(() => {
    const runningBots = bots.filter(b => b.status === 'running' && !b.settings.paperTrading && b.connectedExchange !== 'demo');
    if (runningBots.length === 0 || Object.keys(livePrices).length === 0) return;

    const newSignals: Record<string, { direction: 'BUY' | 'SELL' | 'HOLD'; strength: number; confidence: number; timestamp: number }> = {};
    runningBots.forEach(bot => {
      const symbol = bot.pair.replace('/', '');
      const priceData = livePrices[symbol];
      if (!priceData) return;

      const signalBoost = calculateSignalBoost(bot.activeTech, bot.activeFilters, bot.bridgeFusion);
      const techCount = bot.activeTech.length;
      const filterCount = bot.activeFilters.length;
      const baseConfidence = 35 + techCount * 8 + filterCount * 5 + (bot.bridgeFusion.enabled ? 12 : 0);
      const confidence = Math.min(baseConfidence + signalBoost * 100, 95);

      const changePercent = priceData.changePercent;
      let direction: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
      let strength = 50;

      if (changePercent > 2) { direction = 'BUY'; strength = Math.min(60 + changePercent * 5, 90); }
      else if (changePercent > 0.5) { direction = 'BUY'; strength = 45 + changePercent * 8; }
      else if (changePercent < -2) { direction = 'SELL'; strength = Math.min(60 + Math.abs(changePercent) * 5, 90); }
      else if (changePercent < -0.5) { direction = 'SELL'; strength = 45 + Math.abs(changePercent) * 8; }
      else { direction = 'HOLD'; strength = 30 + Math.abs(changePercent) * 10; }

      strength = Math.min(strength * (1 + signalBoost * 0.3), 95);

      newSignals[bot.id] = { direction, strength: Math.round(strength), confidence: Math.round(confidence), timestamp: Date.now() };
    });

    setBotSignals(prev => ({ ...prev, ...newSignals }));
  }, [livePrices, bots]);

  const lastCommandTimeRef = useRef<Record<string, number>>({});
  const commandCooldownMs = 60000;

  useEffect(() => {
    const currentBots = botsRef.current;
    const runningBots = currentBots.filter(b => b.status === 'running' && !b.settings.paperTrading && b.connectedExchange !== 'demo');
    if (runningBots.length === 0 || Object.keys(botSignals).length === 0 || Object.keys(livePrices).length === 0) return;

    const currentTradeCount = currentBots.filter(b => !b.settings.paperTrading && b.connectedExchange !== 'demo').reduce((sum, b) => sum + b.trades, 0);
    const dailyLimit = (serverTradeUsage?.maxTrades && serverTradeUsage.maxTrades > 0) ? serverTradeUsage.maxTrades : 10;
    const isUnlimited = serverTradeUsage?.maxTrades === -1;
    if (!isUnlimited && currentTradeCount >= dailyLimit) return;

    const now = Date.now();
    const pendingCommands: { bot: TradingBot; command: TradeCommand; signal: typeof botSignals[string] }[] = [];

    const updatedBots = currentBots.map(bot => {
      const signal = botSignals[bot.id];
      if (!signal || signal.direction === 'HOLD') return bot;
      if (bot.status !== 'running' || bot.settings.paperTrading || bot.connectedExchange === 'demo') return bot;

      const lastCmd = lastCommandTimeRef.current[bot.id] || 0;
      if (now - lastCmd < commandCooldownMs) return bot;

      const minStrength = 55;
      const minConfidence = 50;
      if (signal.strength < minStrength || signal.confidence < minConfidence) return bot;

      const symbol = bot.pair.replace('/', '');
      const priceData = livePrices[symbol];
      if (!priceData) return bot;

      const investment = bot.settings.investment || 100;
      const quantity = priceData.price > 0 ? parseFloat((investment / priceData.price).toFixed(6)) : 0;
      if (quantity <= 0) return bot;

      let commandType: CommandType = signal.direction;
      if (bot.type === 'dca' && signal.direction === 'BUY') commandType = 'DCA_BUY';
      else if (bot.type === 'grid') commandType = signal.direction === 'BUY' ? 'GRID_BUY' : 'GRID_SELL';

      const command: TradeCommand = {
        id: `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        type: commandType,
        price: priceData.price,
        quantity,
        timestamp: new Date(),
        status: 'SENT',
        exchange: bot.connectedExchange,
        pair: bot.pair,
      };

      lastCommandTimeRef.current[bot.id] = now;
      pendingCommands.push({ bot, command, signal });

      const newLog = [command, ...bot.commandLog].slice(0, 50);
      return {
        ...bot,
        trades: bot.trades + 1,
        commandLog: newLog,
        lastTradeTime: now,
        signalQuality: signal.confidence,
      };
    });

    if (pendingCommands.length > 0) {
      setBots(updatedBots);

      for (const { bot, command } of pendingCommands) {
        const side = ['BUY', 'DCA_BUY', 'GRID_BUY'].includes(command.type) ? 'buy' : 'sell';
        fetch('/api/trading/bot-execute', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            exchange: bot.connectedExchange,
            pair: bot.pair,
            side,
            quantity: command.quantity,
            price: command.price,
            botId: bot.id,
            commandId: command.id,
          }),
        })
          .then(r => r.json())
          .then(data => {
            const newStatus: CommandStatus = data.success ? 'FILLED' : 'FAILED';
            setBots(prev => prev.map(b => {
              if (b.id !== bot.id) return b;
              return {
                ...b,
                commandLog: b.commandLog.map(cmd =>
                  cmd.id === command.id ? { ...cmd, status: newStatus, pnl: data.order?.orderId ? undefined : undefined } : cmd
                ),
              };
            }));
            if (data.success) {
              console.log(`[Bot ${bot.name}] Order FILLED on ${bot.connectedExchange}: ${side} ${command.quantity} ${bot.pair} @ $${command.price} | Kraken ID: ${data.order?.orderId}`);
            } else {
              console.warn(`[Bot ${bot.name}] Order FAILED: ${data.message}`);
            }
          })
          .catch(err => {
            console.error(`[Bot ${bot.name}] Execution error:`, err);
            setBots(prev => prev.map(b => {
              if (b.id !== bot.id) return b;
              return {
                ...b,
                commandLog: b.commandLog.map(cmd =>
                  cmd.id === command.id ? { ...cmd, status: 'FAILED' as CommandStatus } : cmd
                ),
              };
            }));
          });
      }
    }
  }, [botSignals]);

  const BASE_PRICES: Record<string, number> = {
    'BTC/USDT': 94500, 'ETH/USDT': 3200, 'SOL/USDT': 185, 'BNB/USDT': 620,
    'XRP/USDT': 2.4, 'ADA/USDT': 0.85, 'DOGE/USDT': 0.32, 'AVAX/USDT': 35,
    'DOT/USDT': 7.2, 'LINK/USDT': 22, 'MATIC/USDT': 0.95, 'SHIB/USDT': 0.000022
  };

  const createBot = () => {
    if (!canCreateBot) {
      toast({ title: 'Bot Limit Reached', description: `Upgrade your plan to create more bots. Current limit: ${tierConfig.maxBots}`, variant: 'destructive' });
      return;
    }
    if (!tierConfig.botTypes.includes(selectedBotType)) {
      setShowUpgradeModal(true);
      return;
    }

    const botTypeConfig = BOT_TYPES.find(bt => bt.id === selectedBotType)!;
    const isDemo = !isAuthenticated;
    const isFreeUser = tierKey === 'free';
    const isFreeRealTrading = isFreeUser && selectedExchange !== 'demo';

    if (isFreeRealTrading && totalRealTrades >= maxDailyTrades) {
      toast({ title: 'Daily Trade Limit Reached', description: `You've used all ${maxDailyTrades} free real trades for today. Upgrade to Basic ($24/mo) for 80 trades/day, or switch to Demo Sandbox.`, variant: 'destructive' });
      return;
    }

    const exchangeInfo = SUPPORTED_EXCHANGES.find(e => e.id === selectedExchange);
    const newBot: TradingBot = {
      id: `bot_${Date.now()}`,
      type: selectedBotType,
      name: `${botTypeConfig.name} ${bots.filter(b => b.type === selectedBotType).length + 1}`,
      pair: selectedPair,
      status: 'running',
      profit: 0, profitPercent: 0, trades: 0, winRate: 0, sharpeRatio: 0, maxDrawdown: 0,
      createdAt: new Date(),
      settings: { ...botSettings, paperTrading: isFreeUser && !isFreeRealTrading ? true : botSettings.paperTrading },
      isDemo,
      activeTech: selectedTech.filter(t => tierConfig.techAccess.includes(t)),
      activeFilters: selectedFilters.filter(f => tierConfig.filterAccess.includes(f)),
      bridgeFusion: tierConfig.bridgeAccess.includes(bridgeConfig.mode) ? { ...bridgeConfig } : { enabled: false, mode: 'off', selectedFilters: [], autoAdjust: false, fusionStrength: 75 },
      dailyTrades: 0, dailyLoss: 0, lastTradeTime: 0,
      signalQuality: 40,
      connectedExchange: isFreeRealTrading ? selectedExchange : (isFreeUser ? 'demo' : selectedExchange),
      commandLog: []
    };

    setBots([...bots, newBot]);
    closeModal();
    toast({ 
      title: isFreeRealTrading ? 'Real Trading Bot Created — 10 Trades/Day' : isFreeUser ? 'Paper Trading Bot Created' : isDemo ? 'Demo Bot Created' : 'Trading Bot Active',
      description: isFreeRealTrading ? `${newBot.name} will send up to 10 real trade commands per day to ${exchangeInfo?.name || selectedExchange}. You pay only your exchange's trading fee — no fees from Alpha Unlimited.` : isFreeUser ? `${newBot.name} is running in paper trading mode with simulated data. Upgrade to Basic ($24/mo) to connect your exchange and trade with real funds.` : isDemo ? 'Log in to save your bots and connect exchanges.' : `${newBot.name} is now sending automated commands to ${exchangeInfo?.name || selectedExchange} for ${selectedPair}. All trades execute on your exchange — no funds flow through Alpha Unlimited.`
    });
  };

  const toggleBot = (id: string) => {
    setBots(prev => prev.map(bot => 
      bot.id === id ? { ...bot, status: bot.status === 'running' ? 'paused' : 'running', dailyTrades: bot.status === 'running' ? bot.dailyTrades : 0, dailyLoss: bot.status === 'running' ? bot.dailyLoss : 0 } : bot
    ));
  };

  const deleteBot = (id: string) => {
    setBots(prev => prev.filter(bot => bot.id !== id));
    toast({ title: 'Bot Deleted', description: 'Trading bot has been removed and will no longer send commands' });
  };

  const startEditBot = (botId: string) => {
    const bot = bots.find(b => b.id === botId);
    if (!bot) return;
    setEditingBotId(botId);
    setSelectedBotType(bot.type);
    setSelectedPair(bot.pair);
    setBotSettings({ ...bot.settings });
    setSelectedTech([...bot.activeTech]);
    setSelectedFilters([...bot.activeFilters]);
    setBridgeConfig({ ...bot.bridgeFusion });
    setSelectedExchange(bot.connectedExchange);
    setCreateStep('settings');
    setShowCreateModal(true);
  };

  const saveEditedBot = () => {
    if (!editingBotId) return;
    const wasPaused = bots.find(b => b.id === editingBotId)?.status === 'paused';
    setBots(prev => prev.map(bot => {
      if (bot.id !== editingBotId) return bot;
      return {
        ...bot,
        pair: selectedPair,
        settings: { ...botSettings },
        activeTech: selectedTech.filter(t => tierConfig.techAccess.includes(t)),
        activeFilters: selectedFilters.filter(f => tierConfig.filterAccess.includes(f)),
        bridgeFusion: tierConfig.bridgeAccess.includes(bridgeConfig.mode) ? { ...bridgeConfig } : bot.bridgeFusion,
        connectedExchange: selectedExchange,
      };
    }));
    setShowCreateModal(false);
    setEditingBotId(null);
    setCreateStep('type');
    toast({ 
      title: 'Bot Updated', 
      description: `Parameters saved successfully.${wasPaused ? '' : ' Changes are active immediately.'}` 
    });
  };

  const closeModal = () => {
    setShowCreateModal(false);
    setEditingBotId(null);
    setCreateStep('type');
    setSelectedTech([]);
    setSelectedFilters([]);
    setSelectedExchange('binance');
    setBridgeConfig({ enabled: false, mode: 'off', selectedFilters: [], autoAdjust: false, fusionStrength: 75 });
  };

  const toggleBotBridge = (botId: string) => {
    setBots(prev => prev.map(bot => {
      if (bot.id !== botId) return bot;
      const newEnabled = !bot.bridgeFusion.enabled;
      return { ...bot, bridgeFusion: { ...bot.bridgeFusion, enabled: newEnabled } };
    }));
  };

  const currentSignalBoost = calculateSignalBoost(selectedTech, selectedFilters, bridgeConfig);
  const projectedWinRate = Math.min(92, 52 + currentSignalBoost * 100);

  const renderCreateStepContent = () => {
    switch (createStep) {
      case 'type':
        return (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Select Bot Type</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {BOT_TYPES.map(bt => {
                  const isAvailable = tierConfig.botTypes.includes(bt.id);
                  const isLockedEdit = !!editingBotId && bt.id !== selectedBotType;
                  return (
                    <button key={bt.id} onClick={() => !isLockedEdit && isAvailable && setSelectedBotType(bt.id)} disabled={!isAvailable || isLockedEdit}
                      className={`p-3 rounded-lg border transition-all text-left relative ${
                        selectedBotType === bt.id ? `${bt.bgColor} border-${bt.color}-500/50` :
                        isLockedEdit ? 'bg-gray-900/50 border-gray-800 opacity-30 cursor-not-allowed' :
                        isAvailable ? 'bg-gray-800/50 border-gray-700 hover:border-gray-600' :
                        'bg-gray-900/50 border-gray-800 opacity-50 cursor-not-allowed'
                      }`} data-testid={`button-select-${bt.id}`}>
                      {!isAvailable && <Lock size={12} className="absolute top-2 right-2 text-gray-500" />}
                      <div className={`mb-1 ${selectedBotType === bt.id ? `text-${bt.color}-400` : 'text-gray-400'}`}>{bt.icon}</div>
                      <div className={`text-xs font-medium ${selectedBotType === bt.id ? 'text-white' : 'text-gray-300'}`}>{bt.name}</div>
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="p-3 bg-gray-800/50 rounded-lg">
              <div className="flex items-start gap-2">
                <Info size={16} className="text-gray-400 mt-0.5" />
                <div>
                  <div className="text-sm text-gray-300">{BOT_TYPES.find(bt => bt.id === selectedBotType)?.description}</div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {BOT_TYPES.find(bt => bt.id === selectedBotType)?.features.map((f, i) => (
                      <span key={i} className="text-[10px] px-1.5 py-0.5 bg-gray-700 rounded text-gray-400">{f}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-1">Trading Pair</label>
              <select value={selectedPair} onChange={e => setSelectedPair(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="select-pair">
                {TRADING_PAIRS.map(pair => <option key={pair} value={pair}>{pair}</option>)}
              </select>
            </div>
            {editingBotId && (
              <div className="p-2 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-center gap-2 text-xs">
                <Pencil size={12} className="text-blue-400" />
                <span className="text-blue-400">Editing mode — bot type is locked. Use the tabs above to change other parameters.</span>
              </div>
            )}
          </div>
        );

      case 'settings':
        return renderBotSettings();

      case 'tech':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-white flex items-center gap-2"><Cpu size={16} className="text-primary" /> Proprietary Technologies</h4>
              <span className="text-xs text-gray-500">{selectedTech.length} active</span>
            </div>
            <p className="text-xs text-gray-500">Enable Alpha Unlimited's proprietary trading technologies for enhanced signal accuracy and smarter entries/exits.</p>
            <div className="space-y-2">
              {PROPRIETARY_TECH.map(tech => {
                const hasAccess = tierConfig.techAccess.includes(tech.id);
                const isActive = selectedTech.includes(tech.id);
                return (
                  <div key={tech.id} className={`p-3 rounded-lg border transition-all ${
                    isActive ? 'border-opacity-50 bg-opacity-10' : 'border-gray-700 bg-gray-800/30'
                  } ${!hasAccess ? 'opacity-50' : 'cursor-pointer hover:border-opacity-30'}`}
                    style={isActive ? { borderColor: tech.color + '80', backgroundColor: tech.color + '15' } : {}}
                    onClick={() => {
                      if (!hasAccess) { setShowUpgradeModal(true); return; }
                      setSelectedTech(prev => prev.includes(tech.id) ? prev.filter(t => t !== tech.id) : [...prev, tech.id]);
                    }} data-testid={`tech-toggle-${tech.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold" style={{ backgroundColor: tech.color + '20', color: tech.color }}>
                          {tech.shortName}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-white flex items-center gap-2">
                            {tech.name}
                            {!hasAccess && <Lock size={12} className="text-gray-500" />}
                          </div>
                          <div className="text-xs text-gray-500">{tech.description}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-1.5 py-0.5 rounded" style={{ backgroundColor: tech.color + '20', color: tech.color }}>
                          +{(tech.boostFactor * 100).toFixed(0)}% signal
                        </span>
                        {isActive ? <ToggleRight size={20} style={{ color: tech.color }} /> : <ToggleLeft size={20} className="text-gray-600" />}
                      </div>
                    </div>
                    {!hasAccess && (
                      <div className="mt-2 text-xs text-gray-500 flex items-center gap-1">
                        <Crown size={10} className="text-yellow-500" /> Requires {tech.minTier.charAt(0).toUpperCase() + tech.minTier.slice(1)} tier or higher
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {selectedTech.length > 0 && (
              <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Combined Signal Boost:</span>
                  <span className="text-primary font-bold">+{(selectedTech.reduce((sum, id) => sum + (PROPRIETARY_TECH.find(t => t.id === id)?.boostFactor || 0), 0) * 100).toFixed(0)}%</span>
                </div>
              </div>
            )}
          </div>
        );

      case 'filters':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-white flex items-center gap-2"><Filter size={16} className="text-blue-400" /> Advanced Market Filters™</h4>
              <span className="text-xs text-gray-500">{selectedFilters.length}/8 active</span>
            </div>
            <p className="text-xs text-gray-500">Activate proprietary market analysis filters for deeper market insight. These can also be combined using Bridge Fusion™.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ADVANCED_FILTERS.map(filter => {
                const hasAccess = tierConfig.filterAccess.includes(filter.id);
                const isActive = selectedFilters.includes(filter.id);
                return (
                  <div key={filter.id} className={`p-3 rounded-lg border transition-all ${
                    isActive ? 'border-opacity-50' : 'border-gray-700'
                  } ${!hasAccess ? 'opacity-50' : 'cursor-pointer hover:border-gray-600'}`}
                    style={isActive ? { borderColor: filter.color + '60', backgroundColor: filter.color + '10' } : { backgroundColor: '#1a1a2e' }}
                    onClick={() => {
                      if (!hasAccess) { setShowUpgradeModal(true); return; }
                      setSelectedFilters(prev => prev.includes(filter.id) ? prev.filter(f => f !== filter.id) : [...prev, filter.id]);
                    }} data-testid={`filter-toggle-${filter.id}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-white flex items-center gap-2">
                        <CircleDot size={12} style={{ color: filter.color }} />
                        {filter.name}
                        {!hasAccess && <Lock size={10} className="text-gray-500" />}
                      </span>
                      {isActive ? <Check size={14} style={{ color: filter.color }} /> : <div className="w-3.5 h-3.5 rounded border border-gray-600" />}
                    </div>
                    <p className="text-[10px] text-gray-500 leading-relaxed">{filter.description}</p>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: filter.color + '15', color: filter.color }}>+{(filter.boostFactor * 100).toFixed(0)}% accuracy</span>
                      {!hasAccess && <span className="text-[10px] text-gray-600">{filter.minTier}+</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case 'bridge':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-white flex items-center gap-2"><GitMerge size={16} className="text-primary" /> Bridge Fusion™</h4>
              {bridgeConfig.enabled && <span className="text-xs px-2 py-0.5 bg-primary/20 text-primary rounded-full">ACTIVE</span>}
            </div>
            <p className="text-xs text-gray-500">
              Bridge Fusion™ combines 2-8 Advanced Market Filters into a single unified signal, dramatically improving trade accuracy. 
              {getTierIndex(tierKey) < getTierIndex('platinum') && ' Requires Platinum tier or higher.'}
            </p>
            
            {!tierConfig.bridgeAccess.includes('manual') && !tierConfig.bridgeAccess.includes('auto') ? (
              <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg text-center">
                <Lock size={24} className="mx-auto text-gray-500 mb-2" />
                <p className="text-sm text-gray-400 mb-2">Bridge Fusion™ is available from Platinum tier</p>
                <Button size="sm" className="bg-primary hover:bg-primary/90" onClick={() => setShowUpgradeModal(true)}>
                  <Crown size={14} className="mr-1" /> Upgrade to Unlock
                </Button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                  <div>
                    <span className="text-sm text-white font-medium">Enable Bridge Fusion</span>
                    <p className="text-xs text-gray-500">Fuse selected filters into one unified signal</p>
                  </div>
                  <button onClick={() => setBridgeConfig(prev => ({ ...prev, enabled: !prev.enabled, mode: !prev.enabled ? 'manual' : 'off' }))}
                    className="transition-colors" data-testid="bridge-toggle">
                    {bridgeConfig.enabled ? <ToggleRight size={28} className="text-primary" /> : <ToggleLeft size={28} className="text-gray-600" />}
                  </button>
                </div>

                {bridgeConfig.enabled && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-3">
                    <div>
                      <label className="text-sm text-gray-400 block mb-2">Fusion Mode</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button onClick={() => setBridgeConfig(prev => ({ ...prev, mode: 'manual' }))}
                          className={`p-3 rounded-lg border text-left transition-all ${
                            bridgeConfig.mode === 'manual' ? 'bg-primary/10 border-primary/50' : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                          }`} data-testid="bridge-mode-manual">
                          <Sliders size={16} className={bridgeConfig.mode === 'manual' ? 'text-primary mb-1' : 'text-gray-500 mb-1'} />
                          <div className="text-sm font-medium text-white">Manual</div>
                          <p className="text-[10px] text-gray-500">Choose which filters to fuse together</p>
                        </button>
                        <button onClick={() => {
                            if (!tierConfig.bridgeAccess.includes('auto')) { setShowUpgradeModal(true); return; }
                            setBridgeConfig(prev => ({ ...prev, mode: 'auto', autoAdjust: true }));
                          }}
                          className={`p-3 rounded-lg border text-left transition-all relative ${
                            bridgeConfig.mode === 'auto' ? 'bg-primary/10 border-primary/50' : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                          } ${!tierConfig.bridgeAccess.includes('auto') ? 'opacity-60' : ''}`} data-testid="bridge-mode-auto">
                          {!tierConfig.bridgeAccess.includes('auto') && <Lock size={10} className="absolute top-2 right-2 text-gray-500" />}
                          <Shuffle size={16} className={bridgeConfig.mode === 'auto' ? 'text-primary mb-1' : 'text-gray-500 mb-1'} />
                          <div className="text-sm font-medium text-white">Auto</div>
                          <p className="text-[10px] text-gray-500">Bot dynamically adjusts fusion in real-time</p>
                          {!tierConfig.bridgeAccess.includes('auto') && <p className="text-[10px] text-yellow-500 mt-1">Alpha tier only</p>}
                        </button>
                      </div>
                    </div>

                    {bridgeConfig.mode === 'manual' && (
                      <div>
                        <label className="text-sm text-gray-400 block mb-2">Select Filters to Fuse (2-8)</label>
                        <div className="grid grid-cols-2 gap-1.5">
                          {selectedFilters.length === 0 ? (
                            <div className="col-span-2 text-center py-4 text-xs text-gray-500 bg-gray-800/30 rounded-lg">
                              No filters selected. Go back to the Filters step to activate filters first.
                            </div>
                          ) : (
                            selectedFilters.map(filterId => {
                              const filter = ADVANCED_FILTERS.find(f => f.id === filterId);
                              if (!filter) return null;
                              const isInBridge = bridgeConfig.selectedFilters.includes(filterId);
                              return (
                                <button key={filterId} onClick={() => {
                                    setBridgeConfig(prev => ({
                                      ...prev,
                                      selectedFilters: isInBridge
                                        ? prev.selectedFilters.filter(f => f !== filterId)
                                        : prev.selectedFilters.length < 8 ? [...prev.selectedFilters, filterId] : prev.selectedFilters
                                    }));
                                  }}
                                  className={`p-2 rounded-lg border text-left text-xs transition-all ${
                                    isInBridge ? 'border-primary/50 bg-primary/10' : 'border-gray-700 bg-gray-800/30 hover:border-gray-600'
                                  }`}>
                                  <span className="flex items-center gap-1.5">
                                    {isInBridge ? <Check size={10} className="text-primary" /> : <div className="w-2.5 h-2.5 rounded border border-gray-600" />}
                                    <span className="text-gray-300">{filter.name}</span>
                                  </span>
                                </button>
                              );
                            })
                          )}
                        </div>
                        {bridgeConfig.selectedFilters.length > 0 && bridgeConfig.selectedFilters.length < 2 && (
                          <p className="text-xs text-yellow-500 mt-2 flex items-center gap-1"><AlertTriangle size={12} /> Select at least 2 filters for Bridge Fusion</p>
                        )}
                      </div>
                    )}

                    {bridgeConfig.mode === 'auto' && (
                      <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                        <div className="flex items-center gap-2 text-sm text-primary mb-2">
                          <Sparkles size={14} /> Auto Bridge Fusion Active
                        </div>
                        <p className="text-xs text-gray-400">
                          The bot will automatically select optimal filter combinations during live trading, dynamically adjusting the bridge based on current market conditions for maximum accuracy. 
                          It will fuse 2-8 filters randomly and accurately as needed for potential higher profitable margins.
                        </p>
                        <div className="mt-2 flex items-center justify-between">
                          <label className="text-xs text-gray-500">Auto-Adjust Frequency</label>
                          <span className="text-xs text-primary">Every 15-60 seconds</span>
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="text-sm text-gray-400 block mb-2">Fusion Strength: {bridgeConfig.fusionStrength}%</label>
                      <input type="range" min={10} max={100} value={bridgeConfig.fusionStrength}
                        onChange={e => setBridgeConfig(prev => ({ ...prev, fusionStrength: parseInt(e.target.value) }))}
                        className="w-full accent-primary" data-testid="bridge-strength-slider" />
                      <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                        <span>Conservative (10%)</span><span>Balanced (50%)</span><span>Aggressive (100%)</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </div>
        );

      case 'exchange':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-white flex items-center gap-2"><Wallet size={16} className="text-primary" /> {tierKey === 'free' ? 'Demo Sandbox' : 'Connect to Exchange'}</h4>
            </div>
            {tierKey === 'free' ? (
              <>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <button onClick={() => setSelectedExchange('demo')}
                    className={`p-3 rounded-lg border text-center transition-all ${selectedExchange === 'demo' ? 'bg-gray-700/50 border-gray-500' : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'}`}
                    data-testid="button-exchange-demo">
                    <Bot size={20} className={`mx-auto mb-1 ${selectedExchange === 'demo' ? 'text-gray-300' : 'text-gray-500'}`} />
                    <div className="text-sm font-medium text-white">Demo Sandbox</div>
                    <p className="text-[10px] text-gray-500">Paper trading, $10k simulated</p>
                  </button>
                  <button onClick={() => setSelectedExchange('binance')}
                    className={`p-3 rounded-lg border text-center transition-all ${selectedExchange !== 'demo' ? 'bg-green-500/10 border-green-500/30' : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'}`}
                    data-testid="button-exchange-real">
                    <Zap size={20} className={`mx-auto mb-1 ${selectedExchange !== 'demo' ? 'text-green-400' : 'text-gray-500'}`} />
                    <div className="text-sm font-medium text-white">Real Exchange</div>
                    <p className="text-[10px] text-green-400">10 free trades/day</p>
                  </button>
                </div>
                {selectedExchange === 'demo' ? (
                  <div className="p-4 bg-gray-800/80 border border-gray-700 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gray-700 flex items-center justify-center flex-shrink-0">
                        <Bot size={20} className="text-gray-400" />
                      </div>
                      <div>
                        <span className="text-white text-sm font-semibold block mb-1">Demo Sandbox — Paper Trading Mode</span>
                        <p className="text-gray-400 text-xs leading-relaxed">
                          Your bot will run in our demo sandbox with simulated market data. No real exchange connection needed. 
                          Practice strategies, test parameters, and learn how the bot works — completely risk-free.
                        </p>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-3 gap-2">
                      <div className="p-2 bg-gray-900/60 rounded text-center">
                        <span className="text-green-400 text-sm font-bold block">$10,000</span>
                        <span className="text-gray-500 text-[10px]">Simulated Balance</span>
                      </div>
                      <div className="p-2 bg-gray-900/60 rounded text-center">
                        <span className="text-blue-400 text-sm font-bold block">Real-Time</span>
                        <span className="text-gray-500 text-[10px]">Market Data</span>
                      </div>
                      <div className="p-2 bg-gray-900/60 rounded text-center">
                        <span className="text-purple-400 text-sm font-bold block">Zero Risk</span>
                        <span className="text-gray-500 text-[10px]">No Real Funds</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Zap size={14} className="text-green-400" />
                        <span className="text-green-300 text-sm font-semibold">10 Free Real Trades Per Day</span>
                      </div>
                      <p className="text-gray-400 text-xs leading-relaxed">
                        Connect your exchange and get 10 real automated trades daily — completely free. Your bot sends trade commands directly to your exchange via API. You pay only your exchange's trading fee (e.g., 0.1% on Binance). No fees from Alpha Unlimited.
                      </p>
                    </div>
                    <p className="text-xs text-gray-500 mb-2">Select which exchange your bot will send trade commands to:</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {SUPPORTED_EXCHANGES.filter(e => e.id !== 'demo').map(exchange => (
                        <button key={exchange.id} onClick={() => setSelectedExchange(exchange.id)}
                          className={`p-3 rounded-lg border transition-all text-left ${
                            selectedExchange === exchange.id ? 'bg-primary/10 border-primary/50' : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                          }`} data-testid={`select-exchange-${exchange.id}`}>
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ backgroundColor: exchange.color + '20', color: exchange.color }}>
                              {exchange.name.charAt(0)}
                            </div>
                            <span className={`text-sm font-medium ${selectedExchange === exchange.id ? 'text-white' : 'text-gray-300'}`}>{exchange.name}</span>
                          </div>
                          {selectedExchange === exchange.id && <Check size={14} className="text-primary mt-1" />}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg mt-3">
                  <div className="flex items-center gap-2">
                    <Crown size={14} className="text-primary" />
                    <span className="text-gray-300 text-xs">Need more than 10 trades/day? Upgrade to <span className="text-primary font-bold">Basic ($24/mo)</span> for 80 trades/day and 5 bots with 3 exchange connections.</span>
                  </div>
                </div>
              </>
            ) : (
              <>
                <p className="text-xs text-gray-500">Select which exchange your bot will send trade commands to. The bot sends automated buy, sell, take-profit, and stop-loss orders directly to your exchange via API. Your funds stay on your exchange at all times.</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SUPPORTED_EXCHANGES.filter(e => e.id !== 'demo').map(exchange => (
                    <button key={exchange.id} onClick={() => setSelectedExchange(exchange.id)}
                      className={`p-3 rounded-lg border transition-all text-left ${
                        selectedExchange === exchange.id ? 'bg-primary/10 border-primary/50' : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                      }`} data-testid={`select-exchange-${exchange.id}`}>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ backgroundColor: exchange.color + '20', color: exchange.color }}>
                          {exchange.name.charAt(0)}
                        </div>
                        <span className={`text-sm font-medium ${selectedExchange === exchange.id ? 'text-white' : 'text-gray-300'}`}>{exchange.name}</span>
                      </div>
                      {selectedExchange === exchange.id && <Check size={14} className="text-primary mt-1" />}
                    </button>
                  ))}
                </div>
              </>
            )}
            {tierKey !== 'free' && (
            <div className="p-3 bg-green-500/5 border border-green-500/20 rounded-lg">
              <div className="flex items-start gap-2">
                <Shield size={14} className="text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="text-green-300 text-xs font-semibold">Your Funds Stay on {SUPPORTED_EXCHANGES.find(e => e.id === selectedExchange)?.name}</span>
                  <p className="text-gray-400 text-[11px] leading-relaxed mt-0.5">
                    The bot sends trade commands via your exchange's API. No funds are transferred to or held by Alpha Unlimited. 
                    You maintain full control of your assets on your exchange at all times.
                  </p>
                </div>
              </div>
            </div>
            )}
            {!isAuthenticated && (
              <div className="p-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle size={14} className="text-yellow-400 flex-shrink-0 mt-0.5" />
                  <p className="text-yellow-300 text-xs">Sign in and connect your exchange API keys in the Trading Terminal to enable live trading. Demo bots simulate commands only.</p>
                </div>
              </div>
            )}
          </div>
        );

      case 'advanced':
        return (
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-white flex items-center gap-2"><Settings size={16} className="text-gray-400" /> Advanced Risk Controls</h4>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm text-gray-400 block mb-1">Stop Loss %</label>
                <input type="number" value={botSettings.stopLoss} onChange={e => setBotSettings({...botSettings, stopLoss: parseFloat(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-stop-loss" />
              </div>
              <div>
                <label className="text-sm text-gray-400 block mb-1">Take Profit %</label>
                <input type="number" value={botSettings.takeProfit} onChange={e => setBotSettings({...botSettings, takeProfit: parseFloat(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-take-profit" />
              </div>
            </div>

            {tierConfig.features.includes('trailing_sl') && (
              <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                <div>
                  <span className="text-sm text-white">Trailing Stop-Loss</span>
                  <p className="text-xs text-gray-500">Stop-loss follows price up, locks in profit</p>
                </div>
                <button onClick={() => setBotSettings({...botSettings, trailingStopLoss: !botSettings.trailingStopLoss})} data-testid="toggle-trailing-sl">
                  {botSettings.trailingStopLoss ? <ToggleRight size={24} className="text-green-400" /> : <ToggleLeft size={24} className="text-gray-600" />}
                </button>
              </div>
            )}

            {botSettings.trailingStopLoss && (
              <div>
                <label className="text-sm text-gray-400 block mb-1">Trailing Gap %</label>
                <input type="number" step="0.1" value={botSettings.trailingPercent} onChange={e => setBotSettings({...botSettings, trailingPercent: parseFloat(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-trailing-gap" />
              </div>
            )}

            {tierConfig.features.includes('trailing_tp') && (
              <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                <div>
                  <span className="text-sm text-white">Trailing Take-Profit</span>
                  <p className="text-xs text-gray-500">Maximizes gains by following price before exit</p>
                </div>
                <button onClick={() => setBotSettings({...botSettings, trailingTakeProfit: !botSettings.trailingTakeProfit})} data-testid="toggle-trailing-tp">
                  {botSettings.trailingTakeProfit ? <ToggleRight size={24} className="text-green-400" /> : <ToggleLeft size={24} className="text-gray-600" />}
                </button>
              </div>
            )}

            {tierConfig.features.includes('oco') && (
              <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                <div>
                  <span className="text-sm text-white">OCO Orders</span>
                  <p className="text-xs text-gray-500">One-Cancels-Other: auto-cancel opposing order</p>
                </div>
                <button onClick={() => setBotSettings({...botSettings, ocoEnabled: !botSettings.ocoEnabled})} data-testid="toggle-oco">
                  {botSettings.ocoEnabled ? <ToggleRight size={24} className="text-blue-400" /> : <ToggleLeft size={24} className="text-gray-600" />}
                </button>
              </div>
            )}

            {tierConfig.features.includes('multi_tp') && (
              <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                <label className="text-sm text-gray-400 block mb-2">Multiple Take-Profit Levels</label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {botSettings.takeProfitLevels?.map((tp, i) => (
                    <div key={i} className="flex gap-1 items-center">
                      <input type="number" value={tp.price} onChange={e => {
                          const levels = [...(botSettings.takeProfitLevels || [])];
                          levels[i] = { ...levels[i], price: parseFloat(e.target.value) };
                          setBotSettings({...botSettings, takeProfitLevels: levels});
                        }} className="w-12 bg-gray-700 rounded px-1 py-1 text-white text-center" placeholder="%" />
                      <span className="text-gray-500">%→</span>
                      <input type="number" value={tp.percent} onChange={e => {
                          const levels = [...(botSettings.takeProfitLevels || [])];
                          levels[i] = { ...levels[i], percent: parseFloat(e.target.value) };
                          setBotSettings({...botSettings, takeProfitLevels: levels});
                        }} className="w-12 bg-gray-700 rounded px-1 py-1 text-white text-center" placeholder="sell%" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tierConfig.features.includes('cooldown') && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Cooldown (seconds)</label>
                  <input type="number" min={0} value={botSettings.cooldownSeconds} onChange={e => setBotSettings({...botSettings, cooldownSeconds: parseInt(e.target.value) || 0})}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-cooldown"
                    placeholder="0 = no cooldown" />
                  <p className="text-[10px] text-gray-600 mt-1">Wait between trades</p>
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Max Daily Trades</label>
                  <input type="number" min={0} value={botSettings.maxDailyTrades} onChange={e => setBotSettings({...botSettings, maxDailyTrades: parseInt(e.target.value) || 0})}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-max-daily"
                    placeholder="0 = unlimited" />
                  <p className="text-[10px] text-gray-600 mt-1">0 = unlimited</p>
                </div>
              </div>
            )}

            {tierConfig.features.includes('max_daily') && (
              <div>
                <label className="text-sm text-gray-400 block mb-1">Max Daily Loss %</label>
                <input type="number" min={0} step={0.5} value={botSettings.maxDailyLossPercent} onChange={e => setBotSettings({...botSettings, maxDailyLossPercent: parseFloat(e.target.value) || 0})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-max-daily-loss"
                  placeholder="0 = no limit" />
                <p className="text-[10px] text-gray-600 mt-1">Bot pauses when daily loss exceeds this percentage of investment. 0 = no limit.</p>
              </div>
            )}

            {tierConfig.features.includes('position_sizing') && (
              <div>
                <label className="text-sm text-gray-400 block mb-1">Position Size: {botSettings.positionSizePercent}% of portfolio</label>
                <input type="range" min={1} max={100} value={botSettings.positionSizePercent} onChange={e => setBotSettings({...botSettings, positionSizePercent: parseInt(e.target.value)})}
                  className="w-full accent-primary" data-testid="input-position-size" />
                <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                  <span>1% (Conservative)</span><span>50%</span><span>100% (Full)</span>
                </div>
              </div>
            )}

            {tierConfig.features.includes('paper_trading') && (
              <div className={`flex items-center justify-between p-3 rounded-lg border ${tierKey === 'free' ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-yellow-500/5 border-yellow-500/20'}`}>
                <div>
                  <span className="text-sm text-white flex items-center gap-2">
                    <FileText size={14} className="text-yellow-400" /> Paper Trading Mode
                    {tierKey === 'free' && <span className="px-1.5 py-0.5 rounded text-[9px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">REQUIRED ON FREE</span>}
                  </span>
                  <p className="text-xs text-gray-500">
                    {tierKey === 'free' 
                      ? 'Paper trading is on by default for demo sandbox bots. Select Real Exchange in the Exchange step to use your 10 free daily trades.'
                      : 'Simulate trades without real funds — test your strategy'}
                  </p>
                </div>
                {tierKey === 'free' ? (
                  <div className="flex items-center gap-1">
                    <ToggleRight size={24} className="text-yellow-400" />
                    <Lock size={12} className="text-yellow-500" />
                  </div>
                ) : (
                  <button onClick={() => setBotSettings({...botSettings, paperTrading: !botSettings.paperTrading})} data-testid="toggle-paper-trading">
                    {botSettings.paperTrading ? <ToggleRight size={24} className="text-yellow-400" /> : <ToggleLeft size={24} className="text-gray-600" />}
                  </button>
                )}
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  const renderBotSettings = () => {
    switch (selectedBotType) {
      case 'grid':
      case 'infinity_grid':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Upper Price</label>
                <input type="number" value={botSettings.upperPrice} onChange={e => setBotSettings({...botSettings, upperPrice: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-upper-price" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Lower Price</label>
                <input type="number" value={botSettings.lowerPrice} onChange={e => setBotSettings({...botSettings, lowerPrice: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-lower-price" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Grid Count</label>
                <input type="number" value={botSettings.gridCount} onChange={e => setBotSettings({...botSettings, gridCount: parseInt(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-grid-count" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Investment (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-investment" /></div>
            </div>
          </div>
        );
      case 'dca':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Base Order (USDT)</label>
                <input type="number" value={botSettings.orderAmount} onChange={e => setBotSettings({...botSettings, orderAmount: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-order-amount" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Frequency</label>
                <select value={botSettings.frequency} onChange={e => setBotSettings({...botSettings, frequency: e.target.value as any})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="select-frequency">
                  <option value="hourly">Hourly</option><option value="4hourly">4 Hours</option><option value="daily">Daily</option><option value="weekly">Weekly</option>
                </select></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Safety Orders</label>
                <input type="number" value={botSettings.safetyOrders} onChange={e => setBotSettings({...botSettings, safetyOrders: parseInt(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-safety-orders" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">SO Size (USDT)</label>
                <input type="number" value={botSettings.safetyOrderSize} onChange={e => setBotSettings({...botSettings, safetyOrderSize: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-safety-size" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">SO Step %</label>
                <input type="number" value={botSettings.safetyOrderStep} onChange={e => setBotSettings({...botSettings, safetyOrderStep: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-safety-step" /></div>
            </div>
            <div><label className="text-sm text-gray-400 block mb-1">Investment (USDT)</label>
              <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-investment-dca" /></div>
          </div>
        );
      case 'trailing_stop':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Position Size (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-position-size-ts" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Trailing Gap %</label>
                <input type="number" step="0.1" value={botSettings.trailingPercent} onChange={e => setBotSettings({...botSettings, trailingPercent: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-trailing-percent" /></div>
            </div>
            <div><label className="text-sm text-gray-400 block mb-1">Activation Price (optional)</label>
              <input type="number" value={botSettings.activationPrice} onChange={e => setBotSettings({...botSettings, activationPrice: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" placeholder="Start trailing at..." data-testid="input-activation-price" /></div>
          </div>
        );
      case 'twap':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Total Order Size (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-twap-size" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Time Period</label>
                <select value={botSettings.frequency} onChange={e => setBotSettings({...botSettings, frequency: e.target.value as any})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="select-twap-period">
                  <option value="hourly">1 Hour</option><option value="4hourly">4 Hours</option><option value="daily">24 Hours</option><option value="weekly">7 Days</option>
                </select></div>
            </div>
            <div><label className="text-sm text-gray-400 block mb-1">Number of Slices</label>
              <input type="number" value={botSettings.maxOrders} onChange={e => setBotSettings({...botSettings, maxOrders: parseInt(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-slices" /></div>
          </div>
        );
      case 'signal':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Position Size (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-signal-size" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Signal Source</label>
                <select value={botSettings.signalSource} onChange={e => setBotSettings({...botSettings, signalSource: e.target.value as any})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="select-signal-source">
                  <option value="ai">AI Predictions</option>
                  <option value="rsi">RSI (Oversold/Overbought)</option>
                  <option value="macd">MACD Crossover</option>
                  <option value="bollinger">Bollinger Bands</option>
                  {tierConfig.techAccess.includes('acm') && <option value="acm">ACM™ Signals</option>}
                  {tierConfig.techAccess.includes('ance') && <option value="ance">ANCE™ Engine</option>}
                  <option value="custom">Custom Webhook</option>
                </select></div>
            </div>
            <div><label className="text-sm text-gray-400 block mb-1">Signal Confidence Threshold %</label>
              <input type="number" value={botSettings.signalThreshold} onChange={e => setBotSettings({...botSettings, signalThreshold: parseInt(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-signal-threshold" /></div>
          </div>
        );
      case 'arbitrage':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Capital (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-arb-capital" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Min Spread %</label>
                <input type="number" step="0.1" value={botSettings.minSpread} onChange={e => setBotSettings({...botSettings, minSpread: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-min-spread" /></div>
            </div>
            <div><label className="text-sm text-gray-400 block mb-2">Exchanges to Monitor</label>
              <div className="flex flex-wrap gap-2">
                {['binance', 'okx', 'bybit', 'kucoin', 'gate', 'coinbase', 'kraken', 'bitget', 'mexc', 'htx'].map(ex => (
                  <button key={ex} onClick={() => setBotSettings({...botSettings, exchanges: (botSettings.exchanges || []).includes(ex) ? (botSettings.exchanges || []).filter(e => e !== ex) : [...(botSettings.exchanges || []), ex]})}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${(botSettings.exchanges || []).includes(ex) ? 'bg-pink-500/20 text-pink-400 border border-pink-500/50' : 'bg-gray-800 text-gray-400 border border-gray-700'}`}>
                    {ex.charAt(0).toUpperCase() + ex.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      case 'martingale':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Initial Order (USDT)</label>
                <input type="number" value={botSettings.orderAmount} onChange={e => setBotSettings({...botSettings, orderAmount: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-martingale-initial" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Multiplier</label>
                <input type="number" step="0.1" value={botSettings.martingaleMultiplier} onChange={e => setBotSettings({...botSettings, martingaleMultiplier: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-multiplier" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm text-gray-400 block mb-1">Max Steps</label>
                <input type="number" value={botSettings.maxMartingaleSteps} onChange={e => setBotSettings({...botSettings, maxMartingaleSteps: parseInt(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-max-steps" /></div>
              <div><label className="text-sm text-gray-400 block mb-1">Investment (USDT)</label>
                <input type="number" value={botSettings.investment} onChange={e => setBotSettings({...botSettings, investment: parseFloat(e.target.value)})} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white" data-testid="input-investment-mart" /></div>
            </div>
            <div className="p-3 bg-orange-500/10 border border-orange-500/20 rounded-lg">
              <div className="flex items-center gap-2 text-xs text-orange-400 mb-1"><AlertTriangle size={14} /> Risk Warning</div>
              <div className="text-sm text-gray-300">
                Max exposure: ${((botSettings.orderAmount || 0) * Math.pow((botSettings.martingaleMultiplier || 2), (botSettings.maxMartingaleSteps || 5) - 1)).toFixed(0)}
                {' '}| Total risk: ${Array.from({length: botSettings.maxMartingaleSteps || 5}, (_, i) => (botSettings.orderAmount || 0) * Math.pow((botSettings.martingaleMultiplier || 2), i)).reduce((a, b) => a + b, 0).toFixed(0)}
              </div>
            </div>
          </div>
        );
      default: return null;
    }
  };

  const steps: { id: typeof createStep; label: string; icon: React.ReactNode }[] = [
    { id: 'type', label: 'Bot Type', icon: <Bot size={14} /> },
    { id: 'settings', label: 'Parameters', icon: <Settings size={14} /> },
    { id: 'tech', label: 'Technology', icon: <Cpu size={14} /> },
    { id: 'filters', label: 'Filters', icon: <Filter size={14} /> },
    { id: 'bridge', label: 'Bridge Fusion', icon: <GitMerge size={14} /> },
    { id: 'exchange', label: 'Exchange', icon: <Wallet size={14} /> },
    { id: 'advanced', label: 'Risk Controls', icon: <Shield size={14} /> }
  ];

  const currentStepIndex = steps.findIndex(s => s.id === createStep);
  const isLastStep = currentStepIndex === steps.length - 1;
  const isFirstStep = currentStepIndex === 0;

  return (
    <div className="space-y-4" data-testid="ai-trading-bots">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Bot className="text-primary" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">AI Trading Bots</h2>
            <p className="text-xs text-gray-500">
              {bots.length}/{tierConfig.maxBots === -1 ? '∞' : tierConfig.maxBots} bots • {tierConfig.name} tier • Automated Exchange Commands
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`px-2 py-1 rounded text-xs font-medium ${
            tierConfig.color === 'gold' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
            tierConfig.color === 'purple' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' :
            tierConfig.color === 'pink' ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' :
            tierConfig.color === 'blue' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
            'bg-gray-500/20 text-gray-400 border border-gray-500/30'
          }`}>{tierConfig.name}</span>
          <Button onClick={() => { setEditingBotId(null); setShowCreateModal(true); setCreateStep('type'); }} disabled={!canCreateBot} className="bg-primary hover:bg-primary/90" size="sm" data-testid="button-create-bot">
            <Plus size={16} className="mr-1" /> New Bot
          </Button>
        </div>
      </div>

      {tierKey === 'free' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl overflow-hidden border border-gray-700">
          <div className="bg-gradient-to-r from-gray-800 via-gray-900 to-gray-800 p-4">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gray-500 to-gray-700 flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold text-sm">Free Tier — 10 Real Trades/Day + Demo Sandbox</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-green-500/20 text-green-400 border border-green-500/30">ACTIVE</span>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Get 10 free real trades per day on your connected exchange, or practice risk-free in our demo sandbox. 
                  Use Grid, DCA, and Trailing Stop bots with real or simulated funds.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {[
                { icon: <Zap size={14} />, label: '10 Real Trades/Day', desc: 'Connect exchange', active: true },
                { icon: <Bot size={14} />, label: '3 Bots', desc: 'Grid, DCA, Trailing', active: true },
                { icon: <BarChart3 size={14} />, label: 'Backtesting', desc: 'Test with history', active: true },
                { icon: <PieChart size={14} />, label: 'Portfolio View', desc: 'Track holdings', active: true },
                { icon: <Brain size={14} />, label: 'AI Suggestions', desc: 'Smart parameters', active: true },
                { icon: <Activity size={14} />, label: 'Market Overview', desc: 'Real-time prices', active: true },
                { icon: <Eye size={14} />, label: 'Copy Bot Preview', desc: 'View top traders', active: true },
              ].map((f, i) => (
                <div key={i} className="p-2 rounded-lg bg-gray-800/60 border border-gray-700/50">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-green-400">{f.icon}</span>
                    <span className="text-white text-[11px] font-medium">{f.label}</span>
                  </div>
                  <span className="text-gray-500 text-[10px]">{f.desc}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { icon: <Wallet size={12} />, label: '80+ Trades/Day', tier: 'Basic' },
                { icon: <Cpu size={12} />, label: 'Proprietary Tech', tier: 'Premium' },
                { icon: <Filter size={12} />, label: 'Advanced Filters', tier: 'Premium' },
                { icon: <GitMerge size={12} />, label: 'Bridge Fusion', tier: 'Platinum' },
              ].map((f, i) => (
                <div key={i} className="p-2 rounded-lg bg-gray-900/80 border border-gray-700/30 flex items-center gap-2">
                  <Lock size={10} className="text-gray-600 flex-shrink-0" />
                  <div>
                    <span className="text-gray-500 text-[10px] block">{f.label}</span>
                    <span className="text-gray-600 text-[9px]">Unlocks at {f.tier}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 p-2 bg-primary/5 border border-primary/20 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Zap size={14} className="text-primary" />
                <span className="text-gray-300 text-xs">Need more than 10 trades/day? Upgrade for 80+ daily trades, more bots, and proprietary tech starting at <span className="text-primary font-bold">$24/mo</span></span>
              </div>
              <button onClick={() => setShowUpgradeModal(true)} className="px-3 py-1.5 rounded-lg bg-primary/20 text-primary text-xs font-medium hover:bg-primary/30 transition-colors border border-primary/30 whitespace-nowrap" data-testid="button-upgrade-from-free">
                Compare Plans
              </button>
            </div>
          </div>
        </motion.div>
      )}

      <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Crown size={14} className="text-primary" />
            <span className="text-primary text-xs font-semibold">
              {tierKey === 'free' ? 'Free Tier — 10 Real Trades/Day + Demo Sandbox' : `Included with your ${tierConfig.name} subscription`}
            </span>
          </div>
          <span className="text-gray-500 text-[10px]">
            {tierConfig.maxBots === -1 ? 'Unlimited' : tierConfig.maxBots} bots • {tierKey === 'free' ? '10 real trades/day' : `${tierConfig.techAccess.length} technologies`} • {tierConfig.filterAccess.length} filters
          </span>
        </div>
      </div>

      <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg">
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="text-gray-500">Available bot types:</span>
          {BOT_TYPES.map(bt => (
            <span key={bt.id} className={`px-2 py-0.5 rounded ${tierConfig.botTypes.includes(bt.id) ? `bg-${bt.color}-500/20 text-${bt.color}-400` : 'bg-gray-800 text-gray-600'}`}>
              {bt.name}{!tierConfig.botTypes.includes(bt.id) && <Lock size={10} className="inline ml-1" />}
            </span>
          ))}
        </div>
      </div>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="relative overflow-hidden rounded-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-[#FFD700]/10 via-[#00D4FF]/10 to-[#A855F7]/10" />
        <div className="absolute inset-0 border border-[#FFD700]/30 rounded-xl" />
        <div className="relative p-4 sm:p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FFD700] to-[#00D4FF] flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[#FFD700] font-semibold text-sm">Proprietary Technology Powered</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-green-500/20 text-green-400 border border-green-500/30">ACTIVE</span>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  AI-powered signal generators using <span className="text-[#FFD700]">ACM™</span>, <span className="text-[#00D4FF]">QFRM™</span>, <span className="text-[#A855F7]">BIF™</span>, 
                  {' '}<span className="text-[#22C55E]">SBPE™</span>, <span className="text-[#F97316]">ANCE™</span> & <span className="text-[#EF4444]">ANCE²</span> 
                  {' '}+ 8 Advanced Market Filters + Bridge Fusion™. Bots send automated trade commands to your connected exchange — no funds flow through Alpha Unlimited.
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 text-[10px]">
              <div className="px-2 py-1 rounded bg-[#FFD700]/10 border border-[#FFD700]/30 text-[#FFD700] flex items-center gap-1"><Brain size={10} /> 18 Proprietary Technologies</div>
              <div className="px-2 py-1 rounded bg-[#00D4FF]/10 border border-[#00D4FF]/30 text-[#00D4FF] flex items-center gap-1"><Filter size={10} /> 8 Filters</div>
              <div className="px-2 py-1 rounded bg-[#A855F7]/10 border border-[#A855F7]/30 text-[#A855F7] flex items-center gap-1"><GitMerge size={10} /> Bridge Fusion</div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-xs text-gray-500">
              {tierConfig.techAccess.length} technologies • {tierConfig.filterAccess.length} filters • Bridge: {tierConfig.bridgeAccess.includes('auto') ? 'Auto' : tierConfig.bridgeAccess.includes('manual') ? 'Manual' : 'Locked'}
            </div>
            <Link href="/copyright">
              <span className="text-[#00D4FF] hover:text-[#00D4FF]/80 text-xs font-medium flex items-center gap-1 cursor-pointer whitespace-nowrap">
                Protected Technology <ExternalLink className="w-3 h-3" />
              </span>
            </Link>
          </div>
        </div>
      </motion.div>

      <div className="p-3 bg-green-500/5 border border-green-500/20 rounded-lg">
        <div className="flex items-start gap-2">
          <Shield size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
          <div>
            <span className="text-green-300 text-xs font-semibold">Automated Exchange Commands — Your Funds Stay on Your Exchange</span>
            <p className="text-gray-400 text-[11px] leading-relaxed mt-0.5">
              These AI bots send automated buy, sell, take-profit, and stop-loss commands directly to your connected exchange via API. 
              No funds are transferred to or held by Alpha Unlimited — all trades execute on your exchange where you maintain full control.
              Connect your exchange API keys in the Trading Terminal to enable live automated trading.
            </p>
          </div>
        </div>
      </div>

      {tierKey === 'free' && (
        <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity size={14} className="text-primary" />
              <span className="text-white text-sm font-medium">Daily Real Trades</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">{totalRealTrades}/{maxDailyTrades} used today</span>
              <div className="w-24 h-2 bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, (totalRealTrades / maxDailyTrades) * 100)}%`, backgroundColor: totalRealTrades >= maxDailyTrades ? '#EF4444' : totalRealTrades >= maxDailyTrades * 0.7 ? '#F59E0B' : '#22C55E' }} />
              </div>
            </div>
          </div>
          {totalRealTrades >= maxDailyTrades && (
            <div className="mt-2 p-2 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle size={12} className="text-red-400" />
                <span className="text-red-300 text-xs">Daily trade limit reached. Resets at midnight UTC.</span>
              </div>
              <button onClick={() => setShowUpgradeModal(true)} className="px-2 py-1 rounded bg-primary/20 text-primary text-xs font-medium hover:bg-primary/30 transition-colors border border-primary/30" data-testid="button-upgrade-trade-limit">
                Upgrade
              </button>
            </div>
          )}
        </div>
      )}

      {bots.length === 0 ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12 bg-gray-900/50 rounded-lg border border-gray-800">
          <Bot size={48} className="mx-auto text-gray-600 mb-4" />
          <h3 className="text-lg font-medium text-gray-400 mb-2">{tierKey === 'free' ? 'Start Trading — Free' : 'No Trading Bots'}</h3>
          <p className="text-sm text-gray-500 mb-2">
            {tierKey === 'free' 
              ? 'Create your first bot — connect your exchange for 10 free real trades/day, or use our demo sandbox to practice risk-free.'
              : 'Create your first AI trading bot to start automated trading on your connected exchange'}
          </p>
          <p className="text-xs text-gray-600 mb-4">
            {tierKey === 'free' 
              ? 'Free tier: 3 bots (Grid, DCA, Trailing) • 10 real trades/day • Demo sandbox • Backtesting • AI suggestions'
              : `${tierConfig.name} tier: Up to ${tierConfig.maxBots === -1 ? 'unlimited' : tierConfig.maxBots} bots • ${tierConfig.techAccess.length} technologies • ${tierConfig.filterAccess.length} filters`}
          </p>
          <div className="flex items-center justify-center gap-3">
            <Button onClick={() => { setEditingBotId(null); setShowCreateModal(true); setCreateStep('type'); }} className="bg-primary hover:bg-primary/90" data-testid="button-create-first-bot">
              <Plus size={16} className="mr-1" /> {tierKey === 'free' ? 'Create Free Bot' : 'Create Bot'}
            </Button>
            {tierKey === 'free' && (
              <Button onClick={() => setShowUpgradeModal(true)} variant="outline" className="border-gray-600 text-gray-400" data-testid="button-upgrade-empty">
                <Crown size={16} className="mr-1" /> Go Live — From $24/mo
              </Button>
            )}
          </div>
        </motion.div>
      ) : (
        <div className="grid gap-3">
          {bots.map(bot => (
            <motion.div key={bot.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-lg border transition-colors ${bot.status === 'running' ? 'bg-gray-900/80 border-green-500/20' : 'bg-gray-900/50 border-gray-800'}`}
              data-testid={`bot-card-${bot.id}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${BOT_TYPES.find(bt => bt.id === bot.type)?.bgColor || 'bg-gray-800'}`}>
                    {BOT_TYPES.find(bt => bt.id === bot.type)?.icon || <Bot size={20} />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-white">{bot.name}</span>
                      {bot.isDemo && <span className="px-1.5 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-400">DEMO</span>}
                      {bot.settings.paperTrading && <span className="px-1.5 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-400">PAPER</span>}
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${bot.status === 'running' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                        {bot.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 flex items-center gap-2 flex-wrap">
                      <span className="px-1.5 py-0.5 rounded bg-gray-800 text-gray-300 text-[10px] font-medium">{SUPPORTED_EXCHANGES.find(e => e.id === bot.connectedExchange)?.name || bot.connectedExchange}</span>
                      <span>{bot.pair} • {bot.trades} commands sent</span>
                      {bot.activeTech.length > 0 && (
                        <span className="flex items-center gap-1">
                          {bot.activeTech.map(techId => {
                            const tech = PROPRIETARY_TECH.find(t => t.id === techId);
                            return tech ? <span key={techId} className="px-1 py-0 rounded text-[9px] font-bold" style={{ backgroundColor: tech.color + '20', color: tech.color }}>{tech.shortName}</span> : null;
                          })}
                        </span>
                      )}
                      {bot.bridgeFusion.enabled && (
                        <span className="px-1 py-0 rounded text-[9px] bg-primary/20 text-primary font-bold flex items-center gap-0.5">
                          <GitMerge size={8} /> BRIDGE {bot.bridgeFusion.mode === 'auto' ? '(AUTO)' : `(${bot.bridgeFusion.selectedFilters.length})`}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {(bot.settings.paperTrading || bot.connectedExchange === 'demo') ? (
                    <div className="text-right">
                      <div className="text-xs text-yellow-400 font-medium">DEMO — Not Real Profits</div>
                      <div className="text-[10px] text-gray-500">Connect exchange for live P&L</div>
                    </div>
                  ) : (() => {
                    const symbol = bot.pair.replace('/', '');
                    const priceData = livePrices[symbol];
                    const signal = botSignals[bot.id];
                    const exchangeName = SUPPORTED_EXCHANGES.find(e => e.id === bot.connectedExchange)?.name || bot.connectedExchange;
                    if (!priceData) {
                      return (
                        <div className="text-right">
                          <div className="text-xs text-gray-400 flex items-center gap-1.5 justify-end"><RefreshCw size={10} className="animate-spin" /> Loading {bot.pair}</div>
                          <div className="text-[10px] text-gray-500">{exchangeName}</div>
                        </div>
                      );
                    }
                    return (
                      <div className="text-right">
                        <div className="text-xs text-white font-mono font-medium">${priceData.price < 1 ? priceData.price.toFixed(6) : priceData.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                        <div className={`text-[10px] font-medium ${priceData.changePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {priceData.changePercent >= 0 ? '+' : ''}{priceData.changePercent.toFixed(2)}% · {exchangeName}
                        </div>
                        {signal && (
                          <div className={`text-[9px] mt-0.5 ${signal.confidence >= 70 ? 'text-primary' : 'text-gray-500'}`}>
                            {signal.confidence}% confidence
                          </div>
                        )}
                      </div>
                    );
                  })()}
                  {(() => {
                    const signal = botSignals[bot.id];
                    if (!signal) {
                      const symbol = bot.pair.replace('/', '');
                      const hasPrice = !!livePrices[symbol];
                      return (
                        <div className="text-center min-w-[50px]">
                          <div className="text-xs text-gray-500 mb-0.5">Signal</div>
                          <div className="text-sm font-bold text-gray-500">{hasPrice && bot.status === 'running' ? <RefreshCw size={14} className="animate-spin mx-auto" /> : '—'}</div>
                        </div>
                      );
                    }
                    const colors = { BUY: 'text-green-400', SELL: 'text-red-400', HOLD: 'text-yellow-400' };
                    return (
                      <div className="text-center min-w-[50px]">
                        <div className="text-xs text-gray-500 mb-0.5">Signal</div>
                        <div className={`text-sm font-bold ${colors[signal.direction]}`}>{signal.direction}</div>
                        <div className={`text-[9px] ${colors[signal.direction]}`}>{signal.strength}%</div>
                      </div>
                    );
                  })()}
                  <button onClick={() => { setShowCommandLog(showCommandLog === bot.id ? null : bot.id); if (showPerformance === bot.id) setShowPerformance(null); }}
                    className={`p-2 rounded-lg transition-colors ${showCommandLog === bot.id ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-800 text-gray-400 hover:text-white'}`} 
                    title="Command Log" data-testid={`button-commands-${bot.id}`}>
                    <FileText size={16} />
                  </button>
                  <button onClick={() => { setShowPerformance(showPerformance === bot.id ? null : bot.id); if (showCommandLog === bot.id) setShowCommandLog(null); }}
                    className={`p-2 rounded-lg transition-colors ${showPerformance === bot.id ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
                    data-testid={`button-performance-${bot.id}`}>
                    <BarChart3 size={16} />
                  </button>
                  {bot.bridgeFusion.enabled && (
                    <button onClick={() => toggleBotBridge(bot.id)}
                      className={`p-2 rounded-lg transition-colors ${bot.bridgeFusion.enabled ? 'bg-primary/20 text-primary' : 'bg-gray-800 text-gray-600'}`}
                      title="Toggle Bridge Fusion" data-testid={`button-bridge-${bot.id}`}>
                      <GitMerge size={16} />
                    </button>
                  )}
                  <div className="flex items-center gap-1">
                    <button onClick={() => startEditBot(bot.id)}
                      className="p-2 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-colors"
                      title="Edit Bot Parameters" data-testid={`button-edit-bot-${bot.id}`}>
                      <Pencil size={16} />
                    </button>
                    <button onClick={() => toggleBot(bot.id)}
                      className={`p-2 rounded-lg transition-colors ${bot.status === 'running' ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30' : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'}`}
                      data-testid={`button-toggle-bot-${bot.id}`}>
                      {bot.status === 'running' ? <Pause size={16} /> : <Play size={16} />}
                    </button>
                    <button onClick={() => deleteBot(bot.id)}
                      className="p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors" data-testid={`button-delete-bot-${bot.id}`}>
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
              
              <AnimatePresence>
                {showPerformance === bot.id && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                    <div className="mt-4 pt-4 border-t border-gray-800">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                        <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">Win Rate</div>
                          <div className="font-bold text-gray-500">—</div>
                        </div>
                        <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">Sharpe Ratio</div>
                          <div className="font-bold text-gray-500">—</div>
                        </div>
                        <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">Max Drawdown</div>
                          <div className="font-bold text-gray-500">—</div>
                        </div>
                        <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                          <div className="text-xs text-gray-500 mb-1">ROI</div>
                          <div className="font-bold text-gray-500">—</div>
                        </div>
                      </div>
                      {(bot.activeTech.length > 0 || bot.activeFilters.length > 0 || bot.bridgeFusion.enabled) && (
                        <div className="p-3 bg-gray-800/30 rounded-lg border border-gray-700">
                          <div className="text-xs text-gray-500 mb-2">Active Enhancements</div>
                          <div className="flex flex-wrap gap-1.5">
                            {bot.activeTech.map(techId => {
                              const tech = PROPRIETARY_TECH.find(t => t.id === techId);
                              return tech ? <span key={techId} className="px-2 py-0.5 rounded text-[10px] font-medium" style={{ backgroundColor: tech.color + '15', color: tech.color, border: `1px solid ${tech.color}30` }}>{tech.shortName} +{(tech.boostFactor*100).toFixed(0)}%</span> : null;
                            })}
                            {bot.activeFilters.map(filterId => {
                              const filter = ADVANCED_FILTERS.find(f => f.id === filterId);
                              return filter ? <span key={filterId} className="px-2 py-0.5 rounded text-[10px]" style={{ backgroundColor: filter.color + '15', color: filter.color, border: `1px solid ${filter.color}30` }}>{filter.name}</span> : null;
                            })}
                            {bot.bridgeFusion.enabled && (
                              <span className="px-2 py-0.5 rounded text-[10px] bg-primary/15 text-primary border border-primary/30 flex items-center gap-1">
                                <GitMerge size={8} /> Bridge Fusion ({bot.bridgeFusion.mode}) — {bot.bridgeFusion.fusionStrength}% strength
                              </span>
                            )}
                          </div>
                          <div className="mt-2 text-xs text-gray-500">
                            Total signal boost: +{(calculateSignalBoost(bot.activeTech, bot.activeFilters, bot.bridgeFusion) * 100).toFixed(1)}% | 
                            Projected win rate: {Math.min(92, 52 + calculateSignalBoost(bot.activeTech, bot.activeFilters, bot.bridgeFusion) * 100).toFixed(1)}%
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {showCommandLog === bot.id && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                    <div className="mt-4 pt-4 border-t border-gray-800">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <FileText size={14} className="text-blue-400" />
                          <span className="text-sm font-medium text-white">Command Log</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800 text-gray-400">{bot.commandLog.length} commands</span>
                        </div>
                        <span className="text-[10px] text-gray-500">Sent to {SUPPORTED_EXCHANGES.find(e => e.id === bot.connectedExchange)?.name}</span>
                      </div>
                      {bot.commandLog.length === 0 ? (
                        <div className="text-center py-4 text-gray-500 text-xs">No commands sent yet. Bot is analyzing market conditions...</div>
                      ) : (
                        <div className="space-y-1 max-h-[200px] overflow-y-auto">
                          {bot.commandLog.slice(0, 15).map(cmd => (
                            <div key={cmd.id} className="flex items-center justify-between p-2 bg-gray-800/40 rounded-lg text-xs">
                              <div className="flex items-center gap-2">
                                <span className={`px-1.5 py-0.5 rounded font-bold text-[10px] ${
                                  cmd.type === 'BUY' || cmd.type === 'DCA_BUY' || cmd.type === 'GRID_BUY' ? 'bg-green-500/20 text-green-400' :
                                  cmd.type === 'SELL' || cmd.type === 'GRID_SELL' || cmd.type === 'TAKE_PROFIT' ? 'bg-blue-500/20 text-blue-400' :
                                  cmd.type === 'STOP_LOSS' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                                }`}>{cmd.type.replace('_', ' ')}</span>
                                <span className="text-gray-300">{cmd.pair}</span>
                                <span className="text-gray-500">@ ${cmd.price.toLocaleString()}</span>
                                <span className="text-gray-600">qty: {cmd.quantity.toFixed(6)}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                {cmd.pnl && <span className="text-green-400 text-[10px]">+${cmd.pnl.toFixed(2)}</span>}
                                <span className={`text-[10px] ${cmd.status === 'FILLED' ? 'text-green-400' : cmd.status === 'PENDING' ? 'text-yellow-400' : 'text-gray-500'}`}>
                                  {cmd.status}
                                </span>
                                <span className="text-gray-600 text-[10px]">{new Date(cmd.timestamp).toLocaleTimeString()}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {showCreateModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={closeModal}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
              onClick={e => e.stopPropagation()} data-testid="create-bot-modal">
              
              <div className="p-4 border-b border-gray-800 flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">{editingBotId ? 'Edit Bot Parameters' : 'Create AI Trading Bot'}</h3>
                <button onClick={closeModal} className="text-gray-400 hover:text-white"><X size={24} /></button>
              </div>

              <div className="px-3 pt-2 pb-1.5 border-b border-gray-800">
                <div className="flex gap-0.5 flex-wrap pb-1">
                  {steps.map((step, i) => (
                    <button key={step.id} onClick={() => setCreateStep(step.id)}
                      className={`flex items-center gap-1 px-1.5 py-1 rounded-md text-[10px] font-medium whitespace-nowrap transition-all ${
                        createStep === step.id ? 'bg-primary/20 text-primary border border-primary/30' :
                        i < currentStepIndex ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                        'bg-gray-800/50 text-gray-500 border border-gray-700 hover:text-gray-400'
                      }`} data-testid={`step-${step.id}`}>
                      {step.icon}
                      {step.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {renderCreateStepContent()}
              </div>

              <div className="p-4 border-t border-gray-800">
                {currentSignalBoost > 0 && (
                  <div className="mb-3 p-2 bg-primary/5 border border-primary/20 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-gray-400 flex items-center gap-1"><Gauge size={12} className="text-primary" /> Signal Quality Boost</span>
                    <span className="text-primary font-bold">+{(currentSignalBoost * 100).toFixed(0)}% accuracy • ~{projectedWinRate.toFixed(0)}% win rate</span>
                  </div>
                )}
                
                {!isAuthenticated && (
                  <div className="mb-3 p-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg flex items-center gap-2 text-xs">
                    <AlertTriangle size={14} className="text-yellow-400" />
                    <span className="text-yellow-400">Log in to save your bots and connect your exchange API keys for live automated trading.</span>
                  </div>
                )}

                <div className="flex items-center justify-between gap-3">
                  <Button variant="outline" onClick={() => {
                      if (isFirstStep) closeModal();
                      else setCreateStep(steps[currentStepIndex - 1].id);
                    }} className="border-gray-700 text-gray-400" data-testid="button-prev-step">
                    {isFirstStep ? 'Cancel' : 'Back'}
                  </Button>
                  {editingBotId ? (
                    <div className="flex gap-2 flex-1">
                      {!isLastStep && (
                        <Button onClick={() => setCreateStep(steps[currentStepIndex + 1].id)} variant="outline" className="border-gray-700 text-gray-400" data-testid="button-next-step-edit">
                          Next: {steps[currentStepIndex + 1].label}
                        </Button>
                      )}
                      <Button onClick={saveEditedBot} className="bg-green-600 hover:bg-green-700 flex-1" data-testid="button-save-edit-bot">
                        <Save size={16} className="mr-2" /> Save Changes
                      </Button>
                    </div>
                  ) : isLastStep ? (
                    <Button onClick={createBot} className="bg-primary hover:bg-primary/90 flex-1" data-testid="button-confirm-create-bot">
                      <Zap size={16} className="mr-2" /> Create Trading Bot
                    </Button>
                  ) : (
                    <Button onClick={() => setCreateStep(steps[currentStepIndex + 1].id)} className="bg-primary hover:bg-primary/90 flex-1" data-testid="button-next-step">
                      Next: {steps[currentStepIndex + 1].label}
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showUpgradeModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-[60] p-4" onClick={() => setShowUpgradeModal(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900 border border-gray-700 rounded-xl p-6 max-w-lg w-full" onClick={e => e.stopPropagation()}>
              <div className="text-center mb-6">
                <Crown className="mx-auto text-yellow-400 mb-3" size={48} />
                <h3 className="text-xl font-bold text-white mb-2">Upgrade Your Alpha Unlimited Tier</h3>
                <p className="text-gray-400 text-sm">Your subscription includes AI Trading Bots. Upgrade to unlock more bot types, proprietary technologies, advanced filters, and Bridge Fusion™.</p>
              </div>
              <div className="space-y-2 mb-6">
                {Object.entries(BOT_TIERS).map(([key, tier]) => (
                  <div key={key} className={`p-3 rounded-lg border ${key === tierKey ? 'border-primary/50 bg-primary/10' : 'border-gray-700 bg-gray-800/30'}`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-medium text-white">{tier.name}</span>
                        {key === tierKey && <span className="ml-2 text-[10px] text-primary bg-primary/20 px-1.5 py-0.5 rounded">CURRENT</span>}
                      </div>
                      <span className="text-xs text-gray-400">{tier.maxBots === -1 ? '∞' : tier.maxBots} bots</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{tier.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {tier.techAccess.length > 0 && <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">{tier.techAccess.length} tech</span>}
                      {tier.filterAccess.length > 0 && <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">{tier.filterAccess.length} filters</span>}
                      {tier.bridgeAccess.includes('auto') && <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">Auto Bridge</span>}
                      {tier.bridgeAccess.includes('manual') && !tier.bridgeAccess.includes('auto') && <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">Manual Bridge</span>}
                    </div>
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                <Button onClick={() => {
                  setShowUpgradeModal(false);
                  const tierSection = document.querySelector('[data-testid="button-tier-inline-basic"]');
                  if (tierSection) tierSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }} className="w-full bg-primary hover:bg-primary/90">
                  <Crown size={16} className="mr-2" /> View Subscription Tiers
                </Button>
                <Button onClick={() => setShowUpgradeModal(false)} variant="outline" className="w-full border-gray-600 text-gray-400">
                  Close
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
