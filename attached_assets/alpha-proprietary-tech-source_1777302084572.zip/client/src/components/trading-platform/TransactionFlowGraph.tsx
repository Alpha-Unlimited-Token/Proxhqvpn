/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Transaction Flow Visualization™ — Blockchain Evidence Trail Renderer
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * AUT_ModuleHash: AUT_e7b4c91f28a3d5601234abcd
 * ALPHA_INTEGRITY_SEAL: TX_FLOW_GRAPH_v2.0_PROTECTED
 * Calibration: FLOW_RENDERER_SEALED
 */

import { useState, useRef, useCallback, useMemo, useEffect } from "react";

export interface TxFlowNode {
  id: string;
  address: string;
  label: string;
  role: "victim" | "source" | "laundering" | "gas_funder" | "original_funder" | "poi" | "split_wallet" | "dai_recipient" | "dai_dispersal" | "destination" | "arb_receiver" | "final_destination" | "exchange" | "defi" | "token_recipient";
  chain: string;
  amount?: string;
  token?: string;
  column: number;
  subLabel?: string;
}

export interface TxFlowEdge {
  from: string;
  to: string;
  amount?: string;
  token?: string;
  txHash?: string;
  label?: string;
}

interface TransactionFlowGraphProps {
  nodes: TxFlowNode[];
  edges: TxFlowEdge[];
  title?: string;
  caseId?: string;
  onNodeClick?: (node: TxFlowNode) => void;
}

const ROLE_STYLES: Record<string, { bg: string; border: string; text: string; glow: string; icon: string }> = {
  victim:           { bg: "#1a0a0a", border: "#dc2626", text: "#fca5a5", glow: "rgba(220,38,38,0.4)", icon: "!" },
  source:           { bg: "#2d0a0a", border: "#ef4444", text: "#fca5a5", glow: "rgba(239,68,68,0.5)", icon: "\u26A0" },
  laundering:       { bg: "#2d0e22", border: "#ec4899", text: "#f9a8d4", glow: "rgba(236,72,153,0.4)", icon: "\u2622" },
  gas_funder:       { bg: "#1a1a0a", border: "#ca8a04", text: "#fde047", glow: "rgba(202,138,4,0.3)", icon: "\u26FD" },
  original_funder:  { bg: "#1a0e0a", border: "#ea580c", text: "#fdba74", glow: "rgba(234,88,12,0.4)", icon: "\u{1F3ED}" },
  poi:              { bg: "#2d0a1a", border: "#e11d48", text: "#fda4af", glow: "rgba(225,29,72,0.5)", icon: "\u{1F50D}" },
  split_wallet:     { bg: "#1a0e2d", border: "#8b5cf6", text: "#c4b5fd", glow: "rgba(139,92,246,0.3)", icon: "\u21C9" },
  dai_recipient:    { bg: "#0a1a2d", border: "#0ea5e9", text: "#7dd3fc", glow: "rgba(14,165,233,0.3)", icon: "D" },
  dai_dispersal:    { bg: "#0a1a2d", border: "#0ea5e9", text: "#7dd3fc", glow: "rgba(14,165,233,0.3)", icon: "D" },
  destination:      { bg: "#0e2d1a", border: "#16a34a", text: "#86efac", glow: "rgba(22,163,74,0.3)", icon: "\u2794" },
  arb_receiver:     { bg: "#0a0e2d", border: "#6366f1", text: "#a5b4fc", glow: "rgba(99,102,241,0.3)", icon: "A" },
  final_destination:{ bg: "#2d2206", border: "#d97706", text: "#fcd34d", glow: "rgba(217,119,6,0.5)", icon: "\u{1F3C1}" },
  exchange:         { bg: "#2d2a06", border: "#eab308", text: "#fef08a", glow: "rgba(234,179,8,0.5)", icon: "\u{1F3E6}" },
  defi:             { bg: "#0a2d1a", border: "#10b981", text: "#6ee7b7", glow: "rgba(16,185,129,0.3)", icon: "\u{1F504}" },
  token_recipient:  { bg: "#1a1f2e", border: "#64748b", text: "#94a3b8", glow: "rgba(100,116,139,0.2)", icon: "\u25CF" },
};

function getStyle(role: string) {
  return ROLE_STYLES[role] || ROLE_STYLES.token_recipient;
}

function shortenAddr(addr: string): string {
  if (!addr || addr.length < 12) return addr;
  return addr.slice(0, 8) + "..." + addr.slice(-6);
}

const NODE_W = 220;
const NODE_H = 64;
const COL_SPACING = 320;
const ROW_SPACING = 82;
const PAD = 80;

export default function TransactionFlowGraph({ nodes, edges, title, caseId, onNodeClick }: TransactionFlowGraphProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [dragging, setDragging] = useState(false);
  const [dragOrigin, setDragOrigin] = useState({ x: 0, y: 0 });
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [animPhase, setAnimPhase] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setAnimPhase(p => (p + 1) % 100), 50);
    return () => clearInterval(t);
  }, []);

  const layout = useMemo(() => {
    const cols: Record<number, TxFlowNode[]> = {};
    nodes.forEach(n => {
      const c = n.column;
      if (!cols[c]) cols[c] = [];
      cols[c].push(n);
    });

    const colKeys = Object.keys(cols).map(Number).sort((a, b) => a - b);
    const positions = new Map<string, { x: number; y: number; node: TxFlowNode }>();
    let maxY = 0;

    colKeys.forEach((col, ci) => {
      const colNodes = cols[col];
      const startY = PAD;
      colNodes.forEach((node, ri) => {
        const x = PAD + ci * COL_SPACING;
        const y = startY + ri * ROW_SPACING;
        positions.set(node.id, { x, y, node });
        if (y + NODE_H > maxY) maxY = y + NODE_H;
      });
    });

    const width = PAD * 2 + colKeys.length * COL_SPACING;
    const height = maxY + PAD;
    return { positions, width: Math.max(width, 900), height: Math.max(height, 500), colKeys };
  }, [nodes]);

  useEffect(() => {
    if (containerRef.current && layout.width > 0) {
      const cw = containerRef.current.clientWidth;
      const ch = containerRef.current.clientHeight || 650;
      const sx = cw / layout.width;
      const sy = ch / layout.height;
      const s = Math.min(sx, sy, 1) * 0.88;
      setTransform({ x: (cw - layout.width * s) / 2, y: 20, scale: s });
    }
  }, [layout]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const d = e.deltaY > 0 ? 0.92 : 1.08;
    setTransform(t => ({ ...t, scale: Math.max(0.08, Math.min(4, t.scale * d)) }));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setDragging(true);
    setDragOrigin({ x: e.clientX - transform.x, y: e.clientY - transform.y });
  }, [transform]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragging) return;
    setTransform(t => ({ ...t, x: e.clientX - dragOrigin.x, y: e.clientY - dragOrigin.y }));
  }, [dragging, dragOrigin]);

  const handleMouseUp = useCallback(() => setDragging(false), []);

  const connectedSet = useMemo(() => {
    if (!selectedNode) return new Set<string>();
    const s = new Set<string>();
    edges.forEach(e => {
      if (e.from === selectedNode) s.add(e.to);
      if (e.to === selectedNode) s.add(e.from);
    });
    return s;
  }, [selectedNode, edges]);

  const edgeData = useMemo(() => {
    return edges.map((edge, i) => {
      const fp = layout.positions.get(edge.from);
      const tp = layout.positions.get(edge.to);
      if (!fp || !tp) return null;

      const x1 = fp.x + NODE_W;
      const y1 = fp.y + NODE_H / 2;
      const x2 = tp.x;
      const y2 = tp.y + NODE_H / 2;

      const dx = x2 - x1;
      const cp1x = x1 + dx * 0.35;
      const cp2x = x2 - dx * 0.35;
      const path = `M ${x1} ${y1} C ${cp1x} ${y1}, ${cp2x} ${y2}, ${x2} ${y2}`;

      const toStyle = getStyle(tp.node.role);
      const isActive = selectedNode ? (edge.from === selectedNode || edge.to === selectedNode) : true;

      return { path, x1, y1, x2, y2, edge, i, toStyle, isActive, midX: (x1 + x2) / 2, midY: (y1 + y2) / 2 };
    }).filter(Boolean) as any[];
  }, [edges, layout, selectedNode]);

  if (!nodes || nodes.length === 0) {
    return (
      <div data-testid="text-no-flow-data" className="bg-[#08090d] rounded-xl border border-gray-800/40 p-8 text-center">
        <p className="text-gray-500 text-sm">No transaction flow data available for this case.</p>
      </div>
    );
  }

  return (
    <div data-testid="transaction-flow-graph" className="bg-[#08090d] rounded-xl border border-[#1a1d28] overflow-hidden shadow-2xl">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#1a1d28] bg-[#0c0e14]">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          <h3 className="text-sm font-bold tracking-wider" style={{ color: "#d4a843", fontFamily: "'Orbitron', sans-serif" }}>
            ALPHA TRANSACTION FLOW TRACE\u2122
          </h3>
          {title && <span className="text-[10px] text-gray-500 ml-2">| {title}</span>}
          <span className="text-[10px] text-gray-600">{nodes.length} nodes \u00B7 {edges.length} flows</span>
        </div>
        <div className="flex items-center gap-2">
          <button data-testid="button-flow-zoom-in" onClick={() => setTransform(t => ({ ...t, scale: Math.min(4, t.scale * 1.2) }))} className="w-7 h-7 flex items-center justify-center bg-[#141720] hover:bg-[#1a1f2e] rounded text-gray-400 text-sm border border-[#1e2230]">+</button>
          <button data-testid="button-flow-zoom-out" onClick={() => setTransform(t => ({ ...t, scale: Math.max(0.08, t.scale * 0.8) }))} className="w-7 h-7 flex items-center justify-center bg-[#141720] hover:bg-[#1a1f2e] rounded text-gray-400 text-sm border border-[#1e2230]">\u2212</button>
          <button data-testid="button-flow-fit" onClick={() => {
            if (containerRef.current) {
              const cw = containerRef.current.clientWidth;
              const ch = containerRef.current.clientHeight;
              const s = Math.min(cw / layout.width, ch / layout.height, 1) * 0.88;
              setTransform({ x: (cw - layout.width * s) / 2, y: 20, scale: s });
            }
          }} className="px-2 h-7 flex items-center justify-center bg-[#141720] hover:bg-[#1a1f2e] rounded text-gray-400 text-[10px] border border-[#1e2230]">Fit</button>
          {selectedNode && <button data-testid="button-flow-clear" onClick={() => setSelectedNode(null)} className="px-2 h-7 flex items-center justify-center bg-amber-900/20 hover:bg-amber-800/30 rounded text-amber-400 text-[10px] border border-amber-700/30">Clear</button>}
        </div>
      </div>

      <div className="flex items-center gap-4 px-5 py-1.5 border-b border-[#13151e] bg-[#0a0c12]">
        {[
          { role: "victim", label: "Victim" },
          { role: "source", label: "Source/Attacker" },
          { role: "laundering", label: "Laundering Hub" },
          { role: "poi", label: "Person of Interest" },
          { role: "split_wallet", label: "Split Wallet" },
          { role: "destination", label: "Fund Destination" },
          { role: "exchange", label: "Exchange" },
          { role: "arb_receiver", label: "Arbitrum" },
          { role: "final_destination", label: "Final Dest" },
        ].map(({ role, label }) => {
          const s = getStyle(role);
          return (
            <div key={role} className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.border, boxShadow: `0 0 6px ${s.glow}` }} />
              <span className="text-[9px] text-gray-500 tracking-wide">{label}</span>
            </div>
          );
        })}
      </div>

      <div
        ref={containerRef}
        className="relative select-none"
        style={{ height: "650px", cursor: dragging ? "grabbing" : "grab", background: "radial-gradient(ellipse at center, #0d0f16 0%, #08090d 100%)" }}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0)", backgroundSize: "40px 40px", pointerEvents: "none" }} />

        <svg width="100%" height="100%" style={{ position: "absolute", top: 0, left: 0 }}>
          <defs>
            {Object.entries(ROLE_STYLES).map(([role, s]) => (
              <marker key={`flow-arr-${role}`} id={`flow-arrow-${role}`} markerWidth="10" markerHeight="8" refX="10" refY="4" orient="auto">
                <polygon points="0 0, 10 4, 0 8" fill={s.border} opacity="0.8" />
              </marker>
            ))}
            <filter id="node-shadow">
              <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#000" floodOpacity="0.5" />
            </filter>
            <filter id="glow-pulse">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          <g transform={`translate(${transform.x}, ${transform.y}) scale(${transform.scale})`}>
            {edgeData.map((ed: any) => {
              const opacity = ed.isActive ? 0.7 : 0.12;
              const strokeW = ed.isActive ? 2 : 1;
              const dashOffset = -animPhase * 2;

              return (
                <g key={`edge-${ed.i}`}>
                  <path d={ed.path} fill="none" stroke={ed.toStyle.border} strokeWidth={strokeW} opacity={opacity} markerEnd={`url(#flow-arrow-${ed.edge.to ? (layout.positions.get(ed.edge.to)?.node.role || "token_recipient") : "token_recipient"})`} strokeDasharray={ed.isActive ? "none" : "4 4"} />
                  {ed.isActive && (
                    <path d={ed.path} fill="none" stroke={ed.toStyle.border} strokeWidth={1} opacity={0.4} strokeDasharray="6 12" strokeDashoffset={dashOffset} />
                  )}
                  {ed.edge.amount && ed.isActive && (
                    <g transform={`translate(${ed.midX}, ${ed.midY - 8})`}>
                      <rect x={-30} y={-8} width={60} height={16} rx={3} fill="#0c0e14" stroke={ed.toStyle.border} strokeWidth={0.5} opacity={0.9} />
                      <text x={0} y={4} textAnchor="middle" fill={ed.toStyle.text} fontSize="8" fontFamily="'Roboto Mono', monospace">{ed.edge.amount}</text>
                    </g>
                  )}
                </g>
              );
            })}

            {Array.from(layout.positions.entries()).map(([id, { x, y, node }]) => {
              const s = getStyle(node.role);
              const isSelected = selectedNode === id;
              const isConnected = connectedSet.has(id);
              const isHovered = hoveredNode === id;
              const dimmed = selectedNode && !isSelected && !isConnected;
              const nodeOpacity = dimmed ? 0.2 : 1;

              return (
                <g
                  key={id}
                  transform={`translate(${x}, ${y})`}
                  opacity={nodeOpacity}
                  style={{ cursor: "pointer", transition: "opacity 0.3s" }}
                  onMouseEnter={() => setHoveredNode(id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedNode(prev => prev === id ? null : id);
                    onNodeClick?.(node);
                  }}
                >
                  {(isSelected || isHovered) && (
                    <rect x={-3} y={-3} width={NODE_W + 6} height={NODE_H + 6} rx={10} fill="none" stroke={s.border} strokeWidth={1.5} opacity={0.5} filter="url(#glow-pulse)" />
                  )}

                  <rect x={0} y={0} width={NODE_W} height={NODE_H} rx={8} fill={s.bg} stroke={s.border} strokeWidth={isSelected ? 2 : 1.2} filter="url(#node-shadow)" />

                  <rect x={0} y={0} width={NODE_W} height={NODE_H} rx={8} fill="none" stroke={s.border} strokeWidth={0.3} opacity={0.3} />

                  <line x1={30} y1={0} x2={30} y2={NODE_H} stroke={s.border} strokeWidth={0.5} opacity={0.3} />

                  <text x={15} y={NODE_H / 2 + 5} textAnchor="middle" fill={s.text} fontSize="14" fontFamily="sans-serif">{s.icon}</text>

                  <text x={38} y={20} fill={s.text} fontSize="9.5" fontWeight="bold" fontFamily="'Roboto Mono', monospace" letterSpacing="0.3">
                    {shortenAddr(node.address)}
                  </text>

                  <text x={38} y={34} fill={s.text} fontSize="8" opacity={0.7} fontFamily="'Poppins', sans-serif">
                    {node.label.length > 26 ? node.label.slice(0, 24) + ".." : node.label}
                  </text>

                  {(node.amount || node.token) && (
                    <text x={38} y={48} fill={s.border} fontSize="7.5" fontWeight="bold" fontFamily="'Roboto Mono', monospace" opacity={0.9}>
                      {node.amount}{node.token ? ` ${node.token}` : ""}
                    </text>
                  )}

                  {node.subLabel && (
                    <text x={38} y={58} fill={s.text} fontSize="7" opacity={0.5} fontFamily="'Poppins', sans-serif">{node.subLabel}</text>
                  )}

                  <rect x={NODE_W - 50} y={3} width={46} height={14} rx={3} fill={s.border} opacity={0.15} />
                  <text x={NODE_W - 27} y={13} textAnchor="middle" fill={s.border} fontSize="7" fontFamily="'Roboto Mono', monospace" fontWeight="bold">
                    {node.chain.toUpperCase().slice(0, 6)}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>

        <div className="absolute bottom-3 left-5 flex items-center gap-2">
          <div className="px-3 py-1 bg-[#0c0e14]/90 border border-[#1e2230] rounded text-[9px] text-gray-500 tracking-wider" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            ALPHA UNLIMITED TRADING \u00B7 FORENSIC INTELLIGENCE ENGINE\u2122
          </div>
          {caseId && <div className="px-2 py-1 bg-[#0c0e14]/90 border border-amber-900/30 rounded text-[9px] text-amber-600/70 font-mono">Case: {caseId.slice(0, 8)}</div>}
        </div>
        <div className="absolute bottom-3 right-5 px-2 py-1 bg-[#0c0e14]/90 border border-[#1e2230] rounded text-[9px] text-gray-600 font-mono">
          Zoom: {(transform.scale * 100).toFixed(0)}%
        </div>
      </div>
    </div>
  );
}
