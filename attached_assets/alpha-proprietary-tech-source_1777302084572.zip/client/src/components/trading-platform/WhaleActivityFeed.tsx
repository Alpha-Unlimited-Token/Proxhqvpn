/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha WhaleActivityFeed™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_af9b82a25f9c59a146ddb946
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface WhaleTransaction {
  id: string;
  type: string;
  token: string;
  amount: number;
  value: number;
  timestamp: string;
  chain: string;
  from: string;
  to: string;
}

const CHAIN_COLORS: Record<string, string> = {
  bitcoin: '#F7931A',
  ethereum: '#627EEA',
  solana: '#9945FF',
  bsc: '#F0B90B',
  arbitrum: '#28A0F0',
  base: '#0052FF',
  tron: '#FF0013',
  polygon: '#8247E5',
};

const CHAIN_ICONS: Record<string, string> = {
  bitcoin: '₿',
  ethereum: '⟠',
  solana: '◎',
  bsc: '🔶',
  arbitrum: '🔵',
  base: '🔷',
  tron: '🔴',
  polygon: '🟣',
};

function formatValue(value: number): string {
  if (value >= 1e9) return `$${(value / 1e9).toFixed(1)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `$${(value / 1e3).toFixed(0)}K`;
  return `$${value.toFixed(0)}`;
}

function formatAmount(amount: number): string {
  if (amount >= 1e6) return `${(amount / 1e6).toFixed(1)}M`;
  if (amount >= 1e3) return `${(amount / 1e3).toFixed(1)}K`;
  return amount.toFixed(2);
}

function timeAgo(timestamp: string): string {
  const diff = Date.now() - new Date(timestamp).getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  return `${Math.floor(mins / 60)}h ago`;
}

let whaleCache: { transactions: WhaleTransaction[]; lastUpdate: Date; prevIds: Set<string> } = {
  transactions: [],
  lastUpdate: new Date(),
  prevIds: new Set(),
};
let globalIntervalId: ReturnType<typeof setInterval> | null = null;
let subscriberCount = 0;
const listeners = new Set<() => void>();

function notifyListeners() {
  listeners.forEach(fn => fn());
}

async function fetchWhaleDataGlobal() {
  try {
    const res = await fetch('/api/whale-transactions');
    if (!res.ok) return;
    const data = await res.json();
    const txList: WhaleTransaction[] = Array.isArray(data) ? data : (data?.transactions || []);
    if (txList.length > 0) {
      whaleCache = {
        transactions: txList,
        lastUpdate: new Date(),
        prevIds: new Set(txList.map(tx => tx.id)),
      };
      notifyListeners();
    }
  } catch (e) {
  }
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  subscriberCount++;
  if (subscriberCount === 1) {
    fetchWhaleDataGlobal();
    globalIntervalId = setInterval(fetchWhaleDataGlobal, 10000);
  }
  return () => {
    listeners.delete(listener);
    subscriberCount--;
    if (subscriberCount <= 0) {
      subscriberCount = 0;
      if (globalIntervalId) {
        clearInterval(globalIntervalId);
        globalIntervalId = null;
      }
    }
  };
}

interface WhaleActivityFeedProps {
  variant?: 'ticker' | 'compact' | 'mini';
  maxItems?: number;
  className?: string;
}

export function WhaleActivityFeed({ variant = 'ticker', maxItems = 8, className = '' }: WhaleActivityFeedProps) {
  const [transactions, setTransactions] = useState<WhaleTransaction[]>(whaleCache.transactions);
  const [lastUpdate, setLastUpdate] = useState<Date>(whaleCache.lastUpdate);
  const [newTxIds, setNewTxIds] = useState<Set<string>>(new Set());
  const prevIdsRef = useRef<Set<string>>(whaleCache.prevIds);

  useEffect(() => {
    const onUpdate = () => {
      const newIds = new Set<string>();
      whaleCache.transactions.forEach(tx => {
        if (!prevIdsRef.current.has(tx.id)) {
          newIds.add(tx.id);
        }
      });
      if (newIds.size > 0) {
        setNewTxIds(newIds);
        setTimeout(() => setNewTxIds(new Set()), 3000);
      }
      prevIdsRef.current = new Set(whaleCache.transactions.map(tx => tx.id));
      setTransactions(whaleCache.transactions);
      setLastUpdate(whaleCache.lastUpdate);
    };
    const unsub = subscribe(onUpdate);
    if (whaleCache.transactions.length > 0) {
      setTransactions(whaleCache.transactions);
      setLastUpdate(whaleCache.lastUpdate);
    }
    return unsub;
  }, []);

  const displayed = transactions.slice(0, maxItems);

  if (displayed.length === 0) {
    return (
      <div className={`flex items-center gap-2 text-[9px] text-gray-500 ${className}`}>
        <div className="w-2 h-2 rounded-full bg-blue-500/50 animate-pulse" />
        Loading whale activity...
      </div>
    );
  }

  if (variant === 'mini') {
    return (
      <div className={`flex items-center gap-1 overflow-hidden ${className}`} data-testid="whale-feed-mini">
        <span className="text-[8px] text-blue-400 font-bold whitespace-nowrap flex items-center gap-0.5">
          <AlertTriangle size={8} /> 🐋
        </span>
        <div className="flex-1 overflow-hidden relative">
          <div className="flex gap-3 animate-marquee">
            {displayed.map(tx => (
              <span key={tx.id} className="whitespace-nowrap text-[8px]" data-testid={`whale-mini-tx-${tx.id}`}>
                <span style={{ color: CHAIN_COLORS[tx.chain] || '#9ca3af' }}>{CHAIN_ICONS[tx.chain] || '🔗'}</span>
                {' '}
                <span className={tx.type === 'sell' ? 'text-red-400' : 'text-green-400'}>
                  {formatAmount(tx.amount)} {tx.token}
                </span>
                {' '}
                <span className="text-gray-500">{formatValue(tx.value)}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className={`${className}`} data-testid="whale-feed-compact">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[9px] font-bold text-blue-400 flex items-center gap-1">
            <AlertTriangle size={9} /> 🐋 Whale Activity
          </span>
          <span className="text-[7px] text-gray-500 flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            {timeAgo(lastUpdate.toISOString())}
          </span>
        </div>
        <div className="space-y-0.5 max-h-[120px] overflow-y-auto scrollbar-thin">
          <AnimatePresence mode="popLayout">
            {displayed.slice(0, 5).map(tx => (
              <motion.div
                key={tx.id}
                initial={newTxIds.has(tx.id) ? { opacity: 0, x: -10, backgroundColor: 'rgba(59, 130, 246, 0.15)' } : { opacity: 1, x: 0 }}
                animate={{ opacity: 1, x: 0, backgroundColor: 'transparent' }}
                transition={{ duration: 0.4 }}
                className="flex items-center justify-between px-1 py-0.5 rounded text-[8px] hover:bg-white/5"
                data-testid={`whale-compact-tx-${tx.id}`}
              >
                <div className="flex items-center gap-1">
                  <span style={{ color: CHAIN_COLORS[tx.chain] || '#9ca3af', fontSize: 9 }}>{CHAIN_ICONS[tx.chain] || '🔗'}</span>
                  <span className={tx.type === 'sell' ? 'text-red-400' : 'text-green-400'}>
                    {tx.type === 'sell' ? <ArrowDownRight size={7} /> : <ArrowUpRight size={7} />}
                  </span>
                  <span className="text-gray-300">{formatAmount(tx.amount)} <span className="text-gray-500">{tx.token}</span></span>
                </div>
                <span className="text-gray-400 font-mono">{formatValue(tx.value)}</span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-[#0D1117]/90 border border-blue-500/20 rounded-lg p-2 ${className}`} data-testid="whale-feed-ticker">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] font-bold text-blue-400 flex items-center gap-1">
          <AlertTriangle size={10} /> 🐋 Live Whale Activity
        </span>
        <div className="flex items-center gap-2">
          <span className="text-[7px] text-gray-500">Updates every 10s</span>
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
        </div>
      </div>
      <div className="space-y-0.5">
        <AnimatePresence mode="popLayout">
          {displayed.map(tx => (
            <motion.div
              key={tx.id}
              layout
              initial={newTxIds.has(tx.id) ? { opacity: 0, x: -20, scale: 0.95 } : { opacity: 1, x: 0, scale: 1 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className={`flex items-center justify-between px-1.5 py-1 rounded text-[9px] transition-colors ${
                newTxIds.has(tx.id) ? 'bg-blue-500/10 border border-blue-500/30' : 'hover:bg-white/5'
              }`}
              data-testid={`whale-tx-${tx.id}`}
            >
              <div className="flex items-center gap-1.5">
                <span style={{ color: CHAIN_COLORS[tx.chain] || '#9ca3af', fontSize: 11 }}>{CHAIN_ICONS[tx.chain] || '🔗'}</span>
                <span className={`font-bold ${tx.type === 'sell' ? 'text-red-400' : 'text-green-400'}`}>
                  {tx.type === 'sell' ? '↓SELL' : tx.type === 'buy' ? '↑BUY' : '→XFER'}
                </span>
                <span className="text-gray-300 font-medium">{formatAmount(tx.amount)} <span className="text-gray-500">{tx.token}</span></span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-300 font-mono font-bold">{formatValue(tx.value)}</span>
                <span className="text-gray-600 text-[7px]">{timeAgo(tx.timestamp)}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
