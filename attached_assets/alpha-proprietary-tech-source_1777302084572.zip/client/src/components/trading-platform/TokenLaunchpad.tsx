/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TokenLaunchpad™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_c21be291194cf814faacf9f2
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Rocket, Clock, Users, DollarSign, TrendingUp, Star, Lock,
  AlertTriangle, CheckCircle, ExternalLink, Calendar, Target,
  Bell, Mail, Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface LaunchProject {
  id: string;
  name: string;
  symbol: string;
  logo: string;
  description: string;
  category: string;
  chain: string;
  status: 'upcoming' | 'live' | 'ended';
  startDate: Date;
  endDate: Date;
  tokenPrice: number;
  totalRaise: number;
  currentRaise: number;
  participants: number;
  allocation: { tier: string; amount: number }[];
  vestingPeriod: string;
  tge: number;
  socials: { twitter?: string; telegram?: string; website?: string };
  isVerified: boolean;
}

const LAUNCH_PROJECTS: LaunchProject[] = [
  {
    id: '1',
    name: 'NeuroAI',
    symbol: 'NRAI',
    logo: '🧠',
    description: 'Decentralized AI compute network with distributed GPU resources',
    category: 'AI',
    chain: 'Ethereum',
    status: 'live',
    startDate: new Date('2026-01-28'),
    endDate: new Date('2026-02-02'),
    tokenPrice: 0.045,
    totalRaise: 2500000,
    currentRaise: 1875000,
    participants: 4521,
    allocation: [{ tier: 'free', amount: 100 }, { tier: 'basic', amount: 500 }, { tier: 'premium', amount: 2500 }, { tier: 'platinum', amount: 7500 }, { tier: 'alpha', amount: 10000 }],
    vestingPeriod: '12 months linear',
    tge: 20,
    socials: { twitter: 'https://x.com/neuroai', website: 'https://neuroai.io' },
    isVerified: true
  },
  {
    id: '2',
    name: 'SolanaSwift',
    symbol: 'SWIFT',
    logo: '⚡',
    description: 'Ultra-fast DEX aggregator with AI-powered routing',
    category: 'DeFi',
    chain: 'Solana',
    status: 'upcoming',
    startDate: new Date('2026-02-05'),
    endDate: new Date('2026-02-10'),
    tokenPrice: 0.012,
    totalRaise: 1000000,
    currentRaise: 0,
    participants: 0,
    allocation: [{ tier: 'free', amount: 50 }, { tier: 'basic', amount: 250 }, { tier: 'premium', amount: 1000 }, { tier: 'platinum', amount: 3500 }, { tier: 'alpha', amount: 5000 }],
    vestingPeriod: '6 months linear',
    tge: 25,
    socials: { twitter: 'https://x.com/solswift', telegram: 'https://t.me/solswift' },
    isVerified: true
  },
  {
    id: '3',
    name: 'GameFi Legends',
    symbol: 'GFL',
    logo: '🎮',
    description: 'Play-to-earn gaming platform with cross-chain NFT support',
    category: 'Gaming',
    chain: 'Polygon',
    status: 'upcoming',
    startDate: new Date('2026-02-15'),
    endDate: new Date('2026-02-20'),
    tokenPrice: 0.008,
    totalRaise: 750000,
    currentRaise: 0,
    participants: 0,
    allocation: [{ tier: 'free', amount: 25 }, { tier: 'basic', amount: 100 }, { tier: 'premium', amount: 500 }, { tier: 'platinum', amount: 1500 }, { tier: 'alpha', amount: 2500 }],
    vestingPeriod: '9 months cliff + linear',
    tge: 15,
    socials: { website: 'https://gamefilegends.io' },
    isVerified: false
  },
  {
    id: '4',
    name: 'ZeroKnowledge',
    symbol: 'ZKP',
    logo: '🔐',
    description: 'Privacy-first Layer 2 with ZK-rollup technology',
    category: 'Infrastructure',
    chain: 'Ethereum L2',
    status: 'ended',
    startDate: new Date('2026-01-15'),
    endDate: new Date('2026-01-20'),
    tokenPrice: 0.085,
    totalRaise: 5000000,
    currentRaise: 5000000,
    participants: 12453,
    allocation: [{ tier: 'free', amount: 200 }, { tier: 'basic', amount: 1000 }, { tier: 'premium', amount: 5000 }, { tier: 'platinum', amount: 15000 }, { tier: 'alpha', amount: 25000 }],
    vestingPeriod: '18 months linear',
    tge: 10,
    socials: { twitter: 'https://x.com/zeroknowledge', website: 'https://zkp.network' },
    isVerified: true
  },
];

export function TokenLaunchpad({ userTier = 'free' }: { userTier?: string }) {
  const { toast } = useToast();
  const [filter, setFilter] = useState<'all' | 'live' | 'upcoming' | 'ended'>('all');
  const [notifyEmail, setNotifyEmail] = useState('');
  const [emailSubmitted, setEmailSubmitted] = useState(false);

  const getAllocation = (project: LaunchProject) => {
    const tierAlloc = project.allocation.find(a => a.tier === userTier);
    return tierAlloc?.amount || project.allocation[0].amount;
  };

  const getTimeRemaining = (endDate: Date) => {
    const diff = endDate.getTime() - Date.now();
    if (diff <= 0) return 'Ended';
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    return `${days}d ${hours}h`;
  };

  const handleNotifyMe = () => {
    if (!notifyEmail || !notifyEmail.includes('@')) {
      toast({ title: 'Invalid Email', description: 'Please enter a valid email address', variant: 'destructive' });
      return;
    }
    setEmailSubmitted(true);
    toast({ title: 'You\'re on the list!', description: 'We\'ll notify you when the Token Launchpad goes live.' });
    setNotifyEmail('');
  };

  const filteredProjects = LAUNCH_PROJECTS.filter(p => filter === 'all' || p.status === filter);

  return (
    <div className="space-y-4" data-testid="token-launchpad">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Rocket className="text-purple-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Token Launchpad</h2>
            <p className="text-xs text-gray-500">Early access to new token launches</p>
          </div>
        </div>
        <div className="text-xs text-gray-400">
          Your tier: <span className="text-cyan-400 font-medium capitalize">{userTier}</span>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl border border-purple-500/40 bg-gradient-to-r from-purple-900/30 via-indigo-900/30 to-cyan-900/30 p-5"
        data-testid="coming-soon-banner"
      >
        <div className="absolute top-0 right-0 px-3 py-1 bg-purple-500 text-white text-[10px] font-bold uppercase tracking-wider rounded-bl-lg">
          Coming Soon
        </div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-500/20 border border-purple-500/30 flex-shrink-0">
            <Bell className="text-purple-400" size={24} />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-bold text-white mb-1">Token Launchpad — Coming Soon</h3>
            <p className="text-sm text-gray-300">
              The projects shown below are <span className="text-yellow-400 font-medium">examples</span> of what you'll see when this feature launches. No real launches are live yet.
            </p>
          </div>
        </div>

        <div className="mt-4 flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
          {emailSubmitted ? (
            <div className="flex items-center gap-2 text-green-400 text-sm" data-testid="notify-success">
              <CheckCircle size={16} />
              <span>You're on the list! We'll notify you when we launch.</span>
            </div>
          ) : (
            <>
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                <input
                  type="email"
                  value={notifyEmail}
                  onChange={e => setNotifyEmail(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleNotifyMe()}
                  placeholder="Enter your email for launch updates"
                  className="w-full pl-9 pr-3 py-2 bg-gray-800/80 border border-gray-700 rounded-lg text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50"
                  data-testid="input-notify-email"
                />
              </div>
              <Button
                onClick={handleNotifyMe}
                className="bg-purple-500 hover:bg-purple-600 text-white font-medium"
                size="sm"
                data-testid="button-notify-me"
              >
                <Bell size={14} className="mr-1.5" /> Notify Me
              </Button>
            </>
          )}
        </div>
      </motion.div>

      <div className="flex gap-2">
        {(['all', 'live', 'upcoming', 'ended'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              filter === f
                ? f === 'live' ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                  : f === 'upcoming' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                  : f === 'ended' ? 'bg-gray-500/20 text-gray-400 border border-gray-500/50'
                  : 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
                : 'bg-gray-800 text-gray-400 border border-gray-700'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)} {f === 'live' && '🔥'}
          </button>
        ))}
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
          <div className="px-4 py-2 bg-black/60 backdrop-blur-sm border border-purple-500/30 rounded-lg">
            <div className="flex items-center gap-2 text-purple-300 text-sm font-medium">
              <Eye size={16} />
              Preview — Example Projects
            </div>
          </div>
        </div>

        <div className="space-y-3 opacity-50" data-testid="demo-projects-list">
          {filteredProjects.map((project, i) => {
            const progress = (project.currentRaise / project.totalRaise) * 100;

            return (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`p-4 bg-gray-900/50 border rounded-lg transition-all ${
                  project.status === 'live' ? 'border-green-500/30' : 'border-gray-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                  <div className="flex items-start gap-3 sm:gap-4">
                    <div className="text-4xl">{project.logo}</div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center flex-wrap gap-2 mb-1">
                        <span className="font-bold text-white text-lg">{project.name}</span>
                        <span className="text-gray-500">${project.symbol}</span>
                        {project.isVerified && <CheckCircle size={14} className="text-blue-400" />}
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          project.status === 'live' ? 'bg-green-500/20 text-green-400'
                            : project.status === 'upcoming' ? 'bg-cyan-500/20 text-cyan-400'
                            : 'bg-gray-500/20 text-gray-400'
                        }`}>
                          {project.status.toUpperCase()}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                          EXAMPLE
                        </span>
                      </div>

                      <p className="text-sm text-gray-400 mb-2">{project.description}</p>

                      <div className="flex flex-wrap gap-2 mb-3">
                        <span className="px-2 py-0.5 bg-purple-500/20 text-purple-400 text-xs rounded">{project.category}</span>
                        <span className="px-2 py-0.5 bg-gray-700 text-gray-300 text-xs rounded">{project.chain}</span>
                      </div>

                      <div className="mb-2">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-500">Progress</span>
                          <span className="text-white">${(project.currentRaise / 1000000).toFixed(2)}M / ${(project.totalRaise / 1000000).toFixed(2)}M</span>
                        </div>
                        <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${project.status === 'ended' ? 'bg-gray-500' : 'bg-gradient-to-r from-purple-500 to-cyan-500'}`}
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
                        <span className="flex items-center gap-1"><DollarSign size={12} /> ${project.tokenPrice}</span>
                        <span className="flex items-center gap-1"><Users size={12} /> {project.participants.toLocaleString()}</span>
                        <span className="flex items-center gap-1"><Clock size={12} /> {getTimeRemaining(project.endDate)}</span>
                        <span className="flex items-center gap-1"><Lock size={12} /> TGE: {project.tge}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:block sm:text-right mt-3 sm:mt-0 pt-3 sm:pt-0 border-t sm:border-t-0 border-gray-800 sm:flex-shrink-0">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Your Allocation</div>
                      <div className="text-lg font-bold text-cyan-400">${getAllocation(project)}</div>
                    </div>

                    <div className="sm:mt-2">
                      {project.status === 'live' && (
                        <Button
                          disabled
                          className="bg-purple-500/50 cursor-not-allowed"
                          size="sm"
                        >
                          Participate
                        </Button>
                      )}
                      {project.status === 'upcoming' && (
                        <Button variant="outline" size="sm" disabled className="border-cyan-500/30 text-cyan-400/50 cursor-not-allowed">
                          Set Reminder
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <div className="p-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg text-xs text-yellow-400/80 flex items-start gap-2" data-testid="demo-disclaimer">
        <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
        <span>
          All projects, data, and figures shown above are fictional examples for demonstration purposes only. 
          No real token launches are currently available. Real projects will be listed once the Launchpad feature is live.
        </span>
      </div>
    </div>
  );
}
