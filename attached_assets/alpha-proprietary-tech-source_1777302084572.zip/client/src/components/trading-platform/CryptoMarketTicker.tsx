/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha CryptoMarketTicker™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_3fa3e3ee4f023de8cd239537
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, TrendingDown, Filter, X, ChevronDown, ChevronUp,
  Flame, Zap, BarChart3, Clock, ArrowUpRight, ArrowDownRight,
  Search, Star, RefreshCw, SlidersHorizontal, Wallet, Link2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ChainType } from '@/contexts/WalletContext';

interface ConnectedWalletInfo {
  id: string;
  name: string;
  chain: ChainType;
}

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  change1h: number;
  change7d: number;
  volume24h: number;
  marketCap: number;
  category: string;
  trending: boolean;
  chain: ChainType | 'multi';
  exchanges: string[];
  image?: string;
}

interface CryptoMarketTickerProps {
  connectedWallets?: ConnectedWalletInfo[];
  connectedExchanges?: string[];
  compact?: boolean;
}

type SortOption = 'gainers' | 'losers' | 'volume' | 'marketCap' | 'trending';
type TimeFrame = '1h' | '24h' | '7d';
type MarketCapFilter = 'all' | 'large' | 'mid' | 'small' | 'micro';
type ChainFilter = 'all' | 'solana' | 'evm' | 'connected';

const COIN_CATEGORIES = [
  { id: 'all', name: 'All Coins', icon: '🌐' },
  { id: 'layer1', name: 'Layer 1', icon: '⛓️' },
  { id: 'defi', name: 'DeFi', icon: '🏦' },
  { id: 'meme', name: 'Meme Coins', icon: '🐕' },
  { id: 'gaming', name: 'Gaming', icon: '🎮' },
  { id: 'ai', name: 'AI & Big Data', icon: '🤖' },
  { id: 'nft', name: 'NFT/Metaverse', icon: '🖼️' },
  { id: 'exchange', name: 'Exchange Tokens', icon: '🏛️' },
  { id: 'stablecoin', name: 'Stablecoins', icon: '💵' },
];

const CHAIN_OPTIONS = [
  { id: 'all', name: 'All Chains', icon: '🌐' },
  { id: 'connected', name: 'My Connected', icon: '🔗' },
  { id: 'solana', name: 'Solana', icon: '◎' },
  { id: 'evm', name: 'Ethereum/EVM', icon: '⟠' },
];

const MARKET_CAP_OPTIONS = [
  { id: 'all', name: 'All Market Caps' },
  { id: 'large', name: 'Large Cap (>$10B)' },
  { id: 'mid', name: 'Mid Cap ($1B-$10B)' },
  { id: 'small', name: 'Small Cap ($100M-$1B)' },
  { id: 'micro', name: 'Micro Cap (<$100M)' },
];

const EXCHANGE_COINS: Record<string, string[]> = {
  binance: ['BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'DOGE', 'ADA', 'AVAX', 'LINK', 'SHIB', 'POL', 'UNI', 'PEPE', 'WIF', 'BONK', 'RNDR', 'FTM', 'INJ', 'GRT', 'AAVE'],
  bybit: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'AVAX', 'LINK', 'PEPE', 'WIF', 'BONK', 'RNDR', 'INJ'],
  okx: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'ADA', 'AVAX', 'LINK', 'SHIB', 'POL', 'UNI', 'PEPE', 'BONK'],
  coinbase: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'ADA', 'AVAX', 'LINK', 'SHIB', 'POL', 'UNI', 'AAVE', 'GRT', 'RNDR'],
  kraken: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'ADA', 'AVAX', 'LINK', 'POL', 'UNI', 'AAVE', 'GRT'],
  kucoin: ['BTC', 'ETH', 'SOL', 'DOGE', 'PEPE', 'WIF', 'BONK', 'SHIB', 'INJ', 'FTM'],
  gate: ['BTC', 'ETH', 'SOL', 'DOGE', 'PEPE', 'WIF', 'BONK', 'SHIB', 'FTM', 'INJ'],
  mexc: ['BTC', 'ETH', 'SOL', 'DOGE', 'PEPE', 'WIF', 'BONK', 'SHIB', 'FTM'],
  bitget: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'PEPE', 'WIF', 'BONK'],
  htx: ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'AVAX', 'LINK'],
};

const COIN_IDS = 'bitcoin,ethereum,solana,ripple,dogecoin,pepe,shiba-inu,cardano,avalanche-2,chainlink,uniswap,aave,binancecoin,matic-network,dogwifcoin,bonk,render-token,fantom,injective-protocol,the-graph,jupiter-exchange-solana,raydium,pyth-network,jito-governance-token';

const COIN_METADATA: Record<string, { symbol: string; category: string; chain: ChainType | 'multi'; exchanges: string[] }> = {
  'bitcoin': { symbol: 'BTC', category: 'layer1', chain: 'multi', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'kucoin', 'gate', 'mexc', 'bitget', 'htx'] },
  'ethereum': { symbol: 'ETH', category: 'layer1', chain: 'evm', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'kucoin', 'gate', 'mexc', 'bitget', 'htx'] },
  'solana': { symbol: 'SOL', category: 'layer1', chain: 'solana', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'kucoin', 'gate', 'mexc', 'bitget', 'htx'] },
  'ripple': { symbol: 'XRP', category: 'layer1', chain: 'multi', exchanges: ['binance', 'okx', 'coinbase', 'kraken', 'bitget', 'htx'] },
  'dogecoin': { symbol: 'DOGE', category: 'meme', chain: 'multi', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'kucoin', 'gate', 'mexc', 'bitget', 'htx'] },
  'pepe': { symbol: 'PEPE', category: 'meme', chain: 'evm', exchanges: ['binance', 'bybit', 'okx', 'kucoin', 'gate', 'mexc', 'bitget'] },
  'shiba-inu': { symbol: 'SHIB', category: 'meme', chain: 'evm', exchanges: ['binance', 'okx', 'coinbase', 'kucoin', 'gate', 'mexc'] },
  'cardano': { symbol: 'ADA', category: 'layer1', chain: 'multi', exchanges: ['binance', 'okx', 'coinbase', 'kraken'] },
  'avalanche-2': { symbol: 'AVAX', category: 'layer1', chain: 'evm', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'htx'] },
  'chainlink': { symbol: 'LINK', category: 'defi', chain: 'evm', exchanges: ['binance', 'bybit', 'okx', 'coinbase', 'kraken', 'htx'] },
  'uniswap': { symbol: 'UNI', category: 'defi', chain: 'evm', exchanges: ['binance', 'okx', 'coinbase', 'kraken'] },
  'aave': { symbol: 'AAVE', category: 'defi', chain: 'evm', exchanges: ['binance', 'coinbase', 'kraken'] },
  'binancecoin': { symbol: 'BNB', category: 'exchange', chain: 'evm', exchanges: ['binance'] },
  'matic-network': { symbol: 'POL', category: 'layer1', chain: 'evm', exchanges: ['binance', 'okx', 'coinbase', 'kraken'] },
  'dogwifcoin': { symbol: 'WIF', category: 'meme', chain: 'solana', exchanges: ['binance', 'bybit', 'okx', 'kucoin', 'gate', 'mexc', 'bitget'] },
  'bonk': { symbol: 'BONK', category: 'meme', chain: 'solana', exchanges: ['binance', 'bybit', 'okx', 'kucoin', 'gate', 'mexc', 'bitget'] },
  'render-token': { symbol: 'RNDR', category: 'ai', chain: 'solana', exchanges: ['binance', 'bybit', 'coinbase'] },
  'fantom': { symbol: 'FTM', category: 'layer1', chain: 'evm', exchanges: ['kucoin', 'gate', 'mexc'] },
  'injective-protocol': { symbol: 'INJ', category: 'defi', chain: 'multi', exchanges: ['binance', 'bybit', 'kucoin', 'gate'] },
  'the-graph': { symbol: 'GRT', category: 'ai', chain: 'evm', exchanges: ['binance', 'coinbase', 'kraken'] },
  'jupiter-exchange-solana': { symbol: 'JUP', category: 'defi', chain: 'solana', exchanges: ['binance', 'bybit', 'okx', 'kucoin'] },
  'raydium': { symbol: 'RAY', category: 'defi', chain: 'solana', exchanges: ['binance', 'okx', 'kucoin', 'gate'] },
  'pyth-network': { symbol: 'PYTH', category: 'defi', chain: 'solana', exchanges: ['binance', 'bybit', 'okx', 'kucoin'] },
  'jito-governance-token': { symbol: 'JTO', category: 'defi', chain: 'solana', exchanges: ['binance', 'bybit', 'okx'] },
};

const fetchLiveData = async (): Promise<CryptoData[]> => {
  try {
    const response = await fetch('/api/trading/market-overview');
    
    if (!response.ok) {
      throw new Error('Failed to fetch live data');
    }
    
    const data = await response.json();
    
    return data.map((coin: any) => {
      const metadata = COIN_METADATA[coin.id] || { 
        symbol: coin.symbol.toUpperCase(), 
        category: 'layer1', 
        chain: 'multi' as ChainType, 
        exchanges: [] 
      };
      
      return {
        id: coin.id,
        symbol: metadata.symbol,
        name: coin.name,
        price: coin.current_price || 0,
        change24h: coin.price_change_percentage_24h || 0,
        change1h: coin.price_change_percentage_1h_in_currency || 0,
        change7d: coin.price_change_percentage_7d_in_currency || 0,
        volume24h: coin.total_volume || 0,
        marketCap: coin.market_cap || 0,
        category: metadata.category,
        trending: Math.abs(coin.price_change_percentage_24h || 0) > 5,
        chain: metadata.chain,
        exchanges: metadata.exchanges,
        image: coin.image,
      };
    });
  } catch (error) {
    console.error('Error fetching live crypto data:', error);
    return [];
  }
};

export function CryptoMarketTicker({ connectedWallets = [], connectedExchanges = [], compact = false }: CryptoMarketTickerProps) {
  const [cryptoData, setCryptoData] = useState<CryptoData[]>([]);
  const [filteredData, setFilteredData] = useState<CryptoData[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [loadError, setLoadError] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('alpha-ticker-favorites');
      return saved ? new Set(JSON.parse(saved)) : new Set<string>();
    } catch { return new Set<string>(); }
  });
  const marqueeRef = useRef<HTMLDivElement>(null);

  const toggleFavorite = useCallback((coinId: string) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(coinId)) {
        next.delete(coinId);
      } else {
        next.add(coinId);
      }
      localStorage.setItem('alpha-ticker-favorites', JSON.stringify(Array.from(next)));
      return next;
    });
  }, []);

  useEffect(() => {
    const loadData = async () => {
      setIsRefreshing(true);
      setLoadError(null);
      const data = await fetchLiveData();
      if (data.length > 0) {
        setCryptoData(data);
        setLastUpdated(new Date());
      } else {
        setLoadError('Unable to load live data. Please try again.');
      }
      setIsRefreshing(false);
    };
    
    loadData();
    
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);
  
  const [sortBy, setSortBy] = useState<SortOption>('gainers');
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('24h');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [marketCapFilter, setMarketCapFilter] = useState<MarketCapFilter>('all');
  const [chainFilter, setChainFilter] = useState<ChainFilter>('all');
  const [minPercentage, setMinPercentage] = useState<number | ''>('');
  const [maxPercentage, setMaxPercentage] = useState<number | ''>('');
  const [minVolume, setMinVolume] = useState<number | ''>('');
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyTrending, setShowOnlyTrending] = useState(false);
  const [showOnlyConnected, setShowOnlyConnected] = useState(false);

  const connectedChains = useMemo(() => {
    const chains = new Set<ChainType>();
    connectedWallets.forEach(wallet => {
      if (wallet.chain !== 'none') chains.add(wallet.chain);
    });
    return chains;
  }, [connectedWallets]);

  const exchangeAvailableCoins = useMemo(() => {
    const coins = new Set<string>();
    connectedExchanges.forEach(exchangeId => {
      const exchangeCoins = EXCHANGE_COINS[exchangeId] || [];
      exchangeCoins.forEach(coin => coins.add(coin));
    });
    return coins;
  }, [connectedExchanges]);

  const hasConnections = connectedWallets.length > 0 || connectedExchanges.length > 0;

  useEffect(() => {
    let result = [...cryptoData];
    
    if (searchQuery) {
      result = result.filter(coin => 
        coin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        coin.symbol.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (categoryFilter !== 'all') {
      result = result.filter(coin => coin.category === categoryFilter);
    }
    
    if (chainFilter !== 'all') {
      if (chainFilter === 'connected') {
        result = result.filter(coin => {
          if (connectedChains.size > 0) {
            const matchesWalletChain = coin.chain === 'multi' || connectedChains.has(coin.chain as ChainType);
            if (matchesWalletChain) return true;
          }
          if (exchangeAvailableCoins.size > 0) {
            return exchangeAvailableCoins.has(coin.symbol);
          }
          return false;
        });
      } else {
        result = result.filter(coin => coin.chain === chainFilter || coin.chain === 'multi');
      }
    }

    if (showOnlyConnected && hasConnections) {
      result = result.filter(coin => {
        const matchesWalletChain = connectedChains.size === 0 || coin.chain === 'multi' || connectedChains.has(coin.chain as ChainType);
        const matchesExchange = exchangeAvailableCoins.size === 0 || exchangeAvailableCoins.has(coin.symbol);
        return matchesWalletChain && matchesExchange;
      });
    }
    
    if (marketCapFilter !== 'all') {
      result = result.filter(coin => {
        switch (marketCapFilter) {
          case 'large': return coin.marketCap >= 10000000000;
          case 'mid': return coin.marketCap >= 1000000000 && coin.marketCap < 10000000000;
          case 'small': return coin.marketCap >= 100000000 && coin.marketCap < 1000000000;
          case 'micro': return coin.marketCap < 100000000;
          default: return true;
        }
      });
    }
    
    const getChange = (coin: CryptoData) => {
      switch (timeFrame) {
        case '1h': return coin.change1h;
        case '7d': return coin.change7d;
        default: return coin.change24h;
      }
    };
    
    if (minPercentage !== '') {
      result = result.filter(coin => getChange(coin) >= minPercentage);
    }
    if (maxPercentage !== '') {
      result = result.filter(coin => getChange(coin) <= maxPercentage);
    }
    
    if (minVolume !== '') {
      result = result.filter(coin => coin.volume24h >= minVolume * 1000000);
    }
    
    if (minPrice !== '') {
      result = result.filter(coin => coin.price >= minPrice);
    }
    if (maxPrice !== '') {
      result = result.filter(coin => coin.price <= maxPrice);
    }
    
    if (showOnlyTrending) {
      result = result.filter(coin => coin.trending);
    }
    
    switch (sortBy) {
      case 'gainers':
        result.sort((a, b) => getChange(b) - getChange(a));
        break;
      case 'losers':
        result.sort((a, b) => getChange(a) - getChange(b));
        break;
      case 'volume':
        result.sort((a, b) => b.volume24h - a.volume24h);
        break;
      case 'marketCap':
        result.sort((a, b) => b.marketCap - a.marketCap);
        break;
      case 'trending':
        result.sort((a, b) => (b.trending ? 1 : 0) - (a.trending ? 1 : 0));
        break;
    }
    
    setFilteredData(result);
  }, [cryptoData, sortBy, timeFrame, categoryFilter, marketCapFilter, chainFilter, minPercentage, maxPercentage, minVolume, minPrice, maxPrice, searchQuery, showOnlyTrending, showOnlyConnected, connectedChains, exchangeAvailableCoins, hasConnections]);

  const refreshData = async () => {
    setIsRefreshing(true);
    setLoadError(null);
    const data = await fetchLiveData();
    if (data.length > 0) {
      setCryptoData(data);
      setLastUpdated(new Date());
    } else {
      setLoadError('Unable to refresh data. Please try again.');
    }
    setIsRefreshing(false);
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) return `$${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    if (price >= 1) return `$${price.toFixed(2)}`;
    if (price >= 0.0001) return `$${price.toFixed(6)}`;
    return `$${price.toFixed(8)}`;
  };

  const formatVolume = (vol: number) => {
    if (vol >= 1e9) return `$${(vol / 1e9).toFixed(2)}B`;
    if (vol >= 1e6) return `$${(vol / 1e6).toFixed(2)}M`;
    return `$${vol.toLocaleString()}`;
  };

  const formatMarketCap = (cap: number) => {
    if (cap >= 1e12) return `$${(cap / 1e12).toFixed(2)}T`;
    if (cap >= 1e9) return `$${(cap / 1e9).toFixed(2)}B`;
    if (cap >= 1e6) return `$${(cap / 1e6).toFixed(2)}M`;
    return `$${cap.toLocaleString()}`;
  };

  const getChangeValue = (coin: CryptoData) => {
    switch (timeFrame) {
      case '1h': return coin.change1h;
      case '7d': return coin.change7d;
      default: return coin.change24h;
    }
  };

  const clearFilters = () => {
    setCategoryFilter('all');
    setMarketCapFilter('all');
    setChainFilter('all');
    setMinPercentage('');
    setMaxPercentage('');
    setMinVolume('');
    setMinPrice('');
    setMaxPrice('');
    setSearchQuery('');
    setShowOnlyTrending(false);
    setShowOnlyConnected(false);
  };

  const hasActiveFilters = categoryFilter !== 'all' || marketCapFilter !== 'all' || 
    chainFilter !== 'all' || minPercentage !== '' || maxPercentage !== '' || minVolume !== '' || 
    minPrice !== '' || maxPrice !== '' || searchQuery !== '' || showOnlyTrending || showOnlyConnected;

  const sortedWithFavorites = useMemo(() => {
    const favs = filteredData.filter(c => favorites.has(c.id));
    const nonFavs = filteredData.filter(c => !favorites.has(c.id));
    return [...favs, ...nonFavs];
  }, [filteredData, favorites]);

  const baseItems = sortedWithFavorites.slice(0, compact ? 16 : 12);
  const marqueeItems = [...baseItems, ...baseItems];

  return (
    <div className={`bg-[#0D1A2D] border border-[#1A2942] rounded-xl overflow-hidden${compact ? '' : ' mb-4'}`} data-testid="crypto-market-ticker">
      <style>{`
        @keyframes marquee-scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .marquee-container {
          overflow: hidden !important;
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .marquee-container::-webkit-scrollbar {
          display: none;
          width: 0;
          height: 0;
        }
      `}</style>
      {!compact && <div className="p-3 sm:p-4 border-b border-[#1A2942]">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
              Market Overview
            </h3>
            {loadError && (
              <span className="text-red-400 text-xs">{loadError}</span>
            )}
          </div>
          
          <div className="overflow-x-auto -mx-3 px-3 scrollbar-thin">
            <div className="flex items-center gap-1 bg-[#152238] rounded-lg p-1 min-w-max">
              {(['gainers', 'losers', 'trending', 'volume', 'marketCap'] as SortOption[]).map((option) => (
                <button
                  key={option}
                  onClick={() => setSortBy(option)}
                  className={`px-2.5 sm:px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                    sortBy === option 
                      ? 'bg-[#00D4FF] text-[#0A1628]' 
                      : 'text-gray-400 hover:text-white hover:bg-[#1A2942]'
                  }`}
                  data-testid={`sort-${option}`}
                >
                  {option === 'gainers' && '🚀 Gainers'}
                  {option === 'losers' && '📉 Losers'}
                  {option === 'trending' && '🔥 Trending'}
                  {option === 'volume' && '📊 Volume'}
                  {option === 'marketCap' && '💎 Market Cap'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-1 bg-[#152238] rounded-lg p-1">
              {(['1h', '24h', '7d'] as TimeFrame[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeFrame(tf)}
                  className={`px-2.5 sm:px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                    timeFrame === tf 
                      ? 'bg-[#00D4FF] text-[#0A1628]' 
                      : 'text-gray-400 hover:text-white hover:bg-[#1A2942]'
                  }`}
                  data-testid={`timeframe-${tf}`}
                >
                  {tf}
                </button>
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className={`border-[#1A2942] text-xs ${hasActiveFilters ? 'bg-[#00D4FF]/20 border-[#00D4FF]' : ''}`}
              data-testid="button-toggle-filters"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1" />
              <span className="hidden sm:inline">Filters</span>
              <span className="sm:hidden">⚙️</span>
              {hasActiveFilters && <span className="ml-1 bg-[#00D4FF] text-[#0A1628] rounded-full w-4 h-4 text-[10px] flex items-center justify-center">!</span>}
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={refreshData}
              disabled={isRefreshing}
              className="text-gray-400 hover:text-white p-2"
              data-testid="button-refresh-ticker"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>

            <span className="text-xs text-gray-500 hidden md:block">
              Updated: {lastUpdated.toLocaleTimeString()}
            </span>
          </div>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="pt-4 mt-4 border-t border-[#1A2942] grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Search coins..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                    data-testid="input-search-coins"
                  />
                </div>

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none"
                  data-testid="select-category"
                >
                  {COIN_CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
                  ))}
                </select>

                <select
                  value={marketCapFilter}
                  onChange={(e) => setMarketCapFilter(e.target.value as MarketCapFilter)}
                  className="bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none"
                  data-testid="select-market-cap"
                >
                  {MARKET_CAP_OPTIONS.map(opt => (
                    <option key={opt.id} value={opt.id}>{opt.name}</option>
                  ))}
                </select>

                <select
                  value={chainFilter}
                  onChange={(e) => setChainFilter(e.target.value as ChainFilter)}
                  className={`bg-[#152238] border rounded-lg px-3 py-2 text-sm text-white focus:border-[#00D4FF] focus:outline-none ${
                    chainFilter === 'connected' ? 'border-[#00D4FF] bg-[#00D4FF]/10' : 'border-[#1A2942]'
                  }`}
                  data-testid="select-chain"
                >
                  {CHAIN_OPTIONS.map(opt => (
                    <option key={opt.id} value={opt.id} disabled={opt.id === 'connected' && !hasConnections}>
                      {opt.icon} {opt.name} {opt.id === 'connected' && !hasConnections ? '(No connections)' : ''}
                    </option>
                  ))}
                </select>

                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min %"
                    value={minPercentage}
                    onChange={(e) => setMinPercentage(e.target.value ? Number(e.target.value) : '')}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                    data-testid="input-min-percentage"
                  />
                  <input
                    type="number"
                    placeholder="Max %"
                    value={maxPercentage}
                    onChange={(e) => setMaxPercentage(e.target.value ? Number(e.target.value) : '')}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                    data-testid="input-max-percentage"
                  />
                </div>

                <input
                  type="number"
                  placeholder="Min Volume ($M)"
                  value={minVolume}
                  onChange={(e) => setMinVolume(e.target.value ? Number(e.target.value) : '')}
                  className="bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                  data-testid="input-min-volume"
                />

                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min Price ($)"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value ? Number(e.target.value) : '')}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                    data-testid="input-min-price"
                  />
                  <input
                    type="number"
                    placeholder="Max Price ($)"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : '')}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-[#00D4FF] focus:outline-none"
                    data-testid="input-max-price"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showOnlyTrending}
                      onChange={(e) => setShowOnlyTrending(e.target.checked)}
                      className="w-4 h-4 rounded border-[#1A2942] bg-[#152238] text-[#00D4FF] focus:ring-[#00D4FF]"
                      data-testid="checkbox-trending-only"
                    />
                    <span className="text-sm text-gray-400">🔥 Trending</span>
                  </label>
                  
                  {hasConnections && (
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={showOnlyConnected}
                        onChange={(e) => setShowOnlyConnected(e.target.checked)}
                        className="w-4 h-4 rounded border-[#1A2942] bg-[#152238] text-[#00D4FF] focus:ring-[#00D4FF]"
                        data-testid="checkbox-connected-only"
                      />
                      <span className="text-sm text-gray-400 flex items-center gap-1">
                        <Link2 className="w-3 h-3" /> My Connected
                      </span>
                    </label>
                  )}
                  
                  {hasActiveFilters && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearFilters}
                      className="text-gray-400 hover:text-red-400"
                      data-testid="button-clear-filters"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Clear
                    </Button>
                  )}
                </div>
                
                {hasConnections && (
                  <div className="col-span-full mt-2 flex flex-wrap items-center gap-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Link2 className="w-3 h-3 text-[#00D4FF]" /> Connected:
                    </span>
                    {connectedWallets.map(wallet => (
                      <span key={wallet.id} className="px-2 py-0.5 bg-[#152238] rounded-full border border-[#1A2942] flex items-center gap-1">
                        <Wallet className="w-3 h-3" /> {wallet.name}
                        <span className="text-[#00D4FF]">({wallet.chain})</span>
                      </span>
                    ))}
                    {connectedExchanges.map(exchange => (
                      <span key={exchange} className="px-2 py-0.5 bg-[#152238] rounded-full border border-[#1A2942] flex items-center gap-1">
                        🏛️ {exchange}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>}

      <div className="marquee-container">
        <div
          ref={marqueeRef}
          className={compact ? "p-2 flex gap-2 min-w-max" : "p-3 flex gap-3 min-w-max"}
          style={{ animation: `marquee-scroll ${compact ? 40 : 50}s linear infinite`, width: 'max-content' }}
          onMouseEnter={(e) => { e.currentTarget.style.animationPlayState = 'paused'; }}
          onMouseLeave={(e) => { e.currentTarget.style.animationPlayState = 'running'; }}
          onTouchStart={(e) => { e.currentTarget.style.animationPlayState = 'paused'; }}
          onTouchEnd={(e) => { e.currentTarget.style.animationPlayState = 'running'; }}
        >
          {marqueeItems.map((coin, index) => {
            const change = getChangeValue(coin);
            const isPositive = change >= 0;
            const isFav = favorites.has(coin.id);
            const cardClass = compact
              ? `flex-shrink-0 border rounded-xl p-2 min-w-[140px] transition-all cursor-pointer group ${isFav ? 'bg-[#1a2a3f] border-primary/30' : 'bg-[#152238] border-[#1A2942] hover:border-[#00D4FF]/50'}`
              : `flex-shrink-0 border rounded-xl p-3 min-w-[180px] transition-all cursor-pointer group ${isFav ? 'bg-[#1a2a3f] border-primary/30' : 'bg-[#152238] border-[#1A2942] hover:border-[#00D4FF]/50'}`;

            const cardContent = (
              <>
                <div className={`flex items-center justify-between ${compact ? 'mb-1' : 'mb-2'}`}>
                  <div className="flex items-center gap-2">
                    <div className={`rounded-full bg-gradient-to-br from-[#00D4FF]/20 to-[#0066FF]/20 flex items-center justify-center font-bold text-[#00D4FF] ${compact ? 'w-6 h-6 text-xs' : 'w-8 h-8 text-sm'}`}>
                      {coin.symbol.slice(0, 2)}
                    </div>
                    <div>
                      <span className={`text-white font-semibold ${compact ? 'text-xs' : 'text-sm'}`}>{coin.symbol}</span>
                      {coin.trending && <Flame className="inline w-3 h-3 ml-1 text-orange-500" />}
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(coin.id); }}
                    className={`transition-colors ${compact ? 'p-0.5' : 'p-1'}`}
                    data-testid={`btn-fav-${coin.symbol.toLowerCase()}`}
                    title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Star className={`${compact ? 'w-3 h-3' : 'w-4 h-4'} ${isFav ? 'text-primary fill-primary' : 'text-gray-600 group-hover:text-gray-400'}`} />
                  </button>
                </div>
                
                <div className={`font-bold text-white ${compact ? 'text-sm mb-0.5' : 'text-lg mb-1'}`}>
                  {formatPrice(coin.price)}
                </div>
                
                <div className={`flex items-center gap-1 font-medium ${isPositive ? 'text-green-400' : 'text-red-400'} ${compact ? 'text-xs' : 'text-sm'}`}>
                  {isPositive ? <ArrowUpRight className={compact ? "w-3 h-3" : "w-4 h-4"} /> : <ArrowDownRight className={compact ? "w-3 h-3" : "w-4 h-4"} />}
                  {isPositive ? '+' : ''}{change.toFixed(2)}%
                  {!compact && <span className="text-gray-500 text-xs ml-1">({timeFrame})</span>}
                </div>

                {!compact && (
                  <div className="mt-2 pt-2 border-t border-[#1A2942] flex justify-between text-[10px] text-gray-500">
                    <span>Vol: {formatVolume(coin.volume24h)}</span>
                    <span>MCap: {formatMarketCap(coin.marketCap)}</span>
                  </div>
                )}
              </>
            );

            return compact ? (
              <div
                key={`${coin.id}-${index}`}
                className={cardClass}
                data-testid={`coin-card-${coin.symbol.toLowerCase()}`}
              >
                {cardContent}
              </div>
            ) : (
              <motion.div
                key={`${coin.id}-${index}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={cardClass}
                data-testid={`coin-card-${coin.symbol.toLowerCase()}`}
              >
                {cardContent}
              </motion.div>
            );
          })}
        </div>
      </div>

      {!compact && filteredData.length === 0 && (
        <div className="p-8 text-center text-gray-500">
          <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p>No coins match your filters</p>
          <Button variant="link" onClick={clearFilters} className="text-[#00D4FF]">
            Clear filters
          </Button>
        </div>
      )}

      {!compact && (
        <div className="p-2 border-t border-[#1A2942] text-center text-xs text-gray-500">
          Showing {filteredData.slice(0, 12).length} of {filteredData.length} coins
          {hasActiveFilters && <span className="text-[#00D4FF] ml-2">(Filtered)</span>}
        </div>
      )}
    </div>
  );
}
