/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha SocialSentiment™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_7d3103ed03093687cf54c359
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, TrendingDown, MessageCircle, Users, Activity,
  Hash, BarChart3, Zap, RefreshCw, Star, AlertCircle,
  ArrowUp, ArrowDown, Flame, Eye, Heart, Share2
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SocialMetrics {
  symbol: string;
  name: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  sentimentScore: number;
  tradeCount: number;
  tradingActivity: number;
  marketVolume: number;
  marketRank: number;
  trendingRank?: number;
  price: number;
  priceChange: number;
  volume24h: number;
  dataSource: string;
}

export function SocialSentiment({ userTier = 'free' }: { userTier?: string }) {
  const [socialData, setSocialData] = useState<SocialMetrics[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'bullish' | 'bearish' | 'trending'>('all');
  const [sortBy, setSortBy] = useState<'sentiment' | 'volume' | 'activity'>('sentiment');
  const [dataError, setDataError] = useState<string | null>(null);
  
  const isBasicPlus = userTier === 'basic' || userTier === 'premium' || userTier === 'platinum' || userTier === 'alpha';
  const isPremiumPlus = userTier === 'premium' || userTier === 'platinum' || userTier === 'alpha';
  const isAlpha = userTier === 'alpha';

  const refreshData = useCallback(async () => {
    setIsLoading(true);
    setDataError(null);
    try {
      const res = await fetch('/api/social-sentiment');
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      setSocialData(json.data || json);
    } catch {
      setDataError('Unable to load live sentiment data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 30000);
    return () => clearInterval(interval);
  }, [refreshData]);

  const filteredData = socialData
    .filter(item => {
      if (filter === 'all') return true;
      if (filter === 'trending') return item.trendingRank !== undefined;
      return item.sentiment === filter;
    })
    .sort((a, b) => {
      if (sortBy === 'sentiment') return b.sentimentScore - a.sentimentScore;
      if (sortBy === 'volume') return b.tradeCount - a.tradeCount;
      return b.tradingActivity - a.tradingActivity;
    });

  const overallSentiment = socialData.length > 0 ? socialData.reduce((sum, item) => sum + item.sentimentScore, 0) / socialData.length : 0;
  const totalVolume = socialData.reduce((sum, item) => sum + item.tradeCount, 0);
  const bullishCount = socialData.filter(i => i.sentiment === 'bullish').length;

  if (isLoading && socialData.length === 0) {
    return (
      <div className="space-y-4 text-center" data-testid="social-sentiment-loading">
        <RefreshCw className="text-cyan-400 mx-auto animate-spin" size={40} />
        <h3 className="text-base sm:text-lg font-bold text-white">Loading Live Sentiment Data...</h3>
        <p className="text-gray-400 text-sm">Fetching real-time market sentiment from exchanges</p>
      </div>
    );
  }

  if (dataError && socialData.length === 0) {
    return (
      <div className="space-y-4 text-center" data-testid="social-sentiment-error">
        <AlertCircle className="text-red-400 mx-auto" size={40} />
        <h3 className="text-base sm:text-lg font-bold text-white">Sentiment Data Unavailable</h3>
        <p className="text-gray-400 text-sm">{dataError}</p>
        <Button onClick={refreshData} className="bg-cyan-500 hover:bg-cyan-600">
          <RefreshCw className="w-4 h-4 mr-2" /> Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="social-sentiment">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <MessageCircle className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Market Sentiment</h2>
            <p className="text-xs text-gray-500">Derived from market price action &amp; volume</p>
          </div>
          <span className="text-xs px-2 py-0.5 bg-green-500/20 text-green-400 rounded-full">Live</span>
        </div>
        <Button
          onClick={refreshData}
          variant="outline"
          size="sm"
          disabled={isLoading}
          className="border-gray-700"
          data-testid="button-refresh-sentiment"
        >
          <RefreshCw size={14} className={`mr-1 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-3 bg-gray-900/80 border border-gray-800 rounded-lg"
        >
          <div className="text-xs text-gray-500 mb-1">Market Sentiment</div>
          <div className={`text-xl font-bold ${overallSentiment >= 60 ? 'text-green-400' : overallSentiment >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
            {overallSentiment.toFixed(0)}%
          </div>
          <div className={`text-xs ${overallSentiment >= 50 ? 'text-green-400' : 'text-red-400'}`}>
            {overallSentiment >= 60 ? 'Bullish' : overallSentiment >= 40 ? 'Neutral' : 'Bearish'}
          </div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-3 bg-gray-900/80 border border-gray-800 rounded-lg"
        >
          <div className="text-xs text-gray-500 mb-1">Trade Volume</div>
          <div className="text-xl font-bold text-white">{(totalVolume / 1000000).toFixed(1)}M</div>
          <div className="text-xs text-gray-400">trades/24h</div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-3 bg-gray-900/80 border border-gray-800 rounded-lg"
        >
          <div className="text-xs text-gray-500 mb-1">Bullish Assets</div>
          <div className="text-xl font-bold text-green-400">{bullishCount}/{socialData.length}</div>
          <div className="text-xs text-gray-400">tracking</div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-3 bg-gray-900/80 border border-gray-800 rounded-lg"
        >
          <div className="text-xs text-gray-500 mb-1">Top Trending</div>
          <div className="text-xl font-bold text-cyan-400">{socialData.find(i => i.trendingRank === 1)?.symbol || 'N/A'}</div>
          <div className="text-xs text-cyan-400 flex items-center gap-1">
            <Flame size={10} /> Hot right now
          </div>
        </motion.div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex gap-1">
          {(['all', 'bullish', 'bearish', 'trending'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                filter === f 
                  ? f === 'bullish' ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                  : f === 'bearish' ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                  : f === 'trending' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                  : 'bg-gray-700 text-white border border-gray-600'
                  : 'bg-gray-800/50 text-gray-400 hover:text-white'
              }`}
              data-testid={`button-filter-${f}`}
            >
              {f === 'trending' && <Flame size={12} className="inline mr-1" />}
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex gap-1 ml-auto">
          {(['sentiment', 'volume', 'activity'] as const).map(s => (
            <button
              key={s}
              onClick={() => setSortBy(s)}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                sortBy === s ? 'bg-primary/20 text-primary' : 'text-gray-500 hover:text-gray-300'
              }`}
              data-testid={`button-sort-${s}`}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {filteredData.map((item, idx) => (
          <motion.div
            key={item.symbol}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className={`p-3 rounded-lg border transition-colors ${
              item.sentiment === 'bullish' ? 'bg-green-500/5 border-green-500/20 hover:border-green-500/40'
              : item.sentiment === 'bearish' ? 'bg-red-500/5 border-red-500/20 hover:border-red-500/40'
              : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
            }`}
            data-testid={`sentiment-card-${item.symbol}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="text-center">
                  <div className="font-bold text-white">{item.symbol}</div>
                  <div className="text-[10px] text-gray-500">{item.name}</div>
                </div>
                {item.trendingRank && (
                  <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 text-[10px] flex items-center gap-0.5">
                    <Flame size={10} /> #{item.trendingRank}
                  </span>
                )}
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-center">
                  <div className="text-[10px] text-gray-500">Sentiment</div>
                  <div className={`font-bold ${
                    item.sentimentScore >= 60 ? 'text-green-400' 
                    : item.sentimentScore >= 40 ? 'text-yellow-400' 
                    : 'text-red-400'
                  }`}>
                    {item.sentimentScore.toFixed(0)}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-[10px] text-gray-500">Trades</div>
                  <div className="text-sm text-white flex items-center gap-1">
                    {(item.tradeCount / 1000).toFixed(0)}K
                    {item.priceChange >= 0 
                      ? <ArrowUp size={10} className="text-green-400" />
                      : <ArrowDown size={10} className="text-red-400" />
                    }
                  </div>
                </div>
                {isPremiumPlus && (
                  <>
                    <div className="text-center">
                      <div className="text-[10px] text-gray-500">Volume</div>
                      <div className="text-sm text-purple-400">${(item.marketVolume / 1e9).toFixed(1)}B</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-gray-500">Rank</div>
                      <div className="text-sm text-cyan-400">#{item.marketRank}</div>
                    </div>
                  </>
                )}
                <div className="w-24 h-2 bg-gray-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${item.sentimentScore}%` }}
                    className={`h-full ${
                      item.sentimentScore >= 60 ? 'bg-green-500' 
                      : item.sentimentScore >= 40 ? 'bg-yellow-500' 
                      : 'bg-red-500'
                    }`}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {!isPremiumPlus && (
        <div className="p-4 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-lg text-center">
          <Star className="mx-auto text-yellow-400 mb-2" size={24} />
          <div className="text-sm font-medium text-white mb-1">Unlock Pro Analytics</div>
          <div className="text-xs text-gray-400 mb-3">Get market volume, ranking data, and more with Pro tier</div>
          <Button className="bg-gradient-to-r from-purple-500 to-cyan-500 text-white" size="sm">
            Upgrade to Pro
          </Button>
        </div>
      )}
    </div>
  );
}
