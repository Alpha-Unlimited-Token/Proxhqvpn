/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AISupportResistance™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_7e08e7c964ebebb5a1453e23
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, TrendingUp, TrendingDown, Target, Layers,
  ArrowUp, ArrowDown, Zap, RefreshCw, Lock, Crown, BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SupportResistanceZone {
  id: string;
  type: 'support' | 'resistance';
  price: number;
  strength: 'weak' | 'moderate' | 'strong';
  touchCount: number;
  source: 'historical' | 'fibonacci' | 'pivot' | 'ai_predicted';
}

interface TrendAnalysis {
  direction: 'bullish' | 'bearish' | 'neutral';
  strength: number;
  confidence: number;
  signals: string[];
}

interface AIZoneAnalysis {
  zones: SupportResistanceZone[];
  trend: TrendAnalysis;
  nextSupport: number;
  nextResistance: number;
}

interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

function calcEMA(values: number[], period: number): number[] {
  const ema: number[] = [];
  const k = 2 / (period + 1);
  ema[0] = values[0];
  for (let i = 1; i < values.length; i++) {
    ema[i] = values[i] * k + ema[i - 1] * (1 - k);
  }
  return ema;
}

function calcRSI(closes: number[], period = 14): number {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function findPivotPoints(candles: CandleData[]): { pp: number; r1: number; r2: number; r3: number; s1: number; s2: number; s3: number } {
  const last = candles[candles.length - 1];
  const pp = (last.high + last.low + last.close) / 3;
  return {
    pp,
    r1: 2 * pp - last.low,
    r2: pp + (last.high - last.low),
    r3: last.high + 2 * (pp - last.low),
    s1: 2 * pp - last.high,
    s2: pp - (last.high - last.low),
    s3: last.low - 2 * (last.high - pp),
  };
}

function findFibLevels(candles: CandleData[]): { levels: number[]; swingHigh: number; swingLow: number } {
  let swingHigh = -Infinity, swingLow = Infinity;
  const lookback = Math.min(candles.length, 100);
  for (let i = candles.length - lookback; i < candles.length; i++) {
    if (candles[i].high > swingHigh) swingHigh = candles[i].high;
    if (candles[i].low < swingLow) swingLow = candles[i].low;
  }
  const range = swingHigh - swingLow;
  const ratios = [0.236, 0.382, 0.5, 0.618, 0.786];
  const levels = ratios.map(r => swingLow + range * r);
  return { levels, swingHigh, swingLow };
}

function findPriceClusters(candles: CandleData[], currentPrice: number): { price: number; touches: number }[] {
  const precision = currentPrice > 1000 ? 10 : currentPrice > 100 ? 1 : currentPrice > 1 ? 0.01 : 0.0001;
  const bucketSize = currentPrice * 0.005;
  const buckets = new Map<number, number>();

  for (const c of candles) {
    for (const p of [c.high, c.low, c.open, c.close]) {
      const bucket = Math.round(p / bucketSize) * bucketSize;
      buckets.set(bucket, (buckets.get(bucket) || 0) + 1);
    }
  }

  return Array.from(buckets.entries())
    .map(([price, touches]) => ({ price, touches }))
    .filter(c => c.touches >= 3)
    .sort((a, b) => b.touches - a.touches)
    .slice(0, 10);
}

function analyzeFromCandles(candles: CandleData[], currentPrice: number): AIZoneAnalysis {
  const closes = candles.map(c => c.close);
  const zones: SupportResistanceZone[] = [];
  let zoneId = 0;

  const pivots = findPivotPoints(candles);
  const pivotLevels = [
    { price: pivots.r3, type: 'resistance' as const, label: 'R3' },
    { price: pivots.r2, type: 'resistance' as const, label: 'R2' },
    { price: pivots.r1, type: 'resistance' as const, label: 'R1' },
    { price: pivots.s1, type: 'support' as const, label: 'S1' },
    { price: pivots.s2, type: 'support' as const, label: 'S2' },
    { price: pivots.s3, type: 'support' as const, label: 'S3' },
  ];

  for (const pv of pivotLevels) {
    if (pv.price > 0) {
      const distPct = Math.abs(pv.price - currentPrice) / currentPrice;
      if (distPct < 0.15) {
        zones.push({
          id: `pivot-${zoneId++}`,
          type: pv.type,
          price: pv.price,
          strength: distPct < 0.03 ? 'strong' : distPct < 0.07 ? 'moderate' : 'weak',
          touchCount: Math.max(1, Math.round(4 - distPct * 30)),
          source: 'pivot',
        });
      }
    }
  }

  const fib = findFibLevels(candles);
  for (const level of fib.levels) {
    const distPct = Math.abs(level - currentPrice) / currentPrice;
    if (distPct < 0.12 && distPct > 0.005) {
      zones.push({
        id: `fib-${zoneId++}`,
        type: level > currentPrice ? 'resistance' : 'support',
        price: level,
        strength: distPct < 0.03 ? 'strong' : distPct < 0.06 ? 'moderate' : 'weak',
        touchCount: 1,
        source: 'fibonacci',
      });
    }
  }

  const clusters = findPriceClusters(candles, currentPrice);
  for (const cluster of clusters) {
    const distPct = Math.abs(cluster.price - currentPrice) / currentPrice;
    if (distPct > 0.003 && distPct < 0.12) {
      const existing = zones.find(z => Math.abs(z.price - cluster.price) / currentPrice < 0.008);
      if (existing) {
        existing.touchCount = Math.max(existing.touchCount, cluster.touches);
        if (cluster.touches >= 6) existing.strength = 'strong';
        else if (cluster.touches >= 4) existing.strength = existing.strength === 'weak' ? 'moderate' : existing.strength;
      } else {
        zones.push({
          id: `hist-${zoneId++}`,
          type: cluster.price > currentPrice ? 'resistance' : 'support',
          price: cluster.price,
          strength: cluster.touches >= 6 ? 'strong' : cluster.touches >= 4 ? 'moderate' : 'weak',
          touchCount: cluster.touches,
          source: 'historical',
        });
      }
    }
  }

  const ema9 = calcEMA(closes, 9);
  const ema21 = calcEMA(closes, 21);
  const ema50 = calcEMA(closes, 50);
  const rsi = calcRSI(closes);
  const macdLine = ema9.map((v, i) => v - ema21[i]);
  const macdSignal = calcEMA(macdLine.slice(-26), 9);
  const macdHist = macdLine[macdLine.length - 1] - (macdSignal[macdSignal.length - 1] || 0);

  const signals: string[] = [];
  const lastEma9 = ema9[ema9.length - 1];
  const lastEma21 = ema21[ema21.length - 1];
  const lastEma50 = ema50[ema50.length - 1];
  const prevEma9 = ema9[ema9.length - 2];
  const prevEma21 = ema21[ema21.length - 2];

  if (prevEma9 < prevEma21 && lastEma9 > lastEma21) signals.push('EMA crossover bullish');
  else if (prevEma9 > prevEma21 && lastEma9 < lastEma21) signals.push('EMA crossover bearish');
  if (rsi < 30) signals.push('RSI oversold');
  else if (rsi > 70) signals.push('RSI overbought');
  if (closes.length >= 16) {
    const recent = closes.slice(-3);
    const prevRsi = calcRSI(closes.slice(0, -2));
    if (recent[2] < recent[0] && rsi > prevRsi) signals.push('RSI divergence detected');
    if (recent[2] > recent[0] && rsi < prevRsi) signals.push('Bearish RSI divergence');
  }
  if (macdHist > 0 && macdLine[macdLine.length - 2] - (macdSignal[macdSignal.length - 2] || 0) < 0) signals.push('MACD bullish crossover');
  if (macdHist > 0) signals.push('MACD histogram positive');
  else signals.push('MACD histogram negative');

  const latestVols = candles.slice(-5).map(c => c.volume || 0);
  const avgVol = candles.slice(-20).reduce((s, c) => s + (c.volume || 0), 0) / 20;
  if (latestVols.some(v => v > avgVol * 1.5)) signals.push('Volume spike detected');

  let bullScore = 0, bearScore = 0;
  if (currentPrice > lastEma9) bullScore++; else bearScore++;
  if (currentPrice > lastEma21) bullScore++; else bearScore++;
  if (currentPrice > lastEma50) bullScore++; else bearScore++;
  if (rsi > 50) bullScore++; else bearScore++;
  if (macdHist > 0) bullScore++; else bearScore++;
  if (lastEma9 > lastEma21) bullScore++; else bearScore++;

  const total = bullScore + bearScore;
  const direction = bullScore > bearScore + 1 ? 'bullish' : bearScore > bullScore + 1 ? 'bearish' : 'neutral';
  const strength = Math.max(bullScore, bearScore) / total;
  const confidence = 0.5 + (Math.abs(bullScore - bearScore) / total) * 0.45;

  const resistanceZones = zones.filter(z => z.type === 'resistance').sort((a, b) => a.price - b.price);
  const supportZones = zones.filter(z => z.type === 'support').sort((a, b) => b.price - a.price);

  const sortedZones = [
    ...resistanceZones.slice(0, 3).reverse(),
    ...supportZones.slice(0, 3),
  ];

  return {
    zones: sortedZones,
    trend: { direction, strength, confidence, signals },
    nextSupport: supportZones[0]?.price || currentPrice * 0.98,
    nextResistance: resistanceZones[0]?.price || currentPrice * 1.02,
  };
}

export function AISupportResistance({ 
  currentPrice = 0, 
  symbol = 'BTC/USDT',
  userTier = 'free',
  candleData = [] as CandleData[],
}: { 
  currentPrice?: number; 
  symbol?: string;
  userTier?: string;
  candleData?: CandleData[];
}) {
  const [analysis, setAnalysis] = useState<AIZoneAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [liveCandles, setLiveCandles] = useState<CandleData[]>([]);
  const [fetchError, setFetchError] = useState(false);
  
  const isPremium = userTier === 'premium' || userTier === 'platinum' || userTier === 'alpha';

  const fetchAndAnalyze = useCallback(async () => {
    if (!currentPrice || currentPrice <= 0) return;
    setIsLoading(true);

    setFetchError(false);
    try {
      let candles = candleData.length >= 50 ? candleData : liveCandles;

      if (candles.length < 50) {
        const cleanSymbol = symbol.replace('/', '').toUpperCase();
        const res = await fetch(`/api/historical-klines?symbol=${cleanSymbol}&interval=1h&limit=200`);
        if (res.ok) {
          const data = await res.json();
          candles = data.map((d: any) => ({
            time: d.time || d.t / 1000 || d[0] / 1000,
            open: parseFloat(d.open || d.o || d[1]),
            high: parseFloat(d.high || d.h || d[2]),
            low: parseFloat(d.low || d.l || d[3]),
            close: parseFloat(d.close || d.c || d[4]),
            volume: parseFloat(d.volume || d.v || d[5] || 0),
          }));
          setLiveCandles(candles);
        }
      }

      if (candles.length < 20) {
        setIsLoading(false);
        return;
      }

      const result = analyzeFromCandles(candles, currentPrice);
      setAnalysis(result);
    } catch (err) {
      console.debug('AI S/R analysis error:', err);
      setFetchError(true);
    }
    setIsLoading(false);
  }, [currentPrice, symbol, candleData, liveCandles]);

  useEffect(() => {
    if (currentPrice > 0) fetchAndAnalyze();
  }, [symbol]);

  useEffect(() => {
    if (!currentPrice || currentPrice <= 0) return;
    const interval = setInterval(() => {
      fetchAndAnalyze();
    }, 30000);
    return () => clearInterval(interval);
  }, [symbol, fetchAndAnalyze]);

  useEffect(() => {
    if (analysis && candleData.length >= 50 && currentPrice > 0) {
      const result = analyzeFromCandles(candleData, currentPrice);
      setAnalysis(result);
    }
  }, [currentPrice, candleData.length]);

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'strong': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'moderate': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'fibonacci': return '🔗';
      case 'historical': return '📊';
      case 'pivot': return '🎯';
      case 'ai_predicted': return '⚡';
      default: return '📈';
    }
  };

  const formatPrice = (price: number) => {
    if (price >= 10000) return `$${price.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    if (price >= 1) return `$${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    return `$${price.toFixed(6)}`;
  };

  return (
    <div className="bg-gray-900/50 rounded-xl border border-gray-800 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Target className="text-cyan-400" size={18} />
          <div>
            <h3 className="text-sm font-semibold text-white">AI Support/Resistance</h3>
            <p className="text-[10px] text-gray-500">{symbol} · AI-powered zone detection</p>
          </div>
        </div>
        <Button 
          size="sm" 
          variant="outline"
          onClick={fetchAndAnalyze}
          disabled={isLoading}
          className="text-xs gap-1"
          data-testid="btn-analyze-sr"
        >
          <RefreshCw size={12} className={isLoading ? 'animate-spin' : ''} />
          Analyze
        </Button>
      </div>

      {fetchError && !analysis && (
        <div className="text-center py-4">
          <span className="text-xs text-gray-500">Unable to load market data. Click Analyze to retry.</span>
        </div>
      )}

      {isLoading && !analysis && (
        <div className="flex items-center justify-center py-6">
          <RefreshCw className="animate-spin text-cyan-400" size={20} />
          <span className="text-xs text-gray-400 ml-2">Analyzing live market data...</span>
        </div>
      )}

      {analysis && (
        <>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-gray-800/50 rounded-lg p-2 text-center">
              <div className="text-[10px] text-gray-500">Trend</div>
              <div className={`text-sm font-bold flex items-center justify-center gap-1 ${
                analysis.trend.direction === 'bullish' ? 'text-green-400' : 
                analysis.trend.direction === 'bearish' ? 'text-red-400' : 'text-gray-400'
              }`}>
                {analysis.trend.direction === 'bullish' ? <TrendingUp size={14} /> : 
                 analysis.trend.direction === 'bearish' ? <TrendingDown size={14} /> : 
                 <Activity size={14} />}
                {analysis.trend.direction.charAt(0).toUpperCase() + analysis.trend.direction.slice(1)}
              </div>
              <div className="text-[10px] text-gray-500">{Math.round(analysis.trend.confidence * 100)}% conf.</div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-2 text-center">
              <div className="text-[10px] text-gray-500">Support</div>
              <div className="text-sm font-bold text-green-400">{formatPrice(analysis.nextSupport)}</div>
              <div className="text-[10px] text-gray-500">{((1 - analysis.nextSupport / currentPrice) * 100).toFixed(1)}% below</div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-2 text-center">
              <div className="text-[10px] text-gray-500">Resistance</div>
              <div className="text-sm font-bold text-red-400">{formatPrice(analysis.nextResistance)}</div>
              <div className="text-[10px] text-gray-500">{((analysis.nextResistance / currentPrice - 1) * 100).toFixed(1)}% above</div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-white font-medium">Price Zones</span>
              <button 
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="text-[10px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
                data-testid="toggle-sr-details"
              >
                {showAdvanced ? 'Hide Details' : 'Show Details'}
              </button>
            </div>
            <div className="space-y-1.5">
              {analysis.zones.map((zone) => (
                <motion.div
                  key={zone.id}
                  initial={{ opacity: 0, x: zone.type === 'resistance' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex items-center justify-between p-2 rounded-lg border ${
                    zone.type === 'resistance' 
                      ? 'border-red-500/20 bg-red-500/5' 
                      : 'border-green-500/20 bg-green-500/5'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {zone.type === 'resistance' ? 
                      <ArrowUp size={14} className="text-red-400" /> : 
                      <ArrowDown size={14} className="text-green-400" />}
                    <span className={`text-sm font-mono font-bold ${
                      zone.type === 'resistance' ? 'text-red-400' : 'text-green-400'
                    }`}>
                      {formatPrice(zone.price)}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] border ${getStrengthColor(zone.strength)}`}>
                      {zone.strength}
                    </span>
                    {showAdvanced && (
                      <span className="flex items-center gap-1 text-[10px] text-gray-500">
                        {getSourceIcon(zone.source)} {zone.source.replace('_', ' ')}
                      </span>
                    )}
                  </div>
                  {showAdvanced && (
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span>{zone.touchCount} touches</span>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          <div className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg min-h-[80px]">
            <div className="text-xs text-gray-400 mb-2">AI Signals Detected</div>
            <div className="flex flex-wrap gap-1 max-h-[48px] overflow-y-auto">
              {analysis.trend.signals.length > 0 ? (
                analysis.trend.signals.map((signal, idx) => (
                  <span key={idx} className="px-2 py-1 bg-primary/20 text-primary rounded text-xs">
                    {signal}
                  </span>
                ))
              ) : (
                <span className="text-xs text-gray-500">No significant signals detected</span>
              )}
            </div>
          </div>
        </>
      )}

      {!isPremium && (
        <div className="p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg text-center">
          <Crown className="mx-auto text-yellow-400 mb-2" size={24} />
          <div className="text-sm font-medium text-white mb-1">Unlock AI Predictions</div>
          <div className="text-xs text-gray-400 mb-3">Get breakout probabilities, trend strength analysis, and more</div>
          <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white" size="sm">
            Upgrade to Pro
          </Button>
        </div>
      )}
    </div>
  );
}
