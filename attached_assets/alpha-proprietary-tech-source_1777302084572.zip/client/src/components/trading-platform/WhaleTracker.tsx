/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha WhaleTracker™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_1230dbd19dd3d42b708bed34
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, TrendingUp, TrendingDown, Eye, Star, StarOff, Plus, Search, 
  RefreshCw, ExternalLink, Copy, Check, Filter, ChevronDown, Bell,
  BellRing, Wallet, ArrowUpRight, ArrowDownRight, Clock, Zap, 
  Activity, BarChart3, Target, Award, Shield, AlertTriangle, X,
  UserPlus, Settings, Globe, Coins
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface TrackedTrader {
  id: string;
  name: string;
  address: string;
  shortAddress: string;
  avatar: string;
  chain: 'solana' | 'ethereum' | 'bsc' | 'arbitrum' | 'base' | 'multi';
  type: 'whale' | 'smart_money' | 'influencer' | 'fund' | 'exchange';
  tags: string[];
  stats: {
    totalPnl: number;
    winRate: number;
    avgReturn: number;
    trades30d: number;
    followers: number;
    rank: number;
  };
  recentTrades: TradeActivity[];
  isFollowed: boolean;
  lastActive: Date;
  source: 'nansen' | 'arkham' | 'debank' | 'custom';
}

interface TradeActivity {
  id: string;
  visibleTrader?: string;
  type: 'buy' | 'sell' | 'swap' | 'transfer';
  token: string;
  tokenIcon: string;
  amount: number;
  value: number;
  timestamp: Date;
  txHash: string;
  platform: string;
}

interface FilterOptions {
  chain: string;
  type: string;
  minPnl: number;
  minWinRate: number;
  sortBy: 'pnl' | 'winRate' | 'trades' | 'followers' | 'recent';
}

interface WhaleTransaction {
  id: string;
  type: string;
  token: string;
  tokenIcon: string;
  amount: number;
  value: number;
  timestamp: string;
  txHash: string;
  platform: string;
  chain: string;
  from: string;
  to: string;
}

const CHAIN_ICONS: Record<string, { icon: string; color: string; name: string }> = {
  solana: { icon: '◎', color: '#9945FF', name: 'Solana' },
  ethereum: { icon: '⟠', color: '#627EEA', name: 'Ethereum' },
  bsc: { icon: '🔶', color: '#F0B90B', name: 'BNB Chain' },
  arbitrum: { icon: '🔵', color: '#28A0F0', name: 'Arbitrum' },
  base: { icon: '🔷', color: '#0052FF', name: 'Base' },
  multi: { icon: '🌐', color: '#00D4FF', name: 'Multi-Chain' },
  bitcoin: { icon: '₿', color: '#F7931A', name: 'Bitcoin' },
};

const TRADER_TYPES: Record<string, { label: string; color: string; icon: string }> = {
  whale: { label: 'Whale', color: '#00D4FF', icon: '🐋' },
  smart_money: { label: 'Smart Money', color: '#10B981', icon: '🧠' },
  influencer: { label: 'Influencer', color: '#EC4899', icon: '⭐' },
  fund: { label: 'Fund/VC', color: '#8B5CF6', icon: '🏛️' },
  exchange: { label: 'Exchange', color: '#F59E0B', icon: '🏦' },
};

function mapChain(chain: string): TrackedTrader['chain'] {
  const normalized = chain.toLowerCase();
  if (normalized === 'bitcoin' || normalized === 'btc') return 'ethereum';
  if (normalized === 'solana' || normalized === 'sol') return 'solana';
  if (normalized === 'bsc' || normalized === 'bnb') return 'bsc';
  if (normalized === 'arbitrum') return 'arbitrum';
  if (normalized === 'base') return 'base';
  if (normalized === 'ethereum' || normalized === 'eth') return 'ethereum';
  return 'multi';
}

function shortenAddress(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function transformTransactionsToTraders(transactions: WhaleTransaction[], existingTraders: TrackedTrader[]): TrackedTrader[] {
  const grouped = new Map<string, WhaleTransaction[]>();

  for (const tx of transactions) {
    const key = tx.from;
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key)!.push(tx);
  }

  const followedIds = new Set(existingTraders.filter(t => t.isFollowed).map(t => t.address));
  const customTraders = existingTraders.filter(t => t.source === 'custom');

  const traders: TrackedTrader[] = [];
  let rank = 1;

  const sortedEntries = Array.from(grouped.entries()).sort((a, b) => {
    const totalA = a[1].reduce((sum, tx) => sum + tx.value, 0);
    const totalB = b[1].reduce((sum, tx) => sum + tx.value, 0);
    return totalB - totalA;
  });

  for (const [address, txs] of sortedEntries) {
    const totalValue = txs.reduce((sum, tx) => sum + tx.value, 0);
    const chains = new Set(txs.map(tx => tx.chain));
    const primaryChain = chains.size > 1 ? 'multi' : mapChain(txs[0].chain);
    const tokens = Array.from(new Set(txs.map(tx => tx.token)));
    const latestTx = txs.reduce((latest, tx) =>
      new Date(tx.timestamp) > new Date(latest.timestamp) ? tx : latest
    , txs[0]);

    const recentTrades: TradeActivity[] = txs.slice(0, 3).map(tx => ({
      id: tx.id,
      type: 'transfer' as const,
      token: tx.token,
      tokenIcon: tx.tokenIcon,
      amount: tx.amount,
      value: tx.value,
      timestamp: new Date(tx.timestamp),
      txHash: tx.txHash,
      platform: tx.platform,
    }));

    const traderType: TrackedTrader['type'] = totalValue > 5000000 ? 'whale' :
      totalValue > 1000000 ? 'smart_money' : 'whale';

    const avatar = traderType === 'whale' ? '🐋' : '🧠';

    traders.push({
      id: `whale_${address}`,
      name: `Whale ${shortenAddress(address)}`,
      address: address,
      shortAddress: shortenAddress(address),
      avatar,
      chain: primaryChain,
      type: traderType,
      tags: tokens.slice(0, 3),
      stats: {
        totalPnl: totalValue,
        winRate: 0,
        avgReturn: 0,
        trades30d: txs.length,
        followers: 0,
        rank: rank,
      },
      recentTrades,
      isFollowed: followedIds.has(address),
      lastActive: new Date(latestTx.timestamp),
      source: 'arkham',
    });
    rank++;
  }

  return [...traders, ...customTraders];
}

function transformTransactionsToFeed(transactions: WhaleTransaction[]): TradeActivity[] {
  return transactions.map(tx => ({
    id: tx.id,
    type: 'transfer' as const,
    token: tx.token,
    tokenIcon: tx.tokenIcon,
    amount: tx.amount,
    value: tx.value,
    timestamp: new Date(tx.timestamp),
    txHash: tx.txHash,
    platform: tx.platform,
    visibleTrader: shortenAddress(tx.from),
  }));
}

export function WhaleTracker() {
  const { toast } = useToast();
  const [showDemo, setShowDemo] = useState(false);
  const [traders, setTraders] = useState<TrackedTrader[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [showAddWallet, setShowAddWallet] = useState(false);
  const [customWalletAddress, setCustomWalletAddress] = useState('');
  const [customWalletName, setCustomWalletName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'following' | 'live'>('all');
  const [liveFeed, setLiveFeed] = useState<TradeActivity[]>([]);
  const [dataSources, setDataSources] = useState<string[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  
  const [filters, setFilters] = useState<FilterOptions>({
    chain: 'all',
    type: 'all',
    minPnl: 0,
    minWinRate: 0,
    sortBy: 'pnl'
  });

  const fetchWhaleData = useCallback(async () => {
    try {
      const response = await fetch('/api/whale-transactions');
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      const transactions: WhaleTransaction[] = data.transactions || [];

      if (transactions.length === 0) {
        toast({
          title: 'No Data',
          description: 'No whale transactions found at this time. Try again later.',
        });
        return;
      }

      setTraders(prev => transformTransactionsToTraders(transactions, prev));
      setLiveFeed(transformTransactionsToFeed(transactions));
      if (data.sources) {
        setDataSources(data.sources);
      }
      setShowDemo(true);
    } catch (error: any) {
      toast({
        title: 'Failed to Load Whale Data',
        description: error.message || 'Could not fetch whale transactions. Please try again.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  useEffect(() => {
    if (traders.length === 0) return;
    const followedIds = traders.filter(t => t.isFollowed).map(t => t.id);
    localStorage.setItem('alpha-tracked-traders', JSON.stringify(followedIds));
  }, [traders]);

  useEffect(() => {
    if (!showDemo) return;

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    intervalRef.current = setInterval(() => {
      fetchWhaleData();
    }, 10000);
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [showDemo, fetchWhaleData]);

  const toggleFollow = (traderId: string) => {
    setTraders(prev => prev.map(t => {
      if (t.id === traderId) {
        const newFollowState = !t.isFollowed;
        toast({
          title: newFollowState ? 'Following Trader' : 'Unfollowed Trader',
          description: newFollowState 
            ? `You'll receive alerts when ${t.name} makes trades` 
            : `Stopped tracking ${t.name}`,
        });
        return { ...t, isFollowed: newFollowState };
      }
      return t;
    }));
  };

  const copyAddress = async (address: string) => {
    await navigator.clipboard.writeText(address);
    setCopied(address);
    setTimeout(() => setCopied(null), 2000);
    toast({ title: 'Address Copied', description: address });
  };

  const addCustomWallet = async () => {
    if (!customWalletAddress.trim()) {
      toast({ title: 'Error', description: 'Please enter a wallet address', variant: 'destructive' });
      return;
    }
    
    setIsLoading(true);
    
    await new Promise(r => setTimeout(r, 1500));
    
    const newTrader: TrackedTrader = {
      id: `custom_${Date.now()}`,
      name: customWalletName || `Wallet ${customWalletAddress.slice(0, 6)}`,
      address: customWalletAddress,
      shortAddress: `${customWalletAddress.slice(0, 6)}...${customWalletAddress.slice(-4)}`,
      avatar: '👤',
      chain: customWalletAddress.length > 50 ? 'solana' : 'ethereum',
      type: 'whale',
      tags: ['Custom', 'Tracking'],
      stats: { totalPnl: 0, winRate: 0, avgReturn: 0, trades30d: 0, followers: 1, rank: 999 },
      recentTrades: [],
      isFollowed: true,
      lastActive: new Date(),
      source: 'custom'
    };
    
    setTraders(prev => [...prev, newTrader]);
    setCustomWalletAddress('');
    setCustomWalletName('');
    setShowAddWallet(false);
    setIsLoading(false);
    
    toast({ title: 'Wallet Added', description: `Now tracking ${newTrader.name}` });
  };

  const filteredTraders = traders
    .filter(t => {
      if (activeTab === 'following' && !t.isFollowed) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!t.name.toLowerCase().includes(q) && 
            !t.address.toLowerCase().includes(q) &&
            !t.tags.some(tag => tag.toLowerCase().includes(q))) {
          return false;
        }
      }
      if (filters.chain !== 'all' && t.chain !== filters.chain) return false;
      if (filters.type !== 'all' && t.type !== filters.type) return false;
      if (t.stats.totalPnl < filters.minPnl) return false;
      if (t.stats.winRate < filters.minWinRate) return false;
      return true;
    })
    .sort((a, b) => {
      switch (filters.sortBy) {
        case 'pnl': return b.stats.totalPnl - a.stats.totalPnl;
        case 'winRate': return b.stats.winRate - a.stats.winRate;
        case 'trades': return b.stats.trades30d - a.stats.trades30d;
        case 'followers': return b.stats.followers - a.stats.followers;
        case 'recent': return b.lastActive.getTime() - a.lastActive.getTime();
        default: return 0;
      }
    });

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const formatValue = (value: number): string => {
    if (Math.abs(value) >= 1000000) return `$${(value / 1000000).toFixed(2)}M`;
    if (Math.abs(value) >= 1000) return `$${(value / 1000).toFixed(1)}K`;
    return `$${value.toFixed(0)}`;
  };

  const loadLiveData = async () => {
    setIsLoading(true);
    await fetchWhaleData();
    setIsLoading(false);
  };

  if (traders.length === 0 && !showDemo) {
    return (
      <div className="space-y-4 p-6 bg-gray-900/50 border border-gray-800 rounded-xl text-center px-3 sm:px-4 md:px-6" data-testid="whale-tracker-empty">
        <Users className="text-gray-600 mx-auto" size={48} />
        <h3 className="text-lg font-bold text-white">Whale & Smart Money Tracker</h3>
        <p className="text-gray-400 text-sm max-w-md mx-auto">
          Track real whale wallets and large blockchain transactions across Bitcoin, Ethereum, and more in real-time.
        </p>
        <Button onClick={loadLiveData} className="bg-cyan-500 hover:bg-cyan-600" disabled={isLoading} data-testid="button-load-live-data">
          {isLoading ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Eye className="w-4 h-4 mr-2" />} Load Live Whale Data
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4 px-3 sm:px-4 md:px-6" data-testid="whale-tracker">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Users className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Whale & Smart Money Tracker</h2>
            <p className="text-xs text-gray-500">Monitor top traders across all chains</p>
          </div>
          <span className="text-xs px-2 py-0.5 bg-green-500/20 text-green-400 rounded-full flex items-center gap-1">
            <Activity size={10} className="animate-pulse" /> Live
          </span>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={loadLiveData}
            variant="outline"
            size="sm"
            className="border-gray-700"
            disabled={isLoading}
            data-testid="button-refresh-data"
          >
            <RefreshCw size={14} className={`mr-1 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
          <Button
            onClick={() => setShowAddWallet(true)}
            className="bg-cyan-500 hover:bg-cyan-600"
            size="sm"
            data-testid="button-add-wallet"
          >
            <UserPlus size={14} className="mr-1" /> Track Wallet
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search traders, wallets, or tags..."
            className="pl-10 bg-gray-900/50 border-gray-700"
            data-testid="input-search-traders"
          />
        </div>
        <Button
          onClick={() => setShowFilters(!showFilters)}
          variant="outline"
          className="border-gray-700"
          data-testid="button-toggle-filters"
        >
          <Filter size={14} className="mr-1" /> Filters
          <ChevronDown className={`w-4 h-4 ml-1 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
        </Button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Chain</label>
                <select
                  value={filters.chain}
                  onChange={(e) => setFilters({ ...filters, chain: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                >
                  <option value="all">All Chains</option>
                  {Object.entries(CHAIN_ICONS).map(([key, val]) => (
                    <option key={key} value={key}>{val.icon} {val.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Type</label>
                <select
                  value={filters.type}
                  onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                >
                  <option value="all">All Types</option>
                  {Object.entries(TRADER_TYPES).map(([key, val]) => (
                    <option key={key} value={key}>{val.icon} {val.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Min Win Rate</label>
                <select
                  value={filters.minWinRate}
                  onChange={(e) => setFilters({ ...filters, minWinRate: Number(e.target.value) })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                >
                  <option value={0}>Any</option>
                  <option value={50}>50%+</option>
                  <option value={60}>60%+</option>
                  <option value={70}>70%+</option>
                  <option value={80}>80%+</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Sort By</label>
                <select
                  value={filters.sortBy}
                  onChange={(e) => setFilters({ ...filters, sortBy: e.target.value as any })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                >
                  <option value="pnl">Total Value</option>
                  <option value="winRate">Win Rate</option>
                  <option value="trades">Trade Count</option>
                  <option value="followers">Followers</option>
                  <option value="recent">Recently Active</option>
                </select>
              </div>
              <div className="flex items-end">
                <Button
                  onClick={() => setFilters({ chain: 'all', type: 'all', minPnl: 0, minWinRate: 0, sortBy: 'pnl' })}
                  variant="outline"
                  size="sm"
                  className="w-full border-gray-700"
                >
                  Reset
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex gap-2 border-b border-gray-800 pb-2">
        {[
          { id: 'all', label: 'All Traders', count: traders.length },
          { id: 'following', label: 'Following', count: traders.filter(t => t.isFollowed).length },
          { id: 'live', label: 'Live Feed', count: liveFeed.length },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
            data-testid={`tab-${tab.id}`}
          >
            {tab.label}
            <span className="ml-2 text-xs opacity-70">({tab.count})</span>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {showAddWallet && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-gray-900/50 border border-cyan-500/30 rounded-lg space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <Wallet size={16} className="text-cyan-400" />
                Track Custom Wallet
              </h3>
              <button onClick={() => setShowAddWallet(false)} className="text-gray-500 hover:text-white">
                <X size={16} />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Wallet Address *</label>
                <Input
                  value={customWalletAddress}
                  onChange={(e) => setCustomWalletAddress(e.target.value)}
                  placeholder="0x... or Solana address"
                  className="bg-gray-800 border-gray-700"
                  data-testid="input-custom-wallet"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Name (Optional)</label>
                <Input
                  value={customWalletName}
                  onChange={(e) => setCustomWalletName(e.target.value)}
                  placeholder="e.g., My Whale"
                  className="bg-gray-800 border-gray-700"
                />
              </div>
            </div>
            <Button
              onClick={addCustomWallet}
              disabled={isLoading || !customWalletAddress.trim()}
              className="w-full bg-cyan-500 hover:bg-cyan-600"
              data-testid="button-confirm-add-wallet"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <Plus size={14} className="mr-2" />}
              Add Wallet
            </Button>
            <p className="text-xs text-gray-500 text-center">
              Track any Ethereum or Solana wallet. Data sourced from DexScreener, DeBank, and on-chain analytics.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {activeTab === 'live' ? (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Activity className="w-4 h-4 text-green-400 animate-pulse" />
            <span>Live whale transactions (auto-refreshes every 30s)</span>
          </div>
          {liveFeed.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Activity size={40} className="mx-auto mb-3 opacity-50" />
              <p>No live transactions yet</p>
              <p className="text-sm mt-1">Waiting for whale activity...</p>
            </div>
          ) : (
            liveFeed.slice(0, 20).map((trade, index) => (
              <motion.div
                key={trade.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-3 bg-gray-900/50 border border-gray-800 rounded-lg flex items-center gap-3"
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${
                  trade.type === 'buy' ? 'bg-green-500/20 text-green-400' :
                  trade.type === 'sell' ? 'bg-red-500/20 text-red-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  {trade.tokenIcon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium ${
                      trade.type === 'buy' ? 'text-green-400' :
                      trade.type === 'sell' ? 'text-red-400' :
                      'text-blue-400'
                    }`}>
                      {trade.type.toUpperCase()}
                    </span>
                    <span className="text-white font-medium">{trade.token}</span>
                    <span className="text-gray-500 text-xs">{trade.platform}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {formatValue(trade.value)} • {trade.amount.toFixed(4)} {trade.token} • {formatTimeAgo(trade.timestamp)}
                    {trade.visibleTrader && <span className="ml-1">• from {trade.visibleTrader}</span>}
                  </div>
                </div>
                <a
                  href={`https://solscan.io/tx/${trade.txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-500 hover:text-cyan-400"
                >
                  <ExternalLink size={14} />
                </a>
              </motion.div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTraders.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users size={40} className="mx-auto mb-3 opacity-50" />
              <p>No traders found</p>
              <p className="text-sm mt-1">Try adjusting your filters or search</p>
            </div>
          ) : (
            filteredTraders.map((trader, index) => (
              <motion.div
                key={trader.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className={`p-4 bg-gray-900/50 border rounded-lg hover:border-cyan-500/30 transition-colors ${
                  trader.isFollowed ? 'border-cyan-500/30' : 'border-gray-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center text-2xl border border-gray-700">
                      {trader.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white">{trader.name}</span>
                        <span 
                          className="px-1.5 py-0.5 rounded text-[10px] font-medium"
                          style={{ 
                            backgroundColor: `${TRADER_TYPES[trader.type].color}20`,
                            color: TRADER_TYPES[trader.type].color
                          }}
                        >
                          {TRADER_TYPES[trader.type].icon} {TRADER_TYPES[trader.type].label}
                        </span>
                        <span 
                          className="px-1.5 py-0.5 rounded text-[10px]"
                          style={{ 
                            backgroundColor: `${(CHAIN_ICONS[trader.chain] || CHAIN_ICONS.multi).color}20`,
                            color: (CHAIN_ICONS[trader.chain] || CHAIN_ICONS.multi).color
                          }}
                        >
                          {(CHAIN_ICONS[trader.chain] || CHAIN_ICONS.multi).icon}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <button
                          onClick={() => copyAddress(trader.address)}
                          className="flex items-center gap-1 hover:text-white transition-colors"
                        >
                          {trader.shortAddress}
                          {copied === trader.address ? <Check size={10} className="text-green-400" /> : <Copy size={10} />}
                        </button>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock size={10} /> {formatTimeAgo(trader.lastActive)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div>
                      <div className={`text-sm font-bold ${trader.stats.totalPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {formatValue(trader.stats.totalPnl)}
                      </div>
                      <div className="text-[10px] text-gray-500">Total Value</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white">{trader.stats.winRate}%</div>
                      <div className="text-[10px] text-gray-500">Win Rate</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-cyan-400">{trader.stats.trades30d}</div>
                      <div className="text-[10px] text-gray-500">Transactions</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-purple-400">#{trader.stats.rank}</div>
                      <div className="text-[10px] text-gray-500">Rank</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => toggleFollow(trader.id)}
                      variant={trader.isFollowed ? 'default' : 'outline'}
                      size="sm"
                      className={trader.isFollowed ? 'bg-cyan-500 hover:bg-cyan-600' : 'border-gray-700'}
                      data-testid={`button-follow-${trader.id}`}
                    >
                      {trader.isFollowed ? (
                        <>
                          <Star size={14} className="mr-1 fill-current" /> Following
                        </>
                      ) : (
                        <>
                          <StarOff size={14} className="mr-1" /> Follow
                        </>
                      )}
                    </Button>
                    <a
                      href={`https://intel.arkm.com/explorer/address/${trader.address}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg border border-gray-700 text-gray-400 hover:text-white hover:border-gray-600"
                    >
                      <ExternalLink size={14} />
                    </a>
                  </div>
                </div>

                {trader.tags.length > 0 && (
                  <div className="flex gap-1 mt-3 flex-wrap">
                    {trader.tags.map(tag => (
                      <span key={tag} className="px-2 py-0.5 bg-gray-800 text-gray-400 rounded text-[10px]">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                {trader.recentTrades.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-800">
                    <div className="text-xs text-gray-500 mb-2">Recent Trades</div>
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {trader.recentTrades.slice(0, 3).map(trade => (
                        <div
                          key={trade.id}
                          className={`flex items-center gap-2 px-2 py-1 rounded-lg text-xs whitespace-nowrap ${
                            trade.type === 'buy' ? 'bg-green-500/10 text-green-400' :
                            trade.type === 'sell' ? 'bg-red-500/10 text-red-400' :
                            'bg-blue-500/10 text-blue-400'
                          }`}
                        >
                          <span>{trade.tokenIcon}</span>
                          <span>{trade.type.toUpperCase()}</span>
                          <span>{trade.token}</span>
                          <span className="text-gray-500">{formatValue(trade.value)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      )}

      <div className="p-3 bg-gray-900/30 border border-gray-800 rounded-lg space-y-2">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Shield size={12} />
          <span>Data aggregated from {dataSources.length > 0 ? dataSources.join(', ') : 'blockchain explorers and on-chain analytics'}.</span>
        </div>
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-gray-800">
          <span className="text-[10px] text-gray-600">Powered by:</span>
          <a href="https://blockchain.info" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-orange-500/10 text-orange-400 rounded text-[10px] hover:bg-orange-500/20 transition-colors">
            Blockchain.info
          </a>
          <a href="https://blockchair.com" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded text-[10px] hover:bg-blue-500/20 transition-colors">
            Blockchair
          </a>
          <a href="https://binance.com" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-yellow-500/10 text-yellow-400 rounded text-[10px] hover:bg-yellow-500/20 transition-colors">
            Binance
          </a>
          <a href="https://intel.arkm.com" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-purple-500/10 text-purple-400 rounded text-[10px] hover:bg-purple-500/20 transition-colors">
            Arkham Intel
          </a>
        </div>
      </div>
    </div>
  );
}
