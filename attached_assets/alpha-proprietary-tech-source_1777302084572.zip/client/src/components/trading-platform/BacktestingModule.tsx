/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha BacktestingModule™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_c25add16780f0d7748e8bce4
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play, RotateCcw, BarChart3, LineChart, ArrowUpRight, ArrowDownRight,
  Activity, Settings, TrendingUp, TrendingDown, ChevronDown, X, Eye,
  Clock, Target, Shield, Zap, Calendar, DollarSign, AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface Candle {
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  t: number;
}

interface BacktestTrade {
  id: string;
  type: 'long' | 'short';
  entryPrice: number;
  exitPrice: number;
  entryDate: string;
  exitDate: string;
  pnl: number;
  pnlPercent: number;
  holdingPeriod: number;
}

interface BacktestResult {
  id: string;
  strategyName: string;
  strategyId: string;
  pair: string;
  timeframe: string;
  startDate: string;
  endDate: string;
  initialCapital: number;
  finalCapital: number;
  totalReturn: number;
  maxDrawdown: number;
  winRate: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  totalTrades: number;
  profitableTrades: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  avgHoldingPeriod: number;
  bestTrade: number;
  worstTrade: number;
  avgTradeDuration: number;
  trades: BacktestTrade[];
  equityCurve: number[];
  drawdownCurve: number[];
}

interface StrategyParams {
  ma_crossover: { shortPeriod: number; longPeriod: number };
  rsi_reversal: { period: number; oversold: number; overbought: number };
  macd_signal: { fast: number; slow: number; signal: number };
  bollinger_bounce: { period: number; stdDev: number };
  breakout: { lookback: number; atrMultiplier: number };
}

interface RiskSettings {
  stopLoss: number;
  takeProfit: number;
  positionSize: number;
}

const STRATEGIES = [
  { id: 'ma_crossover', name: 'MA Crossover', description: 'SMA crossover signals' },
  { id: 'rsi_reversal', name: 'RSI Reversal', description: 'RSI oversold/overbought' },
  { id: 'macd_signal', name: 'MACD Signal', description: 'MACD line crossovers' },
  { id: 'bollinger_bounce', name: 'Bollinger Bounce', description: 'Mean reversion at bands' },
  { id: 'breakout', name: 'Price Breakout', description: 'Channel breakout trading' },
] as const;

const PAIRS = ['BTC/USD', 'ETH/USD', 'SOL/USD', 'DOGE/USD', 'PEPE/USD', 'ADA/USD', 'AVAX/USD', 'LINK/USD'];
const TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', '1d'];

const DEFAULT_PARAMS: StrategyParams = {
  ma_crossover: { shortPeriod: 20, longPeriod: 50 },
  rsi_reversal: { period: 14, oversold: 30, overbought: 70 },
  macd_signal: { fast: 12, slow: 26, signal: 9 },
  bollinger_bounce: { period: 20, stdDev: 2 },
  breakout: { lookback: 20, atrMultiplier: 1.5 },
};

async function fetchCandles(pair: string, timeframe: string, count: number): Promise<Candle[]> {
  let symbol = pair.replace('/', '');
  if (!symbol.endsWith('USDT')) symbol = symbol.replace(/USD$/, 'USDT');
  const response = await fetch(`/api/historical-klines?symbol=${symbol}&interval=${timeframe}&limit=${count}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch candle data: ${response.statusText}`);
  }
  const data = await response.json();
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error('No historical data returned from API');
  }
  return data;
}

function sma(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) { result.push(null); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += data[j];
    result.push(sum / period);
  }
  return result;
}

function ema(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  const k = 2 / (period + 1);
  let prev: number | null = null;
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) { result.push(null); continue; }
    if (prev === null) {
      let sum = 0;
      for (let j = i - period + 1; j <= i; j++) sum += data[j];
      prev = sum / period;
    } else {
      prev = data[i] * k + prev * (1 - k);
    }
    result.push(prev);
  }
  return result;
}

function calcRSI(closes: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  if (closes.length < period + 1) return closes.map(() => null);
  const changes: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    changes.push(closes[i] - closes[i - 1]);
  }
  result.push(null);
  let avgGain = 0, avgLoss = 0;
  for (let i = 0; i < period; i++) {
    if (changes[i] > 0) avgGain += changes[i];
    else avgLoss += -changes[i];
  }
  avgGain /= period;
  avgLoss /= period;
  for (let i = 1; i < period; i++) result.push(null);
  result.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
  for (let i = period; i < changes.length; i++) {
    const gain = changes[i] > 0 ? changes[i] : 0;
    const loss = changes[i] < 0 ? -changes[i] : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    result.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
  }
  return result;
}

function calcMACD(closes: number[], fast: number, slow: number, sig: number) {
  const fastEma = ema(closes, fast);
  const slowEma = ema(closes, slow);
  const macdLine: (number | null)[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (fastEma[i] !== null && slowEma[i] !== null) {
      macdLine.push(fastEma[i]! - slowEma[i]!);
    } else {
      macdLine.push(null);
    }
  }
  const validMacd = macdLine.filter(v => v !== null) as number[];
  const signalRaw = ema(validMacd, sig);
  const signalLine: (number | null)[] = [];
  let vi = 0;
  for (let i = 0; i < closes.length; i++) {
    if (macdLine[i] !== null) {
      signalLine.push(signalRaw[vi] ?? null);
      vi++;
    } else {
      signalLine.push(null);
    }
  }
  return { macdLine, signalLine };
}

function calcBollinger(closes: number[], period: number, mult: number) {
  const mid = sma(closes, period);
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (mid[i] === null) { upper.push(null); lower.push(null); continue; }
    let variance = 0;
    for (let j = i - period + 1; j <= i; j++) variance += (closes[j] - mid[i]!) ** 2;
    const std = Math.sqrt(variance / period);
    upper.push(mid[i]! + mult * std);
    lower.push(mid[i]! - mult * std);
  }
  return { mid, upper, lower };
}

function calcATR(candles: Candle[], period: number): (number | null)[] {
  const trs: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) { trs.push(candles[i].h - candles[i].l); continue; }
    const tr = Math.max(
      candles[i].h - candles[i].l,
      Math.abs(candles[i].h - candles[i - 1].c),
      Math.abs(candles[i].l - candles[i - 1].c)
    );
    trs.push(tr);
  }
  return sma(trs, period);
}

type StrategyId = typeof STRATEGIES[number]['id'];

function runStrategy(
  candles: Candle[],
  strategyId: StrategyId,
  params: StrategyParams,
  risk: RiskSettings,
  capital: number
): { trades: BacktestTrade[]; equityCurve: number[]; drawdownCurve: number[] } {
  const closes = candles.map(c => c.c);
  const trades: BacktestTrade[] = [];
  const equityCurve: number[] = [capital];
  let equity = capital;
  let peak = capital;
  const drawdownCurve: number[] = [0];
  let position: { type: 'long' | 'short'; entry: number; entryIdx: number } | null = null;
  let tradeCount = 0;

  const posSize = risk.positionSize / 100;
  const sl = risk.stopLoss / 100;
  const tp = risk.takeProfit / 100;

  const tryClose = (idx: number, price: number, reason?: string) => {
    if (!position) return;
    const pnlMult = position.type === 'long'
      ? (price - position.entry) / position.entry
      : (position.entry - price) / position.entry;
    const tradePnl = equity * posSize * pnlMult;
    equity += tradePnl;
    const pnlPct = pnlMult * 100;
    trades.push({
      id: `t_${tradeCount++}`,
      type: position.type,
      entryPrice: position.entry,
      exitPrice: price,
      entryDate: new Date(candles[position.entryIdx].t).toISOString().split('T')[0],
      exitDate: new Date(candles[idx].t).toISOString().split('T')[0],
      pnl: tradePnl,
      pnlPercent: pnlPct,
      holdingPeriod: idx - position.entryIdx,
    });
    position = null;
  };

  const checkStopTp = (idx: number) => {
    if (!position) return;
    const c = candles[idx];
    if (position.type === 'long') {
      if (c.l <= position.entry * (1 - sl)) { tryClose(idx, position.entry * (1 - sl)); return; }
      if (c.h >= position.entry * (1 + tp)) { tryClose(idx, position.entry * (1 + tp)); return; }
    } else {
      if (c.h >= position.entry * (1 + sl)) { tryClose(idx, position.entry * (1 + sl)); return; }
      if (c.l <= position.entry * (1 - tp)) { tryClose(idx, position.entry * (1 - tp)); return; }
    }
  };

  if (strategyId === 'ma_crossover') {
    const shortMA = sma(closes, params.ma_crossover.shortPeriod);
    const longMA = sma(closes, params.ma_crossover.longPeriod);
    for (let i = 1; i < candles.length; i++) {
      checkStopTp(i);
      if (shortMA[i] !== null && longMA[i] !== null && shortMA[i - 1] !== null && longMA[i - 1] !== null) {
        if (shortMA[i - 1]! <= longMA[i - 1]! && shortMA[i]! > longMA[i]!) {
          if (position?.type === 'short') tryClose(i, closes[i]);
          if (!position) position = { type: 'long', entry: closes[i], entryIdx: i };
        }
        if (shortMA[i - 1]! >= longMA[i - 1]! && shortMA[i]! < longMA[i]!) {
          if (position?.type === 'long') tryClose(i, closes[i]);
          if (!position) position = { type: 'short', entry: closes[i], entryIdx: i };
        }
      }
      equityCurve.push(equity);
      peak = Math.max(peak, equity);
      drawdownCurve.push(peak > 0 ? ((peak - equity) / peak) * 100 : 0);
    }
  }

  if (strategyId === 'rsi_reversal') {
    const rsi = calcRSI(closes, params.rsi_reversal.period);
    for (let i = 1; i < candles.length; i++) {
      checkStopTp(i);
      if (rsi[i] !== null && rsi[i - 1] !== null) {
        if (rsi[i - 1]! >= params.rsi_reversal.oversold && rsi[i]! < params.rsi_reversal.oversold) {
          if (position?.type === 'short') tryClose(i, closes[i]);
          if (!position) position = { type: 'long', entry: closes[i], entryIdx: i };
        }
        if (rsi[i - 1]! <= params.rsi_reversal.overbought && rsi[i]! > params.rsi_reversal.overbought) {
          if (position?.type === 'long') tryClose(i, closes[i]);
          if (!position) position = { type: 'short', entry: closes[i], entryIdx: i };
        }
      }
      equityCurve.push(equity);
      peak = Math.max(peak, equity);
      drawdownCurve.push(peak > 0 ? ((peak - equity) / peak) * 100 : 0);
    }
  }

  if (strategyId === 'macd_signal') {
    const { macdLine, signalLine } = calcMACD(closes, params.macd_signal.fast, params.macd_signal.slow, params.macd_signal.signal);
    for (let i = 1; i < candles.length; i++) {
      checkStopTp(i);
      if (macdLine[i] !== null && signalLine[i] !== null && macdLine[i - 1] !== null && signalLine[i - 1] !== null) {
        if (macdLine[i - 1]! <= signalLine[i - 1]! && macdLine[i]! > signalLine[i]!) {
          if (position?.type === 'short') tryClose(i, closes[i]);
          if (!position) position = { type: 'long', entry: closes[i], entryIdx: i };
        }
        if (macdLine[i - 1]! >= signalLine[i - 1]! && macdLine[i]! < signalLine[i]!) {
          if (position?.type === 'long') tryClose(i, closes[i]);
          if (!position) position = { type: 'short', entry: closes[i], entryIdx: i };
        }
      }
      equityCurve.push(equity);
      peak = Math.max(peak, equity);
      drawdownCurve.push(peak > 0 ? ((peak - equity) / peak) * 100 : 0);
    }
  }

  if (strategyId === 'bollinger_bounce') {
    const { upper, lower } = calcBollinger(closes, params.bollinger_bounce.period, params.bollinger_bounce.stdDev);
    for (let i = 1; i < candles.length; i++) {
      checkStopTp(i);
      if (lower[i] !== null && upper[i] !== null) {
        if (closes[i] <= lower[i]! && !position) {
          position = { type: 'long', entry: closes[i], entryIdx: i };
        }
        if (closes[i] >= upper[i]! && !position) {
          position = { type: 'short', entry: closes[i], entryIdx: i };
        }
        if (position?.type === 'long' && closes[i] >= upper[i]!) tryClose(i, closes[i]);
        if (position?.type === 'short' && closes[i] <= lower[i]!) tryClose(i, closes[i]);
      }
      equityCurve.push(equity);
      peak = Math.max(peak, equity);
      drawdownCurve.push(peak > 0 ? ((peak - equity) / peak) * 100 : 0);
    }
  }

  if (strategyId === 'breakout') {
    const lb = params.breakout.lookback;
    const atrMult = params.breakout.atrMultiplier;
    const atr = calcATR(candles, lb);
    for (let i = lb; i < candles.length; i++) {
      if (position && atr[i] !== null) {
        const atrStop = atr[i]! * atrMult;
        const c = candles[i];
        if (position.type === 'long') {
          const stopPrice = position.entry - atrStop;
          const tpPrice = position.entry + atrStop * (tp / sl);
          if (c.l <= stopPrice) { tryClose(i, stopPrice); }
          else if (c.h >= tpPrice) { tryClose(i, tpPrice); }
        } else {
          const stopPrice = position.entry + atrStop;
          const tpPrice = position.entry - atrStop * (tp / sl);
          if (c.h >= stopPrice) { tryClose(i, stopPrice); }
          else if (c.l <= tpPrice) { tryClose(i, tpPrice); }
        }
      } else {
        checkStopTp(i);
      }
      let highest = -Infinity, lowest = Infinity;
      for (let j = i - lb; j < i; j++) {
        highest = Math.max(highest, candles[j].h);
        lowest = Math.min(lowest, candles[j].l);
      }
      if (closes[i] > highest) {
        if (position?.type === 'short') tryClose(i, closes[i]);
        if (!position) position = { type: 'long', entry: closes[i], entryIdx: i };
      }
      if (closes[i] < lowest) {
        if (position?.type === 'long') tryClose(i, closes[i]);
        if (!position) position = { type: 'short', entry: closes[i], entryIdx: i };
      }
      equityCurve.push(equity);
      peak = Math.max(peak, equity);
      drawdownCurve.push(peak > 0 ? ((peak - equity) / peak) * 100 : 0);
    }
  }

  if (position) {
    tryClose(candles.length - 1, closes[candles.length - 1]);
  }

  return { trades, equityCurve, drawdownCurve };
}

function computeMetrics(trades: BacktestTrade[], equityCurve: number[], drawdownCurve: number[], capital: number): Omit<BacktestResult, 'id' | 'strategyName' | 'strategyId' | 'pair' | 'timeframe' | 'startDate' | 'endDate' | 'trades' | 'equityCurve' | 'drawdownCurve'> {
  const finalCapital = equityCurve[equityCurve.length - 1] || capital;
  const totalReturn = ((finalCapital - capital) / capital) * 100;
  const maxDrawdown = drawdownCurve.length > 0 ? Math.max(...drawdownCurve) : 0;
  const wins = trades.filter(t => t.pnl > 0);
  const losses = trades.filter(t => t.pnl <= 0);
  const winRate = trades.length > 0 ? (wins.length / trades.length) * 100 : 0;
  const avgWin = wins.length > 0 ? wins.reduce((a, t) => a + t.pnl, 0) / wins.length : 0;
  const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((a, t) => a + t.pnl, 0) / losses.length) : 0;
  const grossProfit = wins.reduce((a, t) => a + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnl, 0));
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 99.99 : 0;

  const returns: number[] = [];
  for (let i = 1; i < equityCurve.length; i++) {
    returns.push((equityCurve[i] - equityCurve[i - 1]) / equityCurve[i - 1]);
  }
  const meanReturn = returns.length > 0 ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const stdReturn = returns.length > 1 ? Math.sqrt(returns.reduce((a, r) => a + (r - meanReturn) ** 2, 0) / (returns.length - 1)) : 0;
  const sharpeRatio = stdReturn > 0 ? (meanReturn / stdReturn) * Math.sqrt(252) : 0;

  const negReturns = returns.filter(r => r < 0);
  const downDev = negReturns.length > 1 ? Math.sqrt(negReturns.reduce((a, r) => a + r ** 2, 0) / negReturns.length) : 0;
  const sortinoRatio = downDev > 0 ? (meanReturn / downDev) * Math.sqrt(252) : 0;

  const yearsInBacktest = Math.max(equityCurve.length / 252, 0.01);
  const cagr = equityCurve.length > 1 ? (Math.pow(finalCapital / capital, 1 / yearsInBacktest) - 1) : 0;
  const calmarRatio = maxDrawdown > 0 ? (cagr / (maxDrawdown / 100)) : 0;

  let maxConsWins = 0, maxConsLosses = 0, cw = 0, cl = 0;
  trades.forEach(t => {
    if (t.pnl > 0) { cw++; cl = 0; maxConsWins = Math.max(maxConsWins, cw); }
    else { cl++; cw = 0; maxConsLosses = Math.max(maxConsLosses, cl); }
  });

  const avgHoldingPeriod = trades.length > 0 ? trades.reduce((a, t) => a + t.holdingPeriod, 0) / trades.length : 0;
  const bestTrade = trades.length > 0 ? Math.max(...trades.map(t => t.pnlPercent)) : 0;
  const worstTrade = trades.length > 0 ? Math.min(...trades.map(t => t.pnlPercent)) : 0;
  const avgTradeDuration = avgHoldingPeriod;

  return {
    initialCapital: capital, finalCapital, totalReturn, maxDrawdown, winRate,
    sharpeRatio, sortinoRatio, calmarRatio, totalTrades: trades.length,
    profitableTrades: wins.length, avgWin, avgLoss, profitFactor,
    maxConsecutiveWins: maxConsWins, maxConsecutiveLosses: maxConsLosses,
    avgHoldingPeriod, bestTrade, worstTrade, avgTradeDuration,
  };
}

function EquityCurveSVG({ curve, drawdown, capital }: { curve: number[]; drawdown: number[]; capital: number }) {
  if (curve.length < 2) return null;
  const w = 700, h = 200, pad = 50, padR = 20, padB = 25;
  const minE = Math.min(...curve) * 0.98;
  const maxE = Math.max(...curve) * 1.02;
  const maxDD = Math.max(...drawdown, 1);
  const scaleX = (i: number) => pad + (i / (curve.length - 1)) * (w - pad - padR);
  const scaleY = (v: number) => padB + (1 - (v - minE) / (maxE - minE)) * (h - padB - 10);
  const scaleDDY = (v: number) => padB + (1 - v / maxDD) * (h - padB - 10);

  const ddPath = `M${scaleX(0)},${h - padB} ` +
    drawdown.map((d, i) => `L${scaleX(i)},${h - padB - (d / maxDD) * (h - padB - 10) * 0.3}`).join(' ') +
    ` L${scaleX(drawdown.length - 1)},${h - padB} Z`;

  let linePath = '';
  const segments: { path: string; color: string }[] = [];
  for (let i = 0; i < curve.length; i++) {
    const x = scaleX(i);
    const y = scaleY(curve[i]);
    if (i === 0) linePath = `M${x},${y}`;
    else linePath += ` L${x},${y}`;
  }

  const greenParts: string[] = [];
  const redParts: string[] = [];
  for (let i = 0; i < curve.length - 1; i++) {
    const seg = `M${scaleX(i)},${scaleY(curve[i])} L${scaleX(i + 1)},${scaleY(curve[i + 1])}`;
    if (curve[i] >= capital && curve[i + 1] >= capital) greenParts.push(seg);
    else if (curve[i] < capital && curve[i + 1] < capital) redParts.push(seg);
    else greenParts.push(seg);
  }

  const yTicks = 5;
  const labels = [];
  for (let i = 0; i <= yTicks; i++) {
    const val = minE + (i / yTicks) * (maxE - minE);
    labels.push({ y: scaleY(val), label: val >= 1000 ? `$${(val / 1000).toFixed(1)}k` : `$${val.toFixed(0)}` });
  }

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" preserveAspectRatio="xMidYMid meet">
      <defs>
        <linearGradient id="ddGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ff4444" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#ff4444" stopOpacity="0.05" />
        </linearGradient>
      </defs>
      {labels.map((l, i) => (
        <g key={i}>
          <line x1={pad} y1={l.y} x2={w - padR} y2={l.y} stroke="rgba(255,255,255,0.05)" strokeWidth="0.5" />
          <text x={pad - 5} y={l.y + 3} fill="#6b7280" fontSize="8" textAnchor="end">{l.label}</text>
        </g>
      ))}
      <line x1={scaleX(0)} y1={scaleY(capital)} x2={scaleX(curve.length - 1)} y2={scaleY(capital)} stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" strokeDasharray="4,4" />
      <path d={ddPath} fill="url(#ddGrad)" />
      {greenParts.length > 0 && <path d={greenParts.join(' ')} fill="none" stroke="#22c55e" strokeWidth="1.5" />}
      {redParts.length > 0 && <path d={redParts.join(' ')} fill="none" stroke="#ef4444" strokeWidth="1.5" />}
    </svg>
  );
}

function ParamSlider({ label, value, min, max, step, onChange }: {
  label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs text-gray-400 w-24 shrink-0">{label}</span>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="flex-1 h-1 accent-[#00D4FF] bg-white/10 rounded cursor-pointer"
        data-testid={`slider-${label.toLowerCase().replace(/\s/g, '-')}`}
      />
      <span className="text-xs text-white w-10 text-right font-mono">{value}</span>
    </div>
  );
}

export function BacktestingModule() {
  const [results, setResults] = useState<BacktestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedStrategyId, setSelectedStrategyId] = useState<StrategyId>('ma_crossover');
  const [selectedPair, setSelectedPair] = useState(PAIRS[0]);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState('2025-01-01');
  const [initialCapital, setInitialCapital] = useState(10000);
  const [activeResult, setActiveResult] = useState<BacktestResult | null>(null);
  const [showCompare, setShowCompare] = useState(false);
  const [params, setParams] = useState<StrategyParams>({ ...DEFAULT_PARAMS });
  const [risk, setRisk] = useState<RiskSettings>({ stopLoss: 3, takeProfit: 6, positionSize: 10 });
  const [showParams, setShowParams] = useState(false);

  const updateParam = useCallback((strategy: keyof StrategyParams, key: string, val: number) => {
    setParams(p => ({ ...p, [strategy]: { ...p[strategy], [key]: val } }));
  }, []);

  const runBacktest = useCallback(async () => {
    setIsRunning(true);
    setProgress(0);

    const progressInterval = setInterval(() => {
      setProgress(prev => prev < 90 ? prev + 3 : prev);
    }, 80);

    try {
      const candleCount = 500;
      const candles = await fetchCandles(selectedPair, selectedTimeframe, candleCount);

      clearInterval(progressInterval);
      setProgress(100);

      const { trades, equityCurve, drawdownCurve } = runStrategy(candles, selectedStrategyId, params, risk, initialCapital);
      const metrics = computeMetrics(trades, equityCurve, drawdownCurve, initialCapital);

      const stratName = STRATEGIES.find(s => s.id === selectedStrategyId)?.name || selectedStrategyId;
      const result: BacktestResult = {
        id: `bt_${Date.now()}`,
        strategyName: stratName,
        strategyId: selectedStrategyId,
        pair: selectedPair,
        timeframe: selectedTimeframe,
        startDate,
        endDate,
        ...metrics,
        trades,
        equityCurve,
        drawdownCurve,
      };

      setResults(prev => [result, ...prev]);
      setActiveResult(result);
      toast.success(`Backtest complete: ${stratName} on ${selectedPair}`);
    } catch (error) {
      clearInterval(progressInterval);
      toast.error(`Backtest failed: ${error instanceof Error ? error.message : 'Unable to fetch historical data'}`);
    } finally {
      setIsRunning(false);
    }
  }, [selectedStrategyId, selectedPair, selectedTimeframe, startDate, endDate, initialCapital, params, risk]);

  const fmt = (v: number, d = 2) => {
    if (Math.abs(v) >= 1000) return `$${(v / 1000).toFixed(1)}k`;
    return `$${v.toFixed(d)}`;
  };

  const fmtPct = (v: number) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}%`;

  const comparisonMetrics = useMemo(() => {
    if (results.length < 2) return null;
    const keys: { key: keyof BacktestResult; label: string; higher: boolean }[] = [
      { key: 'totalReturn', label: 'Total Return %', higher: true },
      { key: 'winRate', label: 'Win Rate %', higher: true },
      { key: 'sharpeRatio', label: 'Sharpe Ratio', higher: true },
      { key: 'sortinoRatio', label: 'Sortino Ratio', higher: true },
      { key: 'maxDrawdown', label: 'Max Drawdown %', higher: false },
      { key: 'profitFactor', label: 'Profit Factor', higher: true },
      { key: 'calmarRatio', label: 'Calmar Ratio', higher: true },
      { key: 'totalTrades', label: 'Total Trades', higher: true },
    ];
    return keys.map(({ key, label, higher }) => {
      const vals = results.map(r => r[key] as number);
      const bestIdx = higher ? vals.indexOf(Math.max(...vals)) : vals.indexOf(Math.min(...vals));
      return { label, vals, bestIdx };
    });
  }, [results]);

  const recentTrades = activeResult ? activeResult.trades.slice(-50) : [];

  return (
    <div className="tp-card p-4">
      <div className="flex items-center justify-between mb-4" data-testid="backtest-header">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-[#00D4FF]" />
          <h3 className="text-lg font-semibold text-white">Strategy Backtesting</h3>
          {results.length > 0 && (
            <span className="px-2 py-0.5 bg-[#00D4FF]/20 text-[#00D4FF] text-xs rounded font-mono">
              {results.length} run{results.length > 1 ? 's' : ''}
            </span>
          )}
        </div>
        {results.length >= 2 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowCompare(!showCompare)}
            className="text-gray-400 hover:text-white text-xs"
            data-testid="toggle-compare"
          >
            {showCompare ? <X className="w-3 h-3 mr-1" /> : <Activity className="w-3 h-3 mr-1" />}
            {showCompare ? 'Hide Compare' : 'Compare'}
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div className="space-y-3">
          <div>
            <label className="text-xs text-gray-400 block mb-1">Strategy</label>
            <select
              value={selectedStrategyId}
              onChange={e => setSelectedStrategyId(e.target.value as StrategyId)}
              className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
              data-testid="select-strategy"
            >
              {STRATEGIES.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1">{STRATEGIES.find(s => s.id === selectedStrategyId)?.description}</p>
          </div>

          <button
            onClick={() => setShowParams(!showParams)}
            className="flex items-center gap-1 text-xs text-[#00D4FF] hover:text-[#00D4FF]/80"
            data-testid="toggle-params"
          >
            <Settings className="w-3 h-3" />
            Strategy Parameters
            <ChevronDown className={`w-3 h-3 transition-transform ${showParams ? 'rotate-180' : ''}`} />
          </button>

          <AnimatePresence>
            {showParams && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden space-y-2"
              >
                {selectedStrategyId === 'ma_crossover' && (
                  <>
                    <ParamSlider label="Short Period" value={params.ma_crossover.shortPeriod} min={5} max={50} step={1} onChange={v => updateParam('ma_crossover', 'shortPeriod', v)} />
                    <ParamSlider label="Long Period" value={params.ma_crossover.longPeriod} min={20} max={200} step={5} onChange={v => updateParam('ma_crossover', 'longPeriod', v)} />
                  </>
                )}
                {selectedStrategyId === 'rsi_reversal' && (
                  <>
                    <ParamSlider label="RSI Period" value={params.rsi_reversal.period} min={5} max={30} step={1} onChange={v => updateParam('rsi_reversal', 'period', v)} />
                    <ParamSlider label="Oversold" value={params.rsi_reversal.oversold} min={10} max={40} step={1} onChange={v => updateParam('rsi_reversal', 'oversold', v)} />
                    <ParamSlider label="Overbought" value={params.rsi_reversal.overbought} min={60} max={90} step={1} onChange={v => updateParam('rsi_reversal', 'overbought', v)} />
                  </>
                )}
                {selectedStrategyId === 'macd_signal' && (
                  <>
                    <ParamSlider label="Fast" value={params.macd_signal.fast} min={5} max={20} step={1} onChange={v => updateParam('macd_signal', 'fast', v)} />
                    <ParamSlider label="Slow" value={params.macd_signal.slow} min={15} max={50} step={1} onChange={v => updateParam('macd_signal', 'slow', v)} />
                    <ParamSlider label="Signal" value={params.macd_signal.signal} min={3} max={15} step={1} onChange={v => updateParam('macd_signal', 'signal', v)} />
                  </>
                )}
                {selectedStrategyId === 'bollinger_bounce' && (
                  <>
                    <ParamSlider label="Period" value={params.bollinger_bounce.period} min={10} max={50} step={1} onChange={v => updateParam('bollinger_bounce', 'period', v)} />
                    <ParamSlider label="Std Dev" value={params.bollinger_bounce.stdDev} min={1} max={4} step={0.1} onChange={v => updateParam('bollinger_bounce', 'stdDev', v)} />
                  </>
                )}
                {selectedStrategyId === 'breakout' && (
                  <>
                    <ParamSlider label="Lookback" value={params.breakout.lookback} min={5} max={50} step={1} onChange={v => updateParam('breakout', 'lookback', v)} />
                    <ParamSlider label="ATR Mult" value={params.breakout.atrMultiplier} min={0.5} max={4} step={0.1} onChange={v => updateParam('breakout', 'atrMultiplier', v)} />
                  </>
                )}
                <div className="border-t border-white/5 pt-2 mt-2">
                  <span className="text-xs text-gray-500 block mb-1">Risk Management</span>
                  <ParamSlider label="Stop Loss %" value={risk.stopLoss} min={1} max={20} step={0.5} onChange={v => setRisk(r => ({ ...r, stopLoss: v }))} />
                  <ParamSlider label="Take Profit %" value={risk.takeProfit} min={1} max={50} step={0.5} onChange={v => setRisk(r => ({ ...r, takeProfit: v }))} />
                  <ParamSlider label="Position %" value={risk.positionSize} min={1} max={100} step={1} onChange={v => setRisk(r => ({ ...r, positionSize: v }))} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Pair</label>
              <select
                value={selectedPair}
                onChange={e => setSelectedPair(e.target.value)}
                className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
                data-testid="select-pair"
              >
                {PAIRS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">Timeframe</label>
              <select
                value={selectedTimeframe}
                onChange={e => setSelectedTimeframe(e.target.value)}
                className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
                data-testid="select-timeframe"
              >
                {TIMEFRAMES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Start Date</label>
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
                className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
                data-testid="input-start-date" />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">End Date</label>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
                className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
                data-testid="input-end-date" />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-400 block mb-1">Initial Capital ($)</label>
            <input type="number" value={initialCapital} onChange={e => setInitialCapital(Number(e.target.value))}
              className="w-full bg-[#0A1628] border border-white/10 rounded px-3 py-2 text-white text-sm"
              data-testid="input-capital" />
          </div>

          <Button
            onClick={runBacktest}
            disabled={isRunning}
            className="w-full bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black font-semibold"
            data-testid="button-run-backtest"
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                Running... {progress}%
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Backtest
              </>
            )}
          </Button>
          {isRunning && (
            <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
              <motion.div
                className="h-full bg-[#00D4FF]"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
          )}
        </div>

        {activeResult && (
          <div className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2" data-testid="metrics-grid">
              {[
                { label: 'Total Return', value: fmtPct(activeResult.totalReturn), color: activeResult.totalReturn >= 0 ? 'text-green-400' : 'text-red-400' },
                { label: 'Final Capital', value: fmt(activeResult.finalCapital), color: 'text-white' },
                { label: 'Win Rate', value: `${activeResult.winRate.toFixed(1)}%`, color: 'text-[#00D4FF]' },
                { label: 'Max Drawdown', value: `-${activeResult.maxDrawdown.toFixed(1)}%`, color: 'text-orange-400' },
                { label: 'Sharpe Ratio', value: activeResult.sharpeRatio.toFixed(2), color: activeResult.sharpeRatio >= 1 ? 'text-green-400' : 'text-yellow-400' },
                { label: 'Sortino Ratio', value: activeResult.sortinoRatio.toFixed(2), color: activeResult.sortinoRatio >= 1 ? 'text-green-400' : 'text-yellow-400' },
                { label: 'Profit Factor', value: activeResult.profitFactor.toFixed(2), color: activeResult.profitFactor >= 1 ? 'text-green-400' : 'text-red-400' },
                { label: 'Total Trades', value: String(activeResult.totalTrades), color: 'text-white' },
              ].map((m, i) => (
                <div key={i} className="p-3 bg-[#0A1628]/50 rounded-lg border border-white/5" data-testid={`metric-${m.label.toLowerCase().replace(/\s/g, '-')}`}>
                  <div className="text-xs text-gray-400">{m.label}</div>
                  <div className={`text-lg font-bold ${m.color}`}>{m.value}</div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#0A1628]/50 rounded-lg border border-white/5" data-testid="equity-curve">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-400">Equity Curve & Drawdown</span>
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1"><span className="w-2 h-0.5 bg-green-500 inline-block" /> Above Capital</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-0.5 bg-red-500 inline-block" /> Below Capital</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500/20 inline-block rounded" /> Drawdown</span>
                </div>
              </div>
              <EquityCurveSVG curve={activeResult.equityCurve} drawdown={activeResult.drawdownCurve} capital={activeResult.initialCapital} />
            </div>

            <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-xs">
              {[
                { label: 'Calmar', value: activeResult.calmarRatio.toFixed(2) },
                { label: 'Consec Wins', value: String(activeResult.maxConsecutiveWins) },
                { label: 'Consec Losses', value: String(activeResult.maxConsecutiveLosses) },
                { label: 'Avg Hold', value: `${activeResult.avgHoldingPeriod.toFixed(0)} bars` },
                { label: 'Best Trade', value: fmtPct(activeResult.bestTrade) },
                { label: 'Worst Trade', value: fmtPct(activeResult.worstTrade) },
              ].map((m, i) => (
                <div key={i} className="p-2 bg-[#0A1628]/30 rounded text-center">
                  <div className="text-gray-500">{m.label}</div>
                  <div className="text-white font-mono mt-0.5">{m.value}</div>
                </div>
              ))}
            </div>

            {recentTrades.length > 0 && (
              <div className="bg-[#0A1628]/50 rounded-lg border border-white/5 overflow-hidden" data-testid="trade-log">
                <div className="p-3 border-b border-white/5">
                  <span className="text-xs text-gray-400">Trade Log ({recentTrades.length} of {activeResult.totalTrades})</span>
                </div>
                <div className="max-h-60 overflow-y-auto">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-[#0D1117]">
                      <tr className="text-gray-500 border-b border-white/5">
                        <th className="p-2 text-left">#</th>
                        <th className="p-2 text-left">Type</th>
                        <th className="p-2 text-right">Entry</th>
                        <th className="p-2 text-right">Exit</th>
                        <th className="p-2 text-right">P&L ($)</th>
                        <th className="p-2 text-right">P&L (%)</th>
                        <th className="p-2 text-right">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentTrades.map((trade, idx) => (
                        <tr
                          key={trade.id}
                          className={`border-b border-white/5 ${trade.pnl >= 0 ? 'bg-green-500/5' : 'bg-red-500/5'}`}
                          data-testid={`trade-row-${idx}`}
                        >
                          <td className="p-2 text-gray-400">{idx + 1}</td>
                          <td className="p-2">
                            <span className={`flex items-center gap-1 ${trade.type === 'long' ? 'text-green-400' : 'text-red-400'}`}>
                              {trade.type === 'long' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                              {trade.type === 'long' ? 'Long' : 'Short'}
                            </span>
                          </td>
                          <td className="p-2 text-right text-white font-mono">
                            {trade.entryPrice < 1 ? trade.entryPrice.toPrecision(4) : trade.entryPrice.toFixed(2)}
                          </td>
                          <td className="p-2 text-right text-white font-mono">
                            {trade.exitPrice < 1 ? trade.exitPrice.toPrecision(4) : trade.exitPrice.toFixed(2)}
                          </td>
                          <td className={`p-2 text-right font-mono ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}
                          </td>
                          <td className={`p-2 text-right font-mono ${trade.pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {fmtPct(trade.pnlPercent)}
                          </td>
                          <td className="p-2 text-right text-gray-400">{trade.entryDate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {!activeResult && (
          <div className="lg:col-span-2 flex items-center justify-center py-16">
            <div className="text-center">
              <LineChart className="w-12 h-12 text-gray-600 mx-auto mb-3" />
              <p className="text-gray-400 mb-1">Configure & Run a Backtest</p>
              <p className="text-xs text-gray-500">Select a strategy, adjust parameters, and click Run</p>
            </div>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <div className="border-t border-white/5 pt-4">
          <div className="text-xs text-gray-400 mb-2">Previous Backtests</div>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {results.map(result => (
              <button
                key={result.id}
                onClick={() => setActiveResult(result)}
                className={`w-full flex items-center justify-between p-2 rounded text-sm transition-colors ${activeResult?.id === result.id ? 'bg-[#00D4FF]/10 border border-[#00D4FF]/30' : 'hover:bg-white/5'}`}
                data-testid={`result-${result.id}`}
              >
                <span className="text-gray-400">{result.strategyName} • {result.pair} • {result.timeframe}</span>
                <span className={result.totalReturn >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {fmtPct(result.totalReturn)}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      <AnimatePresence>
        {showCompare && results.length >= 2 && comparisonMetrics && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-white/5 pt-4 mt-4"
            data-testid="comparison-view"
          >
            <div className="text-xs text-gray-400 mb-3">Strategy Comparison</div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="p-2 text-left text-gray-400">Metric</th>
                    {results.map((r, i) => (
                      <th key={r.id} className="p-2 text-center text-gray-300">{r.strategyName}<br /><span className="text-gray-500 font-normal">{r.pair}</span></th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonMetrics.map((row, ri) => (
                    <tr key={ri} className="border-b border-white/5">
                      <td className="p-2 text-gray-400">{row.label}</td>
                      {row.vals.map((val, vi) => (
                        <td key={vi} className={`p-2 text-center font-mono ${vi === row.bestIdx ? 'text-[#FFD700] font-bold' : 'text-white'}`}>
                          {typeof val === 'number' ? val.toFixed(2) : val}
                          {vi === row.bestIdx && <span className="ml-1 text-[#FFD700]">★</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
