/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PortfolioTracker™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_50e4c1977e10c203cd96fe1a
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  PieChart, TrendingUp, TrendingDown, BarChart3, Wallet, RefreshCw,
  ArrowUpRight, ArrowDownRight, DollarSign, Percent, Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PortfolioAsset {
  symbol: string;
  name: string;
  amount: number;
  avgPrice: number;
  currentPrice: number;
  value: number;
  pnl: number;
  pnlPercent: number;
  allocation: number;
  color: string;
}

interface PerformanceMetric {
  label: string;
  value: string;
  change?: number;
  icon: React.ReactNode;
}

const EMPTY_PORTFOLIO: PortfolioAsset[] = [];

export function PortfolioTracker() {
  const [portfolio, setPortfolio] = useState<PortfolioAsset[]>(EMPTY_PORTFOLIO);
  const [isLoading, setIsLoading] = useState(false);
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | 'all'>('30d');

  const totalValue = portfolio.reduce((sum, a) => sum + a.value, 0);
  const totalPnl = portfolio.reduce((sum, a) => sum + a.pnl, 0);
  const totalPnlPercent = (totalPnl / (totalValue - totalPnl)) * 100;
  const totalCost = portfolio.reduce((sum, a) => sum + (a.amount * a.avgPrice), 0);

  const metrics: PerformanceMetric[] = [
    { label: 'Total Value', value: `$${totalValue.toLocaleString()}`, icon: <Wallet size={16} className="text-cyan-400" /> },
    { label: 'Total P&L', value: `$${totalPnl >= 0 ? '+' : ''}${totalPnl.toLocaleString()}`, change: totalPnlPercent, icon: totalPnl >= 0 ? <TrendingUp size={16} className="text-green-400" /> : <TrendingDown size={16} className="text-red-400" /> },
    { label: 'Win Rate', value: '72%', icon: <Target size={16} className="text-purple-400" /> },
    { label: 'Sharpe Ratio', value: '2.45', icon: <BarChart3 size={16} className="text-yellow-400" /> },
  ];

  const refreshPrices = async () => {
    if (portfolio.length === 0) return;
    setIsLoading(true);
    try {
      const updatedPortfolio = await Promise.all(
        portfolio.map(async (asset) => {
          try {
            const symbol = asset.symbol === 'USDT' ? null : `${asset.symbol}USDT`;
            if (!symbol) return { ...asset, currentPrice: 1, value: asset.amount, pnl: asset.amount - (asset.amount * asset.avgPrice), pnlPercent: ((1 - asset.avgPrice) / asset.avgPrice) * 100 };
            const res = await fetch(`/api/trading/ticker/${symbol}`);
            if (!res.ok) return asset;
            const data = await res.json();
            const newPrice = typeof data.price === 'string' ? parseFloat(data.price) : data.price;
            const newValue = asset.amount * newPrice;
            const newPnl = newValue - (asset.amount * asset.avgPrice);
            const newPnlPercent = ((newPrice - asset.avgPrice) / asset.avgPrice) * 100;
            return { ...asset, currentPrice: newPrice, value: newValue, pnl: newPnl, pnlPercent: newPnlPercent };
          } catch {
            return asset;
          }
        })
      );
      setPortfolio(updatedPortfolio);
    } catch {
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const interval = setInterval(refreshPrices, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-4" data-testid="portfolio-tracker">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PieChart className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Portfolio Analytics</h2>
            <p className="text-xs text-gray-500">Track performance across all connected accounts</p>
          </div>
        </div>
        <Button
          onClick={refreshPrices}
          variant="outline"
          size="sm"
          disabled={isLoading}
          className="border-gray-700"
        >
          <RefreshCw size={14} className={`mr-1 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {metrics.map((metric, i) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg"
          >
            <div className="flex items-center gap-2 mb-2">
              {metric.icon}
              <span className="text-xs text-gray-500">{metric.label}</span>
            </div>
            <div className="text-xl font-bold text-white">{metric.value}</div>
            {metric.change !== undefined && (
              <div className={`text-xs flex items-center gap-1 ${metric.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {metric.change >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                {metric.change >= 0 ? '+' : ''}{metric.change.toFixed(2)}%
              </div>
            )}
          </motion.div>
        ))}
      </div>

      <div className="flex gap-1 mb-2">
        {(['24h', '7d', '30d', 'all'] as const).map(tf => (
          <button
            key={tf}
            onClick={() => setTimeframe(tf)}
            className={`px-3 py-1 rounded text-xs ${
              timeframe === tf ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-400'
            }`}
          >
            {tf === 'all' ? 'All Time' : tf.toUpperCase()}
          </button>
        ))}
      </div>

      {portfolio.length === 0 ? (
        <div className="text-center py-12 bg-gray-900/50 rounded-lg border border-gray-800">
          <Wallet size={48} className="mx-auto text-gray-600 mb-4" />
          <h3 className="text-lg font-medium text-gray-400 mb-2">No Portfolio Data</h3>
          <p className="text-sm text-gray-500">Connect a wallet or exchange to track your holdings</p>
        </div>
      ) : (
      <div className="grid md:grid-cols-3 gap-4">
        <div className="md:col-span-2 bg-gray-900/50 border border-gray-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-white mb-3">Holdings</h3>
          <div className="space-y-2">
            {portfolio.map((asset, i) => (
              <motion.div
                key={asset.symbol}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center gap-3 p-2 hover:bg-gray-800/50 rounded transition-colors"
              >
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                  style={{ backgroundColor: asset.color + '30', color: asset.color }}
                >
                  {asset.symbol.slice(0, 2)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-white">{asset.symbol}</span>
                    <span className="text-xs text-gray-500">{asset.name}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {asset.amount.toLocaleString()} @ ${asset.avgPrice.toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-white">${asset.value.toLocaleString()}</div>
                  <div className={`text-xs flex items-center justify-end gap-1 ${asset.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {asset.pnl >= 0 ? '+' : ''}${asset.pnl.toLocaleString()} ({asset.pnlPercent.toFixed(1)}%)
                  </div>
                </div>
                <div className="w-16 text-right">
                  <div className="text-xs text-gray-400">{asset.allocation}%</div>
                  <div className="w-full h-1.5 bg-gray-800 rounded-full mt-1">
                    <div 
                      className="h-full rounded-full" 
                      style={{ width: `${asset.allocation}%`, backgroundColor: asset.color }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
            <h3 className="text-sm font-medium text-white mb-3">Allocation</h3>
            <div className="relative w-32 h-32 mx-auto">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                {portfolio.reduce((acc, asset, i) => {
                  const startAngle = acc.offset;
                  const angle = (asset.allocation / 100) * 360;
                  const x1 = 50 + 40 * Math.cos((startAngle * Math.PI) / 180);
                  const y1 = 50 + 40 * Math.sin((startAngle * Math.PI) / 180);
                  const x2 = 50 + 40 * Math.cos(((startAngle + angle) * Math.PI) / 180);
                  const y2 = 50 + 40 * Math.sin(((startAngle + angle) * Math.PI) / 180);
                  const largeArc = angle > 180 ? 1 : 0;
                  acc.paths.push(
                    <path
                      key={asset.symbol}
                      d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArc} 1 ${x2} ${y2} Z`}
                      fill={asset.color}
                      opacity={0.8}
                    />
                  );
                  acc.offset += angle;
                  return acc;
                }, { offset: 0, paths: [] as React.ReactNode[] }).paths}
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">${(totalValue / 1000).toFixed(1)}K</div>
                  <div className="text-[10px] text-gray-500">Total</div>
                </div>
              </div>
            </div>
            <div className="mt-4 space-y-1">
              {portfolio.slice(0, 4).map(asset => (
                <div key={asset.symbol} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: asset.color }} />
                    <span className="text-gray-400">{asset.symbol}</span>
                  </div>
                  <span className="text-white">{asset.allocation}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
            <h3 className="text-sm font-medium text-white mb-3">Statistics</h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-500">Total Cost Basis</span>
                <span className="text-white">${totalCost.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Unrealized P&L</span>
                <span className={totalPnl >= 0 ? 'text-green-400' : 'text-red-400'}>
                  ${totalPnl >= 0 ? '+' : ''}{totalPnl.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Best Performer</span>
                <span className="text-green-400">SOL +67.1%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Worst Performer</span>
                <span className="text-gray-400">USDT 0%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
}

