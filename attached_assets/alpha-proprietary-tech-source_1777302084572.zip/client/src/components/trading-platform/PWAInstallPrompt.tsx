/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PWAInstallPrompt™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_53c684f499d4413f1aed21c2
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, Smartphone, Check } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);

  useEffect(() => {
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIOSDevice);

    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                         (window.navigator as any).standalone === true;
    
    if (isStandalone) {
      setIsInstalled(true);
      return;
    }

    const dismissed = localStorage.getItem('pwa-prompt-dismissed');
    if (dismissed) {
      const dismissedTime = parseInt(dismissed);
      if (Date.now() - dismissedTime < 7 * 24 * 60 * 60 * 1000) {
        return;
      }
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Don't auto-show PWA prompt - only show when user explicitly requests
    };

    window.addEventListener('beforeinstallprompt', handler);

    // Don't auto-show iOS install prompt - only show when user explicitly requests

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstall = async () => {
    if (isIOS) {
      setShowIOSInstructions(true);
      return;
    }

    if (!deferredPrompt) return;

    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setIsInstalled(true);
    }
    
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setShowIOSInstructions(false);
    localStorage.setItem('pwa-prompt-dismissed', Date.now().toString());
  };

  if (isInstalled || (!showPrompt && !showIOSInstructions)) return null;

  return (
    <AnimatePresence>
      {showIOSInstructions ? (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:w-96"
          data-testid="pwa-ios-instructions"
        >
          <div className="bg-[#0A1628] border border-[#00D4FF]/30 rounded-xl p-4 shadow-2xl shadow-[#00D4FF]/10">
            <button
              onClick={handleDismiss}
              className="absolute top-3 right-3 text-gray-400 hover:text-white transition-colors"
              data-testid="button-dismiss-ios"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-[#00D4FF]/20 rounded-full flex items-center justify-center mx-auto">
                <Smartphone className="w-6 h-6 text-[#00D4FF]" />
              </div>
              
              <h3 className="text-white font-semibold text-lg">Install on iOS</h3>
              
              <div className="text-left space-y-2 text-sm text-gray-300">
                <div className="flex items-start gap-2">
                  <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">1</span>
                  <span>Tap the <span className="text-[#00D4FF]">Share</span> button at the bottom of your browser</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">2</span>
                  <span>Scroll down and tap <span className="text-[#00D4FF]">"Add to Home Screen"</span></span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">3</span>
                  <span>Tap <span className="text-[#00D4FF]">"Add"</span> in the top right corner</span>
                </div>
              </div>
              
              <button
                onClick={handleDismiss}
                className="w-full py-2 bg-[#00D4FF]/20 text-[#00D4FF] rounded-lg hover:bg-[#00D4FF]/30 transition-colors text-sm font-medium"
                data-testid="button-got-it"
              >
                Got it!
              </button>
            </div>
          </div>
        </motion.div>
      ) : showPrompt && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:w-96"
          data-testid="pwa-install-prompt"
        >
          <div className="bg-[#0A1628] border border-[#00D4FF]/30 rounded-xl p-4 shadow-2xl shadow-[#00D4FF]/10">
            <button
              onClick={handleDismiss}
              className="absolute top-3 right-3 text-gray-400 hover:text-white transition-colors"
              data-testid="button-dismiss-prompt"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-[#00D4FF] to-[#0066FF] rounded-xl flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-lg font-['Orbitron']">AU</span>
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-semibold text-lg mb-1">Install Alpha Trading</h3>
                <p className="text-gray-400 text-sm mb-3">
                  Get the full trading experience with offline access and instant launch
                </p>
                
                <div className="flex gap-2">
                  <button
                    onClick={handleInstall}
                    className="flex items-center gap-2 px-4 py-2 bg-[#00D4FF] text-[#0A1628] rounded-lg font-medium text-sm hover:bg-[#00D4FF]/90 transition-colors"
                    data-testid="button-install-app"
                  >
                    <Download className="w-4 h-4" />
                    Install
                  </button>
                  <button
                    onClick={handleDismiss}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors text-sm"
                    data-testid="button-not-now"
                  >
                    Not now
                  </button>
                </div>
              </div>
            </div>
            
            <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-gray-500">
              <Check className="w-3.5 h-3.5 text-green-400" />
              <span>Free, no app store required</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
