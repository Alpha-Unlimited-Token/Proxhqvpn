/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Digital Asset Recovery Dossier™ — Forensic Evidence Report Generator
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * AUT_ModuleHash: AUT_c3d7e92a15f8b4601234cdef
 * ALPHA_INTEGRITY_SEAL: RECOVERY_DOSSIER_v1.0_PROTECTED
 * Calibration: DOSSIER_ENGINE_SEALED
 */

import { useRef } from "react";
import TransactionFlowGraph, { type TxFlowNode, type TxFlowEdge } from "./TransactionFlowGraph";

interface WalletEntry {
  address: string;
  label: string;
  role: string;
  chain: string;
  amount?: string;
  token?: string;
}

interface ExchangeTarget {
  exchange: string;
  walletAddress: string;
  walletLabel: string;
  direction: string;
  amount: string;
  token: string;
  txHash: string;
}

interface RecoveryDossierProps {
  caseName: string;
  caseId: string;
  victimHandle: string;
  victimAddress: string;
  totalStolen: string;
  totalStolenUSD: string;
  theftDate: string;
  blockchain: string;
  description: string;
  wallets: WalletEntry[];
  exchangeTargets: ExchangeTarget[];
  flowNodes: TxFlowNode[];
  flowEdges: TxFlowEdge[];
  scanSummary: {
    walletsScanned: number;
    walletsWithFindings: number;
    tornadoCashInteractions: number;
    exchangeInteractions: number;
    relayerInteractions: number;
    riskAssessment: string;
    poolsScanned: number;
    depositsAnalyzed: number;
    withdrawalsAnalyzed: number;
  };
}

export default function RecoveryDossier({
  caseName, caseId, victimHandle, victimAddress, totalStolen, totalStolenUSD,
  theftDate, blockchain, description, wallets, exchangeTargets, flowNodes,
  flowEdges, scanSummary,
}: RecoveryDossierProps) {
  const reportRef = useRef<HTMLDivElement>(null);

  const caseRef = `AUT-FIE-${caseId.slice(0, 8).toUpperCase()}`;
  const generatedDate = new Date().toISOString().replace("T", " ").slice(0, 19);

  const uniqueExchanges = [...new Set(exchangeTargets.map(t => t.exchange))];
  const sourceWallets = wallets.filter(w => ["source", "victim", "attacker"].includes(w.role));
  const launderingWallets = wallets.filter(w => ["laundering", "laundering_hub"].includes(w.role));
  const splitWallets = wallets.filter(w => w.role === "split_wallet");
  const destinationWallets = wallets.filter(w => ["destination", "fund_destination"].includes(w.role));
  const arbReceivers = wallets.filter(w => ["arb_receiver", "Arb Receiver"].includes(w.role));
  const daiRecipients = wallets.filter(w => ["dai_recipient", "DAI Recipient", "dai_dispersal", "DAI Dispersal"].includes(w.role));
  const poiWallets = wallets.filter(w => ["poi", "person_of_interest"].includes(w.role));
  const gasWallets = wallets.filter(w => ["gas_funder"].includes(w.role));
  const originalFunders = wallets.filter(w => ["original_funder"].includes(w.role));
  const finalDest = wallets.filter(w => ["final_destination"].includes(w.role));

  const handlePrint = () => {
    window.print();
  };

  return (
    <div data-testid="recovery-dossier" className="space-y-0">
      <div className="flex items-center justify-between mb-4 print:hidden">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          <h2 className="text-lg font-bold tracking-wider" style={{ color: "#d4a843", fontFamily: "'Orbitron', sans-serif" }}>
            ALPHA DIGITAL ASSET RECOVERY DOSSIER&trade;
          </h2>
        </div>
        <button
          data-testid="button-print-dossier"
          onClick={handlePrint}
          className="px-4 py-2 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-700/40 rounded-lg text-amber-400 text-sm font-medium"
        >
          Print / Export PDF
        </button>
      </div>

      <div ref={reportRef} className="bg-[#0c0e14] border border-[#1a1d28] rounded-xl overflow-hidden shadow-2xl">
        <div className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1a0e2d 0%, #0d0a1a 40%, #0a0e14 100%)" }}>
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d4a843' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
          <div className="relative px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-900/30">
                  <span className="text-white font-bold text-lg" style={{ fontFamily: "'Orbitron', sans-serif" }}>A</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold tracking-widest" style={{ color: "#d4a843", fontFamily: "'Orbitron', sans-serif" }}>
                    DIGITAL ASSET RECOVERY DOSSIER
                  </h1>
                  <div className="text-xs text-gray-400 mt-1 tracking-wider">
                    For Exchange Compliance Investigation &amp; Emergency Asset Freeze Request
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-amber-600/60 tracking-wider">ALPHA UNLIMITED TRADING</div>
                <div className="text-[10px] text-gray-500">Forensic Intelligence Engine&trade;</div>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-6 text-[11px]">
              <div><span className="text-gray-500">Case Ref:</span> <span className="text-amber-400 font-mono font-bold">{caseRef}</span></div>
              <div><span className="text-gray-500">Generated:</span> <span className="text-gray-300">{generatedDate}</span></div>
              <div><span className="text-gray-500">Blockchain:</span> <span className="text-gray-300">{blockchain}</span></div>
              <div><span className="text-gray-500">Classification:</span> <span className="text-red-400 font-bold">CONFIDENTIAL — LAW ENFORCEMENT SENSITIVE</span></div>
            </div>
          </div>
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            INCIDENT SUMMARY
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-12 gap-y-3">
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Victim / Handle</div>
              <div className="text-sm text-gray-200 font-medium">{victimHandle}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Theft Date</div>
              <div className="text-sm text-gray-200">{theftDate}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Total Stolen</div>
              <div className="text-sm text-red-400 font-bold">{totalStolen}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Est. USD Value</div>
              <div className="text-sm text-red-400 font-bold">{totalStolenUSD}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Addresses Traced</div>
              <div className="text-sm text-gray-200">{scanSummary.walletsScanned}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Addresses w/ Findings</div>
              <div className="text-sm text-amber-400 font-bold">{scanSummary.walletsWithFindings}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Exchanges Identified</div>
              <div className="text-sm text-yellow-400 font-bold">{uniqueExchanges.length}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Risk Assessment</div>
              <div className="text-sm text-red-400 font-bold">{scanSummary.riskAssessment}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">TC Pools Scanned</div>
              <div className="text-sm text-gray-200">{scanSummary.poolsScanned}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">TC Deposits Analyzed</div>
              <div className="text-sm text-gray-200">{scanSummary.depositsAnalyzed}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">TC Withdrawals Analyzed</div>
              <div className="text-sm text-gray-200">{scanSummary.withdrawalsAnalyzed}</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Privacy Protocol Use</div>
              <div className="text-sm text-green-400 font-bold">{scanSummary.tornadoCashInteractions === 0 ? "NONE DETECTED" : `${scanSummary.tornadoCashInteractions} interactions`}</div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-[#0a0c12] rounded-lg border border-gray-800/30">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Case Description</div>
            <div className="text-sm text-gray-300">{description}</div>
          </div>
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            BLOCKCHAIN EVIDENCE TRAIL — COMPLETE FUND FLOW
          </h2>

          {sourceWallets.length > 0 && (
            <WalletSection title="ORIGIN — Victim & Source Wallets" color="red" wallets={sourceWallets} />
          )}
          {launderingWallets.length > 0 && (
            <WalletSection title="LAUNDERING HUB" color="pink" wallets={launderingWallets} />
          )}
          {gasWallets.length > 0 && (
            <WalletSection title="GAS FUNDING WALLET" color="yellow" wallets={gasWallets} />
          )}
          {originalFunders.length > 0 && (
            <WalletSection title="ORIGINAL FUNDER (Wallet Factory)" color="orange" wallets={originalFunders} />
          )}
          {poiWallets.length > 0 && (
            <WalletSection title="PERSON OF INTEREST" color="rose" wallets={poiWallets} />
          )}
          {splitWallets.length > 0 && (
            <WalletSection title={`SPLIT WALLETS (${splitWallets.length} addresses)`} color="violet" wallets={splitWallets} />
          )}
          {daiRecipients.length > 0 && (
            <WalletSection title={`DAI DISPERSAL RECIPIENTS (${daiRecipients.length})`} color="sky" wallets={daiRecipients} />
          )}
          {destinationWallets.length > 0 && (
            <WalletSection title={`FUND DESTINATIONS (${destinationWallets.length} addresses)`} color="green" wallets={destinationWallets} />
          )}
          {arbReceivers.length > 0 && (
            <WalletSection title={`ARBITRUM RECEIVERS (${arbReceivers.length})`} color="indigo" wallets={arbReceivers} />
          )}
          {finalDest.length > 0 && (
            <WalletSection title="FINAL DESTINATION" color="amber" wallets={finalDest} />
          )}
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            TRANSACTION FLOW VISUALIZATION
          </h2>
          <TransactionFlowGraph
            nodes={flowNodes}
            edges={flowEdges}
            title={caseName}
            caseId={caseId}
          />
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            EXCHANGE DEPOSIT EVIDENCE — PRIORITY SUBPOENA TARGETS ({uniqueExchanges.length} Exchanges)
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
            {uniqueExchanges.map(ex => {
              const count = exchangeTargets.filter(t => t.exchange === ex).length;
              return (
                <div key={ex} className="bg-[#161b22] rounded-lg border border-yellow-900/30 p-3">
                  <div className="text-xs text-yellow-400 font-bold">{ex}</div>
                  <div className="text-lg text-yellow-300 font-bold">{count}</div>
                  <div className="text-[10px] text-gray-500">transaction(s) detected</div>
                </div>
              );
            })}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">#</th>
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">Exchange</th>
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">Source Wallet</th>
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">Direction</th>
                  <th className="text-right py-2 px-2 text-gray-500 font-medium">Amount</th>
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">Token</th>
                  <th className="text-left py-2 px-2 text-gray-500 font-medium">Transaction Hash</th>
                </tr>
              </thead>
              <tbody>
                {exchangeTargets.map((t, i) => (
                  <tr key={i} className="border-b border-gray-800/30 hover:bg-[#161b22]">
                    <td className="py-1.5 px-2 text-gray-600">{i + 1}</td>
                    <td className="py-1.5 px-2 text-yellow-400 font-medium">{t.exchange}</td>
                    <td className="py-1.5 px-2 font-mono text-gray-300" title={t.walletAddress}>
                      {t.walletAddress.slice(0, 10)}...{t.walletAddress.slice(-6)}
                    </td>
                    <td className="py-1.5 px-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                        t.direction.includes("deposit") ? "bg-red-900/30 text-red-400" : "bg-green-900/30 text-green-400"
                      }`}>
                        {t.direction.includes("deposit") ? "DEPOSIT \u2192" : "\u2190 WITHDRAWAL"}
                      </span>
                    </td>
                    <td className="py-1.5 px-2 text-right text-gray-200 font-mono">{t.amount}</td>
                    <td className="py-1.5 px-2 text-gray-400">{t.token}</td>
                    <td className="py-1.5 px-2 font-mono text-blue-400 text-[10px]" title={t.txHash}>
                      {t.txHash ? `${t.txHash.slice(0, 14)}...` : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            RECOMMENDED INVESTIGATIVE ACTIONS
          </h2>

          <div className="space-y-3">
            {uniqueExchanges.filter(ex => exchangeTargets.some(t => t.exchange === ex && t.direction.includes("deposit"))).map((ex, i) => {
              const deposits = exchangeTargets.filter(t => t.exchange === ex && t.direction.includes("deposit"));
              const sourceAddrs = [...new Set(deposits.map(d => d.walletAddress))];
              return (
                <div key={ex} className="bg-[#161b22] rounded-lg border border-red-900/20 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-6 h-6 rounded-full bg-red-600 text-white text-xs flex items-center justify-center font-bold">{i + 1}</span>
                    <span className="text-sm text-red-400 font-bold">PRIORITY SUBPOENA: {ex}</span>
                  </div>
                  <div className="text-xs text-gray-400 ml-8">
                    Request KYC records, IP login history, device fingerprints, and complete transaction ledger for deposits from:
                  </div>
                  <div className="ml-8 mt-2 space-y-1">
                    {sourceAddrs.map(addr => (
                      <div key={addr} className="flex items-center gap-2">
                        <span className="text-[10px] text-red-500">\u25CF</span>
                        <span className="text-[11px] font-mono text-gray-300">{addr}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="px-8 py-6 border-t border-[#1a1d28]">
          <h2 className="text-sm font-bold text-amber-400 tracking-wider mb-4 pb-2 border-b border-amber-900/30" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            PRIVACY PROTOCOL ANALYSIS
          </h2>

          <div className="bg-[#161b22] rounded-lg border border-green-900/20 p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-green-600/20 flex items-center justify-center">
                <span className="text-green-400 text-sm">\u2713</span>
              </div>
              <div>
                <div className="text-sm text-green-400 font-bold">NO TORNADO CASH OR MIXER USAGE DETECTED</div>
                <div className="text-xs text-gray-500">All {scanSummary.poolsScanned} Tornado Cash pools scanned. {scanSummary.depositsAnalyzed} deposits and {scanSummary.withdrawalsAnalyzed} withdrawals analyzed. Zero matches to case wallets.</div>
              </div>
            </div>
            <div className="text-xs text-gray-400 bg-[#0a0c12] rounded p-3 border border-gray-800/30">
              <strong className="text-green-400">Assessment:</strong> The attacker did not use privacy-preserving protocols (Tornado Cash, mixers, or relayers). 
              Stolen funds were moved directly through intermediary wallets to centralized exchange deposit addresses. 
              This is favorable for recovery — KYC identity of the depositor is retrievable via standard exchange compliance subpoena.
            </div>
          </div>
        </div>

        <div className="px-8 py-4 border-t border-[#1a1d28] bg-[#0a0c12]">
          <div className="flex items-center justify-between">
            <div className="text-[9px] text-gray-600 tracking-wider" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              ALPHA UNLIMITED TRADING &middot; FORENSIC INTELLIGENCE ENGINE&trade; &middot; CONFIDENTIAL
            </div>
            <div className="text-[9px] text-gray-600">
              Report generated {generatedDate} &middot; Case {caseRef}
            </div>
          </div>
          <div className="text-[8px] text-gray-700 mt-1">
            This report contains blockchain evidence gathered through automated on-chain analysis. All transaction hashes and addresses are verifiable on public block explorers.
            This document is intended for use by law enforcement, exchange compliance departments, and authorized legal representatives only.
          </div>
        </div>
      </div>
    </div>
  );
}

function WalletSection({ title, color, wallets }: { title: string; color: string; wallets: WalletEntry[] }) {
  const colorMap: Record<string, { border: string; text: string; dot: string }> = {
    red: { border: "border-red-900/30", text: "text-red-400", dot: "bg-red-500" },
    pink: { border: "border-pink-900/30", text: "text-pink-400", dot: "bg-pink-500" },
    yellow: { border: "border-yellow-900/30", text: "text-yellow-400", dot: "bg-yellow-500" },
    orange: { border: "border-orange-900/30", text: "text-orange-400", dot: "bg-orange-500" },
    rose: { border: "border-rose-900/30", text: "text-rose-400", dot: "bg-rose-500" },
    violet: { border: "border-violet-900/30", text: "text-violet-400", dot: "bg-violet-500" },
    sky: { border: "border-sky-900/30", text: "text-sky-400", dot: "bg-sky-500" },
    green: { border: "border-green-900/30", text: "text-green-400", dot: "bg-green-500" },
    indigo: { border: "border-indigo-900/30", text: "text-indigo-400", dot: "bg-indigo-500" },
    amber: { border: "border-amber-900/30", text: "text-amber-400", dot: "bg-amber-500" },
  };
  const c = colorMap[color] || colorMap.red;

  return (
    <div className={`mb-4 bg-[#0a0c12] rounded-lg border ${c.border} p-4`}>
      <h3 className={`text-xs font-bold ${c.text} tracking-wider mb-2`}>{title}</h3>
      <div className="space-y-1">
        {wallets.map((w, i) => (
          <div key={i} className="flex items-center gap-3 py-1">
            <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
            <span className="text-[11px] font-mono text-gray-300 min-w-[340px]">{w.address}</span>
            <span className="text-[11px] text-gray-500">{w.label}</span>
            {w.amount && <span className={`text-[11px] font-mono ${c.text} ml-auto`}>{w.amount} {w.token || ""}</span>}
            <span className="text-[10px] text-gray-600 uppercase">{w.chain}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
