/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha ChartDrawingToolbar™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_371d2b4793959224c2a6da0e
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import {
  MousePointer, Minus, MoveVertical, TrendingUp, TrendingDown,
  Layers, Target, Percent, Square, ArrowUp, ArrowDown, ArrowLeft, ArrowRight,
  Ruler, Circle, Type, Plus, Trash2, Lock, Unlock, Eye, EyeOff,
  Pencil, Highlighter, Triangle, Hexagon, PenTool, Move,
  LineChart as LineIcon, Hash, BarChart3, Activity, GitBranch,
  Crosshair, MapPin, MessageSquare, Flag, Table2, Tag,
  Bookmark, Clock, Waves, Diamond, Maximize2, ScanLine, Grip,
  ChevronRight, Star, Magnet
} from 'lucide-react';

export type DrawingToolType = 'select' | 'eraser' | 'hline' | 'vline' | 'trendline' | 'uptrend' | 'downtrend' | 'channel' | 'ray' | 'marker' | 'text' | 'fibRetracement' | 'rectangle' | 'arrow' | 'measure' | 'buyDot' | 'sellDot' | 'signalDot' | 'pitchfork' | 'fibExtension' | 'circle' | 'ellipse' | 'crossLine' | 'longPosition' | 'shortPosition'
  | 'infoLine' | 'extendedLine' | 'trendAngle' | 'horizontalRay' | 'crossLinePoint'
  | 'parallelChannel' | 'regressionTrend' | 'flatTopBottom' | 'disjointChannel'
  | 'schiffPitchfork' | 'modSchiffPitchfork' | 'insidePitchfork'
  | 'fibChannel' | 'fibTimeZone' | 'fibSpeedFan' | 'trendFibTime' | 'fibCircles' | 'fibSpiral' | 'fibSpeedArcs' | 'fibWedge' | 'pitchfan'
  | 'gannBox' | 'gannSquareFixed' | 'gannSquare' | 'gannFan'
  | 'xabcdPattern' | 'cypherPattern' | 'headShoulders' | 'abcdPattern' | 'trianglePattern' | 'threeDrives'
  | 'elliottImpulse' | 'elliottCorrection' | 'elliottTriangle' | 'elliottDouble' | 'elliottTriple'
  | 'cyclicLines' | 'timeCycles' | 'sineLine'
  | 'forecast' | 'barsPattern' | 'ghostFeed' | 'projection'
  | 'anchoredVWAP' | 'fixedRangeVP'
  | 'priceRange' | 'dateRange' | 'datePriceRange'
  | 'brush' | 'highlighterTool'
  | 'arrowMarker' | 'arrowMarkUp' | 'arrowMarkDown' | 'arrowMarkLeft' | 'arrowMarkRight'
  | 'rotatedRect' | 'path' | 'polyline' | 'triangleShape' | 'arc' | 'curve' | 'doubleCurve'
  | 'anchoredText' | 'note' | 'priceNote' | 'pin' | 'table' | 'callout' | 'comment' | 'priceLabel' | 'signpost' | 'flagMark';

interface ToolItem {
  id: DrawingToolType;
  label: string;
  shortcut?: string;
}

interface ToolCategory {
  name: string;
  icon: React.ReactNode;
  tools: ToolItem[];
}

const TOOL_CATEGORIES: ToolCategory[] = [
  {
    name: 'CURSOR',
    icon: <MousePointer size={16} />,
    tools: [
      { id: 'select', label: 'Cursor' },
      { id: 'crossLine', label: 'Cross' },
      { id: 'marker', label: 'Dot' },
      { id: 'arrow', label: 'Arrow' },
      { id: 'eraser', label: 'Eraser' },
    ],
  },
  {
    name: 'LINES',
    icon: <LineIcon size={16} />,
    tools: [
      { id: 'trendline', label: 'Trend Line', shortcut: '\u2303T' },
      { id: 'ray', label: 'Ray' },
      { id: 'infoLine', label: 'Info Line' },
      { id: 'extendedLine', label: 'Extended Line' },
      { id: 'trendAngle', label: 'Trend Angle' },
      { id: 'hline', label: 'Horizontal Line', shortcut: '\u2303H' },
      { id: 'horizontalRay', label: 'Horizontal Ray', shortcut: '\u2303J' },
      { id: 'vline', label: 'Vertical Line', shortcut: '\u2303V' },
      { id: 'crossLinePoint', label: 'Cross Line', shortcut: '\u2303C' },
    ],
  },
  {
    name: 'CHANNELS',
    icon: <Layers size={16} />,
    tools: [
      { id: 'channel', label: 'Parallel Channel' },
      { id: 'regressionTrend', label: 'Regression Trend' },
      { id: 'flatTopBottom', label: 'Flat Top/Bottom' },
      { id: 'disjointChannel', label: 'Disjoint Channel' },
    ],
  },
  {
    name: 'PITCHFORKS',
    icon: <GitBranch size={16} />,
    tools: [
      { id: 'pitchfork', label: 'Pitchfork' },
      { id: 'schiffPitchfork', label: 'Schiff Pitchfork' },
      { id: 'modSchiffPitchfork', label: 'Modified Schiff Pitchfork' },
      { id: 'insidePitchfork', label: 'Inside Pitchfork' },
    ],
  },
  {
    name: 'FIBONACCI',
    icon: <Percent size={16} />,
    tools: [
      { id: 'fibRetracement', label: 'Fib Retracement', shortcut: '\u2303F' },
      { id: 'fibExtension', label: 'Trend-Based Fib Extension' },
      { id: 'fibChannel', label: 'Fib Channel' },
      { id: 'fibTimeZone', label: 'Fib Time Zone' },
      { id: 'fibSpeedFan', label: 'Fib Speed Resistance Fan' },
      { id: 'trendFibTime', label: 'Trend-Based Fib Time' },
      { id: 'fibCircles', label: 'Fib Circles' },
      { id: 'fibSpiral', label: 'Fib Spiral' },
      { id: 'fibSpeedArcs', label: 'Fib Speed Resistance Arcs' },
      { id: 'fibWedge', label: 'Fib Wedge' },
      { id: 'pitchfan', label: 'Pitchfan' },
    ],
  },
  {
    name: 'GANN',
    icon: <Hash size={16} />,
    tools: [
      { id: 'gannBox', label: 'Gann Box' },
      { id: 'gannSquareFixed', label: 'Gann Square Fixed' },
      { id: 'gannSquare', label: 'Gann Square' },
      { id: 'gannFan', label: 'Gann Fan' },
    ],
  },
  {
    name: 'PATTERNS',
    icon: <Diamond size={16} />,
    tools: [
      { id: 'xabcdPattern', label: 'XABCD Pattern' },
      { id: 'cypherPattern', label: 'Cypher Pattern' },
      { id: 'headShoulders', label: 'Head and Shoulders' },
      { id: 'abcdPattern', label: 'ABCD Pattern' },
      { id: 'trianglePattern', label: 'Triangle Pattern' },
      { id: 'threeDrives', label: 'Three Drives Pattern' },
    ],
  },
  {
    name: 'ELLIOTT WAVES',
    icon: <Waves size={16} />,
    tools: [
      { id: 'elliottImpulse', label: 'Elliott Impulse Wave (12345)' },
      { id: 'elliottCorrection', label: 'Elliott Correction Wave (ABC)' },
      { id: 'elliottTriangle', label: 'Elliott Triangle Wave (ABCDE)' },
      { id: 'elliottDouble', label: 'Elliott Double Combo (WXY)' },
      { id: 'elliottTriple', label: 'Elliott Triple Combo (WXYXZ)' },
    ],
  },
  {
    name: 'CYCLES',
    icon: <Activity size={16} />,
    tools: [
      { id: 'cyclicLines', label: 'Cyclic Lines' },
      { id: 'timeCycles', label: 'Time Cycles' },
      { id: 'sineLine', label: 'Sine Line' },
    ],
  },
  {
    name: 'PROJECTION',
    icon: <BarChart3 size={16} />,
    tools: [
      { id: 'longPosition', label: 'Long Position' },
      { id: 'shortPosition', label: 'Short Position' },
      { id: 'forecast', label: 'Forecast' },
      { id: 'barsPattern', label: 'Bars Pattern' },
      { id: 'ghostFeed', label: 'Ghost Feed' },
      { id: 'projection', label: 'Projection' },
    ],
  },
  {
    name: 'VOLUME-BASED',
    icon: <BarChart3 size={16} />,
    tools: [
      { id: 'anchoredVWAP', label: 'Anchored VWAP' },
      { id: 'fixedRangeVP', label: 'Fixed Range Volume Profile' },
    ],
  },
  {
    name: 'MEASURER',
    icon: <Ruler size={16} />,
    tools: [
      { id: 'measure', label: 'Price Range' },
      { id: 'dateRange', label: 'Date Range' },
      { id: 'datePriceRange', label: 'Date and Price Range' },
    ],
  },
  {
    name: 'BRUSHES',
    icon: <Pencil size={16} />,
    tools: [
      { id: 'brush', label: 'Brush' },
      { id: 'highlighterTool', label: 'Highlighter' },
    ],
  },
  {
    name: 'ARROWS',
    icon: <ArrowUp size={16} />,
    tools: [
      { id: 'arrowMarker', label: 'Arrow Marker' },
      { id: 'arrow', label: 'Arrow' },
      { id: 'arrowMarkUp', label: 'Arrow Mark Up' },
      { id: 'arrowMarkDown', label: 'Arrow Mark Down' },
      { id: 'arrowMarkLeft', label: 'Arrow Mark Left' },
      { id: 'arrowMarkRight', label: 'Arrow Mark Right' },
    ],
  },
  {
    name: 'SHAPES',
    icon: <Square size={16} />,
    tools: [
      { id: 'rectangle', label: 'Rectangle', shortcut: '\u2303\u21E7R' },
      { id: 'rotatedRect', label: 'Rotated Rectangle' },
      { id: 'path', label: 'Path' },
      { id: 'circle', label: 'Circle' },
      { id: 'ellipse', label: 'Ellipse' },
      { id: 'polyline', label: 'Polyline' },
      { id: 'triangleShape', label: 'Triangle' },
      { id: 'arc', label: 'Arc' },
      { id: 'curve', label: 'Curve' },
      { id: 'doubleCurve', label: 'Double Curve' },
    ],
  },
  {
    name: 'TEXT & NOTES',
    icon: <Type size={16} />,
    tools: [
      { id: 'text', label: 'Text' },
      { id: 'anchoredText', label: 'Anchored Text' },
      { id: 'note', label: 'Note' },
      { id: 'priceNote', label: 'Price Note' },
      { id: 'pin', label: 'Pin' },
      { id: 'table', label: 'Table' },
      { id: 'callout', label: 'Callout' },
      { id: 'comment', label: 'Comment' },
      { id: 'priceLabel', label: 'Price Label' },
      { id: 'signpost', label: 'Signpost' },
      { id: 'flagMark', label: 'Flag Mark' },
    ],
  },
  {
    name: 'SIGNALS',
    icon: <Circle size={16} />,
    tools: [
      { id: 'buyDot', label: 'BUY Signal (Green)' },
      { id: 'sellDot', label: 'SELL Signal (Red)' },
      { id: 'signalDot', label: 'SIGNAL Marker (Orange)' },
    ],
  },
];

function getToolIcon(toolId: DrawingToolType): React.ReactNode {
  const iconSize = 14;
  const icons: Record<string, React.ReactNode> = {
    select: <MousePointer size={iconSize} />,
    crossLine: <Plus size={iconSize} />,
    marker: <Circle size={iconSize} className="fill-current" style={{ width: 6, height: 6 }} />,
    arrow: <ArrowUp size={iconSize} />,
    eraser: <Trash2 size={iconSize} />,
    trendline: <LineIcon size={iconSize} />,
    ray: <Target size={iconSize} />,
    infoLine: <LineIcon size={iconSize} />,
    extendedLine: <LineIcon size={iconSize} />,
    trendAngle: <LineIcon size={iconSize} />,
    hline: <Minus size={iconSize} />,
    horizontalRay: <Minus size={iconSize} />,
    vline: <MoveVertical size={iconSize} />,
    crossLinePoint: <Plus size={iconSize} />,
    channel: <Layers size={iconSize} />,
    parallelChannel: <Layers size={iconSize} />,
    regressionTrend: <LineIcon size={iconSize} />,
    flatTopBottom: <Minus size={iconSize} />,
    disjointChannel: <Layers size={iconSize} />,
    pitchfork: <GitBranch size={iconSize} />,
    schiffPitchfork: <GitBranch size={iconSize} />,
    modSchiffPitchfork: <GitBranch size={iconSize} />,
    insidePitchfork: <GitBranch size={iconSize} />,
    fibRetracement: <Percent size={iconSize} />,
    fibExtension: <Percent size={iconSize} />,
    fibChannel: <Percent size={iconSize} />,
    fibTimeZone: <Percent size={iconSize} />,
    fibSpeedFan: <Percent size={iconSize} />,
    trendFibTime: <Percent size={iconSize} />,
    fibCircles: <Circle size={iconSize} />,
    fibSpiral: <Activity size={iconSize} />,
    fibSpeedArcs: <Activity size={iconSize} />,
    fibWedge: <Triangle size={iconSize} />,
    pitchfan: <LineIcon size={iconSize} />,
    gannBox: <Square size={iconSize} />,
    gannSquareFixed: <Square size={iconSize} />,
    gannSquare: <Square size={iconSize} />,
    gannFan: <LineIcon size={iconSize} />,
    xabcdPattern: <Diamond size={iconSize} />,
    cypherPattern: <Diamond size={iconSize} />,
    headShoulders: <Diamond size={iconSize} />,
    abcdPattern: <Diamond size={iconSize} />,
    trianglePattern: <Triangle size={iconSize} />,
    threeDrives: <Diamond size={iconSize} />,
    elliottImpulse: <Waves size={iconSize} />,
    elliottCorrection: <Waves size={iconSize} />,
    elliottTriangle: <Waves size={iconSize} />,
    elliottDouble: <Waves size={iconSize} />,
    elliottTriple: <Waves size={iconSize} />,
    cyclicLines: <Activity size={iconSize} />,
    timeCycles: <Clock size={iconSize} />,
    sineLine: <Waves size={iconSize} />,
    longPosition: <TrendingUp size={iconSize} />,
    shortPosition: <TrendingDown size={iconSize} />,
    forecast: <BarChart3 size={iconSize} />,
    barsPattern: <BarChart3 size={iconSize} />,
    ghostFeed: <Activity size={iconSize} />,
    projection: <ScanLine size={iconSize} />,
    anchoredVWAP: <BarChart3 size={iconSize} />,
    fixedRangeVP: <BarChart3 size={iconSize} />,
    measure: <Ruler size={iconSize} />,
    priceRange: <Ruler size={iconSize} />,
    dateRange: <Ruler size={iconSize} />,
    datePriceRange: <Ruler size={iconSize} />,
    brush: <Pencil size={iconSize} />,
    highlighterTool: <Highlighter size={iconSize} />,
    arrowMarker: <ArrowUp size={iconSize} />,
    arrowMarkUp: <ArrowUp size={iconSize} />,
    arrowMarkDown: <ArrowDown size={iconSize} />,
    arrowMarkLeft: <ArrowLeft size={iconSize} />,
    arrowMarkRight: <ArrowRight size={iconSize} />,
    rectangle: <Square size={iconSize} />,
    rotatedRect: <Square size={iconSize} className="rotate-45" />,
    path: <PenTool size={iconSize} />,
    circle: <Circle size={iconSize} />,
    ellipse: <Circle size={iconSize} className="scale-x-125" />,
    polyline: <PenTool size={iconSize} />,
    triangleShape: <Triangle size={iconSize} />,
    arc: <Activity size={iconSize} />,
    curve: <Activity size={iconSize} />,
    doubleCurve: <Activity size={iconSize} />,
    text: <Type size={iconSize} />,
    anchoredText: <Type size={iconSize} />,
    note: <MessageSquare size={iconSize} />,
    priceNote: <Tag size={iconSize} />,
    pin: <MapPin size={iconSize} />,
    table: <Table2 size={iconSize} />,
    callout: <MessageSquare size={iconSize} />,
    comment: <MessageSquare size={iconSize} />,
    priceLabel: <Tag size={iconSize} />,
    signpost: <Bookmark size={iconSize} />,
    flagMark: <Flag size={iconSize} />,
    buyDot: <Circle size={iconSize} />,
    sellDot: <Circle size={iconSize} />,
    signalDot: <Circle size={iconSize} />,
    uptrend: <TrendingUp size={iconSize} />,
    downtrend: <TrendingDown size={iconSize} />,
  };
  return icons[toolId] || <Circle size={iconSize} />;
}

function getToolColor(toolId: DrawingToolType): string | undefined {
  const colors: Record<string, string> = {
    eraser: '#EF4444',
    marker: '#FFD700',
    buyDot: '#22C55E',
    sellDot: '#EF4444',
    signalDot: '#F97316',
    pitchfork: '#8b5cf6',
    fibExtension: '#f59e0b',
    longPosition: '#22c55e',
    shortPosition: '#ef4444',
    uptrend: '#22c55e',
    downtrend: '#ef4444',
  };
  return colors[toolId];
}

interface ChartDrawingToolbarProps {
  activeDrawingTool: DrawingToolType;
  onSelectTool: (tool: DrawingToolType) => void;
  magnetMode: 'off' | 'weak' | 'strong';
  onMagnetChange: (mode: 'off' | 'weak' | 'strong') => void;
  lockDrawings: boolean;
  onLockChange: (locked: boolean) => void;
  hideAllOverlays: boolean;
  onHideOverlaysChange: (hidden: boolean) => void;
  drawingCount: number;
  onClearAll: () => void;
  onDeleteSelected: () => void;
  selectedDrawingId: string | null;
}

function DropdownPortal({ 
  buttonRef, 
  cat, 
  activeDrawingTool, 
  favorites, 
  onSelectTool, 
  toggleFavorite, 
  onClose 
}: { 
  buttonRef: React.RefObject<HTMLButtonElement | null>;
  cat: ToolCategory;
  activeDrawingTool: DrawingToolType;
  favorites: DrawingToolType[];
  onSelectTool: (tool: DrawingToolType) => void;
  toggleFavorite: (toolId: DrawingToolType) => void;
  onClose: () => void;
}) {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ top: 0, left: 0 });

  useEffect(() => {
    if (!buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const dropdownHeight = cat.tools.length * 36 + 40;
    let top = rect.top;
    if (top + dropdownHeight > window.innerHeight) {
      top = Math.max(8, window.innerHeight - dropdownHeight - 8);
    }
    setPos({ top, left: rect.right });
  }, [buttonRef, cat.tools.length]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (
        dropdownRef.current && !dropdownRef.current.contains(e.target as Node) &&
        buttonRef.current && !buttonRef.current.contains(e.target as Node)
      ) {
        onClose();
      }
    };
    const handleScroll = () => onClose();
    document.addEventListener('mousedown', handleClick);
    window.addEventListener('scroll', handleScroll, true);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      window.removeEventListener('scroll', handleScroll, true);
    };
  }, [onClose, buttonRef]);

  return createPortal(
    <div
      ref={dropdownRef}
      className="fixed z-[10000] min-w-[220px] max-h-[80vh] overflow-y-auto bg-gray-900 border border-gray-700 rounded-lg shadow-2xl"
      style={{ 
        top: pos.top, 
        left: pos.left,
        boxShadow: '4px 4px 24px rgba(0,0,0,0.7)',
      }}
    >
      <div className="px-3 py-2 border-b border-gray-700/50">
        <span className="text-[10px] font-bold text-gray-400 tracking-wider">{cat.name}</span>
      </div>
      <div className="py-1">
        {cat.tools.map((tool) => {
          const isActive = activeDrawingTool === tool.id;
          const isFav = favorites.includes(tool.id);
          const color = getToolColor(tool.id);
          return (
            <div
              key={tool.id}
              className={`flex items-center gap-2.5 px-3 py-2 cursor-pointer transition-colors group/item ${
                isActive
                  ? 'bg-cyan-500/15 text-white'
                  : 'text-gray-300 hover:bg-gray-800/80 hover:text-white'
              }`}
              onClick={() => {
                onSelectTool(tool.id);
                onClose();
              }}
              data-testid={`button-tool-${tool.id}`}
            >
              <span style={color ? { color } : {}}>
                {getToolIcon(tool.id)}
              </span>
              <span className="flex-1 text-sm">{tool.label}</span>
              {tool.shortcut && (
                <span className="text-[10px] text-gray-500 font-mono">{tool.shortcut}</span>
              )}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(tool.id);
                }}
                className={`opacity-0 group-hover/item:opacity-100 transition-opacity ${
                  isFav ? 'opacity-100 text-yellow-400' : 'text-gray-600 hover:text-yellow-400'
                }`}
                title={isFav ? 'Remove from favorites' : 'Add to favorites'}
              >
                <Star size={12} className={isFav ? 'fill-current' : ''} />
              </button>
            </div>
          );
        })}
      </div>
    </div>,
    document.body
  );
}

export function ChartDrawingToolbar({
  activeDrawingTool,
  onSelectTool,
  magnetMode,
  onMagnetChange,
  lockDrawings,
  onLockChange,
  hideAllOverlays,
  onHideOverlaysChange,
  drawingCount,
  onClearAll,
  onDeleteSelected,
  selectedDrawingId,
}: ChartDrawingToolbarProps) {
  const [openCategory, setOpenCategory] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<DrawingToolType[]>(() => {
    try {
      const saved = localStorage.getItem('chartToolFavorites');
      return saved ? JSON.parse(saved) : ['trendline', 'hline', 'fibRetracement', 'rectangle'];
    } catch { return ['trendline', 'hline', 'fibRetracement', 'rectangle']; }
  });
  const buttonRefs = useRef<Map<string, HTMLButtonElement | null>>(new Map());

  useEffect(() => {
    localStorage.setItem('chartToolFavorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (toolId: DrawingToolType) => {
    setFavorites(prev =>
      prev.includes(toolId)
        ? prev.filter(f => f !== toolId)
        : [...prev, toolId]
    );
  };

  return (
    <div className="flex flex-col w-10 bg-gray-900/95 border-r border-gray-800 select-none z-50 overflow-y-auto scrollbar-none" style={{ maxHeight: '100%' }} data-testid="chart-drawing-toolbar">
      {TOOL_CATEGORIES.map(cat => {
        const isOpen = openCategory === cat.name;
        const hasActiveTool = cat.tools.some(t => t.id === activeDrawingTool);

        return (
          <div key={cat.name}>
            <button
              ref={(el) => { buttonRefs.current.set(cat.name, el); }}
              onClick={() => setOpenCategory(isOpen ? null : cat.name)}
              className={`w-full p-2.5 flex items-center justify-center transition-colors relative group ${
                hasActiveTool
                  ? 'text-cyan-400 bg-cyan-500/10'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'
              }`}
              title={cat.name}
              data-testid={`button-category-${cat.name.toLowerCase().replace(/[^a-z]/g, '')}`}
            >
              {cat.icon}
              {hasActiveTool && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-cyan-400 rounded-r" />
              )}
            </button>

            {isOpen && (
              <DropdownPortal
                buttonRef={{ current: buttonRefs.current.get(cat.name) || null }}
                cat={cat}
                activeDrawingTool={activeDrawingTool}
                favorites={favorites}
                onSelectTool={onSelectTool}
                toggleFavorite={toggleFavorite}
                onClose={() => setOpenCategory(null)}
              />
            )}
          </div>
        );
      })}

      <div className="border-t border-gray-700/50 mt-auto">
        <button
          onClick={() => onMagnetChange(magnetMode === 'off' ? 'weak' : magnetMode === 'weak' ? 'strong' : 'off')}
          className={`w-full p-2.5 flex items-center justify-center transition-colors ${
            magnetMode !== 'off'
              ? 'text-purple-400 bg-purple-500/10'
              : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'
          }`}
          title={`Magnet: ${magnetMode === 'off' ? 'Off' : magnetMode === 'weak' ? 'Weak' : 'Strong'}`}
          data-testid="button-magnet-mode"
        >
          <Magnet size={16} />
        </button>

        <button
          onClick={() => onLockChange(!lockDrawings)}
          className={`w-full p-2.5 flex items-center justify-center transition-colors ${
            lockDrawings
              ? 'text-yellow-400 bg-yellow-500/10'
              : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'
          }`}
          title={lockDrawings ? 'Unlock Drawings' : 'Lock Drawings'}
          data-testid="button-lock-drawings"
        >
          {lockDrawings ? <Lock size={16} /> : <Unlock size={16} />}
        </button>

        <button
          onClick={() => onHideOverlaysChange(!hideAllOverlays)}
          className={`w-full p-2.5 flex items-center justify-center transition-colors ${
            hideAllOverlays
              ? 'text-blue-400 bg-blue-500/10'
              : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'
          }`}
          title={hideAllOverlays ? 'Show All Drawings' : 'Hide All Drawings'}
          data-testid="button-hide-overlays"
        >
          {hideAllOverlays ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>

        {drawingCount > 0 && (
          <button
            onClick={onClearAll}
            className="w-full p-2.5 flex items-center justify-center transition-colors text-gray-500 hover:text-red-400 hover:bg-red-500/10 relative"
            title={`Delete All (${drawingCount})`}
            data-testid="button-clear-all-drawings"
          >
            <Trash2 size={16} />
            <span className="absolute top-0.5 right-0.5 bg-red-500 text-white text-[7px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold">
              {drawingCount}
            </span>
          </button>
        )}
      </div>
    </div>
  );
}

export { TOOL_CATEGORIES, getToolIcon, getToolColor };
