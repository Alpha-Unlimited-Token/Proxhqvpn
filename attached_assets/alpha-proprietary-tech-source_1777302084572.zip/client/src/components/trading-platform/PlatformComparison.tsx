/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PlatformComparison™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_85beaf9a58d7f11d33682734
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, Fragment } from 'react';
import { motion } from 'framer-motion';
import { 
  Check, X, Crown, Trophy, Star, ChevronDown, ChevronUp,
  TrendingUp, Shield, Zap, Bot, BarChart3, Wallet, Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PlatformFeature {
  category: string;
  features: {
    name: string;
    description: string;
    alphaUnlimited: boolean | 'exclusive' | 'coming';
    binance: boolean;
    coinbase: boolean;
    kraken: boolean;
    tradingView: boolean;
    threeCommas: boolean;
    bitsgap: boolean;
  }[];
}

const PLATFORM_FEATURES: PlatformFeature[] = [
  {
    category: 'Trading Features',
    features: [
      { name: 'Spot Trading', description: 'Buy and sell cryptocurrencies', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Margin Trading', description: 'Trade with leverage', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Futures Trading', description: 'Perpetual and dated futures', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Short Selling', description: 'Profit from falling prices', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Leverage (up to 125x)', description: 'Adjustable leverage with margin modes', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Cross/Isolated Margin', description: 'Multiple margin mode support', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Options Trading', description: 'Call and put options', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: false },
      { name: 'P2P Trading', description: 'Peer-to-peer marketplace', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Cross-Platform Trading', description: 'Trade across 30+ exchanges', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: true },
    ]
  },
  {
    category: 'AI & Automation',
    features: [
      { name: 'AI Trading Signals', description: 'ML-powered buy/sell signals', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Grid Bot', description: 'Automated range trading', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'DCA Bot', description: 'Dollar cost averaging automation', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'AI Support/Resistance', description: 'AI-detected price zones', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Social Sentiment AI', description: 'Galaxy Score & AltRank metrics', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Copy Trading', description: 'Follow top traders', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: false },
      { name: '3rd Party Bot Integration', description: 'Freqtrade, 3Commas, Cryptohopper', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
    ]
  },
  {
    category: 'Charting & Analysis',
    features: [
      { name: 'Advanced Charts', description: 'TradingView-style charts', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: '100+ Indicators', description: 'RSI, MACD, Bollinger, etc.', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'Drawing Tools', description: 'Trend lines, Fibonacci, etc.', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: true, threeCommas: false, bitsgap: true },
      { name: 'Multi-Timeframe Analysis', description: 'View multiple timeframes', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: true, threeCommas: false, bitsgap: true },
      { name: 'Pattern Recognition', description: 'AI pattern detection', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
    ]
  },
  {
    category: 'Order Types',
    features: [
      { name: 'Market/Limit Orders', description: 'Basic order types', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'Stop Loss/Take Profit', description: 'Risk management orders', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'Trailing Stop', description: 'Dynamic stop orders', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'OCO Orders', description: 'One-cancels-other', alphaUnlimited: true, binance: true, coinbase: false, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'TWAP Orders', description: 'Time-weighted average price', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: true },
      { name: 'Iceberg Orders', description: 'Hidden large orders', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: true },
      { name: 'Scaled Orders', description: 'Ladder entry/exit', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: true },
    ]
  },
  {
    category: 'Arbitrage & DeFi',
    features: [
      { name: 'Arbitrage Scanner', description: 'Cross-exchange opportunities', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: true },
      { name: 'DEX Integration', description: 'Uniswap, Jupiter, Raydium', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Universal Swap', description: 'Swap any token instantly', alphaUnlimited: 'exclusive', binance: true, coinbase: true, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Staking & Earn', description: 'Passive income features', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Token Launchpad', description: 'Early access to new tokens', alphaUnlimited: true, binance: true, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
    ]
  },
  {
    category: 'Wallet & Connectivity',
    features: [
      { name: 'Multi-Wallet Support', description: '50+ wallet integrations', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Multi-Exchange API', description: 'Connect 30+ exchanges', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Custom API Connections', description: 'Connect unlisted platforms', alphaUnlimited: 'exclusive', binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Hardware Wallet Support', description: 'Ledger, Trezor integration', alphaUnlimited: true, binance: false, coinbase: true, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
    ]
  },
  {
    category: 'Portfolio & Analytics',
    features: [
      { name: 'Portfolio Tracker', description: 'Track all holdings', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'P&L Analytics', description: 'Profit/loss tracking', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Tax Reporting', description: 'Generate tax reports', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Performance Metrics', description: 'Win rate, Sharpe ratio, etc.', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: false, threeCommas: true, bitsgap: true },
    ]
  },
  {
    category: 'Security & Access',
    features: [
      { name: 'Two-Factor Auth', description: '2FA security', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'IP Whitelisting', description: 'Restrict API access', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
      { name: 'Security Dashboard', description: 'Monitor account security', alphaUnlimited: 'exclusive', binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'API Key Encryption', description: 'Encrypted credential storage', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: false, threeCommas: true, bitsgap: true },
    ]
  },
  {
    category: 'Additional Features',
    features: [
      { name: 'NFT Marketplace', description: 'Buy/sell NFTs', alphaUnlimited: true, binance: true, coinbase: true, kraken: false, tradingView: false, threeCommas: false, bitsgap: false },
      { name: 'Community Hub', description: 'Social features & forums', alphaUnlimited: true, binance: false, coinbase: false, kraken: false, tradingView: true, threeCommas: false, bitsgap: false },
      { name: 'Learning Center', description: 'Tutorials & education', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'Mobile PWA', description: 'Install as mobile app', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
      { name: 'Push Notifications', description: 'Price & trade alerts', alphaUnlimited: true, binance: true, coinbase: true, kraken: true, tradingView: true, threeCommas: true, bitsgap: true },
    ]
  },
];

const PLATFORMS = [
  { id: 'alphaUnlimited', name: 'Alpha Unlimited', color: '#00D4FF', icon: '⚡' },
  { id: 'binance', name: 'Binance', color: '#F0B90B', icon: '🔶' },
  { id: 'coinbase', name: 'Coinbase', color: '#0052FF', icon: '🔵' },
  { id: 'kraken', name: 'Kraken', color: '#5741D9', icon: '🐙' },
  { id: 'tradingView', name: 'TradingView', color: '#2962FF', icon: '📈' },
  { id: 'threeCommas', name: '3Commas', color: '#00C853', icon: '🤖' },
  { id: 'bitsgap', name: 'Bitsgap', color: '#FF6B00', icon: '📊' },
];

export function PlatformComparison() {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['Trading Features', 'AI & Automation']);
  const [showAllPlatforms, setShowAllPlatforms] = useState(false);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => 
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    );
  };

  const countFeatures = (platformId: string) => {
    return PLATFORM_FEATURES.reduce((total, cat) => {
      return total + cat.features.filter(f => {
        const value = f[platformId as keyof typeof f];
        return value === true || value === 'exclusive';
      }).length;
    }, 0);
  };

  const totalFeatures = PLATFORM_FEATURES.reduce((t, c) => t + c.features.length, 0);
  const exclusiveCount = PLATFORM_FEATURES.reduce((total, cat) => {
    return total + cat.features.filter(f => f.alphaUnlimited === 'exclusive').length;
  }, 0);

  const renderFeatureValue = (value: boolean | 'exclusive' | 'coming') => {
    if (value === 'exclusive') {
      return (
        <div className="flex items-center justify-center">
          <Star size={14} className="text-yellow-400 fill-yellow-400" />
        </div>
      );
    }
    if (value === 'coming') {
      return <span className="text-xs text-gray-500">Soon</span>;
    }
    if (value) {
      return <Check size={14} className="text-green-400" />;
    }
    return <X size={14} className="text-red-400/50" />;
  };

  const visiblePlatforms = showAllPlatforms ? PLATFORMS : PLATFORMS.slice(0, 4);

  return (
    <div className="space-y-6" data-testid="platform-comparison">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Trophy className="text-yellow-400" size={28} />
          <h2 className="text-2xl font-bold text-white">Platform Comparison</h2>
        </div>
        <p className="text-gray-400">See how Alpha Unlimited Trading outperforms the competition</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-4 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/50 rounded-xl text-center"
        >
          <div className="text-3xl font-bold text-cyan-400">{countFeatures('alphaUnlimited')}</div>
          <div className="text-sm text-gray-400">Total Features</div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-4 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-500/50 rounded-xl text-center"
        >
          <div className="text-3xl font-bold text-yellow-400">{exclusiveCount}</div>
          <div className="text-sm text-gray-400">Exclusive Features</div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-4 bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/50 rounded-xl text-center"
        >
          <div className="text-3xl font-bold text-green-400">30+</div>
          <div className="text-sm text-gray-400">Exchange Integrations</div>
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-4 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/50 rounded-xl text-center"
        >
          <div className="text-3xl font-bold text-purple-400">50+</div>
          <div className="text-sm text-gray-400">Wallet Integrations</div>
        </motion.div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <Check size={12} className="text-green-400" /> Available
          </div>
          <div className="flex items-center gap-1">
            <Star size={12} className="text-yellow-400 fill-yellow-400" /> Exclusive
          </div>
          <div className="flex items-center gap-1">
            <X size={12} className="text-red-400/50" /> Not Available
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowAllPlatforms(!showAllPlatforms)}
          className="text-xs border-gray-700"
        >
          {showAllPlatforms ? 'Show Less' : 'Show All Platforms'}
          {showAllPlatforms ? <ChevronUp size={14} className="ml-1" /> : <ChevronDown size={14} className="ml-1" />}
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-gray-800">
              <th className="text-left py-3 px-4 text-sm font-medium text-gray-400 w-64">Feature</th>
              {visiblePlatforms.map(platform => (
                <th key={platform.id} className="text-center py-3 px-2 min-w-[80px]">
                  <div className={`text-xs font-medium ${platform.id === 'alphaUnlimited' ? 'text-cyan-400' : 'text-gray-400'}`}>
                    <span className="text-lg block">{platform.icon}</span>
                    {platform.name.split(' ')[0]}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PLATFORM_FEATURES.map(category => (
              <Fragment key={category.category}>
                <tr 
                  onClick={() => toggleCategory(category.category)}
                  className="cursor-pointer bg-gray-900/50 hover:bg-gray-900/80 transition-colors"
                >
                  <td colSpan={visiblePlatforms.length + 1} className="py-2 px-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-white text-sm">{category.category}</span>
                      {expandedCategories.includes(category.category) 
                        ? <ChevronUp size={16} className="text-gray-500" />
                        : <ChevronDown size={16} className="text-gray-500" />
                      }
                    </div>
                  </td>
                </tr>
                {expandedCategories.includes(category.category) && category.features.map(feature => (
                  <tr key={feature.name} className="border-b border-gray-800/50 hover:bg-gray-800/30">
                    <td className="py-2 px-4">
                      <div className="text-sm text-white">{feature.name}</div>
                      <div className="text-xs text-gray-500">{feature.description}</div>
                    </td>
                    {visiblePlatforms.map(platform => (
                      <td key={platform.id} className="text-center py-2 px-2">
                        {renderFeatureValue(feature[platform.id as keyof typeof feature] as any)}
                      </td>
                    ))}
                  </tr>
                ))}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <div className="p-4 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-xl">
        <div className="flex items-center gap-3 mb-3">
          <Crown className="text-yellow-400" size={24} />
          <h3 className="font-bold text-white">Why Alpha Unlimited Trading is #1</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="flex items-start gap-2">
            <Zap className="text-cyan-400 shrink-0 mt-0.5" size={16} />
            <div>
              <div className="text-white font-medium">AI-Powered Trading</div>
              <div className="text-gray-400">Exclusive ML signals, pattern recognition, and sentiment analysis</div>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Wallet className="text-cyan-400 shrink-0 mt-0.5" size={16} />
            <div>
              <div className="text-white font-medium">Universal Connectivity</div>
              <div className="text-gray-400">50+ wallets, 30+ exchanges, custom API connections</div>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Shield className="text-cyan-400 shrink-0 mt-0.5" size={16} />
            <div>
              <div className="text-white font-medium">All-in-One Platform</div>
              <div className="text-gray-400">Trading, NFTs, games, community, and DeFi in one place</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
