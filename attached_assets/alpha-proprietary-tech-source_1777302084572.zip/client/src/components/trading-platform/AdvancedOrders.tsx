/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AdvancedOrders™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_8db786537d9f9c2442156b74
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Layers, TrendingUp, TrendingDown, Target, Clock, Eye, EyeOff,
  AlertTriangle, Info, Settings, Zap, ChevronDown, ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface OrderType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  tier: 'free' | 'basic' | 'premium' | 'platinum' | 'alpha';
  fields: { name: string; type: string; label: string; placeholder?: string }[];
}

const ORDER_TYPES: OrderType[] = [
  {
    id: 'limit',
    name: 'Limit Order',
    description: 'Execute at specific price or better',
    icon: <Target size={16} />,
    tier: 'free',
    fields: [
      { name: 'price', type: 'number', label: 'Price', placeholder: '0.00' },
      { name: 'amount', type: 'number', label: 'Amount', placeholder: '0.00' },
    ]
  },
  {
    id: 'stop_limit',
    name: 'Stop Limit',
    description: 'Trigger limit order at stop price',
    icon: <AlertTriangle size={16} />,
    tier: 'free',
    fields: [
      { name: 'stopPrice', type: 'number', label: 'Stop Price', placeholder: '0.00' },
      { name: 'limitPrice', type: 'number', label: 'Limit Price', placeholder: '0.00' },
      { name: 'amount', type: 'number', label: 'Amount', placeholder: '0.00' },
    ]
  },
  {
    id: 'trailing_stop',
    name: 'Trailing Stop',
    description: 'Dynamic stop that follows price',
    icon: <TrendingUp size={16} />,
    tier: 'basic',
    fields: [
      { name: 'trailPercent', type: 'number', label: 'Trail %', placeholder: '2.0' },
      { name: 'amount', type: 'number', label: 'Amount', placeholder: '0.00' },
    ]
  },
  {
    id: 'oco',
    name: 'OCO Order',
    description: 'One-Cancels-Other: TP + SL combo',
    icon: <Layers size={16} />,
    tier: 'basic',
    fields: [
      { name: 'takeProfitPrice', type: 'number', label: 'Take Profit', placeholder: '0.00' },
      { name: 'stopLossPrice', type: 'number', label: 'Stop Loss', placeholder: '0.00' },
      { name: 'amount', type: 'number', label: 'Amount', placeholder: '0.00' },
    ]
  },
  {
    id: 'twap',
    name: 'TWAP Order',
    description: 'Time-weighted average execution',
    icon: <Clock size={16} />,
    tier: 'premium',
    fields: [
      { name: 'totalAmount', type: 'number', label: 'Total Amount', placeholder: '0.00' },
      { name: 'duration', type: 'number', label: 'Duration (min)', placeholder: '60' },
      { name: 'slices', type: 'number', label: 'Slices', placeholder: '10' },
    ]
  },
  {
    id: 'iceberg',
    name: 'Iceberg Order',
    description: 'Hide large orders in small chunks',
    icon: <Eye size={16} />,
    tier: 'premium',
    fields: [
      { name: 'totalAmount', type: 'number', label: 'Total Amount', placeholder: '0.00' },
      { name: 'visibleAmount', type: 'number', label: 'Visible Amount', placeholder: '0.00' },
      { name: 'price', type: 'number', label: 'Price', placeholder: '0.00' },
    ]
  },
  {
    id: 'scaled',
    name: 'Scaled Order',
    description: 'Ladder entry across price range',
    icon: <Settings size={16} />,
    tier: 'premium',
    fields: [
      { name: 'priceFrom', type: 'number', label: 'Price From', placeholder: '0.00' },
      { name: 'priceTo', type: 'number', label: 'Price To', placeholder: '0.00' },
      { name: 'totalAmount', type: 'number', label: 'Total Amount', placeholder: '0.00' },
      { name: 'orders', type: 'number', label: 'Order Count', placeholder: '5' },
    ]
  },
];

export function AdvancedOrders({ userTier = 'free', symbol = 'BTC/USDT' }: { userTier?: string; symbol?: string }) {
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState('limit');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [showAdvanced, setShowAdvanced] = useState(false);

  const tierLevel = { free: 0, basic: 1, premium: 2, platinum: 3, alpha: 4 };
  const currentLevel = tierLevel[userTier as keyof typeof tierLevel] || 0;

  const canUseOrder = (orderTier: string) => {
    return currentLevel >= tierLevel[orderTier as keyof typeof tierLevel];
  };

  const selectedOrder = ORDER_TYPES.find(o => o.id === selectedType);

  const handleSubmit = () => {
    if (!canUseOrder(selectedOrder?.tier || 'free')) {
      toast({ 
        title: 'Upgrade Required', 
        description: `${selectedOrder?.name} requires ${selectedOrder?.tier} tier or higher`,
        variant: 'destructive'
      });
      return;
    }

    toast({ 
      title: 'Order Placed', 
      description: `${selectedOrder?.name} for ${symbol} submitted successfully`,
    });
    setFormData({});
  };

  return (
    <div className="space-y-4" data-testid="advanced-orders">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Layers className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Advanced Orders</h2>
            <p className="text-xs text-gray-500">Professional order types for precise execution</p>
          </div>
        </div>
        <div className="text-sm text-gray-400">{symbol}</div>
      </div>

      <div className="flex gap-2 mb-4">
        <Button
          onClick={() => setSide('buy')}
          className={`flex-1 ${side === 'buy' ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-800 hover:bg-gray-700'}`}
        >
          <TrendingUp size={16} className="mr-1" /> Buy
        </Button>
        <Button
          onClick={() => setSide('sell')}
          className={`flex-1 ${side === 'sell' ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-800 hover:bg-gray-700'}`}
        >
          <TrendingDown size={16} className="mr-1" /> Sell
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {ORDER_TYPES.slice(0, 4).map(order => (
          <button
            key={order.id}
            onClick={() => setSelectedType(order.id)}
            disabled={!canUseOrder(order.tier)}
            className={`p-2 rounded-lg border text-center transition-all ${
              selectedType === order.id
                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400'
                : canUseOrder(order.tier)
                  ? 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                  : 'bg-gray-900 border-gray-800 text-gray-600 cursor-not-allowed'
            }`}
          >
            <div className="flex justify-center mb-1">{order.icon}</div>
            <div className="text-xs">{order.name.split(' ')[0]}</div>
            {!canUseOrder(order.tier) && (
              <div className="text-[10px] text-yellow-500 mt-1">{order.tier}</div>
            )}
          </button>
        ))}
      </div>

      <button
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="w-full flex items-center justify-between p-2 bg-gray-900/50 border border-gray-800 rounded-lg text-sm text-gray-400 hover:border-gray-700"
      >
        <span>Advanced Order Types</span>
        {showAdvanced ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>

      <AnimatePresence>
        {showAdvanced && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-2"
          >
            {ORDER_TYPES.slice(4).map(order => (
              <button
                key={order.id}
                onClick={() => setSelectedType(order.id)}
                disabled={!canUseOrder(order.tier)}
                className={`p-3 rounded-lg border text-left transition-all ${
                  selectedType === order.id
                    ? 'bg-cyan-500/20 border-cyan-500'
                    : canUseOrder(order.tier)
                      ? 'bg-gray-800 border-gray-700 hover:border-gray-600'
                      : 'bg-gray-900 border-gray-800 cursor-not-allowed opacity-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className={selectedType === order.id ? 'text-cyan-400' : 'text-gray-400'}>
                    {order.icon}
                  </span>
                  <span className={`text-sm font-medium ${selectedType === order.id ? 'text-cyan-400' : 'text-white'}`}>
                    {order.name}
                  </span>
                </div>
                <div className="text-xs text-gray-500">{order.description}</div>
                {!canUseOrder(order.tier) && (
                  <div className="text-xs text-yellow-500 mt-1">Requires {order.tier}</div>
                )}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {selectedOrder && (
        <motion.div
          key={selectedOrder.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg space-y-3"
        >
          <div className="flex items-center gap-2 text-sm">
            <span className="text-cyan-400">{selectedOrder.icon}</span>
            <span className="text-white font-medium">{selectedOrder.name}</span>
            <span className="text-gray-500">•</span>
            <span className="text-gray-400">{selectedOrder.description}</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {selectedOrder.fields.map(field => (
              <div key={field.name}>
                <label className="block text-xs text-gray-400 mb-1">{field.label}</label>
                <input
                  type={field.type}
                  value={formData[field.name] || ''}
                  onChange={e => setFormData({ ...formData, [field.name]: e.target.value })}
                  placeholder={field.placeholder}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-cyan-500 focus:outline-none"
                />
              </div>
            ))}
          </div>

          <Button
            onClick={handleSubmit}
            className={`w-full ${side === 'buy' ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600'}`}
            disabled={!canUseOrder(selectedOrder.tier)}
          >
            <Zap size={16} className="mr-1" />
            Place {side === 'buy' ? 'Buy' : 'Sell'} {selectedOrder.name}
          </Button>

          {!canUseOrder(selectedOrder.tier) && (
            <div className="p-2 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-400 flex items-center gap-2">
              <Info size={14} />
              Upgrade to {selectedOrder.tier} tier to use {selectedOrder.name}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}
