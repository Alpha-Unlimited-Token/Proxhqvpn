/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha LanguageSwitcher™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_8c559cfa1b415f7a64ef300e
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useRef, useEffect } from 'react';
import { Globe, Check, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage, SUPPORTED_LANGUAGES } from '@/contexts/LanguageContext';

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentLang = SUPPORTED_LANGUAGES.find(l => l.code === language);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative flex-shrink-0" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center bg-white/5 hover:bg-white/10 rounded-md transition-colors min-h-[44px] min-w-[44px] justify-center"
        style={{ padding: '8px 10px', gap: '4px' }}
        aria-label="Select language"
      >
        <Globe className="w-3 h-3 text-[#00D4FF] flex-shrink-0" />
        <span className="text-sm leading-none flex-shrink-0">{currentLang?.flag}</span>
        <span className="text-xs text-gray-300 hidden sm:inline leading-none whitespace-nowrap flex-shrink-0" style={{ letterSpacing: '-0.02em' }}>{currentLang?.name}</span>
        <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 mt-1.5 w-48 bg-[#0A1628] border border-white/10 rounded-md shadow-xl overflow-hidden z-50"
          >
            <div className="px-2 py-1.5 border-b border-white/5">
              <span className="text-[10px] text-gray-500 uppercase tracking-wider">Select Language</span>
            </div>
            <div className="max-h-72 overflow-y-auto">
              {SUPPORTED_LANGUAGES.map(lang => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLanguage(lang.code);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 min-h-[44px] hover:bg-white/5 transition-colors ${
                    language === lang.code ? 'bg-[#00D4FF]/10' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base leading-none">{lang.flag}</span>
                    <div className="text-left">
                      <div className="text-xs text-white leading-tight">{lang.name}</div>
                    </div>
                  </div>
                  {language === lang.code && (
                    <Check className="w-3 h-3 text-[#00D4FF]" />
                  )}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
