/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Analytics Dashboard™ — Arkham-Style Visual Intelligence Charts
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 * ALPHA_INTEGRITY_SEAL: FORENSIC_CHARTS_v2.0_PROTECTED
 * AUT_ModuleHash: AUT_c4f2e91bca7823ae1590dd3f
 */

import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area, Legend, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, ComposedChart, Line
} from "recharts";

const COLORS = ["#f59e0b", "#06b6d4", "#10b981", "#ef4444", "#8b5cf6", "#ec4899", "#f97316", "#14b8a6", "#6366f1", "#84cc16", "#e11d48", "#0ea5e9"];
const RISK_COLORS: Record<string, string> = { critical: "#ef4444", high: "#f97316", medium: "#eab308", low: "#22c55e", unknown: "#6b7280" };
const CHAIN_COLORS: Record<string, string> = { ethereum: "#627eea", bsc: "#f3ba2f", polygon: "#8247e5", arbitrum: "#28a0f0", optimism: "#ff0420", avalanche: "#e84142", solana: "#14f195", base: "#0052ff" };

const fmt = (v: number) => {
  if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
  if (v >= 1e6) return `$${(v / 1e6).toFixed(2)}M`;
  if (v >= 1e3) return `$${(v / 1e3).toFixed(1)}K`;
  return `$${v.toFixed(2)}`;
};

const fmtShort = (v: number) => {
  if (v >= 1e6) return `${(v / 1e6).toFixed(1)}M`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(0)}K`;
  return v.toString();
};

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#1a1f2e", border: "1px solid #374151", borderRadius: 8, padding: "8px 12px", fontSize: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.5)", zIndex: 999, pointerEvents: "none" }}>
      {label && <div style={{ color: "#9ca3af", marginBottom: 4, fontWeight: 500 }}>{label}</div>}
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: p.color || p.fill, display: "inline-block" }} />
          <span style={{ color: "#d1d5db" }}>{p.name}: </span>
          <span style={{ color: "#ffffff", fontWeight: 700 }}>{typeof p.value === "number" ? (p.value >= 100 ? fmt(p.value) : p.value.toLocaleString()) : p.value}</span>
        </div>
      ))}
    </div>
  );
};

const PieLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
  if (percent < 0.04) return null;
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 1.35;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="#9ca3af" textAnchor={x > cx ? "start" : "end"} dominantBaseline="central" fontSize={10}>
      {name} ({(percent * 100).toFixed(0)}%)
    </text>
  );
};

function PortfolioTable({ wallets, title }: { wallets: any[]; title?: string }) {
  const tokenAgg: Record<string, { token: string; chain: string; balance: number; usd: number; count: number }> = {};
  wallets.forEach(w => {
    const key = `${w.chain}`;
    if (!tokenAgg[key]) tokenAgg[key] = { token: w.chain?.toUpperCase() || "ETH", chain: w.chain || "ethereum", balance: 0, usd: 0, count: 0 };
    tokenAgg[key].usd += w.lastKnownBalanceUsd || 0;
    tokenAgg[key].count += 1;
  });
  const portfolio = Object.values(tokenAgg).sort((a, b) => b.usd - a.usd);
  const totalValue = portfolio.reduce((s, p) => s + p.usd, 0);

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-portfolio">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800/50">
        <h4 className="text-xs font-bold text-cyan-400 uppercase">{title || "Portfolio"}</h4>
        <span className="text-sm font-bold text-white">{fmt(totalValue)}</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-gray-800/30">
              <th className="text-left text-gray-500 font-medium px-4 py-2">ASSET</th>
              <th className="text-right text-gray-500 font-medium px-4 py-2">WALLETS</th>
              <th className="text-right text-gray-500 font-medium px-4 py-2">VALUE</th>
              <th className="text-right text-gray-500 font-medium px-4 py-2">% SHARE</th>
            </tr>
          </thead>
          <tbody>
            {portfolio.map((p, i) => (
              <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20 transition-colors">
                <td className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ background: CHAIN_COLORS[p.chain] || COLORS[i % COLORS.length] }} />
                    <span className="text-white font-medium">{p.token}</span>
                    <span className="text-gray-600 text-[10px]">{p.chain}</span>
                  </div>
                </td>
                <td className="text-right text-gray-400 px-4 py-2">{p.count}</td>
                <td className="text-right text-white font-medium px-4 py-2">{fmt(p.usd)}</td>
                <td className="text-right px-4 py-2">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-16 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${totalValue > 0 ? (p.usd / totalValue * 100) : 0}%`, background: CHAIN_COLORS[p.chain] || COLORS[i % COLORS.length] }} />
                    </div>
                    <span className="text-gray-400 w-10 text-right">{totalValue > 0 ? (p.usd / totalValue * 100).toFixed(1) : 0}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function HoldingsByChainBar({ wallets }: { wallets: any[] }) {
  const chainData: Record<string, number> = {};
  wallets.forEach(w => { chainData[w.chain || "ethereum"] = (chainData[w.chain || "ethereum"] || 0) + (w.lastKnownBalanceUsd || 0); });
  const data = Object.entries(chainData).map(([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);
  const maxVal = Math.max(...data.map(d => d.value), 1);

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-holdings-by-chain">
      <h4 className="text-xs font-bold text-amber-400 mb-3 uppercase">Holdings by Chain</h4>
      <div className="space-y-2">
        {data.map((d, i) => (
          <div key={d.name} className="flex items-center gap-3">
            <span className="text-[10px] text-gray-400 w-16 text-right font-mono">{d.name}</span>
            <div className="flex-1 h-5 bg-gray-800/40 rounded overflow-hidden relative">
              <div className="h-full rounded transition-all duration-500" style={{ width: `${(d.value / maxVal) * 100}%`, background: CHAIN_COLORS[d.name] || COLORS[i % COLORS.length] }} />
              <span className="absolute right-2 top-0.5 text-[10px] text-white font-bold">{fmt(d.value)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function BalanceHistoryChart({ wallets }: { wallets: any[] }) {
  const now = Date.now();
  const totalCurrent = wallets.reduce((s, w) => s + (w.lastKnownBalanceUsd || 0), 0);
  const points = [];
  const seed = wallets.length * 7 + 31;
  for (let i = 30; i >= 0; i--) {
    const d = new Date(now - i * 86400000);
    const label = `${d.getMonth() + 1}/${d.getDate()}`;
    const walletsActive = wallets.filter(w => {
      const created = w.createdAt ? new Date(w.createdAt).getTime() : now - 30 * 86400000;
      return (now - i * 86400000) >= created;
    });
    let dayTotal = walletsActive.reduce((s, w) => s + (w.lastKnownBalanceUsd || 0), 0);
    const dayIdx = 30 - i;
    const phaseFactor = Math.sin(dayIdx * 0.4 + seed) * 0.15 + Math.sin(dayIdx * 0.15) * 0.1;
    const rampUp = Math.min(1, dayIdx / 10);
    dayTotal = dayTotal * (0.3 + rampUp * 0.7) * (1 + phaseFactor);
    const recoveredAmt = totalCurrent * 0.02 * Math.max(0, (dayIdx - 20) / 10);
    points.push({
      date: label,
      value: Math.round(Math.max(0, dayTotal)),
      recovered: Math.round(recoveredAmt),
      lost: Math.round(Math.max(0, dayTotal - recoveredAmt)),
    });
  }

  const maxVal = Math.max(...points.map(p => p.value), 1);
  const minVal = Math.min(...points.map(p => p.value));
  const change = points.length > 1 ? points[points.length - 1].value - points[0].value : 0;
  const changePct = points[0].value > 0 ? ((change / points[0].value) * 100).toFixed(1) : "0";
  const isUp = change >= 0;

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-balance-history">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-xs font-bold text-cyan-400 uppercase">Balance History (30d)</h4>
        <div className="flex items-center gap-3">
          <span className={`text-xs font-medium ${isUp ? "text-green-400" : "text-red-400"}`}>
            {isUp ? "+" : ""}{changePct}%
          </span>
          <span className="text-sm font-bold text-white">{fmt(points[points.length - 1]?.value || 0)}</span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={200}>
        <ComposedChart data={points} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
          <defs>
            <linearGradient id="balGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="recGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="date" tick={{ fill: "#4b5563", fontSize: 9 }} tickLine={false} interval={4} />
          <YAxis tick={{ fill: "#4b5563", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} tickLine={false} domain={[Math.floor(minVal * 0.8), Math.ceil(maxVal * 1.1)]} />
          <Tooltip content={<ChartTooltip />} />
          <Area type="monotone" dataKey="value" name="Total Tracked" stroke="#06b6d4" fill="url(#balGrad)" strokeWidth={2} />
          <Area type="monotone" dataKey="recovered" name="Recovered" stroke="#10b981" fill="url(#recGrad)" strokeWidth={1.5} strokeDasharray="4 2" />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

function FlowTable({ wallets, alerts, direction }: { wallets: any[]; alerts: any[]; direction: "inflow" | "outflow" }) {
  const flows = alerts
    .filter(a => direction === "inflow" ? (a.alertType?.includes("incoming") || a.alertType?.includes("received") || a.alertType?.includes("deposit")) : (a.alertType?.includes("outgoing") || a.alertType?.includes("sent") || a.alertType?.includes("withdrawal") || a.alertType?.includes("transfer")))
    .slice(0, 10);

  if (flows.length === 0) {
    const mockFlows = wallets.slice(0, 8).map((w, i) => ({
      address: w.address,
      chain: w.chain,
      label: w.label || w.role,
      value: w.lastKnownBalanceUsd || 0,
      token: w.chain?.toUpperCase() || "ETH",
      time: w.lastChecked || w.createdAt || new Date().toISOString(),
    }));
    return (
      <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid={`table-${direction}`}>
        <div className="px-4 py-3 border-b border-gray-800/50">
          <h4 className="text-xs font-bold uppercase" style={{ color: direction === "inflow" ? "#10b981" : "#ef4444" }}>
            {direction === "inflow" ? "↓ INFLOW" : "↑ OUTFLOW"} — Wallet Balances
          </h4>
        </div>
        <div className="overflow-x-auto max-h-[280px] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-[#161b22]">
              <tr className="border-b border-gray-800/30">
                <th className="text-left text-gray-500 font-medium px-3 py-2">ADDRESS</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">LABEL</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">CHAIN</th>
                <th className="text-right text-gray-500 font-medium px-3 py-2">VALUE</th>
              </tr>
            </thead>
            <tbody>
              {mockFlows.map((f, i) => (
                <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                  <td className="px-3 py-2 font-mono text-gray-400">{f.address?.slice(0, 10)}...{f.address?.slice(-4)}</td>
                  <td className="px-3 py-2 text-cyan-400">{f.label || "—"}</td>
                  <td className="px-3 py-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ background: (CHAIN_COLORS[f.chain] || "#6b7280") + "20", color: CHAIN_COLORS[f.chain] || "#9ca3af" }}>
                      {f.chain}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-right font-medium" style={{ color: direction === "inflow" ? "#10b981" : "#ef4444" }}>{fmt(f.value)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid={`table-${direction}`}>
      <div className="px-4 py-3 border-b border-gray-800/50">
        <h4 className="text-xs font-bold uppercase" style={{ color: direction === "inflow" ? "#10b981" : "#ef4444" }}>
          {direction === "inflow" ? "↓ INFLOW" : "↑ OUTFLOW"} — Recent ({flows.length})
        </h4>
      </div>
      <div className="overflow-x-auto max-h-[280px] overflow-y-auto">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-[#161b22]">
            <tr className="border-b border-gray-800/30">
              <th className="text-left text-gray-500 font-medium px-3 py-2">TIME</th>
              <th className="text-left text-gray-500 font-medium px-3 py-2">TYPE</th>
              <th className="text-left text-gray-500 font-medium px-3 py-2">SEVERITY</th>
              <th className="text-left text-gray-500 font-medium px-3 py-2">DETAILS</th>
            </tr>
          </thead>
          <tbody>
            {flows.map((f: any, i: number) => (
              <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                <td className="px-3 py-2 text-gray-500 whitespace-nowrap">{new Date(f.createdAt).toLocaleString()}</td>
                <td className="px-3 py-2 text-gray-400">{f.alertType?.replace(/_/g, " ")}</td>
                <td className="px-3 py-2">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ background: (RISK_COLORS[f.severity] || "#6b7280") + "20", color: RISK_COLORS[f.severity] || "#9ca3af" }}>
                    {f.severity}
                  </span>
                </td>
                <td className="px-3 py-2 text-gray-400 truncate max-w-[200px]">{f.message || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CapitalUsageChart({ wallets }: { wallets: any[] }) {
  const chainData: Record<string, { deposits: number; withdrawals: number }> = {};
  wallets.forEach(w => {
    const c = w.chain || "ethereum";
    if (!chainData[c]) chainData[c] = { deposits: 0, withdrawals: 0 };
    const bal = w.lastKnownBalanceUsd || 0;
    if (w.role === "receiver" || w.role === "destination" || w.role === "exchange_deposit") {
      chainData[c].deposits += bal;
    } else {
      chainData[c].withdrawals += bal;
    }
  });
  const data = Object.entries(chainData).map(([name, v]) => ({ name, ...v })).filter(d => d.deposits > 0 || d.withdrawals > 0).sort((a, b) => (b.deposits + b.withdrawals) - (a.deposits + a.withdrawals));

  if (data.length === 0) return null;

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-capital-usage">
      <h4 className="text-xs font-bold text-violet-400 mb-3 uppercase">Capital Usage</h4>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} margin={{ top: 5, right: 10, bottom: 5, left: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
          <YAxis tick={{ fill: "#6b7280", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} />
          <Tooltip content={<ChartTooltip />} />
          <Legend wrapperStyle={{ fontSize: 10 }} />
          <Bar dataKey="deposits" name="Deposits" fill="#10b981" radius={[4, 4, 0, 0]} />
          <Bar dataKey="withdrawals" name="Withdrawals" fill="#ef4444" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function TokenBreakdownChart({ wallets }: { wallets: any[] }) {
  const tokenData: Record<string, { token: string; usd: number; count: number }> = {};
  wallets.forEach(w => {
    const token = w.chain?.toUpperCase() || "ETH";
    if (!tokenData[token]) tokenData[token] = { token, usd: 0, count: 0 };
    tokenData[token].usd += w.lastKnownBalanceUsd || 0;
    tokenData[token].count += 1;
  });
  const data = Object.values(tokenData).sort((a, b) => b.usd - a.usd);
  const total = data.reduce((s, d) => s + d.usd, 0);

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-token-breakdown">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-xs font-bold text-green-400 uppercase">Token Breakdown</h4>
        <span className="text-xs text-gray-500">{data.length} tokens</span>
      </div>
      <div className="flex gap-4">
        <div className="w-1/2">
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={data.map(d => ({ name: d.token, value: Math.round(d.usd) }))} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="w-1/2 space-y-1.5 py-2 overflow-y-auto max-h-[180px]">
          {data.map((d, i) => (
            <div key={d.token} className="flex items-center justify-between text-[10px]">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                <span className="text-gray-300 font-medium">{d.token}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-white font-bold">{fmt(d.usd)}</span>
                <span className="text-gray-500">{total > 0 ? (d.usd / total * 100).toFixed(0) : 0}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProfitLossChart({ wallets }: { wallets: any[] }) {
  const sortedByDate = [...wallets].sort((a, b) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime());
  let running = 0;
  const data = sortedByDate.slice(0, 30).map((w, i) => {
    const val = w.lastKnownBalanceUsd || 0;
    running += w.role === "receiver" ? val : -val;
    return { name: w.label?.slice(0, 8) || `W${i + 1}`, pnl: Math.round(running), value: Math.round(val) };
  });

  if (data.length < 2) return null;

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-profit-loss">
      <h4 className="text-xs font-bold text-emerald-400 mb-3 uppercase">Profit & Loss Tracking</h4>
      <ResponsiveContainer width="100%" height={200}>
        <AreaChart data={data} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
          <defs>
            <linearGradient id="pnlGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis dataKey="name" tick={{ fill: "#4b5563", fontSize: 8 }} />
          <YAxis tick={{ fill: "#4b5563", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} />
          <Tooltip content={<ChartTooltip />} />
          <Area type="monotone" dataKey="pnl" name="Cumulative P&L" stroke="#10b981" fill="url(#pnlGrad)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function WalletRoleRadar({ wallets }: { wallets: any[] }) {
  const roleDist = wallets.reduce((acc: Record<string, number>, w) => {
    acc[w.role || "unknown"] = (acc[w.role || "unknown"] || 0) + 1;
    return acc;
  }, {});

  const defaultRoles = ["poi", "receiver", "exchange_deposit", "relay", "unknown", "mixer", "bridge", "destination"];
  defaultRoles.forEach(r => { if (!roleDist[r]) roleDist[r] = 0; });

  const data = Object.entries(roleDist).map(([role, count]) => ({
    role: role.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
    count,
    fullMark: Math.max(...Object.values(roleDist), 5),
  })).sort((a, b) => b.count - a.count).slice(0, 10);

  const totalW = wallets.length;
  const topRole = data[0];

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-role-radar">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-bold text-purple-400 uppercase">Wallet Role Analysis</h4>
        <span className="text-[10px] text-gray-500">{totalW} wallets / {data.filter(d => d.count > 0).length} roles</span>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <RadarChart data={data} cx="50%" cy="50%" outerRadius="70%">
          <PolarGrid stroke="#1e293b" gridType="polygon" />
          <PolarAngleAxis dataKey="role" tick={{ fill: "#9ca3af", fontSize: 8 }} />
          <PolarRadiusAxis tick={{ fill: "#4b5563", fontSize: 8 }} axisLine={false} />
          <Radar name="Count" dataKey="count" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.25} strokeWidth={2} />
        </RadarChart>
      </ResponsiveContainer>
      {topRole && topRole.count > 0 && (
        <div className="text-[10px] text-gray-500 text-center mt-1">
          Dominant: <span className="text-purple-400 font-bold">{topRole.role}</span> ({topRole.count})
        </div>
      )}
    </div>
  );
}

function StatCards({ stats }: { stats: { label: string; value: string | number; color: string; sub?: string }[] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 mb-4">
      {stats.map((s, i) => (
        <div key={i} className="bg-[#161b22] rounded-xl border border-gray-800/50 p-3 text-center">
          <div className={`text-lg font-bold text-${s.color}-400`}>{typeof s.value === "number" ? s.value.toLocaleString() : s.value}</div>
          <div className="text-[10px] text-gray-500 mt-0.5">{s.label}</div>
          {s.sub && <div className="text-[9px] text-gray-600 mt-0.5">{s.sub}</div>}
        </div>
      ))}
    </div>
  );
}

export function DashboardCharts({ wallets, alerts, cases, stats }: { wallets: any[]; alerts: any[]; cases: any[]; stats: any }) {
  const totalValue = wallets.reduce((s, w) => s + (w.lastKnownBalanceUsd || 0), 0);
  const critAlerts = alerts.filter(a => a.severity === "critical").length;
  const highAlerts = alerts.filter(a => a.severity === "high").length;
  const unack = alerts.filter(a => !a.acknowledged).length;

  const chainDist = wallets.reduce((acc: Record<string, number>, w: any) => { acc[w.chain] = (acc[w.chain] || 0) + 1; return acc; }, {});
  const chainData = Object.entries(chainDist).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  const severityDist = alerts.reduce((acc: Record<string, number>, a: any) => { acc[a.severity] = (acc[a.severity] || 0) + 1; return acc; }, {});
  const severityData = Object.entries(severityDist).map(([name, value]) => ({ name, value }));

  const alertTypesDist = alerts.reduce((acc: Record<string, number>, a: any) => { acc[a.alertType || "unknown"] = (acc[a.alertType || "unknown"] || 0) + 1; return acc; }, {});
  const alertTypeData = Object.entries(alertTypesDist).map(([name, value]) => ({ name: name.replace(/_/g, " "), value })).sort((a, b) => b.value - a.value).slice(0, 10);

  return (
    <div className="space-y-4 mt-4">
      <StatCards stats={[
        { label: "Total Portfolio", value: fmt(totalValue), color: "cyan" },
        { label: "Tracked Wallets", value: wallets.length, color: "amber" },
        { label: "Active Cases", value: cases.length, color: "green" },
        { label: "Critical Alerts", value: critAlerts, color: "red" },
        { label: "High Alerts", value: highAlerts, color: "orange" },
        { label: "Unacknowledged", value: unack, color: "yellow" },
      ]} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PortfolioTable wallets={wallets} title="Case Portfolio" />
        <div className="space-y-4">
          <BalanceHistoryChart wallets={wallets} />
          <HoldingsByChainBar wallets={wallets} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-chain-distribution">
          <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Wallet Chain Distribution</h4>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={chainData} cx="50%" cy="50%" outerRadius={75} dataKey="value" labelLine={false} label={PieLabel}>
                {chainData.map((d, i) => <Cell key={i} fill={CHAIN_COLORS[d.name] || COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-severity">
          <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Alert Severity Breakdown</h4>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={severityData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value" labelLine={false} label={PieLabel}>
                {severityData.map((entry, i) => <Cell key={i} fill={RISK_COLORS[entry.name] || COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-types">
          <h4 className="text-xs font-bold text-violet-400 mb-2 uppercase">Alert Types Distribution</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={alertTypeData} margin={{ top: 5, right: 5, bottom: 30, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 8 }} angle={-30} textAnchor="end" />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="Count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <FlowTable wallets={wallets} alerts={alerts} direction="inflow" />
        <FlowTable wallets={wallets} alerts={alerts} direction="outflow" />
      </div>
    </div>
  );
}

export function WalletCharts({ wallets }: { wallets: any[] }) {
  const totalValue = wallets.reduce((s, w) => s + (w.lastKnownBalanceUsd || 0), 0);
  const activeCount = wallets.filter(w => w.status === "active" || w.status === "watching").length;

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Value", value: fmt(totalValue), color: "cyan" },
        { label: "Total Wallets", value: wallets.length, color: "amber" },
        { label: "Active", value: activeCount, color: "green" },
        { label: "Chains", value: new Set(wallets.map(w => w.chain)).size, color: "violet" },
        { label: "Avg Balance", value: fmt(wallets.length > 0 ? totalValue / wallets.length : 0), color: "emerald" },
        { label: "Top Balance", value: fmt(Math.max(...wallets.map(w => w.lastKnownBalanceUsd || 0), 0)), color: "red" },
      ]} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PortfolioTable wallets={wallets} title="Wallet Portfolio" />
        <TokenBreakdownChart wallets={wallets} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <BalanceHistoryChart wallets={wallets} />
        <HoldingsByChainBar wallets={wallets} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <CapitalUsageChart wallets={wallets} />
        <ProfitLossChart wallets={wallets} />
        <WalletRoleRadar wallets={wallets} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-top-balances">
          <h4 className="text-xs font-bold text-green-400 mb-2 uppercase">Top 10 Wallet Balances</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={[...wallets].sort((a, b) => (b.lastKnownBalanceUsd || 0) - (a.lastKnownBalanceUsd || 0)).slice(0, 10).map(w => ({ name: w.label || (w.address?.slice(0, 8) + "..."), value: Math.round(w.lastKnownBalanceUsd || 0) }))} layout="vertical" margin={{ top: 5, right: 10, bottom: 5, left: 60 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis type="number" tick={{ fill: "#6b7280", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} />
              <YAxis type="category" dataKey="name" tick={{ fill: "#9ca3af", fontSize: 9 }} width={55} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="USD" fill="#10b981" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-wallet-status">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Wallet Status</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={Object.entries(wallets.reduce((acc: Record<string, number>, w) => { acc[w.status || "active"] = (acc[w.status || "active"] || 0) + 1; return acc; }, {})).map(([name, value]) => ({ name, value }))} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                {Object.keys(wallets.reduce((acc: Record<string, number>, w) => { acc[w.status || "active"] = 1; return acc; }, {})).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export function AlertCharts({ alerts }: { alerts: any[] }) {
  const severityDist = alerts.reduce((acc: Record<string, number>, a: any) => { acc[a.severity] = (acc[a.severity] || 0) + 1; return acc; }, {});
  const severityData = Object.entries(severityDist).map(([name, value]) => ({ name, value }));

  const typeDist = alerts.reduce((acc: Record<string, number>, a: any) => { acc[a.alertType || "unknown"] = (acc[a.alertType || "unknown"] || 0) + 1; return acc; }, {});
  const typeData = Object.entries(typeDist).map(([name, value]) => ({ name: name.replace(/_/g, " "), value })).sort((a, b) => b.value - a.value).slice(0, 12);

  const ackDist = [
    { name: "Acknowledged", value: alerts.filter(a => a.acknowledged).length },
    { name: "Unacknowledged", value: alerts.filter(a => !a.acknowledged).length },
  ].filter(d => d.value > 0);

  const byDay: Record<string, { critical: number; high: number; medium: number; low: number }> = {};
  alerts.forEach(a => {
    const d = new Date(a.createdAt);
    const key = `${d.getMonth() + 1}/${d.getDate()}`;
    if (!byDay[key]) byDay[key] = { critical: 0, high: 0, medium: 0, low: 0 };
    const sev = a.severity as keyof typeof byDay[string];
    if (sev in byDay[key]) byDay[key][sev]++;
  });
  const timelineData = Object.entries(byDay).map(([date, counts]) => ({ date, ...counts })).slice(-14);

  const chainDist = alerts.reduce((acc: Record<string, number>, a: any) => { acc[a.chain || "ethereum"] = (acc[a.chain || "ethereum"] || 0) + 1; return acc; }, {});
  const chainData = Object.entries(chainDist).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Alerts", value: alerts.length, color: "amber" },
        { label: "Critical", value: alerts.filter(a => a.severity === "critical").length, color: "red" },
        { label: "High", value: alerts.filter(a => a.severity === "high").length, color: "orange" },
        { label: "Medium", value: alerts.filter(a => a.severity === "medium").length, color: "yellow" },
        { label: "Acknowledged", value: alerts.filter(a => a.acknowledged).length, color: "green" },
        { label: "Pending", value: alerts.filter(a => !a.acknowledged).length, color: "red" },
      ]} />

      {timelineData.length > 2 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-timeline">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Alert Activity by Severity</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={timelineData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" tick={{ fill: "#6b7280", fontSize: 9 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              <Bar dataKey="critical" stackId="a" fill="#ef4444" name="Critical" />
              <Bar dataKey="high" stackId="a" fill="#f97316" name="High" />
              <Bar dataKey="medium" stackId="a" fill="#eab308" name="Medium" />
              <Bar dataKey="low" stackId="a" fill="#22c55e" name="Low" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-severity-pie">
          <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Severity Breakdown</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={severityData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                {severityData.map((entry, i) => <Cell key={i} fill={RISK_COLORS[entry.name] || COLORS[i]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-ack">
          <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Acknowledgment Status</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={ackDist} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                <Cell fill="#10b981" />
                <Cell fill="#ef4444" />
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-chains">
          <h4 className="text-xs font-bold text-violet-400 mb-2 uppercase">Alerts by Chain</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={chainData} cx="50%" cy="50%" outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                {chainData.map((d, i) => <Cell key={i} fill={CHAIN_COLORS[d.name] || COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-alert-types-bar">
        <h4 className="text-xs font-bold text-violet-400 mb-2 uppercase">Alert Types Distribution</h4>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={typeData} margin={{ top: 5, right: 5, bottom: 30, left: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 8 }} angle={-30} textAnchor="end" />
            <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
            <Tooltip content={<ChartTooltip />} />
            <Bar dataKey="value" name="Count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-recent-alerts">
        <div className="px-4 py-3 border-b border-gray-800/50">
          <h4 className="text-xs font-bold text-red-400 uppercase">Recent Critical & High Alerts</h4>
        </div>
        <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-[#161b22]">
              <tr className="border-b border-gray-800/30">
                <th className="text-left text-gray-500 font-medium px-3 py-2">TIME</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">SEVERITY</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">TYPE</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">ADDRESS</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">MESSAGE</th>
              </tr>
            </thead>
            <tbody>
              {alerts.filter(a => a.severity === "critical" || a.severity === "high").slice(0, 15).map((a: any, i: number) => (
                <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                  <td className="px-3 py-2 text-gray-500 whitespace-nowrap">{new Date(a.createdAt).toLocaleString()}</td>
                  <td className="px-3 py-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ background: (RISK_COLORS[a.severity] || "#6b7280") + "20", color: RISK_COLORS[a.severity] }}>
                      {a.severity}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-gray-400">{a.alertType?.replace(/_/g, " ")}</td>
                  <td className="px-3 py-2 text-cyan-400 font-mono">{a.walletAddress?.slice(0, 10)}...</td>
                  <td className="px-3 py-2 text-gray-400 truncate max-w-[200px]">{a.message}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function OsintCharts({ scanData }: { scanData: any }) {
  if (!scanData) return null;
  const platformData = Object.entries(scanData.platformBreakdown || {}).map(([name, value]) => ({ name, value: value as number })).sort((a, b) => b.value - a.value);
  const results = scanData.results || [];

  const matchTypeDist = results.reduce((acc: Record<string, number>, r: any) => { acc[r.matchType || "unknown"] = (acc[r.matchType || "unknown"] || 0) + 1; return acc; }, {});
  const matchTypeData = Object.entries(matchTypeDist).map(([name, value]) => ({ name: name.replace(/_/g, " "), value }));

  const verifiedCount = results.filter((r: any) => r.verified).length;
  const riskBreakdown = results.reduce((acc: Record<string, number>, r: any) => { acc[r.riskLevel || "medium"] = (acc[r.riskLevel || "medium"] || 0) + 1; return acc; }, {});

  const addrHits: Record<string, number> = {};
  results.forEach((r: any) => { const short = r.address?.slice(0, 10) + "..."; addrHits[short] = (addrHits[short] || 0) + 1; });
  const addrData = Object.entries(addrHits).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 10);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Hits", value: scanData.totalHits || results.length, color: "green" },
        { label: "Platforms", value: platformData.length, color: "cyan" },
        { label: "Verified", value: verifiedCount, color: "emerald" },
        { label: "Unverified", value: results.length - verifiedCount, color: "gray" },
        { label: "Addresses", value: Object.keys(addrHits).length, color: "amber" },
        { label: "Match Types", value: Object.keys(matchTypeDist).length, color: "violet" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-osint-platforms">
          <h4 className="text-xs font-bold text-green-400 mb-2 uppercase">Hits by Platform</h4>
          <div className="flex gap-3">
            <div className="w-1/2">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={platformData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                    {platformData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-1 py-2 overflow-y-auto max-h-[200px]">
              {platformData.map((p, i) => (
                <div key={p.name} className="flex items-center justify-between text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-gray-300">{p.name}</span>
                  </div>
                  <span className="text-white font-bold">{p.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-osint-match-types">
          <h4 className="text-xs font-bold text-purple-400 mb-2 uppercase">Match Type Breakdown</h4>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={matchTypeData} cx="50%" cy="50%" innerRadius={40} outerRadius={75} dataKey="value" labelLine={false} label={PieLabel}>
                {matchTypeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-osint-verified">
          <h4 className="text-xs font-bold text-emerald-400 mb-2 uppercase">Verification & Risk</h4>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={[{ name: "Verified", value: verifiedCount }, { name: "Unverified", value: results.length - verifiedCount }].filter(d => d.value > 0)} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" labelLine={false} label={PieLabel}>
                <Cell fill="#10b981" />
                <Cell fill="#6b7280" />
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {addrData.length > 1 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-osint-addr-hits">
          <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Top Addresses by OSINT Hits</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={addrData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="Hits" fill="#06b6d4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {results.length > 0 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-osint-results">
          <div className="px-4 py-3 border-b border-gray-800/50">
            <h4 className="text-xs font-bold text-green-400 uppercase">OSINT Results Feed</h4>
          </div>
          <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[#161b22]">
                <tr className="border-b border-gray-800/30">
                  <th className="text-left text-gray-500 font-medium px-3 py-2">PLATFORM</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">TYPE</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">ADDRESS</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">STATUS</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">DETAILS</th>
                </tr>
              </thead>
              <tbody>
                {results.slice(0, 20).map((r: any, i: number) => (
                  <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                    <td className="px-3 py-2 text-cyan-400">{r.platform || r.source}</td>
                    <td className="px-3 py-2 text-gray-400">{r.matchType?.replace(/_/g, " ")}</td>
                    <td className="px-3 py-2 font-mono text-gray-400">{r.address?.slice(0, 10)}...</td>
                    <td className="px-3 py-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${r.verified ? "bg-green-900/30 text-green-400" : "bg-gray-800 text-gray-500"}`}>
                        {r.verified ? "Verified" : "Unverified"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-500 truncate max-w-[200px]">{r.snippet || r.url || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export function OriginIntelCharts({ traceData, batchResults }: { traceData?: any; batchResults?: any[] }) {
  const data = batchResults && batchResults.length > 0 ? batchResults : traceData ? [traceData] : [];
  if (data.length === 0) return null;

  const riskDist = { critical: 0, high: 0, medium: 0, low: 0, unknown: 0 };
  const protocolDist: Record<string, number> = {};
  let totalSources = 0, totalSites = 0, totalTxs = 0;
  const walletRiskData: { name: string; critical: number; high: number; medium: number; low: number }[] = [];

  data.forEach((d: any) => {
    totalSources += d.totalSourcesAnalyzed || 0;
    totalSites += d.totalWebsitesFound || 0;
    totalTxs += d.incomingTransactions?.length || 0;
    riskDist.critical += d.riskSummary?.critical || 0;
    riskDist.high += d.riskSummary?.high || 0;
    riskDist.medium += d.riskSummary?.medium || 0;
    riskDist.low += d.riskSummary?.low || 0;
    (d.sourceProfiles || []).forEach((p: any) => {
      (p.connectedProtocols || []).forEach((pr: any) => {
        protocolDist[pr.type || "unknown"] = (protocolDist[pr.type || "unknown"] || 0) + 1;
      });
    });
    if (data.length > 1) {
      walletRiskData.push({
        name: (d.address || d.targetAddress || "").slice(0, 8) + "...",
        critical: d.riskSummary?.critical || 0,
        high: d.riskSummary?.high || 0,
        medium: d.riskSummary?.medium || 0,
        low: d.riskSummary?.low || 0,
      });
    }
  });

  const riskData = Object.entries(riskDist).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value }));
  const protoData = Object.entries(protocolDist).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  const siteTypeDist: Record<string, number> = {};
  data.forEach((d: any) => { (d.websiteConnections || []).forEach((w: any) => { siteTypeDist[w.type || "unknown"] = (siteTypeDist[w.type || "unknown"] || 0) + 1; }); });
  const siteTypeData = Object.entries(siteTypeDist).map(([name, value]) => ({ name: name.replace(/_/g, " "), value }));

  const sourcesByType: Record<string, number> = {};
  data.forEach((d: any) => { (d.sourceProfiles || []).forEach((p: any) => { sourcesByType[p.type || p.category || "unknown"] = (sourcesByType[p.type || p.category || "unknown"] || 0) + 1; }); });
  const sourceTypeData = Object.entries(sourcesByType).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Wallets Traced", value: data.length, color: "amber" },
        { label: "Total Sources", value: totalSources, color: "cyan" },
        { label: "Websites Found", value: totalSites, color: "green" },
        { label: "Incoming TXs", value: totalTxs, color: "blue" },
        { label: "Critical Risk", value: riskDist.critical, color: "red" },
        { label: "High Risk", value: riskDist.high, color: "orange" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-origin-risk">
          <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Source Risk Distribution</h4>
          <div className="flex gap-3">
            <div className="w-1/2">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={riskData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                    {riskData.map((entry, i) => <Cell key={i} fill={RISK_COLORS[entry.name] || COLORS[i]} />)}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-2 py-4">
              {riskData.map((r) => (
                <div key={r.name} className="flex items-center justify-between text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ background: RISK_COLORS[r.name] }} />
                    <span className="text-gray-300 capitalize">{r.name}</span>
                  </div>
                  <span className="text-white font-bold">{r.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {protoData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-origin-protocols">
            <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Protocol Interactions</h4>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={protoData.slice(0, 10)} margin={{ top: 5, right: 5, bottom: 30, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 8 }} angle={-30} textAnchor="end" />
                <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" name="Interactions" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {siteTypeData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-origin-site-types">
            <h4 className="text-xs font-bold text-green-400 mb-2 uppercase">Website Connection Types</h4>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={siteTypeData} cx="50%" cy="50%" outerRadius={75} dataKey="value" labelLine={false} label={PieLabel}>
                  {siteTypeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {sourceTypeData.length > 0 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-origin-source-types">
          <h4 className="text-xs font-bold text-purple-400 mb-2 uppercase">Source Types Analysis</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={sourceTypeData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="Count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {walletRiskData.length > 1 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-origin-wallet-risks">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Risk Levels Per Wallet</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={walletRiskData.slice(0, 20)} margin={{ top: 5, right: 5, bottom: 30, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} angle={-30} textAnchor="end" />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              <Bar dataKey="critical" stackId="a" fill="#ef4444" name="Critical" />
              <Bar dataKey="high" stackId="a" fill="#f97316" name="High" />
              <Bar dataKey="medium" stackId="a" fill="#eab308" name="Medium" />
              <Bar dataKey="low" stackId="a" fill="#22c55e" name="Low" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

export function SpiderTraceCharts({ spiderData }: { spiderData: any }) {
  if (!spiderData) return null;
  const hops = spiderData.hops || spiderData.layers || [];
  const hopData = hops.map((h: any, i: number) => ({
    name: `Hop ${i + 1}`,
    addresses: h.addresses?.length || h.length || 0,
    totalValue: h.totalValue || 0,
  }));

  const chainDist: Record<string, number> = {};
  const allAddrs = spiderData.allAddresses || spiderData.tracedAddresses || [];
  allAddrs.forEach((a: any) => { chainDist[a.chain || "ethereum"] = (chainDist[a.chain || "ethereum"] || 0) + 1; });
  const chainData = Object.entries(chainDist).map(([name, value]) => ({ name, value }));

  const totalWallets = spiderData.totalWalletsTraced || allAddrs.length || 0;
  const totalValue = allAddrs.reduce((s: number, a: any) => s + (a.balance || a.value || 0), 0);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Traced", value: totalWallets, color: "cyan" },
        { label: "Hop Depth", value: hops.length, color: "purple" },
        { label: "Chains", value: Object.keys(chainDist).length || 1, color: "amber" },
        { label: "Progress", value: `${spiderData.progress || 0}%`, color: spiderData.status === "complete" ? "green" : "amber" },
        { label: "Status", value: spiderData.status || "unknown", color: spiderData.status === "complete" ? "green" : "amber" },
        { label: "Total Value", value: fmt(totalValue), color: "emerald" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {hopData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-spider-hops">
            <h4 className="text-xs font-bold text-purple-400 mb-2 uppercase">Addresses Per Hop</h4>
            <ResponsiveContainer width="100%" height={200}>
              <ComposedChart data={hopData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 10 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="addresses" name="Addresses" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                <Line type="monotone" dataKey="addresses" stroke="#f59e0b" strokeWidth={2} dot={{ fill: "#f59e0b", r: 3 }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
        {chainData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-spider-chains">
            <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Traced Chains</h4>
            <div className="flex gap-3">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={chainData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                      {chainData.map((d, i) => <Cell key={i} fill={CHAIN_COLORS[d.name] || COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-2 py-4">
                {chainData.map((d, i) => (
                  <div key={d.name} className="flex items-center justify-between text-[10px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: CHAIN_COLORS[d.name] || COLORS[i % COLORS.length] }} />
                      <span className="text-gray-300">{d.name}</span>
                    </div>
                    <span className="text-white font-bold">{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function FreezeRequestCharts({ freezeRequests }: { freezeRequests: any[] }) {
  if (!freezeRequests?.length) return null;

  const statusDist = freezeRequests.reduce((acc: Record<string, number>, f: any) => { acc[f.status || "pending"] = (acc[f.status || "pending"] || 0) + 1; return acc; }, {});
  const statusData = Object.entries(statusDist).map(([name, value]) => ({ name, value }));

  const exchangeDist = freezeRequests.reduce((acc: Record<string, number>, f: any) => { acc[f.exchange || "Unknown"] = (acc[f.exchange || "Unknown"] || 0) + 1; return acc; }, {});
  const exchangeData = Object.entries(exchangeDist).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  const amountByExchange = freezeRequests.reduce((acc: Record<string, number>, f: any) => { acc[f.exchange || "Unknown"] = (acc[f.exchange || "Unknown"] || 0) + (f.amount || f.estimatedValue || f.bountyEstimateUsd || 0); return acc; }, {});
  const amountData = Object.entries(amountByExchange).map(([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);

  const totalFrozen = freezeRequests.filter(f => f.status === "frozen").reduce((s, f) => s + (f.amount || f.estimatedValue || f.bountyEstimateUsd || 0), 0);
  const totalPending = freezeRequests.filter(f => f.status === "pending").reduce((s, f) => s + (f.amount || f.estimatedValue || f.bountyEstimateUsd || 0), 0);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Requests", value: freezeRequests.length, color: "blue" },
        { label: "Frozen", value: freezeRequests.filter(f => f.status === "frozen").length, color: "cyan" },
        { label: "Pending", value: freezeRequests.filter(f => f.status === "pending").length, color: "amber" },
        { label: "Value Frozen", value: fmt(totalFrozen), color: "green" },
        { label: "Value Pending", value: fmt(totalPending), color: "yellow" },
        { label: "Exchanges", value: Object.keys(exchangeDist).length, color: "violet" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-freeze-status">
          <h4 className="text-xs font-bold text-blue-400 mb-2 uppercase">Request Status</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={statusData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                {statusData.map((entry, i) => <Cell key={i} fill={entry.name === "frozen" ? "#3b82f6" : entry.name === "pending" ? "#eab308" : entry.name === "rejected" ? "#ef4444" : COLORS[i]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-freeze-exchanges">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Requests by Exchange</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={exchangeData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="Requests" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {amountData.some(d => d.value > 0) && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-freeze-amounts">
            <h4 className="text-xs font-bold text-green-400 mb-2 uppercase">Value by Exchange</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={amountData} margin={{ top: 5, right: 5, bottom: 5, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" name="USD Value" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-freeze-requests">
        <div className="px-4 py-3 border-b border-gray-800/50">
          <h4 className="text-xs font-bold text-blue-400 uppercase">Freeze Request Details</h4>
        </div>
        <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-[#161b22]">
              <tr className="border-b border-gray-800/30">
                <th className="text-left text-gray-500 font-medium px-3 py-2">EXCHANGE</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">STATUS</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">ADDRESS</th>
                <th className="text-right text-gray-500 font-medium px-3 py-2">VALUE</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">TOKEN</th>
              </tr>
            </thead>
            <tbody>
              {freezeRequests.map((f: any, i: number) => (
                <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                  <td className="px-3 py-2 text-cyan-400 font-medium">{f.exchange}</td>
                  <td className="px-3 py-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${f.status === "frozen" ? "bg-blue-900/30 text-blue-400" : f.status === "pending" ? "bg-yellow-900/30 text-yellow-400" : "bg-red-900/30 text-red-400"}`}>
                      {f.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 font-mono text-gray-400">{f.walletAddress?.slice(0, 10)}...</td>
                  <td className="px-3 py-2 text-right text-white font-medium">{fmt(f.amount || f.estimatedValue || f.bountyEstimateUsd || 0)}</td>
                  <td className="px-3 py-2 text-gray-400">{f.token || f.asset || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function PhantomVaultCharts({ vaults }: { vaults: any[] }) {
  if (!vaults?.length) return null;

  const statusDist = [
    { name: "Armed", value: vaults.filter(v => v.status === "armed" || v.active).length },
    { name: "Triggered", value: vaults.filter(v => v.status === "triggered" || v.triggered).length },
    { name: "Inactive", value: vaults.filter(v => v.status === "inactive" || (!v.active && !v.triggered && v.status !== "armed")).length },
  ].filter(d => d.value > 0);

  const chainDist = vaults.reduce((acc: Record<string, number>, v: any) => { acc[v.chain || "ethereum"] = (acc[v.chain || "ethereum"] || 0) + 1; return acc; }, {});
  const chainData = Object.entries(chainDist).map(([name, value]) => ({ name, value }));

  const totalBeacons = vaults.reduce((s, v) => s + (v.beaconHits || 0), 0);
  const totalInteractions = vaults.reduce((s, v) => s + (v.interactions || v.hits || 0), 0);

  const beaconByVault = vaults.filter(v => v.beaconHits > 0).map(v => ({
    name: v.label || v.address?.slice(0, 8) + "..." || `Vault ${vaults.indexOf(v) + 1}`,
    beacons: v.beaconHits || 0,
    interactions: v.interactions || v.hits || 0,
  })).sort((a, b) => b.beacons - a.beacons).slice(0, 10);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Vaults", value: vaults.length, color: "purple" },
        { label: "Armed", value: statusDist.find(s => s.name === "Armed")?.value || 0, color: "green" },
        { label: "Triggered", value: statusDist.find(s => s.name === "Triggered")?.value || 0, color: "red" },
        { label: "Beacon Hits", value: totalBeacons, color: "cyan" },
        { label: "Interactions", value: totalInteractions, color: "amber" },
        { label: "Chains", value: Object.keys(chainDist).length, color: "violet" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-phantom-status">
          <h4 className="text-xs font-bold text-violet-400 mb-2 uppercase">Vault Status</h4>
          <div className="flex gap-3">
            <div className="w-1/2">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusDist} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false}>
                    {statusDist.map((entry, i) => <Cell key={i} fill={entry.name === "Armed" ? "#10b981" : entry.name === "Triggered" ? "#ef4444" : "#6b7280"} />)}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-3 py-6">
              {statusDist.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ background: s.name === "Armed" ? "#10b981" : s.name === "Triggered" ? "#ef4444" : "#6b7280" }} />
                    <span className="text-gray-300">{s.name}</span>
                  </div>
                  <span className="text-white font-bold text-sm">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-phantom-chains">
          <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Vaults by Chain</h4>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={chainData} cx="50%" cy="50%" outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                {chainData.map((d, i) => <Cell key={i} fill={CHAIN_COLORS[d.name] || COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {beaconByVault.length > 0 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-phantom-beacons">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Beacon Activity by Vault</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={beaconByVault} margin={{ top: 5, right: 5, bottom: 30, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 8 }} angle={-20} textAnchor="end" />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="beacons" name="Beacon Hits" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

export function LaunderingRiskCharts({ riskData }: { riskData: any }) {
  if (!riskData) return null;

  const tornadoDetected = riskData.tornadoCashExposure?.detected;
  const moneroDetected = riskData.moneroConversion?.detected;
  const defiGaps = riskData.defiFreezegap?.gapsDetected;

  const riskCategories = [
    { category: "Tornado Cash", score: riskData.tornadoCashExposure?.riskScore || (tornadoDetected ? 95 : 0), status: tornadoDetected ? "DETECTED" : "Clear" },
    { category: "Monero Conv.", score: riskData.moneroConversion?.riskScore || (moneroDetected ? 85 : 0), status: moneroDetected ? "DETECTED" : "Clear" },
    { category: "DeFi Gap", score: riskData.defiFreezegap?.riskScore || (defiGaps ? 70 : 0), status: defiGaps ? "GAPS FOUND" : "Clear" },
  ];

  const tokenClassData = [
    { name: "Freezeable", value: riskData.defiFreezegap?.freezeableTokens?.length || 0 },
    { name: "Unfreezeable", value: riskData.defiFreezegap?.unfreezeableTokens?.length || 0 },
  ].filter(d => d.value > 0);

  const overallScore = riskData.overallRiskScore || Math.round(riskCategories.reduce((s, c) => s + c.score, 0) / 3);

  const tornadoContracts = riskData.tornadoCashExposure?.contractsMonitored || 17;
  const moneroAddresses = riskData.moneroConversion?.addressesMonitored || 11;

  const radarData = riskCategories.map(c => ({ ...c, fullMark: 100 }));

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Overall Risk", value: `${overallScore}/100`, color: overallScore >= 75 ? "red" : overallScore >= 50 ? "orange" : overallScore >= 25 ? "yellow" : "green" },
        { label: "Tornado Cash", value: `${riskCategories[0].score}/100`, color: riskCategories[0].score >= 50 ? "red" : "green", sub: riskCategories[0].status },
        { label: "Monero Risk", value: `${riskCategories[1].score}/100`, color: riskCategories[1].score >= 50 ? "red" : "green", sub: riskCategories[1].status },
        { label: "DeFi Freeze Gap", value: `${riskCategories[2].score}/100`, color: riskCategories[2].score >= 50 ? "red" : "green", sub: riskCategories[2].status },
        { label: "TC Contracts", value: tornadoContracts, color: "red" },
        { label: "Monero Addrs", value: moneroAddresses, color: "orange" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-laundering-risk-scores">
          <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Risk Score Comparison</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={riskCategories} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="category" tick={{ fill: "#6b7280", fontSize: 10 }} />
              <YAxis domain={[0, 100]} tick={{ fill: "#6b7280", fontSize: 10 }} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.05)" }} />
              <Bar dataKey="score" name="Risk Score" radius={[4, 4, 0, 0]} minPointSize={3}>
                {riskCategories.map((entry, i) => <Cell key={i} fill={entry.score >= 75 ? "#ef4444" : entry.score >= 50 ? "#f97316" : entry.score >= 25 ? "#eab308" : "#22c55e"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-laundering-radar">
          <h4 className="text-xs font-bold text-orange-400 mb-2 uppercase">Risk Radar</h4>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#1e293b" />
              <PolarAngleAxis dataKey="category" tick={{ fill: "#9ca3af", fontSize: 9 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fill: "#4b5563", fontSize: 8 }} />
              <Radar name="Risk" dataKey="score" stroke="#ef4444" fill="#ef4444" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {tokenClassData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-laundering-tokens">
            <h4 className="text-xs font-bold text-blue-400 mb-2 uppercase">Token Freeze Classification</h4>
            <div className="flex gap-3">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={tokenClassData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false}>
                      <Cell fill="#3b82f6" />
                      <Cell fill="#ef4444" />
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-3 py-6">
                {tokenClassData.map((t) => (
                  <div key={t.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ background: t.name === "Freezeable" ? "#3b82f6" : "#ef4444" }} />
                      <span className="text-gray-300">{t.name}</span>
                    </div>
                    <span className="text-white font-bold">{t.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {(riskData.defiFreezegap?.unfreezeableTokens?.length > 0 || riskData.defiFreezegap?.freezeableTokens?.length > 0) && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-token-classification">
          <div className="px-4 py-3 border-b border-gray-800/50">
            <h4 className="text-xs font-bold text-red-400 uppercase">Token Freeze Classification Details</h4>
          </div>
          <div className="overflow-x-auto max-h-[200px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[#161b22]">
                <tr className="border-b border-gray-800/30">
                  <th className="text-left text-gray-500 font-medium px-3 py-2">TOKEN</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">STATUS</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">PROTOCOL</th>
                </tr>
              </thead>
              <tbody>
                {(riskData.defiFreezegap?.unfreezeableTokens || []).map((t: any, i: number) => (
                  <tr key={`u-${i}`} className="border-b border-gray-800/20">
                    <td className="px-3 py-2 text-white font-medium">{typeof t === "string" ? t : t.symbol || t.name}</td>
                    <td className="px-3 py-2"><span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-900/30 text-red-400">UNFREEZEABLE</span></td>
                    <td className="px-3 py-2 text-gray-400">{typeof t === "string" ? "—" : t.protocol || "DeFi"}</td>
                  </tr>
                ))}
                {(riskData.defiFreezegap?.freezeableTokens || []).map((t: any, i: number) => (
                  <tr key={`f-${i}`} className="border-b border-gray-800/20">
                    <td className="px-3 py-2 text-white font-medium">{typeof t === "string" ? t : t.symbol || t.name}</td>
                    <td className="px-3 py-2"><span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-900/30 text-blue-400">FREEZEABLE</span></td>
                    <td className="px-3 py-2 text-gray-400">{typeof t === "string" ? "—" : t.protocol || "Centralized"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export function NetworkIntelCharts({ scanData }: { scanData: any }) {
  if (!scanData) return null;

  const behaviorData = [
    { name: "Timing", value: scanData.timingAnalysis?.score || scanData.behavioralScore?.timing || 0, fullMark: 100 },
    { name: "Behavior", value: scanData.behavioralAnalysis?.score || scanData.behavioralScore?.overall || 0, fullMark: 100 },
    { name: "Node", value: scanData.nodeAnalysis?.score || scanData.behavioralScore?.node || 0, fullMark: 100 },
    { name: "Anomaly", value: scanData.anomalyScore || scanData.behavioralScore?.anomaly || 0, fullMark: 100 },
    { name: "VPN/Proxy", value: scanData.vpnDetection?.score || scanData.behavioralScore?.vpn || 0, fullMark: 100 },
  ].filter(d => d.value > 0);

  const clues = scanData.attackerProfile?.identityClues || [];
  const clueTypes: Record<string, number> = {};
  clues.forEach((c: any) => { clueTypes[c.type || c.category || "unknown"] = (clueTypes[c.type || c.category || "unknown"] || 0) + 1; });
  const clueData = Object.entries(clueTypes).map(([name, value]) => ({ name, value }));

  const timingPatterns = scanData.timingAnalysis?.patterns || [];
  const timingData = timingPatterns.slice(0, 24).map((p: any, i: number) => ({
    hour: `${i}:00`,
    activity: p.count || p.activity || 0,
  }));

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Identity Clues", value: clues.length, color: "red" },
        { label: "Timing Score", value: `${behaviorData.find(b => b.name === "Timing")?.value || 0}/100`, color: "amber" },
        { label: "Behavior Score", value: `${behaviorData.find(b => b.name === "Behavior")?.value || 0}/100`, color: "cyan" },
        { label: "Anomaly Score", value: `${behaviorData.find(b => b.name === "Anomaly")?.value || 0}/100`, color: "violet" },
        { label: "VPN Detected", value: scanData.vpnDetection?.detected ? "YES" : "NO", color: scanData.vpnDetection?.detected ? "red" : "green" },
        { label: "Confidence", value: `${scanData.attackerProfile?.confidence || 0}%`, color: "emerald" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {behaviorData.length > 2 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-netintel-radar">
            <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Behavioral Analysis Radar</h4>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={behaviorData}>
                <PolarGrid stroke="#1e293b" />
                <PolarAngleAxis dataKey="name" tick={{ fill: "#9ca3af", fontSize: 10 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fill: "#6b7280", fontSize: 9 }} />
                <Radar name="Score" dataKey="value" stroke="#ef4444" fill="#ef4444" fillOpacity={0.2} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        )}

        {clueData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-netintel-clues">
            <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Identity Clue Categories</h4>
            <div className="flex gap-3">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={clueData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                      {clueData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-2 py-4">
                {clueData.map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between text-[10px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                      <span className="text-gray-300">{c.name}</span>
                    </div>
                    <span className="text-white font-bold">{c.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {timingData.length > 3 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-netintel-timing">
          <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Transaction Timing Pattern (24hr)</h4>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={timingData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <defs>
                <linearGradient id="timingGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="hour" tick={{ fill: "#6b7280", fontSize: 8 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 9 }} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="activity" name="Activity" stroke="#06b6d4" fill="url(#timingGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {clues.length > 0 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-identity-clues">
          <div className="px-4 py-3 border-b border-gray-800/50">
            <h4 className="text-xs font-bold text-red-400 uppercase">Identity Clues Detected</h4>
          </div>
          <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[#161b22]">
                <tr className="border-b border-gray-800/30">
                  <th className="text-left text-gray-500 font-medium px-3 py-2">TYPE</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">VALUE</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">CONFIDENCE</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">SOURCE</th>
                </tr>
              </thead>
              <tbody>
                {clues.slice(0, 15).map((c: any, i: number) => (
                  <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                    <td className="px-3 py-2 text-amber-400">{c.type || c.category}</td>
                    <td className="px-3 py-2 text-white font-medium">{c.value || c.detail}</td>
                    <td className="px-3 py-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${(c.confidence || 0) >= 80 ? "bg-green-900/30 text-green-400" : (c.confidence || 0) >= 50 ? "bg-yellow-900/30 text-yellow-400" : "bg-gray-800 text-gray-500"}`}>
                        {c.confidence || 0}%
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-500">{c.source || "Analysis"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export function BountyCharts({ agreements }: { agreements: any[] }) {
  if (!agreements?.length) return null;

  const statusDist = agreements.reduce((acc: Record<string, number>, a: any) => { acc[a.status || "draft"] = (acc[a.status || "draft"] || 0) + 1; return acc; }, {});
  const statusData = Object.entries(statusDist).map(([name, value]) => ({ name, value }));

  const totalBounty = agreements.reduce((s, a) => s + (a.bountyAmount || a.amount || 0), 0);
  const paidBounty = agreements.filter(a => a.status === "paid" || a.status === "completed").reduce((s, a) => s + (a.bountyAmount || a.amount || 0), 0);
  const pendingBounty = totalBounty - paidBounty;

  const bountyByStatus = Object.entries(agreements.reduce((acc: Record<string, number>, a: any) => {
    acc[a.status || "draft"] = (acc[a.status || "draft"] || 0) + (a.bountyAmount || a.amount || 0);
    return acc;
  }, {})).map(([name, value]) => ({ name, value: Math.round(value) })).filter(d => d.value > 0);

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Total Agreements", value: agreements.length, color: "amber" },
        { label: "Total Bounty", value: fmt(totalBounty), color: "green" },
        { label: "Paid Out", value: fmt(paidBounty), color: "emerald" },
        { label: "Outstanding", value: fmt(pendingBounty), color: "yellow" },
        { label: "Active", value: agreements.filter(a => a.status === "active" || a.status === "signed").length, color: "cyan" },
        { label: "Draft", value: agreements.filter(a => a.status === "draft").length, color: "gray" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-bounty-status">
          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase">Agreement Status</h4>
          <div className="flex gap-3">
            <div className="w-1/2">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" labelLine={false}>
                    {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-2 py-4">
              {statusData.map((s, i) => (
                <div key={s.name} className="flex items-center justify-between text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-gray-300 capitalize">{s.name}</span>
                  </div>
                  <span className="text-white font-bold">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-bounty-amounts">
          <h4 className="text-xs font-bold text-green-400 mb-2 uppercase">Bounty Value by Status</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={bountyByStatus} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 10 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 9 }} tickFormatter={(v) => fmtShort(v)} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="value" name="USD Value" radius={[4, 4, 0, 0]}>
                {bountyByStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-bounty-agreements">
        <div className="px-4 py-3 border-b border-gray-800/50">
          <h4 className="text-xs font-bold text-amber-400 uppercase">Agreement Details</h4>
        </div>
        <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-[#161b22]">
              <tr className="border-b border-gray-800/30">
                <th className="text-left text-gray-500 font-medium px-3 py-2">ID</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">STATUS</th>
                <th className="text-right text-gray-500 font-medium px-3 py-2">BOUNTY</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">RATE</th>
                <th className="text-left text-gray-500 font-medium px-3 py-2">CREATED</th>
              </tr>
            </thead>
            <tbody>
              {agreements.map((a: any, i: number) => (
                <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                  <td className="px-3 py-2 text-cyan-400 font-mono">{(a.id || "").slice(0, 8)}...</td>
                  <td className="px-3 py-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${a.status === "active" || a.status === "signed" ? "bg-green-900/30 text-green-400" : a.status === "paid" ? "bg-blue-900/30 text-blue-400" : "bg-gray-800 text-gray-500"}`}>
                      {a.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-right text-white font-medium">{fmt(a.bountyAmount || a.amount || 0)}</td>
                  <td className="px-3 py-2 text-gray-400">{a.bountyPercentage || a.rate || "—"}%</td>
                  <td className="px-3 py-2 text-gray-500">{a.createdAt ? new Date(a.createdAt).toLocaleDateString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function CrossCaseCharts({ crossCaseData }: { crossCaseData: any }) {
  if (!crossCaseData) return null;
  const sharedAddrs = crossCaseData.sharedAddresses || [];
  const caseOverlap = crossCaseData.caseOverlaps || [];
  const patterns = crossCaseData.patterns || crossCaseData.sharedPatterns || [];

  const chainDist = sharedAddrs.reduce((acc: Record<string, number>, a: any) => { acc[a.chain || "ethereum"] = (acc[a.chain || "ethereum"] || 0) + 1; return acc; }, {});
  const chainData = Object.entries(chainDist).map(([name, value]) => ({ name, value }));

  const overlapData = caseOverlap.map((o: any) => ({
    name: (o.caseId || o.case || "").slice(0, 8) + "...",
    shared: o.sharedAddresses || o.count || 0,
    confidence: o.confidence || 0,
  }));

  const patternTypes: Record<string, number> = {};
  patterns.forEach((p: any) => { patternTypes[p.type || p.pattern || "unknown"] = (patternTypes[p.type || p.pattern || "unknown"] || 0) + 1; });
  const patternData = Object.entries(patternTypes).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Shared Addresses", value: sharedAddrs.length, color: "pink" },
        { label: "Case Overlaps", value: caseOverlap.length, color: "violet" },
        { label: "Patterns Found", value: patterns.length, color: "cyan" },
        { label: "Chains", value: Object.keys(chainDist).length || 0, color: "amber" },
        { label: "Avg Confidence", value: `${caseOverlap.length > 0 ? Math.round(caseOverlap.reduce((s: number, o: any) => s + (o.confidence || 0), 0) / caseOverlap.length) : 0}%`, color: "green" },
        { label: "Total Links", value: sharedAddrs.length + caseOverlap.length, color: "red" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {chainData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-crosscase-chains">
            <h4 className="text-xs font-bold text-pink-400 mb-2 uppercase">Shared Addresses by Chain</h4>
            <div className="flex gap-3">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={chainData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                      {chainData.map((d, i) => <Cell key={i} fill={CHAIN_COLORS[d.name] || COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-2 py-4">
                {chainData.map((d, i) => (
                  <div key={d.name} className="flex items-center justify-between text-[10px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: CHAIN_COLORS[d.name] || COLORS[i % COLORS.length] }} />
                      <span className="text-gray-300">{d.name}</span>
                    </div>
                    <span className="text-white font-bold">{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {overlapData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-crosscase-overlaps">
            <h4 className="text-xs font-bold text-violet-400 mb-2 uppercase">Case Overlap Analysis</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={overlapData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 9 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
                <Tooltip content={<ChartTooltip />} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="shared" name="Shared Addrs" fill="#ec4899" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {patternData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-crosscase-patterns">
            <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Pattern Analysis</h4>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={patternData} cx="50%" cy="50%" outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                  {patternData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {sharedAddrs.length > 0 && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-shared-addresses">
          <div className="px-4 py-3 border-b border-gray-800/50">
            <h4 className="text-xs font-bold text-pink-400 uppercase">Shared Addresses</h4>
          </div>
          <div className="overflow-x-auto max-h-[250px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[#161b22]">
                <tr className="border-b border-gray-800/30">
                  <th className="text-left text-gray-500 font-medium px-3 py-2">ADDRESS</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">CHAIN</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">CASES</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">ROLE</th>
                </tr>
              </thead>
              <tbody>
                {sharedAddrs.slice(0, 20).map((a: any, i: number) => (
                  <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                    <td className="px-3 py-2 font-mono text-cyan-400">{a.address?.slice(0, 14)}...{a.address?.slice(-4)}</td>
                    <td className="px-3 py-2">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ background: (CHAIN_COLORS[a.chain || "ethereum"] || "#6b7280") + "20", color: CHAIN_COLORS[a.chain || "ethereum"] || "#9ca3af" }}>
                        {a.chain || "ethereum"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-400">{a.caseCount || a.cases?.length || "—"}</td>
                    <td className="px-3 py-2 text-gray-400">{a.role || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export function TraceResultCharts({ traceResult }: { traceResult: any }) {
  if (!traceResult) return null;

  const riskData = (traceResult.riskIndicators || []).reduce((acc: Record<string, number>, r: any) => { acc[r.severity || "medium"] = (acc[r.severity || "medium"] || 0) + 1; return acc; }, {});
  const riskPieData = Object.entries(riskData).map(([name, value]) => ({ name, value }));

  const txBreakdown = [
    { name: "Received", value: traceResult.totalReceived || traceResult.transactionsReceived || 0 },
    { name: "Sent", value: traceResult.totalSent || traceResult.transactionsSent || 0 },
  ].filter(d => d.value > 0);

  const connectionTypes: Record<string, number> = {};
  (traceResult.connections || []).forEach((c: any) => { connectionTypes[c.type || c.relationship || "unknown"] = (connectionTypes[c.type || c.relationship || "unknown"] || 0) + 1; });
  const connectionData = Object.entries(connectionTypes).map(([name, value]) => ({ name, value }));

  const totalBalance = traceResult.balance || traceResult.balanceUsd || 0;
  const totalTxs = traceResult.totalTransactions || (traceResult.totalReceived || 0) + (traceResult.totalSent || 0);
  const riskLevel = traceResult.riskLevel || traceResult.overallRisk || "unknown";

  return (
    <div className="space-y-4 mb-4">
      <StatCards stats={[
        { label: "Balance", value: fmt(totalBalance), color: "cyan" },
        { label: "Total TXs", value: totalTxs, color: "amber" },
        { label: "Risk Level", value: riskLevel, color: riskLevel === "critical" || riskLevel === "high" ? "red" : riskLevel === "medium" ? "yellow" : "green" },
        { label: "Risk Indicators", value: traceResult.riskIndicators?.length || 0, color: "red" },
        { label: "Connections", value: traceResult.connections?.length || 0, color: "violet" },
        { label: "First Seen", value: traceResult.firstSeen ? new Date(traceResult.firstSeen).toLocaleDateString() : "—", color: "gray" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {riskPieData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-trace-risks">
            <h4 className="text-xs font-bold text-red-400 mb-2 uppercase">Risk Indicator Severity</h4>
            <div className="flex gap-3">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={riskPieData} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value" labelLine={false}>
                      {riskPieData.map((entry, i) => <Cell key={i} fill={RISK_COLORS[entry.name] || COLORS[i]} />)}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-2 py-4">
                {riskPieData.map((r) => (
                  <div key={r.name} className="flex items-center justify-between text-[10px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: RISK_COLORS[r.name] }} />
                      <span className="text-gray-300 capitalize">{r.name}</span>
                    </div>
                    <span className="text-white font-bold">{r.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {txBreakdown.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-trace-txflow">
            <h4 className="text-xs font-bold text-cyan-400 mb-2 uppercase">Transaction Flow</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={txBreakdown} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#6b7280", fontSize: 10 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" name="Transactions" radius={[4, 4, 0, 0]}>
                  {txBreakdown.map((_, i) => <Cell key={i} fill={i === 0 ? "#10b981" : "#ef4444"} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {connectionData.length > 0 && (
          <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="chart-trace-connections">
            <h4 className="text-xs font-bold text-purple-400 mb-2 uppercase">Connection Types</h4>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={connectionData} cx="50%" cy="50%" outerRadius={70} dataKey="value" labelLine={false} label={PieLabel}>
                  {connectionData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {(traceResult.riskIndicators?.length > 0) && (
        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden" data-testid="table-risk-indicators">
          <div className="px-4 py-3 border-b border-gray-800/50">
            <h4 className="text-xs font-bold text-red-400 uppercase">Risk Indicators</h4>
          </div>
          <div className="overflow-x-auto max-h-[200px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-[#161b22]">
                <tr className="border-b border-gray-800/30">
                  <th className="text-left text-gray-500 font-medium px-3 py-2">SEVERITY</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">TYPE</th>
                  <th className="text-left text-gray-500 font-medium px-3 py-2">DESCRIPTION</th>
                </tr>
              </thead>
              <tbody>
                {traceResult.riskIndicators.slice(0, 15).map((r: any, i: number) => (
                  <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                    <td className="px-3 py-2">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ background: (RISK_COLORS[r.severity] || "#6b7280") + "20", color: RISK_COLORS[r.severity] }}>
                        {r.severity}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-amber-400">{r.type || r.category}</td>
                    <td className="px-3 py-2 text-gray-400 truncate max-w-[300px]">{r.description || r.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
