/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha NFTMarketplaceSections™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_585d03993500139132b91d69
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import type { NFT } from "@shared/models/nft";
import { STAKING_APY_BY_RARITY } from "@shared/models/nft";
import {
  Clock, ChevronLeft, ChevronRight, TrendingUp, Heart, Eye,
  Crown, ShoppingCart, Gem, Star, Shield, Sparkles, Zap,
  Package, Tag, DollarSign, Award, Upload, Globe, Link,
  FileText, Info, Wallet, CheckCircle, AlertTriangle, ArrowRight,
  BarChart3, Target, Brain, Lock, Unlock, Gift, Percent,
  Activity, Layers, GripVertical, Plus, X, Save, Play,
  Trash2, Settings, ArrowDown, ArrowUp, CircleDot, Gauge
} from "lucide-react";

type Rarity = "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary" | "Mythic";

const RARITY_CONFIG: Record<Rarity, { color: string; border: string; bg: string; icon: any }> = {
  Common: { color: "text-gray-400", border: "border-gray-500/30", bg: "bg-gray-500/10", icon: Shield },
  Uncommon: { color: "text-green-400", border: "border-green-500/30", bg: "bg-green-500/10", icon: Star },
  Rare: { color: "text-blue-400", border: "border-blue-500/30", bg: "bg-blue-500/10", icon: Gem },
  Epic: { color: "text-purple-400", border: "border-purple-500/30", bg: "bg-purple-500/10", icon: Sparkles },
  Legendary: { color: "text-yellow-400", border: "border-yellow-500/30", bg: "bg-yellow-500/10", icon: Crown },
  Mythic: { color: "text-red-400", border: "border-red-500/30", bg: "bg-red-500/10", icon: Zap },
};

const RARITY_OPTIONS: Rarity[] = ["Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"];

export function MarketplaceHero({ stats }: {
  stats: { totalVolume: number; totalListed: number; floorPrice: number };
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative overflow-hidden rounded-2xl mb-8"
      data-testid="marketplace-hero"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-[#0D1117] via-[#161B22] to-[#0D1117]" />
      <div className="absolute inset-0 bg-gradient-to-br from-[#FFD700]/10 via-transparent to-[#00D4FF]/10" />
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#FFD700]/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#00D4FF]/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
      <div className="relative z-10 px-6 py-10 md:px-12 md:py-14">
        <div className="max-w-3xl">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Explore Exclusive{" "}
            <span className="bg-gradient-to-r from-[#FFD700] to-[#00D4FF] bg-clip-text text-transparent">
              NFTs
            </span>
          </h1>
          <p className="text-[#94A3B8] text-sm md:text-base mb-8 max-w-xl">
            Discover, collect, and trade unique digital assets on the Alpha Unlimited marketplace. Powered by multi-chain blockchain technology.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-4 max-w-lg">
          <div className="bg-[#0F1923]/80 border border-[#1A2942] rounded-xl p-4 text-center" data-testid="stat-total-volume">
            <p className="text-[#FFD700] text-xl md:text-2xl font-bold">${stats.totalVolume.toLocaleString()}</p>
            <p className="text-[#64748B] text-xs mt-1">Total Volume</p>
          </div>
          <div className="bg-[#0F1923]/80 border border-[#1A2942] rounded-xl p-4 text-center" data-testid="stat-total-listed">
            <p className="text-[#00D4FF] text-xl md:text-2xl font-bold">{stats.totalListed.toLocaleString()}</p>
            <p className="text-[#64748B] text-xs mt-1">Listed NFTs</p>
          </div>
          <div className="bg-[#0F1923]/80 border border-[#1A2942] rounded-xl p-4 text-center" data-testid="stat-floor-price">
            <p className="text-white text-xl md:text-2xl font-bold">${stats.floorPrice.toFixed(2)}</p>
            <p className="text-[#64748B] text-xs mt-1">Floor Price</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function NewNFTsCarousel({ nfts, onSelect, onBuy, getNFTImage }: {
  nfts: NFT[];
  onSelect: (nft: NFT) => void;
  onBuy: (nft: NFT) => void;
  getNFTImage: (nft: NFT) => string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container || nfts.length === 0) return;
    let animId: number;
    let scrollPos = 0;
    const speed = 0.5;

    const animate = () => {
      if (!isPaused && container) {
        scrollPos += speed;
        if (scrollPos >= container.scrollWidth / 2) {
          scrollPos = 0;
        }
        container.scrollLeft = scrollPos;
      }
      animId = requestAnimationFrame(animate);
    };
    animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, [isPaused, nfts.length]);

  const scroll = (dir: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = dir === "left" ? -300 : 300;
    scrollRef.current.scrollBy({ left: amount, behavior: "smooth" });
  };

  if (nfts.length === 0) return null;

  const displayNfts = [...nfts, ...nfts];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="mb-8"
      data-testid="new-nfts-carousel"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-[#00D4FF]" />
          <h2 className="text-white text-lg font-bold">Recently Listed</h2>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            className="w-8 h-8 bg-[#161B22] border-[#1A2942] text-white hover:bg-[#1A2942]"
            onClick={() => scroll("left")}
            data-testid="carousel-prev"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="w-8 h-8 bg-[#161B22] border-[#1A2942] text-white hover:bg-[#1A2942]"
            onClick={() => scroll("right")}
            data-testid="carousel-next"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {displayNfts.map((nft, idx) => {
          const rc = RARITY_CONFIG[(nft.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
          const RIcon = rc.icon;
          return (
            <div
              key={`${nft.id}-${idx}`}
              className={`flex-shrink-0 w-48 bg-[#0F1923] border ${rc.border} rounded-xl overflow-hidden hover:border-[#00D4FF]/40 transition-all cursor-pointer group`}
              onClick={() => onSelect(nft)}
              data-testid={`carousel-card-${nft.id}`}
            >
              <div className="aspect-square relative overflow-hidden">
                <img
                  src={getNFTImage(nft)}
                  alt={nft.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  draggable={false}
                />
                <div className={`absolute top-2 left-2 ${rc.bg} ${rc.color} px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1`}>
                  <RIcon className="w-3 h-3" /> {nft.rarity}
                </div>
              </div>
              <div className="p-3">
                <h4 className="text-white text-xs font-semibold truncate">{nft.name}</h4>
                <p className="text-[#64748B] text-[10px] mt-0.5 truncate">by {nft.creatorUsername || "AlphaGenesis"}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[#00D4FF] font-bold text-sm">${nft.priceUSD}</span>
                </div>
                {!nft.isSold && (
                  <Button
                    onClick={e => { e.stopPropagation(); onBuy(nft); }}
                    className="w-full mt-2 bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 text-[10px] py-1 h-7"
                    data-testid={`carousel-buy-${nft.id}`}
                  >
                    <ShoppingCart className="w-3 h-3 mr-1" /> Buy Now
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}

export function TrendingSection({ nfts, onSelect, onBuy, getNFTImage }: {
  nfts: NFT[];
  onSelect: (nft: NFT) => void;
  onBuy: (nft: NFT) => void;
  getNFTImage: (nft: NFT) => string;
}) {
  const top8 = nfts.slice(0, 8);
  if (top8.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mb-8"
      data-testid="trending-section"
    >
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-[#00D4FF]" />
        <h2 className="text-white text-lg font-bold">Trending Now</h2>
        <span className="text-lg">🔥</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {top8.map((nft, idx) => {
          const rc = RARITY_CONFIG[(nft.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
          return (
            <motion.div
              key={nft.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className="bg-[#0F1923] border border-[#1A2942] rounded-xl overflow-hidden hover:border-[#00D4FF]/40 transition-all cursor-pointer group relative"
              onClick={() => onSelect(nft)}
              data-testid={`trending-card-${nft.id}`}
            >
              <div className="absolute top-2 left-2 z-10 w-6 h-6 rounded-full bg-[#0D1117]/90 border border-[#1A2942] flex items-center justify-center">
                <span className="text-[#FFD700] text-xs font-bold">#{idx + 1}</span>
              </div>
              <div className="aspect-square relative overflow-hidden">
                <img
                  src={getNFTImage(nft)}
                  alt={nft.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  draggable={false}
                />
              </div>
              <div className="p-3">
                <h4 className="text-white text-sm font-semibold truncate">{nft.name}</h4>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[#00D4FF] font-bold text-sm">${nft.priceUSD}</span>
                  <div className="flex items-center gap-2 text-[10px] text-[#64748B]">
                    <span className="flex items-center gap-0.5"><Heart className="w-3 h-3" /> {nft.likes}</span>
                    <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {nft.views}</span>
                  </div>
                </div>
                {!nft.isSold && (
                  <Button
                    onClick={e => { e.stopPropagation(); onBuy(nft); }}
                    className="w-full mt-2 bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 text-xs py-1 h-7"
                    data-testid={`trending-buy-${nft.id}`}
                  >
                    <ShoppingCart className="w-3 h-3 mr-1" /> Buy
                  </Button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}

export function TrendingShowcase({ nfts, onSelect, onBuy, getNFTImage }: {
  nfts: NFT[];
  onSelect: (nft: NFT) => void;
  onBuy: (nft: NFT) => void;
  getNFTImage: (nft: NFT) => string;
}) {
  const [currentPairIndex, setCurrentPairIndex] = useState(0);

  const pairs: NFT[][] = [];
  for (let i = 0; i < nfts.length; i += 2) {
    if (i + 1 < nfts.length) {
      pairs.push([nfts[i], nfts[i + 1]]);
    } else {
      pairs.push([nfts[i]]);
    }
  }

  useEffect(() => {
    if (pairs.length <= 1) return;
    let timeoutId: ReturnType<typeof setTimeout>;
    const interval = setInterval(() => {
      timeoutId = setTimeout(() => {
        setCurrentPairIndex(prev => (prev + 1) % pairs.length);
      }, 600);
    }, 4000);
    return () => {
      clearInterval(interval);
      clearTimeout(timeoutId);
    };
  }, [pairs.length]);

  if (nfts.length === 0) return null;

  const currentPair = pairs[currentPairIndex] || pairs[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mb-8"
      data-testid="trending-showcase"
    >
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-[#FFD700]" />
        <h2 className="text-white text-lg font-bold">Trending Now</h2>
        <span className="text-lg">🔥</span>
        <div className="flex gap-1 ml-auto">
          {pairs.map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                i === currentPairIndex ? "bg-[#FFD700] w-4" : "bg-[#1A2942]"
              }`}
            />
          ))}
        </div>
      </div>
      <div className="relative overflow-hidden rounded-xl" style={{ minHeight: "280px" }}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPairIndex}
            initial={{ x: 300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="grid grid-cols-2 gap-4"
          >
            {currentPair.map((nft) => {
              const rc = RARITY_CONFIG[(nft.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
              const RIcon = rc.icon;
              return (
                <div
                  key={nft.id}
                  className={`bg-[#0F1923] border ${rc.border} rounded-xl overflow-hidden hover:border-[#FFD700]/40 transition-all cursor-pointer group`}
                  onClick={() => onSelect(nft)}
                  data-testid={`showcase-card-${nft.id}`}
                >
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <img
                      src={getNFTImage(nft)}
                      alt={nft.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      draggable={false}
                    />
                    <div className={`absolute top-3 left-3 ${rc.bg} ${rc.color} px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1`}>
                      <RIcon className="w-3.5 h-3.5" /> {nft.rarity}
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3">
                      <h4 className="text-white text-sm font-bold truncate">{nft.name}</h4>
                      <p className="text-gray-300 text-xs mt-0.5">by {nft.creatorUsername || "AlphaGenesis"}</p>
                    </div>
                  </div>
                  <div className="p-3 flex items-center justify-between">
                    <span className="text-[#FFD700] font-bold text-lg">${nft.priceUSD}</span>
                    <div className="flex items-center gap-3 text-xs text-[#64748B]">
                      <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5" /> {nft.likes}</span>
                      <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {nft.views}</span>
                    </div>
                    {!nft.isSold && (
                      <Button
                        onClick={e => { e.stopPropagation(); onBuy(nft); }}
                        className="bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/30 hover:bg-[#FFD700]/30 text-xs py-1 h-8 px-3"
                        data-testid={`showcase-buy-${nft.id}`}
                      >
                        <ShoppingCart className="w-3.5 h-3.5 mr-1" /> Buy
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export function TopSellersGrid({ sellers, onViewCreator }: {
  sellers: Array<{
    creatorId: string;
    creatorUsername: string;
    totalSales: number;
    totalRevenue: number;
    nftCount: number;
  }>;
  onViewCreator: (creatorId: string) => void;
}) {
  if (sellers.length === 0) return null;

  const getMedalColor = (idx: number) => {
    if (idx === 0) return { border: "border-[#FFD700]/50", bg: "bg-[#FFD700]/10", text: "text-[#FFD700]", label: "🥇" };
    if (idx === 1) return { border: "border-[#C0C0C0]/50", bg: "bg-[#C0C0C0]/10", text: "text-[#C0C0C0]", label: "🥈" };
    if (idx === 2) return { border: "border-[#CD7F32]/50", bg: "bg-[#CD7F32]/10", text: "text-[#CD7F32]", label: "🥉" };
    return { border: "border-[#1A2942]", bg: "bg-[#161B22]", text: "text-[#64748B]", label: `#${idx + 1}` };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="mb-8"
      data-testid="top-sellers-grid"
    >
      <div className="flex items-center gap-2 mb-4">
        <Crown className="w-5 h-5 text-[#FFD700]" />
        <h2 className="text-white text-lg font-bold">Top Sellers</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {sellers.map((seller, idx) => {
          const medal = getMedalColor(idx);
          const initials = seller.creatorUsername
            .split(/[\s_-]/)
            .map(w => w[0]?.toUpperCase() || "")
            .slice(0, 2)
            .join("");

          return (
            <motion.div
              key={seller.creatorId}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className={`bg-[#0F1923] border ${medal.border} rounded-xl p-4 hover:border-[#00D4FF]/40 transition-all cursor-pointer`}
              onClick={() => onViewCreator(seller.creatorId)}
              data-testid={`seller-card-${seller.creatorId}`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-full ${medal.bg} flex items-center justify-center ${medal.text} font-bold text-sm`}>
                  {initials || "??"}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm">{medal.label}</span>
                    <h4 className="text-white text-sm font-semibold truncate">{seller.creatorUsername}</h4>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-[#00D4FF] text-sm font-bold">{seller.totalSales}</p>
                  <p className="text-[#64748B] text-[10px]">Sales</p>
                </div>
                <div>
                  <p className="text-[#FFD700] text-sm font-bold">${seller.totalRevenue.toLocaleString()}</p>
                  <p className="text-[#64748B] text-[10px]">Revenue</p>
                </div>
                <div>
                  <p className="text-white text-sm font-bold">{seller.nftCount}</p>
                  <p className="text-[#64748B] text-[10px]">NFTs</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}

export function PortfolioStats({ stats }: {
  stats: {
    totalOwned: number;
    totalListed: number;
    totalSold: number;
    totalValue: number;
    totalEarnings: number;
  };
}) {
  const items = [
    { icon: Package, label: "Total Owned", value: stats.totalOwned.toString(), color: "text-[#00D4FF]" },
    { icon: Tag, label: "Listed", value: stats.totalListed.toString(), color: "text-green-400" },
    { icon: ShoppingCart, label: "Sold", value: stats.totalSold.toString(), color: "text-purple-400" },
    { icon: DollarSign, label: "Portfolio Value", value: `$${stats.totalValue.toLocaleString()}`, color: "text-[#FFD700]" },
    { icon: Award, label: "Total Earnings", value: `$${stats.totalEarnings.toLocaleString()}`, color: "text-emerald-400" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-6"
      data-testid="portfolio-stats"
    >
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.label}
            className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 text-center"
            data-testid={`portfolio-stat-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
          >
            <Icon className={`w-5 h-5 ${item.color} mx-auto mb-2`} />
            <p className={`${item.color} text-lg md:text-xl font-bold`}>{item.value}</p>
            <p className="text-[#64748B] text-xs mt-1">{item.label}</p>
          </div>
        );
      })}
    </motion.div>
  );
}

export function MigrationImportForm({ onMigrate, isPending, supportedChains }: {
  onMigrate: (data: {
    name: string;
    contractAddress: string;
    tokenId: string;
    sourceChain: string;
    targetChain?: string;
    imageUrl?: string;
    metadataUrl?: string;
    description?: string;
    rarity?: string;
  }) => void;
  isPending: boolean;
  supportedChains: Array<{ id: string; name: string; symbol: string; icon: string }>;
}) {
  const [name, setName] = useState("");
  const [contractAddress, setContractAddress] = useState("");
  const [tokenId, setTokenId] = useState("");
  const [sourceChain, setSourceChain] = useState(supportedChains[0]?.id || "");
  const [targetChain, setTargetChain] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [metadataUrl, setMetadataUrl] = useState("");
  const [description, setDescription] = useState("");
  const [rarity, setRarity] = useState<string>("Common");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !contractAddress || !tokenId || !sourceChain) return;
    onMigrate({
      name,
      contractAddress,
      tokenId,
      sourceChain,
      targetChain: targetChain || undefined,
      imageUrl: imageUrl || undefined,
      metadataUrl: metadataUrl || undefined,
      description: description || undefined,
      rarity,
    });
  };

  const inputClass = "w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm placeholder-[#64748B] focus:outline-none focus:border-[#00D4FF]/50 transition-colors";
  const labelClass = "text-[#94A3B8] text-xs font-medium mb-1 block";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-6"
      data-testid="migration-import-form"
    >
      <div className="flex items-center gap-2 mb-6">
        <Upload className="w-5 h-5 text-[#00D4FF]" />
        <h2 className="text-white text-lg font-bold">Import NFT from Another Network</h2>
      </div>

      <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-4 mb-6 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#00D4FF] flex-shrink-0 mt-0.5" />
        <p className="text-[#94A3B8] text-xs leading-relaxed">
          This creates a record of your NFT on Alpha Unlimited. Once imported, you can list it for sale on our marketplace. The original NFT remains on its source blockchain.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>NFT Name *</label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Enter NFT name"
              className={inputClass}
              required
              data-testid="input-migrate-name"
            />
          </div>
          <div>
            <label className={labelClass}>Source Blockchain *</label>
            <select
              value={sourceChain}
              onChange={e => setSourceChain(e.target.value)}
              className={inputClass}
              required
              data-testid="select-source-chain"
            >
              {supportedChains.map(chain => (
                <option key={chain.id} value={chain.id}>
                  {chain.icon} {chain.name} ({chain.symbol})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>Contract Address *</label>
            <input
              type="text"
              value={contractAddress}
              onChange={e => setContractAddress(e.target.value)}
              placeholder="0x..."
              className={inputClass}
              required
              data-testid="input-contract-address"
            />
          </div>
          <div>
            <label className={labelClass}>Token ID *</label>
            <input
              type="text"
              value={tokenId}
              onChange={e => setTokenId(e.target.value)}
              placeholder="Enter token ID"
              className={inputClass}
              required
              data-testid="input-token-id"
            />
          </div>
        </div>

        <div>
          <label className={labelClass}>Target Blockchain (optional)</label>
          <select
            value={targetChain}
            onChange={e => setTargetChain(e.target.value)}
            className={inputClass}
            data-testid="select-target-chain"
          >
            <option value="">Same as source</option>
            {supportedChains.map(chain => (
              <option key={chain.id} value={chain.id}>
                {chain.icon} {chain.name} ({chain.symbol})
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>Image URL (optional)</label>
            <input
              type="url"
              value={imageUrl}
              onChange={e => setImageUrl(e.target.value)}
              placeholder="https://..."
              className={inputClass}
              data-testid="input-image-url"
            />
          </div>
          <div>
            <label className={labelClass}>Metadata URL (optional)</label>
            <input
              type="url"
              value={metadataUrl}
              onChange={e => setMetadataUrl(e.target.value)}
              placeholder="https://..."
              className={inputClass}
              data-testid="input-metadata-url"
            />
          </div>
        </div>

        <div>
          <label className={labelClass}>Description (optional)</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Describe your NFT..."
            className={`${inputClass} resize-none h-20`}
            data-testid="input-migrate-description"
          />
        </div>

        <div>
          <label className={labelClass}>Rarity</label>
          <div className="flex flex-wrap gap-2">
            {RARITY_OPTIONS.map(r => {
              const rc = RARITY_CONFIG[r];
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRarity(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    rarity === r
                      ? `${rc.bg} ${rc.color} ${rc.border}`
                      : "bg-[#0D1117] border-[#1A2942] text-[#64748B] hover:border-[#1A2942]/80"
                  }`}
                  data-testid={`rarity-select-${r.toLowerCase()}`}
                >
                  {r}
                </button>
              );
            })}
          </div>
        </div>

        <Button
          type="submit"
          disabled={isPending || !name || !contractAddress || !tokenId || !sourceChain}
          className="w-full bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 mt-2"
          data-testid="button-import-nft"
        >
          {isPending ? (
            <>Importing...</>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" /> Import NFT
            </>
          )}
        </Button>
      </form>
    </motion.div>
  );
}

export function SellerPaymentGuide() {
  const steps = [
    {
      num: 1,
      title: "Create your NFT and set a price",
      desc: "Design or upload your NFT artwork, set a name, rarity, and USD price. Your NFT will be minted on your chosen blockchain.",
      icon: Sparkles,
    },
    {
      num: 2,
      title: "Provide your wallet address",
      desc: "Enter a wallet address that matches the blockchain you selected. This is where you'll receive payments from buyers.",
      icon: Wallet,
    },
    {
      num: 3,
      title: "List your NFT on the marketplace",
      desc: "Once created, list your NFT for sale. It will appear in the marketplace for all users to browse and purchase.",
      icon: Tag,
    },
    {
      num: 4,
      title: "Buyer sends crypto directly to your wallet",
      desc: "When a buyer purchases your NFT, they send cryptocurrency directly from their connected wallet or exchange to your wallet address — peer-to-peer, no middleman.",
      icon: Globe,
    },
    {
      num: 5,
      title: "Transaction verified & NFT transferred",
      desc: "After the buyer submits their transaction hash, the purchase is verified. The NFT ownership transfers to the buyer and your listing is marked as sold.",
      icon: CheckCircle,
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-6"
      data-testid="seller-payment-guide"
    >
      <div className="flex items-center gap-2 mb-6">
        <DollarSign className="w-5 h-5 text-[#FFD700]" />
        <h2 className="text-white text-lg font-bold">How to Receive Payments as a Seller</h2>
      </div>

      <div className="space-y-4">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <motion.div
              key={step.num}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.1 }}
              className="flex items-start gap-4"
              data-testid={`payment-step-${step.num}`}
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-[#00D4FF]/20 to-[#FFD700]/20 border border-[#1A2942] flex items-center justify-center">
                <span className="text-[#FFD700] font-bold text-sm">{step.num}</span>
              </div>
              <div className="flex-1 bg-[#0D1117] border border-[#1A2942] rounded-lg p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Icon className="w-4 h-4 text-[#00D4FF]" />
                  <h4 className="text-white text-sm font-semibold">{step.title}</h4>
                </div>
                <p className="text-[#94A3B8] text-xs leading-relaxed">{step.desc}</p>
              </div>
              {idx < steps.length - 1 && (
                <div className="hidden md:block absolute left-[19px] mt-10 w-px h-4 bg-[#1A2942]" />
              )}
            </motion.div>
          );
        })}
      </div>

      <div className="mt-6 space-y-3">
        <div className="bg-[#00D4FF]/5 border border-[#00D4FF]/20 rounded-lg p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-[#00D4FF] flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-[#00D4FF] text-xs font-semibold mb-1">Supported Wallets</h4>
            <p className="text-[#94A3B8] text-xs leading-relaxed">
              Use wallets compatible with your chosen blockchain: MetaMask (ETH/BNB/MATIC/AVAX), Phantom (SOL), Trust Wallet (multi-chain), or any wallet supporting the target chain.
            </p>
          </div>
        </div>

        <div className="bg-[#FFD700]/5 border border-[#FFD700]/20 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FFD700] flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-[#FFD700] text-xs font-semibold mb-1">Important</h4>
            <p className="text-[#94A3B8] text-xs leading-relaxed">
              Always double-check your wallet address before listing. Sending funds to an incorrect address is irreversible. Make sure the wallet matches the blockchain network of your NFT.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function PriceSuggestionPanel({ suggestion, onApply }: {
  suggestion: {
    suggestedPrice: number; avgRarityPrice: number;
    avgElementPrice: number; floorPrice: number; traitMultiplier: number;
  } | undefined;
  onApply?: (price: number) => void;
}) {
  if (!suggestion) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-[#FFD700]/5 to-[#00D4FF]/5 border border-[#FFD700]/20 rounded-xl p-4 mb-4"
      data-testid="price-suggestion-panel"
    >
      <div className="flex items-center gap-2 mb-3">
        <BarChart3 className="w-5 h-5 text-[#FFD700]" />
        <h3 className="text-white text-sm font-bold">Dynamic Price Suggestion</h3>
        <span className="bg-[#FFD700]/20 text-[#FFD700] text-[10px] font-bold px-2 py-0.5 rounded-full">AI</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
        <div className="bg-[#0D1117] rounded-lg p-3 text-center">
          <p className="text-[#FFD700] text-lg font-bold">${suggestion.suggestedPrice}</p>
          <p className="text-[#64748B] text-[10px]">Suggested Price</p>
        </div>
        <div className="bg-[#0D1117] rounded-lg p-3 text-center">
          <p className="text-[#00D4FF] text-sm font-bold">${suggestion.avgRarityPrice}</p>
          <p className="text-[#64748B] text-[10px]">Avg Rarity Price</p>
        </div>
        <div className="bg-[#0D1117] rounded-lg p-3 text-center">
          <p className="text-purple-400 text-sm font-bold">${suggestion.avgElementPrice}</p>
          <p className="text-[#64748B] text-[10px]">Avg Element Price</p>
        </div>
        <div className="bg-[#0D1117] rounded-lg p-3 text-center">
          <p className="text-green-400 text-sm font-bold">{suggestion.traitMultiplier}x</p>
          <p className="text-[#64748B] text-[10px]">Rarity Multiplier</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <p className="text-[#94A3B8] text-xs flex-1">
          Floor: <span className="text-white font-medium">${suggestion.floorPrice}</span>
        </p>
        {onApply && (
          <Button
            onClick={() => onApply(suggestion.suggestedPrice)}
            className="bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/30 hover:bg-[#FFD700]/30 text-xs"
            data-testid="button-apply-suggestion"
          >
            <Target className="w-3 h-3 mr-1" /> Apply Suggested Price
          </Button>
        )}
      </div>
    </motion.div>
  );
}

export function NFTAssessmentPanel({ assessment, onAssess, isPending }: {
  assessment?: {
    rarityScore: number; estimatedValueUSD: number; confidenceLevel: number;
    traitAnalysis: Record<string, any>; marketComparison: Record<string, any>;
    recommendation: string;
  };
  onAssess: () => void;
  isPending: boolean;
}) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-[#FFD700]";
    if (score >= 60) return "text-purple-400";
    if (score >= 40) return "text-[#00D4FF]";
    if (score >= 20) return "text-green-400";
    return "text-gray-400";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4"
      data-testid="nft-assessment-panel"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-400" />
          <h3 className="text-white text-sm font-bold">AI Rarity & Value Assessment</h3>
        </div>
        <Button
          onClick={onAssess}
          disabled={isPending}
          className="bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30 text-xs"
          data-testid="button-assess-nft"
        >
          {isPending ? (
            <><Activity className="w-3 h-3 mr-1 animate-spin" /> Analyzing...</>
          ) : (
            <><Brain className="w-3 h-3 mr-1" /> {assessment ? "Re-Assess" : "Assess NFT"}</>
          )}
        </Button>
      </div>

      {assessment && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-[#0D1117] rounded-lg p-3 text-center">
              <Gauge className="w-5 h-5 mx-auto mb-1 text-purple-400" />
              <p className={`text-xl font-bold ${getScoreColor(assessment.rarityScore)}`}>
                {assessment.rarityScore}
              </p>
              <p className="text-[#64748B] text-[10px]">Rarity Score</p>
            </div>
            <div className="bg-[#0D1117] rounded-lg p-3 text-center">
              <DollarSign className="w-5 h-5 mx-auto mb-1 text-[#FFD700]" />
              <p className="text-xl font-bold text-[#FFD700]">${assessment.estimatedValueUSD}</p>
              <p className="text-[#64748B] text-[10px]">Est. Value</p>
            </div>
            <div className="bg-[#0D1117] rounded-lg p-3 text-center">
              <Target className="w-5 h-5 mx-auto mb-1 text-[#00D4FF]" />
              <p className="text-xl font-bold text-[#00D4FF]">{assessment.confidenceLevel}%</p>
              <p className="text-[#64748B] text-[10px]">Confidence</p>
            </div>
          </div>

          {assessment.traitAnalysis && Object.keys(assessment.traitAnalysis).length > 0 && (
            <div>
              <h4 className="text-white text-xs font-semibold mb-2 flex items-center gap-1">
                <Layers className="w-3 h-3 text-purple-400" /> Trait Analysis
              </h4>
              <div className="space-y-1.5">
                {Object.entries(assessment.traitAnalysis).map(([trait, data]: [string, any]) => (
                  <div key={trait} className="flex items-center gap-2">
                    <span className="text-[#94A3B8] text-xs flex-1 truncate">{trait}</span>
                    <div className="w-24 h-1.5 bg-[#1A2942] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#00D4FF] to-purple-400 rounded-full"
                        style={{ width: `${Math.min(100, data.rarityScore || 0)}%` }}
                      />
                    </div>
                    <span className={`text-xs font-bold ${getScoreColor(data.rarityScore || 0)}`}>
                      {data.rarityScore || 0}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {assessment.marketComparison && (
            <div className="bg-[#0D1117] rounded-lg p-3">
              <h4 className="text-white text-xs font-semibold mb-2 flex items-center gap-1">
                <BarChart3 className="w-3 h-3 text-[#00D4FF]" /> Market Position
              </h4>
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#94A3B8]">Current vs Average:</span>
                <span className={`font-bold ${
                  assessment.marketComparison.marketPosition === "Below Market" ? "text-green-400" :
                  assessment.marketComparison.marketPosition === "Above Market" ? "text-red-400" : "text-[#FFD700]"
                }`}>
                  {assessment.marketComparison.marketPosition}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs mt-1">
                <span className="text-[#94A3B8]">Price Ratio:</span>
                <span className="text-white font-medium">{assessment.marketComparison.priceRatio}x</span>
              </div>
            </div>
          )}

          {assessment.recommendation && (
            <div className="bg-purple-500/5 border border-purple-500/20 rounded-lg p-3">
              <p className="text-purple-300 text-xs leading-relaxed flex items-start gap-2">
                <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                {assessment.recommendation}
              </p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

export function NFTStakingSection({ stakes, onStake, onUnstake, onClaim, stakePending, unstakePending, claimPending }: {
  stakes: Array<{
    id: number; nftId: number; apyRate: number; accruedRewards: number;
    status: string; stakedAt: string; nft?: NFT;
  }>;
  onStake?: (nftId: number) => void;
  onUnstake: (nftId: number) => void;
  onClaim: (nftId: number) => void;
  stakePending: boolean;
  unstakePending: boolean;
  claimPending: boolean;
}) {
  const activeStakes = stakes.filter(s => s.status === "active");
  const totalRewards = activeStakes.reduce((sum, s) => {
    const hoursSince = (Date.now() - new Date(s.stakedAt).getTime()) / (1000 * 60 * 60);
    const dailyRate = s.apyRate / 365 / 100;
    const nftValue = s.nft?.priceUSD || 50;
    return sum + (s.accruedRewards || 0) + (nftValue * dailyRate * (hoursSince / 24));
  }, 0);
  const totalStakedValue = activeStakes.reduce((sum, s) => sum + (s.nft?.priceUSD || 0), 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
      data-testid="nft-staking-section"
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 text-center">
          <Lock className="w-5 h-5 text-[#00D4FF] mx-auto mb-2" />
          <p className="text-[#00D4FF] text-xl font-bold">{activeStakes.length}</p>
          <p className="text-[#64748B] text-xs mt-1">Staked NFTs</p>
        </div>
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 text-center">
          <DollarSign className="w-5 h-5 text-[#FFD700] mx-auto mb-2" />
          <p className="text-[#FFD700] text-xl font-bold">${totalStakedValue.toLocaleString()}</p>
          <p className="text-[#64748B] text-xs mt-1">Total Staked Value</p>
        </div>
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 text-center">
          <Gift className="w-5 h-5 text-green-400 mx-auto mb-2" />
          <p className="text-green-400 text-xl font-bold">${totalRewards.toFixed(2)}</p>
          <p className="text-[#64748B] text-xs mt-1">Pending Rewards</p>
        </div>
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 text-center">
          <Percent className="w-5 h-5 text-purple-400 mx-auto mb-2" />
          <p className="text-purple-400 text-xl font-bold">
            {activeStakes.length > 0 ? `${Math.max(...activeStakes.map(s => s.apyRate))}%` : "0%"}
          </p>
          <p className="text-[#64748B] text-xs mt-1">Max APY</p>
        </div>
      </div>

      <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
        <h3 className="text-white text-sm font-bold mb-3 flex items-center gap-2">
          <Percent className="w-4 h-4 text-[#FFD700]" /> Staking Rewards by Rarity
        </h3>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
          {Object.entries(STAKING_APY_BY_RARITY).map(([rarity, apy]) => {
            const rc = RARITY_CONFIG[(rarity as Rarity)] || RARITY_CONFIG.Common;
            return (
              <div key={rarity} className={`${rc.bg} border ${rc.border} rounded-lg p-2 text-center`}>
                <p className={`${rc.color} text-lg font-bold`}>{apy}%</p>
                <p className="text-[#64748B] text-[10px]">{rarity}</p>
              </div>
            );
          })}
        </div>
      </div>

      {activeStakes.length === 0 ? (
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-8 text-center">
          <Lock className="w-10 h-10 text-[#1A2942] mx-auto mb-3" />
          <p className="text-[#94A3B8] text-sm mb-1">No NFTs currently staked</p>
          <p className="text-[#64748B] text-xs">Stake your NFTs from the "My NFTs" tab to start earning passive rewards</p>
        </div>
      ) : (
        <div className="space-y-3">
          <h3 className="text-white text-sm font-bold flex items-center gap-2">
            <Activity className="w-4 h-4 text-green-400" /> Active Stakes
          </h3>
          {activeStakes.map(stake => {
            const rc = RARITY_CONFIG[(stake.nft?.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
            const hoursSince = (Date.now() - new Date(stake.stakedAt).getTime()) / (1000 * 60 * 60);
            const daysSince = Math.floor(hoursSince / 24);
            const dailyRate = stake.apyRate / 365 / 100;
            const nftValue = stake.nft?.priceUSD || 50;
            const currentRewards = (stake.accruedRewards || 0) + (nftValue * dailyRate * (hoursSince / 24));

            return (
              <motion.div
                key={stake.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className={`bg-[#0D1117] border ${rc.border} rounded-xl p-4`}
                data-testid={`stake-card-${stake.nftId}`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-white text-sm font-semibold">{stake.nft?.name || `NFT #${stake.nftId}`}</h4>
                      <span className={`${rc.bg} ${rc.color} text-[10px] font-bold px-2 py-0.5 rounded-full`}>
                        {stake.nft?.rarity || "Common"}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-3 mt-3">
                      <div>
                        <p className="text-[#64748B] text-[10px]">APY</p>
                        <p className="text-green-400 text-sm font-bold">{stake.apyRate}%</p>
                      </div>
                      <div>
                        <p className="text-[#64748B] text-[10px]">Staked</p>
                        <p className="text-white text-sm font-bold">{daysSince}d</p>
                      </div>
                      <div>
                        <p className="text-[#64748B] text-[10px]">Value</p>
                        <p className="text-[#00D4FF] text-sm font-bold">${nftValue}</p>
                      </div>
                      <div>
                        <p className="text-[#64748B] text-[10px]">Rewards</p>
                        <p className="text-[#FFD700] text-sm font-bold">${currentRewards.toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button
                      onClick={() => onClaim(stake.nftId)}
                      disabled={claimPending}
                      className="bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 text-xs"
                      data-testid={`button-claim-${stake.nftId}`}
                    >
                      <Gift className="w-3 h-3 mr-1" /> Claim
                    </Button>
                    <Button
                      onClick={() => onUnstake(stake.nftId)}
                      disabled={unstakePending}
                      className="bg-orange-500/20 text-orange-400 border border-orange-500/30 hover:bg-orange-500/30 text-xs"
                      data-testid={`button-unstake-${stake.nftId}`}
                    >
                      <Unlock className="w-3 h-3 mr-1" /> Unstake
                    </Button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}

const STRATEGY_BLOCKS = [
  { type: "indicator", id: "rsi", label: "RSI", color: "text-blue-400", bgColor: "bg-blue-500/10", borderColor: "border-blue-500/30", desc: "Relative Strength Index" },
  { type: "indicator", id: "macd", label: "MACD", color: "text-green-400", bgColor: "bg-green-500/10", borderColor: "border-green-500/30", desc: "Moving Average Convergence" },
  { type: "indicator", id: "bollinger", label: "Bollinger Bands", color: "text-yellow-400", bgColor: "bg-yellow-500/10", borderColor: "border-yellow-500/30", desc: "Volatility bands" },
  { type: "indicator", id: "ema", label: "EMA Cross", color: "text-purple-400", bgColor: "bg-purple-500/10", borderColor: "border-purple-500/30", desc: "Exponential MA crossover" },
  { type: "indicator", id: "volume", label: "Volume Spike", color: "text-cyan-400", bgColor: "bg-cyan-500/10", borderColor: "border-cyan-500/30", desc: "Unusual volume detection" },
  { type: "indicator", id: "atr", label: "ATR Filter", color: "text-orange-400", bgColor: "bg-orange-500/10", borderColor: "border-orange-500/30", desc: "Volatility filter" },
  { type: "condition", id: "above", label: "Price Above", color: "text-emerald-400", bgColor: "bg-emerald-500/10", borderColor: "border-emerald-500/30", desc: "Price threshold check" },
  { type: "condition", id: "below", label: "Price Below", color: "text-red-400", bgColor: "bg-red-500/10", borderColor: "border-red-500/30", desc: "Price floor check" },
  { type: "condition", id: "crossover", label: "Crossover", color: "text-indigo-400", bgColor: "bg-indigo-500/10", borderColor: "border-indigo-500/30", desc: "Line crossover detection" },
  { type: "action", id: "buy", label: "Buy Signal", color: "text-green-400", bgColor: "bg-green-500/10", borderColor: "border-green-500/30", desc: "Trigger buy order" },
  { type: "action", id: "sell", label: "Sell Signal", color: "text-red-400", bgColor: "bg-red-500/10", borderColor: "border-red-500/30", desc: "Trigger sell order" },
  { type: "action", id: "alert", label: "Alert", color: "text-yellow-400", bgColor: "bg-yellow-500/10", borderColor: "border-yellow-500/30", desc: "Send notification" },
  { type: "risk", id: "stoploss", label: "Stop Loss", color: "text-red-400", bgColor: "bg-red-500/10", borderColor: "border-red-500/30", desc: "Set stop loss level" },
  { type: "risk", id: "takeprofit", label: "Take Profit", color: "text-green-400", bgColor: "bg-green-500/10", borderColor: "border-green-500/30", desc: "Set take profit level" },
  { type: "risk", id: "positionsize", label: "Position Size", color: "text-blue-400", bgColor: "bg-blue-500/10", borderColor: "border-blue-500/30", desc: "Max position sizing" },
] as const;

type StrategyNode = {
  id: string;
  blockId: string;
  label: string;
  type: string;
  params: Record<string, string>;
  position: { x: number; y: number };
};

type StrategyEdge = {
  from: string;
  to: string;
};

export function StrategyBuilder({ strategies, onSave, onDelete, savePending, deletePending }: {
  strategies: Array<{ id: number; name: string; description?: string; nodes: any[]; edges: any[]; isActive: boolean; createdAt: string }>;
  onSave: (data: { name: string; description?: string; nodes: any[]; edges: any[]; isActive?: boolean; id?: number }) => void;
  onDelete: (id: number) => void;
  savePending: boolean;
  deletePending: boolean;
}) {
  const [strategyName, setStrategyName] = useState("My Strategy");
  const [strategyDesc, setStrategyDesc] = useState("");
  const [nodes, setNodes] = useState<StrategyNode[]>([]);
  const [edges, setEdges] = useState<StrategyEdge[]>([]);
  const [editingId, setEditingId] = useState<number | undefined>();
  const [showSaved, setShowSaved] = useState(false);
  const [draggedBlock, setDraggedBlock] = useState<string | null>(null);
  const [connectFrom, setConnectFrom] = useState<string | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  const handleDragStart = (blockId: string) => {
    setDraggedBlock(blockId);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedBlock || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const block = STRATEGY_BLOCKS.find(b => b.id === draggedBlock);
    if (!block) return;
    const newNode: StrategyNode = {
      id: `node_${Date.now()}`,
      blockId: block.id,
      label: block.label,
      type: block.type,
      params: {},
      position: { x: Math.max(0, x - 60), y: Math.max(0, y - 20) },
    };
    setNodes(prev => [...prev, newNode]);
    setDraggedBlock(null);
  }, [draggedBlock]);

  const removeNode = (nodeId: string) => {
    setNodes(prev => prev.filter(n => n.id !== nodeId));
    setEdges(prev => prev.filter(e => e.from !== nodeId && e.to !== nodeId));
    if (selectedNode === nodeId) setSelectedNode(null);
  };

  const handleNodeClick = (nodeId: string) => {
    if (connectFrom) {
      if (connectFrom !== nodeId) {
        setEdges(prev => [...prev, { from: connectFrom, to: nodeId }]);
      }
      setConnectFrom(null);
    } else {
      setSelectedNode(nodeId === selectedNode ? null : nodeId);
    }
  };

  const loadStrategy = (strategy: any) => {
    setStrategyName(strategy.name);
    setStrategyDesc(strategy.description || "");
    setNodes(strategy.nodes || []);
    setEdges(strategy.edges || []);
    setEditingId(strategy.id);
    setShowSaved(false);
  };

  const clearCanvas = () => {
    setNodes([]);
    setEdges([]);
    setEditingId(undefined);
    setStrategyName("My Strategy");
    setStrategyDesc("");
  };

  const blockCategories = [
    { label: "Indicators", type: "indicator", icon: Activity },
    { label: "Conditions", type: "condition", icon: CircleDot },
    { label: "Actions", type: "action", icon: Play },
    { label: "Risk Mgmt", type: "risk", icon: Shield },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
      data-testid="strategy-builder"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <input
            value={strategyName}
            onChange={e => setStrategyName(e.target.value)}
            className="bg-transparent text-white text-lg font-bold border-b border-transparent hover:border-[#1A2942] focus:border-[#00D4FF] outline-none transition-colors px-1"
            data-testid="input-strategy-name"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="bg-[#161B22] border-[#1A2942] text-[#94A3B8] hover:bg-[#1A2942] text-xs"
            onClick={() => setShowSaved(!showSaved)}
            data-testid="button-saved-strategies"
          >
            <Layers className="w-3 h-3 mr-1" /> Saved ({strategies.length})
          </Button>
          <Button
            variant="outline"
            className="bg-[#161B22] border-[#1A2942] text-[#94A3B8] hover:bg-[#1A2942] text-xs"
            onClick={clearCanvas}
            data-testid="button-clear-canvas"
          >
            <X className="w-3 h-3 mr-1" /> Clear
          </Button>
          <Button
            onClick={() => onSave({ name: strategyName, description: strategyDesc, nodes, edges, id: editingId })}
            disabled={savePending || nodes.length === 0 || !strategyName.trim()}
            className="bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 text-xs"
            data-testid="button-save-strategy"
          >
            <Save className="w-3 h-3 mr-1" /> {savePending ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {showSaved && strategies.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4 overflow-hidden"
          >
            <h4 className="text-white text-sm font-bold mb-3">Saved Strategies</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {strategies.map(s => (
                <div key={s.id} className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-3 hover:border-[#00D4FF]/30 transition-all">
                  <div className="flex items-center justify-between mb-1">
                    <h5 className="text-white text-xs font-semibold truncate">{s.name}</h5>
                    <div className="flex gap-1">
                      <button
                        onClick={() => loadStrategy(s)}
                        className="p-1 text-[#00D4FF] hover:bg-[#00D4FF]/10 rounded"
                        data-testid={`button-load-strategy-${s.id}`}
                      >
                        <Play className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onDelete(s.id)}
                        className="p-1 text-red-400 hover:bg-red-500/10 rounded"
                        data-testid={`button-delete-strategy-${s.id}`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                  <p className="text-[#64748B] text-[10px]">
                    {(s.nodes || []).length} blocks / {new Date(s.createdAt).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid lg:grid-cols-[200px_1fr] gap-4">
        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-3 space-y-3 max-h-[500px] overflow-y-auto">
          <h4 className="text-white text-xs font-bold flex items-center gap-1">
            <GripVertical className="w-3 h-3 text-[#64748B]" /> Drag blocks to canvas
          </h4>
          {blockCategories.map(cat => {
            const CatIcon = cat.icon;
            const catBlocks = STRATEGY_BLOCKS.filter(b => b.type === cat.type);
            return (
              <div key={cat.type}>
                <p className="text-[#64748B] text-[10px] font-bold uppercase mb-1.5 flex items-center gap-1">
                  <CatIcon className="w-3 h-3" /> {cat.label}
                </p>
                <div className="space-y-1">
                  {catBlocks.map(block => (
                    <div
                      key={block.id}
                      draggable
                      onDragStart={() => handleDragStart(block.id)}
                      className={`${block.bgColor} border ${block.borderColor} rounded-lg px-2.5 py-1.5 cursor-grab active:cursor-grabbing hover:opacity-80 transition-opacity`}
                      data-testid={`block-${block.id}`}
                    >
                      <p className={`${block.color} text-xs font-semibold`}>{block.label}</p>
                      <p className="text-[#64748B] text-[9px]">{block.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div
          ref={canvasRef}
          className="bg-[#0D1117] border border-[#1A2942] rounded-xl min-h-[400px] relative overflow-hidden"
          onDragOver={e => e.preventDefault()}
          onDrop={handleDrop}
          data-testid="strategy-canvas"
        >
          <div className="absolute inset-0" style={{
            backgroundImage: "radial-gradient(circle, #1A2942 1px, transparent 1px)",
            backgroundSize: "20px 20px",
          }} />

          <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
            {edges.map((edge, idx) => {
              const fromNode = nodes.find(n => n.id === edge.from);
              const toNode = nodes.find(n => n.id === edge.to);
              if (!fromNode || !toNode) return null;
              return (
                <line
                  key={idx}
                  x1={fromNode.position.x + 60}
                  y1={fromNode.position.y + 20}
                  x2={toNode.position.x + 60}
                  y2={toNode.position.y + 20}
                  stroke="#00D4FF"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  opacity="0.5"
                />
              );
            })}
          </svg>

          {nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center" style={{ zIndex: 2 }}>
              <div className="text-center">
                <Layers className="w-10 h-10 text-[#1A2942] mx-auto mb-2" />
                <p className="text-[#64748B] text-sm mb-1">Drag & drop blocks here</p>
                <p className="text-[#3A4A5C] text-xs">Build your custom trading strategy visually</p>
              </div>
            </div>
          )}

          {nodes.map(node => {
            const block = STRATEGY_BLOCKS.find(b => b.id === node.blockId);
            if (!block) return null;
            const isSelected = selectedNode === node.id;
            const isConnecting = connectFrom === node.id;
            return (
              <div
                key={node.id}
                className={`absolute ${block.bgColor} border-2 ${isSelected ? "border-[#00D4FF]" : isConnecting ? "border-[#FFD700]" : block.borderColor} rounded-lg px-3 py-2 cursor-pointer hover:shadow-lg transition-all group`}
                style={{ left: node.position.x, top: node.position.y, zIndex: isSelected ? 10 : 3, minWidth: 120 }}
                onClick={() => handleNodeClick(node.id)}
                data-testid={`canvas-node-${node.id}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className={`${block.color} text-xs font-semibold`}>{node.label}</span>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={e => { e.stopPropagation(); setConnectFrom(node.id); }}
                      className="p-0.5 text-[#00D4FF] hover:bg-[#00D4FF]/10 rounded"
                      title="Connect to another block"
                    >
                      <ArrowRight className="w-3 h-3" />
                    </button>
                    <button
                      onClick={e => { e.stopPropagation(); removeNode(node.id); }}
                      className="p-0.5 text-red-400 hover:bg-red-500/10 rounded"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                <p className="text-[#64748B] text-[9px] mt-0.5">{block.desc}</p>
              </div>
            );
          })}

          {connectFrom && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-[#FFD700]/20 text-[#FFD700] text-xs px-3 py-1.5 rounded-full border border-[#FFD700]/30" style={{ zIndex: 20 }}>
              Click another block to connect, or click empty space to cancel
            </div>
          )}
        </div>
      </div>

      <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <Info className="w-4 h-4 text-[#00D4FF]" />
          <h4 className="text-white text-xs font-semibold">How to Use the Strategy Builder</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs text-[#94A3B8]">
          <div className="flex items-start gap-2">
            <span className="text-[#00D4FF] font-bold text-sm">1</span>
            <p>Drag indicator blocks (RSI, MACD, etc.) onto the canvas</p>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#00D4FF] font-bold text-sm">2</span>
            <p>Add condition blocks to define entry/exit rules</p>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#00D4FF] font-bold text-sm">3</span>
            <p>Connect blocks by clicking one, then clicking another</p>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#00D4FF] font-bold text-sm">4</span>
            <p>Add risk management and save your strategy</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
