/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha ThirdPartyBots™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_ea7a9ff40256ef153e401286
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bot, Link2, ExternalLink, Settings, Check, X, AlertTriangle,
  Key, Server, RefreshCw, Zap, Lock, Crown, Plug, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface BotConnection {
  id: string;
  name: string;
  type: 'freqtrade' | '3commas' | 'cryptohopper' | 'custom';
  status: 'connected' | 'disconnected' | 'error';
  apiUrl?: string;
  lastSync?: Date;
  stats?: {
    activeTrades: number;
    profit: number;
    profitPercent: number;
  };
}

const BOT_PROVIDERS = [
  { 
    id: 'freqtrade', 
    name: 'Freqtrade', 
    description: 'Free, open-source Python trading bot',
    icon: '🤖',
    features: ['ML Strategy', 'Backtesting', 'Custom Indicators'],
    tier: 'pro'
  },
  { 
    id: '3commas', 
    name: '3Commas', 
    description: 'Popular multi-exchange trading platform',
    icon: '📊',
    features: ['Grid Bots', 'DCA Bots', 'Copy Trading'],
    tier: 'pro'
  },
  { 
    id: 'cryptohopper', 
    name: 'Cryptohopper', 
    description: 'AI-powered trading automation',
    icon: '🦘',
    features: ['AI Strategies', 'Marketplace', 'Signals'],
    tier: 'alpha'
  },
  { 
    id: 'custom', 
    name: 'Custom API', 
    description: 'Connect your own trading bot via REST API',
    icon: '⚙️',
    features: ['REST API', 'WebSocket', 'Custom Logic'],
    tier: 'alpha'
  },
];

export function ThirdPartyBots({ userTier = 'free' }: { userTier?: string }) {
  const { toast } = useToast();
  const [connections, setConnections] = useState<BotConnection[]>([]);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [apiUrl, setApiUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);

  const canConnect = userTier === 'premium' || userTier === 'platinum' || userTier === 'alpha';

  useEffect(() => {
    const saved = localStorage.getItem('alpha-bot-connections');
    if (saved) {
      setConnections(JSON.parse(saved).map((c: any) => ({
        ...c,
        lastSync: c.lastSync ? new Date(c.lastSync) : undefined
      })));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('alpha-bot-connections', JSON.stringify(connections));
  }, [connections]);

  useEffect(() => {
  }, []);

  const connectBot = async () => {
    if (!selectedProvider || !apiUrl) {
      toast({ title: 'Missing Information', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }

    setIsConnecting(true);
    
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newConnection: BotConnection = {
      id: `conn_${Date.now()}`,
      name: BOT_PROVIDERS.find(p => p.id === selectedProvider)?.name || 'Custom Bot',
      type: selectedProvider as any,
      status: 'connected',
      apiUrl,
      lastSync: new Date(),
      stats: {
        activeTrades: 0,
        profit: 0,
        profitPercent: 0
      }
    };

    setConnections([...connections, newConnection]);
    setShowConnectModal(false);
    setSelectedProvider(null);
    setApiUrl('');
    setApiKey('');
    setApiSecret('');
    setIsConnecting(false);
    
    toast({ title: 'Bot Connected', description: `${newConnection.name} is now syncing with your account` });
  };

  const disconnectBot = (id: string) => {
    setConnections(prev => prev.filter(c => c.id !== id));
    toast({ title: 'Bot Disconnected', description: 'Connection has been removed' });
  };

  const syncBot = (id: string) => {
    setConnections(prev => prev.map(c => 
      c.id === id ? { ...c, lastSync: new Date() } : c
    ));
    toast({ title: 'Syncing...', description: 'Fetching latest data from bot' });
  };

  return (
    <div className="space-y-4" data-testid="third-party-bots">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Plug className="text-orange-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">3rd Party Bot Connections</h2>
            <p className="text-xs text-gray-500">Connect external trading bots to your dashboard</p>
          </div>
        </div>
        {canConnect ? (
          <Button
            onClick={() => setShowConnectModal(true)}
            className="bg-orange-500 hover:bg-orange-600"
            size="sm"
            data-testid="button-connect-bot"
          >
            <Link2 size={16} className="mr-1" /> Connect Bot
          </Button>
        ) : (
          <Button
            variant="outline"
            size="sm"
            className="border-orange-500/50 text-orange-400"
            data-testid="button-upgrade-for-bots"
          >
            <Crown size={16} className="mr-1" /> Pro Required
          </Button>
        )}
      </div>

      {!canConnect && (
        <div className="p-4 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border border-orange-500/30 rounded-lg">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <Lock className="text-orange-400 flex-shrink-0" size={32} />
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white">Unlock 3rd Party Bot Integration</div>
              <div className="text-sm text-gray-400">
                Connect Freqtrade, 3Commas, Cryptohopper, and custom bots with Pro or Enterprise plans
              </div>
            </div>
            <Button className="bg-orange-500 hover:bg-orange-600 flex-shrink-0 w-full sm:w-auto" size="sm">
              Upgrade to Pro
            </Button>
          </div>
        </div>
      )}

      {canConnect && connections.length === 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12 bg-gray-900/50 rounded-lg border border-gray-800"
        >
          <Plug size={48} className="mx-auto text-gray-600 mb-4" />
          <h3 className="text-lg font-medium text-gray-400 mb-2">No Bots Connected</h3>
          <p className="text-sm text-gray-500 mb-4">Connect your Freqtrade, 3Commas, or custom trading bots</p>
          <Button onClick={() => setShowConnectModal(true)} className="bg-orange-500 hover:bg-orange-600">
            <Link2 size={16} className="mr-1" /> Connect Your First Bot
          </Button>
        </motion.div>
      )}

      {connections.length > 0 && (
        <div className="space-y-3">
          {connections.map(conn => (
            <motion.div
              key={conn.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-lg border ${
                conn.status === 'connected' 
                  ? 'bg-gray-900/80 border-green-500/30' 
                  : conn.status === 'error'
                  ? 'bg-gray-900/80 border-red-500/30'
                  : 'bg-gray-900/50 border-gray-800'
              }`}
              data-testid={`bot-connection-${conn.id}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">
                    {BOT_PROVIDERS.find(p => p.id === conn.type)?.icon || '🤖'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white">{conn.name}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        conn.status === 'connected' ? 'bg-green-500/20 text-green-400'
                        : conn.status === 'error' ? 'bg-red-500/20 text-red-400'
                        : 'bg-gray-500/20 text-gray-400'
                      }`}>
                        {conn.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 flex items-center gap-2">
                      <span>{conn.apiUrl}</span>
                      {conn.lastSync && (
                        <span className="text-gray-600">• Synced {new Date(conn.lastSync).toLocaleTimeString()}</span>
                      )}
                    </div>
                  </div>
                </div>

                {conn.stats && (
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Active Trades</div>
                      <div className="font-bold text-white">{conn.stats.activeTrades}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Profit</div>
                      <div className="font-bold text-gray-400 text-xs">
                        Connect exchange to view
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-500">ROI</div>
                      <div className="font-bold text-gray-400 text-xs">
                        Awaiting sync
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => syncBot(conn.id)}
                    className="p-2 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-colors"
                    title="Sync now"
                    data-testid={`button-sync-${conn.id}`}
                  >
                    <RefreshCw size={16} />
                  </button>
                  <button
                    onClick={() => disconnectBot(conn.id)}
                    className="p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"
                    title="Disconnect"
                    data-testid={`button-disconnect-${conn.id}`}
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {showConnectModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
            onClick={() => setShowConnectModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900 border border-gray-700 rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
              data-testid="connect-bot-modal"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Connect Trading Bot</h3>
                <button onClick={() => setShowConnectModal(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Select Provider</label>
                  <div className="grid grid-cols-2 gap-2">
                    {BOT_PROVIDERS.map(provider => {
                      const isLocked = provider.tier === 'alpha' && userTier !== 'alpha';
                      return (
                        <button
                          key={provider.id}
                          onClick={() => !isLocked && setSelectedProvider(provider.id)}
                          disabled={isLocked}
                          className={`p-3 rounded-lg border text-left transition-colors ${
                            selectedProvider === provider.id
                              ? 'bg-orange-500/20 border-orange-500/50'
                              : isLocked
                              ? 'bg-gray-800/30 border-gray-800 opacity-50 cursor-not-allowed'
                              : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                          }`}
                          data-testid={`button-provider-${provider.id}`}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xl">{provider.icon}</span>
                            <span className="font-medium text-white">{provider.name}</span>
                            {isLocked && <Lock size={12} className="text-gray-500" />}
                          </div>
                          <div className="text-xs text-gray-500">{provider.description}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {selectedProvider && (
                  <>
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">API URL</label>
                      <input
                        type="text"
                        value={apiUrl}
                        onChange={e => setApiUrl(e.target.value)}
                        placeholder={selectedProvider === 'freqtrade' ? 'http://localhost:8080' : 'https://api.example.com'}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                        data-testid="input-api-url"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">API Key (Optional)</label>
                      <input
                        type="password"
                        value={apiKey}
                        onChange={e => setApiKey(e.target.value)}
                        placeholder="Your API key"
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                        autoComplete="new-password"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-testid="input-bot-api-key"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">API Secret (Optional)</label>
                      <input
                        type="password"
                        value={apiSecret}
                        onChange={e => setApiSecret(e.target.value)}
                        placeholder="Your API secret"
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                        autoComplete="new-password"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-testid="input-bot-api-secret"
                      />
                    </div>

                    <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                      <div className="text-xs text-blue-400 mb-1 flex items-center gap-1">
                        <Activity size={12} /> {BOT_PROVIDERS.find(p => p.id === selectedProvider)?.name} Features
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {BOT_PROVIDERS.find(p => p.id === selectedProvider)?.features.map(f => (
                          <span key={f} className="px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded text-xs">{f}</span>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <Button 
                  onClick={connectBot} 
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  disabled={!selectedProvider || !apiUrl || isConnecting}
                  data-testid="button-confirm-connect"
                >
                  {isConnecting ? (
                    <><RefreshCw size={16} className="mr-2 animate-spin" /> Connecting...</>
                  ) : (
                    <><Zap size={16} className="mr-2" /> Connect Bot</>
                  )}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
