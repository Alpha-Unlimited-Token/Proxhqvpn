/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Server-Side Bot Management Console™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Server-Side Bot Engine™
 * - 24/7 Autonomous Trading™
 * - Bot Fleet Management Protocol™
 * - Real-Time Position Tracking™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_9a2f334c610aa3aba1c207fb
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Server, Play, Pause, Trash2, Plus, Bot, Activity, Clock,
  CheckCircle, XCircle, AlertTriangle, Info, RefreshCw, ChevronDown,
  ChevronUp, Zap, Shield, ArrowUpDown, Cpu, Eye, Settings, Upload,
  GitMerge, Filter, Target, Layers, TrendingUp, BarChart3, Percent,
  Pencil, Save, Brain
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

interface ServerBot {
  id: number;
  userId: string;
  name: string;
  type: string;
  pair: string;
  exchange: string;
  status: string;
  settings: Record<string, any>;
  activeTech: string[];
  activeFilters: string[];
  lastSignalData: Record<string, any> | null;
  lastTradeAt: string | null;
  totalTrades: number;
  totalPnl: number;
  createdAt: string;
  updatedAt: string;
  openPosition?: {
    entryPrice: number;
    quantity: number;
    entryTime: number;
    side: string;
    investment: number;
  } | null;
}

interface BotLog {
  id: number;
  botId: number;
  logType: string;
  message: string;
  data: Record<string, any> | null;
  createdAt: string;
}

const BOT_TYPE_LABELS: Record<string, string> = {
  grid: 'Grid Bot', dca: 'DCA Bot', trailing_stop: 'Trailing Stop',
  twap: 'TWAP Bot', signal: 'Signal Bot', arbitrage: 'Arbitrage Bot',
  martingale: 'Martingale Bot', infinity_grid: 'Infinity Grid',
  leveraged_grid: 'Leveraged Grid', rebalancing: 'Rebalancing Bot',
  smart_trade: 'SmartTrade Bot', reverse_grid: 'Reverse Grid',
  auto_invest: 'Auto-Invest', spot_futures_arb: 'Spot-Futures Arb',
};

const DEFAULT_TRADING_PAIRS = [
  'BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT', 'BNB/USDT',
  'DOGE/USDT', 'AVAX/USDT', 'ADA/USDT', 'DOT/USDT', 'LINK/USDT',
];

const ALL_EXCHANGES = [
  { id: 'kraken', name: 'Kraken' },
  { id: 'binance', name: 'Binance' },
  { id: 'binanceus', name: 'Binance.US' },
  { id: 'coinbase', name: 'Coinbase' },
  { id: 'bybit', name: 'Bybit' },
  { id: 'okx', name: 'OKX' },
  { id: 'kucoin', name: 'KuCoin' },
  { id: 'bitget', name: 'Bitget' },
  { id: 'gateio', name: 'Gate.io' },
  { id: 'mexc', name: 'MEXC' },
  { id: 'htx', name: 'HTX' },
  { id: 'gemini', name: 'Gemini' },
  { id: 'bitstamp', name: 'Bitstamp' },
  { id: 'crypto.com', name: 'Crypto.com' },
];

const PROPRIETARY_TECH = [
  { id: 'acm', name: 'Alpha Convergence Matrix™', shortName: 'ACM', color: '#FFD700', boost: '+8%', desc: 'Momentum, volume, smart money flow, trend & volatility' },
  { id: 'qfrm', name: 'Quantum Flow Resonance Matrix™', shortName: 'QFRM', color: '#00D4FF', boost: '+7%', desc: 'Price jerk, resonance frequencies, entropy gradients' },
  { id: 'bif', name: 'Blockchain Intelligence Filter™', shortName: 'BIF', color: '#A855F7', boost: '+6%', desc: 'Network congestion, miner selling, hash rate momentum' },
  { id: 'sbpe', name: 'Stochastic Block Prediction Engine™', shortName: 'SBPE', color: '#22C55E', boost: '+5%', desc: 'Block direction prediction via stochastic phase analysis' },
  { id: 'ance', name: 'Adaptive Neural Confluence Engine™', shortName: 'ANCE', color: '#F97316', boost: '+12%', desc: '7-layer AI: Hull MA, VWAP, RSI, MACD, Fibonacci, Entropy, Volume' },
  { id: 'ance2', name: 'ANCE² Meta-Intelligence Layer™', shortName: 'ANCE²', color: '#EF4444', boost: '+15%', desc: 'Second intelligence layer analyzing ANCE output' },
];

const ADVANCED_FILTERS = [
  { id: 'order_flow', name: 'Order Flow Imbalance', shortName: 'OFI', color: '#3B82F6', boost: '+3%' },
  { id: 'fair_value_gap', name: 'Fair Value Gap', shortName: 'FVG', color: '#8B5CF6', boost: '+3%' },
  { id: 'absorption', name: 'Absorption Detector', shortName: 'ABS', color: '#06B6D4', boost: '+2.5%' },
  { id: 'fractal_energy', name: 'Fractal Energy', shortName: 'FE', color: '#10B981', boost: '+2.5%' },
  { id: 'wyckoff', name: 'Wyckoff Phase Detector', shortName: 'WYC', color: '#F59E0B', boost: '+3.5%' },
  { id: 'entropy', name: 'Entropy Regime', shortName: 'ENT', color: '#EC4899', boost: '+3%' },
  { id: 'hurst', name: 'Hurst Regime', shortName: 'HUR', color: '#14B8A6', boost: '+3%' },
  { id: 'delta_divergence', name: 'Delta Divergence', shortName: 'DD', color: '#F43F5E', boost: '+3.5%' },
];

export function ServerBotManager() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [bots, setBots] = useState<ServerBot[]>([]);
  const [engineRunning, setEngineRunning] = useState(false);
  const [engineStatus, setEngineStatus] = useState<{
    wsConnected: boolean;
    subscribedPairs: string[];
    activeBotCount: number;
    livePriceCount: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [editingBotId, setEditingBotId] = useState<number | null>(null);
  const [expandedBot, setExpandedBot] = useState<number | null>(null);
  const [botLogs, setBotLogs] = useState<Record<number, BotLog[]>>({});
  const [settingPositionFor, setSettingPositionFor] = useState<number | null>(null);
  const [positionForm, setPositionForm] = useState({ entryPrice: '', quantity: '', investment: '' });
  const [logsLoading, setLogsLoading] = useState<Record<number, boolean>>({});

  const [newBot, setNewBot] = useState({
    name: '', type: 'signal', pair: 'XRP/USDT', exchange: 'kraken',
    paperTrading: false, ocoEnabled: true,
    autoCooldown: false, autoTakeProfit: false, autoStopLoss: false, autoThreshold: false, autoTrailing: false,
    investment: 100, takeProfit: 10, stopLoss: 5,
    trailingPercent: 3, cooldownSeconds: 60,
    signalThreshold: 70,
    maxDailyTrades: 0, maxDailyLossPercent: 5,
    positionSizePercent: 100,
    signalSource: 'ai',
    upperPrice: 0, lowerPrice: 0, gridCount: 10,
    safetyOrders: 3, safetyOrderSize: 50, safetyOrderStep: 2,
    martingaleMultiplier: 2, maxMartingaleSteps: 5,
    orderAmount: 100, frequency: 'daily', maxOrders: 30,
    activationPrice: 0, minSpread: 0.5,
    bridgeFusion: false, bridgeFusionMode: 'auto' as 'auto' | 'manual',
  });
  const [selectedTech, setSelectedTech] = useState<string[]>([]);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [exchangePairs, setExchangePairs] = useState<string[]>(DEFAULT_TRADING_PAIRS);
  const [pairsLoading, setPairsLoading] = useState(false);
  const [pairSearch, setPairSearch] = useState('');
  const [connectedExchanges, setConnectedExchanges] = useState<string[]>([]);
  const [showTechPanel, setShowTechPanel] = useState(false);
  const [volatilityData, setVolatilityData] = useState<{
    available: boolean;
    dailySwing?: number;
    volatilityLevel?: string;
    suggestedCooldown?: number;
    currentPrice?: number;
    high24h?: number;
    low24h?: number;
    autoParams?: {
      cooldownMs: number;
      takeProfit: number;
      stopLoss: number;
      trailingPercent: number;
      signalThreshold: number;
      dailySwing: number;
      volatilityLevel: string;
      trendDirection: string;
      trendStrength: number;
      rsi: number;
    };
  } | null>(null);

  const toggleTech = (id: string) => {
    setSelectedTech(prev => prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]);
  };
  const toggleFilter = (id: string) => {
    setSelectedFilters(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const hasAnyAuto = newBot.autoCooldown || newBot.autoTakeProfit || newBot.autoStopLoss || newBot.autoThreshold || newBot.autoTrailing;

  const fetchVolatility = useCallback(async (pair: string, bot: typeof newBot) => {
    try {
      const params = new URLSearchParams({
        baseCooldown: String(bot.cooldownSeconds),
        takeProfit: String(bot.takeProfit),
        stopLoss: String(bot.stopLoss),
        trailingPercent: String(bot.trailingPercent),
        signalThreshold: String(bot.signalThreshold),
      });
      const res = await fetch(`/api/server-bots/volatility/${encodeURIComponent(pair)}?${params}`);
      if (res.ok) {
        const data = await res.json();
        setVolatilityData(data);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!isAuthenticated || !showCreate || !hasAnyAuto) return;
    fetchVolatility(newBot.pair, newBot);
    const interval = setInterval(() => fetchVolatility(newBot.pair, newBot), 10000);
    return () => clearInterval(interval);
  }, [isAuthenticated, showCreate, newBot.pair, newBot.cooldownSeconds, newBot.takeProfit, newBot.stopLoss, newBot.trailingPercent, newBot.signalThreshold, hasAnyAuto, fetchVolatility]);

  const fetchBots = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/server-bots');
      if (res.ok) {
        const data = await res.json();
        setBots(data.bots);
        setEngineRunning(data.engineRunning);
        if (data.engineStatus) setEngineStatus(data.engineStatus);
      }
    } catch {} finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => { fetchBots(); }, [fetchBots]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const interval = setInterval(fetchBots, 15000);
    return () => clearInterval(interval);
  }, [isAuthenticated, fetchBots]);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetch('/api/trading/exchanges')
      .then(r => r.ok ? r.json() : [])
      .then(data => {
        const ids = (Array.isArray(data) ? data : []).map((c: any) => c.exchangeName || c.exchange || '').filter(Boolean);
        setConnectedExchanges(ids);
      })
      .catch(() => {});
  }, [isAuthenticated]);

  const fetchExchangePairs = useCallback(async (exchange: string) => {
    setPairsLoading(true);
    setPairSearch('');
    try {
      const res = await fetch(`/api/server-bots/exchange-pairs/${encodeURIComponent(exchange)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.pairs && data.pairs.length > 0) {
          setExchangePairs(data.pairs);
          if (!data.pairs.includes(newBot.pair)) {
            setNewBot(prev => ({ ...prev, pair: data.pairs[0] }));
          }
        } else {
          setExchangePairs(DEFAULT_TRADING_PAIRS);
        }
      } else {
        setExchangePairs(DEFAULT_TRADING_PAIRS);
      }
    } catch {
      setExchangePairs(DEFAULT_TRADING_PAIRS);
    } finally {
      setPairsLoading(false);
    }
  }, [newBot.pair]);

  useEffect(() => {
    if (!isAuthenticated || !showCreate) return;
    fetchExchangePairs(newBot.exchange);
  }, [isAuthenticated, showCreate, newBot.exchange, fetchExchangePairs]);

  const filteredPairs = pairSearch
    ? exchangePairs.filter(p => p.toLowerCase().includes(pairSearch.toLowerCase()))
    : exchangePairs;

  const fetchLogs = async (botId: number) => {
    setLogsLoading(prev => ({ ...prev, [botId]: true }));
    try {
      const res = await fetch(`/api/server-bots/${botId}/logs?limit=30`);
      if (res.ok) {
        const logs = await res.json();
        setBotLogs(prev => ({ ...prev, [botId]: logs }));
      }
    } catch {} finally {
      setLogsLoading(prev => ({ ...prev, [botId]: false }));
    }
  };

  const createBot = async () => {
    if (!newBot.name.trim()) {
      toast({ title: 'Enter a bot name', variant: 'destructive' });
      return;
    }
    try {
      const res = await fetch('/api/server-bots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newBot.name,
          type: newBot.type,
          pair: newBot.pair,
          exchange: newBot.exchange,
          settings: {
            investment: newBot.investment,
            takeProfit: newBot.takeProfit,
            stopLoss: newBot.stopLoss,
            trailingPercent: newBot.trailingPercent,
            cooldownSeconds: newBot.cooldownSeconds,
            signalThreshold: newBot.signalThreshold,
            paperTrading: newBot.paperTrading,
            ocoEnabled: newBot.ocoEnabled,
            autoCooldown: newBot.autoCooldown,
            autoTakeProfit: newBot.autoTakeProfit,
            autoStopLoss: newBot.autoStopLoss,
            autoThreshold: newBot.autoThreshold,
            autoTrailing: newBot.autoTrailing,
            maxDailyTrades: newBot.maxDailyTrades,
            maxDailyLossPercent: newBot.maxDailyLossPercent,
            positionSizePercent: newBot.positionSizePercent,
            signalSource: newBot.signalSource,
            upperPrice: newBot.upperPrice,
            lowerPrice: newBot.lowerPrice,
            gridCount: newBot.gridCount,
            safetyOrders: newBot.safetyOrders,
            safetyOrderSize: newBot.safetyOrderSize,
            safetyOrderStep: newBot.safetyOrderStep,
            martingaleMultiplier: newBot.martingaleMultiplier,
            maxMartingaleSteps: newBot.maxMartingaleSteps,
            orderAmount: newBot.orderAmount,
            frequency: newBot.frequency,
            maxOrders: newBot.maxOrders,
            activationPrice: newBot.activationPrice,
            minSpread: newBot.minSpread,
            bridgeFusion: newBot.bridgeFusion,
            bridgeFusionMode: newBot.bridgeFusionMode,
            bridgeFusionFilters: selectedFilters,
          },
          activeTech: selectedTech,
          activeFilters: selectedFilters,
        }),
      });
      if (res.ok) {
        toast({ title: 'Server bot created!' });
        setShowCreate(false);
        setShowTechPanel(false);
        setSelectedTech([]);
        setSelectedFilters([]);
        setNewBot({ name: '', type: 'signal', pair: 'XRP/USDT', exchange: 'kraken', paperTrading: false, ocoEnabled: true, autoCooldown: false, autoTakeProfit: false, autoStopLoss: false, autoThreshold: false, autoTrailing: false, investment: 100, takeProfit: 10, stopLoss: 5, trailingPercent: 3, cooldownSeconds: 60, signalThreshold: 70, maxDailyTrades: 0, maxDailyLossPercent: 5, positionSizePercent: 100, signalSource: 'ai', upperPrice: 0, lowerPrice: 0, gridCount: 10, safetyOrders: 3, safetyOrderSize: 50, safetyOrderStep: 2, martingaleMultiplier: 2, maxMartingaleSteps: 5, orderAmount: 100, frequency: 'daily', maxOrders: 30, activationPrice: 0, minSpread: 0.5, bridgeFusion: false, bridgeFusionMode: 'auto' as 'auto' | 'manual' });
        fetchBots();
      } else {
        const err = await res.json();
        toast({ title: err.message, variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: e.message, variant: 'destructive' });
    }
  };

  const startBot = async (id: number) => {
    try {
      const res = await fetch(`/api/server-bots/${id}/start`, { method: 'POST' });
      if (res.ok) {
        toast({ title: 'Bot started! It will run 24/7 on the server.' });
        fetchBots();
      } else {
        const err = await res.json();
        toast({ title: err.message, variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: e.message, variant: 'destructive' });
    }
  };

  const pauseBot = async (id: number) => {
    try {
      const res = await fetch(`/api/server-bots/${id}/pause`, { method: 'POST' });
      if (res.ok) {
        toast({ title: 'Bot paused' });
        fetchBots();
      }
    } catch (e: any) {
      toast({ title: e.message, variant: 'destructive' });
    }
  };

  const deleteBot = async (id: number) => {
    try {
      const res = await fetch(`/api/server-bots/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast({ title: 'Bot deleted' });
        fetchBots();
      }
    } catch (e: any) {
      toast({ title: e.message, variant: 'destructive' });
    }
  };

  const startEditing = (bot: ServerBot) => {
    const s = bot.settings as any || {};
    setNewBot({
      name: bot.name,
      type: bot.type,
      pair: bot.pair,
      exchange: bot.exchange,
      paperTrading: s.paperTrading || false,
      ocoEnabled: s.ocoEnabled !== undefined ? s.ocoEnabled : true,
      autoCooldown: s.autoCooldown || false,
      autoTakeProfit: s.autoTakeProfit || false,
      autoStopLoss: s.autoStopLoss || false,
      autoThreshold: s.autoThreshold || false,
      autoTrailing: s.autoTrailing || false,
      investment: s.investment || 100,
      takeProfit: s.takeProfit || 10,
      stopLoss: s.stopLoss || 5,
      trailingPercent: s.trailingPercent || 3,
      cooldownSeconds: s.cooldownSeconds || 60,
      signalThreshold: s.signalThreshold || 70,
      maxDailyTrades: s.maxDailyTrades || 0,
      maxDailyLossPercent: s.maxDailyLossPercent || 5,
      positionSizePercent: s.positionSizePercent || 100,
      signalSource: s.signalSource || 'ai',
      upperPrice: s.upperPrice || 0,
      lowerPrice: s.lowerPrice || 0,
      gridCount: s.gridCount || 10,
      safetyOrders: s.safetyOrders || 3,
      safetyOrderSize: s.safetyOrderSize || 50,
      safetyOrderStep: s.safetyOrderStep || 2,
      martingaleMultiplier: s.martingaleMultiplier || 2,
      maxMartingaleSteps: s.maxMartingaleSteps || 5,
      orderAmount: s.orderAmount || 100,
      frequency: s.frequency || 'daily',
      maxOrders: s.maxOrders || 30,
      activationPrice: s.activationPrice || 0,
      minSpread: s.minSpread || 0.5,
      bridgeFusion: s.bridgeFusion || false,
      bridgeFusionMode: s.bridgeFusionMode || 'auto' as 'auto' | 'manual',
    });
    setSelectedTech(bot.activeTech || []);
    setSelectedFilters(bot.activeFilters || []);
    setEditingBotId(bot.id);
    setShowCreate(true);
    setExpandedBot(null);
  };

  const updateBot = async () => {
    if (!editingBotId) return;
    try {
      const res = await fetch(`/api/server-bots/${editingBotId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newBot.name,
          settings: {
            investment: newBot.investment,
            takeProfit: newBot.takeProfit,
            stopLoss: newBot.stopLoss,
            trailingPercent: newBot.trailingPercent,
            cooldownSeconds: newBot.cooldownSeconds,
            signalThreshold: newBot.signalThreshold,
            paperTrading: newBot.paperTrading,
            ocoEnabled: newBot.ocoEnabled,
            autoCooldown: newBot.autoCooldown,
            autoTakeProfit: newBot.autoTakeProfit,
            autoStopLoss: newBot.autoStopLoss,
            autoThreshold: newBot.autoThreshold,
            autoTrailing: newBot.autoTrailing,
            maxDailyTrades: newBot.maxDailyTrades,
            maxDailyLossPercent: newBot.maxDailyLossPercent,
            positionSizePercent: newBot.positionSizePercent,
            signalSource: newBot.signalSource,
            upperPrice: newBot.upperPrice,
            lowerPrice: newBot.lowerPrice,
            gridCount: newBot.gridCount,
            safetyOrders: newBot.safetyOrders,
            safetyOrderSize: newBot.safetyOrderSize,
            safetyOrderStep: newBot.safetyOrderStep,
            martingaleMultiplier: newBot.martingaleMultiplier,
            maxMartingaleSteps: newBot.maxMartingaleSteps,
            orderAmount: newBot.orderAmount,
            frequency: newBot.frequency,
            maxOrders: newBot.maxOrders,
            activationPrice: newBot.activationPrice,
            minSpread: newBot.minSpread,
            bridgeFusion: newBot.bridgeFusion,
            bridgeFusionMode: newBot.bridgeFusionMode,
            bridgeFusionFilters: selectedFilters,
          },
          activeTech: selectedTech,
          activeFilters: selectedFilters,
        }),
      });
      if (res.ok) {
        toast({ title: 'Bot updated successfully!' });
        setShowCreate(false);
        setEditingBotId(null);
        setShowTechPanel(false);
        setSelectedTech([]);
        setSelectedFilters([]);
        setNewBot({ name: '', type: 'signal', pair: 'XRP/USDT', exchange: 'kraken', paperTrading: false, ocoEnabled: true, autoCooldown: false, autoTakeProfit: false, autoStopLoss: false, autoThreshold: false, autoTrailing: false, investment: 100, takeProfit: 10, stopLoss: 5, trailingPercent: 3, cooldownSeconds: 60, signalThreshold: 70, maxDailyTrades: 0, maxDailyLossPercent: 5, positionSizePercent: 100, signalSource: 'ai', upperPrice: 0, lowerPrice: 0, gridCount: 10, safetyOrders: 3, safetyOrderSize: 50, safetyOrderStep: 2, martingaleMultiplier: 2, maxMartingaleSteps: 5, orderAmount: 100, frequency: 'daily', maxOrders: 30, activationPrice: 0, minSpread: 0.5, bridgeFusion: false, bridgeFusionMode: 'auto' as 'auto' | 'manual' });
        fetchBots();
      } else {
        const err = await res.json();
        toast({ title: err.message, variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: e.message, variant: 'destructive' });
    }
  };

  const setExistingPosition = async (botId: number) => {
    const ep = parseFloat(positionForm.entryPrice);
    const qty = parseFloat(positionForm.quantity);
    if (!ep || !qty || ep <= 0 || qty <= 0) {
      toast({ title: 'Enter valid entry price and quantity', variant: 'destructive' });
      return;
    }
    try {
      const res = await fetch(`/api/server-bots/${botId}/set-position`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entryPrice: ep, quantity: qty, investment: positionForm.investment ? parseFloat(positionForm.investment) : ep * qty }),
      });
      if (!res.ok) throw new Error((await res.json()).message);
      toast({ title: 'Position set — bot will now monitor for SELL signals' });
      setSettingPositionFor(null);
      setPositionForm({ entryPrice: '', quantity: '', investment: '' });
      fetchBots();
    } catch (err: any) {
      toast({ title: 'Failed to set position', description: err.message, variant: 'destructive' });
    }
  };

  const clearPosition = async (botId: number) => {
    try {
      const res = await fetch(`/api/server-bots/${botId}/clear-position`, { method: 'POST' });
      if (!res.ok) throw new Error((await res.json()).message);
      toast({ title: 'Position cleared' });
      fetchBots();
    } catch (err: any) {
      toast({ title: 'Failed to clear position', description: err.message, variant: 'destructive' });
    }
  };

  const cancelEdit = () => {
    setShowCreate(false);
    setEditingBotId(null);
    setShowTechPanel(false);
    setSelectedTech([]);
    setSelectedFilters([]);
    setNewBot({ name: '', type: 'signal', pair: 'XRP/USDT', exchange: 'kraken', paperTrading: false, ocoEnabled: true, autoCooldown: false, autoTakeProfit: false, autoStopLoss: false, autoThreshold: false, autoTrailing: false, investment: 100, takeProfit: 10, stopLoss: 5, trailingPercent: 3, cooldownSeconds: 60, signalThreshold: 70, maxDailyTrades: 0, maxDailyLossPercent: 5, positionSizePercent: 100, signalSource: 'ai', upperPrice: 0, lowerPrice: 0, gridCount: 10, safetyOrders: 3, safetyOrderSize: 50, safetyOrderStep: 2, martingaleMultiplier: 2, maxMartingaleSteps: 5, orderAmount: 100, frequency: 'daily', maxOrders: 30, activationPrice: 0, minSpread: 0.5, bridgeFusion: false, bridgeFusionMode: 'auto' as 'auto' | 'manual' });
  };

  const migrateFromBrowser = async () => {
    try {
      const stored = localStorage.getItem('alpha-trading-bots-v3');
      if (!stored) {
        toast({ title: 'No browser bots found to migrate', variant: 'destructive' });
        return;
      }
      const browserBots = JSON.parse(stored);
      if (!Array.isArray(browserBots) || browserBots.length === 0) {
        toast({ title: 'No browser bots found to migrate', variant: 'destructive' });
        return;
      }

      let migrated = 0;
      for (const bb of browserBots) {
        const res = await fetch('/api/server-bots/migrate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: bb.name || `Migrated ${bb.type} Bot`,
            type: bb.type || 'signal',
            pair: bb.pair || 'BTC/USDT',
            exchange: bb.connectedExchange || 'kraken',
            settings: bb.settings || {},
            activeTech: bb.activeTech || [],
            activeFilters: bb.activeFilters || [],
            autoStart: bb.status === 'running',
          }),
        });
        if (res.ok) migrated++;
      }

      toast({ title: `Migrated ${migrated} bot(s) to server!` });
      fetchBots();
    } catch (e: any) {
      toast({ title: `Migration failed: ${e.message}`, variant: 'destructive' });
    }
  };

  const logTypeIcon = (type: string) => {
    switch (type) {
      case 'trade': return <CheckCircle size={12} className="text-green-400" />;
      case 'error': return <XCircle size={12} className="text-red-400" />;
      case 'warning': return <AlertTriangle size={12} className="text-yellow-400" />;
      case 'signal': return <Activity size={12} className="text-blue-400" />;
      default: return <Info size={12} className="text-gray-400" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="p-6 text-center text-gray-400" data-testid="server-bots-auth-required">
        <Server size={32} className="mx-auto mb-3 text-gray-600" />
        <p>Log in to manage server-side bots</p>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="server-bot-manager">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/20">
            <Server size={20} className="text-emerald-400" />
          </div>
          <div>
            <h3 className="font-bold text-lg" data-testid="text-server-bots-title">24/7 Server Bots</h3>
            <p className="text-xs text-gray-400">Run even when you're offline</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {engineStatus?.wsConnected && (
            <span className="flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 animate-pulse" data-testid="status-ws">
              <Zap size={10} /> LIVE {engineStatus.subscribedPairs.length} pair{engineStatus.subscribedPairs.length !== 1 ? 's' : ''}
            </span>
          )}
          <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${engineRunning ? 'bg-green-500/20 text-green-400' : 'bg-gray-700 text-gray-400'}`} data-testid="status-engine">
            <Cpu size={10} /> {engineRunning ? (engineStatus?.wsConnected ? 'Real-Time' : 'Active') : 'Idle'}
          </span>
          <Button size="sm" variant="outline" onClick={fetchBots} data-testid="button-refresh-bots">
            <RefreshCw size={14} />
          </Button>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Button size="sm" onClick={() => { if (editingBotId) cancelEdit(); setShowCreate(!showCreate); setEditingBotId(null); }} className="bg-emerald-600 hover:bg-emerald-700" data-testid="button-create-server-bot">
          <Plus size={14} className="mr-1" /> New Server Bot
        </Button>
        <Button size="sm" variant="outline" onClick={migrateFromBrowser} data-testid="button-migrate-bots">
          <Upload size={14} className="mr-1" /> Migrate Browser Bots
        </Button>
      </div>

      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`bg-gray-900/80 border rounded-xl p-4 space-y-3 ${editingBotId ? 'border-blue-500/30' : 'border-emerald-500/30'}`}
          >
            <h4 className={`font-semibold flex items-center gap-2 ${editingBotId ? 'text-blue-400' : 'text-emerald-400'}`}>
              {editingBotId ? <><Pencil size={16} /> Edit Bot — {newBot.name}</> : <><Zap size={16} /> Create Server Bot</>}
            </h4>
            {editingBotId && (
              <p className="text-xs text-blue-400/70">Modify settings below and click Save Changes. The bot will use the new settings on its next cycle.</p>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Bot Name</label>
                <input
                  value={newBot.name}
                  onChange={e => setNewBot(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="My XRP Bot"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                  data-testid="input-server-bot-name"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Bot Type {editingBotId && <span className="text-gray-600">(locked)</span>}</label>
                <select
                  value={newBot.type}
                  onChange={e => setNewBot(prev => ({ ...prev, type: e.target.value }))}
                  className={`w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm ${editingBotId ? 'opacity-50 cursor-not-allowed' : ''}`}
                  data-testid="select-server-bot-type"
                  disabled={!!editingBotId}
                >
                  {Object.entries(BOT_TYPE_LABELS).map(([id, label]) => (
                    <option key={id} value={id}>{label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  Trading Pair {pairsLoading && <span className="text-yellow-400 ml-1">(loading...)</span>}
                  <span className="text-gray-500 ml-1">({exchangePairs.length} available)</span>
                </label>
                <input
                  type="text"
                  placeholder="Search pairs..."
                  value={pairSearch}
                  onChange={e => setPairSearch(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-t-lg px-3 py-1.5 text-white text-xs mb-0 border-b-0"
                  data-testid="input-server-bot-pair-search"
                />
                <select
                  value={newBot.pair}
                  onChange={e => setNewBot(prev => ({ ...prev, pair: e.target.value }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-b-lg px-3 py-2 text-white text-sm"
                  size={Math.min(8, filteredPairs.length)}
                  data-testid="select-server-bot-pair"
                >
                  {filteredPairs.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  Exchange
                  {connectedExchanges.length > 0 && <span className="text-green-400 ml-1">({connectedExchanges.length} connected)</span>}
                </label>
                <select
                  value={newBot.exchange}
                  onChange={e => setNewBot(prev => ({ ...prev, exchange: e.target.value }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                  data-testid="select-server-bot-exchange"
                >
                  {ALL_EXCHANGES.map(ex => (
                    <option key={ex.id} value={ex.id}>
                      {ex.name}{connectedExchanges.includes(ex.id) ? ' (Connected)' : ''}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Investment ($)</label>
                <input type="number" value={newBot.investment} onChange={e => setNewBot(prev => ({ ...prev, investment: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-investment" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Take Profit (%)</label>
                <input type="number" value={newBot.takeProfit} onChange={e => setNewBot(prev => ({ ...prev, takeProfit: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-tp" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Stop Loss (%)</label>
                <input type="number" value={newBot.stopLoss} onChange={e => setNewBot(prev => ({ ...prev, stopLoss: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-sl" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Trailing %</label>
                <input type="number" value={newBot.trailingPercent} onChange={e => setNewBot(prev => ({ ...prev, trailingPercent: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-trailing" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  {newBot.autoCooldown ? 'Base Cooldown (sec)' : 'Cooldown (sec)'}
                </label>
                <input type="number" value={newBot.cooldownSeconds} onChange={e => setNewBot(prev => ({ ...prev, cooldownSeconds: parseInt(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-cooldown" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Signal Threshold</label>
                <input type="number" value={newBot.signalThreshold} onChange={e => setNewBot(prev => ({ ...prev, signalThreshold: parseInt(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-server-bot-threshold" />
              </div>
            </div>

            <div className={`border rounded-lg overflow-hidden transition-all ${hasAnyAuto ? 'border-cyan-500/40 bg-cyan-500/5' : 'border-gray-700 bg-gray-900/30'}`}>
              <div className="flex items-center justify-between px-3 py-2">
                <div className="flex items-center gap-2">
                  <Activity size={14} className={hasAnyAuto ? 'text-cyan-400' : 'text-gray-500'} />
                  <span className={`text-sm font-medium ${hasAnyAuto ? 'text-cyan-300' : 'text-gray-400'}`}>
                    Auto-Optimize Parameters
                  </span>
                  {hasAnyAuto && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                      {[newBot.autoCooldown, newBot.autoTakeProfit, newBot.autoStopLoss, newBot.autoThreshold, newBot.autoTrailing].filter(Boolean).length} active
                    </span>
                  )}
                </div>
                {hasAnyAuto && volatilityData?.available && (
                  <span className="text-[10px] text-cyan-400 animate-pulse flex items-center gap-1">
                    <Zap size={10} /> LIVE
                  </span>
                )}
              </div>

              <div className="px-3 pb-2">
                <p className="text-[11px] text-gray-500 mb-2">
                  Set your base values above, then toggle any parameter to auto-adjust based on real-time market conditions.
                </p>

                <div className="space-y-1.5">
                  {[
                    { key: 'autoCooldown' as const, label: 'Cooldown', base: `${newBot.cooldownSeconds}s`, auto: volatilityData?.autoParams ? `${Math.round(volatilityData.autoParams.cooldownMs / 1000)}s` : '—', color: 'text-cyan-400', desc: 'Faster in volatile markets, slower in calm' },
                    { key: 'autoTakeProfit' as const, label: 'Take Profit', base: `${newBot.takeProfit}%`, auto: volatilityData?.autoParams ? `${volatilityData.autoParams.takeProfit}%` : '—', color: 'text-emerald-400', desc: 'Bigger targets when swings are larger' },
                    { key: 'autoStopLoss' as const, label: 'Stop Loss', base: `${newBot.stopLoss}%`, auto: volatilityData?.autoParams ? `${volatilityData.autoParams.stopLoss}%` : '—', color: 'text-red-400', desc: 'Wider stops in volatile markets to avoid noise' },
                    { key: 'autoThreshold' as const, label: 'Signal Threshold', base: `${newBot.signalThreshold}`, auto: volatilityData?.autoParams ? `${volatilityData.autoParams.signalThreshold}` : '—', color: 'text-amber-400', desc: 'Lower in strong trends to catch more moves' },
                    { key: 'autoTrailing' as const, label: 'Trailing Gap', base: `${newBot.trailingPercent}%`, auto: volatilityData?.autoParams ? `${volatilityData.autoParams.trailingPercent}%` : '—', color: 'text-purple-400', desc: 'Tighter trail in fast moves, wider in slow' },
                  ].map(item => (
                    <div key={item.key} className={`flex items-center gap-2 p-1.5 rounded-lg transition-all ${newBot[item.key] ? 'bg-gray-900/60' : ''}`}>
                      <input
                        type="checkbox"
                        checked={newBot[item.key]}
                        onChange={e => setNewBot(prev => ({ ...prev, [item.key]: e.target.checked }))}
                        className="rounded flex-shrink-0"
                        data-testid={`toggle-${item.key}`}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-medium ${newBot[item.key] ? item.color : 'text-gray-500'}`}>{item.label}</span>
                          {newBot[item.key] && volatilityData?.autoParams && (
                            <span className="text-[10px] text-gray-400">
                              {item.base} → <span className={item.color}>{item.auto}</span>
                            </span>
                          )}
                        </div>
                        <p className="text-[9px] text-gray-600 leading-tight">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {hasAnyAuto && (
                  <div className="mt-2 space-y-2">
                    {volatilityData?.available && volatilityData.autoParams ? (
                      <div className="grid grid-cols-3 gap-2">
                        <div className="bg-gray-900/60 rounded-lg p-2">
                          <p className="text-[10px] text-gray-500 mb-0.5">24h Swing</p>
                          <p className={`text-sm font-bold ${
                            (volatilityData.dailySwing || 0) >= 10 ? 'text-red-400' :
                            (volatilityData.dailySwing || 0) >= 7 ? 'text-orange-400' :
                            (volatilityData.dailySwing || 0) >= 4 ? 'text-yellow-400' :
                            'text-green-400'
                          }`} data-testid="text-daily-swing">
                            {(volatilityData.dailySwing || 0).toFixed(2)}%
                          </p>
                        </div>
                        <div className="bg-gray-900/60 rounded-lg p-2">
                          <p className="text-[10px] text-gray-500 mb-0.5">Trend</p>
                          <p className={`text-sm font-bold ${
                            volatilityData.autoParams.trendDirection === 'bullish' ? 'text-green-400' :
                            volatilityData.autoParams.trendDirection === 'bearish' ? 'text-red-400' :
                            'text-gray-400'
                          }`} data-testid="text-trend">
                            {volatilityData.autoParams.trendDirection === 'bullish' ? '↑' : volatilityData.autoParams.trendDirection === 'bearish' ? '↓' : '→'} {volatilityData.autoParams.trendStrength}%
                          </p>
                        </div>
                        <div className="bg-gray-900/60 rounded-lg p-2">
                          <p className="text-[10px] text-gray-500 mb-0.5">RSI</p>
                          <p className={`text-sm font-bold ${
                            volatilityData.autoParams.rsi < 30 ? 'text-green-400' :
                            volatilityData.autoParams.rsi > 70 ? 'text-red-400' :
                            'text-gray-300'
                          }`} data-testid="text-rsi">
                            {volatilityData.autoParams.rsi}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-gray-900/60 rounded-lg p-2 text-center">
                        <p className="text-[11px] text-gray-500">
                          <Info size={12} className="inline mr-1" />
                          Start a bot on this pair to see live auto-adjusted values
                        </p>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <button
                        onClick={() => setNewBot(prev => ({ ...prev, autoCooldown: true, autoTakeProfit: true, autoStopLoss: true, autoThreshold: true, autoTrailing: true }))}
                        className="text-[10px] text-cyan-500 hover:text-cyan-400"
                        data-testid="button-enable-all-auto"
                      >
                        Enable all
                      </button>
                      <button
                        onClick={() => setNewBot(prev => ({ ...prev, autoCooldown: false, autoTakeProfit: false, autoStopLoss: false, autoThreshold: false, autoTrailing: false }))}
                        className="text-[10px] text-gray-500 hover:text-red-400"
                        data-testid="button-disable-all-auto"
                      >
                        Disable all
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {(newBot.type === 'grid' || newBot.type === 'infinity_grid' || newBot.type === 'reverse_grid' || newBot.type === 'leveraged_grid') && (
              <div className="border border-indigo-500/30 rounded-lg p-3 bg-indigo-500/5 space-y-2">
                <p className="text-xs font-medium text-indigo-400 flex items-center gap-1"><Layers size={12} /> Grid Parameters</p>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Upper Price</label>
                    <input type="number" step="0.01" value={newBot.upperPrice} onChange={e => setNewBot(prev => ({ ...prev, upperPrice: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-upper-price" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Lower Price</label>
                    <input type="number" step="0.01" value={newBot.lowerPrice} onChange={e => setNewBot(prev => ({ ...prev, lowerPrice: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-lower-price" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Grid Count</label>
                    <input type="number" value={newBot.gridCount} onChange={e => setNewBot(prev => ({ ...prev, gridCount: parseInt(e.target.value) || 10 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-grid-count" />
                  </div>
                </div>
                {newBot.upperPrice > 0 && newBot.lowerPrice > 0 && newBot.gridCount > 1 && (
                  <p className="text-[10px] text-gray-500">Grid spacing: ${((newBot.upperPrice - newBot.lowerPrice) / newBot.gridCount).toFixed(4)} per level | Per-grid investment: ${(newBot.investment / newBot.gridCount).toFixed(2)}</p>
                )}
              </div>
            )}

            {newBot.type === 'dca' && (
              <div className="border border-teal-500/30 rounded-lg p-3 bg-teal-500/5 space-y-2">
                <p className="text-xs font-medium text-teal-400 flex items-center gap-1"><TrendingUp size={12} /> DCA Parameters</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Base Order ($)</label>
                    <input type="number" value={newBot.orderAmount} onChange={e => setNewBot(prev => ({ ...prev, orderAmount: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-base-order" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Frequency</label>
                    <select value={newBot.frequency} onChange={e => setNewBot(prev => ({ ...prev, frequency: e.target.value }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="select-sb-frequency">
                      <option value="hourly">Hourly</option>
                      <option value="4hourly">4 Hours</option>
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Safety Orders</label>
                    <input type="number" value={newBot.safetyOrders} onChange={e => setNewBot(prev => ({ ...prev, safetyOrders: parseInt(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-safety-orders" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">SO Size ($)</label>
                    <input type="number" value={newBot.safetyOrderSize} onChange={e => setNewBot(prev => ({ ...prev, safetyOrderSize: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-safety-size" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">SO Step %</label>
                    <input type="number" step="0.5" value={newBot.safetyOrderStep} onChange={e => setNewBot(prev => ({ ...prev, safetyOrderStep: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-safety-step" />
                  </div>
                </div>
              </div>
            )}

            {newBot.type === 'signal' && (
              <div className="border border-blue-500/30 rounded-lg p-3 bg-blue-500/5 space-y-2">
                <p className="text-xs font-medium text-blue-400 flex items-center gap-1"><Target size={12} /> Signal Parameters</p>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Signal Source</label>
                  <select value={newBot.signalSource} onChange={e => setNewBot(prev => ({ ...prev, signalSource: e.target.value }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="select-sb-signal-source">
                    <option value="ai">AI Predictions</option>
                    <option value="rsi">RSI (Oversold/Overbought)</option>
                    <option value="macd">MACD Crossover</option>
                    <option value="bollinger">Bollinger Bands</option>
                    <option value="acm">ACM™ Signals</option>
                    <option value="ance">ANCE™ Engine</option>
                    <option value="custom">Custom Webhook</option>
                  </select>
                </div>
              </div>
            )}

            {newBot.type === 'trailing_stop' && (
              <div className="border border-purple-500/30 rounded-lg p-3 bg-purple-500/5 space-y-2">
                <p className="text-xs font-medium text-purple-400 flex items-center gap-1"><TrendingUp size={12} /> Trailing Stop Parameters</p>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Activation Price (optional — start trailing at this price)</label>
                  <input type="number" step="0.01" value={newBot.activationPrice} onChange={e => setNewBot(prev => ({ ...prev, activationPrice: parseFloat(e.target.value) || 0 }))} placeholder="0 = immediate" className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-activation-price" />
                </div>
              </div>
            )}

            {newBot.type === 'twap' && (
              <div className="border border-sky-500/30 rounded-lg p-3 bg-sky-500/5 space-y-2">
                <p className="text-xs font-medium text-sky-400 flex items-center gap-1"><BarChart3 size={12} /> TWAP Parameters</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Time Period</label>
                    <select value={newBot.frequency} onChange={e => setNewBot(prev => ({ ...prev, frequency: e.target.value }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="select-sb-twap-period">
                      <option value="hourly">1 Hour</option>
                      <option value="4hourly">4 Hours</option>
                      <option value="daily">24 Hours</option>
                      <option value="weekly">7 Days</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Number of Slices</label>
                    <input type="number" value={newBot.maxOrders} onChange={e => setNewBot(prev => ({ ...prev, maxOrders: parseInt(e.target.value) || 1 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-slices" />
                  </div>
                </div>
              </div>
            )}

            {newBot.type === 'arbitrage' && (
              <div className="border border-pink-500/30 rounded-lg p-3 bg-pink-500/5 space-y-2">
                <p className="text-xs font-medium text-pink-400 flex items-center gap-1"><ArrowUpDown size={12} /> Arbitrage Parameters</p>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Min Spread %</label>
                  <input type="number" step="0.1" value={newBot.minSpread} onChange={e => setNewBot(prev => ({ ...prev, minSpread: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-min-spread" />
                </div>
              </div>
            )}

            {newBot.type === 'martingale' && (
              <div className="border border-orange-500/30 rounded-lg p-3 bg-orange-500/5 space-y-2">
                <p className="text-xs font-medium text-orange-400 flex items-center gap-1"><Layers size={12} /> Martingale Parameters</p>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Initial Order ($)</label>
                    <input type="number" value={newBot.orderAmount} onChange={e => setNewBot(prev => ({ ...prev, orderAmount: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-mart-initial" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Multiplier</label>
                    <input type="number" step="0.1" value={newBot.martingaleMultiplier} onChange={e => setNewBot(prev => ({ ...prev, martingaleMultiplier: parseFloat(e.target.value) || 2 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-multiplier" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Max Steps</label>
                    <input type="number" value={newBot.maxMartingaleSteps} onChange={e => setNewBot(prev => ({ ...prev, maxMartingaleSteps: parseInt(e.target.value) || 5 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-max-steps" />
                  </div>
                </div>
                <div className="p-2 bg-orange-500/10 border border-orange-500/20 rounded-lg">
                  <div className="flex items-center gap-1 text-[10px] text-orange-400 mb-0.5"><AlertTriangle size={10} /> Risk Warning</div>
                  <p className="text-[10px] text-gray-400">
                    Max exposure: ${((newBot.orderAmount || 0) * Math.pow((newBot.martingaleMultiplier || 2), (newBot.maxMartingaleSteps || 5) - 1)).toFixed(0)}
                    {' '}| Total risk: ${Array.from({length: newBot.maxMartingaleSteps || 5}, (_, i) => (newBot.orderAmount || 0) * Math.pow((newBot.martingaleMultiplier || 2), i)).reduce((a, b) => a + b, 0).toFixed(0)}
                  </p>
                </div>
              </div>
            )}

            <div className="border border-gray-700 rounded-lg p-3 bg-gray-900/40 space-y-3">
              <p className="text-xs font-medium text-gray-300 flex items-center gap-1"><Settings size={12} /> Risk Management</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Max Daily Trades</label>
                  <input type="number" min={0} value={newBot.maxDailyTrades} onChange={e => setNewBot(prev => ({ ...prev, maxDailyTrades: parseInt(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-max-daily" />
                  <p className="text-[9px] text-gray-600 mt-0.5">0 = unlimited</p>
                </div>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Max Daily Loss %</label>
                  <input type="number" min={0} step={0.5} value={newBot.maxDailyLossPercent} onChange={e => setNewBot(prev => ({ ...prev, maxDailyLossPercent: parseFloat(e.target.value) || 0 }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm" data-testid="input-sb-max-daily-loss" />
                  <p className="text-[9px] text-gray-600 mt-0.5">Bot pauses when daily loss exceeds this %</p>
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Position Size: {newBot.positionSizePercent}% of portfolio</label>
                <input type="range" min={1} max={100} value={newBot.positionSizePercent} onChange={e => setNewBot(prev => ({ ...prev, positionSizePercent: parseInt(e.target.value) }))} className="w-full accent-primary" data-testid="input-sb-position-size" />
                <div className="flex justify-between text-[9px] text-gray-600 mt-0.5">
                  <span>1% (Conservative)</span><span>50%</span><span>100% (Full)</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={newBot.ocoEnabled} onChange={e => setNewBot(prev => ({ ...prev, ocoEnabled: e.target.checked }))} className="rounded" data-testid="checkbox-sb-oco" />
                  <Target size={14} className="text-amber-400" /> OCO Orders
                </label>
                <span className="text-[10px] text-gray-500">One-Cancels-Other: TP & SL linked</span>
              </div>
            </div>

            <div className="border border-violet-500/30 rounded-lg overflow-hidden">
              <button
                onClick={() => setNewBot(prev => ({ ...prev, bridgeFusion: !prev.bridgeFusion }))}
                className="w-full flex items-center justify-between px-3 py-2 bg-violet-500/10 hover:bg-violet-500/15 transition-colors"
                data-testid="button-toggle-bridge-fusion"
              >
                <div className="flex items-center gap-2">
                  <GitMerge size={14} className={newBot.bridgeFusion ? 'text-violet-400' : 'text-gray-500'} />
                  <span className={`text-sm font-medium ${newBot.bridgeFusion ? 'text-violet-400' : 'text-gray-400'}`}>Bridge Fusion Architecture</span>
                  {newBot.bridgeFusion && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-500/20 text-violet-300">
                      {newBot.bridgeFusionMode.toUpperCase()}
                    </span>
                  )}
                </div>
                {newBot.bridgeFusion ? <ChevronUp size={14} className="text-violet-400" /> : <ChevronDown size={14} className="text-gray-500" />}
              </button>
              <AnimatePresence>
                {newBot.bridgeFusion && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="px-3 py-3 space-y-3 bg-gray-950/50"
                  >
                    <div className="flex gap-2">
                      {(['auto', 'manual'] as const).map(mode => (
                        <button
                          key={mode}
                          onClick={() => setNewBot(prev => ({ ...prev, bridgeFusionMode: mode }))}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            newBot.bridgeFusionMode === mode
                              ? 'bg-violet-500/20 text-violet-300 border border-violet-500/50'
                              : 'bg-gray-800 text-gray-400 border border-gray-700'
                          }`}
                          data-testid={`button-bridge-mode-${mode}`}
                        >
                          {mode === 'auto' ? 'Auto Mode (1.5x bonus)' : 'Manual Mode'}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-gray-500">
                      {newBot.bridgeFusionMode === 'auto'
                        ? 'Bridge Convergence Intelligence automatically selects optimal filter combinations from your active filters. 1.5× fusion multiplier bonus.'
                        : 'Manually select which filters feed into the Bridge Fusion signal pipeline.'}
                    </p>
                    {selectedFilters.length >= 2 ? (
                      <div className="p-2 bg-violet-500/10 border border-violet-500/20 rounded-lg">
                        <p className="text-[10px] text-violet-300">
                          <Zap size={10} className="inline mr-1" />
                          Bridge Fusion active with {selectedFilters.length} filters — {newBot.bridgeFusionMode === 'auto' ? '1.5×' : '1.0×'} fusion multiplier
                        </p>
                      </div>
                    ) : (
                      <div className="p-2 bg-gray-800/50 border border-gray-700 rounded-lg">
                        <p className="text-[10px] text-gray-500">
                          <Info size={10} className="inline mr-1" />
                          Select at least 2 Advanced Filters in the Technology panel to activate Bridge Fusion
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newBot.paperTrading}
                  onChange={e => setNewBot(prev => ({ ...prev, paperTrading: e.target.checked }))}
                  className="rounded"
                  data-testid="checkbox-server-bot-paper"
                />
                <Shield size={14} className="text-blue-400" /> Paper Trading (no real money)
              </label>
            </div>

            <div className="border border-amber-500/30 rounded-lg overflow-hidden">
              <button
                onClick={() => setShowTechPanel(!showTechPanel)}
                className="w-full flex items-center justify-between px-3 py-2 bg-amber-500/10 hover:bg-amber-500/15 transition-colors"
                data-testid="button-toggle-tech-panel"
              >
                <div className="flex items-center gap-2">
                  <Zap size={14} className="text-amber-400" />
                  <span className="text-sm font-medium text-amber-400">Proprietary Technologies</span>
                  {(selectedTech.length + selectedFilters.length) > 0 && (
                    <span className="text-xs px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                      {selectedTech.length + selectedFilters.length} active
                    </span>
                  )}
                </div>
                {showTechPanel ? <ChevronUp size={14} className="text-amber-400" /> : <ChevronDown size={14} className="text-amber-400" />}
              </button>

              <AnimatePresence>
                {showTechPanel && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="px-3 py-3 space-y-3 bg-gray-950/50"
                  >
                    <div>
                      <p className="text-xs text-gray-400 mb-2">Core Technologies — boost signal strength & confidence</p>
                      <div className="grid grid-cols-2 gap-2">
                        {PROPRIETARY_TECH.map(tech => {
                          const isActive = selectedTech.includes(tech.id);
                          return (
                            <button
                              key={tech.id}
                              onClick={() => toggleTech(tech.id)}
                              className={`text-left p-2 rounded-lg border transition-all ${
                                isActive
                                  ? 'border-opacity-60 bg-opacity-15'
                                  : 'border-gray-700 bg-gray-900/50 hover:bg-gray-800/50'
                              }`}
                              style={isActive ? { borderColor: tech.color + '99', backgroundColor: tech.color + '15' } : {}}
                              data-testid={`button-tech-${tech.id}`}
                            >
                              <div className="flex items-center justify-between mb-0.5">
                                <span className="text-xs font-bold" style={{ color: isActive ? tech.color : '#9CA3AF' }}>
                                  {tech.shortName}
                                </span>
                                <span className="text-[10px] font-mono" style={{ color: tech.color }}>
                                  {tech.boost}
                                </span>
                              </div>
                              <p className="text-[10px] text-gray-500 leading-tight">{tech.desc}</p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-gray-400 mb-2">Advanced Filters — fine-tune signal accuracy</p>
                      <div className="flex flex-wrap gap-1.5">
                        {ADVANCED_FILTERS.map(filter => {
                          const isActive = selectedFilters.includes(filter.id);
                          return (
                            <button
                              key={filter.id}
                              onClick={() => toggleFilter(filter.id)}
                              className={`px-2 py-1 rounded-md text-[10px] font-medium border transition-all ${
                                isActive ? '' : 'border-gray-700 text-gray-500 hover:text-gray-300'
                              }`}
                              style={isActive ? { borderColor: filter.color + '60', backgroundColor: filter.color + '15', color: filter.color } : {}}
                              data-testid={`button-filter-${filter.id}`}
                            >
                              {filter.shortName} {filter.boost}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {(selectedTech.length + selectedFilters.length) > 0 && (
                      <div className="flex items-center justify-between pt-1 border-t border-gray-800">
                        <div className="flex flex-wrap gap-1">
                          {selectedTech.map(id => {
                            const t = PROPRIETARY_TECH.find(x => x.id === id);
                            return t ? <span key={id} className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ backgroundColor: t.color + '20', color: t.color }}>{t.shortName}</span> : null;
                          })}
                          {selectedFilters.map(id => {
                            const f = ADVANCED_FILTERS.find(x => x.id === id);
                            return f ? <span key={id} className="px-1.5 py-0.5 rounded text-[10px] font-bold" style={{ backgroundColor: f.color + '20', color: f.color }}>{f.shortName}</span> : null;
                          })}
                        </div>
                        <button onClick={() => { setSelectedTech([]); setSelectedFilters([]); }} className="text-[10px] text-gray-500 hover:text-red-400" data-testid="button-clear-tech">
                          Clear all
                        </button>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="flex gap-2">
              {editingBotId ? (
                <Button size="sm" onClick={updateBot} className="bg-blue-600 hover:bg-blue-700" data-testid="button-confirm-update-server-bot">
                  <Save size={14} className="mr-1" /> Save Changes
                </Button>
              ) : (
                <Button size="sm" onClick={createBot} className="bg-emerald-600 hover:bg-emerald-700" data-testid="button-confirm-create-server-bot">
                  <Plus size={14} className="mr-1" /> Create Bot
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={cancelEdit} data-testid="button-cancel-create">
                Cancel
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="text-center text-gray-400 py-8">
          <RefreshCw size={20} className="mx-auto animate-spin mb-2" />
          <p className="text-sm">Loading server bots...</p>
        </div>
      ) : bots.length === 0 ? (
        <div className="text-center text-gray-400 py-8 bg-gray-900/50 rounded-xl border border-gray-800" data-testid="text-no-server-bots">
          <Server size={32} className="mx-auto mb-3 text-gray-600" />
          <p className="text-sm mb-1">No server bots yet</p>
          <p className="text-xs text-gray-500">Create a new bot or migrate your browser bots to run 24/7</p>
        </div>
      ) : (
        <div className="space-y-3">
          {bots.map(bot => (
            <div key={bot.id} className="bg-gray-900/60 border border-gray-800 rounded-xl overflow-hidden" data-testid={`card-server-bot-${bot.id}`}>
              <div className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${bot.status === 'running' ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
                  <div>
                    <div className="font-medium text-sm flex items-center gap-2">
                      {bot.name}
                      <span className="text-xs px-1.5 py-0.5 rounded bg-gray-800 text-gray-400">{BOT_TYPE_LABELS[bot.type] || bot.type}</span>
                      {bot.settings && (bot.settings as any)._managedByCC && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 flex items-center gap-1">
                          <Brain size={9} /> CC Managed
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-400 flex items-center gap-2 flex-wrap">
                      <span>{bot.pair}</span>
                      <span className="text-gray-600">|</span>
                      <span>{bot.exchange}</span>
                      <span className="text-gray-600">|</span>
                      <span>{bot.totalTrades} trades</span>
                      {bot.settings && (bot.settings as any).paperTrading && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="text-blue-400 flex items-center gap-1"><Shield size={10} /> Paper</span>
                        </>
                      )}
                      {bot.settings && ((bot.settings as any).autoCooldown || (bot.settings as any).autoTakeProfit || (bot.settings as any).autoStopLoss || (bot.settings as any).autoThreshold || (bot.settings as any).autoTrailing) && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="text-cyan-400 flex items-center gap-1 flex-wrap">
                            <Activity size={10} />
                            {(bot.settings as any).autoCooldown && <span className="text-[9px] px-1 rounded bg-cyan-500/15">CD</span>}
                            {(bot.settings as any).autoTakeProfit && <span className="text-[9px] px-1 rounded bg-emerald-500/15 text-emerald-400">TP</span>}
                            {(bot.settings as any).autoStopLoss && <span className="text-[9px] px-1 rounded bg-red-500/15 text-red-400">SL</span>}
                            {(bot.settings as any).autoThreshold && <span className="text-[9px] px-1 rounded bg-amber-500/15 text-amber-400">TH</span>}
                            {(bot.settings as any).autoTrailing && <span className="text-[9px] px-1 rounded bg-purple-500/15 text-purple-400">TR</span>}
                          </span>
                        </>
                      )}
                      {bot.activeTech && bot.activeTech.length > 0 && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="flex items-center gap-1 flex-wrap">
                            {bot.activeTech.map((techId: string) => {
                              const t = PROPRIETARY_TECH.find(x => x.id === techId);
                              return t ? <span key={techId} className="px-1 py-0 rounded text-[9px] font-bold" style={{ backgroundColor: t.color + '20', color: t.color }}>{t.shortName}</span> : null;
                            })}
                          </span>
                        </>
                      )}
                      {bot.activeFilters && bot.activeFilters.length > 0 && (
                        <span className="flex items-center gap-1 flex-wrap">
                          {bot.activeFilters.map((filterId: string) => {
                            const f = ADVANCED_FILTERS.find(x => x.id === filterId);
                            return f ? <span key={filterId} className="px-1 py-0 rounded text-[9px] font-bold" style={{ backgroundColor: f.color + '20', color: f.color }}>{f.shortName}</span> : null;
                          })}
                        </span>
                      )}
                      {bot.settings && (bot.settings as any).ocoEnabled && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="text-amber-400 text-[9px] px-1 rounded bg-amber-500/15 flex items-center gap-0.5"><Target size={8} /> OCO</span>
                        </>
                      )}
                      {bot.settings && (bot.settings as any).bridgeFusion && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="text-violet-400 text-[9px] px-1 rounded bg-violet-500/15 flex items-center gap-0.5">
                            <GitMerge size={8} /> BRIDGE {(bot.settings as any).bridgeFusionMode === 'auto' ? '(AUTO)' : '(MAN)'}
                          </span>
                        </>
                      )}
                      {bot.settings && (bot.settings as any).signalSource && (bot.settings as any).signalSource !== 'ai' && (
                        <>
                          <span className="text-gray-600">|</span>
                          <span className="text-blue-400 text-[9px] px-1 rounded bg-blue-500/15">{(bot.settings as any).signalSource.toUpperCase()}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {bot.lastSignalData && (
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      (bot.lastSignalData as any).direction === 'BUY' ? 'bg-green-500/20 text-green-400' :
                      (bot.lastSignalData as any).direction === 'SELL' ? 'bg-red-500/20 text-red-400' :
                      'bg-gray-700 text-gray-400'
                    }`} data-testid={`text-signal-${bot.id}`}>
                      {(bot.lastSignalData as any).direction} ({((bot.lastSignalData as any).strength || 0).toFixed(0)}%)
                    </span>
                  )}

                  {bot.status === 'running' ? (
                    <Button size="sm" variant="outline" onClick={() => pauseBot(bot.id)} className="text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/10" data-testid={`button-pause-${bot.id}`}>
                      <Pause size={14} />
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => startBot(bot.id)} className="text-green-400 border-green-500/30 hover:bg-green-500/10" data-testid={`button-start-${bot.id}`}>
                      <Play size={14} />
                    </Button>
                  )}

                  <Button size="sm" variant="outline" onClick={() => startEditing(bot)} className="text-blue-400 border-blue-500/30 hover:bg-blue-500/10" data-testid={`button-edit-${bot.id}`} title="Edit bot settings">
                    <Pencil size={14} />
                  </Button>

                  <Button size="sm" variant="outline" onClick={() => deleteBot(bot.id)} className="text-red-400 border-red-500/30 hover:bg-red-500/10" data-testid={`button-delete-${bot.id}`}>
                    <Trash2 size={14} />
                  </Button>

                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      if (expandedBot === bot.id) {
                        setExpandedBot(null);
                      } else {
                        setExpandedBot(bot.id);
                        fetchLogs(bot.id);
                      }
                    }}
                    data-testid={`button-expand-${bot.id}`}
                  >
                    {expandedBot === bot.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </Button>
                </div>
              </div>

              {(bot.openPosition || (bot.lastSignalData as any)?.exchangeFees) && (
                <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                  {bot.openPosition && (() => {
                    const pos = bot.openPosition;
                    const lastPrice = (bot.lastSignalData as any)?.price || pos.entryPrice;
                    const pnlPercent = ((lastPrice - pos.entryPrice) / pos.entryPrice) * 100;
                    const grossPnl = (lastPrice - pos.entryPrice) * pos.quantity;
                    const holdMs = Date.now() - pos.entryTime;
                    const holdStr = holdMs > 3600000 ? `${(holdMs / 3600000).toFixed(1)}h` : `${(holdMs / 60000).toFixed(0)}m`;
                    return (
                      <div className={`text-[10px] px-2 py-1 rounded-md border ${pnlPercent >= 0 ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-red-500/30 bg-red-500/10 text-red-400'}`} data-testid={`position-${bot.id}`}>
                        <span className="font-bold">OPEN</span> {pos.quantity.toFixed(6)} @ ${pos.entryPrice.toFixed(2)}
                        <span className="mx-1">|</span>
                        <span className="font-bold">{pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%</span> (${grossPnl >= 0 ? '+' : ''}{grossPnl.toFixed(2)})
                        <span className="mx-1">|</span>
                        Held: {holdStr}
                      </div>
                    );
                  })()}
                  {!bot.openPosition && (
                    <button
                      onClick={() => { setSettingPositionFor(settingPositionFor === bot.id ? null : bot.id); setPositionForm({ entryPrice: '', quantity: '', investment: '' }); }}
                      className="text-[10px] text-amber-400 px-2 py-1 rounded-md border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 cursor-pointer"
                      data-testid={`button-set-position-${bot.id}`}
                    >
                      {settingPositionFor === bot.id ? 'Cancel' : 'Set Existing Position'}
                    </button>
                  )}
                  {bot.openPosition && (
                    <button
                      onClick={() => clearPosition(bot.id)}
                      className="text-[10px] text-gray-500 px-1.5 py-0.5 rounded border border-gray-700/50 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30 cursor-pointer"
                      data-testid={`button-clear-position-${bot.id}`}
                    >
                      Clear
                    </button>
                  )}
                  {(bot.lastSignalData as any)?.exchangeFees && (
                    <span className="text-[10px] text-gray-500 px-2 py-0.5 rounded bg-gray-800/50" data-testid={`fees-${bot.id}`}>
                      {(bot.lastSignalData as any).exchangeFees.name}: {((bot.lastSignalData as any).exchangeFees.taker).toFixed(2)}% taker
                    </span>
                  )}
                  {bot.totalPnl !== 0 && (
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${bot.totalPnl >= 0 ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400'}`} data-testid={`pnl-${bot.id}`}>
                      Total P&L: ${bot.totalPnl >= 0 ? '+' : ''}{bot.totalPnl.toFixed(2)}
                    </span>
                  )}
                </div>
              )}

              {settingPositionFor === bot.id && (
                <div className="mt-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg space-y-2">
                  <p className="text-xs text-amber-400 font-semibold">Set your existing position so the bot can sell when profitable</p>
                  <p className="text-[10px] text-gray-400">Enter the price you bought at and how many coins you hold. The bot will start monitoring for sell signals.</p>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] text-gray-400 block mb-0.5">Entry Price ($)</label>
                      <input
                        type="number" step="any" placeholder="e.g. 2.35"
                        value={positionForm.entryPrice}
                        onChange={e => setPositionForm(p => ({ ...p, entryPrice: e.target.value }))}
                        className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1 text-white text-xs"
                        data-testid={`input-position-entry-${bot.id}`}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 block mb-0.5">Quantity (coins)</label>
                      <input
                        type="number" step="any" placeholder="e.g. 42.5"
                        value={positionForm.quantity}
                        onChange={e => setPositionForm(p => ({ ...p, quantity: e.target.value }))}
                        className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1 text-white text-xs"
                        data-testid={`input-position-qty-${bot.id}`}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button size="sm" onClick={() => setExistingPosition(bot.id)} className="bg-amber-600 hover:bg-amber-700 text-xs w-full" data-testid={`button-confirm-position-${bot.id}`}>
                        Set Position
                      </Button>
                    </div>
                  </div>
                  {positionForm.entryPrice && positionForm.quantity && (
                    <p className="text-[10px] text-gray-500">
                      Total value: ${(parseFloat(positionForm.entryPrice || '0') * parseFloat(positionForm.quantity || '0')).toFixed(2)}
                    </p>
                  )}
                </div>
              )}

              <AnimatePresence>
                {expandedBot === bot.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-gray-800"
                  >
                    <div className="p-3 space-y-2">
                      {bot.settings && (
                        <div className="bg-gray-800/40 rounded-lg p-2.5 space-y-2">
                          <h5 className="text-xs font-semibold text-gray-300 flex items-center gap-1"><Settings size={12} /> Bot Configuration</h5>
                          <div className="grid grid-cols-4 gap-2 text-[11px]">
                            <div><span className="text-gray-500">Investment</span><br /><span className="text-white">${(bot.settings as any).investment || 0}</span></div>
                            <div><span className="text-gray-500">Take Profit</span><br /><span className="text-emerald-400">{(bot.settings as any).takeProfit || 0}%</span></div>
                            <div><span className="text-gray-500">Stop Loss</span><br /><span className="text-red-400">{(bot.settings as any).stopLoss || 0}%</span></div>
                            <div><span className="text-gray-500">Trailing</span><br /><span className="text-purple-400">{(bot.settings as any).trailingPercent || 0}%</span></div>
                            <div><span className="text-gray-500">Cooldown</span><br /><span className="text-white">{(bot.settings as any).cooldownSeconds || 0}s</span></div>
                            <div><span className="text-gray-500">Threshold</span><br /><span className="text-white">{(bot.settings as any).signalThreshold || 0}</span></div>
                            <div><span className="text-gray-500">Position Size</span><br /><span className="text-white">{(bot.settings as any).positionSizePercent || 100}%</span></div>
                            <div><span className="text-gray-500">Max Daily</span><br /><span className="text-white">{(bot.settings as any).maxDailyTrades === 0 ? '∞' : (bot.settings as any).maxDailyTrades || '∞'}</span></div>
                          </div>
                          <div className="flex flex-wrap gap-1.5 pt-1 border-t border-gray-700/50">
                            {(bot.settings as any).ocoEnabled && <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400">OCO</span>}
                            {(bot.settings as any).bridgeFusion && <span className="text-[9px] px-1.5 py-0.5 rounded bg-violet-500/15 text-violet-400">Bridge Fusion ({(bot.settings as any).bridgeFusionMode})</span>}
                            {(bot.settings as any).signalSource && (bot.settings as any).signalSource !== 'ai' && <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-400">Source: {(bot.settings as any).signalSource.toUpperCase()}</span>}
                            {(bot.settings as any).maxDailyLossPercent > 0 && <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400">Max Loss: {(bot.settings as any).maxDailyLossPercent}%/day</span>}
                            {(bot.type === 'grid' || bot.type === 'infinity_grid') && (bot.settings as any).gridCount > 0 && <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-400">Grid: {(bot.settings as any).gridCount} levels (${(bot.settings as any).lowerPrice}–${(bot.settings as any).upperPrice})</span>}
                            {bot.type === 'martingale' && <span className="text-[9px] px-1.5 py-0.5 rounded bg-orange-500/15 text-orange-400">Martingale: {(bot.settings as any).martingaleMultiplier}x / {(bot.settings as any).maxMartingaleSteps} steps</span>}
                            {bot.type === 'dca' && <span className="text-[9px] px-1.5 py-0.5 rounded bg-teal-500/15 text-teal-400">DCA: {(bot.settings as any).safetyOrders} SOs @ ${(bot.settings as any).safetyOrderSize}</span>}
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-semibold text-gray-300 flex items-center gap-1">
                          <Eye size={12} /> Activity Log
                        </h5>
                        <Button size="sm" variant="ghost" onClick={() => fetchLogs(bot.id)} className="text-xs" data-testid={`button-refresh-logs-${bot.id}`}>
                          <RefreshCw size={12} className={logsLoading[bot.id] ? 'animate-spin' : ''} />
                        </Button>
                      </div>

                      {bot.lastSignalData && (
                        <div className="bg-gray-800/60 rounded-lg p-2 text-xs space-y-1">
                          <div className="flex items-center justify-between text-gray-300">
                            <span>Last Signal</span>
                            <span className={
                              (bot.lastSignalData as any).direction === 'BUY' ? 'text-green-400' :
                              (bot.lastSignalData as any).direction === 'SELL' ? 'text-red-400' : 'text-gray-400'
                            }>
                              {(bot.lastSignalData as any).direction} @ ${((bot.lastSignalData as any).price || 0).toFixed(6)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-gray-400">
                            <span>Strength / Confidence</span>
                            <span>{((bot.lastSignalData as any).strength || 0).toFixed(1)}% / {((bot.lastSignalData as any).confidence || 0).toFixed(1)}%</span>
                          </div>
                        </div>
                      )}

                      <div className="max-h-48 overflow-y-auto space-y-1 scrollbar-visible-thin">
                        {(botLogs[bot.id] || []).length === 0 ? (
                          <p className="text-xs text-gray-500 text-center py-3">No logs yet — bot will log activity when running</p>
                        ) : (
                          (botLogs[bot.id] || []).map(log => (
                            <div key={log.id} className="flex items-start gap-2 text-xs py-1 px-2 rounded bg-gray-800/40 hover:bg-gray-800/60">
                              {logTypeIcon(log.logType)}
                              <div className="flex-1 min-w-0">
                                <span className="text-gray-300 break-words">{log.message}</span>
                              </div>
                              <span className="text-gray-500 whitespace-nowrap flex-shrink-0">
                                {new Date(log.createdAt).toLocaleTimeString()}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}

      <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3 text-xs text-gray-400">
        <div className="flex items-start gap-2">
          <Server size={14} className="text-emerald-400 mt-0.5 flex-shrink-0" />
          <div>
            <span className="text-emerald-400 font-medium">24/7 Real-Time Server Execution</span> — These bots stream live prices via Binance WebSocket in real-time, reacting to every price tick instantly — not on a delay. Signal analysis runs continuously using momentum, RSI, volatility, and your active technologies. Trades execute through your connected exchange API keys, even when you close your browser or log out.
          </div>
        </div>
      </div>
    </div>
  );
}
