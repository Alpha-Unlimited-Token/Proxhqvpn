/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Quantum Market Genome Engine™ Dashboard is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Quantum Market Genome Engine™
 * - 7-Dimension Genome Analysis™
 * - Market DNA Profiling™
 * - Predictive Genome Scoring™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_5064de4d48f2a616db0718c1
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Dna, TrendingUp, TrendingDown, Minus, Activity, Zap, Shield, BarChart3, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { QMGE_DIMENSION_META, GENOME_PATTERNS, type QMGEGenomeMap, type QMGEDimension } from '@/lib/qmge/types';
import { getQMGESignalColor, getQMGEScoreGrade } from '@/lib/qmge/engine';

interface QMGEDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  qmgeData: QMGEGenomeMap | null;
  symbol: string;
}

interface DataPoint {
  time: number;
  score: number;
}

const PATTERN_COLORS = [
  '#22c55e', '#3b82f6', '#f97316', '#a855f7', '#eab308',
  '#06b6d4', '#ec4899', '#14b8a6', '#f43f5e', '#8b5cf6',
  '#10b981', '#6366f1', '#d946ef', '#0ea5e9', '#84cc16',
];

const MAX_DATA_POINTS = 60;

function getDimensionScore(dimensions: QMGEGenomeMap['dimensions'], key: QMGEDimension) {
  return dimensions.find(d => d.key === key);
}

function computePatternScore(pattern: string, data: QMGEGenomeMap): number {
  const dims = data.dimensions;
  const get = (key: QMGEDimension) => getDimensionScore(dims, key);

  const capitalFlow = get('capital_flow');
  const liquidityTopology = get('liquidity_topology');
  const derivativesPressure = get('derivatives_pressure');
  const whaleDna = get('whale_dna');
  const sentimentVelocity = get('sentiment_velocity');
  const networkHealth = get('network_health');
  const macroCorrelation = get('macro_correlation');

  if (data.genomePattern === pattern) return 100;

  switch (pattern) {
    case 'Alpha Surge':
      return capitalFlow ? (capitalFlow.signal === 'bullish' ? capitalFlow.score : capitalFlow.score * 0.5) : 30;

    case 'Stealth Accumulation':
      return whaleDna && sentimentVelocity
        ? whaleDna.score * 0.7 + (100 - sentimentVelocity.score) * 0.3
        : 25;

    case 'Liquidity Cascade':
      return liquidityTopology ? liquidityTopology.score : 20;

    case 'Whale Convergence':
      return whaleDna
        ? (whaleDna.strength > 0.7 ? whaleDna.score * whaleDna.strength : whaleDna.score * 0.4)
        : 15;

    case 'Sentiment Divergence': {
      if (!sentimentVelocity || !capitalFlow) return 20;
      if (sentimentVelocity.signal !== capitalFlow.signal) {
        return Math.min(100, Math.abs(sentimentVelocity.score - capitalFlow.score) + 30);
      }
      return Math.abs(sentimentVelocity.score - capitalFlow.score) * 0.5;
    }

    case 'Network Awakening':
      return networkHealth ? (networkHealth.signal === 'bullish' ? networkHealth.score : networkHealth.score * 0.4) : 18;

    case 'Macro Decoupling': {
      if (!macroCorrelation) return 15;
      const bullishCount = dims.filter(d => d.key !== 'macro_correlation' && d.signal === 'bullish').length;
      if (macroCorrelation.signal === 'bearish' && bullishCount >= 3) {
        return Math.min(100, (100 - macroCorrelation.score) * 0.8 + bullishCount * 5);
      }
      return (100 - macroCorrelation.score) * 0.3;
    }

    case 'Genome Mutation':
      return Math.min(100, (1 - data.convergenceIndex) * 100);

    case 'Adaptive Resonance': {
      const avg = dims.reduce((s, d) => s + d.score, 0) / (dims.length || 1);
      const mixedSignals = new Set(dims.map(d => d.signal)).size;
      return mixedSignals >= 2 && data.convergenceIndex > 0.3 && data.convergenceIndex < 0.7
        ? Math.min(100, avg * 0.8 + mixedSignals * 10)
        : avg * 0.4;
    }

    case 'Quantum Alignment': {
      const bullish = dims.filter(d => d.signal === 'bullish').length;
      return bullish >= 5
        ? Math.min(100, data.convergenceIndex * 100)
        : data.convergenceIndex * 50;
    }

    case 'Pressure Inversion':
      return derivativesPressure
        ? (derivativesPressure.signal === 'bearish' ? 100 - derivativesPressure.score : derivativesPressure.score * 0.3)
        : 20;

    case 'Flow Reversal':
      return capitalFlow ? Math.min(100, capitalFlow.strength * 100) : 15;

    case 'Silent Accumulation':
      return whaleDna
        ? (whaleDna.signal === 'bullish' ? whaleDna.score * 0.6 : whaleDna.score * 0.2)
        : 10;

    case 'Volatility Genome Shift':
      return Math.min(100, data.mutationRate * 100);

    case 'Cross-Dimensional Convergence':
      return Math.min(100, data.convergenceIndex * 100);

    default:
      return 25;
  }
}

function formatTimeLabel(diffMs: number): string {
  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m`;
  return `${Math.floor(min / 60)}h`;
}

function drawAreaChart(
  canvas: HTMLCanvasElement,
  data: DataPoint[],
  color: string,
  chartWidth: number,
  chartHeight: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = window.devicePixelRatio || 1;
  canvas.width = chartWidth * dpr;
  canvas.height = chartHeight * dpr;
  canvas.style.width = `${chartWidth}px`;
  canvas.style.height = `${chartHeight}px`;
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, chartWidth, chartHeight);

  const padding = { top: 8, right: 40, bottom: 24, left: 8 };
  const plotW = chartWidth - padding.left - padding.right;
  const plotH = chartHeight - padding.top - padding.bottom;

  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.setLineDash([4, 4]);
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padding.top + (plotH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(chartWidth - padding.right, y);
    ctx.stroke();
  }
  ctx.setLineDash([]);

  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.font = '9px monospace';
  ctx.textAlign = 'left';
  for (let i = 0; i <= 4; i++) {
    const y = padding.top + (plotH / 4) * i;
    const val = 100 - (i * 25);
    ctx.fillText(`${val}`, chartWidth - padding.right + 4, y + 3);
  }

  if (data.length < 2) {
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Collecting data...', chartWidth / 2, chartHeight / 2);
    return;
  }

  const now = data[data.length - 1].time;
  const timeRange = Math.max(1000, now - data[0].time);

  const labelCount = Math.min(5, data.length);
  ctx.fillStyle = 'rgba(255,255,255,0.3)';
  ctx.font = '8px monospace';
  ctx.textAlign = 'center';
  for (let i = 0; i < labelCount; i++) {
    const frac = i / (labelCount - 1);
    const x = padding.left + frac * plotW;
    const t = now - timeRange * (1 - frac);
    const diff = now - t;
    if (diff > 500) {
      ctx.fillText(formatTimeLabel(diff), x, chartHeight - 4);
    }
  }
  ctx.fillText('now', chartWidth - padding.right, chartHeight - 4);

  const toX = (t: number) => padding.left + ((t - data[0].time) / timeRange) * plotW;
  const toY = (s: number) => padding.top + plotH - (Math.max(0, Math.min(100, s)) / 100) * plotH;

  const gradient = ctx.createLinearGradient(0, padding.top, 0, padding.top + plotH);
  gradient.addColorStop(0, color + '40');
  gradient.addColorStop(1, color + '05');

  ctx.beginPath();
  ctx.moveTo(toX(data[0].time), padding.top + plotH);
  for (const pt of data) {
    ctx.lineTo(toX(pt.time), toY(pt.score));
  }
  ctx.lineTo(toX(data[data.length - 1].time), padding.top + plotH);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(toX(data[0].time), toY(data[0].score));
  for (let i = 1; i < data.length; i++) {
    ctx.lineTo(toX(data[i].time), toY(data[i].score));
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const lastPt = data[data.length - 1];
  ctx.beginPath();
  ctx.arc(toX(lastPt.time), toY(lastPt.score), 3, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = '#0D1117';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = color;
  ctx.font = 'bold 14px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`${lastPt.score.toFixed(1)}`, chartWidth - padding.right - 2, padding.top + 16);
}

function QMGEDashboard({ isOpen, onClose, qmgeData, symbol }: QMGEDashboardProps) {
  const dimensionHistories = useRef<Record<QMGEDimension, DataPoint[]>>({
    capital_flow: [],
    liquidity_topology: [],
    derivatives_pressure: [],
    whale_dna: [],
    sentiment_velocity: [],
    network_health: [],
    macro_correlation: [],
  });

  const patternHistories = useRef<Record<string, DataPoint[]>>(
    Object.fromEntries(GENOME_PATTERNS.map(p => [p, []]))
  );

  const lastTimestamp = useRef<number>(0);
  const dimCanvasRefs = useRef<Record<string, HTMLCanvasElement | null>>({});
  const patCanvasRefs = useRef<Record<string, HTMLCanvasElement | null>>({});
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    if (!qmgeData || qmgeData.timestamp === lastTimestamp.current) return;
    lastTimestamp.current = qmgeData.timestamp;

    for (const dim of qmgeData.dimensions) {
      const hist = dimensionHistories.current[dim.key];
      hist.push({ time: qmgeData.timestamp, score: dim.score });
      if (hist.length > MAX_DATA_POINTS) hist.splice(0, hist.length - MAX_DATA_POINTS);
    }

    for (const pattern of GENOME_PATTERNS) {
      const score = computePatternScore(pattern, qmgeData);
      const hist = patternHistories.current[pattern];
      hist.push({ time: qmgeData.timestamp, score });
      if (hist.length > MAX_DATA_POINTS) hist.splice(0, hist.length - MAX_DATA_POINTS);
    }
  }, [qmgeData]);

  const renderCharts = useCallback(() => {
    if (!isOpen) return;

    const dimKeys: QMGEDimension[] = [
      'capital_flow', 'liquidity_topology', 'derivatives_pressure',
      'whale_dna', 'sentiment_velocity', 'network_health', 'macro_correlation',
    ];

    for (const key of dimKeys) {
      const canvas = dimCanvasRefs.current[key];
      if (canvas) {
        drawAreaChart(canvas, dimensionHistories.current[key], QMGE_DIMENSION_META[key].color, 280, 160);
      }
    }

    for (let i = 0; i < GENOME_PATTERNS.length; i++) {
      const pattern = GENOME_PATTERNS[i];
      const canvas = patCanvasRefs.current[pattern];
      if (canvas) {
        drawAreaChart(canvas, patternHistories.current[pattern], PATTERN_COLORS[i], 220, 120);
      }
    }

    animFrameRef.current = requestAnimationFrame(renderCharts);
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      animFrameRef.current = requestAnimationFrame(renderCharts);
    }
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isOpen, renderCharts]);

  const patternScores = useMemo(() => {
    if (!qmgeData) return {} as Record<string, number>;
    return Object.fromEntries(
      GENOME_PATTERNS.map(p => [p, computePatternScore(p, qmgeData)])
    );
  }, [qmgeData]);

  const grade = useMemo(() => {
    if (!qmgeData) return null;
    return getQMGEScoreGrade(qmgeData.aggregateScore);
  }, [qmgeData]);

  const signalColor = useMemo(() => {
    if (!qmgeData) return '#eab308';
    return getQMGESignalColor(qmgeData.aggregateSignal);
  }, [qmgeData]);

  const signalLabel = useMemo(() => {
    if (!qmgeData) return 'N/A';
    return qmgeData.aggregateSignal.replace(/_/g, ' ').toUpperCase();
  }, [qmgeData]);

  const predictionIcon = useMemo(() => {
    if (!qmgeData) return <Minus className="w-4 h-4" />;
    switch (qmgeData.prediction.direction) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Minus className="w-4 h-4 text-yellow-400" />;
    }
  }, [qmgeData]);

  const trendIcon = useCallback((trend: 'up' | 'down' | 'flat') => {
    switch (trend) {
      case 'up': return <ArrowUpRight className="w-3 h-3 text-green-400" />;
      case 'down': return <ArrowDownRight className="w-3 h-3 text-red-400" />;
      default: return <Minus className="w-3 h-3 text-gray-500" />;
    }
  }, []);

  const signalBadgeColor = useCallback((signal: 'bullish' | 'bearish' | 'neutral') => {
    switch (signal) {
      case 'bullish': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'bearish': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    }
  }, []);

  if (!isOpen) return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          data-testid="qmge-dashboard-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[9999] flex flex-col"
          style={{ backgroundColor: '#0D1117' }}
        >
          <div
            data-testid="qmge-dashboard-header"
            className="flex items-center justify-between px-4 py-3 border-b"
            style={{ borderColor: 'rgba(107,114,128,0.5)', background: 'linear-gradient(to right, #0D1117, #1a1040, #0D1117)' }}
          >
            <div className="flex items-center gap-3">
              <Dna className="w-6 h-6 text-purple-400" />
              <div>
                <h1 className="text-lg font-bold text-white tracking-tight">
                  QMGE™ Live Dashboard
                </h1>
                <span className="text-xs text-gray-400">{symbol || 'N/A'}</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {grade && (
                <span
                  data-testid="qmge-dashboard-grade"
                  className="text-xs font-bold px-2 py-0.5 rounded"
                  style={{ color: grade.color, border: `1px solid ${grade.color}40` }}
                >
                  {grade.grade} — {grade.label}
                </span>
              )}
              <button
                data-testid="qmge-dashboard-close"
                onClick={onClose}
                className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #0D1117' }}>
            {qmgeData && (
              <div
                data-testid="qmge-summary-bar"
                className="flex flex-wrap items-center gap-3 px-4 py-3 border-b"
                style={{ borderColor: 'rgba(107,114,128,0.3)', backgroundColor: '#161B22' }}
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Score</span>
                  <span className="text-sm font-bold" style={{ color: signalColor }}>
                    {qmgeData.aggregateScore.toFixed(1)}
                  </span>
                </div>
                <div className="w-px h-5 bg-gray-700" />
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Signal</span>
                  <span
                    data-testid="qmge-summary-signal"
                    className="text-xs font-bold px-2 py-0.5 rounded"
                    style={{ color: signalColor, border: `1px solid ${signalColor}40`, backgroundColor: `${signalColor}15` }}
                  >
                    {signalLabel}
                  </span>
                </div>
                <div className="w-px h-5 bg-gray-700" />
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Pattern</span>
                  <span className="text-xs font-semibold text-purple-300">{qmgeData.genomePattern}</span>
                </div>
                <div className="w-px h-5 bg-gray-700" />
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Convergence</span>
                  <span className="text-xs font-mono text-gray-300">{(qmgeData.convergenceIndex * 100).toFixed(1)}%</span>
                </div>
                <div className="w-px h-5 bg-gray-700" />
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Mutation</span>
                  <span className="text-xs font-mono text-gray-300">{(qmgeData.mutationRate * 100).toFixed(1)}%</span>
                </div>
                <div className="w-px h-5 bg-gray-700" />
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-gray-500 tracking-wider">Prediction</span>
                  {predictionIcon}
                  <span className="text-xs text-gray-300 capitalize">{qmgeData.prediction.direction}</span>
                </div>
              </div>
            )}

            <div className="px-4 py-4">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-white tracking-wide">
                  7 Genome Dimensions — Live Analysis
                </h2>
              </div>

              <div
                data-testid="qmge-dimensions-grid"
                className="grid grid-cols-1 md:grid-cols-2 gap-3"
              >
                {(Object.keys(QMGE_DIMENSION_META) as QMGEDimension[]).map((key) => {
                  const meta = QMGE_DIMENSION_META[key];
                  const dim = qmgeData?.dimensions.find(d => d.key === key);
                  return (
                    <div
                      key={key}
                      data-testid={`qmge-dimension-card-${key}`}
                      className="rounded-lg p-3"
                      style={{ backgroundColor: '#161B22', border: '1px solid rgba(107,114,128,0.3)' }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: meta.color }}
                          />
                          <span className="text-xs font-semibold text-gray-200">{meta.name}</span>
                        </div>
                        {dim && (
                          <span
                            data-testid={`qmge-dimension-signal-${key}`}
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${signalBadgeColor(dim.signal)}`}
                          >
                            {dim.signal.toUpperCase()}
                          </span>
                        )}
                      </div>

                      <canvas
                        ref={(el) => { dimCanvasRefs.current[key] = el; }}
                        data-testid={`qmge-dimension-chart-${key}`}
                        style={{ width: 280, height: 160 }}
                        className="w-full max-w-[280px]"
                      />

                      {dim && dim.subMetrics.length > 0 && (
                        <div
                          data-testid={`qmge-dimension-submetrics-${key}`}
                          className="flex flex-wrap gap-x-3 gap-y-1 mt-2 pt-2"
                          style={{ borderTop: '1px solid rgba(107,114,128,0.2)' }}
                        >
                          {dim.subMetrics.map((sm, idx) => (
                            <div key={idx} className="flex items-center gap-1">
                              {trendIcon(sm.trend)}
                              <span className="text-[10px] text-gray-500">{sm.label}:</span>
                              <span className="text-[10px] font-mono text-gray-300">{sm.value}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="px-4 py-4 pb-8">
              <div className="flex items-center gap-2 mb-4">
                <Dna className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Proprietary Genome Patterns™ — Pattern Detection
                </h2>
              </div>

              <div
                data-testid="qmge-patterns-grid"
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
              >
                {GENOME_PATTERNS.map((pattern, idx) => {
                  const isActive = qmgeData?.genomePattern === pattern;
                  const score = patternScores[pattern] ?? 0;
                  const color = PATTERN_COLORS[idx];
                  return (
                    <div
                      key={pattern}
                      data-testid={`qmge-pattern-card-${idx}`}
                      className="rounded-lg p-3"
                      style={{
                        backgroundColor: '#161B22',
                        border: isActive ? `1px solid ${color}80` : '1px solid rgba(107,114,128,0.3)',
                        boxShadow: isActive ? `0 0 12px ${color}20` : 'none',
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-gray-200 truncate pr-2">{pattern}</span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {isActive && (
                            <span
                              data-testid={`qmge-pattern-active-${idx}`}
                              className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                              style={{ color, backgroundColor: `${color}20`, border: `1px solid ${color}50` }}
                            >
                              ACTIVE
                            </span>
                          )}
                          <span className="text-xs font-mono" style={{ color }}>
                            {score.toFixed(0)}%
                          </span>
                        </div>
                      </div>

                      <canvas
                        ref={(el) => { patCanvasRefs.current[pattern] = el; }}
                        data-testid={`qmge-pattern-chart-${idx}`}
                        style={{ width: 220, height: 120 }}
                        className="w-full max-w-[220px]"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}

export default QMGEDashboard;
