/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TradingPlatformNavbar™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_cb36370c090f6c5022159bf9
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { Link, useLocation } from "wouter";
import { TrendingUp, BarChart3, Menu, X, Zap, User, Settings, Shield, LogOut, Smartphone, FlaskConical, Image, ShoppingBag, Award, ChevronDown, Download, ArrowLeftRight, Brain, Cpu, Layers, Pickaxe, ShieldCheck, Search, Activity, Wallet, AlertTriangle, FileText, Fish } from "lucide-react";
import { useState, useEffect, lazy, Suspense } from "react";
import tradingLogo from "@/assets/logos/trading-logo.png";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
const LazyMultiWalletManager = lazy(() => import("@/components/MultiWalletManager").then(m => ({ default: m.MultiWalletManager })));
const LazyThemeConfigurator = lazy(() => import("./ThemeConfigurator").then(m => ({ default: m.ThemeConfigurator })));
const LanguageSwitcher = lazy(() => import("./LanguageSwitcher").then(m => ({ default: m.LanguageSwitcher })));

const PRIMARY_LINKS = [
  { href: "/", label: "Home", icon: Zap },
  { href: "/terminal", label: "Terminal", icon: TrendingUp },
  { href: "/features", label: "Features", icon: Layers },
];

const MORE_LINKS = [
  { href: "/arbitrage", label: "Arbitrage", icon: BarChart3 },
  { href: "/technology", label: "Technology", icon: Cpu },
  { href: "/exchange", label: "Exchange", icon: ArrowLeftRight },
  { href: "/safesend", label: "SafeSend", icon: ShieldCheck },
  { href: "/portfolio-health", label: "Portfolio Health", icon: Activity },
  { href: "/whale-watch", label: "Whale Watch", icon: Fish },
  { href: "/rug-pull-detector", label: "Rug Pull Detector", icon: AlertTriangle },
  { href: "/multi-chain-wallet", label: "Multi-Chain Wallet", icon: Wallet },
  { href: "/tax-report", label: "Tax Report", icon: FileText },
  { href: "/backtest", label: "Backtest", icon: FlaskConical },
  { href: "/miner", label: "Mining", icon: Pickaxe },
  { href: "/nft", label: "NFTs", icon: Image },
  { href: "/security-overview", label: "Security", icon: Shield },
  { href: "/forensic-services", label: "Forensic Recovery", icon: Search },
  { href: "/alpha-trading/phantom-vault", label: "Phantom Vault", icon: Shield },
  { href: "/software-downloads", label: "Downloads", icon: Download },
  { href: "/ambassador", label: "Ambassador", icon: Award },
];

const ALL_MOBILE_LINKS = [...PRIMARY_LINKS, ...MORE_LINKS];

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function TradingPlatformNavbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isAppInstalled, setIsAppInstalled] = useState(false);
  const [showAppModal, setShowAppModal] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showThemeConfig, setShowThemeConfig] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('trading-dark-mode');
    if (saved !== null) {
      setIsDarkMode(saved === 'true');
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('trading-dark-mode', String(isDarkMode));
    document.documentElement.classList.toggle('light-mode', !isDarkMode);
  }, [isDarkMode]);

  useEffect(() => {
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIOSDevice);
    
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                         (window.navigator as any).standalone === true;
    setIsAppInstalled(isStandalone);

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsAppInstalled(true);
      }
      setDeferredPrompt(null);
      setShowAppModal(false);
    } else if (isIOS) {
      setShowAppModal(true);
    } else {
      setShowAppModal(true);
    }
  };

  const isMoreActive = MORE_LINKS.some(link => location === link.href);

  return (
    <nav className="tp-navbar" data-testid="trading-platform-navbar">
      <div className="max-w-7xl mx-auto flex items-center justify-between w-full px-2 sm:px-4">
        <Link href="/">
          <div className="tp-navbar-brand cursor-pointer flex items-center gap-2 flex-shrink-0" data-testid="link-trading-home">
            <img src={tradingLogo} alt="Alpha Trading" className="h-8 w-auto flex-shrink-0" style={{ maxHeight: '2rem', height: '2rem' }} />
            <span className="text-lg font-bold text-white whitespace-nowrap"><span className="text-[#00D4FF]">ALPHA</span></span>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-1 lg:gap-2 ml-4">
          {PRIMARY_LINKS.map((link) => {
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <div
                  className={`flex items-center gap-1 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap px-2 py-1.5 rounded-lg ${
                    isActive
                      ? "text-[#00D4FF] bg-[#00D4FF]/10"
                      : "text-[#94A3B8] hover:text-white hover:bg-white/5"
                  }`}
                  data-testid={`link-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <link.icon size={14} className="flex-shrink-0" />
                  {link.label}
                </div>
              </Link>
            );
          })}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className={`flex items-center gap-1 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap px-2 py-1.5 rounded-lg ${
                  isMoreActive
                    ? "text-[#00D4FF] bg-[#00D4FF]/10"
                    : "text-[#94A3B8] hover:text-white hover:bg-white/5"
                }`}
                data-testid="nav-more-dropdown"
              >
                More
                <ChevronDown size={12} className="opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="center" className="bg-[#0D1117] border-[#1E3A5F] min-w-[180px] z-[200]">
              {MORE_LINKS.map((link) => {
                const isActive = location === link.href;
                return (
                  <DropdownMenuItem key={link.href} asChild>
                    <Link
                      href={link.href}
                      className={`cursor-pointer flex items-center gap-2 ${
                        isActive ? "text-[#00D4FF]" : "text-[#94A3B8] hover:text-white"
                      }`}
                      data-testid={`link-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <link.icon size={16} /> {link.label}
                    </Link>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>

          {!isAppInstalled && (
            <button
              onClick={handleInstallClick}
              className="flex items-center gap-1 text-sm font-medium text-[#00D4FF] hover:text-white transition-colors cursor-pointer whitespace-nowrap px-2 py-1.5 rounded-lg hover:bg-white/5"
              data-testid="button-get-app-nav"
            >
              <Smartphone size={14} />
              App
              <span className="bg-[#00D4FF] text-[#0A1628] text-[9px] font-bold px-1 py-0.5 rounded uppercase">
                New
              </span>
            </button>
          )}
        </div>

        <div className="hidden md:flex items-center gap-2 flex-shrink-0">
          <Suspense fallback={null}><LazyMultiWalletManager compact variant="trading-platform" /></Suspense>
          {isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1.5 cursor-pointer hover:opacity-80 transition-opacity">
                <Avatar className="h-7 w-7 border border-[#00D4FF]/30">
                  <AvatarImage src={user.profileImageUrl || undefined} />
                  <AvatarFallback className="bg-[#152238] text-[#00D4FF] text-xs">
                    {user.displayName?.charAt(0) || user.username?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
                <ChevronDown size={12} className="text-[#94A3B8]" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" sideOffset={12} className="bg-[#0D1117] border-[#1E3A5F] min-w-[180px] z-[200]">
                <DropdownMenuLabel className="text-white text-sm font-medium pb-0">
                  {user.displayName || user.username}
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-[#1E3A5F]" />
                <Link href="/account">
                  <DropdownMenuItem className="cursor-pointer text-[#94A3B8] hover:text-white hover:bg-[#152238]">
                    <User className="mr-2 h-4 w-4" />
                    My Account
                  </DropdownMenuItem>
                </Link>
                <Link href="/security">
                  <DropdownMenuItem className="cursor-pointer text-[#94A3B8] hover:text-white hover:bg-[#152238]">
                    <Shield className="mr-2 h-4 w-4" />
                    Security
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator className="bg-[#1E3A5F]" />
                <DropdownMenuItem 
                  className="cursor-pointer text-red-400 hover:text-red-300 hover:bg-[#152238]"
                  onClick={() => window.location.href = '/api/logout'}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <button 
              className="tp-btn-primary text-sm px-4 py-2 min-h-[44px]"
              onClick={() => window.location.href = '/login'}
              data-testid="button-sign-in"
            >
              Sign In
            </button>
          )}
          <LanguageSwitcher />
        </div>

        <button
          className="md:hidden text-white p-2 flex-shrink-0 min-w-[44px] min-h-[44px] flex items-center justify-center"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#060A10]/95 backdrop-blur-lg border-b border-white/5 py-3 px-4 z-50 max-h-[80vh] overflow-y-auto">
          <div className="flex flex-col divide-y divide-[#1E293B]/40">
            {ALL_MOBILE_LINKS.map((link) => {
              const isActive = location === link.href;
              return (
                <Link key={link.href} href={link.href}>
                  <div
                    className={`flex items-center gap-3 py-3 text-sm font-medium cursor-pointer ${
                      isActive ? "text-[#00D4FF]" : "text-gray-400"
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isActive ? 'bg-[#00D4FF]/10' : 'bg-white/5'}`}>
                      <link.icon size={16} />
                    </div>
                    {link.label}
                  </div>
                </Link>
              );
            })}
          </div>
          {!isAppInstalled && (
            <button
              onClick={() => {
                handleInstallClick();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-3 py-3 text-sm font-medium text-[#00D4FF] cursor-pointer w-full mt-1"
              data-testid="button-get-app-mobile"
            >
              <div className="w-8 h-8 rounded-lg bg-[#00D4FF]/10 flex items-center justify-center flex-shrink-0">
                <Smartphone size={16} />
              </div>
              Get App
              <span className="bg-[#00D4FF] text-[#0A1628] text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ml-1">
                New
              </span>
            </button>
          )}
          <div className="py-3 border-t border-[#1E293B]/40 mt-2">
            <Suspense fallback={null}><LazyMultiWalletManager variant="trading-platform" /></Suspense>
          </div>
          {isAuthenticated && user ? (
            <div className="pt-3 mt-1 border-t border-[#1E293B]/40 space-y-1">
              <div className="flex items-center gap-3 py-2">
                <Avatar className="h-8 w-8 border border-white/10">
                  <AvatarImage src={user.profileImageUrl || undefined} />
                  <AvatarFallback className="bg-gradient-to-br from-[#00D4FF]/30 to-[#a855f7]/30 text-[#00D4FF] text-xs">
                    {user.displayName?.charAt(0) || user.username?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="text-white font-medium text-sm">{user.displayName || user.username}</span>
              </div>
              <Link href="/account">
                <div className="flex items-center gap-3 py-2 text-gray-400 text-sm" onClick={() => setMobileMenuOpen(false)}>
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                    <User size={16} />
                  </div>
                  My Account
                </div>
              </Link>
              <Link href="/security">
                <div className="flex items-center gap-3 py-2 text-gray-400 text-sm" onClick={() => setMobileMenuOpen(false)}>
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                    <Shield size={16} />
                  </div>
                  Security
                </div>
              </Link>
              <div 
                className="flex items-center gap-3 py-2 text-red-400 cursor-pointer text-sm"
                onClick={() => window.location.href = '/api/logout'}
              >
                <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                  <LogOut size={16} />
                </div>
                Sign Out
              </div>
            </div>
          ) : (
            <div className="pt-3 mt-1 border-t border-[#1E293B]/40">
              <button 
                className="w-full py-2.5 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#060A10] font-bold rounded-xl text-sm"
                onClick={() => window.location.href = '/login'}
              >
                Sign In
              </button>
            </div>
          )}
        </div>
      )}

      {showAppModal && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowAppModal(false)}>
          <div 
            className="bg-[#0A1628] border border-[#00D4FF]/30 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-[#00D4FF] to-[#0066FF] rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Smartphone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Install Alpha Trading</h3>
              
              {isIOS ? (
                <div className="text-left space-y-3 my-6">
                  <p className="text-[#94A3B8] text-sm mb-4">To install on iOS:</p>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                    <span className="text-white text-sm">Tap the <span className="text-[#00D4FF]">Share</span> button at the bottom of Safari</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                    <span className="text-white text-sm">Scroll and tap <span className="text-[#00D4FF]">"Add to Home Screen"</span></span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                    <span className="text-white text-sm">Tap <span className="text-[#00D4FF]">"Add"</span></span>
                  </div>
                </div>
              ) : (
                <div className="text-left space-y-3 my-6">
                  <p className="text-[#94A3B8] text-sm mb-4">To install on your device:</p>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                    <span className="text-white text-sm">Look for the <span className="text-[#00D4FF]">Install</span> prompt in your browser</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                    <span className="text-white text-sm">Or tap the browser menu (⋮) and select <span className="text-[#00D4FF]">"Add to Home Screen"</span></span>
                  </div>
                </div>
              )}
              
              <button
                onClick={() => setShowAppModal(false)}
                className="w-full py-3 bg-[#00D4FF] text-[#0A1628] font-bold rounded-xl hover:bg-[#00D4FF]/90 transition-colors"
              >
                Got it!
              </button>
            </div>
          </div>
        </div>
      )}

      <Suspense fallback={null}><LazyThemeConfigurator isOpen={showThemeConfig} onClose={() => setShowThemeConfig(false)} /></Suspense>
    </nav>
  );
}
