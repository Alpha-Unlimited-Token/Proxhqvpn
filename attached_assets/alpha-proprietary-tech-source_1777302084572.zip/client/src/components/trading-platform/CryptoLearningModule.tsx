/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Crypto Learning Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Crypto Learning Engine™
 * - Interactive Education Module™
 * - Progress Tracking System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_df51e81c68fc88b302047149
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, BookOpen, Trophy, Star, Zap, Target, CheckCircle,
  XCircle, ChevronRight, Lock, Play, Award, Flame, TrendingUp,
  BarChart3, Shield, Coins, Clock, ArrowRight, RefreshCw, X,
  Lightbulb, Brain, Rocket, Medal, Crown, Gift, Sparkles, Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface LearningProgress {
  totalXP: number;
  level: number;
  currentStreak: number;
  longestStreak: number;
  lastActiveDate: string;
  completedLessons: string[];
  completedQuizzes: string[];
  achievements: string[];
  quizScores: Record<string, number>;
}

interface Lesson {
  id: string;
  title: string;
  description: string;
  content: LessonContent[];
  xpReward: number;
  duration: string;
}

interface LessonContent {
  type: 'text' | 'tip' | 'warning' | 'example';
  content: string;
}

interface Quiz {
  id: string;
  lessonId: string;
  questions: QuizQuestion[];
  passingScore: number;
  xpReward: number;
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface LearningPath {
  id: string;
  title: string;
  icon: string;
  color: string;
  description: string;
  lessons: Lesson[];
  quiz: Quiz;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  requirement: string;
  xpBonus: number;
}

const STORAGE_KEY = 'alpha-learning-progress';

const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_lesson', title: 'First Steps', description: 'Complete your first lesson', icon: '🎯', requirement: 'Complete 1 lesson', xpBonus: 50 },
  { id: 'quiz_master', title: 'Quiz Master', description: 'Score 100% on any quiz', icon: '🏆', requirement: 'Perfect quiz score', xpBonus: 100 },
  { id: 'streak_3', title: 'On Fire', description: 'Maintain a 3-day learning streak', icon: '🔥', requirement: '3-day streak', xpBonus: 75 },
  { id: 'streak_7', title: 'Dedicated Learner', description: 'Maintain a 7-day learning streak', icon: '⚡', requirement: '7-day streak', xpBonus: 150 },
  { id: 'complete_path', title: 'Path Master', description: 'Complete an entire learning path', icon: '🎓', requirement: 'Complete 1 path', xpBonus: 200 },
  { id: 'level_5', title: 'Rising Star', description: 'Reach level 5', icon: '⭐', requirement: 'Level 5', xpBonus: 100 },
  { id: 'level_10', title: 'Trading Scholar', description: 'Reach level 10', icon: '👑', requirement: 'Level 10', xpBonus: 250 },
  { id: 'all_basics', title: 'Foundation Builder', description: 'Complete Trading Basics path', icon: '🏗️', requirement: 'Trading Basics complete', xpBonus: 150 },
];

const LEARNING_PATHS: LearningPath[] = [
  {
    id: 'trading_basics',
    title: 'Trading Basics',
    icon: '📚',
    color: '#00D4FF',
    description: 'Learn the fundamentals of cryptocurrency trading',
    lessons: [
      {
        id: 'tb_1',
        title: 'What is Cryptocurrency?',
        description: 'Understanding digital currencies and blockchain',
        xpReward: 25,
        duration: '5 min',
        content: [
          { type: 'text', content: 'Cryptocurrency is a digital or virtual currency that uses cryptography for security. Unlike traditional currencies, cryptocurrencies operate on decentralized networks based on blockchain technology.' },
          { type: 'tip', content: 'Bitcoin was the first cryptocurrency, created in 2009 by an anonymous person or group using the name Satoshi Nakamoto.' },
          { type: 'text', content: 'Key characteristics of cryptocurrencies include: Decentralization (no central authority), Transparency (all transactions are recorded on a public ledger), Security (cryptographic protocols protect transactions), and Limited Supply (many have a fixed maximum supply).' },
          { type: 'example', content: 'Think of Bitcoin like digital gold - it\'s scarce (only 21 million will ever exist), divisible, and can be transferred anywhere in the world within minutes.' },
        ],
      },
      {
        id: 'tb_2',
        title: 'Understanding Trading Pairs',
        description: 'Learn how trading pairs work in crypto markets',
        xpReward: 30,
        duration: '6 min',
        content: [
          { type: 'text', content: 'A trading pair represents two assets that can be traded against each other. For example, BTC/USDT means you\'re trading Bitcoin against Tether (a stablecoin pegged to the US dollar).' },
          { type: 'text', content: 'The first currency is called the BASE currency, and the second is the QUOTE currency. When you buy BTC/USDT, you\'re buying Bitcoin and selling USDT.' },
          { type: 'tip', content: 'Common quote currencies include USDT, USDC, BTC, and ETH. Stablecoin pairs like /USDT are popular because they\'re easier to value in dollar terms.' },
          { type: 'example', content: 'If ETH/USDT = 3500, it means 1 ETH costs 3500 USDT. If you have 7000 USDT, you could buy 2 ETH.' },
        ],
      },
      {
        id: 'tb_3',
        title: 'Market Orders vs Limit Orders',
        description: 'Different ways to execute trades',
        xpReward: 35,
        duration: '7 min',
        content: [
          { type: 'text', content: 'A MARKET ORDER executes immediately at the current best available price. It guarantees execution but not price.' },
          { type: 'text', content: 'A LIMIT ORDER lets you specify the exact price you want. It only executes when the market reaches your price.' },
          { type: 'warning', content: 'Market orders in volatile conditions can result in slippage - executing at a worse price than expected.' },
          { type: 'tip', content: 'Use limit orders for better price control, especially with larger trades or in volatile markets.' },
          { type: 'example', content: 'Bitcoin is at $100,000. A market buy executes now at ~$100,000. A limit buy at $95,000 waits until Bitcoin drops to that price.' },
        ],
      },
    ],
    quiz: {
      id: 'quiz_tb',
      lessonId: 'trading_basics',
      passingScore: 70,
      xpReward: 75,
      questions: [
        { id: 'q1', question: 'What technology underlies most cryptocurrencies?', options: ['Cloud computing', 'Blockchain', 'AI/Machine Learning', 'Quantum computing'], correctAnswer: 1, explanation: 'Blockchain is the distributed ledger technology that underlies cryptocurrencies, providing transparency and security.' },
        { id: 'q2', question: 'In the trading pair ETH/USDT, which is the base currency?', options: ['USDT', 'ETH', 'USD', 'Neither'], correctAnswer: 1, explanation: 'The first currency in a trading pair (ETH) is the base currency - it\'s what you\'re buying or selling.' },
        { id: 'q3', question: 'Which order type guarantees execution but not price?', options: ['Limit order', 'Stop order', 'Market order', 'Conditional order'], correctAnswer: 2, explanation: 'Market orders execute immediately at the best available price, guaranteeing execution but potentially at a different price than expected.' },
        { id: 'q4', question: 'What is the maximum supply of Bitcoin?', options: ['Unlimited', '100 million', '21 million', '1 billion'], correctAnswer: 2, explanation: 'Bitcoin has a fixed maximum supply of 21 million coins, making it scarce like digital gold.' },
      ],
    },
  },
  {
    id: 'technical_analysis',
    title: 'Technical Analysis',
    icon: '📊',
    color: '#10B981',
    description: 'Learn to read charts and identify patterns',
    lessons: [
      {
        id: 'ta_1',
        title: 'Introduction to Charts',
        description: 'Understanding candlestick charts',
        xpReward: 30,
        duration: '6 min',
        content: [
          { type: 'text', content: 'Candlestick charts display price movements over time. Each candlestick shows four prices: Open, High, Low, and Close (OHLC).' },
          { type: 'text', content: 'Green/white candles indicate the price closed higher than it opened (bullish). Red/black candles show the price closed lower (bearish).' },
          { type: 'tip', content: 'The "body" shows the open-to-close range, while the "wicks" (shadows) show the high and low prices during that period.' },
          { type: 'example', content: 'A long green candle with short wicks indicates strong buying pressure and bullish sentiment.' },
        ],
      },
      {
        id: 'ta_2',
        title: 'Support and Resistance',
        description: 'Key price levels that matter',
        xpReward: 35,
        duration: '7 min',
        content: [
          { type: 'text', content: 'SUPPORT is a price level where buying pressure is strong enough to prevent further decline. Think of it as a "floor" where price tends to bounce.' },
          { type: 'text', content: 'RESISTANCE is a price level where selling pressure prevents further rise. It acts as a "ceiling" that price struggles to break through.' },
          { type: 'tip', content: 'When price breaks through resistance, that level often becomes new support (and vice versa).' },
          { type: 'warning', content: 'Support and resistance are zones, not exact prices. Don\'t expect price to bounce at exactly the same level every time.' },
        ],
      },
      {
        id: 'ta_3',
        title: 'Moving Averages',
        description: 'Trend-following indicators',
        xpReward: 40,
        duration: '8 min',
        content: [
          { type: 'text', content: 'Moving Averages (MA) smooth out price data to show the overall trend direction. Common periods are 20, 50, 100, and 200.' },
          { type: 'text', content: 'SMA (Simple Moving Average) gives equal weight to all periods. EMA (Exponential Moving Average) gives more weight to recent prices.' },
          { type: 'tip', content: 'The "Golden Cross" (50 MA crossing above 200 MA) is bullish. The "Death Cross" (50 MA below 200 MA) is bearish.' },
          { type: 'example', content: 'If price is above the 200-day MA, the long-term trend is considered bullish. Many traders use this as a filter.' },
        ],
      },
    ],
    quiz: {
      id: 'quiz_ta',
      lessonId: 'technical_analysis',
      passingScore: 70,
      xpReward: 85,
      questions: [
        { id: 'q1', question: 'What does a green candlestick indicate?', options: ['Price went down', 'Price closed higher than it opened', 'High trading volume', 'A new all-time high'], correctAnswer: 1, explanation: 'Green/white candles show the closing price was higher than the opening price - bullish movement.' },
        { id: 'q2', question: 'What is a support level?', options: ['The highest price ever', 'A level where selling is strong', 'A level where buying prevents further decline', 'The average price'], correctAnswer: 2, explanation: 'Support is a price level where enough buying interest exists to prevent the price from falling further.' },
        { id: 'q3', question: 'What is a "Golden Cross"?', options: ['When price hits all-time high', '50 MA crossing above 200 MA', 'A pattern of golden candles', 'Reaching 100% profit'], correctAnswer: 1, explanation: 'A Golden Cross occurs when the 50-period moving average crosses above the 200-period moving average, signaling bullish momentum.' },
        { id: 'q4', question: 'Which moving average reacts faster to price changes?', options: ['SMA', 'EMA', 'They\'re the same', 'Neither reacts to price'], correctAnswer: 1, explanation: 'EMA (Exponential Moving Average) gives more weight to recent prices, making it more responsive to new data.' },
      ],
    },
  },
  {
    id: 'risk_management',
    title: 'Risk Management',
    icon: '🛡️',
    color: '#F59E0B',
    description: 'Protect your capital and manage risk',
    lessons: [
      {
        id: 'rm_1',
        title: 'The 1% Rule',
        description: 'Never risk more than you can afford to lose',
        xpReward: 35,
        duration: '6 min',
        content: [
          { type: 'text', content: 'The 1% Rule states you should never risk more than 1% of your total trading capital on a single trade. This protects you from catastrophic losses.' },
          { type: 'example', content: 'With a $10,000 account, you should risk max $100 per trade. Even 10 consecutive losses only costs 10% of your capital.' },
          { type: 'warning', content: 'Many beginners lose their entire account by risking too much on single trades, especially with leverage.' },
          { type: 'tip', content: 'Adjust your position size based on your stop loss distance to maintain consistent risk.' },
        ],
      },
      {
        id: 'rm_2',
        title: 'Stop Losses and Take Profits',
        description: 'Automating your exit strategy',
        xpReward: 40,
        duration: '7 min',
        content: [
          { type: 'text', content: 'A STOP LOSS is an order that automatically closes your position if price moves against you by a certain amount, limiting your loss.' },
          { type: 'text', content: 'A TAKE PROFIT is an order that automatically closes your position when you reach your profit target.' },
          { type: 'tip', content: 'Always set your stop loss BEFORE entering a trade. Decide where you\'ll exit if wrong before you think about profits.' },
          { type: 'warning', content: 'Never move your stop loss further away from your entry to "give the trade more room" - this is how small losses become big ones.' },
        ],
      },
      {
        id: 'rm_3',
        title: 'Risk-Reward Ratio',
        description: 'Making math work in your favor',
        xpReward: 45,
        duration: '8 min',
        content: [
          { type: 'text', content: 'Risk-Reward Ratio (RRR) compares potential loss to potential gain. A 1:3 ratio means risking $1 to potentially make $3.' },
          { type: 'text', content: 'With a 1:3 RRR, you only need to win 25% of trades to break even. With 1:2, you need 33% winners.' },
          { type: 'tip', content: 'Professional traders typically aim for at least 1:2 risk-reward. Some won\'t take trades below 1:3.' },
          { type: 'example', content: 'Buy ETH at $3000 with stop loss at $2900 (risk $100). Take profit at $3300 (reward $300). That\'s 1:3 RRR.' },
        ],
      },
    ],
    quiz: {
      id: 'quiz_rm',
      lessonId: 'risk_management',
      passingScore: 70,
      xpReward: 90,
      questions: [
        { id: 'q1', question: 'According to the 1% rule, how much should you risk with a $5,000 account?', options: ['$500', '$100', '$50', '$5'], correctAnswer: 2, explanation: '1% of $5,000 = $50. This keeps you in the game even during losing streaks.' },
        { id: 'q2', question: 'What should you set BEFORE entering a trade?', options: ['Take profit only', 'Stop loss', 'Leverage', 'News alerts'], correctAnswer: 1, explanation: 'Always define your exit strategy (stop loss) before entering. Know how much you\'re willing to lose.' },
        { id: 'q3', question: 'With a 1:3 risk-reward ratio, what win rate do you need to break even?', options: ['50%', '75%', '33%', '25%'], correctAnswer: 3, explanation: 'With 1:3 RRR, 1 win covers 3 losses. So winning just 25% of trades breaks even.' },
        { id: 'q4', question: 'What should you NEVER do with a stop loss?', options: ['Set it before entry', 'Use trailing stops', 'Move it further away to avoid being stopped out', 'Place it at technical levels'], correctAnswer: 2, explanation: 'Moving stop losses further away turns small manageable losses into potentially devastating ones.' },
      ],
    },
  },
  {
    id: 'defi_basics',
    title: 'DeFi Fundamentals',
    icon: '🌐',
    color: '#8B5CF6',
    description: 'Explore decentralized finance',
    lessons: [
      {
        id: 'df_1',
        title: 'What is DeFi?',
        description: 'Decentralized finance explained',
        xpReward: 30,
        duration: '6 min',
        content: [
          { type: 'text', content: 'DeFi (Decentralized Finance) refers to financial services built on blockchain networks, operating without traditional intermediaries like banks.' },
          { type: 'text', content: 'Key DeFi services include: lending/borrowing, decentralized exchanges (DEXs), yield farming, and liquidity provision.' },
          { type: 'tip', content: 'DeFi protocols are typically governed by smart contracts - self-executing code that runs exactly as programmed.' },
          { type: 'warning', content: 'DeFi carries unique risks including smart contract bugs, impermanent loss, and protocol hacks. Always DYOR (Do Your Own Research).' },
        ],
      },
      {
        id: 'df_2',
        title: 'DEXs vs CEXs',
        description: 'Decentralized vs Centralized Exchanges',
        xpReward: 35,
        duration: '7 min',
        content: [
          { type: 'text', content: 'CEX (Centralized Exchange): Companies like Binance, Coinbase that hold your funds. Easy to use, but you don\'t control your keys.' },
          { type: 'text', content: 'DEX (Decentralized Exchange): Protocols like Uniswap, Jupiter where you trade directly from your wallet. You keep custody of your funds.' },
          { type: 'tip', content: '"Not your keys, not your coins" - DEXs let you maintain self-custody, but you\'re responsible for securing your wallet.' },
          { type: 'example', content: 'Popular DEXs: Uniswap (Ethereum), Jupiter/Raydium (Solana), PancakeSwap (BSC)' },
        ],
      },
    ],
    quiz: {
      id: 'quiz_df',
      lessonId: 'defi_basics',
      passingScore: 70,
      xpReward: 80,
      questions: [
        { id: 'q1', question: 'What does DeFi stand for?', options: ['Definitive Finance', 'Decentralized Finance', 'Digital Finance', 'Derivative Finance'], correctAnswer: 1, explanation: 'DeFi = Decentralized Finance - financial services without traditional intermediaries.' },
        { id: 'q2', question: 'What is a key advantage of using a DEX?', options: ['Lower fees always', 'Self-custody of funds', 'Faster transactions', 'Better customer support'], correctAnswer: 1, explanation: 'DEXs allow you to trade while maintaining control of your private keys and funds.' },
        { id: 'q3', question: 'What executes DeFi protocol rules?', options: ['Bank employees', 'Government regulators', 'Smart contracts', 'AI algorithms'], correctAnswer: 2, explanation: 'Smart contracts are self-executing code that automatically enforce protocol rules on the blockchain.' },
      ],
    },
  },
  {
    id: 'tmde_basics',
    title: 'TMDE Analysis',
    icon: '🌹',
    color: '#F43F5E',
    description: 'Learn the Temporal Momentum Divergence Engine™',
    lessons: [
      {
        id: 'tmde_1',
        title: 'What is TMDE?',
        description: 'Understanding multi-timeframe divergence analysis',
        xpReward: 35,
        duration: '7 min',
        content: [
          { type: 'text', content: 'The Temporal Momentum Divergence Engine™ (TMDE) is a proprietary indicator that simultaneously analyzes 6 timeframes to detect momentum divergence and convergence patterns.' },
          { type: 'tip', content: 'TMDE provides cross-timeframe confirmation signals that are impossible to identify through single-timeframe analysis alone.' },
          { type: 'text', content: 'By analyzing momentum across multiple time horizons simultaneously, TMDE reveals when short-term and long-term trends are aligning (convergence) or conflicting (divergence).' },
          { type: 'example', content: 'If the 1H, 4H, and Daily timeframes all show bullish momentum convergence, TMDE generates a high-confidence long signal.' },
        ],
      },
      {
        id: 'tmde_2',
        title: 'Reading TMDE Signals',
        description: 'Interpreting divergence and convergence patterns',
        xpReward: 40,
        duration: '8 min',
        content: [
          { type: 'text', content: 'TMDE signals fall into two categories: Divergence (timeframes disagree on direction) and Convergence (timeframes align in the same direction).' },
          { type: 'text', content: 'Strong convergence across all 6 timeframes indicates high-probability trade setups. Divergence signals caution and potential reversals.' },
          { type: 'tip', content: 'The rose-colored TMDE overlay on your chart highlights zones where cross-timeframe alignment is strongest.' },
          { type: 'warning', content: 'Never rely on a single timeframe. TMDE\'s power comes from analyzing all 6 timeframes together for confirmation.' },
        ],
      },
    ],
    quiz: {
      id: 'quiz_tmde',
      lessonId: 'tmde_basics',
      passingScore: 70,
      xpReward: 80,
      questions: [
        { id: 'q1', question: 'How many timeframes does TMDE analyze simultaneously?', options: ['2', '4', '6', '8'], correctAnswer: 2, explanation: 'TMDE analyzes 6 timeframes simultaneously for comprehensive divergence/convergence detection.' },
        { id: 'q2', question: 'What does convergence in TMDE indicate?', options: ['Timeframes disagree', 'Timeframes align in the same direction', 'Market is closed', 'Low volume'], correctAnswer: 1, explanation: 'Convergence means multiple timeframes are aligning in the same direction, indicating a high-probability setup.' },
        { id: 'q3', question: 'What color scheme does TMDE use?', options: ['Blue/cyan', 'Green/emerald', 'Rose/pink', 'Gold/amber'], correctAnswer: 2, explanation: 'TMDE uses a rose/pink color scheme (#F43F5E) for its chart overlays and visualizations.' },
      ],
    },
  },
];

const calculateLevel = (xp: number): number => {
  return Math.floor(xp / 100) + 1;
};

const getXPForNextLevel = (level: number): number => {
  return level * 100;
};

export function CryptoLearningModule() {
  const [progress, setProgress] = useState<LearningProgress>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
    return {
      totalXP: 0,
      level: 1,
      currentStreak: 0,
      longestStreak: 0,
      lastActiveDate: '',
      completedLessons: [],
      completedQuizzes: [],
      achievements: [],
      quizScores: {},
    };
  });

  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const [newAchievement, setNewAchievement] = useState<Achievement | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (progress.lastActiveDate && progress.lastActiveDate !== today) {
      const lastDate = new Date(progress.lastActiveDate);
      const todayDate = new Date(today);
      const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays > 1) {
        setProgress(prev => ({ ...prev, currentStreak: 0 }));
      }
    }
  }, [progress.lastActiveDate]);

  const updateStreak = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    if (progress.lastActiveDate !== today) {
      const lastDate = progress.lastActiveDate ? new Date(progress.lastActiveDate) : null;
      const todayDate = new Date(today);
      
      let newStreak = 1;
      if (lastDate) {
        const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays === 1) {
          newStreak = progress.currentStreak + 1;
        }
      }
      
      setProgress(prev => ({
        ...prev,
        lastActiveDate: today,
        currentStreak: newStreak,
        longestStreak: Math.max(prev.longestStreak, newStreak),
      }));
    }
  }, [progress.lastActiveDate, progress.currentStreak]);

  const checkAchievements = useCallback((updatedProgress: LearningProgress) => {
    const newAchievements: Achievement[] = [];

    if (!updatedProgress.achievements.includes('first_lesson') && updatedProgress.completedLessons.length >= 1) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'first_lesson')!);
    }

    if (!updatedProgress.achievements.includes('streak_3') && updatedProgress.currentStreak >= 3) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'streak_3')!);
    }

    if (!updatedProgress.achievements.includes('streak_7') && updatedProgress.currentStreak >= 7) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'streak_7')!);
    }

    if (!updatedProgress.achievements.includes('level_5') && updatedProgress.level >= 5) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'level_5')!);
    }

    if (!updatedProgress.achievements.includes('level_10') && updatedProgress.level >= 10) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'level_10')!);
    }

    const perfectQuiz = Object.values(updatedProgress.quizScores).some(score => score === 100);
    if (!updatedProgress.achievements.includes('quiz_master') && perfectQuiz) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'quiz_master')!);
    }

    const isPathComplete = (path: LearningPath): boolean => {
      const allLessonsComplete = path.lessons.every(l => updatedProgress.completedLessons.includes(l.id));
      const quizComplete = updatedProgress.completedQuizzes.includes(path.quiz.id);
      return allLessonsComplete && quizComplete;
    };

    const anyPathComplete = LEARNING_PATHS.some(path => isPathComplete(path));
    if (!updatedProgress.achievements.includes('complete_path') && anyPathComplete) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'complete_path')!);
    }

    const tradingBasicsPath = LEARNING_PATHS.find(p => p.id === 'trading_basics');
    if (tradingBasicsPath && !updatedProgress.achievements.includes('all_basics') && isPathComplete(tradingBasicsPath)) {
      newAchievements.push(ACHIEVEMENTS.find(a => a.id === 'all_basics')!);
    }

    return newAchievements;
  }, []);

  const awardXP = useCallback((amount: number, source: string) => {
    setProgress(prev => {
      const newXP = prev.totalXP + amount;
      const newLevel = calculateLevel(newXP);
      const leveledUp = newLevel > prev.level;

      if (leveledUp) {
        toast.success('Level Up!', { description: `You reached level ${newLevel}!` });
      }

      return { ...prev, totalXP: newXP, level: newLevel };
    });

    toast.success(`+${amount} XP`, { description: source });
  }, []);

  const completeLesson = useCallback((lesson: Lesson) => {
    if (progress.completedLessons.includes(lesson.id)) {
      toast.info('Lesson already completed');
      return;
    }

    updateStreak();

    setProgress(prev => {
      const updated = {
        ...prev,
        completedLessons: [...prev.completedLessons, lesson.id],
        totalXP: prev.totalXP + lesson.xpReward,
        level: calculateLevel(prev.totalXP + lesson.xpReward),
      };

      const newAchievements = checkAchievements(updated);
      if (newAchievements.length > 0) {
        const bonusXP = newAchievements.reduce((sum, a) => sum + a.xpBonus, 0);
        updated.totalXP += bonusXP;
        updated.level = calculateLevel(updated.totalXP);
        updated.achievements = [...prev.achievements, ...newAchievements.map(a => a.id)];
        setNewAchievement(newAchievements[0]);
      }

      return updated;
    });

    toast.success('Lesson Complete!', { description: `+${lesson.xpReward} XP earned` });
    setSelectedLesson(null);
  }, [progress.completedLessons, updateStreak, checkAchievements]);

  const submitQuiz = useCallback(() => {
    if (!selectedPath) return;
    
    const quiz = selectedPath.quiz;
    let correct = 0;
    
    quiz.questions.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) {
        correct++;
      }
    });

    const score = Math.round((correct / quiz.questions.length) * 100);
    const passed = score >= quiz.passingScore;

    updateStreak();

    setProgress(prev => {
      const updated = {
        ...prev,
        quizScores: { ...prev.quizScores, [quiz.id]: Math.max(prev.quizScores[quiz.id] || 0, score) },
        completedQuizzes: passed && !prev.completedQuizzes.includes(quiz.id)
          ? [...prev.completedQuizzes, quiz.id]
          : prev.completedQuizzes,
        totalXP: passed && !prev.completedQuizzes.includes(quiz.id)
          ? prev.totalXP + quiz.xpReward
          : prev.totalXP,
      };
      
      updated.level = calculateLevel(updated.totalXP);

      const newAchievements = checkAchievements(updated);
      if (newAchievements.length > 0) {
        const bonusXP = newAchievements.reduce((sum, a) => sum + a.xpBonus, 0);
        updated.totalXP += bonusXP;
        updated.level = calculateLevel(updated.totalXP);
        updated.achievements = [...prev.achievements, ...newAchievements.map(a => a.id)];
        setNewAchievement(newAchievements[0]);
      }

      return updated;
    });

    setQuizSubmitted(true);

    if (passed) {
      toast.success(`Quiz Passed! Score: ${score}%`, { description: `+${quiz.xpReward} XP earned` });
    } else {
      toast.error(`Score: ${score}%`, { description: `Need ${quiz.passingScore}% to pass. Try again!` });
    }
  }, [selectedPath, quizAnswers, updateStreak, checkAchievements]);

  const getPathProgress = (path: LearningPath): number => {
    const completedInPath = path.lessons.filter(l => progress.completedLessons.includes(l.id)).length;
    const quizComplete = progress.completedQuizzes.includes(path.quiz.id) ? 1 : 0;
    return Math.round(((completedInPath + quizComplete) / (path.lessons.length + 1)) * 100);
  };

  const xpForCurrentLevel = (progress.level - 1) * 100;
  const xpForNextLevel = progress.level * 100;
  const currentLevelProgress = ((progress.totalXP - xpForCurrentLevel) / (xpForNextLevel - xpForCurrentLevel)) * 100;

  return (
    <div className="space-y-4 px-3 sm:px-4 md:px-6" data-testid="crypto-learning-module">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/20 rounded-lg">
            <GraduationCap className="text-purple-400" size={24} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Crypto Trading Academy</h2>
            <p className="text-xs text-gray-500">Learn, practice, and earn rewards</p>
          </div>
        </div>
        <Button
          onClick={() => setShowAchievements(true)}
          variant="outline"
          size="sm"
          className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10"
          data-testid="button-achievements"
        >
          <Trophy size={14} className="mr-1" /> {progress.achievements.length}/{ACHIEVEMENTS.length} Achievements
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-gradient-to-br from-purple-500/20 to-purple-500/5 border border-purple-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Star className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-gray-400">Level</span>
          </div>
          <p className="text-2xl font-bold text-white">{progress.level}</p>
          <div className="mt-1 h-1.5 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-purple-500 transition-all"
              style={{ width: `${currentLevelProgress}%` }}
            />
          </div>
          <p className="text-[10px] text-gray-500 mt-1">{progress.totalXP}/{xpForNextLevel} XP</p>
        </div>

        <div className="p-3 bg-gradient-to-br from-orange-500/20 to-orange-500/5 border border-orange-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-4 h-4 text-orange-400" />
            <span className="text-xs text-gray-400">Streak</span>
          </div>
          <p className="text-2xl font-bold text-white">{progress.currentStreak} <span className="text-sm text-gray-400">days</span></p>
          <p className="text-[10px] text-gray-500 mt-1">Best: {progress.longestStreak} days</p>
        </div>

        <div className="p-3 bg-gradient-to-br from-cyan-500/20 to-cyan-500/5 border border-cyan-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-gray-400">Lessons</span>
          </div>
          <p className="text-2xl font-bold text-white">{progress.completedLessons.length}</p>
          <p className="text-[10px] text-gray-500 mt-1">{LEARNING_PATHS.reduce((sum, p) => sum + p.lessons.length, 0)} total available</p>
        </div>

        <div className="p-3 bg-gradient-to-br from-green-500/20 to-green-500/5 border border-green-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Zap className="w-4 h-4 text-green-400" />
            <span className="text-xs text-gray-400">Total XP</span>
          </div>
          <p className="text-2xl font-bold text-white">{progress.totalXP.toLocaleString()}</p>
          <p className="text-[10px] text-gray-500 mt-1">{progress.completedQuizzes.length} quizzes passed</p>
        </div>
      </div>

      {selectedLesson ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 sm:p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setSelectedLesson(null)}
              className="flex items-center gap-2 text-gray-400 hover:text-white"
            >
              <ArrowRight className="w-4 h-4 rotate-180" /> Back to Path
            </button>
            <span className="text-xs text-gray-500 flex items-center gap-1">
              <Clock size={12} /> {selectedLesson.duration}
            </span>
          </div>

          <h3 className="text-xl font-bold text-white mb-2">{selectedLesson.title}</h3>
          <p className="text-gray-400 text-sm mb-6">{selectedLesson.description}</p>

          <div className="space-y-4">
            {selectedLesson.content.map((block, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className={`p-4 rounded-lg ${
                  block.type === 'text' ? 'bg-gray-800/50 border border-gray-700' :
                  block.type === 'tip' ? 'bg-green-500/10 border border-green-500/30' :
                  block.type === 'warning' ? 'bg-orange-500/10 border border-orange-500/30' :
                  'bg-cyan-500/10 border border-cyan-500/30'
                }`}
              >
                <div className="flex items-start gap-3">
                  {block.type === 'tip' && <Lightbulb className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />}
                  {block.type === 'warning' && <Shield className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />}
                  {block.type === 'example' && <Target className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />}
                  <p className="text-gray-300 text-sm leading-relaxed">{block.content}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 flex justify-end">
            <Button
              onClick={() => completeLesson(selectedLesson)}
              disabled={progress.completedLessons.includes(selectedLesson.id)}
              className="bg-purple-500 hover:bg-purple-600"
              data-testid="button-complete-lesson"
            >
              {progress.completedLessons.includes(selectedLesson.id) ? (
                <>
                  <CheckCircle size={16} className="mr-2" /> Completed
                </>
              ) : (
                <>
                  <Zap size={16} className="mr-2" /> Complete Lesson (+{selectedLesson.xpReward} XP)
                </>
              )}
            </Button>
          </div>
        </motion.div>
      ) : showQuiz && selectedPath ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 sm:p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => { setShowQuiz(false); setQuizAnswers({}); setQuizSubmitted(false); }}
              className="flex items-center gap-2 text-gray-400 hover:text-white"
            >
              <ArrowRight className="w-4 h-4 rotate-180" /> Back to Path
            </button>
            <span className="text-xs text-purple-400 flex items-center gap-1">
              <Trophy size={12} /> Pass with {selectedPath.quiz.passingScore}%
            </span>
          </div>

          <h3 className="text-xl font-bold text-white mb-6">{selectedPath.title} Quiz</h3>

          <div className="space-y-6">
            {selectedPath.quiz.questions.map((q, qIdx) => (
              <motion.div
                key={q.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: qIdx * 0.1 }}
                className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg"
              >
                <p className="text-white font-medium mb-3">
                  {qIdx + 1}. {q.question}
                </p>
                <div className="space-y-2">
                  {q.options.map((option, oIdx) => {
                    const isSelected = quizAnswers[q.id] === oIdx;
                    const isCorrect = quizSubmitted && oIdx === q.correctAnswer;
                    const isWrong = quizSubmitted && isSelected && oIdx !== q.correctAnswer;

                    return (
                      <button
                        key={oIdx}
                        onClick={() => !quizSubmitted && setQuizAnswers(prev => ({ ...prev, [q.id]: oIdx }))}
                        disabled={quizSubmitted}
                        className={`w-full p-3 rounded-lg text-left text-sm transition-all ${
                          isCorrect ? 'bg-green-500/20 border-green-500 text-green-400' :
                          isWrong ? 'bg-red-500/20 border-red-500 text-red-400' :
                          isSelected ? 'bg-purple-500/20 border-purple-500 text-white' :
                          'bg-gray-900/50 border-gray-700 text-gray-300 hover:border-gray-600'
                        } border`}
                        data-testid={`quiz-option-${q.id}-${oIdx}`}
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs ${
                            isSelected ? 'border-purple-500 bg-purple-500 text-white' : 'border-gray-600'
                          }`}>
                            {String.fromCharCode(65 + oIdx)}
                          </span>
                          {option}
                          {isCorrect && <CheckCircle className="w-4 h-4 ml-auto text-green-400" />}
                          {isWrong && <XCircle className="w-4 h-4 ml-auto text-red-400" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
                {quizSubmitted && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-3 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg"
                  >
                    <p className="text-sm text-blue-300">
                      <strong>Explanation:</strong> {q.explanation}
                    </p>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>

          <div className="mt-6 flex justify-end gap-3">
            {quizSubmitted ? (
              <Button
                onClick={() => { setQuizAnswers({}); setQuizSubmitted(false); }}
                variant="outline"
                className="border-gray-700"
              >
                <RefreshCw size={16} className="mr-2" /> Retry Quiz
              </Button>
            ) : (
              <Button
                onClick={submitQuiz}
                disabled={Object.keys(quizAnswers).length !== selectedPath.quiz.questions.length}
                className="bg-purple-500 hover:bg-purple-600"
                data-testid="button-submit-quiz"
              >
                Submit Quiz
              </Button>
            )}
          </div>
        </motion.div>
      ) : selectedPath ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 sm:p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setSelectedPath(null)}
              className="flex items-center gap-2 text-gray-400 hover:text-white"
            >
              <ArrowRight className="w-4 h-4 rotate-180" /> All Paths
            </button>
            <span className="text-xs font-medium" style={{ color: selectedPath.color }}>
              {getPathProgress(selectedPath)}% Complete
            </span>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <span className="text-3xl">{selectedPath.icon}</span>
            <div>
              <h3 className="text-xl font-bold text-white">{selectedPath.title}</h3>
              <p className="text-sm text-gray-400">{selectedPath.description}</p>
            </div>
          </div>

          <div className="space-y-3">
            {selectedPath.lessons.map((lesson, idx) => {
              const isCompleted = progress.completedLessons.includes(lesson.id);
              const isLocked = idx > 0 && !progress.completedLessons.includes(selectedPath.lessons[idx - 1].id);

              return (
                <motion.button
                  key={lesson.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => !isLocked && setSelectedLesson(lesson)}
                  disabled={isLocked}
                  className={`w-full p-4 rounded-lg border text-left transition-all ${
                    isCompleted ? 'bg-green-500/10 border-green-500/30' :
                    isLocked ? 'bg-gray-800/30 border-gray-800 opacity-50 cursor-not-allowed' :
                    'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                  }`}
                  data-testid={`lesson-${lesson.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        isCompleted ? 'bg-green-500' : isLocked ? 'bg-gray-700' : 'bg-gray-700'
                      }`}>
                        {isCompleted ? (
                          <CheckCircle className="w-4 h-4 text-white" />
                        ) : isLocked ? (
                          <Lock className="w-4 h-4 text-gray-500" />
                        ) : (
                          <span className="text-sm text-gray-300">{idx + 1}</span>
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-white">{lesson.title}</p>
                        <p className="text-xs text-gray-500">{lesson.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-purple-400">+{lesson.xpReward} XP</span>
                      <p className="text-xs text-gray-500">{lesson.duration}</p>
                    </div>
                  </div>
                </motion.button>
              );
            })}

            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: selectedPath.lessons.length * 0.05 }}
              onClick={() => setShowQuiz(true)}
              disabled={!selectedPath.lessons.every(l => progress.completedLessons.includes(l.id))}
              className={`w-full p-4 rounded-lg border text-left transition-all ${
                progress.completedQuizzes.includes(selectedPath.quiz.id)
                  ? 'bg-yellow-500/10 border-yellow-500/30'
                  : !selectedPath.lessons.every(l => progress.completedLessons.includes(l.id))
                    ? 'bg-gray-800/30 border-gray-800 opacity-50 cursor-not-allowed'
                    : 'bg-purple-500/10 border-purple-500/30 hover:border-purple-500/50'
              }`}
              data-testid="quiz-button"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    progress.completedQuizzes.includes(selectedPath.quiz.id)
                      ? 'bg-yellow-500'
                      : 'bg-purple-500/50'
                  }`}>
                    <Trophy className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-white">Final Quiz</p>
                    <p className="text-xs text-gray-500">Test your knowledge</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs text-yellow-400">+{selectedPath.quiz.xpReward} XP</span>
                  {progress.quizScores[selectedPath.quiz.id] && (
                    <p className="text-xs text-gray-500">Best: {progress.quizScores[selectedPath.quiz.id]}%</p>
                  )}
                </div>
              </div>
            </motion.button>
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {LEARNING_PATHS.map((path, idx) => {
            const pathProgress = getPathProgress(path);

            return (
              <motion.button
                key={path.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                onClick={() => setSelectedPath(path)}
                className="p-4 bg-gray-900/50 border border-gray-800 rounded-xl text-left hover:border-gray-700 transition-all group"
                data-testid={`path-${path.id}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <span className="text-3xl">{path.icon}</span>
                  <span className="text-xs font-medium px-2 py-1 rounded-full" style={{ 
                    backgroundColor: `${path.color}20`,
                    color: path.color
                  }}>
                    {pathProgress}%
                  </span>
                </div>
                <h3 className="font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors">
                  {path.title}
                </h3>
                <p className="text-sm text-gray-400 mb-3">{path.description}</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">{path.lessons.length} lessons + quiz</span>
                  <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-cyan-400 transition-colors" />
                </div>
                <div className="mt-3 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full transition-all"
                    style={{ width: `${pathProgress}%`, backgroundColor: path.color }}
                  />
                </div>
              </motion.button>
            );
          })}
        </div>
      )}

      <AnimatePresence>
        {showAchievements && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            onClick={() => setShowAchievements(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-gray-900 border border-gray-800 rounded-xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-400" /> Achievements
                </h3>
                <button onClick={() => setShowAchievements(false)} className="text-gray-500 hover:text-white">
                  <X size={20} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {ACHIEVEMENTS.map(achievement => {
                  const unlocked = progress.achievements.includes(achievement.id);

                  return (
                    <div
                      key={achievement.id}
                      className={`p-3 rounded-lg border ${
                        unlocked
                          ? 'bg-yellow-500/10 border-yellow-500/30'
                          : 'bg-gray-800/50 border-gray-700 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-2xl">{achievement.icon}</span>
                        {unlocked && <CheckCircle className="w-4 h-4 text-yellow-400" />}
                      </div>
                      <p className="font-medium text-white text-sm">{achievement.title}</p>
                      <p className="text-xs text-gray-400">{achievement.description}</p>
                      <p className="text-xs text-purple-400 mt-1">+{achievement.xpBonus} XP</p>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {newAchievement && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.9 }}
            className="fixed bottom-4 right-4 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/50 rounded-xl p-4 z-50 max-w-sm"
            onClick={() => setNewAchievement(null)}
          >
            <div className="flex items-center gap-3">
              <div className="text-4xl animate-bounce">{newAchievement.icon}</div>
              <div>
                <p className="text-xs text-yellow-400 font-medium">Achievement Unlocked!</p>
                <p className="text-white font-bold">{newAchievement.title}</p>
                <p className="text-xs text-gray-400">{newAchievement.description}</p>
                <p className="text-xs text-purple-400">+{newAchievement.xpBonus} XP Bonus</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
