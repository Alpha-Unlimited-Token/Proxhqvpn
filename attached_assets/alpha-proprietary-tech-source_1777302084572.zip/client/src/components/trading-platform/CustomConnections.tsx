/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha CustomConnections™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_303d380037eb5c2ee0e7a3e8
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wallet, Plus, Key, Server, Check, X, Trash2, Edit2, Save,
  ExternalLink, RefreshCw, Shield, AlertTriangle, Eye, EyeOff,
  Link2, Unlink, Settings, ChevronDown, ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface CustomConnection {
  id: string;
  name: string;
  type: 'wallet' | 'exchange' | 'platform';
  apiKey: string;
  apiSecret?: string;
  passphrase?: string;
  endpoint?: string;
  permissions: string[];
  status: 'connected' | 'disconnected' | 'error';
  lastVerified?: Date;
  notes?: string;
}

const CONNECTION_TEMPLATES = [
  { type: 'wallet', name: 'Custom Wallet', icon: '💳', description: 'Connect any wallet via API', fields: ['apiKey', 'endpoint'] },
  { type: 'exchange', name: 'Custom Exchange', icon: '📊', description: 'Connect any CEX or DEX', fields: ['apiKey', 'apiSecret', 'passphrase', 'endpoint'] },
  { type: 'platform', name: 'Trading Platform', icon: '🤖', description: 'Connect trading bots or signals', fields: ['apiKey', 'apiSecret', 'endpoint'] },
];

const COMMON_PERMISSIONS = [
  { id: 'read', label: 'Read Account', description: 'View balances and history' },
  { id: 'trade', label: 'Trade', description: 'Place and manage orders' },
  { id: 'withdraw', label: 'Withdraw', description: 'Withdraw funds (use caution)' },
  { id: 'transfer', label: 'Internal Transfer', description: 'Move between accounts' },
];

export function CustomConnections({ variant = 'trading-platform' }: { variant?: 'main' | 'trading-platform' }) {
  const { toast } = useToast();
  const [connections, setConnections] = useState<CustomConnection[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<'wallet' | 'exchange' | 'platform' | null>(null);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

  const [newConnection, setNewConnection] = useState({
    name: '',
    type: 'exchange' as 'wallet' | 'exchange' | 'platform',
    apiKey: '',
    apiSecret: '',
    passphrase: '',
    endpoint: '',
    permissions: ['read'] as string[],
    notes: ''
  });

  const primaryColor = variant === 'trading-platform' ? '#00D4FF' : '#FFD700';

  useEffect(() => {
    const saved = localStorage.getItem('alpha-custom-connections');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const sanitized = parsed.map((c: any) => {
          const conn = {
            ...c,
            lastVerified: c.lastVerified ? new Date(c.lastVerified) : undefined
          };
          if (conn.apiKey && conn.apiKey.length > 12 && !conn.apiKey.includes('****') && !conn.apiKey.includes('••••')) {
            conn.apiKey = conn.apiKey.slice(0, 4) + '****' + conn.apiKey.slice(-4);
          }
          if (conn.apiSecret && conn.apiSecret.length > 12 && !conn.apiSecret.includes('••••')) {
            conn.apiSecret = '••••••••';
          }
          return conn;
        });
        setConnections(sanitized);
        localStorage.setItem('alpha-custom-connections', JSON.stringify(sanitized));
      } catch {
        setConnections([]);
      }
    }
  }, []);

  useEffect(() => {
    if (connections.length > 0) {
      localStorage.setItem('alpha-custom-connections', JSON.stringify(connections));
    }
  }, [connections]);

  const handleAddConnection = () => {
    if (!newConnection.name || !newConnection.apiKey) {
      toast({ title: 'Missing Information', description: 'Name and API Key are required', variant: 'destructive' });
      return;
    }

    const rawApiKey = newConnection.apiKey;
    const connection: CustomConnection = {
      id: `custom_${Date.now()}`,
      name: newConnection.name,
      type: newConnection.type,
      apiKey: rawApiKey.length > 8 ? rawApiKey.slice(0, 4) + '****' + rawApiKey.slice(-4) : '****',
      apiSecret: newConnection.apiSecret ? '••••••••' : undefined,
      passphrase: newConnection.passphrase ? '••••••••' : undefined,
      endpoint: newConnection.endpoint || undefined,
      permissions: newConnection.permissions,
      status: 'connected',
      lastVerified: new Date(),
      notes: newConnection.notes || undefined
    };

    setConnections([...connections, connection]);
    setShowAddModal(false);
    resetForm();
    toast({ title: 'Connection Added', description: `${connection.name} has been connected` });
  };

  const handleUpdateConnection = (id: string, updates: Partial<CustomConnection>) => {
    setConnections(connections.map(c => c.id === id ? { ...c, ...updates } : c));
    setEditingId(null);
    toast({ title: 'Connection Updated' });
  };

  const handleRemoveConnection = (id: string) => {
    setConnections(connections.filter(c => c.id !== id));
    toast({ title: 'Connection Removed' });
  };

  const handleVerifyConnection = async (id: string) => {
    setConnections(connections.map(c => 
      c.id === id ? { ...c, status: 'connected', lastVerified: new Date() } : c
    ));
    toast({ title: 'Connection Verified', description: 'API connection is working' });
  };

  const resetForm = () => {
    setNewConnection({
      name: '',
      type: 'exchange',
      apiKey: '',
      apiSecret: '',
      passphrase: '',
      endpoint: '',
      permissions: ['read'],
      notes: ''
    });
  };

  const togglePermission = (perm: string) => {
    if (newConnection.permissions.includes(perm)) {
      setNewConnection({ ...newConnection, permissions: newConnection.permissions.filter(p => p !== perm) });
    } else {
      setNewConnection({ ...newConnection, permissions: [...newConnection.permissions, perm] });
    }
  };

  const getConnectionsByType = (type: 'wallet' | 'exchange' | 'platform') => 
    connections.filter(c => c.type === type);

  return (
    <div className="space-y-4" data-testid="custom-connections">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Key className="text-cyan-400" size={24} />
          <div>
            <h2 className="text-lg font-bold text-white">Custom Connections</h2>
            <p className="text-xs text-gray-500">Connect unlisted wallets & platforms via API</p>
          </div>
        </div>
        <Button
          onClick={() => setShowAddModal(true)}
          className="bg-cyan-500 hover:bg-cyan-600"
          size="sm"
          data-testid="button-add-custom-connection"
        >
          <Plus size={16} className="mr-1" /> Add Connection
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {CONNECTION_TEMPLATES.map(template => {
          const count = getConnectionsByType(template.type as any).length;
          return (
            <motion.button
              key={template.type}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setExpandedSection(expandedSection === template.type as any ? null : template.type as any)}
              className={`p-4 rounded-lg border transition-all text-left ${
                expandedSection === template.type 
                  ? 'bg-cyan-500/10 border-cyan-500/50' 
                  : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
              }`}
              data-testid={`section-${template.type}`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">{template.icon}</span>
                {count > 0 && (
                  <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs rounded-full">
                    {count}
                  </span>
                )}
              </div>
              <div className="font-medium text-white text-sm">{template.name}</div>
              <div className="text-xs text-gray-500">{template.description}</div>
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {expandedSection && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-white capitalize">{expandedSection} Connections</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setNewConnection({ ...newConnection, type: expandedSection });
                    setShowAddModal(true);
                  }}
                  className="text-cyan-400 hover:text-cyan-300"
                >
                  <Plus size={14} className="mr-1" /> Add {expandedSection}
                </Button>
              </div>

              {getConnectionsByType(expandedSection).length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Key size={32} className="mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No {expandedSection} connections yet</p>
                  <p className="text-xs">Click "Add {expandedSection}" to connect via API</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {getConnectionsByType(expandedSection).map(conn => (
                    <motion.div
                      key={conn.id}
                      layout
                      className="p-3 bg-gray-800/50 border border-gray-700 rounded-lg"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${
                            conn.status === 'connected' ? 'bg-green-400' :
                            conn.status === 'error' ? 'bg-red-400' : 'bg-gray-400'
                          }`} />
                          <div>
                            <div className="font-medium text-white text-sm">{conn.name}</div>
                            <div className="text-xs text-gray-500 flex items-center gap-2">
                              <span>API: {conn.apiKey}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex gap-1">
                            {conn.permissions.map(p => (
                              <span key={p} className="px-1.5 py-0.5 bg-gray-700 text-gray-300 text-[10px] rounded">
                                {p}
                              </span>
                            ))}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleVerifyConnection(conn.id)}
                            className="h-7 px-2"
                          >
                            <RefreshCw size={12} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveConnection(conn.id)}
                            className="h-7 px-2 text-red-400 hover:text-red-300"
                          >
                            <Trash2 size={12} />
                          </Button>
                        </div>
                      </div>
                      {conn.endpoint && (
                        <div className="mt-2 text-xs text-gray-500 flex items-center gap-1">
                          <Server size={10} /> {conn.endpoint}
                        </div>
                      )}
                      {conn.lastVerified && (
                        <div className="mt-1 text-[10px] text-gray-600">
                          Last verified: {conn.lastVerified.toLocaleString()}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Key className="text-cyan-400" size={20} />
              Add Custom Connection
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              {CONNECTION_TEMPLATES.map(t => (
                <button
                  key={t.type}
                  onClick={() => setNewConnection({ ...newConnection, type: t.type as any })}
                  className={`flex-1 p-2 rounded border text-center transition-all ${
                    newConnection.type === t.type 
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400' 
                      : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                  }`}
                >
                  <span className="text-lg block">{t.icon}</span>
                  <span className="text-xs">{t.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">Connection Name *</label>
              <input
                type="text"
                value={newConnection.name}
                onChange={e => setNewConnection({ ...newConnection, name: e.target.value })}
                placeholder="e.g., My Kraken Account"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-cyan-500 focus:outline-none"
                data-testid="input-connection-name"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">API Key *</label>
              <input
                type="text"
                value={newConnection.apiKey}
                onChange={e => setNewConnection({ ...newConnection, apiKey: e.target.value })}
                placeholder="Enter your API key"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm font-mono focus:border-cyan-500 focus:outline-none"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-lpignore="true"
                data-1p-ignore="true"
                data-testid="input-custom-conn-api-key"
              />
            </div>

            {(newConnection.type === 'exchange' || newConnection.type === 'platform') && (
              <div>
                <label className="block text-sm text-gray-400 mb-1">API Secret</label>
                <input
                  type="password"
                  value={newConnection.apiSecret}
                  onChange={e => setNewConnection({ ...newConnection, apiSecret: e.target.value })}
                  placeholder="Enter your API secret"
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm font-mono focus:border-cyan-500 focus:outline-none"
                  autoComplete="new-password"
                  data-lpignore="true"
                  data-1p-ignore="true"
                  data-testid="input-custom-conn-api-secret"
                />
              </div>
            )}

            {newConnection.type === 'exchange' && (
              <div>
                <label className="block text-sm text-gray-400 mb-1">Passphrase (if required)</label>
                <input
                  type="password"
                  value={newConnection.passphrase}
                  onChange={e => setNewConnection({ ...newConnection, passphrase: e.target.value })}
                  placeholder="Optional passphrase"
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm font-mono focus:border-cyan-500 focus:outline-none"
                  autoComplete="new-password"
                  data-lpignore="true"
                  data-1p-ignore="true"
                  data-testid="input-custom-conn-passphrase"
                />
              </div>
            )}

            <div>
              <label className="block text-sm text-gray-400 mb-1">API Endpoint (Optional)</label>
              <input
                type="url"
                value={newConnection.endpoint}
                onChange={e => setNewConnection({ ...newConnection, endpoint: e.target.value })}
                placeholder="https://api.example.com"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-cyan-500 focus:outline-none"
                data-testid="input-endpoint"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Permissions</label>
              <div className="flex flex-wrap gap-2">
                {COMMON_PERMISSIONS.map(perm => (
                  <button
                    key={perm.id}
                    onClick={() => togglePermission(perm.id)}
                    className={`px-3 py-1.5 rounded text-xs transition-all ${
                      newConnection.permissions.includes(perm.id)
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                        : 'bg-gray-800 text-gray-400 border border-gray-700 hover:border-gray-600'
                    }`}
                    title={perm.description}
                  >
                    {perm.label}
                  </button>
                ))}
              </div>
              {newConnection.permissions.includes('withdraw') && (
                <div className="mt-2 p-2 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-400 flex items-center gap-2">
                  <AlertTriangle size={14} />
                  Withdraw permission enabled - use with caution
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">Notes (Optional)</label>
              <textarea
                value={newConnection.notes}
                onChange={e => setNewConnection({ ...newConnection, notes: e.target.value })}
                placeholder="Any notes about this connection..."
                rows={2}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm resize-none focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div className="p-3 bg-gray-800/50 border border-gray-700 rounded text-xs text-gray-400">
              <Shield size={14} className="inline mr-1 text-green-400" />
              Your API keys are stored locally on your device and never sent to our servers.
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => { setShowAddModal(false); resetForm(); }}
                className="flex-1 border-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddConnection}
                className="flex-1 bg-cyan-500 hover:bg-cyan-600"
                data-testid="button-save-connection"
              >
                <Check size={16} className="mr-1" /> Connect
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
