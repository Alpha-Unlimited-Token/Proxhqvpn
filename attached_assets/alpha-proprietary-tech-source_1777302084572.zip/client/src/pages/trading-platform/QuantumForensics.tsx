/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Quantum Forensic Intelligence Module™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Quantum Forensic Intelligence Module™
 * - Post-Quantum Signature Forensic Deconstruction™
 * - Quantum Key Extraction Trace™
 * - Lattice-Based Evidence Verification™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_QS_FORENSICS_PAGE_SEALED
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Search, Shield, Fingerprint, AlertTriangle, Eye, FileText, Link, Cpu } from "lucide-react";

interface ForensicFinding {
  findingId: string;
  txHash: string;
  chain: string;
  caseId: string;
  analysisType: string;
  quantumSignatureAnalysis: {
    signatureScheme: string;
    keyReuse: boolean;
    noncePatterns: string;
    ecdsaVulnerability: string;
    quantumExploitPossible: boolean;
    estimatedKeyExtractionTime: string;
  };
  evidenceIntegrity: {
    hashAlgorithm: string;
    integrityVerified: boolean;
    tamperDetected: boolean;
    latticeProofGenerated: boolean;
    courtAdmissible: boolean;
  };
  attackClassification: {
    type: string;
    sophistication: string;
    quantumToolsUsed: boolean;
    attackerCapability: string;
  };
  recommendations: string[];
  timestamp: string;
}

export default function QuantumForensics() {
  const [txHash, setTxHash] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [caseId, setCaseId] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [finding, setFinding] = useState<ForensicFinding | null>(null);

  const handleAnalyze = async () => {
    if (!txHash) return;
    setAnalyzing(true);
    setFinding(null);
    try {
      const res = await fetch("/api/quantum/forensics/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ txHash, chain, caseId: caseId || undefined }),
      });
      const data = await res.json();
      setFinding(data);
    } catch (e) { console.error(e); }
    setAnalyzing(false);
  };

  return (
    <TradingPlatformLayout title="Quantum Forensic Intelligence Module™" subtitle="Post-Quantum Signature Forensic Analysis & Evidence Verification">
      <div className="space-y-6 p-4 max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30 mb-6">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Fingerprint className="w-4 h-4" /> Quantum Forensic Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <Input
                  data-testid="input-forensic-tx"
                  placeholder="Transaction Hash (0x...)"
                  value={txHash}
                  onChange={(e) => setTxHash(e.target.value)}
                  className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                />
                <select
                  data-testid="select-forensic-chain"
                  value={chain}
                  onChange={(e) => setChain(e.target.value)}
                  className="bg-[#0a0a1a] border border-gray-700 text-white text-sm rounded-md px-3"
                >
                  <option value="ethereum">Ethereum</option>
                  <option value="bsc">BSC</option>
                  <option value="polygon">Polygon</option>
                  <option value="arbitrum">Arbitrum</option>
                  <option value="solana">Solana</option>
                </select>
                <Input
                  data-testid="input-forensic-case"
                  placeholder="Case ID (optional)"
                  value={caseId}
                  onChange={(e) => setCaseId(e.target.value)}
                  className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                />
                <Button
                  data-testid="button-forensic-analyze"
                  onClick={handleAnalyze}
                  disabled={analyzing || !txHash}
                  className="bg-[#d4af37] hover:bg-[#b8962e] text-black"
                >
                  {analyzing ? "Analyzing..." : "Analyze Transaction"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {finding && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Eye className="w-4 h-4" /> Signature Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Scheme:</span>
                      <span className="text-gray-300">{finding.quantumSignatureAnalysis.signatureScheme}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Key Reuse:</span>
                      <span className={finding.quantumSignatureAnalysis.keyReuse ? 'text-red-400' : 'text-green-400'}>
                        {finding.quantumSignatureAnalysis.keyReuse ? "DETECTED" : "None"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Nonce Pattern:</span>
                      <span className="text-gray-300">{finding.quantumSignatureAnalysis.noncePatterns}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">ECDSA Vuln:</span>
                      <Badge variant="outline" className={`text-[10px] ${finding.quantumSignatureAnalysis.ecdsaVulnerability === 'HIGH' ? 'text-red-400 border-red-400/30' : finding.quantumSignatureAnalysis.ecdsaVulnerability === 'MEDIUM' ? 'text-yellow-400 border-yellow-400/30' : 'text-green-400 border-green-400/30'}`}>
                        {finding.quantumSignatureAnalysis.ecdsaVulnerability}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Quantum Exploit:</span>
                      <span className={finding.quantumSignatureAnalysis.quantumExploitPossible ? 'text-red-400 font-bold' : 'text-green-400'}>
                        {finding.quantumSignatureAnalysis.quantumExploitPossible ? "POSSIBLE" : "Not feasible"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Key Extraction:</span>
                      <span className="text-gray-300">{finding.quantumSignatureAnalysis.estimatedKeyExtractionTime}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Shield className="w-4 h-4" /> Evidence Integrity
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Hash Algorithm:</span>
                      <span className="text-gray-300">{finding.evidenceIntegrity.hashAlgorithm}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Integrity:</span>
                      <Badge variant="outline" className={`text-[10px] ${finding.evidenceIntegrity.integrityVerified ? 'text-green-400 border-green-400/30' : 'text-red-400 border-red-400/30'}`}>
                        {finding.evidenceIntegrity.integrityVerified ? "VERIFIED" : "UNVERIFIED"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Tamper Detection:</span>
                      <span className={finding.evidenceIntegrity.tamperDetected ? 'text-red-400' : 'text-green-400'}>
                        {finding.evidenceIntegrity.tamperDetected ? "TAMPERED" : "Clean"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Lattice Proof:</span>
                      <span className={finding.evidenceIntegrity.latticeProofGenerated ? 'text-green-400' : 'text-gray-500'}>
                        {finding.evidenceIntegrity.latticeProofGenerated ? "Generated" : "Pending"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Court Admissible:</span>
                      <Badge variant="outline" className={`text-[10px] ${finding.evidenceIntegrity.courtAdmissible ? 'text-green-400 border-green-400/30' : 'text-yellow-400 border-yellow-400/30'}`}>
                        {finding.evidenceIntegrity.courtAdmissible ? "YES" : "PENDING"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" /> Attack Classification
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Attack Type:</span>
                      <span className="text-gray-300">{finding.attackClassification.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Sophistication:</span>
                      <Badge variant="outline" className={`text-[10px] ${finding.attackClassification.sophistication === 'ADVANCED' ? 'text-red-400 border-red-400/30' : 'text-yellow-400 border-yellow-400/30'}`}>
                        {finding.attackClassification.sophistication}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Quantum Tools:</span>
                      <span className={finding.attackClassification.quantumToolsUsed ? 'text-red-400' : 'text-green-400'}>
                        {finding.attackClassification.quantumToolsUsed ? "Suspected" : "None"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Attacker Level:</span>
                      <span className="text-gray-300">{finding.attackClassification.attackerCapability}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                <CardHeader>
                  <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {finding.recommendations.map((rec, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs">
                        <span className="text-[#d4af37] mt-0.5">({i + 1})</span>
                        <span className="text-gray-300">{rec}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 border-t border-gray-800 text-[10px] text-gray-500">
                    Finding ID: {finding.findingId} | Case: {finding.caseId} | {new Date(finding.timestamp).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="mt-6 p-4 bg-[#0a0a1a] rounded-lg border border-[#d4af37]/20">
            <h3 className="text-[#d4af37] text-sm font-bold mb-2">About Quantum Forensic Intelligence Module™</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Signature Deconstruction</h4>
                <p>Deconstructs ECDSA signatures to analyze nonce patterns, key reuse, and quantum vulnerability. Identifies transactions that could be replayed or forged using quantum computing capabilities.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Quantum-Proof Evidence</h4>
                <p>Generates lattice-based cryptographic proofs for evidence integrity that remain valid even in a post-quantum world. Evidence sealed with ML-DSA signatures for court admissibility.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Attack Classification</h4>
                <p>Classifies attacks by sophistication level and determines whether quantum computing tools were involved. Integrates with the Forensic Intelligence Engine for comprehensive case analysis.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}
