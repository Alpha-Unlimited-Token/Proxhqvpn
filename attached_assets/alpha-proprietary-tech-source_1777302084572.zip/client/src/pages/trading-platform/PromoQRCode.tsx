/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha PromoQRCode™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_923621e87eeb3b61cf8ecea7
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Download, QrCode, Copy, Check, Smartphone, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import QRCode from 'qrcode';

const TRADING_URL = 'https://alphaunlimitedtrading.com';

export default function PromoQRCode() {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [size, setSize] = useState<'small' | 'medium' | 'large'>('large');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const sizeMap = {
    small: 200,
    medium: 400,
    large: 600
  };

  useEffect(() => {
    generateQR();
  }, [size]);

  const generateQR = async () => {
    try {
      const dataUrl = await QRCode.toDataURL(TRADING_URL, {
        width: sizeMap[size],
        margin: 2,
        color: {
          dark: '#00D4FF',
          light: '#0A1628'
        },
        errorCorrectionLevel: 'H'
      });
      setQrDataUrl(dataUrl);
    } catch (err) {
      console.error('Error generating QR code:', err);
    }
  };

  const downloadQR = (format: 'png' | 'svg') => {
    if (format === 'png') {
      const link = document.createElement('a');
      link.download = `alpha-unlimited-trading-qr-${size}.png`;
      link.href = qrDataUrl;
      link.click();
    } else {
      QRCode.toString(TRADING_URL, {
        type: 'svg',
        width: sizeMap[size],
        margin: 2,
        color: {
          dark: '#00D4FF',
          light: '#0A1628'
        }
      }, (err, svg) => {
        if (err) return;
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = `alpha-unlimited-trading-qr-${size}.svg`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
      });
    }
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(TRADING_URL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A1628] via-[#0D1B2A] to-[#0A1628] py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <QrCode className="w-12 h-12 text-[#00D4FF]" />
            <h1 className="text-4xl md:text-5xl font-bold text-white">
              Promotional <span className="text-[#00D4FF]">QR Code</span>
            </h1>
          </div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Download and share this QR code to instantly direct people to Alpha Unlimited Trading
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-[#0D1B2A] border border-[#00D4FF]/30 rounded-2xl p-8 flex flex-col items-center"
          >
            <div className="bg-[#0A1628] p-6 rounded-xl border border-[#00D4FF]/20 mb-6">
              {qrDataUrl && (
                <img 
                  src={qrDataUrl} 
                  alt="Alpha Unlimited Trading QR Code"
                  className="w-64 h-64 object-contain"
                />
              )}
            </div>

            <div className="text-center mb-6">
              <div className="flex items-center justify-center gap-2 text-[#00D4FF] font-mono text-sm bg-[#00D4FF]/10 px-4 py-2 rounded-lg">
                <Smartphone size={16} />
                <span>Scan to visit</span>
              </div>
              <p className="text-white font-semibold mt-2">{TRADING_URL}</p>
            </div>

            <div className="flex gap-2 mb-4">
              <Button
                onClick={copyLink}
                variant="outline"
                className="border-[#00D4FF]/50 text-[#00D4FF] hover:bg-[#00D4FF]/20"
              >
                {copied ? <Check size={16} /> : <Copy size={16} />}
                {copied ? 'Copied!' : 'Copy Link'}
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-[#0D1B2A] border border-[#00D4FF]/30 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Share2 className="text-[#00D4FF]" size={20} />
                Download Options
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm mb-2 block">Size</label>
                  <div className="flex gap-2">
                    {(['small', 'medium', 'large'] as const).map((s) => (
                      <button
                        key={s}
                        onClick={() => setSize(s)}
                        className={`px-4 py-2 rounded-lg font-medium transition-all ${
                          size === s
                            ? 'bg-[#00D4FF] text-black'
                            : 'bg-[#0A1628] text-gray-400 hover:text-white border border-gray-700'
                        }`}
                      >
                        {s.charAt(0).toUpperCase() + s.slice(1)}
                        <span className="text-xs ml-1 opacity-70">({sizeMap[s]}px)</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4">
                  <Button
                    onClick={() => downloadQR('png')}
                    className="bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black font-bold py-6"
                  >
                    <Download size={20} className="mr-2" />
                    Download PNG
                  </Button>
                  <Button
                    onClick={() => downloadQR('svg')}
                    variant="outline"
                    className="border-[#00D4FF] text-[#00D4FF] hover:bg-[#00D4FF]/20 font-bold py-6"
                  >
                    <Download size={20} className="mr-2" />
                    Download SVG
                  </Button>
                </div>
              </div>
            </div>

            <div className="bg-[#0D1B2A] border border-[#00D4FF]/30 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Usage Ideas</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-[#00D4FF]">•</span>
                  Print on business cards, flyers, or posters
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#00D4FF]">•</span>
                  Add to social media profiles and posts
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#00D4FF]">•</span>
                  Include in email signatures
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#00D4FF]">•</span>
                  Display at trade shows or events
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#00D4FF]">•</span>
                  Add to merchandise or promotional items
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-r from-[#00D4FF]/20 to-[#0066FF]/20 border border-[#00D4FF]/30 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-[#00D4FF] rounded-full flex items-center justify-center">
                  <span className="text-black font-bold text-lg">α</span>
                </div>
                <div>
                  <h4 className="text-white font-bold">Alpha Unlimited Trading</h4>
                  <p className="text-gray-400 text-sm">Professional Crypto Trading Platform</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <canvas ref={canvasRef} style={{ display: 'none' }} />
    </div>
  );
}
