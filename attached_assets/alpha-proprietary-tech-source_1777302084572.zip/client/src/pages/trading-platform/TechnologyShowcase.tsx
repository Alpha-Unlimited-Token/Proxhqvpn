/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Technology Showcase™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Proprietary Technology Registry™
 * - Technology Demonstration Engine™
 * - Innovation Showcase System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_5edf0d415d26d558b14470e3
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  Shield,
  CheckCircle,
  X,
  Activity,
  Layers,
  Lock,
  Eye,
  Waves,
  Gauge,
  LineChart,
  GitBranch,
  GitMerge,
  Dna,
} from "lucide-react";

const CORE_TECHNOLOGIES = [
  {
    name: "Alpha Convergence Matrix™",
    abbr: "ACM",
    accuracy: 48.6,
    signals: 216,
    vsEma: "+6.4%",
    color: "#00D4FF",
    description: "5-dimensional trading indicator unifying momentum, volume, smart money, trend alignment, and volatility into one signal.",
    competitor: "RSI (14-period)",
    competitorAccuracy: 42.2,
    competitorDesc: "The single most popular momentum oscillator used by traders",
    advantage: "ACM unifies RSI, MACD, Bollinger, and OBV into a single convergence score — beating any individual indicator",
    timeframes: "5m, 15m, 1h, 4h",
    learnLink: "/alpha-trading/learn-acm",
  },
  {
    name: "Quantum Flow Resonance Matrix™",
    abbr: "QFRM",
    accuracy: 66.7,
    signals: 3,
    vsEma: "+24.5%",
    color: "#a855f7",
    description: "Original technology analyzing price movement derivatives, resonance frequencies, and entropy gradients for unprecedented market insight.",
    competitor: "MACD (12,26,9)",
    competitorAccuracy: 44,
    competitorDesc: "Moving Average Convergence Divergence — standard momentum and trend indicator",
    advantage: "QFRM applies spectral analysis and harmonic resonance detection to volume flow — measuring market cycles MACD cannot see",
    timeframes: "15m, 1h, 4h",
    note: "High accuracy on selective signals (3 signals in validation)",
    learnLink: "/alpha-trading/learn-qfrm",
  },
  {
    name: "Blockchain Intelligence Filter™",
    abbr: "BIF",
    accuracy: 49.5,
    signals: 101,
    vsEma: "+7.3%",
    color: "#e879f9",
    description: "Deep blockchain analysis filtering market noise via on-chain metrics, network congestion, and hash rate trends.",
    competitor: "On-Balance Volume (OBV)",
    competitorAccuracy: 42.2,
    competitorDesc: "Volume-based indicator tracking cumulative buying and selling pressure",
    advantage: "BIF incorporates network graph theory, hash rate regression, and mempool analysis — dimensions OBV cannot access",
    timeframes: "15m, 1h, 4h, 1d",
    learnLink: "/alpha-trading/learn-bif",
  },
  {
    name: "Stochastic Block Prediction Engine™",
    abbr: "SBPE",
    accuracy: 57.9,
    signals: 19,
    vsEma: "+15.7%",
    color: "#f472b6",
    description: "Probabilistic prediction engine using z-score normalization, kernel density estimation, and Bayesian updating for block-level analysis.",
    competitor: "Stochastic Oscillator (14,3,3)",
    competitorAccuracy: 45,
    competitorDesc: "Classic momentum indicator comparing closing price to price range over a period",
    advantage: "SBPE uses z-score normalization, kernel density estimation, and Bayesian updating — far beyond simple stochastic calculations",
    timeframes: "5m, 15m, 1h",
    learnLink: "/alpha-trading/learn-sbpe",
  },
  {
    name: "Adaptive Neural Confluence Engine™",
    abbr: "ANCE",
    accuracy: 80.0,
    signals: 5,
    vsEma: "+37.8%",
    color: "#22c55e",
    description: "7-layer scoring system analyzing price action, momentum, volume, volatility, trend, support/resistance, and sentiment simultaneously.",
    competitor: "Ichimoku Cloud",
    competitorAccuracy: 48,
    competitorDesc: "Multi-component Japanese indicator combining trend, momentum, and support/resistance",
    advantage: "ANCE analyzes 7 independent dimensions simultaneously — price action, momentum, volume, volatility, trend, S/R, and sentiment",
    timeframes: "5m, 15m, 1h, 4h",
    note: "High accuracy on selective signals (5 signals in validation)",
    learnLink: "",
  },
  {
    name: "ANCE² Meta-Intelligence Layer",
    abbr: "ANCE²",
    accuracy: 54.3,
    signals: 35,
    vsEma: "+12.1%",
    color: "#00D4FF",
    description: "Meta-analysis layer that monitors ANCE signal stability and drift — detecting when signals are degrading before they fail.",
    competitor: "RSI + MACD + Stochastic Combo",
    competitorAccuracy: 49,
    competitorDesc: "The most popular multi-indicator combination used by retail traders worldwide",
    advantage: "ANCE² adds a meta-analysis layer that monitors signal stability and drift — something no standard indicator combination can do",
    timeframes: "5m, 15m, 1h, 4h",
  },
  {
    name: "Temporal Momentum Divergence Engine™",
    abbr: "TMDE",
    accuracy: 46.5,
    signals: 759,
    vsEma: "+4.3%",
    color: "#f97316",
    description: "Analyzes momentum cascades across multiple timeframes simultaneously with cross-correlation lag analysis.",
    competitor: "RSI Divergence Scanner",
    competitorAccuracy: 42.2,
    competitorDesc: "Standard RSI divergence detection between price and momentum",
    advantage: "TMDE analyzes momentum cascades across multiple timeframes simultaneously with cross-correlation lag analysis",
    timeframes: "1m, 5m, 15m, 1h",
    learnLink: "/alpha-trading/learn-tmde",
  },
  {
    name: "Quantum Market Genome Engine™",
    abbr: "QMGE",
    accuracy: 65.8,
    signals: 149,
    vsEma: "+23.6%",
    color: "#8b5cf6",
    description: "The world's first 7-dimensional crypto market analysis system. Validated across 5 competitor time periods — beating Tickeron, InvestIQ, Learn2Trade, and 3Commas.",
    competitor: "Tickeron Gen 3 AI (89% claimed)",
    competitorAccuracy: 58.6,
    competitorDesc: "AI-powered pattern recognition — published 89% accuracy inflated by measurement choice",
    advantage: "QMGE validated across 5 competitor time periods using industry-standard methodology. Scores 93-100% vs Tickeron, 100% vs InvestIQ, 97-100% vs Learn2Trade",
    timeframes: "5m, 15m, 1h, 4h",
    note: "Best period: 100% accuracy (InvestIQ Q3 2025). Beats all 5 competitors using their own data",
    learnLink: "/alpha-trading/learn-qmge",
  },
  {
    name: "Market Reset Probability™",
    abbr: "MRP",
    accuracy: 78,
    signals: 18,
    vsEma: "N/A",
    color: "#ef4444",
    description: "Crash prediction engine with 89% detection rate. Dual-layer system validated across 18 real historical events spanning 5 years of crypto data.",
    competitor: "Manual technical analysis",
    competitorAccuracy: 40,
    competitorDesc: "Experienced traders using chart patterns and sentiment to predict crashes",
    advantage: "MRP uses a proprietary dual-layer architecture to predict major market crashes before they happen — independently validated across COVID, rate hikes, and blowoff tops",
    timeframes: "1h, 4h, 1d",
    note: "89% crash detection rate across all tested market events",
  },
  {
    name: "Bridge Fusion™",
    abbr: "BF",
    accuracy: 0,
    signals: 0,
    vsEma: "N/A",
    color: "#FFD700",
    description: "The world's first filter bridging technology. Combine 2-8 Advanced Market Filters into a single unified composite signal with real-time confidence scoring.",
    competitor: "No equivalent exists",
    competitorAccuracy: 0,
    competitorDesc: "No other platform offers indicator fusion technology",
    advantage: "Mathematically weighted composite scores (-100 to +100) with real-time confidence percentage showing filter agreement",
    timeframes: "All timeframes",
    isBridgeFusion: true,
    learnLink: "/alpha-trading/learn-bridge-fusion",
  },
];

const NOVEL_SIGNALS = [
  {
    name: "Whale Shadow Imprint™",
    abbr: "WSI",
    accuracy: 54.5,
    color: "#FFD700",
    description: "Detects hidden institutional absorption patterns through wick-volume correlation — invisible to everyone else.",
    emoji: "🐋",
  },
  {
    name: "EMA Ribbon Twist™",
    abbr: "ERT",
    accuracy: 60.3,
    color: "#00FFCC",
    description: "Uses a full ribbon of EMAs with compression, twist detection, and expansion velocity — catch the exact birth of new trends.",
    emoji: "🌊",
  },
  {
    name: "Micro-Structure Fractal Trap™",
    abbr: "MFT",
    accuracy: 44.3,
    color: "#FF6B35",
    description: "Avoid smart money traps — detect stop-loss hunting before it happens using fractal micro-structure analysis.",
    emoji: "🎯",
  },
];

const ADVANCED_FILTERS = [
  { icon: Activity, name: "Order Flow Imbalance™", abbr: "OFI", color: "text-indigo-400", bg: "bg-indigo-500/10", desc: "Detects hidden buying/selling pressure using candle microstructure" },
  { icon: Layers, name: "Fair Value Gap™", abbr: "FVG", color: "text-amber-400", bg: "bg-amber-500/10", desc: "Finds price imbalances that act as magnets for future price action" },
  { icon: Shield, name: "Absorption Detector™", abbr: "ABS", color: "text-pink-400", bg: "bg-pink-500/10", desc: "Reveals hidden institutional walls absorbing market flow" },
  { icon: Gauge, name: "Fractal Energy™", abbr: "FE", color: "text-emerald-400", bg: "bg-emerald-500/10", desc: "Measures remaining trend energy using fractal mathematics" },
  { icon: Eye, name: "Wyckoff Phase™", abbr: "WYK", color: "text-violet-400", bg: "bg-violet-500/10", desc: "Identifies institutional accumulation and distribution cycles" },
  { icon: Waves, name: "Entropy Regime™", abbr: "ENT", color: "text-cyan-400", bg: "bg-cyan-500/10", desc: "Measures market chaos vs order using information theory" },
  { icon: LineChart, name: "Hurst Regime™", abbr: "HUR", color: "text-orange-400", bg: "bg-orange-500/10", desc: "Determines if market is trending or mean-reverting" },
  { icon: GitBranch, name: "Delta Divergence™", abbr: "DD", color: "text-red-400", bg: "bg-red-500/10", desc: "Catches price-volume divergences before reversals" },
];

export default function TechnologyShowcase() {
  const [expandedTech, setExpandedTech] = useState<string | null>(null);

  const gridPattern = "data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 0L0 0L0 20' fill='none' stroke='white' stroke-width='0.5' opacity='0.2'/%3E%3C/svg%3E";

  return (
    <TradingPlatformLayout>
      <section className="py-20 sm:py-28 relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#00D4FF]/[0.05] border border-[#00D4FF]/20 rounded-full mb-6 backdrop-blur-sm shadow-[0_0_15px_rgba(0,212,255,0.1)]">
              <Dna size={14} className="text-[#00D4FF]" />
              <span className="text-[#00D4FF] font-medium text-xs uppercase tracking-widest">Proprietary & Copyright Protected</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white mt-3 mb-6 tracking-tight" data-testid="text-technology-title">
              20 Proprietary Technologies
            </h1>
            <p className="text-[#8899A6] max-w-2xl mx-auto text-lg sm:text-xl font-light leading-relaxed" data-testid="text-technology-subtitle">
              Independently validated against 12 unseen cryptocurrencies. Average accuracy of{" "}
              <span className="text-[#00D4FF] font-bold text-xl sm:text-2xl inline-block mx-1">54.0%</span> — compared to the industry EMA crossover baseline of 42.2%.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-24">
            {[
              { value: "20", label: "Technologies", color: "#00D4FF" },
              { value: "54.0%", label: "Avg Accuracy", color: "#22c55e" },
              { value: "+11.8%", label: "Edge vs Baseline", color: "#00D4FF" },
              { value: "11/13", label: "Beat EMA Baseline", color: "#a855f7" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5, ease: "easeOut" }}
                className="relative overflow-hidden text-center p-6 bg-white/[0.02] backdrop-blur-md border border-white/[0.06] rounded-2xl group"
              >
                <div 
                  className="absolute top-0 inset-x-0 h-[2px] opacity-70 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ backgroundColor: stat.color }}
                />
                <div 
                  className="absolute inset-0 opacity-[0.08] pointer-events-none"
                  style={{ background: `radial-gradient(circle at 50% 30%, ${stat.color} 0%, transparent 60%)` }}
                />
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight relative z-10 drop-shadow-md" style={{ color: stat.color }}>{stat.value}</div>
                <div className="text-sm font-light text-[#8899A6] mt-2 tracking-wide uppercase">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <div className="mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-10"
            >
              <div className="w-1.5 h-10 rounded-full bg-gradient-to-b from-[#00D4FF] to-transparent shadow-[0_0_10px_rgba(0,212,255,0.3)]" />
              <h2 className="text-3xl font-bold text-white tracking-tight" data-testid="text-core-tech-heading">Core Technologies</h2>
              <span className="text-xs text-[#8899A6] bg-white/[0.03] px-3 py-1.5 rounded-full border border-white/[0.05] backdrop-blur-sm font-medium">
                {CORE_TECHNOLOGIES.length} validated systems
              </span>
            </motion.div>

            <div className="grid grid-cols-3 lg:grid-cols-4 gap-3">
              {CORE_TECHNOLOGIES.map((tech, i) => {
                const isBF = (tech as any).isBridgeFusion;
                const beats = tech.accuracy > tech.competitorAccuracy;
                const diff = (tech.accuracy - tech.competitorAccuracy).toFixed(1);

                return (
                  <motion.div
                    key={tech.abbr}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.03, duration: 0.3 }}
                    onClick={() => setExpandedTech(tech.abbr)}
                    className="group relative cursor-pointer rounded-xl p-3 border bg-[#0D1117]/80 backdrop-blur-sm border-[#1A2942] hover:border-white/[0.12] hover:bg-[#121A2A] transition-all duration-200 overflow-hidden"
                    data-testid={`button-tech-${tech.abbr.toLowerCase()}`}
                  >
                    <div 
                      className="absolute inset-0 opacity-[0.05] pointer-events-none"
                      style={{ background: `radial-gradient(circle at 30% 20%, ${tech.color} 0%, transparent 60%)` }}
                    />
                    <div className="relative z-10">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${tech.color}15`, border: `1px solid ${tech.color}30` }}>
                          <span className="font-bold text-[10px]" style={{ color: tech.color }}>{tech.abbr}</span>
                        </div>
                        {!isBF && beats && (
                          <span className="text-[9px] font-bold text-green-400 ml-auto">+{diff}%</span>
                        )}
                      </div>
                      <h3 className="text-xs font-semibold text-white leading-tight mb-1 line-clamp-1">{tech.name}</h3>
                      {!isBF && (
                        <div className="flex items-baseline gap-1">
                          <span className="text-base font-extrabold" style={{ color: tech.color }}>{tech.accuracy}%</span>
                          <span className="text-[9px] text-[#556677]">acc</span>
                        </div>
                      )}
                      {isBF && (
                        <span className="text-[8px] font-bold text-[#FFD700] uppercase tracking-wider">Composite</span>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <AnimatePresence>
              {expandedTech && (() => {
                const tech = CORE_TECHNOLOGIES.find(t => t.abbr === expandedTech);
                if (!tech) return null;
                const isBF = (tech as any).isBridgeFusion;
                const beats = tech.accuracy > tech.competitorAccuracy;
                const diff = (tech.accuracy - tech.competitorAccuracy).toFixed(1);

                return (
                  <motion.div
                    key="modal-overlay"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/70 backdrop-blur-sm"
                    onClick={() => setExpandedTech(null)}
                  >
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 20 }}
                      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                      className="relative w-full max-w-lg rounded-2xl border border-[#2A3952] bg-[#0D1117] shadow-2xl shadow-black/50 overflow-hidden"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div 
                        className="absolute inset-0 opacity-[0.08] pointer-events-none"
                        style={{ background: `radial-gradient(circle at 30% 10%, ${tech.color} 0%, transparent 50%)` }}
                      />

                      <div className="relative z-10 p-6">
                        <button
                          onClick={() => setExpandedTech(null)}
                          className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                          data-testid="button-close-modal"
                        >
                          <X size={16} className="text-[#8899A6]" />
                        </button>

                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${tech.color}15`, border: `1px solid ${tech.color}30` }}>
                            <span className="font-bold text-sm" style={{ color: tech.color }}>{tech.abbr}</span>
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-white">{tech.name}</h3>
                            {isBF && <span className="text-xs font-bold text-[#FFD700] uppercase tracking-wider">Composite Super-Indicator</span>}
                          </div>
                        </div>

                        <p className="text-sm text-[#A0B2C0] mb-5 leading-relaxed">{tech.description}</p>

                        {!isBF && (
                          <div className="flex gap-3 mb-5">
                            <div className="flex-1 p-4 bg-black/40 rounded-xl border border-white/[0.05]">
                              <div className="flex items-center gap-2 mb-2">
                                <div className="w-2 h-2 rounded-full shadow-[0_0_6px_currentColor]" style={{ background: tech.color, color: tech.color }} />
                                <span className="text-[10px] font-bold uppercase tracking-wider text-white">Our Technology</span>
                              </div>
                              <div className="text-3xl font-extrabold mb-2" style={{ color: tech.color }}>{tech.accuracy}%</div>
                              <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden mb-2">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${tech.accuracy}%` }}
                                  transition={{ duration: 0.8, ease: "easeOut" }}
                                  className="h-full rounded-full"
                                  style={{ background: tech.color }}
                                />
                              </div>
                              <div className="flex justify-between text-[10px] text-[#8899A6]">
                                <span>{tech.signals} signals</span>
                                <span>{tech.timeframes}</span>
                              </div>
                            </div>

                            <div className="flex-1 p-4 bg-black/20 rounded-xl border border-white/[0.03]">
                              <div className="flex items-center gap-2 mb-2">
                                <div className="w-2 h-2 rounded-full bg-[#94A3B8]" />
                                <span className="text-[10px] font-bold uppercase tracking-wider text-[#94A3B8]">Industry</span>
                              </div>
                              <div className="text-2xl font-bold text-[#94A3B8] mb-2">{tech.competitorAccuracy}%</div>
                              <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden mb-2">
                                <div className="h-full rounded-full bg-[#64748B]" style={{ width: `${tech.competitorAccuracy}%` }} />
                              </div>
                              <p className="text-[10px] text-[#94A3B8]">{tech.competitorDesc}</p>
                            </div>
                          </div>
                        )}

                        <div className="flex items-start gap-2 p-3 bg-green-500/[0.04] rounded-xl border border-green-500/10 mb-4">
                          <CheckCircle size={14} className="text-green-400 flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-[#A0B2C0] leading-relaxed">
                            <span className="text-green-400 font-medium">Why ours is different: </span>
                            {tech.advantage}
                          </p>
                        </div>

                        {tech.note && (
                          <p className="text-[10px] text-[#556677] italic mb-4 pl-2 border-l border-[#556677]/30">{tech.note}</p>
                        )}

                        <div className="flex items-center justify-between pt-3 border-t border-white/[0.06]">
                          <div className="flex items-center gap-3 text-[10px] text-[#556677]">
                            <span className="flex items-center gap-1"><Lock size={10} /> Copyright Protected</span>
                            {!isBF && <span>EMA: <span className="text-green-400 font-medium">{tech.vsEma}</span></span>}
                            {!isBF && beats && <span className="text-green-400 font-bold">+{diff}% advantage</span>}
                          </div>
                          {tech.learnLink && (
                            <Link href={tech.learnLink}>
                              <span className="flex items-center gap-1 text-xs font-bold transition-all" style={{ color: tech.color }}>
                                Learn More <ArrowRight size={12} />
                              </span>
                            </Link>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                );
              })()}
            </AnimatePresence>
          </div>

          <div className="mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="w-1.5 h-10 rounded-full bg-gradient-to-b from-[#00D4FF] to-transparent shadow-[0_0_10px_rgba(0,212,255,0.3)]" />
              <h2 className="text-3xl font-bold text-white tracking-tight" data-testid="text-filters-heading">8 Advanced Market Filters™</h2>
              <span className="text-xs text-amber-400 bg-amber-500/10 px-3 py-1.5 rounded-full border border-amber-500/20 font-bold uppercase tracking-wider">
                Bearish Lean Confirmation
              </span>
            </motion.div>
            
            <p className="text-[#8899A6] text-lg font-light mb-10 max-w-3xl leading-relaxed">
              8 microstructure filters that validate sell signals from your other technologies. Combined holdout accuracy of 57.1% across 14 signals. 
              Strongest in down-trending markets. Use with <strong className="text-white font-semibold">Bridge Fusion™</strong> to create composite super-indicators.
            </p>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
              {ADVANCED_FILTERS.map((filter, idx) => (
                <motion.div
                  key={filter.abbr}
                  initial={{ opacity: 0, scale: 0.95, y: 15 }}
                  whileInView={{ opacity: 1, scale: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05, duration: 0.4, ease: "easeOut" }}
                  className="group"
                >
                  <div className="p-5 bg-white/[0.02] border border-white/[0.05] rounded-2xl hover:bg-white/[0.04] hover:border-white/[0.15] transition-all duration-300 h-full relative overflow-hidden shadow-lg backdrop-blur-sm cursor-pointer">
                    <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay pointer-events-none transition-opacity duration-300 group-hover:opacity-[0.08]" style={{ backgroundImage: `url("${gridPattern}")` }} />
                    <div className="flex items-center gap-3 mb-4 relative z-10">
                      <div className={`w-10 h-10 rounded-xl ${filter.bg} flex items-center justify-center transition-transform duration-300 ease-out group-hover:scale-110 shadow-inner`}>
                        <filter.icon size={20} className={filter.color} />
                      </div>
                      <span className={`text-sm font-extrabold tracking-wider ${filter.color} group-hover:brightness-125 transition-all`}>{filter.abbr}</span>
                    </div>
                    <h4 className="text-base font-bold text-white mb-2 relative z-10">{filter.name}</h4>
                    <p className="text-sm font-light text-[#8899A6] leading-relaxed relative z-10">{filter.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-r from-amber-500/10 to-transparent border border-amber-500/20 rounded-2xl p-8 relative overflow-hidden backdrop-blur-sm"
            >
              <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-amber-500/5 to-transparent pointer-events-none" />
              <div className="flex items-start md:items-center gap-5 mb-6 relative z-10 flex-col md:flex-row">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-[0_0_20px_rgba(251,191,36,0.3)]">
                  <GitMerge size={26} className="text-[#0A1628]" />
                </div>
                <div>
                  <h3 className="text-2xl font-extrabold text-amber-400 mb-1 tracking-tight">Bridge Fusion™</h3>
                  <p className="text-sm font-light text-[#A0B2C0]">Unprecedented filter combination technology</p>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 relative z-10">
                <div className="p-4 bg-black/40 rounded-xl border border-white/[0.05] text-center backdrop-blur-md">
                  <p className="text-amber-400 font-extrabold text-2xl drop-shadow-sm mb-1">18+</p>
                  <p className="text-xs text-[#8899A6] font-medium uppercase tracking-wider">Fuseable Indicators</p>
                </div>
                <div className="p-4 bg-black/40 rounded-xl border border-white/[0.05] text-center backdrop-blur-md">
                  <p className="text-amber-400 font-extrabold text-2xl drop-shadow-sm mb-1">2-8</p>
                  <p className="text-xs text-[#8899A6] font-medium uppercase tracking-wider">Filters Per Bridge</p>
                </div>
                <div className="p-4 bg-black/40 rounded-xl border border-white/[0.05] text-center backdrop-blur-md col-span-2 md:col-span-1">
                  <p className="text-amber-400 font-extrabold text-2xl drop-shadow-sm mb-1">100%</p>
                  <p className="text-xs text-[#8899A6] font-medium uppercase tracking-wider">Confidence Scoring</p>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-10"
            >
              <div className="w-1.5 h-10 rounded-full bg-gradient-to-b from-[#00FFCC] to-transparent shadow-[0_0_10px_rgba(0,255,204,0.3)]" />
              <h2 className="text-3xl font-bold text-white tracking-tight" data-testid="text-novel-signals-heading">3 Novel Signal Technologies</h2>
              <span className="text-xs text-[#00FFCC] bg-[#00FFCC]/10 px-3 py-1.5 rounded-full border border-[#00FFCC]/20 font-bold uppercase tracking-wider">
                Bonus Inclusion
              </span>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-6">
              {NOVEL_SIGNALS.map((signal, idx) => (
                <motion.div
                  key={signal.abbr}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.5, ease: "easeOut" }}
                  className="relative p-[1px] rounded-2xl group"
                  style={{ backgroundImage: `linear-gradient(180deg, transparent, ${signal.color}40)` }}
                  data-testid={`card-signal-${signal.abbr.toLowerCase()}`}
                >
                  <div className="bg-[#0A111A] h-full rounded-[15px] p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4">
                      <div className="px-3 py-1 rounded-full text-xs font-bold shadow-sm" style={{ background: `${signal.color}20`, color: signal.color }}>
                        {signal.accuracy}% Acc
                      </div>
                    </div>
                    
                    <div className="absolute -bottom-10 -right-10 text-9xl opacity-[0.03] pointer-events-none blur-sm transform group-hover:scale-110 transition-transform duration-700">
                      {signal.emoji}
                    </div>

                    <div className="flex items-center gap-4 mb-5 relative z-10 mt-2">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner border border-white/[0.05]" style={{ background: `${signal.color}15` }}>
                        {signal.emoji}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg leading-tight" style={{ color: signal.color }}>{signal.name}</h3>
                        <span className="text-xs text-[#6B7C8E] font-bold tracking-wider">{signal.abbr}</span>
                      </div>
                    </div>
                    <p className="text-[15px] text-[#8899A6] font-light leading-relaxed relative z-10">{signal.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-[#061410] to-[#0A1628] border border-green-500/20 rounded-3xl p-8 sm:p-10 mb-24 relative overflow-hidden shadow-2xl" 
            data-testid="tech-validation-summary"
          >
            <CheckCircle size={250} className="absolute -bottom-16 -right-16 text-green-500/5 rotate-[-15deg] pointer-events-none" />

            <div className="flex items-center gap-4 mb-8 relative z-10">
              <div className="p-3 bg-green-500/10 rounded-xl border border-green-500/20">
                <CheckCircle size={24} className="text-green-400 drop-shadow-[0_0_8px_rgba(74,222,128,0.5)]" />
              </div>
              <h3 className="text-2xl font-extrabold text-green-400 tracking-tight">Independent Validation Summary</h3>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8 divide-y md:divide-y-0 md:divide-x divide-green-500/10 text-base text-[#8899A6] relative z-10 font-light">
              <div className="space-y-5">
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-2 shadow-[0_0_5px_rgba(74,222,128,0.8)]" />
                  <p><span className="text-white font-bold tracking-wide">11 of 13</span> technologies beat the EMA baseline</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00D4FF] mt-2 shadow-[0_0_5px_rgba(0,212,255,0.8)]" />
                  <p><span className="text-[#00D4FF] font-bold text-lg drop-shadow-sm">54.0%</span> average accuracy vs 42.2% industry baseline</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-2 shadow-[0_0_5px_rgba(74,222,128,0.8)]" />
                  <p><span className="text-green-400 font-bold text-lg drop-shadow-sm">+11.8%</span> edge that compounds with every trade</p>
                </div>
              </div>
              <div className="space-y-5 md:pl-8 pt-6 md:pt-0">
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#8899A6] mt-2" />
                  <p>Tested across <span className="text-[#00D4FF] font-bold">12 unseen cryptocurrencies</span></p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#8899A6] mt-2" />
                  <p>Using <span className="text-white font-bold">2023-2024 out-of-sample data</span></p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#8899A6] mt-2" />
                  <p>Industry-standard blind validation methodology</p>
                </div>
              </div>
            </div>
            <p className="text-xs text-[#556677] mt-8 pt-4 border-t border-green-500/10 relative z-10 leading-relaxed max-w-4xl">
              All accuracy metrics derived from independent blind validation using historical data. Industry indicator baselines measured over the exact same datasets for 1:1 fair comparison. Past performance does not guarantee future results in live market conditions.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center relative py-10"
          >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,212,255,0.08)_0%,transparent_70%)] pointer-events-none" />
            
            <h2 className="text-4xl sm:text-5xl font-extrabold mb-4 tracking-tight bg-gradient-to-r from-white via-white to-[#00D4FF] bg-clip-text text-transparent inline-block">
              Try These Exclusive Technologies
            </h2>
            <p className="text-[#A0B2C0] text-xl font-light mb-1 max-w-2xl mx-auto">
              Access all 20 proprietary technologies in the trading terminal.
            </p>
            <p className="text-[#6B7C8E] text-base mb-10">Free to explore. Built for ultimate precision.</p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
              <Link href="/terminal">
                <span className="relative p-[2px] rounded-xl overflow-hidden group inline-block">
                  <div className="absolute inset-0 bg-gradient-to-r from-[#00D4FF] via-[#00FFCC] to-[#00D4FF] opacity-70 group-hover:opacity-100 transition-opacity duration-300 animate-pulse" />
                  <button
                    className="relative px-10 py-4 bg-[#0A1628] rounded-[10px] text-white font-bold transition-all duration-300 group-hover:bg-[#0A1628]/80 flex items-center gap-2 text-lg shadow-[0_0_20px_rgba(0,212,255,0.2)]"
                    data-testid="button-try-tech-terminal"
                  >
                    Open Terminal
                    <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </span>
              </Link>
              <Link href="/software-downloads">
                <button
                  className="px-10 py-4 bg-white/[0.03] backdrop-blur-md border border-white/[0.1] hover:border-white/[0.2] hover:bg-white/[0.06] text-white font-bold rounded-xl transition-all duration-300 text-lg shadow-lg"
                  data-testid="button-download-standalone"
                >
                  Download Standalone Apps
                </button>
              </Link>
            </div>
            <p className="mt-8 text-sm text-[#556677] font-medium tracking-wide">
              <Link href="/copyright" className="hover:text-[#00D4FF] transition-colors flex items-center justify-center gap-2">
                <Lock size={14} />
                All technologies protected by International Copyright Law
              </Link>
            </p>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}
