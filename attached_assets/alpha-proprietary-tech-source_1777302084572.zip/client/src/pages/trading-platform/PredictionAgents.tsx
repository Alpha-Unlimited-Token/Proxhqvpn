/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha 4-Agent Prediction Market Arbitrage Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - 4-Agent Prediction Engine™
 * - Multi-Platform Arbitrage System™
 * - NOAA Weather Agent™
 * - Sports Injury Agent™
 * - Crypto Spread Agent™
 * - Sentiment Polling Agent™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_4a2ad49550650358a27053bb
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { EngineStatus, Signal, Trade, AgentStatus } from "../../../../server/prediction-agents/types";

function formatTime(ts: number | null): string {
  if (!ts) return "Never";
  const d = new Date(ts);
  return d.toLocaleTimeString();
}

function formatUptime(ms: number): string {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m ${sec}s`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function edgeColor(edge: number): string {
  if (edge >= 0.25) return "text-green-400";
  if (edge >= 0.15) return "text-emerald-400";
  if (edge >= 0.08) return "text-yellow-400";
  return "text-orange-400";
}

function confidenceBadge(confidence: number) {
  if (confidence >= 0.8) return <Badge className="bg-green-600/20 text-green-400 border-green-500/30" data-testid="badge-confidence-high">High</Badge>;
  if (confidence >= 0.6) return <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-500/30" data-testid="badge-confidence-medium">Medium</Badge>;
  return <Badge className="bg-orange-600/20 text-orange-400 border-orange-500/30" data-testid="badge-confidence-low">Low</Badge>;
}

function agentIcon(id: string): string {
  switch (id) {
    case "weather": return "🌦️";
    case "crypto": return "₿";
    case "sentiment": return "📊";
    case "sports": return "⚽";
    default: return "🤖";
  }
}

function AgentStatusCard({ agent, onToggle }: { agent: AgentStatus; onToggle: (id: string, enabled: boolean) => void }) {
  return (
    <Card className="bg-[#0f1923] border-[#1E3A5F]/50 hover:border-[#1E3A5F] transition-colors" data-testid={`card-agent-${agent.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{agentIcon(agent.id)}</span>
            <div>
              <h3 className="text-sm font-semibold text-white" data-testid={`text-agent-name-${agent.id}`}>{agent.name}</h3>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className={`w-2 h-2 rounded-full ${agent.running ? "bg-green-500 animate-pulse" : agent.enabled ? "bg-yellow-500" : "bg-gray-600"}`} />
                <span className="text-[11px] text-gray-400" data-testid={`text-agent-status-${agent.id}`}>
                  {agent.running ? "Scanning..." : agent.enabled ? "Idle" : "Disabled"}
                </span>
              </div>
            </div>
          </div>
          <Switch
            checked={agent.enabled}
            onCheckedChange={(checked) => onToggle(agent.id, checked)}
            data-testid={`switch-agent-${agent.id}`}
          />
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-[#0a1018] rounded p-2">
            <div className="text-xs text-gray-500">Scans</div>
            <div className="text-sm font-mono text-white" data-testid={`text-scan-count-${agent.id}`}>{agent.scanCount}</div>
          </div>
          <div className="bg-[#0a1018] rounded p-2">
            <div className="text-xs text-gray-500">Signals</div>
            <div className="text-sm font-mono text-cyan-400" data-testid={`text-signal-count-${agent.id}`}>{agent.activeSignals}</div>
          </div>
          <div className="bg-[#0a1018] rounded p-2">
            <div className="text-xs text-gray-500">Win Rate</div>
            <div className="text-sm font-mono text-green-400" data-testid={`text-win-rate-${agent.id}`}>{(agent.winRate * 100).toFixed(0)}%</div>
          </div>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-gray-500">
          <span>Last scan: {formatTime(agent.lastScan)}</span>
          {agent.lastError && (
            <span className="text-red-400 truncate max-w-[120px]" title={agent.lastError}>⚠ Error</span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function SignalStrengthBar({ edge }: { edge: number }) {
  const pct = Math.min(edge * 200, 100);
  return (
    <div className="w-full h-1.5 bg-[#0a1018] rounded-full overflow-hidden" data-testid="bar-signal-strength">
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{
          width: `${pct}%`,
          background: pct > 60 ? "linear-gradient(90deg, #10b981, #22c55e)" :
                     pct > 30 ? "linear-gradient(90deg, #eab308, #facc15)" :
                     "linear-gradient(90deg, #f97316, #fb923c)"
        }}
      />
    </div>
  );
}

function SignalsTable({ signals, marketFilter }: { signals: Signal[]; marketFilter: string }) {
  const filtered = marketFilter === "all" ? signals : signals.filter(s => s.market.platform === marketFilter);

  if (filtered.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-signals">
        <div className="text-3xl mb-2">📡</div>
        <p>No active signals. Agents are scanning markets...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-signals">
        <thead>
          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
            <th className="text-left py-2 px-3">Agent</th>
            <th className="text-left py-2 px-3">Market</th>
            <th className="text-left py-2 px-3">Direction</th>
            <th className="text-right py-2 px-3">Edge</th>
            <th className="text-right py-2 px-3">Price</th>
            <th className="text-right py-2 px-3">Fair Value</th>
            <th className="text-center py-2 px-3">Confidence</th>
            <th className="text-center py-2 px-3">Strength</th>
            <th className="text-left py-2 px-3">Platform</th>
            <th className="text-left py-2 px-3">Time</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((sig) => (
            <tr key={sig.id} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors" data-testid={`row-signal-${sig.id}`}>
              <td className="py-2 px-3">
                <span className="mr-1">{agentIcon(sig.agentId)}</span>
                <span className="text-gray-300 text-xs">{sig.agentName}</span>
              </td>
              <td className="py-2 px-3">
                <div className="text-white text-xs font-medium max-w-[200px] truncate" title={sig.market.title}>
                  {sig.market.title}
                </div>
              </td>
              <td className="py-2 px-3">
                <Badge className={`text-[10px] ${sig.direction.includes("BUY") ? "bg-green-600/20 text-green-400 border-green-500/30" : "bg-red-600/20 text-red-400 border-red-500/30"}`}>
                  {sig.direction}
                </Badge>
              </td>
              <td className={`py-2 px-3 text-right font-mono font-semibold ${edgeColor(sig.edge)}`} data-testid={`text-edge-${sig.id}`}>
                {(sig.edge * 100).toFixed(1)}%
              </td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">
                {sig.currentPrice.toFixed(2)}¢
              </td>
              <td className="py-2 px-3 text-right font-mono text-cyan-400">
                {sig.fairValue.toFixed(2)}¢
              </td>
              <td className="py-2 px-3 text-center">
                {confidenceBadge(sig.confidence)}
              </td>
              <td className="py-2 px-3 w-24">
                <SignalStrengthBar edge={sig.edge} />
              </td>
              <td className="py-2 px-3">
                <Badge variant="outline" className="text-[10px] border-[#1E3A5F] text-gray-400">
                  {sig.market.platform}
                </Badge>
              </td>
              <td className="py-2 px-3 text-gray-500 text-xs">
                {formatTime(sig.timestamp)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TradesTable({ trades }: { trades: Trade[] }) {
  if (trades.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-trades">
        <div className="text-3xl mb-2">📋</div>
        <p>No trades yet. Running in dry-run mode.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-trades">
        <thead>
          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
            <th className="text-left py-2 px-3">Market</th>
            <th className="text-left py-2 px-3">Direction</th>
            <th className="text-right py-2 px-3">Entry</th>
            <th className="text-right py-2 px-3">Exit</th>
            <th className="text-right py-2 px-3">Size</th>
            <th className="text-right py-2 px-3">P&L</th>
            <th className="text-center py-2 px-3">Status</th>
            <th className="text-left py-2 px-3">Time</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((trade) => (
            <tr key={trade.id} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50" data-testid={`row-trade-${trade.id}`}>
              <td className="py-2 px-3 text-white text-xs max-w-[180px] truncate">{trade.marketTitle}</td>
              <td className="py-2 px-3">
                <Badge className={`text-[10px] ${trade.direction.includes("BUY") ? "bg-green-600/20 text-green-400 border-green-500/30" : "bg-red-600/20 text-red-400 border-red-500/30"}`}>
                  {trade.direction}
                </Badge>
              </td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">{trade.entryPrice.toFixed(2)}¢</td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">{trade.exitPrice ? `${trade.exitPrice.toFixed(2)}¢` : "—"}</td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">${trade.size.toFixed(2)}</td>
              <td className={`py-2 px-3 text-right font-mono font-semibold ${(trade.pnl || 0) >= 0 ? "text-green-400" : "text-red-400"}`} data-testid={`text-pnl-${trade.id}`}>
                {trade.pnl !== null ? `$${trade.pnl.toFixed(2)}` : "—"}
              </td>
              <td className="py-2 px-3 text-center">
                <Badge variant="outline" className={`text-[10px] ${trade.status === "open" ? "border-cyan-500 text-cyan-400" : trade.status === "closed" ? "border-gray-500 text-gray-400" : "border-yellow-500 text-yellow-400"}`}>
                  {trade.status}
                </Badge>
              </td>
              <td className="py-2 px-3 text-gray-500 text-xs">{formatTime(trade.entryTime)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PnLChart({ trades }: { trades: Trade[] }) {
  const closedTrades = trades.filter(t => t.status === "closed" && t.pnl !== null);
  if (closedTrades.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-gray-500 text-sm" data-testid="text-no-pnl-data">
        <div className="text-center">
          <div className="text-2xl mb-2">📈</div>
          <p>P&L chart will appear after trades close</p>
        </div>
      </div>
    );
  }

  let cumPnl = 0;
  const points = closedTrades.map((t, i) => {
    cumPnl += t.pnl || 0;
    return { x: i, y: cumPnl };
  });

  const maxY = Math.max(...points.map(p => Math.abs(p.y)), 1);
  const h = 160;
  const w = 100;

  return (
    <div className="p-4" data-testid="chart-pnl">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-48" preserveAspectRatio="none">
        <line x1="0" y1={h / 2} x2={w} y2={h / 2} stroke="#1E3A5F" strokeWidth="0.5" strokeDasharray="2,2" />
        <polyline
          fill="none"
          stroke={cumPnl >= 0 ? "#22c55e" : "#ef4444"}
          strokeWidth="1.5"
          points={points.map(p => `${(p.x / (points.length - 1 || 1)) * w},${h / 2 - (p.y / maxY) * (h / 2 - 10)}`).join(" ")}
        />
        {points.map((p, i) => (
          <circle
            key={i}
            cx={(p.x / (points.length - 1 || 1)) * w}
            cy={h / 2 - (p.y / maxY) * (h / 2 - 10)}
            r="2"
            fill={p.y >= 0 ? "#22c55e" : "#ef4444"}
          />
        ))}
        <text x="2" y="10" fill="#6b7280" fontSize="6">+${maxY.toFixed(0)}</text>
        <text x="2" y={h - 4} fill="#6b7280" fontSize="6">-${maxY.toFixed(0)}</text>
      </svg>
    </div>
  );
}

export default function PredictionAgents() {
  const [status, setStatus] = useState<EngineStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [marketFilter, setMarketFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("signals");

  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch("/api/prediction-agents/status");
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, [fetchStatus]);

  const handleStartStop = async () => {
    if (!status) return;
    const endpoint = status.running ? "/api/prediction-agents/stop" : "/api/prediction-agents/start";
    await fetch(endpoint, { method: "POST" });
    setTimeout(fetchStatus, 500);
  };

  const handleAgentToggle = async (agentId: string, enabled: boolean) => {
    await fetch("/api/prediction-agents/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agents: [{ id: agentId, enabled }] }),
    });
    setTimeout(fetchStatus, 500);
  };

  const handleConfigUpdate = async (updates: Record<string, any>) => {
    await fetch("/api/prediction-agents/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    setTimeout(fetchStatus, 500);
  };

  if (loading) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-400 text-sm">Loading Prediction Engine...</span>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  const agents = status?.agents || [];
  const activeSignals = status?.activeSignals || [];
  const recentTrades = status?.recentTrades || [];
  const config = status?.config;

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-prediction-agents">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
              🤖 Prediction Market Agents
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              4-agent arbitrage system scanning Polymarket, Kalshi & Manifold for mispriced opportunities
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm">
              <div className={`w-2.5 h-2.5 rounded-full ${status?.running ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
              <span className="text-gray-300" data-testid="text-engine-status">
                {status?.running ? "Engine Running" : "Engine Stopped"}
              </span>
              {status?.running && status.uptime > 0 && (
                <span className="text-gray-500 text-xs">({formatUptime(status.uptime)})</span>
              )}
            </div>
            <Button
              onClick={handleStartStop}
              variant={status?.running ? "destructive" : "default"}
              size="sm"
              className={status?.running ? "" : "bg-green-600 hover:bg-green-700"}
              data-testid="button-start-stop"
            >
              {status?.running ? "Stop Engine" : "Start Engine"}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-gray-500">Active Signals</div>
              <div className="text-xl font-bold font-mono text-cyan-400" data-testid="text-total-signals">{activeSignals.length}</div>
            </CardContent>
          </Card>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-gray-500">Total Trades</div>
              <div className="text-xl font-bold font-mono text-white" data-testid="text-total-trades">{status?.totalTrades || 0}</div>
            </CardContent>
          </Card>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-gray-500">Win Rate</div>
              <div className="text-xl font-bold font-mono text-green-400" data-testid="text-total-win-rate">{((status?.winRate || 0) * 100).toFixed(0)}%</div>
            </CardContent>
          </Card>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-gray-500">Total P&L</div>
              <div className={`text-xl font-bold font-mono ${(status?.totalPnl || 0) >= 0 ? "text-green-400" : "text-red-400"}`} data-testid="text-total-pnl">
                ${(status?.totalPnl || 0).toFixed(2)}
              </div>
            </CardContent>
          </Card>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-gray-500">Mode</div>
              <div className="text-sm font-semibold mt-1" data-testid="text-mode">
                <Badge className={config?.dryRun ? "bg-yellow-600/20 text-yellow-400 border-yellow-500/30" : "bg-green-600/20 text-green-400 border-green-500/30"}>
                  {config?.dryRun ? "DRY RUN" : "LIVE"}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {agents.map((agent) => (
            <AgentStatusCard key={agent.id} agent={agent} onToggle={handleAgentToggle} />
          ))}
        </div>

        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardHeader className="pb-2">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="bg-[#0a1018]">
                  <TabsTrigger value="signals" className="text-xs" data-testid="tab-signals">
                    📡 Signals ({activeSignals.length})
                  </TabsTrigger>
                  <TabsTrigger value="trades" className="text-xs" data-testid="tab-trades">
                    📋 Trades ({recentTrades.length})
                  </TabsTrigger>
                  <TabsTrigger value="pnl" className="text-xs" data-testid="tab-pnl">
                    📈 P&L
                  </TabsTrigger>
                  <TabsTrigger value="config" className="text-xs" data-testid="tab-config">
                    ⚙️ Config
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              {activeTab === "signals" && (
                <Select value={marketFilter} onValueChange={setMarketFilter}>
                  <SelectTrigger className="w-[160px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm h-8" data-testid="select-market-filter">
                    <SelectValue placeholder="Filter market" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Markets</SelectItem>
                    <SelectItem value="polymarket">Polymarket</SelectItem>
                    <SelectItem value="kalshi">Kalshi</SelectItem>
                    <SelectItem value="manifold">Manifold</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {activeTab === "signals" && <SignalsTable signals={activeSignals} marketFilter={marketFilter} />}
            {activeTab === "trades" && <TradesTable trades={recentTrades} />}
            {activeTab === "pnl" && <PnLChart trades={recentTrades} />}
            {activeTab === "config" && config && (
              <div className="p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Platforms</Label>
                    <div className="flex flex-wrap gap-2">
                      {["polymarket", "kalshi", "manifold"].map((p) => (
                        <Badge
                          key={p}
                          className={`cursor-pointer text-xs ${config.platforms.includes(p) ? "bg-cyan-600/20 text-cyan-400 border-cyan-500/30" : "bg-gray-800 text-gray-500 border-gray-700"}`}
                          onClick={() => {
                            const updated = config.platforms.includes(p)
                              ? config.platforms.filter(x => x !== p)
                              : [...config.platforms, p];
                            if (updated.length > 0) handleConfigUpdate({ platforms: updated });
                          }}
                          data-testid={`badge-platform-${p}`}
                        >
                          {p}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Max Total Exposure ($)</Label>
                    <Input
                      type="number"
                      value={config.maxTotalExposure}
                      onChange={(e) => handleConfigUpdate({ maxTotalExposure: Number(e.target.value) })}
                      className="bg-[#0a1018] border-[#1E3A5F]/50 h-8 text-sm"
                      data-testid="input-max-exposure"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Max Trades Per Day</Label>
                    <Input
                      type="number"
                      value={config.maxTradesPerDay}
                      onChange={(e) => handleConfigUpdate({ maxTradesPerDay: Number(e.target.value) })}
                      className="bg-[#0a1018] border-[#1E3A5F]/50 h-8 text-sm"
                      data-testid="input-max-trades"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Min Edge Threshold (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={(config.minEdgeThreshold * 100).toFixed(0)}
                      onChange={(e) => handleConfigUpdate({ minEdgeThreshold: Number(e.target.value) / 100 })}
                      className="bg-[#0a1018] border-[#1E3A5F]/50 h-8 text-sm"
                      data-testid="input-min-edge"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Trading Mode</Label>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={!config.dryRun}
                        onCheckedChange={(checked) => handleConfigUpdate({ dryRun: !checked })}
                        data-testid="switch-live-mode"
                      />
                      <span className={`text-sm ${config.dryRun ? "text-yellow-400" : "text-green-400"}`}>
                        {config.dryRun ? "Dry Run (Signals Only)" : "Live Trading"}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-400 text-xs">Wallet</Label>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${config.walletConnected ? "bg-green-500" : "bg-red-500"}`} />
                      <span className="text-sm text-gray-400" data-testid="text-wallet-status">
                        {config.walletConnected ? "Connected" : "Not Connected"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-[#1E3A5F]/30 pt-4">
                  <h4 className="text-sm font-semibold text-gray-300 mb-3">Agent Configuration</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {config.agents.map((agentCfg) => (
                      <div key={agentCfg.id} className="bg-[#0a1018] rounded p-3 space-y-2" data-testid={`config-agent-${agentCfg.id}`}>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-white">{agentIcon(agentCfg.id)} {agentCfg.name}</span>
                          <Switch
                            checked={agentCfg.enabled}
                            onCheckedChange={(checked) => handleAgentToggle(agentCfg.id, checked)}
                            data-testid={`switch-config-agent-${agentCfg.id}`}
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-gray-500 text-[10px]">Scan (min)</Label>
                            <Input
                              type="number"
                              value={Math.round(agentCfg.scanIntervalMs / 60000)}
                              onChange={(e) => handleConfigUpdate({
                                agents: [{ id: agentCfg.id, scanIntervalMs: Number(e.target.value) * 60000 }]
                              })}
                              className="bg-[#0f1923] border-[#1E3A5F]/30 h-7 text-xs"
                              data-testid={`input-scan-interval-${agentCfg.id}`}
                            />
                          </div>
                          <div>
                            <Label className="text-gray-500 text-[10px]">Min Edge (%)</Label>
                            <Input
                              type="number"
                              step="1"
                              value={(agentCfg.minEdge * 100).toFixed(0)}
                              onChange={(e) => handleConfigUpdate({
                                agents: [{ id: agentCfg.id, minEdge: Number(e.target.value) / 100 }]
                              })}
                              className="bg-[#0f1923] border-[#1E3A5F]/30 h-7 text-xs"
                              data-testid={`input-min-edge-${agentCfg.id}`}
                            />
                          </div>
                          <div>
                            <Label className="text-gray-500 text-[10px]">Max Size ($)</Label>
                            <Input
                              type="number"
                              value={agentCfg.maxPositionSize}
                              onChange={(e) => handleConfigUpdate({
                                agents: [{ id: agentCfg.id, maxPositionSize: Number(e.target.value) }]
                              })}
                              className="bg-[#0f1923] border-[#1E3A5F]/30 h-7 text-xs"
                              data-testid={`input-max-size-${agentCfg.id}`}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </TradingPlatformLayout>
  );
}
