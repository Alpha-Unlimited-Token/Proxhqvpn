/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Multi-Chain Wallet™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Multi-Chain Wallet™
 * - Cross-Chain Asset Aggregator™
 * - Real-Time Balance Engine™
 * - Multi-Network Transaction Manager™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_25d096916ab7648ab9c782f6
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ChainConfig {
  id: string;
  name: string;
  symbol: string;
  icon: string;
  color: string;
  explorer: string;
  rpcUrl: string;
}

const CHAINS: ChainConfig[] = [
  { id: "ethereum", name: "Ethereum", symbol: "ETH", icon: "⟠", color: "#627EEA", explorer: "https://etherscan.io", rpcUrl: "https://eth.blockscout.com/api/v2" },
  { id: "bsc", name: "BNB Chain", symbol: "BNB", icon: "⬡", color: "#F3BA2F", explorer: "https://bscscan.com", rpcUrl: "https://bsc.blockscout.com/api/v2" },
  { id: "polygon", name: "Polygon", symbol: "MATIC", icon: "⬟", color: "#8247E5", explorer: "https://polygonscan.com", rpcUrl: "https://polygon.blockscout.com/api/v2" },
  { id: "arbitrum", name: "Arbitrum", symbol: "ETH", icon: "◈", color: "#28A0F0", explorer: "https://arbiscan.io", rpcUrl: "https://arbitrum.blockscout.com/api/v2" },
  { id: "optimism", name: "Optimism", symbol: "ETH", icon: "◉", color: "#FF0420", explorer: "https://optimistic.etherscan.io", rpcUrl: "https://optimism.blockscout.com/api/v2" },
  { id: "avalanche", name: "Avalanche", symbol: "AVAX", icon: "▲", color: "#E84142", explorer: "https://snowtrace.io", rpcUrl: "https://avax.blockscout.com/api/v2" },
  { id: "solana", name: "Solana", symbol: "SOL", icon: "◎", color: "#9945FF", explorer: "https://solscan.io", rpcUrl: "https://api.mainnet-beta.solana.com" },
  { id: "base", name: "Base", symbol: "ETH", icon: "⬢", color: "#0052FF", explorer: "https://basescan.org", rpcUrl: "https://base.blockscout.com/api/v2" },
];

interface TokenBalance {
  symbol: string;
  name: string;
  balance: string;
  decimals: number;
  usdValue: number;
  contractAddress: string;
  chain: string;
  logoUrl?: string;
}

interface NFTItem {
  tokenId: string;
  name: string;
  collection: string;
  imageUrl: string;
  chain: string;
  contractAddress: string;
}

interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  chain: string;
  status: "success" | "failed" | "pending";
  type: "send" | "receive" | "swap" | "contract";
}

interface WalletData {
  address: string;
  chain: string;
  nativeBalance: string;
  nativeUsdValue: number;
  tokens: TokenBalance[];
  nfts: NFTItem[];
  transactions: Transaction[];
}

function shortenAddress(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function formatUsd(value: number): string {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(2)}K`;
  return `$${value.toFixed(2)}`;
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function ChainBadge({ chainId }: { chainId: string }) {
  const chain = CHAINS.find(c => c.id === chainId);
  if (!chain) return null;
  return (
    <Badge
      className="text-[10px] border px-1.5"
      style={{ backgroundColor: `${chain.color}20`, color: chain.color, borderColor: `${chain.color}40` }}
      data-testid={`badge-chain-${chainId}`}
    >
      {chain.icon} {chain.name}
    </Badge>
  );
}

function PortfolioSummary({ wallets }: { wallets: WalletData[] }) {
  const totalNativeUsd = wallets.reduce((sum, w) => sum + w.nativeUsdValue, 0);
  const totalTokensUsd = wallets.reduce((sum, w) => sum + w.tokens.reduce((s, t) => s + t.usdValue, 0), 0);
  const totalUsd = totalNativeUsd + totalTokensUsd;
  const totalTokens = wallets.reduce((sum, w) => sum + w.tokens.length, 0);
  const totalNfts = wallets.reduce((sum, w) => sum + w.nfts.length, 0);
  const chainsUsed = new Set(wallets.map(w => w.chain)).size;

  const chainBreakdown = CHAINS.map(chain => {
    const chainWallets = wallets.filter(w => w.chain === chain.id);
    const value = chainWallets.reduce((sum, w) => w.nativeUsdValue + w.tokens.reduce((s, t) => s + t.usdValue, 0) + sum, 0);
    return { ...chain, value };
  }).filter(c => c.value > 0).sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500">Total Portfolio Value</div>
            <div className="text-2xl font-bold font-mono text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-500" data-testid="text-total-portfolio-value">
              {formatUsd(totalUsd)}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500">Chains Connected</div>
            <div className="text-2xl font-bold font-mono text-cyan-400" data-testid="text-chains-count">{chainsUsed}</div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500">Total Tokens</div>
            <div className="text-2xl font-bold font-mono text-green-400" data-testid="text-total-tokens">{totalTokens}</div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500">NFTs Owned</div>
            <div className="text-2xl font-bold font-mono text-purple-400" data-testid="text-total-nfts">{totalNfts}</div>
          </CardContent>
        </Card>
      </div>

      {chainBreakdown.length > 0 && (
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">Chain Allocation</h3>
            <div className="space-y-2">
              {chainBreakdown.map(chain => {
                const pct = totalUsd > 0 ? (chain.value / totalUsd) * 100 : 0;
                return (
                  <div key={chain.id} className="flex items-center gap-3" data-testid={`allocation-chain-${chain.id}`}>
                    <span className="text-lg w-6 text-center">{chain.icon}</span>
                    <span className="text-sm text-white w-24">{chain.name}</span>
                    <div className="flex-1 h-2 bg-[#0a1018] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, backgroundColor: chain.color }}
                      />
                    </div>
                    <span className="text-sm font-mono text-gray-300 w-24 text-right">{formatUsd(chain.value)}</span>
                    <span className="text-xs text-gray-500 w-12 text-right">{pct.toFixed(1)}%</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function TokensView({ wallets, chainFilter }: { wallets: WalletData[]; chainFilter: string }) {
  const allTokens: (TokenBalance & { walletAddress: string })[] = [];
  for (const w of wallets) {
    if (chainFilter !== "all" && w.chain !== chainFilter) continue;
    allTokens.push({
      symbol: w.chain === "solana" ? "SOL" : CHAINS.find(c => c.id === w.chain)?.symbol || "ETH",
      name: CHAINS.find(c => c.id === w.chain)?.name || w.chain,
      balance: w.nativeBalance,
      decimals: 18,
      usdValue: w.nativeUsdValue,
      contractAddress: "native",
      chain: w.chain,
      walletAddress: w.address,
    });
    for (const token of w.tokens) {
      allTokens.push({ ...token, walletAddress: w.address });
    }
  }

  const sorted = allTokens.sort((a, b) => b.usdValue - a.usdValue);

  if (sorted.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-tokens">
        <div className="text-3xl mb-2">💰</div>
        <p>No tokens found. Connect a wallet to view balances.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-tokens">
        <thead>
          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
            <th className="text-left py-2 px-3">Token</th>
            <th className="text-left py-2 px-3">Chain</th>
            <th className="text-right py-2 px-3">Balance</th>
            <th className="text-right py-2 px-3">USD Value</th>
            <th className="text-left py-2 px-3">Wallet</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((token, i) => (
            <tr key={`${token.chain}-${token.contractAddress}-${i}`} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors" data-testid={`row-token-${i}`}>
              <td className="py-2 px-3">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-[#1E3A5F]/50 flex items-center justify-center text-xs font-bold text-white">
                    {token.symbol.charAt(0)}
                  </div>
                  <div>
                    <div className="text-white font-medium text-xs">{token.symbol}</div>
                    <div className="text-gray-500 text-[10px]">{token.name}</div>
                  </div>
                </div>
              </td>
              <td className="py-2 px-3"><ChainBadge chainId={token.chain} /></td>
              <td className="py-2 px-3 text-right font-mono text-gray-300 text-xs">{parseFloat(token.balance).toFixed(4)}</td>
              <td className="py-2 px-3 text-right font-mono text-green-400 font-semibold text-xs">{formatUsd(token.usdValue)}</td>
              <td className="py-2 px-3 text-gray-500 text-xs font-mono">{shortenAddress((token as any).walletAddress || "")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function NFTsView({ wallets, chainFilter }: { wallets: WalletData[]; chainFilter: string }) {
  const allNfts: NFTItem[] = [];
  for (const w of wallets) {
    if (chainFilter !== "all" && w.chain !== chainFilter) continue;
    allNfts.push(...w.nfts);
  }

  if (allNfts.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-nfts">
        <div className="text-3xl mb-2">🖼️</div>
        <p>No NFTs found across connected wallets.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3" data-testid="grid-nfts">
      {allNfts.map((nft, i) => (
        <Card key={`${nft.chain}-${nft.contractAddress}-${nft.tokenId}-${i}`} className="bg-[#0f1923] border-[#1E3A5F]/50 overflow-hidden hover:border-[#1E3A5F] transition-colors" data-testid={`card-nft-${i}`}>
          <div className="aspect-square bg-[#0a1018] flex items-center justify-center">
            {nft.imageUrl ? (
              <img src={nft.imageUrl} alt={nft.name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-4xl">🖼️</span>
            )}
          </div>
          <CardContent className="p-3">
            <div className="text-white text-xs font-medium truncate">{nft.name || `#${nft.tokenId}`}</div>
            <div className="text-gray-500 text-[10px] truncate">{nft.collection}</div>
            <div className="mt-1"><ChainBadge chainId={nft.chain} /></div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function TransactionsView({ wallets, chainFilter }: { wallets: WalletData[]; chainFilter: string }) {
  const allTxs: Transaction[] = [];
  for (const w of wallets) {
    if (chainFilter !== "all" && w.chain !== chainFilter) continue;
    allTxs.push(...w.transactions);
  }

  const sorted = allTxs.sort((a, b) => b.timestamp - a.timestamp);

  if (sorted.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-transactions">
        <div className="text-3xl mb-2">📜</div>
        <p>No transactions found. Connect a wallet to view history.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-transactions">
        <thead>
          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
            <th className="text-left py-2 px-3">Type</th>
            <th className="text-left py-2 px-3">Chain</th>
            <th className="text-left py-2 px-3">Hash</th>
            <th className="text-left py-2 px-3">From</th>
            <th className="text-left py-2 px-3">To</th>
            <th className="text-right py-2 px-3">Value</th>
            <th className="text-center py-2 px-3">Status</th>
            <th className="text-right py-2 px-3">Time</th>
          </tr>
        </thead>
        <tbody>
          {sorted.slice(0, 50).map((tx, i) => (
            <tr key={`${tx.hash}-${i}`} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors" data-testid={`row-tx-${i}`}>
              <td className="py-2 px-3">
                <Badge className={`text-[10px] ${
                  tx.type === "receive" ? "bg-green-600/20 text-green-400 border-green-500/30" :
                  tx.type === "send" ? "bg-red-600/20 text-red-400 border-red-500/30" :
                  tx.type === "swap" ? "bg-cyan-600/20 text-cyan-400 border-cyan-500/30" :
                  "bg-purple-600/20 text-purple-400 border-purple-500/30"
                }`}>
                  {tx.type === "receive" ? "↓ Receive" : tx.type === "send" ? "↑ Send" : tx.type === "swap" ? "⇄ Swap" : "◈ Contract"}
                </Badge>
              </td>
              <td className="py-2 px-3"><ChainBadge chainId={tx.chain} /></td>
              <td className="py-2 px-3 font-mono text-cyan-400 text-xs">
                <a href={`${CHAINS.find(c => c.id === tx.chain)?.explorer}/tx/${tx.hash}`} target="_blank" rel="noopener noreferrer" className="hover:underline" data-testid={`link-tx-${i}`}>
                  {shortenAddress(tx.hash)}
                </a>
              </td>
              <td className="py-2 px-3 font-mono text-gray-400 text-xs">{shortenAddress(tx.from)}</td>
              <td className="py-2 px-3 font-mono text-gray-400 text-xs">{shortenAddress(tx.to)}</td>
              <td className="py-2 px-3 text-right font-mono text-white text-xs">{tx.value}</td>
              <td className="py-2 px-3 text-center">
                <div className={`w-2 h-2 rounded-full mx-auto ${
                  tx.status === "success" ? "bg-green-500" : tx.status === "failed" ? "bg-red-500" : "bg-yellow-500 animate-pulse"
                }`} />
              </td>
              <td className="py-2 px-3 text-right text-gray-500 text-xs">{timeAgo(tx.timestamp)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function MultiChainWallet() {
  const [wallets, setWallets] = useState<WalletData[]>([]);
  const [loading, setLoading] = useState(false);
  const [addressInput, setAddressInput] = useState("");
  const [selectedChain, setSelectedChain] = useState("ethereum");
  const [chainFilter, setChainFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("tokens");
  const [connectedAddresses, setConnectedAddresses] = useState<{ address: string; chain: string }[]>([]);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const fetchWalletData = useCallback(async (address: string, chain: string) => {
    setLoading(true);
    setFetchError(null);
    try {
      const res = await fetch(`/api/multi-chain-wallet/balances?address=${encodeURIComponent(address)}&chain=${encodeURIComponent(chain)}`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to fetch wallet data" }));
        throw new Error(err.message || "Failed to fetch wallet data");
      }
      const data: WalletData = await res.json();
      setWallets(prev => {
        const filtered = prev.filter(w => !(w.address === address && w.chain === chain));
        return [...filtered, data];
      });
    } catch (err: any) {
      setFetchError(err.message || "Failed to fetch wallet data");
    } finally {
      setLoading(false);
    }
  }, []);

  const handleAddWallet = async () => {
    if (!addressInput.trim()) return;
    const addr = addressInput.trim();
    const existing = connectedAddresses.find(c => c.address === addr && c.chain === selectedChain);
    if (existing) return;

    setConnectedAddresses(prev => [...prev, { address: addr, chain: selectedChain }]);
    await fetchWalletData(addr, selectedChain);
    setAddressInput("");
  };

  const handleRemoveWallet = (address: string, chain: string) => {
    setConnectedAddresses(prev => prev.filter(c => !(c.address === address && c.chain === chain)));
    setWallets(prev => prev.filter(w => !(w.address === address && w.chain === chain)));
  };

  const handleRefreshAll = async () => {
    for (const conn of connectedAddresses) {
      await fetchWalletData(conn.address, conn.chain);
    }
  };

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-multi-chain-wallet">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-5">
            <img
              src="/phoenix-multichain-wallet.png"
              alt="Alpha Phoenix with blockchain chain necklaces and wallet charms"
              className="w-80 h-48 md:w-[480px] md:h-[280px] object-contain drop-shadow-[0_0_25px_rgba(0,212,255,0.4)]"
              data-testid="img-multichain-phoenix"
            />
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
                🔗 Multi-Chain Wallet
              </h1>
              <p className="text-gray-400 text-sm mt-1">
                Unified dashboard for assets across Ethereum, BSC, Polygon, Arbitrum, Solana, and more
              </p>
            </div>
          </div>
          {connectedAddresses.length > 0 && (
            <Button
              onClick={handleRefreshAll}
              variant="outline"
              size="sm"
              className="border-[#1E3A5F] text-gray-300 hover:bg-[#1E3A5F]/30"
              disabled={loading}
              data-testid="button-refresh-all"
            >
              {loading ? "Refreshing..." : "↻ Refresh All"}
            </Button>
          )}
        </div>

        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-3">
              <Select value={selectedChain} onValueChange={setSelectedChain}>
                <SelectTrigger className="w-full md:w-[200px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm h-10" data-testid="select-chain">
                  <SelectValue placeholder="Select chain" />
                </SelectTrigger>
                <SelectContent>
                  {CHAINS.map(chain => (
                    <SelectItem key={chain.id} value={chain.id}>
                      {chain.icon} {chain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Enter wallet address (0x... or Solana address)"
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                className="flex-1 bg-[#0a1018] border-[#1E3A5F]/50 h-10 text-sm"
                onKeyDown={(e) => e.key === "Enter" && handleAddWallet()}
                data-testid="input-wallet-address"
              />
              <Button
                onClick={handleAddWallet}
                disabled={!addressInput.trim() || loading}
                className="bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-black font-semibold h-10"
                data-testid="button-add-wallet"
              >
                {loading ? "Loading..." : "Connect Wallet"}
              </Button>
            </div>
            {fetchError && (
              <div className="mt-3 text-red-400 text-sm bg-red-900/20 border border-red-500/30 rounded p-2" data-testid="text-fetch-error">
                ⚠ {fetchError}
              </div>
            )}
          </CardContent>
        </Card>

        {connectedAddresses.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {connectedAddresses.map((conn, i) => {
              const chain = CHAINS.find(c => c.id === conn.chain);
              return (
                <div
                  key={`${conn.chain}-${conn.address}-${i}`}
                  className="flex items-center gap-2 bg-[#0f1923] border border-[#1E3A5F]/50 rounded-lg px-3 py-1.5"
                  data-testid={`connected-wallet-${i}`}
                >
                  <span className="text-sm">{chain?.icon}</span>
                  <span className="text-xs font-mono text-gray-300">{shortenAddress(conn.address)}</span>
                  <span className="text-[10px] text-gray-500">{chain?.name}</span>
                  <button
                    onClick={() => handleRemoveWallet(conn.address, conn.chain)}
                    className="text-gray-500 hover:text-red-400 text-xs ml-1"
                    data-testid={`button-remove-wallet-${i}`}
                  >
                    ✕
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {wallets.length > 0 && <PortfolioSummary wallets={wallets} />}

        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardHeader className="pb-2">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="bg-[#0a1018]">
                  <TabsTrigger value="tokens" className="text-xs" data-testid="tab-tokens">
                    💰 Tokens
                  </TabsTrigger>
                  <TabsTrigger value="nfts" className="text-xs" data-testid="tab-nfts">
                    🖼️ NFTs
                  </TabsTrigger>
                  <TabsTrigger value="transactions" className="text-xs" data-testid="tab-transactions">
                    📜 Transactions
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              <Select value={chainFilter} onValueChange={setChainFilter}>
                <SelectTrigger className="w-[180px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm h-8" data-testid="select-chain-filter">
                  <SelectValue placeholder="Filter by chain" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Chains</SelectItem>
                  {CHAINS.map(chain => (
                    <SelectItem key={chain.id} value={chain.id}>
                      {chain.icon} {chain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {activeTab === "tokens" && <TokensView wallets={wallets} chainFilter={chainFilter} />}
            {activeTab === "nfts" && <NFTsView wallets={wallets} chainFilter={chainFilter} />}
            {activeTab === "transactions" && <TransactionsView wallets={wallets} chainFilter={chainFilter} />}
          </CardContent>
        </Card>

        {wallets.length === 0 && connectedAddresses.length === 0 && (
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="py-16 text-center">
              <div className="text-5xl mb-4">🔗</div>
              <h2 className="text-xl font-bold text-white mb-2" data-testid="text-empty-state">Connect Your Wallets</h2>
              <p className="text-gray-400 text-sm max-w-md mx-auto mb-6">
                Enter any wallet address above to view unified balances, NFTs, and transaction history across multiple blockchains.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                {CHAINS.map(chain => (
                  <div
                    key={chain.id}
                    className="flex items-center gap-2 bg-[#0a1018] rounded-lg px-4 py-2 border border-[#1E3A5F]/30"
                    data-testid={`supported-chain-${chain.id}`}
                  >
                    <span className="text-lg">{chain.icon}</span>
                    <span className="text-sm text-gray-300">{chain.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </TradingPlatformLayout>
  );
}
