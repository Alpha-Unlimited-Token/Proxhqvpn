/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Crypto Learning Center™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Crypto Learning Center™
 * - Interactive Education Platform™
 * - Visual Pattern Recognition™
 * - Progress Tracking Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_cc65c71686f1c7e73633d319
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, GraduationCap, BarChart3, TrendingUp, TrendingDown,
  Shield, Target, Layers, ChevronDown, ChevronRight, CheckCircle,
  AlertTriangle, Lightbulb, ArrowRight, Zap, DollarSign, Activity,
  Clock, Eye, Lock, Brain, Flame, LineChart
} from 'lucide-react';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { Link } from 'wouter';

function CandlestickAnatomy() {
  return (
    <svg viewBox="0 0 400 280" className="w-full max-w-md mx-auto">
      <rect x="170" y="20" width="60" height="200" rx="3" fill="#22c55e" opacity="0.15" stroke="#22c55e" strokeWidth="1" strokeDasharray="4" />
      <line x1="200" y1="30" x2="200" y2="60" stroke="#22c55e" strokeWidth="2" />
      <rect x="185" y="60" width="30" height="100" rx="2" fill="#22c55e" />
      <line x1="200" y1="160" x2="200" y2="200" stroke="#22c55e" strokeWidth="2" />
      <line x1="210" y1="30" x2="260" y2="30" stroke="#8899A6" strokeWidth="1" strokeDasharray="3" />
      <text x="265" y="34" fill="#8899A6" fontSize="11" fontFamily="sans-serif">High (Wick/Shadow)</text>
      <line x1="220" y1="60" x2="260" y2="48" stroke="#8899A6" strokeWidth="1" strokeDasharray="3" />
      <text x="265" y="52" fill="#22c55e" fontSize="11" fontFamily="sans-serif">Close (Top of Body)</text>
      <line x1="220" y1="110" x2="260" y2="110" stroke="#8899A6" strokeWidth="1" strokeDasharray="3" />
      <text x="265" y="114" fill="#94A3B8" fontSize="11" fontFamily="sans-serif">Body</text>
      <line x1="220" y1="160" x2="260" y2="168" stroke="#8899A6" strokeWidth="1" strokeDasharray="3" />
      <text x="265" y="172" fill="#ef4444" fontSize="11" fontFamily="sans-serif">Open (Bottom of Body)</text>
      <line x1="210" y1="200" x2="260" y2="200" stroke="#8899A6" strokeWidth="1" strokeDasharray="3" />
      <text x="265" y="204" fill="#8899A6" fontSize="11" fontFamily="sans-serif">Low (Wick/Shadow)</text>
      <text x="200" y="240" textAnchor="middle" fill="#22c55e" fontSize="13" fontWeight="bold" fontFamily="sans-serif">Bullish Candle</text>
      <text x="200" y="256" textAnchor="middle" fill="#8899A6" fontSize="10" fontFamily="sans-serif">Close &gt; Open = Price went UP</text>

      <line x1="60" y1="40" x2="60" y2="70" stroke="#ef4444" strokeWidth="2" />
      <rect x="45" y="70" width="30" height="100" rx="2" fill="#ef4444" />
      <line x1="60" y1="170" x2="60" y2="210" stroke="#ef4444" strokeWidth="2" />
      <text x="60" y="240" textAnchor="middle" fill="#ef4444" fontSize="13" fontWeight="bold" fontFamily="sans-serif">Bearish</text>
      <text x="60" y="256" textAnchor="middle" fill="#8899A6" fontSize="10" fontFamily="sans-serif">Close &lt; Open</text>
    </svg>
  );
}

function CandlestickPatterns() {
  return (
    <svg viewBox="0 0 640 320" className="w-full max-w-2xl mx-auto">
      <rect x="10" y="10" width="145" height="290" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="82" y="35" textAnchor="middle" fill="#22c55e" fontSize="12" fontWeight="bold">Hammer</text>
      <line x1="82" y1="55" x2="82" y2="70" stroke="#22c55e" strokeWidth="2" />
      <rect x="72" y="70" width="20" height="20" rx="2" fill="#22c55e" />
      <line x1="82" y1="90" x2="82" y2="150" stroke="#22c55e" strokeWidth="2" />
      <text x="82" y="175" textAnchor="middle" fill="#8899A6" fontSize="9">Small body on top</text>
      <text x="82" y="188" textAnchor="middle" fill="#8899A6" fontSize="9">Long lower wick</text>
      <text x="82" y="205" textAnchor="middle" fill="#22c55e" fontSize="9" fontWeight="bold">↑ Bullish reversal</text>

      <rect x="165" y="10" width="145" height="290" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="238" y="35" textAnchor="middle" fill="#eab308" fontSize="12" fontWeight="bold">Doji</text>
      <line x1="238" y1="60" x2="238" y2="95" stroke="#eab308" strokeWidth="2" />
      <rect x="228" y="95" width="20" height="3" rx="1" fill="#eab308" />
      <line x1="238" y1="98" x2="238" y2="135" stroke="#eab308" strokeWidth="2" />
      <text x="238" y="165" textAnchor="middle" fill="#8899A6" fontSize="9">Open ≈ Close</text>
      <text x="238" y="178" textAnchor="middle" fill="#8899A6" fontSize="9">Nearly no body</text>
      <text x="238" y="195" textAnchor="middle" fill="#eab308" fontSize="9" fontWeight="bold">⚖ Indecision</text>

      <rect x="320" y="10" width="145" height="290" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="393" y="35" textAnchor="middle" fill="#22c55e" fontSize="12" fontWeight="bold">Bullish Engulfing</text>
      <line x1="375" y1="60" x2="375" y2="75" stroke="#ef4444" strokeWidth="2" />
      <rect x="367" y="75" width="16" height="30" rx="2" fill="#ef4444" />
      <line x1="375" y1="105" x2="375" y2="120" stroke="#ef4444" strokeWidth="2" />
      <line x1="408" y1="55" x2="408" y2="65" stroke="#22c55e" strokeWidth="2" />
      <rect x="396" y="65" width="24" height="50" rx="2" fill="#22c55e" />
      <line x1="408" y1="115" x2="408" y2="130" stroke="#22c55e" strokeWidth="2" />
      <text x="393" y="165" textAnchor="middle" fill="#8899A6" fontSize="9">Green candle fully</text>
      <text x="393" y="178" textAnchor="middle" fill="#8899A6" fontSize="9">engulfs the red one</text>
      <text x="393" y="195" textAnchor="middle" fill="#22c55e" fontSize="9" fontWeight="bold">↑ Strong reversal</text>

      <rect x="475" y="10" width="155" height="290" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="552" y="35" textAnchor="middle" fill="#ef4444" fontSize="12" fontWeight="bold">Shooting Star</text>
      <line x1="552" y1="60" x2="552" y2="120" stroke="#ef4444" strokeWidth="2" />
      <rect x="542" y="120" width="20" height="20" rx="2" fill="#ef4444" />
      <line x1="552" y1="140" x2="552" y2="150" stroke="#ef4444" strokeWidth="2" />
      <text x="552" y="175" textAnchor="middle" fill="#8899A6" fontSize="9">Long upper wick</text>
      <text x="552" y="188" textAnchor="middle" fill="#8899A6" fontSize="9">Small body on bottom</text>
      <text x="552" y="205" textAnchor="middle" fill="#ef4444" fontSize="9" fontWeight="bold">↓ Bearish reversal</text>

      <text x="82" y="230" textAnchor="middle" fill="#22c55e" fontSize="9" fontWeight="bold">Morning Star ★</text>
      <line x1="50" y1="245" x2="50" y2="252" stroke="#ef4444" strokeWidth="1.5" />
      <rect x="44" y="252" width="12" height="20" rx="1" fill="#ef4444" />
      <line x1="50" y1="272" x2="50" y2="278" stroke="#ef4444" strokeWidth="1.5" />
      <line x1="82" y1="260" x2="82" y2="265" stroke="#eab308" strokeWidth="1.5" />
      <rect x="77" y="265" width="10" height="5" rx="1" fill="#eab308" />
      <line x1="82" y1="270" x2="82" y2="278" stroke="#eab308" strokeWidth="1.5" />
      <line x1="112" y1="240" x2="112" y2="248" stroke="#22c55e" strokeWidth="1.5" />
      <rect x="106" y="248" width="12" height="22" rx="1" fill="#22c55e" />
      <line x1="112" y1="270" x2="112" y2="278" stroke="#22c55e" strokeWidth="1.5" />
      <text x="82" y="295" textAnchor="middle" fill="#22c55e" fontSize="8">3-candle bullish reversal</text>

      <text x="238" y="230" textAnchor="middle" fill="#ef4444" fontSize="9" fontWeight="bold">Evening Star ★</text>
      <line x1="206" y1="252" x2="206" y2="248" stroke="#22c55e" strokeWidth="1.5" />
      <rect x="200" y="248" width="12" height="22" rx="1" fill="#22c55e" />
      <line x1="206" y1="270" x2="206" y2="278" stroke="#22c55e" strokeWidth="1.5" />
      <line x1="238" y1="245" x2="238" y2="250" stroke="#eab308" strokeWidth="1.5" />
      <rect x="233" y="250" width="10" height="5" rx="1" fill="#eab308" />
      <line x1="238" y1="255" x2="238" y2="262" stroke="#eab308" strokeWidth="1.5" />
      <line x1="268" y1="252" x2="268" y2="258" stroke="#ef4444" strokeWidth="1.5" />
      <rect x="262" y="258" width="12" height="20" rx="1" fill="#ef4444" />
      <line x1="268" y1="278" x2="268" y2="285" stroke="#ef4444" strokeWidth="1.5" />
      <text x="238" y="300" textAnchor="middle" fill="#ef4444" fontSize="8">3-candle bearish reversal</text>
    </svg>
  );
}

function TrendVisual() {
  return (
    <svg viewBox="0 0 600 220" className="w-full max-w-2xl mx-auto">
      <rect x="5" y="5" width="190" height="210" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="100" y="28" textAnchor="middle" fill="#22c55e" fontSize="12" fontWeight="bold">Uptrend</text>
      <polyline points="25,170 55,145 70,155 105,120 120,130 155,90 170,100" fill="none" stroke="#22c55e" strokeWidth="2" />
      <line x1="25" y1="170" x2="170" y2="100" stroke="#22c55e" strokeWidth="1" strokeDasharray="4" opacity="0.5" />
      <circle cx="55" cy="145" r="3" fill="#22c55e" />
      <text x="55" y="140" textAnchor="middle" fill="#8899A6" fontSize="7">HL</text>
      <circle cx="105" cy="120" r="3" fill="#22c55e" />
      <text x="105" y="115" textAnchor="middle" fill="#8899A6" fontSize="7">HH</text>
      <circle cx="155" cy="90" r="3" fill="#22c55e" />
      <text x="155" y="85" textAnchor="middle" fill="#8899A6" fontSize="7">HH</text>
      <text x="100" y="195" textAnchor="middle" fill="#8899A6" fontSize="9">Higher Highs (HH)</text>
      <text x="100" y="207" textAnchor="middle" fill="#8899A6" fontSize="9">Higher Lows (HL)</text>

      <rect x="205" y="5" width="190" height="210" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="300" y="28" textAnchor="middle" fill="#ef4444" fontSize="12" fontWeight="bold">Downtrend</text>
      <polyline points="225,60 255,85 270,75 305,110 320,100 355,140 370,130" fill="none" stroke="#ef4444" strokeWidth="2" />
      <line x1="225" y1="60" x2="370" y2="130" stroke="#ef4444" strokeWidth="1" strokeDasharray="4" opacity="0.5" />
      <circle cx="255" cy="85" r="3" fill="#ef4444" />
      <text x="255" y="95" textAnchor="middle" fill="#8899A6" fontSize="7">LH</text>
      <circle cx="305" cy="110" r="3" fill="#ef4444" />
      <text x="305" y="120" textAnchor="middle" fill="#8899A6" fontSize="7">LL</text>
      <circle cx="355" cy="140" r="3" fill="#ef4444" />
      <text x="355" y="150" textAnchor="middle" fill="#8899A6" fontSize="7">LL</text>
      <text x="300" y="195" textAnchor="middle" fill="#8899A6" fontSize="9">Lower Highs (LH)</text>
      <text x="300" y="207" textAnchor="middle" fill="#8899A6" fontSize="9">Lower Lows (LL)</text>

      <rect x="405" y="5" width="190" height="210" rx="8" fill="#0D1117" stroke="#1A2942" />
      <text x="500" y="28" textAnchor="middle" fill="#eab308" fontSize="12" fontWeight="bold">Sideways / Range</text>
      <line x1="425" y1="80" x2="575" y2="80" stroke="#eab308" strokeWidth="1" strokeDasharray="4" opacity="0.4" />
      <line x1="425" y1="140" x2="575" y2="140" stroke="#eab308" strokeWidth="1" strokeDasharray="4" opacity="0.4" />
      <text x="580" y="83" fill="#eab308" fontSize="7">Resistance</text>
      <text x="580" y="143" fill="#eab308" fontSize="7">Support</text>
      <polyline points="430,120 450,90 470,130 490,85 510,125 530,90 550,130 570,95" fill="none" stroke="#eab308" strokeWidth="2" />
      <text x="500" y="195" textAnchor="middle" fill="#8899A6" fontSize="9">Price bounces between</text>
      <text x="500" y="207" textAnchor="middle" fill="#8899A6" fontSize="9">support &amp; resistance</text>
    </svg>
  );
}

function SupportResistanceVisual() {
  return (
    <svg viewBox="0 0 500 250" className="w-full max-w-lg mx-auto">
      <line x1="40" y1="60" x2="460" y2="60" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="6" />
      <text x="465" y="64" fill="#ef4444" fontSize="10" fontWeight="bold">Resistance $45,000</text>
      <line x1="40" y1="190" x2="460" y2="190" stroke="#22c55e" strokeWidth="1.5" strokeDasharray="6" />
      <text x="465" y="194" fill="#22c55e" fontSize="10" fontWeight="bold">Support $38,000</text>
      <polyline points="50,150 80,100 100,140 130,70 145,130 170,80 200,150 230,65 250,120 280,180 300,100 330,70 350,120 380,185 400,110 430,75 450,130" fill="none" stroke="#00D4FF" strokeWidth="1.5" />
      <circle cx="130" cy="70" r="4" fill="none" stroke="#ef4444" strokeWidth="1.5" />
      <circle cx="230" cy="65" r="4" fill="none" stroke="#ef4444" strokeWidth="1.5" />
      <circle cx="330" cy="70" r="4" fill="none" stroke="#ef4444" strokeWidth="1.5" />
      <circle cx="430" cy="75" r="4" fill="none" stroke="#ef4444" strokeWidth="1.5" />
      <circle cx="280" cy="180" r="4" fill="none" stroke="#22c55e" strokeWidth="1.5" />
      <circle cx="380" cy="185" r="4" fill="none" stroke="#22c55e" strokeWidth="1.5" />
      <text x="130" y="55" textAnchor="middle" fill="#ef4444" fontSize="8">Rejected ↓</text>
      <text x="330" y="55" textAnchor="middle" fill="#ef4444" fontSize="8">Rejected ↓</text>
      <text x="280" y="210" textAnchor="middle" fill="#22c55e" fontSize="8">Bounced ↑</text>
      <text x="380" y="210" textAnchor="middle" fill="#22c55e" fontSize="8">Bounced ↑</text>
      <text x="250" y="240" textAnchor="middle" fill="#8899A6" fontSize="9">Price repeatedly tests and bounces off key levels</text>
    </svg>
  );
}

function MovingAveragesVisual() {
  return (
    <svg viewBox="0 0 500 200" className="w-full max-w-lg mx-auto">
      <polyline points="30,120 60,100 90,130 120,95 150,110 180,85 210,105 240,80 270,100 300,75 330,90 360,70 390,85 420,65 450,80 470,60" fill="none" stroke="#8899A6" strokeWidth="1.2" opacity="0.5" />
      <polyline points="30,115 60,110 90,112 120,105 150,106 180,98 210,100 240,92 270,93 300,86 330,87 360,80 390,80 420,74 450,75 470,68" fill="none" stroke="#eab308" strokeWidth="2" />
      <polyline points="30,118 60,116 90,117 120,114 150,113 180,110 210,108 240,104 270,102 300,97 330,95 360,90 390,88 420,84 450,82 470,78" fill="none" stroke="#ef4444" strokeWidth="2" />
      <rect x="300" y="10" width="160" height="50" rx="6" fill="#0D1117" stroke="#1A2942" />
      <line x1="310" y1="25" x2="330" y2="25" stroke="#8899A6" strokeWidth="1.2" />
      <text x="335" y="28" fill="#8899A6" fontSize="9">Price</text>
      <line x1="310" y1="38" x2="330" y2="38" stroke="#eab308" strokeWidth="2" />
      <text x="335" y="41" fill="#eab308" fontSize="9">SMA 20 (Short)</text>
      <line x1="310" y1="51" x2="330" y2="51" stroke="#ef4444" strokeWidth="2" />
      <text x="335" y="54" fill="#ef4444" fontSize="9">SMA 50 (Long)</text>
      <circle cx="210" cy="100" r="8" fill="none" stroke="#22c55e" strokeWidth="1.5" strokeDasharray="3" />
      <text x="210" y="90" textAnchor="middle" fill="#22c55e" fontSize="8" fontWeight="bold">Golden Cross ↑</text>
      <text x="250" y="190" textAnchor="middle" fill="#8899A6" fontSize="9">When short MA crosses above long MA = Bullish signal</text>
    </svg>
  );
}

function VolumeVisual() {
  return (
    <svg viewBox="0 0 500 200" className="w-full max-w-lg mx-auto">
      <polyline points="30,80 70,60 110,90 150,40 190,70 230,50 270,65 310,30 350,55 390,45 430,35 470,50" fill="none" stroke="#00D4FF" strokeWidth="1.5" />
      {[
        { x: 30, h: 40, c: '#22c55e' }, { x: 70, h: 55, c: '#22c55e' }, { x: 110, h: 30, c: '#ef4444' },
        { x: 150, h: 70, c: '#22c55e' }, { x: 190, h: 35, c: '#ef4444' }, { x: 230, h: 50, c: '#22c55e' },
        { x: 270, h: 25, c: '#ef4444' }, { x: 310, h: 80, c: '#22c55e' }, { x: 350, h: 45, c: '#22c55e' },
        { x: 390, h: 60, c: '#22c55e' }, { x: 430, h: 55, c: '#22c55e' }, { x: 470, h: 35, c: '#ef4444' },
      ].map((bar, i) => (
        <rect key={i} x={bar.x - 12} y={170 - bar.h} width="24" height={bar.h} rx="2" fill={bar.c} opacity="0.6" />
      ))}
      <line x1="20" y1="170" x2="480" y2="170" stroke="#1A2942" strokeWidth="1" />
      <text x="310" y="110" fill="#22c55e" fontSize="8" fontWeight="bold">High volume</text>
      <text x="310" y="120" fill="#22c55e" fontSize="8">confirms breakout</text>
      <text x="250" y="195" textAnchor="middle" fill="#8899A6" fontSize="9">Volume confirms price moves — high volume = strong conviction</text>
    </svg>
  );
}

function RSIVisual() {
  return (
    <svg viewBox="0 0 500 180" className="w-full max-w-lg mx-auto">
      <rect x="20" y="10" width="460" height="150" rx="8" fill="#0D1117" stroke="#1A2942" />
      <line x1="40" y1="38" x2="460" y2="38" stroke="#ef4444" strokeWidth="1" strokeDasharray="4" opacity="0.5" />
      <text x="462" y="42" fill="#ef4444" fontSize="8">70 (Overbought)</text>
      <line x1="40" y1="85" x2="460" y2="85" stroke="#8899A6" strokeWidth="0.5" strokeDasharray="2" opacity="0.3" />
      <text x="462" y="89" fill="#8899A6" fontSize="8">50</text>
      <line x1="40" y1="132" x2="460" y2="132" stroke="#22c55e" strokeWidth="1" strokeDasharray="4" opacity="0.5" />
      <text x="462" y="136" fill="#22c55e" fontSize="8">30 (Oversold)</text>
      <polyline points="50,90 80,75 110,60 140,35 170,30 200,45 230,70 260,95 290,120 320,140 340,135 370,110 400,80 430,55 450,65" fill="none" stroke="#a855f7" strokeWidth="2" />
      <rect x="130" y="18" width="60" height="16" rx="4" fill="#ef4444" opacity="0.15" />
      <text x="160" y="30" textAnchor="middle" fill="#ef4444" fontSize="8" fontWeight="bold">SELL zone</text>
      <rect x="290" y="136" width="55" height="16" rx="4" fill="#22c55e" opacity="0.15" />
      <text x="318" y="148" textAnchor="middle" fill="#22c55e" fontSize="8" fontWeight="bold">BUY zone</text>
      <text x="250" y="175" textAnchor="middle" fill="#8899A6" fontSize="9">RSI above 70 = Overbought (consider selling) | Below 30 = Oversold (consider buying)</text>
    </svg>
  );
}

interface Section {
  id: string;
  title: string;
  icon: typeof BookOpen;
  color: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  content: React.ReactNode;
}

const SECTIONS: Section[] = [
  {
    id: 'basics',
    title: 'Cryptocurrency Basics',
    icon: BookOpen,
    color: '#00D4FF',
    difficulty: 'Beginner',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">What is Cryptocurrency?</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-3">
            Cryptocurrency is digital money that uses cryptography for security. Unlike traditional currencies controlled by banks and governments, crypto operates on decentralized networks called blockchains. Every transaction is recorded on a public ledger that anyone can verify but nobody can alter.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#00D4FF] mb-1">Bitcoin (BTC)</h5>
              <p className="text-xs text-[#8899A6]">The first and largest cryptocurrency. Created in 2009 by Satoshi Nakamoto. Limited supply of 21 million coins. Often called "digital gold" — used as a store of value.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#a855f7] mb-1">Ethereum (ETH)</h5>
              <p className="text-xs text-[#8899A6]">The second largest crypto. Unlike Bitcoin, Ethereum supports smart contracts — self-executing programs that run on the blockchain. Powers DeFi, NFTs, and thousands of apps.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#22c55e] mb-1">Altcoins</h5>
              <p className="text-xs text-[#8899A6]">Any cryptocurrency other than Bitcoin. Includes Solana (fast transactions), XRP (cross-border payments), Cardano (research-driven), and thousands more — each with different use cases.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#eab308] mb-1">Stablecoins</h5>
              <p className="text-xs text-[#8899A6]">Cryptocurrencies pegged to stable assets like the US Dollar. USDT (Tether) and USDC are the most popular. Used for trading pairs and as a safe haven during market volatility.</p>
            </div>
          </div>
        </div>
        <div className="p-4 bg-[#00D4FF]/5 border border-[#00D4FF]/20 rounded-xl">
          <div className="flex items-start gap-2">
            <Lightbulb size={16} className="text-[#00D4FF] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-[#00D4FF] mb-1">Key Concept: Market Cap</p>
              <p className="text-xs text-[#94A3B8]">Market Cap = Current Price × Total Circulating Supply. A coin priced at $1 with 1 billion coins has the same market cap ($1B) as a coin priced at $100 with 10 million coins. Always compare market caps, not just prices.</p>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">How Blockchain Works</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-3">
            A blockchain is a chain of blocks, where each block contains a batch of transactions. Once added, blocks cannot be changed — making the ledger tamper-proof. This is secured through consensus mechanisms:
          </p>
          <div className="space-y-2">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942] flex items-start gap-3">
              <Shield size={16} className="text-[#eab308] flex-shrink-0 mt-0.5" />
              <div>
                <h5 className="text-sm font-semibold text-white">Proof of Work (PoW)</h5>
                <p className="text-xs text-[#8899A6]">Miners compete to solve complex mathematical puzzles. The winner adds the next block and earns rewards. Bitcoin uses PoW. Requires significant computing power and energy.</p>
              </div>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942] flex items-start gap-3">
              <Lock size={16} className="text-[#22c55e] flex-shrink-0 mt-0.5" />
              <div>
                <h5 className="text-sm font-semibold text-white">Proof of Stake (PoS)</h5>
                <p className="text-xs text-[#8899A6]">Validators stake (lock up) their coins as collateral. They're chosen to validate blocks based on their stake. Ethereum switched to PoS in 2022. Uses 99.9% less energy than PoW.</p>
              </div>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Wallets and Exchanges</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-3">
            To own and trade crypto, you need a wallet (to store) and usually an exchange (to buy/sell).
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-white mb-1">Hot Wallets</h5>
              <p className="text-xs text-[#8899A6]">Connected to the internet. Convenient for trading. Examples: MetaMask, Trust Wallet. Higher risk of hacking but faster access.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-white mb-1">Cold Wallets</h5>
              <p className="text-xs text-[#8899A6]">Offline storage. Hardware devices like Ledger or Trezor. Most secure for long-term holding. Not connected to the internet.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'reading-charts',
    title: 'Reading Charts & Candlesticks',
    icon: BarChart3,
    color: '#22c55e',
    difficulty: 'Beginner',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Anatomy of a Candlestick</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Candlestick charts are the most popular way to view price action. Each candle represents a time period (1 minute, 1 hour, 1 day, etc.) and shows four prices: Open, High, Low, and Close.
          </p>
          <CandlestickAnatomy />
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-[#22c55e]/5 border border-[#22c55e]/20 rounded-lg">
              <h5 className="text-sm font-semibold text-[#22c55e] mb-1">Green / Bullish Candle</h5>
              <p className="text-xs text-[#8899A6]">The close price is HIGHER than the open. Price went up during this period. The body shows the range between open and close.</p>
            </div>
            <div className="p-3 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-lg">
              <h5 className="text-sm font-semibold text-[#ef4444] mb-1">Red / Bearish Candle</h5>
              <p className="text-xs text-[#8899A6]">The close price is LOWER than the open. Price went down. The wicks (thin lines) show the highest and lowest prices reached.</p>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Timeframes</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-3">
            Each candle represents a specific time period. Shorter timeframes show more detail but more noise; longer timeframes show clearer trends.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { tf: '1m / 5m', use: 'Scalping', desc: 'Very short trades, seconds to minutes' },
              { tf: '15m / 1H', use: 'Day Trading', desc: 'Intraday trades, hours' },
              { tf: '4H / 1D', use: 'Swing Trading', desc: 'Multi-day positions' },
              { tf: '1W / 1M', use: 'Investing', desc: 'Long-term trends, weeks-months' },
            ].map(item => (
              <div key={item.tf} className="p-2.5 bg-[#161b22] rounded-lg border border-[#1A2942] text-center">
                <p className="text-sm font-bold text-[#00D4FF] font-mono">{item.tf}</p>
                <p className="text-xs text-white font-semibold mt-1">{item.use}</p>
                <p className="text-[10px] text-[#8899A6] mt-0.5">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'candlestick-patterns',
    title: 'Candlestick Patterns',
    icon: Eye,
    color: '#a855f7',
    difficulty: 'Intermediate',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Key Candlestick Patterns</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Candlestick patterns help predict where the price might go next. Reversal patterns signal a change in direction; continuation patterns suggest the trend will keep going. Here are the most important ones:
          </p>
          <CandlestickPatterns />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 bg-[#22c55e]/5 border border-[#22c55e]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#22c55e] mb-2">Bullish Patterns (Price May Go Up)</h5>
            <ul className="space-y-1.5 text-xs text-[#94A3B8]">
              <li className="flex items-start gap-1.5"><CheckCircle size={12} className="text-[#22c55e] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Hammer:</strong> Small body, long lower wick. Shows buyers stepped in after a dip.</span></li>
              <li className="flex items-start gap-1.5"><CheckCircle size={12} className="text-[#22c55e] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Bullish Engulfing:</strong> A big green candle completely covers the previous red candle.</span></li>
              <li className="flex items-start gap-1.5"><CheckCircle size={12} className="text-[#22c55e] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Morning Star:</strong> Three candles — red, tiny, then green. Signals bottom reversal.</span></li>
              <li className="flex items-start gap-1.5"><CheckCircle size={12} className="text-[#22c55e] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Three White Soldiers:</strong> Three consecutive green candles with higher closes.</span></li>
            </ul>
          </div>
          <div className="p-3 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#ef4444] mb-2">Bearish Patterns (Price May Go Down)</h5>
            <ul className="space-y-1.5 text-xs text-[#94A3B8]">
              <li className="flex items-start gap-1.5"><AlertTriangle size={12} className="text-[#ef4444] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Shooting Star:</strong> Small body, long upper wick. Sellers pushed price back down.</span></li>
              <li className="flex items-start gap-1.5"><AlertTriangle size={12} className="text-[#ef4444] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Bearish Engulfing:</strong> A big red candle completely covers the previous green candle.</span></li>
              <li className="flex items-start gap-1.5"><AlertTriangle size={12} className="text-[#ef4444] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Evening Star:</strong> Three candles — green, tiny, then red. Signals top reversal.</span></li>
              <li className="flex items-start gap-1.5"><AlertTriangle size={12} className="text-[#ef4444] flex-shrink-0 mt-0.5" /><span><strong className="text-white">Three Black Crows:</strong> Three consecutive red candles with lower closes.</span></li>
            </ul>
          </div>
        </div>
        <div className="p-4 bg-[#eab308]/5 border border-[#eab308]/20 rounded-xl">
          <div className="flex items-start gap-2">
            <AlertTriangle size={16} className="text-[#eab308] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-[#eab308] mb-1">Important Note</p>
              <p className="text-xs text-[#94A3B8]">No pattern works 100% of the time. Always confirm patterns with volume and other indicators. A hammer with high volume is more reliable than one with low volume. Use multiple signals together.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'trends',
    title: 'Trend Analysis',
    icon: TrendingUp,
    color: '#22c55e',
    difficulty: 'Intermediate',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Identifying Trends</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            The trend is your friend — one of the most important principles in trading. Markets move in three directions: up (bullish), down (bearish), or sideways (ranging). Identifying the current trend is the first step before making any trade.
          </p>
          <TrendVisual />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 bg-[#22c55e]/5 border border-[#22c55e]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#22c55e] mb-2 flex items-center gap-1"><TrendingUp size={14} /> Uptrend</h5>
            <p className="text-xs text-[#94A3B8]">Price makes <strong className="text-white">higher highs</strong> and <strong className="text-white">higher lows</strong>. Each peak is higher than the last, and each dip doesn't go as low. This is the best time to buy or hold long positions.</p>
          </div>
          <div className="p-3 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#ef4444] mb-2 flex items-center gap-1"><TrendingDown size={14} /> Downtrend</h5>
            <p className="text-xs text-[#94A3B8]">Price makes <strong className="text-white">lower highs</strong> and <strong className="text-white">lower lows</strong>. Each bounce is weaker than the last. Best to stay in stablecoins or short-sell (advanced).</p>
          </div>
          <div className="p-3 bg-[#eab308]/5 border border-[#eab308]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#eab308] mb-2 flex items-center gap-1"><Activity size={14} /> Sideways</h5>
            <p className="text-xs text-[#94A3B8]">Price bounces between support and resistance without a clear direction. Can trade the range by buying at support and selling at resistance.</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'support-resistance',
    title: 'Support & Resistance',
    icon: Layers,
    color: '#eab308',
    difficulty: 'Intermediate',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Understanding Support & Resistance</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Support and resistance are price levels where buying or selling pressure consistently prevents the price from moving further. These are arguably the most important concept in technical analysis.
          </p>
          <SupportResistanceVisual />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 bg-[#22c55e]/5 border border-[#22c55e]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#22c55e] mb-2">Support (Floor)</h5>
            <p className="text-xs text-[#94A3B8]">A price level where demand is strong enough to prevent further decline. Think of it as a floor — price bounces up from here. The more times price bounces off a support level, the stronger it is.</p>
          </div>
          <div className="p-3 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-lg">
            <h5 className="text-sm font-semibold text-[#ef4444] mb-2">Resistance (Ceiling)</h5>
            <p className="text-xs text-[#94A3B8]">A price level where selling pressure prevents further rise. Think of it as a ceiling. When price breaks through resistance, it often becomes the new support — this is called a "breakout."</p>
          </div>
        </div>
        <div className="p-4 bg-[#00D4FF]/5 border border-[#00D4FF]/20 rounded-xl">
          <div className="flex items-start gap-2">
            <Lightbulb size={16} className="text-[#00D4FF] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-[#00D4FF] mb-1">Trading Tip</p>
              <p className="text-xs text-[#94A3B8]">When support breaks, it often becomes resistance (and vice versa). Look for price to retest the broken level before continuing. This "retest" often provides a good entry point for trades.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'indicators',
    title: 'Technical Indicators',
    icon: LineChart,
    color: '#00D4FF',
    difficulty: 'Intermediate',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Moving Averages (MA)</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Moving averages smooth out price data to show the overall trend direction. They're the most widely used indicators in trading.
          </p>
          <MovingAveragesVisual />
          <div className="mt-4 space-y-2">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#eab308] mb-1">Simple Moving Average (SMA)</h5>
              <p className="text-xs text-[#8899A6]">Average price over a set number of periods. SMA 20 = average of last 20 candles. Popular SMAs: 20 (short-term), 50 (medium), 200 (long-term). When price is above the SMA, the trend is generally bullish.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#00D4FF] mb-1">Golden Cross & Death Cross</h5>
              <p className="text-xs text-[#8899A6]"><strong className="text-[#22c55e]">Golden Cross:</strong> Short MA crosses ABOVE long MA = bullish signal. <strong className="text-[#ef4444]">Death Cross:</strong> Short MA crosses BELOW long MA = bearish signal. These are among the most watched signals in all of trading.</p>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">RSI — Relative Strength Index</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            RSI measures the speed and magnitude of price changes on a scale of 0-100. It tells you if an asset is overbought (too expensive, might drop) or oversold (too cheap, might bounce).
          </p>
          <RSIVisual />
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Volume</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Volume shows how many units were traded during a period. It's the most important confirmation tool — a price move with high volume is much more significant than one with low volume.
          </p>
          <VolumeVisual />
          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="p-2.5 bg-[#22c55e]/5 border border-[#22c55e]/20 rounded-lg">
              <p className="text-xs text-[#94A3B8]"><strong className="text-[#22c55e]">High volume + price up</strong> = Strong buying pressure, trend likely to continue</p>
            </div>
            <div className="p-2.5 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-lg">
              <p className="text-xs text-[#94A3B8]"><strong className="text-[#ef4444]">Price up + low volume</strong> = Weak move, potential reversal ahead</p>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Other Important Indicators</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#a855f7] mb-1">MACD</h5>
              <p className="text-xs text-[#8899A6]">Moving Average Convergence Divergence. Shows the relationship between two moving averages. When the MACD line crosses above the signal line, it's bullish. Cross below = bearish. The histogram shows the distance between the two lines.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#00D4FF] mb-1">Bollinger Bands</h5>
              <p className="text-xs text-[#8899A6]">Three lines: a middle SMA with upper and lower bands at 2 standard deviations. When price touches the upper band, it may be overbought. Lower band = oversold. Bands squeezing together signals a big move is coming.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#eab308] mb-1">Fibonacci Retracement</h5>
              <p className="text-xs text-[#8899A6]">Key levels at 23.6%, 38.2%, 50%, 61.8%, and 78.6%. After a big move, price often retraces to these levels before continuing. The 61.8% level (the "golden ratio") is the most watched.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-[#22c55e] mb-1">Stochastic Oscillator</h5>
              <p className="text-xs text-[#8899A6]">Compares the closing price to the price range over a period. Like RSI, it measures overbought (above 80) and oversold (below 20). Best used with other indicators for confirmation.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'strategies',
    title: 'Trading Strategies',
    icon: Target,
    color: '#ef4444',
    difficulty: 'Intermediate',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Popular Trading Strategies</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            A strategy gives you a systematic approach to entering and exiting trades. No strategy wins every time — the key is having a plan and sticking to it consistently.
          </p>
        </div>
        <div className="space-y-3">
          {[
            {
              name: 'Day Trading',
              time: '1-15 min candles',
              hold: 'Minutes to hours',
              desc: 'Open and close positions within the same day. Never hold overnight. Requires constant monitoring, quick decisions, and strict discipline. Works best in volatile markets.',
              pros: ['No overnight risk', 'Many opportunities daily', 'Quick profits'],
              cons: ['Very stressful', 'Requires full-time focus', 'High fees from many trades'],
              color: '#ef4444',
            },
            {
              name: 'Swing Trading',
              time: '4H-1D candles',
              hold: 'Days to weeks',
              desc: 'Capture "swings" in price — buying at the bottom of a dip and selling at the top of a rally. Less stressful than day trading and works well with support/resistance levels.',
              pros: ['Less screen time needed', 'Catch bigger moves', 'Lower fees'],
              cons: ['Overnight risk', 'Requires patience', 'May miss quick moves'],
              color: '#eab308',
            },
            {
              name: 'Trend Following',
              time: '1D-1W candles',
              hold: 'Weeks to months',
              desc: 'Identify the major trend and ride it. "The trend is your friend." Use moving averages to confirm direction. Only trade in the direction of the trend.',
              pros: ['Simple to understand', 'Catches big moves', 'Low stress'],
              cons: ['Late entries', 'Choppy markets are painful', 'Requires patience'],
              color: '#22c55e',
            },
            {
              name: 'Scalping',
              time: '1m-5m candles',
              hold: 'Seconds to minutes',
              desc: 'Make many tiny trades capturing small price movements. Requires very fast execution and tight spreads. Not recommended for beginners.',
              pros: ['Many small wins', 'Low exposure time', 'Works in any market'],
              cons: ['Very high stress', 'Needs lowest fees', 'Tiny mistakes add up fast'],
              color: '#a855f7',
            },
            {
              name: 'HODLing (Buy & Hold)',
              time: '1W-1M candles',
              hold: 'Months to years',
              desc: 'Buy quality assets and hold them long-term regardless of short-term price swings. The simplest strategy. Works best with large-cap coins like BTC and ETH.',
              pros: ['Zero stress', 'No technical skill needed', 'Historically profitable for BTC'],
              cons: ['Capital locked up', 'No active income', 'Must survive 80%+ drawdowns'],
              color: '#00D4FF',
            },
          ].map(s => (
            <div key={s.name} className="p-4 bg-[#0D1117] border border-[#1A2942] rounded-xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${s.color}15` }}>
                  <Target size={18} style={{ color: s.color }} />
                </div>
                <div>
                  <h5 className="text-sm font-bold text-white">{s.name}</h5>
                  <div className="flex gap-3 text-[10px] text-[#8899A6]">
                    <span>Timeframe: {s.time}</span>
                    <span>Hold: {s.hold}</span>
                  </div>
                </div>
              </div>
              <p className="text-xs text-[#94A3B8] mb-3">{s.desc}</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-[10px] text-[#22c55e] font-semibold mb-1">Advantages</p>
                  {s.pros.map(p => (
                    <p key={p} className="text-[10px] text-[#94A3B8] flex items-center gap-1"><CheckCircle size={8} className="text-[#22c55e]" />{p}</p>
                  ))}
                </div>
                <div>
                  <p className="text-[10px] text-[#ef4444] font-semibold mb-1">Challenges</p>
                  {s.cons.map(c => (
                    <p key={c} className="text-[10px] text-[#94A3B8] flex items-center gap-1"><AlertTriangle size={8} className="text-[#ef4444]" />{c}</p>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'risk-management',
    title: 'Risk Management',
    icon: Shield,
    color: '#ef4444',
    difficulty: 'Beginner',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">The #1 Rule: Protect Your Capital</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Risk management is more important than any strategy or indicator. Professional traders survive because they manage risk ruthlessly. A great win rate means nothing if one bad trade wipes out all your profits.
          </p>
        </div>
        <div className="space-y-3">
          <div className="p-4 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-xl">
            <h5 className="text-sm font-semibold text-[#ef4444] mb-2 flex items-center gap-2">
              <AlertTriangle size={16} /> The 1% Rule
            </h5>
            <p className="text-xs text-[#94A3B8] mb-2">Never risk more than 1-2% of your total account on a single trade. If your account is $10,000, your maximum loss per trade should be $100-200.</p>
            <div className="p-3 bg-[#0D1117] rounded-lg">
              <p className="text-xs text-[#8899A6] font-mono">
                Account: $10,000<br/>
                Max risk per trade (1%): $100<br/>
                Entry price: $50,000 (BTC)<br/>
                Stop loss at: $49,500 ($500 below entry)<br/>
                Position size: $100 ÷ $500 = 0.2 BTC ($10,000 worth)<br/>
                <span className="text-[#22c55e]">→ If stopped out, you lose $100 (1% of account)</span>
              </p>
            </div>
          </div>

          <div className="p-4 bg-[#161b22] border border-[#1A2942] rounded-xl">
            <h5 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
              <Target size={16} className="text-[#eab308]" /> Stop-Loss Orders
            </h5>
            <p className="text-xs text-[#94A3B8] mb-2">A stop-loss automatically sells your position if the price drops to a certain level. It limits your downside. ALWAYS set a stop-loss before entering a trade.</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="p-2 bg-[#0D1117] rounded-lg text-center">
                <p className="text-xs font-semibold text-white">Fixed Stop</p>
                <p className="text-[10px] text-[#8899A6]">Set at a fixed % below entry (e.g., 2-5%)</p>
              </div>
              <div className="p-2 bg-[#0D1117] rounded-lg text-center">
                <p className="text-xs font-semibold text-white">Technical Stop</p>
                <p className="text-[10px] text-[#8899A6]">Placed below support levels or key MAs</p>
              </div>
              <div className="p-2 bg-[#0D1117] rounded-lg text-center">
                <p className="text-xs font-semibold text-white">Trailing Stop</p>
                <p className="text-[10px] text-[#8899A6]">Follows price up, locks in profits</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-[#161b22] border border-[#1A2942] rounded-xl">
            <h5 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
              <BarChart3 size={16} className="text-[#00D4FF]" /> Risk-Reward Ratio
            </h5>
            <p className="text-xs text-[#94A3B8] mb-2">Always aim for at least a 1:2 risk-reward ratio. If you're risking $100, your target profit should be at least $200. This means you can be wrong 50% of the time and still be profitable.</p>
            <div className="p-3 bg-[#0D1117] rounded-lg">
              <p className="text-xs text-[#8899A6] font-mono">
                Risk: $100 (stop-loss distance)<br/>
                Reward: $200 (take-profit distance)<br/>
                Ratio: 1:2<br/>
                <span className="text-[#22c55e]">Win 5 trades = $1,000 | Lose 5 trades = $500</span><br/>
                <span className="text-[#22c55e]">→ Net profit: $500 even with 50% win rate!</span>
              </p>
            </div>
          </div>

          <div className="p-4 bg-[#eab308]/5 border border-[#eab308]/20 rounded-xl">
            <h5 className="text-sm font-semibold text-[#eab308] mb-2 flex items-center gap-2">
              <Brain size={16} /> Trading Psychology
            </h5>
            <p className="text-xs text-[#94A3B8] mb-2">Your emotions are your biggest enemy in trading. Follow these rules:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                'Never trade with money you can\'t afford to lose',
                'Don\'t revenge trade after a loss',
                'Take profits — don\'t let greed hold you too long',
                'Stick to your plan, don\'t change mid-trade',
                'Keep a trading journal — review every trade',
                'If you\'re emotional, step away from the screen',
              ].map(rule => (
                <p key={rule} className="text-[10px] text-[#94A3B8] flex items-start gap-1.5">
                  <CheckCircle size={10} className="text-[#eab308] flex-shrink-0 mt-0.5" />
                  {rule}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'order-types',
    title: 'Order Types Explained',
    icon: DollarSign,
    color: '#00D4FF',
    difficulty: 'Beginner',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Understanding Order Types</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            Different order types give you control over when and how your trades execute. Knowing which to use is essential for effective trading.
          </p>
        </div>
        <div className="space-y-3">
          {[
            {
              name: 'Market Order',
              desc: 'Executes immediately at the current market price. You get filled right away but the exact price may vary slightly (slippage). Best when you need to get in or out quickly.',
              example: '"Buy 0.1 BTC at market price" → Fills instantly at whatever the current ask price is',
              color: '#22c55e',
            },
            {
              name: 'Limit Order',
              desc: 'Sets a specific price you want to buy or sell at. The order only fills if the market reaches your price. You control the exact price but it may never fill if the market doesn\'t reach it.',
              example: '"Buy 0.1 BTC at $42,000" → Only fills if BTC drops to $42,000 or below',
              color: '#00D4FF',
            },
            {
              name: 'Stop-Loss Order',
              desc: 'Automatically sells when price drops to a specified level. Protects you from large losses. Essential for every trade. Becomes a market order once triggered.',
              example: '"Sell if BTC drops to $39,000" → Limits your loss if the trade goes against you',
              color: '#ef4444',
            },
            {
              name: 'Take-Profit Order',
              desc: 'Automatically sells when price reaches your profit target. Locks in gains without needing to watch the screen. Often used with stop-loss orders together.',
              example: '"Sell if BTC reaches $48,000" → Automatically takes profit at your target',
              color: '#eab308',
            },
            {
              name: 'Stop-Limit Order',
              desc: 'Combines stop and limit orders. When the stop price is hit, a limit order is placed instead of a market order. Gives more price control but may not fill in a fast-moving market.',
              example: '"If BTC drops to $40,000, place a sell limit at $39,800"',
              color: '#a855f7',
            },
            {
              name: 'Trailing Stop',
              desc: 'A dynamic stop-loss that follows the price as it moves in your favor. If you set a 5% trailing stop and BTC goes from $40K to $50K, your stop is at $47,500. Locks in profits while letting winners run.',
              example: '"Trail 5% behind the price" → Stop moves up as price moves up, never moves down',
              color: '#f97316',
            },
          ].map(order => (
            <div key={order.name} className="p-4 bg-[#0D1117] border border-[#1A2942] rounded-xl">
              <h5 className="text-sm font-bold text-white mb-1" style={{ color: order.color }}>{order.name}</h5>
              <p className="text-xs text-[#94A3B8] mb-2">{order.desc}</p>
              <div className="p-2 bg-[#161b22] rounded-lg">
                <p className="text-[10px] text-[#8899A6] font-mono">{order.example}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'defi',
    title: 'DeFi & Advanced Concepts',
    icon: Zap,
    color: '#a855f7',
    difficulty: 'Advanced',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Decentralized Finance (DeFi)</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            DeFi removes middlemen (banks, brokers) from financial services. Everything runs on smart contracts — automated programs on the blockchain that execute when conditions are met.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { name: 'DEXs (Decentralized Exchanges)', desc: 'Trade directly from your wallet without a central authority. Examples: Uniswap, SushiSwap. You keep custody of your funds at all times.', color: '#00D4FF' },
              { name: 'Liquidity Pools', desc: 'Provide your tokens to a pool and earn fees from trades. You become the market maker. Risk: impermanent loss if token prices diverge significantly.', color: '#22c55e' },
              { name: 'Yield Farming', desc: 'Move assets between protocols to maximize returns. Often involves providing liquidity, staking LP tokens, and claiming reward tokens. Can be complex.', color: '#eab308' },
              { name: 'Lending & Borrowing', desc: 'Lend crypto to earn interest (Aave, Compound). Borrow against your crypto as collateral without selling it. Liquidation risk if collateral value drops.', color: '#a855f7' },
              { name: 'Staking', desc: 'Lock up tokens to help secure a PoS network and earn rewards. Lower risk than yield farming. ETH staking currently yields ~3-5% APY.', color: '#22c55e' },
              { name: 'Flash Loans', desc: 'Borrow without collateral — but must repay within a single transaction. Used for arbitrage and liquidations. If the loan isn\'t repaid, the entire transaction reverts.', color: '#ef4444' },
            ].map(item => (
              <div key={item.name} className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
                <h5 className="text-sm font-semibold mb-1" style={{ color: item.color }}>{item.name}</h5>
                <p className="text-xs text-[#8899A6]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Leverage Trading</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-3">
            Leverage lets you control a larger position with less capital. 10x leverage means $1,000 controls $10,000 worth of crypto. Profits and losses are both amplified.
          </p>
          <div className="p-4 bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-xl">
            <div className="flex items-start gap-2">
              <AlertTriangle size={16} className="text-[#ef4444] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-[#ef4444] mb-1">Leverage Warning</p>
                <p className="text-xs text-[#94A3B8]">At 10x leverage, a 10% move against you = 100% loss (liquidation). At 100x, just 1% = liquidation. Over 90% of leveraged traders lose money. If you're a beginner, avoid leverage entirely. If you must use it, start with 2-3x maximum and always use stop-losses.</p>
              </div>
            </div>
          </div>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Token Types</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-white mb-1">Layer 1</h5>
              <p className="text-xs text-[#8899A6]">Base blockchains: Bitcoin, Ethereum, Solana, Avalanche. They process and secure transactions directly.</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-white mb-1">Layer 2</h5>
              <p className="text-xs text-[#8899A6]">Built on top of L1s for faster/cheaper transactions. Arbitrum, Optimism, Base (on Ethereum), Lightning (on Bitcoin).</p>
            </div>
            <div className="p-3 bg-[#161b22] rounded-lg border border-[#1A2942]">
              <h5 className="text-sm font-semibold text-white mb-1">Governance</h5>
              <p className="text-xs text-[#8899A6]">Tokens that let you vote on protocol changes. UNI (Uniswap), AAVE, COMP. Holding = having a say in the project's future.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'security',
    title: 'Crypto Security',
    icon: Lock,
    color: '#ef4444',
    difficulty: 'Beginner',
    content: (
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Protecting Your Crypto</h4>
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">
            In crypto, you are your own bank. There's no customer service to call if you lose your funds. Security is 100% your responsibility.
          </p>
        </div>
        <div className="space-y-3">
          {[
            { title: 'Never share your seed phrase', desc: 'Your 12/24-word seed phrase is the master key to your wallet. NOBODY legitimate will ever ask for it. Not support, not admins, not your exchange. If someone asks, it\'s a scam.', icon: Lock, color: '#ef4444' },
            { title: 'Use 2FA on everything', desc: 'Enable two-factor authentication on all exchanges and wallets. Use an authenticator app (Google Authenticator, Authy) — NOT SMS. SIM swaps can steal SMS codes.', icon: Shield, color: '#eab308' },
            { title: 'Verify addresses carefully', desc: 'Always double-check wallet addresses before sending. Malware can replace clipboard addresses. Send a tiny test transaction first for large transfers.', icon: Eye, color: '#00D4FF' },
            { title: 'Beware of phishing', desc: 'Bookmark exchange/wallet URLs. Never click links from emails, DMs, or social media. Scammers create pixel-perfect copies of legitimate sites.', icon: AlertTriangle, color: '#ef4444' },
            { title: 'Use hardware wallets for large amounts', desc: 'If you hold more than you\'re willing to lose, get a hardware wallet (Ledger, Trezor). Keep it in a safe place. Store your seed phrase on metal, not paper.', icon: Lock, color: '#22c55e' },
            { title: 'Don\'t trust, verify', desc: 'If someone DMs you about an "opportunity" or "airdrop," it\'s almost certainly a scam. If a return sounds too good to be true, it is. Never send crypto to "double" it.', icon: Brain, color: '#a855f7' },
          ].map(item => (
            <div key={item.title} className="p-3 bg-[#0D1117] border border-[#1A2942] rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <item.icon size={16} style={{ color: item.color }} />
              </div>
              <div>
                <h5 className="text-sm font-semibold text-white mb-0.5">{item.title}</h5>
                <p className="text-xs text-[#8899A6]">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
];

export default function CryptoLearningCenter() {
  const [openSection, setOpenSection] = useState<string>('basics');
  const [completedSections, setCompletedSections] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('learning-progress');
      return saved ? new Set(JSON.parse(saved)) : new Set<string>();
    } catch { return new Set<string>(); }
  });

  const toggleComplete = (id: string) => {
    setCompletedSections(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      localStorage.setItem('learning-progress', JSON.stringify([...next]));
      return next;
    });
  };

  const progress = Math.round((completedSections.size / SECTIONS.length) * 100);

  const difficultyColor = (d: string) => d === 'Beginner' ? 'text-[#22c55e]' : d === 'Intermediate' ? 'text-[#eab308]' : 'text-[#ef4444]';

  return (
    <TradingPlatformLayout>
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6" data-testid="learning-center-page">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center gap-3" style={{ fontFamily: 'Orbitron, sans-serif' }} data-testid="text-learning-heading">
              <GraduationCap className="text-[#00D4FF]" size={28} />
              Crypto Learning Center
            </h1>
            <p className="text-sm text-[#8899A6] mt-1">
              Everything you need to know about cryptocurrency trading — from zero to confident trader
            </p>
          </div>
          <Link href="/terminal">
            <span className="flex items-center gap-2 text-sm text-[#00D4FF] hover:underline cursor-pointer">
              Practice on Terminal <ArrowRight size={14} />
            </span>
          </Link>
        </div>

        <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-[#8899A6]">Your Progress</span>
            <span className="text-xs text-[#00D4FF] font-semibold">{completedSections.size}/{SECTIONS.length} sections</span>
          </div>
          <div className="h-2 bg-[#161b22] rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#00D4FF] to-[#22c55e] rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          <p className="text-[10px] text-[#8899A6] mt-1">{progress}% complete — Mark sections as done as you learn</p>
        </div>

        <div className="space-y-2">
          {SECTIONS.map((section, idx) => {
            const isOpen = openSection === section.id;
            const isDone = completedSections.has(section.id);
            const Icon = section.icon;

            return (
              <motion.div
                key={section.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                className="bg-[#0D1117] border border-[#1A2942] rounded-xl overflow-hidden"
                data-testid={`section-${section.id}`}
              >
                <button
                  onClick={() => setOpenSection(isOpen ? '' : section.id)}
                  className="w-full p-4 flex items-center gap-3 text-left hover:bg-[#161b22]/50 transition-colors"
                  data-testid={`button-section-${section.id}`}
                >
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${section.color}15` }}>
                    <Icon size={18} style={{ color: section.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold text-white">{section.title}</h3>
                      <span className={`text-[10px] font-medium ${difficultyColor(section.difficulty)}`}>{section.difficulty}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {isDone && <CheckCircle size={16} className="text-[#22c55e]" />}
                    {isOpen ? <ChevronDown size={16} className="text-[#8899A6]" /> : <ChevronRight size={16} className="text-[#8899A6]" />}
                  </div>
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 border-t border-[#1A2942] pt-4">
                        {section.content}
                        <div className="mt-6 flex items-center justify-between pt-4 border-t border-[#1A2942]">
                          <button
                            onClick={() => toggleComplete(section.id)}
                            className={`flex items-center gap-2 text-xs px-4 py-2 rounded-lg transition-all ${
                              isDone
                                ? 'bg-[#22c55e]/10 text-[#22c55e] border border-[#22c55e]/30'
                                : 'bg-[#161b22] text-[#94A3B8] border border-[#1A2942] hover:text-white'
                            }`}
                            data-testid={`button-complete-${section.id}`}
                          >
                            <CheckCircle size={14} />
                            {isDone ? 'Completed!' : 'Mark as Complete'}
                          </button>
                          {idx < SECTIONS.length - 1 && (
                            <button
                              onClick={() => setOpenSection(SECTIONS[idx + 1].id)}
                              className="flex items-center gap-1 text-xs text-[#00D4FF] hover:underline"
                            >
                              Next: {SECTIONS[idx + 1].title} <ArrowRight size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-[#00D4FF]/5 to-purple-500/5 border border-[#1A2942] rounded-xl p-6 text-center">
          <h3 className="text-lg font-bold text-white mb-2">Ready to Put Your Knowledge to Work?</h3>
          <p className="text-xs text-[#8899A6] mb-4 max-w-lg mx-auto">
            Practice what you've learned on our advanced trading terminal with real-time data, AI-powered signals, and proprietary indicators.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link href="/terminal">
              <span className="inline-flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-bold rounded-xl text-sm cursor-pointer">
                <TrendingUp size={16} /> Open Trading Terminal
              </span>
            </Link>
            <Link href="/news-sentiment">
              <span className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#161b22] border border-[#1A2942] text-white font-medium rounded-xl text-sm cursor-pointer hover:border-[#00D4FF]/50">
                <Brain size={16} /> AI Sentiment Analysis
              </span>
            </Link>
          </div>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}