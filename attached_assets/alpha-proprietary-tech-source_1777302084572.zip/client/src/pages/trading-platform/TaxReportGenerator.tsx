/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Tax Report Generator™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Tax Report Generator™
 * - Cost Basis Calculator™
 * - Multi-Method Tax Computation™
 * - Export Format Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_b7edc90346b2fa0f6194b43c
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useCallback } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { motion, AnimatePresence } from "framer-motion";

interface Transaction {
  id: string;
  date: string;
  type: "buy" | "sell" | "transfer" | "swap";
  asset: string;
  amount: number;
  pricePerUnit: number;
  totalValue: number;
  fee: number;
  exchange: string;
  chain: string;
  txHash?: string;
}

interface GainLossEntry {
  asset: string;
  acquiredDate: string;
  soldDate: string;
  proceeds: number;
  costBasis: number;
  gainLoss: number;
  holdingPeriod: "short" | "long";
  method: string;
}

interface TaxSummary {
  totalProceeds: number;
  totalCostBasis: number;
  totalGainLoss: number;
  shortTermGains: number;
  longTermGains: number;
  shortTermLosses: number;
  longTermLosses: number;
  netShortTerm: number;
  netLongTerm: number;
  totalTaxableGain: number;
  entries: GainLossEntry[];
}

type CostBasisMethod = "fifo" | "lifo" | "hifo";
type Jurisdiction = "us" | "uk" | "eu";

const SAMPLE_TRANSACTIONS: Transaction[] = [
  { id: "tx1", date: "2024-01-15", type: "buy", asset: "BTC", amount: 0.5, pricePerUnit: 42500, totalValue: 21250, fee: 15, exchange: "Coinbase", chain: "Bitcoin" },
  { id: "tx2", date: "2024-02-20", type: "buy", asset: "ETH", amount: 5, pricePerUnit: 2800, totalValue: 14000, fee: 10, exchange: "Kraken", chain: "Ethereum" },
  { id: "tx3", date: "2024-03-10", type: "buy", asset: "BTC", amount: 0.3, pricePerUnit: 68000, totalValue: 20400, fee: 12, exchange: "Binance", chain: "Bitcoin" },
  { id: "tx4", date: "2024-04-05", type: "sell", asset: "ETH", amount: 3, pricePerUnit: 3500, totalValue: 10500, fee: 8, exchange: "Coinbase", chain: "Ethereum" },
  { id: "tx5", date: "2024-05-22", type: "sell", asset: "BTC", amount: 0.4, pricePerUnit: 71000, totalValue: 28400, fee: 18, exchange: "Kraken", chain: "Bitcoin" },
  { id: "tx6", date: "2024-06-15", type: "buy", asset: "SOL", amount: 50, pricePerUnit: 145, totalValue: 7250, fee: 5, exchange: "Binance", chain: "Solana" },
  { id: "tx7", date: "2024-07-08", type: "swap", asset: "ETH", amount: 2, pricePerUnit: 3200, totalValue: 6400, fee: 20, exchange: "Uniswap", chain: "Ethereum" },
  { id: "tx8", date: "2024-08-18", type: "sell", asset: "SOL", amount: 30, pricePerUnit: 165, totalValue: 4950, fee: 4, exchange: "Binance", chain: "Solana" },
  { id: "tx9", date: "2024-09-25", type: "buy", asset: "BTC", amount: 0.2, pricePerUnit: 63000, totalValue: 12600, fee: 10, exchange: "Coinbase", chain: "Bitcoin" },
  { id: "tx10", date: "2024-10-30", type: "sell", asset: "BTC", amount: 0.3, pricePerUnit: 72500, totalValue: 21750, fee: 14, exchange: "Kraken", chain: "Bitcoin" },
];

function calculateTaxReport(transactions: Transaction[], method: CostBasisMethod): TaxSummary {
  const buyLots: Map<string, { date: string; amount: number; price: number; fee: number }[]> = new Map();
  const entries: GainLossEntry[] = [];

  const buys = transactions.filter(t => t.type === "buy" || t.type === "swap");
  const sells = transactions.filter(t => t.type === "sell");

  for (const tx of buys) {
    const lots = buyLots.get(tx.asset) || [];
    lots.push({ date: tx.date, amount: tx.amount, price: tx.pricePerUnit, fee: tx.fee / tx.amount });
    buyLots.set(tx.asset, lots);
  }

  for (const sell of sells) {
    const lots = buyLots.get(sell.asset) || [];
    let remaining = sell.amount;

    if (method === "lifo") {
      lots.reverse();
    } else if (method === "hifo") {
      lots.sort((a, b) => b.price - a.price);
    }

    while (remaining > 0 && lots.length > 0) {
      const lot = lots[0];
      const used = Math.min(remaining, lot.amount);
      const costBasis = used * (lot.price + lot.fee);
      const proceeds = used * sell.pricePerUnit - (sell.fee * (used / sell.amount));
      const gainLoss = proceeds - costBasis;

      const acquiredDate = new Date(lot.date);
      const soldDate = new Date(sell.date);
      const daysDiff = (soldDate.getTime() - acquiredDate.getTime()) / (1000 * 60 * 60 * 24);
      const holdingPeriod: "short" | "long" = daysDiff > 365 ? "long" : "short";

      entries.push({
        asset: sell.asset,
        acquiredDate: lot.date,
        soldDate: sell.date,
        proceeds,
        costBasis,
        gainLoss,
        holdingPeriod,
        method: method.toUpperCase(),
      });

      lot.amount -= used;
      remaining -= used;
      if (lot.amount <= 0) lots.shift();
    }

    if (method === "lifo") {
      lots.reverse();
    }
    buyLots.set(sell.asset, lots);
  }

  const totalProceeds = entries.reduce((s, e) => s + e.proceeds, 0);
  const totalCostBasis = entries.reduce((s, e) => s + e.costBasis, 0);
  const totalGainLoss = entries.reduce((s, e) => s + e.gainLoss, 0);
  const shortTermGains = entries.filter(e => e.holdingPeriod === "short" && e.gainLoss > 0).reduce((s, e) => s + e.gainLoss, 0);
  const longTermGains = entries.filter(e => e.holdingPeriod === "long" && e.gainLoss > 0).reduce((s, e) => s + e.gainLoss, 0);
  const shortTermLosses = entries.filter(e => e.holdingPeriod === "short" && e.gainLoss < 0).reduce((s, e) => s + Math.abs(e.gainLoss), 0);
  const longTermLosses = entries.filter(e => e.holdingPeriod === "long" && e.gainLoss < 0).reduce((s, e) => s + Math.abs(e.gainLoss), 0);

  return {
    totalProceeds,
    totalCostBasis,
    totalGainLoss,
    shortTermGains,
    longTermGains,
    shortTermLosses,
    longTermLosses,
    netShortTerm: shortTermGains - shortTermLosses,
    netLongTerm: longTermGains - longTermLosses,
    totalTaxableGain: (shortTermGains - shortTermLosses) + (longTermGains - longTermLosses),
    entries,
  };
}

function exportToCSV(entries: GainLossEntry[], jurisdiction: Jurisdiction): string {
  const headers = jurisdiction === "us"
    ? "Asset,Date Acquired,Date Sold,Proceeds ($),Cost Basis ($),Gain/Loss ($),Holding Period,Method"
    : jurisdiction === "uk"
    ? "Asset,Date Acquired,Date Disposed,Proceeds (GBP),Allowable Cost (GBP),Gain/Loss (GBP),Holding Period,Method"
    : "Asset,Date Acquired,Date Disposed,Proceeds (EUR),Cost Basis (EUR),Gain/Loss (EUR),Holding Period,Method";

  const rows = entries.map(e =>
    `${e.asset},${e.acquiredDate},${e.soldDate},${e.proceeds.toFixed(2)},${e.costBasis.toFixed(2)},${e.gainLoss.toFixed(2)},${e.holdingPeriod},${e.method}`
  );

  return [headers, ...rows].join("\n");
}

function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function ManualEntryForm({ onAdd }: { onAdd: (tx: Transaction) => void }) {
  const [form, setForm] = useState({
    date: new Date().toISOString().split("T")[0],
    type: "buy" as Transaction["type"],
    asset: "",
    amount: "",
    pricePerUnit: "",
    fee: "",
    exchange: "",
    chain: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(form.amount);
    const price = parseFloat(form.pricePerUnit);
    const fee = parseFloat(form.fee) || 0;
    if (!form.asset || isNaN(amount) || isNaN(price)) return;

    onAdd({
      id: `manual-${Date.now()}`,
      date: form.date,
      type: form.type,
      asset: form.asset.toUpperCase(),
      amount,
      pricePerUnit: price,
      totalValue: amount * price,
      fee,
      exchange: form.exchange || "Manual",
      chain: form.chain || "Unknown",
    });

    setForm({ date: new Date().toISOString().split("T")[0], type: "buy", asset: "", amount: "", pricePerUnit: "", fee: "", exchange: "", chain: "" });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Date</Label>
          <Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm text-white" data-testid="input-tx-date" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Type</Label>
          <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as Transaction["type"] }))}>
            <SelectTrigger className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="select-tx-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="buy">Buy</SelectItem>
              <SelectItem value="sell">Sell</SelectItem>
              <SelectItem value="swap">Swap</SelectItem>
              <SelectItem value="transfer">Transfer</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Asset</Label>
          <Input placeholder="BTC, ETH..." value={form.asset} onChange={e => setForm(f => ({ ...f, asset: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-asset" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Amount</Label>
          <Input type="number" step="any" placeholder="0.00" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-amount" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Price/Unit ($)</Label>
          <Input type="number" step="any" placeholder="0.00" value={form.pricePerUnit} onChange={e => setForm(f => ({ ...f, pricePerUnit: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-price" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Fee ($)</Label>
          <Input type="number" step="any" placeholder="0.00" value={form.fee} onChange={e => setForm(f => ({ ...f, fee: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-fee" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Exchange</Label>
          <Input placeholder="Coinbase, Binance..." value={form.exchange} onChange={e => setForm(f => ({ ...f, exchange: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-exchange" />
        </div>
        <div className="space-y-1">
          <Label className="text-gray-400 text-xs">Chain</Label>
          <Input placeholder="Ethereum, Bitcoin..." value={form.chain} onChange={e => setForm(f => ({ ...f, chain: e.target.value }))} className="bg-[#0a1018] border-[#1E3A5F]/50 h-9 text-sm" data-testid="input-tx-chain" />
        </div>
      </div>
      <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700 text-white" data-testid="button-add-transaction">
        Add Transaction
      </Button>
    </form>
  );
}

function TransactionsTable({ transactions, onRemove }: { transactions: Transaction[]; onRemove: (id: string) => void }) {
  if (transactions.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500" data-testid="text-no-transactions">
        <div className="text-3xl mb-2">📋</div>
        <p>No transactions yet. Add manually or import from an exchange.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-transactions">
        <thead>
          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
            <th className="text-left py-2 px-3">Date</th>
            <th className="text-left py-2 px-3">Type</th>
            <th className="text-left py-2 px-3">Asset</th>
            <th className="text-right py-2 px-3">Amount</th>
            <th className="text-right py-2 px-3">Price/Unit</th>
            <th className="text-right py-2 px-3">Total Value</th>
            <th className="text-right py-2 px-3">Fee</th>
            <th className="text-left py-2 px-3">Exchange</th>
            <th className="text-center py-2 px-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx) => (
            <tr key={tx.id} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors" data-testid={`row-transaction-${tx.id}`}>
              <td className="py-2 px-3 text-gray-300 text-xs">{tx.date}</td>
              <td className="py-2 px-3">
                <Badge className={`text-[10px] ${
                  tx.type === "buy" ? "bg-green-600/20 text-green-400 border-green-500/30" :
                  tx.type === "sell" ? "bg-red-600/20 text-red-400 border-red-500/30" :
                  tx.type === "swap" ? "bg-purple-600/20 text-purple-400 border-purple-500/30" :
                  "bg-blue-600/20 text-blue-400 border-blue-500/30"
                }`}>
                  {tx.type.toUpperCase()}
                </Badge>
              </td>
              <td className="py-2 px-3 text-white font-medium">{tx.asset}</td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">{tx.amount.toFixed(6)}</td>
              <td className="py-2 px-3 text-right font-mono text-gray-300">${tx.pricePerUnit.toLocaleString()}</td>
              <td className="py-2 px-3 text-right font-mono text-cyan-400">${tx.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              <td className="py-2 px-3 text-right font-mono text-gray-500">${tx.fee.toFixed(2)}</td>
              <td className="py-2 px-3 text-gray-400 text-xs">{tx.exchange}</td>
              <td className="py-2 px-3 text-center">
                <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300 h-6 px-2 text-xs" onClick={() => onRemove(tx.id)} data-testid={`button-remove-tx-${tx.id}`}>
                  Remove
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TaxSummaryView({ summary, jurisdiction }: { summary: TaxSummary; jurisdiction: Jurisdiction }) {
  const currencySymbol = jurisdiction === "uk" ? "£" : jurisdiction === "eu" ? "€" : "$";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500 mb-1">Total Proceeds</div>
            <div className="text-lg font-bold font-mono text-white" data-testid="text-total-proceeds">
              {currencySymbol}{summary.totalProceeds.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500 mb-1">Total Cost Basis</div>
            <div className="text-lg font-bold font-mono text-gray-300" data-testid="text-total-cost-basis">
              {currencySymbol}{summary.totalCostBasis.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500 mb-1">Net Gain/Loss</div>
            <div className={`text-lg font-bold font-mono ${summary.totalGainLoss >= 0 ? "text-green-400" : "text-red-400"}`} data-testid="text-net-gain-loss">
              {summary.totalGainLoss >= 0 ? "+" : ""}{currencySymbol}{summary.totalGainLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-gray-500 mb-1">Taxable Amount</div>
            <div className={`text-lg font-bold font-mono ${summary.totalTaxableGain >= 0 ? "text-yellow-400" : "text-green-400"}`} data-testid="text-taxable-amount">
              {currencySymbol}{Math.abs(summary.totalTaxableGain).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Short-Term ({"<"} 1 Year)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Gains</span>
              <span className="text-green-400 font-mono" data-testid="text-short-term-gains">+{currencySymbol}{summary.shortTermGains.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Losses</span>
              <span className="text-red-400 font-mono" data-testid="text-short-term-losses">-{currencySymbol}{summary.shortTermLosses.toFixed(2)}</span>
            </div>
            <div className="border-t border-[#1E3A5F]/50 pt-2 flex justify-between text-sm font-semibold">
              <span className="text-gray-300">Net</span>
              <span className={`font-mono ${summary.netShortTerm >= 0 ? "text-green-400" : "text-red-400"}`} data-testid="text-net-short-term">
                {summary.netShortTerm >= 0 ? "+" : ""}{currencySymbol}{summary.netShortTerm.toFixed(2)}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Long-Term ({">"} 1 Year)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Gains</span>
              <span className="text-green-400 font-mono" data-testid="text-long-term-gains">+{currencySymbol}{summary.longTermGains.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Losses</span>
              <span className="text-red-400 font-mono" data-testid="text-long-term-losses">-{currencySymbol}{summary.longTermLosses.toFixed(2)}</span>
            </div>
            <div className="border-t border-[#1E3A5F]/50 pt-2 flex justify-between text-sm font-semibold">
              <span className="text-gray-300">Net</span>
              <span className={`font-mono ${summary.netLongTerm >= 0 ? "text-green-400" : "text-red-400"}`} data-testid="text-net-long-term">
                {summary.netLongTerm >= 0 ? "+" : ""}{currencySymbol}{summary.netLongTerm.toFixed(2)}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {jurisdiction === "us" && (
        <Card className="bg-[#0f1923] border-yellow-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <span className="text-xl">📝</span>
              <div>
                <h4 className="text-sm font-semibold text-yellow-400 mb-1">IRS Form 8949 Summary</h4>
                <p className="text-xs text-gray-400">
                  Short-term gains/losses are reported in Part I (Box A/B/C). Long-term gains/losses are reported in Part II (Box D/E/F).
                  Net capital losses can offset up to $3,000 of ordinary income per year. Excess losses carry forward.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {jurisdiction === "uk" && (
        <Card className="bg-[#0f1923] border-yellow-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <span className="text-xl">📝</span>
              <div>
                <h4 className="text-sm font-semibold text-yellow-400 mb-1">HMRC Capital Gains Tax</h4>
                <p className="text-xs text-gray-400">
                  Crypto disposals must be reported on your Self Assessment. The annual CGT allowance (£6,000 for 2024/25) applies.
                  HMRC uses share pooling rules by default. Consider using the SA108 supplementary pages.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {jurisdiction === "eu" && (
        <Card className="bg-[#0f1923] border-yellow-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <span className="text-xl">📝</span>
              <div>
                <h4 className="text-sm font-semibold text-yellow-400 mb-1">EU Tax Guidelines (MiCA)</h4>
                <p className="text-xs text-gray-400">
                  Tax treatment varies by EU member state. Generally, crypto gains are taxable as capital gains or miscellaneous income.
                  Some jurisdictions offer holding period exemptions (e.g., Germany: 1 year hold = tax-free).
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {summary.entries.length > 0 && (
        <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Detailed Gain/Loss Entries</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm" data-testid="table-gain-loss">
                <thead>
                  <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
                    <th className="text-left py-2 px-3">Asset</th>
                    <th className="text-left py-2 px-3">Acquired</th>
                    <th className="text-left py-2 px-3">Sold</th>
                    <th className="text-right py-2 px-3">Proceeds</th>
                    <th className="text-right py-2 px-3">Cost Basis</th>
                    <th className="text-right py-2 px-3">Gain/Loss</th>
                    <th className="text-center py-2 px-3">Period</th>
                    <th className="text-center py-2 px-3">Method</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.entries.map((entry, idx) => (
                    <tr key={idx} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50" data-testid={`row-gain-loss-${idx}`}>
                      <td className="py-2 px-3 text-white font-medium">{entry.asset}</td>
                      <td className="py-2 px-3 text-gray-400 text-xs">{entry.acquiredDate}</td>
                      <td className="py-2 px-3 text-gray-400 text-xs">{entry.soldDate}</td>
                      <td className="py-2 px-3 text-right font-mono text-gray-300">{currencySymbol}{entry.proceeds.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono text-gray-300">{currencySymbol}{entry.costBasis.toFixed(2)}</td>
                      <td className={`py-2 px-3 text-right font-mono font-semibold ${entry.gainLoss >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {entry.gainLoss >= 0 ? "+" : ""}{currencySymbol}{entry.gainLoss.toFixed(2)}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <Badge className={`text-[10px] ${entry.holdingPeriod === "long" ? "bg-blue-600/20 text-blue-400 border-blue-500/30" : "bg-orange-600/20 text-orange-400 border-orange-500/30"}`}>
                          {entry.holdingPeriod === "long" ? "Long" : "Short"}
                        </Badge>
                      </td>
                      <td className="py-2 px-3 text-center">
                        <Badge variant="outline" className="text-[10px] border-[#1E3A5F] text-gray-400">{entry.method}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function TaxReportGenerator() {
  const [transactions, setTransactions] = useState<Transaction[]>([...SAMPLE_TRANSACTIONS]);
  const [method, setMethod] = useState<CostBasisMethod>("fifo");
  const [jurisdiction, setJurisdiction] = useState<Jurisdiction>("us");
  const [activeTab, setActiveTab] = useState("transactions");
  const [taxSummary, setTaxSummary] = useState<TaxSummary | null>(null);
  const [generating, setGenerating] = useState(false);
  const [includeSampleData, setIncludeSampleData] = useState(true);

  const handleAddTransaction = useCallback((tx: Transaction) => {
    setTransactions(prev => [...prev, tx]);
  }, []);

  const handleRemoveTransaction = useCallback((id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  }, []);

  const handleGenerateReport = useCallback(async () => {
    setGenerating(true);
    await new Promise(r => setTimeout(r, 1200));
    const summary = calculateTaxReport(transactions, method);
    setTaxSummary(summary);
    setActiveTab("report");
    setGenerating(false);
  }, [transactions, method]);

  const handleExportCSV = useCallback(() => {
    if (!taxSummary) return;
    const csv = exportToCSV(taxSummary.entries, jurisdiction);
    const year = new Date().getFullYear();
    downloadFile(csv, `crypto-tax-report-${year}-${method.toUpperCase()}.csv`, "text/csv");
  }, [taxSummary, jurisdiction, method]);

  const handleExportPDF = useCallback(async () => {
    if (!taxSummary) return;
    try {
      const res = await fetch("/api/tax-report/generate-pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entries: taxSummary.entries, summary: taxSummary, jurisdiction, method }),
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `crypto-tax-report-${new Date().getFullYear()}-${method.toUpperCase()}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        const csv = exportToCSV(taxSummary.entries, jurisdiction);
        downloadFile(csv, `crypto-tax-report-${new Date().getFullYear()}-${method.toUpperCase()}.csv`, "text/csv");
      }
    } catch {
      const csv = exportToCSV(taxSummary.entries, jurisdiction);
      downloadFile(csv, `crypto-tax-report-${new Date().getFullYear()}-${method.toUpperCase()}.csv`, "text/csv");
    }
  }, [taxSummary, jurisdiction, method]);

  const handleImportCSV = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split("\n").slice(1);
      const imported: Transaction[] = [];
      for (const line of lines) {
        const cols = line.split(",").map(c => c.trim());
        if (cols.length < 7) continue;
        const [date, type, asset, amount, price, fee, exchange] = cols;
        const parsedAmount = parseFloat(amount);
        const parsedPrice = parseFloat(price);
        if (isNaN(parsedAmount) || isNaN(parsedPrice)) continue;
        imported.push({
          id: `import-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          date,
          type: (type?.toLowerCase() || "buy") as Transaction["type"],
          asset: asset?.toUpperCase() || "UNKNOWN",
          amount: parsedAmount,
          pricePerUnit: parsedPrice,
          totalValue: parsedAmount * parsedPrice,
          fee: parseFloat(fee) || 0,
          exchange: exchange || "Imported",
          chain: "Unknown",
        });
      }
      if (imported.length > 0) {
        setTransactions(prev => [...prev, ...imported]);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }, []);

  const handleToggleSampleData = useCallback((checked: boolean) => {
    setIncludeSampleData(checked);
    if (checked) {
      setTransactions(prev => {
        const manualOnly = prev.filter(t => !t.id.startsWith("tx"));
        return [...SAMPLE_TRANSACTIONS, ...manualOnly];
      });
    } else {
      setTransactions(prev => prev.filter(t => !t.id.startsWith("tx")));
    }
  }, []);

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-tax-report-generator">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
                📊 Tax Report Generator
              </h1>
              <p className="text-gray-400 text-sm mt-1">
                Calculate capital gains/losses and generate tax-ready reports for crypto transactions
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Select value={jurisdiction} onValueChange={v => setJurisdiction(v as Jurisdiction)}>
                <SelectTrigger className="w-[140px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm h-9" data-testid="select-jurisdiction">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="us">🇺🇸 United States</SelectItem>
                  <SelectItem value="uk">🇬🇧 United Kingdom</SelectItem>
                  <SelectItem value="eu">🇪🇺 European Union</SelectItem>
                </SelectContent>
              </Select>
              <Select value={method} onValueChange={v => setMethod(v as CostBasisMethod)}>
                <SelectTrigger className="w-[120px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm h-9" data-testid="select-cost-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fifo">FIFO</SelectItem>
                  <SelectItem value="lifo">LIFO</SelectItem>
                  <SelectItem value="hifo">HIFO</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.1 }}>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="p-3 text-center">
                <div className="text-xs text-gray-500">Transactions</div>
                <div className="text-xl font-bold font-mono text-cyan-400" data-testid="text-transaction-count">{transactions.length}</div>
              </CardContent>
            </Card>
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="p-3 text-center">
                <div className="text-xs text-gray-500">Buy Orders</div>
                <div className="text-xl font-bold font-mono text-green-400" data-testid="text-buy-count">{transactions.filter(t => t.type === "buy").length}</div>
              </CardContent>
            </Card>
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="p-3 text-center">
                <div className="text-xs text-gray-500">Sell Orders</div>
                <div className="text-xl font-bold font-mono text-red-400" data-testid="text-sell-count">{transactions.filter(t => t.type === "sell").length}</div>
              </CardContent>
            </Card>
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="p-3 text-center">
                <div className="text-xs text-gray-500">Total Volume</div>
                <div className="text-xl font-bold font-mono text-white" data-testid="text-total-volume">
                  ${transactions.reduce((s, t) => s + t.totalValue, 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="p-3 text-center">
                <div className="text-xs text-gray-500">Method</div>
                <div className="text-sm font-semibold mt-1" data-testid="text-method">
                  <Badge className="bg-cyan-600/20 text-cyan-400 border-cyan-500/30">{method.toUpperCase()}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }}>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardHeader className="pb-2">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="bg-[#0a1018]">
                    <TabsTrigger value="transactions" className="text-xs" data-testid="tab-transactions">
                      📋 Transactions ({transactions.length})
                    </TabsTrigger>
                    <TabsTrigger value="manual" className="text-xs" data-testid="tab-manual-entry">
                      ✏️ Manual Entry
                    </TabsTrigger>
                    <TabsTrigger value="import" className="text-xs" data-testid="tab-import">
                      📥 Import
                    </TabsTrigger>
                    {taxSummary && (
                      <TabsTrigger value="report" className="text-xs" data-testid="tab-report">
                        📊 Tax Report
                      </TabsTrigger>
                    )}
                  </TabsList>
                </Tabs>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Switch checked={includeSampleData} onCheckedChange={handleToggleSampleData} data-testid="switch-sample-data" />
                    <span className="text-xs text-gray-400">Sample Data</span>
                  </div>
                  <Button
                    onClick={handleGenerateReport}
                    disabled={transactions.length === 0 || generating}
                    className="bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-white"
                    data-testid="button-generate-report"
                  >
                    {generating ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Calculating...
                      </span>
                    ) : (
                      "Generate Report"
                    )}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <AnimatePresence mode="wait">
                {activeTab === "transactions" && (
                  <motion.div key="transactions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <TransactionsTable transactions={transactions} onRemove={handleRemoveTransaction} />
                  </motion.div>
                )}
                {activeTab === "manual" && (
                  <motion.div key="manual" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4">
                    <ManualEntryForm onAdd={handleAddTransaction} />
                  </motion.div>
                )}
                {activeTab === "import" && (
                  <motion.div key="import" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-semibold text-white mb-3">Import from CSV</h3>
                        <p className="text-xs text-gray-400 mb-3">
                          Upload a CSV file with columns: Date, Type, Asset, Amount, Price, Fee, Exchange
                        </p>
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input type="file" accept=".csv" onChange={handleImportCSV} className="hidden" data-testid="input-import-csv" />
                          <Button variant="outline" className="border-[#1E3A5F] text-cyan-400 hover:bg-[#152238]" data-testid="button-import-csv" onClick={() => document.querySelector<HTMLInputElement>('[data-testid="input-import-csv"]')?.click()}>
                            📁 Select CSV File
                          </Button>
                        </label>
                      </div>

                      <div className="border-t border-[#1E3A5F]/50 pt-6">
                        <h3 className="text-sm font-semibold text-white mb-3">Import from Exchange</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {[
                            { name: "Coinbase", icon: "🟦" },
                            { name: "Binance", icon: "🟨" },
                            { name: "Kraken", icon: "🟪" },
                            { name: "Gemini", icon: "🟩" },
                            { name: "KuCoin", icon: "🟧" },
                            { name: "Crypto.com", icon: "🔵" },
                            { name: "MetaMask", icon: "🦊" },
                            { name: "Phantom", icon: "👻" },
                          ].map(exchange => (
                            <Button
                              key={exchange.name}
                              variant="outline"
                              className="border-[#1E3A5F] text-gray-300 hover:bg-[#152238] hover:text-white h-12 justify-start"
                              data-testid={`button-import-${exchange.name.toLowerCase().replace(".", "-")}`}
                            >
                              <span className="mr-2">{exchange.icon}</span>
                              {exchange.name}
                            </Button>
                          ))}
                        </div>
                        <p className="text-xs text-gray-500 mt-3">
                          Connect your exchange account to automatically import transaction history via API.
                        </p>
                      </div>

                      <div className="border-t border-[#1E3A5F]/50 pt-6">
                        <h3 className="text-sm font-semibold text-white mb-3">Import from Wallet</h3>
                        <div className="flex gap-3">
                          <Input placeholder="Enter wallet address (0x... or SOL...)" className="bg-[#0a1018] border-[#1E3A5F]/50 text-sm flex-1" data-testid="input-wallet-address" />
                          <Select defaultValue="ethereum">
                            <SelectTrigger className="w-[140px] bg-[#0a1018] border-[#1E3A5F]/50 text-sm" data-testid="select-import-chain">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ethereum">Ethereum</SelectItem>
                              <SelectItem value="bsc">BSC</SelectItem>
                              <SelectItem value="polygon">Polygon</SelectItem>
                              <SelectItem value="arbitrum">Arbitrum</SelectItem>
                              <SelectItem value="solana">Solana</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button className="bg-cyan-600 hover:bg-cyan-700" data-testid="button-import-wallet">
                            Import
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
                {activeTab === "report" && taxSummary && (
                  <motion.div key="report" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4">
                    <div className="flex gap-3 mb-4">
                      <Button onClick={handleExportCSV} variant="outline" className="border-[#1E3A5F] text-cyan-400 hover:bg-[#152238]" data-testid="button-export-csv">
                        📥 Export CSV
                      </Button>
                      <Button onClick={handleExportPDF} className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white" data-testid="button-export-pdf">
                        📄 Export PDF
                      </Button>
                    </div>
                    <TaxSummaryView summary={taxSummary} jurisdiction={jurisdiction} />
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.3 }}>
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🔒</span>
                  <div>
                    <h4 className="text-sm font-semibold text-white">Privacy First</h4>
                    <p className="text-xs text-gray-400 mt-1">All calculations run locally in your browser. No transaction data is sent to external servers.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">📐</span>
                  <div>
                    <h4 className="text-sm font-semibold text-white">Multiple Methods</h4>
                    <p className="text-xs text-gray-400 mt-1">FIFO, LIFO, and HIFO cost basis methods. Compare results to optimize your tax position.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🌍</span>
                  <div>
                    <h4 className="text-sm font-semibold text-white">Multi-Jurisdiction</h4>
                    <p className="text-xs text-gray-400 mt-1">Support for US (IRS), UK (HMRC), and EU tax reporting requirements.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4, delay: 0.4 }}>
          <p className="text-xs text-gray-600 text-center">
            Disclaimer: This tool provides estimates only. Consult a qualified tax professional for official tax filings.
            Tax laws vary by jurisdiction and individual circumstances.
          </p>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}