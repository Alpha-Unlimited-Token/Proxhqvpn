/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha NFT Marketplace™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - NFT Marketplace™
 * - AI-Generated NFT Engine™
 * - Digital Asset Gallery™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_2fd7d28701a23c30b3530fb8
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useMemo, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { AINFTGenerator } from "@/components/trading-platform/AINFTGenerator";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Image, Sparkles, ShoppingCart, Search, Filter,
  Heart, Eye, Tag, Wand2,
  X, Gem, Crown, Star, Shield, Zap,
  RefreshCw, Copy, ExternalLink, Grid, List, TrendingUp, Upload,
  Wallet, Globe, Share2, Link, ArrowRight, Lock, Unlock, DollarSign,
  AlertTriangle, ChevronDown, CheckCircle, Percent
} from "lucide-react";
import {
  useMarketplaceNFTs, useMyNFTs, useCreateNFT,
  useListNFT, useUnlistNFT, useLikeNFT, useViewNFT, useBlockchains,
  useAiNftCredits, useAiNftCheckout, useAiNftGenerate, useAiNftPackages,
  useTrendingNFTs, useNewNFTs, useTopSellers, usePortfolioStats, useMigrateNFT,
  usePriceSuggestion, useAssessNFT, useNFTAssessment,
  useStakeNFT, useUnstakeNFT, useClaimRewards, useUserStakes,
  useStrategies, useSaveStrategy, useDeleteStrategy
} from "@/hooks/useNFTMarketplace";
import {
  MarketplaceHero, NewNFTsCarousel, TrendingShowcase, TopSellersGrid,
  PortfolioStats, MigrationImportForm, SellerPaymentGuide,
  PriceSuggestionPanel, NFTAssessmentPanel, NFTStakingSection, StrategyBuilder
} from "@/components/trading-platform/NFTMarketplaceSections";
import {
  GamifiedRewardsPanel, CommunityForum, FractionalOwnershipCard,
  P2PBuyModal, DEXProtocolsSection, UserFractionsPanel,
} from "@/components/trading-platform/NFTCommunityFeatures";
import type { NFT } from "@shared/models/nft";
import { PAYOUT_CURRENCIES, validateWalletAddress } from "@shared/models/nft";






type Rarity = "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary" | "Mythic";

const RARITY_CONFIG: Record<Rarity, { color: string; border: string; bg: string; icon: any }> = {
  Common: { color: "text-gray-400", border: "border-gray-500/30", bg: "bg-gray-500/10", icon: Shield },
  Uncommon: { color: "text-green-400", border: "border-green-500/30", bg: "bg-green-500/10", icon: Star },
  Rare: { color: "text-blue-400", border: "border-blue-500/30", bg: "bg-blue-500/10", icon: Gem },
  Epic: { color: "text-purple-400", border: "border-purple-500/30", bg: "bg-purple-500/10", icon: Sparkles },
  Legendary: { color: "text-yellow-400", border: "border-yellow-500/30", bg: "bg-yellow-500/10", icon: Crown },
  Mythic: { color: "text-red-400", border: "border-red-500/30", bg: "bg-red-500/10", icon: Zap },
};

const SUPPORTED_CRYPTOS = [
  { id: 'btc', name: 'Bitcoin', symbol: 'BTC', icon: '₿' },
  { id: 'eth', name: 'Ethereum', symbol: 'ETH', icon: 'Ξ' },
  { id: 'usdterc20', name: 'USDT (ERC-20)', symbol: 'USDT', icon: '₮' },
  { id: 'bnbbsc', name: 'BNB', symbol: 'BNB', icon: '◆' },
  { id: 'xrp', name: 'XRP', symbol: 'XRP', icon: '✕' },
  { id: 'usdc', name: 'USD Coin (ERC-20)', symbol: 'USDC', icon: '$' },
  { id: 'sol', name: 'Solana', symbol: 'SOL', icon: '◎' },
  { id: 'doge', name: 'Dogecoin', symbol: 'DOGE', icon: 'Ð' },
  { id: 'ada', name: 'Cardano', symbol: 'ADA', icon: '₳' },
  { id: 'trx', name: 'TRON', symbol: 'TRX', icon: '◈' },
];

function getNFTImage(nft: NFT): string {
  return nft.imageUrl || "";
}

function DRMCanvas({ imageUrl, className = "", style = {} }: { imageUrl: string; className?: string; style?: React.CSSProperties }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const [fallback, setFallback] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) { setFallback(true); return; }

    const gl = canvas.getContext('webgl', {
      preserveDrawingBuffer: false,
      antialias: false,
      alpha: false,
      premultipliedAlpha: false,
      desynchronized: true,
    });
    if (!gl) { setFallback(true); return; }

    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); setFallback(true); });

    const img = new window.Image();
    img.crossOrigin = "anonymous";
    img.onerror = () => setFallback(true);
    img.onload = () => {
      canvas.width = Math.min(img.naturalWidth || 400, 512);
      canvas.height = Math.min(img.naturalHeight || 400, 512);

      const vs = gl.createShader(gl.VERTEX_SHADER);
      const fs = gl.createShader(gl.FRAGMENT_SHADER);
      if (!vs || !fs) { setFallback(true); return; }
      gl.shaderSource(vs, 'attribute vec2 a_p;attribute vec2 a_t;varying vec2 v_t;void main(){gl_Position=vec4(a_p,0,1);v_t=a_t;}');
      gl.compileShader(vs);
      if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) { setFallback(true); return; }
      gl.shaderSource(fs, 'precision mediump float;varying vec2 v_t;uniform sampler2D u_i;void main(){gl_FragColor=texture2D(u_i,v_t);}');
      gl.compileShader(fs);
      if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) { setFallback(true); return; }

      const prog = gl.createProgram();
      if (!prog) { setFallback(true); return; }
      gl.attachShader(prog, vs);
      gl.attachShader(prog, fs);
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { setFallback(true); return; }
      gl.useProgram(prog);

      const pb = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, pb);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,1,1]), gl.STATIC_DRAW);
      const pl = gl.getAttribLocation(prog, 'a_p');
      gl.enableVertexAttribArray(pl);
      gl.vertexAttribPointer(pl, 2, gl.FLOAT, false, 0, 0);

      const tb = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, tb);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0,1,1,1,0,0,1,0]), gl.STATIC_DRAW);
      const tl = gl.getAttribLocation(prog, 'a_t');
      gl.enableVertexAttribArray(tl);
      gl.vertexAttribPointer(tl, 2, gl.FLOAT, false, 0, 0);

      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);

      let lastDraw = 0;
      const render = (time: number) => {
        if (document.hidden) { animRef.current = requestAnimationFrame(render); return; }
        if (time - lastDraw < 100) { animRef.current = requestAnimationFrame(render); return; }
        lastDraw = time;
        gl.viewport(0, 0, canvas.width, canvas.height);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        animRef.current = requestAnimationFrame(render);
      };
      animRef.current = requestAnimationFrame(render);
    };
    img.src = imageUrl;

    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [imageUrl]);

  if (fallback) {
    return (
      <div
        className={`w-full h-full bg-cover bg-center select-none ${className}`}
        style={{ ...style, backgroundImage: `url(${imageUrl})`, WebkitTouchCallout: "none", WebkitUserSelect: "none", userSelect: "none" }}
        onContextMenu={e => e.preventDefault()}
        onDragStart={e => e.preventDefault()}
        draggable={false}
      />
    );
  }

  return (
    <div className={`relative ${className}`} style={{ ...style, WebkitTouchCallout: "none", WebkitUserSelect: "none", userSelect: "none" }}>
      <canvas
        ref={canvasRef}
        className="w-full h-full object-cover"
        style={{ transform: "translateZ(0)", willChange: "transform", backfaceVisibility: "hidden" }}
        onContextMenu={e => e.preventDefault()}
        onDragStart={e => e.preventDefault()}
        draggable={false}
      />
      <div className="absolute inset-0" style={{ pointerEvents: "none" }} />
    </div>
  );
}

function NFTCard({ nft, onSelect, onBuy, showListButton, onList, onUnlist }: {
  nft: NFT; onSelect: () => void; onBuy?: () => void;
  showListButton?: boolean; onList?: () => void; onUnlist?: () => void;
}) {
  const rc = RARITY_CONFIG[(nft.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
  const RIcon = rc.icon;
  const imageUrl = getNFTImage(nft);
  const blockchainInfo = SUPPORTED_CRYPTOS.find(c => c.id === nft.blockchain) || { icon: "◎", symbol: "SOL" };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-[#0F1923] border ${rc.border} rounded-xl overflow-hidden hover:border-[#00D4FF]/40 transition-all cursor-pointer group`}
      onClick={onSelect}
      data-testid={`nft-card-${nft.id}`}
    >
      <div className="aspect-square relative overflow-hidden">
        <DRMCanvas imageUrl={imageUrl} className="w-full h-full" />
        <div className={`absolute top-2 left-2 ${rc.bg} ${rc.color} px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1`}>
          <RIcon className="w-3 h-3" /> {nft.rarity}
        </div>
        <div className="absolute top-2 right-2 bg-black/60 text-white px-1.5 py-0.5 rounded text-[10px]">
          {blockchainInfo.icon} {blockchainInfo.symbol}
        </div>
        {nft.isSold && (
          <div className="absolute inset-0 bg-gray-800/75 flex items-center justify-center">
            <span className="text-gray-300 font-bold text-sm tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif' }}>SOLD</span>
          </div>
        )}
      </div>
      <div className="p-3">
        <h4 className="text-white text-sm font-semibold truncate">{nft.name}</h4>
        <p className="text-[#64748B] text-[10px] mt-0.5">by {nft.creatorUsername || "AlphaGenesis"}</p>
        <div className="flex items-center justify-between mt-2">
          <span className="text-[#00D4FF] font-bold text-sm">${nft.priceUSD}</span>
          <div className="flex items-center gap-2 text-[10px] text-[#64748B]">
            <span className="flex items-center gap-0.5"><Heart className="w-3 h-3" /> {nft.likes}</span>
            <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {nft.views}</span>
          </div>
        </div>
        {!nft.isSold && onBuy && !showListButton && (
          <Button
            onClick={e => { e.stopPropagation(); onBuy(); }}
            className="w-full mt-2 bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 text-xs py-1"
            data-testid={`button-buy-${nft.id}`}
          >
            <ShoppingCart className="w-3 h-3 mr-1" /> Buy Now
          </Button>
        )}
        {showListButton && !nft.isListed && onList && (
          <Button
            onClick={e => { e.stopPropagation(); onList(); }}
            className="w-full mt-2 bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 text-xs py-1"
            data-testid={`button-list-${nft.id}`}
          >
            <Tag className="w-3 h-3 mr-1" /> List for Sale
          </Button>
        )}
        {showListButton && nft.isListed && onUnlist && (
          <Button
            onClick={e => { e.stopPropagation(); onUnlist(); }}
            className="w-full mt-2 bg-orange-500/20 text-orange-400 border border-orange-500/30 hover:bg-orange-500/30 text-xs py-1"
            data-testid={`button-unlist-${nft.id}`}
          >
            <Lock className="w-3 h-3 mr-1" /> Remove Listing
          </Button>
        )}
      </div>
    </motion.div>
  );
}

function NFTListItem({ nft, onSelect, onBuy }: { nft: NFT; onSelect: () => void; onBuy?: () => void }) {
  const rc = RARITY_CONFIG[(nft.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
  const RIcon = rc.icon;
  const imageUrl = getNFTImage(nft);
  const blockchainInfo = SUPPORTED_CRYPTOS.find(c => c.id === nft.blockchain) || { icon: "◎", symbol: "SOL" };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className={`bg-[#0F1923] border ${rc.border} rounded-lg p-3 flex items-center gap-4 hover:border-[#00D4FF]/40 transition-all cursor-pointer`}
      onClick={onSelect}
      data-testid={`nft-list-${nft.id}`}
    >
      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
        <DRMCanvas imageUrl={imageUrl} className="w-full h-full" />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="text-white text-sm font-semibold truncate">{nft.name}</h4>
        <div className="flex items-center gap-2 mt-0.5">
          <span className={`${rc.bg} ${rc.color} px-1.5 py-0.5 rounded text-[10px] font-bold flex items-center gap-0.5`}>
            <RIcon className="w-2.5 h-2.5" /> {nft.rarity}
          </span>
          <span className="text-[#64748B] text-[10px]">{nft.element || "Alpha"}</span>
          <span className="text-[#64748B] text-[10px]">{blockchainInfo.icon} {blockchainInfo.symbol}</span>
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <p className="text-[#00D4FF] font-bold">${nft.priceUSD}</p>
        <div className="flex items-center gap-2 text-[10px] text-[#64748B] mt-0.5">
          <span><Heart className="w-3 h-3 inline" /> {nft.likes}</span>
          <span><Eye className="w-3 h-3 inline" /> {nft.views}</span>
        </div>
      </div>
      {!nft.isSold && onBuy && (
        <Button onClick={e => { e.stopPropagation(); onBuy(); }} className="bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30 text-xs" data-testid={`button-buy-list-${nft.id}`}>
          Buy
        </Button>
      )}
    </motion.div>
  );
}

function ListingPriceSuggestion({ nftId, onApply }: { nftId: number; onApply: (price: number) => void }) {
  const { data: suggestion } = usePriceSuggestion(nftId);
  if (!suggestion) return null;
  return <PriceSuggestionPanel suggestion={suggestion} onApply={onApply} />;
}

export default function AlphaTradingNFT() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"marketplace" | "my-nfts" | "portfolio" | "create" | "wallet" | "migrate" | "staking" | "strategies" | "community" | "rewards" | "dex">("create");
  const [showP2PBuy, setShowP2PBuy] = useState<NFT | null>(null);
  const [showFractional, setShowFractional] = useState<NFT | null>(null);
  const [selectedNFT, setSelectedNFT] = useState<NFT | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showListDialog, setShowListDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [listingNFT, setListingNFT] = useState<NFT | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [rarityFilter, setRarityFilter] = useState<Rarity | "All">("All");
  const ELEMENTS = ["Alpha", "Nebula Glow", "Volcanic Ash", "Arctic Frost", "Desert Haze", "Forest Mist", "Deep Space", "Underwater", "Neon City", "Ancient Temple", "Void Realm", "Cyberpunk Skyline"];
  const [elementFilter, setElementFilter] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"price-asc" | "price-desc" | "likes" | "newest">("likes");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showFilters, setShowFilters] = useState(false);
  const [listPrice, setListPrice] = useState("");


  const [listPayoutCurrency, setListPayoutCurrency] = useState("sol");
  const [listPayoutWallet, setListPayoutWallet] = useState("");
  const [listWalletError, setListWalletError] = useState("");

  const [isScreenCaptured, setIsScreenCaptured] = useState(false);
  const [showMintDialog, setShowMintDialog] = useState(false);
  const [mintingNFT, setMintingNFT] = useState<NFT | null>(null);
  const [mintStep, setMintStep] = useState<"prepare" | "signing" | "confirm" | "done">("prepare");
  const [mintWallet, setMintWallet] = useState("");
  const [mintTxHash, setMintTxHash] = useState("");
  const [mintResult, setMintResult] = useState<any>(null);
  const [isMinting, setIsMinting] = useState(false);

  const { data: marketplaceNFTs = [], isLoading: loadingMarketplace } = useMarketplaceNFTs();
  const { data: myNFTsList = [], isLoading: loadingMyNFTs } = useMyNFTs();
  const { data: blockchains = [] } = useBlockchains();
  const createNFTMutation = useCreateNFT();
  const listMutation = useListNFT();
  const unlistMutation = useUnlistNFT();
  const likeMutation = useLikeNFT();
  const viewMutation = useViewNFT();
  const { data: aiCreditsData } = useAiNftCredits();
  const { data: aiPackages = [] } = useAiNftPackages();
  const aiCheckoutMutation = useAiNftCheckout();
  const aiGenerateMutation = useAiNftGenerate();
  const { data: trendingNFTs = [] } = useTrendingNFTs(8);
  const { data: newNFTs = [] } = useNewNFTs(20);
  const { data: topSellers = [] } = useTopSellers(10);
  const { data: portfolioStats } = usePortfolioStats();
  const migrateMutation = useMigrateNFT();
  const stakeNFTMutation = useStakeNFT();
  const unstakeNFTMutation = useUnstakeNFT();
  const claimRewardsMutation = useClaimRewards();
  const { data: userStakes = [] } = useUserStakes();
  const assessNFTMutation = useAssessNFT();
  const { data: strategies = [] } = useStrategies();
  const saveStrategyMutation = useSaveStrategy();
  const deleteStrategyMutation = useDeleteStrategy();
  const [showAiPackages, setShowAiPackages] = useState(false);
  const aiCreditsRemaining = aiCreditsData?.totalRemaining ?? 0;

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('buy') === 'credits') {
      setShowAiPackages(true);
    }
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsScreenCaptured(true);
        setTimeout(() => setIsScreenCaptured(false), 1500);
      }
    };
    const handleBlur = () => {
      setIsScreenCaptured(true);
      setTimeout(() => setIsScreenCaptured(false), 1500);
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleBlur);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleBlur);
    };
  }, []);

  useEffect(() => {
    const meta = document.createElement('meta');
    meta.name = 'robots';
    meta.content = 'noimageindex';
    document.head.appendChild(meta);
    const metaGoogle = document.createElement('meta');
    metaGoogle.name = 'googlebot';
    metaGoogle.content = 'noimageindex';
    document.head.appendChild(metaGoogle);
    return () => {
      document.head.removeChild(meta);
      document.head.removeChild(metaGoogle);
    };
  }, []);

  const filteredMarketplace = useMemo(() => {
    let items = [...marketplaceNFTs];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      items = items.filter(n => n.name.toLowerCase().includes(q) || (n.element || "").toLowerCase().includes(q) || (n.creatorUsername || "").toLowerCase().includes(q));
    }
    if (rarityFilter !== "All") items = items.filter(n => n.rarity === rarityFilter);
    if (elementFilter !== "All") items = items.filter(n => n.element === elementFilter);
    switch (sortBy) {
      case "price-asc": items.sort((a, b) => a.priceUSD - b.priceUSD); break;
      case "price-desc": items.sort((a, b) => b.priceUSD - a.priceUSD); break;
      case "likes": items.sort((a, b) => b.likes - a.likes); break;
      case "newest": items.sort((a, b) => b.id - a.id); break;
    }
    return items;
  }, [marketplaceNFTs, searchQuery, rarityFilter, elementFilter, sortBy]);

  const handleBuyClick = useCallback((nft: NFT) => {
    if (!user) {
      toast({ title: "Sign in required", description: "Please sign in to purchase NFTs.", variant: "destructive" });
      return;
    }
    setShowP2PBuy(nft);
  }, [user, toast]);


  const handleList = useCallback(() => {
    if (!listingNFT || !listPrice) return;
    const price = parseFloat(listPrice);
    if (isNaN(price) || price <= 0) {
      toast({ title: "Invalid price", description: "Please enter a valid price in USD.", variant: "destructive" });
      return;
    }
    if (!listPayoutWallet.trim()) {
      toast({ title: "Wallet required", description: "Please enter your wallet address to receive payments.", variant: "destructive" });
      return;
    }
    const validation = validateWalletAddress(listPayoutCurrency, listPayoutWallet);
    if (!validation.valid) {
      setListWalletError(validation.message);
      toast({ title: "Invalid wallet address", description: validation.message, variant: "destructive" });
      return;
    }
    listMutation.mutate(
      { nftId: listingNFT.id, priceUSD: price, payoutCurrency: listPayoutCurrency, payoutWallet: listPayoutWallet },
      {
        onSuccess: () => {
          setShowListDialog(false);
          setListPrice("");
          setListPayoutWallet("");
          setListWalletError("");
          toast({ title: "NFT Listed!", description: `"${listingNFT.name}" is now listed for $${price}` });
        },
        onError: (err: any) => {
          toast({ title: "Listing Failed", description: err.message, variant: "destructive" });
        }
      }
    );
  }, [listingNFT, listPrice, listPayoutCurrency, listPayoutWallet, listMutation, toast]);

  const handleUnlist = useCallback((nft: NFT) => {
    unlistMutation.mutate(nft.id, {
      onSuccess: () => {
        toast({ title: "NFT Unlisted", description: `"${nft.name}" has been removed from the marketplace` });
      },
    });
  }, [unlistMutation, toast]);

  const handleAiCheckout = useCallback((packageId: string) => {
    aiCheckoutMutation.mutate(packageId, {
      onSuccess: (data: any) => {
        if (data.url) window.location.href = data.url;
      },
      onError: (err: any) => {
        toast({ title: "Checkout Failed", description: err.message, variant: "destructive" });
      },
    });
  }, [aiCheckoutMutation, toast]);

  const handleSelectNFT = useCallback((nft: NFT) => {
    setSelectedNFT(nft);
    setShowDetail(true);
    viewMutation.mutate(nft.id);
  }, [viewMutation]);

  const handleShare = useCallback((nft: NFT) => {
    setSelectedNFT(nft);
    setShowShareDialog(true);
  }, []);

  const copyShareLink = useCallback(() => {
    if (!selectedNFT) return;
    const url = `${window.location.origin}/alpha-trading/nft?view=${selectedNFT.id}`;
    navigator.clipboard.writeText(url);
    toast({ title: "Link Copied!", description: "Share link copied to clipboard." });
  }, [selectedNFT, toast]);

  const handlePrepareMint = useCallback(async () => {
    if (!mintingNFT || !mintWallet.trim()) return;
    setIsMinting(true);
    try {
      const res = await fetch(`/api/nfts/${mintingNFT.id}/prepare-mint`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ creatorWallet: mintWallet.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMintResult(data);
        setMintStep("signing");
        toast({ title: "Metadata Ready", description: "NFT metadata uploaded to IPFS. Connect your wallet to sign the mint transaction." });
      } else {
        toast({ title: "Prepare Failed", description: data.message, variant: "destructive" });
      }
    } catch (err: any) {
      toast({ title: "Error", description: err?.message || "Failed to prepare mint", variant: "destructive" });
    } finally {
      setIsMinting(false);
    }
  }, [mintingNFT, mintWallet, toast]);

  const handleConfirmMint = useCallback(async () => {
    if (!mintingNFT || !mintTxHash.trim()) return;
    setIsMinting(true);
    try {
      const res = await fetch(`/api/nfts/${mintingNFT.id}/confirm-mint`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transactionHash: mintTxHash.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMintResult(data);
        setMintStep("done");
        toast({ title: "NFT Minted!", description: data.message });
      } else {
        toast({ title: "Confirmation Failed", description: data.message, variant: "destructive" });
      }
    } catch (err: any) {
      toast({ title: "Error", description: err?.message || "Failed to confirm mint", variant: "destructive" });
    } finally {
      setIsMinting(false);
    }
  }, [mintingNFT, mintTxHash, toast]);

  const openMintDialog = useCallback((nft: NFT) => {
    setMintingNFT(nft);
    setMintStep("prepare");
    setMintWallet("");
    setMintTxHash("");
    setMintResult(null);
    setShowMintDialog(true);
    setShowDetail(false);
  }, []);

  const stats = useMemo(() => ({
    totalVolume: marketplaceNFTs.reduce((sum, n) => sum + (n.isListed ? n.priceUSD : 0), 0),
    totalListed: marketplaceNFTs.length,
    floorPrice: marketplaceNFTs.length > 0 ? Math.min(...marketplaceNFTs.map(n => n.priceUSD)) : 0,
    totalOwned: myNFTsList.length,
  }), [marketplaceNFTs, myNFTsList]);

  return (
    <TradingPlatformLayout>
      <div
        className="max-w-7xl mx-auto py-6 px-4"
        data-testid="trading-nft-marketplace"
        onContextMenu={e => e.preventDefault()}
        style={{ WebkitTouchCallout: "none", WebkitUserSelect: "none", userSelect: "none" }}
      >
        {isScreenCaptured && (
          <div className="fixed inset-0 bg-black z-[9999]" style={{ pointerEvents: "none" }} />
        )}

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-10 h-10 rounded-xl bg-[#00D4FF]/20 border border-[#00D4FF]/30 flex items-center justify-center">
                  <Image className="w-5 h-5 text-[#00D4FF]" />
                </div>
                <h1 className="text-2xl md:text-3xl font-bold text-white">
                  NFT <span className="text-[#00D4FF]">Marketplace</span>
                </h1>
              </div>
              <p className="text-[#94A3B8] text-sm">Browse, collect, create, and sell exclusive Alpha NFTs with cryptocurrency</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "Floor Price", value: `$${stats.floorPrice}`, icon: TrendingUp },
                { label: "Total Listed", value: stats.totalListed.toString(), icon: Tag },
                { label: "Volume", value: `$${stats.totalVolume.toLocaleString()}`, icon: ShoppingCart },
                { label: "My NFTs", value: stats.totalOwned.toString(), icon: Heart },
              ].map(s => (
                <div key={s.label} className="bg-[#0F1923] border border-[#1A2942] rounded-lg px-3 py-2 text-center">
                  <s.icon className="w-3.5 h-3.5 text-[#00D4FF] mx-auto mb-1" />
                  <p className="text-white text-sm font-bold">{s.value}</p>
                  <p className="text-[#64748B] text-[10px]">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-1 bg-[#0F1923] border border-[#1A2942] rounded-lg p-1 w-fit flex-wrap">
            {(["create", "marketplace", "my-nfts", "portfolio", "wallet", "migrate", "staking", "strategies", "community", "rewards", "dex"] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-all ${
                  activeTab === tab
                    ? "bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30"
                    : "text-[#94A3B8] hover:text-white hover:bg-[#1A2942]"
                }`}
                data-testid={`tab-${tab}`}
              >
                {tab === "create" && <><Wand2 className="w-4 h-4 inline mr-1.5" />Create</>}
                {tab === "marketplace" && <><ShoppingCart className="w-4 h-4 inline mr-1.5" />Marketplace</>}
                {tab === "my-nfts" && <><Heart className="w-4 h-4 inline mr-1.5" />My NFTs</>}
                {tab === "portfolio" && <><TrendingUp className="w-4 h-4 inline mr-1.5" />Portfolio</>}
                {tab === "wallet" && <><Wallet className="w-4 h-4 inline mr-1.5" />Wallet</>}
                {tab === "migrate" && <><Globe className="w-4 h-4 inline mr-1.5" />Migrate</>}
                {tab === "community" && <><span className="w-4 h-4 inline-flex items-center justify-center mr-1.5">💬</span>Forum</>}
                {tab === "rewards" && <><span className="w-4 h-4 inline-flex items-center justify-center mr-1.5">🏆</span>Rewards</>}
                {tab === "dex" && <><span className="w-4 h-4 inline-flex items-center justify-center mr-1.5">🔗</span>DEX</>}
              </button>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {activeTab === "marketplace" && (
            <motion.div key="marketplace" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <MarketplaceHero stats={{ totalVolume: stats.totalVolume, totalListed: stats.totalListed, floorPrice: stats.floorPrice }} />

              {newNFTs.length > 0 && (
                <div className="mb-8">
                  <NewNFTsCarousel nfts={newNFTs} onSelect={handleSelectNFT} onBuy={handleBuyClick} getNFTImage={getNFTImage} />
                </div>
              )}

              {trendingNFTs.length > 0 && (
                <div className="mb-8">
                  <TrendingShowcase nfts={trendingNFTs} onSelect={handleSelectNFT} onBuy={handleBuyClick} getNFTImage={getNFTImage} />
                </div>
              )}

              {topSellers.length > 0 && (
                <div className="mb-8">
                  <TopSellersGrid sellers={topSellers} onViewCreator={(creatorId) => {
                    setSearchQuery(topSellers.find(s => s.creatorId === creatorId)?.creatorUsername || "");
                  }} />
                </div>
              )}

              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Grid className="w-5 h-5 text-[#00D4FF]" /> All NFTs
              </h3>
              <div className="flex flex-col md:flex-row gap-3 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="text"
                    placeholder="Search by name, element, or creator..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full bg-[#0F1923] border border-[#1A2942] rounded-lg pl-10 pr-4 py-2.5 text-white text-sm placeholder-[#64748B] focus:outline-none focus:border-[#00D4FF]/50"
                    data-testid="input-nft-search"
                  />
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => setShowFilters(!showFilters)}
                    className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm transition-all ${
                      showFilters ? "bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30" : "bg-[#0F1923] border border-[#1A2942] text-[#94A3B8] hover:text-white"
                    }`}
                    data-testid="button-toggle-filters"
                  >
                    <Filter className="w-4 h-4" /> Filters
                  </button>
                  <select
                    value={sortBy}
                    onChange={e => setSortBy(e.target.value as any)}
                    className="bg-[#0F1923] border border-[#1A2942] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#00D4FF]/50"
                    data-testid="select-sort"
                  >
                    <option value="likes">Most Popular</option>
                    <option value="price-asc">Price: Low to High</option>
                    <option value="price-desc">Price: High to Low</option>
                    <option value="newest">Newest</option>
                  </select>
                  <div className="flex bg-[#0F1923] border border-[#1A2942] rounded-lg overflow-hidden">
                    <button onClick={() => setViewMode("grid")} className={`px-2.5 py-2.5 ${viewMode === "grid" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#64748B]"}`} data-testid="button-grid-view">
                      <Grid className="w-4 h-4" />
                    </button>
                    <button onClick={() => setViewMode("list")} className={`px-2.5 py-2.5 ${viewMode === "list" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "text-[#64748B]"}`} data-testid="button-list-view">
                      <List className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {showFilters && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="mb-4 overflow-hidden">
                  <div className="bg-[#0F1923] border border-[#1A2942] rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-[#94A3B8] mb-2 block">Rarity</label>
                        <div className="flex flex-wrap gap-1.5">
                          {(["All", "Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"] as const).map(r => (
                            <button
                              key={r}
                              onClick={() => setRarityFilter(r)}
                              className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
                                rarityFilter === r
                                  ? r === "All" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : `${RARITY_CONFIG[r as Rarity].bg} ${RARITY_CONFIG[r as Rarity].color}`
                                  : "bg-[#1A2942] text-[#64748B] hover:text-white"
                              }`}
                              data-testid={`filter-rarity-${r}`}
                            >
                              {r}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="text-xs text-[#94A3B8] mb-2 block">Element</label>
                        <div className="flex flex-wrap gap-1.5">
                          <button onClick={() => setElementFilter("All")} className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${elementFilter === "All" ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "bg-[#1A2942] text-[#64748B] hover:text-white"}`}>All</button>
                          {ELEMENTS.slice(0, 12).map(el => (
                            <button
                              key={el}
                              onClick={() => setElementFilter(el)}
                              className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${elementFilter === el ? "bg-[#00D4FF]/20 text-[#00D4FF]" : "bg-[#1A2942] text-[#64748B] hover:text-white"}`}
                              data-testid={`filter-element-${el}`}
                            >
                              {el}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {loadingMarketplace ? (
                <div className="text-center py-20">
                  <RefreshCw className="w-8 h-8 text-[#00D4FF] mx-auto mb-3 animate-spin" />
                  <p className="text-[#94A3B8]">Loading marketplace...</p>
                </div>
              ) : filteredMarketplace.length === 0 ? (
                <div className="text-center py-20">
                  <Image className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                  <p className="text-[#64748B]">No NFTs match your filters</p>
                </div>
              ) : viewMode === "grid" ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {filteredMarketplace.map(nft => (
                    <NFTCard key={nft.id} nft={nft} onSelect={() => handleSelectNFT(nft)} onBuy={() => handleBuyClick(nft)} />
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredMarketplace.map(nft => (
                    <NFTListItem key={nft.id} nft={nft} onSelect={() => handleSelectNFT(nft)} onBuy={() => handleBuyClick(nft)} />
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "my-nfts" && (
            <motion.div key="my-nfts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {!user ? (
                <div className="text-center py-20">
                  <Shield className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                  <p className="text-[#94A3B8] mb-2">Sign in to view your NFT collection</p>
                  <p className="text-[#64748B] text-sm">Connect your account to manage your NFTs</p>
                </div>
              ) : loadingMyNFTs ? (
                <div className="text-center py-20">
                  <RefreshCw className="w-8 h-8 text-[#00D4FF] mx-auto mb-3 animate-spin" />
                  <p className="text-[#94A3B8]">Loading your NFTs...</p>
                </div>
              ) : myNFTsList.length === 0 ? (
                <div className="text-center py-20">
                  <Heart className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                  <p className="text-[#94A3B8] mb-2">No NFTs in your collection yet</p>
                  <p className="text-[#64748B] text-sm mb-4">Browse the marketplace or create your own</p>
                  <div className="flex gap-3 justify-center">
                    <Button onClick={() => setActiveTab("marketplace")} className="bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 hover:bg-[#00D4FF]/30" data-testid="button-browse-marketplace">
                      <ShoppingCart className="w-4 h-4 mr-1.5" /> Browse Marketplace
                    </Button>
                    <Button onClick={() => setActiveTab("create")} className="bg-[#00D4FF] text-black hover:bg-[#00D4FF]/90" data-testid="button-create-nft">
                      <Wand2 className="w-4 h-4 mr-1.5" /> Create NFT
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {myNFTsList.map(nft => (
                    <NFTCard
                      key={nft.id}
                      nft={nft}
                      onSelect={() => handleSelectNFT(nft)}
                      showListButton
                      onList={() => { setListingNFT(nft); setListPayoutCurrency(nft.blockchain || "btc"); setListPayoutWallet(""); setListWalletError(""); setShowListDialog(true); }}
                      onUnlist={() => handleUnlist(nft)}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "portfolio" && (
            <motion.div key="portfolio" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {!user ? (
                <div className="text-center py-20">
                  <Shield className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                  <p className="text-[#94A3B8] mb-2">Sign in to view your portfolio</p>
                  <p className="text-[#64748B] text-sm">Connect your account to track your NFT portfolio</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {portfolioStats && <PortfolioStats stats={portfolioStats} />}

                  <div className="grid lg:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <Heart className="w-5 h-5 text-[#00D4FF]" /> Your Collection
                      </h3>
                      {loadingMyNFTs ? (
                        <div className="text-center py-10">
                          <RefreshCw className="w-6 h-6 text-[#00D4FF] mx-auto mb-2 animate-spin" />
                          <p className="text-[#94A3B8] text-sm">Loading...</p>
                        </div>
                      ) : myNFTsList.length === 0 ? (
                        <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-8 text-center">
                          <Image className="w-10 h-10 text-[#1A2942] mx-auto mb-2" />
                          <p className="text-[#94A3B8] text-sm mb-3">No NFTs yet</p>
                          <div className="flex gap-2 justify-center">
                            <Button onClick={() => setActiveTab("marketplace")} className="bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30 text-xs" data-testid="button-portfolio-browse">
                              Browse Marketplace
                            </Button>
                            <Button onClick={() => setActiveTab("create")} className="bg-[#00D4FF] text-black text-xs" data-testid="button-portfolio-create">
                              Create NFT
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-3">
                          {myNFTsList.slice(0, 6).map(nft => (
                            <NFTCard
                              key={nft.id}
                              nft={nft}
                              onSelect={() => handleSelectNFT(nft)}
                              showListButton
                              onList={() => { setListingNFT(nft); setListPayoutCurrency(nft.blockchain || "btc"); setListPayoutWallet(""); setListWalletError(""); setShowListDialog(true); }}
                              onUnlist={() => handleUnlist(nft)}
                            />
                          ))}
                          {myNFTsList.length > 6 && (
                            <button onClick={() => setActiveTab("my-nfts")} className="bg-[#0F1923] border border-[#1A2942] rounded-xl flex items-center justify-center p-4 hover:border-[#00D4FF]/30 transition-all" data-testid="button-view-all-nfts">
                              <span className="text-[#00D4FF] text-sm font-medium">View All {myNFTsList.length} NFTs</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    <div>
                      <SellerPaymentGuide />
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "create" && (
            <motion.div key="create" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {!user ? (
                <div className="text-center py-20">
                  <Shield className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                  <p className="text-[#94A3B8] mb-2">Sign in to create NFTs</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <AINFTGenerator
                    onNFTCreated={() => setActiveTab("my-nfts")}
                    showPackages={() => setShowAiPackages(true)}
                  />
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "wallet" && (
            <motion.div key="wallet" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-6">
                  <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-[#00D4FF]" /> Connect Your Wallet
                  </h2>
                  <p className="text-[#94A3B8] text-sm mb-6">To sell NFTs and receive cryptocurrency payments, you need to connect a wallet address. When a buyer purchases your NFT, the payment will be processed through our secure payment system and funds will be available in your connected wallet.</p>

                  <div className="space-y-4">
                    <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-4">
                      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#00D4FF]/20 text-[#00D4FF] text-xs flex items-center justify-center font-bold">1</span>
                        Choose Your Blockchain
                      </h3>
                      <p className="text-[#94A3B8] text-sm">Select which blockchain network you want to receive payments on. This determines which wallet you'll need. Popular choices:</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-3">
                        {SUPPORTED_CRYPTOS.slice(0, 6).map(chain => (
                          <div key={chain.id} className="bg-[#161B22] border border-[#1A2942] rounded-lg p-3 text-center">
                            <span className="text-2xl">{chain.icon}</span>
                            <p className="text-white text-sm font-medium mt-1">{chain.name}</p>
                            <p className="text-[#64748B] text-xs">{chain.symbol}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-4">
                      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#00D4FF]/20 text-[#00D4FF] text-xs flex items-center justify-center font-bold">2</span>
                        Set Up Your Wallet
                      </h3>
                      <p className="text-[#94A3B8] text-sm mb-3">Download and set up a wallet for your chosen blockchain:</p>
                      <div className="space-y-2 text-sm text-[#94A3B8]">
                        <div className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" /><span><strong className="text-white">Solana (SOL)</strong>: Phantom Wallet (phantom.app) or Solflare (solflare.com)</span></div>
                        <div className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" /><span><strong className="text-white">Ethereum (ETH)</strong>: MetaMask (metamask.io) or Trust Wallet</span></div>
                        <div className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" /><span><strong className="text-white">BNB Smart Chain</strong>: MetaMask with BSC network or Trust Wallet</span></div>
                        <div className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" /><span><strong className="text-white">Polygon (MATIC)</strong>: MetaMask with Polygon network</span></div>
                        <div className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" /><span><strong className="text-white">Bitcoin (BTC)</strong>: Electrum, Ledger, or any BTC wallet</span></div>
                      </div>
                    </div>

                    <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-4">
                      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#00D4FF]/20 text-[#00D4FF] text-xs flex items-center justify-center font-bold">3</span>
                        Enter Your Wallet Address
                      </h3>
                      <p className="text-[#94A3B8] text-sm mb-3">When creating an NFT, paste your wallet address in the "Your Wallet Address" field. This is where you'll receive funds when someone buys your NFT.</p>
                      <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 text-sm text-yellow-400">
                        <strong>Important:</strong> Always double-check your wallet address. Payments sent to the wrong address cannot be recovered. Never share your private key or seed phrase.
                      </div>
                    </div>

                    <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-4">
                      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#00D4FF]/20 text-[#00D4FF] text-xs flex items-center justify-center font-bold">4</span>
                        How Payments Work
                      </h3>
                      <div className="space-y-2 text-sm text-[#94A3B8]">
                        <p><ArrowRight className="w-3 h-3 inline text-[#00D4FF] mr-1" /> Buyer selects your NFT and chooses a cryptocurrency to pay with</p>
                        <p><ArrowRight className="w-3 h-3 inline text-[#00D4FF] mr-1" /> Payment is processed securely through our payment provider</p>
                        <p><ArrowRight className="w-3 h-3 inline text-[#00D4FF] mr-1" /> Once confirmed, the NFT is transferred to the buyer</p>
                        <p><ArrowRight className="w-3 h-3 inline text-[#00D4FF] mr-1" /> Funds are available in your wallet on your chosen blockchain</p>
                        <p><ArrowRight className="w-3 h-3 inline text-[#00D4FF] mr-1" /> Every NFT is one-of-one - once sold, it's exclusively owned by the buyer</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-6">
                  <h2 className="text-xl font-bold text-white mb-4">For Platform Owner: NOWPayments Setup</h2>
                  <div className="space-y-3 text-sm text-[#94A3B8]">
                    <p>The NFT marketplace uses NOWPayments to process cryptocurrency payments. To collect funds from NFT sales:</p>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Go to <strong className="text-white">nowpayments.io</strong> and create an account</li>
                      <li>In Dashboard, go to <strong className="text-white">Settings &gt; Payout Wallet</strong></li>
                      <li>Add your wallet address for each cryptocurrency you want to accept</li>
                      <li>Configure the <strong className="text-white">IPN Callback URL</strong> to your deployed site URL + <code className="text-[#00D4FF]">/api/crypto/nft-webhook</code></li>
                      <li>Your API Key and IPN Secret are already configured in this application</li>
                      <li>NOWPayments automatically converts and forwards funds to your configured wallet</li>
                    </ol>
                    <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-blue-400 mt-3">
                      <strong>Tip:</strong> NOWPayments supports 300+ cryptocurrencies and handles conversion. You only need to set up one payout wallet per blockchain you want to receive on.
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "migrate" && (
            <motion.div key="migrate" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-4xl mx-auto space-y-6">
                <div className="grid lg:grid-cols-2 gap-6">
                  <div>
                    {user ? (
                      <MigrationImportForm
                        onMigrate={(data) => {
                          migrateMutation.mutate(data, {
                            onSuccess: () => {
                              toast({ title: "NFT Imported!", description: `"${data.name}" has been imported to your collection. You can now list it for sale.` });
                              setActiveTab("my-nfts");
                            },
                            onError: (err: any) => {
                              toast({ title: "Import Failed", description: err.message, variant: "destructive" });
                            },
                          });
                        }}
                        isPending={migrateMutation.isPending}
                        supportedChains={SUPPORTED_CRYPTOS}
                      />
                    ) : (
                      <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-8 text-center">
                        <Shield className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                        <p className="text-[#94A3B8] mb-2">Sign in to import NFTs</p>
                        <p className="text-[#64748B] text-sm">Connect your account to migrate NFTs from other networks</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-6">
                    <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-6">
                      <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <ExternalLink className="w-5 h-5 text-[#00D4FF]" /> Export to External Chains
                      </h2>
                      <p className="text-[#94A3B8] text-sm mb-4">Move Alpha Unlimited NFTs to external blockchains:</p>
                      <div className="space-y-3">
                        <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-3">
                          <h3 className="text-white font-semibold text-sm mb-2">Supported Migration Paths</h3>
                          <div className="space-y-1.5 text-xs text-[#94A3B8]">
                            <div className="flex items-center gap-2"><span className="text-base">◎</span> <strong className="text-white">Solana</strong> - Metaplex / Magic Eden</div>
                            <div className="flex items-center gap-2"><span className="text-base">Ξ</span> <strong className="text-white">Ethereum</strong> - OpenSea / Rarible</div>
                            <div className="flex items-center gap-2"><span className="text-base">⬡</span> <strong className="text-white">Polygon</strong> - OpenSea (gas-free)</div>
                            <div className="flex items-center gap-2"><span className="text-base">◆</span> <strong className="text-white">BNB Chain</strong> - tofuNFT / PancakeSwap</div>
                          </div>
                        </div>
                        <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-3">
                          <h3 className="text-white font-semibold text-sm mb-2">How to Export</h3>
                          <div className="space-y-1.5 text-xs text-[#94A3B8]">
                            <p><span className="text-[#00D4FF] font-bold">1.</span> Go to "My NFTs" and select the NFT</p>
                            <p><span className="text-[#00D4FF] font-bold">2.</span> Export metadata (JSON + image)</p>
                            <p><span className="text-[#00D4FF] font-bold">3.</span> Upload image to IPFS (nft.storage or Pinata)</p>
                            <p><span className="text-[#00D4FF] font-bold">4.</span> Create NFT on your chosen marketplace</p>
                            <p><span className="text-[#00D4FF] font-bold">5.</span> Pay gas fee to mint on-chain</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                      <h3 className="text-yellow-400 font-semibold text-sm mb-2">Important Notes</h3>
                      <div className="space-y-1 text-xs text-yellow-300/80">
                        <p>- Migrating to/from a blockchain may require gas fees</p>
                        <p>- Once migrated, the NFT is governed by that blockchain's smart contract</p>
                        <p>- Imported NFTs can be listed for sale on Alpha Unlimited marketplace</p>
                        <p>- Screenshot protection only applies while on this platform</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "staking" && (
            <motion.div key="staking" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-5xl mx-auto">
                {user ? (
                  <NFTStakingSection
                    stakes={userStakes.map((s: any) => ({
                      ...s,
                      nft: [...myNFTsList, ...marketplaceNFTs].find((n: NFT) => n.id === s.nftId),
                    }))}
                    onStake={(nftId) => {
                      stakeNFTMutation.mutate(nftId, {
                        onSuccess: () => toast({ title: "NFT Staked!", description: "Your NFT is now earning rewards." }),
                        onError: (err: any) => toast({ title: "Staking Failed", description: err.message, variant: "destructive" }),
                      });
                    }}
                    onUnstake={(nftId) => {
                      unstakeNFTMutation.mutate(nftId, {
                        onSuccess: () => toast({ title: "NFT Unstaked", description: "Your NFT has been returned to your collection." }),
                        onError: (err: any) => toast({ title: "Unstake Failed", description: err.message, variant: "destructive" }),
                      });
                    }}
                    onClaim={(nftId) => {
                      claimRewardsMutation.mutate(nftId, {
                        onSuccess: (data: any) => toast({ title: "Rewards Claimed!", description: `You claimed $${data?.claimedAmount?.toFixed(2) || "0.00"} in rewards.` }),
                        onError: (err: any) => toast({ title: "Claim Failed", description: err.message, variant: "destructive" }),
                      });
                    }}
                    stakePending={stakeNFTMutation.isPending}
                    unstakePending={unstakeNFTMutation.isPending}
                    claimPending={claimRewardsMutation.isPending}
                  />
                ) : (
                  <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-8 text-center">
                    <Lock className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                    <p className="text-[#94A3B8] mb-2">Sign in to access NFT staking</p>
                    <p className="text-[#64748B] text-sm">Stake your NFTs to earn passive rewards based on rarity</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "strategies" && (
            <motion.div key="strategies" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-6xl mx-auto">
                {user ? (
                  <StrategyBuilder
                    strategies={strategies}
                    onSave={(data) => {
                      saveStrategyMutation.mutate(data, {
                        onSuccess: () => toast({ title: "Strategy Saved!", description: `"${data.name}" has been saved successfully.` }),
                        onError: (err: any) => toast({ title: "Save Failed", description: err.message, variant: "destructive" }),
                      });
                    }}
                    onDelete={(id) => {
                      deleteStrategyMutation.mutate(id, {
                        onSuccess: () => toast({ title: "Strategy Deleted", description: "The strategy has been removed." }),
                        onError: (err: any) => toast({ title: "Delete Failed", description: err.message, variant: "destructive" }),
                      });
                    }}
                    savePending={saveStrategyMutation.isPending}
                    deletePending={deleteStrategyMutation.isPending}
                  />
                ) : (
                  <div className="bg-[#0F1923] border border-[#1A2942] rounded-xl p-8 text-center">
                    <Sparkles className="w-12 h-12 text-[#1A2942] mx-auto mb-3" />
                    <p className="text-[#94A3B8] mb-2">Sign in to create trading strategies</p>
                    <p className="text-[#64748B] text-sm">Build custom strategies using a visual drag-and-drop interface</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "community" && (
            <motion.div key="community" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-4xl mx-auto">
                <CommunityForum />
              </div>
            </motion.div>
          )}

          {activeTab === "rewards" && (
            <motion.div key="rewards" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-6">
                <GamifiedRewardsPanel />
                <UserFractionsPanel />
              </div>
            </motion.div>
          )}

          {activeTab === "dex" && (
            <motion.div key="dex" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-4xl mx-auto">
                <DEXProtocolsSection />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {showP2PBuy && (
          <Dialog open={!!showP2PBuy} onOpenChange={() => setShowP2PBuy(null)}>
            <DialogContent className="bg-transparent border-none shadow-none p-0 max-w-md">
              <P2PBuyModal nft={showP2PBuy} onClose={() => setShowP2PBuy(null)} />
            </DialogContent>
          </Dialog>
        )}

        {showFractional && (
          <Dialog open={!!showFractional} onOpenChange={() => setShowFractional(null)}>
            <DialogContent className="bg-transparent border-none shadow-none p-0 max-w-md">
              <FractionalOwnershipCard nft={showFractional} onClose={() => setShowFractional(null)} />
            </DialogContent>
          </Dialog>
        )}

        <Dialog open={showDetail} onOpenChange={setShowDetail}>
          <DialogContent className="bg-[#0F1923] border border-[#1A2942] max-w-2xl max-h-[90vh] overflow-y-auto">
            {selectedNFT && (() => {
              const rc = RARITY_CONFIG[(selectedNFT.rarity as Rarity) || "Common"] || RARITY_CONFIG.Common;
              const RIcon = rc.icon;
              const blockchainInfo = SUPPORTED_CRYPTOS.find(c => c.id === selectedNFT.blockchain) || { icon: "◎", name: "Solana", symbol: "SOL" };
              return (
                <>
                  <DialogHeader>
                    <DialogTitle className="text-white flex items-center gap-2">
                      <RIcon className={`w-5 h-5 ${rc.color}`} /> {selectedNFT.name}
                    </DialogTitle>
                  </DialogHeader>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="aspect-square rounded-xl overflow-hidden border border-[#1A2942]">
                      <DRMCanvas imageUrl={getNFTImage(selectedNFT)} className="w-full h-full" />
                    </div>
                    <div className="space-y-4">
                      <div>
                        <p className="text-[#94A3B8] text-sm mb-1">Description</p>
                        <p className="text-white text-sm">{selectedNFT.description}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-[#0D1117] rounded-lg p-3">
                          <p className="text-[#64748B] text-xs">Rarity</p>
                          <p className={`${rc.color} text-sm font-bold`}>{selectedNFT.rarity}</p>
                        </div>
                        <div className="bg-[#0D1117] rounded-lg p-3">
                          <p className="text-[#64748B] text-xs">Element</p>
                          <p className="text-white text-sm font-bold">{selectedNFT.element || "Alpha"}</p>
                        </div>
                        <div className="bg-[#0D1117] rounded-lg p-3">
                          <p className="text-[#64748B] text-xs">Blockchain</p>
                          <p className="text-white text-sm font-bold">{blockchainInfo.icon} {blockchainInfo.name}</p>
                        </div>
                        <div className="bg-[#0D1117] rounded-lg p-3">
                          <p className="text-[#64748B] text-xs">Edition</p>
                          <p className="text-white text-sm font-bold">1 of 1</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[#64748B] text-xs">Price</p>
                          <p className="text-[#00D4FF] text-2xl font-bold">${selectedNFT.priceUSD}</p>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-[#94A3B8]">
                          <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5" /> {selectedNFT.likes}</span>
                          <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {selectedNFT.views}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-[#64748B] text-xs mb-1">Creator</p>
                        <p className="text-white text-sm">{selectedNFT.creatorUsername || "AlphaGenesis"}</p>
                      </div>
                      {selectedNFT.isSold ? (
                        <div className="bg-gray-800/50 border border-gray-600/30 rounded-lg p-3 text-center">
                          <p className="text-gray-300 font-bold tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif' }}>SOLD</p>
                          <p className="text-gray-400 text-xs mt-1">This NFT has been purchased</p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex gap-2">
                            <Button
                              onClick={() => { setShowDetail(false); setShowP2PBuy(selectedNFT); }}
                              className="flex-1 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold"
                              data-testid="button-buy-detail"
                            >
                              <Wallet className="w-4 h-4 mr-1.5" /> Buy with Crypto
                            </Button>
                            <Button
                              onClick={() => { likeMutation.mutate(selectedNFT.id); toast({ title: "Liked!" }); }}
                              className="bg-[#1A2942] text-[#94A3B8] hover:text-red-400"
                              data-testid="button-like-detail"
                            >
                              <Heart className="w-4 h-4" />
                            </Button>
                            <Button
                              onClick={() => handleShare(selectedNFT)}
                              className="bg-[#1A2942] text-[#94A3B8] hover:text-[#00D4FF]"
                              data-testid="button-share-detail"
                            >
                              <Share2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <Button
                            onClick={() => { setShowDetail(false); setShowFractional(selectedNFT); }}
                            className="w-full bg-[#1A2942] text-[#00D4FF] border border-[#00D4FF]/30 font-bold text-xs hover:bg-[#00D4FF]/10"
                            data-testid="button-buy-fraction"
                          >
                            <span className="mr-1">📊</span> Buy Fractional Shares
                          </Button>
                        </div>
                      )}
                      {user && (
                        <div className="flex gap-2 pt-2 border-t border-[#1A2942]">
                          <Button
                            onClick={() => {
                              assessNFTMutation.mutate(selectedNFT.id, {
                                onSuccess: (data: any) => toast({ title: "Assessment Complete", description: `Rarity Score: ${data.rarityScore}/100, Est. Value: $${data.estimatedValueUSD}` }),
                                onError: (err: any) => toast({ title: "Assessment Failed", description: err.message, variant: "destructive" }),
                              });
                            }}
                            disabled={assessNFTMutation.isPending}
                            className="flex-1 bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30 text-xs"
                            data-testid="button-assess-detail"
                          >
                            {assessNFTMutation.isPending ? "Analyzing..." : "AI Assess Value"}
                          </Button>
                          {!selectedNFT.isListed && selectedNFT.ownerId === user.id && (
                            <Button
                              onClick={() => {
                                stakeNFTMutation.mutate(selectedNFT.id, {
                                  onSuccess: () => { toast({ title: "NFT Staked!", description: "Your NFT is now earning rewards." }); setShowDetail(false); },
                                  onError: (err: any) => toast({ title: "Staking Failed", description: err.message, variant: "destructive" }),
                                });
                              }}
                              disabled={stakeNFTMutation.isPending}
                              className="flex-1 bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 text-xs"
                              data-testid="button-stake-detail"
                            >
                              <Lock className="w-3 h-3 mr-1" /> Stake for Rewards
                            </Button>
                          )}
                          {selectedNFT.ownerId === user.id && (selectedNFT as any).mintStatus !== "minted" && (
                            <Button
                              onClick={() => openMintDialog(selectedNFT)}
                              className="flex-1 bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/30 hover:bg-[#FFD700]/30 text-xs font-bold"
                              data-testid="button-mint-detail"
                            >
                              <Globe className="w-3 h-3 mr-1" /> Mint On-Chain
                            </Button>
                          )}
                          {(selectedNFT as any).mintStatus === "minted" && (
                            <div className="flex-1 bg-green-500/10 text-green-400 border border-green-500/30 rounded-md px-3 py-1.5 text-xs text-center font-bold flex items-center justify-center gap-1">
                              <CheckCircle className="w-3 h-3" /> Minted On-Chain
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </>
              );
            })()}
          </DialogContent>
        </Dialog>

        <Dialog open={showListDialog} onOpenChange={setShowListDialog}>
          <DialogContent className="bg-[#0F1923] border border-[#1A2942] max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">List NFT for Sale</DialogTitle>
            </DialogHeader>
            {listingNFT && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-[#0D1117] rounded-lg p-3">
                  <div className="w-16 h-16 rounded-lg overflow-hidden">
                    <DRMCanvas imageUrl={getNFTImage(listingNFT)} className="w-full h-full" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">{listingNFT.name}</p>
                    <p className="text-[#94A3B8] text-xs">{listingNFT.rarity}</p>
                  </div>
                </div>
                <ListingPriceSuggestion nftId={listingNFT.id} onApply={(price) => setListPrice(price.toString())} />
                <div>
                  <label className="text-xs text-[#94A3B8] mb-1 block">Sale Price (USD)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                    <input
                      type="number"
                      value={listPrice}
                      onChange={e => setListPrice(e.target.value)}
                      placeholder="Enter price in USD"
                      className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg pl-9 pr-4 py-2.5 text-white text-sm placeholder-[#64748B] focus:outline-none focus:border-[#00D4FF]/50"
                      data-testid="input-list-price"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-[#94A3B8] mb-1 block">You will be paid in</label>
                  <div className="flex items-center gap-2 bg-[#0D1117] border border-[#FFD700]/30 rounded-lg px-3 py-2.5" data-testid="list-auto-payout-display">
                    <span className="text-lg">{SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.icon || "◎"}</span>
                    <span className="text-white text-sm font-medium">{SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.name || listPayoutCurrency} ({SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.symbol || listPayoutCurrency})</span>
                    <span className="ml-auto text-[#FFD700] text-xs">Matches NFT blockchain</span>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-[#94A3B8] mb-1 block">
                    Your {SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.name || ""} Wallet Address *
                  </label>
                  <input
                    type="text"
                    value={listPayoutWallet}
                    onChange={e => {
                      setListPayoutWallet(e.target.value);
                      if (listWalletError) {
                        const v = validateWalletAddress(listPayoutCurrency, e.target.value);
                        setListWalletError(v.valid ? "" : v.message);
                      }
                    }}
                    onBlur={() => {
                      if (listPayoutWallet.trim()) {
                        const v = validateWalletAddress(listPayoutCurrency, listPayoutWallet);
                        setListWalletError(v.valid ? "" : v.message);
                      }
                    }}
                    placeholder={PAYOUT_CURRENCIES.find(c => c.id === listPayoutCurrency)?.placeholder || `Enter ${SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.name || ""} wallet address...`}
                    className={`w-full bg-[#0D1117] border rounded-lg px-3 py-2.5 text-white text-sm placeholder-[#64748B] focus:outline-none ${
                      listWalletError ? "border-red-500 focus:border-red-400" : listPayoutWallet && !listWalletError ? "border-green-500/50 focus:border-green-400" : "border-[#1A2942] focus:border-[#FFD700]/50"
                    }`}
                    data-testid="input-list-payout-wallet"
                  />
                  {listWalletError && (
                    <div className="flex items-start gap-1.5 mt-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 mt-0.5 flex-shrink-0" />
                      <p className="text-red-400 text-xs" data-testid="text-list-wallet-error">{listWalletError}</p>
                    </div>
                  )}
                  {listPayoutWallet && !listWalletError && (
                    <div className="flex items-center gap-1.5 mt-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                      <p className="text-green-400 text-xs">Valid {SUPPORTED_CRYPTOS.find(c => c.id === listPayoutCurrency)?.name} address</p>
                    </div>
                  )}
                </div>

                <div className="bg-[#0D1117] border border-[#FFD700]/20 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-[#FFD700] mt-0.5 flex-shrink-0" />
                    <p className="text-[#FFD700]/80 text-xs leading-relaxed">
                      <span className="font-semibold text-[#FFD700]">Important:</span> Double-check your wallet address carefully. Any mistakes in the wallet address could result in permanent loss of funds. Make sure the address matches the selected cryptocurrency's blockchain. We are not responsible for funds sent to incorrect addresses.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0D1117] border border-[#00D4FF]/20 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <Percent className="w-4 h-4 text-[#00D4FF] mt-0.5 flex-shrink-0" />
                    <div className="text-xs leading-relaxed">
                      <p className="text-[#00D4FF] font-semibold mb-1">Transaction Fee Disclosure</p>
                      <p className="text-gray-400">
                        A <span className="text-white font-medium">0.5% transaction fee</span> is applied by <span className="text-white font-medium">NOWPayments</span> (the third-party payment processor) to all NFT transactions and is deducted from the amount you receive as the seller.
                        {listPrice && !isNaN(parseFloat(listPrice)) && parseFloat(listPrice) > 0 && (
                          <span> For a ${parseFloat(listPrice).toFixed(2)} listing, the fee would be approximately <span className="text-yellow-400 font-medium">${(parseFloat(listPrice) * 0.005).toFixed(2)}</span>, and you would receive approximately <span className="text-green-400 font-medium">${(parseFloat(listPrice) * 0.995).toFixed(2)}</span>.</span>
                        )}
                        {" "}This fee is <span className="text-white font-medium">NOT</span> charged by Alpha Unlimited Trading. See our <a href="/disclaimer" className="text-[#00D4FF] hover:underline">Disclaimer</a> for full details.
                      </p>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleList}
                  disabled={listMutation.isPending || !listPrice || !listPayoutWallet || !!listWalletError}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-black font-bold py-4"
                  data-testid="button-confirm-list"
                >
                  {listMutation.isPending ? (
                    <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Listing...</>
                  ) : (
                    <><Tag className="w-4 h-4 mr-2" /> List for ${listPrice || "0"}</>
                  )}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
          <DialogContent className="bg-[#0F1923] border border-[#1A2942] max-w-md">
            <DialogHeader>
              <DialogTitle className="text-white">Share NFT</DialogTitle>
            </DialogHeader>
            {selectedNFT && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-[#0D1117] rounded-lg p-3">
                  <div className="w-16 h-16 rounded-lg overflow-hidden">
                    <DRMCanvas imageUrl={getNFTImage(selectedNFT)} className="w-full h-full" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">{selectedNFT.name}</p>
                    <p className="text-[#94A3B8] text-xs">by {selectedNFT.creatorUsername || "AlphaGenesis"}</p>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-[#94A3B8] mb-1 block">Share Link</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      readOnly
                      value={`${window.location.origin}/alpha-trading/nft?view=${selectedNFT.id}`}
                      className="flex-1 bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm"
                    />
                    <Button onClick={copyShareLink} className="bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30" data-testid="button-copy-share">
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex gap-2">
                  <a href={`https://twitter.com/intent/tweet?text=Check out this NFT: ${selectedNFT.name}&url=${encodeURIComponent(`${window.location.origin}/alpha-trading/nft?view=${selectedNFT.id}`)}`}
                    target="_blank" rel="noopener noreferrer"
                    className="flex-1 bg-[#1DA1F2]/20 text-[#1DA1F2] border border-[#1DA1F2]/30 rounded-lg px-3 py-2 text-center text-sm font-medium hover:bg-[#1DA1F2]/30 transition-all">
                    Share on X
                  </a>
                  <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`${window.location.origin}/alpha-trading/nft?view=${selectedNFT.id}`)}`}
                    target="_blank" rel="noopener noreferrer"
                    className="flex-1 bg-[#1877F2]/20 text-[#1877F2] border border-[#1877F2]/30 rounded-lg px-3 py-2 text-center text-sm font-medium hover:bg-[#1877F2]/30 transition-all">
                    Share on Facebook
                  </a>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
        <Dialog open={showMintDialog} onOpenChange={setShowMintDialog}>
          <DialogContent className="bg-[#0F1923] border border-[#1A2942] max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-[#FFD700]" /> Mint NFT On-Chain
              </DialogTitle>
            </DialogHeader>
            {mintingNFT && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-[#0D1117] border border-[#1A2942] rounded-lg p-3">
                  <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={mintingNFT.imageUrl || "/placeholder-nft.png"} alt={mintingNFT.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-sm">{mintingNFT.name}</h4>
                    <p className="text-[#64748B] text-xs">{mintingNFT.rarity} | {SUPPORTED_CRYPTOS.find(c => c.id === mintingNFT.blockchain)?.name || "Solana"}</p>
                    <p className="text-[#00D4FF] text-sm font-bold">${mintingNFT.priceUSD}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${mintStep === "prepare" ? "bg-[#FFD700] text-black" : "bg-[#1A2942] text-[#94A3B8]"}`}>1</div>
                  <div className={`flex-1 h-0.5 ${mintStep !== "prepare" ? "bg-[#FFD700]" : "bg-[#1A2942]"}`} />
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${mintStep === "signing" ? "bg-[#FFD700] text-black" : mintStep === "confirm" || mintStep === "done" ? "bg-[#FFD700] text-black" : "bg-[#1A2942] text-[#94A3B8]"}`}>2</div>
                  <div className={`flex-1 h-0.5 ${mintStep === "confirm" || mintStep === "done" ? "bg-[#FFD700]" : "bg-[#1A2942]"}`} />
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${mintStep === "done" ? "bg-green-500 text-black" : "bg-[#1A2942] text-[#94A3B8]"}`}>3</div>
                </div>

                {mintStep === "prepare" && (
                  <div className="space-y-3">
                    <p className="text-[#94A3B8] text-sm">Enter your wallet address to prepare metadata and upload to IPFS.</p>
                    <div>
                      <label className="text-[#64748B] text-xs mb-1 block">Wallet Address</label>
                      <input
                        value={mintWallet}
                        onChange={e => setMintWallet(e.target.value)}
                        placeholder="Enter your wallet address..."
                        className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#FFD700]/50 outline-none"
                        data-testid="input-mint-wallet"
                      />
                    </div>
                    <Button
                      onClick={handlePrepareMint}
                      disabled={isMinting || !mintWallet.trim()}
                      className="w-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-bold"
                      data-testid="button-prepare-mint"
                    >
                      {isMinting ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                      {isMinting ? "Preparing..." : "Upload to IPFS & Prepare"}
                    </Button>
                  </div>
                )}

                {mintStep === "signing" && mintResult && (
                  <div className="space-y-3">
                    <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
                      <p className="text-green-400 text-sm font-bold flex items-center gap-1"><CheckCircle className="w-4 h-4" /> Metadata uploaded to IPFS</p>
                      {mintResult.metadataUri && (
                        <p className="text-[#64748B] text-xs mt-1 break-all">URI: {mintResult.metadataUri}</p>
                      )}
                    </div>
                    <div className="bg-[#0D1117] border border-[#1A2942] rounded-lg p-3">
                      <p className="text-[#94A3B8] text-sm mb-2">Now connect your wallet and sign the mint transaction. After signing, paste the transaction hash below.</p>
                      {mintResult.mintInstructions && (
                        <div className="bg-[#161B22] rounded p-2 mb-2">
                          <p className="text-[#FFD700] text-xs font-bold mb-1">Instructions:</p>
                          <p className="text-[#94A3B8] text-xs whitespace-pre-wrap">{typeof mintResult.mintInstructions === "string" ? mintResult.mintInstructions : JSON.stringify(mintResult.mintInstructions, null, 2)}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="text-[#64748B] text-xs mb-1 block">Transaction Hash</label>
                      <input
                        value={mintTxHash}
                        onChange={e => setMintTxHash(e.target.value)}
                        placeholder="Paste transaction hash after signing..."
                        className="w-full bg-[#0D1117] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#FFD700]/50 outline-none"
                        data-testid="input-mint-txhash"
                      />
                    </div>
                    <Button
                      onClick={() => { setMintStep("confirm"); handleConfirmMint(); }}
                      disabled={isMinting || !mintTxHash.trim()}
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold"
                      data-testid="button-confirm-mint"
                    >
                      {isMinting ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                      {isMinting ? "Confirming..." : "Confirm Mint"}
                    </Button>
                  </div>
                )}

                {mintStep === "done" && (
                  <div className="space-y-3 text-center">
                    <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-6">
                      <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
                      <h3 className="text-green-400 text-lg font-bold">Successfully Minted!</h3>
                      <p className="text-[#94A3B8] text-sm mt-2">Your NFT is now permanently on the blockchain.</p>
                      {mintResult?.transactionHash && (
                        <p className="text-[#64748B] text-xs mt-2 break-all">TX: {mintResult.transactionHash}</p>
                      )}
                      {mintResult?.explorerUrl && (
                        <a href={mintResult.explorerUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[#00D4FF] text-xs mt-2 hover:underline">
                          <ExternalLink className="w-3 h-3" /> View on Explorer
                        </a>
                      )}
                    </div>
                    <Button
                      onClick={() => setShowMintDialog(false)}
                      className="w-full bg-[#1A2942] text-white"
                      data-testid="button-close-mint"
                    >
                      Close
                    </Button>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showAiPackages} onOpenChange={setShowAiPackages}>
          <DialogContent className="bg-[#0F1923] border border-[#1A2942] max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-[#FFD700]" /> AI NFT Credit Packages
              </DialogTitle>
            </DialogHeader>
            <p className="text-[#94A3B8] text-sm mb-4">
              Purchase credits to generate unique AI-powered NFT artwork. Each credit creates one unique NFT using advanced AI image generation.
            </p>
            <div className="space-y-3">
              {aiPackages.map((pkg) => (
                <div key={pkg.id} className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-4 hover:border-[#FFD700]/30 transition-all" data-testid={`card-ai-package-${pkg.id}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-bold text-base">{pkg.name}</h4>
                      <p className="text-[#94A3B8] text-xs mt-0.5">{pkg.credits} AI-generated NFTs</p>
                      <p className="text-[#64748B] text-xs">${(pkg.priceUSD / pkg.credits).toFixed(2)}/NFT</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[#FFD700] font-bold text-lg">${pkg.priceUSD.toFixed(2)}</p>
                      <Button
                        onClick={() => handleAiCheckout(pkg.id)}
                        disabled={aiCheckoutMutation.isPending}
                        className="mt-2 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-semibold text-xs px-4 py-1.5 rounded-lg hover:opacity-90"
                        data-testid={`button-buy-${pkg.id}`}
                      >
                        {aiCheckoutMutation.isPending ? "Processing..." : "Buy Now"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-[#64748B] text-xs mt-3">
              Tax applied at checkout. Credits never expire. Prices subject to change.
            </p>
          </DialogContent>
        </Dialog>
      </div>
    </TradingPlatformLayout>
  );
}
