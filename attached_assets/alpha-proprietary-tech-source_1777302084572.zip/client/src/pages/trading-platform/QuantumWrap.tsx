/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha SafeSend Quantum Wrap™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - SafeSend Quantum Wrap™
 * - ML-KEM Transaction Encapsulation™
 * - Quantum-Resistant Address Binding™
 * - Post-Quantum Mempool Protection™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_QS_WRAP_PAGE_SEALED
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Shield, Lock, Send, CheckCircle, Layers, Key, Fingerprint, ArrowRight } from "lucide-react";

interface QuantumWrapResult {
  wrapId: string;
  originalTx: {
    to: string;
    from: string;
    value: string;
    chain: string;
  };
  quantumProtection: {
    encapsulationAlgorithm: string;
    keySize: number;
    latticeParameters: string;
    mempoolProtection: boolean;
    addressBindingVerified: boolean;
  };
  wrappedTransaction: {
    quantumSignature: string;
    encapsulatedKey: string;
    latticeProof: string;
    nistComplianceLevel: string;
  };
  securityMetrics: {
    quantumResistanceBits: number;
    classicalSecurityBits: number;
    protectionLevel: string;
    estimatedQuantumBreakTime: string;
  };
  status: string;
  timestamp: string;
}

export default function QuantumWrap() {
  const [toAddress, setToAddress] = useState("");
  const [fromAddress, setFromAddress] = useState("");
  const [value, setValue] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [wrapping, setWrapping] = useState(false);
  const [result, setResult] = useState<QuantumWrapResult | null>(null);

  const handleWrap = async () => {
    if (!toAddress || !fromAddress) return;
    setWrapping(true);
    setResult(null);
    try {
      const res = await fetch("/api/quantum/wrap/protect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: toAddress, from: fromAddress, value: value || "0", chain }),
      });
      const data = await res.json();
      setResult(data);
    } catch (e) { console.error(e); }
    setWrapping(false);
  };

  return (
    <TradingPlatformLayout title="SafeSend Quantum Wrap™" subtitle="ML-KEM Transaction Encapsulation & Post-Quantum Mempool Protection">
      <div className="space-y-6 p-4 max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30 mb-6">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Shield className="w-4 h-4" /> Quantum-Wrap a Transaction
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">From Address</label>
                  <Input
                    data-testid="input-wrap-from"
                    placeholder="Sender address (0x...)"
                    value={fromAddress}
                    onChange={(e) => setFromAddress(e.target.value)}
                    className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">To Address</label>
                  <Input
                    data-testid="input-wrap-to"
                    placeholder="Recipient address (0x...)"
                    value={toAddress}
                    onChange={(e) => setToAddress(e.target.value)}
                    className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Value (ETH/Native)</label>
                  <Input
                    data-testid="input-wrap-value"
                    placeholder="0.0"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Blockchain</label>
                  <select
                    data-testid="select-wrap-chain"
                    value={chain}
                    onChange={(e) => setChain(e.target.value)}
                    className="w-full bg-[#0a0a1a] border border-gray-700 text-white text-sm rounded-md px-3 py-2"
                  >
                    <option value="ethereum">Ethereum</option>
                    <option value="bsc">BSC</option>
                    <option value="polygon">Polygon</option>
                    <option value="arbitrum">Arbitrum</option>
                    <option value="solana">Solana</option>
                    <option value="base">Base</option>
                  </select>
                </div>
              </div>
              <Button
                data-testid="button-wrap-protect"
                onClick={handleWrap}
                disabled={wrapping || !toAddress || !fromAddress}
                className="w-full bg-[#d4af37] hover:bg-[#b8962e] text-black"
              >
                {wrapping ? "Generating Quantum Wrap..." : "Apply Quantum Wrap Protection"}
              </Button>
            </CardContent>
          </Card>

          {result && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex items-center justify-center gap-4 p-4">
                <div className="text-center">
                  <div className="text-xs text-gray-400">From</div>
                  <div className="text-xs text-gray-300 font-mono">{result.originalTx.from.substring(0, 10)}...</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-px w-8 bg-gray-600" />
                  <div className="p-2 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/50">
                    <Lock className="w-5 h-5 text-[#d4af37]" />
                  </div>
                  <div className="h-px w-8 bg-gray-600" />
                </div>
                <div className="text-center">
                  <div className="text-xs text-gray-400">To</div>
                  <div className="text-xs text-gray-300 font-mono">{result.originalTx.to.substring(0, 10)}...</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Key className="w-4 h-4" /> Quantum Protection
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Algorithm:</span>
                      <span className="text-gray-300">{result.quantumProtection.encapsulationAlgorithm}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Key Size:</span>
                      <span className="text-gray-300">{result.quantumProtection.keySize} bits</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Lattice Params:</span>
                      <span className="text-gray-300">{result.quantumProtection.latticeParameters}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Mempool Protection:</span>
                      <CheckCircle className={`w-4 h-4 ${result.quantumProtection.mempoolProtection ? 'text-green-400' : 'text-gray-500'}`} />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Address Binding:</span>
                      <CheckCircle className={`w-4 h-4 ${result.quantumProtection.addressBindingVerified ? 'text-green-400' : 'text-gray-500'}`} />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Fingerprint className="w-4 h-4" /> Wrapped Transaction
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div>
                      <span className="text-gray-400">Quantum Signature:</span>
                      <div className="text-gray-300 font-mono text-[10px] mt-1 break-all">{result.wrappedTransaction.quantumSignature.substring(0, 40)}...</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Encapsulated Key:</span>
                      <div className="text-gray-300 font-mono text-[10px] mt-1 break-all">{result.wrappedTransaction.encapsulatedKey.substring(0, 40)}...</div>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">NIST Level:</span>
                      <Badge variant="outline" className="text-green-400 border-green-400/30 text-[10px]">
                        {result.wrappedTransaction.nistComplianceLevel}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Layers className="w-4 h-4" /> Security Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Quantum Resistance:</span>
                      <span className="text-green-400 font-bold">{result.securityMetrics.quantumResistanceBits}-bit</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Classical Security:</span>
                      <span className="text-gray-300">{result.securityMetrics.classicalSecurityBits}-bit</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Protection Level:</span>
                      <Badge className="bg-green-600 text-[10px]">{result.securityMetrics.protectionLevel}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Break Time:</span>
                      <span className="text-gray-300">{result.securityMetrics.estimatedQuantumBreakTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Wrap Status:</span>
                      <Badge className="bg-[#d4af37] text-black text-[10px]">{result.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="p-3 bg-green-900/20 border border-green-500/30 rounded-lg text-center">
                <CheckCircle className="w-6 h-6 text-green-400 mx-auto mb-1" />
                <div className="text-sm text-green-400 font-bold">Transaction Quantum-Wrapped Successfully</div>
                <div className="text-xs text-gray-400 mt-1">Wrap ID: {result.wrapId}</div>
              </div>
            </motion.div>
          )}

          <div className="mt-6 p-4 bg-[#0a0a1a] rounded-lg border border-[#d4af37]/20">
            <h3 className="text-[#d4af37] text-sm font-bold mb-2">How SafeSend Quantum Wrap™ Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">ML-KEM Encapsulation</h4>
                <p>Wraps every outgoing transaction in a ML-KEM-1024 lattice-based key encapsulation. Even if ECDSA is broken by quantum computers, the wrapped transaction remains secure.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Mempool Protection</h4>
                <p>Protects transactions from quantum-enabled front-running while they sit in the mempool. Quantum-wrapped transactions cannot be decoded or manipulated by quantum adversaries pre-confirmation.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Address Binding</h4>
                <p>Cryptographically binds sender and receiver addresses using post-quantum lattice proofs. Prevents quantum-enabled address manipulation and man-in-the-middle attacks during transaction routing.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}
