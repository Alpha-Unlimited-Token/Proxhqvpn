/**
 * Alpha Unlimited Trading Platform - Home Page v2
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * This file contains proprietary platform content, UI/UX design, and references to
 * protected technologies including Quantum Market Genome Engine™ (QMGE) and all
 * associated proprietary trading technologies.
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  TrendingUp,
  BarChart3,
  Bot,
  Cpu,
  Wallet,
  Pickaxe,
  ArrowRight,
  Shield,
  Zap,
  Globe,
  ChevronDown,
  Brain,
  GraduationCap,
  Sparkles,
  Star,
  Quote,
  Send,
} from "lucide-react";

interface Testimonial {
  id: number;
  name: string;
  role?: string | null;
  rating: number;
  content: string;
  service?: string | null;
  isFeatured: boolean;
  createdAt: string;
}

function TestimonialsSection() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: items = [], isLoading } = useQuery<Testimonial[]>({ queryKey: ['/api/testimonials'] });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', role: '', email: '', rating: 5, content: '', service: '' });
  const submit = useMutation({
    mutationFn: async (payload: typeof form) => {
      const cleaned: any = { name: payload.name.trim(), rating: Number(payload.rating), content: payload.content.trim() };
      if (payload.role.trim())    cleaned.role    = payload.role.trim();
      if (payload.email.trim())   cleaned.email   = payload.email.trim();
      if (payload.service.trim()) cleaned.service = payload.service.trim();
      const r = await apiRequest('POST', '/api/testimonials', cleaned);
      return r.json();
    },
    onSuccess: (data) => {
      toast({ title: 'Thank you!', description: data.message || 'Your testimonial was submitted for review.' });
      setForm({ name: '', role: '', email: '', rating: 5, content: '', service: '' });
      setOpen(false);
      qc.invalidateQueries({ queryKey: ['/api/testimonials'] });
    },
    onError: (e: any) => toast({ title: 'Submission failed', description: e?.message || 'Please check your entries and try again.', variant: 'destructive' }),
  });

  return (
    <section className="px-4 pb-16" data-testid="section-testimonials">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-4 rounded-full bg-gradient-to-r from-[#a855f7]/10 to-[#00D4FF]/10 border border-[#a855f7]/30">
            <Quote size={16} className="text-[#a855f7]" />
            <span className="text-sm font-semibold text-[#a855f7]" style={{ fontFamily: 'Orbitron, sans-serif' }}>CLIENT TESTIMONIALS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3" style={{ fontFamily: 'Orbitron, sans-serif' }} data-testid="text-testimonials-heading">
            What Our Clients Say
          </h2>
          <p className="text-[#94A3B8] max-w-2xl mx-auto font-light">
            Real feedback from traders, investors, and victims-turned-recovered who've used Alpha Unlimited Trading services.
          </p>
        </div>

        {isLoading ? (
          <div className="text-center text-[#94A3B8]" data-testid="text-testimonials-loading">Loading testimonials…</div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-[#0F1729]/60 p-10 text-center" data-testid="empty-testimonials">
            <p className="text-[#94A3B8] mb-2">No testimonials posted yet.</p>
            <p className="text-sm text-[#64748B]">Be the first — share your experience using the form below.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {items.map(t => (
              <div key={t.id} className="rounded-2xl border border-white/10 bg-gradient-to-br from-[#0F1729]/80 to-[#0A1628]/80 p-6 hover:border-[#00D4FF]/30 transition-colors" data-testid={`card-testimonial-${t.id}`}>
                <div className="flex items-center gap-1 mb-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={16} className={i < t.rating ? 'text-[#FFB800] fill-[#FFB800]' : 'text-[#334155]'} />
                  ))}
                  {t.isFeatured && <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/30 uppercase tracking-wide">Featured</span>}
                </div>
                <p className="text-[#CBD5E1] text-sm leading-relaxed mb-4 line-clamp-6" data-testid={`text-testimonial-content-${t.id}`}>"{t.content}"</p>
                <div className="border-t border-white/5 pt-3">
                  <p className="text-white font-semibold text-sm" data-testid={`text-testimonial-name-${t.id}`}>{t.name}</p>
                  {t.role && <p className="text-[#94A3B8] text-xs">{t.role}</p>}
                  {t.service && <p className="text-[#00D4FF] text-xs mt-1">re: {t.service}</p>}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-10 flex flex-col items-center">
          {!open ? (
            <button
              onClick={() => setOpen(true)}
              className="px-8 py-4 bg-gradient-to-r from-[#a855f7] to-[#00D4FF] text-[#0A1628] font-bold rounded-2xl flex items-center gap-2 hover:-translate-y-1 active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(168,85,247,0.3)]"
              data-testid="button-open-testimonial-form"
            >
              <Send size={18} /> Write a Testimonial
            </button>
          ) : (
            <form
              className="w-full max-w-2xl rounded-2xl border border-white/10 bg-[#0F1729]/80 p-6 space-y-4"
              data-testid="form-testimonial"
              onSubmit={(e) => { e.preventDefault(); submit.mutate(form); }}
            >
              <h3 className="text-xl font-bold text-white" style={{ fontFamily: 'Orbitron, sans-serif' }}>Share Your Experience</h3>
              <p className="text-xs text-[#94A3B8]">All submissions are reviewed before being published.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input required maxLength={80} placeholder="Your name *" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="px-4 py-3 bg-[#0A1628] border border-white/10 rounded-xl text-white text-sm placeholder-[#64748B] focus:border-[#00D4FF] focus:outline-none" data-testid="input-testimonial-name" />
                <input maxLength={120} placeholder="Role / Title (optional)" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className="px-4 py-3 bg-[#0A1628] border border-white/10 rounded-xl text-white text-sm placeholder-[#64748B] focus:border-[#00D4FF] focus:outline-none" data-testid="input-testimonial-role" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input type="email" maxLength={200} placeholder="Email (kept private, optional)" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="px-4 py-3 bg-[#0A1628] border border-white/10 rounded-xl text-white text-sm placeholder-[#64748B] focus:border-[#00D4FF] focus:outline-none" data-testid="input-testimonial-email" />
                <input maxLength={120} placeholder="Service used (e.g. Forensic Recovery, AACC™)" value={form.service} onChange={e => setForm({ ...form, service: e.target.value })} className="px-4 py-3 bg-[#0A1628] border border-white/10 rounded-xl text-white text-sm placeholder-[#64748B] focus:border-[#00D4FF] focus:outline-none" data-testid="input-testimonial-service" />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#94A3B8]">Rating:</span>
                {[1,2,3,4,5].map(n => (
                  <button type="button" key={n} onClick={() => setForm({ ...form, rating: n })} className="p-1" data-testid={`button-rating-${n}`}>
                    <Star size={22} className={n <= form.rating ? 'text-[#FFB800] fill-[#FFB800]' : 'text-[#334155]'} />
                  </button>
                ))}
              </div>
              <textarea
                required minLength={20} maxLength={1500} rows={5}
                placeholder="Tell us about your experience (20–1500 characters)…"
                value={form.content}
                onChange={e => setForm({ ...form, content: e.target.value })}
                className="w-full px-4 py-3 bg-[#0A1628] border border-white/10 rounded-xl text-white text-sm placeholder-[#64748B] focus:border-[#00D4FF] focus:outline-none resize-none"
                data-testid="textarea-testimonial-content"
              />
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#64748B]">{form.content.length}/1500</span>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setOpen(false)} className="px-5 py-2.5 text-sm rounded-xl border border-white/10 text-[#94A3B8] hover:bg-white/5" data-testid="button-cancel-testimonial">Cancel</button>
                  <button type="submit" disabled={submit.isPending} className="px-6 py-2.5 text-sm rounded-xl bg-gradient-to-r from-[#a855f7] to-[#00D4FF] text-[#0A1628] font-semibold hover:-translate-y-0.5 active:scale-[0.98] transition-transform disabled:opacity-60" data-testid="button-submit-testimonial">
                    {submit.isPending ? 'Submitting…' : 'Submit Testimonial'}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

const STATS = [
  { value: "270+", label: "Cryptocurrencies", color: "#00D4FF" },
  { value: "32+", label: "Exchanges", color: "#a855f7" },
  { value: "20", label: "Proprietary Tools", color: "#00D4FF" },
  { value: "24/7", label: "AI Trading", color: "#22C55E" },
];

const CORE_FEATURES = [
  {
    icon: TrendingUp,
    title: "Trading Terminal",
    description: "Professional charts with 15+ indicators, AI signals, futures trading with up to 125x leverage, and real-time execution across 32+ exchanges.",
    href: "/terminal",
    color: "#00D4FF",
  },
  {
    icon: BarChart3,
    title: "Arbitrage Scanner",
    description: "Spot price differences across 10+ exchanges instantly and capitalize on market inefficiencies.",
    href: "/arbitrage",
    color: "#22C55E",
  },
  {
    icon: Bot,
    title: "AI Trading Bots",
    description: "14 automated strategies with long and short positions, futures support, and paper trading simulator.",
    href: "/terminal",
    color: "#A855F7",
  },
  {
    icon: Cpu,
    title: "Command Center",
    description: "Full AACC dashboard with all 20 proprietary technologies, futures/spot mode, signals, and analytics.",
    href: "/command-center",
    color: "#00D4FF",
  },
  {
    icon: Wallet,
    title: "Portfolio Tracker",
    description: "Multi-asset tracking with P&L visualization, performance metrics, and tax reporting tools.",
    href: "/terminal",
    color: "#a855f7",
  },
  {
    icon: Pickaxe,
    title: "Mining Center",
    description: "Connect mining hardware, monitor hashrates, and optimize your mining operations in real-time.",
    href: "/miner",
    color: "#00D4FF",
  },
  {
    icon: Brain,
    title: "AI News Sentiment",
    description: "Real-time crypto news analyzed for market sentiment and impact with AI-powered analysis.",
    href: "/news-sentiment",
    color: "#a855f7",
  },
  {
    icon: GraduationCap,
    title: "Learning Center",
    description: "Comprehensive crypto education with visual guides on candlesticks, chart patterns, and trading strategies.",
    href: "/learning-center",
    color: "#22C55E",
  },
];

const WHY_ALPHA = [
  {
    icon: Shield,
    title: "Security",
    description: "89 active protections across 8 categories. Scored 80/80 (100%) — ranked #1 above Coinbase, Binance, Kraken, and OKX.",
    color: "#22C55E",
  },
  {
    icon: Zap,
    title: "Technology",
    description: "20 proprietary technologies found nowhere else. QMGE scores up to 100% accuracy using industry-standard methodology.",
    color: "#00D4FF",
  },
  {
    icon: Globe,
    title: "Coverage",
    description: "270+ cryptos, 32+ exchanges, 57+ wallets, 70+ blockchains. One platform for everything.",
    color: "#a855f7",
  },
];

const hexToRgba = (hex: string, alpha: number) => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

const hexToRgb = (hex: string) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '0, 212, 255';
};

export default function AlphaTradingHomeV2() {
  return (
    <TradingPlatformLayout>
      <div className="max-w-6xl mx-auto py-8 sm:py-12 md:py-16 space-y-16 sm:space-y-20 md:space-y-24 relative z-10">

        {/* 1. HERO SECTION */}
        <section className="px-4" data-testid="hero-section">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-12 relative">

            <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#00D4FF]/5 rounded-full blur-[120px] pointer-events-none" />

            <div className="flex-1 text-center lg:text-left relative z-10">
              <div className="inline-flex items-center gap-2 px-5 py-2 bg-[#00D4FF]/10 border border-[#00D4FF]/40 rounded-full mb-8 shadow-[0_0_15px_rgba(0,212,255,0.3)]">
                <Sparkles size={16} className="text-[#00D4FF] animate-pulse" />
                <span className="text-[#00D4FF] text-xs sm:text-sm font-semibold tracking-wider uppercase">Powered by 20 Proprietary Technologies</span>
              </div>

              <h1
                className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight tracking-tight"
                style={{ fontFamily: "Orbitron, sans-serif" }}
                data-testid="text-hero-title"
              >
                <span className="text-white drop-shadow-md">Trade Smarter with </span>
                <span className="bg-gradient-to-r from-[#00D4FF] via-[#a855f7] to-[#00D4FF] bg-[length:200%_auto] animate-[gradient_4s_linear_infinite] bg-clip-text text-transparent drop-shadow-lg">
                  Alpha Unlimited
                </span>
              </h1>

              <p
                className="text-lg sm:text-xl text-[#94A3B8] max-w-2xl mx-auto lg:mx-0 mb-10 leading-relaxed font-light"
                data-testid="text-hero-subtitle"
              >
                Professional crypto trading platform with futures trading, short selling, 20 proprietary technologies, AI-powered signals, and real-time execution across 32+ exchanges.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 sm:gap-6">
                <Link href="/terminal">
                  <button
                    className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-bold rounded-2xl text-base flex items-center gap-3 justify-center hover:scale-[1.02] hover:shadow-[0_0_25px_rgba(0,212,255,0.4)] active:scale-[0.98] transition-all duration-300"
                    data-testid="button-launch-terminal"
                  >
                    <TrendingUp size={20} />
                    Launch Terminal
                  </button>
                </Link>
                <Link href="/features">
                  <button
                    className="w-full sm:w-auto px-8 py-4 border-2 border-[#1E293B] hover:border-[#334155] text-white font-semibold rounded-2xl text-base flex items-center gap-3 bg-[#0A0F1C]/80 backdrop-blur-sm justify-center hover:bg-[#111827] transition-all duration-300"
                    data-testid="button-explore-features"
                  >
                    Explore Features
                    <ChevronDown size={18} />
                  </button>
                </Link>
              </div>
            </div>

            <div
              className="flex-shrink-0 w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 relative z-10 group"
              data-testid="hero-phoenix-container"
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#00D4FF]/20 via-transparent to-[#a855f7]/20 blur-3xl" />
              <picture>
                <source srcSet="/assets/phoenix/alpha-phoenix-action-pose.webp" type="image/webp" />
                <img
                  src="/assets/phoenix/alpha-phoenix-action-pose.png"
                  alt="Alpha Phoenix"
                  className="w-full h-full object-cover rounded-2xl relative z-10"
                  loading="eager"
                  fetchPriority="high"
                  width={384}
                  height={384}
                  data-testid="img-phoenix-mascot"
                />
              </picture>
            </div>
          </div>
        </section>

        <div className="h-px w-full max-w-4xl mx-auto bg-gradient-to-r from-transparent via-[#00D4FF]/30 to-transparent" />

        {/* 2. STATS BAR */}
        <section className="px-4" data-testid="stats-bar">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-5">
            {STATS.map((stat) => (
              <div
                key={stat.label}
                className="relative text-center p-5 sm:p-6 rounded-xl bg-[#0D1117] border border-[#1A2942] shadow-lg overflow-hidden group hover:-translate-y-1 transition-transform duration-300"
                data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-1"
                  style={{ backgroundColor: stat.color, opacity: 0.8 }}
                ></div>
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl pointer-events-none"
                  style={{ background: `radial-gradient(circle at center, ${hexToRgba(stat.color, 0.15)} 0%, transparent 70%)` }}
                ></div>
                <div
                  className="text-3xl sm:text-4xl font-bold mb-2 tracking-tight relative z-10"
                  style={{ color: stat.color, fontFamily: "Orbitron, sans-serif", textShadow: `0 0 20px ${hexToRgba(stat.color, 0.3)}` }}
                  data-testid={`text-stat-value-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  {stat.value}
                </div>
                <div className="text-sm font-medium text-[#8899A6] relative z-10">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="h-px w-full max-w-4xl mx-auto bg-gradient-to-r from-transparent via-[#a855f7]/30 to-transparent" />

        {/* 3. CORE FEATURES */}
        <section className="px-4" data-testid="core-features">
          <div className="text-center mb-10 sm:mb-16">
            <h2
              className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight"
              style={{ fontFamily: "Orbitron, sans-serif" }}
              data-testid="text-features-heading"
            >
              Core Features
            </h2>
            <p className="text-base sm:text-lg text-[#94A3B8] max-w-2xl mx-auto font-light">
              Everything you need to trade crypto like a professional, engineered with precision.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            {CORE_FEATURES.map((feature, i) => {
              const Icon = feature.icon;
              const rgb = hexToRgb(feature.color);
              const hasTint = i % 2 === 0;

              return (
                <Link key={feature.title} href={feature.href}>
                  <div className="block group h-full">
                    <div
                      className={`h-full p-6 sm:p-8 rounded-2xl border transition-all duration-500 cursor-pointer relative overflow-hidden flex flex-col group-hover:-translate-y-1 ${
                        hasTint
                          ? 'bg-[#0D1117] border-[#1E293B]'
                          : 'bg-[#111827] border-[#2A3952]'
                      }`}
                      data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <div
                        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                        style={{ background: `linear-gradient(135deg, rgba(${rgb}, 0.08) 0%, transparent 100%)` }}
                      />

                      {hasTint && (
                        <div
                          className="absolute inset-0 opacity-100 pointer-events-none"
                          style={{ background: `radial-gradient(circle at top right, rgba(${rgb}, 0.03), transparent)` }}
                        />
                      )}

                      <div className="relative flex-1 flex flex-col">
                        <div
                          className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 shadow-inner transition-transform duration-500 group-hover:-translate-y-1"
                          style={{
                            background: `linear-gradient(135deg, rgba(${rgb}, 0.15) 0%, rgba(${rgb}, 0.05) 100%)`,
                            border: `1px solid rgba(${rgb}, 0.2)`
                          }}
                        >
                          <Icon size={26} style={{ color: feature.color }} />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3 transition-colors duration-300" style={{ fontFamily: "Orbitron, sans-serif" }}>
                          {feature.title}
                        </h3>
                        <p className="text-sm text-[#94A3B8] leading-relaxed mb-6 flex-1 font-light">
                          {feature.description}
                        </p>
                        <div className="mt-auto">
                          <span
                            className="text-sm font-semibold flex items-center gap-2 transition-all duration-300 group-hover:gap-3"
                            style={{ color: feature.color }}
                          >
                            Learn more <ArrowRight size={14} />
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/technology">
              <span className="px-6 py-2.5 text-sm font-medium text-[#00D4FF] border border-[#00D4FF]/30 hover:border-[#00D4FF]/60 rounded-xl bg-[#00D4FF]/5 hover:bg-[#00D4FF]/10 transition-all flex items-center gap-2" data-testid="link-view-technology">
                View 20 Proprietary Technologies
                <ArrowRight size={14} />
              </span>
            </Link>
            <Link href="/features">
              <span className="px-6 py-2.5 text-sm font-medium text-[#a855f7] border border-[#a855f7]/30 hover:border-[#a855f7]/60 rounded-xl bg-[#a855f7]/5 hover:bg-[#a855f7]/10 transition-all flex items-center gap-2" data-testid="link-features-overview">
                Full Features Overview
                <ArrowRight size={14} />
              </span>
            </Link>
          </div>
        </section>

        <div className="h-px w-full max-w-4xl mx-auto bg-gradient-to-r from-transparent via-[#22C55E]/30 to-transparent" />

        {/* 4. WHY ALPHA */}
        <section className="px-4" data-testid="why-alpha">
          <div className="text-center mb-10 sm:mb-16">
            <h2
              className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight"
              style={{ fontFamily: "Orbitron, sans-serif" }}
              data-testid="text-why-heading"
            >
              Why Alpha Unlimited
            </h2>
            <p className="text-base sm:text-lg text-[#94A3B8] max-w-2xl mx-auto font-light">
              Built on a foundation of uncompromised security and unrivaled technology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {WHY_ALPHA.map((item) => {
              const Icon = item.icon;
              const rgb = hexToRgb(item.color);

              return (
                <div key={item.title} className="block group">
                  <div
                    className="text-center p-8 sm:p-10 rounded-2xl bg-[#111827] relative overflow-hidden h-full flex flex-col items-center border border-[#1E293B] hover:-translate-y-1 transition-all duration-300"
                    data-testid={`card-why-${item.title.toLowerCase()}`}
                  >
                    <div
                      className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
                      style={{ backgroundColor: item.color, opacity: 0.8 }}
                    ></div>
                    <div
                      className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl pointer-events-none"
                      style={{ background: `radial-gradient(circle at center, ${hexToRgba(item.color, 0.15)} 0%, transparent 70%)` }}
                    ></div>

                    <div className="relative z-10 flex flex-col items-center">
                      <div
                        className="w-20 h-20 rounded-2xl flex items-center justify-center mb-6 shadow-lg transition-transform duration-500 group-hover:scale-110"
                        style={{
                          background: `radial-gradient(circle, rgba(${rgb}, 0.2) 0%, rgba(${rgb}, 0.05) 100%)`,
                          boxShadow: `0 0 20px rgba(${rgb}, 0.15)`
                        }}
                      >
                        <Icon size={32} style={{ color: item.color }} />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: "Orbitron, sans-serif" }}>
                        {item.title}
                      </h3>
                      <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed font-light">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 4.5. TESTIMONIALS SECTION */}
        <TestimonialsSection />

        {/* 5. CTA SECTION */}
        <section className="px-4 pb-16" data-testid="cta-section">
          <div className="relative rounded-[2rem] overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-[#00D4FF] via-[#a855f7] to-[#00D4FF] opacity-40 group-hover:opacity-70 transition-opacity duration-500 animate-[gradient_4s_linear_infinite] bg-[length:200%_auto]" />
            <div className="absolute inset-[2px] bg-[#0A0F1C] rounded-[2rem]" />

            <div className="absolute inset-0 overflow-hidden rounded-[2rem]">
              <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-[#00D4FF]/10 rounded-full blur-[100px] -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
              <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#a855f7]/10 rounded-full blur-[100px] translate-x-1/2 translate-y-1/2 pointer-events-none" />
            </div>

            <div className="relative text-center p-10 sm:p-16 md:p-20 z-10 flex flex-col items-center">
              <h2
                className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight drop-shadow-lg"
                style={{ fontFamily: "Orbitron, sans-serif" }}
                data-testid="text-cta-heading"
              >
                Ready to Dominate the Market?
              </h2>
              <p className="text-base sm:text-lg md:text-xl text-[#94A3B8] mb-10 max-w-2xl mx-auto font-light">
                Join thousands of traders using the most advanced crypto trading platform available.
              </p>
              <Link href="/terminal">
                <button
                  className="relative overflow-hidden px-10 py-5 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-bold rounded-2xl text-lg flex items-center gap-3 shadow-[0_0_30px_rgba(0,212,255,0.3)] hover:shadow-[0_0_40px_rgba(0,212,255,0.5)] hover:-translate-y-1 active:scale-[0.98] transition-all duration-300"
                  data-testid="button-cta-start-trading"
                >
                  <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent animate-[shimmer_2s_infinite]" />
                  <TrendingUp size={24} />
                  Start Trading Now
                </button>
              </Link>
            </div>
          </div>
        </section>

      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
      `}} />
    </TradingPlatformLayout>
  );
}
