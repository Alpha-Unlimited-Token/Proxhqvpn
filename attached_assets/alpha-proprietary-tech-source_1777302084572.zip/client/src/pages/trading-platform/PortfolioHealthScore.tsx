/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Portfolio Health Score™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Portfolio Health Score™
 * - Risk Performance Assessment™
 * - Portfolio Diversification Analyzer™
 * - Actionable Recommendation Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_80c28cae9b24aceda9526e62
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";

interface AssetHolding {
  symbol: string;
  name: string;
  amount: number;
  valueUsd: number;
  allocation: number;
  priceChange24h: number;
  sector: string;
  isStablecoin: boolean;
}

interface RiskMetric {
  name: string;
  score: number;
  maxScore: number;
  description: string;
  status: "excellent" | "good" | "warning" | "danger";
}

interface PortfolioAnalysis {
  overallScore: number;
  totalValue: number;
  holdings: AssetHolding[];
  metrics: RiskMetric[];
  recommendations: string[];
  sectorAllocation: Record<string, number>;
  volatilityExposure: number;
  correlationRisk: number;
  diversificationScore: number;
  stablecoinRatio: number;
}

function getScoreColor(score: number): string {
  if (score >= 80) return "text-green-400";
  if (score >= 60) return "text-yellow-400";
  if (score >= 40) return "text-orange-400";
  return "text-red-400";
}

function getScoreGradient(score: number): string {
  if (score >= 80) return "from-green-500 to-emerald-400";
  if (score >= 60) return "from-yellow-500 to-amber-400";
  if (score >= 40) return "from-orange-500 to-amber-500";
  return "from-red-500 to-rose-400";
}

function getStatusColor(status: string): string {
  switch (status) {
    case "excellent": return "bg-green-600/20 text-green-400 border-green-500/30";
    case "good": return "bg-cyan-600/20 text-cyan-400 border-cyan-500/30";
    case "warning": return "bg-yellow-600/20 text-yellow-400 border-yellow-500/30";
    case "danger": return "bg-red-600/20 text-red-400 border-red-500/30";
    default: return "bg-gray-600/20 text-gray-400 border-gray-500/30";
  }
}

function HealthGauge({ score }: { score: number }) {
  const angle = (score / 100) * 180;
  const radius = 80;
  const cx = 100;
  const cy = 95;

  const endX = cx + radius * Math.cos((Math.PI * (180 - angle)) / 180);
  const endY = cy - radius * Math.sin((Math.PI * (180 - angle)) / 180);

  const largeArc = angle > 180 ? 1 : 0;

  return (
    <div className="flex flex-col items-center" data-testid="gauge-health-score">
      <svg viewBox="0 0 200 120" className="w-64 h-40">
        <defs>
          <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="25%" stopColor="#f97316" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="75%" stopColor="#22c55e" />
            <stop offset="100%" stopColor="#10b981" />
          </linearGradient>
        </defs>
        <path
          d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy}`}
          fill="none"
          stroke="#1E3A5F"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <path
          d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 ${largeArc} 1 ${endX} ${endY}`}
          fill="none"
          stroke="url(#gaugeGrad)"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <circle cx={endX} cy={endY} r="6" fill="white" />
        <text x={cx} y={cy - 15} textAnchor="middle" className={getScoreColor(score)} fill="currentColor" fontSize="28" fontWeight="bold">
          {score}
        </text>
        <text x={cx} y={cy + 5} textAnchor="middle" fill="#6b7280" fontSize="10">
          / 100
        </text>
        <text x={cx - radius + 5} y={cy + 15} fill="#6b7280" fontSize="8">0</text>
        <text x={cx + radius - 10} y={cy + 15} fill="#6b7280" fontSize="8">100</text>
      </svg>
      <div className={`text-lg font-bold ${getScoreColor(score)}`} data-testid="text-score-label">
        {score >= 80 ? "Excellent" : score >= 60 ? "Good" : score >= 40 ? "Fair" : "Needs Attention"}
      </div>
    </div>
  );
}

function SectorChart({ sectorAllocation }: { sectorAllocation: Record<string, number> }) {
  const sectors = Object.entries(sectorAllocation).sort((a, b) => b[1] - a[1]);
  const colors = [
    "#FFD700", "#00D4FF", "#A855F7", "#22C55E", "#EF4444",
    "#F97316", "#3B82F6", "#EC4899", "#14B8A6", "#8B5CF6"
  ];

  let cumulativeAngle = 0;
  const cx = 60;
  const cy = 60;
  const r = 50;

  return (
    <div className="flex items-center gap-4" data-testid="chart-sector-allocation">
      <svg viewBox="0 0 120 120" className="w-32 h-32 flex-shrink-0">
        {sectors.map(([sector, pct], i) => {
          const startAngle = cumulativeAngle;
          const sliceAngle = (pct / 100) * 360;
          cumulativeAngle += sliceAngle;

          const startRad = ((startAngle - 90) * Math.PI) / 180;
          const endRad = ((startAngle + sliceAngle - 90) * Math.PI) / 180;

          const x1 = cx + r * Math.cos(startRad);
          const y1 = cy + r * Math.sin(startRad);
          const x2 = cx + r * Math.cos(endRad);
          const y2 = cy + r * Math.sin(endRad);

          const largeArc = sliceAngle > 180 ? 1 : 0;

          return (
            <path
              key={sector}
              d={`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`}
              fill={colors[i % colors.length]}
              opacity={0.8}
              stroke="#0f1923"
              strokeWidth="1"
            />
          );
        })}
        <circle cx={cx} cy={cy} r="25" fill="#0f1923" />
      </svg>
      <div className="flex flex-col gap-1 text-xs">
        {sectors.map(([sector, pct], i) => (
          <div key={sector} className="flex items-center gap-2" data-testid={`text-sector-${sector}`}>
            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: colors[i % colors.length] }} />
            <span className="text-gray-400 capitalize">{sector}</span>
            <span className="text-white font-mono ml-auto">{pct.toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function MetricBar({ metric }: { metric: RiskMetric }) {
  const pct = (metric.score / metric.maxScore) * 100;
  return (
    <div className="space-y-1" data-testid={`metric-${metric.name.toLowerCase().replace(/\s/g, '-')}`}>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-300">{metric.name}</span>
        <div className="flex items-center gap-2">
          <span className="text-sm font-mono text-white">{metric.score}/{metric.maxScore}</span>
          <Badge className={`text-[10px] ${getStatusColor(metric.status)}`} data-testid={`badge-metric-status-${metric.name.toLowerCase().replace(/\s/g, '-')}`}>
            {metric.status}
          </Badge>
        </div>
      </div>
      <div className="w-full h-2 bg-[#0a1018] rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full bg-gradient-to-r ${getScoreGradient(pct)}`}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>
      <p className="text-[11px] text-gray-500">{metric.description}</p>
    </div>
  );
}

export default function PortfolioHealthScore() {
  const [analysis, setAnalysis] = useState<PortfolioAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [refreshing, setRefreshing] = useState(false);

  const fetchAnalysis = useCallback(async () => {
    try {
      setError(null);
      const res = await fetch("/api/portfolio/health-score");
      if (res.ok) {
        const data = await res.json();
        setAnalysis(data);
      } else {
        const errData = await res.json().catch(() => ({ message: "Failed to load portfolio analysis" }));
        setError(errData.message);
      }
    } catch {
      setError("Failed to connect to server");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchAnalysis();
  };

  if (loading) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-400 text-sm">Analyzing portfolio health...</span>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-portfolio-health-score">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4"
        >
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
              🏥 Portfolio Health Score
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              Comprehensive risk assessment and performance analysis of your crypto portfolio
            </p>
          </div>
          <Button
            onClick={handleRefresh}
            disabled={refreshing}
            variant="outline"
            size="sm"
            className="border-[#1E3A5F] text-gray-300 hover:bg-[#152238]"
            data-testid="button-refresh"
          >
            {refreshing ? "Refreshing..." : "🔄 Refresh Analysis"}
          </Button>
        </motion.div>

        {error && (
          <Card className="bg-red-900/20 border-red-500/30">
            <CardContent className="p-4 text-center">
              <p className="text-red-400" data-testid="text-error">{error}</p>
              <Button onClick={handleRefresh} variant="outline" size="sm" className="mt-2 border-red-500/30 text-red-400" data-testid="button-retry">
                Retry
              </Button>
            </CardContent>
          </Card>
        )}

        {analysis && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardContent className="p-3 text-center">
                    <div className="text-xs text-gray-500">Health Score</div>
                    <div className={`text-xl font-bold font-mono ${getScoreColor(analysis.overallScore)}`} data-testid="text-overall-score">{analysis.overallScore}</div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardContent className="p-3 text-center">
                    <div className="text-xs text-gray-500">Total Value</div>
                    <div className="text-xl font-bold font-mono text-white" data-testid="text-total-value">
                      ${analysis.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardContent className="p-3 text-center">
                    <div className="text-xs text-gray-500">Diversification</div>
                    <div className={`text-xl font-bold font-mono ${getScoreColor(analysis.diversificationScore)}`} data-testid="text-diversification">
                      {analysis.diversificationScore}%
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardContent className="p-3 text-center">
                    <div className="text-xs text-gray-500">Volatility</div>
                    <div className={`text-xl font-bold font-mono ${analysis.volatilityExposure <= 40 ? "text-green-400" : analysis.volatilityExposure <= 60 ? "text-yellow-400" : "text-red-400"}`} data-testid="text-volatility">
                      {analysis.volatilityExposure}%
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardContent className="p-3 text-center">
                    <div className="text-xs text-gray-500">Stablecoin Ratio</div>
                    <div className="text-xl font-bold font-mono text-cyan-400" data-testid="text-stablecoin-ratio">
                      {analysis.stablecoinRatio}%
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-300">Health Gauge</CardTitle>
                  </CardHeader>
                  <CardContent className="flex justify-center">
                    <HealthGauge score={analysis.overallScore} />
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-300">Sector Allocation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <SectorChart sectorAllocation={analysis.sectorAllocation} />
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}>
                <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-300">Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {analysis.recommendations.map((rec, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs" data-testid={`text-recommendation-${i}`}>
                        <span className="text-yellow-400 mt-0.5">💡</span>
                        <span className="text-gray-300">{rec}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardHeader className="pb-2">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="bg-[#0a1018]">
                    <TabsTrigger value="overview" className="text-xs" data-testid="tab-overview">
                      📊 Risk Breakdown
                    </TabsTrigger>
                    <TabsTrigger value="holdings" className="text-xs" data-testid="tab-holdings">
                      💰 Holdings ({analysis.holdings.length})
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                {activeTab === "overview" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-5"
                    data-testid="section-risk-breakdown"
                  >
                    {analysis.metrics.map((metric) => (
                      <MetricBar key={metric.name} metric={metric} />
                    ))}
                  </motion.div>
                )}

                {activeTab === "holdings" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    data-testid="section-holdings"
                  >
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm" data-testid="table-holdings">
                        <thead>
                          <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
                            <th className="text-left py-2 px-3">Asset</th>
                            <th className="text-right py-2 px-3">Amount</th>
                            <th className="text-right py-2 px-3">Value</th>
                            <th className="text-right py-2 px-3">Allocation</th>
                            <th className="text-right py-2 px-3">24h Change</th>
                            <th className="text-left py-2 px-3">Sector</th>
                          </tr>
                        </thead>
                        <tbody>
                          {analysis.holdings.map((holding) => (
                            <tr key={holding.symbol} className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors" data-testid={`row-holding-${holding.symbol}`}>
                              <td className="py-2 px-3">
                                <div className="flex items-center gap-2">
                                  <span className="text-white font-medium">{holding.symbol}</span>
                                  <span className="text-gray-500 text-xs">{holding.name}</span>
                                  {holding.isStablecoin && (
                                    <Badge className="text-[9px] bg-cyan-600/20 text-cyan-400 border-cyan-500/30">Stable</Badge>
                                  )}
                                </div>
                              </td>
                              <td className="py-2 px-3 text-right font-mono text-gray-300">
                                {holding.amount.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                              </td>
                              <td className="py-2 px-3 text-right font-mono text-white">
                                ${holding.valueUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </td>
                              <td className="py-2 px-3 text-right">
                                <div className="flex items-center justify-end gap-2">
                                  <div className="w-16 h-1.5 bg-[#0a1018] rounded-full overflow-hidden">
                                    <div
                                      className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
                                      style={{ width: `${Math.min(holding.allocation, 100)}%` }}
                                    />
                                  </div>
                                  <span className="font-mono text-cyan-400 text-xs">{holding.allocation.toFixed(1)}%</span>
                                </div>
                              </td>
                              <td className={`py-2 px-3 text-right font-mono ${holding.priceChange24h >= 0 ? "text-green-400" : "text-red-400"}`}>
                                {holding.priceChange24h >= 0 ? "+" : ""}{holding.priceChange24h.toFixed(2)}%
                              </td>
                              <td className="py-2 px-3">
                                <Badge variant="outline" className="text-[10px] border-[#1E3A5F] text-gray-400 capitalize">
                                  {holding.sector}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {!analysis && !error && (
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-12 text-center">
              <div className="text-4xl mb-3">📊</div>
              <h3 className="text-lg text-white mb-2" data-testid="text-no-portfolio">No Portfolio Data</h3>
              <p className="text-gray-400 text-sm">Connect your exchange or wallet to analyze your portfolio health.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </TradingPlatformLayout>
  );
}
