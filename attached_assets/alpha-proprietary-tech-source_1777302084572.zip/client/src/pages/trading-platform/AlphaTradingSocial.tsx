/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Social Trading Hub™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Social Trading Hub™
 * - Community Engagement Platform™
 * - Social Feed Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_9a5c57ee48fee1205d9aad37
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, MessageCircle, Trophy, TrendingUp, Heart, 
  Send, Share2, UserPlus, Crown, Medal, Award, Copy, Check
} from "lucide-react";
import { CompareWithFriends } from "@/components/CompareWithFriends";
import { SocialTradingPanel } from "@/components/trading-platform/SocialTradingPanel";

export default function AlphaTradingSocial() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const handleCopyTrade = (tradeId: string) => {
    setCopied(true);
    toast({
      title: "Trade Copied!",
      description: "This trade has been added to your watchlist.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Social Trading Hub</h1>
            <p className="text-[#94A3B8]">
              Copy top traders, compete on leaderboards, and share your trading insights
            </p>
          </div>

          <Tabs defaultValue="leaderboard" className="space-y-6">
            <TabsList className="bg-[#152238] border border-[#1E3A5F] flex-wrap h-auto">
              <TabsTrigger value="leaderboard" className="data-[state=active]:bg-[#00D4FF] data-[state=active]:text-black">
                <Trophy className="w-4 h-4 mr-2" /> Leaderboard
              </TabsTrigger>
              <TabsTrigger value="copy-trading" className="data-[state=active]:bg-[#00D4FF] data-[state=active]:text-black">
                <Copy className="w-4 h-4 mr-2" /> Copy Trading
              </TabsTrigger>
              <TabsTrigger value="compare" className="data-[state=active]:bg-[#00D4FF] data-[state=active]:text-black">
                <Users className="w-4 h-4 mr-2" /> Compare
              </TabsTrigger>
              <TabsTrigger value="feed" className="data-[state=active]:bg-[#00D4FF] data-[state=active]:text-black">
                <MessageCircle className="w-4 h-4 mr-2" /> Feed
              </TabsTrigger>
            </TabsList>

            <TabsContent value="leaderboard" className="space-y-6">
              <Card className="bg-[#0D1117] border-[#1E3A5F]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-[#00D4FF]" /> Top Traders This Month
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { rank: 1, name: "CryptoWhale", returns: "+156.4%", trades: 234, winRate: 72, icon: Crown, color: "text-yellow-400" },
                      { rank: 2, name: "DiamondHands", returns: "+98.7%", trades: 189, winRate: 68, icon: Medal, color: "text-gray-300" },
                      { rank: 3, name: "AlphaTrader", returns: "+87.2%", trades: 156, winRate: 65, icon: Award, color: "text-amber-600" },
                      { rank: 4, name: "MoonShot", returns: "+76.5%", trades: 203, winRate: 61, icon: TrendingUp, color: "text-[#00D4FF]" },
                      { rank: 5, name: "DeFiKing", returns: "+65.3%", trades: 178, winRate: 58, icon: TrendingUp, color: "text-[#00D4FF]" },
                    ].map((trader) => (
                      <div key={trader.rank} className="flex flex-wrap items-center justify-between gap-3 p-4 bg-[#152238] rounded-lg border border-[#1E3A5F] hover:border-[#00D4FF]/50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className={`text-2xl font-bold ${trader.color}`}>
                            <trader.icon className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="font-semibold text-white">{trader.name}</p>
                            <p className="text-sm text-[#94A3B8]">{trader.trades} trades • {trader.winRate}% win rate</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-green-400 font-bold text-lg">{trader.returns}</span>
                          <Button 
                          size="sm" 
                          className="bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black"
                          onClick={() => {
                            if (!isAuthenticated) {
                              window.location.href = '/api/login';
                            } else {
                              toast({
                                title: "Copy Trading Started!",
                                description: `You are now copying ${trader.name}'s trades.`,
                              });
                            }
                          }}
                        >
                          <Copy className="w-4 h-4 mr-1" /> Copy
                        </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="copy-trading" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-[#0D1117] border-[#1E3A5F]">
                  <CardHeader>
                    <CardTitle className="text-white">How Copy Trading Works</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-[#94A3B8]">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#00D4FF]/20 flex items-center justify-center text-[#00D4FF] font-bold">1</div>
                      <div>
                        <p className="font-medium text-white">Choose a Trader</p>
                        <p className="text-sm">Browse the leaderboard and find traders whose strategy matches yours.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#00D4FF]/20 flex items-center justify-center text-[#00D4FF] font-bold">2</div>
                      <div>
                        <p className="font-medium text-white">Set Your Parameters</p>
                        <p className="text-sm">Define how much to allocate and your risk tolerance.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#00D4FF]/20 flex items-center justify-center text-[#00D4FF] font-bold">3</div>
                      <div>
                        <p className="font-medium text-white">Auto-Copy Trades</p>
                        <p className="text-sm">Their trades are automatically mirrored in your account.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-[#0D1117] border-[#1E3A5F]">
                  <CardHeader>
                    <CardTitle className="text-white">Your Copy Trading</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isAuthenticated ? (
                      <div className="space-y-4">
                        <p className="text-[#94A3B8]">You are not currently copying any traders.</p>
                        <Button 
                          className="w-full bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black"
                          onClick={() => {
                            const tabsList = document.querySelector('[data-state="active"][value="leaderboard"]');
                            if (!tabsList) {
                              const leaderboardTab = document.querySelector('[value="leaderboard"]') as HTMLElement;
                              leaderboardTab?.click();
                            }
                          }}
                        >
                          Browse Top Traders
                        </Button>
                      </div>
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-[#94A3B8] mb-4">Sign in to start copy trading</p>
                        <Button 
                          className="bg-[#00D4FF] hover:bg-[#00D4FF]/80 text-black"
                          onClick={() => window.location.href = '/api/login'}
                        >
                          Sign In
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="compare">
              <CompareWithFriends />
            </TabsContent>

            <TabsContent value="feed">
              <SocialTradingPanel />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
