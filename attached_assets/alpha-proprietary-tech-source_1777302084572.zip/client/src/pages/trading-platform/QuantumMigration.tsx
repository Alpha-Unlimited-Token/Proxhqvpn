/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Quantum Migration Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Alpha Quantum Migration Engine™
 * - Post-Quantum Key Derivation Pipeline™
 * - Hybrid Signature Transition Protocol™
 * - Zero-Downtime Cryptographic Migration™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_QS_MIGRATION_PAGE_SEALED
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Clock, CheckCircle, Layers, Cpu, FileText, ArrowUpRight } from "lucide-react";

interface MigrationPlan {
  planId: string;
  sourceAddress: string;
  chain: string;
  currentAlgorithm: string;
  targetAlgorithm: string;
  status: string;
  estimatedGasCost: string;
  migrationSteps: {
    step: number;
    name: string;
    description: string;
    status: string;
    estimatedTime: string;
  }[];
  riskAssessment: {
    overallRisk: string;
    migrationComplexity: string;
    downtime: string;
    rollbackPossible: boolean;
  };
  generatedAt: string;
}

const ALGORITHMS = [
  { value: "ML-DSA-87", label: "ML-DSA-87 (FIPS 204)", desc: "Recommended — NIST Level 5" },
  { value: "ML-KEM-1024", label: "ML-KEM-1024 (FIPS 203)", desc: "Key Encapsulation — NIST Level 5" },
  { value: "SLH-DSA-256f", label: "SLH-DSA-256f (FIPS 205)", desc: "Hash-Based — Stateless" },
  { value: "HYBRID-ECDSA-MLDSA", label: "Hybrid ECDSA + ML-DSA", desc: "Backward Compatible" },
];

export default function QuantumMigration() {
  const [sourceAddress, setSourceAddress] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [targetAlgorithm, setTargetAlgorithm] = useState("ML-DSA-87");
  const [generating, setGenerating] = useState(false);
  const [plan, setPlan] = useState<MigrationPlan | null>(null);

  const handleGenerate = async () => {
    if (!sourceAddress) return;
    setGenerating(true);
    setPlan(null);
    try {
      const res = await fetch("/api/quantum/migration/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceAddress, chain, targetAlgorithm }),
      });
      const data = await res.json();
      setPlan(data);
    } catch (e) { console.error(e); }
    setGenerating(false);
  };

  const stepStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4 text-green-400" />;
      case "in-progress": return <Cpu className="w-4 h-4 text-[#d4af37] animate-pulse" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <TradingPlatformLayout title="Alpha Quantum Migration Engine™" subtitle="Zero-Downtime Post-Quantum Cryptographic Migration">
      <div className="space-y-6 p-4 max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30 mb-6">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Layers className="w-4 h-4" /> Generate Migration Plan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Source Wallet / Contract Address</label>
                  <Input
                    data-testid="input-migration-address"
                    placeholder="0x..."
                    value={sourceAddress}
                    onChange={(e) => setSourceAddress(e.target.value)}
                    className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Blockchain</label>
                  <select
                    data-testid="select-migration-chain"
                    value={chain}
                    onChange={(e) => setChain(e.target.value)}
                    className="w-full bg-[#0a0a1a] border border-gray-700 text-white text-sm rounded-md px-3 py-2"
                  >
                    <option value="ethereum">Ethereum</option>
                    <option value="bsc">BSC</option>
                    <option value="polygon">Polygon</option>
                    <option value="arbitrum">Arbitrum</option>
                    <option value="solana">Solana</option>
                  </select>
                </div>
              </div>

              <div className="mb-4">
                <label className="text-xs text-gray-400 mb-2 block">Target Post-Quantum Algorithm</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {ALGORITHMS.map((algo) => (
                    <div
                      key={algo.value}
                      data-testid={`option-algo-${algo.value}`}
                      onClick={() => setTargetAlgorithm(algo.value)}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        targetAlgorithm === algo.value
                          ? 'border-[#d4af37] bg-[#d4af37]/10'
                          : 'border-gray-700 bg-[#0a0a1a] hover:border-gray-500'
                      }`}
                    >
                      <div className="text-sm text-gray-200">{algo.label}</div>
                      <div className="text-[10px] text-gray-500">{algo.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              <Button
                data-testid="button-generate-plan"
                onClick={handleGenerate}
                disabled={generating || !sourceAddress}
                className="w-full bg-[#d4af37] hover:bg-[#b8962e] text-black"
              >
                {generating ? "Generating Migration Plan..." : "Generate Migration Plan"}
              </Button>
            </CardContent>
          </Card>

          {plan && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardContent className="pt-4">
                    <div className="text-xs text-gray-400">Current → Target</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm text-red-400">{plan.currentAlgorithm}</span>
                      <ArrowRight className="w-4 h-4 text-[#d4af37]" />
                      <span className="text-sm text-green-400">{plan.targetAlgorithm}</span>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardContent className="pt-4">
                    <div className="text-xs text-gray-400">Status</div>
                    <Badge className="mt-1 bg-blue-600">{plan.status}</Badge>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardContent className="pt-4">
                    <div className="text-xs text-gray-400">Est. Gas Cost</div>
                    <div className="text-lg font-bold text-white mt-1">{plan.estimatedGasCost}</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardContent className="pt-4">
                    <div className="text-xs text-gray-400">Risk Level</div>
                    <Badge className={`mt-1 ${plan.riskAssessment.overallRisk === 'LOW' ? 'bg-green-600' : plan.riskAssessment.overallRisk === 'MEDIUM' ? 'bg-yellow-600' : 'bg-red-600'}`}>
                      {plan.riskAssessment.overallRisk}
                    </Badge>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                <CardHeader>
                  <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Migration Steps
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {plan.migrationSteps.map((step, i) => (
                      <div key={i} className="flex items-start gap-3 p-3 bg-[#0a0a1a] rounded-lg border border-gray-800">
                        <div className="flex-shrink-0 mt-0.5">{stepStatusIcon(step.status)}</div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-200">Step {step.step}: {step.name}</span>
                            <span className="text-[10px] text-gray-500">{step.estimatedTime}</span>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                <CardHeader>
                  <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                    <Shield className="w-4 h-4" /> Risk Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                    <div>
                      <span className="text-gray-400">Complexity:</span>
                      <div className="text-gray-200 mt-1">{plan.riskAssessment.migrationComplexity}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Expected Downtime:</span>
                      <div className="text-gray-200 mt-1">{plan.riskAssessment.downtime}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Rollback Possible:</span>
                      <div className={`mt-1 ${plan.riskAssessment.rollbackPossible ? 'text-green-400' : 'text-red-400'}`}>
                        {plan.riskAssessment.rollbackPossible ? "Yes" : "No"}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Plan ID:</span>
                      <div className="text-gray-200 mt-1 font-mono text-[10px]">{plan.planId}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="mt-6 p-4 bg-[#0a0a1a] rounded-lg border border-[#d4af37]/20">
            <h3 className="text-[#d4af37] text-sm font-bold mb-2">How Alpha Quantum Migration Engine™ Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Hybrid Transition</h4>
                <p>Supports dual-signature schemes (classical + post-quantum) during migration to maintain backward compatibility while adding quantum resistance. Zero-downtime migration with automatic rollback capability.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">NIST-Approved Algorithms</h4>
                <p>Migrates to ML-DSA (FIPS 204), ML-KEM (FIPS 203), or SLH-DSA (FIPS 205) — the official NIST post-quantum cryptography standards selected after 8 years of evaluation.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Gas-Optimized Execution</h4>
                <p>Migration plans are optimized for minimal gas consumption using batched operations, proxy contract upgrades, and off-chain key generation to reduce on-chain costs.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}
