/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Intelligence Engine™ — Bounty Agreement Signing Page
 * AUT_ModuleHash: AUT_b7c2a8e3f1dd958d49b9b41a
 * ALPHA_INTEGRITY_SEAL: BOUNTY_AGREEMENT_v1.0_PROTECTED
 */
import { useState, useEffect } from "react";
import { useParams } from "wouter";

export default function BountyAgreement() {
  const params = useParams<{ id: string }>();
  const agreementId = params.id;
  const [agreement, setAgreement] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [signerName, setSignerName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [signing, setSigning] = useState(false);
  const [signed, setSigned] = useState(false);
  const [signatureHash, setSignatureHash] = useState("");

  useEffect(() => {
    if (!agreementId) return;
    fetch(`/api/forensic/public/agreement/${agreementId}`)
      .then(r => { if (!r.ok) throw new Error("Agreement not found"); return r.json(); })
      .then(data => { setAgreement(data); if (data.clientName) setSignerName(data.clientName); if (data.clientEmail) setClientEmail(data.clientEmail); if (data.status === "signed") setSigned(true); })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [agreementId]);

  const handleSign = async () => {
    if (!agreed || !signerName) return;
    setSigning(true);
    try {
      const res = await fetch(`/api/forensic/public/agreement/${agreementId}/sign`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ signerName, clientEmail }),
      });
      const data = await res.json();
      if (data.success) {
        setSigned(true);
        setSignatureHash(data.signatureHash);
      } else {
        setError(data.message || "Failed to sign agreement");
      }
    } catch (e: any) {
      setError(e.message);
    }
    setSigning(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-[#0a0e14] flex items-center justify-center">
      <div className="text-cyan-400 text-lg animate-pulse">Loading Agreement...</div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-[#0a0e14] flex items-center justify-center">
      <div className="bg-[#161b22] rounded-lg border border-red-900/40 p-8 max-w-md text-center">
        <div className="text-red-400 text-lg font-bold mb-2">Error</div>
        <div className="text-gray-400 text-sm">{error}</div>
      </div>
    </div>
  );

  if (!agreement) return null;

  return (
    <div className="min-h-screen bg-[#0a0e14] text-gray-200">
      <div className="bg-[#0d1117] border-b border-cyan-900/30 py-4">
        <div className="max-w-4xl mx-auto px-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-lg flex items-center justify-center">
              <svg className="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-400" data-testid="text-agreement-header">Recovery Bounty Agreement</h1>
              <div className="text-[10px] text-gray-500">Alpha Unlimited Trading Company | Alpha Forensic Intelligence Engine&trade;</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {signed ? (
          <div className="bg-[#161b22] rounded-xl border border-green-900/40 p-8 text-center" data-testid="div-agreement-signed">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-8 w-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            </div>
            <h2 className="text-2xl font-bold text-green-400 mb-2">Agreement Signed</h2>
            <p className="text-gray-400 mb-4">This bounty recovery agreement has been digitally signed and recorded.</p>
            {signatureHash && (
              <div className="bg-[#0d1117] rounded-lg p-3 inline-block">
                <div className="text-[10px] text-gray-500 uppercase mb-1">Digital Signature Hash</div>
                <div className="text-xs font-mono text-cyan-400" data-testid="text-signature-hash">{signatureHash}</div>
              </div>
            )}
            <div className="mt-4 text-[10px] text-gray-600">A copy of this agreement and signature has been recorded in the Forensic Intelligence Engine&trade;.</div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-[#161b22] rounded-lg border border-cyan-900/30 p-4 text-center">
                <div className="text-[10px] text-gray-500 uppercase mb-1">Case</div>
                <div className="text-sm font-bold text-cyan-400" data-testid="text-agreement-case-name">{agreement.caseName}</div>
              </div>
              <div className="bg-[#161b22] rounded-lg border border-red-900/30 p-4 text-center">
                <div className="text-[10px] text-gray-500 uppercase mb-1">Total Stolen (Estimated)</div>
                <div className="text-sm font-bold text-red-400" data-testid="text-agreement-stolen">${Number(agreement.totalStolenUsd || 0).toLocaleString()}</div>
              </div>
              <div className="bg-[#161b22] rounded-lg border border-yellow-900/30 p-4 text-center">
                <div className="text-[10px] text-gray-500 uppercase mb-1">Recovery Bounty</div>
                <div className="text-sm font-bold text-yellow-400" data-testid="text-agreement-bounty-pct">{agreement.bountyPercentage}%</div>
              </div>
            </div>

            <div className="bg-[#161b22] rounded-xl border border-gray-800 mb-6">
              <div className="border-b border-gray-800 px-6 py-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-gray-300">Agreement Terms</h2>
                <span className="text-[10px] text-yellow-400/60">Please read carefully before signing</span>
              </div>
              <div className="px-6 py-4">
                <pre className="text-xs text-gray-300 whitespace-pre-wrap font-mono leading-relaxed max-h-[500px] overflow-y-auto" data-testid="text-agreement-content">{agreement.agreementText}</pre>
              </div>
            </div>

            <div className="bg-[#161b22] rounded-xl border border-yellow-900/40 p-6">
              <h3 className="text-sm font-bold text-yellow-400 mb-4">Sign This Agreement</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-[10px] text-gray-500 uppercase mb-1">Your Full Name (required)</label>
                  <input data-testid="input-signer-name" value={signerName} onChange={e => setSignerName(e.target.value)} placeholder="Enter your full legal name" className="w-full bg-[#0d1117] border border-gray-700 rounded-lg px-4 py-3 text-sm text-gray-200 focus:border-yellow-500/50 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 uppercase mb-1">Your Email (optional)</label>
                  <input data-testid="input-signer-email" type="email" value={clientEmail} onChange={e => setClientEmail(e.target.value)} placeholder="you@example.com" className="w-full bg-[#0d1117] border border-gray-700 rounded-lg px-4 py-3 text-sm text-gray-200 focus:border-yellow-500/50 focus:outline-none" />
                </div>
              </div>
              <label className="flex items-start gap-3 cursor-pointer mb-4 p-3 rounded-lg hover:bg-[#0d1117]/50">
                <input data-testid="checkbox-agree" type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="mt-1 rounded border-gray-600 text-yellow-500 focus:ring-yellow-500 bg-[#0d1117]" />
                <span className="text-xs text-gray-300 leading-relaxed">I have read and understood the full terms of this Recovery Bounty Agreement. I agree to pay the specified bounty percentage of all recovered cryptocurrency assets to Alpha Unlimited Trading Company as compensation for forensic investigation services. I understand that this digital signature has the same legal effect as a handwritten signature.</span>
              </label>
              <button data-testid="button-sign-agreement" disabled={!agreed || !signerName || signing} onClick={handleSign} className="w-full py-3 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-500 hover:to-amber-500 text-white rounded-lg font-bold text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all">
                {signing ? "Signing Agreement..." : "Sign Agreement"}
              </button>
              <div className="text-center text-[10px] text-gray-600 mt-3">Your digital signature will be cryptographically recorded with timestamp, IP address, and a SHA-256 hash for legal verification.</div>
            </div>
          </>
        )}

        <div className="text-center text-[9px] text-gray-700 mt-8 border-t border-gray-900 pt-4">
          &copy; 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved. | Alpha Forensic Intelligence Engine&trade; | Protected by international copyright and trade secret laws.
        </div>
      </div>
    </div>
  );
}
