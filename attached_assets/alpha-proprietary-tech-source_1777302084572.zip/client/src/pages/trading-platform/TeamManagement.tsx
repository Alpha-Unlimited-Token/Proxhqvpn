import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  accessCode: string;
  status: string;
  lastLoginAt: string | null;
  createdAt: string;
}

interface CodeSubmission {
  id: string;
  teamMemberId: string;
  teamMemberName: string;
  technologyName: string;
  fileName: string;
  description: string;
  submittedCode: string;
  status: string;
  adminNotes: string | null;
  reviewedAt: string | null;
  createdAt: string;
}

type AdminTab = "members" | "submissions";

export default function TeamManagement() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<AdminTab>("members");
  const [showAddForm, setShowAddForm] = useState(false);
  const [addForm, setAddForm] = useState({ name: "", email: "", role: "investigator" });
  const [reviewingSubmission, setReviewingSubmission] = useState<CodeSubmission | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");

  const { data: members = [], isLoading: membersLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/admin/team-members"],
    queryFn: async () => {
      const r = await fetch("/api/admin/team-members", { credentials: "include" });
      if (!r.ok) return [];
      return r.json();
    },
  });

  const { data: submissions = [], isLoading: submissionsLoading } = useQuery<CodeSubmission[]>({
    queryKey: ["/api/admin/code-submissions"],
    queryFn: async () => {
      const r = await fetch("/api/admin/code-submissions", { credentials: "include" });
      if (!r.ok) return [];
      return r.json();
    },
  });

  const addMember = useMutation({
    mutationFn: async (data: typeof addForm) => {
      const res = await fetch("/api/admin/team-members", {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).message);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/team-members"] });
      setShowAddForm(false);
      setAddForm({ name: "", email: "", role: "investigator" });
      setGeneratedCode(data.accessCode);
      setStatusMessage(`Team member ${data.name} added! Share their access code with them securely.`);
    },
  });

  const toggleMemberStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await fetch(`/api/admin/team-members/${id}`, {
        method: "PATCH", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/admin/team-members"] }),
  });

  const removeMember = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/admin/team-members/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/admin/team-members"] }),
  });

  const reviewSubmission = useMutation({
    mutationFn: async ({ id, status, adminNotes }: { id: string; status: string; adminNotes: string }) => {
      const res = await fetch(`/api/admin/code-submissions/${id}`, {
        method: "PATCH", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, adminNotes }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/code-submissions"] });
      setReviewingSubmission(null);
      setReviewNotes("");
    },
  });

  const pendingCount = submissions.filter(s => s.status === "pending").length;

  return (
    <div className="min-h-screen bg-[#050a12] pb-24">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="text-xs tracking-[3px] text-[#d4a017] mb-1">ADMIN CONTROL</div>
            <h1 className="text-3xl font-bold text-white">Team Management</h1>
            <p className="text-gray-400 text-sm mt-1">Manage forensic investigation team members and code submissions</p>
          </div>
        </div>

        <div className="flex gap-3 mb-6">
          <button data-testid="button-admin-tab-members" onClick={() => setTab("members")} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === "members" ? "bg-[#d4a017]/20 border border-[#d4a017] text-[#d4a017]" : "bg-[#111] border border-[#333] text-gray-400 hover:text-white"}`}>
            Team Members ({members.length})
          </button>
          <button data-testid="button-admin-tab-submissions" onClick={() => setTab("submissions")} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all relative ${tab === "submissions" ? "bg-[#d4a017]/20 border border-[#d4a017] text-[#d4a017]" : "bg-[#111] border border-[#333] text-gray-400 hover:text-white"}`}>
            Code Submissions ({submissions.length})
            {pendingCount > 0 && <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">{pendingCount}</span>}
          </button>
        </div>

        {statusMessage && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 mb-6">
            <p className="text-green-400 text-sm">{statusMessage}</p>
            {generatedCode && (
              <div className="mt-2 bg-[#0a0f1a] rounded-lg p-3">
                <div className="text-xs text-gray-400 mb-1">Access Code (share securely — shown only once):</div>
                <div className="text-lg font-mono text-[#d4a017] font-bold select-all">{generatedCode}</div>
              </div>
            )}
            <button onClick={() => { setStatusMessage(""); setGeneratedCode(""); }} className="mt-2 text-xs text-gray-500 hover:text-gray-300">Dismiss</button>
          </div>
        )}

        <AnimatePresence mode="wait">
          {tab === "members" && (
            <motion.div key="members" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="flex justify-end mb-4">
                <button data-testid="button-add-member" onClick={() => setShowAddForm(!showAddForm)} className="px-4 py-2 bg-gradient-to-r from-[#d4a017] to-[#b8860b] text-black font-bold rounded-lg text-sm">
                  {showAddForm ? "Cancel" : "+ Add Team Member"}
                </button>
              </div>

              {showAddForm && (
                <div className="bg-[#111] border border-[#d4a017]/30 rounded-xl p-6 mb-6">
                  <h3 className="text-white font-bold mb-4">Add New Team Member</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Full Name</label>
                      <input data-testid="input-member-name" value={addForm.name} onChange={e => setAddForm(p => ({ ...p, name: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm" placeholder="John Smith" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Email</label>
                      <input data-testid="input-member-email" value={addForm.email} onChange={e => setAddForm(p => ({ ...p, email: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm" placeholder="team@email.com" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Role</label>
                      <select data-testid="select-member-role" value={addForm.role} onChange={e => setAddForm(p => ({ ...p, role: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm">
                        <option value="investigator">Investigator</option>
                        <option value="analyst">Analyst</option>
                        <option value="lead_investigator">Lead Investigator</option>
                        <option value="forensic_engineer">Forensic Engineer</option>
                        <option value="consultant">Consultant</option>
                      </select>
                    </div>
                  </div>
                  <button data-testid="button-save-member" onClick={() => addMember.mutate(addForm)} disabled={!addForm.name || !addForm.email || addMember.isPending} className="px-6 py-2 bg-gradient-to-r from-[#d4a017] to-[#b8860b] text-black font-bold rounded-lg text-sm disabled:opacity-50">
                    {addMember.isPending ? "Creating..." : "Create Team Member"}
                  </button>
                  {addMember.isError && <p className="text-red-400 text-sm mt-2">{(addMember.error as Error).message}</p>}
                </div>
              )}

              <div className="grid gap-3">
                {membersLoading && <div className="text-gray-500 text-center py-12">Loading...</div>}
                {members.length === 0 && !membersLoading && <div className="text-gray-500 text-center py-12">No team members yet</div>}
                {members.map(m => (
                  <div key={m.id} data-testid={`card-member-${m.id}`} className="bg-[#111] border border-[#333] rounded-xl p-4 flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h4 className="text-white font-bold">{m.name}</h4>
                        <span className="px-2 py-0.5 rounded text-xs bg-[#d4a017]/20 text-[#d4a017]">{m.role}</span>
                        <span className={`px-2 py-0.5 rounded text-xs ${m.status === "active" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>{m.status}</span>
                      </div>
                      <div className="text-sm text-gray-400">{m.email}</div>
                      <div className="text-xs text-gray-600 mt-1">
                        Joined: {new Date(m.createdAt).toLocaleDateString()} {m.lastLoginAt ? `• Last login: ${new Date(m.lastLoginAt).toLocaleString()}` : "• Never logged in"}
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button data-testid={`button-toggle-${m.id}`} onClick={() => toggleMemberStatus.mutate({ id: m.id, status: m.status === "active" ? "suspended" : "active" })} className={`px-3 py-2 rounded-lg text-xs font-medium ${m.status === "active" ? "bg-yellow-500/10 border border-yellow-500/30 text-yellow-400" : "bg-green-500/10 border border-green-500/30 text-green-400"}`}>
                        {m.status === "active" ? "Suspend" : "Activate"}
                      </button>
                      <button data-testid={`button-remove-${m.id}`} onClick={() => { if (confirm(`Remove ${m.name} from the team?`)) removeMember.mutate(m.id); }} className="px-3 py-2 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400 font-medium">
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {tab === "submissions" && (
            <motion.div key="submissions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {reviewingSubmission && (
                <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setReviewingSubmission(null)}>
                  <div className="bg-[#111] border border-[#333] rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                    <div className="p-6 border-b border-[#333]">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-white">{reviewingSubmission.technologyName}</h3>
                          <div className="text-sm text-gray-400 mt-1">File: {reviewingSubmission.fileName} • By: {reviewingSubmission.teamMemberName}</div>
                        </div>
                        <button onClick={() => setReviewingSubmission(null)} className="text-gray-400 hover:text-white text-2xl">&times;</button>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="mb-4">
                        <div className="text-xs text-gray-500 mb-1">Description:</div>
                        <p className="text-sm text-white">{reviewingSubmission.description}</p>
                      </div>
                      <div className="mb-4">
                        <div className="text-xs text-gray-500 mb-2">Submitted Code:</div>
                        <pre className="bg-[#0a0f1a] border border-[#333] rounded-lg p-4 text-xs text-green-400 font-mono overflow-x-auto max-h-[400px] overflow-y-auto">{reviewingSubmission.submittedCode}</pre>
                      </div>
                      {reviewingSubmission.status === "pending" && (
                        <div className="border-t border-[#333] pt-4 mt-4">
                          <div className="mb-3">
                            <label className="text-xs text-gray-400 block mb-1">Admin Notes</label>
                            <textarea value={reviewNotes} onChange={e => setReviewNotes(e.target.value)} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm h-20 resize-none" placeholder="Notes for the team member..." />
                          </div>
                          <div className="flex gap-3">
                            <button data-testid="button-approve-submission" onClick={() => reviewSubmission.mutate({ id: reviewingSubmission.id, status: "approved", adminNotes: reviewNotes })} className="px-6 py-2 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 font-bold text-sm">
                              Approve
                            </button>
                            <button data-testid="button-reject-submission" onClick={() => reviewSubmission.mutate({ id: reviewingSubmission.id, status: "rejected", adminNotes: reviewNotes })} className="px-6 py-2 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 font-bold text-sm">
                              Reject
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="grid gap-3">
                {submissionsLoading && <div className="text-gray-500 text-center py-12">Loading...</div>}
                {submissions.length === 0 && !submissionsLoading && <div className="text-gray-500 text-center py-12">No code submissions yet</div>}
                {submissions.map(s => (
                  <div key={s.id} data-testid={`card-admin-submission-${s.id}`} className={`bg-[#111] border rounded-xl p-4 cursor-pointer hover:bg-[#1a1a2e] transition-all ${s.status === "pending" ? "border-yellow-500/30" : "border-[#333]"}`} onClick={() => { setReviewingSubmission(s); setReviewNotes(""); }}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <h4 className="text-white font-medium">{s.technologyName}</h4>
                        <span className="text-xs text-gray-500">{s.fileName}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${s.status === "pending" ? "bg-yellow-500/20 text-yellow-400" : s.status === "approved" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>{s.status?.toUpperCase()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">{s.description.length > 100 ? s.description.slice(0, 100) + "..." : s.description}</p>
                        <div className="text-xs text-gray-600 mt-1">By: {s.teamMemberName} • {new Date(s.createdAt).toLocaleString()}</div>
                      </div>
                      <div className="text-xs text-[#d4a017] ml-4">Click to review →</div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}