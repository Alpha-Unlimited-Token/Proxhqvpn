/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Law Enforcement Technology Briefing Page™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Alpha Law Enforcement Briefing Interface™
 * - Alpha Forensic Intelligence Engine™ Documentation
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: LAW_ENFORCEMENT_PAGE_v1.0_PROTECTED
 * AUT_ModuleHash: AUT_le_page_interface_01
 */

import { useState } from "react";
import { motion } from "framer-motion";

const COPYRIGHT = "© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity. Patent Pending.";

const TECH_SECTIONS = [
  {
    title: "Alpha Spider Beacon Protocol™",
    color: "emerald",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>
    ),
    description: "Cross-chain persistent surveillance beacon system that deploys tracking beacons across 20+ blockchain networks to monitor stolen funds in real-time.",
    details: [
      "Deploy beacons on any wallet address across Ethereum, Bitcoin, Arbitrum, Polygon, BSC, Solana, and 15+ additional chains",
      "Cross-chain beacons automatically expand to monitor the same address across multiple networks simultaneously",
      "Real-time signal relay: every balance change, transfer, DEX interaction, or bridge usage triggers an alert in the Command Center",
      "Dormant beacons on other chains activate automatically when cross-chain activity is detected",
      "Five beacon types: Address Monitor, Cross-Chain, DEX Watcher, Bridge Sentinel, and AUC Trap",
    ],
    howItWorks: "An investigator selects a wallet address and blockchain, then deploys a beacon. The system periodically queries blockchain explorers (Blockscout, Blockchain.info, Solana RPC) for any activity on that address. When changes are detected — balance shifts, new transactions, contract interactions — a signal is generated with full details (timestamp, counterparty, amount, tx hash) and displayed in the Forensic Command Center.",
  },
  {
    title: "AUC Trap Mechanism™",
    color: "red",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
    ),
    description: "Token swap surveillance tool — when law enforcement swaps stolen tokens into Alpha Unlimited Coin (AUC), every subsequent AUC transfer triggers an automatic alert with full transaction details.",
    details: [
      "Stolen tokens are swapped to AUC, which has built-in blockchain transfer hooks",
      "Every AUC transfer involving the trapped wallet fires an immediate CRITICAL signal",
      "Captures sender address, recipient address, amount, and timestamp for every movement",
      "Simultaneously monitors the original theft address for swap-back activity",
      "Creates a two-pronged surveillance net: AUC transfer hooks + original address beacon",
    ],
    howItWorks: "When law enforcement gains legal access to a wallet with stolen tokens, those tokens are exchanged for AUC via the Alpha Unlimited Coin Exchange. The AUC blockchain is fully instrumented — every transaction on the chain runs through transfer hooks that report to the Forensic Command Center. If the suspect tries to move or convert the AUC, the system instantly captures the destination wallet. Meanwhile, a separate beacon watches the original theft address for any parallel activity.",
  },
  {
    title: "Autonomous Spider Trace™",
    color: "cyan",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    ),
    description: "Recursive multi-hop fund flow analysis that traces stolen cryptocurrency from victim to final destination, identifying exchanges, bridges, mixers, and intermediary wallets.",
    details: [
      "Starts at the victim wallet and recursively follows all outgoing transactions",
      "Classifies discovered addresses by role: Exchange, Bridge, Mixer, Intermediary, Drainer",
      "Identifies known exchange deposit addresses (Binance, Coinbase, Kraken, Crypto.com, etc.)",
      "Detects bridge usage (Hop, Stargate, Across) and mixing service interactions (Tornado Cash)",
      "Interactive fund flow visualization with zoom, pan, and click-to-inspect",
      "Automatically adds discovered wallets to monitoring",
    ],
    howItWorks: "The Spider Trace queries blockchain explorer APIs to retrieve all transactions from the victim's address. For each recipient address, it checks against databases of known exchange and bridge addresses, then recursively traces the next hop. The result is a complete fund flow tree showing exactly where every dollar went. Exchange deposits are actionable — they indicate the suspect has interacted with a KYC-compliant service where law enforcement can serve legal process.",
  },
  {
    title: "Alpha Phantom Vault Protocol™",
    color: "yellow",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
    ),
    description: "Honeypot wallet deployment system — creates decoy wallets that appear to hold valuable tokens, capturing any suspect interactions.",
    details: [
      "Deploy decoy wallets on any supported blockchain with simulated balances",
      "Supports multiple token types: USDC, USDT, ETH, DAI, WBTC",
      "When a suspect interacts with the vault, captures their wallet address and transaction details",
      "Reveals gas fee payment sources, which may expose the suspect's primary wallet",
      "Triggered addresses are automatically added to monitoring with Spider Beacons",
      "Analogous to bait cars or dye packs in traditional law enforcement",
    ],
    howItWorks: "An investigator deploys a Phantom Vault on a specified chain with a chosen token type and amount. The vault address is strategically placed where the suspect is likely to encounter it. When any address sends a transaction to the vault, the system captures the sender's identity (wallet address), the gas fee source (which may be a different wallet), and generates a critical alert. The triggering address is automatically added to the monitoring system.",
  },
  {
    title: "Exchange Freeze Request System™",
    color: "blue",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
    ),
    description: "Automated generation of formal, evidence-backed freeze requests for cryptocurrency exchanges when stolen funds are identified at regulated platforms.",
    details: [
      "Generates formal requests with case reference, victim info, and on-chain evidence",
      "Includes transaction hashes showing the complete flow from victim to exchange",
      "Supports all major exchanges: Binance, Coinbase, Kraken, OKX, Crypto.com, and more",
      "Batch freeze capability when funds are identified at multiple exchanges simultaneously",
      "Status tracking: Pending, Sent, Acknowledged, Frozen, Rejected",
    ],
    howItWorks: "When Spider Trace or beacon signals identify that stolen funds have arrived at a known exchange address, the investigator initiates a freeze request. The system compiles the evidence chain (victim wallet → intermediary wallets → exchange deposit address), formats it into a formal compliance request, and sends it to the exchange's compliance department email. The request includes estimated value, relevant transaction hashes, and can reference a court order or law enforcement badge number.",
  },
  {
    title: "Laundering Risk Intelligence™",
    color: "amber",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
    ),
    description: "Identifies how stolen funds are being laundered — Tornado Cash mixing, Monero conversion, and DeFi protocol freeze gaps — to guide recovery strategy.",
    details: [
      "Monitors 17 known Tornado Cash contracts for DAI mixing activity",
      "Tracks 11 Monero on-ramp services: Wagyu Bridge, ChangeNOW, FixedFloat, and more",
      "Classifies tokens as freezeable (USDC, USDT) vs. unfreezable (DAI, WETH, LUSD)",
      "Documents specific protocol-level gaps preventing freeze/recovery",
      "Real-time alerts for tornado_cash_interaction, monero_conversion, and unfreezable_token_movement",
    ],
    howItWorks: "The system analyzes token flows through known laundering infrastructure. For each transaction, it checks if the destination matches Tornado Cash pool contracts (100, 1K, 10K, 100K DAI), Monero on-ramp addresses, or DeFi protocols without freeze capability. This intelligence tells law enforcement which assets CAN be frozen (USDC via Circle, USDT via Tether) versus which require alternative recovery strategies (DAI has no central freeze authority).",
  },
  {
    title: "OSINT Intelligence Spider™",
    color: "green",
    icon: (
      <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>
    ),
    description: "Scans open-source intelligence platforms for any public exposure of wallet addresses connected to the investigation.",
    details: [
      "Scans Pastebin, GitHub, social media, blockchain forums, and dark web archives",
      "Identifies leaked private keys, wallet dumps, and operational notes",
      "Risk classification with source URLs and context snippets",
      "Transaction Origin Intelligence traces where theft transactions were initiated from",
      "Network Intelligence Tracer builds digital profiles from IP/device metadata",
    ],
    howItWorks: "The OSINT Spider takes wallet addresses from the investigation and searches public data sources for any mentions. This can reveal the suspect's operational security mistakes — addresses posted on forums, private keys accidentally committed to GitHub, or wallets mentioned in dark web marketplace listings. Combined with Network Intelligence (IP analysis, device fingerprinting, time zone detection), this builds a comprehensive attacker profile.",
  },
];

export default function LawEnforcementBriefing() {
  const [downloading, setDownloading] = useState<string | null>(null);
  const [emailForm, setEmailForm] = useState({ recipientEmail: "", recipientName: "", message: "" });
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [expandedSection, setExpandedSection] = useState<number | null>(null);

  const handleDownloadFile = async (endpoint: string, filename: string, key: string) => {
    setDownloading(key);
    try {
      const resp = await fetch(endpoint, { credentials: "include" });
      if (!resp.ok) throw new Error("Download failed");
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      alert("Download failed: " + e.message);
    } finally {
      setDownloading(null);
    }
  };

  const handleDownload = () => handleDownloadFile(
    "/api/forensic/law-enforcement/download-briefing",
    "Alpha-Forensic-Intelligence-Engine-Law-Enforcement-Briefing.pptx",
    "briefing"
  );

  const handleEmail = async () => {
    if (!emailForm.recipientEmail) return;
    setSending(true);
    setResult(null);
    try {
      const resp = await fetch("/api/forensic/law-enforcement/email-briefing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(emailForm),
      });
      const data = await resp.json();
      if (resp.ok && data.success) {
        setResult({ ok: true, msg: `Briefing sent successfully to ${emailForm.recipientEmail}` });
        setEmailForm({ recipientEmail: "", recipientName: "", message: "" });
      } else {
        setResult({ ok: false, msg: data.message || "Failed to send" });
      }
    } catch (e: any) {
      setResult({ ok: false, msg: e.message });
    } finally {
      setSending(false);
    }
  };

  const colorMap: Record<string, { border: string; text: string; bg: string; glow: string }> = {
    emerald: { border: "border-emerald-700/40", text: "text-emerald-400", bg: "bg-emerald-900/20", glow: "from-emerald-600/10" },
    red: { border: "border-red-700/40", text: "text-red-400", bg: "bg-red-900/20", glow: "from-red-600/10" },
    cyan: { border: "border-cyan-700/40", text: "text-cyan-400", bg: "bg-cyan-900/20", glow: "from-cyan-600/10" },
    yellow: { border: "border-yellow-700/40", text: "text-yellow-400", bg: "bg-yellow-900/20", glow: "from-yellow-600/10" },
    blue: { border: "border-blue-700/40", text: "text-blue-400", bg: "bg-blue-900/20", glow: "from-blue-600/10" },
    amber: { border: "border-amber-700/40", text: "text-amber-400", bg: "bg-amber-900/20", glow: "from-amber-600/10" },
    green: { border: "border-green-700/40", text: "text-green-400", bg: "bg-green-900/20", glow: "from-green-600/10" },
  };

  return (
    <div className="min-h-screen bg-[#0a0e14] text-gray-200">
      <div className="border-b border-cyan-900/30 bg-[#0d1117]/90 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img
                src="/forensic-phoenix-tiktok-bg2.png"
                alt="Alpha Phoenix Detective"
                className="w-36 h-36 md:w-48 md:h-48 object-contain drop-shadow-[0_0_25px_rgba(0,212,255,0.4)]"
                data-testid="img-le-phoenix"
              />
              <div>
                <div className="text-xs text-red-400 font-bold tracking-wider mb-1">CONFIDENTIAL — FOR LAW ENFORCEMENT USE ONLY</div>
                <h1 className="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400" data-testid="text-le-title">
                  Alpha Forensic Intelligence Engine&trade;
                </h1>
                <p className="text-gray-400 text-sm mt-1">Cryptocurrency Theft Investigation &amp; Recovery Technology Platform</p>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <button
                data-testid="button-download-briefing"
                onClick={handleDownload}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "briefing" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Generating...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg> Tech Briefing (18 slides)</>
                )}
              </button>
              <button
                data-testid="button-download-le-proposal"
                onClick={() => handleDownloadFile("/api/forensic/law-enforcement/download-le-proposal", "Alpha-Forensic-Engine-Law-Enforcement-Adoption-Proposal.pptx", "le-proposal")}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "le-proposal" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Generating...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg> Law Enforcement Proposal (20 slides)</>
                )}
              </button>
              <button
                data-testid="button-download-exchange-proposal"
                onClick={() => handleDownloadFile("/api/forensic/law-enforcement/download-exchange-proposal", "AUC-Exchange-Listing-Proposal.pptx", "exchange-proposal")}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "exchange-proposal" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Generating...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg> Exchange Listing Proposal (20 slides)</>
                )}
              </button>
              <button
                data-testid="button-download-master-fxusd"
                onClick={() => handleDownloadFile("/api/forensic/law-enforcement/download-master-fxusd", "Sillytuna-Master-FXUSD-Anchored-Evidence.txt", "master-fxusd")}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "master-fxusd" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Downloading...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg> Master FXUSD Evidence (64 Wallets, 1435 TXs)</>
                )}
              </button>
              <button
                data-testid="button-download-crypto-com-chain"
                onClick={() => handleDownloadFile("/api/forensic/law-enforcement/download-crypto-com-chain", "Sillytuna-CryptoCom-Full-Chain-Trace-Evidence.txt", "crypto-com-chain")}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "crypto-com-chain" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Downloading...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg> Crypto.com Chain Trace (3,678 TXs)</>
                )}
              </button>
              <button
                data-testid="button-download-fxusd-chain"
                onClick={() => handleDownloadFile("/api/forensic/law-enforcement/download-fxusd-chain", "Sillytuna-FXUSD-Source-CryptoCom-Evidence-Chain.txt", "fxusd-chain")}
                disabled={!!downloading}
                className="w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-xs font-medium transition-all flex items-center gap-2"
              >
                {downloading === "fxusd-chain" ? (
                  <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Downloading...</>
                ) : (
                  <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg> FXUSD Source Evidence Chain (LE Subpoena)</>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-6">
            <h2 className="text-lg font-bold text-cyan-400 mb-3" data-testid="text-overview-title">Platform Overview</h2>
            <p className="text-gray-300 text-sm leading-relaxed mb-4">
              The Alpha Forensic Intelligence Engine&trade; is a proprietary cryptocurrency investigation platform designed to assist law enforcement agencies in tracking, analyzing, and recovering stolen digital assets across multiple blockchain networks. The platform processes real blockchain data from 20+ networks simultaneously, providing real-time monitoring, automated alerting, and comprehensive evidence compilation for prosecution.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "Blockchain Networks", value: "20+", color: "text-cyan-400" },
                { label: "Proprietary Technologies", value: "15+", color: "text-emerald-400" },
                { label: "Investigation Tools", value: "16 Tabs", color: "text-blue-400" },
                { label: "Export Formats", value: "JSON/CSV/PPTX", color: "text-amber-400" },
              ].map(s => (
                <div key={s.label} className="bg-[#0d1117] rounded-lg p-3 text-center">
                  <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-[10px] text-gray-500 mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        <div className="space-y-4 mb-10">
          {TECH_SECTIONS.map((section, idx) => {
            const c = colorMap[section.color] || colorMap.cyan;
            const isExpanded = expandedSection === idx;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className={`bg-[#161b22] rounded-xl border ${c.border} overflow-hidden`}
              >
                <button
                  data-testid={`button-expand-section-${idx}`}
                  onClick={() => setExpandedSection(isExpanded ? null : idx)}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/[0.02] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`${c.text}`}>{section.icon}</div>
                    <div className="text-left">
                      <h3 className={`text-base font-bold ${c.text}`}>{section.title}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{section.description}</p>
                    </div>
                  </div>
                  <svg className={`h-5 w-5 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </button>

                {isExpanded && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} className="px-6 pb-5">
                    <div className="border-t border-gray-800/50 pt-4">
                      <div className="mb-4">
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Key Capabilities</h4>
                        <ul className="space-y-1.5">
                          {section.details.map((detail, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                              <span className={`${c.text} mt-1 text-xs`}>&#9679;</span>
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className={`${c.bg} rounded-lg p-4`}>
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">How It Works</h4>
                        <p className="text-sm text-gray-300 leading-relaxed">{section.howItWorks}</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="bg-[#161b22] rounded-xl border border-red-900/40 p-6">
            <h2 className="text-lg font-bold text-red-400 mb-3" data-testid="text-case-study-title">Case Study: @sillytuna — $24M Cryptocurrency Theft</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {[
                { label: "Victim", value: "Alex Amsel", color: "text-gray-200" },
                { label: "Handle", value: "@sillytuna", color: "text-cyan-400" },
                { label: "Estimated Loss", value: "~$24,000,000", color: "text-red-400" },
                { label: "Attack Type", value: "Physical Theft", color: "text-amber-400" },
              ].map(s => (
                <div key={s.label} className="bg-[#0d1117] rounded-lg p-3">
                  <div className="text-[10px] text-gray-500">{s.label}</div>
                  <div className={`text-sm font-bold ${s.color}`}>{s.value}</div>
                </div>
              ))}
            </div>
            <div className="text-sm text-gray-300 space-y-2">
              <p><strong className="text-gray-200">Fund Dispersal Traced by Alpha Forensic Intelligence Engine&trade;:</strong></p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  { label: "DAI Conversion", amount: "~$20,000,000", detail: "Dispersed across 12+ wallets. DAI chosen because it cannot be frozen.", color: "text-amber-400" },
                  { label: "Monero Conversion", amount: "~$2,470,000", detail: "19 Hyperliquid accounts via Wagyu Bridge to untraceable Monero.", color: "text-purple-400" },
                  { label: "Bitcoin via LiFi Bridge", amount: "~$1,100,000", detail: "Cross-chain to Bitcoin. ~0.5 BTC suspected mixer involvement.", color: "text-orange-400" },
                  { label: "Arbitrum USDC", amount: "~$2,480,000", detail: "10 receiver addresses. USDC is freezeable via Circle.", color: "text-blue-400" },
                ].map(item => (
                  <div key={item.label} className="bg-[#0d1117] rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-gray-400">{item.label}</span>
                      <span className={`text-sm font-bold ${item.color}`}>{item.amount}</span>
                    </div>
                    <p className="text-[11px] text-gray-500">{item.detail}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 bg-red-900/10 border border-red-800/30 rounded-lg p-3">
                <p className="text-xs text-red-400 font-bold mb-1">SMOKING GUN — Crypto.com Deposit</p>
                <p className="text-xs text-gray-400">
                  Address <span className="font-mono text-cyan-400">0x6583706...fad846</span> received 155,017.66 USDC at Crypto.com. 
                  This exchange has KYC (Know Your Customer) records that can identify the account holder upon legal request.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="bg-[#161b22] rounded-xl border border-amber-900/40 p-6">
            <h2 className="text-lg font-bold text-amber-400 mb-3" data-testid="text-email-title">Email Briefing Package</h2>
            <p className="text-xs text-gray-500 mb-4">Send the complete technology briefing (PowerPoint + overview) to law enforcement contacts, attorneys, or the victim for forwarding to investigators.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Recipient Email *</label>
                <input
                  data-testid="input-le-email"
                  type="email"
                  value={emailForm.recipientEmail}
                  onChange={e => setEmailForm(f => ({ ...f, recipientEmail: e.target.value }))}
                  placeholder="detective@agency.gov"
                  className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-amber-500 outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Recipient Name</label>
                <input
                  data-testid="input-le-name"
                  type="text"
                  value={emailForm.recipientName}
                  onChange={e => setEmailForm(f => ({ ...f, recipientName: e.target.value }))}
                  placeholder="Detective Smith"
                  className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-amber-500 outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Custom Message (optional)</label>
                <input
                  data-testid="input-le-message"
                  type="text"
                  value={emailForm.message}
                  onChange={e => setEmailForm(f => ({ ...f, message: e.target.value }))}
                  placeholder="Additional context..."
                  className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-amber-500 outline-none"
                />
              </div>
            </div>
            {result && (
              <div className={`mb-3 text-xs px-3 py-2 rounded ${result.ok ? "text-green-400 bg-green-900/30 border border-green-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`}>
                {result.msg}
              </div>
            )}
            <button
              data-testid="button-send-briefing"
              disabled={sending || !emailForm.recipientEmail}
              onClick={handleEmail}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium transition-all flex items-center gap-2"
            >
              {sending ? (
                <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Sending...</>
              ) : (
                <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg> Send Briefing with PowerPoint</>
              )}
            </button>
          </div>
        </motion.div>

        <div className="border-t border-gray-800/50 pt-6 text-center">
          <p className="text-[10px] text-gray-600 leading-relaxed max-w-3xl mx-auto">
            {COPYRIGHT}<br />
            All technologies referenced on this page — including Alpha Forensic Intelligence Engine&trade;, Alpha Spider Beacon Protocol&trade;, AUC Trap Mechanism&trade;, Autonomous Spider Trace&trade;, Alpha Phantom Vault Protocol&trade;, Exchange Freeze Request System&trade;, OSINT Intelligence Spider&trade;, Laundering Risk Intelligence&trade;, Transaction Origin Intelligence&trade;, Network Intelligence Tracer&trade;, Cross-Case Intelligence Engine&trade;, Alpha Wallet Monitor Service&trade;, and Alpha Spider Beacon Protocol&trade; Cross-Chain Intelligence Layer&trade; — are proprietary intellectual property of Alpha Unlimited Trading Company. Protected by international copyright, trade secret, and pending patent applications. Unauthorized reproduction, distribution, reverse engineering, or use is strictly prohibited.
          </p>
        </div>
      </div>
    </div>
  );
}
