/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Forensic Email Intelligence System™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Forensic Email Intelligence™
 * - Case Communication Engine™
 * - Evidence Delivery System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_23292ac3dc2e328441fd10e3
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import {
  Mail, Inbox, Send, Trash2, RefreshCw, ChevronLeft, ChevronRight,
  Search, Plus, Reply, AlertCircle, Loader2, MailOpen, Clock,
  ArrowLeft, X, Paperclip, User, AtSign
} from "lucide-react";

interface InboxInfo {
  id: string;
  username: string;
  domain: string;
  displayName?: string;
}

interface Thread {
  id: string;
  subject: string;
  snippet?: string;
  from?: string;
  to?: string[];
  lastMessageAt?: string;
  createdAt?: string;
  messageCount?: number;
  messages?: Message[];
}

interface Message {
  id: string;
  from: string;
  to: string[];
  subject: string;
  body: string;
  html?: string;
  createdAt: string;
  threadId?: string;
}

const COLOR = "#00D4FF";
const BG = "#0D1117";
const CARD_BG = "#152238";
const BORDER = "#1A2942";

export default function EmailInbox() {
  const { user } = useAuth();
  const [inboxes, setInboxes] = useState<InboxInfo[]>([]);
  const [selectedInbox, setSelectedInbox] = useState<InboxInfo | null>(null);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [selectedThread, setSelectedThread] = useState<Thread | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingThreads, setLoadingThreads] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCompose, setShowCompose] = useState(false);
  const [showReply, setShowReply] = useState(false);
  const [composeTo, setComposeTo] = useState("");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeBody, setComposeBody] = useState("");
  const [sending, setSending] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [replyBody, setReplyBody] = useState("");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Email Inbox - Alpha Unlimited Trading";
  }, []);

  const fetchInboxes = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch("/api/support/inboxes", { credentials: "include" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "Failed to fetch inboxes");
      }
      const data = await res.json();
      const inboxList = Array.isArray(data) ? data : data.data || [];
      setInboxes(inboxList);
      if (inboxList.length > 0 && !selectedInbox) {
        setSelectedInbox(inboxList[0]);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchThreads = useCallback(async (inboxId: string) => {
    try {
      setLoadingThreads(true);
      const res = await fetch(`/api/support/emails/${inboxId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch emails");
      const data = await res.json();
      const threadList = Array.isArray(data) ? data : data.data || data.threads || [];
      setThreads(threadList);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoadingThreads(false);
    }
  }, []);

  const fetchThread = useCallback(async (inboxId: string, threadId: string) => {
    try {
      setLoadingMessages(true);
      const res = await fetch(`/api/support/thread/${inboxId}/${threadId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch thread");
      const data = await res.json();
      const msgs = data.messages || data.data?.messages || (Array.isArray(data) ? data : []);
      msgs.sort((a: Message, b: Message) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime());
      setMessages(msgs);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoadingMessages(false);
    }
  }, []);

  useEffect(() => {
    if (user) fetchInboxes();
  }, [user, fetchInboxes]);

  useEffect(() => {
    if (selectedInbox) {
      fetchThreads(selectedInbox.id);
      setSelectedThread(null);
      setMessages([]);
    }
  }, [selectedInbox, fetchThreads]);

  const handleSelectThread = (thread: Thread) => {
    setSelectedThread(thread);
    if (selectedInbox) fetchThread(selectedInbox.id, thread.id);
  };

  const handleSend = async () => {
    if (!selectedInbox || !composeTo.trim() || !composeSubject.trim() || !composeBody.trim()) return;
    setSending(true);
    setError(null);
    try {
      await apiRequest("POST", "/api/support/send", {
        inboxId: selectedInbox.id,
        to: composeTo.split(",").map(e => e.trim()),
        subject: composeSubject,
        body: composeBody,
      });
      setShowCompose(false);
      setComposeTo("");
      setComposeSubject("");
      setComposeBody("");
      setSuccessMessage("Email sent successfully");
      setTimeout(() => setSuccessMessage(null), 3000);
      fetchThreads(selectedInbox.id);
    } catch (err: any) {
      setError(err.message || "Failed to send email");
    } finally {
      setSending(false);
    }
  };

  const handleReply = async () => {
    if (!selectedInbox || !selectedThread || !replyBody.trim()) return;
    setSending(true);
    setError(null);
    try {
      const lastMsg = messages[messages.length - 1];
      const replyTo = lastMsg?.from || "";
      await apiRequest("POST", "/api/support/reply", {
        inboxId: selectedInbox.id,
        to: [replyTo],
        subject: `Re: ${selectedThread.subject || ""}`,
        body: replyBody,
        inReplyTo: lastMsg?.id,
      });
      setReplyBody("");
      setShowReply(false);
      setSuccessMessage("Reply sent");
      setTimeout(() => setSuccessMessage(null), 3000);
      fetchThread(selectedInbox.id, selectedThread.id);
    } catch (err: any) {
      setError(err.message || "Failed to send reply");
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async (threadId: string) => {
    if (!selectedInbox) return;
    setDeleting(threadId);
    try {
      const res = await fetch(`/api/support/thread/${selectedInbox.id}/${threadId}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "Delete failed");
      }
      setThreads(prev => prev.filter(t => t.id !== threadId));
      if (selectedThread?.id === threadId) {
        setSelectedThread(null);
        setMessages([]);
      }
      setSuccessMessage("Thread deleted");
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setError("Failed to delete thread");
    } finally {
      setDeleting(null);
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      const now = new Date();
      const diff = now.getTime() - d.getTime();
      if (diff < 86400000) {
        return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      }
      if (diff < 604800000) {
        return d.toLocaleDateString([], { weekday: "short", hour: "2-digit", minute: "2-digit" });
      }
      return d.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
    } catch {
      return dateStr;
    }
  };

  const filteredThreads = threads.filter(t => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      (t.subject || "").toLowerCase().includes(q) ||
      (t.snippet || "").toLowerCase().includes(q) ||
      (t.from || "").toLowerCase().includes(q)
    );
  });

  if (!user) {
    return (
      <TradingPlatformLayout>
        <div style={{ minHeight: "100vh", background: BG, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ textAlign: "center", color: "#9ca3af" }}>
            <Mail size={48} style={{ margin: "0 auto 16px", opacity: 0.5 }} />
            <p style={{ fontSize: 16, marginBottom: 16 }}>Sign in to access your email inbox</p>
            <a href="/api/login" data-testid="link-login" style={{
              display: "inline-flex", alignItems: "center", gap: 8, padding: "10px 24px",
              background: `linear-gradient(135deg, ${COLOR}, #0099CC)`, color: "#0A1628",
              borderRadius: 8, fontFamily: "Orbitron, monospace", fontWeight: 700, fontSize: 13,
              textDecoration: "none"
            }}>Sign In</a>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  return (
    <TradingPlatformLayout>
      <div style={{ minHeight: "100vh", background: BG, paddingTop: 80, paddingBottom: 40 }}>
        <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 16px" }}>

          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <Mail size={24} color={COLOR} />
              <h1 data-testid="text-inbox-title" style={{
                fontFamily: "Orbitron, monospace", fontSize: "clamp(18px, 3vw, 28px)",
                fontWeight: 900, color: "#e5e7eb", letterSpacing: 1
              }}>
                Email Inbox
              </h1>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                data-testid="button-compose"
                onClick={() => { setShowCompose(true); setShowReply(false); }}
                style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "8px 16px",
                  background: `linear-gradient(135deg, ${COLOR}, #0099CC)`, color: "#0A1628",
                  border: "none", borderRadius: 8, cursor: "pointer", fontSize: 13,
                  fontFamily: "Orbitron, monospace", fontWeight: 700
                }}
              >
                <Plus size={14} /> Compose
              </button>
              <button
                data-testid="button-refresh"
                onClick={() => selectedInbox && fetchThreads(selectedInbox.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "8px 12px",
                  background: "rgba(255,255,255,0.05)", color: "#9ca3af",
                  border: `1px solid ${BORDER}`, borderRadius: 8, cursor: "pointer", fontSize: 13
                }}
              >
                <RefreshCw size={14} />
              </button>
            </div>
          </div>

          <AnimatePresence>
            {successMessage && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                style={{
                  padding: "10px 16px", marginBottom: 16, borderRadius: 8,
                  background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.3)",
                  color: "#22c55e", fontSize: 13, display: "flex", alignItems: "center", gap: 8
                }}
              >
                <MailOpen size={14} /> {successMessage}
              </motion.div>
            )}
            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                data-testid="text-inbox-error"
                style={{
                  padding: "10px 16px", marginBottom: 16, borderRadius: 8,
                  background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)",
                  color: "#ef4444", fontSize: 13, display: "flex", alignItems: "center", gap: 8,
                  justifyContent: "space-between"
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <AlertCircle size={14} /> {error}
                </div>
                <button onClick={() => setError(null)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer" }}>
                  <X size={14} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {loading ? (
            <div style={{ textAlign: "center", padding: 60 }}>
              <Loader2 size={32} color={COLOR} className="animate-spin" style={{ margin: "0 auto" }} />
              <p style={{ color: "#9ca3af", marginTop: 12, fontSize: 13 }}>Loading inboxes...</p>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16, minHeight: 600 }}>

              <div style={{ background: CARD_BG, borderRadius: 12, border: `1px solid ${BORDER}`, overflow: "hidden" }}>
                <div style={{
                  padding: "12px 16px", borderBottom: `1px solid ${BORDER}`,
                  fontFamily: "Orbitron, monospace", fontSize: 11, color: COLOR,
                  letterSpacing: 1, fontWeight: 700
                }}>
                  INBOXES
                </div>
                {inboxes.length === 0 ? (
                  <div style={{ padding: 20, textAlign: "center", color: "#6b7280", fontSize: 13 }}>
                    No inboxes found
                  </div>
                ) : (
                  inboxes.map(inbox => (
                    <button
                      key={inbox.id}
                      data-testid={`button-inbox-${inbox.username}`}
                      onClick={() => setSelectedInbox(inbox)}
                      style={{
                        width: "100%", display: "flex", alignItems: "center", gap: 10,
                        padding: "12px 16px", border: "none", cursor: "pointer", textAlign: "left",
                        background: selectedInbox?.id === inbox.id ? `${COLOR}15` : "transparent",
                        borderLeft: selectedInbox?.id === inbox.id ? `3px solid ${COLOR}` : "3px solid transparent",
                        transition: "all 0.15s"
                      }}
                    >
                      <Inbox size={16} color={selectedInbox?.id === inbox.id ? COLOR : "#6b7280"} />
                      <div>
                        <div style={{
                          fontSize: 13, color: selectedInbox?.id === inbox.id ? "#e5e7eb" : "#9ca3af",
                          fontWeight: selectedInbox?.id === inbox.id ? 600 : 400
                        }}>
                          {inbox.displayName || inbox.username}
                        </div>
                        <div style={{ fontSize: 11, color: "#6b7280" }}>
                          {inbox.username}@{inbox.domain}
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>

              <div style={{ background: CARD_BG, borderRadius: 12, border: `1px solid ${BORDER}`, overflow: "hidden", display: "flex", flexDirection: "column" }}>

                {showCompose ? (
                  <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
                    <div style={{
                      padding: "12px 16px", borderBottom: `1px solid ${BORDER}`,
                      display: "flex", alignItems: "center", justifyContent: "space-between"
                    }}>
                      <span style={{ fontFamily: "Orbitron, monospace", fontSize: 12, color: COLOR, fontWeight: 700, letterSpacing: 1 }}>
                        NEW MESSAGE
                      </span>
                      <button data-testid="button-close-compose" onClick={() => setShowCompose(false)} style={{ background: "none", border: "none", color: "#9ca3af", cursor: "pointer" }}>
                        <X size={16} />
                      </button>
                    </div>
                    <div style={{ flex: 1, padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${BORDER}`, paddingBottom: 10 }}>
                        <span style={{ color: "#6b7280", fontSize: 13, minWidth: 40 }}>To:</span>
                        <input
                          data-testid="input-compose-to"
                          value={composeTo}
                          onChange={e => setComposeTo(e.target.value)}
                          placeholder="recipient@example.com"
                          style={{
                            flex: 1, background: "transparent", border: "none", color: "#e5e7eb",
                            fontSize: 13, outline: "none"
                          }}
                        />
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${BORDER}`, paddingBottom: 10 }}>
                        <span style={{ color: "#6b7280", fontSize: 13, minWidth: 40 }}>Subj:</span>
                        <input
                          data-testid="input-compose-subject"
                          value={composeSubject}
                          onChange={e => setComposeSubject(e.target.value)}
                          placeholder="Subject"
                          style={{
                            flex: 1, background: "transparent", border: "none", color: "#e5e7eb",
                            fontSize: 13, outline: "none"
                          }}
                        />
                      </div>
                      <textarea
                        data-testid="input-compose-body"
                        value={composeBody}
                        onChange={e => setComposeBody(e.target.value)}
                        placeholder="Write your message..."
                        style={{
                          flex: 1, background: "rgba(255,255,255,0.03)", border: `1px solid ${BORDER}`,
                          borderRadius: 8, padding: 12, color: "#e5e7eb", fontSize: 13,
                          resize: "none", outline: "none", minHeight: 200, lineHeight: 1.6
                        }}
                      />
                      <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                        <button
                          data-testid="button-cancel-compose"
                          onClick={() => setShowCompose(false)}
                          style={{
                            padding: "8px 16px", background: "rgba(255,255,255,0.05)",
                            border: `1px solid ${BORDER}`, borderRadius: 6, color: "#9ca3af",
                            cursor: "pointer", fontSize: 13
                          }}
                        >
                          Cancel
                        </button>
                        <button
                          data-testid="button-send-email"
                          onClick={handleSend}
                          disabled={sending || !composeTo.trim() || !composeSubject.trim() || !composeBody.trim()}
                          style={{
                            display: "flex", alignItems: "center", gap: 6, padding: "8px 20px",
                            background: `linear-gradient(135deg, ${COLOR}, #0099CC)`, color: "#0A1628",
                            border: "none", borderRadius: 6, cursor: sending ? "wait" : "pointer",
                            fontSize: 13, fontWeight: 700, opacity: sending ? 0.7 : 1
                          }}
                        >
                          {sending ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                          {sending ? "Sending..." : "Send"}
                        </button>
                      </div>
                    </div>
                  </div>
                ) : selectedThread ? (
                  <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
                    <div style={{
                      padding: "12px 16px", borderBottom: `1px solid ${BORDER}`,
                      display: "flex", alignItems: "center", gap: 12
                    }}>
                      <button
                        data-testid="button-back-to-list"
                        onClick={() => { setSelectedThread(null); setMessages([]); setShowReply(false); }}
                        style={{ background: "none", border: "none", color: "#9ca3af", cursor: "pointer", display: "flex", alignItems: "center" }}
                      >
                        <ArrowLeft size={18} />
                      </button>
                      <div style={{ flex: 1, overflow: "hidden" }}>
                        <div style={{ fontSize: 14, fontWeight: 600, color: "#e5e7eb", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {selectedThread.subject || "(No Subject)"}
                        </div>
                        <div style={{ fontSize: 11, color: "#6b7280" }}>
                          {messages.length} message{messages.length !== 1 ? "s" : ""}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button
                          data-testid="button-reply-thread"
                          onClick={() => setShowReply(!showReply)}
                          style={{
                            display: "flex", alignItems: "center", gap: 4, padding: "6px 12px",
                            background: showReply ? `${COLOR}20` : "rgba(255,255,255,0.05)",
                            border: `1px solid ${showReply ? COLOR : BORDER}`, borderRadius: 6,
                            color: showReply ? COLOR : "#9ca3af", cursor: "pointer", fontSize: 12
                          }}
                        >
                          <Reply size={12} /> Reply
                        </button>
                        <button
                          data-testid="button-delete-thread"
                          onClick={() => handleDelete(selectedThread.id)}
                          disabled={!!deleting}
                          style={{
                            display: "flex", alignItems: "center", gap: 4, padding: "6px 12px",
                            background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)",
                            borderRadius: 6, color: "#ef4444", cursor: "pointer", fontSize: 12
                          }}
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>

                    <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
                      {loadingMessages ? (
                        <div style={{ textAlign: "center", padding: 40 }}>
                          <Loader2 size={24} color={COLOR} className="animate-spin" style={{ margin: "0 auto" }} />
                        </div>
                      ) : (
                        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                          {messages.map((msg, i) => {
                            const isFromUs = selectedInbox && msg.from?.includes(selectedInbox.username);
                            return (
                              <motion.div
                                key={msg.id || i}
                                data-testid={`card-message-${i}`}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.05 }}
                                style={{
                                  background: isFromUs ? `${COLOR}08` : "rgba(255,255,255,0.02)",
                                  border: `1px solid ${isFromUs ? `${COLOR}20` : BORDER}`,
                                  borderRadius: 10, padding: 16
                                }}
                              >
                                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                    <div style={{
                                      width: 28, height: 28, borderRadius: "50%",
                                      background: isFromUs ? `${COLOR}20` : "rgba(255,255,255,0.08)",
                                      display: "flex", alignItems: "center", justifyContent: "center"
                                    }}>
                                      <User size={14} color={isFromUs ? COLOR : "#9ca3af"} />
                                    </div>
                                    <div>
                                      <div style={{ fontSize: 13, fontWeight: 600, color: "#e5e7eb" }}>
                                        {msg.from || "Unknown"}
                                      </div>
                                      <div style={{ fontSize: 11, color: "#6b7280" }}>
                                        to {(msg.to || []).join(", ")}
                                      </div>
                                    </div>
                                  </div>
                                  <div style={{ display: "flex", alignItems: "center", gap: 4, color: "#6b7280", fontSize: 11 }}>
                                    <Clock size={10} />
                                    {formatDate(msg.createdAt)}
                                  </div>
                                </div>
                                <div style={{
                                  color: "#d1d5db", fontSize: 13, lineHeight: 1.7,
                                  whiteSpace: "pre-wrap", wordBreak: "break-word"
                                }}>
                                  {(msg.body || msg.html || "").replace(/<[^>]*>/g, "")}
                                </div>
                              </motion.div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {showReply && (
                      <div style={{ borderTop: `1px solid ${BORDER}`, padding: 16 }}>
                        <textarea
                          data-testid="input-reply-body"
                          value={replyBody}
                          onChange={e => setReplyBody(e.target.value)}
                          placeholder="Write your reply..."
                          autoFocus
                          style={{
                            width: "100%", background: "rgba(255,255,255,0.03)", border: `1px solid ${BORDER}`,
                            borderRadius: 8, padding: 12, color: "#e5e7eb", fontSize: 13,
                            resize: "none", outline: "none", minHeight: 100, lineHeight: 1.6, marginBottom: 10
                          }}
                        />
                        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                          <button
                            onClick={() => { setShowReply(false); setReplyBody(""); }}
                            style={{
                              padding: "6px 14px", background: "rgba(255,255,255,0.05)",
                              border: `1px solid ${BORDER}`, borderRadius: 6, color: "#9ca3af",
                              cursor: "pointer", fontSize: 12
                            }}
                          >
                            Cancel
                          </button>
                          <button
                            data-testid="button-send-reply"
                            onClick={handleReply}
                            disabled={sending || !replyBody.trim()}
                            style={{
                              display: "flex", alignItems: "center", gap: 4, padding: "6px 16px",
                              background: `linear-gradient(135deg, ${COLOR}, #0099CC)`, color: "#0A1628",
                              border: "none", borderRadius: 6, cursor: sending ? "wait" : "pointer",
                              fontSize: 12, fontWeight: 700
                            }}
                          >
                            {sending ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                            Send Reply
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
                    <div style={{
                      padding: "10px 16px", borderBottom: `1px solid ${BORDER}`,
                      display: "flex", alignItems: "center", gap: 10
                    }}>
                      <Search size={14} color="#6b7280" />
                      <input
                        data-testid="input-search-emails"
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search emails..."
                        style={{
                          flex: 1, background: "transparent", border: "none", color: "#e5e7eb",
                          fontSize: 13, outline: "none"
                        }}
                      />
                      {searchQuery && (
                        <button onClick={() => setSearchQuery("")} style={{ background: "none", border: "none", color: "#6b7280", cursor: "pointer" }}>
                          <X size={14} />
                        </button>
                      )}
                    </div>

                    <div style={{ flex: 1, overflow: "auto" }}>
                      {loadingThreads ? (
                        <div style={{ textAlign: "center", padding: 40 }}>
                          <Loader2 size={24} color={COLOR} className="animate-spin" style={{ margin: "0 auto" }} />
                          <p style={{ color: "#6b7280", fontSize: 12, marginTop: 8 }}>Loading emails...</p>
                        </div>
                      ) : filteredThreads.length === 0 ? (
                        <div style={{ textAlign: "center", padding: 60, color: "#6b7280" }}>
                          <Inbox size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                          <p style={{ fontSize: 14 }}>{searchQuery ? "No matching emails" : "No emails yet"}</p>
                          <p style={{ fontSize: 12, marginTop: 4 }}>
                            {searchQuery ? "Try a different search" : "Compose a new email to get started"}
                          </p>
                        </div>
                      ) : (
                        filteredThreads.map((thread, i) => (
                          <motion.div
                            key={thread.id}
                            data-testid={`row-thread-${thread.id}`}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: i * 0.03 }}
                            onClick={() => handleSelectThread(thread)}
                            style={{
                              display: "flex", alignItems: "center", gap: 12, padding: "12px 16px",
                              borderBottom: `1px solid ${BORDER}`, cursor: "pointer",
                              transition: "background 0.15s"
                            }}
                            onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.03)")}
                            onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                          >
                            <div style={{
                              width: 32, height: 32, borderRadius: "50%", flexShrink: 0,
                              background: `${COLOR}15`, display: "flex", alignItems: "center", justifyContent: "center"
                            }}>
                              <Mail size={14} color={COLOR} />
                            </div>
                            <div style={{ flex: 1, overflow: "hidden", minWidth: 0 }}>
                              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                                <span style={{
                                  fontSize: 13, fontWeight: 600, color: "#e5e7eb",
                                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
                                }}>
                                  {thread.subject || "(No Subject)"}
                                </span>
                                <span style={{ fontSize: 11, color: "#6b7280", flexShrink: 0 }}>
                                  {formatDate(thread.lastMessageAt || thread.createdAt)}
                                </span>
                              </div>
                              <div style={{
                                fontSize: 12, color: "#6b7280", marginTop: 2,
                                whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
                              }}>
                                {thread.snippet || thread.from || ""}
                              </div>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
                              {(thread.messageCount || 0) > 1 && (
                                <span style={{
                                  fontSize: 10, color: COLOR, background: `${COLOR}15`,
                                  padding: "2px 6px", borderRadius: 10, fontWeight: 600
                                }}>
                                  {thread.messageCount}
                                </span>
                              )}
                              <button
                                data-testid={`button-delete-${thread.id}`}
                                onClick={e => { e.stopPropagation(); handleDelete(thread.id); }}
                                disabled={deleting === thread.id}
                                style={{
                                  background: "none", border: "none", color: "#6b7280",
                                  cursor: "pointer", padding: 4, borderRadius: 4, opacity: 0.5,
                                  transition: "opacity 0.15s"
                                }}
                                onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
                                onMouseLeave={e => (e.currentTarget.style.opacity = "0.5")}
                              >
                                {deleting === thread.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                              </button>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
