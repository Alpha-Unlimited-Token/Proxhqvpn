import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

const COPYRIGHT = "© 2024-2026 Alpha Unlimited Technologies. All Rights Reserved Worldwide in Perpetuity. Patent Pending. PROPRIETARY AND CONFIDENTIAL — CONTAINS TRADE SECRETS.";

interface TeamMemberSession {
  id: string;
  name: string;
  email: string;
  role: string;
  sessionToken: string;
}

interface CaseData {
  id: string;
  caseName: string;
  victimAddress: string;
  victimHandle: string;
  description: string;
  status: string;
  totalStolenUsd: number;
  totalRecoveredUsd: number;
  chains: string[];
}

interface WalletData {
  id: string;
  address: string;
  chain: string;
  role: string;
  label: string;
  lastKnownBalanceEth: number;
  lastKnownBalanceUsd: number;
  status: string;
}

interface AlertData {
  id: string;
  alertType: string;
  message: string;
  severity: string;
  acknowledged: boolean;
  createdAt: string;
}

interface TechFile {
  name: string;
  path: string;
  category: string;
  description: string;
  size: number;
}

interface CodeSubmission {
  id: string;
  technologyName: string;
  fileName: string;
  description: string;
  status: string;
  adminNotes: string | null;
  createdAt: string;
}

type PortalTab = "cases" | "wallets" | "alerts" | "technology" | "submissions";

export default function TeamPortal() {
  const [session, setSession] = useState<TeamMemberSession | null>(null);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginCode, setLoginCode] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<PortalTab>("cases");

  const [cases, setCases] = useState<CaseData[]>([]);
  const [wallets, setWallets] = useState<WalletData[]>([]);
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [techFiles, setTechFiles] = useState<TechFile[]>([]);
  const [viewingCode, setViewingCode] = useState<{ name: string; content: string } | null>(null);
  const [submissions, setSubmissions] = useState<CodeSubmission[]>([]);

  const [submitForm, setSubmitForm] = useState({ technologyName: "", fileName: "", description: "", submittedCode: "" });
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [submitStatus, setSubmitStatus] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("team_session_token");
    if (token) {
      fetch("/api/team/session", { headers: { "X-Team-Token": token } })
        .then(r => r.ok ? r.json() : Promise.reject())
        .then(data => { setSession(data); setLoading(false); })
        .catch(() => { localStorage.removeItem("team_session_token"); setLoading(false); });
    } else {
      setLoading(false);
    }
  }, []);

  const handleLogin = async () => {
    setLoginError("");
    try {
      const res = await fetch("/api/team/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, accessCode: loginCode }),
      });
      if (!res.ok) {
        const data = await res.json();
        setLoginError(data.message || "Login failed");
        return;
      }
      const data = await res.json();
      localStorage.setItem("team_session_token", data.sessionToken);
      setSession(data);
    } catch {
      setLoginError("Connection failed");
    }
  };

  const handleLogout = () => {
    const token = localStorage.getItem("team_session_token");
    if (token) fetch("/api/team/logout", { method: "POST", headers: { "X-Team-Token": token } });
    localStorage.removeItem("team_session_token");
    setSession(null);
  };

  const authHeaders = useCallback(() => ({
    "X-Team-Token": session?.sessionToken || "",
    "Content-Type": "application/json",
  }), [session]);

  useEffect(() => {
    if (!session) return;
    const h = { "X-Team-Token": session.sessionToken };
    if (tab === "cases") fetch("/api/team/cases", { headers: h }).then(r => r.json()).then(setCases).catch(() => {});
    if (tab === "wallets") fetch("/api/team/wallets", { headers: h }).then(r => r.json()).then(setWallets).catch(() => {});
    if (tab === "alerts") fetch("/api/team/alerts", { headers: h }).then(r => r.json()).then(setAlerts).catch(() => {});
    if (tab === "technology") fetch("/api/team/technology", { headers: h }).then(r => r.json()).then(setTechFiles).catch(() => {});
    if (tab === "submissions") fetch("/api/team/submissions", { headers: h }).then(r => r.json()).then(setSubmissions).catch(() => {});
  }, [session, tab]);

  const viewTechCode = async (path: string, name: string) => {
    if (!session) return;
    const res = await fetch(`/api/team/technology/view?path=${encodeURIComponent(path)}`, { headers: { "X-Team-Token": session.sessionToken } });
    if (res.ok) {
      const data = await res.json();
      setViewingCode({ name, content: data.content });
    }
  };

  const downloadTechCode = async (path: string, name: string) => {
    if (!session) return;
    const res = await fetch(`/api/team/technology/download?path=${encodeURIComponent(path)}`, { headers: { "X-Team-Token": session.sessionToken } });
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleSubmitCode = async () => {
    if (!session) return;
    setSubmitStatus("");
    try {
      const res = await fetch("/api/team/submissions", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ ...submitForm, teamMemberId: session.id, teamMemberName: session.name }),
      });
      if (res.ok) {
        setSubmitStatus("Code upgrade submitted for admin review!");
        setShowSubmitForm(false);
        setSubmitForm({ technologyName: "", fileName: "", description: "", submittedCode: "" });
        fetch("/api/team/submissions", { headers: { "X-Team-Token": session.sessionToken } }).then(r => r.json()).then(setSubmissions);
      } else {
        setSubmitStatus("Submission failed. Please try again.");
      }
    } catch {
      setSubmitStatus("Connection error.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050a12] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-[#d4a017] border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-[#050a12] flex items-center justify-center px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <div className="bg-[#111111] border border-[#333333] rounded-xl p-8">
            <div className="text-center mb-8">
              <div className="text-xs tracking-[3px] text-[#d4a017] mb-2">ALPHA UNLIMITED TECHNOLOGIES</div>
              <h1 className="text-2xl font-bold text-white mb-2">Team Portal</h1>
              <p className="text-sm text-gray-400">Authorized forensic team members only</p>
            </div>
            {loginError && <div data-testid="text-login-error" className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-4 text-red-400 text-sm">{loginError}</div>}
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Email Address</label>
                <input data-testid="input-team-email" type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#d4a017] outline-none" placeholder="your@email.com" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Access Code</label>
                <input data-testid="input-team-code" type="password" value={loginCode} onChange={e => setLoginCode(e.target.value)} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#d4a017] outline-none" placeholder="Enter access code" onKeyDown={e => e.key === "Enter" && handleLogin()} />
              </div>
              <button data-testid="button-team-login" onClick={handleLogin} className="w-full bg-gradient-to-r from-[#d4a017] to-[#b8860b] text-black font-bold py-3 rounded-lg hover:shadow-lg hover:shadow-[#d4a017]/20 transition-all">
                Access Portal
              </button>
            </div>
            <div className="mt-6 text-center text-xs text-gray-600">{COPYRIGHT}</div>
          </div>
        </motion.div>
      </div>
    );
  }

  const tabs: { key: PortalTab; label: string; icon: string }[] = [
    { key: "cases", label: "Cases", icon: "📁" },
    { key: "wallets", label: "Wallets", icon: "👛" },
    { key: "alerts", label: "Alerts", icon: "🚨" },
    { key: "technology", label: "Technology", icon: "⚙️" },
    { key: "submissions", label: "My Submissions", icon: "📤" },
  ];

  return (
    <div className="min-h-screen bg-[#050a12]">
      <div className="border-b border-[#333] bg-[#0a0f1a]">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <div className="text-xs tracking-[3px] text-[#d4a017]">ALPHA FORENSIC INTELLIGENCE</div>
              <h1 className="text-xl font-bold text-white">Team Portal</h1>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-white font-medium">{session.name}</div>
              <div className="text-xs text-gray-400">{session.role} • {session.email}</div>
            </div>
            <button data-testid="button-team-logout" onClick={handleLogout} className="px-4 py-2 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm hover:bg-red-500/20 transition-all">
              Sign Out
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map(t => (
            <button key={t.key} data-testid={`button-tab-${t.key}`} onClick={() => setTab(t.key)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${tab === t.key ? "bg-[#d4a017]/20 border border-[#d4a017] text-[#d4a017]" : "bg-[#111] border border-[#333] text-gray-400 hover:text-white"}`}>
              <span>{t.icon}</span> {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pb-8">
        <AnimatePresence mode="wait">
          {tab === "cases" && (
            <motion.div key="cases" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="grid gap-4">
                {cases.length === 0 && <div className="text-gray-500 text-center py-12">No cases available</div>}
                {cases.map(c => (
                  <div key={c.id} data-testid={`card-case-${c.id}`} className="bg-[#111] border border-[#333] rounded-xl p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-white">{c.caseName}</h3>
                        <div className="text-sm text-gray-400 mt-1">{c.victimHandle && `Victim: ${c.victimHandle}`}</div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${c.status === "active" ? "bg-green-500/20 text-green-400" : "bg-gray-500/20 text-gray-400"}`}>{c.status?.toUpperCase()}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="bg-[#0a0f1a] rounded-lg p-3">
                        <div className="text-xs text-gray-500">Stolen Amount</div>
                        <div className="text-lg font-bold text-red-400">${(c.totalStolenUsd || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-[#0a0f1a] rounded-lg p-3">
                        <div className="text-xs text-gray-500">Recovered</div>
                        <div className="text-lg font-bold text-green-400">${(c.totalRecoveredUsd || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-[#0a0f1a] rounded-lg p-3">
                        <div className="text-xs text-gray-500">Chains</div>
                        <div className="text-sm font-medium text-white mt-1">{(c.chains || []).join(", ") || "—"}</div>
                      </div>
                      <div className="bg-[#0a0f1a] rounded-lg p-3">
                        <div className="text-xs text-gray-500">Victim Wallet</div>
                        <div className="text-xs font-mono text-[#4ade80] mt-1 break-all">{c.victimAddress || "—"}</div>
                      </div>
                    </div>
                    {c.description && <p className="text-sm text-gray-400">{c.description}</p>}
                    <div className="mt-3 text-xs text-gray-600">Case ID: {c.id}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {tab === "wallets" && (
            <motion.div key="wallets" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="bg-[#111] border border-[#333] rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#333]">
                        <th className="px-4 py-3 text-left text-xs text-gray-500 font-medium">Address</th>
                        <th className="px-4 py-3 text-left text-xs text-gray-500 font-medium">Label</th>
                        <th className="px-4 py-3 text-left text-xs text-gray-500 font-medium">Role</th>
                        <th className="px-4 py-3 text-left text-xs text-gray-500 font-medium">Chain</th>
                        <th className="px-4 py-3 text-right text-xs text-gray-500 font-medium">ETH Balance</th>
                        <th className="px-4 py-3 text-center text-xs text-gray-500 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {wallets.map(w => (
                        <tr key={w.id} data-testid={`row-wallet-${w.id}`} className="border-b border-[#222] hover:bg-[#1a1a2e] transition-colors">
                          <td className="px-4 py-3 font-mono text-xs text-[#4ade80]">{w.address}</td>
                          <td className="px-4 py-3 text-white">{w.label || "—"}</td>
                          <td className="px-4 py-3 text-gray-400">{w.role || "—"}</td>
                          <td className="px-4 py-3 text-gray-400">{w.chain}</td>
                          <td className="px-4 py-3 text-right text-white">{w.lastKnownBalanceEth?.toFixed(4) || "—"}</td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-xs ${w.status === "monitoring" ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}`}>{w.status}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {wallets.length === 0 && <div className="text-gray-500 text-center py-12">No monitored wallets</div>}
                </div>
              </div>
            </motion.div>
          )}

          {tab === "alerts" && (
            <motion.div key="alerts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="grid gap-3">
                {alerts.length === 0 && <div className="text-gray-500 text-center py-12">No alerts</div>}
                {alerts.map(a => (
                  <div key={a.id} data-testid={`card-alert-${a.id}`} className={`bg-[#111] border rounded-xl p-4 ${a.severity === "critical" ? "border-red-500/50" : a.severity === "high" ? "border-orange-500/50" : "border-[#333]"}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-xs font-bold ${a.severity === "critical" ? "bg-red-500/20 text-red-400" : a.severity === "high" ? "bg-orange-500/20 text-orange-400" : a.severity === "medium" ? "bg-yellow-500/20 text-yellow-400" : "bg-blue-500/20 text-blue-400"}`}>{a.severity?.toUpperCase()}</span>
                        <span className="text-xs text-gray-500">{a.alertType}</span>
                      </div>
                      <span className="text-xs text-gray-600">{a.createdAt ? new Date(a.createdAt).toLocaleString() : ""}</span>
                    </div>
                    <p className="text-sm text-white">{a.message}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {tab === "technology" && (
            <motion.div key="technology" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="bg-[#0d1a0d] border border-[#2d5a2d] rounded-xl p-4 mb-4">
                <p className="text-sm text-green-400">{COPYRIGHT}</p>
                <p className="text-xs text-gray-500 mt-1">All technology code is read-only. You may view and download but cannot edit. To propose changes, use the "My Submissions" tab to submit upgrade code for admin review.</p>
              </div>

              {viewingCode ? (
                <div className="bg-[#111] border border-[#333] rounded-xl">
                  <div className="flex items-center justify-between p-4 border-b border-[#333]">
                    <div>
                      <h3 className="text-white font-bold">{viewingCode.name}</h3>
                      <div className="text-xs text-gray-500 mt-1">READ-ONLY — {COPYRIGHT}</div>
                    </div>
                    <button data-testid="button-close-code-view" onClick={() => setViewingCode(null)} className="px-4 py-2 bg-[#333] rounded-lg text-white text-sm hover:bg-[#444] transition-all">Close</button>
                  </div>
                  <pre className="p-4 text-xs text-gray-300 overflow-x-auto max-h-[600px] overflow-y-auto font-mono leading-relaxed select-all">{viewingCode.content}</pre>
                </div>
              ) : (
                <div className="grid gap-3">
                  {techFiles.length === 0 && <div className="text-gray-500 text-center py-12">No technology files available</div>}
                  {techFiles.map(f => (
                    <div key={f.path} data-testid={`card-tech-${f.name}`} className="bg-[#111] border border-[#333] rounded-xl p-4 flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="px-2 py-0.5 rounded text-xs bg-[#d4a017]/20 text-[#d4a017]">{f.category}</span>
                          <h4 className="text-white font-medium truncate">{f.name}</h4>
                        </div>
                        <p className="text-xs text-gray-500">{f.description}</p>
                        <div className="text-xs text-gray-600 mt-1">{(f.size / 1024).toFixed(1)} KB</div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <button data-testid={`button-view-${f.name}`} onClick={() => viewTechCode(f.path, f.name)} className="px-3 py-2 bg-[#1a1a2e] border border-[#333] rounded-lg text-sm text-white hover:border-[#d4a017] transition-all">View</button>
                        <button data-testid={`button-download-${f.name}`} onClick={() => downloadTechCode(f.path, f.name)} className="px-3 py-2 bg-[#d4a017]/10 border border-[#d4a017]/30 rounded-lg text-sm text-[#d4a017] hover:bg-[#d4a017]/20 transition-all">Download</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {tab === "submissions" && (
            <motion.div key="submissions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white">Code Upgrade Submissions</h2>
                <button data-testid="button-new-submission" onClick={() => setShowSubmitForm(!showSubmitForm)} className="px-4 py-2 bg-gradient-to-r from-[#d4a017] to-[#b8860b] text-black font-bold rounded-lg text-sm hover:shadow-lg hover:shadow-[#d4a017]/20 transition-all">
                  {showSubmitForm ? "Cancel" : "Submit New Code"}
                </button>
              </div>

              {submitStatus && <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 mb-4 text-green-400 text-sm">{submitStatus}</div>}

              {showSubmitForm && (
                <div className="bg-[#111] border border-[#d4a017]/30 rounded-xl p-6 mb-6">
                  <h3 className="text-white font-bold mb-4">Submit Code Upgrade for Admin Review</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Technology Name</label>
                      <input data-testid="input-submit-tech" value={submitForm.technologyName} onChange={e => setSubmitForm(p => ({ ...p, technologyName: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm" placeholder="e.g., DAU v2 Dye Pack Protocol" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Target File Name</label>
                      <input data-testid="input-submit-file" value={submitForm.fileName} onChange={e => setSubmitForm(p => ({ ...p, fileName: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm" placeholder="e.g., DAUv2_Lite.sol" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Description of Changes</label>
                      <textarea data-testid="input-submit-desc" value={submitForm.description} onChange={e => setSubmitForm(p => ({ ...p, description: e.target.value }))} className="w-full bg-[#1a1a2e] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[#d4a017] outline-none text-sm h-24 resize-none" placeholder="Describe what changes you're proposing and why..." />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Code</label>
                      <textarea data-testid="input-submit-code" value={submitForm.submittedCode} onChange={e => setSubmitForm(p => ({ ...p, submittedCode: e.target.value }))} className="w-full bg-[#0a0f1a] border border-[#333] rounded-lg px-4 py-2 text-green-400 font-mono focus:border-[#d4a017] outline-none text-xs h-48 resize-y" placeholder="Paste your upgrade code here..." />
                    </div>
                    <button data-testid="button-submit-code" onClick={handleSubmitCode} disabled={!submitForm.technologyName || !submitForm.fileName || !submitForm.description || !submitForm.submittedCode} className="px-6 py-3 bg-gradient-to-r from-[#d4a017] to-[#b8860b] text-black font-bold rounded-lg text-sm hover:shadow-lg hover:shadow-[#d4a017]/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                      Submit for Admin Review
                    </button>
                  </div>
                </div>
              )}

              <div className="grid gap-3">
                {submissions.length === 0 && !showSubmitForm && <div className="text-gray-500 text-center py-12">No submissions yet</div>}
                {submissions.map(s => (
                  <div key={s.id} data-testid={`card-submission-${s.id}`} className="bg-[#111] border border-[#333] rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="text-white font-medium">{s.technologyName}</h4>
                        <div className="text-xs text-gray-500">{s.fileName}</div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${s.status === "pending" ? "bg-yellow-500/20 text-yellow-400" : s.status === "approved" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>{s.status?.toUpperCase()}</span>
                    </div>
                    <p className="text-sm text-gray-400 mb-2">{s.description}</p>
                    {s.adminNotes && (
                      <div className="bg-[#0a0f1a] rounded-lg p-3 mt-2">
                        <div className="text-xs text-[#d4a017] mb-1">Admin Notes:</div>
                        <p className="text-sm text-white">{s.adminNotes}</p>
                      </div>
                    )}
                    <div className="text-xs text-gray-600 mt-2">Submitted: {s.createdAt ? new Date(s.createdAt).toLocaleString() : ""}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="border-t border-[#222] py-4 text-center">
        <div className="text-xs text-gray-600">{COPYRIGHT}</div>
      </div>
    </div>
  );
}