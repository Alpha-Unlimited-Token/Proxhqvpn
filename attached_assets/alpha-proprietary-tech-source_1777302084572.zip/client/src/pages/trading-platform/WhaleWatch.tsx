/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha WhaleWatch™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_ef9934ed9c4b2c6b92c06815
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Search, RefreshCw, ExternalLink, Copy, Check, Filter, ChevronDown,
  Bell, BellOff, Activity, BarChart3, TrendingUp, TrendingDown, 
  Wallet, ArrowUpRight, ArrowDownRight, Clock, Zap, Users, Eye,
  Globe, AlertTriangle, X, UserPlus, Shield
} from "lucide-react";

interface WhaleTransaction {
  id: string;
  type: string;
  token: string;
  tokenIcon: string;
  amount: number;
  value: number;
  timestamp: string;
  txHash: string;
  platform: string;
  chain: string;
  from: string;
  to: string;
}

interface AlertThreshold {
  id: string;
  chain: string;
  minAmount: number;
  enabled: boolean;
}

const CHAIN_CONFIG: Record<string, { icon: string; color: string; name: string }> = {
  bitcoin: { icon: "₿", color: "#F7931A", name: "Bitcoin" },
  ethereum: { icon: "⟠", color: "#627EEA", name: "Ethereum" },
  solana: { icon: "◎", color: "#9945FF", name: "Solana" },
  bsc: { icon: "🔶", color: "#F0B90B", name: "BNB Chain" },
  arbitrum: { icon: "🔵", color: "#28A0F0", name: "Arbitrum" },
  base: { icon: "🔷", color: "#0052FF", name: "Base" },
};

function shortenAddress(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function formatValue(value: number): string {
  if (Math.abs(value) >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(2)}B`;
  if (Math.abs(value) >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (Math.abs(value) >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(0)}`;
}

function formatTimeAgo(dateStr: string): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function impactLevel(value: number): { label: string; color: string; bg: string } {
  if (value >= 10_000_000) return { label: "Critical", color: "text-red-400", bg: "bg-red-600/20 border-red-500/30" };
  if (value >= 5_000_000) return { label: "High", color: "text-orange-400", bg: "bg-orange-600/20 border-orange-500/30" };
  if (value >= 1_000_000) return { label: "Medium", color: "text-yellow-400", bg: "bg-yellow-600/20 border-yellow-500/30" };
  return { label: "Low", color: "text-green-400", bg: "bg-green-600/20 border-green-500/30" };
}

function TransactionRow({ tx }: { tx: WhaleTransaction }) {
  const [copied, setCopied] = useState(false);
  const impact = impactLevel(tx.value);
  const chainInfo = CHAIN_CONFIG[tx.chain.toLowerCase()] || CHAIN_CONFIG.ethereum;

  const copyHash = async () => {
    await navigator.clipboard.writeText(tx.txHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.tr
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors"
      data-testid={`row-tx-${tx.id}`}
    >
      <td className="py-3 px-3">
        <div className="flex items-center gap-2">
          <span style={{ color: chainInfo.color }}>{chainInfo.icon}</span>
          <span className="text-xs text-gray-400">{chainInfo.name}</span>
        </div>
      </td>
      <td className="py-3 px-3">
        <Badge className={`text-[10px] ${tx.type === "transfer" ? "bg-blue-600/20 text-blue-400 border-blue-500/30" : tx.type === "buy" ? "bg-green-600/20 text-green-400 border-green-500/30" : "bg-red-600/20 text-red-400 border-red-500/30"}`}>
          {tx.type.toUpperCase()}
        </Badge>
      </td>
      <td className="py-3 px-3">
        <div className="flex items-center gap-2">
          <span className="text-lg">{tx.tokenIcon}</span>
          <span className="text-white font-medium text-sm">{tx.token}</span>
        </div>
      </td>
      <td className="py-3 px-3 text-right font-mono text-white text-sm" data-testid={`text-amount-${tx.id}`}>
        {tx.amount.toLocaleString()}
      </td>
      <td className="py-3 px-3 text-right font-mono font-semibold text-cyan-400 text-sm" data-testid={`text-value-${tx.id}`}>
        {formatValue(tx.value)}
      </td>
      <td className="py-3 px-3">
        <Badge className={`text-[10px] ${impact.bg}`} data-testid={`badge-impact-${tx.id}`}>
          {impact.label}
        </Badge>
      </td>
      <td className="py-3 px-3">
        <div className="text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <ArrowUpRight size={10} className="text-red-400" />
            <span className="font-mono">{shortenAddress(tx.from)}</span>
          </div>
          <div className="flex items-center gap-1 mt-0.5">
            <ArrowDownRight size={10} className="text-green-400" />
            <span className="font-mono">{shortenAddress(tx.to)}</span>
          </div>
        </div>
      </td>
      <td className="py-3 px-3 text-xs text-gray-500">{formatTimeAgo(tx.timestamp)}</td>
      <td className="py-3 px-3">
        <div className="flex items-center gap-1">
          <button
            onClick={copyHash}
            className="p-1 hover:bg-white/10 rounded transition-colors"
            data-testid={`button-copy-hash-${tx.id}`}
          >
            {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} className="text-gray-500" />}
          </button>
          <a
            href={tx.chain.toLowerCase() === "bitcoin" ? `https://blockchain.info/tx/${tx.txHash}` : `https://etherscan.io/tx/${tx.txHash}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-1 hover:bg-white/10 rounded transition-colors"
            data-testid={`link-explorer-${tx.id}`}
          >
            <ExternalLink size={12} className="text-gray-500" />
          </a>
        </div>
      </td>
    </motion.tr>
  );
}

function TransactionCard({ tx }: { tx: WhaleTransaction }) {
  const impact = impactLevel(tx.value);
  const chainInfo = CHAIN_CONFIG[tx.chain.toLowerCase()] || CHAIN_CONFIG.ethereum;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-3 bg-[#0a1018] rounded-lg border border-[#1E3A5F]/30 hover:border-[#1E3A5F]/60 transition-colors"
      data-testid={`card-tx-${tx.id}`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-lg">{tx.tokenIcon}</span>
          <div>
            <span className="text-white font-medium text-sm">{tx.token}</span>
            <div className="flex items-center gap-1 mt-0.5">
              <span style={{ color: chainInfo.color }} className="text-xs">{chainInfo.icon} {chainInfo.name}</span>
            </div>
          </div>
        </div>
        <Badge className={`text-[10px] ${impact.bg}`}>{impact.label}</Badge>
      </div>
      <div className="flex items-center justify-between">
        <span className="font-mono text-cyan-400 font-semibold">{formatValue(tx.value)}</span>
        <span className="text-xs text-gray-500">{formatTimeAgo(tx.timestamp)}</span>
      </div>
      <div className="mt-2 text-xs text-gray-500 flex items-center gap-1">
        <span className="font-mono">{shortenAddress(tx.from)}</span>
        <span>→</span>
        <span className="font-mono">{shortenAddress(tx.to)}</span>
      </div>
    </motion.div>
  );
}

function WhaleStats({ transactions }: { transactions: WhaleTransaction[] }) {
  const totalVolume = transactions.reduce((sum, tx) => sum + tx.value, 0);
  const uniqueWhales = new Set(transactions.map(tx => tx.from)).size;
  const chainBreakdown = transactions.reduce((acc, tx) => {
    const chain = tx.chain.toLowerCase();
    acc[chain] = (acc[chain] || 0) + tx.value;
    return acc;
  }, {} as Record<string, number>);
  const topChain = Object.entries(chainBreakdown).sort((a, b) => b[1] - a[1])[0];
  const criticalCount = transactions.filter(tx => tx.value >= 10_000_000).length;

  const stats = [
    { label: "Total Volume", value: formatValue(totalVolume), icon: <BarChart3 size={16} className="text-cyan-400" />, testId: "text-total-volume" },
    { label: "Transactions", value: transactions.length.toString(), icon: <Activity size={16} className="text-green-400" />, testId: "text-tx-count" },
    { label: "Unique Whales", value: uniqueWhales.toString(), icon: <Users size={16} className="text-purple-400" />, testId: "text-whale-count" },
    { label: "Critical Alerts", value: criticalCount.toString(), icon: <AlertTriangle size={16} className="text-red-400" />, testId: "text-critical-count" },
    { label: "Top Chain", value: topChain ? (CHAIN_CONFIG[topChain[0]]?.name || topChain[0]) : "N/A", icon: <Globe size={16} className="text-yellow-400" />, testId: "text-top-chain" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {stats.map((stat) => (
        <Card key={stat.label} className="bg-[#0f1923] border-[#1E3A5F]/50">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              {stat.icon}
              <span className="text-xs text-gray-500">{stat.label}</span>
            </div>
            <div className="text-lg font-bold font-mono text-white" data-testid={stat.testId}>
              {stat.value}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ChainVolumeChart({ transactions }: { transactions: WhaleTransaction[] }) {
  const chainVolumes = transactions.reduce((acc, tx) => {
    const chain = tx.chain.toLowerCase();
    acc[chain] = (acc[chain] || 0) + tx.value;
    return acc;
  }, {} as Record<string, number>);

  const sorted = Object.entries(chainVolumes).sort((a, b) => b[1] - a[1]);
  const maxVal = sorted.length > 0 ? sorted[0][1] : 1;

  return (
    <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
          <BarChart3 size={14} /> Volume by Chain
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {sorted.map(([chain, volume]) => {
          const config = CHAIN_CONFIG[chain] || { icon: "🔗", color: "#666", name: chain };
          const pct = (volume / maxVal) * 100;
          return (
            <div key={chain} data-testid={`chart-chain-${chain}`}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2 text-sm">
                  <span style={{ color: config.color }}>{config.icon}</span>
                  <span className="text-gray-300">{config.name}</span>
                </div>
                <span className="text-xs font-mono text-cyan-400">{formatValue(volume)}</span>
              </div>
              <div className="w-full h-2 bg-[#0a1018] rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="h-full rounded-full"
                  style={{ background: `linear-gradient(90deg, ${config.color}88, ${config.color})` }}
                />
              </div>
            </div>
          );
        })}
        {sorted.length === 0 && (
          <div className="text-center text-gray-500 text-sm py-4">No data available</div>
        )}
      </CardContent>
    </Card>
  );
}

function TopWhalesList({ transactions }: { transactions: WhaleTransaction[] }) {
  const whaleVolumes = transactions.reduce((acc, tx) => {
    acc[tx.from] = (acc[tx.from] || 0) + tx.value;
    return acc;
  }, {} as Record<string, number>);

  const sorted = Object.entries(whaleVolumes)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  return (
    <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
          <Users size={14} /> Top Whale Wallets
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {sorted.map(([address, volume], i) => (
          <div
            key={address}
            className="flex items-center justify-between p-2 bg-[#0a1018] rounded-lg"
            data-testid={`item-whale-${i}`}
          >
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-gray-500 w-5">#{i + 1}</span>
              <span className="text-sm">🐋</span>
              <span className="font-mono text-xs text-gray-300">{shortenAddress(address)}</span>
            </div>
            <span className="font-mono text-xs text-cyan-400 font-semibold">{formatValue(volume)}</span>
          </div>
        ))}
        {sorted.length === 0 && (
          <div className="text-center text-gray-500 text-sm py-4">No whale data</div>
        )}
      </CardContent>
    </Card>
  );
}

export default function WhaleWatch() {
  const { toast } = useToast();
  const [transactions, setTransactions] = useState<WhaleTransaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);
  const [activeTab, setActiveTab] = useState("feed");
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [dataSources, setDataSources] = useState<string[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [chainFilter, setChainFilter] = useState("all");
  const [minAmount, setMinAmount] = useState("0");
  const [timeRange, setTimeRange] = useState("24h");
  const [searchQuery, setSearchQuery] = useState("");

  const [alerts, setAlerts] = useState<AlertThreshold[]>([
    { id: "btc-alert", chain: "bitcoin", minAmount: 10_000_000, enabled: true },
    { id: "eth-alert", chain: "ethereum", minAmount: 5_000_000, enabled: true },
  ]);

  const fetchTransactions = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/whale-transactions");
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      const txs: WhaleTransaction[] = data.transactions || [];
      setTransactions(txs);
      if (data.sources) setDataSources(data.sources);

      const enabledAlerts = alerts.filter(a => a.enabled);
      for (const tx of txs) {
        for (const alert of enabledAlerts) {
          if (tx.chain.toLowerCase() === alert.chain && tx.value >= alert.minAmount) {
            toast({
              title: `🐋 Whale Alert: ${CHAIN_CONFIG[alert.chain]?.name || alert.chain}`,
              description: `${formatValue(tx.value)} ${tx.token} moved`,
            });
            break;
          }
        }
      }
    } catch (error: any) {
      toast({
        title: "Failed to Load Data",
        description: error.message || "Could not fetch whale transactions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
      setInitialLoad(false);
    }
  }, [toast, alerts]);

  useEffect(() => {
    fetchTransactions();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(fetchTransactions, 15000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [autoRefresh, fetchTransactions]);

  const filteredTransactions = transactions.filter(tx => {
    if (chainFilter !== "all" && tx.chain.toLowerCase() !== chainFilter) return false;
    const minVal = parseFloat(minAmount) || 0;
    if (tx.value < minVal) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      if (
        !tx.token.toLowerCase().includes(q) &&
        !tx.from.toLowerCase().includes(q) &&
        !tx.to.toLowerCase().includes(q) &&
        !tx.txHash.toLowerCase().includes(q)
      ) return false;
    }
    if (timeRange !== "all") {
      const now = Date.now();
      const txTime = new Date(tx.timestamp).getTime();
      const ranges: Record<string, number> = {
        "1h": 3600000,
        "6h": 21600000,
        "24h": 86400000,
        "7d": 604800000,
      };
      if (ranges[timeRange] && now - txTime > ranges[timeRange]) return false;
    }
    return true;
  });

  const toggleAlert = (alertId: string) => {
    setAlerts(prev => prev.map(a =>
      a.id === alertId ? { ...a, enabled: !a.enabled } : a
    ));
  };

  const addAlert = () => {
    const newAlert: AlertThreshold = {
      id: `alert-${Date.now()}`,
      chain: "bitcoin",
      minAmount: 1_000_000,
      enabled: true,
    };
    setAlerts(prev => [...prev, newAlert]);
  };

  const removeAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  };

  if (initialLoad) {
    return (
      <TradingPlatformLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-400 text-sm">Loading Whale Watch...</span>
          </div>
        </div>
      </TradingPlatformLayout>
    );
  }

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-whale-watch">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
              🐋 Whale Watch
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              Real-time large transaction monitoring across multiple blockchains
            </p>
            {dataSources.length > 0 && (
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-gray-500">Sources:</span>
                {dataSources.map(src => (
                  <Badge key={src} variant="outline" className="text-[10px] border-[#1E3A5F] text-gray-400">
                    {src}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm">
              <div className={`w-2.5 h-2.5 rounded-full ${autoRefresh ? "bg-green-500 animate-pulse" : "bg-gray-600"}`} />
              <span className="text-gray-300" data-testid="text-auto-refresh-status">
                {autoRefresh ? "Auto-refresh ON" : "Auto-refresh OFF"}
              </span>
            </div>
            <Button
              onClick={() => setAutoRefresh(!autoRefresh)}
              variant="outline"
              size="sm"
              className={`border-gray-700 ${autoRefresh ? "text-green-400" : ""}`}
              data-testid="button-toggle-auto-refresh"
            >
              {autoRefresh ? <Bell size={14} className="mr-1" /> : <BellOff size={14} className="mr-1" />}
              {autoRefresh ? "Live" : "Paused"}
            </Button>
            <Button
              onClick={fetchTransactions}
              variant="outline"
              size="sm"
              className="border-gray-700"
              disabled={loading}
              data-testid="button-refresh"
            >
              <RefreshCw size={14} className={`mr-1 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        <WhaleStats transactions={filteredTransactions} />

        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by token, address, or tx hash..."
              className="pl-10 bg-[#0f1923] border-[#1E3A5F]/50"
              data-testid="input-search"
            />
          </div>
          <Select value={chainFilter} onValueChange={setChainFilter}>
            <SelectTrigger className="w-[160px] bg-[#0f1923] border-[#1E3A5F]/50 text-sm h-10" data-testid="select-chain-filter">
              <SelectValue placeholder="Chain" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Chains</SelectItem>
              {Object.entries(CHAIN_CONFIG).map(([key, val]) => (
                <SelectItem key={key} value={key}>{val.icon} {val.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={minAmount} onValueChange={setMinAmount}>
            <SelectTrigger className="w-[160px] bg-[#0f1923] border-[#1E3A5F]/50 text-sm h-10" data-testid="select-min-amount">
              <SelectValue placeholder="Min Amount" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Any Amount</SelectItem>
              <SelectItem value="100000">$100K+</SelectItem>
              <SelectItem value="500000">$500K+</SelectItem>
              <SelectItem value="1000000">$1M+</SelectItem>
              <SelectItem value="5000000">$5M+</SelectItem>
              <SelectItem value="10000000">$10M+</SelectItem>
            </SelectContent>
          </Select>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px] bg-[#0f1923] border-[#1E3A5F]/50 text-sm h-10" data-testid="select-time-range">
              <SelectValue placeholder="Time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last 1 Hour</SelectItem>
              <SelectItem value="6h">Last 6 Hours</SelectItem>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-[#0a1018]">
            <TabsTrigger value="feed" className="text-xs" data-testid="tab-feed">
              <Activity size={12} className="mr-1" /> Live Feed ({filteredTransactions.length})
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-xs" data-testid="tab-analytics">
              <BarChart3 size={12} className="mr-1" /> Analytics
            </TabsTrigger>
            <TabsTrigger value="alerts" className="text-xs" data-testid="tab-alerts">
              <Bell size={12} className="mr-1" /> Alerts ({alerts.filter(a => a.enabled).length})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {activeTab === "feed" && (
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardContent className="p-0">
              {filteredTransactions.length === 0 ? (
                <div className="text-center py-16 text-gray-500" data-testid="text-no-transactions">
                  <div className="text-4xl mb-3">🐋</div>
                  <p className="text-lg font-medium">No whale transactions found</p>
                  <p className="text-sm mt-1">Try adjusting your filters or check back later</p>
                </div>
              ) : (
                <>
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-sm" data-testid="table-transactions">
                      <thead>
                        <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
                          <th className="text-left py-2 px-3">Chain</th>
                          <th className="text-left py-2 px-3">Type</th>
                          <th className="text-left py-2 px-3">Token</th>
                          <th className="text-right py-2 px-3">Amount</th>
                          <th className="text-right py-2 px-3">Value</th>
                          <th className="text-center py-2 px-3">Impact</th>
                          <th className="text-left py-2 px-3">From / To</th>
                          <th className="text-left py-2 px-3">Time</th>
                          <th className="text-left py-2 px-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <AnimatePresence>
                          {filteredTransactions.map((tx) => (
                            <TransactionRow key={tx.id} tx={tx} />
                          ))}
                        </AnimatePresence>
                      </tbody>
                    </table>
                  </div>
                  <div className="md:hidden p-3 space-y-3">
                    <AnimatePresence>
                      {filteredTransactions.map((tx) => (
                        <TransactionCard key={tx.id} tx={tx} />
                      ))}
                    </AnimatePresence>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}

        {activeTab === "analytics" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <ChainVolumeChart transactions={filteredTransactions} />
            <TopWhalesList transactions={filteredTransactions} />
          </div>
        )}

        {activeTab === "alerts" && (
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm text-gray-300 flex items-center gap-2">
                  <Bell size={14} className="text-cyan-400" /> Alert Thresholds
                </CardTitle>
                <Button onClick={addAlert} size="sm" className="bg-cyan-500 hover:bg-cyan-600" data-testid="button-add-alert">
                  <Zap size={12} className="mr-1" /> Add Alert
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {alerts.map((alert) => {
                const chainConfig = CHAIN_CONFIG[alert.chain] || { icon: "🔗", color: "#666", name: alert.chain };
                return (
                  <motion.div
                    key={alert.id}
                    layout
                    className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${alert.enabled ? "bg-[#0a1018] border-cyan-500/20" : "bg-[#0a1018]/50 border-[#1E3A5F]/20 opacity-60"}`}
                    data-testid={`alert-${alert.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <span style={{ color: chainConfig.color }} className="text-lg">{chainConfig.icon}</span>
                      <div>
                        <div className="text-sm text-white font-medium">{chainConfig.name}</div>
                        <div className="text-xs text-gray-500">Min: {formatValue(alert.minAmount)}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={alert.chain}
                        onValueChange={(val) => setAlerts(prev => prev.map(a => a.id === alert.id ? { ...a, chain: val } : a))}
                      >
                        <SelectTrigger className="w-[120px] bg-[#0a1018] border-[#1E3A5F]/50 text-xs h-8" data-testid={`select-alert-chain-${alert.id}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(CHAIN_CONFIG).map(([key, val]) => (
                            <SelectItem key={key} value={key}>{val.icon} {val.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select
                        value={alert.minAmount.toString()}
                        onValueChange={(val) => setAlerts(prev => prev.map(a => a.id === alert.id ? { ...a, minAmount: parseInt(val) } : a))}
                      >
                        <SelectTrigger className="w-[100px] bg-[#0a1018] border-[#1E3A5F]/50 text-xs h-8" data-testid={`select-alert-amount-${alert.id}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="100000">$100K</SelectItem>
                          <SelectItem value="500000">$500K</SelectItem>
                          <SelectItem value="1000000">$1M</SelectItem>
                          <SelectItem value="5000000">$5M</SelectItem>
                          <SelectItem value="10000000">$10M</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleAlert(alert.id)}
                        className={alert.enabled ? "text-green-400" : "text-gray-500"}
                        data-testid={`button-toggle-alert-${alert.id}`}
                      >
                        {alert.enabled ? <Bell size={14} /> : <BellOff size={14} />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeAlert(alert.id)}
                        className="text-red-400 hover:text-red-300"
                        data-testid={`button-remove-alert-${alert.id}`}
                      >
                        <X size={14} />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
              {alerts.length === 0 && (
                <div className="text-center py-8 text-gray-500" data-testid="text-no-alerts">
                  <Bell size={24} className="mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No alerts configured. Add one to get notified of whale movements.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </TradingPlatformLayout>
  );
}