/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Arbitrage Scanner™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Arbitrage Scanner™
 * - Cross-Exchange Price Comparator™
 * - Real-Time Spread Detection™
 * - Arbitrage Opportunity Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_fbdfdaa27bceb93055cc5417
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import Arbitrage from "@/pages/Arbitrage";
import { useWallet } from "@/contexts/WalletContext";

export default function AlphaTradingArbitrage() {
  const wallet = useWallet();
  const [connectedExchanges] = useState<string[]>(() => {
    const stored = localStorage.getItem('connected_exchanges');
    return stored ? JSON.parse(stored) : [];
  });

  return (
    <Arbitrage 
      variant="trading-platform" 
      connectedWallets={wallet.connectedWallets.map(w => ({
        id: w.id,
        name: w.name,
        chain: w.chain as "none" | "solana" | "evm",
        type: w.type
      }))}
      connectedExchanges={connectedExchanges}
    />
  );
}
