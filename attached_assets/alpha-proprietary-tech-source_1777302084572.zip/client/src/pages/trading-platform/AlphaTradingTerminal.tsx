/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Trading Terminal Interface™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Trading Terminal Interface™
 * - Multi-Panel Trading View™
 * - Real-Time Execution Console™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_76f5d9e88b877e3f0d10fe56
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import Trading from "@/pages/Trading";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { CollapsibleSection } from "@/components/CollapsibleSection";
import {
  ArrowRight,
  Shield,
  Globe,
  Lock,
  Eye,
  Activity,
  Wallet,
  Award,
  ShieldAlert,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Crown,
  Zap,
  Bot,
  Brain,
  Star,
  TrendingUp,
  BarChart3,
  Target,
  Users,
  Layers,
  Copy,
  Play,
  Monitor,
  LineChart,
  ArrowUpRight,
  Sparkles,
  Clock,
  Gauge,
  Radio,
  ShieldCheck,
  BadgeCheck,
  Cpu,
  Network,
  Server,
  Briefcase,
  ArrowLeftRight,
  Bell,
  BookOpen,
  MessageCircle,
  Calculator,
  Settings,
  Rocket,
  Grid3X3,
  Coins,
  GripHorizontal,
} from "lucide-react";

function AnimatedCounter({ target, suffix = "", prefix = "" }: { target: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 2000;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target]);

  return (
    <div className="text-4xl sm:text-5xl font-bold text-white tabular-nums">
      {prefix}{count}{suffix}
    </div>
  );
}

const SUBSCRIPTION_PLANS = [
  {
    name: "Basic",
    price: "$24",
    period: "/mo",
    color: "#3b82f6",
    gradient: "from-blue-500/10 to-blue-600/5",
    borderHover: "hover:border-blue-500/40",
    features: ["80 trades/day", "5 AI Trading Bots", "Strategy Designer & Backtesting", "TWAP & Signal Bots", "3 Exchange Connections"],
    cta: "Get Started",
    popular: false,
    icon: Zap,
  },
  {
    name: "Premium",
    price: "$44",
    period: "/mo",
    color: "#a855f7",
    gradient: "from-purple-500/10 to-purple-600/5",
    borderHover: "hover:border-purple-500/40",
    features: ["200 trades/day", "15 Bots + All 11 Bot Types", "SmartTrade & TradingView Webhooks", "11 Proprietary Technologies", "Strategy Marketplace & Copy Trading"],
    cta: "Go Premium",
    popular: true,
    icon: Star,
  },
  {
    name: "Platinum",
    price: "$64",
    period: "/mo",
    color: "#06b6d4",
    gradient: "from-cyan-500/10 to-cyan-600/5",
    borderHover: "hover:border-cyan-400/40",
    features: ["500 trades/day", "25 Bots + 17 Proprietary Technologies", "AI Strategy Selection", "Futures & Position Scaling", "10 Exchange Connections"],
    cta: "Go Platinum",
    popular: false,
    icon: Crown,
  },
  {
    name: "Alpha",
    price: "$94",
    period: "/mo",
    color: "#FFD700",
    gradient: "from-yellow-500/10 to-yellow-600/5",
    borderHover: "hover:border-yellow-500/40",
    features: ["Unlimited Bots + All 20 Technologies", "Custom Bot Builder & Strategy Designer", "Auto Bridge Fusion + ANCE\u00B2", "Dedicated Account Manager", "API Access & White-label"],
    cta: "Go Alpha",
    popular: false,
    icon: Award,
  },
];

const SECURITY_CATEGORIES = [
  {
    title: "Network & Infrastructure",
    icon: Globe,
    count: 10,
    color: "#3b82f6",
    items: ["DDoS Protection & Mitigation", "Web Application Firewall (WAF)", "SSL/TLS Encryption (HTTPS)", "Rate Limiting & Throttling", "IP Blocklist & Geo-Blocking", "Request Smuggling Detection", "DNS Security (DNSSEC)", "Load Balancing & Failover", "CDN Protection", "Infrastructure Monitoring"],
  },
  {
    title: "Authentication & Access",
    icon: Lock,
    count: 10,
    color: "#8b5cf6",
    items: ["Multi-Factor Authentication (MFA/2FA)", "OAuth 2.0 & OpenID Connect", "Session Management & Rotation", "Password Hashing (bcrypt/argon2)", "Account Lockout Protection", "IP Change Detection", "Idle Session Timeout", "API Key Authentication", "Role-Based Access Control", "Single Sign-On (SSO)"],
  },
  {
    title: "Application Security",
    icon: Shield,
    count: 10,
    color: "#06b6d4",
    items: ["SQL Injection Prevention", "XSS (Cross-Site Scripting) Protection", "CSRF Token Validation", "Input Sanitization & Validation", "Content Security Policy (CSP)", "Security Headers (HSTS, X-Frame)", "Anti-Debugging Protection", "Code Integrity Verification", "DevTools Detection", "Function Freezing"],
  },
  {
    title: "Data Protection & Privacy",
    icon: Eye,
    count: 10,
    color: "#10b981",
    items: ["End-to-End Encryption", "Encrypted Database Storage", "HMAC-Signed Local Storage", "Secure Cookie Settings (HttpOnly)", "Data Anonymization", "GDPR Compliance Framework", "Privacy-By-Design Architecture", "Secure Data Transmission", "Encrypted Backups", "Data Retention Policies"],
  },
  {
    title: "Monitoring & Threat Detection",
    icon: Activity,
    count: 10,
    color: "#f59e0b",
    items: ["Real-Time Activity Monitoring", "Brute Force Detection", "Anomaly Detection Engine", "Automated IP Blocking", "Honeypot Trap Systems", "Cross-Tab Monitoring", "Clock Tampering Detection", "Malicious Bot Detection", "Directory Bruteforce Protection", "Request Fingerprinting"],
  },
  {
    title: "Financial & Custodial",
    icon: Wallet,
    count: 10,
    color: "#ec4899",
    items: ["Non-Custodial Architecture", "Cold Storage Reserves", "Insurance/SAFU Fund", "Proof of Reserves", "Withdrawal Whitelisting", "Anti-Phishing Code System", "Transaction Signing Verification", "Multi-Signature Wallets", "Hot Wallet Limits", "Audit Trail Logging"],
  },
  {
    title: "Compliance & Legal",
    icon: Award,
    count: 10,
    color: "#14b8a6",
    items: ["KYC/AML Compliance", "SOC 2 Type II Certification", "ISO 27001 Certification", "Bug Bounty Program", "Regular Penetration Testing", "Third-Party Security Audits", "Regulatory Compliance", "Terms of Service Enforcement", "Legal Disclaimer System", "Consent Management"],
  },
  {
    title: "Advanced Anti-Tampering",
    icon: ShieldAlert,
    count: 10,
    color: "#ef4444",
    items: ["Device Fingerprinting", "Progressive Tamper Scoring", "Console Protection", "Right-Click Prevention", "Keyboard Shortcut Blocking", "LocalStorage Wrapping", "Window Property Protection", "Cross-Origin Policies", "Obfuscation Layers", "Runtime Integrity Checks"],
  },
];

const PLATFORM_FEATURES = [
  { icon: LineChart, title: "Professional Charts", desc: "15+ technical indicators with real-time WebSocket streaming", category: "Trading" },
  { icon: Brain, title: "ANCE AI Signals", desc: "7-layer neural scoring with live confidence analysis", category: "AI" },
  { icon: BarChart3, title: "Arbitrage Scanner", desc: "Cross-exchange price gaps detected in milliseconds", category: "Trading" },
  { icon: Bot, title: "8 AI Trading Bots", desc: "From grid to momentum, fully automated strategies", category: "AI" },
  { icon: Users, title: "Copy Trading", desc: "Mirror top performers with one click", category: "Social" },
  { icon: Layers, title: "Custom Dashboard", desc: "Drag-and-drop 16 widget types to your layout", category: "Tools" },
  { icon: Target, title: "Advanced Orders", desc: "OCO, trailing stop, and 5 more pro order types", category: "Trading" },
  { icon: Copy, title: "Strategy Backtesting", desc: "Test ideas against years of historical data", category: "Tools" },
  { icon: Gauge, title: "Probability Calculator", desc: "AI-ranked profit probability across 30 coins", category: "AI" },
  { icon: Radio, title: "Whale Notifications", desc: "Real-time alerts when big money moves", category: "Social" },
  { icon: Cpu, title: "18 Proprietary Technologies", desc: "Exclusive algorithms found nowhere else", category: "AI" },
  { icon: Network, title: "32+ Exchange Connections", desc: "Unified interface across all major exchanges", category: "Trading" },
];

const HOW_IT_WORKS = [
  { step: "01", title: "Connect", desc: "Link your exchange with read-only API keys. Your funds stay in your exchange.", icon: Monitor },
  { step: "02", title: "Analyze", desc: "Our AI scans markets with 18 proprietary technologies for optimal signals.", icon: Brain },
  { step: "03", title: "Execute", desc: "Trade manually or let AI bots handle it. Full control, always.", icon: Zap },
  { step: "04", title: "Grow", desc: "Track performance, backtest strategies, and scale your approach.", icon: TrendingUp },
];

const TERMINAL_TOOLS = [
  { icon: Briefcase, title: "Portfolio Tracker", desc: "Real-time P&L, allocation charts, and performance analytics across all connected exchanges", color: "#3b82f6", link: "/alpha-trading/terminal" },
  { icon: BarChart3, title: "Arbitrage Scanner", desc: "Spot price differences across 10+ exchanges and execute cross-exchange trades instantly", color: "#10b981", link: "/alpha-trading/terminal" },
  { icon: Users, title: "Copy Trading", desc: "Follow top performers and automatically mirror their trades in real-time", color: "#a855f7", link: "/alpha-trading/terminal" },
  { icon: Bot, title: "AI Trading Bots", desc: "8 automated strategies including Grid, DCA, Trailing, TWAP, and Signal bots", color: "#f59e0b", link: "/alpha-trading/terminal" },
  { icon: Radio, title: "Whale Tracker", desc: "Monitor large blockchain transactions and get instant alerts when big money moves", color: "#ec4899", link: "/alpha-trading/terminal" },
  { icon: Copy, title: "Strategy Backtesting", desc: "Test your trading ideas against years of historical market data before risking capital", color: "#06b6d4", link: "/alpha-trading/terminal" },
  { icon: GripHorizontal, title: "Dashboard Builder", desc: "Drag-and-drop 16 widget types to create your personalized trading workspace", color: "#8b5cf6", link: "/alpha-trading/terminal" },
  { icon: ArrowLeftRight, title: "DEX & Universal Swap", desc: "Swap tokens across Uniswap, Jupiter, Raydium, PancakeSwap and more from one interface", color: "#14b8a6", link: "/alpha-trading/terminal" },
  { icon: Bell, title: "Price Alerts", desc: "Set custom price targets and get notified via push, email, or in-app when triggered", color: "#ef4444", link: "/alpha-trading/terminal" },
  { icon: Brain, title: "AI Recommendations", desc: "Get AI-powered trade suggestions with confidence scores and risk analysis", color: "#FFD700", link: "/alpha-trading/terminal" },
  { icon: Calculator, title: "Trading Calculator", desc: "Position sizing, risk/reward, profit targets, and liquidation price calculator", color: "#64748B", link: "/alpha-trading/terminal" },
  { icon: Rocket, title: "Token Launchpad", desc: "Discover and get early access to new token launches before they hit major exchanges", color: "#f97316", link: "/alpha-trading/terminal" },
  { icon: Coins, title: "Staking & Earn", desc: "Flexible and locked staking pools to earn passive yield on your holdings", color: "#22c55e", link: "/alpha-trading/terminal" },
  { icon: Settings, title: "Custom Connections", desc: "Connect any unlisted exchange or wallet via API keys for unified portfolio management", color: "#94a3b8", link: "/alpha-trading/terminal" },
  { icon: BookOpen, title: "Learning Center", desc: "Step-by-step guides for every tool, strategy tutorials, and trading fundamentals", color: "#6366f1", link: "/alpha-trading/terminal" },
  { icon: MessageCircle, title: "AI Trading Chatbot", desc: "Ask questions about markets, get strategy advice, and control your terminal with natural language", color: "#0ea5e9", link: "/alpha-trading/terminal" },
  { icon: Grid3X3, title: "Cross-Platform Trading", desc: "Execute trades on 32+ exchanges from a single unified interface without switching tabs", color: "#d946ef", link: "/alpha-trading/terminal" },
  { icon: Star, title: "Premium Add-Ons", desc: "Stackable add-ons for whale alerts, premium signals, backtesting pro, and more", color: "#eab308", link: "/alpha-trading/terminal" },
];

const TRUST_BADGES = [
  { label: "SOC 2 Type II", icon: BadgeCheck },
  { label: "ISO 27001", icon: ShieldCheck },
  { label: "Non-Custodial", icon: Lock },
  { label: "Bug Bounty", icon: Shield },
  { label: "GDPR Ready", icon: Eye },
  { label: "256-bit SSL", icon: Server },
];

export default function AlphaTradingTerminal() {
  const [openSecuritySection, setOpenSecuritySection] = useState<number | null>(null);
  const [activeFeatureTab, setActiveFeatureTab] = useState("All");
  const featureTabs = ["All", "Trading", "AI", "Social", "Tools"];

  const filteredFeatures = activeFeatureTab === "All"
    ? PLATFORM_FEATURES
    : PLATFORM_FEATURES.filter(f => f.category === activeFeatureTab);

  return (
    <TradingPlatformLayout>
      <section className="relative py-16 sm:py-24 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00D4FF]/3 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#a855f7]/3 rounded-full blur-[100px]" />
        </div>
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#00D4FF]/8 border border-[#00D4FF]/20 rounded-full mb-6">
              <Sparkles size={14} className="text-[#00D4FF]" />
              <span className="text-[#00D4FF] text-xs font-medium tracking-wide uppercase">Powered by 18 Proprietary Technologies</span>
            </div>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight tracking-tight"
            data-testid="text-hero-title"
          >
            The Most Advanced
            <br />
            <span className="bg-gradient-to-r from-[#00D4FF] via-[#a855f7] to-[#FFD700] bg-clip-text text-transparent">
              Trading Terminal
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-[#94A3B8] text-lg sm:text-xl max-w-2xl mx-auto mb-8 leading-relaxed"
            data-testid="text-hero-description"
          >
            Real-time charts, AI-powered signals, automated bots, and institutional-grade security.
            Everything you need to trade smarter, in one place.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap items-center justify-center gap-4"
          >
            <a href="#terminal" className="group px-8 py-3.5 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-xl hover:shadow-lg hover:shadow-[#00D4FF]/20 transition-all flex items-center gap-2" data-testid="button-launch-terminal">
              Launch Terminal
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#features" className="px-8 py-3.5 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all flex items-center gap-2" data-testid="button-explore-features">
              Explore Features
              <ChevronDown size={18} />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3 mt-10 text-sm text-[#64748B]"
          >
            <span className="flex items-center gap-1.5"><Monitor size={14} className="text-[#00D4FF]" /> Desktop & Mobile</span>
            <span className="flex items-center gap-1.5"><Clock size={14} className="text-green-400" /> Real-time Data</span>
            <span className="flex items-center gap-1.5"><Shield size={14} className="text-[#FFD700]" /> 89 Security Layers</span>
            <span className="flex items-center gap-1.5"><Wallet size={14} className="text-purple-400" /> Non-Custodial</span>
          </motion.div>
        </div>
      </section>

      <section id="terminal" className="pb-10 sm:pb-16">
        <div className="max-w-[1500px] mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative rounded-2xl shadow-2xl shadow-[#00D4FF]/5 border border-[#1A2942]/80">
              <div className="absolute inset-0 bg-gradient-to-b from-[#00D4FF]/3 to-transparent h-1 rounded-t-2xl" />
              <Trading variant="trading-platform" />
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-12 sm:py-16 border-t border-[#152238]/60">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
            {[
              { value: 270, suffix: "+", label: "Cryptocurrencies", color: "#00D4FF" },
              { value: 32, suffix: "+", label: "Exchanges", color: "#a855f7" },
              { value: 57, suffix: "", label: "Wallets Supported", color: "#FFD700" },
              { value: 89, suffix: "", label: "Security Layers", color: "#10b981" },
            ].map((stat) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
              >
                <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                <div className="text-sm text-[#64748B] mt-1 font-medium" data-testid={`text-stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>{stat.label}</div>
                <div className="w-8 h-0.5 mx-auto mt-3 rounded-full" style={{ backgroundColor: stat.color, opacity: 0.5 }} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-8 border-t border-b border-[#152238]/40">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
            {TRUST_BADGES.map((badge) => (
              <div key={badge.label} className="flex items-center gap-2 text-[#64748B] hover:text-[#94A3B8] transition-colors" data-testid={`badge-${badge.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <badge.icon size={16} className="text-green-400/70" />
                <span className="text-xs font-medium uppercase tracking-wider">{badge.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CollapsibleSection previewHeight={320} label="View All Features">
      <section id="features" className="py-16 sm:py-24">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              Professional Tools, Zero Compromise
            </h2>
            <p className="text-[#94A3B8] max-w-2xl mx-auto text-lg">
              Everything institutional traders use, designed for everyone
            </p>
          </motion.div>

          <div className="flex items-center justify-center gap-2 mb-10">
            {featureTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveFeatureTab(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeFeatureTab === tab
                    ? "bg-[#00D4FF]/15 text-[#00D4FF] border border-[#00D4FF]/30"
                    : "text-[#64748B] hover:text-white hover:bg-white/5 border border-transparent"
                }`}
                data-testid={`tab-feature-${tab.toLowerCase()}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredFeatures.map((feature, i) => (
                <motion.div
                  key={feature.title}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, delay: i * 0.04 }}
                  className="group relative bg-[#0D1117] border border-[#1A2942] rounded-xl p-5 hover:border-[#00D4FF]/25 transition-all duration-300"
                  data-testid={`feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-[#00D4FF]/3 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#00D4FF]/15 to-[#00D4FF]/5 flex items-center justify-center border border-[#00D4FF]/10">
                        <feature.icon size={20} className="text-[#00D4FF]" />
                      </div>
                      <span className="text-[10px] font-semibold uppercase tracking-widest text-[#475569] bg-[#152238]/80 px-2 py-0.5 rounded">{feature.category}</span>
                    </div>
                    <h3 className="text-white font-semibold text-[15px] mb-1.5">{feature.title}</h3>
                    <p className="text-[#64748B] text-sm leading-relaxed">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>
      </CollapsibleSection>

      <section className="py-16 sm:py-24 relative">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1A2942] to-transparent" />
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-purple-500/8 border border-purple-500/20 rounded-full mb-6">
              <Layers size={14} className="text-purple-400" />
              <span className="text-purple-400 text-xs font-medium tracking-wide uppercase">Built-In Tools</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              18 Trading Tools, One Terminal
            </h2>
            <p className="text-[#94A3B8] text-lg max-w-2xl mx-auto">
              Every tool you need is built right into your terminal. No switching between apps.
            </p>
          </motion.div>

          <CollapsibleSection previewHeight={300} label="View All Tools">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {TERMINAL_TOOLS.map((tool, i) => (
              <motion.div
                key={tool.title}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="group flex items-start gap-4 p-4 rounded-xl bg-[#0D1117] border border-[#1A2942] hover:border-[#2A3952] transition-all"
                data-testid={`tool-${tool.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: tool.color + "12" }}>
                  <tool.icon size={18} style={{ color: tool.color }} />
                </div>
                <div className="min-w-0">
                  <h3 className="text-white font-semibold text-sm mb-1">{tool.title}</h3>
                  <p className="text-[#64748B] text-xs leading-relaxed">{tool.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
          </CollapsibleSection>
        </div>
      </section>

      <section className="py-16 sm:py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A1628]/80 via-[#0A1628]/40 to-transparent pointer-events-none" />
        <div className="max-w-5xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              Up and Running in Minutes
            </h2>
            <p className="text-[#94A3B8] text-lg max-w-xl mx-auto">
              No downloads, no complex setup. Connect your exchange and start trading.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {HOW_IT_WORKS.map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="relative text-center"
              >
                {i < HOW_IT_WORKS.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-px bg-gradient-to-r from-[#1A2942] to-transparent" />
                )}
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#152238] to-[#0D1117] border border-[#1A2942] flex items-center justify-center mx-auto mb-4 relative">
                  <item.icon size={28} className="text-[#00D4FF]" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[#00D4FF] text-[#0A1628] text-[10px] font-bold flex items-center justify-center">
                    {item.step}
                  </div>
                </div>
                <h3 className="text-white font-semibold text-lg mb-2" data-testid={`text-step-${item.step}`}>{item.title}</h3>
                <p className="text-[#64748B] text-sm leading-relaxed max-w-[200px] mx-auto">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 relative">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1A2942] to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1A2942] to-transparent" />
        </div>
        <div className="max-w-5xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              Why Traders Choose Alpha
            </h2>
            <p className="text-[#94A3B8] text-lg max-w-xl mx-auto">
              Built different from every other trading platform
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-5">
            {[
              {
                icon: Zap,
                title: "Blazing Fast Execution",
                desc: "WebSocket streaming delivers jitter-free candlestick data directly from exchanges. No delays, no lag, no missed opportunities.",
                color: "#00D4FF",
                gradient: "from-[#00D4FF]/10 to-[#00D4FF]/2",
              },
              {
                icon: Lock,
                title: "Non-Custodial by Design",
                desc: "Your funds never leave your exchange. We connect through read/trade API keys only. You maintain full control, always.",
                color: "#10b981",
                gradient: "from-emerald-500/10 to-emerald-500/2",
              },
              {
                icon: Cpu,
                title: "18 Proprietary Technologies",
                desc: "From ANCE neural signals to QMGE genome analysis, our exclusive algorithms are found nowhere else in the industry.",
                color: "#FFD700",
                gradient: "from-yellow-500/10 to-yellow-500/2",
              },
            ].map((card, i) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`relative p-6 rounded-2xl bg-gradient-to-b ${card.gradient} border border-[#1A2942] hover:border-opacity-60 transition-all group`}
              >
                <div className="w-12 h-12 rounded-xl bg-[#0D1117] border border-[#1A2942] flex items-center justify-center mb-5">
                  <card.icon size={22} style={{ color: card.color }} />
                </div>
                <h3 className="text-white font-bold text-lg mb-3" data-testid={`text-why-${card.title.toLowerCase().replace(/\s+/g, '-')}`}>{card.title}</h3>
                <p className="text-[#94A3B8] text-sm leading-relaxed">{card.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-28 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0A1628]/50 to-transparent pointer-events-none" />
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-14"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#00D4FF]/8 border border-[#00D4FF]/20 rounded-full mb-6">
              <Crown size={14} className="text-[#00D4FF]" />
              <span className="text-[#00D4FF] text-xs font-medium tracking-wide uppercase">Trading Plans</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              Choose Your Trading Level
            </h2>
            <p className="text-[#94A3B8] text-lg max-w-2xl mx-auto">
              Start free with powerful tools. Upgrade when you're ready for more.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 max-w-5xl mx-auto"
          >
            <div className="bg-gradient-to-r from-[#152238]/80 via-[#0D1117] to-[#152238]/80 border border-[#1A2942] rounded-2xl p-6" data-testid="plan-card-free">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-[#1A2942]/50 flex items-center justify-center flex-shrink-0">
                    <Play size={24} className="text-[#64748B]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-xl font-bold text-white" data-testid="text-plan-free">Free Tier</h3>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-green-500/20 text-green-400 border border-green-500/30 font-bold">NO CREDIT CARD</span>
                    </div>
                    <p className="text-[#94A3B8] text-sm mb-3">Practice risk-free with paper trading bots, a $10k demo sandbox, and real-time market data.</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                      {["3 Paper Trading Bots", "$10k Demo Sandbox", "Backtesting", "Portfolio Tracking", "AI Suggestions", "Real-Time Market Data", "Copy Bot Preview", "Price Alerts", "Grid/DCA/Trailing Bots", "Email Alerts"].map((f) => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-300">
                          <CheckCircle size={10} className="text-green-500 flex-shrink-0" />
                          {f}
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {["Real Exchange Trading", "Proprietary Technologies", "Advanced Filters", "Bridge Fusion"].map((f) => (
                        <span key={f} className="flex items-center gap-1 text-[10px] text-[#475569] px-2 py-0.5 rounded bg-[#0D1117] border border-[#1A2942]">
                          <Lock size={10} /> {f}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-center gap-2 flex-shrink-0">
                  <div className="text-center">
                    <span className="text-4xl font-bold text-white">$0</span>
                    <span className="text-[#64748B]">/forever</span>
                  </div>
                  <button
                    onClick={() => window.location.href = "/api/login"}
                    className="w-full px-6 py-2.5 border border-green-500/40 text-green-400 hover:bg-green-500/10 rounded-xl font-semibold text-sm transition-all"
                    data-testid="button-plan-free"
                  >
                    Start Free
                  </button>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
            {SUBSCRIPTION_PLANS.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className={`relative bg-gradient-to-b ${plan.gradient} border rounded-2xl p-5 transition-all duration-300 ${plan.borderHover} ${
                  plan.popular
                    ? "border-purple-500/50 shadow-lg shadow-purple-500/8 scale-[1.02] lg:scale-[1.03]"
                    : "border-[#1A2942]"
                }`}
                data-testid={`plan-card-${plan.name.toLowerCase()}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white text-[11px] font-bold rounded-full whitespace-nowrap shadow-lg shadow-purple-500/20">
                    Most Popular
                  </div>
                )}
                <div className="text-center mb-5">
                  <div className="w-10 h-10 rounded-xl mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: plan.color + "15" }}>
                    <plan.icon size={18} style={{ color: plan.color }} />
                  </div>
                  <h3 className="text-base font-bold" style={{ color: plan.color }}>{plan.name}</h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-white">{plan.price}</span>
                    <span className="text-sm text-[#64748B]">{plan.period}</span>
                  </div>
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-[#1A2942] to-transparent mb-5" />
                <ul className="space-y-2.5 mb-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm text-gray-300">
                      <CheckCircle size={14} className="mt-0.5 flex-shrink-0" style={{ color: plan.color }} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => window.location.href = "/api/login"}
                  className={`w-full py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 ${
                    plan.popular
                      ? "bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white hover:shadow-md hover:shadow-purple-500/20"
                      : "bg-[#152238] text-white hover:bg-[#1A2942] border border-[#1A2942] hover:border-[#2A3952]"
                  }`}
                  data-testid={`button-plan-${plan.name.toLowerCase()}`}
                >
                  {plan.cta}
                </button>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mt-8 max-w-2xl mx-auto"
          >
            <div className="bg-gradient-to-r from-green-500/5 via-green-500/10 to-green-500/5 border border-green-500/20 rounded-xl p-4">
              <p className="text-[#94A3B8] text-sm">
                <span className="text-white font-semibold">Start Free, Upgrade Anytime.</span> Every plan begins with our free paper trading sandbox. Practice strategies risk-free, then upgrade when you're ready to go live.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-14"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-green-500/8 border border-green-500/20 rounded-full mb-6">
              <Shield size={14} className="text-green-400" />
              <span className="text-green-400 text-xs font-medium tracking-wide uppercase">Enterprise-Grade Security</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              89 Layers of Protection
            </h2>
            <p className="text-[#94A3B8] text-lg max-w-2xl mx-auto">
              Your assets and data are protected by the most comprehensive security stack in crypto
            </p>
          </motion.div>

          <CollapsibleSection previewHeight={280} label="View All Security Layers">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {SECURITY_CATEGORIES.map((category, catIndex) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: catIndex * 0.04 }}
                className="bg-[#0D1117] border border-[#1A2942] rounded-xl overflow-hidden hover:border-[#2A3952] transition-colors"
              >
                <button
                  onClick={() => setOpenSecuritySection(openSecuritySection === catIndex ? null : catIndex)}
                  className="w-full flex items-center justify-between p-4 hover:bg-[#152238]/40 transition-all text-left"
                  data-testid={`security-dropdown-${catIndex}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: category.color + "15" }}>
                      <category.icon size={18} style={{ color: category.color }} />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-sm">{category.title}</h3>
                      <p className="text-xs text-[#475569]">{category.count} protections</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="hidden sm:flex items-center gap-1">
                      {Array.from({ length: 10 }).map((_, i) => (
                        <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: category.color, opacity: 0.7 }} />
                      ))}
                    </div>
                    {openSecuritySection === catIndex ? (
                      <ChevronUp size={18} className="text-[#64748B] ml-2" />
                    ) : (
                      <ChevronDown size={18} className="text-[#64748B] ml-2" />
                    )}
                  </div>
                </button>
                <AnimatePresence>
                  {openSecuritySection === catIndex && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 grid grid-cols-1 gap-1.5">
                        {category.items.map((item) => (
                          <div key={item} className="flex items-center gap-2.5 py-1.5 px-3 bg-[#152238]/30 rounded-lg">
                            <CheckCircle size={13} style={{ color: category.color }} className="flex-shrink-0" />
                            <span className="text-sm text-[#94A3B8]">{item}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>

          </CollapsibleSection>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center mt-8"
          >
            <Link href="/security">
              <button className="px-6 py-2.5 text-sm font-medium text-[#94A3B8] hover:text-white border border-[#1A2942] hover:border-[#2A3952] rounded-xl transition-all flex items-center gap-2 mx-auto" data-testid="button-view-full-security">
                View Full Security Report
                <ArrowRight size={16} />
              </button>
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="py-16 sm:py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A1628]/60 via-[#00D4FF]/3 to-[#0A1628]/60 pointer-events-none" />
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 tracking-tight">
              Ready to Trade Smarter?
            </h2>
            <p className="text-[#94A3B8] text-lg mb-8 max-w-xl mx-auto">
              Join thousands of traders using Alpha Unlimited. Start with a free account and upgrade anytime.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a href="#terminal" className="group px-8 py-3.5 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-xl hover:shadow-lg hover:shadow-[#00D4FF]/20 transition-all flex items-center gap-2" data-testid="button-start-trading-cta">
                Start Trading Now
                <ArrowUpRight size={18} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
              <Link href="/alpha-trading">
                <button className="px-8 py-3.5 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all" data-testid="button-learn-more-cta">
                  Learn More
                </button>
              </Link>
            </div>
            <p className="text-xs text-[#475569] mt-6">
              No credit card required. Free plan available forever.
            </p>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}
