/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Branded Authentication Gateway™
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * ALPHA_INTEGRITY_SEAL: AUTH_GATEWAY_v1.0_PROTECTED
 * AUT_ModuleHash: AUT_d9e3f41bc2a8e16d3490cc7a
 */

import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function BrandedLogin() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [showMore, setShowMore] = useState(false);

  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  const handleLogin = () => {
    window.location.href = "/api/login?returnUrl=/";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050a12] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050a12] flex flex-col items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gradient-radial from-cyan-600/8 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-radial from-blue-600/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-gradient-radial from-purple-600/5 to-transparent rounded-full blur-3xl" />
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-px bg-gradient-to-b from-transparent via-cyan-500/20 to-transparent"
            style={{
              left: `${5 + i * 5}%`,
              top: 0,
              height: "100%",
              opacity: 0.3 + Math.sin(i * 0.5) * 0.2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-md px-6">
        <div className="bg-[#0d1117] border border-gray-800/60 rounded-2xl p-8 backdrop-blur-xl shadow-2xl shadow-black/50">
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30" data-testid="login-logo">
              <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-white" style={{ fontFamily: "Orbitron, sans-serif" }} data-testid="text-login-title">
              Sign up for Alpha Unlimited Trading
            </h1>
          </div>

          <div className="space-y-3 mb-6">
            <button
              onClick={handleLogin}
              className="w-full py-3.5 bg-[#1a1f2e] hover:bg-[#252b3d] border border-gray-700/50 hover:border-gray-600 text-white font-medium rounded-xl transition-all duration-200 flex items-center justify-center gap-3"
              data-testid="button-google"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              <span>Continue with Google</span>
            </button>

            <button
              onClick={handleLogin}
              className="w-full py-3.5 bg-[#1a1f2e] hover:bg-[#252b3d] border border-gray-700/50 hover:border-gray-600 text-white font-medium rounded-xl transition-all duration-200 flex items-center justify-center gap-3"
              data-testid="button-apple"
            >
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
              <span>Continue with Apple</span>
            </button>

            <button
              onClick={handleLogin}
              className="w-full py-3.5 bg-[#1a1f2e] hover:bg-[#252b3d] border border-gray-700/50 hover:border-gray-600 text-white font-medium rounded-xl transition-all duration-200 flex items-center justify-center gap-3"
              data-testid="button-email"
            >
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
              </svg>
              <span>Continue with email</span>
            </button>
          </div>

          {!showMore && (
            <button
              onClick={() => setShowMore(true)}
              className="w-full text-center text-gray-500 hover:text-gray-300 text-sm transition-colors"
              data-testid="button-more-options"
            >
              View more options
            </button>
          )}

          {showMore && (
            <div className="space-y-3 mb-4">
              <button
                onClick={handleLogin}
                className="w-full py-3.5 bg-[#1a1f2e] hover:bg-[#252b3d] border border-gray-700/50 hover:border-gray-600 text-white font-medium rounded-xl transition-all duration-200 flex items-center justify-center gap-3"
                data-testid="button-github"
              >
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/>
                </svg>
                <span>Continue with GitHub</span>
              </button>
            </div>
          )}

          <div className="mt-6 pt-4 border-t border-gray-800/60 text-center">
            <p className="text-gray-600 text-xs">
              Log in secured by <span className="text-cyan-500 font-medium">Alpha Unlimited Trading</span>
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <p className="text-gray-600 text-[10px]">
            By continuing, you agree to Alpha Unlimited Trading's Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
}
