/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Mining Technologies Dashboard™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Temporal Difficulty Analysis™
 * - Entropy Cascade Mapping™
 * - Network Latency Optimizer™
 * - Mining Performance Harmonics™
 * - Predictive Hash Control™
 * - Autonomous Calibration Matrix™
 * - Autonomous Blockchain Spider™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_0daa5f4696ec358b196d0e91
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { 
  ArrowLeft, ExternalLink, Cpu, Zap, BarChart3, Shield, Pickaxe, Coins,
  Smartphone, Monitor, Download, Apple, X, Brain, Target, Sparkles, Settings,
  Play, RefreshCw, Wifi, WifiOff, ChevronUp, Clock, Server, Network, Hash, Signal,
  Link2, Unlink, Sliders, ToggleLeft, ToggleRight, BookOpen, FileDown, Usb,
  AlertCircle, CheckCircle2, ArrowUpCircle, Loader2, Info, HardDrive,
  Activity, Layers, Gauge, GitBranch, Radio, Atom, Flame, Database, TrendingUp, Eye, Bug, Globe, ScanSearch
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import jsPDF from "jspdf";
import { 
  WIFI_ETHERNET_HARDWARE, 
  USB_HARDWARE, 
  ALL_HARDWARE,
  type HardwareDevice,
  type DiscoveredDevice,
  type MinerStats
} from "@/lib/mining/hardware-registry";
import {
  coordinateMiningSignals,
  getConflictSeverityColor,
  getConflictSeverityLabel,
  getPriorityLabel,
  type SignalPriority,
  type CoordinatedCommand,
  type QMGEMiningPayload,
  type MinerAdjustments,
} from "@/lib/mining/coordinator";
import { 
  PROTOCOL_CONFIGS, 
  getProtocolConfig 
} from "@/lib/mining/protocol-handlers";
import {
  simulateNetworkScan,
  simulateUSBScan,
  connectToDevice,
  disconnectDevice,
  refreshDeviceStats,
  checkFirmwareUpdates,
  checkRegistryUpdates,
  formatUptime,
  formatHashrate,
  getConnectionTypeLabel,
  getDeviceConnectionInfo,
  REGISTRY_VERSION,
  type FirmwareUpdate,
  type ConnectionState
} from "@/lib/mining/connection-manager";

const SBPE_TECHNOLOGY = {
  name: "Stochastic Block Prediction Engine™",
  shortName: "SBPE",
  description: "Revolutionary mining optimization technology combining ACM™ and QFRM™ specifically designed for solo mining operations.",
  features: [
    {
      id: "tda",
      icon: Clock,
      title: "Temporal Difficulty Analysis™",
      shortTitle: "TDA",
      desc: "Monitors real-time network difficulty fluctuations to identify optimal mining windows",
      color: "#00D4FF",
      metric: "Difficulty",
      value: "18.2T"
    },
    {
      id: "ecm",
      icon: Hash,
      title: "Entropy Cascade Mapping™",
      shortTitle: "ECM",
      desc: "Analyzes statistical distribution of winning block hashes for nonce optimization",
      color: "#FFD700",
      metric: "Entropy",
      value: "87.3%"
    },
    {
      id: "nlo",
      icon: Network,
      title: "Network Latency Optimizer™",
      shortTitle: "NLO",
      desc: "Minimizes block propagation time for faster submission and reduced orphan risk",
      color: "#00FF88",
      metric: "Latency",
      value: "24ms"
    },
    {
      id: "mpm",
      icon: Coins,
      title: "Mempool Profit Maximizer™",
      shortTitle: "MPM",
      desc: "Optimizes transaction selection for maximum fee collection per block",
      color: "#A855F7",
      metric: "Fees",
      value: "+12.4%"
    },
    {
      id: "phc",
      icon: Target,
      title: "Probabilistic Hash Convergence™",
      shortTitle: "PHC",
      desc: "Statistical modeling for time-to-block estimation and probability scoring",
      color: "#F59E0B",
      metric: "Probability",
      value: "0.0023%"
    },
    {
      id: "acm",
      icon: Brain,
      title: "ACM™ Mining Integration",
      shortTitle: "ACM",
      desc: "Alpha Convergence Matrix momentum and smart money flow for timing optimization",
      color: "#EC4899",
      metric: "Signal",
      value: "BUY"
    },
    {
      id: "abs",
      icon: Bug,
      title: "Autonomous Blockchain Spider™",
      shortTitle: "ABS",
      desc: "Crawls historical block data analyzing nonce patterns, difficulty trends, and timing intelligence to optimize block discovery",
      color: "#14B8A6",
      metric: "Crawled",
      value: "1,247"
    },
  ]
};

const NCA_TECHNOLOGY = {
  name: "Nonce Convergence Algorithm™",
  shortName: "NCA",
  tagline: "Adapted from ACM™ Multi-Dimensional Analysis",
  description: "Instead of brute-force sequential nonce iteration, NCA uses statistical modeling of hash output distributions to predict promising nonce ranges. Combines 5 convergence dimensions—momentum flow analysis, distribution intelligence, range optimization, convergence scoring, and regime classification—into a single nonce search optimization signal.",
  color: "#FF6B35",
  gradient: "from-[#FF6B35] to-[#FF8C42]",
  features: [
    { id: "mfa", icon: Activity, title: "Momentum Flow Analysis™", shortTitle: "MFA", desc: "Tracks nonce search velocity and acceleration to detect favorable momentum in hash output patterns", color: "#FF6B35", metric: "Momentum", value: "+0.84" },
    { id: "diq", icon: Eye, title: "Distribution Intelligence™", shortTitle: "DIQ", desc: "Analyzes statistical distribution of recent hash outputs to identify clustering near target threshold", color: "#FF8C42", metric: "Distribution", value: "Clustered" },
    { id: "rso", icon: Target, title: "Range Search Optimizer™", shortTitle: "RSO", desc: "Dynamically adjusts nonce search range boundaries based on probability density estimation", color: "#FFB347", metric: "Range", value: "±2.1M" },
    { id: "cvs", icon: TrendingUp, title: "Convergence Scoring™", shortTitle: "CVS", desc: "Composite score measuring how close current search patterns are to statistically optimal paths", color: "#FFA07A", metric: "Score", value: "76.4" },
  ]
};

const HFRE_TECHNOLOGY = {
  name: "Hash Flow Resonance Engine™",
  shortName: "HFRE",
  tagline: "Adapted from QFRM™ Flow State Dynamics",
  description: "Analyzes the computational 'flow' of hash operations to detect resonance patterns in SHA-256/Ethash outputs. When the hash function enters favorable states producing outputs closer to the target threshold, HFRE identifies and exploits these resonance windows for dramatically improved solving probability.",
  color: "#7C3AED",
  gradient: "from-[#7C3AED] to-[#A855F7]",
  features: [
    { id: "fsd", icon: Radio, title: "Flow State Detection™", shortTitle: "FSD", desc: "Identifies laminar vs turbulent states in hash computation flow using third-derivative analysis", color: "#7C3AED", metric: "Flow", value: "Laminar" },
    { id: "rfd", icon: Atom, title: "Resonance Frequency™", shortTitle: "RFD", desc: "Detects natural oscillation frequencies in hash outputs approaching resonance events", color: "#8B5CF6", metric: "Frequency", value: "847Hz" },
    { id: "egm", icon: Flame, title: "Entropy Gradient™", shortTitle: "EGM", desc: "Measures order vs chaos transitions in hash output entropy using information theory", color: "#A855F7", metric: "Entropy", value: "Low" },
    { id: "rwp", icon: Gauge, title: "Resonance Window™", shortTitle: "RWP", desc: "Predicts upcoming resonance windows where hash outputs are statistically favorable", color: "#C084FC", metric: "Window", value: "12s" },
  ]
};

const BIN_TECHNOLOGY = {
  name: "Block Intelligence Network™",
  shortName: "BIN",
  tagline: "Adapted from BIF™ Blockchain Analytics",
  description: "Monitors real-time blockchain network state including difficulty adjustments, mempool congestion, competing miners' block propagation patterns, orphan rates, and uncle rates. Provides intelligence to optimize block submission timing and transaction selection for maximum profitability.",
  color: "#06B6D4",
  gradient: "from-[#06B6D4] to-[#22D3EE]",
  features: [
    { id: "nce", icon: Network, title: "Network Congestion Engine™", shortTitle: "NCE", desc: "Estimates real-time blockchain network congestion from volume patterns and fee spreads", color: "#06B6D4", metric: "Congestion", value: "37%" },
    { id: "msp", icon: Database, title: "Miner Strategy Profiler™", shortTitle: "MSP", desc: "Tracks competing miners' block propagation patterns and submission timing strategies", color: "#22D3EE", metric: "Competitors", value: "1,247" },
    { id: "orp", icon: GitBranch, title: "Orphan Rate Predictor™", shortTitle: "ORP", desc: "Predicts orphan/uncle block probability to optimize submission timing and reduce wasted work", color: "#67E8F9", metric: "Orphan Risk", value: "0.3%" },
    { id: "dap", icon: Layers, title: "Difficulty Adjustment™", shortTitle: "DAP", desc: "Forecasts upcoming difficulty adjustments to plan mining intensity around favorable windows", color: "#A5F3FC", metric: "Next Adj.", value: "-1.2%" },
  ]
};

const CCA_TECHNOLOGY = {
  name: "Cross-Correlation Analysis™",
  shortName: "CCA",
  tagline: "Proprietary Blockchain Signal Correlation Intelligence",
  description: "Performs sliding-window cross-correlation analysis on known successfully-mined blockchain data against live hash outputs. By overlaying binary representations of solved blocks and sliding them across current mining data, CCA detects statistical resonance points where live mining patterns align with historical solutions — identifying micro-windows of elevated solving probability.",
  color: "#10B981",
  gradient: "from-[#10B981] to-[#34D399]",
  features: [
    { id: "bco", icon: Layers, title: "Binary Cross-Overlay™", shortTitle: "BCO", desc: "Converts solved block headers to binary sequences and slides them across live hash outputs to detect alignment resonance at every offset position", color: "#10B981", metric: "Alignment", value: "0.0031%" },
    { id: "swd", icon: Activity, title: "Sliding Window Detector™", shortTitle: "SWD", desc: "Implements variable-width sliding windows across multiple blockchain formats (binary, hex, raw blocks) to detect repeating sub-patterns in solved block data", color: "#34D399", metric: "Windows", value: "2,847" },
    { id: "rpa", icon: Target, title: "Residual Pattern Analyzer™", shortTitle: "RPA", desc: "Breaks down solved blockchains into individual blocks, subsections, and binary components, then analyzes residual statistical patterns across all decomposition levels", color: "#6EE7B7", metric: "Residuals", value: "14 detected" },
    { id: "mcm", icon: GitBranch, title: "Multi-Chain Matcher™", shortTitle: "MCM", desc: "Cross-references pattern data from multiple successfully-mined blockchains (BTC, ETH, LTC, DOGE, XMR, KAS) to find universal correlation signatures across different hash algorithms", color: "#A7F3D0", metric: "Chains", value: "6 active" },
  ]
};

const DCA_TECHNOLOGY = {
  name: "Differential Cryptanalysis™",
  shortName: "DCA",
  tagline: "Advanced Cryptographic Structure Intelligence",
  description: "Applies differential cryptanalysis techniques to mining optimization by analyzing how small changes in nonce inputs propagate through hash function rounds. By studying the differential distribution tables and tracking bit-level propagation patterns through reduced-round approximations, DCA identifies statistical biases in intermediate hash states that may indicate favorable nonce search regions.",
  color: "#F97316",
  gradient: "from-[#F97316] to-[#FB923C]",
  features: [
    { id: "ddt", icon: Database, title: "Differential Distribution Table™", shortTitle: "DDT", desc: "Builds real-time differential distribution tables from observed hash input/output pairs, tracking how input differences map to output differences across hash function S-boxes", color: "#F97316", metric: "Bias", value: "2^-47.3" },
    { id: "bpa", icon: Radio, title: "Bit Propagation Analyzer™", shortTitle: "BPA", desc: "Traces how single-bit nonce changes cascade through each of the 64 SHA-256 compression rounds, identifying rounds where differential propagation exhibits non-uniform behavior", color: "#FB923C", metric: "Rounds", value: "31/64" },
    { id: "rrm", icon: Gauge, title: "Reduced-Round Modeler™", shortTitle: "RRM", desc: "Constructs reduced-round approximations of the target hash function to identify exploitable differential characteristics in truncated computation paths", color: "#FDBA74", metric: "Model", value: "Active" },
    { id: "isb", icon: Eye, title: "Intermediate State Bias™", shortTitle: "ISB", desc: "Monitors intermediate hash computation states for statistical deviations from uniformity that could indicate structurally favorable nonce regions in the search space", color: "#FED7AA", metric: "Deviation", value: "±0.003σ" },
  ]
};

const ABS_TECHNOLOGY = {
  name: "Autonomous Blockchain Spider™",
  shortName: "ABS",
  tagline: "Proprietary Blockchain Crawling Intelligence Engine",
  description: "A revolutionary blockchain crawling engine that autonomously traverses historical block data — both forward and backward — analyzing nonce patterns, difficulty trends, inter-block timing, entropy distributions, and block structures. The Spider continuously feeds intelligence directly into TDA™, ECM™, and NLO™ to optimize every aspect of block discovery in real-time.",
  color: "#14B8A6",
  gradient: "from-[#14B8A6] to-[#2DD4BF]",
  features: [
    { id: "hce", icon: ScanSearch, title: "Historical Crawl Engine™", shortTitle: "HCE", desc: "Autonomously crawls backward and forward through the blockchain analyzing every block for actionable mining intelligence", color: "#14B8A6", metric: "Blocks", value: "1,247" },
    { id: "nda", icon: Target, title: "Nonce Distribution Analysis™", shortTitle: "NDA", desc: "Maps nonce values from solved blocks, builds probability distributions, and identifies statistical hotspots for search optimization", color: "#2DD4BF", metric: "Hotspots", value: "23" },
    { id: "dpm", icon: TrendingUp, title: "Difficulty Prediction Model™", shortTitle: "DPM", desc: "Analyzes difficulty adjustment history to predict the next adjustment before it happens, enabling proactive mining strategy", color: "#5EEAD4", metric: "Prediction", value: "-1.4%" },
    { id: "bti", icon: Clock, title: "Block Timing Intelligence™", shortTitle: "BTI", desc: "Analyzes inter-block timestamps to find optimal mining windows when competing hash rate dips", color: "#99F6E4", metric: "Window", value: "Active" },
    { id: "epm", icon: Radio, title: "Entropy Pattern Mapping™", shortTitle: "EPM", desc: "Shannon entropy analysis of historical block hashes with bit distribution evolution tracking over time", color: "#CCFBF1", metric: "Entropy", value: "3.42σ" },
    { id: "tpo", icon: Database, title: "Template Optimization™", shortTitle: "TPO", desc: "Analyzes historical block structures including transaction counts, sizes, and merkle patterns to pre-optimize block templates", color: "#0D9488", metric: "Templates", value: "Optimized" },
  ]
};

const MINING_BRIDGE_FUSION = {
  name: "Mining Bridge Fusion™",
  shortName: "MBF",
  tagline: "Adapted from Bridge Fusion™ Multi-Bridge Architecture",
  description: "Combines NCA™ + HFRE™ + BIN™ + SBPE™ + CCA™ + DCA™ + ABS™ into composite mining optimization bridges. Like trading Bridge Fusion combines multiple filters into unified signals, Mining Bridge Fusion creates synergistic combinations — now enhanced with Autonomous Blockchain Spider™ intelligence — that amplify each technology's effectiveness for maximum block-solving probability.",
  color: "#F59E0B",
  gradient: "from-[#F59E0B] to-[#FBBF24]",
  bridges: [
    { id: "bridge_alpha", name: "Alpha Bridge", techs: ["NCA", "HFRE"], desc: "Combines nonce optimization with hash resonance for maximum search efficiency", color: "#FF6B35" },
    { id: "bridge_omega", name: "Omega Bridge", techs: ["BIN", "SBPE"], desc: "Fuses network intelligence with block prediction for optimal submission timing", color: "#06B6D4" },
    { id: "bridge_quantum", name: "Quantum Bridge", techs: ["HFRE", "BIN", "SBPE"], desc: "Triple-fusion of resonance, intelligence, and prediction for peak performance", color: "#7C3AED" },
    { id: "bridge_correlator", name: "Correlator Bridge", techs: ["CCA", "DCA"], desc: "Fuses cross-correlation pattern detection with differential cryptanalysis for deep structural analysis", color: "#10B981" },
    { id: "bridge_sentinel", name: "Sentinel Bridge", techs: ["CCA", "BIN"], desc: "Combines live blockchain cross-correlation with network intelligence for real-time pattern-aware mining", color: "#34D399" },
    { id: "bridge_cipher", name: "Cipher Bridge", techs: ["DCA", "HFRE"], desc: "Merges differential cryptanalysis with hash flow resonance for cryptographic structure optimization", color: "#F97316" },
    { id: "bridge_spider", name: "Spider Bridge", techs: ["ABS", "BIN", "SBPE"], desc: "Fuses Spider historical intelligence with network monitoring and block prediction for data-driven mining optimization", color: "#14B8A6" },
    { id: "bridge_arachnid", name: "Arachnid Bridge", techs: ["ABS", "NCA", "HFRE"], desc: "Combines Spider nonce hotspot data with convergence algorithms and hash resonance for precision-guided nonce search", color: "#0D9488" },
    { id: "bridge_ultimate", name: "Ultimate Bridge", techs: ["NCA", "HFRE", "BIN", "SBPE", "CCA", "DCA", "ABS"], desc: "Full hepta-bridge fusion — all seven technologies combined for maximum blockchain solving optimization", color: "#F59E0B" },
  ]
};

const BRIDGE_COMPATIBILITY: Record<string, { compatible: string[], incompatible: { tech: string, reason: string }[] }> = {
  "NCA": {
    compatible: ["HFRE", "BIN", "SBPE", "CCA", "ABS"],
    incompatible: [{ tech: "DCA", reason: "NCA momentum flow conflicts with DCA differential propagation — nonce range optimization and bit-level differential analysis operate on incompatible data scales" }]
  },
  "HFRE": {
    compatible: ["NCA", "BIN", "SBPE", "DCA", "ABS"],
    incompatible: [{ tech: "CCA", reason: "HFRE resonance frequency detection interferes with CCA sliding window correlation — overlapping signal processing creates destructive interference patterns" }]
  },
  "BIN": {
    compatible: ["NCA", "HFRE", "SBPE", "CCA", "DCA", "ABS"],
    incompatible: []
  },
  "SBPE": {
    compatible: ["NCA", "HFRE", "BIN", "CCA", "ABS"],
    incompatible: [{ tech: "DCA", reason: "SBPE stochastic prediction models conflict with DCA deterministic differential analysis — probabilistic and deterministic approaches produce contradictory optimization signals" }]
  },
  "CCA": {
    compatible: ["NCA", "BIN", "SBPE", "DCA", "ABS"],
    incompatible: [{ tech: "HFRE", reason: "CCA sliding window correlation conflicts with HFRE resonance frequency detection — overlapping signal processing creates destructive interference patterns" }]
  },
  "DCA": {
    compatible: ["HFRE", "BIN", "CCA", "ABS"],
    incompatible: [
      { tech: "NCA", reason: "DCA differential propagation conflicts with NCA momentum flow — bit-level differential analysis and nonce range optimization operate on incompatible data scales" },
      { tech: "SBPE", reason: "DCA deterministic differential analysis conflicts with SBPE stochastic prediction models — deterministic and probabilistic approaches produce contradictory optimization signals" }
    ]
  },
  "ABS": {
    compatible: ["NCA", "HFRE", "BIN", "SBPE", "CCA", "DCA"],
    incompatible: []
  }
};

const ALL_MINING_TECHS = ["NCA", "HFRE", "BIN", "SBPE", "CCA", "DCA", "ABS"];

const PHTM_TECHNOLOGY = {
  name: "Probabilistic Hash Terrain Mapping™",
  shortName: "PHTM",
  tagline: "Revolutionary Multi-Strategy Blockchain Solving Intelligence",
  description: "A completely original technology that treats the nonce-to-hash output space as a multi-dimensional 'terrain' and uses five distinct navigation strategies to find valleys — hash values below the network difficulty target. By combining Bayesian inference, genetic algorithms, simulated annealing, wavelet decomposition, and gradient optimization, PHTM adapts its search strategy in real-time based on statistical analysis of hash output patterns, creating the most intelligent nonce search system ever developed.",
  color: "#E11D48",
  gradient: "from-[#E11D48] to-[#F43F5E]",
  features: [
    { id: "ghd", icon: TrendingUp, title: "Gradient Hash Descent™", shortTitle: "GHD", desc: "Treats nonce-to-hash mapping as a high-dimensional landscape. Uses gradient-like optimization to navigate toward low-hash regions by analyzing directional derivatives of hash output sequences", color: "#E11D48", metric: "Gradient", value: "-0.47" },
    { id: "bnp", icon: Brain, title: "Bayesian Nonce Prior™", shortTitle: "BNP", desc: "Builds posterior probability distributions over nonce ranges using Bayesian inference from historical block solutions. Continuously updates priors as new hash results arrive", color: "#F43F5E", metric: "Posterior", value: "0.73" },
    { id: "ghe", icon: GitBranch, title: "Genetic Hash Evolution™", shortTitle: "GHE", desc: "Applies genetic algorithm principles to evolve nonce search strategies across generations. Uses crossover, mutation, and selection operators on nonce populations to breed optimal search paths", color: "#FB7185", metric: "Fitness", value: "84.2" },
    { id: "ewd", icon: Radio, title: "Entropy Wavelet Decomposition™", shortTitle: "EWD", desc: "Uses Shannon, Rényi, and Tsallis entropy measures with wavelet decomposition to analyze hash output patterns across multiple scales, identifying resonance frequencies in entropy gradients", color: "#FDA4AF", metric: "Wavelet", value: "3.7σ" },
    { id: "tas", icon: Flame, title: "Thermal Annealing Search™", shortTitle: "TAS", desc: "Applies simulated annealing to nonce search, using a temperature parameter to control probabilistic jumps between nonce ranges. High temperature explores broadly, low temperature exploits locally", color: "#FF6B6B", metric: "Temp", value: "0.42K" },
  ]
};

const BLOCKCHAIN_PRESETS = [
  {
    id: "bitcoin",
    name: "Bitcoin (SHA-256)",
    algorithm: "SHA-256 (Double)",
    blockTime: "~10 min",
    color: "#F7931A",
    params: {
      ghd_learning_rate: 0.015, ghd_momentum: 0.92, ghd_step_size: 2500000,
      bnp_prior_strength: 0.7, bnp_update_interval: 100, bnp_window_size: 5000,
      ghe_population: 256, ghe_mutation_rate: 0.08, ghe_crossover_rate: 0.65, ghe_generations: 50,
      ewd_wavelet_depth: 6, ewd_entropy_type: "shannon", ewd_sensitivity: 0.85,
      tas_initial_temp: 1.0, tas_cooling_rate: 0.003, tas_min_temp: 0.001,
      nca_momentum: 0.84, nca_range: 2100000, hfre_sensitivity: 0.75, bin_threshold: 37,
      cca_window_size: 512, cca_overlap_threshold: 0.015, cca_chains_active: 6, dca_round_depth: 31, dca_bias_sensitivity: 0.003, dca_sample_rate: 1000,
    }
  },
  {
    id: "ethereum_classic",
    name: "Ethereum Classic (Etchash)",
    algorithm: "Ethash/Etchash (Memory-Hard)",
    blockTime: "~13 sec",
    color: "#3AB83A",
    params: {
      ghd_learning_rate: 0.025, ghd_momentum: 0.88, ghd_step_size: 500000,
      bnp_prior_strength: 0.6, bnp_update_interval: 50, bnp_window_size: 2000,
      ghe_population: 128, ghe_mutation_rate: 0.12, ghe_crossover_rate: 0.70, ghe_generations: 30,
      ewd_wavelet_depth: 4, ewd_entropy_type: "renyi", ewd_sensitivity: 0.90,
      tas_initial_temp: 0.8, tas_cooling_rate: 0.005, tas_min_temp: 0.01,
      nca_momentum: 0.78, nca_range: 500000, hfre_sensitivity: 0.82, bin_threshold: 45,
      cca_window_size: 256, cca_overlap_threshold: 0.020, cca_chains_active: 4, dca_round_depth: 24, dca_bias_sensitivity: 0.005, dca_sample_rate: 800,
    }
  },
  {
    id: "dogecoin",
    name: "Dogecoin (Scrypt)",
    algorithm: "Scrypt (Memory-Hard)",
    blockTime: "~1 min",
    color: "#C2A633",
    params: {
      ghd_learning_rate: 0.020, ghd_momentum: 0.90, ghd_step_size: 1000000,
      bnp_prior_strength: 0.65, bnp_update_interval: 75, bnp_window_size: 3000,
      ghe_population: 192, ghe_mutation_rate: 0.10, ghe_crossover_rate: 0.68, ghe_generations: 40,
      ewd_wavelet_depth: 5, ewd_entropy_type: "tsallis", ewd_sensitivity: 0.88,
      tas_initial_temp: 0.9, tas_cooling_rate: 0.004, tas_min_temp: 0.005,
      nca_momentum: 0.81, nca_range: 1500000, hfre_sensitivity: 0.79, bin_threshold: 41,
      cca_window_size: 384, cca_overlap_threshold: 0.018, cca_chains_active: 5, dca_round_depth: 28, dca_bias_sensitivity: 0.004, dca_sample_rate: 900,
    }
  },
  {
    id: "litecoin",
    name: "Litecoin (Scrypt)",
    algorithm: "Scrypt (Memory-Hard)",
    blockTime: "~2.5 min",
    color: "#345D9D",
    params: {
      ghd_learning_rate: 0.018, ghd_momentum: 0.91, ghd_step_size: 1800000,
      bnp_prior_strength: 0.68, bnp_update_interval: 80, bnp_window_size: 4000,
      ghe_population: 224, ghe_mutation_rate: 0.09, ghe_crossover_rate: 0.66, ghe_generations: 45,
      ewd_wavelet_depth: 5, ewd_entropy_type: "shannon", ewd_sensitivity: 0.86,
      tas_initial_temp: 0.95, tas_cooling_rate: 0.0035, tas_min_temp: 0.003,
      nca_momentum: 0.82, nca_range: 1800000, hfre_sensitivity: 0.77, bin_threshold: 39,
      cca_window_size: 384, cca_overlap_threshold: 0.016, cca_chains_active: 5, dca_round_depth: 28, dca_bias_sensitivity: 0.004, dca_sample_rate: 950,
    }
  },
  {
    id: "kaspa",
    name: "Kaspa (kHeavyHash)",
    algorithm: "kHeavyHash (Matrix-Based)",
    blockTime: "~1 sec",
    color: "#70C7BA",
    params: {
      ghd_learning_rate: 0.035, ghd_momentum: 0.85, ghd_step_size: 100000,
      bnp_prior_strength: 0.5, bnp_update_interval: 25, bnp_window_size: 1000,
      ghe_population: 64, ghe_mutation_rate: 0.15, ghe_crossover_rate: 0.75, ghe_generations: 20,
      ewd_wavelet_depth: 3, ewd_entropy_type: "renyi", ewd_sensitivity: 0.92,
      tas_initial_temp: 0.6, tas_cooling_rate: 0.008, tas_min_temp: 0.02,
      nca_momentum: 0.72, nca_range: 200000, hfre_sensitivity: 0.88, bin_threshold: 52,
      cca_window_size: 128, cca_overlap_threshold: 0.025, cca_chains_active: 3, dca_round_depth: 16, dca_bias_sensitivity: 0.006, dca_sample_rate: 500,
    }
  },
  {
    id: "monero",
    name: "Monero (RandomX)",
    algorithm: "RandomX (CPU-Optimized)",
    blockTime: "~2 min",
    color: "#FF6600",
    params: {
      ghd_learning_rate: 0.022, ghd_momentum: 0.89, ghd_step_size: 800000,
      bnp_prior_strength: 0.62, bnp_update_interval: 60, bnp_window_size: 2500,
      ghe_population: 160, ghe_mutation_rate: 0.11, ghe_crossover_rate: 0.69, ghe_generations: 35,
      ewd_wavelet_depth: 4, ewd_entropy_type: "tsallis", ewd_sensitivity: 0.87,
      tas_initial_temp: 0.85, tas_cooling_rate: 0.0045, tas_min_temp: 0.008,
      nca_momentum: 0.80, nca_range: 1200000, hfre_sensitivity: 0.80, bin_threshold: 43,
      cca_window_size: 320, cca_overlap_threshold: 0.018, cca_chains_active: 4, dca_round_depth: 24, dca_bias_sensitivity: 0.005, dca_sample_rate: 750,
    }
  },
];

const PHTM_ADJUSTABLE_PARAMS = [
  { id: "ghd_learning_rate", label: "GHD Learning Rate", min: 0.001, max: 0.1, step: 0.001, default: 0.015, unit: "", group: "GHD", tip: "Controls how aggressively gradient descent adjusts nonce search direction. Higher = faster convergence but may overshoot." },
  { id: "ghd_momentum", label: "GHD Momentum", min: 0.5, max: 0.99, step: 0.01, default: 0.92, unit: "", group: "GHD", tip: "Accumulates past gradient information. Higher = smoother search paths, lower = more responsive to new patterns." },
  { id: "ghd_step_size", label: "GHD Step Size", min: 10000, max: 10000000, step: 10000, default: 2500000, unit: "", group: "GHD", tip: "Distance to jump between nonce evaluations. Larger steps explore more broadly." },
  { id: "bnp_prior_strength", label: "BNP Prior Strength", min: 0.1, max: 1.0, step: 0.05, default: 0.7, unit: "", group: "BNP", tip: "Weight of historical data in Bayesian prior. High = more reliance on past block solutions." },
  { id: "bnp_update_interval", label: "BNP Update Interval", min: 10, max: 500, step: 10, default: 100, unit: "hashes", group: "BNP", tip: "How often the Bayesian posterior is recalculated. Lower = more adaptive but more CPU overhead." },
  { id: "bnp_window_size", label: "BNP Window Size", min: 500, max: 20000, step: 500, default: 5000, unit: "samples", group: "BNP", tip: "Number of recent hash outputs used for Bayesian inference. Larger = more data but slower adaptation." },
  { id: "ghe_population", label: "GHE Population Size", min: 16, max: 512, step: 16, default: 256, unit: "candidates", group: "GHE", tip: "Number of nonce candidates in each genetic generation. Larger = more diverse search." },
  { id: "ghe_mutation_rate", label: "GHE Mutation Rate", min: 0.01, max: 0.3, step: 0.01, default: 0.08, unit: "", group: "GHE", tip: "Probability of random nonce mutations. Higher = more exploration, lower = more exploitation." },
  { id: "ghe_crossover_rate", label: "GHE Crossover Rate", min: 0.3, max: 0.9, step: 0.05, default: 0.65, unit: "", group: "GHE", tip: "Probability of combining two parent nonce strategies. Controls how strategies are blended." },
  { id: "ghe_generations", label: "GHE Generations", min: 5, max: 200, step: 5, default: 50, unit: "gens", group: "GHE", tip: "Number of evolutionary generations per search cycle. More = better optimization but slower." },
  { id: "ewd_wavelet_depth", label: "EWD Wavelet Depth", min: 1, max: 10, step: 1, default: 6, unit: "levels", group: "EWD", tip: "Decomposition depth for wavelet analysis. Deeper = finer pattern detection." },
  { id: "ewd_sensitivity", label: "EWD Entropy Sensitivity", min: 0.5, max: 1.0, step: 0.05, default: 0.85, unit: "", group: "EWD", tip: "Threshold for entropy pattern detection. Higher = more selective, fewer false positives." },
  { id: "tas_initial_temp", label: "TAS Initial Temperature", min: 0.1, max: 2.0, step: 0.05, default: 1.0, unit: "K", group: "TAS", tip: "Starting temperature for simulated annealing. Higher = more random exploration initially." },
  { id: "tas_cooling_rate", label: "TAS Cooling Rate", min: 0.001, max: 0.02, step: 0.001, default: 0.003, unit: "/step", group: "TAS", tip: "How fast the temperature decreases. Slower = more thorough search but takes longer." },
  { id: "tas_min_temp", label: "TAS Minimum Temperature", min: 0.0001, max: 0.1, step: 0.0001, default: 0.001, unit: "K", group: "TAS", tip: "Temperature floor where annealing locks into best-found region." },
];

const TECH_ADJUSTABLE_PARAMS = [
  { id: "nca_momentum", label: "NCA Momentum Flow", min: 0.5, max: 1.0, step: 0.01, default: 0.84, unit: "", group: "NCA", tip: "Controls momentum accumulation in nonce search velocity tracking." },
  { id: "nca_range", label: "NCA Search Range", min: 100000, max: 10000000, step: 100000, default: 2100000, unit: "nonces", group: "NCA", tip: "Width of the nonce range window for convergence analysis." },
  { id: "hfre_sensitivity", label: "HFRE Flow Sensitivity", min: 0.5, max: 1.0, step: 0.01, default: 0.75, unit: "", group: "HFRE", tip: "Sensitivity threshold for detecting laminar vs turbulent hash flow states." },
  { id: "bin_threshold", label: "BIN Congestion Threshold", min: 10, max: 90, step: 1, default: 37, unit: "%", group: "BIN", tip: "Network congestion level that triggers block submission timing optimization." },
  { id: "cca_window_size", label: "CCA Window Size", min: 64, max: 4096, step: 64, default: 512, unit: "bits", group: "CCA", tip: "Width of the sliding correlation window in bits. Larger windows detect broader patterns but require more computation." },
  { id: "cca_overlap_threshold", label: "CCA Overlap Threshold", min: 0.001, max: 0.1, step: 0.001, default: 0.015, unit: "", group: "CCA", tip: "Minimum correlation coefficient to trigger a pattern match. Lower values detect weaker patterns." },
  { id: "cca_chains_active", label: "CCA Active Chains", min: 1, max: 6, step: 1, default: 6, unit: "chains", group: "CCA", tip: "Number of reference blockchains to cross-correlate against. More chains = broader analysis." },
  { id: "dca_round_depth", label: "DCA Round Depth", min: 8, max: 64, step: 4, default: 31, unit: "rounds", group: "DCA", tip: "Number of hash function rounds to analyze. Full SHA-256 uses 64 rounds." },
  { id: "dca_bias_sensitivity", label: "DCA Bias Sensitivity", min: 0.0001, max: 0.01, step: 0.0001, default: 0.003, unit: "σ", group: "DCA", tip: "Statistical deviation threshold for detecting intermediate state biases." },
  { id: "dca_sample_rate", label: "DCA Sample Rate", min: 100, max: 10000, step: 100, default: 1000, unit: "hashes", group: "DCA", tip: "Number of hash pairs sampled per differential analysis cycle." },
];

const ALL_SOLVING_TECHS = [NCA_TECHNOLOGY, HFRE_TECHNOLOGY, BIN_TECHNOLOGY, CCA_TECHNOLOGY, DCA_TECHNOLOGY, ABS_TECHNOLOGY];

const MANUAL_ADJUSTMENTS = [
  { id: "intensity", label: "Mining Intensity", min: 1, max: 100, default: 75, unit: "%" },
  { id: "nonceRange", label: "Nonce Range Start", min: 0, max: 4294967295, default: 0, unit: "" },
  { id: "difficulty", label: "Target Difficulty", min: 1, max: 100, default: 50, unit: "T" },
  { id: "threads", label: "CPU Threads", min: 1, max: 32, default: 8, unit: "" },
  { id: "refreshRate", label: "Signal Refresh Rate", min: 1, max: 60, default: 10, unit: "s" },
  { id: "latencyThreshold", label: "Latency Threshold", min: 10, max: 500, default: 100, unit: "ms" },
];

const MINER_FEATURES = [
  { icon: Cpu, title: "Real-time Hashrate", desc: "Monitor your mining power instantly" },
  { icon: Zap, title: "Daily Rewards", desc: "Track your earnings day by day" },
  { icon: BarChart3, title: "Analytics", desc: "Deep insights into your mining performance" },
  { icon: Shield, title: "Secure Connection", desc: "End-to-end encrypted wallet integration" },
];

const STATS = [
  { value: "24/7", label: "Uptime" },
  { value: "0.001%", label: "Pool Fee" },
  { value: "10+", label: "Coins" },
  { value: "< 1hr", label: "Payout" },
];

const SUPPORTED_SOFTWARE = [
  "CGMiner", "BFGMiner", "XMRig", "T-Rex", "lolMiner", "PhoenixMiner", 
  "TeamRedMiner", "NBMiner", "GMiner", "miniZ", "SRBMiner", "WildRig"
];

type PlatformType = 'android' | 'ios' | 'windows' | 'mac' | null;

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function AlphaTradingMiner() {
  const [isMobile, setIsMobile] = useState(false);
  const [platform, setPlatform] = useState<PlatformType>(null);
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformType>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isAppInstalled, setIsAppInstalled] = useState(false);
  
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [isConnected, setIsConnected] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanType, setScanType] = useState<'wifi' | 'usb' | null>(null);
  const [detectedMiner, setDetectedMiner] = useState<string | null>(null);
  const [connectionType, setConnectionType] = useState<'wifi' | 'usb' | 'manual' | null>(null);
  const [showManualConnect, setShowManualConnect] = useState(false);
  const [minerAddress, setMinerAddress] = useState("");
  const [minerPort, setMinerPort] = useState("4028");
  
  const [discoveredDevices, setDiscoveredDevices] = useState<DiscoveredDevice[]>([]);
  const [connectedDevice, setConnectedDevice] = useState<DiscoveredDevice | null>(null);
  const [currentStats, setCurrentStats] = useState<MinerStats | null>(null);
  const [firmwareUpdates, setFirmwareUpdates] = useState<FirmwareUpdate[]>([]);
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useState(true);
  const [lastRegistryCheck, setLastRegistryCheck] = useState<Date | null>(null);
  
  interface MinerSlot {
    id: string;
    name: string;
    device: DiscoveredDevice | null;
    stats: MinerStats | null;
    isConnected: boolean;
    isScanning: boolean;
    showDetails: boolean;
    color: string;
  }
  
  const SLOT_COLORS = ['#00FF88', '#00D4FF', '#FFD700', '#A855F7', '#FF6B6B', '#06B6D4', '#F97316', '#84CC16'];
  
  const createNewSlot = (index: number): MinerSlot => ({
    id: `slot-${Date.now()}-${index}`,
    name: `Miner ${index + 1}`,
    device: null,
    stats: null,
    isConnected: false,
    isScanning: false,
    showDetails: false,
    color: SLOT_COLORS[index % SLOT_COLORS.length]
  });
  
  const [minerSlots, setMinerSlots] = useState<MinerSlot[]>([createNewSlot(0)]);
  const [activeSlotId, setActiveSlotId] = useState<string | null>(null);
  const [showMultiMinerPanel, setShowMultiMinerPanel] = useState(false);
  const [showAdjustments, setShowAdjustments] = useState(false);
  const [adjustments, setAdjustments] = useState<MinerAdjustments>({
    intensity: 75,
    nonceRange: 0,
    difficulty: 50,
    threads: 8,
    refreshRate: 10,
    latencyThreshold: 100,
  });
  
  const [sbpeData, setSbpeData] = useState<{
    tda: { value: string; status: 'optimal' | 'good' | 'normal' };
    ecm: { value: string; status: 'optimal' | 'good' | 'normal' };
    nlo: { value: string; status: 'optimal' | 'good' | 'normal' };
    mpm: { value: string; status: 'optimal' | 'good' | 'normal' };
    phc: { value: string; status: 'optimal' | 'good' | 'normal' };
    acm: { value: string; status: 'bullish' | 'neutral' | 'bearish' };
    abs: { value: string; status: 'optimal' | 'good' | 'normal' };
  }>({
    tda: { value: "18.2T", status: "optimal" },
    ecm: { value: "87.3%", status: "good" },
    nlo: { value: "24ms", status: "optimal" },
    mpm: { value: "+12.4%", status: "good" },
    phc: { value: "0.0023%", status: "normal" },
    acm: { value: "BUY", status: "bullish" },
    abs: { value: "1,247", status: "optimal" },
  });

  const [solvingData, setSolvingData] = useState<Record<string, { value: string; status: string }>>({
    mfa: { value: "+0.84", status: "optimal" },
    diq: { value: "Clustered", status: "good" },
    rso: { value: "±2.1M", status: "optimal" },
    cvs: { value: "76.4", status: "good" },
    fsd: { value: "Laminar", status: "optimal" },
    rfd: { value: "847Hz", status: "good" },
    egm: { value: "Low", status: "optimal" },
    rwp: { value: "12s", status: "good" },
    nce: { value: "37%", status: "good" },
    msp: { value: "1,247", status: "normal" },
    orp: { value: "0.3%", status: "optimal" },
    dap: { value: "-1.2%", status: "good" },
    bco: { value: "0.0031%", status: "good" },
    swd: { value: "2,847", status: "normal" },
    rpa: { value: "14 detected", status: "good" },
    mcm: { value: "6 active", status: "optimal" },
    ddt: { value: "2^-47.3", status: "good" },
    bpa: { value: "31/64", status: "normal" },
    rrm: { value: "Active", status: "optimal" },
    isb: { value: "±0.003σ", status: "good" },
    hce: { value: "1,247", status: "optimal" },
    nda: { value: "23", status: "good" },
    dpm: { value: "-1.4%", status: "optimal" },
    bti: { value: "Active", status: "optimal" },
    epm: { value: "3.42σ", status: "good" },
    tpo: { value: "Optimized", status: "optimal" },
  });

  const [activeBridges, setActiveBridges] = useState<Record<string, boolean>>({
    bridge_alpha: false,
    bridge_omega: false,
    bridge_quantum: false,
    bridge_correlator: false,
    bridge_sentinel: false,
    bridge_cipher: false,
    bridge_spider: false,
    bridge_arachnid: false,
    bridge_ultimate: false,
  });

  const [bridgeScores, setBridgeScores] = useState<Record<string, { score: number; confidence: number; signal: string }>>({
    bridge_alpha: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_omega: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_quantum: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_correlator: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_sentinel: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_cipher: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_spider: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_arachnid: { score: 0, confidence: 0, signal: "Inactive" },
    bridge_ultimate: { score: 0, confidence: 0, signal: "Inactive" },
  });

  const [showCustomBridge, setShowCustomBridge] = useState(false);
  const [customBridgeTechs, setCustomBridgeTechs] = useState<string[]>([]);
  const [bridgeError, setBridgeError] = useState<string | null>(null);
  const [customBridgeActive, setCustomBridgeActive] = useState(false);
  const [customBridgeScore, setCustomBridgeScore] = useState<{ score: number; confidence: number; signal: string }>({ score: 0, confidence: 0, signal: "Inactive" });

  const [livePatternActive, setLivePatternActive] = useState(false);
  const [detectedPatterns, setDetectedPatterns] = useState<Array<{
    id: string;
    timestamp: Date;
    type: string;
    correlation: number;
    chain: string;
    blockRange: string;
    description: string;
    saved: boolean;
  }>>([]);
  const [patternMemory, setPatternMemory] = useState<Array<{
    id: string;
    timestamp: Date;
    type: string;
    correlation: number;
    chain: string;
    blockRange: string;
    description: string;
    usageCount: number;
  }>>([]);
  const [livePatternStats, setLivePatternStats] = useState({
    blocksAnalyzed: 0,
    correlationsRun: 0,
    patternsFound: 0,
    activeChains: 6,
  });

  const [showPHTM, setShowPHTM] = useState(false);
  const [phtmActive, setPhtmActive] = useState(false);
  const [selectedBlockchain, setSelectedBlockchain] = useState("bitcoin");
  const [phtmParams, setPhtmParams] = useState<Record<string, number | string>>(() => {
    const defaults: Record<string, number | string> = {};
    PHTM_ADJUSTABLE_PARAMS.forEach(p => { defaults[p.id] = p.default; });
    TECH_ADJUSTABLE_PARAMS.forEach(p => { defaults[p.id] = p.default; });
    return defaults;
  });
  const [phtmData, setPhtmData] = useState<Record<string, { value: string; status: string }>>({
    ghd: { value: "-0.47", status: "optimal" },
    bnp: { value: "0.73", status: "good" },
    ghe: { value: "84.2", status: "optimal" },
    ewd: { value: "3.7σ", status: "good" },
    tas: { value: "0.42K", status: "optimal" },
  });
  const [showTutorial, setShowTutorial] = useState(false);
  const [tutorialTab, setTutorialTab] = useState<'overview' | 'phtm' | 'nca' | 'hfre' | 'bin' | 'cca' | 'dca' | 'abs' | 'bridge' | 'params'>('overview');
  const [showAllParams, setShowAllParams] = useState(false);

  const [showSolvingTech, setShowSolvingTech] = useState(true);

  const [cmdCenterBridge, setCmdCenterBridge] = useState<{
    connected: boolean;
    age: number;
    lastUpdate: number;
    data: {
      timestamp: number;
      windowScore: number;
      signal: 'MINE' | 'HOLD' | 'WAIT';
      entropyDeviation: string;
      avgBitDist: string;
      chiSquared: string;
      avgLeadingZeros: string;
      anomalyCount: number;
      strongCorrs: number;
      blockCount: number;
      difficultyTrend: string;
      mod3Entropy: string;
      feedItems: Array<{ type: string; message: string; severity: string; timestamp: number }>;
    } | null;
  } | null>(null);
  const [cmdCenterPolling, setCmdCenterPolling] = useState(true);
  const [cmdCenterBridgeError, setCmdCenterBridgeError] = useState<'auth' | 'network' | 'expired' | null>(null);

  useEffect(() => {
    if (!cmdCenterPolling) return;
    const pollBridge = async () => {
      try {
        const res = await fetch('/api/mining-bridge/signals');
        if (res.status === 401 || res.status === 403) {
          setCmdCenterBridgeError('auth');
          setCmdCenterBridge(null);
          return;
        }
        if (!res.ok) {
          setCmdCenterBridgeError('network');
          return;
        }
        const data = await res.json();
        setCmdCenterBridgeError(null);
        if (data.stale) {
          setCmdCenterBridgeError('expired');
          setCmdCenterBridge(data);
        } else {
          setCmdCenterBridge(data);
        }
      } catch {
        setCmdCenterBridgeError('network');
      }
    };
    pollBridge();
    const interval = setInterval(pollBridge, 15000);
    return () => clearInterval(interval);
  }, [cmdCenterPolling]);

  const [qmgeMiningData, setQmgeMiningData] = useState<QMGEMiningPayload | null>(null);
  const [qmgeMiningStatus, setQmgeMiningStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [qmgeMiningSymbol, setQmgeMiningSymbol] = useState('BTCUSDT');
  const [signalPriority, setSignalPriority] = useState<SignalPriority>('balanced');
  const [autoApplyQMGE, setAutoApplyQMGE] = useState(true);
  const [showCoordinatorPanel, setShowCoordinatorPanel] = useState(true);

  useEffect(() => {
    if (qmgeMiningStatus === 'disconnected') return;
    const fetchMiningData = async () => {
      try {
        const res = await fetch(`/api/qmge/mining-data?symbol=${qmgeMiningSymbol}`);
        const data = await res.json();
        if (data.status === 'online') {
          setQmgeMiningData(data.payload);
          if (qmgeMiningStatus === 'connecting') setQmgeMiningStatus('connected');
        }
      } catch (e) { console.error('QMGE mining data fetch error:', e); }
    };
    fetchMiningData();
    const interval = setInterval(fetchMiningData, 10000);
    return () => clearInterval(interval);
  }, [qmgeMiningStatus, qmgeMiningSymbol]);

  const coordinatedCmd = useMemo(() => coordinateMiningSignals(
    adjustments,
    qmgeMiningData,
    isConnected,
    qmgeMiningStatus === 'connected',
    signalPriority
  ), [adjustments, qmgeMiningData, isConnected, qmgeMiningStatus, signalPriority]);

  const lastAppliedRef = useRef<string>('');
  useEffect(() => {
    if (!autoApplyQMGE || !coordinatedCmd.qmgeApplied || qmgeMiningStatus !== 'connected' || !isConnected) return;
    const key = JSON.stringify(coordinatedCmd.adjustments);
    if (key === lastAppliedRef.current) return;
    lastAppliedRef.current = key;
    setAdjustments(coordinatedCmd.adjustments);
  }, [coordinatedCmd, autoApplyQMGE, qmgeMiningStatus, isConnected]);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoInView, setVideoInView] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    const ua = navigator.userAgent;
    if (/Android/i.test(ua)) setPlatform('android');
    else if (/iPad|iPhone|iPod/.test(ua)) setPlatform('ios');
    else if (/Mac/i.test(ua)) setPlatform('mac');
    else if (/Win/i.test(ua)) setPlatform('windows');
    
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                         (window.navigator as any).standalone === true;
    setIsAppInstalled(isStandalone);

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  useEffect(() => {
    if (!isConnected) return;
    const interval = setInterval(() => {
      setSbpeData({
        tda: { 
          value: "0.0T", 
          status: "normal" 
        },
        ecm: { 
          value: "0.0%", 
          status: "normal" 
        },
        nlo: { 
          value: "0ms", 
          status: "normal" 
        },
        mpm: { 
          value: "+0.0%", 
          status: "normal" 
        },
        phc: { 
          value: "0.0000%", 
          status: "normal" 
        },
        acm: { 
          value: "HOLD", 
          status: "neutral" 
        },
      });

      setSolvingData({
        mfa: { value: "+0.00", status: "normal" },
        diq: { value: "---", status: "normal" },
        rso: { value: "±0.0M", status: "normal" },
        cvs: { value: "0.0", status: "normal" },
        fsd: { value: "---", status: "normal" },
        rfd: { value: "0Hz", status: "normal" },
        egm: { value: "---", status: "normal" },
        rwp: { value: "0s", status: "normal" },
        nce: { value: "0%", status: "normal" },
        msp: { value: "0", status: "normal" },
        orp: { value: "0.0%", status: "normal" },
        dap: { value: "+0.0%", status: "normal" },
        bco: { value: "0.0000%", status: "normal" },
        swd: { value: "0", status: "normal" },
        rpa: { value: "0 detected", status: "normal" },
        mcm: { value: "0 active", status: "normal" },
        ddt: { value: "2^-0.0", status: "normal" },
        bpa: { value: "0/64", status: "normal" },
        rrm: { value: "Inactive", status: "normal" },
        isb: { value: "±0.000σ", status: "normal" },
      });

      const activeKeys = Object.entries(activeBridges).filter(([, v]) => v).map(([k]) => k);
      if (activeKeys.length > 0) {
        const newScores: Record<string, { score: number; confidence: number; signal: string }> = { ...bridgeScores };
        activeKeys.forEach(key => {
          newScores[key] = { score: 0, confidence: 0, signal: "HOLD" };
        });
        setBridgeScores(newScores);
      }

      if (customBridgeActive && customBridgeTechs.length >= 2 && !bridgeError) {
        setCustomBridgeScore({ score: 0, confidence: 0, signal: "HOLD" });
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [isConnected, activeBridges, customBridgeActive, customBridgeTechs, bridgeError]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setVideoInView(entry.isIntersecting);
        if (entry.isIntersecting && videoRef.current) {
          videoRef.current.play().catch(() => {});
        } else if (videoRef.current) {
          videoRef.current.pause();
        }
      },
      { threshold: 0.3 }
    );
    if (videoRef.current) observer.observe(videoRef.current);
    return () => observer.disconnect();
  }, []);

  const handleInstallClick = async (targetPlatform: PlatformType) => {
    if (deferredPrompt && (targetPlatform === 'android' || targetPlatform === platform)) {
      try {
        await deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setIsAppInstalled(true);
        } else {
          setSelectedPlatform(targetPlatform);
          setShowInstallModal(true);
        }
        setDeferredPrompt(null);
      } catch {
        setSelectedPlatform(targetPlatform);
        setShowInstallModal(true);
      }
    } else {
      setSelectedPlatform(targetPlatform);
      setShowInstallModal(true);
    }
  };

  const scanForMiners = (type: 'wifi' | 'usb') => {
    setIsScanning(true);
    setScanType(type);
    
    const scanDuration = type === 'wifi' ? 4000 : 2500;
    
    setTimeout(async () => {
      try {
        const discovered = type === 'wifi' 
          ? await simulateNetworkScan() 
          : await simulateUSBScan();
        
        if (discovered.length > 0) {
          const device = discovered[0];
          const connected = await connectToDevice(device);
          setDiscoveredDevices(discovered);
          setConnectedDevice(connected);
          setDetectedMiner(`${connected.device.name} (${connected.device.hashrate})`);
          setConnectionType(type);
          setIsConnected(true);
          setCurrentStats(connected.stats || null);
          
          const updates = await checkFirmwareUpdates(discovered);
          setFirmwareUpdates(updates);
        }
      } catch (error) {
        console.error('Scan error:', error);
      }
      setIsScanning(false);
      setScanType(null);
    }, scanDuration);
  };

  const connectManually = () => {
    if (minerAddress) {
      setIsConnected(true);
      setDetectedMiner("Manual Connection");
      setConnectionType('manual');
      setShowManualConnect(false);
    }
  };

  const disconnect = useCallback(async () => {
    if (connectedDevice) {
      await disconnectDevice(connectedDevice);
    }
    setIsConnected(false);
    setDetectedMiner(null);
    setConnectionType(null);
    setConnectedDevice(null);
    setCurrentStats(null);
    setDiscoveredDevices([]);
  }, [connectedDevice]);

  const addMinerSlot = () => {
    if (minerSlots.length >= 8) return;
    const newSlot = createNewSlot(minerSlots.length);
    setMinerSlots(prev => [...prev, newSlot]);
  };

  const removeMinerSlot = (slotId: string) => {
    if (minerSlots.length <= 1) return;
    setMinerSlots(prev => prev.filter(s => s.id !== slotId));
    if (activeSlotId === slotId) {
      setActiveSlotId(null);
    }
  };

  const updateSlot = (slotId: string, updates: Partial<MinerSlot>) => {
    setMinerSlots(prev => prev.map(s => s.id === slotId ? { ...s, ...updates } : s));
  };

  const renameSlot = (slotId: string, newName: string) => {
    updateSlot(slotId, { name: newName });
  };

  const scanForSlot = async (slotId: string, type: 'wifi' | 'usb') => {
    updateSlot(slotId, { isScanning: true });
    
    const scanDuration = 3000;
    
    setTimeout(async () => {
      try {
        const discovered = type === 'wifi' 
          ? await simulateNetworkScan()
          : await simulateUSBScan();
        
        if (discovered.length > 0) {
          const device = discovered[0];
          const connected = await connectToDevice(device);
          updateSlot(slotId, {
            device: connected,
            stats: connected.stats || null,
            isConnected: true,
            isScanning: false
          });
        } else {
          updateSlot(slotId, { isScanning: false });
        }
      } catch (error) {
        console.error('Slot scan error:', error);
        updateSlot(slotId, { isScanning: false });
      }
    }, scanDuration);
  };

  const disconnectSlot = async (slotId: string) => {
    const slot = minerSlots.find(s => s.id === slotId);
    if (slot?.device) {
      await disconnectDevice(slot.device);
    }
    updateSlot(slotId, {
      device: null,
      stats: null,
      isConnected: false
    });
  };

  useEffect(() => {
    const intervals: NodeJS.Timeout[] = [];
    
    minerSlots.forEach(slot => {
      if (slot.isConnected && slot.device) {
        const interval = setInterval(async () => {
          try {
            const stats = await refreshDeviceStats(slot.device!);
            updateSlot(slot.id, { stats });
          } catch (error) {
            console.error(`Stats refresh failed for ${slot.name}:`, error);
          }
        }, 5000);
        intervals.push(interval);
      }
    });
    
    return () => intervals.forEach(i => clearInterval(i));
  }, [minerSlots.map(s => s.id + s.isConnected).join(',')]);

  useEffect(() => {
    const checkForUpdates = async () => {
      try {
        const registryUpdate = await checkRegistryUpdates();
        if (registryUpdate) {
          console.log('New registry version available:', registryUpdate.version);
        }
        setLastRegistryCheck(new Date());
      } catch (error) {
        console.error('Registry check failed:', error);
      }
    };
    
    checkForUpdates();
    const interval = setInterval(checkForUpdates, 86400000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!isConnected || !connectedDevice) return;
    
    const refreshStats = async () => {
      try {
        const stats = await refreshDeviceStats(connectedDevice);
        setCurrentStats(stats);
      } catch (error) {
        console.error('Stats refresh failed:', error);
      }
    };
    
    const interval = setInterval(refreshStats, 5000);
    return () => clearInterval(interval);
  }, [isConnected, connectedDevice]);

  useEffect(() => {
    if (!isConnected || !phtmActive) return;
    const phtmInterval = setInterval(() => {
      setPhtmData({
        ghd: { value: "0.00", status: "normal" },
        bnp: { value: "0.00", status: "normal" },
        ghe: { value: "0.0", status: "normal" },
        ewd: { value: "0.0σ", status: "normal" },
        tas: { value: "0.00K", status: "normal" },
      });
    }, 2000);
    return () => clearInterval(phtmInterval);
  }, [isConnected, phtmActive]);

  const applyBlockchainPreset = (presetId: string) => {
    setSelectedBlockchain(presetId);
    const preset = BLOCKCHAIN_PRESETS.find(b => b.id === presetId);
    if (preset) {
      setPhtmParams(prev => ({ ...prev, ...preset.params }));
    }
  };

  const checkBridgeCompatibility = (techs: string[]): string | null => {
    for (let i = 0; i < techs.length; i++) {
      for (let j = i + 1; j < techs.length; j++) {
        const tech1 = techs[i];
        const tech2 = techs[j];
        const compat = BRIDGE_COMPATIBILITY[tech1];
        if (compat) {
          const incomp = compat.incompatible.find(ic => ic.tech === tech2);
          if (incomp) return `⚠ BRIDGE ERROR: ${tech1}™ + ${tech2}™ cannot be bridged — ${incomp.reason}`;
        }
      }
    }
    if (techs.length < 2) return "Select at least 2 technologies to create a bridge";
    return null;
  };

  const toggleCustomBridgeTech = (tech: string) => {
    const newTechs = customBridgeTechs.includes(tech)
      ? customBridgeTechs.filter(t => t !== tech)
      : [...customBridgeTechs, tech];
    setCustomBridgeTechs(newTechs);
    setBridgeError(checkBridgeCompatibility(newTechs));
    if (customBridgeActive) setCustomBridgeActive(false);
  };

  const savePatternToMemory = (pattern: typeof detectedPatterns[0]) => {
    setDetectedPatterns(prev => prev.map(p => p.id === pattern.id ? { ...p, saved: true } : p));
    setPatternMemory(prev => [{
      id: pattern.id,
      timestamp: pattern.timestamp,
      type: pattern.type,
      correlation: pattern.correlation,
      chain: pattern.chain,
      blockRange: pattern.blockRange,
      description: pattern.description,
      usageCount: 0,
    }, ...prev]);
  };

  useEffect(() => {
    if (!isConnected || !livePatternActive) return;
    const patternInterval = setInterval(() => {
      setLivePatternStats(prev => ({
        blocksAnalyzed: prev.blocksAnalyzed,
        correlationsRun: prev.correlationsRun,
        patternsFound: prev.patternsFound,
        activeChains: prev.activeChains,
      }));
    }, 3000);
    return () => clearInterval(patternInterval);
  }, [isConnected, livePatternActive]);

  const downloadPDF = () => {
    const pdfContent = `
ALPHA UNLIMITED MINING COMPANION
Installation & Connection Guide
================================

SECTION 1: INSTALLING THE MINING COMPANION
------------------------------------------

Android:
1. Open this page in Chrome browser
2. Tap the menu (⋮) in the top right corner
3. Select "Install app" or "Add to Home screen"
4. Follow the prompts to complete installation

iOS (iPhone/iPad):
1. Open this page in Safari browser
2. Tap the Share button at the bottom of the screen
3. Scroll down and tap "Add to Home Screen"
4. Tap "Add" to confirm

Windows:
1. Open this page in Chrome or Edge browser
2. Look for the install icon in the address bar
3. Click "Install" when prompted
4. Or click menu (⋮) → Install Alpha Miner

Mac:
1. Open this page in Chrome browser
2. Click menu (⋮) → Install Alpha Miner
3. In Safari: Click File → Add to Dock

SECTION 2: CONNECTING TO YOUR SOLO MINER
----------------------------------------

Wi-Fi Connection (Network Miners):
1. Ensure your miner is connected to your local Wi-Fi network
2. Open Alpha Miner Companion app
3. Click "Scan Wi-Fi Miners" button (blue)
4. The app will scan your network for compatible miners
5. Once detected, connection establishes automatically
6. Best for: ASIC miners, dedicated mining rigs, remote miners

USB Connection (Direct Plug & Play):
1. Connect your USB miner directly to your device
2. Open Alpha Miner Companion app
3. Click "Scan USB Miners" button (green)
4. The app will detect USB-connected mining devices
5. Connection establishes automatically once detected
6. Best for: USB ASIC miners, USB block erupters, portable miners

SUPPORTED WI-FI/ETHERNET HARDWARE:
- Bitaxe NerdQaxe++ Hydro (4.8 TH/s) - Ethernet
- Bitaxe Gamma 601 (1.2 TH/s) - Ethernet
- Bitaxe Supra Hex 701 (4.2 TH/s) - Ethernet
- Bitaxe Ultra (500 GH/s) - Wi-Fi
- NerdMiner (78 KH/s) - Wi-Fi
- Lucky Miner LV06 (500 GH/s) - Wi-Fi
- Apollo BTC (3 TH/s) - Ethernet
- GekkoScience R909 (5.5 TH/s) - Ethernet

SUPPORTED USB HARDWARE:
- GekkoScience NewPac (130 GH/s)
- GekkoScience Compac F (300 GH/s)
- FutureBit Moonlander 2 (5 MH/s Scrypt)
- Bitmain U3 (63 GH/s)
- AntMiner U1 (1.6 GH/s)
- Block Erupter USB (336 MH/s)
- Red/Blue Fury (2.5 GH/s)
- Bi-Fury (5 GH/s)

Supported Mining Software:
- CGMiner, BFGMiner, XMRig, T-Rex, lolMiner
- PhoenixMiner, TeamRedMiner, NBMiner, GMiner
- miniZ, SRBMiner, WildRig

Manual Connection:
1. Open your mining software settings
2. Enable API access (usually port 4028)
3. Note your miner's IP address
4. In Alpha Miner Companion, click "Manual Connect"
5. Enter IP Address: [Your Miner IP]
6. Enter Port: 4028 (or your custom port)
7. Click "Connect"

SECTION 3: USING AUTO VS MANUAL MODE
------------------------------------

AUTO MODE (Recommended):
- SBPE technology automatically optimizes all settings
- ACM & QFRM analyze market conditions in real-time
- No user intervention required
- Optimal for 24/7 unattended mining

MANUAL MODE:
- Full control over all mining parameters
- Adjust mining intensity (1-100%)
- Set custom nonce ranges
- Configure target difficulty
- Set CPU thread count
- Adjust signal refresh rate
- Set latency thresholds

SECTION 4: SBPE TECHNOLOGY FEATURES
-----------------------------------

1. Temporal Difficulty Analysis (TDA™)
   - Monitors network difficulty fluctuations
   - Identifies optimal mining windows

2. Entropy Cascade Mapping (ECM™)
   - Analyzes winning block hash patterns
   - Optimizes nonce search ranges

3. Network Latency Optimizer (NLO™)
   - Minimizes block propagation time
   - Reduces orphan block risk

4. Mempool Profit Maximizer (MPM™)
   - Optimizes transaction selection
   - Maximizes fee collection

5. Probabilistic Hash Convergence (PHC™)
   - Estimates time-to-block
   - Provides probability scoring

6. ACM Mining Integration
   - Momentum-based timing optimization
   - Smart money flow analysis

TROUBLESHOOTING
---------------
- Miner not detected: Ensure API is enabled in miner settings
- Connection timeout: Check firewall settings
- Data not updating: Verify network connectivity

SUPPORT
-------
Visit: alphaunlimitedtrading.com/support
Email: support@alphaunlimited.com

© 2024-2026 Alpha Unlimited Trading. All Rights Reserved.
SBPE™, ACM™, and QFRM™ are protected under international copyright law.
`;

    const doc = new jsPDF();
    const lines = pdfContent.trim().split('\n');
    let y = 20;
    const lineHeight = 6;
    const pageHeight = 280;
    
    doc.setFontSize(10);
    
    lines.forEach((line) => {
      if (y > pageHeight) {
        doc.addPage();
        y = 20;
      }
      
      if (line.includes('===') || line.includes('---')) {
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
      } else if (line.startsWith('SECTION') || line.startsWith('ALPHA') || line.startsWith('TROUBLESHOOTING') || line.startsWith('SUPPORT')) {
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
      } else {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
      }
      
      doc.text(line, 15, y);
      y += lineHeight;
    });
    
    doc.save('Alpha-Miner-Installation-Guide.pdf');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return '#00FF88';
      case 'good': return '#00D4FF';
      case 'bullish': return '#00FF88';
      case 'neutral': return '#FFD700';
      default: return '#94A3B8';
    }
  };

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen" style={{ background: 'linear-gradient(180deg, #0A0F14 0%, #0D1117 50%, #0A0F14 100%)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-12 pb-24 md:pb-12">
          <div className="mb-6 sm:mb-8">
            <Link href="/alpha-trading">
              <span className="inline-flex items-center gap-2 text-[#94A3B8] hover:text-[#00FF88] active:text-[#00FF88] transition-colors cursor-pointer text-sm py-2">
                <ArrowLeft size={16} />
                Back to Home
              </span>
            </Link>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8 sm:mb-16"
          >
            <div className="flex justify-center mb-4 sm:mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-[#00FF88]/30 rounded-3xl blur-2xl" />
                <img 
                  src="/icons/miner-icon-192x192.png" 
                  alt="Alpha Miner" 
                  className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl shadow-lg shadow-[#00FF88]/20"
                />
              </div>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3 sm:mb-4">
              Alpha <span className="text-[#00FF88]">Miner</span> Companion
            </h1>
            <p className="text-[#94A3B8] text-base sm:text-lg max-w-2xl mx-auto px-2">
              Maximize your solo mining potential with SBPE™ technology powered by ACM™ and QFRM™. 
              Intelligent optimization for higher block solving probability.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-4 mb-8 sm:mb-12">
            {STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="bg-[#0D1117] border border-[#00FF88]/20 rounded-lg sm:rounded-xl p-2 sm:p-4 text-center"
              >
                <div className="text-lg sm:text-2xl font-bold text-[#00FF88] mb-0.5 sm:mb-1">{stat.value}</div>
                <div className="text-xs sm:text-sm text-[#94A3B8]">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-br from-[#00FF88]/10 via-[#00D4FF]/10 to-[#FFD700]/10" />
              <div className="absolute inset-0 border border-[#00FF88]/30 rounded-2xl sm:rounded-3xl" />
              
              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isConnected ? 'bg-[#00FF88]/20' : 'bg-gray-800'}`}>
                      {isConnected ? (
                        connectionType === 'usb' ? <Usb className="w-6 h-6 text-[#00FF88]" /> : <Wifi className="w-6 h-6 text-[#00FF88]" />
                      ) : <WifiOff className="w-6 h-6 text-gray-500" />}
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">Miner Connection</h2>
                      <p className="text-sm text-[#94A3B8]">
                        {isConnected ? (
                          <span className="flex items-center gap-2">
                            Connected to {detectedMiner}
                            <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                              connectionType === 'wifi' ? 'bg-[#00D4FF]/20 text-[#00D4FF]' :
                              connectionType === 'usb' ? 'bg-[#00FF88]/20 text-[#00FF88]' :
                              'bg-[#FFD700]/20 text-[#FFD700]'
                            }`}>
                              {connectionType === 'wifi' ? 'Wi-Fi' : connectionType === 'usb' ? 'USB' : 'Manual'}
                            </span>
                          </span>
                        ) : 'Not connected'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex bg-[#0D1117] rounded-lg p-1 border border-gray-800">
                      <button
                        onClick={() => setMode('auto')}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${
                          mode === 'auto' 
                            ? 'bg-[#00FF88] text-[#0A0F14]' 
                            : 'text-gray-400 hover:text-white'
                        }`}
                        data-testid="button-mode-auto"
                      >
                        <ToggleLeft size={16} /> Auto
                      </button>
                      <button
                        onClick={() => { setMode('manual'); setShowAdjustments(true); }}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${
                          mode === 'manual' 
                            ? 'bg-[#FFD700] text-[#0A0F14]' 
                            : 'text-gray-400 hover:text-white'
                        }`}
                        data-testid="button-mode-manual"
                      >
                        <ToggleRight size={16} /> Manual
                      </button>
                    </div>
                    
                    <button
                      onClick={() => setShowMultiMinerPanel(!showMultiMinerPanel)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 border ${
                        showMultiMinerPanel
                          ? 'bg-[#A855F7]/20 text-[#A855F7] border-[#A855F7]/50'
                          : 'bg-[#0D1117] text-gray-400 border-gray-700 hover:text-white hover:border-gray-500'
                      }`}
                      data-testid="button-multi-miner-toggle"
                    >
                      <Server size={16} />
                      Multi-Miner ({minerSlots.filter(s => s.isConnected).length}/{minerSlots.length})
                    </button>
                  </div>
                </div>

                <AnimatePresence>
                  {showMultiMinerPanel && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-6"
                    >
                      <div className="bg-[#0D1117] border border-[#A855F7]/30 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-white font-semibold flex items-center gap-2">
                            <Server size={18} className="text-[#A855F7]" />
                            Multi-Miner Management
                            <span className="text-xs bg-[#A855F7]/20 text-[#A855F7] px-2 py-1 rounded">
                              {minerSlots.filter(s => s.isConnected).length} Active
                            </span>
                          </h3>
                          <button
                            onClick={addMinerSlot}
                            disabled={minerSlots.length >= 8}
                            className="flex items-center gap-1 px-3 py-1 bg-[#A855F7]/20 text-[#A855F7] text-sm rounded-lg hover:bg-[#A855F7]/30 disabled:opacity-50 transition-all"
                            data-testid="button-add-miner-slot"
                          >
                            <span>+ Add Slot</span>
                          </button>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                          {minerSlots.map((slot, idx) => (
                            <div
                              key={slot.id}
                              className="bg-[#1A2632] border rounded-lg p-3 relative"
                              style={{ borderColor: slot.isConnected ? slot.color : '#374151' }}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <div 
                                    className="w-3 h-3 rounded-full"
                                    style={{ backgroundColor: slot.isConnected ? slot.color : '#6B7280' }}
                                  />
                                  <span className="text-white text-sm font-medium">{slot.name}</span>
                                </div>
                                {minerSlots.length > 1 && !slot.isConnected && (
                                  <button
                                    onClick={() => removeMinerSlot(slot.id)}
                                    className="text-gray-500 hover:text-red-400 transition-colors"
                                    data-testid={`button-remove-slot-${idx}`}
                                  >
                                    <X size={14} />
                                  </button>
                                )}
                              </div>
                              
                              {slot.isConnected && slot.device ? (
                                <div className="space-y-2">
                                  <p className="text-xs text-gray-400 truncate">
                                    {slot.device.device?.name || 'Connected'}
                                  </p>
                                  {slot.stats && (
                                    <div className="grid grid-cols-2 gap-1 text-xs">
                                      <div className="bg-black/30 rounded p-1 text-center">
                                        <p className="text-gray-500">Hash</p>
                                        <p style={{ color: slot.color }}>
                                          {formatHashrate(slot.stats.hashrate, slot.stats.hashrateUnit)}
                                        </p>
                                      </div>
                                      <div className="bg-black/30 rounded p-1 text-center">
                                        <p className="text-gray-500">Temp</p>
                                        <p className={slot.stats.temperature > 70 ? 'text-red-400' : 'text-white'}>
                                          {slot.stats.temperature.toFixed(0)}°C
                                        </p>
                                      </div>
                                    </div>
                                  )}
                                  <button
                                    onClick={() => disconnectSlot(slot.id)}
                                    className="w-full py-1 text-xs bg-red-500/20 text-red-400 rounded hover:bg-red-500/30 transition-all"
                                    data-testid={`button-disconnect-slot-${idx}`}
                                  >
                                    Disconnect
                                  </button>
                                </div>
                              ) : slot.isScanning ? (
                                <div className="flex items-center justify-center py-4">
                                  <RefreshCw size={20} className="animate-spin text-[#A855F7]" />
                                </div>
                              ) : (
                                <div className="space-y-2">
                                  <p className="text-xs text-gray-500 text-center py-2">Not connected</p>
                                  <div className="flex gap-1">
                                    <button
                                      onClick={() => scanForSlot(slot.id, 'wifi')}
                                      className="flex-1 py-1 text-xs bg-[#00D4FF]/20 text-[#00D4FF] rounded hover:bg-[#00D4FF]/30 transition-all flex items-center justify-center gap-1"
                                      data-testid={`button-scan-wifi-slot-${idx}`}
                                    >
                                      <Wifi size={10} /> Wi-Fi
                                    </button>
                                    <button
                                      onClick={() => scanForSlot(slot.id, 'usb')}
                                      className="flex-1 py-1 text-xs bg-[#00FF88]/20 text-[#00FF88] rounded hover:bg-[#00FF88]/30 transition-all flex items-center justify-center gap-1"
                                      data-testid={`button-scan-usb-slot-${idx}`}
                                    >
                                      <Usb size={10} /> USB
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                        
                        <p className="text-xs text-gray-500 mt-3 text-center">
                          Connect up to 8 miners independently • Each runs with its own SBPE optimization
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex flex-wrap gap-3 mb-6">
                  {!isConnected ? (
                    <>
                      <button
                        onClick={() => scanForMiners('wifi')}
                        disabled={isScanning}
                        className="flex items-center gap-2 px-4 py-2 bg-[#00D4FF] text-[#0A0F14] font-semibold rounded-lg hover:bg-[#00D4FF]/90 disabled:opacity-50 transition-all"
                        data-testid="button-scan-wifi"
                      >
                        {isScanning && scanType === 'wifi' ? <RefreshCw size={16} className="animate-spin" /> : <Wifi size={16} />}
                        {isScanning && scanType === 'wifi' ? 'Scanning Wi-Fi...' : 'Scan Wi-Fi Miners'}
                      </button>
                      <button
                        onClick={() => scanForMiners('usb')}
                        disabled={isScanning}
                        className="flex items-center gap-2 px-4 py-2 bg-[#00FF88] text-[#0A0F14] font-semibold rounded-lg hover:bg-[#00FF88]/90 disabled:opacity-50 transition-all"
                        data-testid="button-scan-usb"
                      >
                        {isScanning && scanType === 'usb' ? <RefreshCw size={16} className="animate-spin" /> : <Usb size={16} />}
                        {isScanning && scanType === 'usb' ? 'Scanning USB...' : 'Scan USB Miners'}
                      </button>
                      <button
                        onClick={() => setShowManualConnect(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-[#0D1117] text-white border border-[#FFD700]/30 rounded-lg hover:border-[#FFD700]/60 transition-all"
                        data-testid="button-manual-connect"
                      >
                        <Link2 size={16} /> Manual Connect
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-wrap gap-3">
                      <button
                        onClick={disconnect}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg hover:bg-red-500/30 transition-all"
                        data-testid="button-disconnect"
                      >
                        <Unlink size={16} /> Disconnect
                      </button>
                      <button
                        onClick={() => setShowDeviceDetails(!showDeviceDetails)}
                        className="flex items-center gap-2 px-4 py-2 bg-[#0D1117] text-white border border-gray-700 rounded-lg hover:border-[#00D4FF]/60 transition-all"
                        data-testid="button-device-details"
                      >
                        <Info size={16} /> {showDeviceDetails ? 'Hide' : 'Show'} Details
                      </button>
                    </div>
                  )}
                </div>

                {isConnected && connectedDevice && (
                  <AnimatePresence>
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mb-6"
                    >
                      {firmwareUpdates.length > 0 && (
                        <div className="mb-4 p-3 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-lg flex items-center gap-3">
                          <ArrowUpCircle className="text-[#FFD700] flex-shrink-0" size={20} />
                          <div className="flex-1">
                            <p className="text-sm text-[#FFD700] font-medium">Firmware Update Available</p>
                            <p className="text-xs text-gray-400">
                              {firmwareUpdates[0].deviceName}: v{firmwareUpdates[0].currentVersion} → v{firmwareUpdates[0].availableVersion}
                            </p>
                          </div>
                          <button className="px-3 py-1 bg-[#FFD700] text-[#0A0F14] text-xs font-semibold rounded hover:bg-[#FFD700]/90">
                            Update
                          </button>
                        </div>
                      )}

                      {currentStats && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Hashrate</p>
                            <p className="text-lg font-bold text-[#00FF88]">
                              {formatHashrate(currentStats.hashrate, currentStats.hashrateUnit)}
                            </p>
                          </div>
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Temperature</p>
                            <p className={`text-lg font-bold ${currentStats.temperature > 70 ? 'text-red-400' : currentStats.temperature > 55 ? 'text-[#FFD700]' : 'text-[#00D4FF]'}`}>
                              {currentStats.temperature.toFixed(1)}°C
                            </p>
                          </div>
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Uptime</p>
                            <p className="text-lg font-bold text-white">{formatUptime(currentStats.uptime)}</p>
                          </div>
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Accepted</p>
                            <p className="text-lg font-bold text-[#00FF88]">{currentStats.accepted.toLocaleString()}</p>
                          </div>
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Rejected</p>
                            <p className="text-lg font-bold text-red-400">{currentStats.rejected}</p>
                          </div>
                          <div className="bg-[#0D1117] border border-gray-800 rounded-lg p-3 text-center">
                            <p className="text-xs text-gray-500 mb-1">Efficiency</p>
                            <p className="text-lg font-bold text-[#A855F7]">{currentStats.efficiency.toFixed(1)} J/TH</p>
                          </div>
                        </div>
                      )}

                      {showDeviceDetails && connectedDevice.device && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="mt-4 p-4 bg-[#0D1117] border border-gray-800 rounded-xl"
                        >
                          <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <HardDrive size={16} /> Device Information
                          </h4>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-gray-500">Manufacturer</p>
                              <p className="text-white">{connectedDevice.device.manufacturer}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Model</p>
                              <p className="text-white">{connectedDevice.device.model}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Chips</p>
                              <p className="text-white">{connectedDevice.device.chips} × {connectedDevice.device.chipCount}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Protocol</p>
                              <p className="text-[#00D4FF]">{getProtocolConfig(connectedDevice.device.protocol).displayName}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Algorithm</p>
                              <p className="text-white">{connectedDevice.device.algorithm.toUpperCase()}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Firmware</p>
                              <p className="text-white">v{connectedDevice.firmwareVersion || connectedDevice.device.firmware.version}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Power</p>
                              <p className="text-white">{connectedDevice.device.power}W</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Interface</p>
                              <p className="text-white">{getConnectionTypeLabel(connectedDevice.device.interface)}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Connection</p>
                              <p className="text-[#00FF88]">{connectedDevice.ip || connectedDevice.usbPath}</p>
                            </div>
                          </div>
                          <div className="mt-4 pt-3 border-t border-gray-800">
                            <p className="text-gray-500 text-xs mb-2">Features</p>
                            <div className="flex flex-wrap gap-2">
                              {connectedDevice.device.features.map((feature) => (
                                <span key={feature} className="px-2 py-1 bg-[#00D4FF]/10 text-[#00D4FF] text-xs rounded">
                                  {feature}
                                </span>
                              ))}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </motion.div>
                  </AnimatePresence>
                )}

                <AnimatePresence>
                  {showManualConnect && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-6 p-4 bg-[#0D1117] border border-gray-800 rounded-xl"
                    >
                      <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                        <Settings size={16} /> Manual Connection
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">IP Address</label>
                          <input
                            type="text"
                            value={minerAddress}
                            onChange={(e) => setMinerAddress(e.target.value)}
                            placeholder="192.168.1.100"
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                            data-testid="input-miner-ip"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Port</label>
                          <input
                            type="text"
                            value={minerPort}
                            onChange={(e) => setMinerPort(e.target.value)}
                            placeholder="4028"
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
                            data-testid="input-miner-port"
                          />
                        </div>
                        <div className="flex items-end gap-2">
                          <button
                            onClick={connectManually}
                            className="flex-1 px-4 py-2 bg-[#00FF88] text-[#0A0F14] font-semibold rounded-lg hover:bg-[#00FF88]/90"
                            data-testid="button-connect-manual"
                          >
                            Connect
                          </button>
                          <button
                            onClick={() => setShowManualConnect(false)}
                            className="px-4 py-2 bg-gray-800 text-gray-400 rounded-lg hover:text-white"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {mode === 'manual' && showAdjustments && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-6"
                    >
                      <div className="p-4 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-xl">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-[#FFD700] font-semibold flex items-center gap-2">
                            <Sliders size={16} /> Manual Adjustments
                          </h3>
                          <button
                            onClick={() => setShowAdjustments(false)}
                            className="text-gray-400 hover:text-white"
                          >
                            <ChevronUp size={16} />
                          </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                          {MANUAL_ADJUSTMENTS.map((adj) => (
                            <div key={adj.id} className="bg-[#0D1117] p-3 rounded-lg">
                              <label className="text-xs text-gray-400 block mb-2">{adj.label}</label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="range"
                                  min={adj.min}
                                  max={adj.max}
                                  value={adjustments[adj.id as keyof MinerAdjustments]}
                                  onChange={(e) => setAdjustments({...adjustments, [adj.id]: Number(e.target.value)})}
                                  className="flex-1 accent-[#FFD700]"
                                  data-testid={`slider-${adj.id}`}
                                />
                                <span className="text-white text-sm font-medium w-16 text-right">
                                  {adjustments[adj.id as keyof MinerAdjustments]}{adj.unit}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {isConnected && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3"
                  >
                    {SBPE_TECHNOLOGY.features.map((feature) => (
                      <div
                        key={feature.id}
                        className="bg-[#0D1117] border border-gray-800 rounded-xl p-3 text-center"
                      >
                        <div 
                          className="w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2"
                          style={{ backgroundColor: `${feature.color}20` }}
                        >
                          <feature.icon className="w-4 h-4" style={{ color: feature.color }} />
                        </div>
                        <div className="text-xs text-gray-500 mb-1">{feature.shortTitle}</div>
                        <div 
                          className="text-sm font-bold"
                          style={{ color: getStatusColor(sbpeData[feature.id as keyof typeof sbpeData]?.status || 'normal') }}
                        >
                          {sbpeData[feature.id as keyof typeof sbpeData]?.value || feature.value}
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#00D4FF]/10 via-[#FFD700]/5 to-[#A855F7]/10" />
              <div className="absolute inset-0 border border-[#00D4FF]/30 rounded-2xl sm:rounded-3xl" />
              
              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col lg:flex-row gap-8">
                  <div className="lg:w-1/2">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00D4FF] via-[#FFD700] to-[#A855F7] flex items-center justify-center">
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-[#00D4FF] uppercase tracking-wider">Revolutionary Technology</span>
                        <h2 className="text-xl sm:text-2xl font-bold text-white">SBPE™ Mining Technology</h2>
                      </div>
                    </div>
                    
                    <p className="text-[#94A3B8] mb-6">
                      The <span className="text-[#FFD700] font-semibold">Stochastic Block Prediction Engine™</span> combines 
                      our proprietary <span className="text-[#00D4FF]">ACM™</span> and <span className="text-[#00FF88]">QFRM™</span> technologies 
                      specifically optimized for solo mining. This revolutionary system provides intelligent optimization signals 
                      to help your miner work smarter, not just harder.
                    </p>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {SBPE_TECHNOLOGY.features.slice(0, 4).map((feature) => (
                        <div
                          key={feature.id}
                          className="flex items-start gap-3 p-3 bg-[#0D1117]/60 rounded-lg border border-white/5"
                        >
                          <div 
                            className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                            style={{ backgroundColor: `${feature.color}20` }}
                          >
                            <feature.icon className="w-4 h-4" style={{ color: feature.color }} />
                          </div>
                          <div>
                            <div className="text-white text-sm font-medium">{feature.shortTitle}™</div>
                            <div className="text-gray-500 text-xs">{feature.desc.slice(0, 50)}...</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="lg:w-1/2">
                    <div className="relative aspect-video rounded-xl overflow-hidden border border-[#00D4FF]/30 shadow-lg shadow-[#00D4FF]/10">
                      <video
                        ref={videoRef}
                        className="w-full h-full object-cover"
                        muted
                        loop
                        playsInline
                        poster="/images/sbpe-poster.jpg"
                      >
                        <source src="" type="video/mp4" />
                      </video>
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F14] via-transparent to-transparent opacity-60" />
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center gap-2 text-white text-sm font-medium">
                          <Play size={16} className="text-[#00FF88]" />
                          SBPE™ Technology Overview
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#FFD700]/20 flex items-center justify-center">
                      <Shield className="w-5 h-5 text-[#FFD700]" />
                    </div>
                    <div>
                      <span className="text-[#FFD700] font-semibold text-sm">Protected by International Copyright Law</span>
                      <p className="text-[#94A3B8] text-xs">SBPE™, ACM™, and QFRM™ are exclusive proprietary technologies</p>
                    </div>
                  </div>
                  <Link href="/copyright">
                    <span className="text-[#00D4FF] hover:text-[#00D4FF]/80 text-xs font-medium flex items-center gap-1 cursor-pointer whitespace-nowrap">
                      View Protection Details <ExternalLink className="w-3 h-3" />
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#FF6B35]/10 via-[#7C3AED]/10 to-[#06B6D4]/10" />
              <div className="absolute inset-0 border border-[#F59E0B]/30 rounded-2xl sm:rounded-3xl" />
              
              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#FF6B35] via-[#7C3AED] to-[#06B6D4] flex items-center justify-center shadow-lg shadow-[#F59E0B]/20">
                      <Brain className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#F59E0B] uppercase tracking-wider">Exclusive Proprietary Systems</span>
                      <h2 className="text-xl sm:text-2xl font-bold text-white">AI-Powered Blockchain Solving Technologies™</h2>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowSolvingTech(!showSolvingTech)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30 rounded-lg hover:bg-[#F59E0B]/30 transition-all text-sm font-medium"
                    data-testid="button-toggle-solving-tech"
                  >
                    <ChevronUp size={16} className={`transition-transform ${showSolvingTech ? '' : 'rotate-180'}`} />
                    {showSolvingTech ? 'Collapse' : 'Expand'}
                  </button>
                </div>

                <p className="text-[#94A3B8] mb-8 max-w-4xl">
                  Six revolutionary blockchain-solving technologies adapted from our proprietary trading systems. 
                  Each technology applies proven market analysis methodologies to the fundamentally different challenge 
                  of cryptocurrency mining optimization, creating an entirely new category of mining intelligence.
                </p>

                <AnimatePresence>
                  {showSolvingTech && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                    >
                      {ALL_SOLVING_TECHS.map((tech, techIdx) => (
                        <div key={tech.shortName} className="mb-8">
                          <div className="flex items-center gap-3 mb-4">
                            <div 
                              className="w-10 h-10 rounded-lg flex items-center justify-center"
                              style={{ backgroundColor: `${tech.color}20` }}
                            >
                              <span className="text-sm font-bold" style={{ color: tech.color }}>{tech.shortName}</span>
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-white">{tech.name}</h3>
                              <p className="text-xs" style={{ color: tech.color }}>{tech.tagline}</p>
                            </div>
                          </div>
                          
                          <p className="text-sm text-[#94A3B8] mb-4 max-w-3xl">{tech.description}</p>
                          
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {tech.features.map((feature) => (
                              <div
                                key={feature.id}
                                className="bg-[#0D1117] border border-gray-800 rounded-xl p-4 hover:border-opacity-50 transition-all"
                                style={{ borderColor: isConnected ? `${feature.color}30` : undefined }}
                                data-testid={`card-solving-${feature.id}`}
                              >
                                <div 
                                  className="w-9 h-9 rounded-lg flex items-center justify-center mb-3"
                                  style={{ backgroundColor: `${feature.color}15` }}
                                >
                                  <feature.icon className="w-4 h-4" style={{ color: feature.color }} />
                                </div>
                                <div className="text-xs font-semibold mb-1" style={{ color: feature.color }}>{feature.shortTitle}™</div>
                                <div className="text-white text-sm font-medium mb-1">{feature.title}</div>
                                <p className="text-gray-500 text-xs mb-3 line-clamp-2">{feature.desc}</p>
                                
                                {isConnected && (
                                  <div className="pt-2 border-t border-gray-800">
                                    <div className="flex items-center justify-between">
                                      <span className="text-xs text-gray-500">{feature.metric}</span>
                                      <span 
                                        className="text-sm font-bold"
                                        style={{ color: getStatusColor(solvingData[feature.id]?.status || 'normal') }}
                                        data-testid={`value-solving-${feature.id}`}
                                      >
                                        {solvingData[feature.id]?.value || feature.value}
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>

                          {techIdx < ALL_SOLVING_TECHS.length - 1 && (
                            <div className="border-t border-gray-800/50 mt-8" />
                          )}
                        </div>
                      ))}

                      <div className="border-t border-[#F59E0B]/30 mt-6 pt-8">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#F59E0B] to-[#FBBF24] flex items-center justify-center">
                            <Layers className="w-5 h-5 text-[#0A0F14]" />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-white">{MINING_BRIDGE_FUSION.name}</h3>
                            <p className="text-xs text-[#F59E0B]">{MINING_BRIDGE_FUSION.tagline}</p>
                          </div>
                        </div>
                        
                        <p className="text-sm text-[#94A3B8] mb-6 max-w-3xl">{MINING_BRIDGE_FUSION.description}</p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {MINING_BRIDGE_FUSION.bridges.map((bridge) => (
                            <div
                              key={bridge.id}
                              className={`bg-[#0D1117] border rounded-xl p-4 transition-all ${
                                activeBridges[bridge.id] 
                                  ? 'border-[#F59E0B]/50 shadow-lg shadow-[#F59E0B]/10' 
                                  : 'border-gray-800 hover:border-gray-700'
                              }`}
                              data-testid={`card-bridge-${bridge.id}`}
                            >
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <div 
                                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                                    style={{ backgroundColor: `${bridge.color}20` }}
                                  >
                                    <GitBranch className="w-4 h-4" style={{ color: bridge.color }} />
                                  </div>
                                  <div>
                                    <h4 className="text-white text-sm font-semibold">{bridge.name}</h4>
                                    <div className="flex gap-1 mt-0.5">
                                      {bridge.techs.map(t => (
                                        <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-gray-400">{t}</span>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                                <button
                                  onClick={() => {
                                    if (!isConnected) return;
                                    setActiveBridges(prev => ({ ...prev, [bridge.id]: !prev[bridge.id] }));
                                  }}
                                  disabled={!isConnected}
                                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                                    activeBridges[bridge.id]
                                      ? 'bg-[#F59E0B] text-[#0A0F14]'
                                      : isConnected 
                                        ? 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                                        : 'bg-gray-900 text-gray-600 cursor-not-allowed'
                                  }`}
                                  data-testid={`button-bridge-${bridge.id}`}
                                >
                                  {activeBridges[bridge.id] ? 'Active' : 'Activate'}
                                </button>
                              </div>
                              
                              <p className="text-xs text-gray-500 mb-3">{bridge.desc}</p>
                              
                              {activeBridges[bridge.id] && isConnected && (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="grid grid-cols-3 gap-2 pt-3 border-t border-gray-800"
                                >
                                  <div className="text-center">
                                    <p className="text-[10px] text-gray-500">Score</p>
                                    <p className="text-sm font-bold text-[#F59E0B]" data-testid={`score-${bridge.id}`}>
                                      {bridgeScores[bridge.id]?.score || 0}
                                    </p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-[10px] text-gray-500">Confidence</p>
                                    <p className="text-sm font-bold text-[#00FF88]">
                                      {bridgeScores[bridge.id]?.confidence || 0}%
                                    </p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-[10px] text-gray-500">Signal</p>
                                    <p className="text-sm font-bold text-[#00D4FF]">
                                      {bridgeScores[bridge.id]?.signal || "—"}
                                    </p>
                                  </div>
                                </motion.div>
                              )}
                            </div>
                          ))}
                        </div>

                        {!isConnected && (
                          <div className="mt-4 p-3 bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-lg text-center">
                            <p className="text-sm text-[#F59E0B]">Connect a miner to activate real-time solving technology metrics and bridge fusion</p>
                          </div>
                        )}

                        <div className="border-t border-gray-800/50 mt-6 pt-6">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-2">
                              <Layers className="w-5 h-5 text-[#F59E0B]" />
                              <h4 className="text-white font-semibold">Custom Bridge Builder™</h4>
                            </div>
                            <button
                              onClick={() => setShowCustomBridge(!showCustomBridge)}
                              className="text-xs text-[#F59E0B] hover:text-[#FBBF24] transition-colors"
                              data-testid="button-toggle-custom-bridge"
                            >
                              {showCustomBridge ? 'Hide' : 'Build Custom Bridge'}
                            </button>
                          </div>

                          <AnimatePresence>
                            {showCustomBridge && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                              >
                                <p className="text-xs text-[#94A3B8] mb-4">Select 2-8 technologies to bridge together. Some combinations are incompatible due to conflicting signal processing methods.</p>

                                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-4">
                                  {ALL_MINING_TECHS.map(tech => {
                                    const isSelected = customBridgeTechs.includes(tech);
                                    const techColors: Record<string, string> = { NCA: "#FF6B35", HFRE: "#7C3AED", BIN: "#06B6D4", SBPE: "#00D4FF", CCA: "#10B981", DCA: "#F97316" };
                                    return (
                                      <button
                                        key={tech}
                                        onClick={() => toggleCustomBridgeTech(tech)}
                                        disabled={!isConnected}
                                        className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all border ${
                                          isSelected
                                            ? 'text-white shadow-md'
                                            : isConnected
                                              ? 'bg-transparent text-gray-400 border-gray-700 hover:border-gray-500'
                                              : 'bg-gray-900 text-gray-600 cursor-not-allowed border-gray-800'
                                        }`}
                                        style={isSelected ? { backgroundColor: `${techColors[tech]}30`, borderColor: `${techColors[tech]}60`, color: techColors[tech] } : undefined}
                                        data-testid={`button-custom-bridge-${tech.toLowerCase()}`}
                                      >
                                        {tech}™
                                      </button>
                                    );
                                  })}
                                </div>

                                {bridgeError && (
                                  <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg mb-4"
                                  >
                                    <div className="flex items-start gap-2">
                                      <AlertCircle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
                                      <p className="text-xs text-red-400" data-testid="text-bridge-error">{bridgeError}</p>
                                    </div>
                                  </motion.div>
                                )}

                                {customBridgeTechs.length >= 2 && !bridgeError && (
                                  <div className="bg-[#0D1117] border border-[#F59E0B]/30 rounded-xl p-4">
                                    <div className="flex items-center justify-between mb-3">
                                      <div>
                                        <h5 className="text-white text-sm font-semibold">Custom Bridge ({customBridgeTechs.length}-way fusion)</h5>
                                        <div className="flex gap-1 mt-1">
                                          {customBridgeTechs.map(t => (
                                            <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-gray-400">{t}</span>
                                          ))}
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => {
                                          if (!isConnected || bridgeError) return;
                                          setCustomBridgeActive(!customBridgeActive);
                                        }}
                                        disabled={!isConnected}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                                          customBridgeActive
                                            ? 'bg-[#F59E0B] text-[#0A0F14]'
                                            : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                                        }`}
                                        data-testid="button-activate-custom-bridge"
                                      >
                                        {customBridgeActive ? 'Active' : 'Activate'}
                                      </button>
                                    </div>

                                    {customBridgeActive && isConnected && (
                                      <motion.div
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        className="grid grid-cols-3 gap-2 pt-3 border-t border-gray-800"
                                      >
                                        <div className="text-center">
                                          <p className="text-[10px] text-gray-500">Score</p>
                                          <p className="text-sm font-bold text-[#F59E0B]" data-testid="value-custom-bridge-score">{customBridgeScore.score}</p>
                                        </div>
                                        <div className="text-center">
                                          <p className="text-[10px] text-gray-500">Confidence</p>
                                          <p className="text-sm font-bold text-[#00FF88]">{customBridgeScore.confidence}%</p>
                                        </div>
                                        <div className="text-center">
                                          <p className="text-[10px] text-gray-500">Signal</p>
                                          <p className="text-sm font-bold text-[#00D4FF]">{customBridgeScore.signal}</p>
                                        </div>
                                      </motion.div>
                                    )}
                                  </div>
                                )}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      </div>

                      <div className="mt-8 flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-xl">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-[#FFD700]/20 flex items-center justify-center">
                            <Shield className="w-5 h-5 text-[#FFD700]" />
                          </div>
                          <div>
                            <span className="text-[#FFD700] font-semibold text-sm">All Technologies Protected by International Copyright Law</span>
                            <p className="text-[#94A3B8] text-xs">NCA™, HFRE™, BIN™, CCA™, DCA™, Mining Bridge Fusion™, PHTM™, GHD™, BNP™, GHE™, EWD™, and TAS™ are exclusive proprietary technologies of Alpha Unlimited Trading Company</p>
                          </div>
                        </div>
                        <Link href="/copyright">
                          <span className="text-[#00D4FF] hover:text-[#00D4FF]/80 text-xs font-medium flex items-center gap-1 cursor-pointer whitespace-nowrap">
                            View Protection Details <ExternalLink className="w-3 h-3" />
                          </span>
                        </Link>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.37 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#E11D48]/10 via-[#F43F5E]/10 to-[#FB7185]/10" />
              <div className="absolute inset-0 border border-[#E11D48]/30 rounded-2xl sm:rounded-3xl" />
              
              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#E11D48] via-[#F43F5E] to-[#FB7185] flex items-center justify-center shadow-lg shadow-[#E11D48]/20">
                      <Atom className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#E11D48] uppercase tracking-wider">Next-Generation Proprietary System</span>
                      <h2 className="text-xl sm:text-2xl font-bold text-white" data-testid="text-phtm-title">{PHTM_TECHNOLOGY.name}</h2>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => { if (isConnected) setPhtmActive(!phtmActive); }}
                      disabled={!isConnected}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                        phtmActive ? 'bg-[#E11D48] text-white shadow-lg shadow-[#E11D48]/30' : isConnected ? 'bg-[#E11D48]/20 text-[#E11D48] border border-[#E11D48]/30 hover:bg-[#E11D48]/30' : 'bg-gray-900 text-gray-600 cursor-not-allowed'
                      }`}
                      data-testid="button-toggle-phtm"
                    >
                      {phtmActive ? 'Active' : 'Activate'}
                    </button>
                    <button
                      onClick={() => setShowPHTM(!showPHTM)}
                      className="flex items-center gap-2 px-4 py-2 bg-[#E11D48]/20 text-[#E11D48] border border-[#E11D48]/30 rounded-lg hover:bg-[#E11D48]/30 transition-all text-sm font-medium"
                      data-testid="button-toggle-phtm-details"
                    >
                      <ChevronUp size={16} className={`transition-transform ${showPHTM ? '' : 'rotate-180'}`} />
                      {showPHTM ? 'Collapse' : 'Expand'}
                    </button>
                  </div>
                </div>

                <p className="text-[#94A3B8] mb-4 max-w-4xl text-sm">{PHTM_TECHNOLOGY.description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {BLOCKCHAIN_PRESETS.map(bp => (
                    <button
                      key={bp.id}
                      onClick={() => applyBlockchainPreset(bp.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                        selectedBlockchain === bp.id
                          ? 'text-white shadow-md'
                          : 'bg-transparent text-gray-400 border-gray-700 hover:border-gray-500'
                      }`}
                      style={selectedBlockchain === bp.id ? { backgroundColor: `${bp.color}30`, borderColor: `${bp.color}60`, color: bp.color } : undefined}
                      data-testid={`button-preset-${bp.id}`}
                    >
                      {bp.name}
                    </button>
                  ))}
                </div>

                <AnimatePresence>
                  {showPHTM && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-8">
                        {PHTM_TECHNOLOGY.features.map((feature) => (
                          <div
                            key={feature.id}
                            className="bg-[#0D1117] border border-gray-800 rounded-xl p-4 hover:border-opacity-50 transition-all"
                            style={{ borderColor: phtmActive ? `${feature.color}30` : undefined }}
                            data-testid={`card-phtm-${feature.id}`}
                          >
                            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3" style={{ backgroundColor: `${feature.color}15` }}>
                              <feature.icon className="w-4 h-4" style={{ color: feature.color }} />
                            </div>
                            <div className="text-xs font-semibold mb-1" style={{ color: feature.color }}>{feature.shortTitle}™</div>
                            <div className="text-white text-sm font-medium mb-1">{feature.title}</div>
                            <p className="text-gray-500 text-xs mb-3 line-clamp-3">{feature.desc}</p>
                            {phtmActive && isConnected && (
                              <div className="pt-2 border-t border-gray-800">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs text-gray-500">{feature.metric}</span>
                                  <span className="text-sm font-bold" style={{ color: getStatusColor(phtmData[feature.id]?.status || 'normal') }} data-testid={`value-phtm-${feature.id}`}>
                                    {phtmData[feature.id]?.value || feature.value}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      <div className="mb-6 bg-[#14B8A6]/5 border border-[#14B8A6]/20 rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Bug className="w-5 h-5 text-[#14B8A6]" />
                          <h3 className="text-white font-semibold text-sm">Spider Intelligence → PHTM Integration</h3>
                        </div>
                        <p className="text-xs text-[#94A3B8] mb-3">The Autonomous Blockchain Spider™ feeds historical nonce distribution data and block timing intelligence into PHTM, enhancing Bayesian priors and gradient descent optimization with real blockchain data.</p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          <div className="bg-[#0D1117] rounded-lg p-3 text-center" data-testid="stat-spider-phtm-blocks">
                            <p className="text-[10px] text-gray-500 mb-1">Blocks Crawled</p>
                            <p className="text-sm font-bold text-[#14B8A6]">1,247</p>
                          </div>
                          <div className="bg-[#0D1117] rounded-lg p-3 text-center" data-testid="stat-spider-phtm-hotspots">
                            <p className="text-[10px] text-gray-500 mb-1">Nonce Hotspots</p>
                            <p className="text-sm font-bold text-[#2DD4BF]">23</p>
                          </div>
                          <div className="bg-[#0D1117] rounded-lg p-3 text-center" data-testid="stat-spider-phtm-entropy">
                            <p className="text-[10px] text-gray-500 mb-1">Entropy Deviation</p>
                            <p className="text-sm font-bold text-[#5EEAD4]">3.42σ</p>
                          </div>
                          <div className="bg-[#0D1117] rounded-lg p-3 text-center" data-testid="stat-spider-phtm-prediction">
                            <p className="text-[10px] text-gray-500 mb-1">Difficulty Δ</p>
                            <p className="text-sm font-bold text-[#0D9488]">-1.4%</p>
                          </div>
                        </div>
                      </div>

                      <div className="mb-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-white font-semibold flex items-center gap-2"><Sliders size={16} className="text-[#E11D48]" /> PHTM Adjustable Parameters</h3>
                          <button onClick={() => setShowAllParams(!showAllParams)} className="text-xs text-[#E11D48] hover:text-[#F43F5E] transition-colors" data-testid="button-toggle-all-params">
                            {showAllParams ? 'Show PHTM Only' : 'Show All Tech Params'}
                          </button>
                        </div>
                        
                        {(() => {
                          const params = showAllParams ? [...PHTM_ADJUSTABLE_PARAMS, ...TECH_ADJUSTABLE_PARAMS] : PHTM_ADJUSTABLE_PARAMS;
                          const groups = Array.from(new Set(params.map(p => p.group)));
                          return groups.map(group => (
                            <div key={group} className="mb-4">
                              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: group === 'GHD' ? '#E11D48' : group === 'BNP' ? '#F43F5E' : group === 'GHE' ? '#FB7185' : group === 'EWD' ? '#FDA4AF' : group === 'TAS' ? '#FF6B6B' : group === 'NCA' ? '#06B6D4' : group === 'HFRE' ? '#7C3AED' : group === 'CCA' ? '#10B981' : group === 'DCA' ? '#F97316' : '#FF6B35' }} />
                                {group}™ Parameters
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                {params.filter(p => p.group === group).map(param => (
                                  <div key={param.id} className="bg-[#0D1117] border border-gray-800 rounded-lg p-3" data-testid={`param-${param.id}`}>
                                    <div className="flex items-center justify-between mb-1">
                                      <label className="text-xs text-gray-300 font-medium">{param.label}</label>
                                      <div className="group relative">
                                        <Info size={12} className="text-gray-600 hover:text-gray-400 cursor-help" />
                                        <div className="absolute bottom-full right-0 mb-1 w-48 p-2 bg-[#1A2632] border border-gray-700 rounded-lg text-xs text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">{param.tip}</div>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <input
                                        type="range"
                                        min={param.min}
                                        max={param.max}
                                        step={param.step}
                                        value={phtmParams[param.id] ?? param.default}
                                        onChange={(e) => setPhtmParams(prev => ({ ...prev, [param.id]: parseFloat(e.target.value) }))}
                                        className="flex-1 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#E11D48]"
                                        data-testid={`slider-${param.id}`}
                                      />
                                      <span className="text-xs text-white font-mono w-16 text-right">{phtmParams[param.id] ?? param.default}{param.unit}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ));
                        })()}

                        <div className="mt-4 p-3 bg-[#E11D48]/10 border border-[#E11D48]/20 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Info size={14} className="text-[#E11D48]" />
                            <span className="text-xs text-[#E11D48] font-semibold">Recommended: Select a blockchain preset above to auto-load optimized parameter values for that algorithm.</span>
                          </div>
                          <p className="text-xs text-gray-400">Currently loaded: <strong className="text-white">{BLOCKCHAIN_PRESETS.find(b => b.id === selectedBlockchain)?.name}</strong> ({BLOCKCHAIN_PRESETS.find(b => b.id === selectedBlockchain)?.algorithm})</p>
                        </div>
                      </div>

                      {!isConnected && (
                        <div className="p-3 bg-[#E11D48]/10 border border-[#E11D48]/20 rounded-lg text-center">
                          <p className="text-sm text-[#E11D48]">Connect a miner to activate PHTM™ real-time terrain mapping and blockchain solving optimization</p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.34 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#14B8A6]/10 via-[#2DD4BF]/5 to-[#0D9488]/10" />
              <div className="absolute inset-0 border border-[#14B8A6]/30 rounded-2xl sm:rounded-3xl" />

              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#14B8A6] via-[#2DD4BF] to-[#0D9488] flex items-center justify-center shadow-lg shadow-[#14B8A6]/20">
                      <Bug className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#14B8A6] uppercase tracking-wider">Proprietary Blockchain Crawling Engine</span>
                      <h2 className="text-xl sm:text-2xl font-bold text-white" data-testid="text-abs-title">{ABS_TECHNOLOGY.name}</h2>
                    </div>
                  </div>
                </div>

                <p className="text-[#94A3B8] mb-6 max-w-4xl text-sm">{ABS_TECHNOLOGY.description}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                  {ABS_TECHNOLOGY.features.map((feature) => (
                    <div
                      key={feature.id}
                      className="bg-[#0D1117] border border-gray-800 rounded-xl p-4 hover:border-[#14B8A6]/30 transition-all"
                      data-testid={`card-abs-${feature.id}`}
                    >
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3" style={{ backgroundColor: `${feature.color}15` }}>
                        <feature.icon className="w-4 h-4" style={{ color: feature.color }} />
                      </div>
                      <div className="text-xs font-semibold mb-1" style={{ color: feature.color }}>{feature.shortTitle}™</div>
                      <div className="text-white text-sm font-medium mb-1">{feature.title}</div>
                      <p className="text-gray-500 text-xs mb-3 line-clamp-3">{feature.desc}</p>
                      {isConnected && (
                        <div className="pt-2 border-t border-gray-800">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">{feature.metric}</span>
                            <span className="text-sm font-bold" style={{ color: getStatusColor(solvingData[feature.id]?.status || 'normal') }} data-testid={`value-abs-${feature.id}`}>
                              {solvingData[feature.id]?.value || feature.value}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="bg-[#0D1117] border border-[#14B8A6]/20 rounded-xl p-6">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Globe className="w-5 h-5 text-[#14B8A6]" />
                    Spider Intelligence Feed → Mining Technologies
                  </h3>
                  <p className="text-xs text-[#94A3B8] mb-4">The Autonomous Blockchain Spider™ feeds real-time historical intelligence directly into SBPE™ sub-technologies, enhancing their accuracy with data-driven insights from the actual blockchain.</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-[#14B8A6]/5 border border-[#14B8A6]/20 rounded-lg p-4" data-testid="card-spider-feed-tda">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-[#00D4FF]" />
                        <span className="text-sm font-semibold text-[#00D4FF]">TDA™</span>
                      </div>
                      <p className="text-xs text-gray-400 mb-2">Spider → Temporal Difficulty Analysis</p>
                      <p className="text-xs text-[#94A3B8]">Difficulty prediction model feeds predicted adjustments directly into TDA, enabling proactive difficulty-aware mining before network changes take effect.</p>
                      <div className="mt-2 flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-[#00FF88] animate-pulse" />
                        <span className="text-[10px] text-[#00FF88] font-medium">Live Feed Active</span>
                      </div>
                    </div>
                    <div className="bg-[#14B8A6]/5 border border-[#14B8A6]/20 rounded-lg p-4" data-testid="card-spider-feed-ecm">
                      <div className="flex items-center gap-2 mb-2">
                        <Hash className="w-4 h-4 text-[#FFD700]" />
                        <span className="text-sm font-semibold text-[#FFD700]">ECM™</span>
                      </div>
                      <p className="text-xs text-gray-400 mb-2">Spider → Entropy Cascade Mapping</p>
                      <p className="text-xs text-[#94A3B8]">Entropy pattern mapping provides Shannon entropy evolution data to ECM, enabling more accurate statistical distribution modeling of winning block hashes.</p>
                      <div className="mt-2 flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-[#00FF88] animate-pulse" />
                        <span className="text-[10px] text-[#00FF88] font-medium">Live Feed Active</span>
                      </div>
                    </div>
                    <div className="bg-[#14B8A6]/5 border border-[#14B8A6]/20 rounded-lg p-4" data-testid="card-spider-feed-nlo">
                      <div className="flex items-center gap-2 mb-2">
                        <Network className="w-4 h-4 text-[#00FF88]" />
                        <span className="text-sm font-semibold text-[#00FF88]">NLO™</span>
                      </div>
                      <p className="text-xs text-gray-400 mb-2">Spider → Network Latency Optimizer</p>
                      <p className="text-xs text-[#94A3B8]">Block timing intelligence analyzes inter-block timestamps to identify low-competition windows, feeding optimal submission timing data directly into NLO.</p>
                      <div className="mt-2 flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-[#00FF88] animate-pulse" />
                        <span className="text-[10px] text-[#00FF88] font-medium">Live Feed Active</span>
                      </div>
                    </div>
                  </div>
                </div>

                {!isConnected && (
                  <div className="mt-4 p-3 bg-[#14B8A6]/10 border border-[#14B8A6]/20 rounded-lg text-center">
                    <p className="text-sm text-[#14B8A6]">Connect a miner to see live Spider intelligence data and blockchain crawl statistics</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.38 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#10B981]/10 via-[#F97316]/10 to-[#10B981]/10" />
              <div className="absolute inset-0 border border-[#10B981]/30 rounded-2xl sm:rounded-3xl" />

              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#10B981] via-[#34D399] to-[#F97316] flex items-center justify-center shadow-lg shadow-[#10B981]/20">
                      <Signal className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#10B981] uppercase tracking-wider">Real-Time Intelligence</span>
                      <h2 className="text-xl sm:text-2xl font-bold text-white" data-testid="text-live-pattern-title">Live Pattern Detection™</h2>
                    </div>
                  </div>
                  <button
                    onClick={() => { if (isConnected) setLivePatternActive(!livePatternActive); }}
                    disabled={!isConnected}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      livePatternActive ? 'bg-[#10B981] text-white shadow-lg shadow-[#10B981]/30' : isConnected ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30 hover:bg-[#10B981]/30' : 'bg-gray-900 text-gray-600 cursor-not-allowed'
                    }`}
                    data-testid="button-toggle-live-pattern"
                  >
                    {livePatternActive ? '● Scanning Live' : 'Start Scanning'}
                  </button>
                </div>

                <p className="text-[#94A3B8] mb-6 text-sm max-w-4xl">
                  Continuously compares known blockchain cross-correlation signatures against live mining data in real-time.
                  When alignment patterns are detected, they are captured before the data is lost and saved to Pattern Memory
                  for use in future mining sessions across any blockchain.
                </p>

                {livePatternActive && isConnected && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                      <div className="bg-[#0D1117] border border-gray-800 rounded-xl p-3 text-center">
                        <p className="text-xs text-gray-500 mb-1">Blocks Analyzed</p>
                        <p className="text-lg font-bold text-[#10B981]" data-testid="value-blocks-analyzed">{livePatternStats.blocksAnalyzed.toLocaleString()}</p>
                      </div>
                      <div className="bg-[#0D1117] border border-gray-800 rounded-xl p-3 text-center">
                        <p className="text-xs text-gray-500 mb-1">Correlations Run</p>
                        <p className="text-lg font-bold text-[#34D399]" data-testid="value-correlations-run">{livePatternStats.correlationsRun.toLocaleString()}</p>
                      </div>
                      <div className="bg-[#0D1117] border border-gray-800 rounded-xl p-3 text-center">
                        <p className="text-xs text-gray-500 mb-1">Patterns Found</p>
                        <p className="text-lg font-bold text-[#F97316]" data-testid="value-patterns-found">{livePatternStats.patternsFound}</p>
                      </div>
                      <div className="bg-[#0D1117] border border-gray-800 rounded-xl p-3 text-center">
                        <p className="text-xs text-gray-500 mb-1">Active Chains</p>
                        <p className="text-lg font-bold text-[#00D4FF]">{livePatternStats.activeChains}</p>
                      </div>
                    </div>

                    {detectedPatterns.length > 0 && (
                      <div className="mb-6">
                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                          <Activity size={16} className="text-[#10B981]" />
                          Detected Patterns ({detectedPatterns.length})
                        </h4>
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {detectedPatterns.slice(0, 10).map(pattern => (
                            <div key={pattern.id} className={`bg-[#0D1117] border rounded-lg p-3 ${pattern.saved ? 'border-[#10B981]/40' : 'border-gray-800'}`} data-testid={`card-pattern-${pattern.id}`}>
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-semibold text-[#10B981]">{pattern.type}</span>
                                  {pattern.saved && <span className="text-[10px] px-1.5 py-0.5 bg-[#10B981]/20 text-[#10B981] rounded">Saved</span>}
                                </div>
                                {!pattern.saved && (
                                  <button
                                    onClick={() => savePatternToMemory(pattern)}
                                    className="px-2 py-1 bg-[#10B981]/20 text-[#10B981] text-[10px] font-semibold rounded hover:bg-[#10B981]/30 transition-all"
                                    data-testid={`button-save-pattern-${pattern.id}`}
                                  >
                                    Save to Memory
                                  </button>
                                )}
                              </div>
                              <div className="grid grid-cols-3 gap-2 text-xs">
                                <div>
                                  <span className="text-gray-500">Chain:</span>
                                  <span className="text-white ml-1">{pattern.chain}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Correlation:</span>
                                  <span className="text-[#F97316] ml-1">{pattern.correlation}%</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Blocks:</span>
                                  <span className="text-gray-300 ml-1">{pattern.blockRange}</span>
                                </div>
                              </div>
                              <p className="text-[10px] text-gray-500 mt-1">{pattern.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}

                {patternMemory.length > 0 && (
                  <div className="border-t border-gray-800/50 pt-6 mt-6">
                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <Database size={16} className="text-[#F97316]" />
                      Pattern Memory™ ({patternMemory.length} saved)
                    </h4>
                    <p className="text-xs text-[#94A3B8] mb-4">Saved patterns are automatically referenced during future mining sessions to guide nonce search optimization across all supported blockchains.</p>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {patternMemory.map(pm => (
                        <div key={pm.id} className="bg-[#0D1117] border border-[#F97316]/20 rounded-lg p-3" data-testid={`card-memory-${pm.id}`}>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-[#F97316]">{pm.type}</span>
                            <span className="text-[10px] text-gray-500">{pm.timestamp.toLocaleTimeString()}</span>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-xs mt-1">
                            <div><span className="text-gray-500">Chain:</span> <span className="text-white">{pm.chain}</span></div>
                            <div><span className="text-gray-500">Correlation:</span> <span className="text-[#10B981]">{pm.correlation}%</span></div>
                            <div><span className="text-gray-500">Applied:</span> <span className="text-gray-300">{pm.usageCount}x</span></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {!isConnected && (
                  <div className="p-3 bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg text-center">
                    <p className="text-sm text-[#10B981]">Connect a miner to activate Live Pattern Detection™ and start capturing real-time blockchain correlation data</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.39 }}
            className="mb-8 sm:mb-12"
          >
            <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6]/10 via-[#A78BFA]/10 to-[#C4B5FD]/10" />
              <div className="absolute inset-0 border border-[#8B5CF6]/30 rounded-2xl sm:rounded-3xl" />
              
              <div className="relative bg-[#0A0F14]/90 backdrop-blur-sm p-6 sm:p-10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#8B5CF6] to-[#A78BFA] flex items-center justify-center shadow-lg shadow-[#8B5CF6]/20">
                      <BookOpen className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#8B5CF6] uppercase tracking-wider">Learn & Master</span>
                      <h2 className="text-xl sm:text-2xl font-bold text-white" data-testid="text-tutorial-title">Technology Tutorial Center</h2>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowTutorial(!showTutorial)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#8B5CF6]/20 text-[#8B5CF6] border border-[#8B5CF6]/30 rounded-lg hover:bg-[#8B5CF6]/30 transition-all text-sm font-medium"
                    data-testid="button-toggle-tutorial"
                  >
                    <ChevronUp size={16} className={`transition-transform ${showTutorial ? '' : 'rotate-180'}`} />
                    {showTutorial ? 'Collapse' : 'Expand'}
                  </button>
                </div>

                <p className="text-[#94A3B8] mb-4 text-sm">Learn how each proprietary blockchain solving technology works, understand the science behind them, and master the adjustable parameters to optimize your mining performance.</p>

                <AnimatePresence>
                  {showTutorial && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                      <div className="flex flex-wrap gap-2 mb-6">
                        {[
                          { id: 'overview' as const, label: 'Overview', color: '#8B5CF6' },
                          { id: 'phtm' as const, label: 'PHTM™', color: '#E11D48' },
                          { id: 'nca' as const, label: 'NCA™', color: '#06B6D4' },
                          { id: 'hfre' as const, label: 'HFRE™', color: '#7C3AED' },
                          { id: 'bin' as const, label: 'BIN™', color: '#FF6B35' },
                          { id: 'cca' as const, label: 'CCA™', color: '#10B981' },
                          { id: 'dca' as const, label: 'DCA™', color: '#F97316' },
                          { id: 'bridge' as const, label: 'Bridge Fusion™', color: '#F59E0B' },
                          { id: 'params' as const, label: 'Parameter Guide', color: '#00FF88' },
                        ].map(tab => (
                          <button
                            key={tab.id}
                            onClick={() => setTutorialTab(tab.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                              tutorialTab === tab.id ? 'text-white shadow-md' : 'bg-transparent text-gray-400 border-gray-700 hover:border-gray-500'
                            }`}
                            style={tutorialTab === tab.id ? { backgroundColor: `${tab.color}30`, borderColor: `${tab.color}60`, color: tab.color } : undefined}
                            data-testid={`button-tutorial-${tab.id}`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>

                      <div className="bg-[#0D1117] border border-gray-800 rounded-xl p-6">
                        {tutorialTab === 'overview' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#8B5CF6]">What Are AI-Powered Blockchain Solving Technologies?</h3>
                            <p className="text-sm text-[#94A3B8]">Alpha Unlimited Trading has developed a suite of proprietary technologies that apply advanced mathematical optimization to cryptocurrency mining. Unlike traditional brute-force mining that blindly iterates through nonce values, our technologies analyze patterns, predict optimal search strategies, and adapt in real-time to maximize your probability of solving blocks.</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                              <div className="p-4 bg-[#E11D48]/10 border border-[#E11D48]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#E11D48] mb-2">PHTM™ — Probabilistic Hash Terrain Mapping</h4>
                                <p className="text-xs text-gray-400">Our newest and most advanced technology. Combines 5 sub-technologies: Gradient Hash Descent, Bayesian Nonce Prior, Genetic Hash Evolution, Entropy Wavelet Decomposition, and Thermal Annealing Search.</p>
                              </div>
                              <div className="p-4 bg-[#06B6D4]/10 border border-[#06B6D4]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#06B6D4] mb-2">NCA™ — Nonce Convergence Algorithm</h4>
                                <p className="text-xs text-gray-400">Optimizes nonce search velocity using momentum-based convergence analysis. Tracks search patterns across multiple hash evaluations.</p>
                              </div>
                              <div className="p-4 bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#7C3AED] mb-2">HFRE™ — Hash Flow Resonance Engine</h4>
                                <p className="text-xs text-gray-400">Analyzes the computational flow state of hash operations, detecting laminar vs turbulent patterns to optimize processing pipelines.</p>
                              </div>
                              <div className="p-4 bg-[#FF6B35]/10 border border-[#FF6B35]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#FF6B35] mb-2">BIN™ — Block Intelligence Network</h4>
                                <p className="text-xs text-gray-400">Monitors blockchain network state including congestion, miner activity, and block propagation to optimize submission timing.</p>
                              </div>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                              <div className="p-4 bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#10B981] mb-2">CCA™ — Cross-Correlation Analysis</h4>
                                <p className="text-xs text-gray-400">Performs sliding-window cross-correlation on successfully-mined blockchain data against live hash outputs to detect statistical resonance and alignment patterns.</p>
                              </div>
                              <div className="p-4 bg-[#F97316]/10 border border-[#F97316]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#F97316] mb-2">DCA™ — Differential Cryptanalysis</h4>
                                <p className="text-xs text-gray-400">Analyzes how small nonce changes propagate through hash function rounds, building differential distribution tables and tracking bit-level propagation patterns.</p>
                              </div>
                            </div>
                            <div className="p-4 bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-lg mt-4">
                              <h4 className="text-sm font-bold text-[#F59E0B] mb-2">Mining Bridge Fusion™ with Multi-Bridge Architecture™</h4>
                              <p className="text-xs text-gray-400">Combines multiple technologies into unified bridge signals. Choose from 7 bridge configurations (Alpha, Omega, Quantum, Correlator, Sentinel, Cipher, Ultimate) or build custom bridges with the Custom Bridge Builder™.</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'phtm' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#E11D48]">Probabilistic Hash Terrain Mapping™ (PHTM) — Deep Dive</h3>
                            <p className="text-sm text-[#94A3B8]">PHTM is a completely original technology that reimagines the mining problem as navigating a multi-dimensional terrain. Instead of random nonce iteration, PHTM treats the hash output space as a landscape where valleys represent valid hash values (below difficulty target). Five specialized navigation strategies work together to find these valleys efficiently.</p>
                            
                            <div className="space-y-3">
                              <div className="p-4 bg-[#E11D48]/10 border border-[#E11D48]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#E11D48] mb-1">1. Gradient Hash Descent™ (GHD)</h4>
                                <p className="text-xs text-gray-400 mb-2"><strong className="text-gray-300">What it does:</strong> Analyzes sequences of hash outputs to estimate "directional derivatives" in nonce space. When consecutive nonces produce progressively lower hash values, GHD detects this gradient and accelerates the search in that direction.</p>
                                <p className="text-xs text-gray-400"><strong className="text-gray-300">Key Parameters:</strong> Learning Rate (how fast it adjusts), Momentum (smoothing factor), Step Size (distance between evaluations).</p>
                              </div>
                              <div className="p-4 bg-[#F43F5E]/10 border border-[#F43F5E]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#F43F5E] mb-1">2. Bayesian Nonce Prior™ (BNP)</h4>
                                <p className="text-xs text-gray-400 mb-2"><strong className="text-gray-300">What it does:</strong> Uses Bayesian inference to build probability distributions over nonce ranges. As hash results arrive, BNP updates its posterior distribution, concentrating search effort on the most promising nonce regions. Historical block solutions from the blockchain inform the prior.</p>
                                <p className="text-xs text-gray-400"><strong className="text-gray-300">Key Parameters:</strong> Prior Strength (weight of historical data), Update Interval (recalculation frequency), Window Size (data sample size).</p>
                              </div>
                              <div className="p-4 bg-[#FB7185]/10 border border-[#FB7185]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#FB7185] mb-1">3. Genetic Hash Evolution™ (GHE)</h4>
                                <p className="text-xs text-gray-400 mb-2"><strong className="text-gray-300">What it does:</strong> Maintains a "population" of nonce candidates that evolve over generations. Top-performing nonces (those producing lower hash values) are selected as parents. Crossover blends parent strategies, while mutation introduces randomness to avoid local optima.</p>
                                <p className="text-xs text-gray-400"><strong className="text-gray-300">Key Parameters:</strong> Population Size (number of candidates), Mutation Rate (randomness), Crossover Rate (blending), Generations (evolution depth).</p>
                              </div>
                              <div className="p-4 bg-[#FDA4AF]/10 border border-[#FDA4AF]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#FDA4AF] mb-1">4. Entropy Wavelet Decomposition™ (EWD)</h4>
                                <p className="text-xs text-gray-400 mb-2"><strong className="text-gray-300">What it does:</strong> Applies Shannon, Renyi, and Tsallis entropy measures to hash output sequences, then uses wavelet decomposition to analyze these entropy patterns across multiple scales. Identifies resonance frequencies that indicate potentially favorable nonce regions.</p>
                                <p className="text-xs text-gray-400"><strong className="text-gray-300">Key Parameters:</strong> Wavelet Depth (decomposition levels), Entropy Sensitivity (detection threshold).</p>
                              </div>
                              <div className="p-4 bg-[#FF6B6B]/10 border border-[#FF6B6B]/20 rounded-lg">
                                <h4 className="text-sm font-bold text-[#FF6B6B] mb-1">5. Thermal Annealing Search™ (TAS)</h4>
                                <p className="text-xs text-gray-400 mb-2"><strong className="text-gray-300">What it does:</strong> Uses simulated annealing to control the exploration vs exploitation tradeoff. At high "temperature" the search jumps broadly across nonce space (exploration). As temperature cools, the search focuses on the best regions found (exploitation). This prevents getting stuck in local optima.</p>
                                <p className="text-xs text-gray-400"><strong className="text-gray-300">Key Parameters:</strong> Initial Temperature (starting exploration level), Cooling Rate (how fast to focus), Minimum Temperature (exploitation floor).</p>
                              </div>
                            </div>

                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">How to Use PHTM</h4>
                              <ol className="text-xs text-gray-400 space-y-2">
                                <li className="flex items-start gap-2"><span className="bg-[#E11D48]/20 text-[#E11D48] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">1</span> Select your blockchain from the preset buttons (Bitcoin, Ethereum Classic, Dogecoin, etc.)</li>
                                <li className="flex items-start gap-2"><span className="bg-[#E11D48]/20 text-[#E11D48] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">2</span> This auto-loads optimized parameters for that algorithm. You can fine-tune individual values.</li>
                                <li className="flex items-start gap-2"><span className="bg-[#E11D48]/20 text-[#E11D48] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">3</span> Connect your miner and click "Activate" to enable PHTM real-time terrain mapping.</li>
                                <li className="flex items-start gap-2"><span className="bg-[#E11D48]/20 text-[#E11D48] rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">4</span> Monitor the five sub-technology metrics as they work together to optimize your nonce search.</li>
                              </ol>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'nca' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#06B6D4]">Nonce Convergence Algorithm™ (NCA) — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">NCA adapts momentum-based optimization from our ACM™ trading indicator to the mining domain. It tracks the "velocity" of your nonce search across multiple hash evaluations, using momentum accumulation to predict which nonce ranges are converging toward valid solutions.</p>
                            <div className="p-4 bg-[#06B6D4]/10 border border-[#06B6D4]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#06B6D4] mb-2">How NCA Works</h4>
                              <ul className="text-xs text-gray-400 space-y-1.5">
                                <li>Monitors Momentum Flow Accumulator (MFA) — tracks directional momentum in nonce search</li>
                                <li>Analyzes Distribution Intelligence Quotient (DIQ) — evaluates clustering patterns in hash outputs</li>
                                <li>Calculates Range Sensitivity Oscillator (RSO) — measures optimal nonce range boundaries</li>
                                <li>Generates Convergence Velocity Score (CVS) — predicts convergence speed toward valid hashes</li>
                              </ul>
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">NCA Parameters</h4>
                              <p className="text-xs text-gray-400"><strong className="text-gray-300">NCA Momentum Flow</strong> (0.5–1.0): Higher values give more weight to accumulated search history. Default 0.84 works well for SHA-256. Use 0.72–0.78 for faster blockchains like Kaspa.</p>
                              <p className="text-xs text-gray-400 mt-1"><strong className="text-gray-300">NCA Search Range</strong> (100K–10M): Width of the nonce window. Larger for slow-block chains (Bitcoin: 2.1M), smaller for fast chains (Kaspa: 200K).</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'hfre' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#7C3AED]">Hash Flow Resonance Engine™ (HFRE) — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">HFRE applies fluid dynamics concepts to hash computation analysis. It detects whether your hash computation pipeline is in a "laminar" (smooth, efficient) or "turbulent" (chaotic, suboptimal) state, then adjusts processing parameters to maintain optimal flow.</p>
                            <div className="p-4 bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#7C3AED] mb-2">HFRE Sub-Components</h4>
                              <ul className="text-xs text-gray-400 space-y-1.5">
                                <li>Flow State Detector (FSD) — classifies hash computation flow as laminar or turbulent</li>
                                <li>Resonance Frequency Detector (RFD) — identifies optimal hash throughput frequencies</li>
                                <li>Entropy Gradient Monitor (EGM) — tracks entropy levels across hash computation batches</li>
                                <li>Resonance Wave Predictor (RWP) — predicts timing of next resonance peak for optimal submission</li>
                              </ul>
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">HFRE Parameters</h4>
                              <p className="text-xs text-gray-400"><strong className="text-gray-300">HFRE Flow Sensitivity</strong> (0.5–1.0): Threshold for distinguishing laminar from turbulent states. Higher sensitivity detects subtler flow disruptions. Use 0.75 for SHA-256, 0.82–0.88 for memory-hard algorithms.</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'bin' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#FF6B35]">Block Intelligence Network™ (BIN) — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">BIN monitors the blockchain network itself — analyzing congestion levels, miner selling pressure, hash rate fluctuations, and block propagation timing. This intelligence helps optimize when to submit blocks for maximum acceptance probability.</p>
                            <div className="p-4 bg-[#FF6B35]/10 border border-[#FF6B35]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#FF6B35] mb-2">BIN Sub-Components</h4>
                              <ul className="text-xs text-gray-400 space-y-1.5">
                                <li>Network Congestion Estimator (NCE) — real-time blockchain congestion percentage</li>
                                <li>Miner Selling Pressure (MSP) — monitors miner outflows from known miner wallets</li>
                                <li>Orphan Rate Predictor (ORP) — estimates block orphan probability based on network conditions</li>
                                <li>Difficulty Adjustment Predictor (DAP) — forecasts next difficulty adjustment magnitude</li>
                              </ul>
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">BIN Parameters</h4>
                              <p className="text-xs text-gray-400"><strong className="text-gray-300">BIN Congestion Threshold</strong> (10–90%): Network congestion level that triggers submission timing optimization. Lower threshold = more sensitive to congestion (triggers earlier). Bitcoin: 37%, Kaspa: 52% (faster blocks need higher threshold).</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'cca' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#10B981]">Cross-Correlation Analysis™ (CCA) — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">CCA introduces a completely new approach to mining optimization by analyzing patterns across successfully-mined blockchain data. It converts solved block headers into binary sequences, then uses sliding-window cross-correlation to detect alignment patterns between historical solutions and live mining data.</p>
                            <div className="p-4 bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#10B981] mb-2">How CCA Works</h4>
                              <ul className="text-xs text-gray-400 space-y-1.5">
                                <li>Binary Cross-Overlay (BCO) — converts block headers to binary and slides them across live hash data at every offset</li>
                                <li>Sliding Window Detector (SWD) — applies variable-width windows to find sub-patterns in multiple data formats</li>
                                <li>Residual Pattern Analyzer (RPA) — decomposes blocks into subsections and binary components looking for residual patterns</li>
                                <li>Multi-Chain Matcher (MCM) — cross-references patterns across 6 different blockchains for universal signatures</li>
                              </ul>
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">CCA Parameters</h4>
                              <p className="text-xs text-gray-400"><strong className="text-gray-300">Window Size</strong> (64–4096 bits): Width of the correlation window. Larger windows capture broader patterns but need more data.</p>
                              <p className="text-xs text-gray-400 mt-1"><strong className="text-gray-300">Overlap Threshold</strong> (0.001–0.1): Minimum correlation coefficient to flag a match. Lower = more sensitive.</p>
                              <p className="text-xs text-gray-400 mt-1"><strong className="text-gray-300">Active Chains</strong> (1–6): Number of reference blockchains for cross-correlation.</p>
                            </div>
                            <div className="p-4 bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#10B981] mb-2">Bridge Compatibility</h4>
                              <p className="text-xs text-gray-400"><span className="text-[#00FF88]">Compatible:</span> NCA™, BIN™, SBPE™, DCA™</p>
                              <p className="text-xs text-gray-400"><span className="text-red-400">Incompatible:</span> HFRE™ (overlapping signal processing creates destructive interference)</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'dca' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#F97316]">Differential Cryptanalysis™ (DCA) — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">DCA applies the principles of differential cryptanalysis — one of the most powerful techniques in theoretical cryptography — to mining optimization. It studies how small changes in nonce inputs affect hash outputs, looking for statistical biases in the propagation of differences through hash function rounds.</p>
                            <div className="p-4 bg-[#F97316]/10 border border-[#F97316]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#F97316] mb-2">How DCA Works</h4>
                              <ul className="text-xs text-gray-400 space-y-1.5">
                                <li>Differential Distribution Table (DDT) — maps how input differences transform into output differences through S-boxes</li>
                                <li>Bit Propagation Analyzer (BPA) — traces single-bit changes through all 64 SHA-256 compression rounds</li>
                                <li>Reduced-Round Modeler (RRM) — constructs truncated hash function models to find exploitable differential paths</li>
                                <li>Intermediate State Bias (ISB) — monitors internal hash states for non-uniform statistical distributions</li>
                              </ul>
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">DCA Parameters</h4>
                              <p className="text-xs text-gray-400"><strong className="text-gray-300">Round Depth</strong> (8–64): Number of hash rounds analyzed. 31 is the current best reduced-round attack depth for SHA-256.</p>
                              <p className="text-xs text-gray-400 mt-1"><strong className="text-gray-300">Bias Sensitivity</strong> (0.0001–0.01σ): How sensitive the detector is to statistical deviations.</p>
                              <p className="text-xs text-gray-400 mt-1"><strong className="text-gray-300">Sample Rate</strong> (100–10000): Hash pairs analyzed per differential cycle.</p>
                            </div>
                            <div className="p-4 bg-[#F97316]/10 border border-[#F97316]/20 rounded-lg">
                              <h4 className="text-sm font-bold text-[#F97316] mb-2">Bridge Compatibility</h4>
                              <p className="text-xs text-gray-400"><span className="text-[#00FF88]">Compatible:</span> HFRE™, BIN™, CCA™</p>
                              <p className="text-xs text-gray-400"><span className="text-red-400">Incompatible:</span> NCA™ (incompatible data scales), SBPE™ (contradictory optimization signals)</p>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'bridge' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#F59E0B]">Mining Bridge Fusion™ — Tutorial</h3>
                            <p className="text-sm text-[#94A3B8]">Mining Bridge Fusion combines multiple solving technologies into unified signal bridges using our Multi-Bridge Architecture™. Each bridge configuration fuses different technology combinations for specialized optimization profiles.</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {MINING_BRIDGE_FUSION.bridges.map(bridge => (
                                <div key={bridge.id} className="p-4 bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-lg">
                                  <h4 className="text-sm font-bold text-[#F59E0B] mb-1">{bridge.name}</h4>
                                  <div className="flex gap-1 mb-2">{bridge.techs.map(t => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-gray-400">{t}</span>)}</div>
                                  <p className="text-xs text-gray-400">{bridge.desc}</p>
                                </div>
                              ))}
                            </div>
                            <div className="p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                              <h4 className="text-sm font-bold text-white mb-2">How to Use Bridge Fusion</h4>
                              <ol className="text-xs text-gray-400 space-y-1.5">
                                <li>1. Connect your miner first — bridges require active miner connection</li>
                                <li>2. Click "Activate" on your desired bridge configuration</li>
                                <li>3. Monitor the Score (overall signal strength), Confidence (reliability %), and Signal (action recommendation)</li>
                                <li>4. You can activate multiple bridges simultaneously for comparison</li>
                                <li>5. The Ultimate Bridge (hexa-fusion) provides the most comprehensive optimization</li>
                              </ol>
                            </div>
                          </div>
                        )}

                        {tutorialTab === 'params' && (
                          <div className="space-y-4">
                            <h3 className="text-lg font-bold text-[#00FF88]">Parameter Tuning Guide</h3>
                            <p className="text-sm text-[#94A3B8]">All technologies are fully adjustable. Use blockchain presets as starting points, then fine-tune based on your specific hardware and network conditions.</p>
                            
                            <div className="overflow-x-auto">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="border-b border-gray-800">
                                    <th className="text-left py-2 text-gray-400 font-medium">Blockchain</th>
                                    <th className="text-left py-2 text-gray-400 font-medium">Algorithm</th>
                                    <th className="text-left py-2 text-gray-400 font-medium">Block Time</th>
                                    <th className="text-left py-2 text-gray-400 font-medium">Key Tuning Tips</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {BLOCKCHAIN_PRESETS.map(bp => (
                                    <tr key={bp.id} className="border-b border-gray-800/50">
                                      <td className="py-2 font-semibold" style={{ color: bp.color }}>{bp.name}</td>
                                      <td className="py-2 text-gray-400">{bp.algorithm}</td>
                                      <td className="py-2 text-gray-400">{bp.blockTime}</td>
                                      <td className="py-2 text-gray-400">
                                        {bp.id === 'bitcoin' && 'High momentum (0.92), large step sizes. Slower blocks allow deeper optimization.'}
                                        {bp.id === 'ethereum_classic' && 'Lower momentum, smaller steps due to fast blocks. Memory-hard needs higher HFRE sensitivity.'}
                                        {bp.id === 'dogecoin' && 'Balanced approach with Tsallis entropy. Merged mining support with Litecoin.'}
                                        {bp.id === 'litecoin' && 'Similar to Doge but higher momentum. Larger search ranges for 2.5min blocks.'}
                                        {bp.id === 'kaspa' && '1-second blocks need aggressive settings: high learning rate, small populations, fast cooling.'}
                                        {bp.id === 'monero' && 'CPU-optimized RandomX needs moderate settings. Focus on entropy analysis.'}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
                              <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                                <h4 className="text-xs font-bold text-green-400 mb-1">Slow Blockchains (Bitcoin, Litecoin)</h4>
                                <p className="text-xs text-gray-400">Use higher momentum, larger populations, slower cooling. More time to optimize per block.</p>
                              </div>
                              <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                                <h4 className="text-xs font-bold text-yellow-400 mb-1">Medium Blockchains (Doge, Monero)</h4>
                                <p className="text-xs text-gray-400">Balanced settings. Mix exploration and exploitation equally.</p>
                              </div>
                              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                                <h4 className="text-xs font-bold text-red-400 mb-1">Fast Blockchains (Kaspa, ETC)</h4>
                                <p className="text-xs text-gray-400">Aggressive learning rates, small populations, fast cooling. Speed over depth.</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-8 sm:mb-12"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-[#00FF88]" />
                <h2 className="text-xl sm:text-2xl font-bold text-white">Installation & Setup Guide</h2>
              </div>
              <button
                onClick={downloadPDF}
                className="flex items-center gap-2 px-4 py-2 bg-[#00FF88]/20 text-[#00FF88] border border-[#00FF88]/30 rounded-lg hover:bg-[#00FF88]/30 transition-all"
                data-testid="button-download-pdf"
              >
                <FileDown size={16} /> Download PDF
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-[#0D1117] border border-[#1A2632] rounded-xl p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Download size={18} className="text-[#00FF88]" /> Step 1: Install the Companion App
                </h3>
                <div className="space-y-3 text-sm text-[#94A3B8]">
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                    <span>Click the download button for your platform (Android, iOS, Windows, or Mac)</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                    <span>Follow the browser prompts to install the Progressive Web App</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                    <span>Launch the app from your home screen or applications folder</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#0D1117] border border-[#1A2632] rounded-xl p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Link2 size={18} className="text-[#00D4FF]" /> Step 2: Connect to Your Solo Miner
                </h3>
                <div className="space-y-3 text-sm text-[#94A3B8]">
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                    <span><strong>Plug & Play:</strong> Click "Scan for Miners" - the app automatically detects compatible mining software on your network</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                    <span><strong>Manual:</strong> Enter your miner's IP address and API port (default: 4028) if auto-detection fails</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-[#00D4FF]/20 text-[#00D4FF] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                    <span>Ensure your miner has API access enabled (CGMiner: --api-listen, XMRig: http-enabled)</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#0D1117] border border-[#1A2632] rounded-xl p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <ToggleLeft size={18} className="text-[#00FF88]" /> Step 3: Choose Your Mode
                </h3>
                <div className="space-y-4 text-sm">
                  <div className="p-3 bg-[#00FF88]/10 border border-[#00FF88]/30 rounded-lg">
                    <div className="text-[#00FF88] font-semibold mb-1">AUTO Mode (Recommended)</div>
                    <div className="text-[#94A3B8] text-xs">SBPE™ automatically optimizes all settings using ACM™ and QFRM™ signals. Perfect for 24/7 unattended mining.</div>
                  </div>
                  <div className="p-3 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-lg">
                    <div className="text-[#FFD700] font-semibold mb-1">MANUAL Mode</div>
                    <div className="text-[#94A3B8] text-xs">Full control over mining parameters including intensity, nonce ranges, threads, and refresh rates.</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#0D1117] border border-[#1A2632] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-semibold flex items-center gap-2">
                    <Wifi size={18} className="text-[#00D4FF]" /> Wi-Fi/Ethernet Solo Miners ({WIFI_ETHERNET_HARDWARE.length})
                  </h3>
                  <span className="text-xs text-gray-500 flex items-center gap-1">
                    <RefreshCw size={12} /> Registry v{REGISTRY_VERSION}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {WIFI_ETHERNET_HARDWARE.map((hw) => (
                    <span
                      key={hw.id}
                      className="px-3 py-1 bg-[#00D4FF]/10 text-[#00D4FF] text-xs rounded-full border border-[#00D4FF]/30 flex items-center gap-1"
                      title={`${hw.manufacturer} | ${hw.chips} | ${getProtocolConfig(hw.protocol).displayName}`}
                    >
                      {hw.name} ({hw.hashrate})
                    </span>
                  ))}
                </div>
                
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2 mt-6">
                  <Usb size={18} className="text-[#00FF88]" /> USB Solo Miners ({USB_HARDWARE.length})
                </h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  {USB_HARDWARE.map((hw) => (
                    <span
                      key={hw.id}
                      className="px-3 py-1 bg-[#00FF88]/10 text-[#00FF88] text-xs rounded-full border border-[#00FF88]/30 flex items-center gap-1"
                      title={`${hw.manufacturer} | ${hw.chips} | ${getProtocolConfig(hw.protocol).displayName}`}
                    >
                      {hw.name} ({hw.hashrate})
                    </span>
                  ))}
                </div>
                
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2 mt-6">
                  <Server size={18} className="text-[#A855F7]" /> Supported Mining Software
                </h3>
                <div className="flex flex-wrap gap-2">
                  {SUPPORTED_SOFTWARE.map((sw) => (
                    <span
                      key={sw}
                      className="px-3 py-1 bg-[#A855F7]/10 text-[#A855F7] text-xs rounded-full border border-[#A855F7]/30"
                    >
                      {sw}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-4">
                  Any miner with API support (Stratum, JSON-RPC, AxeOS, ESP-Miner) is compatible with Alpha Miner Companion
                </p>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-8 sm:mb-12">
            {MINER_FEATURES.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="bg-[#0D1117] border border-[#1A2632] hover:border-[#00FF88]/30 active:border-[#00FF88]/50 rounded-xl p-4 sm:p-6 text-center transition-all duration-300"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl bg-[#00FF88]/10 flex items-center justify-center text-[#00FF88] mx-auto mb-3 sm:mb-4">
                  <feature.icon size={isMobile ? 20 : 24} />
                </div>
                <h3 className="text-sm sm:text-lg font-semibold text-white mb-1 sm:mb-2">{feature.title}</h3>
                <p className="text-[#94A3B8] text-xs sm:text-sm hidden sm:block">{feature.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="relative overflow-hidden rounded-xl sm:rounded-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#00FF88]/10 via-[#00FF88]/5 to-[#00FF88]/10" />
            <div className="absolute inset-0 border border-[#00FF88]/30 rounded-2xl" />
            <div className="relative bg-[#0A0F14]/80 backdrop-blur-sm py-10 sm:py-12 px-6 sm:px-8 text-center">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl sm:rounded-2xl bg-gradient-to-br from-[#00FF88] to-[#00CC66] flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg shadow-[#00FF88]/30">
                <Pickaxe className="w-8 h-8 sm:w-10 sm:h-10 text-[#0A0F14]" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white mb-3 sm:mb-4">Download Alpha Miner Companion</h2>
              <p className="text-[#94A3B8] text-sm sm:text-base mb-6 sm:mb-8 max-w-lg mx-auto">
                Install the Alpha Miner Companion app on any device to optimize your solo mining operations with SBPE™ technology.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-2xl mx-auto">
                <button 
                  onClick={() => handleInstallClick('android')}
                  className="flex flex-col items-center gap-2 p-4 bg-[#0D1117] border border-[#00FF88]/30 rounded-xl hover:bg-[#00FF88]/10 hover:border-[#00FF88]/50 transition-all group"
                  data-testid="button-download-android"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#3DDC84]/20 flex items-center justify-center group-hover:bg-[#3DDC84]/30 transition-colors">
                    <Smartphone className="w-5 h-5 text-[#3DDC84]" />
                  </div>
                  <span className="text-white text-sm font-medium">Android</span>
                </button>
                
                <button 
                  onClick={() => handleInstallClick('ios')}
                  className="flex flex-col items-center gap-2 p-4 bg-[#0D1117] border border-[#00FF88]/30 rounded-xl hover:bg-[#00FF88]/10 hover:border-[#00FF88]/50 transition-all group"
                  data-testid="button-download-ios"
                >
                  <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-white/20 transition-colors">
                    <Apple className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-white text-sm font-medium">iPhone</span>
                </button>
                
                <button 
                  onClick={() => handleInstallClick('windows')}
                  className="flex flex-col items-center gap-2 p-4 bg-[#0D1117] border border-[#00FF88]/30 rounded-xl hover:bg-[#00FF88]/10 hover:border-[#00FF88]/50 transition-all group"
                  data-testid="button-download-windows"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#0078D4]/20 flex items-center justify-center group-hover:bg-[#0078D4]/30 transition-colors">
                    <Monitor className="w-5 h-5 text-[#0078D4]" />
                  </div>
                  <span className="text-white text-sm font-medium">Windows</span>
                </button>
                
                <button 
                  onClick={() => handleInstallClick('mac')}
                  className="flex flex-col items-center gap-2 p-4 bg-[#0D1117] border border-[#00FF88]/30 rounded-xl hover:bg-[#00FF88]/10 hover:border-[#00FF88]/50 transition-all group"
                  data-testid="button-download-mac"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#A2AAAD]/20 flex items-center justify-center group-hover:bg-[#A2AAAD]/30 transition-colors">
                    <Apple className="w-5 h-5 text-[#A2AAAD]" />
                  </div>
                  <span className="text-white text-sm font-medium">Mac</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.52 }}
          className="mt-8 mb-8"
          data-testid="section-command-center-bridge"
        >
          <div className="bg-gradient-to-r from-amber-500/5 via-[#0A0F14] to-emerald-500/5 border border-amber-500/30 rounded-2xl overflow-hidden">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-600 to-emerald-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Command Center Intelligence</h2>
                    <p className="text-sm text-amber-300/70">Live Signal Bridge — Blockchain Hash Analysis</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCmdCenterPolling(!cmdCenterPolling)}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      cmdCenterBridge?.connected
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : cmdCenterPolling
                        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                        : 'bg-white/5 text-gray-400 border border-white/10'
                    }`}
                    data-testid="button-cmd-center-bridge-toggle"
                  >
                    {cmdCenterBridge?.connected ? (
                      <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Receiving Signals</span>
                    ) : cmdCenterPolling ? (
                      <span className="flex items-center gap-2"><Loader2 className="w-3.5 h-3.5 animate-spin" /> Waiting for Signals</span>
                    ) : 'Enable Bridge'}
                  </button>
                </div>
              </div>

              <p className="text-[#94A3B8] text-sm mb-5">
                Receives real-time blockchain analysis intelligence from the Mining Command Center. When both apps are running, 
                hash pattern analysis, entropy signals, and difficulty trends flow directly to your mining companion — giving your miner 
                a combined intelligence edge from two separate analysis engines working together.
              </p>

              {cmdCenterBridgeError === 'auth' ? (
                <div className="text-center py-8 border border-dashed border-red-500/20 rounded-xl bg-red-500/5">
                  <Shield className="w-10 h-10 text-red-400/50 mx-auto mb-3" />
                  <p className="text-red-300/60 text-sm">Login required to receive Command Center signals</p>
                  <p className="text-red-300/40 text-xs mt-1">Sign in to your account to enable the Signal Bridge</p>
                </div>
              ) : cmdCenterBridgeError === 'expired' ? (
                <div className="text-center py-8 border border-dashed border-yellow-500/20 rounded-xl bg-yellow-500/5">
                  <Clock className="w-10 h-10 text-yellow-400/50 mx-auto mb-3" />
                  <p className="text-yellow-300/60 text-sm">Command Center signals expired (no update in 10+ minutes)</p>
                  <p className="text-yellow-300/40 text-xs mt-1">Run a new analysis in the Mining Command Center to refresh signals</p>
                </div>
              ) : !cmdCenterBridge?.connected ? (
                <div className="text-center py-8 border border-dashed border-amber-500/20 rounded-xl bg-amber-500/5">
                  <Signal className="w-10 h-10 text-amber-400/50 mx-auto mb-3" />
                  <p className="text-amber-300/60 text-sm">
                    {cmdCenterBridgeError === 'network' ? 'Unable to reach Signal Bridge — retrying...' :
                     cmdCenterPolling ? 'Listening for Command Center signals...' : 'Bridge disabled — click "Enable Bridge" to start receiving'}
                  </p>
                  <p className="text-amber-300/40 text-xs mt-1">Open the Mining Command Center in another tab and run a blockchain analysis</p>
                </div>
              ) : cmdCenterBridge.data && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-[#0D1117] border border-amber-500/20 rounded-xl p-4" data-testid="card-bridge-signal">
                      <div className="text-xs text-amber-300/60 mb-1">Mining Signal</div>
                      <div className={`text-2xl font-bold ${
                        cmdCenterBridge.data.signal === 'MINE' ? 'text-green-400' :
                        cmdCenterBridge.data.signal === 'HOLD' ? 'text-yellow-400' : 'text-red-400'
                      }`}>{cmdCenterBridge.data.signal}</div>
                      <div className="text-[10px] text-gray-500 mt-1">From Command Center</div>
                    </div>
                    <div className="bg-[#0D1117] border border-amber-500/20 rounded-xl p-4" data-testid="card-bridge-window-score">
                      <div className="text-xs text-amber-300/60 mb-1">Window Score</div>
                      <div className="text-2xl font-bold text-cyan-400">{cmdCenterBridge.data.windowScore}/100</div>
                      <div className="text-[10px] text-gray-500 mt-1">
                        {cmdCenterBridge.data.windowScore >= 75 ? 'Favorable window' : cmdCenterBridge.data.windowScore >= 50 ? 'Neutral conditions' : 'Unfavorable window'}
                      </div>
                    </div>
                    <div className="bg-[#0D1117] border border-amber-500/20 rounded-xl p-4" data-testid="card-bridge-difficulty">
                      <div className="text-xs text-amber-300/60 mb-1">Difficulty Trend</div>
                      <div className={`text-2xl font-bold ${
                        cmdCenterBridge.data.difficultyTrend === 'falling' ? 'text-green-400' :
                        cmdCenterBridge.data.difficultyTrend === 'stable' ? 'text-cyan-400' : 'text-orange-400'
                      }`}>
                        {cmdCenterBridge.data.difficultyTrend === 'falling' ? '↓ Easing' :
                         cmdCenterBridge.data.difficultyTrend === 'stable' ? '→ Stable' : '↑ Rising'}
                      </div>
                      <div className="text-[10px] text-gray-500 mt-1">Avg {cmdCenterBridge.data.avgLeadingZeros} leading zeros</div>
                    </div>
                    <div className="bg-[#0D1117] border border-amber-500/20 rounded-xl p-4" data-testid="card-bridge-entropy">
                      <div className="text-xs text-amber-300/60 mb-1">Entropy Deviation</div>
                      <div className="text-2xl font-bold text-purple-400">{cmdCenterBridge.data.entropyDeviation}%</div>
                      <div className="text-[10px] text-gray-500 mt-1">Mod3 entropy: {cmdCenterBridge.data.mod3Entropy}%</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                    <div className="bg-[#0D1117] border border-white/5 rounded-lg p-3 text-center">
                      <div className="text-[10px] text-gray-500">Bit Balance</div>
                      <div className="text-sm font-bold text-cyan-300 font-mono">{cmdCenterBridge.data.avgBitDist}%</div>
                    </div>
                    <div className="bg-[#0D1117] border border-white/5 rounded-lg p-3 text-center">
                      <div className="text-[10px] text-gray-500">Chi-Squared</div>
                      <div className="text-sm font-bold text-orange-400 font-mono">{cmdCenterBridge.data.chiSquared}</div>
                    </div>
                    <div className="bg-[#0D1117] border border-white/5 rounded-lg p-3 text-center">
                      <div className="text-[10px] text-gray-500">Anomalies</div>
                      <div className="text-sm font-bold text-yellow-400 font-mono">{cmdCenterBridge.data.anomalyCount}</div>
                    </div>
                    <div className="bg-[#0D1117] border border-white/5 rounded-lg p-3 text-center">
                      <div className="text-[10px] text-gray-500">Correlations</div>
                      <div className="text-sm font-bold text-emerald-400 font-mono">{cmdCenterBridge.data.strongCorrs}</div>
                    </div>
                    <div className="bg-[#0D1117] border border-white/5 rounded-lg p-3 text-center">
                      <div className="text-[10px] text-gray-500">Blocks Analyzed</div>
                      <div className="text-sm font-bold text-white font-mono">{cmdCenterBridge.data.blockCount}</div>
                    </div>
                  </div>

                  {cmdCenterBridge.data.feedItems.length > 0 && (
                    <div className="bg-[#0D1117] border border-amber-500/10 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Activity className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-semibold text-amber-300">Intelligence Feed</span>
                        <span className="text-[10px] text-gray-500 ml-auto">{cmdCenterBridge.data.feedItems.length} signals</span>
                      </div>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {cmdCenterBridge.data.feedItems.slice(0, 8).map((item, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs">
                            <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                              item.severity === 'success' ? 'bg-green-400' :
                              item.severity === 'warning' ? 'bg-yellow-400' :
                              item.severity === 'anomaly' ? 'bg-red-400' : 'bg-blue-400'
                            }`} />
                            <span className="text-gray-400">{item.message}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between px-1">
                    <span className="text-[10px] text-gray-600">
                      Last update: {new Date(cmdCenterBridge.data.timestamp).toLocaleTimeString()} 
                      ({Math.round(cmdCenterBridge.age / 1000)}s ago)
                    </span>
                    <span className="text-[10px] text-emerald-500/60 flex items-center gap-1">
                      <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
                      Auto-refreshing every 15s
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="mt-8 mb-8"
          data-testid="section-qmge-mining-integration"
        >
          <div className="bg-gradient-to-r from-violet-500/5 via-[#0A0F14] to-cyan-500/5 border border-violet-500/30 rounded-2xl overflow-hidden">
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-violet-500/30">
                    <Atom className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">QMGE™ Mining Intelligence</h2>
                    <p className="text-sm text-violet-300/70">Quantum Market Genome Engine — Mining Bridge</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <select
                    value={qmgeMiningSymbol}
                    onChange={(e) => setQmgeMiningSymbol(e.target.value)}
                    className="bg-[#0D1117] border border-violet-500/30 text-white text-sm rounded-lg px-3 py-1.5 focus:border-violet-400 focus:outline-none"
                    data-testid="select-qmge-mining-symbol"
                  >
                    <option value="BTCUSDT">BTC</option>
                    <option value="ETHUSDT">ETH</option>
                    <option value="LTCUSDT">LTC</option>
                    <option value="DOGEUSDT">DOGE</option>
                    <option value="XMRUSDT">XMR</option>
                  </select>
                  <button
                    onClick={() => setQmgeMiningStatus(qmgeMiningStatus === 'connected' ? 'disconnected' : 'connecting')}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      qmgeMiningStatus === 'connected'
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-red-500/20 hover:text-red-400 hover:border-red-500/30'
                        : qmgeMiningStatus === 'connecting'
                        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                        : 'bg-violet-600/80 text-white border border-violet-500/30 hover:bg-violet-500/80'
                    }`}
                    data-testid="button-qmge-mining-connect"
                  >
                    {qmgeMiningStatus === 'connected' ? '● Connected' : qmgeMiningStatus === 'connecting' ? '◌ Connecting...' : 'Connect QMGE'}
                  </button>
                </div>
              </div>

              <p className="text-[#94A3B8] text-sm mb-6">
                QMGE analyzes 7 market genome dimensions to provide real-time mining intelligence — difficulty prediction, chain profitability analysis, 
                optimal mining windows, and nonce range optimization hints. Data feeds directly to your mining companion for enhanced block-solving optimization.
              </p>

              {qmgeMiningStatus === 'disconnected' && (
                <div className="text-center py-8 border border-dashed border-violet-500/20 rounded-xl bg-violet-500/5">
                  <Atom className="w-10 h-10 text-violet-400/50 mx-auto mb-3" />
                  <p className="text-violet-300/60 text-sm">Click "Connect QMGE" to start receiving mining intelligence</p>
                  <p className="text-violet-300/40 text-xs mt-1">Data will be sent to your connected miner via the Mining Bridge API</p>
                </div>
              )}

              {qmgeMiningStatus === 'connecting' && !qmgeMiningData && (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 text-violet-400 mx-auto mb-3 animate-spin" />
                  <p className="text-violet-300/70 text-sm">Establishing QMGE Mining Bridge connection...</p>
                </div>
              )}

              {qmgeMiningData && qmgeMiningStatus === 'connected' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-mining-window">
                      <div className="text-xs text-violet-300/60 mb-1">Mining Window</div>
                      <div className={`text-lg font-bold ${
                        qmgeMiningData.miningWindow.recommendation === 'mine_full_power' ? 'text-green-400' :
                        qmgeMiningData.miningWindow.recommendation === 'mine_reduced' ? 'text-yellow-400' :
                        qmgeMiningData.miningWindow.recommendation === 'hold' ? 'text-orange-400' : 'text-red-400'
                      }`} data-testid="text-mining-recommendation">
                        {qmgeMiningData.miningWindow.recommendation === 'mine_full_power' ? 'FULL POWER' :
                         qmgeMiningData.miningWindow.recommendation === 'mine_reduced' ? 'REDUCED' :
                         qmgeMiningData.miningWindow.recommendation === 'hold' ? 'HOLD' : 'SWITCH CHAIN'}
                      </div>
                      <div className="text-xs text-[#94A3B8] mt-1">Score: {Math.round(qmgeMiningData.miningWindow.windowScore)}/100</div>
                    </div>

                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-difficulty-prediction">
                      <div className="text-xs text-violet-300/60 mb-1">Difficulty</div>
                      <div className={`text-lg font-bold ${
                        qmgeMiningData.difficultyPrediction.direction === 'decreasing' ? 'text-green-400' :
                        qmgeMiningData.difficultyPrediction.direction === 'increasing' ? 'text-red-400' : 'text-yellow-400'
                      }`}>
                        {qmgeMiningData.difficultyPrediction.direction === 'decreasing' ? '↓ Decreasing' :
                         qmgeMiningData.difficultyPrediction.direction === 'increasing' ? '↑ Increasing' : '→ Stable'}
                      </div>
                      <div className="text-xs text-[#94A3B8] mt-1">Confidence: {Math.round(qmgeMiningData.difficultyPrediction.confidence)}%</div>
                    </div>

                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-chain-profitability">
                      <div className="text-xs text-violet-300/60 mb-1">Chain Profitability</div>
                      <div className={`text-lg font-bold ${
                        qmgeMiningData.chainProfitability.signal === 'highly_profitable' ? 'text-green-400' :
                        qmgeMiningData.chainProfitability.signal === 'profitable' ? 'text-cyan-400' :
                        qmgeMiningData.chainProfitability.signal === 'unprofitable' ? 'text-red-400' : 'text-yellow-400'
                      }`}>
                        {qmgeMiningData.chainProfitability.signal.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                      </div>
                      <div className="text-xs text-[#94A3B8] mt-1">Score: {Math.round(qmgeMiningData.chainProfitability.score)}/100</div>
                    </div>

                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-network-intel">
                      <div className="text-xs text-violet-300/60 mb-1">Network Health</div>
                      <div className="text-lg font-bold text-cyan-400">
                        {Math.round(qmgeMiningData.networkIntelligence.hashRateStability)}%
                      </div>
                      <div className="text-xs text-[#94A3B8] mt-1">Congestion: {Math.round(qmgeMiningData.networkIntelligence.congestionLevel)}%</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-hash-optimization">
                      <div className="flex items-center gap-2 mb-3">
                        <Hash className="w-4 h-4 text-violet-400" />
                        <span className="text-sm font-semibold text-white">Hash Optimization Hints</span>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <div className="text-xs text-violet-300/60">Nonce Range Start</div>
                          <div className="text-white font-mono text-xs">{qmgeMiningData.hashOptimization.nonceRangeHint.start.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-xs text-violet-300/60">Nonce Range End</div>
                          <div className="text-white font-mono text-xs">{qmgeMiningData.hashOptimization.nonceRangeHint.end.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-xs text-violet-300/60">Resonance Frequency</div>
                          <div className="text-cyan-400 font-mono">{qmgeMiningData.hashOptimization.resonanceFrequency}</div>
                        </div>
                        <div>
                          <div className="text-xs text-violet-300/60">Entropy Gradient</div>
                          <div className="text-yellow-400 font-mono">{qmgeMiningData.hashOptimization.entropyGradient}</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#0D1117] border border-violet-500/20 rounded-xl p-4" data-testid="card-genome-pattern">
                      <div className="flex items-center gap-2 mb-3">
                        <Activity className="w-4 h-4 text-violet-400" />
                        <span className="text-sm font-semibold text-white">Genome Intelligence</span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-violet-300/60">Active Pattern</span>
                          <span className="text-violet-400 font-semibold">{qmgeMiningData.genomePattern}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-violet-300/60">Aggregate Score</span>
                          <span className="text-white">{Math.round(qmgeMiningData.aggregateScore)}/100</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-violet-300/60">Convergence Target</span>
                          <span className="text-cyan-400 font-mono">{qmgeMiningData.hashOptimization.convergenceTarget}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-violet-300/60">Window Time Left</span>
                          <span className="text-white">{Math.floor(qmgeMiningData.miningWindow.timeRemaining / 60)}m {qmgeMiningData.miningWindow.timeRemaining % 60}s</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#0D1117]/50 border border-violet-500/10 rounded-lg p-3">
                    <p className="text-xs text-[#94A3B8]">
                      <span className="text-violet-400 font-semibold">Mining Bridge API:</span> {window.location.origin}/api/qmge/mining-data?symbol={qmgeMiningSymbol}
                    </p>
                    <p className="text-xs text-violet-300/50 mt-1">{qmgeMiningData.miningWindow.reason}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {(qmgeMiningStatus === 'connected' || isConnected) && coordinatedCmd && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mb-8"
            data-testid="section-signal-coordinator"
          >
            <div className="bg-gradient-to-r from-emerald-500/5 via-[#0A0F14] to-amber-500/5 border border-emerald-500/30 rounded-2xl overflow-hidden">
              <div className="p-6 sm:p-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-600 to-amber-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                      <Sliders className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">Signal Coordinator</h2>
                      <p className="text-sm text-emerald-300/70">Mining Companion + QMGE Conflict Resolution</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowCoordinatorPanel(!showCoordinatorPanel)}
                    className="text-emerald-400 hover:text-emerald-300 transition-colors"
                    data-testid="button-toggle-coordinator"
                  >
                    <ChevronUp className={`w-5 h-5 transition-transform ${showCoordinatorPanel ? '' : 'rotate-180'}`} />
                  </button>
                </div>

                <AnimatePresence>
                  {showCoordinatorPanel && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-[#0D1117] border border-emerald-500/20 rounded-xl p-4" data-testid="card-sync-status">
                          <div className="text-xs text-emerald-300/60 mb-1">Sync Status</div>
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full animate-pulse"
                              style={{ backgroundColor: getConflictSeverityColor(coordinatedCmd.conflictReport.severity) }}
                            />
                            <span
                              className="text-lg font-bold"
                              style={{ color: getConflictSeverityColor(coordinatedCmd.conflictReport.severity) }}
                              data-testid="text-sync-status"
                            >
                              {getConflictSeverityLabel(coordinatedCmd.conflictReport.severity)}
                            </span>
                          </div>
                          <div className="text-xs text-[#94A3B8] mt-1">
                            {coordinatedCmd.conflictReport.conflicts.length} conflict(s) detected
                          </div>
                        </div>

                        <div className="bg-[#0D1117] border border-emerald-500/20 rounded-xl p-4" data-testid="card-active-source">
                          <div className="text-xs text-emerald-300/60 mb-1">Active Source</div>
                          <div className="text-lg font-bold text-white" data-testid="text-active-source">
                            {getPriorityLabel(coordinatedCmd.source)}
                          </div>
                          <div className="text-xs text-[#94A3B8] mt-1">
                            Confidence: {Math.round(coordinatedCmd.confidenceScore)}%
                          </div>
                        </div>

                        <div className="bg-[#0D1117] border border-emerald-500/20 rounded-xl p-4" data-testid="card-overall-action">
                          <div className="text-xs text-emerald-300/60 mb-1">Coordinated Action</div>
                          <div className={`text-lg font-bold ${
                            coordinatedCmd.overallAction === 'mine_full_power' ? 'text-green-400' :
                            coordinatedCmd.overallAction === 'mine_reduced' ? 'text-yellow-400' :
                            coordinatedCmd.overallAction === 'hold' ? 'text-orange-400' :
                            coordinatedCmd.overallAction === 'switch_chain' ? 'text-red-400' : 'text-cyan-400'
                          }`} data-testid="text-coordinated-action">
                            {coordinatedCmd.overallAction === 'mine_full_power' ? 'FULL POWER' :
                             coordinatedCmd.overallAction === 'mine_reduced' ? 'REDUCED' :
                             coordinatedCmd.overallAction === 'hold' ? 'HOLD' :
                             coordinatedCmd.overallAction === 'switch_chain' ? 'SWITCH CHAIN' : 'MANUAL'}
                          </div>
                          <div className="text-xs text-[#94A3B8] mt-1">
                            QMGE {coordinatedCmd.qmgeApplied ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 mb-4">
                        <div className="text-xs text-emerald-300/60">Priority Mode:</div>
                        {(['balanced', 'qmge', 'companion'] as SignalPriority[]).map(p => (
                          <button
                            key={p}
                            onClick={() => setSignalPriority(p)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                              signalPriority === p
                                ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/50'
                                : 'bg-[#0D1117] text-[#94A3B8] border border-[#21262D] hover:border-emerald-500/30 hover:text-emerald-300'
                            }`}
                            data-testid={`button-priority-${p}`}
                          >
                            {getPriorityLabel(p)}
                          </button>
                        ))}
                        <div className="ml-auto flex items-center gap-2">
                          <span className="text-xs text-emerald-300/60">Auto-Apply QMGE:</span>
                          <button
                            onClick={() => setAutoApplyQMGE(!autoApplyQMGE)}
                            className={`transition-colors ${autoApplyQMGE ? 'text-emerald-400' : 'text-[#94A3B8]'}`}
                            data-testid="button-toggle-auto-apply"
                          >
                            {autoApplyQMGE ? <ToggleRight className="w-6 h-6" /> : <ToggleLeft className="w-6 h-6" />}
                          </button>
                        </div>
                      </div>

                      {coordinatedCmd.conflictReport.hasConflict && (
                        <div className="mb-4 space-y-2" data-testid="section-conflicts">
                          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                            Parameter Conflicts
                          </div>
                          {coordinatedCmd.conflictReport.conflicts.map((c, i) => (
                            <div key={i} className="bg-[#0D1117] border border-amber-500/20 rounded-lg p-3 text-sm" data-testid={`conflict-item-${i}`}>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-white font-semibold">{c.parameter}</span>
                                <div className="flex items-center gap-2">
                                  <span className="text-[#94A3B8] text-xs">Companion: <span className="text-cyan-400">{c.companionValue}</span></span>
                                  <span className="text-amber-400">→</span>
                                  <span className="text-[#94A3B8] text-xs">QMGE: <span className="text-violet-400">{c.qmgeRecommended}</span></span>
                                  <span className={`text-xs px-1.5 py-0.5 rounded ${c.priority === 'qmge' ? 'bg-violet-500/20 text-violet-300' : 'bg-cyan-500/20 text-cyan-300'}`}>
                                    {c.priority === 'qmge' ? 'QMGE wins' : 'Companion wins'}
                                  </span>
                                </div>
                              </div>
                              <p className="text-xs text-[#94A3B8]">{c.reason}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {coordinatedCmd.recommendations.length > 0 && (
                        <div className="bg-[#0D1117]/50 border border-emerald-500/10 rounded-lg p-3" data-testid="section-recommendations">
                          <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">
                            Active Recommendations
                          </div>
                          <ul className="space-y-1">
                            {coordinatedCmd.recommendations.map((rec, i) => (
                              <li key={i} className="text-xs text-[#94A3B8] flex items-start gap-2">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400 mt-0.5 flex-shrink-0" />
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="mt-4 grid grid-cols-3 md:grid-cols-6 gap-2" data-testid="section-coordinated-params">
                        {[
                          { label: 'Intensity', key: 'intensity' as const, unit: '%', color: '#22C55E' },
                          { label: 'Nonce Range', key: 'nonceRange' as const, unit: '', color: '#3B82F6' },
                          { label: 'Difficulty', key: 'difficulty' as const, unit: '', color: '#EAB308' },
                          { label: 'Threads', key: 'threads' as const, unit: '', color: '#A855F7' },
                          { label: 'Refresh', key: 'refreshRate' as const, unit: 's', color: '#06B6D4' },
                          { label: 'Latency', key: 'latencyThreshold' as const, unit: 'ms', color: '#F97316' },
                        ].map(param => (
                          <div key={param.key} className="bg-[#0D1117] border border-[#21262D] rounded-lg p-2 text-center" data-testid={`param-${param.key}`}>
                            <div className="text-[10px] text-[#94A3B8] mb-0.5">{param.label}</div>
                            <div className="text-sm font-bold" style={{ color: param.color }}>
                              {coordinatedCmd.adjustments[param.key]}{param.unit}
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-r from-[#FFD700]/5 via-[#0A0F14] to-[#00FF88]/5 border border-[#FFD700]/20 rounded-2xl p-6 mb-20"
        >
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-[#FFD700]" />
            <h2 className="text-xl font-bold text-[#FFD700]">Copyright & Intellectual Property</h2>
          </div>
          <div className="text-sm text-[#94A3B8] space-y-3">
            <p>
              <span className="text-[#FFD700]">© {new Date().getFullYear()} Alpha Unlimited Trading Company.</span> All Rights Reserved Worldwide in Perpetuity.
            </p>
            <p>
              The Alpha Solo Mining Companion™, Stochastic Block Prediction Engine™ (SBPE), Autonomous Blockchain Spider™ (ABS), AI-Powered Blockchain Solving Technologies™ 
              including Nonce Convergence Algorithm™ (NCA), Hash Flow Resonance Engine™ (HFRE), Block Intelligence Network™ (BIN), 
              Cross-Correlation Analysis™ (CCA), Differential Cryptanalysis™ (DCA), Live Pattern Detection™, Pattern Memory™,
              Mining Bridge Fusion™, Custom Bridge Builder™, QMGE™ Mining Bridge, Probabilistic Hash Terrain Mapping™ (PHTM), Gradient Hash Descent™ (GHD), Bayesian Nonce Prior™ (BNP),
              Genetic Hash Evolution™ (GHE), Entropy Wavelet Decomposition™ (EWD), Thermal Annealing Search™ (TAS), 
              and all associated sub-technologies are proprietary technologies exclusively owned by 
              Alpha Unlimited Trading Company.
            </p>
            <p className="text-[#FF6B6B]">
              <strong>WARNING:</strong> Any unauthorized use, copying, reverse engineering, or implementation of these technologies 
              will result in immediate legal action with damages up to $150,000 per work infringed, plus actual damages, lost profits, 
              attorney's fees, and criminal penalties including imprisonment.
            </p>
            <div className="flex items-center gap-4 mt-4">
              <Link href="/copyright">
                <span className="text-[#00D4FF] hover:underline cursor-pointer flex items-center gap-1">
                  <FileDown size={14} /> View Full Copyright Notice
                </span>
              </Link>
            </div>
          </div>
        </motion.div>

        <div className="fixed bottom-0 left-0 right-0 md:hidden bg-[#0A0F14]/95 backdrop-blur-md border-t border-[#00FF88]/20 p-4 z-50">
          <button 
            onClick={() => handleInstallClick(platform)}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#00FF88] text-[#0A0F14] font-bold rounded-xl active:bg-[#00CC66] transition-colors shadow-lg shadow-[#00FF88]/30" 
            data-testid="button-download-miner-mobile"
          >
            <Download size={20} />
            Download Miner Companion
          </button>
        </div>

        <AnimatePresence>
          {showInstallModal && (
            <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4" onClick={() => setShowInstallModal(false)}>
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-[#0A0F14] border border-[#00FF88]/30 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-end mb-2">
                  <button onClick={() => setShowInstallModal(false)} className="text-gray-500 hover:text-white">
                    <X size={20} />
                  </button>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#00FF88] to-[#00CC66] rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Pickaxe className="w-8 h-8 text-[#0A0F14]" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Install Alpha Miner Companion</h3>
                  
                  {selectedPlatform === 'ios' ? (
                    <div className="text-left space-y-3 my-6">
                      <p className="text-[#94A3B8] text-sm mb-4">To install on iPhone/iPad:</p>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                        <span className="text-white text-sm">Open this page in <span className="text-[#00FF88]">Safari</span></span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                        <span className="text-white text-sm">Tap the <span className="text-[#00FF88]">Share</span> button at the bottom</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                        <span className="text-white text-sm">Select <span className="text-[#00FF88]">"Add to Home Screen"</span></span>
                      </div>
                    </div>
                  ) : selectedPlatform === 'android' ? (
                    <div className="text-left space-y-3 my-6">
                      <p className="text-[#94A3B8] text-sm mb-4">To install on Android:</p>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                        <span className="text-white text-sm">Open this page in <span className="text-[#00FF88]">Chrome</span></span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                        <span className="text-white text-sm">Tap the <span className="text-[#00FF88]">menu (⋮)</span> in the top right</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                        <span className="text-white text-sm">Select <span className="text-[#00FF88]">"Install app"</span> or <span className="text-[#00FF88]">"Add to Home screen"</span></span>
                      </div>
                    </div>
                  ) : selectedPlatform === 'windows' ? (
                    <div className="text-left space-y-3 my-6">
                      <p className="text-[#94A3B8] text-sm mb-4">To install on Windows:</p>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                        <span className="text-white text-sm">Open this page in <span className="text-[#00FF88]">Chrome</span> or <span className="text-[#00FF88]">Edge</span></span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                        <span className="text-white text-sm">Click the <span className="text-[#00FF88]">install icon</span> in the address bar</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                        <span className="text-white text-sm">Or click <span className="text-[#00FF88]">menu (⋮) → Install Alpha Miner</span></span>
                      </div>
                    </div>
                  ) : selectedPlatform === 'mac' ? (
                    <div className="text-left space-y-3 my-6">
                      <p className="text-[#94A3B8] text-sm mb-4">To install on Mac:</p>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                        <span className="text-white text-sm">Open this page in <span className="text-[#00FF88]">Chrome</span> or <span className="text-[#00FF88]">Safari</span></span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                        <span className="text-white text-sm">In Chrome: Click <span className="text-[#00FF88]">menu (⋮) → Install Alpha Miner</span></span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">3</span>
                        <span className="text-white text-sm">In Safari: Click <span className="text-[#00FF88]">File → Add to Dock</span></span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-left space-y-3 my-6">
                      <p className="text-[#94A3B8] text-sm mb-4">To install the app:</p>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">1</span>
                        <span className="text-white text-sm">Open this page in a supported browser</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="bg-[#00FF88]/20 text-[#00FF88] rounded-full w-6 h-6 flex items-center justify-center text-xs flex-shrink-0">2</span>
                        <span className="text-white text-sm">Look for the install option in your browser menu</span>
                      </div>
                    </div>
                  )}
                  
                  <button
                    onClick={() => setShowInstallModal(false)}
                    className="w-full py-3 bg-[#00FF88] text-[#0A0F14] font-bold rounded-xl hover:bg-[#00CC66] transition-colors"
                  >
                    Got it!
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </TradingPlatformLayout>
  );
}
