/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Forensic Tracer™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Forensic Tracer™
 * - Fund Flow Visualization Engine™
 * - Address Intelligence Overlay™
 * - Risk Path Detection™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_d6f54d78992c749037540896
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface TracedTransaction {
  hash: string;
  blockNumber: number | null;
  timestamp: string;
  from: string;
  to: string;
  value: string;
  valueUSD: string | null;
  fee: string;
  direction: "incoming" | "outgoing" | "self";
  tokenTransfer: boolean;
  tokenSymbol?: string;
  tokenAmount?: string;
  confirmed: boolean;
}

interface RiskIndicator {
  type: string;
  severity: "critical" | "high" | "medium" | "low";
  description: string;
}

interface ConnectedAddress {
  address: string;
  relationship: "sent_to" | "received_from" | "bidirectional";
  totalValue: string;
  transactionCount: number;
  firstInteraction: string | null;
  lastInteraction: string | null;
}

interface AddressProfile {
  address: string;
  chain: string;
  chainName: string;
  balance: string;
  balanceUSD: string | null;
  totalReceived: string;
  totalSent: string;
  transactionCount: number;
  firstSeen: string | null;
  lastSeen: string | null;
  transactions: TracedTransaction[];
  riskIndicators: RiskIndicator[];
  connectedAddresses: ConnectedAddress[];
}

interface TransactionDetail {
  hash: string;
  chain: string;
  chainName: string;
  blockNumber: number | null;
  blockHash: string | null;
  timestamp: string;
  from: string;
  to: string;
  value: string;
  valueUSD: string | null;
  fee: string;
  feeUSD: string | null;
  gasUsed: string | null;
  gasPrice: string | null;
  nonce: number | null;
  confirmed: boolean;
  confirmations: number;
  inputData: string | null;
  internalTransactions: Array<{ from: string; to: string; value: string }>;
}

interface FundFlowGraph {
  nodes: Array<{ address: string; label: string; totalIn: string; totalOut: string; depth: number }>;
  edges: Array<{ from: string; to: string; value: string; txHash: string; timestamp: string }>;
  rootAddress: string;
  chain: string;
  depth: number;
}

interface ChainInfo {
  id: string;
  name: string;
  symbol: string;
  explorer: string;
}

const CHAIN_COLORS: Record<string, string> = {
  ethereum: "#627EEA",
  bitcoin: "#F7931A",
  bsc: "#F0B90B",
  polygon: "#8247E5",
  solana: "#14F195",
  tron: "#FF0013",
};

const CHAIN_ICONS: Record<string, string> = {
  ethereum: "⟠",
  bitcoin: "₿",
  bsc: "⬡",
  polygon: "⬟",
  solana: "◎",
  tron: "◆",
};

function shortenAddress(addr: string, chars = 6) {
  if (!addr || addr.length < chars * 2 + 3) return addr;
  return addr.slice(0, chars) + "..." + addr.slice(-chars);
}

function formatDate(ts: string) {
  if (!ts) return "N/A";
  try {
    return new Date(ts).toLocaleString();
  } catch {
    return ts;
  }
}

function severityColor(severity: string) {
  switch (severity) {
    case "critical": return "text-red-400 bg-red-500/20 border-red-500/40";
    case "high": return "text-orange-400 bg-orange-500/20 border-orange-500/40";
    case "medium": return "text-yellow-400 bg-yellow-500/20 border-yellow-500/40";
    case "low": return "text-blue-400 bg-blue-500/20 border-blue-500/40";
    default: return "text-gray-400 bg-gray-500/20 border-gray-500/40";
  }
}

function FundFlowVisualization({ graph }: { graph: FundFlowGraph }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const rootColor = "#00D4FF";
  const nodeColors = ["#FFD700", "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4"];

  const nodesByDepth: Record<number, typeof graph.nodes> = {};
  for (const node of graph.nodes) {
    if (!nodesByDepth[node.depth]) nodesByDepth[node.depth] = [];
    nodesByDepth[node.depth].push(node);
  }

  const maxDepth = Math.max(...graph.nodes.map(n => n.depth), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm text-gray-400">
        <span className="w-3 h-3 rounded-full bg-[#00D4FF]" />
        <span>Root Address</span>
        <span className="ml-4 w-3 h-3 rounded-full bg-[#FFD700]" />
        <span>Connected</span>
        <span className="ml-4">Depth: {graph.depth} hops</span>
      </div>

      <div className="space-y-3">
        {Array.from({ length: maxDepth + 1 }, (_, depth) => {
          const depthNodes = nodesByDepth[depth] || [];
          return (
            <div key={depth}>
              <div className="text-[10px] text-gray-500 mb-1 uppercase tracking-wider">
                {depth === 0 ? "Root" : `Hop ${depth}`}
              </div>
              <div className="flex flex-wrap gap-2">
                {depthNodes.map((node, i) => {
                  const color = depth === 0 ? rootColor : nodeColors[i % nodeColors.length];
                  const edgesFrom = graph.edges.filter(e => e.from === node.address || e.to === node.address);
                  const totalFlow = edgesFrom.reduce((s, e) => s + parseFloat(e.value || "0"), 0);
                  return (
                    <div
                      key={node.address}
                      className="border rounded-lg p-2 text-xs min-w-[180px]"
                      style={{ borderColor: color + "60", backgroundColor: color + "10" }}
                    >
                      <div className="font-mono font-bold" style={{ color }}>{node.label}</div>
                      <div className="text-gray-400 mt-1">
                        Flow: {totalFlow.toFixed(6)}
                      </div>
                      {parseFloat(node.totalIn) > 0 && (
                        <div className="text-green-400">In: {parseFloat(node.totalIn).toFixed(4)}</div>
                      )}
                      {parseFloat(node.totalOut) > 0 && (
                        <div className="text-red-400">Out: {parseFloat(node.totalOut).toFixed(4)}</div>
                      )}
                    </div>
                  );
                })}
              </div>

              {depth < maxDepth && graph.edges.filter(e => {
                const fromNode = graph.nodes.find(n => n.address === e.from);
                return fromNode?.depth === depth;
              }).length > 0 && (
                <div className="flex flex-col items-start ml-8 my-1">
                  {graph.edges
                    .filter(e => {
                      const fromNode = graph.nodes.find(n => n.address === e.from);
                      return fromNode?.depth === depth;
                    })
                    .slice(0, 10)
                    .map((edge, i) => (
                      <div key={i} className="flex items-center gap-2 text-[10px] text-gray-500">
                        <span>↓</span>
                        <span className="font-mono">{shortenAddress(edge.from, 4)}</span>
                        <span className="text-yellow-400">→ {parseFloat(edge.value).toFixed(6)}</span>
                        <span className="font-mono">{shortenAddress(edge.to, 4)}</span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function ForensicTracer() {
  const [searchInput, setSearchInput] = useState("");
  const [selectedChain, setSelectedChain] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [addressProfile, setAddressProfile] = useState<AddressProfile | null>(null);
  const [txDetail, setTxDetail] = useState<TransactionDetail | null>(null);
  const [fundFlow, setFundFlow] = useState<FundFlowGraph | null>(null);
  const [flowLoading, setFlowLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "transactions" | "connections" | "risks" | "flow">("overview");
  const [chains] = useState<ChainInfo[]>([
    { id: "ethereum", name: "Ethereum", symbol: "ETH", explorer: "https://etherscan.io" },
    { id: "bitcoin", name: "Bitcoin", symbol: "BTC", explorer: "https://blockchain.info" },
    { id: "bsc", name: "BNB Smart Chain", symbol: "BNB", explorer: "https://bscscan.com" },
    { id: "polygon", name: "Polygon", symbol: "MATIC", explorer: "https://polygonscan.com" },
    { id: "solana", name: "Solana", symbol: "SOL", explorer: "https://explorer.solana.com" },
    { id: "tron", name: "TRON", symbol: "TRX", explorer: "https://tronscan.org" },
  ]);
  const [searchHistory, setSearchHistory] = useState<Array<{ input: string; chain: string; type: string; timestamp: number }>>([]);

  const handleSearch = useCallback(async () => {
    const input = searchInput.trim();
    if (!input) return;

    setLoading(true);
    setError(null);
    setAddressProfile(null);
    setTxDetail(null);
    setFundFlow(null);

    try {
      const detectResp = await fetch(`/api/blockchain/forensic/detect?input=${encodeURIComponent(input)}`);
      const detectData = await detectResp.json();

      let chain = selectedChain;
      let type: "address" | "transaction" = "address";

      if (detectData.detected) {
        if (!chain) chain = detectData.detected.chain;
        type = detectData.detected.type;
      }

      if (!chain) {
        setError("Could not detect blockchain. Please select a chain manually.");
        setLoading(false);
        return;
      }

      setSearchHistory(prev => [
        { input, chain, type, timestamp: Date.now() },
        ...prev.filter(h => h.input !== input).slice(0, 9),
      ]);

      if (type === "transaction") {
        const resp = await fetch(`/api/blockchain/forensic/trace/transaction/${encodeURIComponent(input)}?chain=${chain}`);
        if (!resp.ok) {
          const errData = await resp.json();
          throw new Error(errData.error || "Transaction not found");
        }
        const data = await resp.json();
        setTxDetail(data);
        setActiveTab("overview");
      } else {
        const resp = await fetch(`/api/blockchain/forensic/trace/address/${encodeURIComponent(input)}?chain=${chain}`);
        if (!resp.ok) {
          const errData = await resp.json();
          throw new Error(errData.error || "Address not found");
        }
        const data = await resp.json();
        setAddressProfile(data);
        setActiveTab("overview");
      }
    } catch (err: any) {
      setError(err.message || "Trace failed");
    } finally {
      setLoading(false);
    }
  }, [searchInput, selectedChain]);

  const handleTraceFundFlow = useCallback(async (direction: "forward" | "backward" = "forward") => {
    if (!addressProfile) return;
    setFlowLoading(true);
    setActiveTab("flow");
    try {
      const resp = await fetch("/api/blockchain/forensic/trace/flow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          address: addressProfile.address,
          chain: addressProfile.chain,
          depth: 2,
          direction,
        }),
      });
      if (!resp.ok) throw new Error("Flow trace failed");
      const data = await resp.json();
      setFundFlow(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setFlowLoading(false);
    }
  }, [addressProfile]);

  const handleAddressClick = useCallback((addr: string) => {
    setSearchInput(addr);
    if (addressProfile) setSelectedChain(addressProfile.chain);
    setTimeout(() => {
      handleSearch();
    }, 100);
  }, [addressProfile, handleSearch]);

  const riskScore = addressProfile?.riskIndicators
    ? Math.min(100, addressProfile.riskIndicators.reduce((s, r) => {
        const scores = { critical: 35, high: 20, medium: 10, low: 5 };
        return s + (scores[r.severity] || 0);
      }, 0))
    : 0;

  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex flex-col items-center mb-2">
            <img
              src="/forensic-phoenix-tiktok-bg2.png"
              alt="Alpha Phoenix Detective"
              className="w-56 h-56 md:w-72 md:h-72 object-contain mb-4 drop-shadow-[0_0_30px_rgba(0,212,255,0.4)]"
              data-testid="img-tracer-phoenix"
            />
            <div className="flex items-center gap-3">
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#00D4FF] to-[#FFD700] bg-clip-text text-transparent" style={{ fontFamily: "Orbitron, sans-serif" }}>
                Forensic Intelligence Engine™
              </h1>
            </div>
          </div>
          <p className="text-gray-400 text-sm max-w-2xl mx-auto">
            Powered by the Autonomous Blockchain Spider™ — Trace any address or transaction across
            multiple blockchains. Analyze fund flows, detect risk patterns, and follow the money trail.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#161B22] border border-gray-800 rounded-xl p-6 mb-6"
        >
          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-1 relative">
              <input
                data-testid="input-forensic-search"
                type="text"
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSearch()}
                placeholder="Enter wallet address or transaction hash..."
                className="w-full bg-[#0D1117] border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 font-mono text-sm focus:border-[#00D4FF] focus:outline-none transition-colors"
              />
              {searchInput && (
                <button
                  onClick={() => { setSearchInput(""); setAddressProfile(null); setTxDetail(null); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>

            <select
              data-testid="select-chain"
              value={selectedChain}
              onChange={e => setSelectedChain(e.target.value)}
              className="bg-[#0D1117] border border-gray-700 rounded-lg px-4 py-3 text-white text-sm focus:border-[#00D4FF] focus:outline-none min-w-[160px]"
            >
              <option value="">Auto-Detect Chain</option>
              {chains.map(c => (
                <option key={c.id} value={c.id}>
                  {CHAIN_ICONS[c.id]} {c.name} ({c.symbol})
                </option>
              ))}
            </select>

            <button
              data-testid="button-trace"
              onClick={handleSearch}
              disabled={loading || !searchInput.trim()}
              className="bg-gradient-to-r from-[#00D4FF] to-[#0066FF] text-white font-bold px-8 py-3 rounded-lg hover:opacity-90 disabled:opacity-50 transition-all flex items-center gap-2 whitespace-nowrap"
            >
              {loading ? (
                <>
                  <span className="animate-spin">⟳</span>
                  Tracing...
                </>
              ) : (
                <>🔍 Trace</>
              )}
            </button>
          </div>

          <div className="flex flex-wrap gap-2 mt-3">
            {chains.map(c => (
              <span
                key={c.id}
                className="text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1"
                style={{
                  borderColor: CHAIN_COLORS[c.id] + "40",
                  color: CHAIN_COLORS[c.id],
                  backgroundColor: CHAIN_COLORS[c.id] + "10",
                }}
              >
                {CHAIN_ICONS[c.id]} {c.name}
              </span>
            ))}
          </div>

          {searchHistory.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="text-[10px] text-gray-500 uppercase tracking-wider self-center">Recent:</span>
              {searchHistory.slice(0, 5).map((h, i) => (
                <button
                  key={i}
                  onClick={() => { setSearchInput(h.input); setSelectedChain(h.chain); }}
                  className="text-[10px] px-2 py-0.5 rounded bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 font-mono transition-colors"
                >
                  {CHAIN_ICONS[h.chain]} {shortenAddress(h.input, 6)}
                </button>
              ))}
            </div>
          )}
        </motion.div>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6 text-red-400 text-sm"
            >
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {txDetail && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-[#161B22] border border-gray-800 rounded-xl p-6 mb-6"
            >
              <div className="flex items-center gap-3 mb-4">
                <span className="text-2xl">{CHAIN_ICONS[txDetail.chain]}</span>
                <div>
                  <h2 className="text-lg font-bold" style={{ color: CHAIN_COLORS[txDetail.chain] }}>
                    {txDetail.chainName} Transaction
                  </h2>
                  <p className="text-gray-500 text-xs font-mono break-all">{txDetail.hash}</p>
                </div>
                <span className={`ml-auto px-2 py-1 rounded text-xs ${txDetail.confirmed ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                  {txDetail.confirmed ? "Confirmed" : "Pending"}
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 uppercase">Value</div>
                  <div className="text-lg font-bold text-white">{parseFloat(txDetail.value).toFixed(6)}</div>
                  {txDetail.valueUSD && <div className="text-xs text-green-400">${parseFloat(txDetail.valueUSD).toLocaleString()}</div>}
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 uppercase">Fee</div>
                  <div className="text-sm font-mono text-white">{txDetail.fee}</div>
                  {txDetail.feeUSD && <div className="text-xs text-gray-400">${parseFloat(txDetail.feeUSD).toFixed(2)}</div>}
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 uppercase">Block</div>
                  <div className="text-sm font-mono text-white">{txDetail.blockNumber?.toLocaleString() || "Pending"}</div>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[10px] text-gray-500 uppercase">Time</div>
                  <div className="text-sm text-white">{formatDate(txDetail.timestamp)}</div>
                </div>
              </div>

              <div className="bg-[#0D1117] rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-red-400 text-xs font-bold w-12">FROM</span>
                  <button
                    onClick={() => handleAddressClick(txDetail.from)}
                    className="font-mono text-sm text-[#00D4FF] hover:underline break-all"
                  >
                    {txDetail.from}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-green-400 text-xs font-bold w-12">TO</span>
                  <button
                    onClick={() => handleAddressClick(txDetail.to)}
                    className="font-mono text-sm text-[#00D4FF] hover:underline break-all"
                  >
                    {txDetail.to}
                  </button>
                </div>
              </div>

              {txDetail.internalTransactions.length > 0 && (
                <div className="mt-4">
                  <h3 className="text-sm font-bold text-gray-300 mb-2">Internal Transactions ({txDetail.internalTransactions.length})</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {txDetail.internalTransactions.map((itx, i) => (
                      <div key={i} className="bg-[#0D1117] rounded p-2 text-xs flex items-center gap-2">
                        <span className="font-mono text-gray-400">{shortenAddress(itx.from)}</span>
                        <span className="text-yellow-400">→ {parseFloat(itx.value).toFixed(6)}</span>
                        <span className="font-mono text-gray-400">{shortenAddress(itx.to)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {addressProfile && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <div className="bg-[#161B22] border border-gray-800 rounded-xl p-6 mb-6">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{CHAIN_ICONS[addressProfile.chain]}</span>
                    <div>
                      <h2 className="text-lg font-bold" style={{ color: CHAIN_COLORS[addressProfile.chain] }}>
                        {addressProfile.chainName} Address
                      </h2>
                      <p className="text-gray-500 text-xs font-mono break-all">{addressProfile.address}</p>
                    </div>
                  </div>

                  {riskScore > 0 && (
                    <div className={`ml-auto px-3 py-1 rounded-lg border text-sm font-bold ${
                      riskScore >= 60 ? "bg-red-500/20 border-red-500/40 text-red-400" :
                      riskScore >= 30 ? "bg-orange-500/20 border-orange-500/40 text-orange-400" :
                      "bg-yellow-500/20 border-yellow-500/40 text-yellow-400"
                    }`}>
                      Risk Score: {riskScore}/100
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="bg-[#0D1117] rounded-lg p-3">
                    <div className="text-[10px] text-gray-500 uppercase">Balance</div>
                    <div className="text-lg font-bold text-white">{parseFloat(addressProfile.balance).toFixed(6)}</div>
                    {addressProfile.balanceUSD && (
                      <div className="text-xs text-green-400">${parseFloat(addressProfile.balanceUSD).toLocaleString()}</div>
                    )}
                  </div>
                  <div className="bg-[#0D1117] rounded-lg p-3">
                    <div className="text-[10px] text-gray-500 uppercase">Total Received</div>
                    <div className="text-sm font-mono text-green-400">{parseFloat(addressProfile.totalReceived).toFixed(4)}</div>
                  </div>
                  <div className="bg-[#0D1117] rounded-lg p-3">
                    <div className="text-[10px] text-gray-500 uppercase">Total Sent</div>
                    <div className="text-sm font-mono text-red-400">{parseFloat(addressProfile.totalSent).toFixed(4)}</div>
                  </div>
                  <div className="bg-[#0D1117] rounded-lg p-3">
                    <div className="text-[10px] text-gray-500 uppercase">Transactions</div>
                    <div className="text-sm font-mono text-white">{addressProfile.transactionCount.toLocaleString()}</div>
                  </div>
                  <div className="bg-[#0D1117] rounded-lg p-3">
                    <div className="text-[10px] text-gray-500 uppercase">First Seen</div>
                    <div className="text-xs text-gray-300">{addressProfile.firstSeen ? formatDate(addressProfile.firstSeen) : "N/A"}</div>
                  </div>
                </div>
              </div>

              <div className="flex gap-1 mb-4 bg-[#161B22] rounded-lg p-1 border border-gray-800 overflow-x-auto">
                {(["overview", "transactions", "connections", "risks", "flow"] as const).map(tab => (
                  <button
                    key={tab}
                    data-testid={`tab-${tab}`}
                    onClick={() => {
                      setActiveTab(tab);
                      if (tab === "flow" && !fundFlow && !flowLoading) handleTraceFundFlow("forward");
                    }}
                    className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                      activeTab === tab
                        ? "bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    {tab === "overview" && "📊 Overview"}
                    {tab === "transactions" && `📝 Transactions (${addressProfile.transactions.length})`}
                    {tab === "connections" && `🔗 Connections (${addressProfile.connectedAddresses.length})`}
                    {tab === "risks" && `⚠️ Risk Analysis (${addressProfile.riskIndicators.length})`}
                    {tab === "flow" && "🌊 Fund Flow"}
                  </button>
                ))}
              </div>

              {activeTab === "overview" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                    <h3 className="text-sm font-bold text-gray-300 mb-3">Recent Transactions</h3>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                      {addressProfile.transactions.slice(0, 10).map((tx, i) => (
                        <div key={i} className="bg-[#0D1117] rounded-lg p-3 text-xs">
                          <div className="flex items-center justify-between mb-1">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              tx.direction === "incoming" ? "bg-green-500/20 text-green-400" :
                              tx.direction === "outgoing" ? "bg-red-500/20 text-red-400" :
                              "bg-gray-500/20 text-gray-400"
                            }`}>
                              {tx.direction.toUpperCase()}
                            </span>
                            <span className="text-gray-500">{formatDate(tx.timestamp)}</span>
                          </div>
                          <div className="font-mono text-[#00D4FF] truncate cursor-pointer hover:underline" onClick={() => { setSearchInput(tx.hash); handleSearch(); }}>
                            {shortenAddress(tx.hash, 10)}
                          </div>
                          <div className="flex justify-between mt-1">
                            <span className="text-gray-400">
                              {tx.direction === "outgoing" ? "To: " : "From: "}
                              <button
                                onClick={() => handleAddressClick(tx.direction === "outgoing" ? tx.to : tx.from)}
                                className="text-[#00D4FF] hover:underline font-mono"
                              >
                                {shortenAddress(tx.direction === "outgoing" ? tx.to : tx.from)}
                              </button>
                            </span>
                            <span className={`font-bold ${tx.direction === "incoming" ? "text-green-400" : "text-red-400"}`}>
                              {tx.direction === "incoming" ? "+" : "-"}{parseFloat(tx.value).toFixed(6)}
                            </span>
                          </div>
                          {tx.valueUSD && (
                            <div className="text-right text-gray-500">${parseFloat(tx.valueUSD).toLocaleString()}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-6">
                    {addressProfile.riskIndicators.length > 0 && (
                      <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                        <h3 className="text-sm font-bold text-gray-300 mb-3">Risk Indicators</h3>
                        <div className="space-y-2">
                          {addressProfile.riskIndicators.map((risk, i) => (
                            <div key={i} className={`rounded-lg p-3 border text-xs ${severityColor(risk.severity)}`}>
                              <div className="flex items-center gap-2">
                                <span className="font-bold uppercase text-[10px]">{risk.severity}</span>
                                <span>{risk.description}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                      <h3 className="text-sm font-bold text-gray-300 mb-3">Top Connections</h3>
                      <div className="space-y-2 max-h-[200px] overflow-y-auto">
                        {addressProfile.connectedAddresses.slice(0, 5).map((conn, i) => (
                          <div key={i} className="bg-[#0D1117] rounded-lg p-2 text-xs flex items-center justify-between">
                            <div>
                              <button
                                onClick={() => handleAddressClick(conn.address)}
                                className="font-mono text-[#00D4FF] hover:underline"
                              >
                                {shortenAddress(conn.address)}
                              </button>
                              <div className="text-gray-500 text-[10px]">{conn.transactionCount} txs</div>
                            </div>
                            <div className="text-right">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                                conn.relationship === "sent_to" ? "bg-red-500/20 text-red-400" :
                                conn.relationship === "received_from" ? "bg-green-500/20 text-green-400" :
                                "bg-purple-500/20 text-purple-400"
                              }`}>
                                {conn.relationship === "sent_to" ? "SENT TO" : conn.relationship === "received_from" ? "RECEIVED FROM" : "BIDIRECTIONAL"}
                              </span>
                              <div className="text-gray-400 mt-1">{parseFloat(conn.totalValue).toFixed(4)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "transactions" && (
                <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-gray-700 text-gray-400">
                          <th className="text-left py-2 px-2">Hash</th>
                          <th className="text-left py-2 px-2">Direction</th>
                          <th className="text-left py-2 px-2">From / To</th>
                          <th className="text-right py-2 px-2">Value</th>
                          <th className="text-right py-2 px-2">USD</th>
                          <th className="text-right py-2 px-2">Fee</th>
                          <th className="text-right py-2 px-2">Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {addressProfile.transactions.map((tx, i) => (
                          <tr key={i} className="border-b border-gray-800 hover:bg-gray-800/30">
                            <td className="py-2 px-2 font-mono text-[#00D4FF] cursor-pointer hover:underline" onClick={() => { setSearchInput(tx.hash); }}>
                              {shortenAddress(tx.hash, 8)}
                            </td>
                            <td className="py-2 px-2">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                tx.direction === "incoming" ? "bg-green-500/20 text-green-400" :
                                tx.direction === "outgoing" ? "bg-red-500/20 text-red-400" :
                                "bg-gray-500/20 text-gray-400"
                              }`}>{tx.direction.toUpperCase()}</span>
                            </td>
                            <td className="py-2 px-2">
                              <button
                                onClick={() => handleAddressClick(tx.direction === "outgoing" ? tx.to : tx.from)}
                                className="font-mono text-gray-300 hover:text-[#00D4FF]"
                              >
                                {shortenAddress(tx.direction === "outgoing" ? tx.to : tx.from)}
                              </button>
                            </td>
                            <td className={`py-2 px-2 text-right font-mono ${tx.direction === "incoming" ? "text-green-400" : "text-red-400"}`}>
                              {tx.direction === "incoming" ? "+" : "-"}{parseFloat(tx.value).toFixed(6)}
                            </td>
                            <td className="py-2 px-2 text-right text-gray-400">
                              {tx.valueUSD ? `$${parseFloat(tx.valueUSD).toLocaleString()}` : "-"}
                            </td>
                            <td className="py-2 px-2 text-right font-mono text-gray-500">{parseFloat(tx.fee).toFixed(6)}</td>
                            <td className="py-2 px-2 text-right text-gray-500 whitespace-nowrap">{formatDate(tx.timestamp)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === "connections" && (
                <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {addressProfile.connectedAddresses.map((conn, i) => (
                      <div key={i} className="bg-[#0D1117] rounded-lg p-3 border border-gray-800 hover:border-[#00D4FF]/30 transition-colors">
                        <div className="flex items-center justify-between mb-2">
                          <button
                            onClick={() => handleAddressClick(conn.address)}
                            className="font-mono text-sm text-[#00D4FF] hover:underline truncate max-w-[200px]"
                          >
                            {shortenAddress(conn.address, 8)}
                          </button>
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            conn.relationship === "sent_to" ? "bg-red-500/20 text-red-400" :
                            conn.relationship === "received_from" ? "bg-green-500/20 text-green-400" :
                            "bg-purple-500/20 text-purple-400"
                          }`}>
                            {conn.relationship === "sent_to" ? "SENT TO" : conn.relationship === "received_from" ? "RECEIVED" : "BOTH"}
                          </span>
                        </div>
                        <div className="text-xs text-gray-400 space-y-1">
                          <div className="flex justify-between">
                            <span>Total Value:</span>
                            <span className="text-white font-mono">{parseFloat(conn.totalValue).toFixed(6)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Transactions:</span>
                            <span className="text-white">{conn.transactionCount}</span>
                          </div>
                          {conn.firstInteraction && (
                            <div className="flex justify-between">
                              <span>First:</span>
                              <span className="text-gray-300">{formatDate(conn.firstInteraction)}</span>
                            </div>
                          )}
                          {conn.lastInteraction && (
                            <div className="flex justify-between">
                              <span>Last:</span>
                              <span className="text-gray-300">{formatDate(conn.lastInteraction)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "risks" && (
                <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                  {addressProfile.riskIndicators.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <div className="text-4xl mb-3">✅</div>
                      <p>No risk indicators detected for this address.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 mb-4">
                        <div className={`text-4xl font-bold ${
                          riskScore >= 60 ? "text-red-400" :
                          riskScore >= 30 ? "text-orange-400" :
                          "text-yellow-400"
                        }`}>{riskScore}/100</div>
                        <div>
                          <div className="text-sm font-bold text-gray-300">Composite Risk Score</div>
                          <div className="text-xs text-gray-500">Based on {addressProfile.riskIndicators.length} indicator(s)</div>
                        </div>
                        <div className="ml-auto">
                          <div className="w-48 h-3 bg-gray-800 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all ${
                                riskScore >= 60 ? "bg-red-500" :
                                riskScore >= 30 ? "bg-orange-500" :
                                "bg-yellow-500"
                              }`}
                              style={{ width: `${riskScore}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      {addressProfile.riskIndicators.map((risk, i) => (
                        <div key={i} className={`rounded-xl p-4 border ${severityColor(risk.severity)}`}>
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">
                              {risk.severity === "critical" ? "🚨" :
                               risk.severity === "high" ? "⚠️" :
                               risk.severity === "medium" ? "📋" : "ℹ️"}
                            </span>
                            <div>
                              <div className="font-bold text-sm uppercase">{risk.severity} — {risk.type.replace(/_/g, " ")}</div>
                              <div className="text-sm mt-1 opacity-80">{risk.description}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === "flow" && (
                <div className="bg-[#161B22] border border-gray-800 rounded-xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-gray-300">Fund Flow Trace</h3>
                    <div className="flex gap-2">
                      <button
                        data-testid="button-flow-forward"
                        onClick={() => handleTraceFundFlow("forward")}
                        disabled={flowLoading}
                        className="px-3 py-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 rounded hover:bg-green-500/30 disabled:opacity-50"
                      >
                        {flowLoading ? "Tracing..." : "→ Follow Outgoing"}
                      </button>
                      <button
                        data-testid="button-flow-backward"
                        onClick={() => handleTraceFundFlow("backward")}
                        disabled={flowLoading}
                        className="px-3 py-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded hover:bg-blue-500/30 disabled:opacity-50"
                      >
                        {flowLoading ? "Tracing..." : "← Follow Incoming"}
                      </button>
                    </div>
                  </div>

                  {flowLoading && (
                    <div className="text-center py-12 text-gray-500">
                      <div className="text-4xl animate-spin mb-3">🕸️</div>
                      <p>Autonomous Blockchain Spider™ is crawling...</p>
                      <p className="text-xs text-gray-600 mt-1">Tracing fund flow across multiple hops</p>
                    </div>
                  )}

                  {fundFlow && !flowLoading && (
                    <FundFlowVisualization graph={fundFlow} />
                  )}

                  {!fundFlow && !flowLoading && (
                    <div className="text-center py-12 text-gray-500">
                      <div className="text-4xl mb-3">🕸️</div>
                      <p>Click a direction to trace fund flow</p>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {!addressProfile && !txDetail && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8"
          >
            <div className="bg-[#161B22] border border-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-3">🔍</div>
              <h3 className="text-sm font-bold text-[#00D4FF] mb-2">Address Tracing</h3>
              <p className="text-xs text-gray-400">
                Enter any wallet address to see balance, transaction history,
                connected wallets, and risk analysis across 6 major blockchains.
              </p>
            </div>
            <div className="bg-[#161B22] border border-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-3">🕸️</div>
              <h3 className="text-sm font-bold text-[#FFD700] mb-2">Fund Flow Spider</h3>
              <p className="text-xs text-gray-400">
                Follow the money trail with multi-hop fund flow tracing.
                See where funds came from and where they went, up to 3 hops deep.
              </p>
            </div>
            <div className="bg-[#161B22] border border-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-3">⚠️</div>
              <h3 className="text-sm font-bold text-red-400 mb-2">Risk Detection</h3>
              <p className="text-xs text-gray-400">
                Automated risk scoring detects drain patterns, rapid fund movement,
                wallet splitting, dormant reactivation, and mixer usage.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
