import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const DAU_V1_ADDRESS = "0xAB403962C943e3335903824BB2880A219858C5CC";
const DAU_V2_ADDRESS = "0x875D639ffE58c39324256be7E388Fc85921c76AB";
const DAU_V2_DEPLOY_TX = "0xb8d0c7bc8b1b2bdcb336d6ca320e60440cd99b4f46176d358eb396b88760d3e2";
const DAU_V2_WALLETS_MINTED = 26;

interface WalletData {
  address: string;
  label: string;
  role: string;
  generation: number;
  riskScore: number;
  ethBalance?: string;
  lastActivity?: string;
  status: "active" | "dormant" | "liquidating" | "flagged";
}

interface Technique {
  id: string;
  name: string;
  derivedFrom: string;
  malwareSource: string;
  description: string;
  status: "active" | "ready" | "deployed";
  category: "persistence" | "propagation" | "detection" | "intelligence" | "disruption";
}

const TRACKED_WALLETS: WalletData[] = [
  { address: "0x8e04af7f7c76daa9ab429b1340e0327b5b835748", label: "Cashout Primary", role: "Primary cashout — processes stolen funds to exchanges", generation: 0, riskScore: 100, ethBalance: "1,634.45 ETH", lastActivity: "Apr 13 12:35 UTC", status: "liquidating" },
  { address: "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3", label: "HOP-4 Consolidation", role: "Post-exploit consolidation point", generation: 0, riskScore: 95, ethBalance: "0.00 ETH", lastActivity: "Apr 2 16:57 UTC", status: "dormant" },
  { address: "0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73", label: "OTC/Bridge Service", role: "OTC desk — converts ETH to USDT and routes to Binance", generation: 1, riskScore: 90, ethBalance: "Variable", lastActivity: "Apr 13 07:00 UTC", status: "active" },
  { address: "0x83d10e4698efb8a0bd3cafad6c950572905d5ca1", label: "Distribution EOA", role: "Automated small-batch distribution (auto-forwards via smart contract)", generation: 1, riskScore: 85, ethBalance: "0.00 ETH", lastActivity: "Apr 12 16:02 UTC", status: "active" },
  { address: "0x46af8e7a2ee01134d1757bc19607781dbd410e6b", label: "Circular Mixer", role: "4,280+ TXs — cycles funds in circular patterns back to Cashout", generation: 1, riskScore: 90, ethBalance: "0.22 ETH", lastActivity: "Apr 13 08:47 UTC", status: "active" },
  { address: "0x4d0f03b83650b33138764aaaf3da76861576ff98", label: "KYC Bridge Wallet", role: "Routes funds toward KYC exchange endpoints", generation: 2, riskScore: 80, ethBalance: "Variable", lastActivity: "Apr 10 10:12 UTC", status: "active" },
  { address: "0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a", label: "KYC Bridge Wallet 2", role: "Secondary KYC routing path", generation: 2, riskScore: 80, ethBalance: "Variable", lastActivity: "Apr 9 UTC", status: "active" },
  { address: "0x1f04378f94313421ed1faaf4f6415de722bea5ea", label: "Large-Value Intermediary", role: "Processes large-value transfers between cashout layers", generation: 1, riskScore: 85, ethBalance: "Variable", lastActivity: "Apr 7 UTC", status: "active" },
];

const TECHNIQUES: Technique[] = [
  { id: "t1", name: "Self-Propagating Dye Pack™", derivedFrom: "Mirai Botnet — Self-scanning propagation", malwareSource: "Mirai", description: "Auto-mints DAU v2 to every wallet that receives funds from a tracked address. The dye follows the money through unlimited hops — the entire laundering chain gets tagged.", status: "ready", category: "propagation" },
  { id: "t2", name: "Soulbound Persistence Lock™", derivedFrom: "Sub7/Rootkit — Registry persistence", malwareSource: "Sub7 RAT", description: "Token is permanently welded to the wallet. Cannot be removed, transferred, or burned by the holder. Not even the forensic authority can remove it in soulbound mode — it's there forever.", status: "ready", category: "persistence" },
  { id: "t3", name: "Anti-Removal Rebasing Engine™", derivedFrom: "Conficker — Anti-removal + self-repair", malwareSource: "Conficker", description: "The attacker's DAU v2 balance automatically GROWS over time without any transfer. Uses shares-based math — like a tattoo that gets bigger the longer you have it.", status: "ready", category: "persistence" },
  { id: "t4", name: "Behavioral Fingerprinting Matrix™", derivedFrom: "Keylogger — Keystroke pattern analysis", malwareSource: "Keyloggers", description: "Logs gas price patterns, transaction timing, block position preference, and nonce sequences. Builds a unique behavioral fingerprint that links 'different' wallets controlled by the same person.", status: "active", category: "intelligence" },
  { id: "t5", name: "Steganographic Amount Encoding™", derivedFrom: "Cobalt Strike — DNS tunneling / data exfiltration", malwareSource: "Cobalt Strike", description: "Embeds forensic metadata (case ID, generation, severity, timestamp) INTO the token transfer amounts. Looks like a normal amount but the last digits carry hidden intelligence.", status: "ready", category: "intelligence" },
  { id: "t6", name: "Dead Man's Switch Protocol™", derivedFrom: "Persistence mechanisms — anti-tamper", malwareSource: "Various APTs", description: "If the forensic authority doesn't send a heartbeat for 43,200 blocks (~6 days), the contract auto-dumps ALL tracking data as events. Can't be silenced even if the authority goes offline.", status: "ready", category: "disruption" },
  { id: "t7", name: "Canary Trap Deployment System™", derivedFrom: "Intelligence canary tokens / tripwires", malwareSource: "Canary Tokens", description: "Deploys invisible tripwire contracts at strategic addresses. Any interaction triggers alerts and auto-tags the interacting wallet. Like planting fake documents to catch spies.", status: "ready", category: "detection" },
  { id: "t8", name: "Predictive Address Targeting™ (DGA)", derivedFrom: "Conficker — Domain Generation Algorithm", malwareSource: "Conficker", description: "Uses CREATE2 math to predict where the attacker might deploy contracts next. Pre-registers those addresses for monitoring BEFORE the attacker gets there.", status: "ready", category: "detection" },
  { id: "t9", name: "Approval Surveillance System™", derivedFrom: "Zeus — Man-in-the-browser / Form grabbing", malwareSource: "Zeus", description: "Captures every DeFi approval the attacker makes — which DEXes, bridges, and protocols they authorize. Maps their entire DeFi infrastructure and exit strategy.", status: "active", category: "intelligence" },
  { id: "t10", name: "Honeypot Bait Mechanism™", derivedFrom: "Sub7 — Server stub / reverse connection", malwareSource: "Sub7 RAT", description: "The contract accepts ETH and immediately captures everything: sender address, gas price, tx.origin, timestamp, gas remaining. Auto-mints soulbound dye to anyone who touches it.", status: "ready", category: "detection" },
  { id: "t11", name: "Multi-Authority Resilient Control™", derivedFrom: "Mirai — Decentralized C2 infrastructure", malwareSource: "Mirai Botnet", description: "Multiple forensic authorities control the system. If one key is compromised, others maintain control. The system can't be taken down by targeting a single operator.", status: "ready", category: "persistence" },
  { id: "t12", name: "Flash Loan Atomic Detection™", derivedFrom: "MEV / DeFi exploit analysis", malwareSource: "DeFi Exploits", description: "Detects when tracked wallets use flash loans — the hallmark of sophisticated DeFi laundering. Logs the entire atomic transaction path for reconstruction.", status: "active", category: "detection" },
  { id: "t13", name: "Internal Transaction Tracer™", derivedFrom: "Rootkit — Hidden operations monitoring", malwareSource: "Rootkits", description: "Uses debug_traceTransaction to find HIDDEN value transfers inside contract calls. These don't show up in normal TX data — catches laundering through smart contracts.", status: "active", category: "intelligence" },
  { id: "t14", name: "Nonce Gap Analyzer™", derivedFrom: "Cobalt Strike — Covert channels / sleep patterns", malwareSource: "Cobalt Strike", description: "Monitors nonce sequences for gaps indicating the attacker uses private mempools (Flashbots Protect) to hide transactions from public view.", status: "active", category: "intelligence" },
  { id: "t15", name: "Temporal Timezone Deanonymizer™", derivedFrom: "Behavioral biometrics — activity pattern analysis", malwareSource: "Pegasus", description: "Analyzes transaction timing patterns to identify the attacker's timezone, sleep schedule, and activity patterns. Can narrow down geographic location.", status: "active", category: "intelligence" },
  { id: "t16", name: "Metamorphic Contract Detector™", derivedFrom: "Stuxnet — Modular payload architecture", malwareSource: "Stuxnet", description: "Detects CREATE2 + SELFDESTRUCT patterns where a contract self-destructs and redeploys different code at the same address. Used by sophisticated attackers to evolve their tools.", status: "active", category: "detection" },
  { id: "t17", name: "Common Input Clustering Engine™", derivedFrom: "Conficker — P2P network mapping", malwareSource: "Conficker", description: "When multiple wallets receive initial gas from the same funder, they're likely the same entity. Maps the attacker's full wallet network through funding patterns.", status: "active", category: "intelligence" },
  { id: "t18", name: "Address Poisoning Detector™", derivedFrom: "Phishing — Homoglyph attacks", malwareSource: "Phishing Kits", description: "Detects Unicode homoglyph tokens (fake USDT using Cyrillic Ѕ, etc.) planted in wallets for address confusion attacks. Catalogs all poison tokens with decoded impersonation targets.", status: "active", category: "detection" },
  { id: "t19", name: "Contract Storage Forensics™", derivedFrom: "Memory forensics — RAM analysis", malwareSource: "Volatility Framework", description: "Reads raw EVM storage slots from attacker contracts. Discovers hidden admin addresses, configuration values, and encoded parameters that aren't visible through normal interfaces.", status: "active", category: "intelligence" },
  { id: "t20", name: "Gas Behavioral Clustering™", derivedFrom: "Keystroke dynamics — typing pattern matching", malwareSource: "Keyloggers", description: "Groups wallets by gas price usage patterns. Same person using 'different' wallets gets linked because humans have consistent gas bidding behavior.", status: "active", category: "intelligence" },
  { id: "t21", name: "Precision Watchlist Engine™", derivedFrom: "Stuxnet — Zero-day precision targeting", malwareSource: "Stuxnet", description: "Loaded with 40+ addresses: 14 KYC exchanges, 5 Monero swap services, 8 bridge contracts, 6 mixer addresses, all with severity tiers. Auto-fires alerts on any interaction.", status: "ready", category: "detection" },
  { id: "t22", name: "Cross-Chain Exit Monitor™", derivedFrom: "Emotet — Lateral movement detection", malwareSource: "Emotet", description: "Monitors bridge contract interactions to detect when funds exit Ethereum. Logs bridge name, amount, and timestamp for cross-chain pursuit.", status: "active", category: "detection" },
  { id: "t23", name: "Token Holdings Spider™", derivedFrom: "Pegasus — Silent comprehensive data collection", malwareSource: "Pegasus", description: "Full portfolio scan of every tracked wallet — all ERC-20 tokens held, balances, metadata. Reveals hidden assets, DeFi positions, and token interactions.", status: "active", category: "intelligence" },
  { id: "t24", name: "Dormancy Trigger System™", derivedFrom: "APT29/SUNBURST — 12-14 day dormancy period", malwareSource: "APT29/SUNBURST", description: "SUNBURST waited 12-14 days before activating. This system detects when a dormant attacker wallet suddenly reactivates — fires high-priority alerts on dormancy breaks. Identifies wash cycle timing patterns.", status: "active", category: "detection" },
  { id: "t25", name: "Money Mule Identification Engine™", derivedFrom: "TrickBot/Carbanak — Mule coordination", malwareSource: "TrickBot", description: "Identifies wallets exhibiting classic money mule behavior: receive → hold briefly → forward. Calculates hold time, forward rate, and confidence score. All 3 core wallets flagged as mules with 95% confidence.", status: "active", category: "intelligence" },
  { id: "t26", name: "Evidence Chain Logger™", derivedFrom: "FinFisher — Court-admissible evidence grade", malwareSource: "FinFisher/FinSpy", description: "Creates sequential, immutable evidence entries with block hashes, timestamps, and integrity checksums. Every forensic observation is logged as court-admissible evidence with tamper-proof chain of custody.", status: "ready", category: "intelligence" },
  { id: "t27", name: "Network Topology Mapper™", derivedFrom: "Flame BeetleJuice — Bluetooth/network recon", malwareSource: "Flame", description: "Records directed edges in the wallet relationship graph on-chain. Maps the full topology of the attacker's fund flow network including intermediaries, mules, and exchange deposits.", status: "active", category: "intelligence" },
  { id: "t28", name: "Balance Snapshot Archiver™", derivedFrom: "Flame — Screenshot capture / surveillance", malwareSource: "Flame", description: "Takes periodic balance snapshots across all tracked wallets with block-level precision. Creates an immutable evidence timeline showing exactly when and how much funds moved.", status: "active", category: "intelligence" },
  { id: "t29", name: "EIP-7702 Delegation Monitor™", derivedFrom: "SUNBURST — Supply chain attack detection", malwareSource: "APT29/SUNBURST", description: "Specifically monitors for EIP-7702 delegate designation transactions — the exact attack vector used in the original exploit. Any wallet receiving delegation authority is auto-tracked at maximum severity.", status: "active", category: "detection" },
  { id: "t30", name: "Deployer Chain Tracer™", derivedFrom: "Olympic Destroyer — Propagation chain analysis", malwareSource: "Olympic Destroyer", description: "Traces the full contract creation chain: who deployed the deployer who deployed the mixer? Follows CREATE opcodes back to the ultimate EOA deployer. Reveals the attacker's contract infrastructure.", status: "active", category: "intelligence" },
  { id: "t31", name: "Bytecode Decompilation Engine™", derivedFrom: "Equation Group — Firmware reverse engineering", malwareSource: "Equation Group (NSA)", description: "Extracts function selectors from deployed contract bytecode. Identifies ERC-20/721 interfaces, proxy patterns, CREATE2/SELFDESTRUCT/DELEGATECALL opcodes. Reveals what attacker contracts can actually DO.", status: "active", category: "intelligence" },
  { id: "t32", name: "Deep Storage Forensics™", derivedFrom: "Regin — Multi-stage encrypted virtual filesystem", malwareSource: "Regin", description: "Reads raw EVM storage slots and decodes Solidity layouts: simple vars, mappings, dynamic arrays, structs. Discovers hidden admin addresses, encoded parameters, and configuration values invisible through normal interfaces.", status: "active", category: "intelligence" },
  { id: "t33", name: "ECDSA Signature Fingerprinting™", derivedFrom: "Equation Group — Cryptographic pattern analysis", malwareSource: "Equation Group (NSA)", description: "Extracts and fingerprints ECDSA signature components (v, r, s) from transactions. Creates unique cryptographic fingerprints that can link wallets sharing the same signing patterns — behavioral crypto-biometrics.", status: "ready", category: "intelligence" },
  { id: "t34", name: "Cross-Chain Bridge Detector™", derivedFrom: "Lazarus/APT38 — Multi-chain crypto theft", malwareSource: "Lazarus Group", description: "Database of 14+ bridge contracts (Wormhole, Stargate, Hop, THORChain, Across, Synapse, etc.). Detects all cross-chain exits with destination chains, amounts, and risk levels. THORChain/Monero flagged as CRITICAL.", status: "active", category: "detection" },
  { id: "t35", name: "Transaction Graph Centrality™", derivedFrom: "Carbanak — Financial network infiltration", malwareSource: "Carbanak APT", description: "Builds a directed transaction graph and calculates betweenness centrality for every node. Identifies the key intermediary wallets where ALL money flows converge — the highest-priority targets for freezing.", status: "active", category: "intelligence" },
  { id: "h1", name: "Sleeper Mule Predictor™ [HYBRID]", derivedFrom: "Dormancy (#24) + Mule ID (#25) + Temporal (#15)", malwareSource: "APT29 × TrickBot × Pegasus", description: "HYBRID FUSION: Combines dormancy cycle analysis with money mule detection and timezone deanonymization. A mule that goes dormant then wakes has a SCHEDULE. Predicts the exact time window for the next laundering batch. Cashout: active 6-7AM UTC = UK timezone. HOP-4: OVERDUE — could activate any moment.", status: "active", category: "detection" },
  { id: "h2", name: "Behavioral Composite Identity™ [HYBRID]", derivedFrom: "Gas (#20) + ECDSA (#33) + Nonce (#14) + Temporal (#15)", malwareSource: "Keyloggers × Equation Group × Cobalt Strike × Pegasus", description: "HYBRID FUSION: Four behavioral dimensions fused into ONE identity score. Gas patterns (40%) + ECDSA signatures (25%) + nonce gaps (20%) + timezone (30%). Any single signal is 30-50% confident. All four matching between two wallets = 95%+ same person. Mathematical certainty.", status: "active", category: "intelligence" },
  { id: "h3", name: "Predictive Exit Strategy Engine™ [HYBRID]", derivedFrom: "Approvals (#9) + Bridge (#34) + Dormancy (#24) + Snapshot (#28)", malwareSource: "Zeus × Lazarus × APT29 × Flame", description: "HYBRID FUSION: Approvals reveal WHERE. Dormancy reveals WHEN. Snapshots reveal HOW MUCH. Bridge detection reveals WHICH CHAIN. Combined = predict the attacker's next laundering move BEFORE it happens. Currently tracking 1,634 ETH in cashout wallet.", status: "active", category: "intelligence" },
  { id: "h4", name: "Contract DNA Profiler™ [HYBRID]", derivedFrom: "Bytecode (#31) + Storage (#32) + Deployer (#30) + Metamorphic (#16)", malwareSource: "Equation Group × Regin × Olympic Destroyer × Stuxnet", description: "HYBRID FUSION: Creates a unique 'coding DNA' for smart contracts. What functions, storage layout, deployment patterns, self-destruct capability. Same DNA hash = same developer. Links contracts deployed by the same attacker across chains.", status: "active", category: "intelligence" },
  { id: "h5", name: "Cross-Chain Identity Correlator™ [HYBRID]", derivedFrom: "Clustering (#17) + Bridge (#34) + Graph (#35) + ECDSA (#33)", malwareSource: "Conficker × Lazarus × Carbanak × Equation Group", description: "HYBRID FUSION: Follows identity ACROSS chains. Same funder + same bridge exits + same graph position + same signing patterns = same person on different chains. Creates identity clusters that survive cross-chain hops.", status: "active", category: "intelligence" },
  { id: "h6", name: "Flash Loan Laundering Reconstructor™ [HYBRID]", derivedFrom: "Flash Loan (#12) + Internal TX (#13) + Graph (#35) + Approvals (#9)", malwareSource: "DeFi × Rootkits × Carbanak × Zeus", description: "HYBRID FUSION: Detects flash loan usage, traces all internal calls, maps approval infrastructure, identifies the origin node. 13 suspected flash loans detected in cashout wallet — 5,500 ETH in single atomic TX with 22 internal calls. Circular flow confirmed.", status: "active", category: "detection" },
  { id: "h7", name: "Multi-Dimensional Mule Network Mapper™ [HYBRID]", derivedFrom: "Mule (#25) + Graph (#35) + Topology (#27) + Dormancy (#24)", malwareSource: "TrickBot × Carbanak × Flame × APT29", description: "HYBRID FUSION: Maps the ENTIRE mule network with roles. HUB-AND-SPOKE pattern confirmed: 0x9a72 (relay), 0x8e04 (distributor), 0xf576 (collector), 0x46af (direct-pipe). 4/5 wallets confirmed mules. Central node: OTC bridge service.", status: "active", category: "intelligence" },
  { id: "h8", name: "Forensic Time Machine™ [HYBRID]", derivedFrom: "Snapshot (#28) + Dormancy (#24) + Evidence (#26) + Token Spider (#23)", malwareSource: "Flame × APT29 × FinFisher × Pegasus", description: "HYBRID FUSION: Complete historical reconstruction across 2,468 days. 120 events logged, 34 critical. Every wallet's balance, activity state, and token holdings at every point in time. Full replay capability for court presentation.", status: "active", category: "intelligence" },
  { id: "h9", name: "Recursive Trap Network™ [HYBRID]", derivedFrom: "Honeypot (#10) + Canary (#7) + Propagation (#1) + Watchlist (#21)", malwareSource: "Sub7 × Canary Tokens × Mirai × Stuxnet", description: "HYBRID FUSION: Traps that spawn more traps. Touch one canary → propagation mints dye to all discovered wallets → each becomes a new honeypot → all added to watchlist. 3 initial targets expanded to 28 discovered wallets. 75% coverage. Ever-expanding trap field.", status: "active", category: "propagation" },
];

const BINANCE_DEPOSITS = [
  { date: "Apr 13", amount: "1,700 ETH + 600,000 USDT", via: "OTC/Bridge Service" },
  { date: "Apr 10", amount: "1,300 ETH", via: "OTC/Bridge Service" },
  { date: "Apr 7", amount: "1,600 ETH", via: "OTC/Bridge Service" },
  { date: "Apr 2", amount: "1,500 ETH", via: "OTC/Bridge Service" },
  { date: "Apr 1", amount: "6,000,000 USDT + 500,000 USDT", via: "OTC/Bridge Service" },
  { date: "Mar 31", amount: "1,500 ETH + 1,500,000 USDT", via: "OTC/Bridge Service" },
];

const categoryColors: Record<string, string> = {
  persistence: "#FF6B6B",
  propagation: "#4ECDC4",
  detection: "#FFE66D",
  intelligence: "#A78BFA",
  disruption: "#F97316",
};

const statusColors: Record<string, string> = {
  active: "#10B981",
  ready: "#3B82F6",
  deployed: "#8B5CF6",
  dormant: "#6B7280",
  liquidating: "#EF4444",
  flagged: "#F59E0B",
};

export default function DyePackProtocol() {
  const [activeTab, setActiveTab] = useState<"overview" | "wallets" | "techniques" | "binance" | "timeline">("overview");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [pulseFrame, setPulseFrame] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setPulseFrame(f => f + 1), 2000);
    return () => clearInterval(interval);
  }, []);

  const filteredTechniques = selectedCategory === "all"
    ? TECHNIQUES
    : TECHNIQUES.filter(t => t.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white" data-testid="dye-pack-protocol-page">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-red-900/20 via-transparent to-transparent" />
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-600 via-amber-500 to-red-600" />

        <div className="relative max-w-7xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-900/40 border border-red-500/30 rounded-full mb-4">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-red-400 text-xs font-mono tracking-wider">CLASSIFIED — FORENSIC INTELLIGENCE</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold font-['Orbitron'] mb-3">
              <span className="bg-gradient-to-r from-red-500 via-amber-400 to-red-500 bg-clip-text text-transparent">
                DAU v2 — DYE PACK PROTOCOL™
              </span>
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto text-sm">
              The most aggressive legal forensic tracking token ever built. 44 techniques (35 + 9 hybrids) derived from
              malware architecture analysis — all reimagined as lawful blockchain forensic tools.
            </p>
            <div className="flex justify-center gap-6 mt-4 text-xs font-mono text-gray-500">
              <span>Case: <span className="text-amber-400">{CASE_ID.slice(0, 8)}...</span></span>
              <span>DAU v1: <span className="text-green-400">{DAU_V1_ADDRESS.slice(0, 10)}...</span></span>
              <span>Wallets: <span className="text-red-400">{TRACKED_WALLETS.length} tracked</span></span>
              <span>Techniques: <span className="text-purple-400">{TECHNIQUES.length} active</span></span>
            </div>
          </div>

          <div className="flex gap-2 mb-6 overflow-x-auto pb-2" data-testid="dye-pack-tabs">
            {(["overview", "wallets", "techniques", "binance", "timeline"] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab
                    ? "bg-red-600/30 text-red-300 border border-red-500/40"
                    : "bg-gray-800/50 text-gray-400 border border-gray-700/30 hover:bg-gray-700/50"
                }`}
                data-testid={`tab-${tab}`}
              >
                {tab === "overview" && "Mission Overview"}
                {tab === "wallets" && `Tracked Wallets (${TRACKED_WALLETS.length})`}
                {tab === "techniques" && `Techniques (${TECHNIQUES.length})`}
                {tab === "binance" && "KYC Endpoint Intel"}
                {tab === "timeline" && "Attack Timeline"}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "overview" && (
              <motion.div key="overview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gradient-to-br from-red-900/30 to-red-950/30 border border-red-500/20 rounded-xl p-5">
                    <div className="text-red-400 text-xs font-mono mb-1">FUNDS REMAINING</div>
                    <div className="text-3xl font-bold text-white">1,634 ETH</div>
                    <div className="text-sm text-gray-400 mt-1">~$3.4M at current prices</div>
                    <div className="text-xs text-red-400 mt-2">Cashout wallet — active liquidation in progress</div>
                  </div>
                  <div className="bg-gradient-to-br from-amber-900/30 to-amber-950/30 border border-amber-500/20 rounded-xl p-5">
                    <div className="text-amber-400 text-xs font-mono mb-1">KYC ENDPOINT DEPOSITS</div>
                    <div className="text-3xl font-bold text-white">~$25M+</div>
                    <div className="text-sm text-gray-400 mt-1">To Binance Hot Wallet 14</div>
                    <div className="text-xs text-amber-400 mt-2">7,600+ ETH + 8.6M+ USDT in 2 weeks</div>
                  </div>
                  <div className="bg-gradient-to-br from-purple-900/30 to-purple-950/30 border border-purple-500/20 rounded-xl p-5">
                    <div className="text-purple-400 text-xs font-mono mb-1">CASHOUT NONCE</div>
                    <div className="text-3xl font-bold text-white">33,499</div>
                    <div className="text-sm text-gray-400 mt-1">Total transactions sent</div>
                    <div className="text-xs text-purple-400 mt-2">Active since Jan 2019 — 2,638 days</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-5">
                    <h3 className="text-lg font-bold text-white mb-3 font-['Orbitron']">Malware Architecture Sources</h3>
                    <div className="space-y-2">
                      {[
                        { name: "Sub7 RAT", technique: "Honeypot bait + Persistence", color: "#FF6B6B" },
                        { name: "Mirai Botnet", technique: "Self-propagation + Multi-authority", color: "#4ECDC4" },
                        { name: "Zeus Trojan", technique: "Approval surveillance", color: "#FFE66D" },
                        { name: "Stuxnet", technique: "Precision watchlists + Modular payloads", color: "#A78BFA" },
                        { name: "Conficker", technique: "DGA addressing + Anti-removal rebasing", color: "#F97316" },
                        { name: "Emotet", technique: "Cross-chain lateral movement", color: "#EC4899" },
                        { name: "Cobalt Strike", technique: "Steganographic amounts + Nonce analysis", color: "#06B6D4" },
                        { name: "Pegasus (NSO)", technique: "Silent data collection + Token spider", color: "#84CC16" },
                        { name: "Keyloggers", technique: "Gas/timing behavioral fingerprinting", color: "#F59E0B" },
                      ].map(m => (
                        <div key={m.name} className="flex items-center gap-3 text-sm">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: m.color }} />
                          <span className="text-white font-medium w-28">{m.name}</span>
                          <span className="text-gray-400">→ {m.technique}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-5">
                    <h3 className="text-lg font-bold text-white mb-3 font-['Orbitron']">Technique Categories</h3>
                    <div className="space-y-3">
                      {Object.entries(categoryColors).map(([cat, color]) => {
                        const count = TECHNIQUES.filter(t => t.category === cat).length;
                        return (
                          <div key={cat} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
                              <span className="text-white capitalize text-sm">{cat}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="h-2 rounded-full bg-gray-800" style={{ width: 120 }}>
                                <div
                                  className="h-full rounded-full transition-all"
                                  style={{ width: `${(count / TECHNIQUES.length) * 100}%`, backgroundColor: color }}
                                />
                              </div>
                              <span className="text-gray-400 text-xs w-6 text-right">{count}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-700/30">
                      <div className="text-xs text-gray-500 mb-2">DAU v2 MAINNET DEPLOYMENT</div>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                        <span className="text-green-400 text-xs font-bold">LIVE ON ETHEREUM MAINNET</span>
                      </div>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between"><span className="text-gray-400">Contract</span><a href={`https://etherscan.io/address/${DAU_V2_ADDRESS}`} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{DAU_V2_ADDRESS.slice(0,6)}...{DAU_V2_ADDRESS.slice(-4)}</a></div>
                        <div className="flex justify-between"><span className="text-gray-400">Wallets Tagged</span><span className="text-amber-400 font-bold">{DAU_V2_WALLETS_MINTED}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Confidence</span><span className="text-green-400">65%+ threshold</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Failures</span><span className="text-green-400">0</span></div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-700/30">
                      <div className="text-xs text-gray-500 mb-2">CONTRACT STATUS</div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex justify-between"><span className="text-gray-400">Soulbound Mode</span><span className="text-green-400">ENABLED</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Rebasing</span><span className="text-green-400">READY</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Self-Propagation</span><span className="text-green-400">ACTIVE</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Watchlist</span><span className="text-green-400">ARMED</span></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-red-900/20 border border-red-500/20 rounded-xl p-5">
                  <h3 className="text-lg font-bold text-red-400 mb-2 font-['Orbitron']">LEGAL NOTICE</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    ALL techniques in the DAU v2 Dye Pack Protocol use only public blockchain data and standard EVM operations.
                    No private keys are accessed. No unauthorized modifications are made. No systems are compromised.
                    Every technique is the legal equivalent of putting a tracking dye in stolen currency — visible, persistent,
                    and admissible as evidence. The attacker cannot remove the dye without abandoning the wallet entirely,
                    and even then, their behavioral fingerprint follows them.
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "wallets" && (
              <motion.div key="wallets" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="space-y-3">
                  {TRACKED_WALLETS.map((w, i) => (
                    <div
                      key={w.address}
                      className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-4 hover:border-red-500/30 transition-all"
                      data-testid={`wallet-card-${i}`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: statusColors[w.status] }} />
                            <span className="font-bold text-white">{w.label}</span>
                            <span className="text-xs px-2 py-0.5 rounded-full" style={{
                              backgroundColor: `${statusColors[w.status]}20`,
                              color: statusColors[w.status],
                              border: `1px solid ${statusColors[w.status]}40`,
                            }}>
                              {w.status.toUpperCase()}
                            </span>
                            <span className="text-xs text-gray-500">Gen {w.generation}</span>
                          </div>
                          <div className="font-mono text-xs text-gray-400 mb-1">{w.address}</div>
                          <div className="text-sm text-gray-300">{w.role}</div>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="text-right">
                            <div className="text-xs text-gray-500">Balance</div>
                            <div className="text-white font-mono">{w.ethBalance || "—"}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-gray-500">Risk</div>
                            <div className="font-bold" style={{ color: w.riskScore >= 90 ? "#EF4444" : w.riskScore >= 70 ? "#F59E0B" : "#10B981" }}>
                              {w.riskScore}/100
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-gray-500">Last Activity</div>
                            <div className="text-gray-300 text-xs">{w.lastActivity || "—"}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 bg-amber-900/20 border border-amber-500/20 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                    <span className="text-amber-400 font-bold text-sm">NEW DISCOVERY — Apr 13</span>
                  </div>
                  <div className="text-sm text-gray-300">
                    <span className="font-mono text-amber-300">0x2364ab81...dff1</span> — New feeder wallet sending 700 ETH to Cashout today (4x150 + 250 ETH batches)
                  </div>
                  <div className="text-sm text-gray-300 mt-1">
                    <span className="font-mono text-amber-300">0xfa7eefb7...c39b</span> — 44,240 USDT inflow to Cashout today
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "techniques" && (
              <motion.div key="techniques" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="flex gap-2 mb-4 flex-wrap">
                  <button
                    onClick={() => setSelectedCategory("all")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium ${selectedCategory === "all" ? "bg-white/10 text-white" : "bg-gray-800/50 text-gray-400"}`}
                    data-testid="filter-all"
                  >
                    All ({TECHNIQUES.length})
                  </button>
                  {Object.entries(categoryColors).map(([cat, color]) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${selectedCategory === cat ? "text-white" : "text-gray-400"}`}
                      style={selectedCategory === cat ? { backgroundColor: `${color}30`, border: `1px solid ${color}50` } : { backgroundColor: "rgba(31,41,55,0.5)" }}
                      data-testid={`filter-${cat}`}
                    >
                      {cat} ({TECHNIQUES.filter(t => t.category === cat).length})
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredTechniques.map((t, i) => (
                    <motion.div
                      key={t.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-4 hover:border-gray-600/50 transition-all"
                      data-testid={`technique-card-${t.id}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: categoryColors[t.category] }} />
                          <span className="font-bold text-white text-sm">{t.name}</span>
                        </div>
                        <span className="text-xs px-2 py-0.5 rounded-full" style={{
                          backgroundColor: `${statusColors[t.status]}20`,
                          color: statusColors[t.status],
                        }}>
                          {t.status}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 mb-2">
                        Derived from: <span className="text-gray-400">{t.derivedFrom}</span>
                      </div>
                      <p className="text-xs text-gray-300 leading-relaxed">{t.description}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === "binance" && (
              <motion.div key="binance" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="bg-gray-900/50 border border-red-500/20 rounded-xl p-5 mb-4">
                  <h3 className="text-lg font-bold text-red-400 mb-1 font-['Orbitron']">KYC ENDPOINT: Binance Hot Wallet 14</h3>
                  <div className="font-mono text-xs text-gray-400 mb-3">0x28c6c06298d514db089934071355e5743bf21d60</div>
                  <p className="text-sm text-gray-300 mb-4">
                    ALL OTC flows from the stolen funds terminate at this Binance hot wallet. This is the critical
                    subpoena target — Binance holds KYC records for the account depositing these funds.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                    <div className="bg-red-900/20 border border-red-500/10 rounded-lg p-3">
                      <div className="text-xs text-red-400 mb-1">ETH Deposited (2 weeks)</div>
                      <div className="text-2xl font-bold text-white">7,600+ ETH</div>
                    </div>
                    <div className="bg-red-900/20 border border-red-500/10 rounded-lg p-3">
                      <div className="text-xs text-red-400 mb-1">USDT Deposited (2 weeks)</div>
                      <div className="text-2xl font-bold text-white">8.6M+ USDT</div>
                    </div>
                    <div className="bg-red-900/20 border border-red-500/10 rounded-lg p-3">
                      <div className="text-xs text-red-400 mb-1">Via OTC Wallet</div>
                      <div className="text-lg font-bold text-white font-mono">0x9a7226c3...ba73</div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-5">
                  <h3 className="text-lg font-bold text-white mb-3 font-['Orbitron']">Deposit Timeline</h3>
                  <div className="space-y-3">
                    {BINANCE_DEPOSITS.map((d, i) => (
                      <div key={i} className="flex items-center gap-4 text-sm" data-testid={`binance-deposit-${i}`}>
                        <div className="w-20 text-gray-500 font-mono text-xs">{d.date}</div>
                        <div className="w-2 h-2 rounded-full bg-red-500" />
                        <div className="flex-1 text-white font-medium">{d.amount}</div>
                        <div className="text-gray-400 text-xs">via {d.via}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "timeline" && (
              <motion.div key="timeline" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="bg-gray-900/50 border border-gray-700/30 rounded-xl p-5">
                  <h3 className="text-lg font-bold text-white mb-4 font-['Orbitron']">EIP-7702 Exploit — Full Attack Timeline</h3>
                  <div className="space-y-4">
                    {[
                      { date: "~Jan 2019", event: "Cashout wallet first activated", detail: "Wallet 0x8e04...5748 sends first transaction. This is NOT a fresh wallet — it's established infrastructure with 33,499 total transactions.", severity: "info" },
                      { date: "Jun 2025", event: "HOP-4 wallet activated", detail: "0xf576...59f3 begins consolidation activity. First outbound transaction Jun 27, 2025.", severity: "info" },
                      { date: "Early 2026", event: "EIP-7702 exploit executed against @sillytuna", detail: "~$26M drained via delegate designation attack. Funds flow through multi-hop laundering chain.", severity: "critical" },
                      { date: "Mar 31", event: "Mass Binance deposits begin", detail: "1,500 ETH + 1.5M USDT sent to Binance HW14. Liquidation phase accelerates.", severity: "critical" },
                      { date: "Apr 1", event: "Massive USDT dump to Binance", detail: "6,000,000 USDT + 500,000 USDT deposited to Binance HW14 in single day.", severity: "critical" },
                      { date: "Apr 2", event: "DAU v1 deployed as tracking beacon", detail: `Contract ${DAU_V1_ADDRESS} deployed on mainnet. Minted to victim and attacker wallets.`, severity: "action" },
                      { date: "Apr 6-7", event: "Continued ETH liquidation", detail: "1,600 ETH (Apr 7) and additional batches routed through OTC to Binance.", severity: "critical" },
                      { date: "Apr 9-11", event: "Automated cashout batches detected", detail: "Repeated ~$1K USDC transfers via 0x83d1 smart contract auto-forward. Circular mixer 0x46af cycling funds.", severity: "warning" },
                      { date: "Apr 11", event: "Address poisoning attacks detected", detail: "Unicode phishing tokens sent to attacker wallets -- someone else is also targeting them.", severity: "info" },
                      { date: "Apr 13", event: "DAU v2 Dye Pack deployed to mainnet", detail: `Contract ${DAU_V2_ADDRESS} deployed. Lite contract with soulbound + self-propagation + rebasing + watchlist. Minted to ${DAU_V2_WALLETS_MINTED} wallets at 65%+ confidence. Includes mule wallets, address-similarity matches, and direct fund flow recipients.`, severity: "action" },
                      { date: "Apr 13", event: "Full back-trace completed", detail: "218 wallets discovered from victim (3 hops deep). 178 active, 5 Monero swappers, 9 exchange depositors. 26 wallets above 65% confidence threshold -- all tagged.", severity: "critical" },
                      { date: "Apr 13", event: "DAU v2 Hybrid Fusion Engine — 44 total techniques", detail: "35 base techniques + 9 HYBRID FUSIONS. Hybrids cross-pollinate 2-4 parent techniques into something more powerful: Sleeper Mule Predictor (APT29×TrickBot×Pegasus), Behavioral Composite Identity (4-dimensional), Predictive Exit Strategy (Zeus×Lazarus×APT29×Flame), Contract DNA Profiler (Equation Group×Regin×Olympic Destroyer×Stuxnet), Cross-Chain Identity Correlator, Flash Loan Reconstructor, Mule Network Mapper, Forensic Time Machine, Recursive Trap Network.", severity: "action" },
                      { date: "Apr 13", event: "New feeder wallet discovered", detail: "0x2364ab81...dff1 sends 700 ETH to Cashout (4x150 + 250 batches). New infrastructure.", severity: "warning" },
                      { date: "Apr 13", event: "Live scan: 1,700 ETH + 600K USDT to Binance", detail: "Cashout continues active liquidation. 1,634 ETH (~$3.4M) still remaining in wallet.", severity: "critical" },
                    ].map((e, i) => (
                      <div key={i} className="flex gap-4" data-testid={`timeline-event-${i}`}>
                        <div className="flex flex-col items-center">
                          <div className={`w-3 h-3 rounded-full ${
                            e.severity === "critical" ? "bg-red-500" :
                            e.severity === "warning" ? "bg-amber-500" :
                            e.severity === "action" ? "bg-green-500" : "bg-blue-500"
                          }`} />
                          {i < 11 && <div className="w-px h-full bg-gray-700 mt-1" />}
                        </div>
                        <div className="pb-4">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-mono text-gray-500">{e.date}</span>
                            <span className={`text-xs px-1.5 py-0.5 rounded ${
                              e.severity === "critical" ? "bg-red-900/30 text-red-400" :
                              e.severity === "warning" ? "bg-amber-900/30 text-amber-400" :
                              e.severity === "action" ? "bg-green-900/30 text-green-400" : "bg-blue-900/30 text-blue-400"
                            }`}>
                              {e.severity}
                            </span>
                          </div>
                          <div className="text-sm font-medium text-white">{e.event}</div>
                          <div className="text-xs text-gray-400 mt-0.5">{e.detail}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
