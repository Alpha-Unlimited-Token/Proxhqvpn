/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Futures Trading Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Futures Trading Engine™
 * - Leverage Control System™
 * - Position Management Protocol™
 * - Risk Liquidation Monitor™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_f53d1b39a5128d196888a8b5
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { CollapsibleSection } from "@/components/CollapsibleSection";
import { motion } from "framer-motion";
import {
  TrendingUp,
  Zap,
  Shield,
  Crown,
  CheckCircle,
  X,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  DollarSign,
  BarChart3,
  Clock,
  Award,
  Target,
  Layers,
  Wheat,
  Fuel,
  Bitcoin,
  Globe,
  Star,
  Users,
  Sparkles,
} from "lucide-react";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    priceLabel: "Forever Free",
    badge: "No Other Prop Firm Offers This",
    badgeColor: "bg-green-500/20 text-green-400 border-green-500/30",
    highlight: false,
    contracts: 10,
    account: "$25,000",
    profitSplit: "80%",
    payout: "N/A (Simulated)",
    maxPayout: "N/A",
    payoutFreq: "N/A",
    instruments: "3 instruments",
    timeLimit: "No time limit",
    consistencyRule: "None",
    techIncluded: "Basic tools",
    support: "Community",
    features: [
      "10 contracts from day 1",
      "$25,000 simulated account",
      "3 tradable instruments",
      "No time limit ever",
      "80% profit split",
      "Real market data",
      "Basic charting tools",
      "Practice risk-free",
    ],
  },
  {
    id: "standard",
    name: "Standard",
    price: 49,
    priceLabel: "$49/mo",
    badge: "Most Popular",
    badgeColor: "bg-[#00D4FF]/20 text-[#00D4FF] border-[#00D4FF]/30",
    highlight: false,
    contracts: 25,
    account: "$100,000",
    profitSplit: "85%",
    payout: "Weekly",
    maxPayout: "$25,000",
    payoutFreq: "Weekly",
    instruments: "All CME Group",
    timeLimit: "No time limit",
    consistencyRule: "Standard",
    techIncluded: "10 technologies",
    support: "Email + Chat",
    features: [
      "25 contracts",
      "$100,000 funded account",
      "All CME Group products",
      "85% profit split",
      "Weekly payouts",
      "$25,000 max payout",
      "No time limit",
      "10 proprietary technologies",
    ],
  },
  {
    id: "advanced",
    name: "Advanced",
    price: 89,
    priceLabel: "$89/mo",
    badge: "Best Value",
    badgeColor: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    highlight: true,
    contracts: 50,
    account: "$250,000",
    profitSplit: "90%",
    payout: "Daily",
    maxPayout: "$50,000",
    payoutFreq: "Daily available",
    instruments: "All CME + Crypto",
    timeLimit: "No time limit",
    consistencyRule: "None",
    techIncluded: "15 technologies",
    support: "Priority",
    features: [
      "50 contracts (3x their max!)",
      "$250,000 funded account",
      "90% profit split from day 1",
      "Daily payouts available",
      "$50,000 max payout",
      "No consistency rule",
      "15 proprietary technologies",
      "Priority support",
    ],
  },
  {
    id: "alpha",
    name: "Alpha",
    price: 149,
    priceLabel: "$149/mo",
    badge: "Ultimate",
    badgeColor: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    highlight: false,
    contracts: 100,
    account: "$500,000",
    profitSplit: "95%",
    payout: "Same-day",
    maxPayout: "$100,000",
    payoutFreq: "Same-day",
    instruments: "All markets",
    timeLimit: "No time limit",
    consistencyRule: "None",
    techIncluded: "All 20 technologies",
    support: "Priority + Dedicated",
    features: [
      "100 contracts (7x their max!)",
      "$500,000 funded account",
      "95% profit split",
      "Same-day payouts",
      "$100,000 max payout",
      "No consistency rule",
      "All 20 proprietary technologies",
      "Priority + dedicated support",
    ],
  },
];

const COMPETITOR_COMPARISON = [
  { feature: "Starting Contracts", us: "10 (Free) – 100", them: "5–6" },
  { feature: "Max Contracts", us: "100", them: "15" },
  { feature: "Cheapest Plan", us: "FREE ($0)", them: "$79/mo" },
  { feature: "Max Account Size", us: "$500,000", them: "$450,000 (3 accts)" },
  { feature: "Profit Split", us: "80–95%", them: "70–90%" },
  { feature: "Max Single Payout", us: "$100,000", them: "$15,000" },
  { feature: "Payout Speed", us: "Same-day", them: "Weekly" },
  { feature: "Consistency Rule", us: "None (Advanced+)", them: "Required" },
  { feature: "Time Limit", us: "None", them: "Varies" },
  { feature: "Proprietary Tech", us: "20 technologies", them: "0" },
  { feature: "Free Tier", us: "Yes", them: "No" },
];

const INSTRUMENTS = [
  {
    category: "Equity Indices",
    icon: BarChart3,
    color: "text-blue-400",
    items: ["E-mini S&P 500 (ES)", "E-mini NASDAQ-100 (NQ)", "E-mini Dow (YM)", "E-mini Russell 2000 (RTY)", "Micro E-mini S&P 500 (MES)", "Micro E-mini NASDAQ (MNQ)"],
  },
  {
    category: "Commodities",
    icon: Fuel,
    color: "text-orange-400",
    items: ["Crude Oil (CL)", "Natural Gas (NG)", "Gold (GC)", "Silver (SI)", "Copper (HG)", "Platinum (PL)"],
  },
  {
    category: "Crypto Futures",
    icon: Bitcoin,
    color: "text-yellow-400",
    items: ["Bitcoin (BTC)", "Micro Bitcoin (MBT)", "Ethereum (ETH)", "Micro Ethereum (MET)"],
  },
  {
    category: "Forex Futures",
    icon: Globe,
    color: "text-green-400",
    items: ["Euro FX (6E)", "Japanese Yen (6J)", "British Pound (6B)", "Australian Dollar (6A)", "Canadian Dollar (6C)", "Swiss Franc (6S)"],
  },
  {
    category: "Agriculture",
    icon: Wheat,
    color: "text-amber-400",
    items: ["Corn (ZC)", "Soybeans (ZS)", "Wheat (ZW)", "Live Cattle (LE)", "Lean Hogs (HE)", "Cotton (CT)"],
  },
  {
    category: "Interest Rates",
    icon: TrendingUp,
    color: "text-cyan-400",
    items: ["10-Year T-Note (ZN)", "30-Year T-Bond (ZB)", "5-Year T-Note (ZF)", "2-Year T-Note (ZT)", "Eurodollar (GE)"],
  },
];

const STEPS = [
  {
    step: 1,
    title: "Choose Your Plan",
    description: "Select a plan that fits your trading style. Start free with 10 contracts or go all-in with the Alpha tier at 100 contracts and a $500K account.",
    icon: Target,
  },
  {
    step: 2,
    title: "Pass the Evaluation",
    description: "Trade in a simulated environment with real market data. Hit the profit target while staying within the drawdown limits. No time limit — trade at your pace.",
    icon: BarChart3,
  },
  {
    step: 3,
    title: "Get Funded & Paid",
    description: "Once you pass, trade with a funded account and keep up to 95% of your profits. Payouts as fast as same-day with the Alpha tier.",
    icon: DollarSign,
  },
];

const FAQ_ITEMS = [
  {
    question: "How does the free tier work?",
    answer: "The free tier gives you 10 contracts and a $25,000 simulated account with no time limit. You can practice with real market data and keep 80% of simulated profits. It's designed to let you prove your skills before committing any money — no other prop firm offers this.",
  },
  {
    question: "What is the evaluation process?",
    answer: "You trade in a simulated environment with real market data. Each plan has specific profit targets and maximum drawdown limits. There's no time limit — you can take as long as you need to pass. Once you hit the target while staying within drawdown limits, you move to a funded account.",
  },
  {
    question: "How do payouts work?",
    answer: "Payout frequency depends on your plan: Standard gets weekly payouts, Advanced gets daily payouts, and Alpha gets same-day payouts. Maximum single payout ranges from $25,000 (Standard) to $100,000 (Alpha). We process payouts via bank transfer, crypto, or PayPal.",
  },
  {
    question: "What is the consistency rule?",
    answer: "Many prop firms require a 'consistency rule' where no single day can account for more than a certain percentage of your total profits. We eliminate this restriction on Advanced and Alpha tiers — trade your style without artificial constraints.",
  },
  {
    question: "Can I trade any futures contract?",
    answer: "Standard and above plans have access to all CME Group products including equity indices (ES, NQ, YM), commodities (CL, GC, NG), forex futures, crypto futures, agriculture, and interest rates. The free tier includes 3 instruments to get started.",
  },
  {
    question: "What are the 20 proprietary technologies?",
    answer: "Our Alpha tier includes all 20 proprietary technologies: ACM™, QFRM™, BIF™, SBPE™, ANCE™, ANCE²™, TMDE™, QMGE™, Bridge Fusion™, Trading Probability Calculator™, Alpha Sentinel™, Prob Calc™, plus 8 Advanced Market Filters™ (OFI, FVG, ABS, FE, WYK, ENT, HUR, DD). These technologies are exclusive to Alpha Unlimited and give you an edge no other prop firm can match.",
  },
  {
    question: "How does Alpha Unlimited compare to Alpha Futures Trading?",
    answer: "We beat them in every category: more contracts (100 vs 15 max), lower fees (free tier vs $79 minimum), higher payouts ($100K vs $15K), better profit split (95% vs 90%), faster payouts (same-day vs weekly), no consistency rules, no time limits, and 20 proprietary technologies they simply don't have.",
  },
];

export default function FuturesContracts() {
  const [selectedPlan, setSelectedPlan] = useState("advanced");
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    document.title = "Futures Contracts - Alpha Unlimited Trading";
  }, []);

  return (
    <TradingPlatformLayout>
      <section className="relative py-20 sm:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#00D4FF]/5 via-transparent to-transparent" />
        <div className="absolute inset-0">
          <div className="absolute top-20 left-1/4 w-96 h-96 bg-[#00D4FF]/5 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
        </div>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#00D4FF]/10 border border-[#00D4FF]/30 rounded-full mb-6">
              <Zap size={16} className="text-[#00D4FF]" />
              <span className="text-[#00D4FF] font-semibold text-sm uppercase tracking-wider">Futures Prop Trading</span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 leading-tight" data-testid="text-hero-title">
              More Contracts. Lower Fees.
              <br />
              <span className="text-[#00D4FF]">Higher Payouts.</span>
            </h1>
            <p className="text-[#94A3B8] text-lg sm:text-xl max-w-3xl mx-auto mb-8">
              Alpha Unlimited doesn't just compete — we dominate. Start free with 10 contracts, scale to 100, and keep up to 95% of your profits. No other prop firm comes close.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 mb-10">
              {[
                { label: "100 Max Contracts", icon: TrendingUp },
                { label: "95% Profit Split", icon: DollarSign },
                { label: "$100K Max Payout", icon: Award },
                { label: "Same-Day Payouts", icon: Clock },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2 text-sm text-[#94A3B8]">
                  <item.icon size={16} className="text-[#00D4FF]" />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
            <a href="#pricing">
              <button
                className="px-10 py-4 bg-[#00D4FF] hover:bg-[#00B8E0] text-[#0A1628] font-semibold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg shadow-[#00D4FF]/25"
                data-testid="button-view-plans"
              >
                View Plans & Pricing
              </button>
            </a>
          </motion.div>
        </div>
      </section>

      <section id="pricing" className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Choose Your <span className="text-[#00D4FF]">Trading Plan</span>
            </h2>
            <p className="text-[#94A3B8] max-w-2xl mx-auto">
              Every plan beats the competition. Start free and scale up as you grow.
            </p>
          </motion.div>

          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {PLANS.map((plan) => (
              <button
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  selectedPlan === plan.id
                    ? "bg-[#00D4FF] text-[#0A1628]"
                    : "bg-[#152238] text-[#94A3B8] hover:bg-[#1E3A5F] hover:text-white"
                }`}
                data-testid={`button-plan-tab-${plan.id}`}
              >
                {plan.name} {plan.price > 0 ? `$${plan.price}/mo` : "(Free)"}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {PLANS.map((plan, i) => (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`relative rounded-2xl border p-6 transition-all ${
                  selectedPlan === plan.id
                    ? "border-[#00D4FF]/60 bg-gradient-to-b from-[#00D4FF]/10 to-[#0A1628] shadow-lg shadow-[#00D4FF]/10 scale-[1.02]"
                    : "border-[#152238] bg-[#0D1117] hover:border-[#1E3A5F]"
                }`}
                data-testid={`card-plan-${plan.id}`}
              >
                {plan.badge && (
                  <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold border ${plan.badgeColor}`}>
                    {plan.badge}
                  </div>
                )}
                <div className="text-center mt-2 mb-6">
                  <h3 className="text-xl font-bold text-white mb-1">{plan.name}</h3>
                  <div className="text-3xl font-bold text-[#00D4FF]">
                    {plan.price === 0 ? "Free" : `$${plan.price}`}
                    {plan.price > 0 && <span className="text-sm text-[#64748B] font-normal">/mo</span>}
                  </div>
                </div>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-between p-3 bg-[#0A1628]/60 rounded-xl border border-[#152238]">
                    <span className="text-[#94A3B8] text-sm">Contracts</span>
                    <span className="text-white font-bold">{plan.contracts}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-[#0A1628]/60 rounded-xl border border-[#152238]">
                    <span className="text-[#94A3B8] text-sm">Account</span>
                    <span className="text-white font-bold">{plan.account}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-[#0A1628]/60 rounded-xl border border-[#152238]">
                    <span className="text-[#94A3B8] text-sm">Profit Split</span>
                    <span className="text-green-400 font-bold">{plan.profitSplit}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-[#0A1628]/60 rounded-xl border border-[#152238]">
                    <span className="text-[#94A3B8] text-sm">Max Payout</span>
                    <span className="text-white font-bold">{plan.maxPayout}</span>
                  </div>
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2 text-sm">
                      <CheckCircle size={14} className="text-green-400 mt-0.5 shrink-0" />
                      <span className="text-[#94A3B8]">{feat}</span>
                    </li>
                  ))}
                </ul>
                <button
                  className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
                    plan.id === "free"
                      ? "bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30"
                      : selectedPlan === plan.id
                      ? "bg-[#00D4FF] text-[#0A1628] hover:bg-[#00B8E0]"
                      : "bg-[#152238] text-white hover:bg-[#1E3A5F]"
                  }`}
                  data-testid={`button-select-plan-${plan.id}`}
                >
                  {plan.id === "free" ? "Start Free" : "Get Started"}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-gradient-to-b from-[#0A1628] via-[#0D1117] to-[#0A1628]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/30 rounded-full mb-6">
              <Crown size={16} className="text-yellow-400" />
              <span className="text-yellow-400 font-semibold text-sm uppercase tracking-wider">We Win Every Category</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Alpha Unlimited vs <span className="text-red-400 line-through">Competitors</span>
            </h2>
            <p className="text-[#94A3B8] max-w-2xl mx-auto">
              See exactly how we stack up against other futures prop firms. The numbers speak for themselves.
            </p>
          </motion.div>

          <CollapsibleSection previewHeight={320} label="See Full Comparison">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="overflow-x-auto">
              <table className="w-full" data-testid="table-comparison">
                <thead>
                  <tr className="border-b border-[#152238]">
                    <th className="text-left py-4 px-4 text-[#64748B] text-sm font-medium">Feature</th>
                    <th className="text-center py-4 px-4">
                      <div className="flex items-center justify-center gap-2">
                        <Crown size={14} className="text-yellow-400" />
                        <span className="text-[#00D4FF] font-bold text-sm">Alpha Unlimited</span>
                      </div>
                    </th>
                    <th className="text-center py-4 px-4 text-[#64748B] text-sm font-medium">Competitors</th>
                  </tr>
                </thead>
                <tbody>
                  {COMPETITOR_COMPARISON.map((row, i) => (
                    <tr key={row.feature} className={`border-b border-[#152238]/50 ${i % 2 === 0 ? "bg-[#0A1628]/30" : ""}`} data-testid={`row-comparison-${i}`}>
                      <td className="py-3.5 px-4 text-white text-sm font-medium">{row.feature}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full text-green-400 text-sm font-semibold">
                          <CheckCircle size={12} />
                          {row.us}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 text-sm">
                          <X size={12} />
                          {row.them}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </motion.div>
          </CollapsibleSection>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Trade <span className="text-[#00D4FF]">Every Major Market</span>
            </h2>
            <p className="text-[#94A3B8] max-w-2xl mx-auto">
              Access futures contracts across equity indices, commodities, crypto, forex, agriculture, and interest rates.
            </p>
          </motion.div>

          <CollapsibleSection previewHeight={300} label="See All Instruments">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {INSTRUMENTS.map((group, i) => (
                <motion.div
                  key={group.category}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="bg-[#0D1117] border border-[#152238] rounded-2xl p-6 hover:border-[#1E3A5F] transition-all"
                  data-testid={`card-instruments-${i}`}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-10 h-10 rounded-xl bg-[#152238] flex items-center justify-center ${group.color}`}>
                      <group.icon size={20} />
                    </div>
                    <h3 className="text-white font-bold">{group.category}</h3>
                  </div>
                  <ul className="space-y-2">
                    {group.items.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-sm text-[#94A3B8]">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#00D4FF]/60" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-gradient-to-b from-[#0A1628] via-[#0D1117] to-[#0A1628]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              How It <span className="text-[#00D4FF]">Works</span>
            </h2>
            <p className="text-[#94A3B8] max-w-2xl mx-auto">
              Three simple steps from sign-up to funded trader. No time limits, no hidden fees.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {STEPS.map((step, i) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                className="relative text-center"
                data-testid={`card-step-${step.step}`}
              >
                {i < STEPS.length - 1 && (
                  <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-px bg-gradient-to-r from-[#00D4FF]/30 to-transparent" />
                )}
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#00D4FF]/20 to-[#00D4FF]/5 border border-[#00D4FF]/30 flex items-center justify-center mx-auto mb-6">
                  <step.icon size={32} className="text-[#00D4FF]" />
                </div>
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#00D4FF] text-[#0A1628] font-bold text-sm mb-4">
                  {step.step}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-[#94A3B8] text-sm leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Traders <span className="text-[#00D4FF]">Choose Us</span>
            </h2>
          </motion.div>

          <CollapsibleSection previewHeight={200} label="See All Benefits">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Shield, title: "No Hidden Fees", desc: "Transparent pricing. What you see is what you pay. No activation fees, no data fees." },
                { icon: Clock, title: "No Time Limits", desc: "Take as long as you need to pass the evaluation. Trade at your own pace." },
                { icon: Sparkles, title: "20 Proprietary Tech", desc: "Exclusive technologies like QMGE™, Bridge Fusion™, and ANCE™ give you an unfair advantage." },
                { icon: Users, title: "Community Support", desc: "Join thousands of funded traders sharing strategies, insights, and support." },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-[#0D1117] border border-[#152238] rounded-2xl p-6 text-center hover:border-[#00D4FF]/30 transition-all"
                  data-testid={`card-benefit-${i}`}
                >
                  <div className="w-12 h-12 rounded-xl bg-[#00D4FF]/10 flex items-center justify-center mx-auto mb-4">
                    <item.icon size={24} className="text-[#00D4FF]" />
                  </div>
                  <h3 className="text-white font-bold mb-2">{item.title}</h3>
                  <p className="text-[#94A3B8] text-sm">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-gradient-to-b from-[#0A1628] via-[#0D1117] to-[#0A1628]">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Frequently Asked <span className="text-[#00D4FF]">Questions</span>
            </h2>
          </motion.div>

          <CollapsibleSection previewHeight={260} label="See All FAQs">
            <div className="space-y-3">
              {FAQ_ITEMS.map((faq, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-[#0D1117] border border-[#152238] rounded-xl overflow-hidden"
                  data-testid={`faq-item-${i}`}
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-4 sm:p-5 text-left"
                    data-testid={`button-faq-${i}`}
                  >
                    <span className="text-white font-semibold text-sm sm:text-base pr-4">{faq.question}</span>
                    {openFaq === i ? (
                      <ChevronUp size={18} className="text-[#00D4FF] shrink-0" />
                    ) : (
                      <ChevronDown size={18} className="text-[#64748B] shrink-0" />
                    )}
                  </button>
                  {openFaq === i && (
                    <div className="px-4 sm:px-5 pb-4 sm:pb-5">
                      <p className="text-[#94A3B8] text-sm leading-relaxed">{faq.answer}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="bg-gradient-to-r from-[#00D4FF]/10 via-[#00D4FF]/5 to-[#00D4FF]/10 border border-[#00D4FF]/20 rounded-3xl p-8 sm:p-12">
              <Star size={40} className="text-[#00D4FF] mx-auto mb-6" />
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Ready to Start Trading Futures?
              </h2>
              <p className="text-[#94A3B8] text-lg mb-8 max-w-2xl mx-auto">
                Join the only prop firm that offers a free tier with 10 contracts. No credit card required. No time limits. Start proving your skills today.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  className="px-10 py-4 bg-[#00D4FF] hover:bg-[#00B8E0] text-[#0A1628] font-semibold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg shadow-[#00D4FF]/25 flex items-center gap-2"
                  data-testid="button-cta-start-free"
                >
                  Start Free <ArrowRight size={20} />
                </button>
                <a href="#pricing">
                  <button
                    className="px-10 py-4 bg-[#152238] hover:bg-[#1E3A5F] text-white font-semibold rounded-xl text-lg transition-all"
                    data-testid="button-cta-compare-plans"
                  >
                    Compare Plans
                  </button>
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}
