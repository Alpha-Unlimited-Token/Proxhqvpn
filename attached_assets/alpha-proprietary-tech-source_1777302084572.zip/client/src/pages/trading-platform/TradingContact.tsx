/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TradingContact™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_d0b14e69eec7f66af484d6c0
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Send, Mail, MessageSquare, HelpCircle, Shield, Headphones,
  Clock, Globe, Twitter, ChevronRight, Zap, BarChart3
} from "lucide-react";

export default function TradingContact() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    category: "",
    subject: "",
    message: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast({
        title: "Login Required",
        description: "You must create an account or log in to submit a contact request or any other type of application.",
        variant: "destructive",
      });
      setTimeout(() => { window.location.href = "/api/login"; }, 1500);
      return;
    }

    if (!formData.name || !formData.email || !formData.category || !formData.subject || !formData.message) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          source: "trading-platform",
          userId: user ? (user as any).claims?.sub : null,
        }),
      });

      if (response.ok) {
        toast({
          title: "Message sent!",
          description: "Thank you for reaching out. Our team will respond within 24-48 hours.",
        });
        setFormData({ name: "", email: "", category: "", subject: "", message: "" });
      } else {
        throw new Error("Failed to submit");
      }
    } catch {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <TradingPlatformLayout>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 16px 60px' }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ textAlign: 'center', marginBottom: 40 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginBottom: 12 }}>
            <Mail size={32} color="#00D4FF" />
            <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 28, margin: 0 }}>
              Contact Us
            </h1>
          </div>
          <p style={{ color: '#94A3B8', fontSize: 15, maxWidth: 600, margin: '0 auto' }}>
            Get in touch with the Alpha Unlimited Trading team. We're here to help with trading support, technical issues, partnership inquiries, and more.
          </p>
        </motion.div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16, marginBottom: 32 }}>
          {[
            { icon: Headphones, title: "Trading Support", desc: "Help with the trading terminal, indicators, and platform features", color: "#00D4FF" },
            { icon: Shield, title: "Security & Account", desc: "Account security, API key issues, and authentication help", color: "#22c55e" },
            { icon: Zap, title: "Technology Support", desc: "Questions about proprietary technologies, signals, and software", color: "#a855f7" },
            { icon: BarChart3, title: "Partnership & Business", desc: "Institutional partnerships, ambassador program, and business inquiries", color: "#FFD700" },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              style={{
                background: '#161B22',
                border: '1px solid #30363D',
                borderRadius: 12,
                padding: '20px',
                textAlign: 'center',
              }}
            >
              <item.icon size={28} color={item.color} style={{ marginBottom: 10 }} />
              <div style={{ color: '#e6edf3', fontWeight: 600, fontSize: 14, marginBottom: 6 }}>{item.title}</div>
              <div style={{ color: '#6b7280', fontSize: 12, lineHeight: 1.5 }}>{item.desc}</div>
            </motion.div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, alignItems: 'start' }}>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div style={{
              background: '#161B22',
              border: '1px solid #30363D',
              borderRadius: 14,
              overflow: 'hidden',
            }}>
              <div style={{
                background: 'linear-gradient(135deg, #0D1117 0%, #1a1a3e 100%)',
                padding: '20px 24px',
                borderBottom: '1px solid #30363D',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                  <Send size={18} color="#00D4FF" />
                  <h2 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 16, margin: 0 }}>
                    Send Us a Message
                  </h2>
                </div>
                <p style={{ color: '#6b7280', fontSize: 12, margin: 0 }}>
                  Fill out the form below and our team will respond within 24-48 hours
                </p>
              </div>

              <form onSubmit={handleSubmit} style={{ padding: '24px' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div>
                    <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>
                      Your Name *
                    </label>
                    <input
                      data-testid="input-trading-contact-name"
                      value={formData.name}
                      onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Your full name"
                      style={{
                        width: '100%',
                        background: '#0D1117',
                        border: '1px solid #30363D',
                        borderRadius: 8,
                        padding: '10px 12px',
                        color: '#e6edf3',
                        fontSize: 13,
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>
                      Email Address *
                    </label>
                    <input
                      data-testid="input-trading-contact-email"
                      type="email"
                      value={formData.email}
                      onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="your@email.com"
                      style={{
                        width: '100%',
                        background: '#0D1117',
                        border: '1px solid #30363D',
                        borderRadius: 8,
                        padding: '10px 12px',
                        color: '#e6edf3',
                        fontSize: 13,
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div>
                    <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>
                      Category *
                    </label>
                    <select
                      data-testid="select-trading-contact-category"
                      value={formData.category}
                      onChange={e => setFormData(prev => ({ ...prev, category: e.target.value }))}
                      style={{
                        width: '100%',
                        background: '#0D1117',
                        border: '1px solid #30363D',
                        borderRadius: 8,
                        padding: '10px 12px',
                        color: formData.category ? '#e6edf3' : '#6b7280',
                        fontSize: 13,
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    >
                      <option value="" disabled>Select a category</option>
                      <option value="trading-support">Trading Support</option>
                      <option value="technology">Technology & Software</option>
                      <option value="security">Security & Account</option>
                      <option value="partnership">Partnership & Business</option>
                      <option value="ambassador">Ambassador Program</option>
                      <option value="bug">Bug Report</option>
                      <option value="feature">Feature Request</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>
                      Subject *
                    </label>
                    <input
                      data-testid="input-trading-contact-subject"
                      value={formData.subject}
                      onChange={e => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                      placeholder="Brief description"
                      style={{
                        width: '100%',
                        background: '#0D1117',
                        border: '1px solid #30363D',
                        borderRadius: 8,
                        padding: '10px 12px',
                        color: '#e6edf3',
                        fontSize: 13,
                        outline: 'none',
                        boxSizing: 'border-box',
                      }}
                    />
                  </div>
                </div>

                <div style={{ marginBottom: 20 }}>
                  <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>
                    Message *
                  </label>
                  <textarea
                    data-testid="input-trading-contact-message"
                    value={formData.message}
                    onChange={e => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Tell us more about your question, issue, or feedback..."
                    rows={6}
                    style={{
                      width: '100%',
                      background: '#0D1117',
                      border: '1px solid #30363D',
                      borderRadius: 8,
                      padding: '10px 12px',
                      color: '#e6edf3',
                      fontSize: 13,
                      outline: 'none',
                      resize: 'vertical',
                      boxSizing: 'border-box',
                    }}
                  />
                </div>

                <button
                  data-testid="button-trading-contact-submit"
                  type="submit"
                  disabled={loading}
                  style={{
                    width: '100%',
                    background: loading ? '#333' : 'linear-gradient(135deg, #00D4FF, #0088aa)',
                    color: '#fff',
                    border: 'none',
                    borderRadius: 10,
                    padding: '14px',
                    fontFamily: 'Orbitron, monospace',
                    fontSize: 14,
                    fontWeight: 700,
                    cursor: loading ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 8,
                  }}
                >
                  {loading ? (
                    <div style={{ width: 18, height: 18, border: '2px solid #fff', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
                  ) : (
                    <>
                      <Send size={16} />
                      SEND MESSAGE
                    </>
                  )}
                </button>
              </form>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            style={{ display: 'flex', flexDirection: 'column', gap: 16 }}
          >
            <div style={{
              background: '#161B22',
              border: '1px solid #30363D',
              borderRadius: 14,
              padding: '20px',
            }}>
              <h3 style={{ color: '#FFD700', fontFamily: 'Orbitron, monospace', fontSize: 13, marginBottom: 16 }}>
                DIRECT CONTACT
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <a
                  href="mailto:contact@alphaunlimitedtrading.com"
                  data-testid="link-trading-email"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    color: '#e6edf3',
                    textDecoration: 'none',
                    padding: '10px 12px',
                    background: '#0D1117',
                    borderRadius: 8,
                    border: '1px solid #30363D',
                  }}
                >
                  <Mail size={16} color="#00D4FF" />
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600 }}>Email</div>
                    <div style={{ fontSize: 11, color: '#00D4FF' }}>contact@alphaunlimitedtrading.com</div>
                  </div>
                </a>
                <a
                  href="mailto:legal@alphaunlimitedtrading.com"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    color: '#e6edf3',
                    textDecoration: 'none',
                    padding: '10px 12px',
                    background: '#0D1117',
                    borderRadius: 8,
                    border: '1px solid #30363D',
                  }}
                >
                  <Shield size={16} color="#22c55e" />
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600 }}>Legal & IP</div>
                    <div style={{ fontSize: 11, color: '#22c55e' }}>legal@alphaunlimitedtrading.com</div>
                  </div>
                </a>
                <a
                  href="https://x.com/AlphaUnlimitedT"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    color: '#e6edf3',
                    textDecoration: 'none',
                    padding: '10px 12px',
                    background: '#0D1117',
                    borderRadius: 8,
                    border: '1px solid #30363D',
                  }}
                >
                  <Twitter size={16} color="#1DA1F2" />
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600 }}>Twitter / X</div>
                    <div style={{ fontSize: 11, color: '#1DA1F2' }}>@AlphaUnlimitedT</div>
                  </div>
                </a>
              </div>
            </div>

            <div style={{
              background: '#161B22',
              border: '1px solid #30363D',
              borderRadius: 14,
              padding: '20px',
            }}>
              <h3 style={{ color: '#FFD700', fontFamily: 'Orbitron, monospace', fontSize: 13, marginBottom: 16 }}>
                RESPONSE TIMES
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { label: "Trading Support", time: "< 24 hours", color: "#22c55e" },
                  { label: "Technical Issues", time: "< 24 hours", color: "#00D4FF" },
                  { label: "Security Concerns", time: "< 12 hours", color: "#ef4444" },
                  { label: "Partnership Inquiries", time: "2-3 business days", color: "#FFD700" },
                  { label: "General Questions", time: "24-48 hours", color: "#a855f7" },
                ].map(r => (
                  <div key={r.label} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '6px 0',
                    borderBottom: '1px solid #21262D',
                  }}>
                    <span style={{ color: '#94A3B8', fontSize: 12 }}>{r.label}</span>
                    <span style={{ color: r.color, fontSize: 11, fontWeight: 600 }}>{r.time}</span>
                  </div>
                ))}
              </div>
            </div>

            <div style={{
              background: 'linear-gradient(135deg, #0a1628, #1a0a2e)',
              border: '1px solid #00D4FF33',
              borderRadius: 14,
              padding: '20px',
              textAlign: 'center',
            }}>
              <Globe size={24} color="#00D4FF" style={{ marginBottom: 8 }} />
              <div style={{ color: '#e6edf3', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>
                Global Trading Platform
              </div>
              <div style={{ color: '#6b7280', fontSize: 11, lineHeight: 1.5 }}>
                Serving traders worldwide with 24/7 platform access and support across all major time zones.
              </div>
            </div>
          </motion.div>
        </div>

        <style>{`
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
          @media (max-width: 768px) {
            div[style*="grid-template-columns: 1fr 340px"] {
              grid-template-columns: 1fr !important;
            }
          }
        `}</style>
      </div>
    </TradingPlatformLayout>
  );
}
