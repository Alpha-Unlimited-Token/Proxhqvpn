/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha SafeSend Protocol™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - SafeSend Protocol™
 * - Reversible Transaction Engine™
 * - Address Registry System™
 * - Transaction Insurance Protocol™
 * - 7-Layer Anti-Fraud Verification™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_21e1544ec89bcf57b2e9217f
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  ShieldCheck, Clock, Search, Heart, Radar, Users, Lock, ArrowRight,
  CheckCircle2, XCircle, AlertTriangle, Eye, Fingerprint, Scale,
  Star, Zap, ArrowDownUp, UserCheck, Timer, Activity, ChevronDown,
  ChevronUp, Shield, Database, Globe, Send, Ban, Building2, Gem,
  BarChart3, FileCheck, Landmark, Award, Layers, TrendingUp,
  Coins, BadgeCheck, Key, Mail
} from "lucide-react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";

const fadeIn = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };

function SafeSendProtocol() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [registryAlias, setRegistryAlias] = useState("");
  const [lookupResult, setLookupResult] = useState<any>(null);
  const [lookupError, setLookupError] = useState("");

  const { data: stats } = useQuery({
    queryKey: ["/api/safesend/stats"],
    refetchInterval: 30000,
  });

  const { data: vaultStats } = useQuery({
    queryKey: ["/api/safesend/vault/stats"],
    refetchInterval: 30000,
  });

  const { data: claims } = useQuery({
    queryKey: ["/api/safesend/vault/claims"],
    refetchInterval: 60000,
  });

  const { data: validators } = useQuery({
    queryKey: ["/api/safesend/vault/validators"],
    refetchInterval: 60000,
  });

  const { data: assetStats } = useQuery({
    queryKey: ["/api/safesend/asset/stats"],
    refetchInterval: 60000,
  });

  const { data: forensicStats } = useQuery({
    queryKey: ["/api/safesend/forensics/stats"],
    refetchInterval: 30000,
  });

  const { data: forensicAlerts } = useQuery({
    queryKey: ["/api/safesend/forensics/alerts"],
    refetchInterval: 15000,
  });

  const { data: forensicDossiers } = useQuery({
    queryKey: ["/api/safesend/forensics/dossiers"],
    refetchInterval: 60000,
  });

  const toggle = (id: string) => setExpandedSection(expandedSection === id ? null : id);

  const handleLookup = async () => {
    setLookupError("");
    setLookupResult(null);
    if (!registryAlias.trim()) return;
    try {
      const res = await fetch(`/api/safesend/registry/lookup/${encodeURIComponent(registryAlias.trim())}`);
      const data = await res.json();
      if (data.error) {
        setLookupError(data.error);
      } else {
        setLookupResult(data);
      }
    } catch {
      setLookupError("Failed to lookup alias");
    }
  };

  const vaultBalance = vaultStats?.totalBalance || 0;
  const totalClaims = vaultStats?.totalClaims || 0;
  const claimsPaid = vaultStats?.approvedClaims || 0;
  const activeValidators = validators?.count || 0;
  const totalSafeSendTxs = stats?.safeSend?.totalTransactions || 0;
  const registeredAliases = stats?.safeSend?.registeredAliases || 0;
  const totalAssets = assetStats?.totalAssets || 0;
  const totalMarketCap = assetStats?.totalValuation || 0;

  return (
    <TradingPlatformLayout>
    <div className="min-h-screen bg-[#0D1117]">
      <section className="relative pt-20 pb-16 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#00D4FF]/5 via-transparent to-transparent" />
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div
            initial="hidden" animate="visible" variants={fadeIn}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#00D4FF]/30 bg-[#00D4FF]/10 mb-6">
              <ShieldCheck className="w-4 h-4 text-[#00D4FF]" />
              <span className="text-[#00D4FF] text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>Patent Pending Technology</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, sans-serif' }}>
              Alpha SafeSend Protocol<span className="text-[#00D4FF]">™</span>
            </h1>
            <p className="text-xl text-[#8899A6] max-w-3xl mx-auto mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
              The world's first blockchain with built-in transaction safety. Reversible transfers,
              protocol-level integrity verification, insurance protection, asset tokenization, and inheritance — all at the protocol level.
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <StatCard icon={ShieldCheck} label="SafeSend Transactions" value={totalSafeSendTxs} />
              <StatCard icon={Database} label="Insurance Vault" value={`${vaultBalance.toFixed(2)} AUC`} />
              <StatCard icon={Shield} label="Integrity Validators" value={activeValidators} />
              <StatCard icon={Users} label="Registered Aliases" value={registeredAliases} />
              <StatCard icon={Layers} label="Tokenized Assets" value={totalAssets} />
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 px-4 border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Clock}
            title="Reversible Transactions"
            subtitle="Every AUC transfer includes a configurable time-lock window. Cancel mistakes before they become permanent."
          />
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            <FlowCard
              step={1}
              icon={Send}
              title="Send with SafeSend"
              description="Initiate a transfer with a time-lock window (5 minutes to 24 hours). Funds are held in escrow."
              color="#00D4FF"
            />
            <FlowCard
              step={2}
              icon={Timer}
              title="Review Period"
              description="During the time-lock, you can cancel the transaction and get your funds back. No questions asked."
              color="#FFD700"
            />
            <FlowCard
              step={3}
              icon={CheckCircle2}
              title="Auto-Finalize"
              description="After the time-lock expires, the transaction finalizes automatically. Recipient gets their funds."
              color="#00FF88"
            />
          </div>
          <div className="mt-8 bg-[#152238] rounded-xl border border-[#1A2942] p-6">
            <div className="flex items-center gap-2 mb-3">
              <Lock className="w-5 h-5 text-[#00D4FF]" />
              <h4 className="text-white font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>How It Works</h4>
            </div>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-[#8899A6]" style={{ fontFamily: 'Poppins, sans-serif' }}>
              <div className="space-y-2">
                <p><span className="text-[#00D4FF]">Time-Lock Range:</span> 5 minutes to 24 hours (configurable per transaction)</p>
                <p><span className="text-[#00D4FF]">Default Window:</span> 1 hour — balances security with convenience</p>
                <p><span className="text-[#00D4FF]">Insurance Fee:</span> 0.1% of each transaction goes to the Insurance Vault</p>
              </div>
              <div className="space-y-2">
                <p><span className="text-[#00D4FF]">Cancellation:</span> Only the sender can cancel, only during the time-lock window</p>
                <p><span className="text-[#00D4FF]">Finalization:</span> Automatic after time-lock expires — no action needed</p>
                <p><span className="text-[#00D4FF]">Alias Support:</span> Send to @username.auc instead of long wallet addresses</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Shield}
            title="Alpha Chain Integrity Protocol™ (ACIP™)"
            subtitle="Protocol-level transaction integrity verification that ensures every AUC transfer is cryptographically validated and permanently auditable."
          />
          <div className="mt-6 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#FFD700]/30 bg-[#FFD700]/10">
              <Award className="w-4 h-4 text-[#FFD700]" />
              <span className="text-[#FFD700] text-sm font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Patent Pending — Proposed Global Blockchain Standard</span>
            </div>
          </div>
          <div className="mt-10">
            <IntegrityDiagram />
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-10">
            <FeatureCard
              icon={Fingerprint}
              title="Cryptographic Integrity Signatures"
              description="Every transaction on the AUC chain receives a unique cryptographic integrity signature. This signature is permanently embedded in the transaction's identity, ensuring tamper-proof verification across the entire network."
            />
            <FeatureCard
              icon={Eye}
              title="Multi-Thread Consensus Validation"
              description="ACIP validates fund flows through unlimited consensus threads — verifying every transfer, split, and merge across the network. Each thread is independently verified against the protocol's integrity rules."
            />
            <FeatureCard
              icon={AlertTriangle}
              title="Autonomous Alert & Protection"
              description="If integrity validation detects anomalous fund patterns — such as circular flows or connected wallet violations — the protocol autonomously issues an alert and initiates protective measures."
            />
            <FeatureCard
              icon={Lock}
              title="Self-Defending Protocol Architecture"
              description="ACIP features HMAC-based tamper detection at the protocol level. Any attempt to modify, bypass, or remove the integrity verification system triggers automatic fund invalidation and chain protection measures."
            />
          </div>
          {activeValidators > 0 && (
            <div className="mt-8 bg-[#152238] rounded-xl border border-[#00D4FF]/20 p-6">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="w-5 h-5 text-[#00D4FF] animate-pulse" />
                <h4 className="text-white font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Live Integrity Validation</h4>
              </div>
              <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
                {activeValidators} active integrity validator{activeValidators !== 1 ? 's' : ''} currently performing consensus verification on the AUC blockchain.
              </p>
            </div>
          )}
          <div className="mt-8 bg-gradient-to-r from-[#152238] to-[#0A1628] rounded-xl border border-[#FFD700]/20 p-6">
            <div className="flex items-center gap-2 mb-3">
              <Key className="w-5 h-5 text-[#FFD700]" />
              <h4 className="text-white font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Tamper-Proof Self-Defense</h4>
            </div>
            <p className="text-[#8899A6] text-sm mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              ACIP™ is protected by military-grade HMAC integrity verification. The protocol continuously validates its own code integrity, making it the first self-defending blockchain security layer.
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-[#0D1117] rounded-lg p-4 border border-[#1A2942]">
                <p className="text-[#FF4444] text-xs font-semibold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>IF TAMPERED</p>
                <p className="text-white text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>All funds in affected wallets are automatically invalidated</p>
              </div>
              <div className="bg-[#0D1117] rounded-lg p-4 border border-[#1A2942]">
                <p className="text-[#FF4444] text-xs font-semibold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>IF TAMPERED</p>
                <p className="text-white text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>Associated claims flagged as fraudulent immediately</p>
              </div>
              <div className="bg-[#0D1117] rounded-lg p-4 border border-[#1A2942]">
                <p className="text-[#FF4444] text-xs font-semibold mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>IF TAMPERED</p>
                <p className="text-white text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>Chain state invalidated for compromised addresses</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Fingerprint}
            title="Forensic Intelligence Engine™"
            subtitle="Our proprietary Autonomous Blockchain Spider™ crawls the entire blockchain history — forward and backward — to detect, analyze, and document fraudulent activity. The system operates autonomously, building legal-ready evidence packages in real time."
          />
          <div className="grid md:grid-cols-4 gap-4 mt-10" data-testid="forensic-stats-grid">
            <VaultStatCard label="Forensic Dossiers" value={forensicStats?.totalDossiers || 0} icon={FileCheck} />
            <VaultStatCard label="Critical Severity" value={forensicStats?.criticalDossiers || 0} icon={AlertTriangle} />
            <VaultStatCard label="Legal Referrals" value={forensicStats?.legalReferrals || 0} icon={Scale} />
            <VaultStatCard label="Addresses Invalidated" value={forensicStats?.invalidatedAddresses || 0} icon={Ban} />
          </div>

          {(forensicAlerts?.count > 0) && (
            <div className="mt-8 bg-gradient-to-r from-red-500/10 to-[#152238] rounded-xl border border-red-500/20 p-6" data-testid="forensic-alerts-panel">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-5 h-5 text-red-400 animate-pulse" />
                <h4 className="text-white font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Active Alerts ({forensicAlerts.alerts?.filter((a: any) => !a.acknowledged).length || 0} unacknowledged)</h4>
              </div>
              <div className="space-y-2">
                {forensicAlerts.alerts?.slice(0, 5).map((alert: any) => (
                  <div key={alert.id} className={`bg-[#0D1117] rounded-lg p-3 border ${alert.severity === 'critical' ? 'border-red-500/30' : 'border-[#1A2942]'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs font-bold uppercase ${alert.severity === 'critical' ? 'text-red-400' : alert.severity === 'high' ? 'text-orange-400' : 'text-yellow-400'}`} style={{ fontFamily: 'Poppins, sans-serif' }}>{alert.severity}</span>
                      <span className="text-[#475569] text-xs" style={{ fontFamily: 'Poppins, sans-serif' }}>{new Date(alert.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-white text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>{alert.title}</p>
                    <p className="text-[#8899A6] text-xs mt-1" style={{ fontFamily: 'Poppins, sans-serif' }}>{alert.summary.substring(0, 200)}{alert.summary.length > 200 ? '...' : ''}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-6 mt-10">
            <FeatureCard
              icon={Fingerprint}
              title="Autonomous Blockchain Spider™"
              description="Our proprietary crawler traverses the entire blockchain history in both directions — past and future. No matter when or where a wallet was used, the Spider finds it and builds a complete behavioral profile."
            />
            <FeatureCard
              icon={Globe}
              title="Deep Historical Analysis"
              description="Unlike systems that only monitor forward activity, our technology crawls backward through every historical block to uncover a wallet's complete transaction lineage. Evasion through new wallets is ineffective."
            />
            <FeatureCard
              icon={Eye}
              title="Proprietary Detection Algorithms"
              description="Multiple layers of proprietary pattern recognition work in concert to identify suspicious activity. The specific methods are classified to prevent adversarial adaptation. Patent Pending."
            />
            <FeatureCard
              icon={Scale}
              title="Legal-Ready Evidence Packages"
              description="The Forensic Intelligence Engine autonomously compiles comprehensive evidence packages formatted for direct use in legal proceedings and law enforcement cooperation."
            />
          </div>

          <div className="mt-8 bg-[#152238] rounded-xl border border-[#1A2942] p-6">
            <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>Forensic Dossier Overview</h4>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { label: 'Behavioral Profiling', items: ['Complete activity timeline', 'Historical transaction patterns', 'Behavioral anomaly detection', 'Cross-reference validation', 'Risk classification', 'Proprietary scoring metrics'] },
                { label: 'Network Intelligence', items: ['Relationship mapping', 'Pattern correlation', 'Multi-directional analysis', 'Proprietary graph algorithms', 'Historical chain crawling', 'Autonomous discovery'] },
                { label: 'Evidence Package', items: ['Timestamped audit trail', 'Confidence-scored findings', 'Verified transaction records', 'Comprehensive analysis report', 'Administrative documentation', 'Legal referral readiness'] },
              ].map(col => (
                <div key={col.label} className="bg-[#0A1628] rounded-lg p-4 border border-[#1A2942]">
                  <p className="text-[#00D4FF] text-sm font-semibold mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>{col.label}</p>
                  <div className="space-y-1.5">
                    {col.items.map(item => (
                      <div key={item} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3 h-3 text-[#00FF88] shrink-0" />
                        <span className="text-[#8899A6] text-xs" style={{ fontFamily: 'Poppins, sans-serif' }}>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {(forensicDossiers?.count > 0) && (
            <div className="mt-8">
              <button
                onClick={() => toggle('dossiers')}
                className="w-full flex items-center justify-between bg-[#152238] rounded-xl border border-[#1A2942] p-6 hover:border-[#00D4FF]/30 transition-colors"
                data-testid="toggle-dossiers"
              >
                <div className="flex items-center gap-3">
                  <FileCheck className="w-6 h-6 text-[#00D4FF]" />
                  <h3 className="text-white text-lg font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Active Forensic Dossiers ({forensicDossiers.count})</h3>
                </div>
                {expandedSection === 'dossiers' ? <ChevronUp className="w-5 h-5 text-[#8899A6]" /> : <ChevronDown className="w-5 h-5 text-[#8899A6]" />}
              </button>
              {expandedSection === 'dossiers' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                  className="bg-[#0A1628] rounded-b-xl border border-t-0 border-[#1A2942] p-6 space-y-3"
                >
                  {forensicDossiers.dossiers?.slice(0, 10).map((d: any) => (
                    <div key={d.id} className={`bg-[#152238] rounded-lg p-4 border ${d.severity === 'critical' ? 'border-red-500/30' : d.severity === 'high' ? 'border-orange-500/20' : 'border-[#1A2942]'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${d.severity === 'critical' ? 'bg-red-500/20 text-red-400' : d.severity === 'high' ? 'bg-orange-500/20 text-orange-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{d.severity}</span>
                          <span className="text-white text-sm font-mono" style={{ fontFamily: 'Poppins, sans-serif' }}>{d.primaryAddress.substring(0, 24)}...</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-xs ${d.status === 'referred_to_legal' ? 'bg-purple-500/20 text-purple-400' : d.status === 'active' ? 'bg-[#00D4FF]/20 text-[#00D4FF]' : 'bg-[#1A2942] text-[#8899A6]'}`}>{d.status.replace(/_/g, ' ')}</span>
                      </div>
                      <div className="grid grid-cols-4 gap-4 text-xs text-[#8899A6]" style={{ fontFamily: 'Poppins, sans-serif' }}>
                        <div><span className="text-[#00D4FF]">Trigger:</span> {d.trigger.replace(/_/g, ' ')}</div>
                        <div><span className="text-[#00D4FF]">Transactions:</span> {d.transactionHistory?.length || 0}</div>
                        <div><span className="text-[#00D4FF]">Connected:</span> {d.connectedWallets?.length || 0} wallets</div>
                        <div><span className="text-[#00D4FF]">Indicators:</span> {d.fraudIndicators?.length || 0}</div>
                      </div>
                    </div>
                  ))}
                </motion.div>
              )}
            </div>
          )}
          <div className="mt-10 bg-gradient-to-r from-[#152238] to-[#0A1628] rounded-xl border border-[#FFD700]/20 p-8 text-center">
            <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>Enterprise Licensing Available</h3>
            <p className="text-[#8899A6] text-sm mb-4 max-w-lg mx-auto" style={{ fontFamily: 'Poppins, sans-serif' }}>
              The Forensic Intelligence Engine™ and Autonomous Blockchain Spider™ are available for licensing by exchanges, custodians, and financial institutions. Protect your users with the same proprietary technology that powers Alpha Unlimited.
            </p>
            <a
              href="mailto:licensing@alphaunlimitedtrading.com"
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-[#0A1628] font-bold rounded-lg hover:shadow-lg hover:shadow-[#FFD700]/20 transition-all text-sm"
              data-testid="button-forensic-licensing"
            >
              Inquire About Licensing
            </a>
            <p className="text-[#475569] text-xs mt-2" style={{ fontFamily: 'Poppins, sans-serif' }}>licensing@alphaunlimitedtrading.com — Patent Pending</p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Shield}
            title="Transaction Insurance Vault"
            subtitle="0.1% of every transaction builds a community insurance pool. Verified claims get paid."
          />
          <div className="grid md:grid-cols-4 gap-4 mt-10">
            <VaultStatCard label="Vault Balance" value={`${vaultBalance.toFixed(4)} AUC`} icon={Database} />
            <VaultStatCard label="Claims Filed" value={totalClaims} icon={Scale} />
            <VaultStatCard label="Claims Paid" value={claimsPaid} icon={CheckCircle2} />
            <VaultStatCard label="Fraud Detected" value={vaultStats?.fraudulentClaims || 0} icon={XCircle} />
          </div>

          <div className="mt-10">
            <button
              onClick={() => toggle('antifraud')}
              className="w-full flex items-center justify-between bg-[#152238] rounded-xl border border-[#1A2942] p-6 hover:border-[#00D4FF]/30 transition-colors"
              data-testid="toggle-antifraud"
            >
              <div className="flex items-center gap-3">
                <Fingerprint className="w-6 h-6 text-[#00D4FF]" />
                <h3 className="text-white text-lg font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>7-Layer Anti-Fraud Verification System</h3>
              </div>
              {expandedSection === 'antifraud' ? (
                <ChevronUp className="w-5 h-5 text-[#8899A6]" />
              ) : (
                <ChevronDown className="w-5 h-5 text-[#8899A6]" />
              )}
            </button>
            {expandedSection === 'antifraud' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                className="bg-[#0A1628] rounded-b-xl border border-t-0 border-[#1A2942] p-6 space-y-4"
              >
                <VerificationLayer number={1} title="On-Chain Proof Verification" description="Verify the transaction hash exists on-chain. Confirm funds actually left the claimant's wallet. Check the destination address is not owned by the claimant." icon={Search} />
                <VerificationLayer number={2} title="Wallet Relationship Graph" description="Analyze if claimant and destination wallets have ever interacted. Check if they were funded from the same source. Detect circular fund flows. Auto-deny if relationship found." icon={Globe} />
                <VerificationLayer number={3} title="Time-Lock Investigation Escrow" description="7-30 day investigation window before any payout. Destination wallet is monitored during this period. Any suspicious movement becomes evidence." icon={Timer} />
                <VerificationLayer number={4} title="Stake-to-Claim Requirement" description="Claimant must stake 5% of the claimed amount. If claim is verified legitimate, stake is returned plus payout. If fraudulent, stake is forfeited to the vault." icon={Lock} />
                <VerificationLayer number={5} title="Community Jury (DAO Voting)" description="Jurors must stake AUC to participate in voting. Correct votes earn 10% reward on their stake. Incorrect votes lose their stake. Prevents rubber-stamping." icon={Users} />
                <VerificationLayer number={6} title="Reputation Scoring" description="Score based on account age, transaction history, wallet balance, and previous claim history. New wallets get higher scrutiny. Previous claims reduce trust score." icon={Star} />
                <VerificationLayer number={7} title="Maximum Payout Caps" description="Claims capped at 10% of vault balance. Prior claims reduce the maximum. Limits systemic risk even if a fraudulent claim slips through." icon={Scale} />
              </motion.div>
            )}
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Layers}
            title="Alpha SafeAsset Protocol™"
            subtitle="Tokenize any real-world asset on the AUC blockchain. Fractional ownership, automated yield distribution, and full regulatory compliance."
          />
          <div className="mt-6 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#00D4FF]/30 bg-[#00D4FF]/10">
              <Award className="w-4 h-4 text-[#00D4FF]" />
              <span className="text-[#00D4FF] text-sm font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>Patent Pending Technology</span>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mt-10">
            <VaultStatCard label="Tokenized Assets" value={totalAssets} icon={Layers} />
            <VaultStatCard label="Total Market Cap" value={totalMarketCap > 0 ? `${(totalMarketCap / 1000000).toFixed(1)}M AUC` : '0 AUC'} icon={TrendingUp} />
            <VaultStatCard label="Asset Types" value="8" icon={Gem} />
            <VaultStatCard label="SafeSend Protected" value="100%" icon={ShieldCheck} />
          </div>

          <div className="grid md:grid-cols-4 gap-4 mt-8">
            {[
              { icon: Building2, name: 'Real Estate', desc: 'Commercial & residential properties' },
              { icon: Coins, name: 'Commodities', desc: 'Gold, silver, oil, agricultural' },
              { icon: BarChart3, name: 'Securities', desc: 'Equity, bonds, derivatives' },
              { icon: Gem, name: 'Art & Collectibles', desc: 'Fine art, rare items, IP' },
            ].map((asset, i) => (
              <motion.div
                key={asset.name}
                initial="hidden" animate="visible"
                variants={fadeIn} transition={{ duration: 0.4, delay: i * 0.1 }}
                className="bg-[#152238] rounded-xl border border-[#1A2942] p-5 hover:border-[#00D4FF]/20 transition-colors text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-[#00D4FF]/10 border border-[#00D4FF]/20 flex items-center justify-center mx-auto mb-3">
                  <asset.icon className="w-6 h-6 text-[#00D4FF]" />
                </div>
                <h4 className="text-white font-semibold text-sm mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>{asset.name}</h4>
                <p className="text-[#8899A6] text-xs" style={{ fontFamily: 'Poppins, sans-serif' }}>{asset.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-10">
            <FeatureCard
              icon={Layers}
              title="Fractional Ownership"
              description="Divide any asset into up to 1 billion fractional shares. Each share is a transferable token on the AUC blockchain, enabling micro-investments in previously inaccessible asset classes."
            />
            <FeatureCard
              icon={FileCheck}
              title="Verification & Compliance"
              description="Built-in KYC gates, investor accreditation checks, geographic restrictions, and holding period requirements. Third-party auditor verification with document hash attestation on-chain."
            />
            <FeatureCard
              icon={TrendingUp}
              title="Automated Yield Distribution"
              description="Configure monthly, quarterly, or annual yield payouts. Dividends are automatically distributed to all token holders proportional to their share ownership. Fully on-chain and auditable."
            />
          </div>

          <div className="mt-8 bg-[#152238] rounded-xl border border-[#1A2942] p-6">
            <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>How SafeAsset Tokenization Works</h4>
            <div className="grid md:grid-cols-4 gap-4">
              <FlowCard step={1} icon={FileCheck} title="Verify Asset" description="Upload ownership documents. Third-party auditors verify authenticity and value." color="#00D4FF" />
              <FlowCard step={2} icon={Layers} title="Tokenize" description="Define share count, compliance rules, yield schedule, and secondary market restrictions." color="#FFD700" />
              <FlowCard step={3} icon={Send} title="Distribute" description="Transfer shares to investors. All transfers protected by SafeSend Protocol with escrow and insurance." color="#00FF88" />
              <FlowCard step={4} icon={TrendingUp} title="Earn Yield" description="Automated yield distribution to all holders. Track valuations and manage compliance in real-time." color="#9B59B6" />
            </div>
          </div>

          <div className="mt-8 bg-gradient-to-r from-[#152238] to-[#0A1628] rounded-xl border border-[#00D4FF]/20 p-6">
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="w-5 h-5 text-[#00D4FF]" />
              <h4 className="text-white font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>SafeSend Integration</h4>
            </div>
            <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Every SafeAsset transfer is automatically routed through the SafeSend Protocol. This means every share transfer includes time-lock reversibility, 
              0.1% insurance protection, ACIP™ integrity validation, and the full 7-layer anti-fraud verification system. No other tokenization platform offers this level of protection.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={UserCheck}
            title="Address Registry"
            subtitle="Human-readable wallet names. Send to @alice.auc instead of ALPHA_8F3A2B..."
          />
          <div className="grid md:grid-cols-2 gap-8 mt-10">
            <div className="bg-[#152238] rounded-xl border border-[#1A2942] p-6">
              <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>How It Works</h4>
              <div className="space-y-3 text-sm text-[#8899A6]" style={{ fontFamily: 'Poppins, sans-serif' }}>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" />
                  <p>Register any unique name as your wallet alias (3-32 characters)</p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" />
                  <p>Format: @yourname.auc — clean, memorable, impossible to mistype</p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" />
                  <p>SafeSend transactions automatically resolve aliases to addresses</p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" />
                  <p>Transfer your alias to a new wallet if needed</p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" />
                  <p>Reverse lookup: find the alias for any wallet address</p>
                </div>
              </div>
            </div>
            <div className="bg-[#152238] rounded-xl border border-[#1A2942] p-6">
              <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>Lookup Alias</h4>
              <div className="flex gap-2 mb-4">
                <input
                  type="text"
                  value={registryAlias}
                  onChange={(e) => setRegistryAlias(e.target.value)}
                  placeholder="@alice.auc"
                  className="flex-1 bg-[#0A1628] border border-[#1A2942] rounded-lg px-4 py-2 text-white text-sm focus:border-[#00D4FF] focus:outline-none"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                  data-testid="input-registry-lookup"
                  onKeyDown={(e) => e.key === 'Enter' && handleLookup()}
                />
                <button
                  onClick={handleLookup}
                  className="px-4 py-2 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                  data-testid="button-registry-lookup"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
              {lookupResult && (
                <div className="bg-[#0A1628] rounded-lg p-4 border border-[#00FF88]/20">
                  <p className="text-[#00FF88] text-sm font-medium mb-2">Found!</p>
                  <p className="text-white text-sm font-mono">{lookupResult.alias}</p>
                  <p className="text-[#8899A6] text-xs font-mono mt-1 break-all">{lookupResult.address}</p>
                </div>
              )}
              {lookupError && (
                <div className="bg-[#0A1628] rounded-lg p-4 border border-red-500/20">
                  <p className="text-red-400 text-sm">{lookupError}</p>
                </div>
              )}
              <p className="text-[#475569] text-xs mt-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
                {registeredAliases} aliases registered on the AUC blockchain
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={Heart}
            title="Inheritance Protocol"
            subtitle="Dead man's switch ensures your crypto passes to your chosen beneficiaries. Never lose access to family wealth."
          />
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            <FeatureCard
              icon={Timer}
              title="Configurable Inactivity Period"
              description="Set your dead man's switch for 6 to 24 months. If you don't check in within that window, the protocol activates."
            />
            <FeatureCard
              icon={Users}
              title="Multiple Beneficiaries"
              description="Designate multiple wallet addresses with percentage allocations. Your crypto gets distributed exactly as you specify."
            />
            <FeatureCard
              icon={Activity}
              title="Easy Check-In"
              description="A single button press resets the timer. Any SafeSend transaction or registry activity also counts as a check-in."
            />
          </div>
          <div className="mt-8 bg-[#152238] rounded-xl border border-[#1A2942] p-6">
            <h4 className="text-white font-semibold mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>Example Configuration</h4>
            <div className="bg-[#0A1628] rounded-lg p-4 font-mono text-sm">
              <p className="text-[#8899A6]">{"// Inheritance Configuration"}</p>
              <p className="text-[#00D4FF]">Owner: <span className="text-white">@satoshi.auc</span></p>
              <p className="text-[#00D4FF]">Inactivity Period: <span className="text-white">12 months</span></p>
              <p className="text-[#00D4FF]">Beneficiaries:</p>
              <p className="text-white pl-4">@alice.auc — <span className="text-[#00FF88]">50%</span></p>
              <p className="text-white pl-4">@bob.auc — <span className="text-[#00FF88]">30%</span></p>
              <p className="text-white pl-4">@charity.auc — <span className="text-[#00FF88]">20%</span></p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <SectionHeader
            icon={ArrowDownUp}
            title="Safety Comparison"
            subtitle="AUC is the only blockchain with protocol-level transaction safety."
          />
          <div className="mt-10 overflow-x-auto">
            <table className="w-full text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
              <thead>
                <tr className="border-b border-[#1A2942]">
                  <th className="text-left py-4 px-4 text-[#8899A6] font-medium">Feature</th>
                  <th className="text-center py-4 px-4 text-[#00D4FF] font-bold">AUC</th>
                  <th className="text-center py-4 px-4 text-[#8899A6] font-medium">Bitcoin</th>
                  <th className="text-center py-4 px-4 text-[#8899A6] font-medium">Ethereum</th>
                  <th className="text-center py-4 px-4 text-[#8899A6] font-medium">Solana</th>
                </tr>
              </thead>
              <tbody>
                <ComparisonRow feature="Reversible Transactions" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Time-Lock Protection" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Insurance Vault" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Chain Integrity Protocol (ACIP™)" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Anti-Fraud Verification" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="RWA Tokenization (SafeAsset™)" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Human-Readable Addresses" auc={true} btc={false} eth="ENS" sol="SNS" />
                <ComparisonRow feature="Inheritance Protocol" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Tamper Self-Defense" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Automated Yield Distribution" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Community Jury System" auc={true} btc={false} eth={false} sol={false} />
                <ComparisonRow feature="Wallet Relationship Graph" auc={true} btc={false} eth={false} sol={false} />
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="hidden" animate="visible"
            variants={fadeIn} transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#FFD700]/30 bg-[#FFD700]/10 mb-6">
              <Landmark className="w-4 h-4 text-[#FFD700]" />
              <span className="text-[#FFD700] text-sm font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>The Global Standard for Blockchain Security</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, sans-serif' }}>
              Why Every Blockchain Needs ACIP<span className="text-[#00D4FF]">™</span>
            </h2>
            <p className="text-[#8899A6] max-w-3xl mx-auto" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Over $14 billion is lost to crypto fraud, scams, and theft annually. ACIP™ is the only protocol-level solution
              that makes fraud detection and prevention a fundamental part of blockchain infrastructure — not an afterthought.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <motion.div
              initial="hidden" animate="visible"
              variants={fadeIn} transition={{ duration: 0.5 }}
              className="bg-[#152238] rounded-xl border border-red-500/20 p-6 text-center"
            >
              <p className="text-red-400 text-4xl font-bold mb-2" style={{ fontFamily: 'Orbitron, sans-serif' }}>$14B+</p>
              <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>Lost to crypto fraud annually</p>
            </motion.div>
            <motion.div
              initial="hidden" animate="visible"
              variants={fadeIn} transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-[#152238] rounded-xl border border-[#FFD700]/20 p-6 text-center"
            >
              <p className="text-[#FFD700] text-4xl font-bold mb-2" style={{ fontFamily: 'Orbitron, sans-serif' }}>0%</p>
              <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>Recovery rate on most blockchains</p>
            </motion.div>
            <motion.div
              initial="hidden" animate="visible"
              variants={fadeIn} transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-[#152238] rounded-xl border border-[#00FF88]/20 p-6 text-center"
            >
              <p className="text-[#00FF88] text-4xl font-bold mb-2" style={{ fontFamily: 'Orbitron, sans-serif' }}>100%</p>
              <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>Of AUC transactions protected by ACIP™</p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-10">
            <div className="bg-[#152238] rounded-xl border border-[#1A2942] p-6">
              <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>Without ACIP™ (Current Blockchains)</h4>
              <div className="space-y-3 text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
                <div className="flex items-start gap-3"><XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" /><p className="text-[#8899A6]">Transactions are irreversible — mistakes and fraud are permanent</p></div>
                <div className="flex items-start gap-3"><XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" /><p className="text-[#8899A6]">No built-in fraud detection — rely on third-party services</p></div>
                <div className="flex items-start gap-3"><XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" /><p className="text-[#8899A6]">Stolen funds disappear through mixing services</p></div>
                <div className="flex items-start gap-3"><XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" /><p className="text-[#8899A6]">No insurance, no recovery, no recourse for victims</p></div>
              </div>
            </div>
            <div className="bg-[#152238] rounded-xl border border-[#00D4FF]/20 p-6">
              <h4 className="text-white font-semibold mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>With ACIP™ (AUC Standard)</h4>
              <div className="space-y-3 text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
                <div className="flex items-start gap-3"><CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" /><p className="text-[#8899A6]">Protocol-level integrity validation on every transaction</p></div>
                <div className="flex items-start gap-3"><CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" /><p className="text-[#8899A6]">Autonomous anomaly detection — fraud caught at the protocol layer</p></div>
                <div className="flex items-start gap-3"><CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" /><p className="text-[#8899A6]">Self-defending architecture — tamper-proof by design</p></div>
                <div className="flex items-start gap-3"><CheckCircle2 className="w-4 h-4 text-[#00FF88] mt-0.5 shrink-0" /><p className="text-[#8899A6]">Community insurance vault backs every protected transaction</p></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-[#152238] to-[#0A1628] rounded-xl border border-[#FFD700]/30 p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-3" style={{ fontFamily: 'Orbitron, sans-serif' }}>
              License ACIP™ for Your Blockchain
            </h3>
            <p className="text-[#8899A6] max-w-2xl mx-auto mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Alpha Chain Integrity Protocol™ is available for licensing to other blockchain networks. 
              Bring protocol-level transaction integrity to your ecosystem and protect your users from the $14B+ annual crypto fraud epidemic.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#FFD700]/10 border border-[#FFD700]/20">
                <BadgeCheck className="w-4 h-4 text-[#FFD700]" />
                <span className="text-[#FFD700] text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>Patent Pending</span>
              </div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00D4FF]/10 border border-[#00D4FF]/20">
                <Shield className="w-4 h-4 text-[#00D4FF]" />
                <span className="text-[#00D4FF] text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>Enterprise Licensing Available</span>
              </div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00FF88]/10 border border-[#00FF88]/20">
                <Globe className="w-4 h-4 text-[#00FF88]" />
                <span className="text-[#00FF88] text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>Multi-Chain Compatible</span>
              </div>
            </div>
            <a
              href="mailto:licensing@alphaunlimitedtrading.com"
              className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-[#0A1628] font-bold rounded-lg text-lg hover:opacity-90 transition-opacity"
              style={{ fontFamily: 'Poppins, sans-serif' }}
              data-testid="link-licensing-inquiry"
            >
              <Mail className="w-5 h-5" /> Licensing Inquiries
            </a>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 border-t border-[#1A2942]">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial="hidden" animate="visible"
            variants={fadeIn} transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, sans-serif' }}>
              The Safest Blockchain Ever Built
            </h2>
            <p className="text-[#8899A6] mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
              No other blockchain has transaction-level safety, integrity verification, asset tokenization, and insurance built into the protocol itself.
              AUC protects your funds before, during, and after every transfer.
            </p>
            <a
              href="/terminal"
              className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-bold rounded-lg text-lg hover:opacity-90 transition-opacity"
              style={{ fontFamily: 'Poppins, sans-serif' }}
              data-testid="link-start-trading"
            >
              Start Trading with SafeSend <ArrowRight className="w-5 h-5" />
            </a>
          </motion.div>
        </div>
      </section>

      <section className="py-8 px-4 bg-[#0A1628] border-t border-[#1A2942]">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-[#475569] text-xs leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Alpha Chain Integrity Protocol™ (ACIP™), Alpha SafeSend Protocol™, and Alpha SafeAsset Protocol™ are patent-pending technologies
            of Alpha Unlimited Trading Company. All rights reserved. These technologies are protected by international intellectual property law.
            Unauthorized reproduction, modification, or distribution is strictly prohibited. Licensing inquiries: licensing@alphaunlimitedtrading.com
          </p>
        </div>
      </section>
    </div>
    </TradingPlatformLayout>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="bg-[#152238] rounded-xl border border-[#1A2942] px-6 py-4 min-w-[160px]">
      <div className="flex items-center gap-2 mb-1">
        <Icon className="w-4 h-4 text-[#00D4FF]" />
        <span className="text-[#8899A6] text-xs" style={{ fontFamily: 'Poppins, sans-serif' }}>{label}</span>
      </div>
      <p className="text-white text-xl font-bold" style={{ fontFamily: 'Orbitron, sans-serif' }}>{value}</p>
    </div>
  );
}

function SectionHeader({ icon: Icon, title, subtitle }: { icon: any; title: string; subtitle: string }) {
  return (
    <motion.div
      initial="hidden" animate="visible"
      variants={fadeIn} transition={{ duration: 0.5 }}
      className="text-center"
    >
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#00D4FF]/10 border border-[#00D4FF]/20 mb-4">
        <Icon className="w-6 h-6 text-[#00D4FF]" />
      </div>
      <h2 className="text-2xl md:text-3xl font-bold text-white mb-2" style={{ fontFamily: 'Orbitron, sans-serif' }}>{title}</h2>
      <p className="text-[#8899A6] max-w-2xl mx-auto" style={{ fontFamily: 'Poppins, sans-serif' }}>{subtitle}</p>
    </motion.div>
  );
}

function FlowCard({ step, icon: Icon, title, description, color }: { step: number; icon: any; title: string; description: string; color: string }) {
  return (
    <motion.div
      initial="hidden" animate="visible"
      variants={fadeIn} transition={{ duration: 0.5, delay: step * 0.15 }}
      className="bg-[#152238] rounded-xl border border-[#1A2942] p-6 relative"
    >
      <div className="absolute top-4 right-4 text-4xl font-bold text-white/5" style={{ fontFamily: 'Orbitron, sans-serif' }}>{step}</div>
      <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: `${color}15`, border: `1px solid ${color}30` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <h3 className="text-white font-semibold mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>{title}</h3>
      <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>{description}</p>
    </motion.div>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: any; title: string; description: string }) {
  return (
    <motion.div
      initial="hidden" animate="visible"
      variants={fadeIn} transition={{ duration: 0.5 }}
      className="bg-[#152238] rounded-xl border border-[#1A2942] p-6 hover:border-[#00D4FF]/20 transition-colors"
    >
      <Icon className="w-8 h-8 text-[#00D4FF] mb-3" />
      <h3 className="text-white font-semibold mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>{title}</h3>
      <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>{description}</p>
    </motion.div>
  );
}

function VaultStatCard({ label, value, icon: Icon }: { label: string; value: string | number; icon: any }) {
  return (
    <div className="bg-[#152238] rounded-xl border border-[#1A2942] p-4 text-center">
      <Icon className="w-6 h-6 text-[#00D4FF] mx-auto mb-2" />
      <p className="text-white text-lg font-bold" style={{ fontFamily: 'Orbitron, sans-serif' }}>{value}</p>
      <p className="text-[#8899A6] text-xs" style={{ fontFamily: 'Poppins, sans-serif' }}>{label}</p>
    </div>
  );
}

function VerificationLayer({ number, title, description, icon: Icon }: { number: number; title: string; description: string; icon: any }) {
  return (
    <div className="flex gap-4 items-start">
      <div className="w-8 h-8 rounded-full bg-[#00D4FF]/10 border border-[#00D4FF]/30 flex items-center justify-center shrink-0">
        <span className="text-[#00D4FF] text-sm font-bold" style={{ fontFamily: 'Orbitron, sans-serif' }}>{number}</span>
      </div>
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Icon className="w-4 h-4 text-[#00D4FF]" />
          <h4 className="text-white font-semibold text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>{title}</h4>
        </div>
        <p className="text-[#8899A6] text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>{description}</p>
      </div>
    </div>
  );
}

function ComparisonRow({ feature, auc, btc, eth, sol }: { feature: string; auc: boolean | string; btc: boolean | string; eth: boolean | string; sol: boolean | string }) {
  const renderCell = (val: boolean | string) => {
    if (val === true) return <CheckCircle2 className="w-5 h-5 text-[#00FF88] mx-auto" />;
    if (val === false) return <XCircle className="w-5 h-5 text-[#475569] mx-auto" />;
    return <span className="text-[#FFD700] text-xs">{val}</span>;
  };
  return (
    <tr className="border-b border-[#1A2942]/50 hover:bg-[#152238]/30">
      <td className="py-3 px-4 text-white">{feature}</td>
      <td className="py-3 px-4 text-center bg-[#00D4FF]/5">{renderCell(auc)}</td>
      <td className="py-3 px-4 text-center">{renderCell(btc)}</td>
      <td className="py-3 px-4 text-center">{renderCell(eth)}</td>
      <td className="py-3 px-4 text-center">{renderCell(sol)}</td>
    </tr>
  );
}

function IntegrityDiagram() {
  return (
    <div className="bg-[#152238] rounded-xl border border-[#1A2942] p-8">
      <h4 className="text-white font-semibold mb-6 text-center" style={{ fontFamily: 'Poppins, sans-serif' }}>
        How ACIP™ Validates Transaction Integrity Across the Network
      </h4>
      <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-2">
        <IntegrityNode label="Origin" sublabel="Wallet A" color="#00D4FF" isStart />
        <IntegrityArrow label="Validates integrity" />
        <IntegrityNode label="Destination" sublabel="Wallet B" color="#FFD700" />
        <IntegrityArrow label="Consensus thread" />
        <IntegrityNode label="Thread 1" sublabel="Wallet C" color="#8899A6" />
        <IntegrityArrow label="Validates path" />
        <IntegrityNode label="Thread 2" sublabel="Wallet D" color="#8899A6" />
        <IntegrityArrow label="Anomaly detected" alert />
        <IntegrityNode label="ALERT" sublabel="Protocol Action" color="#FF4444" isAlert />
      </div>
      <div className="mt-6 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 border border-red-500/20">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span className="text-red-400 text-sm font-medium" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Integrity violation detected — protocol autonomously initiates protective measures
          </span>
        </div>
      </div>
    </div>
  );
}

function IntegrityNode({ label, sublabel, color, isStart, isAlert }: { label: string; sublabel: string; color: string; isStart?: boolean; isAlert?: boolean }) {
  return (
    <div
      className={`flex flex-col items-center p-3 rounded-lg border min-w-[90px] ${isAlert ? 'animate-pulse' : ''}`}
      style={{
        borderColor: `${color}40`,
        backgroundColor: `${color}10`,
      }}
    >
      <div
        className="w-8 h-8 rounded-full flex items-center justify-center mb-1"
        style={{ backgroundColor: `${color}20`, border: `2px solid ${color}` }}
      >
        {isAlert ? (
          <AlertTriangle className="w-4 h-4" style={{ color }} />
        ) : isStart ? (
          <Zap className="w-4 h-4" style={{ color }} />
        ) : (
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
        )}
      </div>
      <span className="text-xs font-semibold" style={{ color, fontFamily: 'Poppins, sans-serif' }}>{label}</span>
      <span className="text-[10px] text-[#8899A6]" style={{ fontFamily: 'Poppins, sans-serif' }}>{sublabel}</span>
    </div>
  );
}

function IntegrityArrow({ label, alert }: { label: string; alert?: boolean }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <ArrowRight className={`w-5 h-5 ${alert ? 'text-red-400' : 'text-[#475569]'} hidden md:block`} />
      <span className={`text-[10px] ${alert ? 'text-red-400 font-bold' : 'text-[#475569]'} whitespace-nowrap`} style={{ fontFamily: 'Poppins, sans-serif' }}>
        {label}
      </span>
    </div>
  );
}

export default SafeSendProtocol;
