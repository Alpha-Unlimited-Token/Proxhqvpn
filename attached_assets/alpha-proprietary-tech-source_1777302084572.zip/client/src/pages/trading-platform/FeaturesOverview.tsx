/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Platform Features Showcase™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Alpha Unlimited Trading Platform™
 * - Feature Discovery Engine™
 * - Technology Showcase System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_08a789341ceb42dc869d9a70
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  TrendingUp,
  BarChart3,
  BookOpen,
  ArrowRight,
  Shield,
  Globe,
  ChevronDown,
  ChevronUp,
  Zap,
  Users,
  FlaskConical,
  Sparkles,
  Brain,
  Activity,
  Target,
  Layers,
  Lock,
  Network,
  Eye,
  Bot,
  Wallet,
  Pickaxe,
  Cpu,
  Search,
  Bell,
  LayoutDashboard,
  Gamepad2,
  LineChart,
  ArrowRightLeft,
  Scan,
  Crown,
} from "lucide-react";

const FEATURE_CATEGORIES = [
  {
    category: "Trading & Analysis",
    color: "#00D4FF",
    features: [
      {
        icon: TrendingUp,
        title: "Trading Terminal",
        description: "Professional charts with 15+ technical indicators, Spot and Futures trading modes, AI-powered signals, and real-time execution across 270+ cryptocurrencies.",
        href: "/terminal",
      },
      {
        icon: BarChart3,
        title: "Arbitrage Scanner",
        description: "Real-time price comparison across 10+ exchanges. Identify instant arbitrage opportunities with automated alerts and profit calculations.",
        href: "/arbitrage",
      },
      {
        icon: FlaskConical,
        title: "Strategy Backtesting",
        description: "Interactive historical data charts to test and validate strategies risk-free. Backtest against years of market data before risking capital.",
        href: "/backtest",
      },
      {
        icon: LineChart,
        title: "Trading Probability Calculator",
        description: "Calculate trade probability scores using proprietary algorithms. Combines multiple technologies for statistically-grounded entry/exit decisions.",
        href: "/probability-calculator",
      },
      {
        icon: TrendingUp,
        title: "Futures & Short Selling",
        description: "Open long and short positions on Binance Futures, Bybit, and OKX with up to 125x leverage. Cross and Isolated margin modes with real-time liquidation tracking.",
        href: "/terminal",
      },
      {
        icon: Target,
        title: "Advanced Orders",
        description: "Stop-loss, take-profit, trailing stops, OCO orders, and conditional triggers. Professional-grade order management for every strategy including futures.",
        href: "/terminal",
      },
    ],
  },
  {
    category: "AI & Automation",
    color: "#a855f7",
    features: [
      {
        icon: Bot,
        title: "AI Trading Bots",
        description: "14 automated bot strategies including Grid, DCA, Trailing Stop, Signal-based, and Futures bots with long/short positions. Paper trading simulator for risk-free testing.",
        href: "/terminal",
      },
      {
        icon: Brain,
        title: "AI Trading Assistant",
        description: "Personalized AI-powered insights, trend predictions with confidence scores, and strategy recommendations tailored to your trading style.",
        href: "/terminal",
      },
      {
        icon: Activity,
        title: "News Sentiment Analysis",
        description: "Real-time news sentiment scoring for crypto assets and market events. Premium subscribers get AI-powered analysis. Gauge market mood before making trades.",
        href: "/terminal",
      },
      {
        icon: Cpu,
        title: "Alpha Autonomous Command Center™",
        description: "Fully autonomous AI trading system. Scans markets, deploys long and short bots on futures exchanges, rotates capital, and manages risk — all without human intervention.",
        href: "/command-center",
      },
    ],
  },
  {
    category: "Social & Community",
    color: "#22c55e",
    features: [
      {
        icon: Users,
        title: "Copy & Social Trading",
        description: "Follow top traders, copy their trades automatically, and share your achievements. Social feed with real-time trading activity.",
        href: "/social-feed",
      },
      {
        icon: Eye,
        title: "Whale Alerts",
        description: "Real-time push notifications for whale movements, price alerts, and trading signals. Track large transactions across all blockchains.",
        href: "/terminal",
      },
      {
        icon: Crown,
        title: "Ambassador Program",
        description: "Earn 10% referral commissions, unlock exclusive access, and climb through Bronze, Silver, Gold, and Diamond tiers.",
        href: "/ambassador",
      },
    ],
  },
  {
    category: "Portfolio & DeFi",
    color: "#FFD700",
    features: [
      {
        icon: Wallet,
        title: "Portfolio Tracker",
        description: "Multi-asset tracker with profit/loss visualization and personalized performance reports. Track holdings across all connected exchanges.",
        href: "/terminal",
      },
      {
        icon: Network,
        title: "DEX & DeFi Integration",
        description: "Trade directly on Uniswap, Jupiter, PancakeSwap, and access DeFi yield farming protocols. Multi-chain swaps in one interface.",
        href: "/terminal",
      },
      {
        icon: ArrowRightLeft,
        title: "AUC Exchange",
        description: "Native exchange for Alpha Unlimited Coin with 0.25% trading fees. Built on our custom Proof of Work blockchain with SHA-256 hashing.",
        href: "/exchange",
      },
      {
        icon: Globe,
        title: "32+ Exchanges & 57 Wallets",
        description: "Connect to major exchanges and wallets including DEXs, hardware wallets, and custodial services. Universal trading interface.",
        href: "/terminal",
      },
    ],
  },
  {
    category: "Tools & Customization",
    color: "#f97316",
    features: [
      {
        icon: LayoutDashboard,
        title: "Custom Dashboard",
        description: "Customizable dashboard widgets for data visualization with drag-and-drop layout. Build your perfect trading workspace.",
        href: "/terminal",
      },
      {
        icon: BookOpen,
        title: "Learning Center & Tutorials",
        description: "Interactive tutorials for new trading strategies and platform features. From beginner basics to advanced proprietary technology guides.",
        href: "/learn",
      },
      {
        icon: Sparkles,
        title: "Gamified Rewards & NFTs",
        description: "Earn rewards as an active trader and NFT holder. Achievement-based incentives, exclusive NFT marketplace with multi-crypto payments.",
        href: "/nft",
      },
      {
        icon: Pickaxe,
        title: "Mining Companion",
        description: "Solo Bitcoin mining companion app. Connect your hardware, monitor hashrate, and track progress toward solving blocks.",
        href: "/miner",
      },
      {
        icon: Shield,
        title: "Multi-Factor Authentication",
        description: "Enhanced account security with TOTP-based two-factor authentication. Industry-leading 89 protection features across 8 security layers.",
        href: "/security",
      },
    ],
  },
];

const PLATFORM_STATS = [
  { value: "85+", label: "Platform Features" },
  { value: "270+", label: "Cryptocurrencies" },
  { value: "32+", label: "Exchanges" },
  { value: "70+", label: "Blockchains" },
  { value: "20", label: "Proprietary Technologies" },
  { value: "89", label: "Security Features" },
];

export default function FeaturesOverview() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  return (
    <TradingPlatformLayout>
      <section className="py-20 sm:py-28">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <span className="text-[#00D4FF] font-medium text-sm uppercase tracking-wider">Platform Features</span>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4" data-testid="text-features-title">
              Everything You Need to Trade
            </h1>
            <p className="text-[#8899A6] max-w-2xl mx-auto text-lg" data-testid="text-features-subtitle">
              Professional-grade tools for every trader — from AI-powered automation to social trading, DeFi integration, and beyond.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-16">
            {PLATFORM_STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="text-center p-4 bg-[#0D1117] border border-[#1A2942] rounded-xl"
                data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="text-xl font-bold text-white">{stat.value}</div>
                <div className="text-xs text-[#475569] mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <div className="space-y-12">
            {FEATURE_CATEGORIES.map((cat, catIdx) => (
              <motion.div
                key={cat.category}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: catIdx * 0.05 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-1 h-8 rounded-full" style={{ background: cat.color }} />
                  <h2 className="text-2xl font-bold text-white" data-testid={`text-category-${cat.category.toLowerCase().replace(/\s+/g, '-')}`}>
                    {cat.category}
                  </h2>
                  <span className="text-xs text-[#475569] bg-[#111827] px-2.5 py-1 rounded-full border border-[#1E293B]">
                    {cat.features.length} features
                  </span>
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {cat.features.map((feature, i) => (
                    <Link key={feature.title} href={feature.href}>
                      <div
                        className="group p-5 bg-[#0D1117] border border-[#1A2942] rounded-xl hover:border-[#2A3952] transition-all cursor-pointer h-full"
                        style={{ ["--hover-color" as string]: cat.color }}
                        data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                            style={{ background: `${cat.color}15` }}
                          >
                            <feature.icon size={20} style={{ color: cat.color }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-semibold text-white mb-1.5 group-hover:text-[#00D4FF] transition-colors">
                              {feature.title}
                            </h3>
                            <p className="text-[#8899A6] text-xs leading-relaxed">
                              {feature.description}
                            </p>
                            <div className="flex items-center gap-1 mt-3 text-xs opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: cat.color }}>
                              <span>Explore</span>
                              <ArrowRight size={12} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mt-20"
          >
            <h2 className="text-3xl font-bold text-white mb-4">Ready to explore?</h2>
            <p className="text-[#8899A6] mb-8 max-w-lg mx-auto">
              Launch the terminal to access all features, or dive into our proprietary technology.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/terminal">
                <button
                  className="px-8 py-3 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-lg transition-colors"
                  data-testid="button-launch-terminal-features"
                >
                  Launch Terminal
                  <ArrowRight size={16} className="inline-block ml-2" />
                </button>
              </Link>
              <Link href="/technology">
                <button
                  className="px-8 py-3 bg-[#0D1117] border border-[#1A2942] hover:border-[#2A3952] text-white font-medium rounded-lg transition-colors"
                  data-testid="button-view-technology"
                >
                  View Proprietary Technology
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}
