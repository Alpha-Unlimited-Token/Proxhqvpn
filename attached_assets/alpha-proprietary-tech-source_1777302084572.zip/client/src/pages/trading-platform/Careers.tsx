/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Recruitment Portal™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Recruitment Portal™
 * - Application Processing System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_5e8223cd5366f204c841b868
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { TradingPlatformFooter } from "@/components/trading-platform/TradingPlatformFooter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

const SPECIALTIES = [
  {
    id: "security-researcher",
    title: "Security Researcher / Ethical Hacker",
    icon: "shield",
    color: "from-red-500 to-orange-500",
    border: "border-red-900/40",
    description: "Penetration testing, vulnerability discovery, smart contract auditing, and blockchain security analysis. Help us build the most secure platform in crypto.",
    skills: ["Penetration Testing", "Smart Contract Auditing", "Reverse Engineering", "CVE Research", "Bug Bounty Experience"],
  },
  {
    id: "reformed-blackhat",
    title: "Reformed Black Hat / Gray Hat",
    icon: "zap",
    color: "from-purple-500 to-pink-500",
    border: "border-purple-900/40",
    description: "Your past doesn't define your future. If you've operated on the other side and want to channel your skills for good, we want to talk. No judgment — just opportunity. Turn your deep knowledge of exploits, attack vectors, and system vulnerabilities into a legitimate, well-paying career protecting people instead of hurting them.",
    skills: ["Exploit Development", "Social Engineering Awareness", "Network Intrusion Knowledge", "Malware Analysis", "Dark Web Intelligence"],
    highlight: true,
  },
  {
    id: "blockchain-forensics",
    title: "Blockchain Forensic Analyst",
    icon: "search",
    color: "from-cyan-500 to-blue-500",
    border: "border-cyan-900/40",
    description: "Trace stolen funds, analyze on-chain evidence, and help recover assets for victims. Work with our Forensic Intelligence Engine to bring justice to the blockchain.",
    skills: ["On-Chain Analysis", "Transaction Tracing", "Mixer/Bridge Tracking", "OSINT", "Law Enforcement Collaboration"],
  },
  {
    id: "fullstack-engineer",
    title: "Full-Stack Engineer",
    icon: "code",
    color: "from-green-500 to-emerald-500",
    border: "border-green-900/40",
    description: "Build production-grade trading systems, real-time dashboards, and blockchain integrations. React, TypeScript, Node.js, PostgreSQL, and WebSocket expertise.",
    skills: ["React / TypeScript", "Node.js / Express", "PostgreSQL / Drizzle ORM", "WebSocket / Real-Time Systems", "REST API Design"],
  },
  {
    id: "ai-ml-engineer",
    title: "AI / Machine Learning Engineer",
    icon: "brain",
    color: "from-yellow-500 to-amber-500",
    border: "border-yellow-900/40",
    description: "Develop AI trading bots, market prediction models, and autonomous trading systems. Our AACC scans 270+ coins every 30 seconds — help us make it smarter.",
    skills: ["Python / TensorFlow / PyTorch", "Time Series Forecasting", "NLP for Sentiment Analysis", "Reinforcement Learning", "Quantitative Finance"],
  },
  {
    id: "smart-contract-dev",
    title: "Smart Contract Developer",
    icon: "file-code",
    color: "from-blue-500 to-indigo-500",
    border: "border-blue-900/40",
    description: "Architect and deploy smart contracts for our AUC blockchain, NFT marketplace, SafeSend Protocol, and SafeAsset tokenization platform.",
    skills: ["Solidity / Vyper", "EVM Architecture", "Token Standards (ERC-20/721/1155)", "DeFi Protocol Design", "Gas Optimization"],
  },
  {
    id: "devops-infra",
    title: "DevOps / Infrastructure Engineer",
    icon: "server",
    color: "from-teal-500 to-cyan-500",
    border: "border-teal-900/40",
    description: "Keep our trading platform running 24/7 with zero downtime. Manage real-time data pipelines, blockchain nodes, and high-frequency trading infrastructure.",
    skills: ["Linux / Docker / Kubernetes", "CI/CD Pipelines", "Monitoring & Alerting", "Database Optimization", "Load Balancing / Scaling"],
  },
  {
    id: "ui-ux-designer",
    title: "UI/UX Designer",
    icon: "palette",
    color: "from-pink-500 to-rose-500",
    border: "border-pink-900/40",
    description: "Design beautiful, intuitive interfaces for complex trading tools. Make professional-grade crypto technology accessible to everyone.",
    skills: ["Figma / Sketch", "Design Systems", "Data Visualization", "Mobile-First Design", "User Research"],
  },
  {
    id: "quant-trader",
    title: "Quantitative Trader / Strategist",
    icon: "trending-up",
    color: "from-orange-500 to-red-500",
    border: "border-orange-900/40",
    description: "Design and validate trading strategies for our 14 AI bot types. Backtest algorithms, optimize parameters, and push the boundaries of algorithmic trading.",
    skills: ["Quantitative Analysis", "Statistical Modeling", "Backtesting Frameworks", "Risk Management", "Market Microstructure"],
  },
  {
    id: "community-marketing",
    title: "Community Manager / Marketing",
    icon: "megaphone",
    color: "from-lime-500 to-green-500",
    border: "border-lime-900/40",
    description: "Grow our community, create content, and spread the word. Help us build the largest community of AI-powered traders in the world.",
    skills: ["Social Media Management", "Content Creation", "Community Building", "Crypto Twitter / Discord", "Growth Marketing"],
  },
  {
    id: "legal-compliance",
    title: "Legal / Compliance Specialist",
    icon: "gavel",
    color: "from-slate-400 to-gray-500",
    border: "border-gray-700/40",
    description: "Navigate the evolving regulatory landscape. Help with exchange compliance, forensic evidence standards, law enforcement coordination, and international crypto law.",
    skills: ["Crypto Regulations", "AML/KYC Compliance", "Securities Law", "Digital Asset Classification", "Cross-Border Legal"],
  },
  {
    id: "other",
    title: "Other / Surprise Us",
    icon: "star",
    color: "from-amber-400 to-yellow-500",
    border: "border-yellow-900/40",
    description: "Don't fit neatly into a category? Great minds don't always. If you have skills that can help build the future of crypto trading, we want to hear from you.",
    skills: ["Tell Us Your Skills"],
  },
];

export default function Careers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    specialty: "",
    experience: "",
    background: "",
    portfolio: "",
    whyJoin: "",
    availability: "full-time",
    remote: "remote",
  });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Login Required",
        description: "You must create an account or log in to submit a career application.",
        variant: "destructive",
      });
      setTimeout(() => { window.location.href = "/api/login"; }, 1500);
      return;
    }
    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await fetch("/api/careers/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData, specialty: selectedSpecialty }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSubmitError(data.message || "Something went wrong. Please try again.");
      } else {
        setSubmitted(true);
      }
    } catch {
      setSubmitError("Network error. Please check your connection and try again.");
    }
    setSubmitting(false);
  };

  const spec = SPECIALTIES.find(s => s.id === selectedSpecialty);

  return (
    <div className="min-h-screen bg-[#050a12] text-gray-200">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-900/10 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-cyan-500/5 to-transparent rounded-full blur-3xl" />

        <div className="relative max-w-6xl mx-auto px-4 pt-20 pb-12">
          <Link href="/">
            <span className="text-sm text-cyan-400 hover:text-cyan-300 cursor-pointer mb-6 inline-block" data-testid="link-back-home">&larr; Back to Platform</span>
          </Link>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-careers-title">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400">
                Build the Future of Crypto
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mb-3" data-testid="text-careers-subtitle">
              We're assembling a team of extraordinary minds — engineers, hackers, traders, and visionaries.
            </p>
            <p className="text-base text-gray-500 max-w-3xl mb-8">
              Great minds think alike, but <span className="text-cyan-400 font-medium">like-minded minds think beyond</span> the minds they think alike. We don't care about your past — we care about your potential. Whether you're a self-taught coder, a reformed hacker, a quant from Wall Street, or someone who just sees the world differently — if you can make this company extraordinary, we want you.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative rounded-2xl overflow-hidden border border-purple-800/30 mb-12"
            data-testid="section-blackhat-cta"
          >
            <div className="relative w-full aspect-[16/7] overflow-hidden">
              <img
                src="/assets/phoenix/alpha-phoenix-hacker-v4.png"
                alt="Alpha Phoenix Hacker Mascot"
                className="w-full h-full object-cover"
                loading="lazy"
                data-testid="img-phoenix-hacker"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050a12] via-[#050a12]/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className="inline-block px-3 py-1 bg-purple-600/80 text-white text-xs font-bold rounded-full mb-2 backdrop-blur-sm">NOW RECRUITING</span>
              </div>
            </div>
            <div className="bg-gradient-to-r from-purple-900/20 to-red-900/20 p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl flex-shrink-0">
                &#x26A1;
              </div>
              <div>
                <h2 className="text-lg font-bold text-white mb-2">To the Black Hats, Gray Hats, and Everyone In Between</h2>
                <p className="text-gray-400 leading-relaxed">
                  We get it. The skills you have are rare and powerful. You've seen how systems break, how exploits work, and how vulnerabilities hide in plain sight. Those skills are <span className="text-purple-400 font-medium">incredibly valuable</span> on this side of the fence.
                </p>
                <p className="text-gray-400 leading-relaxed mt-2">
                  Want to turn your life around? Want to make <span className="text-green-400 font-medium">real, positive, residual income</span> without looking over your shoulder? We're not here to judge your past. We're here to build a future where your talents protect people instead of exploiting them. Our forensic systems, security architecture, and threat detection need minds that think like attackers.
                </p>
                <p className="text-gray-500 text-sm mt-3 italic">
                  "The best defenders are those who once attacked." — Every cybersecurity firm that matters knows this.
                </p>
              </div>
            </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-gradient-to-r from-emerald-900/15 via-[#0d1117] to-cyan-900/15 border border-emerald-800/30 rounded-xl p-6 mb-12"
            data-testid="section-bounty-compensation"
          >
            <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <span className="text-2xl">💰</span>
              Recovery Bounty Participation Program
            </h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              When our forensic team helps recover stolen crypto, the company earns a 10% recovery bounty from the victim. 
              We believe the people who do the work should share in the reward. Here's how the bounty is distributed:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="bg-[#0d1117] rounded-lg p-5 border border-emerald-800/20" data-testid="card-bounty-company">
                <div className="text-3xl font-bold text-emerald-400 mb-1" style={{ fontFamily: "Orbitron, sans-serif" }}>60%</div>
                <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Alpha Unlimited Trading Company</div>
                <p className="text-xs text-gray-400">Infrastructure, legal, licensing, R&D, platform development, and operational costs. Keeps the technology cutting-edge and the company growing.</p>
              </div>
              <div className="bg-[#0d1117] rounded-lg p-5 border border-cyan-800/20" data-testid="card-bounty-team">
                <div className="text-3xl font-bold text-cyan-400 mb-1" style={{ fontFamily: "Orbitron, sans-serif" }}>40%</div>
                <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Team Distribution Pool</div>
                <p className="text-xs text-gray-400">Divided equally among all team members who contributed to the recovery — forensic analysts, security researchers, engineers, investigators. Everyone who helped gets an equal share.</p>
              </div>
            </div>

            <div className="bg-[#0a0f17] rounded-lg p-4 border border-gray-800/30">
              <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Example Scenario</div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
                <div>
                  <div className="text-xs text-gray-500">Stolen Amount</div>
                  <div className="text-sm font-bold text-white">$1,000,000</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">10% Recovery Bounty</div>
                  <div className="text-sm font-bold text-emerald-400">$100,000</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Team Pool (40%)</div>
                  <div className="text-sm font-bold text-cyan-400">$40,000</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Per Team Member (5 people)</div>
                  <div className="text-sm font-bold text-yellow-400">$8,000 each</div>
                </div>
              </div>
              <p className="text-[10px] text-gray-600 text-center mt-2">
                Paid in crypto within 14 days of bounty funds being released. The bigger the case, the bigger the reward. Some cases are worth millions.
              </p>
            </div>
          </motion.div>

          <h2 className="text-2xl font-bold text-white mb-6" data-testid="text-specialties-heading">Choose Your Specialty</h2>

          {!selectedSpecialty ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12"
              data-testid="section-specialty-grid"
            >
              {SPECIALTIES.map((s, i) => (
                <motion.button
                  key={s.id}
                  data-testid={`button-specialty-${s.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => setSelectedSpecialty(s.id)}
                  className={`text-left p-5 rounded-xl border ${s.border} bg-[#0d1117] hover:bg-[#161b22] transition-all group ${s.highlight ? "ring-1 ring-purple-500/30" : ""}`}
                >
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${s.color} flex items-center justify-center text-white text-lg mb-3 group-hover:scale-110 transition-transform`}>
                    {s.icon === "shield" && "\u{1F6E1}"}
                    {s.icon === "zap" && "\u26A1"}
                    {s.icon === "search" && "\u{1F50D}"}
                    {s.icon === "code" && "\u{1F4BB}"}
                    {s.icon === "brain" && "\u{1F9E0}"}
                    {s.icon === "file-code" && "\u{1F4DC}"}
                    {s.icon === "server" && "\u{1F5A5}"}
                    {s.icon === "palette" && "\u{1F3A8}"}
                    {s.icon === "trending-up" && "\u{1F4C8}"}
                    {s.icon === "megaphone" && "\u{1F4E3}"}
                    {s.icon === "gavel" && "\u2696"}
                    {s.icon === "star" && "\u2B50"}
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">{s.title}</h3>
                  <p className="text-gray-500 text-xs leading-relaxed line-clamp-2">{s.description}</p>
                  {s.highlight && (
                    <span className="inline-block mt-2 text-[10px] bg-purple-600/20 text-purple-400 border border-purple-600/30 rounded px-2 py-0.5">
                      Your skills are needed here
                    </span>
                  )}
                </motion.button>
              ))}
            </motion.div>
          ) : !submitted ? (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto mb-12">
              <button
                data-testid="button-back-to-specialties"
                onClick={() => setSelectedSpecialty(null)}
                className="text-sm text-cyan-400 hover:text-cyan-300 mb-4 inline-block cursor-pointer"
              >
                &larr; Back to all specialties
              </button>

              {spec && (
                <div className={`p-5 rounded-xl border ${spec.border} bg-[#0d1117] mb-6`}>
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${spec.color} flex items-center justify-center text-white text-lg mb-3`}>
                    {spec.icon === "shield" && "\u{1F6E1}"}
                    {spec.icon === "zap" && "\u26A1"}
                    {spec.icon === "search" && "\u{1F50D}"}
                    {spec.icon === "code" && "\u{1F4BB}"}
                    {spec.icon === "brain" && "\u{1F9E0}"}
                    {spec.icon === "file-code" && "\u{1F4DC}"}
                    {spec.icon === "server" && "\u{1F5A5}"}
                    {spec.icon === "palette" && "\u{1F3A8}"}
                    {spec.icon === "trending-up" && "\u{1F4C8}"}
                    {spec.icon === "megaphone" && "\u{1F4E3}"}
                    {spec.icon === "gavel" && "\u2696"}
                    {spec.icon === "star" && "\u2B50"}
                  </div>
                  <h3 className="text-white font-bold text-lg mb-2">{spec.title}</h3>
                  <p className="text-gray-400 text-sm mb-3">{spec.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {spec.skills.map(s => (
                      <span key={s} className="text-[10px] bg-[#161b22] text-gray-400 border border-gray-800 rounded px-2 py-0.5">{s}</span>
                    ))}
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-application">
                <h3 className="text-lg font-bold text-white">Apply Now</h3>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Full Name *</label>
                  <input
                    data-testid="input-name"
                    required
                    value={formData.name}
                    onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Email *</label>
                  <input
                    data-testid="input-email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData(p => ({ ...p, email: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Years of Experience *</label>
                  <select
                    data-testid="select-experience"
                    required
                    value={formData.experience}
                    onChange={e => setFormData(p => ({ ...p, experience: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                  >
                    <option value="">Select experience level</option>
                    <option value="0-1">0-1 years (Self-taught / Just starting)</option>
                    <option value="1-3">1-3 years</option>
                    <option value="3-5">3-5 years</option>
                    <option value="5-10">5-10 years</option>
                    <option value="10+">10+ years</option>
                    <option value="rather-not-say">Rather not say</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Tell Us About Yourself *</label>
                  <textarea
                    data-testid="input-background"
                    required
                    rows={4}
                    value={formData.background}
                    onChange={e => setFormData(p => ({ ...p, background: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none resize-none"
                    placeholder="Your background, skills, and what makes you unique. Be honest — we value authenticity over polished resumes."
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Portfolio / GitHub / LinkedIn (optional)</label>
                  <input
                    data-testid="input-portfolio"
                    value={formData.portfolio}
                    onChange={e => setFormData(p => ({ ...p, portfolio: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                    placeholder="https://..."
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-500 block mb-1">Why Do You Want to Join Alpha Unlimited? *</label>
                  <textarea
                    data-testid="input-why-join"
                    required
                    rows={3}
                    value={formData.whyJoin}
                    onChange={e => setFormData(p => ({ ...p, whyJoin: e.target.value }))}
                    className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none resize-none"
                    placeholder="What excites you about building the future of crypto trading?"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Availability</label>
                    <select
                      data-testid="select-availability"
                      value={formData.availability}
                      onChange={e => setFormData(p => ({ ...p, availability: e.target.value }))}
                      className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                    >
                      <option value="full-time">Full-Time</option>
                      <option value="part-time">Part-Time</option>
                      <option value="contract">Contract / Freelance</option>
                      <option value="flexible">Flexible</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Work Preference</label>
                    <select
                      data-testid="select-remote"
                      value={formData.remote}
                      onChange={e => setFormData(p => ({ ...p, remote: e.target.value }))}
                      className="w-full px-4 py-3 bg-[#0d1117] border border-gray-700 rounded-lg text-gray-200 focus:border-cyan-500 outline-none"
                    >
                      <option value="remote">Remote</option>
                      <option value="hybrid">Hybrid</option>
                      <option value="onsite">On-Site</option>
                      <option value="anywhere">Anywhere</option>
                    </select>
                  </div>
                </div>

                {submitError && (
                  <div className="p-3 bg-red-900/30 border border-red-700/50 rounded-lg text-red-400 text-sm" data-testid="text-submit-error">
                    {submitError}
                  </div>
                )}

                <button
                  data-testid="button-submit-application"
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg font-bold text-sm transition-all"
                >
                  {submitting ? "Submitting..." : "Submit Application"}
                </button>

                <p className="text-xs text-gray-600 text-center">
                  All applications are reviewed personally. We respond to every single one.
                </p>
              </form>
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-lg mx-auto text-center py-16 mb-12" data-testid="section-application-success">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white text-4xl mx-auto mb-6">
                &#x2714;
              </div>
              <h2 className="text-2xl font-bold text-white mb-3">Application Received</h2>
              <p className="text-gray-400 mb-6">
                Thank you for your interest in Alpha Unlimited Trading. We review every application personally and will be in touch soon.
              </p>
              <button
                data-testid="button-submit-another"
                onClick={() => { setSubmitted(false); setSelectedSpecialty(null); setFormData({ name: "", email: "", specialty: "", experience: "", background: "", portfolio: "", whyJoin: "", availability: "full-time", remote: "remote" }); }}
                className="px-6 py-2 bg-[#161b22] border border-gray-700 hover:border-cyan-500 text-gray-300 rounded-lg text-sm transition-all"
              >
                Submit Another Application
              </button>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          >
            <div className="bg-[#0d1117] border border-gray-800 rounded-xl p-6 text-center" data-testid="section-perk-equity">
              <div className="text-3xl mb-3">&#x1F4B0;</div>
              <h3 className="text-white font-bold mb-2">Competitive Compensation</h3>
              <p className="text-gray-500 text-sm">Competitive pay, crypto bonuses, and the opportunity to earn equity in a company that's redefining the trading industry.</p>
            </div>
            <div className="bg-[#0d1117] border border-gray-800 rounded-xl p-6 text-center" data-testid="section-perk-remote">
              <div className="text-3xl mb-3">&#x1F30D;</div>
              <h3 className="text-white font-bold mb-2">100% Remote</h3>
              <p className="text-gray-500 text-sm">Work from anywhere in the world. We're a global team connected by a shared mission, not an office address.</p>
            </div>
            <div className="bg-[#0d1117] border border-gray-800 rounded-xl p-6 text-center" data-testid="section-perk-impact">
              <div className="text-3xl mb-3">&#x1F680;</div>
              <h3 className="text-white font-bold mb-2">Real Impact</h3>
              <p className="text-gray-500 text-sm">Your work directly impacts thousands of traders and helps recover millions in stolen crypto. This isn't a corporate job — it's a mission.</p>
            </div>
          </motion.div>
        </div>
      </div>

      <TradingPlatformFooter />
    </div>
  );
}