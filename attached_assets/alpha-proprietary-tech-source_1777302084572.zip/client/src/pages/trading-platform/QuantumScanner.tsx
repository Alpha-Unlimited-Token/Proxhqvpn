/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Quantum Vulnerability Scanner™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Quantum Vulnerability Scanner™
 * - ECDSA Quantum Exposure Analysis™
 * - Smart Contract Quantum Risk Assessment™
 * - Post-Quantum Readiness Scoring™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_QS_SCANNER_PAGE_SEALED
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Search, Shield, AlertTriangle, CheckCircle, XCircle, Activity, Lock, Eye } from "lucide-react";

interface VulnerabilityResult {
  address: string;
  chain: string;
  overallRisk: string;
  quantumReadinessScore: number;
  vulnerabilities: {
    id: string;
    type: string;
    severity: string;
    description: string;
    recommendation: string;
    exploitComplexity: string;
  }[];
  signatureAnalysis: {
    algorithm: string;
    keyLength: number;
    quantumVulnerable: boolean;
    estimatedTimeToBreak: string;
    nistCompliant: boolean;
  };
  contractRisks: {
    hasExposedPrivateKeys: boolean;
    usesWeakRandomness: boolean;
    vulnerableToReplay: boolean;
    ecdsaExposure: string;
  };
  scanTimestamp: string;
}

export default function QuantumScanner() {
  const [address, setAddress] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<VulnerabilityResult | null>(null);

  const handleScan = async () => {
    if (!address) return;
    setScanning(true);
    setResult(null);
    try {
      const res = await fetch("/api/quantum/scanner/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address, chain }),
      });
      const data = await res.json();
      setResult(data);
    } catch (e) { console.error(e); }
    setScanning(false);
  };

  const riskColor = (risk: string) => {
    switch (risk) {
      case "CRITICAL": return "text-red-400 bg-red-400/10";
      case "HIGH": return "text-orange-400 bg-orange-400/10";
      case "MEDIUM": return "text-yellow-400 bg-yellow-400/10";
      default: return "text-green-400 bg-green-400/10";
    }
  };

  const severityColor = (severity: string) => {
    switch (severity) {
      case "CRITICAL": return "border-red-500/50 bg-red-500/5";
      case "HIGH": return "border-orange-500/50 bg-orange-500/5";
      case "MEDIUM": return "border-yellow-500/50 bg-yellow-500/5";
      default: return "border-green-500/50 bg-green-500/5";
    }
  };

  return (
    <TradingPlatformLayout title="Quantum Vulnerability Scanner™" subtitle="ECDSA Quantum Exposure & Post-Quantum Readiness Assessment">
      <div className="space-y-6 p-4 max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30 mb-6">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Search className="w-4 h-4" /> Scan Wallet or Contract
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Input
                  data-testid="input-scan-address"
                  placeholder="Wallet or Contract Address (0x...)"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="bg-[#0a0a1a] border-gray-700 text-white text-sm md:col-span-1"
                />
                <select
                  data-testid="select-scan-chain"
                  value={chain}
                  onChange={(e) => setChain(e.target.value)}
                  className="bg-[#0a0a1a] border border-gray-700 text-white text-sm rounded-md px-3"
                >
                  <option value="ethereum">Ethereum</option>
                  <option value="bsc">BSC</option>
                  <option value="polygon">Polygon</option>
                  <option value="arbitrum">Arbitrum</option>
                  <option value="solana">Solana</option>
                  <option value="avalanche">Avalanche</option>
                  <option value="base">Base</option>
                </select>
                <Button
                  data-testid="button-scan"
                  onClick={handleScan}
                  disabled={scanning || !address}
                  className="bg-[#d4af37] hover:bg-[#b8962e] text-black"
                >
                  {scanning ? (
                    <><Activity className="w-4 h-4 mr-2 animate-spin" /> Scanning...</>
                  ) : (
                    <><Search className="w-4 h-4 mr-2" /> Scan for Vulnerabilities</>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {result && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm">Overall Risk</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-3xl font-bold ${riskColor(result.overallRisk)} inline-block px-3 py-1 rounded`}>
                      {result.overallRisk}
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-gray-400 mb-1">Quantum Readiness Score</div>
                      <div className="w-full bg-gray-800 rounded-full h-3">
                        <div
                          className={`h-3 rounded-full ${result.quantumReadinessScore > 70 ? 'bg-green-500' : result.quantumReadinessScore > 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                          style={{ width: `${result.quantumReadinessScore}%` }}
                        />
                      </div>
                      <div className="text-xs text-gray-400 mt-1">{result.quantumReadinessScore}/100</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Lock className="w-4 h-4" /> Signature Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Algorithm:</span>
                      <span className="text-gray-300">{result.signatureAnalysis.algorithm}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Key Length:</span>
                      <span className="text-gray-300">{result.signatureAnalysis.keyLength} bits</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Quantum Vulnerable:</span>
                      <span className={result.signatureAnalysis.quantumVulnerable ? 'text-red-400' : 'text-green-400'}>
                        {result.signatureAnalysis.quantumVulnerable ? "YES" : "NO"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Time to Break:</span>
                      <span className="text-gray-300">{result.signatureAnalysis.estimatedTimeToBreak}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">NIST Compliant:</span>
                      {result.signatureAnalysis.nistCompliant ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                      <Eye className="w-4 h-4" /> Contract Risks
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-2">
                    {[
                      { label: "Exposed Private Keys", value: result.contractRisks.hasExposedPrivateKeys },
                      { label: "Weak Randomness", value: result.contractRisks.usesWeakRandomness },
                      { label: "Replay Vulnerable", value: result.contractRisks.vulnerableToReplay },
                    ].map((risk, i) => (
                      <div key={i} className="flex justify-between items-center">
                        <span className="text-gray-400">{risk.label}:</span>
                        {risk.value ? (
                          <Badge variant="outline" className="text-red-400 border-red-400/30 text-[10px]">VULNERABLE</Badge>
                        ) : (
                          <Badge variant="outline" className="text-green-400 border-green-400/30 text-[10px]">SAFE</Badge>
                        )}
                      </div>
                    ))}
                    <div className="flex justify-between">
                      <span className="text-gray-400">ECDSA Exposure:</span>
                      <span className={`${result.contractRisks.ecdsaExposure === 'HIGH' ? 'text-red-400' : result.contractRisks.ecdsaExposure === 'MEDIUM' ? 'text-yellow-400' : 'text-green-400'}`}>
                        {result.contractRisks.ecdsaExposure}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
                <CardHeader>
                  <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Vulnerabilities Found ({result.vulnerabilities.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {result.vulnerabilities.length === 0 ? (
                    <div className="text-center py-6 text-gray-500">
                      <Shield className="w-10 h-10 mx-auto mb-2 opacity-30" />
                      <p>No quantum vulnerabilities detected</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {result.vulnerabilities.map((vuln, i) => (
                        <div key={i} className={`p-3 rounded-lg border ${severityColor(vuln.severity)}`}>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className={`${riskColor(vuln.severity)} border-current text-[10px]`}>
                                {vuln.severity}
                              </Badge>
                              <span className="text-sm text-gray-200">{vuln.type}</span>
                            </div>
                            <span className="text-[10px] text-gray-500">Complexity: {vuln.exploitComplexity}</span>
                          </div>
                          <p className="text-xs text-gray-400 mb-1">{vuln.description}</p>
                          <p className="text-xs text-[#d4af37]">Recommendation: {vuln.recommendation}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="mt-6 p-4 bg-[#0a0a1a] rounded-lg border border-[#d4af37]/20">
            <h3 className="text-[#d4af37] text-sm font-bold mb-2">About Quantum Vulnerability Scanner™</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">ECDSA Exposure Analysis</h4>
                <p>Analyzes wallet signing patterns to determine ECDSA private key quantum exposure. Identifies wallets using reused nonces or predictable k-values that are vulnerable to Shor's algorithm.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Contract Risk Assessment</h4>
                <p>Scans smart contracts for quantum-vulnerable cryptographic operations including weak randomness sources, exposed key material, and replay attack surfaces.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Readiness Scoring</h4>
                <p>Provides a comprehensive 0-100 quantum readiness score based on cryptographic algorithm strength, key management practices, and post-quantum migration readiness.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}
