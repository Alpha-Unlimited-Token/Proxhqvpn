/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Recovery Services™ — Public Marketing Page
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Referenced:
 * - Alpha Forensic Intelligence Engine™
 * - Autonomous Spider Trace™
 * - Alpha Phantom Vault Protocol™
 * - Exchange Freeze Request System™
 * - Multi-Chain Forensic Analysis™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: RECOVERY_SERVICES_v2.1_PROTECTED
 */

import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Shield,
  Search,
  Eye,
  FileText,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Globe,
  Zap,
  Lock,
  Database,
  Network,
  Activity,
  Users,
  Clock,
  BarChart3,
  FileCode,
  Bug,
} from "lucide-react";

const CAPABILITIES = [
  {
    icon: Search,
    title: "Complete Transaction Tracing",
    description: "Follow every token movement across multiple blockchains with our Autonomous Blockchain Spider™. Trace funds through mixers, bridges, and DEX swaps.",
    color: "#00D4FF",
  },
  {
    icon: Globe,
    title: "Multi-Chain Monitoring",
    description: "Real-time surveillance across Ethereum, Bitcoin, BSC, Polygon, Solana, TRON, and more. No blockchain is beyond our reach.",
    color: "#8247E5",
  },
  {
    icon: Eye,
    title: "Identity Lead Investigation",
    description: "Connect wallet addresses to exchange accounts, ENS domains, social profiles, and known entity databases to identify perpetrators.",
    color: "#FFD700",
  },
  {
    icon: Activity,
    title: "Real-Time Fund Flow Analysis",
    description: "Visualize complete money trails with interactive flow graphs. See exactly where stolen funds move in real-time.",
    color: "#22c55e",
  },
  {
    icon: AlertTriangle,
    title: "Exchange Detection & Alerts",
    description: "Instantly detect when stolen funds reach centralized exchanges. Automated alerts enable rapid freezing requests to compliance teams.",
    color: "#ef4444",
  },
  {
    icon: Shield,
    title: "Recovery Assistance",
    description: "Work with law enforcement agencies worldwide. Generate court-ready evidence packages and assist with asset freezing procedures.",
    color: "#a855f7",
  },
];

const REPORT_FORMATS = [
  { format: "CSV", icon: Database, description: "Spreadsheet-compatible data export", color: "#22c55e" },
  { format: "XML", icon: FileCode, description: "Structured data for legal systems", color: "#f97316" },
  { format: "JSON", icon: FileCode, description: "Machine-readable forensic data", color: "#00D4FF" },
  { format: "HTML", icon: Globe, description: "Interactive web-based reports", color: "#a855f7" },
];

const PROCESS_STEPS = [
  {
    step: 1,
    title: "Submit Your Case",
    description: "Provide wallet addresses, transaction hashes, and details about the incident. Our team reviews within 24 hours.",
    icon: FileText,
  },
  {
    step: 2,
    title: "Automated Deep Trace",
    description: "Our Forensic Intelligence Engine™ deploys autonomous spiders across all connected blockchains to map the complete fund flow.",
    icon: Bug,
  },
  {
    step: 3,
    title: "Analysis & Identification",
    description: "AI-powered risk scoring, exchange detection, and identity correlation to build a complete picture of where funds went.",
    icon: Search,
  },
  {
    step: 4,
    title: "Evidence & Recovery",
    description: "Receive comprehensive forensic reports suitable for law enforcement, exchanges, and legal proceedings.",
    icon: Shield,
  },
];

const STATS = [
  { value: "6+", label: "Blockchains Monitored", icon: Network },
  { value: "24/7", label: "Real-Time Monitoring", icon: Clock },
  { value: "5", label: "Report Formats", icon: FileText },
  { value: "100%", label: "Trace Depth Coverage", icon: BarChart3 },
];

export default function ForensicRecoveryServices() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    walletAddress: "",
    chain: "",
    estimatedLoss: "",
    description: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Login Required",
        description: "You must create an account or log in to submit a recovery service request.",
        variant: "destructive",
      });
      setTimeout(() => { window.location.href = "/api/login"; }, 1500);
      return;
    }
    if (!formData.name || !formData.email || !formData.walletAddress || !formData.description) {
      toast({
        title: "Missing information",
        description: "Please fill out name, email, wallet address, and description.",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/forensic/submit-recovery-case", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(formData),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data?.success === false) {
        throw new Error(data?.message || `Submission failed (HTTP ${res.status})`);
      }
      setSubmitted(true);
      toast({
        title: "Case received",
        description: "Our forensic team has been notified and will follow up shortly.",
      });
    } catch (err: any) {
      toast({
        title: "Submission failed",
        description: err?.message || "Please try again or email us directly.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <TradingPlatformLayout>
      <section className="relative py-20 sm:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#00D4FF]/5 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-[#00D4FF]/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-[#a855f7]/5 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="mx-auto mb-8 w-64 h-64 sm:w-80 sm:h-80 lg:w-96 lg:h-96 relative"
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#00D4FF]/20 to-[#a855f7]/20 blur-2xl" />
              <img
                src="/forensic-phoenix-tiktok-bg2.png"
                alt="Alpha Phoenix Detective"
                className="w-full h-full object-contain relative z-10 drop-shadow-[0_0_30px_rgba(0,212,255,0.3)]"
                data-testid="img-forensic-phoenix"
              />
            </motion.div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#00D4FF]/[0.08] border border-[#00D4FF]/20 rounded-full mb-5">
              <Shield size={14} className="text-[#00D4FF]" />
              <span className="text-[#00D4FF] font-medium text-xs uppercase tracking-wider" data-testid="text-forensic-badge">
                Blockchain Forensic Services
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mt-3 mb-6" data-testid="text-forensic-title">
              Forensic Recovery{" "}
              <span className="bg-gradient-to-r from-[#00D4FF] to-[#a855f7] bg-clip-text text-transparent">
                Services
              </span>
            </h1>
            <p className="text-[#8899A6] max-w-3xl mx-auto text-lg leading-relaxed" data-testid="text-forensic-subtitle">
              Lost crypto to theft, scams, or unauthorized access? Our Forensic Intelligence Engine™ 
              traces stolen funds across multiple blockchains, identifies perpetrators, and generates 
              court-ready evidence for recovery.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
              <a
                href="#submit-case"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-[#00D4FF] to-[#0066FF] text-white font-bold px-8 py-3.5 rounded-xl hover:opacity-90 transition-all text-lg"
                data-testid="button-submit-case-hero"
              >
                Submit a Case
                <ArrowRight size={20} />
              </a>
              <Link href="/forensic-tracer">
                <span
                  className="inline-flex items-center gap-2 border border-[#00D4FF]/30 text-[#00D4FF] font-medium px-8 py-3.5 rounded-xl hover:bg-[#00D4FF]/10 transition-all text-lg cursor-pointer"
                  data-testid="link-try-tracer"
                >
                  <Search size={20} />
                  Try Free Tracer
                </span>
              </Link>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-20">
            {STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-5 bg-[#0D1117] border border-[#1A2942] rounded-xl"
                data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <stat.icon size={20} className="text-[#00D4FF] mx-auto mb-2" />
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-xs text-[#475569] mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <div className="mb-20">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-1 h-8 rounded-full bg-[#00D4FF]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-white" data-testid="text-capabilities-heading">
                Forensic Intelligence Engine™
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {CAPABILITIES.map((cap, i) => (
                <motion.div
                  key={cap.title}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="p-6 bg-[#0D1117] border border-[#1A2942] rounded-xl hover:border-[#2A3952] transition-colors group"
                  data-testid={`card-capability-${i}`}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: cap.color + "15" }}
                  >
                    <cap.icon size={24} style={{ color: cap.color }} />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#00D4FF] transition-colors">
                    {cap.title}
                  </h3>
                  <p className="text-sm text-[#8899A6] leading-relaxed">{cap.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mb-20">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-1 h-8 rounded-full bg-[#a855f7]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-white" data-testid="text-process-heading">
                How It Works
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {PROCESS_STEPS.map((step, i) => (
                <motion.div
                  key={step.step}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="relative p-6 bg-[#0D1117] border border-[#1A2942] rounded-xl"
                  data-testid={`card-process-step-${step.step}`}
                >
                  <div className="absolute -top-3 -left-1 w-8 h-8 rounded-full bg-gradient-to-br from-[#00D4FF] to-[#0066FF] flex items-center justify-center text-white font-bold text-sm">
                    {step.step}
                  </div>
                  <div className="mt-2 mb-3">
                    <step.icon size={24} className="text-[#00D4FF]" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-sm text-[#8899A6] leading-relaxed">{step.description}</p>
                  {i < PROCESS_STEPS.length - 1 && (
                    <div className="hidden lg:block absolute top-1/2 -right-3 text-[#475569]">
                      <ArrowRight size={16} />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mb-20">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-1 h-8 rounded-full bg-[#22c55e]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-white" data-testid="text-reports-heading">
                Multi-Format Evidence Reports
              </h2>
            </div>
            <p className="text-[#8899A6] mb-8 max-w-3xl">
              Generate comprehensive forensic reports in multiple formats suitable for law enforcement agencies, 
              legal proceedings, exchange compliance teams, and internal investigations.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {REPORT_FORMATS.map((fmt, i) => (
                <motion.div
                  key={fmt.format}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="p-4 bg-[#0D1117] border border-[#1A2942] rounded-xl text-center hover:border-[#2A3952] transition-colors"
                  data-testid={`card-format-${fmt.format.toLowerCase()}`}
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-3"
                    style={{ backgroundColor: fmt.color + "15" }}
                  >
                    <fmt.icon size={20} style={{ color: fmt.color }} />
                  </div>
                  <div className="text-lg font-bold text-white">{fmt.format}</div>
                  <p className="text-xs text-[#8899A6] mt-1">{fmt.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mb-20 bg-gradient-to-r from-[#0D1117] to-[#152238] border border-[#1A2942] rounded-2xl p-8 sm:p-10">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4" data-testid="text-spider-heading">
                  Autonomous Blockchain Spider™
                </h2>
                <p className="text-[#8899A6] mb-6 leading-relaxed">
                  Our proprietary spider technology autonomously crawls blockchain networks, 
                  following fund flows through unlimited hops. It detects mixer usage, cross-chain bridges, 
                  DEX swaps, and smart contract interactions — building a complete map of where every 
                  satoshi or wei has traveled.
                </p>
                <div className="space-y-3">
                  {[
                    "Unlimited hop depth tracing",
                    "Cross-chain bridge detection",
                    "Mixer & tumbler identification",
                    "Smart contract interaction analysis",
                    "Known exchange address matching",
                    "Risk scoring & pattern detection",
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <CheckCircle size={16} className="text-[#22c55e] flex-shrink-0" />
                      <span className="text-sm text-white">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                  <div className="text-center mb-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#00D4FF]/20 to-[#a855f7]/20 border border-[#00D4FF]/30 flex items-center justify-center mx-auto mb-3">
                      <Bug size={28} className="text-[#00D4FF]" />
                    </div>
                    <div className="text-sm font-bold text-[#00D4FF]">Spider Active</div>
                  </div>
                  <div className="space-y-2">
                    {[
                      { chain: "Ethereum", status: "Scanning", color: "#627EEA" },
                      { chain: "Bitcoin", status: "Monitoring", color: "#F7931A" },
                      { chain: "BSC", status: "Tracing", color: "#F0B90B" },
                      { chain: "Polygon", status: "Active", color: "#8247E5" },
                      { chain: "Solana", status: "Crawling", color: "#14F195" },
                      { chain: "TRON", status: "Ready", color: "#FF0013" },
                    ].map((chain) => (
                      <div key={chain.chain} className="flex items-center justify-between px-3 py-2 bg-[#152238] rounded-lg">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: chain.color }} />
                          <span className="text-xs text-white font-medium">{chain.chain}</span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ color: chain.color, backgroundColor: chain.color + "15" }}>
                          {chain.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-20" id="submit-case">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-1 h-8 rounded-full bg-[#FFD700]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-white" data-testid="text-submit-heading">
                Submit a Case
              </h2>
            </div>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-[#0D1117] border border-[#22c55e]/30 rounded-2xl p-10 text-center"
                data-testid="text-submission-success"
              >
                <div className="w-16 h-16 rounded-full bg-[#22c55e]/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle size={32} className="text-[#22c55e]" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Case Submitted Successfully</h3>
                <p className="text-[#8899A6] max-w-md mx-auto">
                  Our forensic team will review your submission and contact you within 24 hours. 
                  In the meantime, try our free Forensic Tracer tool to begin your own investigation.
                </p>
                <Link href="/forensic-tracer">
                  <span className="inline-flex items-center gap-2 mt-6 bg-gradient-to-r from-[#00D4FF] to-[#0066FF] text-white font-bold px-6 py-3 rounded-xl hover:opacity-90 transition-all cursor-pointer">
                    <Search size={18} />
                    Open Forensic Tracer
                  </span>
                </Link>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-[#0D1117] border border-[#1A2942] rounded-2xl p-6 sm:p-8 max-w-3xl">
                <div className="grid sm:grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Your Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#475569] focus:border-[#00D4FF] focus:outline-none transition-colors"
                      placeholder="Full name"
                      data-testid="input-case-name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Email Address</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#475569] focus:border-[#00D4FF] focus:outline-none transition-colors"
                      placeholder="you@example.com"
                      data-testid="input-case-email"
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Affected Wallet Address</label>
                    <input
                      type="text"
                      required
                      value={formData.walletAddress}
                      onChange={(e) => setFormData({ ...formData, walletAddress: e.target.value })}
                      className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm font-mono placeholder-[#475569] focus:border-[#00D4FF] focus:outline-none transition-colors"
                      placeholder="0x... or bc1..."
                      data-testid="input-case-wallet"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Blockchain</label>
                    <select
                      required
                      value={formData.chain}
                      onChange={(e) => setFormData({ ...formData, chain: e.target.value })}
                      className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm focus:border-[#00D4FF] focus:outline-none transition-colors"
                      data-testid="select-case-chain"
                    >
                      <option value="">Select blockchain</option>
                      <option value="ethereum">Ethereum</option>
                      <option value="bitcoin">Bitcoin</option>
                      <option value="bsc">BNB Smart Chain</option>
                      <option value="polygon">Polygon</option>
                      <option value="solana">Solana</option>
                      <option value="tron">TRON</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div className="mb-5">
                  <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Estimated Loss (USD)</label>
                  <input
                    type="text"
                    value={formData.estimatedLoss}
                    onChange={(e) => setFormData({ ...formData, estimatedLoss: e.target.value })}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#475569] focus:border-[#00D4FF] focus:outline-none transition-colors"
                    placeholder="$0.00"
                    data-testid="input-case-loss"
                  />
                </div>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-[#8899A6] mb-1.5">Describe What Happened</label>
                  <textarea
                    required
                    rows={4}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-[#152238] border border-[#1A2942] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#475569] focus:border-[#00D4FF] focus:outline-none transition-colors resize-none"
                    placeholder="Describe how the funds were lost, any known transaction hashes, suspicious addresses, timeline of events..."
                    data-testid="input-case-description"
                  />
                </div>
                <div className="flex items-center gap-4">
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-[#00D4FF] to-[#0066FF] text-white font-bold px-8 py-3 rounded-xl hover:opacity-90 transition-all flex items-center gap-2"
                    data-testid="button-submit-case"
                  >
                    <Shield size={18} />
                    Submit Case for Review
                  </button>
                  <p className="text-xs text-[#475569]">
                    <Lock size={10} className="inline mr-1" />
                    Your information is encrypted and confidential
                  </p>
                </div>
              </form>
            )}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-[#00D4FF]/10 to-[#a855f7]/10 border border-[#00D4FF]/20 rounded-2xl p-8 sm:p-10 text-center"
            data-testid="card-cta-bottom"
          >
            <Zap size={32} className="text-[#00D4FF] mx-auto mb-4" />
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              Start Your Investigation Now
            </h2>
            <p className="text-[#8899A6] max-w-2xl mx-auto mb-6">
              Use our free Forensic Tracer tool to begin tracing any wallet address or transaction hash 
              across multiple blockchains. No account required.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Link href="/forensic-tracer">
                <span
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-[#00D4FF] to-[#0066FF] text-white font-bold px-8 py-3.5 rounded-xl hover:opacity-90 transition-all cursor-pointer"
                  data-testid="button-open-tracer-bottom"
                >
                  <Search size={20} />
                  Open Forensic Tracer
                </span>
              </Link>
              <a
                href="#submit-case"
                className="inline-flex items-center gap-2 border border-[#a855f7]/30 text-[#a855f7] font-medium px-8 py-3.5 rounded-xl hover:bg-[#a855f7]/10 transition-all"
                data-testid="button-submit-case-bottom"
              >
                <Users size={20} />
                Get Professional Help
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}