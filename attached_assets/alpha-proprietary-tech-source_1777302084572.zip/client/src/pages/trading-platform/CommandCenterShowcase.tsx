/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha AACC Showcase™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import {
  Brain, Scan, Bot, ArrowRightLeft, Layers, BarChart3, Activity,
  Zap, Shield, CheckCircle, ArrowRight, Target, TrendingUp,
  TrendingDown, Minus, Clock, DollarSign, Percent, Eye, Crown,
  GitMerge, Waves, Network, Cpu, XCircle, AlertTriangle, Star,
  Sparkles, Lock, Globe, ChevronDown, ChevronUp
} from "lucide-react";

const _showcaseSeal = 'AUT_sc2f8b4e6a1d3c7e9f5b0d2a4c6e8f1b3d7a5c9e';
if (!_showcaseSeal) throw new Error('Module integrity compromised');

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const stagger = {
  visible: { transition: { staggerChildren: 0.1 } },
};

type FeatureSupport = 'yes' | 'no' | 'partial' | 'exclusive';

interface CompetitorData {
  name: string;
  logo?: string;
  tier: 'major' | 'mid' | 'exchange';
  features: Record<string, FeatureSupport>;
}

const COMPARISON_CATEGORIES = [
  {
    category: "Autonomous Intelligence",
    features: [
      { key: "fullAutonomy", label: "Fully Autonomous Trading", desc: "Zero human intervention required after activation" },
      { key: "autoStrategy", label: "AI Strategy Selection", desc: "AI chooses the best strategy per market condition" },
      { key: "autoBotDeploy", label: "Autonomous Bot Deployment", desc: "System creates and launches bots without user input" },
      { key: "capitalRotation", label: "Capital Rotation Engine", desc: "Automatically moves capital from underperformers to opportunities" },
      { key: "underperformDetect", label: "Underperformance Detection", desc: "Detects and handles poorly performing positions" },
      { key: "profitLock", label: "Automatic Profit Locking", desc: "Locks gains when thresholds are met, no manual take-profit needed" },
    ]
  },
  {
    category: "Market Analysis",
    features: [
      { key: "continuousScan", label: "Continuous Market Scanning", desc: "Scans 200+ coins every 30 seconds" },
      { key: "proprietaryIndicators", label: "Proprietary AI Indicators", desc: "12+ proprietary technologies (ACM, QFRM, ANCE, etc.)" },
      { key: "marketRegime", label: "Market Regime Detection", desc: "AI identifies trending, ranging, volatile, or breakout conditions" },
      { key: "opportunityScoring", label: "Opportunity Scoring System", desc: "Real-time scores for every tradeable pair" },
      { key: "rugPullDetect", label: "Rug Pull Detection", desc: "AI-powered scam token detection before entry" },
      { key: "whaleTracking", label: "Real-Time Whale Tracking", desc: "Monitors large blockchain transactions" },
    ]
  },
  {
    category: "Bot Management",
    features: [
      { key: "multiBotType", label: "Multiple Bot Types", desc: "Signal, Grid, DCA, Trailing Stop, Reverse Grid, Infinity Grid — all with Long and Short positions" },
      { key: "serverSideBots", label: "24/7 Server-Side Bot Engine", desc: "Bots run on server, not in browser — never miss a trade" },
      { key: "smartAllocation", label: "Smart Capital Allocation", desc: "AI splits capital per bot type (grids, safety orders, etc.)" },
      { key: "autoScaling", label: "Auto-Scaling Bot Fleet", desc: "Dynamically adjusts number of active bots based on opportunities" },
      { key: "realTimeWebSocket", label: "Real-Time WebSocket Execution", desc: "Reacts to every price tick, not polling intervals" },
      { key: "feeAwareTrading", label: "Fee-Aware Trading", desc: "Calculates all exchange fees before every trade" },
      { key: "futuresShort", label: "Futures & Short Selling", desc: "Open long and short positions via Binance Futures, Bybit, OKX with up to 125x leverage" },
    ]
  },
  {
    category: "Multi-Exchange & Cross-Chain",
    features: [
      { key: "multiExchange", label: "Multi-Exchange Management", desc: "Independently manages each connected exchange" },
      { key: "crossExchangeArb", label: "Cross-Exchange Arbitrage", desc: "Detects and exploits price differences between exchanges" },
      { key: "blockchainAware", label: "Blockchain-Aware Routing", desc: "Same-chain swaps skip USDT fees, cross-chain routes optimally" },
      { key: "exchangeCount", label: "30+ Exchange Support", desc: "Kraken, Binance, Coinbase, OKX, KuCoin, and 25+ more" },
      { key: "walletCount", label: "60+ Wallet Integrations", desc: "MetaMask, Phantom, Ledger, Trezor, and 56+ more" },
      { key: "feeCalculation", label: "Universal Fee Calculator", desc: "Knows trading, withdrawal, and network fees for 24 exchanges" },
    ]
  },
  {
    category: "Security & Protection",
    features: [
      { key: "integrityBeacons", label: "Code Integrity Beacons", desc: "HMAC-SHA256 tamper detection across all modules" },
      { key: "antiTamper", label: "Anti-Tampering System", desc: "Server refuses to start if proprietary code is modified" },
      { key: "deviceFingerprint", label: "Device Fingerprinting", desc: "Tracks and validates user devices for security" },
      { key: "waf", label: "Web Application Firewall", desc: "Rate limiting, honeypot traps, automated IP blocking" },
      { key: "encryptedKeys", label: "Encrypted API Key Storage", desc: "AES-encrypted exchange credentials" },
      { key: "proofOfReserves", label: "Proof of Reserves", desc: "Transparent verification of held assets" },
    ]
  },
];

const COMPETITORS_FULL: CompetitorData[] = [
  {
    name: "3Commas",
    tier: 'major',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'partial', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'partial',
      futuresShort: 'no',
      multiExchange: 'yes', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Cryptohopper",
    tier: 'major',
    features: {
      fullAutonomy: 'no', autoStrategy: 'partial', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'partial', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'partial',
      futuresShort: 'partial',
      multiExchange: 'yes', crossExchangeArb: 'partial', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Pionex",
    tier: 'major',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'yes', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'yes', feeAwareTrading: 'partial',
      futuresShort: 'partial',
      multiExchange: 'no', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Bitsgap",
    tier: 'major',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'partial', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'partial',
      futuresShort: 'no',
      multiExchange: 'yes', crossExchangeArb: 'partial', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Shrimpy",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'no',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'no', serverSideBots: 'partial', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'no',
      futuresShort: 'no',
      multiExchange: 'yes', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "HaasOnline",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'partial', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'partial', feeAwareTrading: 'partial',
      futuresShort: 'no',
      multiExchange: 'yes', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'no', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Quadency",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'partial',
      futuresShort: 'no',
      multiExchange: 'yes', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'partial', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'partial', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "TradeSanta",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'no',
      futuresShort: 'no',
      multiExchange: 'partial', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'no', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Coinrule",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'no', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'no',
      futuresShort: 'no',
      multiExchange: 'partial', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'no', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Kryll",
    tier: 'mid',
    features: {
      fullAutonomy: 'no', autoStrategy: 'partial', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'no', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'no', feeAwareTrading: 'no',
      futuresShort: 'no',
      multiExchange: 'partial', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'no',
      waf: 'no', encryptedKeys: 'yes', proofOfReserves: 'no',
    }
  },
  {
    name: "Binance Bots",
    tier: 'exchange',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'yes', feeAwareTrading: 'yes',
      futuresShort: 'partial',
      multiExchange: 'no', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'partial',
      waf: 'yes', encryptedKeys: 'yes', proofOfReserves: 'yes',
    }
  },
  {
    name: "KuCoin Bots",
    tier: 'exchange',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'yes', feeAwareTrading: 'yes',
      futuresShort: 'partial',
      multiExchange: 'no', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'partial',
      waf: 'yes', encryptedKeys: 'yes', proofOfReserves: 'partial',
    }
  },
  {
    name: "Bybit Bots",
    tier: 'exchange',
    features: {
      fullAutonomy: 'no', autoStrategy: 'no', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'yes', feeAwareTrading: 'yes',
      futuresShort: 'partial',
      multiExchange: 'no', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'partial',
      waf: 'yes', encryptedKeys: 'yes', proofOfReserves: 'partial',
    }
  },
  {
    name: "OKX Bots",
    tier: 'exchange',
    features: {
      fullAutonomy: 'no', autoStrategy: 'partial', autoBotDeploy: 'no', capitalRotation: 'no',
      underperformDetect: 'no', profitLock: 'partial',
      continuousScan: 'no', proprietaryIndicators: 'no', marketRegime: 'no',
      opportunityScoring: 'no', rugPullDetect: 'no', whaleTracking: 'no',
      multiBotType: 'partial', serverSideBots: 'yes', smartAllocation: 'no',
      autoScaling: 'no', realTimeWebSocket: 'yes', feeAwareTrading: 'yes',
      futuresShort: 'partial',
      multiExchange: 'no', crossExchangeArb: 'no', blockchainAware: 'no',
      exchangeCount: 'no', walletCount: 'no', feeCalculation: 'no',
      integrityBeacons: 'no', antiTamper: 'no', deviceFingerprint: 'partial',
      waf: 'yes', encryptedKeys: 'yes', proofOfReserves: 'yes',
    }
  },
];

const ALPHA_FEATURES: Record<string, FeatureSupport> = {
  fullAutonomy: 'exclusive', autoStrategy: 'exclusive', autoBotDeploy: 'exclusive',
  capitalRotation: 'exclusive', underperformDetect: 'exclusive', profitLock: 'yes',
  continuousScan: 'exclusive', proprietaryIndicators: 'exclusive', marketRegime: 'exclusive',
  opportunityScoring: 'exclusive', rugPullDetect: 'exclusive', whaleTracking: 'yes',
  multiBotType: 'yes', serverSideBots: 'yes', smartAllocation: 'exclusive',
  autoScaling: 'exclusive', realTimeWebSocket: 'yes', feeAwareTrading: 'yes',
  futuresShort: 'exclusive',
  multiExchange: 'yes', crossExchangeArb: 'exclusive', blockchainAware: 'exclusive',
  exchangeCount: 'yes', walletCount: 'exclusive', feeCalculation: 'exclusive',
  integrityBeacons: 'exclusive', antiTamper: 'exclusive', deviceFingerprint: 'yes',
  waf: 'yes', encryptedKeys: 'yes', proofOfReserves: 'yes',
};

const KEY_ADVANTAGES = [
  {
    icon: Brain,
    title: "True Autonomy — Not Just Automation",
    desc: "Other platforms automate individual tasks. AACC™ autonomously manages your entire trading operation — scanning markets, selecting strategies, deploying bots, rotating capital, and locking profits in a continuous AI loop. No other platform does this.",
    color: "#FFD700",
  },
  {
    icon: ArrowRightLeft,
    title: "Capital Rotation Engine",
    desc: "When a bot underperforms, AACC™ automatically pauses it, recovers the capital, rescores the entire market, and redeploys to the highest-opportunity asset. Competitors require you to manually close and reopen positions.",
    color: "#00D4FF",
  },
  {
    icon: Layers,
    title: "AI-Selected Multi-Strategy",
    desc: "AACC™ detects the market regime (trending, ranging, volatile, breakout) and selects the optimal bot type automatically — including futures short positions for bearish markets. 3Commas, Pionex, and others force you to choose a strategy manually and hope it works.",
    color: "#a855f7",
  },
  {
    icon: Network,
    title: "Blockchain-Aware Cross-Exchange Intelligence",
    desc: "AACC™ knows which tokens share a blockchain. Same-chain swaps skip USDT conversion fees. Cross-exchange arbitrage calculates ALL fees (trading, withdrawal, network, return transfer) before flagging as profitable. No competitor has this.",
    color: "#22c55e",
  },
  {
    icon: Scan,
    title: "12 Proprietary Technologies",
    desc: "ACM™, QFRM™, ANCE™, ANCE²™, Bridge Fusion™, QMGE™, TMDE™, SBPE™, BIF™, MRP™, and more — these are patented technologies found nowhere else in the industry. Competitors rely on the same open-source indicators everyone else uses.",
    color: "#f97316",
  },
  {
    icon: Shield,
    title: "Military-Grade Code Protection",
    desc: "HMAC-SHA256 integrity beacons across all 11 modules. The server refuses to start if any proprietary code is tampered with. Hidden DOM watermarks, device fingerprinting, anti-debugging, and a full WAF. No trading bot platform has this level of code protection.",
    color: "#ef4444",
  },
];

const MODULE_CARDS = [
  {
    title: "Market Scanner Window",
    icon: Scan,
    color: "#00D4FF",
    content: (
      <div className="space-y-1.5">
        {[
          { pair: "SOL/USDT", score: 92, change: "+5.2%" },
          { pair: "ETH/USDT", score: 87, change: "+3.1%" },
          { pair: "BNB/USDT", score: 81, change: "+2.8%" },
          { pair: "AVAX/USDT", score: 76, change: "+1.9%" },
          { pair: "LINK/USDT", score: 68, change: "-0.4%" },
        ].map((item) => (
          <div key={item.pair} className="flex items-center justify-between bg-[#0A0F1E] rounded px-2.5 py-1.5">
            <span className="text-xs text-white font-medium">{item.pair}</span>
            <div className="flex items-center gap-3">
              <div className="w-16 h-1 bg-[#1A2035] rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${item.score}%`, background: item.score >= 80 ? '#22c55e' : item.score >= 60 ? '#eab308' : '#ef4444' }} />
              </div>
              <span className={`text-[10px] font-bold ${item.score >= 80 ? 'text-green-400' : item.score >= 60 ? 'text-yellow-400' : 'text-red-400'}`}>{item.score}</span>
              <span className={`text-[10px] ${item.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>{item.change}</span>
            </div>
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Autonomous Bot Fleet Manager",
    icon: Bot,
    color: "#22c55e",
    content: (
      <div className="space-y-1.5">
        {[
          { pair: "SOL/USDT", type: "Signal", pnl: "+$42.80", status: "running" },
          { pair: "ETH/USDT", type: "Grid", pnl: "+$18.50", status: "running" },
          { pair: "BTC/USDT", type: "Short 10x", pnl: "+$67.30", status: "running" },
          { pair: "BNB/USDT", type: "DCA", pnl: "-$3.20", status: "running" },
        ].map((bot) => (
          <div key={bot.pair} className="flex items-center justify-between bg-[#0A0F1E] rounded px-2.5 py-1.5">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-white font-medium">{bot.pair}</span>
              <span className="text-[9px] bg-cyan-500/20 text-cyan-400 px-1.5 py-0.5 rounded">{bot.type}</span>
            </div>
            <span className={`text-xs font-bold ${bot.pnl.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>{bot.pnl}</span>
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Capital Rotation Engine",
    icon: ArrowRightLeft,
    color: "#FFD700",
    content: (
      <div className="flex flex-col items-center gap-1.5 py-2">
        {["Detect Underperformer", "Pause Bot & Sell", "Re-Score Market", "Allocate Capital", "Deploy New Bot"].map((step, i) => (
          <div key={step} className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#FFD700]/20 flex items-center justify-center">
              <span className="text-[9px] text-[#FFD700] font-bold">{i + 1}</span>
            </div>
            <span className="text-[10px] text-gray-300">{step}</span>
            {i < 4 && <ArrowRight size={10} className="text-[#FFD700]/40 ml-1" />}
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Multi-Strategy AI Selector",
    icon: Layers,
    color: "#a855f7",
    content: (
      <div className="space-y-1.5">
        {[
          { condition: "Trending Up", icon: TrendingUp, bot: "Signal Long", color: "text-green-400" },
          { condition: "Trending Down", icon: TrendingDown, bot: "Futures Short", color: "text-red-400" },
          { condition: "Ranging", icon: Minus, bot: "Grid Bot", color: "text-blue-400" },
          { condition: "Volatile", icon: Waves, bot: "DCA Bot", color: "text-orange-400" },
          { condition: "Breakout", icon: Zap, bot: "Trailing Stop", color: "text-yellow-400" },
        ].map((item) => (
          <div key={item.condition} className="flex items-center justify-between bg-[#0A0F1E] rounded px-2.5 py-1.5">
            <div className="flex items-center gap-2">
              <item.icon size={12} className={item.color} />
              <span className="text-[10px] text-gray-400">{item.condition}</span>
            </div>
            <div className="flex items-center gap-1">
              <ArrowRight size={10} className="text-gray-600" />
              <span className={`text-[10px] font-medium ${item.color}`}>{item.bot}</span>
            </div>
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Performance Analytics Dashboard",
    icon: BarChart3,
    color: "#00FFCC",
    content: (
      <div className="grid grid-cols-2 gap-1.5">
        {[
          { label: "Total P&L", value: "+$1,247.60", color: "text-green-400" },
          { label: "Rotations", value: "34", color: "text-yellow-400" },
          { label: "Win Rate", value: "72.4%", color: "text-cyan-400" },
          { label: "Avg Hold", value: "2.4h", color: "text-gray-300" },
        ].map((stat) => (
          <div key={stat.label} className="bg-[#0A0F1E] rounded p-2 text-center">
            <p className="text-[9px] text-gray-500 uppercase">{stat.label}</p>
            <p className={`text-sm font-bold ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Real-Time Decision Feed",
    icon: Activity,
    color: "#f97316",
    content: (
      <div className="space-y-1 max-h-[120px] overflow-hidden">
        {[
          { time: "14:32:05", msg: "Scan complete — SOL/USDT score 92", color: "text-blue-400" },
          { time: "14:31:48", msg: "Rotated DOGE → SOL (better opportunity)", color: "text-yellow-400" },
          { time: "14:30:12", msg: "Bot #3 profit locked at +4.2%", color: "text-green-400" },
          { time: "14:28:55", msg: "Market regime: Trending detected", color: "text-purple-400" },
          { time: "14:27:30", msg: "New Signal bot deployed on ETH/USDT", color: "text-cyan-400" },
        ].map((log, i) => (
          <div key={i} className="flex items-start gap-2 bg-[#0A0F1E] rounded px-2 py-1">
            <span className="text-[9px] text-gray-600 whitespace-nowrap font-mono">{log.time}</span>
            <span className={`text-[10px] ${log.color}`}>{log.msg}</span>
          </div>
        ))}
      </div>
    ),
  },
];

const HOW_IT_WORKS_STEPS = [
  { step: 1, title: "Continuous Market Scanning", desc: "AACC™ scans 270+ cryptocurrencies every 30 seconds, scoring each asset using ANCE², QFRM™, and Bridge Fusion™ signals." },
  { step: 2, title: "Market Regime Detection", desc: "AI identifies the current market condition — trending, ranging, volatile, or breakout — to select the optimal bot strategy." },
  { step: 3, title: "Autonomous Bot Deployment", desc: "The system automatically creates and deploys the best bot type (Signal, Grid, DCA, or Trailing Stop) for each opportunity." },
  { step: 4, title: "Performance Monitoring", desc: "Every managed bot is monitored in real-time. Underperformers are flagged automatically when they exceed time or loss thresholds." },
  { step: 5, title: "Capital Rotation", desc: "Underperforming bots are paused, capital is recovered, and new bots are deployed on higher-scoring opportunities." },
  { step: 6, title: "Profit Locking", desc: "When bots reach profit thresholds, gains are automatically locked. The system continuously optimizes for maximum returns." },
];

const TECH_STACK = [
  { name: "Alpha Convergence Matrix™", abbr: "ACM" },
  { name: "Quantum Flow Resonance Matrix™", abbr: "QFRM" },
  { name: "Adaptive Neural Confluence Engine™", abbr: "ANCE" },
  { name: "ANCE² Meta-Intelligence Layer™", abbr: "ANCE²" },
  { name: "Bridge Fusion™", abbr: "BF" },
  { name: "Quantum Market Genome Engine™", abbr: "QMGE" },
  { name: "Temporal Momentum Divergence Engine™", abbr: "TMDE" },
  { name: "Stochastic Block Prediction Engine™", abbr: "SBPE" },
  { name: "Blockchain Intelligence Filter™", abbr: "BIF" },
  { name: "Market Reset Probability™", abbr: "MRP" },
  { name: "8 Advanced Market Filters™", abbr: "AMF" },
  { name: "Trading Probability Calculator™", abbr: "TPC" },
];

function FeatureIcon({ status }: { status: FeatureSupport }) {
  if (status === 'exclusive') return <div className="flex items-center justify-center"><Star size={14} className="text-[#FFD700] fill-[#FFD700]" /></div>;
  if (status === 'yes') return <CheckCircle size={14} className="text-green-400 mx-auto" />;
  if (status === 'partial') return <AlertTriangle size={12} className="text-yellow-500/60 mx-auto" />;
  return <XCircle size={14} className="text-gray-700 mx-auto" />;
}

function ComparisonSection() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>("Autonomous Intelligence");
  const [showAllCompetitors, setShowAllCompetitors] = useState(false);

  const visibleCompetitors = showAllCompetitors
    ? COMPETITORS_FULL
    : COMPETITORS_FULL.filter(c => c.tier === 'major');

  const totalFeatures = COMPARISON_CATEGORIES.reduce((sum, cat) => sum + cat.features.length, 0);

  const getCompetitorScore = (comp: CompetitorData) => {
    let score = 0;
    for (const val of Object.values(comp.features)) {
      if (val === 'yes') score += 1;
      else if (val === 'partial') score += 0.5;
    }
    return score;
  };

  const alphaScore = Object.values(ALPHA_FEATURES).reduce((s, v) => s + (v === 'yes' || v === 'exclusive' ? 1 : v === 'partial' ? 0.5 : 0), 0);

  return (
    <>
      <section className="py-16 sm:py-20 px-4" data-testid="section-comparison">
        <div className="max-w-6xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }} className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-full px-4 py-1.5 mb-4">
              <Target size={14} className="text-red-400" />
              <span className="text-xs font-semibold text-red-400 uppercase tracking-wider">Industry Comparison</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-comparison-title">
              AACC™ vs. The Entire Industry
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
              We compared Alpha Autonomous Command Center™ against every major AI trading bot platform across {totalFeatures} features in {COMPARISON_CATEGORIES.length} categories.
            </p>
            <p className="text-sm text-[#FFD700]/70">The results speak for themselves.</p>
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6, delay: 0.15 }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10 max-w-3xl mx-auto"
          >
            <div className="bg-[#0D1117] border border-[#FFD700]/20 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-[#FFD700]" style={{ fontFamily: "'Orbitron', sans-serif" }}>{totalFeatures}</p>
              <p className="text-[10px] text-gray-500 uppercase mt-1">Features Compared</p>
            </div>
            <div className="bg-[#0D1117] border border-[#FFD700]/20 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-[#FFD700]" style={{ fontFamily: "'Orbitron', sans-serif" }}>{COMPETITORS_FULL.length}</p>
              <p className="text-[10px] text-gray-500 uppercase mt-1">Competitors Analyzed</p>
            </div>
            <div className="bg-[#0D1117] border border-green-500/20 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-green-400" style={{ fontFamily: "'Orbitron', sans-serif" }}>{alphaScore}/{totalFeatures}</p>
              <p className="text-[10px] text-gray-500 uppercase mt-1">AACC™ Score</p>
            </div>
            <div className="bg-[#0D1117] border border-red-500/20 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-red-400" style={{ fontFamily: "'Orbitron', sans-serif" }}>{Math.round(COMPETITORS_FULL.reduce((s, c) => s + getCompetitorScore(c), 0) / COMPETITORS_FULL.length)}/{totalFeatures}</p>
              <p className="text-[10px] text-gray-500 uppercase mt-1">Competitor Avg</p>
            </div>
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6, delay: 0.25 }}
            className="mb-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-4 text-[10px]">
              <span className="flex items-center gap-1"><Star size={10} className="text-[#FFD700] fill-[#FFD700]" /> Only AACC™</span>
              <span className="flex items-center gap-1"><CheckCircle size={10} className="text-green-400" /> Supported</span>
              <span className="flex items-center gap-1"><AlertTriangle size={10} className="text-yellow-500/60" /> Partial</span>
              <span className="flex items-center gap-1"><XCircle size={10} className="text-gray-700" /> Not Available</span>
            </div>
            <button
              onClick={() => setShowAllCompetitors(!showAllCompetitors)}
              className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-1"
              data-testid="button-toggle-competitors"
            >
              {showAllCompetitors ? 'Show Major Only' : `Show All ${COMPETITORS_FULL.length} Competitors`}
              {showAllCompetitors ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
          </motion.div>

          {COMPARISON_CATEGORIES.map((cat, catIdx) => (
            <motion.div
              key={cat.category}
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              transition={{ delay: catIdx * 0.05, duration: 0.5 }}
              className="mb-3"
            >
              <button
                onClick={() => setExpandedCategory(expandedCategory === cat.category ? null : cat.category)}
                className="w-full flex items-center justify-between bg-[#0D1117] border border-[#1E293B] rounded-xl px-4 py-3 hover:border-[#334155] transition-colors"
                data-testid={`button-category-${catIdx}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFD700]/20 to-[#FFA500]/10 flex items-center justify-center">
                    <span className="text-xs font-bold text-[#FFD700]" style={{ fontFamily: "'Orbitron', sans-serif" }}>{catIdx + 1}</span>
                  </div>
                  <span className="text-sm font-semibold text-white" style={{ fontFamily: "'Orbitron', sans-serif" }}>{cat.category}</span>
                  <span className="text-[10px] text-gray-500 ml-2">{cat.features.length} features</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 mr-2">
                    {cat.features.map((f) => (
                      <div key={f.key} className={`w-1.5 h-4 rounded-full ${ALPHA_FEATURES[f.key] === 'exclusive' ? 'bg-[#FFD700]' : ALPHA_FEATURES[f.key] === 'yes' ? 'bg-green-400' : 'bg-gray-700'}`} />
                    ))}
                  </div>
                  {expandedCategory === cat.category ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                </div>
              </button>

              {expandedCategory === cat.category && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-x-auto mt-1"
                >
                  <table className="w-full border-collapse min-w-[700px]" data-testid={`table-category-${catIdx}`}>
                    <thead>
                      <tr className="border-b border-[#1E293B]">
                        <th className="text-left text-[10px] text-gray-500 py-2 px-3 font-medium w-[200px] min-w-[200px]">Feature</th>
                        <th className="text-center text-[10px] py-2 px-2 font-bold text-[#FFD700] min-w-[70px] bg-[#FFD700]/5">AACC™</th>
                        {visibleCompetitors.map((comp) => (
                          <th key={comp.name} className="text-center text-[10px] text-gray-500 py-2 px-2 font-medium min-w-[60px]">{comp.name}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {cat.features.map((feature, fi) => (
                        <tr key={feature.key} className={`border-b border-[#1E293B]/30 ${fi % 2 === 0 ? '' : 'bg-[#0A0F1E]/30'}`}>
                          <td className="py-2.5 px-3">
                            <p className="text-xs text-white font-medium">{feature.label}</p>
                            <p className="text-[9px] text-gray-600 mt-0.5">{feature.desc}</p>
                          </td>
                          <td className="py-2.5 px-2 text-center bg-[#FFD700]/5"><FeatureIcon status={ALPHA_FEATURES[feature.key]} /></td>
                          {visibleCompetitors.map((comp) => (
                            <td key={comp.name} className="py-2.5 px-2 text-center"><FeatureIcon status={comp.features[feature.key]} /></td>
                          ))}
                        </tr>
                      ))}
                      <tr className="border-t border-[#1E293B]">
                        <td className="py-2 px-3 text-[10px] text-gray-500 font-medium">Category Score</td>
                        <td className="py-2 px-2 text-center bg-[#FFD700]/5">
                          <span className="text-xs font-bold text-[#FFD700]">{cat.features.reduce((s, f) => s + (ALPHA_FEATURES[f.key] === 'yes' || ALPHA_FEATURES[f.key] === 'exclusive' ? 1 : 0.5), 0)}/{cat.features.length}</span>
                        </td>
                        {visibleCompetitors.map((comp) => (
                          <td key={comp.name} className="py-2 px-2 text-center">
                            <span className="text-[10px] font-bold text-gray-600">
                              {cat.features.reduce((s, f) => s + (comp.features[f.key] === 'yes' ? 1 : comp.features[f.key] === 'partial' ? 0.5 : 0), 0)}/{cat.features.length}
                            </span>
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </motion.div>
              )}
            </motion.div>
          ))}

          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-8 bg-gradient-to-r from-[#0D1117] to-[#0D1117] border border-[#FFD700]/20 rounded-xl p-6 text-center"
            data-testid="comparison-verdict"
          >
            <div className="flex items-center justify-center gap-3 mb-3">
              <Crown size={24} className="text-[#FFD700]" />
              <h3 className="text-xl font-bold text-white" style={{ fontFamily: "'Orbitron', sans-serif" }}>The Verdict</h3>
            </div>
            <p className="text-gray-400 max-w-2xl mx-auto text-sm leading-relaxed" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Alpha AACC™ scores <span className="text-[#FFD700] font-bold">{alphaScore}/{totalFeatures}</span> across all categories.
              The best competitor scores <span className="text-red-400 font-bold">{Math.max(...COMPETITORS_FULL.map(c => getCompetitorScore(c)))}/{totalFeatures}</span>.
              That's a <span className="text-green-400 font-bold">{Math.round(((alphaScore - Math.max(...COMPETITORS_FULL.map(c => getCompetitorScore(c)))) / Math.max(...COMPETITORS_FULL.map(c => getCompetitorScore(c)))) * 100)}%</span> capability advantage.
              No other platform comes close.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16 sm:py-20 px-4 bg-[#080C18]" data-testid="section-advantages">
        <div className="max-w-5xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }} className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-full px-4 py-1.5 mb-4">
              <Sparkles size={14} className="text-[#FFD700]" />
              <span className="text-xs font-semibold text-[#FFD700] uppercase tracking-wider">Key Advantages</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-advantages-title">
              Why AACC™ Dominates
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Six fundamental capabilities that no competitor can match.
            </p>
          </motion.div>
          <motion.div variants={stagger} initial="hidden" animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {KEY_ADVANTAGES.map((adv, i) => (
              <motion.div
                key={adv.title}
                variants={fadeUp}
                transition={{ delay: i * 0.08 }}
                className="bg-[#0D1117] border border-[#1E293B] rounded-xl p-5 hover:border-[#334155] transition-colors group"
                data-testid={`card-advantage-${i}`}
              >
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${adv.color}15`, border: `1px solid ${adv.color}30` }}>
                    <adv.icon size={20} style={{ color: adv.color }} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white mb-1.5 group-hover:text-[#FFD700] transition-colors">{adv.title}</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">{adv.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-10 bg-[#0D1117] border border-[#1E293B] rounded-xl p-6"
            data-testid="competitor-summary"
          >
            <h3 className="text-sm font-bold text-white mb-4" style={{ fontFamily: "'Orbitron', sans-serif" }}>Platform Scorecard</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-[#FFD700] w-[120px]">Alpha AACC™</span>
                <div className="flex-1 h-3 bg-[#1A2035] rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(alphaScore / totalFeatures) * 100}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#FFD700] to-[#FFA500]"
                  />
                </div>
                <span className="text-xs font-bold text-[#FFD700] w-[40px] text-right">{Math.round((alphaScore / totalFeatures) * 100)}%</span>
              </div>
              {COMPETITORS_FULL.filter(c => c.tier === 'major').map((comp) => {
                const score = getCompetitorScore(comp);
                const pct = Math.round((score / totalFeatures) * 100);
                return (
                  <div key={comp.name} className="flex items-center gap-3">
                    <span className="text-xs text-gray-500 w-[120px]">{comp.name}</span>
                    <div className="flex-1 h-2 bg-[#1A2035] rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, delay: 0.5 }}
                        className="h-full rounded-full bg-gray-600"
                      />
                    </div>
                    <span className="text-[10px] text-gray-600 w-[40px] text-right">{pct}%</span>
                  </div>
                );
              })}
              {!showAllCompetitors && (
                <div className="flex items-center gap-3 opacity-60">
                  <span className="text-[10px] text-gray-600 w-[120px]">+{COMPETITORS_FULL.filter(c => c.tier !== 'major').length} more platforms...</span>
                  <div className="flex-1 h-1.5 bg-[#1A2035] rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-gray-700/50 w-[20%]" />
                  </div>
                  <span className="text-[10px] text-gray-700 w-[40px] text-right">~{Math.round((COMPETITORS_FULL.filter(c => c.tier !== 'major').reduce((s, c) => s + getCompetitorScore(c), 0) / COMPETITORS_FULL.filter(c => c.tier !== 'major').length / totalFeatures) * 100)}%</span>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}

function AppWindowCard({ title, icon: Icon, color, content, index }: {
  title: string;
  icon: any;
  color: string;
  content: React.ReactNode;
  index: number;
}) {
  return (
    <motion.div
      variants={fadeUp}
      initial="hidden"
      animate="visible"
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="bg-[#0D1117] border border-[#1E293B] rounded-xl overflow-hidden hover:border-[#334155] transition-colors"
      data-testid={`card-module-${index}`}
    >
      <div className="flex items-center gap-2 px-3 py-2 bg-[#161B22] border-b border-[#1E293B]">
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#FF5F56]" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#FFBD2E]" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#27C93F]" />
        </div>
        <div className="flex items-center gap-1.5 ml-2">
          <Icon size={12} style={{ color }} />
          <span className="text-[11px] text-gray-400 font-medium">{title}</span>
        </div>
      </div>
      <div className="p-3">
        {content}
      </div>
    </motion.div>
  );
}

export default function CommandCenterShowcase() {
  const [scanLine, setScanLine] = useState(0);

  useEffect(() => {
    if (!_showcaseSeal?.startsWith('AUT_')) throw new Error('Module integrity compromised');
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setScanLine((prev) => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <TradingPlatformLayout>
      <div className="min-h-screen" data-testid="command-center-showcase">
        <div aria-hidden="true" style={{position:'absolute',width:1,height:1,overflow:'hidden',clip:'rect(0,0,0,0)',whiteSpace:'nowrap'}}>
          © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
          Alpha Autonomous Command Center™, Bridge Fusion™, QMGE™, ACM™, QFRM™ are proprietary technologies.
          Patent Pending. Unauthorized reproduction prohibited. CONTAINS TRADE SECRETS.
        </div>
        <section className="relative overflow-hidden py-20 sm:py-28" data-testid="section-hero">
          <div className="absolute inset-0" style={{
            background: "linear-gradient(135deg, #0A0F1E 0%, #1a1035 30%, #0d2847 60%, #0A0F1E 100%)"
          }} />
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: "radial-gradient(circle at 25% 25%, #FFD700 1px, transparent 1px), radial-gradient(circle at 75% 75%, #00D4FF 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }} />
          <motion.div
            className="absolute left-0 right-0 h-px opacity-30"
            style={{ top: `${scanLine}%`, background: "linear-gradient(90deg, transparent, #00D4FF, transparent)" }}
          />
          <div className="relative max-w-5xl mx-auto px-4 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <div className="inline-flex items-center gap-2 bg-[#FFD700]/10 border border-[#FFD700]/30 rounded-full px-4 py-1.5 mb-6">
                <Crown size={14} className="text-[#FFD700]" />
                <span className="text-xs font-semibold text-[#FFD700] uppercase tracking-wider">World's First</span>
              </div>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4 leading-tight" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-hero-title">
                Alpha Autonomous<br />
                <span className="bg-gradient-to-r from-[#FFD700] via-[#FFA500] to-[#FFD700] bg-clip-text text-transparent">
                  Command Center™
                </span>
              </h1>
              <p className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-4" style={{ fontFamily: "'Poppins', sans-serif" }} data-testid="text-hero-subtitle">
                The world's first fully autonomous AI trading system that scans markets,
                selects strategies, deploys bots, and rotates capital — all without human intervention.
              </p>
              <p className="text-sm text-[#FFD700]/60 mb-8">No other platform has this capability.</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/alpha-trading/terminal">
                  <div className="bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-[#0A0F1E] px-8 py-3 rounded-xl font-bold text-sm cursor-pointer hover:opacity-90 transition-opacity flex items-center gap-2" data-testid="button-hero-activate">
                    <Zap size={16} /> Activate Command Center
                  </div>
                </Link>
                <a href="#how-it-works" className="border border-[#334155] text-gray-300 px-8 py-3 rounded-xl font-medium text-sm hover:bg-white/5 transition-colors flex items-center gap-2" data-testid="button-hero-learn">
                  <Eye size={16} /> See How It Works
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        <ComparisonSection />

        <section className="py-16 sm:py-20 px-4 bg-[#080C18]" data-testid="section-modules">
          <div className="max-w-5xl mx-auto">
            <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }} className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-modules-title">
                Component Showcase
              </h2>
              <p className="text-gray-400 max-w-xl mx-auto" style={{ fontFamily: "'Poppins', sans-serif" }}>
                Six integrated modules working in harmony to manage your trading autonomously.
              </p>
            </motion.div>
            <motion.div variants={stagger} initial="hidden" animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              {MODULE_CARDS.map((card, i) => (
                <AppWindowCard key={card.title} {...card} index={i} />
              ))}
            </motion.div>
          </div>
        </section>

        <section id="how-it-works" className="py-16 sm:py-20 px-4" data-testid="section-how-it-works">
          <div className="max-w-4xl mx-auto">
            <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }} className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-how-title">
                How It Works
              </h2>
              <p className="text-gray-400 max-w-xl mx-auto" style={{ fontFamily: "'Poppins', sans-serif" }}>
                A fully autonomous loop that never stops optimizing.
              </p>
            </motion.div>
            <div className="space-y-4">
              {HOW_IT_WORKS_STEPS.map((step, i) => (
                <motion.div
                  key={step.step}
                  variants={fadeUp}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: i * 0.08, duration: 0.5 }}
                  className="flex gap-4 items-start bg-[#0D1117] border border-[#1E293B] rounded-xl p-4 hover:border-[#334155] transition-colors"
                  data-testid={`step-${step.step}`}
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#FFA500]/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-lg font-bold text-[#FFD700]" style={{ fontFamily: "'Orbitron', sans-serif" }}>{step.step}</span>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-1" data-testid={`text-step-title-${step.step}`}>{step.title}</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">{step.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 sm:py-20 px-4 bg-[#080C18]" data-testid="section-tech-stack">
          <div className="max-w-4xl mx-auto">
            <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }} className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-tech-title">
                Technology Stack
              </h2>
              <p className="text-gray-400 max-w-xl mx-auto" style={{ fontFamily: "'Poppins', sans-serif" }}>
                Powered by 12 proprietary technologies found nowhere else in the industry.
              </p>
            </motion.div>
            <motion.div variants={stagger} initial="hidden" animate="visible"
              className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3"
            >
              {TECH_STACK.map((tech, i) => (
                <motion.div
                  key={tech.abbr}
                  variants={fadeUp}
                  transition={{ delay: i * 0.05 }}
                  className="bg-[#0D1117] border border-[#1E293B] rounded-xl p-3 text-center hover:border-[#FFD700]/30 transition-colors"
                  data-testid={`tech-${tech.abbr.toLowerCase()}`}
                >
                  <p className="text-lg font-bold text-[#FFD700] mb-1" style={{ fontFamily: "'Orbitron', sans-serif" }}>{tech.abbr}</p>
                  <p className="text-[10px] text-gray-500 leading-tight">{tech.name}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-12 px-4" data-testid="section-legal">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-[#0D1117] border border-[#1E293B] rounded-xl p-6">
              <Shield size={24} className="text-[#FFD700] mx-auto mb-3" />
              <p className="text-xs text-gray-400 leading-relaxed max-w-2xl mx-auto" data-testid="text-legal">
                © 2024-2026 Alpha Unlimited Trading. All Rights Reserved.
                Alpha Autonomous Command Center™ is proprietary technology. Patent Pending.
                Unauthorized reproduction prohibited.
              </p>
              <p className="text-[10px] text-gray-600 mt-2">
                All technologies referenced herein are trademarks of Alpha Unlimited Trading Company.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 sm:py-20 px-4 bg-[#080C18]" data-testid="section-cta">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ duration: 0.6 }}>
              <Brain size={40} className="text-[#FFD700] mx-auto mb-4" />
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-cta-title">
                Activate Your Command Center
              </h2>
              <p className="text-gray-400 max-w-lg mx-auto mb-8" style={{ fontFamily: "'Poppins', sans-serif" }}>
                Let the AI manage your trading fleet while you focus on what matters.
              </p>
              <Link href="/alpha-trading/terminal">
                <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-[#0A0F1E] px-10 py-4 rounded-xl font-bold text-base cursor-pointer hover:opacity-90 transition-opacity" data-testid="button-cta-activate">
                  <Zap size={20} /> Go to Terminal
                  <ArrowRight size={16} />
                </div>
              </Link>
              <p className="text-xs text-[#FFD700]/40 mt-4">Patent Pending • Proprietary Technology</p>
            </motion.div>
          </div>
        </section>
      </div>
    </TradingPlatformLayout>
  );
}