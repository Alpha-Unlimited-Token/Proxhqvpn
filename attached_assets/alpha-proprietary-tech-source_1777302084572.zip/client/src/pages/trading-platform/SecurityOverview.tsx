/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Security Architecture Overview™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - 10-Layer Security Architecture™
 * - Software Anti-Tampering™
 * - HMAC-Signed Storage™
 * - Device Fingerprinting Engine™
 * - Request Fingerprinting System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_8491d64278bd25b4fe7357b5
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Shield,
  Lock,
  Eye,
  Activity,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Crown,
  Ban,
  Server,
  Globe,
  Fingerprint,
  Bug,
  Network,
  Database,
  Key,
  Monitor,
  AlertTriangle,
  Smartphone,
  MapPin,
  Snowflake,
  Plus,
  Trash2,
  Copy,
  ShieldCheck,
  Scale,
  Zap,
  Building2,
  FileCheck,
  Coins,
  Award,
} from "lucide-react";

const SECURITY_RANKINGS = [
  { rank: 1, name: "Alpha Unlimited", score: 100, pct: 100, highlight: true, funding: "Self-built" },
  { rank: 2, name: "Coinbase", score: 68, pct: 68, highlight: false, funding: "$679M+ raised" },
  { rank: 3, name: "Binance", score: 68, pct: 68, highlight: false, funding: "Multi-billion" },
  { rank: 4, name: "OKX", score: 66, pct: 66, highlight: false, funding: "$300M+ raised" },
  { rank: 5, name: "Kraken", score: 65, pct: 65, highlight: false, funding: "$100M+ raised" },
];

const SECURITY_LAYERS = [
  {
    icon: Globe,
    title: "Layer 1: Network & Transport Security",
    color: "#3b82f6",
    count: 8,
    features: [
      "HTTPS/TLS 1.3 Encryption",
      "HSTS Preloading (2-Year)",
      "Content Security Policy (CSP)",
      "Security Headers Suite (12 Headers)",
      "DNS Rebinding Protection",
      "Protocol Downgrade Prevention",
      "Cross-Origin Resource Policy (CORP)",
      "Cross-Origin Opener Policy (COOP)",
    ],
  },
  {
    icon: Ban,
    title: "Layer 2: Web Application Firewall (WAF)",
    color: "#ef4444",
    count: 9,
    features: [
      "Threat-Scoring IP Blocker",
      "Progressive IP Banning (up to 7 days)",
      "SQL Injection Deep Filter (18 Patterns)",
      "XSS Deep Filter (19 Patterns)",
      "Request Smuggling Detection",
      "Directory Bruteforce Protection (40+ Paths)",
      "Path Traversal Prevention",
      "Header Injection Protection",
      "Geo-IP Risk Scoring & Country Blocking",
    ],
  },
  {
    icon: Lock,
    title: "Layer 3: Application Security",
    color: "#a855f7",
    count: 13,
    features: [
      "CSRF Protection (Timing-Safe)",
      "Double-Layer Input Sanitization",
      "Prototype Pollution Protection",
      "HTTP Parameter Pollution Protection",
      "Content-Type Enforcement",
      "Open Redirect Prevention",
      "Method Override Protection",
      "JSON Schema Validation (Zod)",
      "Rate Limiting (Multi-Tier)",
      "Request Size Limiting",
      "Malicious Payload Detection",
      "Anti-Replay Protection (Nonce + Timestamp)",
      "Origin & Referer Validation",
    ],
  },
  {
    icon: Fingerprint,
    title: "Layer 4: Authentication & Session",
    color: "#f97316",
    count: 12,
    features: [
      "Replit OpenID Connect (OAuth 2.0)",
      "TOTP Multi-Factor Authentication",
      "Session Fingerprinting (IP + UA + Headers)",
      "Concurrent Session Limiting",
      "Idle Session Timeout (30 min)",
      "Secure HttpOnly Cookies",
      "Login Attempt Rate Limiting",
      "Account Lockout Protection (5 attempts)",
      "IP Change Detection",
      "Device Fingerprinting",
      "VPN/Proxy/TOR Detection",
      "Geo-IP Risk Scoring",
    ],
  },
  {
    icon: Bug,
    title: "Layer 5: Honeypot & Deception",
    color: "#eab308",
    count: 8,
    features: [
      "29 Honeypot Trap Endpoints",
      "Fake Admin Panels (/wp-admin, /phpmyadmin)",
      "Fake API Documentation (/swagger, /graphql)",
      "Decoy Database Endpoints",
      "Scanner Detection Traps (.git, .env, .aws)",
      "Automated Threat Scoring on Contact",
      "5-Minute Auto-Block on 3+ Hits",
      "Directory Bruteforce Pattern Tracking",
    ],
  },
  {
    icon: Eye,
    title: "Layer 6: Monitoring & Intelligence",
    color: "#06b6d4",
    count: 12,
    features: [
      "Real-Time Security Event Logging",
      "IP-Based Threat Tracking & Scoring",
      "User Agent Analysis (16 Bot Signatures)",
      "Failed Authentication Monitoring",
      "Anomaly Detection (Velocity + Pattern)",
      "Sensitive Route Access Logging",
      "Response Time Monitoring (Slow Request Detection)",
      "Request ID Tracking (UUID per request)",
      "Security Dashboard with Live Data",
      "Audit Trail (Immutable Event Chain)",
      "Admin Security Alert System",
      "Automated Incident Response",
    ],
  },
  {
    icon: Database,
    title: "Layer 7: Data Protection",
    color: "#22c55e",
    count: 10,
    features: [
      "PostgreSQL with Encrypted Connections",
      "Parameterized Queries (Zero SQL Injection Surface)",
      "Input Validation with Zod Schemas",
      "Sensitive Data Auto-Stripping from Responses",
      "Error Sanitization (No Stack Traces Leaked)",
      "Cache-Control on Sensitive Routes",
      "API Response HMAC Signing",
      "Backup Encryption",
      "Data Retention Policies",
      "Secrets Encryption (AES-256-GCM)",
    ],
  },
  {
    icon: Server,
    title: "Layer 8: Infrastructure Security",
    color: "#ec4899",
    count: 11,
    features: [
      "Isolated Container Runtime",
      "Environment Variable Encryption",
      "Dependency Vulnerability Scanning",
      "DDoS Mitigation (Cloudflare-Level)",
      "Load Balancing & Failover",
      "Health Check Monitoring",
      "Server Info Stripping (X-Powered-By removed)",
      "Graceful Error Degradation",
      "Process Crash Recovery (Unhandled Rejection Handler)",
      "ClamAV Antivirus File Upload Scanning",
      "Zero-Downtime Hot Reload",
    ],
  },
  {
    icon: Building2,
    title: "Layer 9: Institutional & Custodial Security",
    color: "#FFD700",
    count: 14,
    features: [
      "Anti-Phishing Verification Code System",
      "Withdrawal Address Whitelisting (24h Cooling)",
      "Trusted Device Management",
      "Login Activity Monitoring & Risk Scoring",
      "Scoped API Key Management (Read/Trade/Withdraw)",
      "Emergency Account Freeze (Kill Switch)",
      "Cold Storage Architecture",
      "Insurance Fund (SafeSend Vault)",
      "Proof of Reserves (On-Chain Verification)",
      "SOC 2 Type II / ISO 27001 Compliance Framework",
      "KYC/AML Compliance Engine",
      "Bug Bounty Program",
      "Session Binding (IP Range Lock)",
      "Multi-Tier Withdrawal Limits",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Layer 10: Proprietary Blockchain Security",
    color: "#00D4FF",
    count: 12,
    features: [
      "Alpha Chain Integrity Protocol™ (ACIP™) — Patent Pending",
      "Autonomous Blockchain Spider™ (Deep Historical Crawling)",
      "Alpha SafeSend Protocol™ (Reversible Transactions)",
      "Alpha SafeAsset Protocol™ (RWA Tokenization)",
      "Forensic Intelligence Engine™ (Proprietary Detection)",
      "Proprietary Fund Recovery System",
      "Multi-Layer Anti-Fraud Verification",
      "Self-Defending Protocol (Autonomous Threat Response)",
      "Transaction Insurance Vault",
      "Tamper-Proof Consensus Validation",
      "Address Registry & Alias System",
      "Inheritance Protocol (Digital Estate Planning)",
    ],
  },
];

const TOTAL_FEATURES = SECURITY_LAYERS.reduce((sum, layer) => sum + layer.count, 0);

const WHY_WE_LEAD = [
  { label: "10-Layer Security Architecture", desc: "Most platforms use 2-3 layers" },
  { label: `${TOTAL_FEATURES} Active Protection Features`, desc: "vs 20-30 on major exchanges" },
  { label: "Proprietary Blockchain Security", desc: "ACIP™, SafeSend™, SafeAsset™ — Patent Pending" },
  { label: "Autonomous Blockchain Spider™", desc: "Deep historical crawling across entire blockchain history" },
  { label: "Institutional-Grade Controls", desc: "Whitelisting, anti-phishing, API keys, freeze" },
  { label: "Self-Defending Protocol", desc: "Autonomous threat response with proprietary countermeasures" },
];

export default function SecurityOverview() {
  const [expandedLayer, setExpandedLayer] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [newWhitelistAddr, setNewWhitelistAddr] = useState("");
  const [newWhitelistLabel, setNewWhitelistLabel] = useState("");
  const [antiPhishingInput, setAntiPhishingInput] = useState("");
  const [newKeyLabel, setNewKeyLabel] = useState("");
  const [newKeyPerms, setNewKeyPerms] = useState<string[]>(["read"]);
  const [copiedKey, setCopiedKey] = useState("");

  const queryClient = useQueryClient();

  const { data: securityStatus } = useQuery({
    queryKey: ["/api/security/status"],
    refetchInterval: 30000,
  });

  const { data: antiPhishing } = useQuery({
    queryKey: ["/api/security/anti-phishing"],
    refetchInterval: 60000,
  });

  const { data: whitelist } = useQuery({
    queryKey: ["/api/security/withdrawal-whitelist"],
    refetchInterval: 30000,
  });

  const { data: devices } = useQuery({
    queryKey: ["/api/security/devices"],
    refetchInterval: 60000,
  });

  const { data: loginActivity } = useQuery({
    queryKey: ["/api/security/login-activity"],
    refetchInterval: 30000,
  });

  const { data: apiKeysData } = useQuery({
    queryKey: ["/api/security/api-keys"],
    refetchInterval: 60000,
  });

  const setPhishingMutation = useMutation({
    mutationFn: async (code: string) => {
      const res = await fetch("/api/security/anti-phishing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/anti-phishing"] });
      setAntiPhishingInput("");
    },
  });

  const addWhitelistMutation = useMutation({
    mutationFn: async (data: { address: string; label: string }) => {
      const res = await fetch("/api/security/withdrawal-whitelist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/withdrawal-whitelist"] });
      setNewWhitelistAddr("");
      setNewWhitelistLabel("");
    },
  });

  const removeWhitelistMutation = useMutation({
    mutationFn: async (address: string) => {
      const res = await fetch("/api/security/withdrawal-whitelist", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address }),
      });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/security/withdrawal-whitelist"] }),
  });

  const revokeDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      const res = await fetch(`/api/security/devices/${deviceId}`, { method: "DELETE" });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/security/devices"] }),
  });

  const createKeyMutation = useMutation({
    mutationFn: async (data: { label: string; permissions: string[] }) => {
      const res = await fetch("/api/security/api-keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/api-keys"] });
      if (data.key) {
        setCopiedKey(data.key);
        setNewKeyLabel("");
      }
    },
  });

  const revokeKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      const res = await fetch(`/api/security/api-keys/${keyId}`, { method: "DELETE" });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/security/api-keys"] }),
  });

  const freezeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/security/account-freeze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "User-initiated emergency freeze" }),
      });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/security/status"] }),
  });

  const unfreezeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/security/account-unfreeze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/security/status"] }),
  });

  const featureCount = securityStatus?.totalSecurityFeatures || TOTAL_FEATURES;
  const isFrozen = securityStatus?.institutional?.accountFrozen;

  const tabs = [
    { id: "overview", label: "Security Layers" },
    { id: "dashboard", label: "Live Dashboard" },
    { id: "controls", label: "Account Security" },
  ];

  return (
    <TradingPlatformLayout>
      <section className="py-20 sm:py-28">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-green-500/[0.08] border border-green-500/20 rounded-full mb-5">
              <Shield size={14} className="text-green-400" />
              <span className="text-green-400 font-medium text-xs uppercase tracking-wider">Industry-Leading Security</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4" data-testid="text-security-title">
              #1 Ranked Security in Crypto
            </h1>
            <p className="text-[#8899A6] max-w-2xl mx-auto text-lg" data-testid="text-security-subtitle">
              {featureCount} active protection features across 10 security layers. Perfect 100/100 score — outranking Coinbase, Binance, Kraken, and OKX.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-12">
            {[
              { value: "100/100", label: "Security Score", color: "#22c55e" },
              { value: String(featureCount), label: "Protection Features", color: "#00D4FF" },
              { value: "10", label: "Security Layers", color: "#a855f7" },
              { value: "#1", label: "Industry Ranking", color: "#00D4FF" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="text-center p-5 bg-[#0D1117] border border-[#1A2942] rounded-xl"
                data-testid={`stat-${stat.label.toLowerCase().replace(/ /g, '-')}`}
              >
                <div className="text-2xl font-bold" style={{ color: stat.color }}>{stat.value}</div>
                <div className="text-xs text-[#475569] mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <div className="flex gap-1 mb-8 bg-[#0D1117] border border-[#1A2942] rounded-lg p-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-2.5 px-4 rounded-md text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? "bg-[#152238] text-white border border-[#2A3952]"
                    : "text-[#475569] hover:text-white"
                }`}
                data-testid={`tab-${tab.id}`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {activeTab === "overview" && (
            <>
              <div className="mb-16">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-1 h-8 rounded-full bg-green-500" />
                  <h2 className="text-2xl font-bold text-white" data-testid="text-ranking-heading">Industry Security Ranking</h2>
                </div>

                <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6 sm:p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
                      <Shield size={24} className="text-green-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <Crown size={16} className="text-[#FFD700]" />
                        <span className="text-[#FFD700] font-bold">#1 Ranked</span>
                      </div>
                      <p className="text-[#475569] text-sm">Total Security — 100/100 (100%)</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {SECURITY_RANKINGS.map((p) => (
                      <div
                        key={p.name}
                        className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                          p.highlight ? "bg-green-500/[0.06] border border-green-500/20" : "border border-transparent"
                        }`}
                        data-testid={`security-rank-${p.rank}`}
                      >
                        <span className={`w-7 text-center font-bold text-sm ${p.highlight ? "text-[#FFD700]" : "text-[#475569]"}`}>
                          #{p.rank}
                        </span>
                        <span className={`font-medium text-sm min-w-[130px] ${p.highlight ? "text-green-400" : "text-white"}`}>
                          {p.name}
                        </span>
                        <div className="flex-1 h-1.5 bg-[#152238] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-1000 ${p.highlight ? "bg-green-500" : "bg-[#2A3952]"}`}
                            style={{ width: `${p.pct}%` }}
                          />
                        </div>
                        <span className={`text-xs font-bold min-w-[50px] text-right ${p.highlight ? "text-green-400" : "text-[#475569]"}`}>
                          {p.score}/100
                        </span>
                        <span className="text-[10px] text-[#475569] min-w-[85px] text-right hidden sm:block">
                          {p.funding}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mb-16">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-1 h-8 rounded-full bg-[#00D4FF]" />
                  <h2 className="text-2xl font-bold text-white" data-testid="text-layers-heading">10 Security Layers — {featureCount} Features</h2>
                </div>

                <div className="space-y-2">
                  {SECURITY_LAYERS.map((layer, i) => {
                    const isOpen = expandedLayer === i;
                    return (
                      <motion.div
                        key={layer.title}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03 }}
                      >
                        <button
                          onClick={() => setExpandedLayer(isOpen ? null : i)}
                          className={`w-full flex items-center gap-3 p-4 rounded-xl text-left transition-all ${
                            isOpen ? "bg-[#152238] border border-[#2A3952]" : "bg-[#0D1117] border border-[#1A2942] hover:border-[#2A3952]"
                          }`}
                          data-testid={`button-layer-${i + 1}`}
                        >
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${layer.color}15` }}>
                            <layer.icon size={20} style={{ color: layer.color }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <span className="font-medium text-sm text-white">{layer.title}</span>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-xs font-bold" style={{ color: layer.color }}>{layer.count} features</span>
                            </div>
                          </div>
                          <div className="flex-shrink-0">
                            {isOpen ? <ChevronUp size={16} className="text-[#475569]" /> : <ChevronDown size={16} className="text-[#475569]" />}
                          </div>
                        </button>

                        <AnimatePresence>
                          {isOpen && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden"
                            >
                              <div className="px-4 pb-4 pt-2 bg-[#152238] border-x border-b border-[#1A2942] rounded-b-xl -mt-2">
                                <div className="grid sm:grid-cols-2 gap-2">
                                  {layer.features.map((feature) => (
                                    <div key={feature} className="flex items-center gap-2 p-2 bg-[#0A1628] rounded-lg">
                                      <CheckCircle size={14} className="text-green-400/70 flex-shrink-0" />
                                      <span className="text-xs text-[#8899A6]">{feature}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              <div className="mb-16">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-1 h-8 rounded-full bg-[#00D4FF]" />
                  <h2 className="text-2xl font-bold text-white" data-testid="text-why-heading">Why We Lead</h2>
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {WHY_WE_LEAD.map((item, i) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="p-5 bg-[#0D1117] border border-[#1A2942] rounded-xl"
                    >
                      <div className="flex items-start gap-2">
                        <CheckCircle size={16} className="text-green-400/70 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-white">{item.label}</p>
                          <p className="text-xs text-[#475569] mt-1">{item.desc}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-1 h-8 rounded-full bg-green-500" />
                <h2 className="text-2xl font-bold text-white">Live Security Dashboard</h2>
                <div className="flex items-center gap-1.5 ml-auto">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-green-400 text-xs font-medium">LIVE</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { label: "WAF Status", value: securityStatus?.firewall?.active ? "Active" : "Inactive", color: "#22c55e", icon: Shield },
                  { label: "Blocked IPs", value: securityStatus?.firewall?.blockedIps || 0, color: "#ef4444", icon: Ban },
                  { label: "Tracked Threats", value: securityStatus?.firewall?.trackedThreats || 0, color: "#f97316", icon: AlertTriangle },
                  { label: "Security Score", value: securityStatus?.securityScore || "100/100", color: "#00D4FF", icon: Award },
                ].map((item) => (
                  <div key={item.label} className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-4" data-testid={`dashboard-${item.label.toLowerCase().replace(/ /g, '-')}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <item.icon size={14} style={{ color: item.color }} />
                      <span className="text-xs text-[#475569]">{item.label}</span>
                    </div>
                    <div className="text-xl font-bold" style={{ color: item.color }}>{String(item.value)}</div>
                  </div>
                ))}
              </div>

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <CheckCircle size={16} className="text-green-400" />
                  Active Security Features ({Object.values(securityStatus?.securityFeatures || {}).filter(Boolean).length})
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                  {Object.entries(securityStatus?.securityFeatures || {}).map(([key, active]) => (
                    <div key={key} className="flex items-center gap-2 p-2 bg-[#152238] rounded-lg">
                      <div className={`w-2 h-2 rounded-full ${active ? "bg-green-500" : "bg-red-500"}`} />
                      <span className="text-xs text-[#8899A6]">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {securityStatus?.antivirus && (
                <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Shield size={16} className="text-[#00D4FF]" />
                    Antivirus Engine
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div><span className="text-xs text-[#475569]">Engine</span><p className="text-white text-sm font-medium">{securityStatus.antivirus.engine || "ClamAV"}</p></div>
                    <div><span className="text-xs text-[#475569]">Status</span><p className={`text-sm font-medium ${securityStatus.antivirus.active ? "text-green-400" : "text-red-400"}`}>{securityStatus.antivirus.active ? "Active" : "Standby"}</p></div>
                    <div><span className="text-xs text-[#475569]">Version</span><p className="text-white text-sm font-medium">{securityStatus.antivirus.version || "Latest"}</p></div>
                    <div><span className="text-xs text-[#475569]">File Upload Scan</span><p className="text-green-400 text-sm font-medium">Enabled</p></div>
                  </div>
                </div>
              )}

              {securityStatus?.institutional && (
                <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Building2 size={16} className="text-[#FFD700]" />
                    Your Account Security Score
                  </h3>
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[#8899A6] text-sm">Account Security</span>
                      <span className="text-white font-bold">{securityStatus.institutional.securityScore}/100</span>
                    </div>
                    <div className="h-2 bg-[#152238] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          securityStatus.institutional.securityScore >= 80 ? "bg-green-500" :
                          securityStatus.institutional.securityScore >= 50 ? "bg-yellow-500" : "bg-red-500"
                        }`}
                        style={{ width: `${securityStatus.institutional.securityScore}%` }}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-3 bg-[#152238] rounded-lg">
                      <span className="text-[#475569]">Anti-Phishing</span>
                      <p className={securityStatus.institutional.antiPhishingEnabled ? "text-green-400 font-bold" : "text-red-400 font-bold"}>
                        {securityStatus.institutional.antiPhishingEnabled ? "Enabled" : "Not Set"}
                      </p>
                    </div>
                    <div className="p-3 bg-[#152238] rounded-lg">
                      <span className="text-[#475569]">Whitelisted Addrs</span>
                      <p className="text-white font-bold">{securityStatus.institutional.whitelistedAddresses}</p>
                    </div>
                    <div className="p-3 bg-[#152238] rounded-lg">
                      <span className="text-[#475569]">Trusted Devices</span>
                      <p className="text-white font-bold">{securityStatus.institutional.trustedDeviceCount}</p>
                    </div>
                    <div className="p-3 bg-[#152238] rounded-lg">
                      <span className="text-[#475569]">API Keys</span>
                      <p className="text-white font-bold">{securityStatus.institutional.apiKeyCount}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === "controls" && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-1 h-8 rounded-full bg-[#FFD700]" />
                <h2 className="text-2xl font-bold text-white">Account Security Controls</h2>
              </div>

              {isFrozen && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 text-center">
                  <Snowflake size={32} className="text-red-400 mx-auto mb-3" />
                  <h3 className="text-red-400 font-bold text-lg mb-2">Account Frozen</h3>
                  <p className="text-[#8899A6] text-sm mb-4">All transactions and modifications are suspended.</p>
                  <button
                    onClick={() => unfreezeMutation.mutate()}
                    className="px-6 py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg transition-colors"
                    data-testid="button-unfreeze"
                  >
                    Unfreeze Account
                  </button>
                </div>
              )}

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <ShieldCheck size={20} className="text-[#00D4FF]" />
                  <h3 className="text-white font-semibold">Anti-Phishing Verification Code</h3>
                </div>
                <p className="text-[#8899A6] text-xs mb-4">Set a personal code that will appear in all official communications to verify they are from Alpha Unlimited.</p>
                {antiPhishing?.enabled ? (
                  <div className="flex items-center gap-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <CheckCircle size={16} className="text-green-400" />
                    <span className="text-green-400 font-medium text-sm">Active: Your code is "{antiPhishing.code}"</span>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={antiPhishingInput}
                      onChange={(e) => setAntiPhishingInput(e.target.value)}
                      placeholder="Enter 4-20 character code"
                      className="flex-1 bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#00D4FF] outline-none"
                      maxLength={20}
                      data-testid="input-anti-phishing"
                    />
                    <button
                      onClick={() => antiPhishingInput && setPhishingMutation.mutate(antiPhishingInput)}
                      className="px-4 py-2 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-lg text-sm"
                      data-testid="button-set-phishing"
                    >
                      Set Code
                    </button>
                  </div>
                )}
              </div>

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Lock size={20} className="text-[#a855f7]" />
                  <h3 className="text-white font-semibold">Withdrawal Address Whitelist</h3>
                </div>
                <p className="text-[#8899A6] text-xs mb-4">Pre-approve withdrawal addresses. New addresses have a 24-hour cooling period before they can be used.</p>

                <div className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={newWhitelistAddr}
                    onChange={(e) => setNewWhitelistAddr(e.target.value)}
                    placeholder="Wallet address"
                    className="flex-1 bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#00D4FF] outline-none"
                    data-testid="input-whitelist-addr"
                  />
                  <input
                    type="text"
                    value={newWhitelistLabel}
                    onChange={(e) => setNewWhitelistLabel(e.target.value)}
                    placeholder="Label"
                    className="w-32 bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#00D4FF] outline-none"
                    data-testid="input-whitelist-label"
                  />
                  <button
                    onClick={() => newWhitelistAddr && newWhitelistLabel && addWhitelistMutation.mutate({ address: newWhitelistAddr, label: newWhitelistLabel })}
                    className="px-3 py-2 bg-[#152238] border border-[#1A2942] hover:border-[#00D4FF]/30 rounded-lg text-[#00D4FF]"
                    data-testid="button-add-whitelist"
                  >
                    <Plus size={16} />
                  </button>
                </div>

                {whitelist?.addresses?.length > 0 ? (
                  <div className="space-y-2">
                    {whitelist.addresses.map((entry: any) => (
                      <div key={entry.address} className="flex items-center justify-between p-3 bg-[#152238] rounded-lg">
                        <div>
                          <p className="text-white text-sm font-mono">{entry.address.substring(0, 24)}...</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[#475569] text-xs">{entry.label}</span>
                            {entry.active ? (
                              <span className="text-green-400 text-xs font-medium">Active</span>
                            ) : (
                              <span className="text-yellow-400 text-xs font-medium">Cooling until {new Date(entry.coolingUntil).toLocaleString()}</span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => removeWhitelistMutation.mutate(entry.address)}
                          className="p-1.5 hover:bg-red-500/10 rounded text-red-400"
                          data-testid={`button-remove-whitelist-${entry.address.substring(0, 8)}`}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[#475569] text-xs text-center py-4">No whitelisted addresses yet. Add addresses to restrict withdrawals.</p>
                )}
              </div>

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Smartphone size={20} className="text-[#22c55e]" />
                  <h3 className="text-white font-semibold">Trusted Devices ({devices?.count || 0})</h3>
                </div>
                {devices?.devices?.length > 0 ? (
                  <div className="space-y-2">
                    {devices.devices.map((device: any) => (
                      <div key={device.id} className="flex items-center justify-between p-3 bg-[#152238] rounded-lg" data-testid={`device-${device.id}`}>
                        <div className="flex items-center gap-3">
                          <Smartphone size={16} className="text-[#8899A6]" />
                          <div>
                            <p className="text-white text-sm">{device.label}</p>
                            <p className="text-[#475569] text-xs">{device.ipAddress} — Last seen {new Date(device.lastSeen).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => revokeDeviceMutation.mutate(device.id)}
                          className="p-1.5 hover:bg-red-500/10 rounded text-red-400 text-xs"
                          data-testid={`button-revoke-device-${device.id}`}
                        >
                          Revoke
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[#475569] text-xs text-center py-4">No trusted devices registered yet. Devices are automatically registered on login.</p>
                )}
              </div>

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <MapPin size={20} className="text-[#06b6d4]" />
                  <h3 className="text-white font-semibold">Login Activity</h3>
                </div>
                {loginActivity?.events?.length > 0 ? (
                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {loginActivity.events.slice(0, 10).map((event: any) => (
                      <div key={event.id} className={`p-3 rounded-lg border ${event.riskScore >= 50 ? 'bg-red-500/5 border-red-500/20' : 'bg-[#152238] border-[#1A2942]'}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {event.success ? <CheckCircle size={14} className="text-green-400" /> : <AlertTriangle size={14} className="text-red-400" />}
                            <span className="text-white text-sm">{event.success ? "Successful Login" : "Failed Attempt"}</span>
                            {event.newDevice && <span className="text-xs bg-yellow-500/20 text-yellow-400 px-1.5 py-0.5 rounded">New Device</span>}
                            {event.newLocation && <span className="text-xs bg-orange-500/20 text-orange-400 px-1.5 py-0.5 rounded">New Location</span>}
                          </div>
                          <span className={`text-xs font-bold ${event.riskScore >= 50 ? 'text-red-400' : event.riskScore >= 20 ? 'text-yellow-400' : 'text-green-400'}`}>
                            Risk: {event.riskScore}
                          </span>
                        </div>
                        <p className="text-[#475569] text-xs mt-1">{event.ipAddress} — {new Date(event.timestamp).toLocaleString()}</p>
                        {event.riskFactors?.length > 0 && event.riskFactors[0] !== "Normal login pattern" && (
                          <div className="flex gap-1 mt-1">
                            {event.riskFactors.map((f: string, i: number) => (
                              <span key={i} className="text-[10px] bg-[#0A1628] text-[#8899A6] px-1.5 py-0.5 rounded">{f}</span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[#475569] text-xs text-center py-4">No login activity recorded yet.</p>
                )}
              </div>

              <div className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Key size={20} className="text-[#f97316]" />
                  <h3 className="text-white font-semibold">API Key Management</h3>
                </div>
                <p className="text-[#8899A6] text-xs mb-4">Create scoped API keys with specific permissions. Keys are shown only once upon creation.</p>

                <div className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={newKeyLabel}
                    onChange={(e) => setNewKeyLabel(e.target.value)}
                    placeholder="Key label"
                    className="flex-1 bg-[#152238] border border-[#1A2942] rounded-lg px-3 py-2 text-white text-sm focus:border-[#00D4FF] outline-none"
                    data-testid="input-key-label"
                  />
                  <div className="flex items-center gap-2">
                    {["read", "trade", "withdraw"].map(perm => (
                      <button
                        key={perm}
                        onClick={() => setNewKeyPerms(prev => prev.includes(perm) ? prev.filter(p => p !== perm) : [...prev, perm])}
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          newKeyPerms.includes(perm)
                            ? "bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30"
                            : "bg-[#152238] text-[#475569] border border-[#1A2942]"
                        }`}
                        data-testid={`toggle-perm-${perm}`}
                      >
                        {perm}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => newKeyLabel && createKeyMutation.mutate({ label: newKeyLabel, permissions: newKeyPerms })}
                    className="px-4 py-2 bg-gradient-to-r from-[#00D4FF] to-[#0099CC] text-[#0A1628] font-semibold rounded-lg text-sm"
                    data-testid="button-create-key"
                  >
                    Create
                  </button>
                </div>

                {copiedKey && (
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg mb-4">
                    <p className="text-green-400 text-xs font-medium mb-1">API Key Created — Copy it now, it will not be shown again:</p>
                    <div className="flex items-center gap-2">
                      <code className="text-white text-xs bg-[#0D1117] px-2 py-1 rounded flex-1 overflow-hidden">{copiedKey}</code>
                      <button
                        onClick={() => { navigator.clipboard.writeText(copiedKey); }}
                        className="p-1.5 hover:bg-[#152238] rounded text-[#00D4FF]"
                        data-testid="button-copy-key"
                      >
                        <Copy size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {apiKeysData?.keys?.length > 0 ? (
                  <div className="space-y-2">
                    {apiKeysData.keys.map((key: any) => (
                      <div key={key.id} className="flex items-center justify-between p-3 bg-[#152238] rounded-lg" data-testid={`api-key-${key.id}`}>
                        <div>
                          <p className="text-white text-sm">{key.label}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[#475569] text-xs font-mono">{key.keyPrefix}...</span>
                            <div className="flex gap-1">
                              {key.permissions?.map((p: string) => (
                                <span key={p} className="text-[10px] bg-[#0A1628] text-[#8899A6] px-1.5 py-0.5 rounded">{p}</span>
                              ))}
                            </div>
                            {key.lastUsed && <span className="text-[#475569] text-[10px]">Last used: {new Date(key.lastUsed).toLocaleDateString()}</span>}
                          </div>
                        </div>
                        <button
                          onClick={() => revokeKeyMutation.mutate(key.id)}
                          className="p-1.5 hover:bg-red-500/10 rounded text-red-400 text-xs"
                          data-testid={`button-revoke-key-${key.id}`}
                        >
                          Revoke
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[#475569] text-xs text-center py-4">No API keys created yet.</p>
                )}
              </div>

              <div className="bg-[#0D1117] border border-red-500/20 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Snowflake size={20} className="text-red-400" />
                  <h3 className="text-white font-semibold">Emergency Account Freeze</h3>
                </div>
                <p className="text-[#8899A6] text-xs mb-4">
                  Instantly freeze all account activity including trading, withdrawals, and API access. Use this if you suspect unauthorized access.
                </p>
                {isFrozen ? (
                  <button
                    onClick={() => unfreezeMutation.mutate()}
                    className="w-full py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg transition-colors"
                    data-testid="button-unfreeze-bottom"
                  >
                    Unfreeze Account
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      if (confirm("Are you sure you want to freeze your account? All transactions will be suspended.")) {
                        freezeMutation.mutate();
                      }
                    }}
                    className="w-full py-3 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg transition-colors"
                    data-testid="button-freeze"
                  >
                    Freeze Account Now
                  </button>
                )}
              </div>
            </div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-16 bg-gradient-to-r from-[#152238] to-[#0A1628] rounded-xl border border-[#FFD700]/20 p-8 text-center"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#FFD700]/[0.08] border border-[#FFD700]/20 rounded-full mb-4">
              <Crown size={14} className="text-[#FFD700]" />
              <span className="text-[#FFD700] font-medium text-xs uppercase tracking-wider">Enterprise & Institutional</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">License Our Security Technology</h2>
            <p className="text-[#8899A6] mb-2 max-w-xl mx-auto">
              Alpha Chain Integrity Protocol™, Autonomous Blockchain Spider™, Forensic Intelligence Engine™, and Alpha SafeSend Protocol™ are available for enterprise licensing.
            </p>
            <p className="text-[#475569] text-sm mb-6 max-w-lg mx-auto">
              With over $14B lost to crypto fraud annually, our proprietary technology gives exchanges, custodians, and financial institutions the tools to protect their users at the protocol level.
            </p>
            <a
              href="mailto:licensing@alphaunlimitedtrading.com"
              className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-[#0A1628] font-bold rounded-lg hover:shadow-lg hover:shadow-[#FFD700]/20 transition-all"
              data-testid="button-licensing-inquiry"
            >
              <Building2 size={18} />
              Inquire About Licensing
            </a>
            <p className="text-[#475569] text-xs mt-3">licensing@alphaunlimitedtrading.com — All technologies Patent Pending</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mt-12"
          >
            <h2 className="text-3xl font-bold text-white mb-4">Your Security Matters</h2>
            <p className="text-[#8899A6] mb-8 max-w-lg mx-auto">
              View the full security comparison, enable MFA, and review your security logs.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/security">
                <button
                  className="px-8 py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg transition-colors"
                  data-testid="button-full-security-page"
                >
                  Full Security Details
                  <ArrowRight size={16} className="inline-block ml-2" />
                </button>
              </Link>
              <Link href="/terminal">
                <button
                  className="px-8 py-3 bg-[#0D1117] border border-[#1A2942] hover:border-[#00D4FF]/30 text-[#00D4FF] font-medium rounded-lg transition-colors"
                  data-testid="button-start-trading-secure"
                >
                  Start Trading Securely
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </TradingPlatformLayout>
  );
}
