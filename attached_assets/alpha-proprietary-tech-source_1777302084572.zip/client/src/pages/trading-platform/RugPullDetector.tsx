/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Rug Pull Detector™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - Rug Pull Detector™
 * - Token Risk Analysis Engine™
 * - Smart Contract Vulnerability Scanner™
 * - Holder Distribution Analyzer™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_1d89f10a384ba0c254cc023d
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";

interface RiskResult {
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  chain: string;
  overallScore: number;
  riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  checks: {
    name: string;
    status: "PASS" | "WARN" | "FAIL";
    score: number;
    detail: string;
  }[];
  holderDistribution: {
    top10Percent: number;
    top50Percent: number;
    totalHolders: number;
  };
  liquidityInfo: {
    totalLiquidity: number;
    isLocked: boolean;
    lockDuration: string;
  };
  contractInfo: {
    isVerified: boolean;
    hasProxy: boolean;
    hasMintFunction: boolean;
    hasPauseFunction: boolean;
    ownerCanTransfer: boolean;
  };
  timestamp: number;
}

function riskColor(level: string) {
  switch (level) {
    case "LOW": return "text-green-400";
    case "MEDIUM": return "text-yellow-400";
    case "HIGH": return "text-orange-400";
    case "CRITICAL": return "text-red-400";
    default: return "text-gray-400";
  }
}

function riskBgColor(level: string) {
  switch (level) {
    case "LOW": return "bg-green-600/20 border-green-500/30 text-green-400";
    case "MEDIUM": return "bg-yellow-600/20 border-yellow-500/30 text-yellow-400";
    case "HIGH": return "bg-orange-600/20 border-orange-500/30 text-orange-400";
    case "CRITICAL": return "bg-red-600/20 border-red-500/30 text-red-400";
    default: return "bg-gray-600/20 border-gray-500/30 text-gray-400";
  }
}

function checkStatusIcon(status: string) {
  switch (status) {
    case "PASS": return "✅";
    case "WARN": return "⚠️";
    case "FAIL": return "❌";
    default: return "❓";
  }
}

function checkStatusColor(status: string) {
  switch (status) {
    case "PASS": return "text-green-400";
    case "WARN": return "text-yellow-400";
    case "FAIL": return "text-red-400";
    default: return "text-gray-400";
  }
}

function RiskGauge({ score }: { score: number }) {
  const angle = (score / 100) * 180 - 90;
  const color = score <= 30 ? "#22c55e" : score <= 60 ? "#eab308" : score <= 80 ? "#f97316" : "#ef4444";

  return (
    <div className="flex flex-col items-center" data-testid="gauge-risk-score">
      <svg viewBox="0 0 200 120" className="w-48 h-28">
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#1E3A5F" strokeWidth="12" strokeLinecap="round" />
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={`${(score / 100) * 251.2} 251.2`}
          className="transition-all duration-1000"
        />
        <line
          x1="100"
          y1="100"
          x2={100 + 60 * Math.cos((angle * Math.PI) / 180)}
          y2={100 + 60 * Math.sin((angle * Math.PI) / 180)}
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
          className="transition-all duration-1000"
        />
        <circle cx="100" cy="100" r="4" fill="white" />
        <text x="100" y="85" textAnchor="middle" fill={color} fontSize="28" fontWeight="bold" fontFamily="monospace">
          {score}
        </text>
        <text x="100" y="98" textAnchor="middle" fill="#6b7280" fontSize="10">
          / 100
        </text>
        <text x="25" y="115" fill="#22c55e" fontSize="8">Safe</text>
        <text x="165" y="115" fill="#ef4444" fontSize="8">Danger</text>
      </svg>
    </div>
  );
}

export default function RugPullDetector() {
  const [tokenInput, setTokenInput] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RiskResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [recentScans, setRecentScans] = useState<RiskResult[]>([]);

  const handleScan = async () => {
    if (!tokenInput.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/token-risk-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: tokenInput.trim(), chain }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to analyze token");
      }

      const data: RiskResult = await res.json();
      setResult(data);
      setRecentScans(prev => [data, ...prev.filter(s => s.tokenAddress !== data.tokenAddress)].slice(0, 10));
    } catch (err: any) {
      setError(err.message || "Analysis failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <TradingPlatformLayout>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" data-testid="page-rug-pull-detector">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row items-center gap-6"
        >
          <img
            src="/phoenix-rug-pull-stopper.png"
            alt="Alpha Phoenix stopping a crypto rug pull"
            className="w-80 h-48 md:w-[480px] md:h-[280px] object-contain drop-shadow-[0_0_25px_rgba(0,212,255,0.4)]"
            data-testid="img-rug-pull-phoenix"
          />
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2" data-testid="text-page-title">
              🛡️ Rug Pull Detector
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              AI-powered token risk analysis using real on-chain data. Detect honeypots, ownership concentration, and liquidity risks.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-lg">Token Scanner</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-3">
                <div className="flex-1">
                  <Label className="text-gray-400 text-xs mb-1.5 block">Token Address or Name</Label>
                  <Input
                    placeholder="0x... or token name (e.g. PEPE, SHIB)"
                    value={tokenInput}
                    onChange={(e) => setTokenInput(e.target.value)}
                    className="bg-[#0a1018] border-[#1E3A5F]/50 text-white"
                    onKeyDown={(e) => e.key === "Enter" && handleScan()}
                    data-testid="input-token-address"
                  />
                </div>
                <div className="w-full md:w-44">
                  <Label className="text-gray-400 text-xs mb-1.5 block">Chain</Label>
                  <Select value={chain} onValueChange={setChain}>
                    <SelectTrigger className="bg-[#0a1018] border-[#1E3A5F]/50 text-white" data-testid="select-chain">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0a1018] border-[#1E3A5F] max-h-[300px] overflow-y-auto" position="popper" sideOffset={4}>
                      <SelectItem value="ethereum" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Ethereum</SelectItem>
                      <SelectItem value="bsc" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">BSC (BNB Chain)</SelectItem>
                      <SelectItem value="polygon" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Polygon</SelectItem>
                      <SelectItem value="arbitrum" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Arbitrum</SelectItem>
                      <SelectItem value="base" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Base</SelectItem>
                      <SelectItem value="optimism" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Optimism</SelectItem>
                      <SelectItem value="avalanche" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Avalanche</SelectItem>
                      <SelectItem value="fantom" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Fantom</SelectItem>
                      <SelectItem value="cronos" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Cronos</SelectItem>
                      <SelectItem value="solana" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Solana</SelectItem>
                      <SelectItem value="tron" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">TRON</SelectItem>
                      <SelectItem value="zksync" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">zkSync Era</SelectItem>
                      <SelectItem value="linea" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Linea</SelectItem>
                      <SelectItem value="mantle" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Mantle</SelectItem>
                      <SelectItem value="scroll" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Scroll</SelectItem>
                      <SelectItem value="celo" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Celo</SelectItem>
                      <SelectItem value="gnosis" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Gnosis</SelectItem>
                      <SelectItem value="moonbeam" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Moonbeam</SelectItem>
                      <SelectItem value="blast" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">Blast</SelectItem>
                      <SelectItem value="pulsechain" className="text-white hover:bg-[#1E3A5F] focus:bg-[#1E3A5F] focus:text-white">PulseChain</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={handleScan}
                    disabled={loading || !tokenInput.trim()}
                    className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-black font-semibold w-full md:w-auto"
                    data-testid="button-scan-token"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        Scanning...
                      </span>
                    ) : (
                      "🔍 Scan Token"
                    )}
                  </Button>
                </div>
              </div>
              {error && (
                <div className="mt-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm" data-testid="text-scan-error">
                  ⚠️ {error}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-[#0f1923] border-[#1E3A5F]/50 lg:col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-lg flex items-center justify-between">
                    <span>Risk Score</span>
                    <Badge className={riskBgColor(result.riskLevel)} data-testid="badge-risk-level">
                      {result.riskLevel}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center">
                  <RiskGauge score={result.overallScore} />
                  <div className="mt-4 text-center space-y-1">
                    <div className="text-white font-semibold text-lg" data-testid="text-token-name">
                      {result.tokenName} ({result.tokenSymbol})
                    </div>
                    <div className="text-gray-500 text-xs font-mono truncate max-w-[250px]" data-testid="text-token-address" title={result.tokenAddress}>
                      {result.tokenAddress}
                    </div>
                    <Badge variant="outline" className="text-xs border-[#1E3A5F] text-gray-400 mt-1" data-testid="badge-chain">
                      {result.chain}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#0f1923] border-[#1E3A5F]/50 lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-lg">Security Checks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {result.checks.map((check, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-3 bg-[#0a1018] rounded-lg"
                        data-testid={`row-check-${i}`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{checkStatusIcon(check.status)}</span>
                          <div>
                            <div className={`text-sm font-medium ${checkStatusColor(check.status)}`}>
                              {check.name}
                            </div>
                            <div className="text-xs text-gray-500">{check.detail}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-1.5 bg-[#1E3A5F]/30 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all duration-500"
                              style={{
                                width: `${check.score}%`,
                                background: check.status === "PASS" ? "#22c55e" : check.status === "WARN" ? "#eab308" : "#ef4444",
                              }}
                            />
                          </div>
                          <span className={`text-xs font-mono ${checkStatusColor(check.status)}`}>
                            {check.score}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-sm">📊 Holder Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Top 10 Holders</span>
                    <span className={`font-mono text-sm ${result.holderDistribution.top10Percent > 80 ? "text-red-400" : result.holderDistribution.top10Percent > 50 ? "text-yellow-400" : "text-green-400"}`} data-testid="text-top10-percent">
                      {result.holderDistribution.top10Percent.toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#0a1018] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${result.holderDistribution.top10Percent}%`,
                        background: result.holderDistribution.top10Percent > 80 ? "#ef4444" : result.holderDistribution.top10Percent > 50 ? "#eab308" : "#22c55e",
                      }}
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Top 50 Holders</span>
                    <span className="font-mono text-sm text-gray-300" data-testid="text-top50-percent">
                      {result.holderDistribution.top50Percent.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Total Holders</span>
                    <span className="font-mono text-sm text-cyan-400" data-testid="text-total-holders">
                      {result.holderDistribution.totalHolders.toLocaleString()}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-sm">💧 Liquidity Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Total Liquidity</span>
                    <span className="font-mono text-sm text-white" data-testid="text-total-liquidity">
                      ${result.liquidityInfo.totalLiquidity.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Liquidity Locked</span>
                    <Badge className={result.liquidityInfo.isLocked ? "bg-green-600/20 text-green-400 border-green-500/30" : "bg-red-600/20 text-red-400 border-red-500/30"} data-testid="badge-liquidity-locked">
                      {result.liquidityInfo.isLocked ? "LOCKED" : "UNLOCKED"}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-xs">Lock Duration</span>
                    <span className="font-mono text-sm text-gray-300" data-testid="text-lock-duration">
                      {result.liquidityInfo.lockDuration}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-sm">📝 Contract Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "Verified Source", value: result.contractInfo.isVerified, good: true },
                    { label: "Proxy Contract", value: result.contractInfo.hasProxy, good: false },
                    { label: "Mint Function", value: result.contractInfo.hasMintFunction, good: false },
                    { label: "Pause Function", value: result.contractInfo.hasPauseFunction, good: false },
                    { label: "Owner Transfer", value: result.contractInfo.ownerCanTransfer, good: false },
                  ].map((item, i) => (
                    <div key={i} className="flex justify-between items-center">
                      <span className="text-gray-400 text-xs">{item.label}</span>
                      <Badge
                        className={
                          (item.good ? item.value : !item.value)
                            ? "bg-green-600/20 text-green-400 border-green-500/30"
                            : "bg-red-600/20 text-red-400 border-red-500/30"
                        }
                        data-testid={`badge-contract-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                      >
                        {item.value ? "YES" : "NO"}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {!result && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardContent className="py-16 text-center">
                <div className="text-5xl mb-4">🔍</div>
                <h3 className="text-white text-lg font-semibold mb-2" data-testid="text-empty-state">
                  Enter a token address to start scanning
                </h3>
                <p className="text-gray-500 text-sm max-w-md mx-auto">
                  Paste any ERC-20 token contract address or search by name. 
                  Our AI analyzes liquidity locks, ownership concentration, contract code, 
                  honeypot detection, and holder distribution to give you a comprehensive risk score.
                </p>
                <div className="mt-6 flex flex-wrap gap-2 justify-center">
                  {[
                    { name: "Liquidity Lock", icon: "🔒" },
                    { name: "Honeypot Check", icon: "🍯" },
                    { name: "Ownership Analysis", icon: "👤" },
                    { name: "Contract Audit", icon: "📋" },
                    { name: "Holder Distribution", icon: "📊" },
                  ].map((item) => (
                    <Badge key={item.name} variant="outline" className="border-[#1E3A5F] text-gray-400 text-xs px-3 py-1.5">
                      {item.icon} {item.name}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {recentScans.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-[#0f1923] border-[#1E3A5F]/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-lg">Recent Scans</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" data-testid="table-recent-scans">
                    <thead>
                      <tr className="border-b border-[#1E3A5F]/50 text-gray-400 text-xs">
                        <th className="text-left py-2 px-3">Token</th>
                        <th className="text-left py-2 px-3">Chain</th>
                        <th className="text-center py-2 px-3">Score</th>
                        <th className="text-center py-2 px-3">Risk Level</th>
                        <th className="text-right py-2 px-3">Time</th>
                        <th className="text-right py-2 px-3">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentScans.map((scan, i) => (
                        <tr
                          key={scan.tokenAddress + "-" + i}
                          className="border-b border-[#1E3A5F]/20 hover:bg-[#152238]/50 transition-colors"
                          data-testid={`row-scan-${i}`}
                        >
                          <td className="py-2 px-3">
                            <div className="text-white text-xs font-medium">{scan.tokenName}</div>
                            <div className="text-gray-500 text-[10px] font-mono truncate max-w-[150px]">{scan.tokenAddress}</div>
                          </td>
                          <td className="py-2 px-3">
                            <Badge variant="outline" className="text-[10px] border-[#1E3A5F] text-gray-400">
                              {scan.chain}
                            </Badge>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <span className={`font-mono font-bold ${riskColor(scan.riskLevel)}`}>
                              {scan.overallScore}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <Badge className={`text-[10px] ${riskBgColor(scan.riskLevel)}`}>
                              {scan.riskLevel}
                            </Badge>
                          </td>
                          <td className="py-2 px-3 text-right text-gray-500 text-xs">
                            {new Date(scan.timestamp).toLocaleTimeString()}
                          </td>
                          <td className="py-2 px-3 text-right">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-xs text-cyan-400 hover:text-cyan-300"
                              onClick={() => {
                                setTokenInput(scan.tokenAddress);
                                setChain(scan.chain);
                                setResult(scan);
                              }}
                              data-testid={`button-view-scan-${i}`}
                            >
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </TradingPlatformLayout>
  );
}
