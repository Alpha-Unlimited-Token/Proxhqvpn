/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Quantum Shield Protocol™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Alpha Quantum Shield Protocol™
 * - ML-KEM Lattice-Based Key Encapsulation™
 * - Real-Time Quantum Threat Detection™
 * - Post-Quantum Signature Verification™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_QS_SHIELD_PAGE_SEALED
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { useState, useEffect } from "react";
import { TradingPlatformLayout } from "@/components/trading-platform/TradingPlatformLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Shield, Activity, AlertTriangle, Lock, Zap, CheckCircle, XCircle, Radio } from "lucide-react";

interface ShieldStatus {
  active: boolean;
  algorithm: string;
  keySize: number;
  activatedAt: string | null;
  threatsBlocked: number;
  lastThreatAt: string | null;
  encapsulationStrength: string;
  quantumResistanceLevel: string;
}

interface ThreatEntry {
  id: string;
  timestamp: string;
  txHash: string;
  chain: string;
  threatLevel: string;
  attackVector: string;
  fromAddress: string;
  blocked: boolean;
  details: string;
}

export default function QuantumShield() {
  const [status, setStatus] = useState<ShieldStatus | null>(null);
  const [threats, setThreats] = useState<ThreatEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activating, setActivating] = useState(false);
  const [analyzeTx, setAnalyzeTx] = useState("");
  const [analyzeChain, setAnalyzeChain] = useState("ethereum");
  const [analyzeFrom, setAnalyzeFrom] = useState("");
  const [analyzeResult, setAnalyzeResult] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    fetchStatus();
    fetchThreats();
  }, []);

  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/quantum/shield/status");
      const data = await res.json();
      setStatus(data);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const fetchThreats = async () => {
    try {
      const res = await fetch("/api/quantum/shield/threats?limit=20");
      const data = await res.json();
      setThreats(data || []);
    } catch (e) { console.error(e); }
  };

  const toggleShield = async () => {
    setActivating(true);
    try {
      const endpoint = status?.active ? "/api/quantum/shield/deactivate" : "/api/quantum/shield/activate";
      const res = await fetch(endpoint, { method: "POST" });
      const data = await res.json();
      setStatus(data);
    } catch (e) { console.error(e); }
    setActivating(false);
  };

  const handleAnalyze = async () => {
    if (!analyzeTx || !analyzeFrom) return;
    setAnalyzing(true);
    try {
      const res = await fetch("/api/quantum/shield/analyze-tx", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ txHash: analyzeTx, chain: analyzeChain, fromAddress: analyzeFrom }),
      });
      const data = await res.json();
      setAnalyzeResult(data.threat);
    } catch (e) { console.error(e); }
    setAnalyzing(false);
  };

  const threatColor = (level: string) => {
    switch (level) {
      case "CRITICAL": return "text-red-400";
      case "HIGH": return "text-orange-400";
      case "MEDIUM": return "text-yellow-400";
      default: return "text-green-400";
    }
  };

  return (
    <TradingPlatformLayout title="Alpha Quantum Shield Protocol™" subtitle="Post-Quantum Cryptographic Defense Layer">
      <div className="space-y-6 p-4 max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4" /> Shield Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-gray-400">Loading...</div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${status?.active ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                      <span className={`text-lg font-bold ${status?.active ? 'text-green-400' : 'text-red-400'}`}>
                        {status?.active ? "ACTIVE" : "INACTIVE"}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400">Algorithm: {status?.algorithm || "ML-KEM-1024"}</div>
                    <div className="text-xs text-gray-400">Key Size: {status?.keySize || 1024} bits</div>
                    <div className="text-xs text-gray-400">Resistance: {status?.quantumResistanceLevel || "NIST Level 5"}</div>
                    <Button
                      data-testid="button-toggle-shield"
                      onClick={toggleShield}
                      disabled={activating}
                      className={`w-full mt-2 ${status?.active ? 'bg-red-600 hover:bg-red-700' : 'bg-[#d4af37] hover:bg-[#b8962e] text-black'}`}
                      size="sm"
                    >
                      {activating ? "Processing..." : status?.active ? "Deactivate Shield" : "Activate Shield"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Protection Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="text-2xl font-bold text-white">{status?.threatsBlocked || 0}</div>
                    <div className="text-xs text-gray-400">Threats Blocked</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-300">{status?.encapsulationStrength || "256-bit"}</div>
                    <div className="text-xs text-gray-400">Encapsulation Strength</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">
                      Last Threat: {status?.lastThreatAt ? new Date(status.lastThreatAt).toLocaleString() : "None detected"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                  <Lock className="w-4 h-4" /> NIST Standards
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: "ML-KEM (FIPS 203)", status: "Active", icon: CheckCircle },
                    { name: "ML-DSA (FIPS 204)", status: "Active", icon: CheckCircle },
                    { name: "SLH-DSA (FIPS 205)", status: "Active", icon: CheckCircle },
                  ].map((std, i) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="text-gray-300">{std.name}</span>
                      <Badge variant="outline" className="text-green-400 border-green-400/30 text-[10px]">
                        <std.icon className="w-3 h-3 mr-1" />{std.status}
                      </Badge>
                    </div>
                  ))}
                  <div className="text-[10px] text-gray-500 mt-2">
                    NIST Post-Quantum Cryptography Standards — Full Compliance
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30 mb-6">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Zap className="w-4 h-4" /> Transaction Quantum Threat Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <Input
                  data-testid="input-analyze-tx"
                  placeholder="Transaction Hash (0x...)"
                  value={analyzeTx}
                  onChange={(e) => setAnalyzeTx(e.target.value)}
                  className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                />
                <Input
                  data-testid="input-analyze-from"
                  placeholder="From Address (0x...)"
                  value={analyzeFrom}
                  onChange={(e) => setAnalyzeFrom(e.target.value)}
                  className="bg-[#0a0a1a] border-gray-700 text-white text-sm"
                />
                <select
                  data-testid="select-analyze-chain"
                  value={analyzeChain}
                  onChange={(e) => setAnalyzeChain(e.target.value)}
                  className="bg-[#0a0a1a] border border-gray-700 text-white text-sm rounded-md px-3"
                >
                  <option value="ethereum">Ethereum</option>
                  <option value="bsc">BSC</option>
                  <option value="polygon">Polygon</option>
                  <option value="arbitrum">Arbitrum</option>
                  <option value="solana">Solana</option>
                </select>
                <Button
                  data-testid="button-analyze-tx"
                  onClick={handleAnalyze}
                  disabled={analyzing || !analyzeTx || !analyzeFrom}
                  className="bg-[#d4af37] hover:bg-[#b8962e] text-black"
                >
                  {analyzing ? "Analyzing..." : "Analyze Threat"}
                </Button>
              </div>

              {analyzeResult && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 p-4 bg-[#0a0a1a] rounded-lg border border-gray-800">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-300">Threat Assessment</span>
                    <Badge className={`${analyzeResult.blocked ? 'bg-red-600' : 'bg-green-600'}`}>
                      {analyzeResult.blocked ? "BLOCKED" : "SAFE"}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div><span className="text-gray-500">Level:</span> <span className={threatColor(analyzeResult.threatLevel)}>{analyzeResult.threatLevel}</span></div>
                    <div><span className="text-gray-500">Vector:</span> <span className="text-gray-300">{analyzeResult.attackVector}</span></div>
                    <div><span className="text-gray-500">Chain:</span> <span className="text-gray-300">{analyzeResult.chain}</span></div>
                    <div><span className="text-gray-500">Confidence:</span> <span className="text-gray-300">{analyzeResult.confidenceScore ? (analyzeResult.confidenceScore * 100).toFixed(1) + "%" : "N/A"}</span></div>
                  </div>
                  <div className="mt-2 text-xs text-gray-400">{analyzeResult.details}</div>
                </motion.div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] border-[#d4af37]/30">
            <CardHeader>
              <CardTitle className="text-[#d4af37] text-sm flex items-center gap-2">
                <Radio className="w-4 h-4" /> Recent Threat Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              {threats.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Shield className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p>No threats detected. Shield is protecting your transactions.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {threats.map((t, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-[#0a0a1a] rounded-lg border border-gray-800 text-xs">
                      <div className="flex items-center gap-3">
                        {t.blocked ? <XCircle className="w-4 h-4 text-red-400" /> : <CheckCircle className="w-4 h-4 text-green-400" />}
                        <div>
                          <div className="text-gray-300 font-mono">{t.txHash?.substring(0, 20)}...</div>
                          <div className="text-gray-500">{t.chain} · {t.attackVector}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className={`${threatColor(t.threatLevel)} border-current text-[10px]`}>
                          {t.threatLevel}
                        </Badge>
                        <div className="text-gray-500 mt-1">{new Date(t.timestamp).toLocaleString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="mt-6 p-4 bg-[#0a0a1a] rounded-lg border border-[#d4af37]/20">
            <h3 className="text-[#d4af37] text-sm font-bold mb-2">How Alpha Quantum Shield Protocol™ Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">ML-KEM Key Encapsulation</h4>
                <p>Uses NIST FIPS 203 Module-Lattice-Based Key Encapsulation to secure all key exchanges against quantum decryption attacks. 1024-bit lattice keys provide NIST Level 5 security.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Real-Time Threat Detection</h4>
                <p>Every transaction is analyzed for quantum attack signatures including Shor's algorithm patterns, Grover's search optimization, and lattice-based cryptanalysis attempts.</p>
              </div>
              <div>
                <h4 className="text-gray-300 font-semibold mb-1">Automatic Blocking</h4>
                <p>Transactions exhibiting quantum threat signatures are automatically blocked before execution. The shield operates at the mempool level for pre-confirmation protection.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </TradingPlatformLayout>
  );
}
