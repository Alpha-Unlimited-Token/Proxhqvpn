/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha News Sentiment Analysis Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Technologies Protected:
   * - News Sentiment Analysis Engine™
 * - AI-Powered Sentiment Scoring™
 * - Market Mood Gauge™
 * - Real-Time News Aggregation™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_4d2f8990d71e4bfe724f1ac5
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain, TrendingUp, TrendingDown, Minus, RefreshCw, ExternalLink,
  AlertTriangle, Zap, BarChart3, Filter, Clock, Newspaper,
  ArrowUp, ArrowDown, Sparkles, Activity, Eye
} from 'lucide-react';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';

interface NewsArticle {
  id: string;
  title: string;
  body: string;
  source: string;
  url: string;
  publishedAt: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  sentimentScore: number;
  impact: 'high' | 'medium' | 'low';
  reasoning: string;
  coins: string[];
  category: string;
  imageUrl?: string;
  aiPowered: boolean;
}

interface MarketMood {
  overall: string;
  score: number;
  bullishCount: number;
  bearishCount: number;
  neutralCount: number;
  totalArticles: number;
}

interface SentimentData {
  articles: NewsArticle[];
  marketMood: MarketMood;
  lastUpdated: string;
  aiPowered: boolean;
  userTier?: string;
  requiresTier?: string | null;
}

function SentimentGauge({ score, size = 180 }: { score: number; size?: number }) {
  const angle = ((score / 100) * 180) - 90;
  const r = size / 2 - 20;
  const cx = size / 2;
  const cy = size / 2 + 10;

  const getColor = (s: number) => s > 60 ? '#22c55e' : s < 40 ? '#ef4444' : '#eab308';

  const segments = [
    { start: -90, end: -54, color: '#ef4444' },
    { start: -54, end: -18, color: '#f97316' },
    { start: -18, end: 18, color: '#eab308' },
    { start: 18, end: 54, color: '#84cc16' },
    { start: 54, end: 90, color: '#22c55e' },
  ];

  const polarToCart = (a: number, radius: number) => ({
    x: cx + radius * Math.cos((a * Math.PI) / 180),
    y: cy + radius * Math.sin((a * Math.PI) / 180),
  });

  const describeArc = (startAngle: number, endAngle: number, radius: number) => {
    const start = polarToCart(startAngle - 90, radius);
    const end = polarToCart(endAngle - 90, radius);
    const large = endAngle - startAngle > 180 ? 1 : 0;
    return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${large} 1 ${end.x} ${end.y}`;
  };

  const needleTip = polarToCart(angle, r - 10);

  return (
    <svg viewBox={`0 0 ${size} ${size / 2 + 40}`} className="w-full max-w-[240px] mx-auto">
      {segments.map((seg, i) => (
        <path key={i} d={describeArc(seg.start, seg.end, r)} fill="none" stroke={seg.color} strokeWidth="12" strokeLinecap="round" opacity={0.3} />
      ))}
      <path d={describeArc(-90, angle, r)} fill="none" stroke={getColor(score)} strokeWidth="12" strokeLinecap="round" />
      <line x1={cx} y1={cy} x2={needleTip.x} y2={needleTip.y} stroke="white" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx={cx} cy={cy} r="5" fill="white" />
      <text x={cx} y={cy + 25} textAnchor="middle" fill="white" fontSize="22" fontWeight="bold" fontFamily="Orbitron, sans-serif">{score}</text>
      <text x={cx} y={cy + 40} textAnchor="middle" fill="#8899A6" fontSize="10">/100</text>
      <text x={cx - r + 5} y={cy + 18} textAnchor="start" fill="#ef4444" fontSize="9">Fear</text>
      <text x={cx + r - 5} y={cy + 18} textAnchor="end" fill="#22c55e" fontSize="9">Greed</text>
    </svg>
  );
}

function ImpactBadge({ impact }: { impact: string }) {
  const config = {
    high: { color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: AlertTriangle, label: 'High Impact' },
    medium: { color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', icon: Zap, label: 'Medium' },
    low: { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20', icon: Minus, label: 'Low' },
  }[impact] || { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20', icon: Minus, label: impact };

  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full border ${config.color}`}>
      <Icon size={10} />
      {config.label}
    </span>
  );
}

function SentimentBadge({ sentiment, score }: { sentiment: string; score: number }) {
  const config = {
    bullish: { color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20', icon: TrendingUp },
    bearish: { color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20', icon: TrendingDown },
    neutral: { color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20', icon: Minus },
  }[sentiment] || { color: 'text-gray-400', bg: 'bg-gray-500/10 border-gray-500/20', icon: Minus };

  const Icon = config.icon;
  return (
    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border ${config.bg}`}>
      <Icon size={14} className={config.color} />
      <span className={`text-xs font-semibold ${config.color} capitalize`}>{sentiment}</span>
      <span className={`text-[10px] ${config.color} opacity-70`}>{score}</span>
    </div>
  );
}

function timeAgo(date: string) {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function NewsSentiment() {
  const [data, setData] = useState<SentimentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'bullish' | 'bearish' | 'neutral'>('all');
  const [coinFilter, setCoinFilter] = useState<string>('all');
  const [impactFilter, setImpactFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/news-sentiment');
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      setData(json);
    } catch {
      setError('Unable to load AI sentiment data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    const interval = setInterval(fetchData, 300000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const allCoins = data ? [...new Set(data.articles.flatMap(a => a.coins))].sort() : [];

  const filtered = data?.articles.filter(a => {
    if (filter !== 'all' && a.sentiment !== filter) return false;
    if (coinFilter !== 'all' && !a.coins.includes(coinFilter)) return false;
    if (impactFilter !== 'all' && a.impact !== impactFilter) return false;
    return true;
  }) || [];

  return (
    <TradingPlatformLayout>
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6" data-testid="news-sentiment-page">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center gap-3" style={{ fontFamily: 'Orbitron, sans-serif' }} data-testid="text-sentiment-heading">
              <Brain className="text-[#00D4FF]" size={28} />
              AI News Sentiment
            </h1>
            <p className="text-sm text-[#8899A6] mt-1">
              Real-time crypto news analyzed by AI for market sentiment and impact
            </p>
          </div>
          <button
            onClick={fetchData}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-[#161b22] border border-gray-700 rounded-lg text-sm text-[#94A3B8] hover:text-white hover:border-[#00D4FF]/50 transition-all disabled:opacity-50"
            data-testid="button-refresh-sentiment"
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            {loading ? 'Analyzing...' : 'Refresh'}
          </button>
        </div>

        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm" data-testid="text-sentiment-error">
            {error}
          </div>
        )}

        {data && !data.aiPowered && data.requiresTier && (
          <div className="relative overflow-hidden rounded-xl border border-[#FFD700]/30 bg-gradient-to-r from-[#FFD700]/5 via-[#0d1117] to-[#00D4FF]/5 p-4" data-testid="banner-ai-upgrade">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[#FFD700]/10">
                  <Sparkles className="text-[#FFD700]" size={20} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Upgrade to Premium for AI-Powered Analysis</p>
                  <p className="text-xs text-[#8899A6] mt-0.5">Get deeper AI sentiment reasoning, more accurate scoring, and impact assessment powered by advanced language models</p>
                </div>
              </div>
              <a
                href="/account"
                className="shrink-0 px-4 py-2 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black text-xs font-bold rounded-lg hover:opacity-90 transition-opacity"
                data-testid="link-upgrade-premium"
              >
                Upgrade Now
              </a>
            </div>
          </div>
        )}

        {data && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-1 bg-[#0D1117] border border-[#1A2942] rounded-xl p-6" data-testid="card-market-mood">
                <h3 className="text-sm font-semibold text-[#8899A6] mb-2 flex items-center gap-2">
                  <Activity size={14} />
                  Market Mood
                </h3>
                <SentimentGauge score={data.marketMood.score} />
                <div className="mt-3 text-center">
                  <span className={`text-lg font-bold capitalize ${
                    data.marketMood.overall === 'bullish' ? 'text-green-400' :
                    data.marketMood.overall === 'bearish' ? 'text-red-400' : 'text-yellow-400'
                  }`}>
                    {data.marketMood.overall}
                  </span>
                </div>
              </div>

              <div className="md:col-span-1 bg-[#0D1117] border border-[#1A2942] rounded-xl p-6 space-y-4" data-testid="card-sentiment-breakdown">
                <h3 className="text-sm font-semibold text-[#8899A6] flex items-center gap-2">
                  <BarChart3 size={14} />
                  Sentiment Breakdown
                </h3>
                {[
                  { label: 'Bullish', count: data.marketMood.bullishCount, total: data.marketMood.totalArticles, color: '#22c55e' },
                  { label: 'Neutral', count: data.marketMood.neutralCount, total: data.marketMood.totalArticles, color: '#eab308' },
                  { label: 'Bearish', count: data.marketMood.bearishCount, total: data.marketMood.totalArticles, color: '#ef4444' },
                ].map(item => (
                  <div key={item.label}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-[#94A3B8]">{item.label}</span>
                      <span style={{ color: item.color }} className="font-medium">{item.count}/{item.total}</span>
                    </div>
                    <div className="h-2 bg-[#161b22] rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(item.count / item.total) * 100}%` }}
                        transition={{ duration: 0.8 }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="md:col-span-1 bg-[#0D1117] border border-[#1A2942] rounded-xl p-6 space-y-3" data-testid="card-analysis-info">
                <h3 className="text-sm font-semibold text-[#8899A6] flex items-center gap-2">
                  <Sparkles size={14} />
                  Analysis Info
                </h3>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#8899A6]">Engine</span>
                    <span className={data.aiPowered ? 'text-[#00D4FF]' : 'text-yellow-400'}>
                      {data.aiPowered ? 'AI-Powered (Premium)' : 'Keyword Analysis'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8899A6]">Articles Analyzed</span>
                    <span className="text-white">{data.marketMood.totalArticles}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8899A6]">Last Updated</span>
                    <span className="text-white">{timeAgo(data.lastUpdated)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8899A6]">Auto-refresh</span>
                    <span className="text-green-400">Every 5 min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8899A6]">Source</span>
                    <span className="text-white">CryptoCompare</span>
                  </div>
                </div>
                {data.aiPowered && (
                  <div className="mt-2 p-2 bg-[#00D4FF]/5 border border-[#00D4FF]/20 rounded-lg text-[10px] text-[#00D4FF] flex items-center gap-1.5">
                    <Brain size={12} />
                    Sentiment analysis with reasoning
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 bg-[#0D1117] border border-[#1A2942] rounded-xl p-3">
              <Filter size={14} className="text-[#8899A6]" />
              <div className="flex gap-1">
                {(['all', 'bullish', 'bearish', 'neutral'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`text-xs px-3 py-1.5 rounded-lg transition-all capitalize ${
                      filter === f ? 'bg-[#00D4FF]/10 text-[#00D4FF] border border-[#00D4FF]/30' : 'text-[#8899A6] hover:text-white'
                    }`}
                    data-testid={`button-filter-${f}`}
                  >
                    {f}
                  </button>
                ))}
              </div>
              <div className="h-4 w-px bg-gray-700 mx-1" />
              <select
                value={coinFilter}
                onChange={e => setCoinFilter(e.target.value)}
                className="text-xs bg-[#161b22] border border-gray-700 rounded-lg px-2 py-1.5 text-[#94A3B8]"
                data-testid="select-coin-filter"
              >
                <option value="all">All Coins</option>
                {allCoins.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select
                value={impactFilter}
                onChange={e => setImpactFilter(e.target.value as any)}
                className="text-xs bg-[#161b22] border border-gray-700 rounded-lg px-2 py-1.5 text-[#94A3B8]"
                data-testid="select-impact-filter"
              >
                <option value="all">All Impact</option>
                <option value="high">High Impact</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
              <span className="text-[10px] text-[#8899A6] ml-auto">{filtered.length} articles</span>
            </div>

            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {filtered.map((article, i) => (
                  <motion.div
                    key={article.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="bg-[#0D1117] border border-[#1A2942] hover:border-[#1A2942]/80 rounded-xl p-4 cursor-pointer transition-all"
                    onClick={() => setExpandedId(expandedId === article.id ? null : article.id)}
                    data-testid={`card-news-${article.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-1 self-stretch rounded-full flex-shrink-0 ${
                        article.sentiment === 'bullish' ? 'bg-green-500' :
                        article.sentiment === 'bearish' ? 'bg-red-500' : 'bg-yellow-500'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <h4 className="text-sm font-semibold text-white leading-snug line-clamp-2" data-testid={`text-news-title-${article.id}`}>
                            {article.title}
                          </h4>
                          <SentimentBadge sentiment={article.sentiment} score={article.sentimentScore} />
                        </div>
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className="text-[10px] text-[#8899A6] flex items-center gap-1">
                            <Newspaper size={10} /> {article.source}
                          </span>
                          <span className="text-[10px] text-[#8899A6] flex items-center gap-1">
                            <Clock size={10} /> {timeAgo(article.publishedAt)}
                          </span>
                          <ImpactBadge impact={article.impact} />
                          {article.aiPowered && (
                            <span className="text-[10px] text-[#00D4FF] flex items-center gap-1">
                              <Brain size={10} /> AI
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {article.coins.map(coin => (
                            <span key={coin} className="text-[10px] bg-[#161b22] text-[#94A3B8] border border-gray-800 rounded px-1.5 py-0.5 font-mono">
                              {coin}
                            </span>
                          ))}
                        </div>
                        <AnimatePresence>
                          {expandedId === article.id && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden"
                            >
                              <div className="mt-3 pt-3 border-t border-[#1A2942] space-y-2">
                                {article.reasoning && (
                                  <div className="p-2.5 bg-[#161b22] rounded-lg">
                                    <p className="text-[10px] text-[#8899A6] mb-1 font-semibold flex items-center gap-1">
                                      <Brain size={10} className={article.aiPowered ? "text-[#FFD700]" : "text-[#00D4FF]"} />
                                      {article.aiPowered ? 'AI-Powered Analysis' : 'Keyword Analysis'}
                                      {article.aiPowered && <span className="ml-1 px-1.5 py-0.5 bg-[#FFD700]/10 text-[#FFD700] rounded text-[8px] font-bold">PREMIUM</span>}
                                    </p>
                                    <p className="text-xs text-[#94A3B8]">{article.reasoning}</p>
                                  </div>
                                )}
                                <p className="text-xs text-[#8899A6] leading-relaxed">{article.body}...</p>
                                <a
                                  href={article.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 text-xs text-[#00D4FF] hover:underline"
                                  onClick={e => e.stopPropagation()}
                                  data-testid={`link-read-more-${article.id}`}
                                >
                                  Read full article <ExternalLink size={10} />
                                </a>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {filtered.length === 0 && !loading && (
                <div className="text-center py-12 text-[#8899A6] text-sm">
                  No articles match your filters. Try adjusting them.
                </div>
              )}
            </div>
          </>
        )}

        {loading && !data && (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="bg-[#0D1117] border border-[#1A2942] rounded-xl p-4 animate-pulse">
                <div className="h-4 bg-[#161b22] rounded w-3/4 mb-3" />
                <div className="h-3 bg-[#161b22] rounded w-1/2 mb-2" />
                <div className="h-3 bg-[#161b22] rounded w-1/3" />
              </div>
            ))}
          </div>
        )}
      </div>
    </TradingPlatformLayout>
  );
}