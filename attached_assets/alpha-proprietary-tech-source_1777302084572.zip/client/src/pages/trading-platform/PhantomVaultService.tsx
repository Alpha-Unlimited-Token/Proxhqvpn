/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Phantom Vault Protocol™ — Customer-Facing Decoy Wallet Service
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements the customer-facing Phantom Vault Protection Service™ including
 * subscription management, decoy wallet creation with AI-generated branding, steganographic
 * beacon embedding, mimic token deployment, and self-destruct timer management.
 *
 * Technologies Protected:
 * - Alpha Phantom Vault Protocol™
 * - Steganographic Beacon Tracking System™
 * - Mimic Token Engine™ (8 token types)
 * - AI Wallet Branding Generator™
 * - Self-Destruct Token Disintegration™
 * - Spider Transfer Auto-Deploy™
 * - 3-Tier Subscription Architecture™ (Shield / Sentinel / Fortress)
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: PHANTOM_VAULT_v2.1_PROTECTED
 * AUT_ModuleHash: AUT_de156a337486719ba4b9f643
 */

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";

const _phantomVaultIntegritySeal = 'AUT_de156a337486719ba4b9f643';
const _pvAntiTamperCheck = (): boolean => {
  const doc = typeof document !== 'undefined' ? document : null;
  if (!doc) return true;
  const scripts = doc.querySelectorAll('script[src]');
  let tampered = false;
  scripts.forEach(s => {
    const src = s.getAttribute('src') || '';
    if (src.includes('phantom') && !src.includes('.replit.')) {
      tampered = true;
    }
  });
  if (tampered) {
    console.error('[FATAL] Alpha Phantom Vault Protocol™ — Unauthorized deployment detected. This proprietary technology is protected by international copyright law. Usage outside authorized Alpha Unlimited infrastructure is a violation of trade secret and copyright protections. Incident logged.');
    try { fetch('/api/security/beacon-violation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ module: 'PhantomVault', seal: _phantomVaultIntegritySeal, host: location.hostname, timestamp: Date.now() }) }).catch(() => {}); } catch {}
  }
  return !tampered;
};
if (typeof window !== 'undefined') { _pvAntiTamperCheck(); }

interface Subscription {
  id: string;
  plan: string;
  status: string;
  maxVaults: number;
  vaultsUsed: number;
  currentPeriodEnd: string;
}

interface Vault {
  id: string;
  vaultName: string;
  walletAddress: string;
  chain: string;
  decoyTokenType: string;
  decoyAmount: number;
  expirationHours: number;
  status: string;
  walletIcon: string | null;
  walletSplash: string | null;
  walletTheme: { primary: string; accent: string; bg: string } | null;
  beaconHits: number;
  triggeredAt: string | null;
  triggeredByAddress: string | null;
  expiresAt: string | null;
  discoveredCount: number;
  transferCount: number;
  createdAt: string;
}

interface Transfer {
  txHash: string;
  to: string;
  amount: number;
  token: string;
  beaconAttached: boolean;
  timestamp: string;
}

const CHAINS = [
  { value: "ethereum", label: "Ethereum" },
  { value: "bsc", label: "BNB Smart Chain" },
  { value: "polygon", label: "Polygon" },
  { value: "arbitrum", label: "Arbitrum" },
  { value: "optimism", label: "Optimism" },
  { value: "base", label: "Base" },
  { value: "avalanche", label: "Avalanche" },
];

const TOKEN_TYPES = [
  { value: "USDC", label: "USDC", icon: "$" },
  { value: "USDT", label: "Tether USDT", icon: "₮" },
  { value: "DAI", label: "DAI", icon: "◈" },
  { value: "ETH", label: "Ethereum", icon: "Ξ" },
  { value: "WETH", label: "Wrapped ETH", icon: "Ξ" },
  { value: "WBTC", label: "Wrapped BTC", icon: "₿" },
  { value: "LINK", label: "Chainlink", icon: "⬡" },
  { value: "UNI", label: "Uniswap", icon: "🦄" },
];

const DISCLAIMER_TEXT = `IMPORTANT LEGAL NOTICE — PLEASE READ CAREFULLY

Alpha Phantom Vault Protection™ creates decoy cryptocurrency wallets containing mimic tokens with embedded tracking beacons for personal security purposes.

DATA ACCESS & RETRIEVAL POLICY:
• You have access to view your vault status, transfer activity, and beacon hit counts.
• Detailed forensic trace data, attacker identification, IP addresses, wallet clustering analysis, and full investigative reports are NOT included in your subscription.
• To obtain comprehensive forensic investigation data suitable for law enforcement or legal proceedings, a separate Data Retrieval Fee of $2,500 per vault is required.
• Alternatively, law enforcement agencies may obtain this data via valid legal process (subpoena, court order, or search warrant).

LIABILITY DISCLAIMER:
• Phantom Vault Protection is provided "as-is" for personal security and deterrence purposes.
• Alpha Unlimited Trading makes no guarantees regarding fund recovery or attacker identification.
• Users are responsible for ensuring compliance with applicable laws in their jurisdiction.
• Mimic tokens are non-transferable on real blockchain networks and have no monetary value.

By proceeding, you acknowledge and accept these terms.`;

function shortenAddr(addr: string): string {
  if (!addr || addr.length < 12) return addr;
  return addr.slice(0, 6) + "..." + addr.slice(-4);
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    armed: "bg-green-500/20 text-green-400 border-green-500/30",
    triggered: "bg-red-500/20 text-red-400 border-red-500/30 animate-pulse",
    disintegrated: "bg-gray-600/20 text-gray-400 border-gray-600/30",
    disarmed: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  };
  return (
    <span className={`px-2 py-0.5 text-xs rounded border ${colors[status] || colors.armed}`} data-testid={`status-${status}`}>
      {status.toUpperCase()}
    </span>
  );
}

function WalletCard({ vault, onOpen }: { vault: Vault; onOpen: () => void }) {
  const theme = vault.walletTheme || { primary: "#1a73e8", accent: "#4285f4", bg: "#0d1421" };

  return (
    <div
      data-testid={`card-vault-${vault.id}`}
      onClick={onOpen}
      className="relative overflow-hidden rounded-xl border cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl"
      style={{ borderColor: theme.primary + "40", background: `linear-gradient(135deg, ${theme.bg}, #0d1117)` }}
    >
      <div className="absolute top-0 right-0 w-32 h-32 opacity-10" style={{ background: `radial-gradient(circle, ${theme.accent}, transparent)` }} />
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          {vault.walletIcon ? (
            <img src={vault.walletIcon} alt="Wallet" className="w-10 h-10 rounded-lg" data-testid={`img-vault-icon-${vault.id}`} />
          ) : (
            <div className="w-10 h-10 rounded-lg flex items-center justify-center text-lg font-bold" style={{ background: theme.primary + "30", color: theme.accent }}>
              {vault.decoyTokenType.charAt(0)}
            </div>
          )}
          <div className="flex-1">
            <div className="text-sm font-semibold text-gray-200" data-testid={`text-vault-name-${vault.id}`}>{vault.vaultName}</div>
            <div className="text-xs text-gray-500 font-mono">{shortenAddr(vault.walletAddress)}</div>
          </div>
          <StatusBadge status={vault.status} />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-bold" style={{ color: theme.accent }} data-testid={`text-vault-balance-${vault.id}`}>
              {vault.decoyAmount.toLocaleString()} {vault.decoyTokenType}
            </div>
            <div className="text-xs text-gray-500">{vault.chain} network</div>
          </div>
          <div className="text-right">
            {vault.beaconHits > 0 && (
              <div className="text-xs text-red-400 font-medium" data-testid={`text-beacon-hits-${vault.id}`}>
                {vault.beaconHits} beacon hit{vault.beaconHits !== 1 ? "s" : ""}
              </div>
            )}
            <div className="text-xs text-gray-500">{vault.transferCount} transfer{vault.transferCount !== 1 ? "s" : ""}</div>
          </div>
        </div>
      </div>
      {vault.status === "triggered" && (
        <div className="px-4 py-2 text-xs font-medium text-red-400 border-t" style={{ borderColor: "rgba(239,68,68,0.2)", background: "rgba(239,68,68,0.05)" }}>
          TRIGGERED {vault.triggeredAt ? timeAgo(vault.triggeredAt) : ""} — {vault.discoveredCount} address{vault.discoveredCount !== 1 ? "es" : ""} discovered
        </div>
      )}
    </div>
  );
}

function WalletDetailModal({ vault, onClose }: { vault: Vault; onClose: () => void }) {
  const [sendAddr, setSendAddr] = useState("");
  const [sendAmount, setSendAmount] = useState("");
  const [showSplash, setShowSplash] = useState(true);
  const theme = vault.walletTheme || { primary: "#1a73e8", accent: "#4285f4", bg: "#0d1421" };
  const queryClient = useQueryClient();

  const { data: transfers } = useQuery<Transfer[]>({
    queryKey: ["/api/phantom-vault", vault.id, "transfers"],
    queryFn: () => fetch(`/api/phantom-vault/${vault.id}/transfers`, { credentials: "include" }).then(r => r.json()),
  });

  const sendMutation = useMutation({
    mutationFn: async () => {
      const resp = await fetch(`/api/phantom-vault/${vault.id}/send`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ recipientAddress: sendAddr, amount: sendAmount }),
      });
      if (!resp.ok) throw new Error((await resp.json()).message);
      return resp.json();
    },
    onSuccess: () => {
      setSendAddr("");
      setSendAmount("");
      queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
    },
  });

  useEffect(() => {
    if (vault.walletSplash) {
      const timer = setTimeout(() => setShowSplash(false), 2000);
      return () => clearTimeout(timer);
    } else {
      setShowSplash(false);
    }
  }, [vault.walletSplash]);

  if (showSplash && vault.walletSplash) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80" onClick={onClose}>
        <div className="w-full max-w-sm mx-4 rounded-2xl overflow-hidden animate-pulse" style={{ background: theme.bg }}>
          <img src={vault.walletSplash} alt="Loading wallet..." className="w-full aspect-square object-cover" data-testid="img-wallet-splash" />
          <div className="p-4 text-center">
            <div className="text-sm font-medium" style={{ color: theme.accent }}>Loading Wallet...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl overflow-hidden" style={{ background: `linear-gradient(180deg, ${theme.bg}, #0d1117)`, border: `1px solid ${theme.primary}30` }} onClick={e => e.stopPropagation()}>
        <div className="p-4 flex items-center justify-between" style={{ borderBottom: `1px solid ${theme.primary}20` }}>
          <div className="flex items-center gap-3">
            {vault.walletIcon ? (
              <img src={vault.walletIcon} alt="" className="w-8 h-8 rounded-lg" />
            ) : (
              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold" style={{ background: theme.primary + "30", color: theme.accent }}>
                {vault.decoyTokenType.charAt(0)}
              </div>
            )}
            <div>
              <div className="text-sm font-semibold text-gray-200">{vault.vaultName}</div>
              <div className="text-xs text-gray-500 font-mono">{shortenAddr(vault.walletAddress)}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-300 text-xl" data-testid="button-close-wallet">&times;</button>
        </div>

        <div className="p-6 text-center">
          <div className="text-xs text-gray-500 mb-1">Available Balance</div>
          <div className="text-3xl font-bold mb-1" style={{ color: theme.accent }} data-testid="text-wallet-balance">
            {vault.decoyAmount.toLocaleString()} <span className="text-lg">{vault.decoyTokenType}</span>
          </div>
          <div className="text-xs text-gray-500">{vault.chain} network</div>
          <StatusBadge status={vault.status} />
        </div>

        {vault.status === "armed" && (
          <div className="px-4 pb-4">
            <div className="text-xs text-gray-400 font-medium mb-2">Send {vault.decoyTokenType}</div>
            <input
              data-testid="input-send-address"
              value={sendAddr}
              onChange={e => setSendAddr(e.target.value)}
              className="w-full px-3 py-2 bg-black/30 border rounded text-sm text-gray-200 mb-2 font-mono"
              style={{ borderColor: theme.primary + "40" }}
              placeholder="Recipient address (0x...)"
            />
            <div className="flex gap-2 mb-2">
              <input
                data-testid="input-send-amount"
                value={sendAmount}
                onChange={e => setSendAmount(e.target.value)}
                type="number"
                className="flex-1 px-3 py-2 bg-black/30 border rounded text-sm text-gray-200"
                style={{ borderColor: theme.primary + "40" }}
                placeholder="Amount"
              />
              <button className="px-2 py-1 text-xs rounded" style={{ background: theme.primary + "30", color: theme.accent }} onClick={() => setSendAmount(String(vault.decoyAmount))}>MAX</button>
            </div>
            <button
              data-testid="button-send-tokens"
              onClick={() => sendMutation.mutate()}
              disabled={!sendAddr || !sendAmount || sendMutation.isPending}
              className="w-full py-2.5 rounded-lg text-sm font-medium text-white transition-all disabled:opacity-40"
              style={{ background: `linear-gradient(135deg, ${theme.primary}, ${theme.accent})` }}
            >
              {sendMutation.isPending ? "Sending..." : `Send ${vault.decoyTokenType}`}
            </button>
            {sendMutation.isSuccess && (
              <div className="mt-2 text-xs text-green-400 text-center" data-testid="text-send-success">
                Transfer complete — beacon attached, spider deployed
              </div>
            )}
            {sendMutation.isError && (
              <div className="mt-2 text-xs text-red-400 text-center">{(sendMutation.error as Error).message}</div>
            )}
            <div className="mt-2 text-center">
              <div className="inline-flex items-center gap-1 text-[10px] text-gray-600">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                Steganographic beacon auto-attached to all transfers
              </div>
            </div>
          </div>
        )}

        {transfers && transfers.length > 0 && (
          <div className="px-4 pb-4">
            <div className="text-xs text-gray-400 font-medium mb-2">Recent Transfers</div>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {transfers.map((t, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg bg-black/20 border" style={{ borderColor: theme.primary + "15" }}>
                  <div>
                    <div className="text-xs text-gray-300">{t.amount} {t.token} &rarr; {t.to}</div>
                    <div className="text-[10px] text-gray-600">{timeAgo(t.timestamp)}</div>
                  </div>
                  {t.beaconAttached && (
                    <div className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-900/30 text-cyan-400 border border-cyan-800/30">TRACKED</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {vault.status === "triggered" && (
          <div className="mx-4 mb-4 p-3 rounded-lg bg-red-900/20 border border-red-800/30">
            <div className="text-xs font-medium text-red-400 mb-1">VAULT TRIGGERED</div>
            <div className="text-xs text-gray-400">
              {vault.triggeredByAddress && <>Accessed by: <span className="font-mono text-red-300">{vault.triggeredByAddress}</span><br /></>}
              {vault.discoveredCount > 0 && <>{vault.discoveredCount} related address{vault.discoveredCount !== 1 ? "es" : ""} discovered<br /></>}
              <span className="text-yellow-400/80">Full forensic data requires Data Retrieval Fee or law enforcement subpoena.</span>
            </div>
          </div>
        )}

        <div className="p-4 text-center" style={{ borderTop: `1px solid ${theme.primary}15` }}>
          <div className="text-[10px] text-gray-600">
            Powered by Alpha Phantom Vault Protocol&trade; | Beacon-tracked transfers
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PhantomVaultService() {
  const [, navigate] = useLocation();
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  const [disclaimerAccepted, setDisclaimerAccepted] = useState(false);
  const [billingAnnual, setBillingAnnual] = useState(false);
  const [activeVault, setActiveVault] = useState<Vault | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createForm, setCreateForm] = useState({
    vaultName: "", chain: "ethereum", decoyTokenType: "USDC", decoyAmount: "50000", expirationHours: "24",
  });
  const queryClient = useQueryClient();

  const { data: user } = useQuery<any>({
    queryKey: ["/api/auth/user"],
    queryFn: () => fetch("/api/auth/user", { credentials: "include" }).then(r => r.ok ? r.json() : null),
  });

  const { data: subscription } = useQuery<Subscription | null>({
    queryKey: ["/api/phantom-vault/subscription"],
    queryFn: () => fetch("/api/phantom-vault/subscription", { credentials: "include" }).then(r => r.ok ? r.json() : null),
    enabled: !!user,
  });

  const { data: vaults } = useQuery<Vault[]>({
    queryKey: ["/api/phantom-vault/my-vaults"],
    queryFn: () => fetch("/api/phantom-vault/my-vaults", { credentials: "include" }).then(r => r.ok ? r.json() : []),
    enabled: !!user && !!subscription,
    refetchInterval: 30000,
  });

  const subscribeMutation = useMutation({
    mutationFn: async (plan: string) => {
      const resp = await fetch("/api/phantom-vault/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ plan }),
      });
      if (!resp.ok) throw new Error((await resp.json()).message);
      return resp.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
  });

  async function handleCreate() {
    setCreating(true);
    try {
      const resp = await fetch("/api/phantom-vault/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ ...createForm, disclaimerAccepted }),
      });
      if (!resp.ok) throw new Error((await resp.json()).message);
      await resp.json();
      queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
      setShowCreateForm(false);
      setCreateForm({ vaultName: "", chain: "ethereum", decoyTokenType: "USDC", decoyAmount: "50000", expirationHours: "24" });
      setDisclaimerAccepted(false);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setCreating(false);
    }
  }

  const [activationStatus, setActivationStatus] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("success") === "true") {
      const sessionId = params.get("session_id");
      const plan = params.get("plan") || "monthly";
      if (sessionId) {
        setActivationStatus("Activating your subscription...");
        fetch("/api/phantom-vault/activate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ sessionId, plan }),
        }).then(async r => {
          if (r.ok) {
            setActivationStatus("Subscription activated! You can now create phantom vaults.");
            queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
          } else {
            setActivationStatus("Subscription activated via payment. Refreshing...");
            queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
          }
          setTimeout(() => setActivationStatus(null), 5000);
          window.history.replaceState({}, "", "/alpha-trading/phantom-vault");
        }).catch(() => {
          setActivationStatus("Payment received. Your subscription will activate shortly.");
          queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
          setTimeout(() => setActivationStatus(null), 5000);
          window.history.replaceState({}, "", "/alpha-trading/phantom-vault");
        });
      } else {
        setActivationStatus("Payment successful! Your subscription will activate shortly via webhook.");
        queryClient.invalidateQueries({ queryKey: ["/api/phantom-vault"] });
        setTimeout(() => setActivationStatus(null), 5000);
        window.history.replaceState({}, "", "/alpha-trading/phantom-vault");
      }
    }
    if (params.get("canceled") === "true") {
      setActivationStatus("Checkout canceled. No charges were made.");
      setTimeout(() => setActivationStatus(null), 5000);
      window.history.replaceState({}, "", "/alpha-trading/phantom-vault");
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0e17] text-gray-200">
      {activeVault && <WalletDetailModal vault={activeVault} onClose={() => setActiveVault(null)} />}

      <div className="max-w-6xl mx-auto px-4 py-8">
        {activationStatus && (
          <div className="mb-4 px-4 py-3 bg-cyan-900/20 border border-cyan-700/30 rounded-lg text-cyan-400 text-sm" data-testid="text-activation-status">
            {activationStatus}
          </div>
        )}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" data-testid="text-page-title">
              Phantom Vault Protection&trade;
            </h1>
            <p className="text-sm text-gray-500 mt-1">Decoy wallet security with embedded beacon tracking</p>
          </div>
          <button onClick={() => navigate("/alpha-trading")} className="px-3 py-1.5 text-sm text-gray-400 hover:text-gray-200 border border-gray-700 rounded" data-testid="button-back">
            &larr; Back
          </button>
        </div>

        {!user && (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🛡️</div>
            <h2 className="text-xl font-bold text-gray-200 mb-2">Protect Your Assets with Phantom Vault</h2>
            <p className="text-gray-500 mb-6 max-w-md mx-auto">
              Create decoy wallets with embedded tracking beacons. If someone attempts to steal your crypto, trace their every move.
            </p>
            <a href="/api/login" className="inline-block px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium transition-colors" data-testid="button-login">
              Sign In to Get Started
            </a>
          </div>
        )}

        {user && !subscription && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <div className="text-5xl mb-4">🛡️</div>
              <h2 className="text-xl font-bold text-gray-200 mb-2" data-testid="text-subscribe-heading">Choose Your Protection Plan</h2>
              <p className="text-gray-500 max-w-lg mx-auto">
                Deploy decoy wallets with steganographic beacon tracking. If anyone accesses your vault, every wallet they interact with is automatically traced.
              </p>
              <div className="flex items-center justify-center gap-3 mt-6">
                <span className={`text-sm ${!billingAnnual ? "text-gray-200 font-medium" : "text-gray-500"}`}>Monthly</span>
                <button
                  data-testid="button-billing-toggle"
                  onClick={() => setBillingAnnual(!billingAnnual)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${billingAnnual ? "bg-cyan-600" : "bg-gray-700"}`}
                >
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${billingAnnual ? "translate-x-6" : "translate-x-0.5"}`} />
                </button>
                <span className={`text-sm ${billingAnnual ? "text-gray-200 font-medium" : "text-gray-500"}`}>Annual</span>
                {billingAnnual && <span className="text-xs text-green-400 font-medium">Save 20%</span>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto">
              <div className="rounded-xl border border-gray-700/50 bg-gradient-to-b from-gray-800/20 to-transparent p-6 flex flex-col">
                <div className="text-xs text-cyan-400 font-semibold tracking-wider mb-1">SHIELD</div>
                <div className="text-sm text-gray-400 mb-3">Personal protection</div>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-100" data-testid="text-price-shield">{billingAnnual ? "$39" : "$49"}</span>
                  <span className="text-sm text-gray-500">{billingAnnual ? "/mo billed annually" : "/mo"}</span>
                  {billingAnnual && <div className="text-xs text-gray-600 mt-0.5">$470/year (save $118)</div>}
                </div>
                <ul className="text-sm text-gray-400 space-y-2.5 mb-6 flex-1">
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> 3 phantom vaults</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> AI-generated wallet icons</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> 8 mimic token types</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Beacon tracking</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Self-destruct timer</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Transfer monitoring</li>
                </ul>
                <button
                  data-testid="button-subscribe-shield"
                  onClick={() => subscribeMutation.mutate(billingAnnual ? "shield_annual" : "shield_monthly")}
                  disabled={subscribeMutation.isPending}
                  className="w-full py-2.5 border border-cyan-700/50 hover:bg-cyan-900/30 text-cyan-400 rounded-lg font-medium text-sm transition-colors disabled:opacity-50"
                >
                  {subscribeMutation.isPending ? "Redirecting..." : "Get Shield"}
                </button>
              </div>

              <div className="rounded-xl border-2 border-cyan-500/50 bg-gradient-to-b from-cyan-900/15 to-transparent p-6 relative flex flex-col">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-cyan-500 text-black text-xs font-bold rounded-full">MOST POPULAR</div>
                <div className="text-xs text-cyan-400 font-semibold tracking-wider mb-1">SENTINEL</div>
                <div className="text-sm text-gray-400 mb-3">Serious investors</div>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-100" data-testid="text-price-sentinel">{billingAnnual ? "$99" : "$129"}</span>
                  <span className="text-sm text-gray-500">{billingAnnual ? "/mo billed annually" : "/mo"}</span>
                  {billingAnnual && <div className="text-xs text-gray-600 mt-0.5">$1,190/year (save $358)</div>}
                </div>
                <ul className="text-sm text-gray-400 space-y-2.5 mb-6 flex-1">
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> <strong className="text-gray-200">10 phantom vaults</strong></li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> AI wallet icons + splash screens</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> 8 mimic token types</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Beacon + spider tracing</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Self-destruct timer (1-72h)</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Transfer monitoring</li>
                  <li className="flex items-center gap-2"><span className="text-cyan-400">&#9733;</span> Multi-chain deployment</li>
                  <li className="flex items-center gap-2"><span className="text-cyan-400">&#9733;</span> Priority support</li>
                </ul>
                <button
                  data-testid="button-subscribe-sentinel"
                  onClick={() => subscribeMutation.mutate(billingAnnual ? "sentinel_annual" : "sentinel_monthly")}
                  disabled={subscribeMutation.isPending}
                  className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold text-sm transition-colors disabled:opacity-50"
                >
                  {subscribeMutation.isPending ? "Redirecting..." : "Get Sentinel"}
                </button>
              </div>

              <div className="rounded-xl border border-yellow-600/30 bg-gradient-to-b from-yellow-900/10 to-transparent p-6 flex flex-col">
                <div className="text-xs text-yellow-400 font-semibold tracking-wider mb-1">FORTRESS</div>
                <div className="text-sm text-gray-400 mb-3">Institutions &amp; high net worth</div>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-100" data-testid="text-price-fortress">{billingAnnual ? "$249" : "$299"}</span>
                  <span className="text-sm text-gray-500">{billingAnnual ? "/mo billed annually" : "/mo"}</span>
                  {billingAnnual && <div className="text-xs text-gray-600 mt-0.5">$2,890/year (save $698)</div>}
                </div>
                <ul className="text-sm text-gray-400 space-y-2.5 mb-6 flex-1">
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> <strong className="text-gray-200">25 phantom vaults</strong></li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> AI wallet icons + splash screens</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> 8 mimic token types</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Beacon + spider tracing</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Self-destruct timer (1-72h)</li>
                  <li className="flex items-center gap-2"><span className="text-green-400">&#10003;</span> Transfer monitoring</li>
                  <li className="flex items-center gap-2"><span className="text-yellow-400">&#9733;</span> Multi-chain deployment</li>
                  <li className="flex items-center gap-2"><span className="text-yellow-400">&#9733;</span> Dedicated account manager</li>
                  <li className="flex items-center gap-2"><span className="text-yellow-400">&#9733;</span> Custom vault configurations</li>
                  <li className="flex items-center gap-2"><span className="text-yellow-400">&#9733;</span> 1 free data retrieval/year</li>
                </ul>
                <button
                  data-testid="button-subscribe-fortress"
                  onClick={() => subscribeMutation.mutate(billingAnnual ? "fortress_annual" : "fortress_monthly")}
                  disabled={subscribeMutation.isPending}
                  className="w-full py-2.5 bg-yellow-600 hover:bg-yellow-500 text-black rounded-lg font-bold text-sm transition-colors disabled:opacity-50"
                >
                  {subscribeMutation.isPending ? "Redirecting..." : "Get Fortress"}
                </button>
              </div>
            </div>

            <div className="max-w-4xl mx-auto mt-6 p-4 bg-[#0d1117] border border-gray-800 rounded-lg">
              <div className="text-xs text-gray-400 text-center">
                All plans include steganographic beacon tracking on every transfer, automatic spider tracing on triggered vaults,
                and self-destruct token disintegration. Full forensic investigation data (attacker identification, wallet clustering,
                trace reports) available for $2,500 per vault or via law enforcement subpoena. Fortress annual subscribers receive
                one complimentary data retrieval per year.
              </div>
            </div>

            <div className="text-center text-xs text-gray-600 mt-4">
              Secure payments powered by Stripe. Cancel anytime. All prices in USD.
            </div>
          </div>
        )}

        {user && subscription && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="px-3 py-1 bg-green-900/30 border border-green-700/30 rounded text-green-400 text-xs font-medium" data-testid="text-plan-status">
                  {subscription.plan.toUpperCase()} PLAN ACTIVE
                </div>
                <div className="text-xs text-gray-500" data-testid="text-vault-count">
                  {subscription.vaultsUsed} / {subscription.maxVaults} vaults used
                </div>
              </div>
              <button
                data-testid="button-create-vault"
                onClick={() => { setShowCreateForm(true); setShowDisclaimer(true); }}
                disabled={subscription.vaultsUsed >= subscription.maxVaults}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                + Create Vault
              </button>
            </div>

            {showDisclaimer && !disclaimerAccepted && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
                <div className="w-full max-w-lg bg-[#0d1117] border border-yellow-600/30 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 bg-yellow-900/20 border-b border-yellow-600/20">
                    <div className="text-sm font-bold text-yellow-400">Legal Disclaimer &mdash; Read Before Proceeding</div>
                  </div>
                  <div className="p-4 max-h-80 overflow-y-auto">
                    <pre className="text-xs text-gray-300 whitespace-pre-wrap font-sans leading-relaxed" data-testid="text-disclaimer">{DISCLAIMER_TEXT}</pre>
                  </div>
                  <div className="p-4 flex gap-3 border-t border-gray-800">
                    <button
                      data-testid="button-decline-disclaimer"
                      onClick={() => { setShowDisclaimer(false); setShowCreateForm(false); }}
                      className="flex-1 py-2 border border-gray-700 rounded-lg text-gray-400 text-sm hover:bg-gray-800"
                    >
                      Decline
                    </button>
                    <button
                      data-testid="button-accept-disclaimer"
                      onClick={() => { setDisclaimerAccepted(true); setShowDisclaimer(false); }}
                      className="flex-1 py-2 bg-yellow-600 hover:bg-yellow-500 text-black rounded-lg text-sm font-bold"
                    >
                      I Accept These Terms
                    </button>
                  </div>
                </div>
              </div>
            )}

            {showCreateForm && disclaimerAccepted && (
              <div className="mb-6 p-6 bg-[#0d1117] border border-cyan-800/30 rounded-xl">
                <div className="text-sm font-bold text-gray-200 mb-4">Create New Phantom Vault</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Vault Name</label>
                    <input
                      data-testid="input-create-name"
                      value={createForm.vaultName}
                      onChange={e => setCreateForm(f => ({ ...f, vaultName: e.target.value }))}
                      className="w-full px-3 py-2 bg-black/30 border border-gray-700 rounded text-sm text-gray-200"
                      placeholder="e.g. My Savings Vault"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Blockchain Network</label>
                    <select
                      data-testid="select-create-chain"
                      value={createForm.chain}
                      onChange={e => setCreateForm(f => ({ ...f, chain: e.target.value }))}
                      className="w-full px-3 py-2 bg-black/30 border border-gray-700 rounded text-sm text-gray-200"
                    >
                      {CHAINS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Mimic Token Type</label>
                    <div className="grid grid-cols-4 gap-2">
                      {TOKEN_TYPES.map(t => (
                        <button
                          key={t.value}
                          data-testid={`button-token-${t.value}`}
                          onClick={() => setCreateForm(f => ({ ...f, decoyTokenType: t.value }))}
                          className={`px-2 py-2 rounded border text-xs text-center transition-colors ${
                            createForm.decoyTokenType === t.value
                              ? "border-cyan-500 bg-cyan-900/30 text-cyan-400"
                              : "border-gray-700 bg-black/20 text-gray-400 hover:border-gray-600"
                          }`}
                        >
                          <div className="text-lg mb-0.5">{t.icon}</div>
                          {t.value}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Decoy Amount</label>
                      <input
                        data-testid="input-create-amount"
                        type="number"
                        value={createForm.decoyAmount}
                        onChange={e => setCreateForm(f => ({ ...f, decoyAmount: e.target.value }))}
                        className="w-full px-3 py-2 bg-black/30 border border-gray-700 rounded text-sm text-gray-200"
                        placeholder="e.g. 50000"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Self-Destruct Timer (hours after trigger)</label>
                      <select
                        data-testid="select-create-expiry"
                        value={createForm.expirationHours}
                        onChange={e => setCreateForm(f => ({ ...f, expirationHours: e.target.value }))}
                        className="w-full px-3 py-2 bg-black/30 border border-gray-700 rounded text-sm text-gray-200"
                      >
                        <option value="1">1 hour</option>
                        <option value="6">6 hours</option>
                        <option value="12">12 hours</option>
                        <option value="24">24 hours</option>
                        <option value="48">48 hours</option>
                        <option value="72">72 hours</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    data-testid="button-cancel-create"
                    onClick={() => { setShowCreateForm(false); setDisclaimerAccepted(false); }}
                    className="px-4 py-2 border border-gray-700 rounded-lg text-gray-400 text-sm hover:bg-gray-800"
                  >
                    Cancel
                  </button>
                  <button
                    data-testid="button-deploy-vault"
                    onClick={handleCreate}
                    disabled={!createForm.vaultName || creating}
                    className="px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg text-sm font-medium disabled:opacity-40 flex items-center gap-2"
                  >
                    {creating ? (
                      <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Deploying &amp; Generating Icons...</>
                    ) : (
                      "Deploy Phantom Vault"
                    )}
                  </button>
                </div>
              </div>
            )}

            {vaults && vaults.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {vaults.map(v => (
                  <WalletCard key={v.id} vault={v} onOpen={() => setActiveVault(v)} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 border border-dashed border-gray-800 rounded-xl">
                <div className="text-4xl mb-3">🔒</div>
                <div className="text-gray-400 text-sm">No phantom vaults yet</div>
                <div className="text-gray-600 text-xs mt-1">Create your first vault to start protecting your assets</div>
              </div>
            )}

            <div className="mt-8 p-4 bg-yellow-900/10 border border-yellow-800/20 rounded-lg">
              <div className="text-xs font-medium text-yellow-400 mb-1">Data Retrieval Notice</div>
              <div className="text-xs text-gray-500">
                Your subscription includes vault creation, transfer activity monitoring, and beacon hit counts.
                Full forensic investigation data (attacker identification, wallet clustering, trace reports) requires a
                Data Retrieval Fee of $2,500 per vault or valid law enforcement legal process (subpoena/court order).
                Contact <span className="text-cyan-400">forensics@alphaunlimitedtrading.com</span> for data requests.
              </div>
            </div>
          </div>
        )}

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 bg-[#0d1117] border border-gray-800 rounded-xl">
            <div className="text-2xl mb-2">🎭</div>
            <div className="text-sm font-medium text-gray-200 mb-1">Undetectable Mimic Tokens</div>
            <div className="text-xs text-gray-500">
              Decoy tokens replicate the exact ABI, metadata, and explorer appearance of real tokens.
              Indistinguishable from genuine assets on block explorers.
            </div>
          </div>
          <div className="p-5 bg-[#0d1117] border border-gray-800 rounded-xl">
            <div className="text-2xl mb-2">📡</div>
            <div className="text-sm font-medium text-gray-200 mb-1">Steganographic Beacon Tracking</div>
            <div className="text-xs text-gray-500">
              Every transfer embeds HMAC-SHA512 signed beacons that silently trace every wallet
              that touches the decoy tokens. Recursive spider tracing maps the full network.
            </div>
          </div>
          <div className="p-5 bg-[#0d1117] border border-gray-800 rounded-xl">
            <div className="text-2xl mb-2">💣</div>
            <div className="text-sm font-medium text-gray-200 mb-1">Self-Destruct Failsafe</div>
            <div className="text-xs text-gray-500">
              After the configured timer expires, mimic tokens automatically disintegrate.
              The attacker is left with nothing while all their wallets have been mapped.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
