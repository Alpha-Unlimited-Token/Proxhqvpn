/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Intelligence Engine™ — Forensic Recovery Command Center
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements the proprietary Forensic Recovery Command Center including real-time
 * wallet monitoring dashboards, automated alert systems, Spider Trace visualization,
 * Phantom Vault Protocol management, Customer Vault Oversight, Exchange Freeze Request
 * System, and Cross-Case Intelligence Engine.
 *
 * Technologies Protected:
 * - Alpha Forensic Intelligence Engine™
 * - Forensic Recovery Command Center™
 * - Autonomous Spider Trace™ Visualization
 * - Alpha Phantom Vault Protocol™ Admin Controls
 * - Customer Vault Oversight System™
 * - Exchange Freeze Request System™
 * - Cross-Case Intelligence Engine™
 * - Multi-Chain Forensic Dashboard™
 * - Real-Time Wallet Balance Monitor™
 * - Forensic Alert Classification Pipeline™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: FORENSIC_ENGINE_v2.1_PROTECTED
 * AUT_ModuleHash: AUT_b0a84a08ad8bbb20f916ebed
 */

import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { apiRequest } from "@/lib/queryClient";
import FundFlowGraph from "@/components/trading-platform/FundFlowGraph";
import TransactionFlowGraph, { type TxFlowNode, type TxFlowEdge } from "@/components/trading-platform/TransactionFlowGraph";
import RecoveryDossier from "@/components/trading-platform/RecoveryDossier";
import EntityDashboard from "@/components/trading-platform/EntityDashboard";
import {
  DashboardCharts, WalletCharts, AlertCharts, OsintCharts, OriginIntelCharts,
  SpiderTraceCharts, FreezeRequestCharts, PhantomVaultCharts, LaunderingRiskCharts,
  NetworkIntelCharts, BountyCharts, CrossCaseCharts, TraceResultCharts,
} from "@/components/trading-platform/ForensicCharts";

const _forensicEngineIntegritySeal = 'AUT_b0a84a08ad8bbb20f916ebed';
const _fieAntiTamperCheck = (): boolean => {
  if (typeof window === 'undefined') return true;
  const hostname = window.location.hostname;
  const authorized = hostname.includes('.replit.') || hostname.includes('replit.dev') || hostname.includes('repl.co') ||
    hostname.includes('alphaunlimitedtrading') || hostname.includes('alphaunlimitedtoken') || hostname === 'localhost';
  if (!authorized) {
    console.error('[FATAL] Alpha Forensic Intelligence Engine™ — UNAUTHORIZED DEPLOYMENT DETECTED at ' + hostname + '. This proprietary technology is protected by international copyright and trade secret laws. All access is logged. Legal action will be pursued.');
    try {
      const beacon = new Image();
      beacon.src = `https://alphaunlimitedtrading.com/api/security/beacon-violation?m=ForensicEngine&s=${_forensicEngineIntegritySeal}&h=${encodeURIComponent(hostname)}&t=${Date.now()}`;
    } catch {}
    try { fetch('/api/security/beacon-violation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ module: 'ForensicIntelligenceEngine', seal: _forensicEngineIntegritySeal, host: hostname, url: window.location.href, timestamp: Date.now(), userAgent: navigator.userAgent }) }).catch(() => {}); } catch {}
  }
  return authorized;
};
if (typeof window !== 'undefined') { _fieAntiTamperCheck(); }

const CHAIN_EXPLORERS: Record<string, { address: string; tx: string; name: string; symbol: string }> = {
  ethereum: { address: "https://etherscan.io/address/", tx: "https://etherscan.io/tx/", name: "Ethereum", symbol: "ETH" },
  bitcoin: { address: "https://blockchair.com/bitcoin/address/", tx: "https://blockchair.com/bitcoin/transaction/", name: "Bitcoin", symbol: "BTC" },
  bsc: { address: "https://bscscan.com/address/", tx: "https://bscscan.com/tx/", name: "BSC", symbol: "BNB" },
  polygon: { address: "https://polygonscan.com/address/", tx: "https://polygonscan.com/tx/", name: "Polygon", symbol: "MATIC" },
  solana: { address: "https://solscan.io/account/", tx: "https://solscan.io/tx/", name: "Solana", symbol: "SOL" },
  tron: { address: "https://tronscan.org/#/address/", tx: "https://tronscan.org/#/transaction/", name: "TRON", symbol: "TRX" },
  arbitrum: { address: "https://arbiscan.io/address/", tx: "https://arbiscan.io/tx/", name: "Arbitrum", symbol: "ETH" },
  optimism: { address: "https://optimistic.etherscan.io/address/", tx: "https://optimistic.etherscan.io/tx/", name: "Optimism", symbol: "ETH" },
  base: { address: "https://basescan.org/address/", tx: "https://basescan.org/tx/", name: "Base", symbol: "ETH" },
  avalanche: { address: "https://snowtrace.io/address/", tx: "https://snowtrace.io/tx/", name: "Avalanche", symbol: "AVAX" },
  fantom: { address: "https://ftmscan.com/address/", tx: "https://ftmscan.com/tx/", name: "Fantom", symbol: "FTM" },
  cronos: { address: "https://cronoscan.com/address/", tx: "https://cronoscan.com/tx/", name: "Cronos", symbol: "CRO" },
  gnosis: { address: "https://gnosisscan.io/address/", tx: "https://gnosisscan.io/tx/", name: "Gnosis", symbol: "xDAI" },
  linea: { address: "https://lineascan.build/address/", tx: "https://lineascan.build/tx/", name: "Linea", symbol: "ETH" },
  scroll: { address: "https://scrollscan.com/address/", tx: "https://scrollscan.com/tx/", name: "Scroll", symbol: "ETH" },
  zksync: { address: "https://explorer.zksync.io/address/", tx: "https://explorer.zksync.io/tx/", name: "zkSync Era", symbol: "ETH" },
  blast: { address: "https://blastscan.io/address/", tx: "https://blastscan.io/tx/", name: "Blast", symbol: "ETH" },
  mantle: { address: "https://mantlescan.xyz/address/", tx: "https://mantlescan.xyz/tx/", name: "Mantle", symbol: "MNT" },
  celo: { address: "https://celoscan.io/address/", tx: "https://celoscan.io/tx/", name: "Celo", symbol: "CELO" },
  moonbeam: { address: "https://moonscan.io/address/", tx: "https://moonscan.io/tx/", name: "Moonbeam", symbol: "GLMR" },
};

function explorerLink(chain: string, type: "address" | "tx", value: string): string {
  const explorer = CHAIN_EXPLORERS[chain] || CHAIN_EXPLORERS.ethereum;
  return type === "address" ? `${explorer.address}${value}` : `${explorer.tx}${value}`;
}

function chainSymbol(chain: string): string {
  return CHAIN_EXPLORERS[chain]?.symbol || "ETH";
}

const EVM_CHAIN_OPTIONS = [
  { value: "ethereum", label: "Ethereum" },
  { value: "arbitrum", label: "Arbitrum" },
  { value: "optimism", label: "Optimism" },
  { value: "base", label: "Base" },
  { value: "polygon", label: "Polygon" },
  { value: "bsc", label: "BSC" },
  { value: "avalanche", label: "Avalanche" },
  { value: "fantom", label: "Fantom" },
  { value: "gnosis", label: "Gnosis" },
  { value: "linea", label: "Linea" },
  { value: "scroll", label: "Scroll" },
  { value: "zksync", label: "zkSync Era" },
  { value: "blast", label: "Blast" },
  { value: "mantle", label: "Mantle" },
  { value: "cronos", label: "Cronos" },
  { value: "celo", label: "Celo" },
  { value: "moonbeam", label: "Moonbeam" },
];

const ALL_CHAIN_OPTIONS = [
  ...EVM_CHAIN_OPTIONS,
  { value: "bitcoin", label: "Bitcoin" },
  { value: "solana", label: "Solana" },
  { value: "tron", label: "TRON" },
];

function detectChainFromAddress(addr: string): string {
  if (!addr) return "ethereum";
  const a = addr.trim();
  if (a.startsWith("bc1") || a.startsWith("1") || a.startsWith("3")) return "bitcoin";
  if (a.startsWith("T") && a.length >= 34) return "tron";
  if ((a.length >= 32 && a.length <= 44) && !a.startsWith("0x") && !a.startsWith("T")) return "solana";
  return "ethereum";
}

interface ForensicCase {
  id: string;
  caseName: string;
  victimAddress: string | null;
  victimHandle: string | null;
  description: string | null;
  status: string;
  totalStolenUsd: number | null;
  totalRecoveredUsd: number | null;
  chains: string[] | null;
  createdAt: string;
}

interface MonitoredWallet {
  id: string;
  caseId: string;
  address: string;
  chain: string;
  role: string | null;
  label: string | null;
  lastKnownBalanceEth: number | null;
  lastKnownBalanceUsd: number | null;
  lastKnownTokens: Record<string, number> | null;
  lastChecked: string | null;
  lastActivity: string | null;
  status: string;
}

interface ForensicAlert {
  id: string;
  caseId: string;
  walletId: string | null;
  alertType: string;
  message: string;
  details: any;
  severity: string;
  acknowledged: boolean;
  createdAt: string;
}

interface MonitorStats {
  totalCases: number;
  activeCases: number;
  totalWallets: number;
  activeMonitoring: number;
  totalAlerts: number;
  unacknowledgedAlerts: number;
  criticalAlerts: number;
  totalValueTracked: number;
  lastCheck: string | null;
}

function formatLargeValue(val: number): string {
  if (!val || !isFinite(val)) return "$0.00";
  if (val > 1e15) val = val / 1e18;
  if (val >= 1e9) return "$" + (val / 1e9).toFixed(2) + "B";
  if (val >= 1e6) return "$" + (val / 1e6).toFixed(2) + "M";
  if (val >= 1e3) return "$" + val.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return "$" + val.toFixed(2);
}

function formatTokenBalance(val: number): string {
  if (!val || !isFinite(val)) return "0";
  if (val > 1e15) val = val / 1e18;
  if (val >= 1e9) return (val / 1e9).toFixed(2) + "B";
  if (val >= 1e6) return (val / 1e6).toFixed(2) + "M";
  return val.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

function formatUsd(val: number | null | undefined): string {
  if (!val) return "$0.00";
  return "$" + val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatEth(val: number | null | undefined): string {
  if (!val) return "0.000000";
  return val.toFixed(6);
}

function shortenAddr(addr: string): string {
  if (!addr || addr.length < 12) return addr;
  return addr.slice(0, 8) + "..." + addr.slice(-6);
}

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function SeverityBadge({ severity }: { severity: string }) {
  const colors: Record<string, string> = {
    critical: "bg-red-600 text-white",
    high: "bg-orange-500 text-white",
    medium: "bg-yellow-500 text-black",
    low: "bg-blue-500 text-white",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-bold ${colors[severity] || colors.low}`}>
      {severity.toUpperCase()}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    monitoring: "bg-green-600/20 text-green-400 border border-green-600/30",
    active: "bg-green-600/20 text-green-400 border border-green-600/30",
    paused: "bg-yellow-600/20 text-yellow-400 border border-yellow-600/30",
    closed: "bg-gray-600/20 text-gray-400 border border-gray-600/30",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-medium ${colors[status] || colors.active}`}>
      {status}
    </span>
  );
}

function TraceResultCard({ result, address, label }: { result: any; address?: string; label?: string }) {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [txPage, setTxPage] = useState(1);
  const [connPage, setConnPage] = useState(1);
  const txPerPage = 10;
  const connPerPage = 10;

  if (result.error) {
    return (
      <div className="bg-[#161b22] rounded-xl border border-red-800/50 p-4">
        <div className="flex items-center gap-2 mb-1">
          {address && <span className="font-mono text-cyan-400 text-xs">{address.slice(0, 10)}...{address.slice(-6)}</span>}
          {label && <span className="text-gray-500 text-xs">{label}</span>}
        </div>
        <div className="text-red-400 text-sm">{result.error}</div>
      </div>
    );
  }

  const sevColors: Record<string, string> = {
    critical: "bg-red-600 text-white",
    high: "bg-orange-500 text-white",
    medium: "bg-yellow-500 text-black",
    low: "bg-blue-500 text-white",
  };

  const dirColors: Record<string, string> = {
    incoming: "text-green-400",
    outgoing: "text-red-400",
    self: "text-gray-400",
  };
  const dirIcons: Record<string, string> = {
    incoming: "↓ IN",
    outgoing: "↑ OUT",
    self: "↻ SELF",
  };
  const relColors: Record<string, string> = {
    sent_to: "text-red-400",
    received_from: "text-green-400",
    bidirectional: "text-yellow-400",
  };
  const relLabels: Record<string, string> = {
    sent_to: "→ Sent To",
    received_from: "← Received From",
    bidirectional: "↔ Bidirectional",
  };

  const transactions = result.transactions || [];
  const connectedAddresses = result.connectedAddresses || [];
  const riskIndicators = result.riskIndicators || [];
  const txTotalPages = Math.max(1, Math.ceil(transactions.length / txPerPage));
  const connTotalPages = Math.max(1, Math.ceil(connectedAddresses.length / connPerPage));
  const pagedTxs = transactions.slice((txPage - 1) * txPerPage, txPage * txPerPage);
  const pagedConns = connectedAddresses.slice((connPage - 1) * connPerPage, connPage * connPerPage);

  const toggle = (s: string) => setExpandedSection(expandedSection === s ? null : s);

  const incomingCount = transactions.filter((t: any) => t.direction === "incoming").length;
  const outgoingCount = transactions.filter((t: any) => t.direction === "outgoing").length;

  return (
    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden">
      <div className="p-4 border-b border-gray-800/50">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <span className="font-mono text-cyan-400 text-sm">{result.address || address}</span>
          {label && <span className="text-gray-500 text-xs bg-gray-800 px-2 py-0.5 rounded">{label}</span>}
          {result.chainName && <span className="text-xs px-2 py-0.5 bg-cyan-900/30 border border-cyan-700/30 rounded text-cyan-400">{result.chainName}</span>}
          {result.chain && !result.chainName && <span className="text-xs px-2 py-0.5 bg-cyan-900/30 border border-cyan-700/30 rounded text-cyan-400">{result.chain}</span>}
          <button
            data-testid="button-copy-trace-addr"
            onClick={() => navigator.clipboard.writeText(result.address || address || "")}
            className="text-[10px] text-cyan-600 hover:text-cyan-400 ml-1"
          >
            Copy
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#0d1117] rounded-lg p-3">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Balance</div>
            <div className="text-sm font-bold text-gray-200">{result.balance || "0"}</div>
            {result.balanceUSD && <div className="text-xs text-green-400">${result.balanceUSD}</div>}
          </div>
          <div className="bg-[#0d1117] rounded-lg p-3">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Transactions</div>
            <div className="text-sm font-bold text-gray-200">{result.transactionCount ?? transactions.length}</div>
            <div className="text-[10px] text-gray-500">{incomingCount} in / {outgoingCount} out</div>
          </div>
          <div className="bg-[#0d1117] rounded-lg p-3">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Total Received</div>
            <div className="text-sm font-bold text-green-400">{result.totalReceived || "—"}</div>
          </div>
          <div className="bg-[#0d1117] rounded-lg p-3">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Total Sent</div>
            <div className="text-sm font-bold text-red-400">{result.totalSent || "—"}</div>
          </div>
        </div>

        {(result.firstSeen || result.lastSeen) && (
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            {result.firstSeen && <div>First Active: <span className="text-gray-300">{new Date(result.firstSeen).toLocaleDateString()}</span></div>}
            {result.lastSeen && <div>Last Active: <span className="text-gray-300">{new Date(result.lastSeen).toLocaleDateString()}</span></div>}
          </div>
        )}
      </div>

      {riskIndicators.length > 0 && (
        <div className="p-4 border-b border-gray-800/50">
          <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Risk Indicators ({riskIndicators.length})</div>
          <div className="flex flex-wrap gap-2">
            {riskIndicators.map((ri: any, i: number) => (
              <div key={i} className="flex items-center gap-1.5 bg-[#0d1117] rounded-lg px-3 py-2 border border-gray-800/50">
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${sevColors[ri.severity] || sevColors.low}`}>
                  {(ri.severity || "low").toUpperCase()}
                </span>
                <span className="text-xs text-gray-300 font-medium">{(ri.type || "unknown").replace(/_/g, " ")}</span>
                {ri.description && <span className="text-[10px] text-gray-500 ml-1">— {ri.description}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {transactions.length > 0 && (
        <div className="border-b border-gray-800/50">
          <button
            data-testid="toggle-trace-transactions"
            onClick={() => toggle("transactions")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/30 transition-colors"
          >
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
              Transactions ({transactions.length})
            </span>
            <span className="text-gray-500 text-xs">{expandedSection === "transactions" ? "▲ Collapse" : "▼ Expand"}</span>
          </button>
          {expandedSection === "transactions" && (
            <div className="px-4 pb-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs" data-testid="table-trace-transactions">
                  <thead>
                    <tr className="border-b border-gray-800/50 text-gray-500">
                      <th className="px-2 py-2 text-left">Direction</th>
                      <th className="px-2 py-2 text-left">Tx Hash</th>
                      <th className="px-2 py-2 text-left">From</th>
                      <th className="px-2 py-2 text-left">To</th>
                      <th className="px-2 py-2 text-right">Value</th>
                      <th className="px-2 py-2 text-right">USD</th>
                      <th className="px-2 py-2 text-left">Token</th>
                      <th className="px-2 py-2 text-left">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagedTxs.map((tx: any, i: number) => (
                      <tr key={tx.hash || i} className="border-b border-gray-800/30 hover:bg-gray-800/20">
                        <td className={`px-2 py-2 font-bold text-[10px] ${dirColors[tx.direction] || "text-gray-400"}`}>
                          {dirIcons[tx.direction] || tx.direction}
                        </td>
                        <td className="px-2 py-2 font-mono text-cyan-500">
                          {tx.hash ? `${tx.hash.slice(0, 8)}...${tx.hash.slice(-6)}` : "—"}
                        </td>
                        <td className="px-2 py-2 font-mono text-gray-400">
                          {tx.from ? `${tx.from.slice(0, 6)}...${tx.from.slice(-4)}` : "—"}
                        </td>
                        <td className="px-2 py-2 font-mono text-gray-400">
                          {tx.to ? `${tx.to.slice(0, 6)}...${tx.to.slice(-4)}` : "—"}
                        </td>
                        <td className="px-2 py-2 text-right text-gray-200">{tx.value || "0"}</td>
                        <td className="px-2 py-2 text-right text-green-400">{tx.valueUSD ? `$${tx.valueUSD}` : "—"}</td>
                        <td className="px-2 py-2">
                          {tx.tokenTransfer && tx.tokenSymbol ? (
                            <span className="px-1.5 py-0.5 bg-purple-900/30 border border-purple-600/30 rounded text-purple-400 text-[10px]">
                              {tx.tokenAmount ? `${tx.tokenAmount} ` : ""}{tx.tokenSymbol}
                            </span>
                          ) : "—"}
                        </td>
                        <td className="px-2 py-2 text-gray-500">{tx.timestamp ? new Date(tx.timestamp).toLocaleDateString() : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {txTotalPages > 1 && (
                <div className="flex items-center justify-between mt-3">
                  <span className="text-[10px] text-gray-500">
                    {(txPage - 1) * txPerPage + 1}–{Math.min(txPage * txPerPage, transactions.length)} of {transactions.length}
                  </span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setTxPage(Math.max(1, txPage - 1))} disabled={txPage <= 1} className="px-2 py-1 rounded text-[10px] bg-gray-800 text-gray-400 hover:bg-gray-700 disabled:opacity-30">← Prev</button>
                    <span className="text-[10px] text-gray-500 mx-1">Page {txPage} of {txTotalPages}</span>
                    <button onClick={() => setTxPage(Math.min(txTotalPages, txPage + 1))} disabled={txPage >= txTotalPages} className="px-2 py-1 rounded text-[10px] bg-gray-800 text-gray-400 hover:bg-gray-700 disabled:opacity-30">Next →</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {connectedAddresses.length > 0 && (
        <div className="border-b border-gray-800/50">
          <button
            data-testid="toggle-trace-connected"
            onClick={() => toggle("connected")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/30 transition-colors"
          >
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
              Connected Addresses ({connectedAddresses.length})
            </span>
            <span className="text-gray-500 text-xs">{expandedSection === "connected" ? "▲ Collapse" : "▼ Expand"}</span>
          </button>
          {expandedSection === "connected" && (
            <div className="px-4 pb-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs" data-testid="table-trace-connected">
                  <thead>
                    <tr className="border-b border-gray-800/50 text-gray-500">
                      <th className="px-2 py-2 text-left">Relationship</th>
                      <th className="px-2 py-2 text-left">Address</th>
                      <th className="px-2 py-2 text-right">Total Value</th>
                      <th className="px-2 py-2 text-right">Tx Count</th>
                      <th className="px-2 py-2 text-left">First Interaction</th>
                      <th className="px-2 py-2 text-left">Last Interaction</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagedConns.map((conn: any, i: number) => (
                      <tr key={conn.address || i} className="border-b border-gray-800/30 hover:bg-gray-800/20">
                        <td className={`px-2 py-2 font-bold text-[10px] ${relColors[conn.relationship] || "text-gray-400"}`}>
                          {relLabels[conn.relationship] || conn.relationship}
                        </td>
                        <td className="px-2 py-2 font-mono text-cyan-500">
                          {conn.address ? `${conn.address.slice(0, 10)}...${conn.address.slice(-6)}` : "—"}
                        </td>
                        <td className="px-2 py-2 text-right text-gray-200">{conn.totalValue || "0"}</td>
                        <td className="px-2 py-2 text-right text-gray-300">{conn.transactionCount ?? "—"}</td>
                        <td className="px-2 py-2 text-gray-500">{conn.firstInteraction ? new Date(conn.firstInteraction).toLocaleDateString() : "—"}</td>
                        <td className="px-2 py-2 text-gray-500">{conn.lastInteraction ? new Date(conn.lastInteraction).toLocaleDateString() : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {connTotalPages > 1 && (
                <div className="flex items-center justify-between mt-3">
                  <span className="text-[10px] text-gray-500">
                    {(connPage - 1) * connPerPage + 1}–{Math.min(connPage * connPerPage, connectedAddresses.length)} of {connectedAddresses.length}
                  </span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setConnPage(Math.max(1, connPage - 1))} disabled={connPage <= 1} className="px-2 py-1 rounded text-[10px] bg-gray-800 text-gray-400 hover:bg-gray-700 disabled:opacity-30">← Prev</button>
                    <span className="text-[10px] text-gray-500 mx-1">Page {connPage} of {connTotalPages}</span>
                    <button onClick={() => setConnPage(Math.min(connTotalPages, connPage + 1))} disabled={connPage >= connTotalPages} className="px-2 py-1 rounded text-[10px] bg-gray-800 text-gray-400 hover:bg-gray-700 disabled:opacity-30">Next →</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      <div>
        <button
          data-testid="toggle-trace-raw"
          onClick={() => toggle("raw")}
          className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/30 transition-colors"
        >
          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Raw JSON Data</span>
          <span className="text-gray-500 text-xs">{expandedSection === "raw" ? "▲ Collapse" : "▼ Expand"}</span>
        </button>
        {expandedSection === "raw" && (
          <div className="px-4 pb-4">
            <pre className="p-3 bg-[#0d1117] rounded-lg text-xs font-mono text-gray-400 max-h-[400px] overflow-y-auto whitespace-pre-wrap">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

function IntelligenceSuiteTab({ selectedCase, wallets }: { selectedCase: string | null; wallets: any[] | undefined }) {
  const [intelMode, setIntelMode] = useState<"lookup" | "risk" | "cluster" | "bridge" | "peel">("lookup");
  const [lookupAddr, setLookupAddr] = useState("");
  const [lookupChain, setLookupChain] = useState("ethereum");
  const [lookupResult, setLookupResult] = useState<any>(null);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [riskAddr, setRiskAddr] = useState("");
  const [riskChain, setRiskChain] = useState("ethereum");
  const [riskResult, setRiskResult] = useState<any>(null);
  const [riskLoading, setRiskLoading] = useState(false);
  const [clusterAddr, setClusterAddr] = useState("");
  const [clusterChain, setClusterChain] = useState("ethereum");
  const [clusterResult, setClusterResult] = useState<any>(null);
  const [clusterLoading, setClusterLoading] = useState(false);
  const [bridgeAddr, setBridgeAddr] = useState("");
  const [bridgeChain, setBridgeChain] = useState("ethereum");
  const [bridgeResult, setBridgeResult] = useState<any>(null);
  const [bridgeLoading, setBridgeLoading] = useState(false);
  const [peelAddr, setPeelAddr] = useState("");
  const [peelChain, setPeelChain] = useState("ethereum");
  const [peelResult, setPeelResult] = useState<any>(null);
  const [peelLoading, setPeelLoading] = useState(false);
  const [labelStats, setLabelStats] = useState<any>(null);
  const [batchRiskResults, setBatchRiskResults] = useState<any[]>([]);
  const [batchRiskLoading, setBatchRiskLoading] = useState(false);

  useEffect(() => {
    fetch("/api/forensic/intelligence/label-stats", { credentials: "include" })
      .then(r => r.json()).then(setLabelStats).catch(() => {});
  }, []);

  const safeFetch = async (url: string, opts?: RequestInit) => {
    const r = await fetch(url, { credentials: "include", ...opts });
    if (!r.ok) {
      const errBody = await r.json().catch(() => ({ message: `HTTP ${r.status}` }));
      throw new Error(errBody.message || `Request failed (${r.status})`);
    }
    return r.json();
  };

  const doLookup = async () => {
    if (!lookupAddr) return;
    setLookupLoading(true);
    try {
      setLookupResult(await safeFetch(`/api/forensic/intelligence/label-lookup?address=${encodeURIComponent(lookupAddr)}&chain=${lookupChain}`));
    } catch (e: any) { setLookupResult({ error: e.message }); }
    setLookupLoading(false);
  };

  const doRisk = async () => {
    if (!riskAddr) return;
    setRiskLoading(true);
    try {
      setRiskResult(await safeFetch("/api/forensic/intelligence/risk-score", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ address: riskAddr, chain: riskChain }) }));
    } catch (e: any) { setRiskResult({ error: e.message }); }
    setRiskLoading(false);
  };

  const doBatchRisk = async () => {
    if (!wallets?.length) return;
    setBatchRiskLoading(true);
    try {
      const addrs = wallets.slice(0, 20).map((w: any) => w.address);
      const data = await safeFetch("/api/forensic/intelligence/risk-score-batch", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ addresses: addrs, chain: "ethereum" }) });
      setBatchRiskResults(data.results || []);
    } catch { setBatchRiskResults([]); }
    setBatchRiskLoading(false);
  };

  const doCluster = async () => {
    if (!clusterAddr) return;
    setClusterLoading(true);
    try {
      setClusterResult(await safeFetch("/api/forensic/intelligence/cluster", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ address: clusterAddr, chain: clusterChain }) }));
    } catch (e: any) { setClusterResult({ error: e.message }); }
    setClusterLoading(false);
  };

  const doBridge = async () => {
    if (!bridgeAddr) return;
    setBridgeLoading(true);
    try {
      setBridgeResult(await safeFetch("/api/forensic/intelligence/bridge-trace", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ address: bridgeAddr, chain: bridgeChain }) }));
    } catch (e: any) { setBridgeResult({ error: e.message }); }
    setBridgeLoading(false);
  };

  const doPeel = async () => {
    if (!peelAddr) return;
    setPeelLoading(true);
    try {
      setPeelResult(await safeFetch("/api/forensic/intelligence/peel-chain", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ address: peelAddr, chain: peelChain }) }));
    } catch (e: any) { setPeelResult({ error: e.message }); }
    setPeelLoading(false);
  };

  const chains = ["ethereum", "arbitrum", "optimism", "base", "polygon", "gnosis", "bsc"];
  const modes = [
    { id: "lookup" as const, label: "Address Lookup", color: "cyan" },
    { id: "risk" as const, label: "Risk Scoring", color: "red" },
    { id: "cluster" as const, label: "Cluster Analysis", color: "purple" },
    { id: "bridge" as const, label: "Bridge Tracer", color: "orange" },
    { id: "peel" as const, label: "Peel Chain", color: "green" },
  ];

  const riskColor = (score: number) => score >= 75 ? "text-red-400" : score >= 50 ? "text-orange-400" : score >= 25 ? "text-yellow-400" : "text-green-400";
  const riskBg = (score: number) => score >= 75 ? "bg-red-500" : score >= 50 ? "bg-orange-500" : score >= 25 ? "bg-yellow-500" : "bg-green-500";

  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400" data-testid="text-intelligence-title">
          Alpha Intelligence Suite&trade;
        </h2>
        {labelStats && (
          <span className="text-xs text-gray-500 bg-[#161b22] px-2 py-1 rounded" data-testid="text-label-db-stats">
            {labelStats.total || 0} labeled addresses | {(labelStats.exchanges || 0) + (labelStats.dex || 0) + (labelStats.bridges || 0) + (labelStats.mixers || 0) + (labelStats.sanctioned || 0)} categorized
          </span>
        )}
      </div>

      <div className="flex gap-2 mb-4 flex-wrap">
        {modes.map(m => (
          <button
            key={m.id}
            data-testid={`button-intel-mode-${m.id}`}
            onClick={() => setIntelMode(m.id)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              intelMode === m.id
                ? `bg-${m.color}-600/20 border border-${m.color}-500/50 text-${m.color}-400`
                : "bg-[#161b22] border border-gray-800 text-gray-400 hover:border-gray-600"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {intelMode === "lookup" && (
        <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-5" data-testid="section-address-lookup">
          <h3 className="text-sm font-bold text-cyan-400 mb-3">ADDRESS LABEL LOOKUP</h3>
          <p className="text-xs text-gray-500 mb-3">Look up any blockchain address against our database of known exchanges, DeFi protocols, bridges, sanctioned entities, and scam addresses.</p>
          <div className="flex gap-2 mb-3">
            <input
              data-testid="input-lookup-address"
              value={lookupAddr}
              onChange={e => setLookupAddr(e.target.value)}
              placeholder="0x... wallet address"
              className="flex-1 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-cyan-500 outline-none font-mono"
            />
            <select data-testid="select-lookup-chain" value={lookupChain} onChange={e => setLookupChain(e.target.value)} className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300">
              {chains.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button data-testid="button-lookup-submit" onClick={doLookup} disabled={lookupLoading || !lookupAddr} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 text-white rounded text-sm font-medium">
              {lookupLoading ? "..." : "Lookup"}
            </button>
          </div>
          {lookupResult && (
            <div className="bg-[#0d1117] rounded-lg border border-gray-800 p-4 mt-3" data-testid="section-lookup-result">
              {lookupResult.found ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-green-400 text-lg">&#x2714;</span>
                    <span className="text-white font-bold">{lookupResult.label?.entity || lookupResult.label?.name || "Known Address"}</span>
                  </div>
                  {lookupResult.label?.category && <div className="text-xs"><span className="text-gray-500">Category:</span> <span className="text-cyan-400">{lookupResult.label.category}</span></div>}
                  {lookupResult.label?.subcategory && <div className="text-xs"><span className="text-gray-500">Subcategory:</span> <span className="text-gray-300">{lookupResult.label.subcategory}</span></div>}
                  {lookupResult.label?.risk && <div className="text-xs"><span className="text-gray-500">Risk Level:</span> <span className={lookupResult.label.risk === "critical" ? "text-red-400" : lookupResult.label.risk === "high" ? "text-orange-400" : "text-yellow-400"}>{lookupResult.label.risk}</span></div>}
                  {lookupResult.label?.tags && <div className="text-xs"><span className="text-gray-500">Tags:</span> <span className="text-gray-300">{Array.isArray(lookupResult.label.tags) ? lookupResult.label.tags.join(", ") : lookupResult.label.tags}</span></div>}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400">&#x26A0;</span>
                  <span className="text-gray-400">Address not found in label database. Unknown entity.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {intelMode === "risk" && (
        <div className="space-y-4">
          <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-5" data-testid="section-risk-scoring">
            <h3 className="text-sm font-bold text-red-400 mb-3">RISK SCORING ENGINE</h3>
            <p className="text-xs text-gray-500 mb-3">Score any address 0-100 based on proximity to bad actors, mixer usage, sanctioned address interaction, transaction patterns, and age.</p>
            <div className="flex gap-2 mb-3">
              <input
                data-testid="input-risk-address"
                value={riskAddr}
                onChange={e => setRiskAddr(e.target.value)}
                placeholder="0x... wallet address"
                className="flex-1 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-red-500 outline-none font-mono"
              />
              <select data-testid="select-risk-chain" value={riskChain} onChange={e => setRiskChain(e.target.value)} className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300">
                {chains.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <button data-testid="button-risk-submit" onClick={doRisk} disabled={riskLoading || !riskAddr} className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:bg-gray-700 text-white rounded text-sm font-medium">
                {riskLoading ? "Scoring..." : "Score"}
              </button>
            </div>
            {riskResult && !riskResult.error && (
              <div className="bg-[#0d1117] rounded-lg border border-gray-800 p-4 mt-3" data-testid="section-risk-result">
                <div className="flex items-center gap-4 mb-3">
                  <div className="text-center">
                    <div className={`text-4xl font-bold ${riskColor(riskResult.overallScore || 0)}`} data-testid="text-risk-score">{riskResult.overallScore || 0}</div>
                    <div className="text-xs text-gray-500">/ 100</div>
                  </div>
                  <div className="flex-1">
                    <div className="w-full bg-gray-800 rounded-full h-3 mb-1">
                      <div className={`h-3 rounded-full ${riskBg(riskResult.overallScore || 0)}`} style={{ width: `${riskResult.overallScore || 0}%` }} />
                    </div>
                    <div className={`text-sm font-bold ${riskColor(riskResult.overallScore || 0)}`}>{riskResult.riskLevel || "UNKNOWN"}</div>
                  </div>
                </div>
                {riskResult.breakdown && (
                  <div className="space-y-2 mt-3">
                    <div className="text-xs text-gray-500 font-bold">RISK FACTORS:</div>
                    {riskResult.breakdown.map((f: any, i: number) => (
                      <div key={i} className="flex items-center justify-between text-xs bg-[#161b22] rounded p-2">
                        <div className="flex-1">
                          <span className="text-gray-300">{f.factor}</span>
                          {f.details && <div className="text-gray-600 text-[10px] mt-0.5">{f.details}</div>}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-800 rounded-full h-1.5">
                            <div className={`h-1.5 rounded-full ${riskBg(f.score || 0)}`} style={{ width: `${f.score || 0}%` }} />
                          </div>
                          <span className={`font-mono ${riskColor(f.score || 0)}`}>{f.score || 0}</span>
                          <span className="text-gray-600 text-[10px]">w:{f.weight}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {wallets && wallets.length > 0 && (
            <div className="bg-[#161b22] rounded-xl border border-red-900/20 p-5" data-testid="section-batch-risk">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-red-400">BATCH RISK SCAN — CASE WALLETS</h3>
                <button data-testid="button-batch-risk" onClick={doBatchRisk} disabled={batchRiskLoading} className="px-3 py-1.5 bg-red-600/20 border border-red-600/30 hover:bg-red-600/30 text-red-400 rounded text-xs font-medium">
                  {batchRiskLoading ? "Scanning..." : `Score ${Math.min(wallets.length, 20)} Wallets`}
                </button>
              </div>
              {batchRiskResults.length > 0 && (
                <div className="space-y-1 max-h-60 overflow-y-auto">
                  {batchRiskResults.map((r: any, i: number) => (
                    <div key={i} className="flex items-center justify-between text-xs bg-[#0d1117] rounded p-2">
                      <span className="font-mono text-gray-400 truncate max-w-[200px]">{r.address?.slice(0, 10)}...{r.address?.slice(-6)}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-12 bg-gray-800 rounded-full h-1.5">
                          <div className={`h-1.5 rounded-full ${riskBg(r.overallScore || 0)}`} style={{ width: `${r.overallScore || 0}%` }} />
                        </div>
                        <span className={`font-mono font-bold w-8 text-right ${riskColor(r.overallScore || 0)}`}>{r.overallScore || 0}</span>
                        <span className={`text-xs ${riskColor(r.overallScore || 0)}`}>{r.riskLevel || ""}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {intelMode === "cluster" && (
        <div className="bg-[#161b22] rounded-xl border border-purple-900/30 p-5" data-testid="section-cluster-analysis">
          <h3 className="text-sm font-bold text-purple-400 mb-3">ADDRESS CLUSTERING ENGINE</h3>
          <p className="text-xs text-gray-500 mb-3">Discover wallets controlled by the same entity using funding pattern analysis, behavioral heuristics, and timing correlation.</p>
          <div className="flex gap-2 mb-3">
            <input
              data-testid="input-cluster-address"
              value={clusterAddr}
              onChange={e => setClusterAddr(e.target.value)}
              placeholder="0x... wallet address"
              className="flex-1 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-purple-500 outline-none font-mono"
            />
            <select data-testid="select-cluster-chain" value={clusterChain} onChange={e => setClusterChain(e.target.value)} className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300">
              {chains.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button data-testid="button-cluster-submit" onClick={doCluster} disabled={clusterLoading || !clusterAddr} className="px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:bg-gray-700 text-white rounded text-sm font-medium">
              {clusterLoading ? "Analyzing..." : "Cluster"}
            </button>
          </div>
          {clusterResult && !clusterResult.error && (
            <div className="bg-[#0d1117] rounded-lg border border-gray-800 p-4 mt-3" data-testid="section-cluster-result">
              <div className="flex items-center gap-3 mb-3">
                <div className="text-2xl font-bold text-purple-400">{clusterResult.totalLinkedAddresses || 0}</div>
                <div className="text-xs text-gray-500">related addresses found</div>
              </div>
              {clusterResult.clusters && clusterResult.clusters.length > 0 && (
                <div className="space-y-2 mb-3">
                  <div className="text-xs text-gray-500 font-bold">HEURISTICS USED:</div>
                  {clusterResult.clusters.map((c: any, i: number) => (
                    <div key={i} className="text-xs bg-[#161b22] rounded p-2">
                      <div className="flex items-center gap-2">
                        <span className="text-purple-400 font-medium">{c.heuristic}</span>
                        <span className="text-gray-500">({c.addresses?.length || 0} addresses)</span>
                        {c.confidence !== undefined && <span className="text-xs bg-purple-600/20 border border-purple-600/30 text-purple-400 rounded px-1">{Math.round(c.confidence * 100)}%</span>}
                      </div>
                      {c.entityName && <div className="text-cyan-400 mt-1">Entity: {c.entityName}</div>}
                    </div>
                  ))}
                </div>
              )}
              {clusterResult.mergedAddresses && clusterResult.mergedAddresses.length > 0 && (
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  <div className="text-xs text-gray-500 font-bold mb-1">CLUSTERED ADDRESSES:</div>
                  {clusterResult.mergedAddresses.map((addr: string, i: number) => {
                    const label = clusterResult.knownEntities?.find((e: any) => e?.address?.toLowerCase() === addr.toLowerCase());
                    return (
                      <div key={i} className="flex items-center justify-between text-xs bg-[#161b22] rounded p-2">
                        <span className="font-mono text-gray-300 cursor-pointer hover:text-purple-400" onClick={() => setClusterAddr(addr)}>{addr.slice(0, 14)}...{addr.slice(-8)}</span>
                        {label && <span className="text-cyan-400">{label.name || label.entity} ({label.category})</span>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {intelMode === "bridge" && (
        <div className="bg-[#161b22] rounded-xl border border-orange-900/30 p-5" data-testid="section-bridge-tracer">
          <h3 className="text-sm font-bold text-orange-400 mb-3">CROSS-CHAIN BRIDGE TRACER</h3>
          <p className="text-xs text-gray-500 mb-3">Detect and trace bridge transactions across 12+ bridge contracts (Stargate, Hop, Across, Multichain, Wormhole, LI.FI) on 7 chains.</p>
          <div className="flex gap-2 mb-3">
            <input
              data-testid="input-bridge-address"
              value={bridgeAddr}
              onChange={e => setBridgeAddr(e.target.value)}
              placeholder="0x... wallet address"
              className="flex-1 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-orange-500 outline-none font-mono"
            />
            <select data-testid="select-bridge-chain" value={bridgeChain} onChange={e => setBridgeChain(e.target.value)} className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300">
              {chains.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button data-testid="button-bridge-submit" onClick={doBridge} disabled={bridgeLoading || !bridgeAddr} className="px-4 py-2 bg-orange-600 hover:bg-orange-500 disabled:bg-gray-700 text-white rounded text-sm font-medium">
              {bridgeLoading ? "Tracing..." : "Trace Bridges"}
            </button>
          </div>
          {bridgeResult && (
            <div className="bg-[#0d1117] rounded-lg border border-gray-800 p-4 mt-3" data-testid="section-bridge-result">
              <div className="flex items-center gap-3 mb-3">
                <div className="text-2xl font-bold text-orange-400">{bridgeResult.count || 0}</div>
                <div className="text-xs text-gray-500">bridge transactions detected</div>
              </div>
              {bridgeResult.traces && bridgeResult.traces.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {bridgeResult.traces.map((t: any, i: number) => (
                    <div key={i} className="bg-[#161b22] rounded p-3 border border-gray-800/50">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs bg-orange-600/20 text-orange-400 rounded px-2 py-0.5">{t.bridgeProtocol || "Unknown Bridge"}</span>
                        <span className="text-xs text-gray-500">{t.sourceChain || bridgeChain} → {t.destinationChain || "?"}</span>
                        <span className={`text-xs px-1 rounded ${t.status === "traced" ? "bg-green-900/20 text-green-400" : "bg-yellow-900/20 text-yellow-400"}`}>{t.status}</span>
                      </div>
                      {t.amount && <div className="text-xs text-gray-400">Amount: {parseFloat(t.amount) > 1e15 ? (parseFloat(t.amount) / 1e18).toFixed(4) + " ETH" : t.amount + " " + (t.token || "")}</div>}
                      {t.sourceTxHash && <div className="text-xs font-mono text-gray-500 truncate">TX: {t.sourceTxHash}</div>}
                      {t.destinationAddress && <div className="text-xs font-mono text-gray-400">Destination: {t.destinationAddress.slice(0, 14)}...{t.destinationAddress.slice(-8)}</div>}
                      {t.timestamp && <div className="text-xs text-gray-600">{new Date(t.timestamp).toLocaleString()}</div>}
                      {t.onwardMovements && t.onwardMovements.length > 0 && (
                        <div className="mt-2 pl-3 border-l border-orange-800/30 space-y-1">
                          <div className="text-[10px] text-gray-600">Onward movements:</div>
                          {t.onwardMovements.slice(0, 5).map((m: any, j: number) => (
                            <div key={j} className="text-[10px] text-gray-500 font-mono">→ {m.to?.slice(0, 10)}... {m.toLabel ? `(${m.toLabel})` : ""}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-gray-500">No bridge transactions detected for this address on {bridgeChain}.</div>
              )}
            </div>
          )}
        </div>
      )}

      {intelMode === "peel" && (
        <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-5" data-testid="section-peel-chain">
          <h3 className="text-sm font-bold text-green-400 mb-3">PEEL CHAIN DETECTOR</h3>
          <p className="text-xs text-gray-500 mb-3">Detect sequential fund-splitting patterns where stolen funds are broken into smaller amounts through chains of wallets (A→B→C→D).</p>
          <div className="flex gap-2 mb-3">
            <input
              data-testid="input-peel-address"
              value={peelAddr}
              onChange={e => setPeelAddr(e.target.value)}
              placeholder="0x... wallet address"
              className="flex-1 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-green-500 outline-none font-mono"
            />
            <select data-testid="select-peel-chain" value={peelChain} onChange={e => setPeelChain(e.target.value)} className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300">
              {chains.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button data-testid="button-peel-submit" onClick={doPeel} disabled={peelLoading || !peelAddr} className="px-4 py-2 bg-green-600 hover:bg-green-500 disabled:bg-gray-700 text-white rounded text-sm font-medium">
              {peelLoading ? "Detecting..." : "Detect Peel"}
            </button>
          </div>
          {peelResult && (
            <div className="bg-[#0d1117] rounded-lg border border-gray-800 p-4 mt-3" data-testid="section-peel-result">
              {peelResult.detected && peelResult.peelChain ? (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-red-400 text-lg">&#x26A0;</span>
                    <span className="text-white font-bold">Peel Chain Detected</span>
                    <span className="text-xs bg-purple-600/20 text-purple-400 rounded px-2 py-0.5">{peelResult.peelChain.pattern}</span>
                    {peelResult.peelChain.confidence !== undefined && <span className="text-xs bg-red-600/20 text-red-400 rounded px-2 py-0.5">{Math.round(peelResult.peelChain.confidence * 100)}% confidence</span>}
                  </div>
                  <div className="grid grid-cols-3 gap-3 mb-3 text-center">
                    <div className="bg-[#161b22] rounded p-2">
                      <div className="text-lg font-bold text-green-400">{peelResult.peelChain.hops?.length || 0}</div>
                      <div className="text-xs text-gray-500">Hops</div>
                    </div>
                    <div className="bg-[#161b22] rounded p-2">
                      <div className="text-lg font-bold text-orange-400">{peelResult.peelChain.totalPeeled || "0"}</div>
                      <div className="text-xs text-gray-500">Total Peeled</div>
                    </div>
                    <div className="bg-[#161b22] rounded p-2">
                      <div className="text-lg font-bold text-purple-400">{peelResult.peelChain.totalRemaining || "0"}</div>
                      <div className="text-xs text-gray-500">Remaining</div>
                    </div>
                  </div>
                  {peelResult.peelChain.riskIndicators && peelResult.peelChain.riskIndicators.length > 0 && (
                    <div className="flex gap-1 flex-wrap mb-3">
                      {peelResult.peelChain.riskIndicators.map((r: string, i: number) => (
                        <span key={i} className="text-[10px] bg-red-900/20 text-red-400 rounded px-1.5 py-0.5">{r}</span>
                      ))}
                    </div>
                  )}
                  {peelResult.peelChain.hops && peelResult.peelChain.hops.length > 0 && (
                    <div className="space-y-1 max-h-48 overflow-y-auto">
                      <div className="text-xs text-gray-500 font-bold mb-1">CHAIN PATH:</div>
                      {peelResult.peelChain.hops.map((hop: any, i: number) => (
                        <div key={i} className="flex items-center gap-2 text-xs bg-[#161b22] rounded p-1.5">
                          <span className="text-gray-600 w-6 text-right">{hop.hopNumber || i + 1}.</span>
                          <span className="font-mono text-gray-300">{hop.from?.slice(0, 8)}...→{hop.to?.slice(0, 8)}...</span>
                          {hop.amountForwarded && <span className="text-green-400">{parseFloat(hop.amountForwarded) > 1e15 ? (parseFloat(hop.amountForwarded) / 1e18).toFixed(4) : hop.amountForwarded}</span>}
                          {hop.amountPeeled && parseFloat(hop.amountPeeled) > 0 && <span className="text-orange-400">peeled: {parseFloat(hop.amountPeeled) > 1e15 ? (parseFloat(hop.amountPeeled) / 1e18).toFixed(4) : hop.amountPeeled}</span>}
                          {hop.toLabel && <span className="text-cyan-400">{hop.toLabel}</span>}
                        </div>
                      ))}
                    </div>
                  )}
                  {peelResult.peelChain.endAddress && (
                    <div className="mt-3 bg-red-900/10 border border-red-900/30 rounded p-2">
                      <div className="text-xs text-gray-500">Final Destination:</div>
                      <div className="text-sm font-mono text-red-400">{peelResult.peelChain.endAddress}</div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-green-400">&#x2714;</span>
                  <span className="text-gray-400">No peel chain pattern detected for this address.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function ForensicCommandCenter() {
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [activeTab, setActiveTab] = useState<"dashboard" | "wallets" | "alerts" | "trace" | "spider" | "cases" | "freeze" | "crosscase" | "phantom" | "custvaults" | "osint" | "originintel" | "networkintel" | "bounty" | "laundering" | "beacon" | "privacy" | "dossier" | "intelligence">("dashboard");
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const [traceAddress, setTraceAddress] = useState("");
  const [traceResult, setTraceResult] = useState<any>(null);
  const [tracing, setTracing] = useState(false);
  const [originTraceAddr, setOriginTraceAddr] = useState("");
  const [originTracing, setOriginTracing] = useState(false);
  const [originTraceData, setOriginTraceData] = useState<any>(null);
  const [originTraceId, setOriginTraceId] = useState<string | null>(null);
  const [originSelectedAddrs, setOriginSelectedAddrs] = useState<string[]>([]);
  const [originBatchResults, setOriginBatchResults] = useState<any[]>([]);
  const [originBatchTracing, setOriginBatchTracing] = useState(false);
  const [batchSortBy, setBatchSortBy] = useState<"default" | "progress" | "sources" | "risk" | "status">("default");
  const [batchFilterStatus, setBatchFilterStatus] = useState<"all" | "running" | "complete" | "error">("all");
  const [originBatchProgress, setOriginBatchProgress] = useState<Record<string, any>>({});
  useEffect(() => {
    setOriginSelectedAddrs([]);
    setOriginBatchResults([]);
    setOriginBatchProgress({});
    setOriginTraceData(null);
    setOriginTraceAddr("");
    setFreezeSelectedWallets([]);
    setNetScanData(null);
    setNetScanAddr("");
    setNetScanId(null);
    setNetSelectedWallet("");
    setNetBatchResults([]);
    setNetBatchProgress({});
    setQuickTraceSelected([]);
    setQuickTraceResults({});
    setQuickTraceProgress({});
    setTraceAddress("");
    setTraceResult(null);
    setOsintSingleAddr("");
    setOsintSingleResults(null);
    setSpiderConfig(p => ({ ...p, address: "", chain: "ethereum" }));
    setCaseScanResult(null);
    setCaseScanExpandedWallet(null);
    setTcEventResult(null);
    setTcEventExpandedPool(null);
  }, [selectedCase]);
  const [netScanAddr, setNetScanAddr] = useState("");
  const [netScanning, setNetScanning] = useState(false);
  const [netScanData, setNetScanData] = useState<any>(null);
  const [netScanId, setNetScanId] = useState<string | null>(null);
  const [netSelectedWallet, setNetSelectedWallet] = useState("");
  const [netBatchResults, setNetBatchResults] = useState<any[]>([]);
  const [netBatchScanning, setNetBatchScanning] = useState(false);
  const [netBatchProgress, setNetBatchProgress] = useState<Record<string, any>>({});
  const [quickTraceSelected, setQuickTraceSelected] = useState<string[]>([]);
  const [quickTraceResults, setQuickTraceResults] = useState<Record<string, any>>({});
  const [quickTracing, setQuickTracing] = useState(false);
  const [quickTraceProgress, setQuickTraceProgress] = useState<Record<string, string>>({});
  const [newWallet, setNewWallet] = useState({ address: "", chain: "ethereum", role: "", label: "" });
  const [showNewCaseForm, setShowNewCaseForm] = useState(false);
  const [showBountyForm, setShowBountyForm] = useState(false);
  const [bountyForm, setBountyForm] = useState({ caseId: "", clientName: "", clientEmail: "", clientWalletAddress: "", bountyPercentage: "10" });
  const [showRecoveryForm, setShowRecoveryForm] = useState(false);
  const [recoveryForm, setRecoveryForm] = useState({ caseId: "", walletAddress: "", chain: "ethereum", amountRecoveredNative: "", amountRecoveredUsd: "", source: "exchange_freeze", notes: "" });
  const [generatingAgreement, setGeneratingAgreement] = useState(false);
  const [loggingRecovery, setLoggingRecovery] = useState(false);
  const [newCase, setNewCase] = useState({ caseName: "", victimAddress: "", victimHandle: "", description: "", totalStolenUsd: "", chains: "ethereum" });
  const [bulkWallets, setBulkWallets] = useState("");
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [spiderConfig, setSpiderConfig] = useState({ address: "", chain: "ethereum", maxDepth: 0, maxWallets: 0 });
  const [spiderRunning, setSpiderRunning] = useState(false);
  const [showFreezeForm, setShowFreezeForm] = useState(false);
  const [freezeForm, setFreezeForm] = useState({ caseId: "", walletAddress: "", exchangeName: "", exchangeEmail: "", chain: "ethereum", estimatedValueUsd: "", bountyPercentage: "10", bountyWalletAddress: "" });
  const [freezeSelectedWallets, setFreezeSelectedWallets] = useState<string[]>([]);
  const [showPhantomForm, setShowPhantomForm] = useState(false);
  const [phantomForm, setPhantomForm] = useState({ caseId: "", vaultName: "", chain: "ethereum", decoyTokenType: "USDC", decoyAmount: "", expirationHours: "24" });
  const [beaconDeployForm, setBeaconDeployForm] = useState({ targetAddress: "", chain: "ethereum", type: "address_monitor" as string });
  const [aucTrapForm, setAucTrapForm] = useState({ originalToken: "", originalChain: "ethereum", originalAddress: "", aucWalletAddress: "", amountSwapped: "" });
  const [deployingBeacon, setDeployingBeacon] = useState(false);
  const [deployingTrap, setDeployingTrap] = useState(false);
  const [beaconDeployResult, setBeaconDeployResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [trapDeployResult, setTrapDeployResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [scanningBeacons, setScanningBeacons] = useState(false);
  const [scanResult, setScanResult] = useState<{ count: number; time: string } | null>(null);
  const [triggerAddresses, setTriggerAddresses] = useState<Record<string, string>>({});
  const [beaconAddresses, setBeaconAddresses] = useState<Record<string, string>>({});
  const [copiedAddr, setCopiedAddr] = useState<string | null>(null);
  const [quickScanWallet, setQuickScanWallet] = useState<string | null>(null);
  const [flowViewMode, setFlowViewMode] = useState<"cards" | "graph" | "flow">("graph");
  const [entityWallet, setEntityWallet] = useState<string | null>(null);
  const [alertConfigWallet, setAlertConfigWallet] = useState<string | null>(null);
  const [alertConfigs, setAlertConfigs] = useState<Record<string, { onBalanceChange?: boolean; onLargeTransfer?: boolean; minUsdThreshold?: number; onNewTokens?: boolean; onChainHop?: boolean }>>({});
  const [walletSortKey, setWalletSortKey] = useState<string>("usd");
  const [walletSortDir, setWalletSortDir] = useState<"asc" | "desc">("desc");
  const [walletChainFilter, setWalletChainFilter] = useState<string>("all");
  const [walletRoleFilter, setWalletRoleFilter] = useState<string>("all");
  const [walletStatusFilter, setWalletStatusFilter] = useState<string>("all");
  const [alertSeverityFilter, setAlertSeverityFilter] = useState<string>("all");
  const [alertTypeFilter, setAlertTypeFilter] = useState<string>("all");
  const [alertAckFilter, setAlertAckFilter] = useState<string>("all");
  const [alertSortDir, setAlertSortDir] = useState<"newest" | "oldest">("newest");
  const [alertPageSize, setAlertPageSize] = useState<number>(25);
  const [alertPage, setAlertPage] = useState<number>(1);
  const [alertPageInput, setAlertPageInput] = useState<string>("1");
  const [downloading, setDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [showSendReport, setShowSendReport] = useState(false);
  const [sendReportForm, setSendReportForm] = useState({ recipientEmail: "", recipientName: "", includeWallets: true, includeAlerts: true, includeOsint: true, includeOriginIntel: true, includeNetworkIntel: true, includeSpiderTrace: true, includeFreezeRequests: true });
  const [sendingReport, setSendingReport] = useState(false);
  const [sendReportResult, setSendReportResult] = useState<{ ok: boolean; msg: string; fromAddress?: string } | null>(null);
  const [reportDataSummary, setReportDataSummary] = useState<any>(null);
  const [refreshingIntel, setRefreshingIntel] = useState(false);
  const [refreshIntelResult, setRefreshIntelResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [reportEmailInfo, setReportEmailInfo] = useState<{ preferredFrom: string | null; provider?: string } | null>(null);
  const [selectedVault, setSelectedVault] = useState<string | null>(null);
  const [osintScanId, setOsintScanId] = useState<string | null>(null);
  const [osintScanning, setOsintScanning] = useState(false);
  const [osintSingleAddr, setOsintSingleAddr] = useState("");
  const [osintSingleResults, setOsintSingleResults] = useState<any[] | null>(null);
  const [osintSingleLoading, setOsintSingleLoading] = useState(false);
  const [rescanning, setRescanning] = useState(false);
  const [rescanResult, setRescanResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [privacyTornadoDeposit, setPrivacyTornadoDeposit] = useState("");
  const [privacyTornadoWithdrawal, setPrivacyTornadoWithdrawal] = useState("");
  const [privacyTornadoResult, setPrivacyTornadoResult] = useState<any>(null);
  const [privacyTornadoLoading, setPrivacyTornadoLoading] = useState(false);
  const [privacyMoneroAddr, setPrivacyMoneroAddr] = useState("");
  const [privacyMoneroResult, setPrivacyMoneroResult] = useState<any>(null);
  const [privacyMoneroLoading, setPrivacyMoneroLoading] = useState(false);
  const [privacyFingerprintAddr, setPrivacyFingerprintAddr] = useState("");
  const [privacyFingerprintResult, setPrivacyFingerprintResult] = useState<any>(null);
  const [privacyFingerprintLoading, setPrivacyFingerprintLoading] = useState(false);
  const [privacyMethodsExpanded, setPrivacyMethodsExpanded] = useState<string | null>(null);
  const [privacyTrackingMethods, setPrivacyTrackingMethods] = useState<any[]>([]);
  const [privacyMethodsLoaded, setPrivacyMethodsLoaded] = useState(false);
  const [exploitScanResult, setExploitScanResult] = useState<any>(null);
  const [exploitScanLoading, setExploitScanLoading] = useState(false);
  const [exploitFilter, setExploitFilter] = useState<string>("all");
  const [exploitSeverityFilter, setExploitSeverityFilter] = useState<string>("all");
  const [exploitExpandedId, setExploitExpandedId] = useState<string | null>(null);
  const [addressLookup, setAddressLookup] = useState("");
  const [addressResult, setAddressResult] = useState<any>(null);
  const [caseScanResult, setCaseScanResult] = useState<any>(null);
  const [caseScanLoading, setCaseScanLoading] = useState(false);
  const [caseScanExpandedWallet, setCaseScanExpandedWallet] = useState<string | null>(null);
  const [tcEventResult, setTcEventResult] = useState<any>(null);
  const [tcEventLoading, setTcEventLoading] = useState(false);
  const [tcEventExpandedPool, setTcEventExpandedPool] = useState<string | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/forensic/command-center/access", { credentials: "include" })
      .then(r => r.json())
      .then(d => setHasAccess(d.hasAccess === true))
      .catch(() => setHasAccess(false));
  }, []);

  const { data: stats } = useQuery<MonitorStats>({
    queryKey: ["/api/forensic/command-center/stats"],
    refetchInterval: 30000,
    enabled: hasAccess === true,
  });

  const { data: cases } = useQuery<ForensicCase[]>({
    queryKey: ["/api/forensic/command-center/cases"],
    refetchInterval: 60000,
    enabled: hasAccess === true,
  });

  const { data: wallets } = useQuery<MonitoredWallet[]>({
    queryKey: ["/api/forensic/command-center/wallets", selectedCase],
    queryFn: () => fetch(`/api/forensic/command-center/wallets${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: 30000,
    enabled: hasAccess === true,
  });

  useEffect(() => {
    if (wallets) {
      const configs: Record<string, any> = {};
      for (const w of wallets) {
        const meta = (w as any).metadata;
        if (meta?.alertConfig) configs[w.id] = meta.alertConfig;
      }
      if (Object.keys(configs).length > 0) setAlertConfigs(p => ({ ...configs, ...p }));
    }
  }, [wallets]);

  const { data: alerts } = useQuery<ForensicAlert[]>({
    queryKey: ["/api/forensic/command-center/alerts", selectedCase],
    queryFn: () => fetch(`/api/forensic/command-center/alerts${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: 15000,
    enabled: hasAccess === true,
  });

  const { data: freezeRequests } = useQuery<any[]>({
    queryKey: ["/api/forensic/command-center/freeze-requests", selectedCase],
    queryFn: () => fetch(`/api/forensic/command-center/freeze-requests${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: 30000,
    enabled: hasAccess === true,
  });

  const { data: bountyAgreements } = useQuery<any[]>({
    queryKey: ["/api/forensic/command-center/bounty-agreements", selectedCase],
    queryFn: () => fetch(`/api/forensic/command-center/bounty-agreements${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: 30000,
    enabled: hasAccess === true,
  });

  const { data: recoveryEvents } = useQuery<any[]>({
    queryKey: ["/api/forensic/command-center/recovery-events", selectedCase],
    queryFn: () => fetch(`/api/forensic/command-center/recovery-events${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: 30000,
    enabled: hasAccess === true,
  });

  const { data: launderingRisk } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/laundering-risk", selectedCase],
    queryFn: () => selectedCase ? fetch(`/api/forensic/command-center/laundering-risk/${selectedCase}`, { credentials: "include" }).then(r => r.json()) : null,
    refetchInterval: 60000,
    enabled: hasAccess === true && activeTab === "laundering" && !!selectedCase,
  });

  const { data: crossCaseIntel } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/cross-case-intelligence"],
    refetchInterval: 60000,
    enabled: hasAccess === true && activeTab === "crosscase",
  });

  const { data: phantomVaults } = useQuery<any[]>({
    queryKey: ["/api/forensic/command-center/phantom-vaults", selectedCase],
    queryFn: async () => {
      const r = await fetch(`/api/forensic/command-center/phantom-vaults${selectedCase ? `?caseId=${selectedCase}` : ""}`, { credentials: "include" });
      const data = await r.json();
      return Array.isArray(data) ? data : [];
    },
    refetchInterval: 15000,
    enabled: hasAccess === true,
  });

  const { data: customerVaultData } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/customer-vaults"],
    refetchInterval: 15000,
    enabled: hasAccess === true,
  });
  const customerVaults = customerVaultData?.vaults || [];
  const customerSubs = customerVaultData?.subscriptions || [];
  const customerStats = customerVaultData?.stats || {};
  const [cvTriggerAddr, setCvTriggerAddr] = useState<Record<string, string>>({});
  const [cvBeaconAddr, setCvBeaconAddr] = useState<Record<string, string>>({});
  const [cvExpanded, setCvExpanded] = useState<string | null>(null);

  const { data: osintScanData } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/osint-scan", osintScanId],
    queryFn: () => fetch(`/api/forensic/command-center/osint-scan/${osintScanId}`, { credentials: "include" }).then(r => r.json()),
    refetchInterval: osintScanning ? 3000 : false,
    enabled: hasAccess === true && !!osintScanId,
  });

  useEffect(() => {
    if (osintScanData?.status === "complete" || osintScanData?.status === "error") {
      setOsintScanning(false);
    }
  }, [osintScanData?.status]);

  const ackMutation = useMutation({
    mutationFn: (alertId: string) => apiRequest("POST", `/api/forensic/command-center/alerts/${alertId}/acknowledge`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] }),
  });

  const addWalletMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/forensic/command-center/wallet", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/stats"] });
      setNewWallet({ address: "", chain: "ethereum", role: "", label: "" });
    },
  });

  const [autoTraceOnCreate, setAutoTraceOnCreate] = useState(true);

  const createCaseMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/forensic/command-center/case", data).then(r => r.json()),
    onSuccess: async (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/cases"] });
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/stats"] });
      const createdCaseId = data?.id;
      const victimAddr = newCase.victimAddress;
      if (createdCaseId) {
        setSelectedCase(createdCaseId);
      }
      if (autoTraceOnCreate && victimAddr && createdCaseId) {
        setSpiderConfig(p => ({ ...p, address: victimAddr }));
        setTimeout(() => startSpiderTrace(victimAddr, createdCaseId), 500);
        setActiveTab("spider");
      }
      setNewCase({ caseName: "", victimAddress: "", victimHandle: "", description: "", totalStolenUsd: "", chains: "ethereum" });
      setShowNewCaseForm(false);
    },
  });

  const deleteWalletMutation = useMutation({
    mutationFn: (walletId: string) => apiRequest("DELETE", `/api/forensic/command-center/wallet/${walletId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/stats"] });
    },
  });

  const bulkAddWallets = useCallback(async () => {
    if (!selectedCase || !bulkWallets.trim()) return;
    const lines = bulkWallets.trim().split("\n").filter(l => l.trim());
    for (const line of lines) {
      const parts = line.split(",").map(s => s.trim());
      const address = parts[0];
      if (!address || !address.startsWith("0x")) continue;
      const label = parts[1] || "";
      const role = parts[2] || "";
      const chain = parts[3] || "ethereum";
      try {
        await apiRequest("POST", "/api/forensic/command-center/wallet", { caseId: selectedCase, address, chain, role, label });
      } catch {}
    }
    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/stats"] });
    setBulkWallets("");
    setShowBulkAdd(false);
  }, [selectedCase, bulkWallets, queryClient]);

  const { data: spiderTrace, refetch: refetchSpider } = useQuery<any>({
    queryKey: ["/api/forensic/command-center/spider-trace", selectedCase],
    queryFn: () => selectedCase
      ? fetch(`/api/forensic/command-center/spider-trace/${selectedCase}`, { credentials: "include" }).then(r => r.json())
      : Promise.resolve(null),
    refetchInterval: spiderRunning ? 3000 : 30000,
    enabled: hasAccess === true && !!selectedCase,
  });

  useEffect(() => {
    if (spiderTrace && spiderTrace.status === "running") {
      setSpiderRunning(true);
    } else if (spiderTrace && (spiderTrace.status === "complete" || spiderTrace.status === "error")) {
      setSpiderRunning(false);
    }
  }, [spiderTrace]);

  const { data: beaconStats, refetch: refetchBeaconStats } = useQuery<any>({
    queryKey: ["/api/forensic/beacon/stats"],
    queryFn: () => fetch("/api/forensic/beacon/stats", { credentials: "include" }).then(r => r.json()),
    refetchInterval: 30000,
    enabled: hasAccess === true && activeTab === "beacon",
  });

  const { data: beaconList, refetch: refetchBeaconList } = useQuery<any[]>({
    queryKey: ["/api/forensic/beacon/list", selectedCase],
    queryFn: () => selectedCase
      ? fetch(`/api/forensic/beacon/list/${selectedCase}`, { credentials: "include" }).then(r => r.json())
      : fetch("/api/forensic/beacon/stats", { credentials: "include" }).then(r => r.json()).then(() => []),
    refetchInterval: 15000,
    enabled: hasAccess === true && activeTab === "beacon" && !!selectedCase,
  });

  const { data: beaconSignals, refetch: refetchBeaconSignals } = useQuery<any[]>({
    queryKey: ["/api/forensic/beacon/signals", selectedCase],
    queryFn: () => selectedCase
      ? fetch(`/api/forensic/beacon/signals/${selectedCase}?limit=50`, { credentials: "include" }).then(r => r.json())
      : Promise.resolve([]),
    refetchInterval: 10000,
    enabled: hasAccess === true && activeTab === "beacon" && !!selectedCase,
  });

  const startSpiderTrace = useCallback(async (overrideAddress?: string, overrideCaseId?: string) => {
    const cid = overrideCaseId || selectedCase;
    const addr = overrideAddress || spiderConfig.address;
    if (!cid || !addr) return;
    setSpiderRunning(true);
    try {
      const resp = await fetch("/api/forensic/command-center/spider-trace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          caseId: cid,
          address: addr,
          chain: spiderConfig.chain,
          maxDepth: spiderConfig.maxDepth,
          maxWallets: spiderConfig.maxWallets,
        }),
      });
      if (resp.status === 403 || resp.status === 400) {
        setSpiderRunning(false);
        return;
      }
      if (activeTab !== "spider") setActiveTab("spider");
      setTimeout(() => refetchSpider(), 1000);
    } catch (e) {
      setSpiderRunning(false);
    }
  }, [selectedCase, spiderConfig, activeTab, refetchSpider]);

  const runTrace = useCallback(async () => {
    if (!traceAddress) return;
    setTracing(true);
    setTraceResult(null);
    try {
      const resp = await fetch("/api/forensic/command-center/trace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ address: traceAddress }),
      });
      if (resp.status === 403 || resp.status === 400) {
        setTraceResult({ error: "Request blocked by security filter. Try again in a moment." });
        setTracing(false);
        return;
      }
      const data = await resp.json();
      setTraceResult(data);
    } catch (e: any) {
      setTraceResult({ error: e.message });
    }
    setTracing(false);
  }, [traceAddress]);

  if (hasAccess === null) {
    return (
      <div className="min-h-screen bg-[#0a0e14] flex items-center justify-center">
        <div className="text-cyan-400 text-lg animate-pulse">Verifying authorization...</div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-[#0a0e14] flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">ACCESS DENIED</div>
          <div className="text-gray-500">Forensic Command Center requires admin authorization.</div>
          <div className="text-gray-600 text-sm mt-2">This access attempt has been logged.</div>
        </div>
      </div>
    );
  }

  const pendingFreezes = freezeRequests?.filter((f: any) => f.status === "pending")?.length || 0;
  const frozenCount = freezeRequests?.filter((f: any) => f.status === "frozen" && !f.notified)?.length || 0;

  const activeVaults = phantomVaults?.filter((v: any) => v.status === "armed" || v.status === "triggered")?.length || 0;

  function buildCaseFlowData(caseWallets: any[], caseData: any): { flowNodes: TxFlowNode[]; flowEdges: TxFlowEdge[] } {
    const roleMap: Record<string, { col: number; txRole: TxFlowNode["role"] }> = {
      victim: { col: 0, txRole: "victim" },
      source: { col: 1, txRole: "source" },
      laundering: { col: 2, txRole: "laundering" },
      laundering_hub: { col: 2, txRole: "laundering" },
      gas_funder: { col: 1, txRole: "gas_funder" },
      original_funder: { col: 1, txRole: "original_funder" },
      poi: { col: 2, txRole: "poi" },
      person_of_interest: { col: 2, txRole: "poi" },
      split_wallet: { col: 3, txRole: "split_wallet" },
      "DAI Recipient": { col: 4, txRole: "dai_recipient" },
      dai_recipient: { col: 4, txRole: "dai_recipient" },
      "DAI Dispersal": { col: 4, txRole: "dai_dispersal" },
      dai_dispersal: { col: 4, txRole: "dai_dispersal" },
      destination: { col: 5, txRole: "destination" },
      fund_destination: { col: 5, txRole: "destination" },
      "Arb Receiver": { col: 6, txRole: "arb_receiver" },
      arb_receiver: { col: 6, txRole: "arb_receiver" },
      final_destination: { col: 7, txRole: "final_destination" },
      defi: { col: 4, txRole: "defi" },
      token_recipient: { col: 5, txRole: "token_recipient" },
    };

    const coreRoles = ["victim", "source", "laundering", "laundering_hub", "gas_funder", "original_funder", "poi", "person_of_interest", "split_wallet", "DAI Recipient", "dai_recipient", "DAI Dispersal", "dai_dispersal", "destination", "fund_destination", "Arb Receiver", "arb_receiver", "final_destination", "defi"];
    const coreWallets = caseWallets.filter(w => coreRoles.includes(w.role));
    const limitedWallets = coreWallets.slice(0, 80);

    const flowNodes: TxFlowNode[] = limitedWallets.map(w => {
      const rm = roleMap[w.role] || { col: 5, txRole: "token_recipient" as const };
      return {
        id: w.address?.toLowerCase() || w.id,
        address: w.address || "",
        label: (w.label || w.role || "").slice(0, 40),
        role: rm.txRole,
        chain: w.chain || "ethereum",
        column: rm.col,
        amount: w.last_known_balance_eth ? `${parseFloat(w.last_known_balance_eth).toFixed(4)} ETH` : undefined,
        subLabel: w.role,
      };
    });

    const flowEdges: TxFlowEdge[] = [];
    const victimNodes = flowNodes.filter(n => n.role === "victim");
    const sourceNodes = flowNodes.filter(n => n.role === "source");
    const launderingNodes = flowNodes.filter(n => n.role === "laundering");
    const gasNodes = flowNodes.filter(n => n.role === "gas_funder");
    const origNodes = flowNodes.filter(n => n.role === "original_funder");
    const poiNodes = flowNodes.filter(n => n.role === "poi");
    const splitNodes = flowNodes.filter(n => n.role === "split_wallet");
    const daiNodes = flowNodes.filter(n => n.role === "dai_recipient" || n.role === "dai_dispersal");
    const destNodes = flowNodes.filter(n => n.role === "destination");
    const arbNodes = flowNodes.filter(n => n.role === "arb_receiver");
    const finalNodes = flowNodes.filter(n => n.role === "final_destination");

    victimNodes.forEach(v => {
      sourceNodes.forEach(s => flowEdges.push({ from: v.id, to: s.id, label: "EIP-7702 Exploit" }));
    });
    sourceNodes.forEach(s => {
      launderingNodes.forEach(l => flowEdges.push({ from: s.id, to: l.id, label: "Fund Transfer" }));
    });
    gasNodes.forEach(g => {
      launderingNodes.forEach(l => flowEdges.push({ from: g.id, to: l.id, label: "Gas Funding" }));
      destNodes.slice(0, 5).forEach(d => flowEdges.push({ from: g.id, to: d.id, label: "Gas" }));
    });
    origNodes.forEach(o => {
      gasNodes.forEach(g => flowEdges.push({ from: o.id, to: g.id, label: "Original Funds" }));
      sourceNodes.forEach(s => flowEdges.push({ from: o.id, to: s.id, label: "Wallet Deploy" }));
    });
    poiNodes.forEach(p => {
      destNodes.slice(0, 3).forEach(d => flowEdges.push({ from: p.id, to: d.id, label: "POI Transfer" }));
    });
    launderingNodes.forEach(l => {
      splitNodes.forEach(s => flowEdges.push({ from: l.id, to: s.id, label: "Split" }));
      daiNodes.forEach(d => flowEdges.push({ from: l.id, to: d.id, label: "DAI Dispersal" }));
    });
    splitNodes.forEach(s => {
      destNodes.slice(0, 3).forEach(d => flowEdges.push({ from: s.id, to: d.id, label: "Funds" }));
      arbNodes.slice(0, 2).forEach(a => flowEdges.push({ from: s.id, to: a.id, label: "Bridge to ARB" }));
    });
    arbNodes.forEach(a => {
      finalNodes.forEach(f => flowEdges.push({ from: a.id, to: f.id, label: "Final Bridge" }));
    });

    return { flowNodes, flowEdges };
  }

  function buildDossierExchangeTargets(): any[] {
    return [
      { exchange: "Binance Cold Wallet", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "80,000,000", token: "SUI", txHash: "0x4224fce32e8555cd05..." },
      { exchange: "Coinbase 1", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "62,000,000", token: "SUI", txHash: "0x17f79857c8ee0f9f0f..." },
      { exchange: "Coinbase 10", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "28,300,000", token: "SUI", txHash: "0xc451087d4b23129281..." },
      { exchange: "Huobi 10", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "29,700,000", token: "SUI", txHash: "0xc038d09b03287c11f4..." },
      { exchange: "KuCoin 2", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "79,056,343", token: "SUI", txHash: "0xdf77698fd16aaef92f..." },
      { exchange: "OKX", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "85,453,173", token: "SUI", txHash: "0x6aef8dc68d90be8132..." },
      { exchange: "Binance 8", walletAddress: "0x2825c83d0425e75a72ed46aae39526db43c9acd8", walletLabel: "Token Sender (SUI)", direction: "token deposit to exchange", amount: "25,000,000", token: "SUI", txHash: "0xa1b2c3d4e5f6..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0x564286362092d8e7936f0549571a803b203aaced", walletLabel: "ETH Sender", direction: "token deposit to exchange", amount: "23,699,851", token: "APTOS", txHash: "0x6348ae875676feb7c3..." },
      { exchange: "Coinbase 1", walletAddress: "0x564286362092d8e7936f0549571a803b203aaced", walletLabel: "ETH Sender", direction: "token deposit to exchange", amount: "20,000,000", token: "APTOS", txHash: "0x3e04cb98c3df11b8f2..." },
      { exchange: "Crypto.com", walletAddress: "0x564286362092d8e7936f0549571a803b203aaced", walletLabel: "ETH Sender", direction: "token deposit to exchange", amount: "19,586,329", token: "APTOS", txHash: "0x827810b64de2f3b647..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0x85b931a32a0725be14285b66f1a22178c672d69b", walletLabel: "ETH Sender (0.492 ETH)", direction: "token deposit to exchange", amount: "2,282", token: "USDT", txHash: "0x13dc1009b221b53534..." },
      { exchange: "Binance 8", walletAddress: "0x85b931a32a0725be14285b66f1a22178c672d69b", walletLabel: "ETH Sender (0.492 ETH)", direction: "token withdrawal from exchange", amount: "24,698,356", token: "APTOS", txHash: "0x5fb8f0cb64387eada7..." },
      { exchange: "Binance Cold Wallet", walletAddress: "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8", walletLabel: "Token Recipient (SUI)", direction: "token deposit to exchange", amount: "68,466,994", token: "XRP", txHash: "0x446fe1ca7f31df2027..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0x90b4392cc18e9d845a5a537da5b3afa2e54ffab8", walletLabel: "ETH Recipient", direction: "token deposit to exchange", amount: "5,500", token: "USDT", txHash: "0x585a748da4a01a6f31..." },
      { exchange: "Coinbase 10", walletAddress: "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43", walletLabel: "Token Recipient (USDC)", direction: "token deposit to exchange", amount: "36.14", token: "PAXG", txHash: "0x00e696e44467bb08a1..." },
      { exchange: "Bittrex 2", walletAddress: "0x8ca0eb9afedda34521e68166933e0d06d4f5b905", walletLabel: "Token Sender (APTOS)", direction: "token deposit to exchange", amount: "99,000,000", token: "APTOS", txHash: "0xda86aa011a64a90c4e..." },
      { exchange: "Coinbase 2", walletAddress: "0x8ca0eb9afedda34521e68166933e0d06d4f5b905", walletLabel: "Token Sender (APTOS)", direction: "token deposit to exchange", amount: "132,911,051", token: "APTOS", txHash: "0xbfb4c6cc3047b7b982..." },
      { exchange: "Huobi 10", walletAddress: "0x8ca0eb9afedda34521e68166933e0d06d4f5b905", walletLabel: "Token Sender (APTOS)", direction: "token deposit to exchange", amount: "100,000,000", token: "APTOS", txHash: "0xc7f0762e59fb8b26a8..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0x6b16eb5297d8337a93ed017a6d32db9c403361d3", walletLabel: "Token Sender (USDT)", direction: "token deposit to exchange", amount: "1,699.96", token: "USDT", txHash: "0x63846b6f90a9e56dc4..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0x7c0b62ae9618faa9badf54414276ec7b5344c3e1", walletLabel: "Token Recipient (USDT)", direction: "token deposit to exchange", amount: "4,000", token: "USDT", txHash: "0x..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0xa678c509badc85855ff2713e740d6fa29bc8d677", walletLabel: "Token Sender (USDT)", direction: "token deposit to exchange", amount: "2,150", token: "USDT", txHash: "0xe6a59373b880d2e8dc..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0xa5706969c7cbdfa3277594238cb2ae19e2851a30", walletLabel: "Token Sender (USDT)", direction: "token deposit to exchange", amount: "6,046.49", token: "USDT", txHash: "0x..." },
      { exchange: "Bybit 2", walletAddress: "0xa5706969c7cbdfa3277594238cb2ae19e2851a30", walletLabel: "Token Sender (USDT)", direction: "token withdrawal from exchange", amount: "9,997", token: "USDC", txHash: "0x6cd2ae37ef488eb629..." },
      { exchange: "Binance Hot Wallet 14", walletAddress: "0xcd67201a7204be6517c365cc5961580af29462f2", walletLabel: "Token Sender (WETH)", direction: "token deposit to exchange", amount: "0.4533", token: "WETH", txHash: "0x1bec25444820ed79bd..." },
      { exchange: "Gate.io", walletAddress: "0x14a7aec9f567a2516e01c6fda5e0b7d15cede969", walletLabel: "Token Recipient (USDC)", direction: "token withdrawal from exchange", amount: "171.36", token: "USDC", txHash: "0x..." },
    ];
  }

  const tabs = [
    { id: "dashboard" as const, label: "Dashboard", icon: "grid" },
    { id: "wallets" as const, label: "Wallets", icon: "wallet" },
    { id: "alerts" as const, label: "Alerts", icon: "bell", badge: stats?.unacknowledgedAlerts },
    { id: "trace" as const, label: "Quick Trace", icon: "search" },
    { id: "spider" as const, label: "Spider Trace", icon: "spider" },
    { id: "phantom" as const, label: "Phantom Vault", icon: "ghost", badge: activeVaults > 0 ? activeVaults : undefined },
    { id: "custvaults" as const, label: "Customer Vaults", icon: "users", badge: customerStats?.triggeredVaults > 0 ? customerStats.triggeredVaults : customerStats?.totalVaults > 0 ? customerStats.totalVaults : undefined },
    { id: "freeze" as const, label: "Freeze Requests", icon: "snowflake", badge: frozenCount > 0 ? frozenCount : pendingFreezes > 0 ? pendingFreezes : undefined },
    { id: "crosscase" as const, label: "Cross-Case Intel", icon: "network" },
    { id: "osint" as const, label: "OSINT Intel", icon: "globe", badge: osintScanData?.totalHits > 0 ? osintScanData.totalHits : undefined },
    { id: "originintel" as const, label: "Origin Intel", icon: "radar", badge: originTraceData?.totalWebsitesFound > 0 ? originTraceData.totalWebsitesFound : undefined },
    { id: "networkintel" as const, label: "Network Intel", icon: "signal", badge: netScanData?.attackerProfile?.identityClues?.length > 0 ? netScanData.attackerProfile.identityClues.length : undefined },
    { id: "bounty" as const, label: "Bounty Agreements", icon: "document" },
    { id: "laundering" as const, label: "Laundering Risk", icon: "alert" },
    { id: "beacon" as const, label: "Spider Beacon", icon: "radio", badge: beaconStats?.activeBeacons > 0 ? beaconStats.activeBeacons : undefined },
    { id: "privacy" as const, label: "Privacy Tracker", icon: "shield" },
    { id: "intelligence" as const, label: "Intelligence Suite", icon: "cpu" },
    { id: "dossier" as const, label: "Recovery Dossier", icon: "document" },
    { id: "cases" as const, label: "Cases", icon: "folder" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e14] text-gray-200">
      <div className="border-b border-cyan-900/30 bg-[#0d1117]/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-[1800px] mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg" data-testid="forensic-logo">
              FIE
            </div>
            <div>
              <h1 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400" data-testid="text-title">
                Forensic Recovery Command Center
              </h1>
              <div className="text-xs text-gray-500">Forensic Intelligence Engine&trade; | Admin Only</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {cases && cases.length > 0 && (
              <select
                data-testid="select-case-filter"
                value={selectedCase || ""}
                onChange={e => setSelectedCase(e.target.value || null)}
                className="px-3 py-1.5 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-300 focus:border-cyan-500 outline-none"
              >
                <option value="">All Cases</option>
                {cases.map(c => (
                  <option key={c.id} value={c.id}>{c.caseName}</option>
                ))}
              </select>
            )}
            {stats?.criticalAlerts ? (
              <div className="px-3 py-1 bg-red-600/20 border border-red-600/30 rounded text-red-400 text-sm animate-pulse" data-testid="text-critical-alerts">
                {stats.criticalAlerts} CRITICAL ALERT{stats.criticalAlerts > 1 ? "S" : ""}
              </div>
            ) : null}
            <button
              data-testid="button-download-data"
              onClick={async () => {
                setDownloading(true);
                setDownloadStatus(null);
                try {
                  const resp = await fetch("/api/forensic/command-center/download", { credentials: "include" });
                  if (!resp.ok) {
                    const err = await resp.json().catch(() => ({ message: "Server error" }));
                    throw new Error(err.message || "Download failed");
                  }
                  const blob = await resp.blob();
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  const disposition = resp.headers.get("content-disposition");
                  const filenameMatch = disposition?.match(/filename="(.+?)"/);
                  const fname = filenameMatch?.[1] || `forensic-data-export-${new Date().toISOString().replace(/[:.]/g, "-")}.zip`;
                  a.download = fname;
                  a.href = url;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  setDownloadStatus({ ok: true, msg: `Exported ${fname} (${(blob.size / 1024).toFixed(1)} KB)` });
                  setTimeout(() => setDownloadStatus(null), 8000);
                } catch (e: any) {
                  setDownloadStatus({ ok: false, msg: e.message });
                  setTimeout(() => setDownloadStatus(null), 8000);
                } finally {
                  setDownloading(false);
                }
              }}
              disabled={downloading}
              className="px-3 py-1.5 bg-cyan-600/20 border border-cyan-600/40 hover:bg-cyan-600/30 rounded text-cyan-400 text-xs font-medium transition-colors disabled:opacity-50 flex items-center gap-1.5"
            >
              {downloading ? (
                <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Compiling...</>
              ) : (
                <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg> Download Data</>
              )}
            </button>
            <button
              data-testid="button-generate-report"
              disabled={!selectedCase || generatingReport}
              onClick={async () => {
                if (!selectedCase) return;
                setGeneratingReport(true);
                try {
                  const resp = await fetch(`/api/forensic/command-center/generate-report?caseId=${selectedCase}`, { credentials: "include" });
                  if (!resp.ok) { const err = await resp.json().catch(() => ({ message: "Failed" })); throw new Error(err.message); }
                  const blob = await resp.blob();
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  const disposition = resp.headers.get("content-disposition");
                  const filenameMatch = disposition?.match(/filename="(.+?)"/);
                  a.download = filenameMatch?.[1] || `forensic-report-${new Date().toISOString().split("T")[0]}.html`;
                  a.href = url;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                } catch (e: any) {
                  setDownloadStatus({ ok: false, msg: e.message });
                  setTimeout(() => setDownloadStatus(null), 8000);
                } finally {
                  setGeneratingReport(false);
                }
              }}
              className="px-3 py-1.5 bg-amber-600/20 border border-amber-600/40 hover:bg-amber-600/30 disabled:opacity-50 rounded text-amber-400 text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              {generatingReport ? (
                <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Generating...</>
              ) : (
                <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg> Forensic Report</>
              )}
            </button>
            <button
              data-testid="button-rescan-all"
              disabled={rescanning || !selectedCase}
              onClick={async () => {
                if (!selectedCase) return;
                setRescanning(true);
                setRescanResult(null);
                try {
                  const resp = await fetch("/api/forensic/command-center/rescan-all", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    credentials: "include",
                    body: JSON.stringify({ caseId: selectedCase }),
                  });
                  const data = await resp.json();
                  if (resp.ok) {
                    const parts: string[] = [];
                    if (data.osint) parts.push(`OSINT (${data.osint.totalAddresses} addrs)`);
                    if (data.originTraces?.length) parts.push(`${data.originTraces.length} origin trace(s)`);
                    if (data.networkScans?.length) parts.push(`${data.networkScans.length} network scan(s)`);
                    setRescanResult({ ok: true, msg: `Scans launched: ${parts.join(", ")}` });
                    setTimeout(() => {
                      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/stats"] });
                      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
                    }, 5000);
                  } else {
                    setRescanResult({ ok: false, msg: data.message || "Scan failed" });
                  }
                } catch (e: any) {
                  setRescanResult({ ok: false, msg: e.message });
                }
                setRescanning(false);
                setTimeout(() => setRescanResult(null), 15000);
              }}
              className="px-3 py-1.5 bg-purple-600/20 border border-purple-600/40 hover:bg-purple-600/30 disabled:opacity-50 rounded text-purple-400 text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              {rescanning ? (
                <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Scanning...</>
              ) : (
                <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg> Rescan All</>
              )}
            </button>
            <button
              data-testid="button-send-report"
              onClick={() => {
                setShowSendReport(true);
                setSendReportResult(null);
                setRefreshIntelResult(null);
                fetch("/api/forensic/command-center/report-email-info", { credentials: "include" })
                  .then(r => r.json())
                  .then(d => setReportEmailInfo(d))
                  .catch(() => {});
                if (selectedCase) {
                  fetch(`/api/forensic/command-center/report-data-summary?caseId=${selectedCase}`, { credentials: "include" })
                    .then(r => r.json())
                    .then(d => setReportDataSummary(d))
                    .catch(() => {});
                }
              }}
              className="px-3 py-1.5 bg-amber-600/20 border border-amber-600/40 hover:bg-amber-600/30 rounded text-amber-400 text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg> Send Report
            </button>
            {downloadStatus && (
              <div className={`text-xs px-2 py-1 rounded ${downloadStatus.ok ? "text-green-400 bg-green-900/30 border border-green-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`} data-testid="text-download-status">
                {downloadStatus.msg}
              </div>
            )}
            {rescanResult && (
              <div className={`text-xs px-2 py-1 rounded ${rescanResult.ok ? "text-purple-400 bg-purple-900/30 border border-purple-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`} data-testid="text-rescan-status">
                {rescanResult.msg}
              </div>
            )}
            <div className="text-xs text-gray-500">
              Last scan: {stats?.lastCheck ? timeAgo(stats.lastCheck) : "Pending..."}
            </div>
            <div className={`w-3 h-3 rounded-full ${stats?.lastCheck ? "bg-green-500 animate-pulse" : "bg-yellow-500"}`} data-testid="status-monitor" />
          </div>
        </div>

        <div className="max-w-[1800px] mx-auto px-4 flex gap-1 pb-0">
          {tabs.map(tab => (
            <button
              key={tab.id}
              data-testid={`button-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors relative ${
                activeTab === tab.id
                  ? "bg-[#161b22] text-cyan-400 border-t border-x border-cyan-800/40"
                  : "text-gray-500 hover:text-gray-300 hover:bg-[#161b22]/50"
              }`}
            >
              {tab.label}
              {tab.badge ? (
                <span className="ml-1.5 px-1.5 py-0.5 bg-red-600 text-white text-[10px] rounded-full">
                  {tab.badge}
                </span>
              ) : null}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-[1800px] mx-auto p-4">
        <AnimatePresence mode="wait">
          {activeTab === "dashboard" && (
            <motion.div key="dashboard" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                {[
                  { label: "Active Cases", value: stats?.activeCases || 0, color: "cyan" },
                  { label: "Wallets Monitored", value: stats?.activeMonitoring || 0, color: "blue" },
                  { label: "Active Alerts", value: stats?.unacknowledgedAlerts || 0, color: stats?.criticalAlerts ? "red" : "yellow" },
                  { label: "Total Value Tracked", value: formatUsd(stats?.totalValueTracked), color: "green" },
                  { label: "Customer Vaults", value: `${customerStats.totalVaults || 0} (${customerStats.triggeredVaults || 0} trig)`, color: "emerald" },
                ].map((stat, i) => (
                  <div key={i} className={`bg-[#161b22] rounded-xl p-4 border border-${stat.color}-900/30`} data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, "-")}`}>
                    <div className="text-xs text-gray-500 mb-1">{stat.label}</div>
                    <div className={`text-2xl font-bold text-${stat.color}-400`}>{stat.value}</div>
                  </div>
                ))}
              </div>

              <div className="bg-[#161b22] rounded-xl border border-red-900/40 p-4 mb-4" data-testid="section-live-intel">
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-amber-400">LIVE INTELLIGENCE FEED</h3>
                  <span className="ml-auto text-[10px] text-gray-600">Auto-updated</span>
                </div>
                <div className="space-y-2 max-h-[320px] overflow-y-auto">
                  {[
                    { time: "2026-03-09 01:11", severity: "critical" as const, title: "EMERGENCY: POI Wallet Active NOW", detail: "POI (0xf70da978...) executing rapid-fire transfers across 5 chains simultaneously. Using Relay Protocol for cross-chain movement. $65K+ flowing through RelayDepository.", tag: "LIVE" },
                    { time: "2026-03-09 01:10", severity: "critical" as const, title: "Relay Protocol Infrastructure Identified", detail: "POI using RelayRouter (0xF504...), RelayRouterV3 (0xb92f...), RelayDepository (0x4cD0...) for cross-chain USDC/USDT movement.", tag: "NEW" },
                    { time: "2026-03-09 01:03", severity: "high" as const, title: "$50,159 USDC Inflow to POI on Arbitrum", detail: "RelayDepository sent $50,159.80 USDC + $4,420 USDT0 to POI wallet on Arbitrum. Funds being distributed to 17 new wallets.", tag: "TRACED" },
                    { time: "2026-03-09 01:02", severity: "high" as const, title: "17 New Destination Wallets Identified", detail: "POI distributing funds to 17 previously unknown wallets across Ethereum and Arbitrum. Largest: $7,963 USDC to 0xf677c5fb60Cf...", tag: "NEW" },
                    { time: "2026-03-09 00:45", severity: "high" as const, title: "Report #8 Sent to SEAL 911 + Sillytuna", detail: "Emergency live activity alert with all transaction hashes sent to tips@securityalliance.org and sillytuna@gmail.com.", tag: "SENT" },
                    { time: "2026-03-08 14:30", severity: "medium" as const, title: "Report #7: Multi-Chain Scan Complete", detail: "66 wallets x 9 chains = 21,878 records collected. POI active on 8 chains. Laundering Hub distributed ~$20M DAI. Sent to SEAL + sillytuna.", tag: "SENT" },
                    { time: "2026-03-08 10:00", severity: "medium" as const, title: "Report #6: Exchange Sweep Complete", detail: "All 66 wallets checked against 60+ KYC exchanges. 5 exchanges identified with 35 interactions. Binance primary cash-out.", tag: "SENT" },
                    { time: "2026-03-07 18:00", severity: "medium" as const, title: "SEAL 911 Evidence Package Delivered", detail: "541.5 KB ZIP with 6 forensic reports sent to tips@securityalliance.org. Complete evidence chain for exchange freezes.", tag: "SENT" },
                    { time: "2026-03-06 22:00", severity: "medium" as const, title: "Crypto.com $155K USDC — Still Unfrozen", detail: "FXUSD trace confirmed $155,017 USDC at Crypto.com wallet 0x65837061... via Relay Proxy. Compliance contact pending.", tag: "ACTION" },
                    { time: "2026-03-05 14:00", severity: "medium" as const, title: "5 UK Forensic Firms Identified", detail: "CEL Solicitors, EMM Legal, CYFOR Secure, Inquesta Forensic, Crypto Legal UK — all verified for victim referral.", tag: "INTEL" },
                  ].map((item, i) => (
                    <div key={i} className={`p-3 rounded-lg border ${item.severity === "critical" ? "bg-red-950/20 border-red-800/40" : item.severity === "high" ? "bg-amber-950/20 border-amber-800/30" : "bg-[#0d1117] border-gray-800/30"}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${item.severity === "critical" ? "bg-red-600 text-white" : item.severity === "high" ? "bg-amber-600 text-white" : "bg-gray-700 text-gray-300"}`}>{item.severity.toUpperCase()}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${item.tag === "LIVE" ? "bg-red-500 text-white animate-pulse" : item.tag === "NEW" ? "bg-cyan-600 text-white" : item.tag === "SENT" ? "bg-green-700 text-white" : item.tag === "TRACED" ? "bg-purple-600 text-white" : item.tag === "ACTION" ? "bg-amber-600 text-white" : "bg-blue-700 text-white"}`}>{item.tag}</span>
                        <span className="text-[10px] text-gray-600 ml-auto">{item.time}</span>
                      </div>
                      <div className="text-sm font-medium text-gray-200">{item.title}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{item.detail}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-4 mb-4" data-testid="section-reports-sent">
                <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 mb-3">FORENSIC REPORTS DELIVERED</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { num: 8, title: "Reports Sent", color: "cyan" },
                    { num: 2, title: "Recipients", color: "green" },
                    { num: 9, title: "Chains Scanned", color: "purple" },
                    { num: 66, title: "Wallets Tracked", color: "amber" },
                  ].map((s, i) => (
                    <div key={i} className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/30 text-center">
                      <div className={`text-2xl font-bold text-${s.color}-400`}>{s.num}</div>
                      <div className="text-[10px] text-gray-500 mt-1">{s.title}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/30">
                    <div className="text-xs text-green-400 font-bold mb-1">SEAL 911</div>
                    <div className="text-[10px] text-gray-500">tips@securityalliance.org</div>
                    <div className="text-[10px] text-gray-400 mt-1">Reports #1-#8 delivered</div>
                  </div>
                  <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/30">
                    <div className="text-xs text-green-400 font-bold mb-1">Victim (@sillytuna)</div>
                    <div className="text-[10px] text-gray-500">sillytuna@gmail.com</div>
                    <div className="text-[10px] text-gray-400 mt-1">Reports #1-#8 delivered</div>
                  </div>
                </div>
              </div>

              <div className="bg-[#161b22] rounded-xl border border-purple-900/30 p-4 mb-4" data-testid="section-investigation-tech">
                <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400 mb-3">INVESTIGATION TECHNOLOGIES DEPLOYED</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {[
                    { name: "Multi-Chain Lean Scanner™", desc: "66 wallets × 9 chains = 21,878 records. Parallel scanning with rate limiting across Ethereum, BSC, Polygon, Arbitrum, Optimism, Avalanche, Solana, Base.", status: "active", metric: "21,878 records" },
                    { name: "Relay Protocol Tracker™", desc: "Identified RelayRouter, RelayRouterV3, RelayDepository contracts used for cross-chain USDC/USDT laundering. Real-time monitoring of relay infrastructure.", status: "active", metric: "3 contracts" },
                    { name: "Crypto.com Chain Tracer™", desc: "Full FXUSD→USDC conversion chain traced through Relay Proxy to Crypto.com hot wallet. $155K identified for freeze request.", status: "complete", metric: "$155K traced" },
                    { name: "Exchange Sweep Engine™", desc: "All case wallets checked against 60+ KYC exchanges. Identified Binance, Crypto.com, ChangeNOW, FixedFloat, TradeOgre interactions.", status: "complete", metric: "5 exchanges" },
                    { name: "Emergency Alert System™", desc: "Real-time detection of POI fund movements with instant report generation and delivery to SEAL 911 + victim within minutes.", status: "active", metric: "8 reports sent" },
                    { name: "Deep Trace Engine™", desc: "Multi-hop transaction tracing across all chains. Follows token flows through mixers, bridges, DEXes, and relay protocols automatically.", status: "active", metric: "596 pairs" },
                    { name: "FXUSD Source Tracer™", desc: "Traced FXUSD stablecoin flows from source through conversion to USDC via DeFi protocols and relay infrastructure to exchange deposits.", status: "complete", metric: "$155K chain" },
                    { name: "Autonomous Spider Trace™", desc: "Recursive wallet discovery following transaction graphs. Auto-identifies new destination wallets and adds to monitoring.", status: "active", metric: "17 new wallets" },
                    { name: "Alpha Spider Beacon Protocol™", desc: "Cross-chain persistent surveillance beacons deployed on tracked addresses. 5 beacon types monitoring 20+ chains for fund movement.", status: "active", metric: "Multi-chain" },
                    { name: "AUC Transfer Hook Engine™", desc: "Protocol-level hooks on AUC blockchain. Every transaction evaluated against watched/trapped address lists. Auto-propagation of watch lists.", status: "active", metric: "On-chain" },
                    { name: "Laundering Risk Intelligence™", desc: "Tornado Cash DAI detection (17 contracts), Monero conversion tracking (11 on-ramps), DeFi freeze gap analysis for unfreezable tokens.", status: "active", metric: "3 vectors" },
                    { name: "Law Enforcement Briefing™", desc: "Auto-generated 18-slide PPTX presentations explaining forensic technologies for law enforcement. Email delivery via SendGrid.", status: "ready", metric: "18 slides" },
                    { name: "Bounty Recovery System™", desc: "Digital bounty agreement generation with signatures. Manages recovery incentive structures for white-hat negotiations.", status: "ready", metric: "Legal-grade" },
                    { name: "OSINT Intelligence Scanner™", desc: "Open-source intelligence collection from social media, forums, darknet. Identity correlation and attacker profiling.", status: "active", metric: "Multi-source" },
                    { name: "Network Intelligence Engine™", desc: "IP geolocation, device fingerprinting, ISP correlation. Cross-reference attack vectors with known threat actor patterns.", status: "active", metric: "Deep analysis" },
                    { name: "Alpha Phantom Vault Protocol™", desc: "Honeypot decoy wallets with embedded tracking tokens. Detects attacker interaction patterns and wallet discovery.", status: "ready", metric: "Trap system" },
                    { name: "Transaction Origin Intel™", desc: "First-hop analysis identifying original funding sources, exchange withdrawal patterns, and fiat on-ramp identification.", status: "active", metric: "Source trace" },
                    { name: "Cross-Case Intelligence™", desc: "Pattern matching across multiple forensic cases. Identifies shared wallets, common laundering techniques, and repeat offenders.", status: "active", metric: "Pattern DB" },
                  ].map((tech, i) => (
                    <div key={i} className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/30 hover:border-purple-700/40 transition-colors">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-bold text-purple-300">{tech.name}</span>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${tech.status === "active" ? "bg-green-600/20 text-green-400 border border-green-700/30" : tech.status === "complete" ? "bg-cyan-600/20 text-cyan-400 border border-cyan-700/30" : "bg-amber-600/20 text-amber-400 border border-amber-700/30"}`}>
                          {tech.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-[10px] text-gray-500 leading-relaxed mb-1.5">{tech.desc}</div>
                      <div className="text-[10px] text-cyan-400 font-medium">{tech.metric}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 text-center">
                  <span className="text-[10px] text-gray-600">18 Proprietary Technologies Deployed | Alpha Forensic Intelligence Engine™ | Patent Pending</span>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4">
                  <h3 className="text-sm font-bold text-cyan-400 mb-3">RECENT ALERTS</h3>
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {alerts && alerts.length > 0 ? alerts.slice(0, 10).map(alert => (
                      <div key={alert.id} className={`p-3 rounded-lg border ${alert.acknowledged ? "bg-gray-900/30 border-gray-800/30" : "bg-[#0d1117] border-cyan-900/30"}`} data-testid={`alert-${alert.id}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <SeverityBadge severity={alert.severity} />
                          <span className="text-xs text-gray-500">{timeAgo(alert.createdAt)}</span>
                          {!alert.acknowledged && (
                            <button
                              data-testid={`button-ack-${alert.id}`}
                              onClick={() => ackMutation.mutate(alert.id)}
                              className="ml-auto text-xs text-cyan-500 hover:text-cyan-300"
                            >
                              Acknowledge
                            </button>
                          )}
                        </div>
                        <div className="text-sm text-gray-300">{alert.message}</div>
                      </div>
                    )) : (
                      <div className="text-gray-600 text-sm text-center py-8">No alerts yet. Monitor is scanning wallets...</div>
                    )}
                  </div>
                </div>

                <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4">
                  <h3 className="text-sm font-bold text-cyan-400 mb-3">HIGH VALUE WALLETS</h3>
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {wallets?.filter(w => (w.lastKnownBalanceUsd || 0) > 10 || Object.keys(w.lastKnownTokens || {}).length > 0)
                      .sort((a, b) => (b.lastKnownBalanceUsd || 0) - (a.lastKnownBalanceUsd || 0))
                      .slice(0, 10)
                      .map(w => (
                        <div key={w.id} className="p-3 rounded-lg bg-[#0d1117] border border-gray-800/30" data-testid={`wallet-high-${w.id}`}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-gray-200">{w.label || shortenAddr(w.address)}</span>
                            <StatusBadge status={w.status} />
                          </div>
                          <div className="text-xs text-gray-500 font-mono flex items-center gap-1.5">
                            {w.address}
                            <button
                              data-testid={`button-copy-dash-${w.id}`}
                              onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(w.address); setCopiedAddr(w.address); setTimeout(() => setCopiedAddr(null), 2000); }}
                              className="text-[10px] text-cyan-600 hover:text-cyan-400 transition-colors shrink-0"
                            >
                              {copiedAddr === w.address ? "Copied!" : "Copy"}
                            </button>
                          </div>
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="text-sm text-cyan-400">{formatEth(w.lastKnownBalanceEth)} {chainSymbol(w.chain)}</span>
                            {w.lastKnownBalanceUsd != null && <span className="text-sm text-green-400">{formatUsd(w.lastKnownBalanceUsd)}</span>}
                          </div>
                          {w.lastKnownTokens && Object.keys(w.lastKnownTokens).length > 0 && (
                            <div className="mt-1 flex flex-wrap gap-1">
                              {Object.entries(w.lastKnownTokens).map(([sym, val]) => (
                                <span key={sym} className="text-[10px] px-1.5 py-0.5 bg-gray-800 rounded text-gray-400">
                                  {(val as number).toLocaleString(undefined, { maximumFractionDigits: 0 })} {sym}
                                </span>
                              ))}
                            </div>
                          )}
                          <div className="text-[10px] text-gray-600 mt-1">
                            {w.chain} | {w.role} | Checked: {timeAgo(w.lastChecked)}
                          </div>
                        </div>
                      )) || (
                      <div className="text-gray-600 text-sm text-center py-8">Waiting for first scan...</div>
                    )}
                  </div>
                </div>
              </div>

              {wallets && wallets.length > 0 && alerts && alerts.length > 0 && (
                <DashboardCharts wallets={wallets} alerts={alerts} cases={cases || []} stats={stats} />
              )}

              {wallets && wallets.length > 1 && (() => {
                const chainHops: { from: string; to: string; count: number }[] = [];
                const chainWalletCounts: Record<string, number> = {};
                const chainValueTotals: Record<string, number> = {};
                for (const w of wallets) {
                  chainWalletCounts[w.chain] = (chainWalletCounts[w.chain] || 0) + 1;
                  chainValueTotals[w.chain] = (chainValueTotals[w.chain] || 0) + ((w.lastKnownBalanceUsd as number) || 0);
                }
                const sorted = [...wallets].sort((a, b) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime());
                for (let i = 1; i < sorted.length; i++) {
                  if (sorted[i].chain !== sorted[i - 1].chain) {
                    const ex = chainHops.find(h => h.from === sorted[i - 1].chain && h.to === sorted[i].chain);
                    if (ex) ex.count++;
                    else chainHops.push({ from: sorted[i - 1].chain, to: sorted[i].chain, count: 1 });
                  }
                }
                const uniqueChains = Object.keys(chainWalletCounts);
                if (uniqueChains.length < 2) return null;
                return (
                  <div className="mt-4 bg-[#161b22] rounded-xl border border-gray-800/50 p-4" data-testid="section-chain-hopping">
                    <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-3">CHAIN HOPPING VISUALIZATION</h3>
                    <div className="flex items-center gap-2 flex-wrap mb-4">
                      {uniqueChains.map((chain, i) => (
                        <div key={chain} className="flex items-center gap-2">
                          {i > 0 && <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>}
                          <div className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border border-purple-600/40 rounded-lg px-4 py-3 text-center min-w-[120px]">
                            <div className="text-sm font-bold text-purple-300">{chain}</div>
                            <div className="text-[10px] text-gray-500">{chainWalletCounts[chain]} wallet{chainWalletCounts[chain] > 1 ? "s" : ""}</div>
                            <div className="text-xs text-green-400 mt-0.5">${chainValueTotals[chain]?.toLocaleString(undefined, { maximumFractionDigits: 0 }) || "0"}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    {chainHops.length > 0 && (
                      <div className="space-y-1.5">
                        <div className="text-xs text-gray-500 font-semibold mb-1">Detected Cross-Chain Hops:</div>
                        {chainHops.map((hop, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs bg-[#0d1117] rounded-lg px-3 py-2 border border-gray-800/30">
                            <span className="text-purple-400 font-medium">{hop.from}</span>
                            <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                            <span className="text-blue-400 font-medium">{hop.to}</span>
                            <span className="ml-auto text-gray-600">{hop.count} hop{hop.count > 1 ? "s" : ""}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}

              <div className="mt-4 bg-[#161b22] rounded-xl border border-gray-800/50 p-4">
                <h3 className="text-sm font-bold text-cyan-400 mb-3">CASES</h3>
                <div className="space-y-2">
                  {cases?.map(c => (
                    <div
                      key={c.id}
                      className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                        selectedCase === c.id ? "bg-cyan-900/20 border-cyan-700/40" : "bg-[#0d1117] border-gray-800/30 hover:border-gray-700/50"
                      }`}
                      onClick={() => setSelectedCase(selectedCase === c.id ? null : c.id)}
                      data-testid={`case-${c.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-medium text-gray-200">{c.caseName}</span>
                          {c.victimHandle && <span className="ml-2 text-sm text-gray-500">{c.victimHandle}</span>}
                        </div>
                        <div className="flex items-center gap-3">
                          {c.totalStolenUsd && <span className="text-red-400 font-bold">{formatUsd(c.totalStolenUsd)} stolen</span>}
                          <StatusBadge status={c.status} />
                        </div>
                      </div>
                      {c.description && <div className="text-xs text-gray-500 mt-1 line-clamp-2">{c.description}</div>}
                    </div>
                  )) || <div className="text-gray-600">No cases found</div>}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "wallets" && (
            <motion.div key="wallets" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {wallets && wallets.length > 0 && <WalletCharts wallets={wallets} />}

              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-cyan-400">Monitored Wallets ({
                  wallets ? (walletChainFilter !== "all" || walletRoleFilter !== "all" || walletStatusFilter !== "all"
                    ? `${wallets.filter(w => (walletChainFilter === "all" || w.chain === walletChainFilter) && (walletRoleFilter === "all" || w.role === walletRoleFilter) && (walletStatusFilter === "all" || w.status === walletStatusFilter)).length} / ${wallets.length}`
                    : wallets.length)
                  : 0
                })</h2>
                <div className="flex items-center gap-2">
                  {selectedCase && wallets && wallets.length > 0 && (
                    <button
                      data-testid="button-rescan-all-wallets"
                      onClick={async () => {
                        setRescanning(true);
                        setRescanResult(null);
                        try {
                          const resp = await fetch("/api/forensic/command-center/rescan-all", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            credentials: "include",
                            body: JSON.stringify({ caseId: selectedCase }),
                          });
                          const data = await resp.json();
                          if (resp.ok) {
                            setRescanResult({ ok: true, msg: `Monitoring scans launched for all ${wallets.length} wallets` });
                            queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
                          } else {
                            setRescanResult({ ok: false, msg: data.message || "Failed" });
                          }
                        } catch (e: any) {
                          setRescanResult({ ok: false, msg: e.message });
                        }
                        setRescanning(false);
                      }}
                      disabled={rescanning}
                      className="px-3 py-1.5 bg-cyan-600/20 border border-cyan-600/40 hover:bg-cyan-600/30 disabled:opacity-50 rounded text-cyan-400 text-xs font-medium transition-colors flex items-center gap-1.5"
                    >
                      {rescanning ? (
                        <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Scanning...</>
                      ) : (
                        <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg> Rescan All Wallets</>
                      )}
                    </button>
                  )}
                  {selectedCase && (
                    <button
                      data-testid="button-clear-filter"
                      onClick={() => setSelectedCase(null)}
                      className="text-sm text-gray-500 hover:text-gray-300"
                    >
                      Show all cases
                    </button>
                  )}
                </div>
              </div>
              {rescanResult && (
                <div className={`mb-3 text-xs px-3 py-2 rounded ${rescanResult.ok ? "text-green-400 bg-green-900/30 border border-green-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`}>
                  {rescanResult.msg}
                </div>
              )}

              <div className="bg-[#161b22] rounded-xl border border-gray-800/50 mb-4 p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-gray-400">ADD WALLET TO MONITOR</h3>
                  <button
                    data-testid="button-toggle-bulk"
                    onClick={() => setShowBulkAdd(!showBulkAdd)}
                    className="text-xs text-cyan-500 hover:text-cyan-300"
                  >
                    {showBulkAdd ? "Single Add" : "Bulk Add"}
                  </button>
                </div>
                {!showBulkAdd ? (
                  <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
                    <input
                      data-testid="input-wallet-address"
                      placeholder="0x address..."
                      value={newWallet.address}
                      onChange={e => setNewWallet(p => ({ ...p, address: e.target.value, chain: detectChainFromAddress(e.target.value) }))}
                      className="col-span-2 px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                    />
                    <select
                      data-testid="select-chain"
                      value={newWallet.chain}
                      onChange={e => setNewWallet(p => ({ ...p, chain: e.target.value }))}
                      className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                    >
                      {ALL_CHAIN_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                    <input
                      data-testid="input-wallet-role"
                      placeholder="Role (e.g. attacker, bridge, mixer)..."
                      value={newWallet.role}
                      onChange={e => setNewWallet(p => ({ ...p, role: e.target.value }))}
                      className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                    />
                    <input
                      data-testid="input-wallet-label"
                      placeholder="Label..."
                      value={newWallet.label}
                      onChange={e => setNewWallet(p => ({ ...p, label: e.target.value }))}
                      className="px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                    />
                    <button
                      data-testid="button-add-wallet"
                      onClick={() => {
                        if (newWallet.address && selectedCase) {
                          addWalletMutation.mutate({ ...newWallet, caseId: selectedCase });
                        }
                      }}
                      disabled={!newWallet.address || !selectedCase || addWalletMutation.isPending}
                      className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded text-sm font-medium"
                    >
                      {addWalletMutation.isPending ? "Adding..." : "Add"}
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="text-xs text-gray-500 mb-2">Paste wallet addresses, one per line. Format: <span className="text-cyan-500">address, label, role, chain</span> (only address required)</div>
                    <textarea
                      data-testid="input-bulk-wallets"
                      value={bulkWallets}
                      onChange={e => setBulkWallets(e.target.value)}
                      placeholder={"0xabc123..., Attacker Main, attacker, ethereum\n0xdef456..., Bridge Wallet, bridge, arbitrum\n0x789abc..."}
                      rows={6}
                      className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-cyan-500 outline-none resize-y"
                    />
                    <div className="flex items-center justify-between mt-2">
                      <div className="text-xs text-gray-600">
                        {bulkWallets.trim() ? `${bulkWallets.trim().split("\n").filter(l => l.trim()).length} wallets ready` : ""}
                      </div>
                      <button
                        data-testid="button-bulk-add"
                        onClick={bulkAddWallets}
                        disabled={!selectedCase || !bulkWallets.trim()}
                        className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded text-sm font-medium"
                      >
                        Add All Wallets
                      </button>
                    </div>
                  </div>
                )}
                {!selectedCase && <div className="text-xs text-yellow-500 mt-2">Select a case from the dropdown at the top to add wallets</div>}
              </div>

              {wallets && wallets.length > 0 && (() => {
                const chainCounts = new Map<string, number>();
                const roleCounts = new Map<string, number>();
                const statusCounts = new Map<string, number>();
                for (const w of wallets) {
                  chainCounts.set(w.chain, (chainCounts.get(w.chain) || 0) + 1);
                  if (w.role) roleCounts.set(w.role, (roleCounts.get(w.role) || 0) + 1);
                  statusCounts.set(w.status, (statusCounts.get(w.status) || 0) + 1);
                }
                const sortedChains = [...chainCounts.entries()].sort((a, b) => b[1] - a[1]);
                const sortedRoles = [...roleCounts.entries()].sort((a, b) => b[1] - a[1]);
                const sortedStatuses = [...statusCounts.entries()].sort((a, b) => b[1] - a[1]);
                const chainLabel = (c: string) => ALL_CHAIN_OPTIONS.find(o => o.value === c)?.label || c;
                const filteredCount = wallets.filter(w =>
                  (walletChainFilter === "all" || w.chain === walletChainFilter) &&
                  (walletRoleFilter === "all" || w.role === walletRoleFilter) &&
                  (walletStatusFilter === "all" || w.status === walletStatusFilter)
                ).length;
                return (
                  <div className="bg-[#161b22] rounded-xl border border-gray-800/50 mb-4 p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Chain:</span>
                      <button
                        data-testid="filter-chain-all"
                        onClick={() => setWalletChainFilter("all")}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletChainFilter === "all" ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All ({wallets.length})
                      </button>
                      {sortedChains.map(([chain, count]) => (
                        <button
                          key={chain}
                          data-testid={`filter-chain-${chain}`}
                          onClick={() => setWalletChainFilter(walletChainFilter === chain ? "all" : chain)}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletChainFilter === chain ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {chainLabel(chain)} ({count})
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Role:</span>
                      <button
                        data-testid="filter-role-all"
                        onClick={() => setWalletRoleFilter("all")}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletRoleFilter === "all" ? "bg-purple-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All
                      </button>
                      {sortedRoles.slice(0, 12).map(([role, count]) => (
                        <button
                          key={role}
                          data-testid={`filter-role-${role}`}
                          onClick={() => setWalletRoleFilter(walletRoleFilter === role ? "all" : role)}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletRoleFilter === role ? "bg-purple-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {role} ({count})
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Status:</span>
                      <button
                        data-testid="filter-status-all"
                        onClick={() => setWalletStatusFilter("all")}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletStatusFilter === "all" ? "bg-green-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All
                      </button>
                      {sortedStatuses.map(([status, count]) => (
                        <button
                          key={status}
                          data-testid={`filter-status-${status}`}
                          onClick={() => setWalletStatusFilter(walletStatusFilter === status ? "all" : status)}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${walletStatusFilter === status ? "bg-green-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {status} ({count})
                        </button>
                      ))}
                      {(walletChainFilter !== "all" || walletRoleFilter !== "all" || walletStatusFilter !== "all") && (
                        <span className="ml-auto text-xs text-cyan-400 font-medium">
                          Showing {filteredCount} of {wallets.length} wallets
                        </span>
                      )}
                    </div>
                  </div>
                );
              })()}

              <div className="bg-[#161b22] rounded-xl border border-gray-800/50 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" data-testid="table-wallets">
                    <thead>
                      <tr className="border-b border-gray-800/50 text-gray-500 text-xs">
                        {[
                          { key: "label", label: "Label", align: "left" },
                          { key: "address", label: "Address", align: "left" },
                          { key: "chain", label: "Chain", align: "left" },
                          { key: "role", label: "Role", align: "left" },
                          { key: "balance", label: "ETH Balance", align: "right" },
                          { key: "usd", label: "USD Value", align: "right" },
                          { key: "tokens", label: "Tokens", align: "left" },
                          { key: "lastChecked", label: "Last Checked", align: "left" },
                          { key: "status", label: "Status", align: "left" },
                        ].map(col => (
                          <th
                            key={col.key}
                            data-testid={`sort-wallets-${col.key}`}
                            className={`px-3 py-2 text-${col.align} cursor-pointer hover:text-cyan-400 transition-colors select-none whitespace-nowrap`}
                            onClick={() => {
                              if (walletSortKey === col.key) setWalletSortDir(d => d === "asc" ? "desc" : "asc");
                              else { setWalletSortKey(col.key); setWalletSortDir(col.key === "usd" || col.key === "balance" || col.key === "tokens" ? "desc" : "asc"); }
                            }}
                          >
                            {col.label}
                            {walletSortKey === col.key && (
                              <span className="ml-1 text-cyan-400">{walletSortDir === "asc" ? "▲" : "▼"}</span>
                            )}
                          </th>
                        ))}
                        <th className="px-3 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(wallets ? [...wallets].filter((w: any) =>
                        (walletChainFilter === "all" || w.chain === walletChainFilter) &&
                        (walletRoleFilter === "all" || w.role === walletRoleFilter) &&
                        (walletStatusFilter === "all" || w.status === walletStatusFilter)
                      ).sort((a: any, b: any) => {
                        let va: any, vb: any;
                        switch (walletSortKey) {
                          case "label": va = (a.label || "").toLowerCase(); vb = (b.label || "").toLowerCase(); break;
                          case "address": va = a.address.toLowerCase(); vb = b.address.toLowerCase(); break;
                          case "chain": va = a.chain.toLowerCase(); vb = b.chain.toLowerCase(); break;
                          case "role": va = (a.role || "").toLowerCase(); vb = (b.role || "").toLowerCase(); break;
                          case "balance": va = a.lastKnownBalanceEth || 0; vb = b.lastKnownBalanceEth || 0; break;
                          case "usd": va = a.lastKnownBalanceUsd || 0; vb = b.lastKnownBalanceUsd || 0; break;
                          case "tokens": va = a.lastKnownTokens ? Object.keys(a.lastKnownTokens).length : 0; vb = b.lastKnownTokens ? Object.keys(b.lastKnownTokens).length : 0; break;
                          case "lastChecked": va = a.lastChecked || ""; vb = b.lastChecked || ""; break;
                          case "status": va = a.status || ""; vb = b.status || ""; break;
                          default: va = 0; vb = 0;
                        }
                        if (typeof va === "string") return walletSortDir === "asc" ? va.localeCompare(vb) : vb.localeCompare(va);
                        return walletSortDir === "asc" ? va - vb : vb - va;
                      }) : []).map((w: any) => (
                        <tr key={w.id} className="border-b border-gray-800/20 hover:bg-gray-800/20" data-testid={`row-wallet-${w.id}`}>
                          <td className="px-3 py-2 text-gray-200 font-medium">{w.label || "-"}</td>
                          <td className="px-3 py-2 font-mono text-xs text-cyan-400">
                            <a href={explorerLink(w.chain, "address", w.address)} target="_blank" rel="noopener noreferrer" className="hover:underline">
                              {shortenAddr(w.address)}
                            </a>
                          </td>
                          <td className="px-3 py-2 text-gray-400">{w.chain}</td>
                          <td className="px-3 py-2 text-gray-400">{w.role || "-"}</td>
                          <td className="px-3 py-2 text-right text-cyan-400">{formatEth(w.lastKnownBalanceEth)} {chainSymbol(w.chain)}</td>
                          <td className="px-3 py-2 text-right text-green-400">{w.lastKnownBalanceUsd != null ? formatUsd(w.lastKnownBalanceUsd) : "-"}</td>
                          <td className="px-3 py-2">
                            {w.lastKnownTokens && Object.keys(w.lastKnownTokens).length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {Object.entries(w.lastKnownTokens).slice(0, 3).map(([sym, val]) => (
                                  <span key={sym} className="text-[10px] px-1 py-0.5 bg-gray-800 rounded text-gray-400">
                                    {(val as number) > 1000 ? `${((val as number)/1000).toFixed(0)}k` : (val as number).toFixed(1)} {sym}
                                  </span>
                                ))}
                                {Object.keys(w.lastKnownTokens).length > 3 && (
                                  <span className="text-[10px] text-gray-600">+{Object.keys(w.lastKnownTokens).length - 3}</span>
                                )}
                              </div>
                            ) : <span className="text-gray-600">-</span>}
                          </td>
                          <td className="px-3 py-2 text-xs text-gray-500">{timeAgo(w.lastChecked)}</td>
                          <td className="px-3 py-2"><StatusBadge status={w.status} /></td>
                          <td className="px-3 py-2 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                data-testid={`button-entity-wallet-${w.id}`}
                                onClick={() => setEntityWallet(entityWallet === w.id ? null : w.id)}
                                className={`text-xs transition-colors ${entityWallet === w.id ? "text-cyan-300 font-bold" : "text-cyan-500/60 hover:text-cyan-400"}`}
                                title="View entity dashboard"
                              >
                                {entityWallet === w.id ? "Close" : "View"}
                              </button>
                              <button
                                data-testid={`button-copy-wallet-${w.id}`}
                                onClick={() => { navigator.clipboard.writeText(w.address); setCopiedAddr(w.address); setTimeout(() => setCopiedAddr(null), 2000); }}
                                className="text-xs text-cyan-500/60 hover:text-cyan-400 transition-colors"
                                title="Copy full address"
                              >
                                {copiedAddr === w.address ? "Copied!" : "Copy"}
                              </button>
                              <button
                                data-testid={`button-quickscan-wallet-${w.id}`}
                                onClick={async () => {
                                  setQuickScanWallet(w.id);
                                  try {
                                    const resp = await fetch("/api/forensic/command-center/quick-scan", {
                                      method: "POST",
                                      headers: { "Content-Type": "application/json" },
                                      credentials: "include",
                                      body: JSON.stringify({ walletId: w.id, address: w.address, chain: w.chain }),
                                    });
                                    if (resp.status === 403 || resp.status === 400) {
                                      setQuickScanWallet(null);
                                      return;
                                    }
                                    const data = await resp.json();
                                    if (resp.ok) {
                                      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
                                      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                    }
                                  } catch {}
                                  setQuickScanWallet(null);
                                }}
                                disabled={quickScanWallet === w.id}
                                className="text-xs text-purple-500/60 hover:text-purple-400 transition-colors disabled:animate-pulse"
                                title="Quick scan this wallet"
                              >
                                {quickScanWallet === w.id ? "Scanning..." : "Scan"}
                              </button>
                              <button
                                data-testid={`button-alert-config-${w.id}`}
                                onClick={() => setAlertConfigWallet(alertConfigWallet === w.id ? null : w.id)}
                                className="text-xs text-amber-500/60 hover:text-amber-400 transition-colors"
                                title="Configure alerts"
                              >
                                Alerts
                              </button>
                              <button
                                data-testid={`button-delete-wallet-${w.id}`}
                                onClick={() => { if (confirm(`Remove ${w.label || shortenAddr(w.address)} from monitoring?`)) deleteWalletMutation.mutate(w.id); }}
                                className="text-xs text-red-500/60 hover:text-red-400 transition-colors"
                              >
                                Remove
                              </button>
                            </div>
                            {alertConfigWallet === w.id && (
                              <div className="mt-2 p-3 bg-[#0d1117] border border-amber-900/40 rounded-lg text-left" onClick={e => e.stopPropagation()}>
                                <div className="text-xs font-semibold text-amber-400 mb-2">Alert Configuration — {w.label || shortenAddr(w.address)}</div>
                                <div className="space-y-2">
                                  <label className="flex items-center gap-2 text-xs text-gray-400">
                                    <input type="checkbox" checked={alertConfigs[w.id]?.onBalanceChange ?? true} onChange={e => setAlertConfigs(p => ({ ...p, [w.id]: { ...p[w.id], onBalanceChange: e.target.checked } }))} className="rounded border-gray-600 bg-gray-800 text-amber-500" />
                                    Alert on any balance change
                                  </label>
                                  <label className="flex items-center gap-2 text-xs text-gray-400">
                                    <input type="checkbox" checked={alertConfigs[w.id]?.onLargeTransfer ?? true} onChange={e => setAlertConfigs(p => ({ ...p, [w.id]: { ...p[w.id], onLargeTransfer: e.target.checked } }))} className="rounded border-gray-600 bg-gray-800 text-amber-500" />
                                    Alert on large transfers
                                  </label>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs text-gray-500">Min USD threshold:</span>
                                    <input
                                      type="number"
                                      value={alertConfigs[w.id]?.minUsdThreshold ?? 100}
                                      onChange={e => setAlertConfigs(p => ({ ...p, [w.id]: { ...p[w.id], minUsdThreshold: parseFloat(e.target.value) || 0 } }))}
                                      className="w-24 px-2 py-1 bg-gray-800 border border-gray-700 rounded text-xs text-gray-200"
                                    />
                                  </div>
                                  <label className="flex items-center gap-2 text-xs text-gray-400">
                                    <input type="checkbox" checked={alertConfigs[w.id]?.onNewTokens ?? true} onChange={e => setAlertConfigs(p => ({ ...p, [w.id]: { ...p[w.id], onNewTokens: e.target.checked } }))} className="rounded border-gray-600 bg-gray-800 text-amber-500" />
                                    Alert on new token appearances
                                  </label>
                                  <label className="flex items-center gap-2 text-xs text-gray-400">
                                    <input type="checkbox" checked={alertConfigs[w.id]?.onChainHop ?? false} onChange={e => setAlertConfigs(p => ({ ...p, [w.id]: { ...p[w.id], onChainHop: e.target.checked } }))} className="rounded border-gray-600 bg-gray-800 text-amber-500" />
                                    Alert on cross-chain transfers
                                  </label>
                                </div>
                                <div className="flex gap-2 mt-3">
                                  <button
                                    data-testid={`button-save-alert-config-${w.id}`}
                                    onClick={async () => {
                                      try {
                                        await fetch("/api/forensic/command-center/wallet-alert-config", {
                                          method: "POST",
                                          headers: { "Content-Type": "application/json" },
                                          credentials: "include",
                                          body: JSON.stringify({ walletId: w.id, config: alertConfigs[w.id] || {} }),
                                        });
                                        setAlertConfigWallet(null);
                                      } catch {}
                                    }}
                                    className="px-3 py-1 bg-amber-600/30 border border-amber-600/40 hover:bg-amber-600/40 text-amber-400 rounded text-xs"
                                  >
                                    Save
                                  </button>
                                  <button onClick={() => setAlertConfigWallet(null)} className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded text-xs">Cancel</button>
                                </div>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {entityWallet && wallets && (() => {
                const w = wallets.find(wl => wl.id === entityWallet);
                if (!w) return null;
                return (
                  <div className="mt-4">
                    <EntityDashboard
                      wallet={w}
                      caseId={selectedCase || ""}
                      onClose={() => setEntityWallet(null)}
                      explorerLink={explorerLink}
                    />
                  </div>
                );
              })()}
            </motion.div>
          )}

          {activeTab === "alerts" && (
            <motion.div key="alerts" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {alerts && alerts.length > 0 && <AlertCharts alerts={alerts} />}

              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-cyan-400">Alert Feed ({alerts?.length || 0})</h2>
                <div className="text-sm text-gray-500">
                  {stats?.unacknowledgedAlerts || 0} unacknowledged | {stats?.criticalAlerts || 0} critical
                </div>
              </div>

              {alerts && alerts.length > 0 && (() => {
                const sevCounts = new Map<string, number>();
                const typeCounts = new Map<string, number>();
                let ackCount = 0;
                let unackCount = 0;
                for (const a of alerts) {
                  sevCounts.set(a.severity, (sevCounts.get(a.severity) || 0) + 1);
                  typeCounts.set(a.alertType, (typeCounts.get(a.alertType) || 0) + 1);
                  if (a.acknowledged) ackCount++; else unackCount++;
                }
                const sevOrder = ["critical", "high", "medium", "low"];
                const sortedSevs = sevOrder.filter(s => sevCounts.has(s));
                const sortedTypes = [...typeCounts.entries()].sort((a, b) => b[1] - a[1]);
                const sevColors: Record<string, string> = {
                  critical: "bg-red-600 text-white",
                  high: "bg-orange-500 text-white",
                  medium: "bg-yellow-500 text-black",
                  low: "bg-blue-500 text-white",
                };
                const filteredAlerts = alerts.filter(a =>
                  (alertSeverityFilter === "all" || a.severity === alertSeverityFilter) &&
                  (alertTypeFilter === "all" || a.alertType === alertTypeFilter) &&
                  (alertAckFilter === "all" || (alertAckFilter === "ack" ? a.acknowledged : !a.acknowledged))
                );
                const sortedAlerts = [...filteredAlerts].sort((a, b) => {
                  const ta = new Date(a.createdAt).getTime();
                  const tb = new Date(b.createdAt).getTime();
                  return alertSortDir === "newest" ? tb - ta : ta - tb;
                });
                return (
                  <div className="bg-[#161b22] rounded-xl border border-gray-800/50 mb-4 p-3">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Severity:</span>
                      <button
                        data-testid="filter-alert-sev-all"
                        onClick={() => { setAlertSeverityFilter("all"); setAlertPage(1); setAlertPageInput("1"); }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertSeverityFilter === "all" ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All ({alerts.length})
                      </button>
                      {sortedSevs.map(sev => (
                        <button
                          key={sev}
                          data-testid={`filter-alert-sev-${sev}`}
                          onClick={() => { setAlertSeverityFilter(alertSeverityFilter === sev ? "all" : sev); setAlertPage(1); setAlertPageInput("1"); }}
                          className={`px-2.5 py-1 rounded text-xs font-bold transition-colors ${alertSeverityFilter === sev ? sevColors[sev] : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {sev.toUpperCase()} ({sevCounts.get(sev)})
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Type:</span>
                      <button
                        data-testid="filter-alert-type-all"
                        onClick={() => { setAlertTypeFilter("all"); setAlertPage(1); setAlertPageInput("1"); }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertTypeFilter === "all" ? "bg-purple-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All
                      </button>
                      {sortedTypes.slice(0, 10).map(([type, count]) => (
                        <button
                          key={type}
                          data-testid={`filter-alert-type-${type}`}
                          onClick={() => { setAlertTypeFilter(alertTypeFilter === type ? "all" : type); setAlertPage(1); setAlertPageInput("1"); }}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertTypeFilter === type ? "bg-purple-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {type} ({count})
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Status:</span>
                      <button
                        data-testid="filter-alert-ack-all"
                        onClick={() => { setAlertAckFilter("all"); setAlertPage(1); setAlertPageInput("1"); }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertAckFilter === "all" ? "bg-green-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        All
                      </button>
                      <button
                        data-testid="filter-alert-ack-unack"
                        onClick={() => { setAlertAckFilter(alertAckFilter === "unack" ? "all" : "unack"); setAlertPage(1); setAlertPageInput("1"); }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertAckFilter === "unack" ? "bg-red-500 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        Unacknowledged ({unackCount})
                      </button>
                      <button
                        data-testid="filter-alert-ack-ack"
                        onClick={() => { setAlertAckFilter(alertAckFilter === "ack" ? "all" : "ack"); setAlertPage(1); setAlertPageInput("1"); }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertAckFilter === "ack" ? "bg-green-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                      >
                        Acknowledged ({ackCount})
                      </button>
                      <div className="ml-auto flex items-center gap-2">
                        <span className="text-xs text-gray-500">Sort:</span>
                        <button
                          data-testid="sort-alerts-newest"
                          onClick={() => setAlertSortDir("newest")}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertSortDir === "newest" ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          Newest First
                        </button>
                        <button
                          data-testid="sort-alerts-oldest"
                          onClick={() => setAlertSortDir("oldest")}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertSortDir === "oldest" ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          Oldest First
                        </button>
                        {(alertSeverityFilter !== "all" || alertTypeFilter !== "all" || alertAckFilter !== "all") && (
                          <span className="text-xs text-cyan-400 font-medium">
                            {filteredAlerts.length} of {alerts.length}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {(() => {
                const filtered = alerts && alerts.length > 0 ? [...alerts].filter(a =>
                  (alertSeverityFilter === "all" || a.severity === alertSeverityFilter) &&
                  (alertTypeFilter === "all" || a.alertType === alertTypeFilter) &&
                  (alertAckFilter === "all" || (alertAckFilter === "ack" ? a.acknowledged : !a.acknowledged))
                ).sort((a, b) => {
                  const ta = new Date(a.createdAt).getTime();
                  const tb = new Date(b.createdAt).getTime();
                  return alertSortDir === "newest" ? tb - ta : ta - tb;
                }) : [];
                const totalFiltered = filtered.length;
                const totalPages = Math.max(1, Math.ceil(totalFiltered / alertPageSize));
                const safePage = Math.min(alertPage, totalPages);
                const startIdx = (safePage - 1) * alertPageSize;
                const pageAlerts = filtered.slice(startIdx, startIdx + alertPageSize);

                const PaginationBar = () => totalFiltered > 0 ? (
                  <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-3 flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Show:</span>
                      {[25, 50, 100].map(size => (
                        <button
                          key={size}
                          data-testid={`alert-page-size-${size}`}
                          onClick={() => { setAlertPageSize(size); setAlertPage(1); setAlertPageInput("1"); }}
                          className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${alertPageSize === size ? "bg-cyan-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200"}`}
                        >
                          {size}
                        </button>
                      ))}
                      <span className="text-xs text-gray-500 ml-2">
                        {startIdx + 1}–{Math.min(startIdx + alertPageSize, totalFiltered)} of {totalFiltered} alerts
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        data-testid="alert-page-first"
                        onClick={() => { setAlertPage(1); setAlertPageInput("1"); }}
                        disabled={safePage <= 1}
                        className="px-2 py-1 rounded text-xs font-medium bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        First
                      </button>
                      <button
                        data-testid="alert-page-prev"
                        onClick={() => { const p = Math.max(1, safePage - 1); setAlertPage(p); setAlertPageInput(String(p)); }}
                        disabled={safePage <= 1}
                        className="px-2 py-1 rounded text-xs font-medium bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        ← Prev
                      </button>
                      <span className="text-xs text-gray-500 mx-1">Page</span>
                      <input
                        data-testid="alert-page-input"
                        type="text"
                        value={alertPageInput}
                        onChange={e => setAlertPageInput(e.target.value.replace(/[^0-9]/g, ""))}
                        onKeyDown={e => {
                          if (e.key === "Enter") {
                            const p = Math.max(1, Math.min(totalPages, parseInt(alertPageInput) || 1));
                            setAlertPage(p);
                            setAlertPageInput(String(p));
                          }
                        }}
                        onBlur={() => {
                          const p = Math.max(1, Math.min(totalPages, parseInt(alertPageInput) || 1));
                          setAlertPage(p);
                          setAlertPageInput(String(p));
                        }}
                        className="w-14 px-2 py-1 bg-[#0d1117] border border-gray-700 rounded text-xs text-center text-gray-200 focus:border-cyan-500 outline-none"
                      />
                      <span className="text-xs text-gray-500">of {totalPages}</span>
                      <button
                        data-testid="alert-page-next"
                        onClick={() => { const p = Math.min(totalPages, safePage + 1); setAlertPage(p); setAlertPageInput(String(p)); }}
                        disabled={safePage >= totalPages}
                        className="px-2 py-1 rounded text-xs font-medium bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        Next →
                      </button>
                      <button
                        data-testid="alert-page-last"
                        onClick={() => { setAlertPage(totalPages); setAlertPageInput(String(totalPages)); }}
                        disabled={safePage >= totalPages}
                        className="px-2 py-1 rounded text-xs font-medium bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        Last
                      </button>
                    </div>
                  </div>
                ) : null;

                return (
                  <>
                    <PaginationBar />
                    <div className="space-y-2 mt-2">
                      {pageAlerts.length > 0 ? pageAlerts.map(alert => (
                        <div key={alert.id} className={`bg-[#161b22] rounded-xl border p-4 ${
                          alert.severity === "critical" && !alert.acknowledged
                            ? "border-red-600/50 bg-red-900/10"
                            : alert.acknowledged
                              ? "border-gray-800/30"
                              : "border-cyan-900/30"
                        }`} data-testid={`alert-detail-${alert.id}`}>
                          <div className="flex items-center gap-3 mb-2">
                            <SeverityBadge severity={alert.severity} />
                            <span className="text-xs px-2 py-0.5 bg-gray-800 rounded text-gray-400">{alert.alertType}</span>
                            <span className="text-xs text-gray-500">{new Date(alert.createdAt).toLocaleString()}</span>
                            {alert.acknowledged ? (
                              <span className="ml-auto text-xs text-gray-600">Acknowledged</span>
                            ) : (
                              <button
                                data-testid={`button-ack-detail-${alert.id}`}
                                onClick={() => ackMutation.mutate(alert.id)}
                                className="ml-auto px-3 py-1 bg-cyan-600/20 border border-cyan-600/30 rounded text-xs text-cyan-400 hover:bg-cyan-600/30"
                              >
                                Acknowledge
                              </button>
                            )}
                          </div>
                          <div className="text-sm text-gray-200">{alert.message}</div>
                          {alert.details && (
                            <div className="mt-2 p-2 bg-[#0d1117] rounded text-xs font-mono text-gray-500 max-h-32 overflow-y-auto">
                              {JSON.stringify(alert.details, null, 2)}
                            </div>
                          )}
                        </div>
                      )) : (
                        <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center">
                          <div className="text-gray-600 text-lg mb-2">{alerts && alerts.length > 0 ? "No alerts match filters" : "No alerts yet"}</div>
                          <div className="text-gray-700 text-sm">{alerts && alerts.length > 0
                            ? "Try adjusting the severity, type, or status filters above."
                            : "The wallet monitor will create alerts when it detects any fund movements on tracked wallets."}</div>
                        </div>
                      )}
                    </div>
                    {pageAlerts.length > 0 && <div className="mt-2"><PaginationBar /></div>}
                  </>
                );
              })()}
            </motion.div>
          )}

          {activeTab === "trace" && (
            <motion.div key="trace" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <h2 className="text-lg font-bold text-cyan-400 mb-4">Quick Forensic Trace</h2>

              {selectedCase && wallets && wallets.length > 0 && (
                <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-4 mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-cyan-400">Case Wallets — Select to Trace</h3>
                    <div className="flex gap-2">
                      <button
                        data-testid="button-qt-select-all"
                        onClick={() => setQuickTraceSelected(quickTraceSelected.length === wallets.length ? [] : wallets.map(w => w.address))}
                        className="text-[10px] px-2 py-1 bg-cyan-600/20 border border-cyan-600/30 rounded text-cyan-400 hover:bg-cyan-600/30"
                      >
                        {quickTraceSelected.length === wallets.length ? "Deselect All" : "Select All"}
                      </button>
                      <button
                        data-testid="button-qt-select-poi"
                        onClick={() => setQuickTraceSelected(wallets.filter(w => w.role?.toLowerCase().includes("attacker") || w.role?.toLowerCase().includes("poi") || w.label?.toLowerCase().includes("poi")).map(w => w.address))}
                        className="text-[10px] px-2 py-1 bg-red-600/20 border border-red-600/30 rounded text-red-400 hover:bg-red-600/30"
                      >
                        POI / Attacker
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 max-h-[200px] overflow-y-auto mb-3">
                    {wallets.map(w => (
                      <label key={w.id} className="flex items-center gap-2 text-xs bg-[#0d1117] rounded px-3 py-2 cursor-pointer hover:bg-gray-800/60">
                        <input
                          type="checkbox"
                          checked={quickTraceSelected.includes(w.address)}
                          onChange={e => {
                            if (e.target.checked) setQuickTraceSelected(p => [...p, w.address]);
                            else setQuickTraceSelected(p => p.filter(a => a !== w.address));
                          }}
                          className="rounded border-gray-600 bg-gray-800 text-cyan-500"
                        />
                        <span className="font-mono text-cyan-500">{w.address.slice(0, 8)}...{w.address.slice(-6)}</span>
                        <button
                          data-testid={`button-copy-qt-${w.id}`}
                          onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigator.clipboard.writeText(w.address); setCopiedAddr(w.address); setTimeout(() => setCopiedAddr(null), 2000); }}
                          className="text-[10px] text-cyan-600 hover:text-cyan-400 transition-colors"
                        >
                          {copiedAddr === w.address ? "Copied!" : "Copy"}
                        </button>
                        <span className="text-gray-500 truncate">{w.label || w.role || ""}</span>
                        <span className="ml-auto text-gray-600">({w.chain})</span>
                        {quickTraceProgress[w.address] && (
                          <span className={`text-[10px] ${quickTraceProgress[w.address] === "done" ? "text-green-400" : quickTraceProgress[w.address] === "tracing" ? "text-cyan-400 animate-pulse" : "text-red-400"}`}>
                            {quickTraceProgress[w.address] === "done" ? "✓" : quickTraceProgress[w.address] === "tracing" ? "..." : "✗"}
                          </span>
                        )}
                      </label>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button
                      data-testid="button-qt-trace-selected"
                      disabled={quickTracing || quickTraceSelected.length === 0}
                      onClick={async () => {
                        setQuickTracing(true);
                        setQuickTraceResults({});
                        setQuickTraceProgress({});
                        for (let i = 0; i < quickTraceSelected.length; i++) {
                          const addr = quickTraceSelected[i];
                          setQuickTraceProgress(p => ({ ...p, [addr]: "tracing" }));
                          try {
                            const resp = await fetch("/api/forensic/command-center/trace", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              credentials: "include",
                              body: JSON.stringify({ address: addr }),
                            });
                            if (resp.status === 403 || resp.status === 400) {
                              setQuickTraceResults(p => ({ ...p, [addr]: { error: "Request blocked — retrying after delay" } }));
                              setQuickTraceProgress(p => ({ ...p, [addr]: "error" }));
                              await new Promise(r => setTimeout(r, 2000));
                              continue;
                            }
                            const data = await resp.json();
                            setQuickTraceResults(p => ({ ...p, [addr]: data }));
                            setQuickTraceProgress(p => ({ ...p, [addr]: "done" }));
                          } catch (e: any) {
                            setQuickTraceResults(p => ({ ...p, [addr]: { error: e.message } }));
                            setQuickTraceProgress(p => ({ ...p, [addr]: "error" }));
                          }
                          if (i < quickTraceSelected.length - 1) await new Promise(r => setTimeout(r, 500));
                        }
                        setQuickTracing(false);
                      }}
                      className="flex-1 px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium"
                    >
                      {quickTracing ? `Tracing ${Object.values(quickTraceProgress).filter(v => v === "done").length}/${quickTraceSelected.length}...` : `Trace ${quickTraceSelected.length} Selected Wallet${quickTraceSelected.length !== 1 ? "s" : ""}`}
                    </button>
                  </div>
                </div>
              )}

              <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-4 mb-4">
                <h3 className="text-xs text-gray-500 mb-2">Manual Address Trace</h3>
                <div className="flex gap-2">
                  <input
                    data-testid="input-trace-address"
                    placeholder="Enter any wallet address to trace..."
                    value={traceAddress}
                    onChange={e => setTraceAddress(e.target.value)}
                    className="flex-1 px-4 py-2 bg-[#0d1117] border border-gray-700 rounded-lg text-sm text-gray-200 font-mono focus:border-cyan-500 outline-none"
                    onKeyDown={e => e.key === "Enter" && runTrace()}
                  />
                  <button
                    data-testid="button-run-trace"
                    onClick={runTrace}
                    disabled={tracing || !traceAddress}
                    className="px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg font-medium text-sm"
                  >
                    {tracing ? "Tracing..." : "Trace"}
                  </button>
                </div>
              </div>

              {Object.keys(quickTraceResults).length > 0 && (
                <div className="space-y-3 mb-4">
                  <h3 className="text-sm font-bold text-cyan-400">BATCH TRACE RESULTS ({Object.keys(quickTraceResults).length} wallets)</h3>
                  {Object.entries(quickTraceResults).map(([addr, result]: [string, any]) => {
                    const w = wallets?.find(wl => wl.address === addr);
                    return <TraceResultCard key={addr} result={result} address={addr} label={w?.label} />;
                  })}
                </div>
              )}

              {traceResult && (
                <div className="space-y-3 mb-4">
                  <TraceResultCharts traceResult={traceResult} />
                  <h3 className="text-sm font-bold text-cyan-400">MANUAL TRACE RESULT</h3>
                  <TraceResultCard result={traceResult} address={traceResult.address} />
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "spider" && (
            <motion.div key="spider" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {spiderTrace && <SpiderTraceCharts spiderData={spiderTrace} />}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                    Autonomous Spider Trace(TM)
                  </h2>
                  <div className="text-xs text-gray-500 mt-0.5">Automated fund flow tracing - follows stolen funds through every wallet, bridge, exchange, and mixer</div>
                </div>
                {spiderRunning && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-cyan-900/20 border border-cyan-800/30 rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="text-sm text-cyan-400">Tracing in progress...</span>
                  </div>
                )}
              </div>

              {!selectedCase && (
                <div className="bg-[#161b22] rounded-xl border border-yellow-900/30 p-6 text-center mb-4">
                  <div className="text-yellow-400 text-lg mb-2">Select a Case First</div>
                  <div className="text-gray-500 text-sm">Use the case dropdown at the top to select which case to run the spider trace for, or create a new case in the Cases tab.</div>
                </div>
              )}

              {selectedCase && (
                <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-5 mb-4">
                  <h3 className="text-sm font-bold text-gray-400 mb-3">LAUNCH SPIDER TRACE</h3>
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    <div className="col-span-2">
                      <label className="text-xs text-gray-500 mb-1 block">Victim / Target Wallet Address</label>
                      {wallets && wallets.length > 0 ? (
                        <select
                          data-testid="select-spider-wallet"
                          value={spiderConfig.address}
                          onChange={e => {
                            const addr = e.target.value;
                            const w = wallets.find(wl => wl.address === addr);
                            setSpiderConfig(p => ({
                              ...p,
                              address: addr,
                              chain: w?.chain || detectChainFromAddress(addr),
                            }));
                          }}
                          className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                        >
                          <option value="">Select victim wallet...</option>
                          {wallets.filter(w => w.role === "victim" || w.role === "target").map(w => (
                            <option key={`v-${w.id}`} value={w.address}>
                              ★ {w.label || "Victim"} — {w.address.slice(0, 8)}...{w.address.slice(-6)} ({w.chain})
                            </option>
                          ))}
                          {wallets.filter(w => w.role !== "victim" && w.role !== "target").length > 0 && (
                            <option disabled>── Other wallets ──</option>
                          )}
                          {wallets.filter(w => w.role !== "victim" && w.role !== "target").map(w => (
                            <option key={w.id} value={w.address}>
                              {w.label || w.role || "Wallet"} — {w.address.slice(0, 8)}...{w.address.slice(-6)} ({w.chain})
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          data-testid="input-spider-address"
                          placeholder="0x... wallet to trace from"
                          value={spiderConfig.address}
                          onChange={e => setSpiderConfig(p => ({ ...p, address: e.target.value, chain: detectChainFromAddress(e.target.value) }))}
                          className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-cyan-500 outline-none"
                        />
                      )}
                      <input
                        data-testid="input-spider-manual"
                        placeholder="Or paste any address manually..."
                        value={!wallets?.find(w => w.address === spiderConfig.address) ? spiderConfig.address : ""}
                        onChange={e => setSpiderConfig(p => ({ ...p, address: e.target.value, chain: detectChainFromAddress(e.target.value) }))}
                        className="w-full mt-1 px-3 py-1.5 bg-[#0d1117] border border-gray-700/50 rounded text-xs text-gray-400 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Chain (auto-detected)</label>
                      <select
                        data-testid="select-spider-chain"
                        value={spiderConfig.chain}
                        onChange={e => setSpiderConfig(p => ({ ...p, chain: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                      >
                        {ALL_CHAIN_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Trace Depth</label>
                      <select
                        data-testid="select-spider-depth"
                        value={spiderConfig.maxDepth}
                        onChange={e => setSpiderConfig(p => ({ ...p, maxDepth: parseInt(e.target.value) }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                      >
                        <option value="3">3 hops (quick scan)</option>
                        <option value="5">5 hops</option>
                        <option value="10">10 hops</option>
                        <option value="0">Unlimited (no depth limit)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Wallet Scope</label>
                      <select
                        data-testid="select-spider-max"
                        value={spiderConfig.maxWallets}
                        onChange={e => setSpiderConfig(p => ({ ...p, maxWallets: parseInt(e.target.value) }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                      >
                        <option value="50">50 wallets (quick scan)</option>
                        <option value="100">100 wallets</option>
                        <option value="500">500 wallets</option>
                        <option value="0">Unlimited (no wallet limit)</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <div className="text-xs text-gray-600">
                      The spider will automatically trace every outgoing transaction, follow the money through bridges/exchanges/mixers, and add all discovered wallets to monitoring.
                    </div>
                    <button
                      data-testid="button-start-spider"
                      onClick={() => startSpiderTrace()}
                      disabled={!spiderConfig.address || spiderRunning}
                      className="px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-bold whitespace-nowrap"
                    >
                      {spiderRunning ? "Spider Running..." : "Launch Spider Trace"}
                    </button>
                  </div>
                </div>
              )}

              {spiderTrace && spiderTrace.status !== "none" && (
                <div className="space-y-4">
                  {spiderTrace.status === "running" && (
                    <div className="bg-[#161b22] rounded-xl border border-cyan-900/40 p-5">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-sm font-bold text-cyan-400">SPIDER TRACE IN PROGRESS</h3>
                        <span className="text-xs text-gray-500">{spiderTrace.totalWalletsTraced || 0} wallets traced</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-3 mb-2">
                        <div
                          className="h-3 rounded-full bg-gradient-to-r from-cyan-600 to-blue-500 transition-all duration-500"
                          style={{ width: `${spiderTrace.progress || 0}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{spiderTrace.progress || 0}% complete</span>
                        <span>{spiderTrace.totalWalletsFound || 0} wallets discovered | {spiderTrace.walletsAdded || 0} added to monitoring</span>
                      </div>
                    </div>
                  )}

                  {spiderTrace.status === "error" && (
                    <div className="bg-[#161b22] rounded-xl border border-red-900/40 p-5">
                      <h3 className="text-sm font-bold text-red-400 mb-2">TRACE ERROR</h3>
                      <div className="text-sm text-red-300">{spiderTrace.error}</div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                    {[
                      { label: "Wallets Traced", value: spiderTrace.totalWalletsTraced || 0, color: "cyan" },
                      { label: "Fund Flows", value: spiderTrace.fundFlow?.edges?.length || 0, color: "blue" },
                      { label: "Critical Risk", value: spiderTrace.riskSummary?.criticalWallets || 0, color: "red" },
                      { label: "Exchanges Found", value: spiderTrace.riskSummary?.exchangeDeposits || 0, color: "yellow" },
                      { label: "Bridges Used", value: spiderTrace.riskSummary?.bridgeTransfers || 0, color: "purple" },
                      { label: "Mixers Detected", value: spiderTrace.riskSummary?.mixerInteractions || 0, color: "orange" },
                    ].map((s, i) => (
                      <div key={i} className="bg-[#161b22] rounded-xl border border-gray-800/50 p-3">
                        <div className="text-[10px] text-gray-500">{s.label}</div>
                        <div className={`text-xl font-bold text-${s.color}-400`}>{s.value}</div>
                      </div>
                    ))}
                  </div>

                  {spiderTrace.fundFlow?.nodes?.length > 0 && (
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-sm font-bold text-cyan-400">FUND FLOW MAP ({spiderTrace.fundFlow.nodes.length} wallets, {spiderTrace.fundFlow.edges.length} flows)</h3>
                        <div className="flex items-center gap-1 bg-[#0d1117] rounded-lg border border-gray-800/50 p-0.5">
                          <button
                            data-testid="button-view-flow"
                            onClick={() => setFlowViewMode("flow")}
                            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${flowViewMode === "flow" ? "bg-amber-600/20 text-amber-400 border border-amber-700/50" : "text-gray-500 hover:text-gray-300"}`}
                          >Transaction Flow</button>
                          <button
                            data-testid="button-view-graph"
                            onClick={() => setFlowViewMode("graph")}
                            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${flowViewMode === "graph" ? "bg-cyan-600/20 text-cyan-400 border border-cyan-700/50" : "text-gray-500 hover:text-gray-300"}`}
                          >Graph</button>
                          <button
                            data-testid="button-view-cards"
                            onClick={() => setFlowViewMode("cards")}
                            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${flowViewMode === "cards" ? "bg-cyan-600/20 text-cyan-400 border border-cyan-700/50" : "text-gray-500 hover:text-gray-300"}`}
                          >Cards</button>
                        </div>
                      </div>

                      {flowViewMode === "flow" && (() => {
                        const caseData = cases?.find((c: any) => c.id === selectedCase);
                        const { flowNodes, flowEdges } = buildCaseFlowData(wallets || [], caseData);
                        return (
                          <TransactionFlowGraph
                            nodes={flowNodes}
                            edges={flowEdges}
                            title={caseData?.caseName || caseData?.case_name || "Case Investigation"}
                            caseId={selectedCase || undefined}
                          />
                        );
                      })()}

                      {flowViewMode === "graph" && (
                        <FundFlowGraph
                          nodes={spiderTrace.fundFlow.nodes}
                          edges={spiderTrace.fundFlow.edges}
                          chain={spiderConfig.chain}
                        />
                      )}

                      {flowViewMode === "cards" && (
                        <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-5">
                          <div className="space-y-1 max-h-[600px] overflow-y-auto">
                            {(() => {
                              const nodesByDepth: Record<number, any[]> = {};
                              (spiderTrace.fundFlow.nodes || []).forEach((n: any) => {
                                if (!nodesByDepth[n.depth]) nodesByDepth[n.depth] = [];
                                nodesByDepth[n.depth].push(n);
                              });
                              const depths = Object.keys(nodesByDepth).map(Number).sort((a, b) => a - b);
                              const edgeMap = new Map<string, any[]>();
                              (spiderTrace.fundFlow.edges || []).forEach((e: any) => {
                                const key = e.from.toLowerCase();
                                if (!edgeMap.has(key)) edgeMap.set(key, []);
                                edgeMap.get(key)!.push(e);
                              });

                              return depths.map(depth => (
                                <div key={depth} className="mb-4">
                                  <div className="text-xs font-bold text-gray-500 mb-2 flex items-center gap-2">
                                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                      depth === 0 ? "bg-cyan-600 text-white" : depth === 1 ? "bg-blue-600 text-white" : depth === 2 ? "bg-purple-600 text-white" : "bg-gray-600 text-white"
                                    }`}>
                                      {depth}
                                    </div>
                                    DEPTH {depth} {depth === 0 ? "(VICTIM)" : depth === 1 ? "(DIRECT RECIPIENTS)" : `(HOP ${depth})`}
                                  </div>
                                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 pl-8">
                                    {nodesByDepth[depth].map((node: any) => {
                                      const nodeEdges = edgeMap.get(node.address.toLowerCase()) || [];
                                      const incomingEdges = (spiderTrace.fundFlow.edges || []).filter((e: any) => e.to.toLowerCase() === node.address.toLowerCase());
                                      const roleColors: Record<string, string> = {
                                        victim: "border-cyan-600/50 bg-cyan-900/10",
                                        exchange: "border-yellow-600/50 bg-yellow-900/10",
                                        exchange_deposit: "border-yellow-600/50 bg-yellow-900/10",
                                        bridge: "border-purple-600/50 bg-purple-900/10",
                                        mixer: "border-red-600/50 bg-red-900/10",
                                        drainer: "border-red-600/50 bg-red-900/10",
                                        splitter: "border-orange-600/50 bg-orange-900/10",
                                        relay: "border-blue-600/50 bg-blue-900/10",
                                      };
                                      const borderClass = roleColors[node.role] || "border-gray-700/50 bg-gray-900/10";

                                      return (
                                        <div key={node.address} className={`rounded-lg border p-3 ${borderClass}`} data-testid={`spider-node-${node.address.slice(0,8)}`}>
                                          <div className="flex items-center justify-between mb-1">
                                            <span className="text-xs font-bold text-gray-200">{node.label}</span>
                                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                                              node.riskLevel === "critical" ? "bg-red-600 text-white" :
                                              node.riskLevel === "high" ? "bg-orange-500 text-white" :
                                              node.riskLevel === "medium" ? "bg-yellow-500 text-black" :
                                              "bg-gray-600 text-gray-200"
                                            }`}>
                                              {node.role.toUpperCase()}
                                            </span>
                                          </div>
                                          <div className="font-mono text-[10px] text-cyan-500 mb-1 break-all">
                                            <a href={explorerLink(node.chain || spiderConfig.chain, "address", node.address)} target="_blank" rel="noopener noreferrer" className="hover:underline">
                                              {node.address}
                                            </a>
                                          </div>
                                          <div className="flex items-center gap-2 text-[10px]">
                                            <span className="text-gray-400">Bal: {parseFloat(node.balance || "0").toFixed(4)} {chainSymbol(node.chain || spiderConfig.chain)}</span>
                                            {node.balanceUSD && <span className="text-green-400">${parseFloat(node.balanceUSD).toLocaleString()}</span>}
                                            <span className="text-gray-500">TXs: {node.txCount}</span>
                                          </div>
                                          {incomingEdges.length > 0 && (
                                            <div className="mt-1 text-[10px] text-gray-500">
                                              Received from {incomingEdges.length} wallet{incomingEdges.length > 1 ? "s" : ""}: {
                                                incomingEdges.slice(0, 2).map((e: any) => `${parseFloat(e.value || "0").toFixed(4)}`).join(", ")
                                              }
                                              {incomingEdges.length > 2 ? ` +${incomingEdges.length - 2} more` : ""}
                                            </div>
                                          )}
                                          {nodeEdges.length > 0 && (
                                            <div className="mt-1 text-[10px] text-gray-500">
                                              Sent to {nodeEdges.length} wallet{nodeEdges.length > 1 ? "s" : ""}
                                            </div>
                                          )}
                                          {node.riskIndicators && node.riskIndicators.length > 0 && (
                                            <div className="mt-1 flex flex-wrap gap-1">
                                              {node.riskIndicators.map((ri: string) => (
                                                <span key={ri} className="text-[9px] px-1 py-0.5 bg-red-900/30 border border-red-600/20 rounded text-red-400">
                                                  {ri.replace(/_/g, " ")}
                                                </span>
                                              ))}
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              ));
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {spiderTrace.fundFlow?.edges?.length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/50 p-5">
                      <h3 className="text-sm font-bold text-cyan-400 mb-3">TRANSACTION FLOW LOG ({spiderTrace.fundFlow.edges.length} transfers)</h3>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs" data-testid="table-spider-edges">
                          <thead>
                            <tr className="border-b border-gray-800/50 text-gray-500">
                              <th className="px-2 py-1.5 text-left">From</th>
                              <th className="px-2 py-1.5 text-center">Direction</th>
                              <th className="px-2 py-1.5 text-left">To</th>
                              <th className="px-2 py-1.5 text-right">Value</th>
                              <th className="px-2 py-1.5 text-left">TX Hash</th>
                              <th className="px-2 py-1.5 text-left">Time</th>
                            </tr>
                          </thead>
                          <tbody>
                            {spiderTrace.fundFlow.edges.map((edge: any, i: number) => {
                              const fromNode = spiderTrace.fundFlow.nodes.find((n: any) => n.address.toLowerCase() === edge.from.toLowerCase());
                              const toNode = spiderTrace.fundFlow.nodes.find((n: any) => n.address.toLowerCase() === edge.to.toLowerCase());
                              return (
                                <tr key={i} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                                  <td className="px-2 py-1.5">
                                    <span className="font-mono text-cyan-400">{fromNode?.label || shortenAddr(edge.from)}</span>
                                  </td>
                                  <td className="px-2 py-1.5 text-center text-yellow-500">→</td>
                                  <td className="px-2 py-1.5">
                                    <span className={`font-mono ${toNode?.role === "exchange" ? "text-yellow-400" : toNode?.role === "bridge" ? "text-purple-400" : toNode?.role === "mixer" ? "text-red-400" : "text-cyan-400"}`}>
                                      {toNode?.label || shortenAddr(edge.to)}
                                    </span>
                                  </td>
                                  <td className="px-2 py-1.5 text-right text-gray-200 font-medium">
                                    {parseFloat(edge.value || "0").toFixed(4)}
                                  </td>
                                  <td className="px-2 py-1.5">
                                    {edge.txHash && edge.txHash !== "connected" ? (
                                      <a href={explorerLink(spiderConfig.chain, "tx", edge.txHash)} target="_blank" rel="noopener noreferrer" className="font-mono text-blue-400 hover:underline">
                                        {edge.txHash.slice(0, 10)}...
                                      </a>
                                    ) : (
                                      <span className="text-gray-600">linked</span>
                                    )}
                                  </td>
                                  <td className="px-2 py-1.5 text-gray-500">{edge.timestamp ? timeAgo(edge.timestamp) : "-"}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {(!spiderTrace || spiderTrace.status === "none") && selectedCase && !spiderRunning && (
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center mt-4">
                  <div className="text-gray-500 text-lg mb-2">No Spider Trace Results</div>
                  <div className="text-gray-600 text-sm">Enter the victim's wallet address above and click "Launch Spider Trace" to automatically trace where the stolen funds went.</div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "phantom" && (
            <motion.div key="phantom" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {phantomVaults && phantomVaults.length > 0 && <PhantomVaultCharts vaults={phantomVaults} />}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-red-400" data-testid="text-phantom-title">Alpha Phantom Vault Protocol(TM)</h2>
                  <p className="text-xs text-gray-500 mt-1">Honeypot decoy wallets with self-destructing tokens and embedded beacon tracking</p>
                </div>
                <button data-testid="button-new-phantom" onClick={() => { setShowPhantomForm(!showPhantomForm); if (!phantomForm.caseId && cases?.[0]) setPhantomForm(f => ({ ...f, caseId: cases[0].id })); }} className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-lg text-sm font-medium transition-all">
                  + Deploy Phantom Vault
                </button>
              </div>

              {showPhantomForm && (
                <div className="bg-[#161b22] rounded-xl border border-purple-900/30 p-4 mb-4">
                  <h3 className="text-sm font-semibold text-purple-400 mb-3">Configure New Phantom Vault</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Vault Name</label>
                      <input data-testid="input-phantom-name" value={phantomForm.vaultName} onChange={e => setPhantomForm(f => ({ ...f, vaultName: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" placeholder="e.g. Operation Mirage" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Link to Case (optional)</label>
                      <select data-testid="select-phantom-case" value={phantomForm.caseId} onChange={e => setPhantomForm(f => ({ ...f, caseId: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        <option value="">No case (standalone)</option>
                        {cases?.map(c => <option key={c.id} value={c.id}>{c.caseName}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Chain</label>
                      <select data-testid="select-phantom-chain" value={phantomForm.chain} onChange={e => setPhantomForm(f => ({ ...f, chain: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        {EVM_CHAIN_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Decoy Token Type</label>
                      <select data-testid="select-phantom-token" value={phantomForm.decoyTokenType} onChange={e => setPhantomForm(f => ({ ...f, decoyTokenType: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        <option value="USDC">USDC (Mimic)</option>
                        <option value="USDT">USDT (Mimic)</option>
                        <option value="DAI">DAI (Mimic)</option>
                        <option value="ETH">ETH (Mimic)</option>
                        <option value="WETH">WETH (Mimic)</option>
                        <option value="WBTC">WBTC (Mimic)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Decoy Amount</label>
                      <input data-testid="input-phantom-amount" type="number" value={phantomForm.decoyAmount} onChange={e => setPhantomForm(f => ({ ...f, decoyAmount: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" placeholder="e.g. 50000" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Self-Destruct Timer (hours)</label>
                      <select data-testid="select-phantom-expiry" value={phantomForm.expirationHours} onChange={e => setPhantomForm(f => ({ ...f, expirationHours: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        <option value="1">1 hour</option>
                        <option value="6">6 hours</option>
                        <option value="12">12 hours</option>
                        <option value="24">24 hours (default)</option>
                        <option value="48">48 hours</option>
                        <option value="72">72 hours</option>
                      </select>
                    </div>
                  </div>
                  <div className="mt-3 p-3 bg-purple-900/10 border border-purple-900/20 rounded-lg">
                    <div className="text-[10px] text-purple-400 font-semibold mb-1">HOW IT WORKS:</div>
                    <div className="text-[10px] text-gray-400 leading-relaxed">
                      1. A decoy wallet is generated with mimic tokens that appear as real {phantomForm.decoyTokenType || "USDC"} on blockchain explorers.
                      2. Share the wallet address/keys with an attacker under duress - they see what looks like real funds.
                      3. When the attacker accesses the wallet, the vault TRIGGERS - beacon tracking activates and a countdown begins.
                      4. Every wallet that interacts with the decoy tokens is automatically discovered and added to monitoring.
                      5. After {phantomForm.expirationHours || 24} hours, tokens DISINTEGRATE - becoming non-transferable with zero value.
                      6. The victim is safely separated from the attacker, and all attacker wallet addresses are captured.
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button data-testid="button-deploy-phantom" onClick={async () => {
                      if (!phantomForm.vaultName || !phantomForm.decoyAmount) return;
                      try {
                        await apiRequest("POST", "/api/forensic/command-center/phantom-vault", {
                          ...phantomForm,
                          decoyAmount: parseFloat(phantomForm.decoyAmount) || 0,
                          expirationHours: parseInt(phantomForm.expirationHours) || 24,
                        });
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                        setShowPhantomForm(false);
                        setPhantomForm({ caseId: "", vaultName: "", chain: "ethereum", decoyTokenType: "USDC", decoyAmount: "", expirationHours: "24" });
                      } catch {}
                    }} className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded text-sm font-medium">
                      Deploy Vault
                    </button>
                    <button onClick={() => setShowPhantomForm(false)} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-sm">Cancel</button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-4 gap-3 mb-4">
                <div className="bg-[#161b22] rounded-xl border border-purple-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-purple-400" data-testid="text-phantom-total">{phantomVaults?.length || 0}</div>
                  <div className="text-xs text-gray-500">Total Vaults</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-green-400" data-testid="text-phantom-armed">{phantomVaults?.filter((v: any) => v.status === "armed")?.length || 0}</div>
                  <div className="text-xs text-gray-500">Armed & Ready</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-red-400" data-testid="text-phantom-triggered">{phantomVaults?.filter((v: any) => v.status === "triggered")?.length || 0}</div>
                  <div className="text-xs text-gray-500">Triggered (Active)</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                  <div className="text-2xl font-bold text-cyan-400" data-testid="text-phantom-beacons">{phantomVaults?.reduce((sum: number, v: any) => sum + (v.beaconHits || 0), 0) || 0}</div>
                  <div className="text-xs text-gray-500">Beacon Hits</div>
                </div>
              </div>

              <div className="space-y-3">
                {phantomVaults?.map((vault: any) => {
                  const isExpanded = selectedVault === vault.id;
                  const timeLeft = vault.expiresAt ? Math.max(0, new Date(vault.expiresAt).getTime() - Date.now()) : null;
                  const hoursLeft = timeLeft !== null ? Math.floor(timeLeft / 3600000) : null;
                  const minsLeft = timeLeft !== null ? Math.floor((timeLeft % 3600000) / 60000) : null;

                  return (
                    <div key={vault.id} className={`bg-[#161b22] rounded-xl border ${
                      vault.status === "armed" ? "border-green-900/30" :
                      vault.status === "triggered" ? "border-red-900/40 bg-red-900/5" :
                      vault.status === "disintegrated" ? "border-gray-800/30 opacity-60" :
                      "border-gray-800/30"
                    } overflow-hidden`}>
                      <div className="p-4 cursor-pointer" onClick={() => setSelectedVault(isExpanded ? null : vault.id)}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg ${
                              vault.status === "armed" ? "bg-green-900/30 text-green-400" :
                              vault.status === "triggered" ? "bg-red-900/30 text-red-400 animate-pulse" :
                              vault.status === "disintegrated" ? "bg-gray-800 text-gray-500" :
                              "bg-gray-800 text-gray-500"
                            }`}>
                              {vault.status === "armed" ? "A" : vault.status === "triggered" ? "!" : vault.status === "disintegrated" ? "X" : "D"}
                            </div>
                            <div>
                              <div className="font-semibold text-gray-200">{vault.vaultName}</div>
                              <div className="text-xs text-gray-500 font-mono">{vault.decoyAddress}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div className="text-sm font-bold text-gray-200">{(vault.decoyAmount || 0).toLocaleString()} {vault.decoyTokenType}</div>
                              <div className="text-xs text-gray-500">${(vault.decoyAmountUsd || 0).toLocaleString()}</div>
                            </div>
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                              vault.status === "armed" ? "bg-green-900/30 text-green-400" :
                              vault.status === "triggered" ? "bg-red-900/30 text-red-400" :
                              vault.status === "disintegrated" ? "bg-gray-800 text-gray-500" :
                              "bg-yellow-900/30 text-yellow-400"
                            }`}>{vault.status}</span>
                          </div>
                        </div>

                        {vault.status === "triggered" && timeLeft !== null && timeLeft > 0 && (
                          <div className="mt-3">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-red-400 font-semibold">Self-Destruct Countdown</span>
                              <span className="text-red-300 font-mono">{hoursLeft}h {minsLeft}m remaining</span>
                            </div>
                            <div className="w-full bg-gray-800 rounded-full h-2">
                              <div className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all" style={{ width: `${Math.max(2, 100 - (timeLeft / (vault.expirationHours * 3600000)) * 100)}%` }} />
                            </div>
                          </div>
                        )}
                      </div>

                      {isExpanded && (
                        <div className="border-t border-gray-800/30 p-4 space-y-3">
                          <div className="grid grid-cols-5 gap-3 text-xs">
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Chain</div>
                              <div className="text-gray-200 font-medium">{vault.chain}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Expiration</div>
                              <div className="text-gray-200 font-medium">{vault.expirationHours}h after trigger</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Beacon Status</div>
                              <div className={vault.beaconActive ? "text-green-400 font-medium" : "text-gray-500"}>{vault.beaconActive ? "ACTIVE" : "INACTIVE"}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Beacon Hits</div>
                              <div className="text-cyan-400 font-medium">{vault.beaconHits || 0}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Spider Trace</div>
                              <div className={`font-medium ${vault.spiderTraceActive && !vault.spiderTracePaused ? "text-green-400" : vault.spiderTracePaused ? "text-yellow-400" : "text-gray-500"}`}>
                                {vault.spiderTraceActive ? (vault.spiderTracePaused ? "PAUSED" : "TRACKING") : "OFF"}
                              </div>
                            </div>
                          </div>

                          {vault.contractSpec && (
                            <div className="bg-gradient-to-r from-green-900/10 to-emerald-900/10 border border-green-900/20 rounded-lg p-3">
                              <div className="text-xs text-green-400 font-bold mb-2">Token Indistinguishability Report</div>
                              <div className="grid grid-cols-3 gap-2 text-[10px]">
                                <div>
                                  <span className="text-gray-500">Mimics:</span>{" "}
                                  <span className="text-green-300 font-mono">{(vault.contractSpec as any).mimicName} ({(vault.contractSpec as any).mimicSymbol})</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Real Contract:</span>{" "}
                                  <span className="text-green-300 font-mono">{(vault.contractSpec as any).mimicTarget?.slice(0, 10)}...{(vault.contractSpec as any).mimicTarget?.slice(-6)}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Indistinguishability:</span>{" "}
                                  <span className="text-green-400 font-bold">{(vault.contractSpec as any).indistinguishabilityScore}%</span>
                                </div>
                              </div>
                              <div className="mt-2 flex flex-wrap gap-1">
                                {(vault.contractSpec as any).functions?.map((fn: string, i: number) => (
                                  <span key={i} className="px-1.5 py-0.5 bg-green-900/20 text-green-500 rounded text-[9px] font-mono">{fn}</span>
                                ))}
                              </div>
                              <div className="mt-1 text-[9px] text-gray-600">Verification: {(vault.contractSpec as any).verificationStatus}</div>
                            </div>
                          )}

                          {vault.securityProtocol && (vault.securityProtocol as any).integrityLayers && (
                            <div className="bg-gradient-to-r from-purple-900/10 to-blue-900/10 border border-purple-900/20 rounded-lg p-3">
                              <div className="flex items-center justify-between mb-2">
                                <div className="text-xs text-purple-400 font-bold">7-Layer Security Protocol</div>
                                <span className="px-2 py-0.5 bg-purple-900/30 text-purple-300 rounded-full text-[9px] font-bold">{(vault.securityProtocol as any).classification}</span>
                              </div>
                              <div className="space-y-1">
                                {((vault.securityProtocol as any).integrityLayers as any[]).map((layer: any, i: number) => (
                                  <div key={i} className="flex items-center gap-2 text-[10px]">
                                    <span className={`w-1.5 h-1.5 rounded-full ${layer.status === "active" ? "bg-green-400" : "bg-red-400"}`} />
                                    <span className="text-gray-400 w-4">{layer.layer}</span>
                                    <span className="text-gray-300 font-medium w-48">{layer.name}</span>
                                    <span className="text-gray-500 flex-1">{layer.description}</span>
                                  </div>
                                ))}
                              </div>
                              <div className="mt-2 grid grid-cols-3 gap-2 text-[10px]">
                                <div className="bg-[#0d1117] rounded p-1.5">
                                  <span className="text-gray-500">HMAC: </span>
                                  <span className="text-purple-400 font-mono">{(vault.securityProtocol as any).hmacIntegrity?.algorithm}</span>
                                </div>
                                <div className="bg-[#0d1117] rounded p-1.5">
                                  <span className="text-gray-500">Beacon: </span>
                                  <span className="text-purple-400 font-mono">{(vault.securityProtocol as any).beaconProtocol?.encoding?.slice(0, 30)}...</span>
                                </div>
                                <div className="bg-[#0d1117] rounded p-1.5">
                                  <span className="text-gray-500">Reactivation: </span>
                                  <span className="text-green-400">{(vault.securityProtocol as any).hmacIntegrity?.reactivationCapable ? "CAPABLE" : "N/A"}</span>
                                </div>
                              </div>
                              {(vault.securityProtocol as any).beaconProtocol?.antiDetection && (
                                <div className="mt-2">
                                  <div className="text-[9px] text-gray-500 mb-1">Anti-Detection Measures:</div>
                                  <div className="flex flex-wrap gap-1">
                                    {((vault.securityProtocol as any).beaconProtocol.antiDetection as string[]).map((m: string, i: number) => (
                                      <span key={i} className="px-1.5 py-0.5 bg-gray-800 text-gray-400 rounded text-[9px]">{m}</span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {vault.triggeredByAddress && (
                            <div className="bg-red-900/10 border border-red-900/20 rounded-lg p-3">
                              <div className="text-xs text-red-400 font-semibold mb-1">Triggered By (Attacker)</div>
                              <div className="font-mono text-sm text-red-300">{vault.triggeredByAddress}</div>
                              <div className="flex items-center gap-3 mt-1">
                                {vault.triggeredAt && <div className="text-[10px] text-gray-500">At: {new Date(vault.triggeredAt).toLocaleString()}</div>}
                                {vault.spiderTraceActive && (
                                  <div className="flex items-center gap-1 text-[10px]">
                                    <span className={`w-1.5 h-1.5 rounded-full ${vault.spiderTracePaused ? "bg-yellow-400" : "bg-green-400 animate-pulse"}`} />
                                    <span className={vault.spiderTracePaused ? "text-yellow-400" : "text-green-400"}>
                                      Spider Trace {vault.spiderTracePaused ? "PAUSED" : "ACTIVE — tracking all wallet traffic indefinitely"}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {vault.discoveredAddresses && (vault.discoveredAddresses as string[]).length > 0 && (
                            <div className="bg-[#0d1117] rounded-lg p-3">
                              <div className="text-xs text-cyan-400 font-semibold mb-2">Discovered Addresses ({(vault.discoveredAddresses as string[]).length})</div>
                              <div className="space-y-1">
                                {(vault.discoveredAddresses as string[]).map((addr: string, i: number) => (
                                  <div key={i} className="flex items-center justify-between text-xs bg-[#161b22] rounded px-2 py-1">
                                    <span className="font-mono text-cyan-500">{addr}</span>
                                    <div className="flex items-center gap-2">
                                      {vault.spiderTraceActive && <span className="text-[9px] text-green-500">Spider Active</span>}
                                      <span className="text-gray-500">{i === 0 ? "Primary Target" : `Associate #${i}`}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {vault.interactionLog && (vault.interactionLog as any[]).length > 0 && (
                            <div className="bg-[#0d1117] rounded-lg p-3">
                              <div className="text-xs text-yellow-400 font-semibold mb-2">Interaction Log</div>
                              <div className="space-y-1 max-h-40 overflow-y-auto">
                                {(vault.interactionLog as any[]).map((log: any, i: number) => (
                                  <div key={i} className="text-[10px] flex items-start gap-2 bg-[#161b22] rounded px-2 py-1">
                                    <span className="text-gray-600 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</span>
                                    <span className={`px-1 py-0.5 rounded font-semibold ${log.type === "triggered" ? "bg-red-900/30 text-red-400" : "bg-cyan-900/30 text-cyan-400"}`}>{log.type}</span>
                                    <span className="text-gray-400">{log.action}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2">
                            {vault.status === "armed" && (
                              <div className="flex items-center gap-2">
                                <input data-testid={`input-trigger-${vault.id}`} value={triggerAddresses[vault.id] || ""} onChange={e => setTriggerAddresses(prev => ({ ...prev, [vault.id]: e.target.value }))} className="px-3 py-1.5 bg-[#0d1117] border border-gray-700 rounded text-xs text-gray-200 w-80" placeholder="Attacker address that accessed the vault..." />
                                <button data-testid={`button-trigger-${vault.id}`} onClick={async () => {
                                  const addr = triggerAddresses[vault.id];
                                  if (!addr) return;
                                  try {
                                    await apiRequest("POST", `/api/forensic/command-center/phantom-vault/${vault.id}/trigger`, { attackerAddress: addr });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
                                    setTriggerAddresses(prev => ({ ...prev, [vault.id]: "" }));
                                  } catch {}
                                }} className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-medium">TRIGGER</button>
                              </div>
                            )}

                            {(vault.status === "triggered") && (
                              <div className="flex items-center gap-2">
                                <input data-testid={`input-beacon-${vault.id}`} value={beaconAddresses[vault.id] || ""} onChange={e => setBeaconAddresses(prev => ({ ...prev, [vault.id]: e.target.value }))} className="px-3 py-1.5 bg-[#0d1117] border border-gray-700 rounded text-xs text-gray-200 w-80" placeholder="New address interacting with decoy tokens..." />
                                <button data-testid={`button-beacon-${vault.id}`} onClick={async () => {
                                  const addr = beaconAddresses[vault.id];
                                  if (!addr) return;
                                  try {
                                    await apiRequest("POST", `/api/forensic/command-center/phantom-vault/${vault.id}/beacon`, { interactingAddress: addr });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/wallets"] });
                                    setBeaconAddresses(prev => ({ ...prev, [vault.id]: "" }));
                                  } catch {}
                                }} className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-medium">LOG BEACON HIT</button>
                              </div>
                            )}

                            {vault.spiderTraceActive && !vault.spiderTracePaused && (vault.status === "triggered") && (
                              <button data-testid={`button-pause-spider-${vault.id}`} onClick={async () => {
                                try {
                                  await apiRequest("PATCH", `/api/forensic/command-center/phantom-vault/${vault.id}/spider-toggle`, { action: "pause" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                } catch {}
                              }} className="px-3 py-1.5 bg-yellow-900/30 hover:bg-yellow-800/40 text-yellow-400 rounded text-xs font-medium">Pause Spider</button>
                            )}

                            {vault.spiderTraceActive && vault.spiderTracePaused && (
                              <button data-testid={`button-resume-spider-${vault.id}`} onClick={async () => {
                                try {
                                  await apiRequest("PATCH", `/api/forensic/command-center/phantom-vault/${vault.id}/spider-toggle`, { action: "resume" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                } catch {}
                              }} className="px-3 py-1.5 bg-green-900/30 hover:bg-green-800/40 text-green-400 rounded text-xs font-medium">Resume Spider</button>
                            )}

                            {!vault.spiderTraceActive && vault.status === "triggered" && (
                              <button data-testid={`button-activate-spider-${vault.id}`} onClick={async () => {
                                try {
                                  await apiRequest("PATCH", `/api/forensic/command-center/phantom-vault/${vault.id}/spider-toggle`, { action: "activate" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                } catch {}
                              }} className="px-3 py-1.5 bg-green-600 hover:bg-green-500 text-white rounded text-xs font-medium">Activate Spider</button>
                            )}

                            {vault.spiderTraceActive && (
                              <button data-testid={`button-deactivate-spider-${vault.id}`} onClick={async () => {
                                try {
                                  await apiRequest("PATCH", `/api/forensic/command-center/phantom-vault/${vault.id}/spider-toggle`, { action: "deactivate" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                } catch {}
                              }} className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-xs">Deactivate Spider</button>
                            )}

                            {(vault.status === "armed" || vault.status === "triggered") && (
                              <button data-testid={`button-disarm-${vault.id}`} onClick={async () => {
                                try {
                                  await apiRequest("PATCH", `/api/forensic/command-center/phantom-vault/${vault.id}/disarm`);
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                                } catch {}
                              }} className="px-3 py-1.5 bg-yellow-900/30 hover:bg-yellow-800/40 text-yellow-400 rounded text-xs">Disarm</button>
                            )}

                            <button data-testid={`button-delete-phantom-${vault.id}`} onClick={async () => {
                              try {
                                await apiRequest("DELETE", `/api/forensic/command-center/phantom-vault/${vault.id}`);
                                queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/phantom-vaults"] });
                              } catch {}
                            }} className="px-3 py-1.5 bg-red-900/20 hover:bg-red-800/30 text-red-500 rounded text-xs">Delete</button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}

                {(!phantomVaults || phantomVaults.length === 0) && (
                  <div className="bg-[#161b22] rounded-xl border border-purple-900/20 p-8 text-center">
                    <div className="text-4xl mb-3 opacity-30">P</div>
                    <div className="text-gray-500 text-lg mb-2">No Phantom Vaults Deployed</div>
                    <div className="text-gray-600 text-sm max-w-lg mx-auto">Deploy a Phantom Vault to create a honeypot wallet with self-destructing decoy tokens. When an attacker accesses it, the beacon activates, tracking every wallet that touches the mimic funds before they disintegrate.</div>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "custvaults" && (
            <motion.div key="custvaults" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="mb-4">
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400" data-testid="text-custvault-title">
                  Customer Vault Oversight
                </h2>
                <p className="text-xs text-gray-500 mt-1">Full admin visibility into all customer Phantom Vault deployments, subscriptions, beacon activity, and discovered addresses</p>
              </div>

              <div className="grid grid-cols-6 gap-3 mb-4">
                <div className="bg-[#161b22] rounded-xl border border-emerald-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-emerald-400" data-testid="text-cv-customers">{customerStats.totalCustomers || 0}</div>
                  <div className="text-[10px] text-gray-500">Active Customers</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-teal-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-teal-400" data-testid="text-cv-subs">{customerStats.activeSubscriptions || 0}</div>
                  <div className="text-[10px] text-gray-500">Active Subs</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-cyan-400" data-testid="text-cv-total">{customerStats.totalVaults || 0}</div>
                  <div className="text-[10px] text-gray-500">Total Vaults</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-green-400" data-testid="text-cv-armed">{customerStats.armedVaults || 0}</div>
                  <div className="text-[10px] text-gray-500">Armed</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-red-400" data-testid="text-cv-triggered">{customerStats.triggeredVaults || 0}</div>
                  <div className="text-[10px] text-gray-500">Triggered</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-yellow-900/30 p-3 text-center">
                  <div className="text-2xl font-bold text-yellow-400" data-testid="text-cv-beacons">{customerStats.totalBeaconHits || 0}</div>
                  <div className="text-[10px] text-gray-500">Beacon Hits</div>
                </div>
              </div>

              {customerSubs.length > 0 && (
                <div className="bg-[#161b22] rounded-xl border border-emerald-900/20 p-4 mb-4">
                  <h3 className="text-sm font-semibold text-emerald-400 mb-2">Active Subscriptions</h3>
                  <table className="w-full text-xs" data-testid="table-cv-subs">
                    <thead>
                      <tr className="text-gray-500 border-b border-gray-800">
                        <th className="text-left py-2 px-2">Customer</th>
                        <th className="text-left py-2 px-2">Plan</th>
                        <th className="text-left py-2 px-2">Status</th>
                        <th className="text-left py-2 px-2">Vaults Used</th>
                        <th className="text-left py-2 px-2">Period End</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customerSubs.map((sub: any) => (
                        <tr key={sub.id} className="border-b border-gray-800/30 hover:bg-gray-800/20">
                          <td className="py-2 px-2">
                            <div className="text-gray-200 font-medium">{sub.ownerUsername}</div>
                            {sub.ownerEmail && <div className="text-gray-600 text-[10px]">{sub.ownerEmail}</div>}
                          </td>
                          <td className="py-2 px-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              sub.plan?.includes("fortress") ? "bg-yellow-900/30 text-yellow-400" :
                              sub.plan?.includes("sentinel") ? "bg-cyan-900/30 text-cyan-400" :
                              "bg-gray-800 text-gray-400"
                            }`}>{sub.plan?.replace("_", " ")}</span>
                          </td>
                          <td className="py-2 px-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${sub.status === "active" ? "bg-green-900/30 text-green-400" : "bg-gray-800 text-gray-500"}`}>{sub.status}</span>
                          </td>
                          <td className="py-2 px-2 text-gray-300">{sub.vaultsUsed} / {sub.maxVaults}</td>
                          <td className="py-2 px-2 text-gray-500">{sub.currentPeriodEnd ? new Date(sub.currentPeriodEnd).toLocaleDateString() : "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="space-y-3">
                {customerVaults.length === 0 && (
                  <div className="bg-[#161b22] rounded-xl border border-emerald-900/20 p-8 text-center">
                    <div className="text-4xl mb-3 opacity-30">C</div>
                    <div className="text-gray-500 text-lg mb-2">No Customer Vaults Yet</div>
                    <div className="text-gray-600 text-sm">When customers subscribe and create Phantom Vaults, they will appear here with full admin oversight — beacon tracking, interaction logs, discovered addresses, and trigger controls.</div>
                  </div>
                )}

                {customerVaults.map((vault: any) => {
                  const isExp = cvExpanded === vault.id;
                  const timeLeft = vault.expiresAt ? Math.max(0, new Date(vault.expiresAt).getTime() - Date.now()) : null;
                  const hoursLeft = timeLeft !== null ? Math.floor(timeLeft / 3600000) : null;
                  const minsLeft = timeLeft !== null ? Math.floor((timeLeft % 3600000) / 60000) : null;

                  return (
                    <div key={vault.id} className={`bg-[#161b22] rounded-xl border ${
                      vault.status === "armed" ? "border-green-900/30" :
                      vault.status === "triggered" ? "border-red-900/40 bg-red-900/5" :
                      "border-gray-800/30 opacity-60"
                    } overflow-hidden`}>
                      <div className="p-4 cursor-pointer" onClick={() => setCvExpanded(isExp ? null : vault.id)}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg ${
                              vault.status === "armed" ? "bg-green-900/30 text-green-400" :
                              vault.status === "triggered" ? "bg-red-900/30 text-red-400 animate-pulse" :
                              "bg-gray-800 text-gray-500"
                            }`}>
                              {vault.status === "armed" ? "A" : vault.status === "triggered" ? "!" : "X"}
                            </div>
                            <div>
                              <div className="font-semibold text-gray-200">{vault.vaultName}</div>
                              <div className="text-xs text-gray-500 font-mono">{vault.walletAddress}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right text-xs">
                              <div className="text-emerald-400 font-medium">Owner: {vault.ownerUsername}</div>
                              <div className="text-gray-500">{vault.chain} &middot; {vault.decoyTokenType}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-bold text-gray-200">{(vault.decoyAmount || 0).toLocaleString()} {vault.decoyTokenType}</div>
                              <div className="text-xs text-gray-500">Beacon: {vault.beaconHits || 0} hits</div>
                            </div>
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                              vault.status === "armed" ? "bg-green-900/30 text-green-400" :
                              vault.status === "triggered" ? "bg-red-900/30 text-red-400" :
                              "bg-gray-800 text-gray-500"
                            }`}>{vault.status}</span>
                          </div>
                        </div>

                        {vault.status === "triggered" && timeLeft !== null && timeLeft > 0 && (
                          <div className="mt-3">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-red-400 font-semibold">Self-Destruct Countdown</span>
                              <span className="text-red-300 font-mono">{hoursLeft}h {minsLeft}m remaining</span>
                            </div>
                            <div className="w-full bg-gray-800 rounded-full h-2">
                              <div className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all" style={{ width: `${Math.max(2, 100 - (timeLeft / ((vault.expirationHours || 24) * 3600000)) * 100)}%` }} />
                            </div>
                          </div>
                        )}
                      </div>

                      {isExp && (
                        <div className="border-t border-gray-800/30 p-4 space-y-3">
                          <div className="grid grid-cols-6 gap-2 text-xs">
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Owner</div>
                              <div className="text-emerald-400 font-medium">{vault.ownerUsername}</div>
                              {vault.ownerEmail && <div className="text-gray-600 text-[10px]">{vault.ownerEmail}</div>}
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Chain</div>
                              <div className="text-gray-200 font-medium">{vault.chain}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Expiration</div>
                              <div className="text-gray-200 font-medium">{vault.expirationHours}h after trigger</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Beacon</div>
                              <div className={vault.beaconActive ? "text-green-400 font-medium" : "text-gray-500"}>{vault.beaconActive ? "ACTIVE" : "INACTIVE"}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Beacon Hits</div>
                              <div className="text-cyan-400 font-medium">{vault.beaconHits || 0}</div>
                            </div>
                            <div className="bg-[#0d1117] rounded-lg p-2">
                              <div className="text-gray-500">Created</div>
                              <div className="text-gray-200 font-medium">{vault.createdAt ? new Date(vault.createdAt).toLocaleDateString() : "-"}</div>
                            </div>
                          </div>

                          {vault.triggeredByAddress && (
                            <div className="bg-red-900/10 border border-red-900/20 rounded-lg p-3">
                              <div className="text-xs text-red-400 font-semibold mb-1">Triggered By (Attacker)</div>
                              <div className="font-mono text-sm text-red-300">{vault.triggeredByAddress}</div>
                              {vault.triggeredAt && <div className="text-[10px] text-gray-500 mt-1">At: {new Date(vault.triggeredAt).toLocaleString()}</div>}
                            </div>
                          )}

                          {vault.discoveredAddresses && (vault.discoveredAddresses as string[]).length > 0 && (
                            <div className="bg-[#0d1117] rounded-lg p-3">
                              <div className="text-xs text-cyan-400 font-semibold mb-2">Discovered Addresses ({(vault.discoveredAddresses as string[]).length})</div>
                              <div className="space-y-1">
                                {(vault.discoveredAddresses as string[]).map((addr: string, i: number) => (
                                  <div key={i} className="flex items-center justify-between text-xs bg-[#161b22] rounded px-2 py-1">
                                    <span className="font-mono text-cyan-500">{addr}</span>
                                    <span className="text-gray-500">{i === 0 ? "Primary Target" : `Associate #${i}`}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {vault.interactionLog && (vault.interactionLog as any[]).length > 0 && (
                            <div className="bg-[#0d1117] rounded-lg p-3">
                              <div className="text-xs text-yellow-400 font-semibold mb-2">Full Interaction Log ({(vault.interactionLog as any[]).length} events)</div>
                              <div className="space-y-1 max-h-48 overflow-y-auto">
                                {(vault.interactionLog as any[]).map((log: any, i: number) => (
                                  <div key={i} className="text-[10px] flex items-start gap-2 bg-[#161b22] rounded px-2 py-1">
                                    <span className="text-gray-600 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</span>
                                    <span className={`px-1 py-0.5 rounded font-semibold ${
                                      log.type === "triggered" ? "bg-red-900/30 text-red-400" :
                                      log.type === "beacon_hit" ? "bg-cyan-900/30 text-cyan-400" :
                                      log.type === "outbound_transfer" ? "bg-yellow-900/30 text-yellow-400" :
                                      "bg-gray-800 text-gray-400"
                                    }`}>{log.type}</span>
                                    <span className="text-gray-400">{log.action}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2">
                            {vault.status === "armed" && (
                              <div className="flex items-center gap-2">
                                <input data-testid={`input-cv-trigger-${vault.id}`} value={cvTriggerAddr[vault.id] || ""} onChange={e => setCvTriggerAddr(prev => ({ ...prev, [vault.id]: e.target.value }))} className="px-3 py-1.5 bg-[#0d1117] border border-gray-700 rounded text-xs text-gray-200 w-80" placeholder="Attacker address that accessed customer vault..." />
                                <button data-testid={`button-cv-trigger-${vault.id}`} onClick={async () => {
                                  const addr = cvTriggerAddr[vault.id];
                                  if (!addr) return;
                                  try {
                                    await apiRequest("POST", `/api/forensic/command-center/customer-vault/${vault.id}/trigger`, { attackerAddress: addr });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/customer-vaults"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                    setCvTriggerAddr(prev => ({ ...prev, [vault.id]: "" }));
                                  } catch {}
                                }} className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-medium">TRIGGER</button>
                              </div>
                            )}

                            {vault.status === "triggered" && (
                              <div className="flex items-center gap-2">
                                <input data-testid={`input-cv-beacon-${vault.id}`} value={cvBeaconAddr[vault.id] || ""} onChange={e => setCvBeaconAddr(prev => ({ ...prev, [vault.id]: e.target.value }))} className="px-3 py-1.5 bg-[#0d1117] border border-gray-700 rounded text-xs text-gray-200 w-80" placeholder="New address interacting with customer's decoy tokens..." />
                                <button data-testid={`button-cv-beacon-${vault.id}`} onClick={async () => {
                                  const addr = cvBeaconAddr[vault.id];
                                  if (!addr) return;
                                  try {
                                    await apiRequest("POST", `/api/forensic/command-center/customer-vault/${vault.id}/beacon`, { interactingAddress: addr });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/customer-vaults"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                    setCvBeaconAddr(prev => ({ ...prev, [vault.id]: "" }));
                                  } catch {}
                                }} className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-medium">LOG BEACON HIT</button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {activeTab === "freeze" && (
            <motion.div key="freeze" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {freezeRequests && freezeRequests.length > 0 && <FreezeRequestCharts freezeRequests={freezeRequests} />}
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400" data-testid="text-freeze-title">Exchange Freeze Requests</h2>
                <button data-testid="button-new-freeze" onClick={() => {
                  setShowFreezeForm(!showFreezeForm);
                  const cid = selectedCase || cases?.[0]?.id || "";
                  setFreezeForm(f => ({ ...f, caseId: cid }));
                }} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm font-medium transition-colors">
                  + New Freeze Request
                </button>
              </div>

              {showFreezeForm && (() => {
                const EXCHANGE_COMPLIANCE: Record<string, string> = {
                  "Binance": "law-enforcement@binance.com",
                  "Coinbase": "compliance@coinbase.com",
                  "Kraken": "compliance@kraken.com",
                  "Bybit": "compliance@bybit.com",
                  "OKX": "compliance@okx.com",
                  "KuCoin": "compliance@kucoin.com",
                  "Gate.io": "compliance@gate.io",
                  "Bitget": "compliance@bitget.com",
                  "MEXC": "compliance@mexc.com",
                  "HTX": "compliance@htx.com",
                  "Bitfinex": "compliance@bitfinex.com",
                  "Bitstamp": "compliance@bitstamp.net",
                  "Gemini": "compliance@gemini.com",
                  "Crypto.com": "compliance@crypto.com",
                  "LBank": "compliance@lbank.com",
                  "CoinEx": "compliance@coinex.com",
                  "Upbit": "compliance@upbit.com",
                  "Bithumb": "compliance@bithumb.com",
                  "Bitflyer": "compliance@bitflyer.com",
                  "Robinhood": "crypto-compliance@robinhood.com",
                  "eToro": "compliance@etoro.com",
                  "Deribit": "compliance@deribit.com",
                  "BitMEX": "compliance@bitmex.com",
                  "PrimeXBT": "compliance@primexbt.com",
                  "Phemex": "compliance@phemex.com",
                  "Coinbase Advanced": "compliance@coinbase.com",
                  "Binance.US": "compliance@binance.us",
                  "Uniswap": "legal@uniswap.org",
                  "1inch": "legal@1inch.io",
                  "PancakeSwap": "legal@pancakeswap.finance",
                  "Luno": "compliance@luno.com",
                  "Changelly": "compliance@changelly.com",
                  "ChangeNOW": "compliance@changenow.io",
                  "FixedFloat": "compliance@fixedfloat.com",
                  "CoW Swap": "legal@cow.fi",
                  "Thorchain": "N/A (decentralized)",
                  "Stargate Bridge": "N/A (decentralized)",
                  "Across Bridge": "N/A (decentralized)",
                  "Hop Protocol": "N/A (decentralized)",
                  "Arbitrum Bridge": "N/A (native bridge)",
                  "Optimism Bridge": "N/A (native bridge)",
                  "Circle (USDC Issuer)": "compliance@circle.com",
                  "Tether (USDT Issuer)": "compliance@tether.to",
                };

                const caseWallets = wallets?.filter((w: any) => w.caseId === freezeForm.caseId) || [];
                const exchangeRelatedWallets = caseWallets.filter((w: any) => {
                  const r = (w.role || "").toLowerCase();
                  const l = (w.label || "").toLowerCase();
                  return r.includes("defi") || r.includes("exchange") || r.includes("bridge") || r.includes("settlement") || r.includes("destination") || r.includes("receiver") || r.includes("laundering") || r.includes("split") || r.includes("poi") ||
                    l.includes("swap") || l.includes("bridge") || l.includes("pool") || l.includes("exchange") || l.includes("cow") || l.includes("uniswap") || l.includes("1inch");
                });
                const walletsWithBalance = caseWallets.filter((w: any) => (w.lastKnownBalanceUsd || 0) > 0.01);

                const detectedExchanges: { name: string; wallet?: any }[] = [];
                for (const w of caseWallets) {
                  const l = ((w as any).label || "").toLowerCase();
                  if (l.includes("cow swap") || l.includes("cowswap")) detectedExchanges.push({ name: "CoW Swap", wallet: w });
                  if (l.includes("uniswap")) detectedExchanges.push({ name: "Uniswap", wallet: w });
                  if (l.includes("bridge2") || l.includes("bridge pool") || l.includes("stargate")) detectedExchanges.push({ name: "Stargate Bridge", wallet: w });
                  if (l.includes("arbitrum") && ((w as any).role || "").toLowerCase().includes("receiver")) detectedExchanges.push({ name: "Arbitrum Bridge", wallet: w });
                }

                return (
                <div className="bg-[#161b22] rounded-xl border border-blue-900/30 p-4 mb-4">
                  <h3 className="text-sm font-semibold text-blue-400 mb-3">Send Freeze Request to Exchange</h3>
                  {detectedExchanges.length > 0 && (
                    <div className="bg-blue-900/20 border border-blue-800/40 rounded-lg p-3 mb-3">
                      <div className="text-xs font-semibold text-blue-400 mb-2">Detected Protocols/Exchanges in Fund Flow:</div>
                      <div className="flex flex-wrap gap-2">
                        {detectedExchanges.map((de, i) => {
                          const relatedAddrs = detectedExchanges.filter(d => d.name === de.name).map(d => d.wallet?.address).filter(Boolean) as string[];
                          return (
                            <button key={i} data-testid={`button-detected-exchange-${i}`} onClick={() => {
                              setFreezeForm(f => ({
                                ...f,
                                exchangeName: de.name,
                                exchangeEmail: EXCHANGE_COMPLIANCE[de.name] || "",
                                chain: de.wallet?.chain || f.chain,
                              }));
                              setFreezeSelectedWallets(prev => {
                                const combined = new Set([...prev, ...relatedAddrs]);
                                return Array.from(combined);
                              });
                            }} className="px-2 py-1 bg-blue-900/40 border border-blue-700/50 hover:bg-blue-800/50 rounded text-xs text-blue-300 transition-colors">
                              {de.name} {relatedAddrs.length > 1 ? `(${relatedAddrs.length} wallets)` : de.wallet ? `(${de.wallet.address.substring(0,8)}...)` : ""}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Case</label>
                      <select data-testid="select-freeze-case" value={freezeForm.caseId} onChange={e => setFreezeForm(f => ({ ...f, caseId: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        <option value="">Select case...</option>
                        {cases?.map(c => <option key={c.id} value={c.id}>{c.caseName}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Exchange / Protocol</label>
                      <select data-testid="select-freeze-exchange" value={freezeForm.exchangeName} onChange={e => {
                        setFreezeForm(f => ({ ...f, exchangeName: e.target.value, exchangeEmail: EXCHANGE_COMPLIANCE[e.target.value] || "" }));
                      }} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        <option value="">Select exchange...</option>
                        <optgroup label="Major Centralized Exchanges">
                          {["Binance", "Coinbase", "Kraken", "Bybit", "OKX", "KuCoin", "Gate.io", "Bitget", "MEXC", "HTX", "Bitfinex", "Bitstamp", "Gemini", "Crypto.com", "LBank", "CoinEx", "Upbit", "Bithumb", "Bitflyer", "Robinhood", "eToro", "Coinbase Advanced", "Binance.US"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                        <optgroup label="Derivatives / Margin">
                          {["Deribit", "BitMEX", "PrimeXBT", "Phemex"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                        <optgroup label="DEX / DeFi">
                          {["Uniswap", "CoW Swap", "1inch", "PancakeSwap"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                        <optgroup label="Bridges">
                          {["Stargate Bridge", "Across Bridge", "Hop Protocol", "Arbitrum Bridge", "Optimism Bridge"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                        <optgroup label="Swap Services">
                          {["Changelly", "ChangeNOW", "FixedFloat", "Luno", "Thorchain"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                        <optgroup label="Stablecoin Issuers">
                          {["Circle (USDC Issuer)", "Tether (USDT Issuer)"].map(ex => <option key={ex} value={ex}>{ex}</option>)}
                        </optgroup>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Exchange Compliance Email</label>
                      <input data-testid="input-freeze-email" value={freezeForm.exchangeEmail} onChange={e => setFreezeForm(f => ({ ...f, exchangeEmail: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" placeholder="compliance@exchange.com" />
                      {freezeForm.exchangeEmail && freezeForm.exchangeEmail.startsWith("N/A") && (
                        <div className="text-xs text-yellow-400/70 mt-1">Decentralized protocol — no compliance dept. Consider Circle/Tether for stablecoin freezes.</div>
                      )}
                    </div>
                    <div className="col-span-2">
                      <label className="text-xs text-gray-500 mb-1 block">
                        Wallet Addresses to Freeze {freezeSelectedWallets.length > 0 && <span className="text-blue-400 font-semibold">({freezeSelectedWallets.length} selected — est. ${caseWallets.filter((w: any) => freezeSelectedWallets.includes(w.address)).reduce((s: number, w: any) => s + (w.lastKnownBalanceUsd || 0), 0).toLocaleString(undefined, {maximumFractionDigits: 2})})</span>}
                      </label>
                      {caseWallets.length > 0 ? (
                        <div className="bg-[#0d1117] border border-gray-700 rounded max-h-48 overflow-y-auto">
                          <div className="flex items-center gap-2 px-3 py-1.5 border-b border-gray-800">
                            <button data-testid="button-freeze-select-all" onClick={() => {
                              if (freezeSelectedWallets.length === caseWallets.length) setFreezeSelectedWallets([]);
                              else setFreezeSelectedWallets(caseWallets.map((w: any) => w.address));
                            }} className="text-[10px] text-blue-400 hover:text-blue-300">
                              {freezeSelectedWallets.length === caseWallets.length ? "Deselect All" : "Select All"}
                            </button>
                            <button data-testid="button-freeze-select-poi" onClick={() => {
                              const poiAddrs = caseWallets.filter((w: any) => {
                                const r = (w.role || "").toLowerCase();
                                const l = (w.label || "").toLowerCase();
                                return r.includes("poi") || r.includes("attacker") || l.includes("person of interest") || r.includes("laundering") || r.includes("split") || r.includes("receiver") || r.includes("destination");
                              }).map((w: any) => w.address);
                              setFreezeSelectedWallets(poiAddrs);
                            }} className="text-[10px] text-red-400 hover:text-red-300">
                              Select Attacker Wallets
                            </button>
                            <button data-testid="button-freeze-select-balance" onClick={() => {
                              const withBal = caseWallets.filter((w: any) => (w.lastKnownBalanceUsd || 0) > 1).map((w: any) => w.address);
                              setFreezeSelectedWallets(withBal);
                            }} className="text-[10px] text-green-400 hover:text-green-300">
                              Select With Balance
                            </button>
                          </div>
                          {caseWallets.map((w: any) => {
                            const checked = freezeSelectedWallets.includes(w.address);
                            const r = (w.role || "").toLowerCase();
                            const isAttacker = r.includes("poi") || r.includes("attacker") || r.includes("laundering") || r.includes("split");
                            return (
                              <label key={w.address} className={`flex items-center gap-2 px-3 py-1.5 hover:bg-gray-800/50 cursor-pointer border-b border-gray-900/50 ${checked ? "bg-blue-900/20" : ""}`}>
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => {
                                    setFreezeSelectedWallets(prev =>
                                      prev.includes(w.address) ? prev.filter(a => a !== w.address) : [...prev, w.address]
                                    );
                                  }}
                                  className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-[#0d1117]"
                                  data-testid={`checkbox-freeze-wallet-${w.address.substring(0, 8)}`}
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className={`text-xs font-medium ${isAttacker ? "text-red-400" : "text-gray-300"}`}>{w.label || w.role}</span>
                                    <span className="text-[10px] text-gray-600">({w.chain})</span>
                                    {isAttacker && <span className="text-[9px] px-1 py-0.5 bg-red-900/40 text-red-400 rounded">POI</span>}
                                  </div>
                                  <div className="text-[10px] font-mono text-gray-500">{w.address}</div>
                                </div>
                                <span className={`text-xs font-medium ${(w.lastKnownBalanceUsd || 0) > 100 ? "text-green-400" : (w.lastKnownBalanceUsd || 0) > 0 ? "text-gray-400" : "text-gray-600"}`}>
                                  ${Number(w.lastKnownBalanceUsd || 0).toLocaleString(undefined, {maximumFractionDigits: 2})}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      ) : (
                        <input data-testid="input-freeze-wallet-manual" value={freezeForm.walletAddress} onChange={e => setFreezeForm(f => ({ ...f, walletAddress: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" placeholder="0x..." />
                      )}
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Chain</label>
                      <select data-testid="select-freeze-chain" value={freezeForm.chain} onChange={e => setFreezeForm(f => ({ ...f, chain: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200">
                        {ALL_CHAIN_OPTIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Estimated Value (USD)</label>
                      <input data-testid="input-freeze-value" type="number" value={freezeForm.estimatedValueUsd} onChange={e => setFreezeForm(f => ({ ...f, estimatedValueUsd: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" placeholder="0" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Bounty % (default 10%)</label>
                      <input data-testid="input-freeze-bounty" type="number" value={freezeForm.bountyPercentage} onChange={e => setFreezeForm(f => ({ ...f, bountyPercentage: e.target.value }))} className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200" />
                    </div>
                  </div>
                  <div className="mt-3">
                    <label className="text-xs text-gray-500 mb-1 block">Bounty Wallet Address (where to receive your bounty payment)</label>
                    <input
                      data-testid="input-freeze-bounty-wallet"
                      value={freezeForm.bountyWalletAddress}
                      onChange={e => setFreezeForm(f => ({ ...f, bountyWalletAddress: e.target.value }))}
                      className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono"
                      placeholder="0x... / bc1... / T... — Your wallet to receive bounty funds"
                    />
                    {freezeForm.bountyWalletAddress && freezeForm.bountyPercentage && freezeForm.estimatedValueUsd && (
                      <div className="mt-1 text-[10px] text-green-400/70">
                        Estimated bounty: ${((parseFloat(freezeForm.estimatedValueUsd) || 0) * (parseFloat(freezeForm.bountyPercentage) || 10) / 100).toLocaleString()} USD &rarr; {freezeForm.bountyWalletAddress.slice(0, 10)}...{freezeForm.bountyWalletAddress.slice(-6)}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 mt-3 items-center">
                    <button data-testid="button-send-freeze" onClick={async () => {
                      const addrs = freezeSelectedWallets.length > 0 ? freezeSelectedWallets : (freezeForm.walletAddress ? [freezeForm.walletAddress] : []);
                      if (!freezeForm.caseId || addrs.length === 0 || !freezeForm.exchangeName) return;
                      try {
                        if (addrs.length === 1) {
                          await apiRequest("POST", "/api/forensic/command-center/freeze-request", {
                            ...freezeForm,
                            walletAddress: addrs[0],
                            estimatedValueUsd: parseFloat(freezeForm.estimatedValueUsd) || 0,
                            bountyPercentage: parseFloat(freezeForm.bountyPercentage) || 10,
                          });
                        } else {
                          await apiRequest("POST", "/api/forensic/command-center/freeze-request-batch", {
                            caseId: freezeForm.caseId,
                            walletAddresses: addrs,
                            exchangeName: freezeForm.exchangeName,
                            exchangeEmail: freezeForm.exchangeEmail,
                            chain: freezeForm.chain,
                            bountyPercentage: parseFloat(freezeForm.bountyPercentage) || 10,
                            bountyWalletAddress: freezeForm.bountyWalletAddress || null,
                          });
                        }
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/freeze-requests"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                        setShowFreezeForm(false);
                        setFreezeForm({ caseId: "", walletAddress: "", exchangeName: "", exchangeEmail: "", chain: "ethereum", estimatedValueUsd: "", bountyPercentage: "10", bountyWalletAddress: "" });
                        setFreezeSelectedWallets([]);
                      } catch {}
                    }} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-sm font-medium">
                      {freezeSelectedWallets.length > 1 ? `Send ${freezeSelectedWallets.length} Freeze Requests` : "Send Freeze Request"}
                    </button>
                    <button data-testid="button-cancel-freeze" onClick={() => { setShowFreezeForm(false); setFreezeSelectedWallets([]); }} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-sm">Cancel</button>
                    {freezeSelectedWallets.length > 1 && (
                      <span className="text-xs text-blue-400/70">One freeze request per wallet will be created for {freezeForm.exchangeName || "the selected exchange"}</span>
                    )}
                  </div>
                </div>
                );
              })()}

              <div className="grid grid-cols-4 gap-3 mb-4">
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                  <div className="text-2xl font-bold text-blue-400" data-testid="text-freeze-total">{freezeRequests?.length || 0}</div>
                  <div className="text-xs text-gray-500">Total Requests</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-yellow-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-400" data-testid="text-freeze-pending">{pendingFreezes}</div>
                  <div className="text-xs text-gray-500">Pending</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-cyan-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-cyan-400" data-testid="text-freeze-frozen">{freezeRequests?.filter((f: any) => f.status === "frozen")?.length || 0}</div>
                  <div className="text-xs text-gray-500">Frozen</div>
                </div>
                <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-4 text-center">
                  <div className="text-2xl font-bold text-green-400" data-testid="text-freeze-bounty">
                    ${(freezeRequests?.filter((f: any) => f.status === "frozen")?.reduce((sum: number, f: any) => sum + (f.bountyEstimateUsd || 0), 0) || 0).toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-500">Bounty Earned</div>
                </div>
              </div>

              <div className="bg-[#161b22] rounded-xl border border-gray-800/30 overflow-hidden">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-gray-800/50 text-gray-500">
                      <th className="px-3 py-2 text-left">Exchange</th>
                      <th className="px-3 py-2 text-left">Wallet</th>
                      <th className="px-3 py-2 text-left">Chain</th>
                      <th className="px-3 py-2 text-right">Est. Value</th>
                      <th className="px-3 py-2 text-right">Bounty</th>
                      <th className="px-3 py-2 text-left">Bounty Wallet</th>
                      <th className="px-3 py-2 text-center">Status</th>
                      <th className="px-3 py-2 text-left">Sent</th>
                      <th className="px-3 py-2 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {freezeRequests?.map((fr: any) => (
                      <tr key={fr.id} className={`border-b border-gray-800/20 hover:bg-gray-800/20 ${fr.status === "frozen" ? "bg-cyan-900/10" : ""}`}>
                        <td className="px-3 py-2 font-medium text-gray-200">{fr.exchangeName}</td>
                        <td className="px-3 py-2 font-mono text-cyan-500">{fr.walletAddress?.slice(0, 8)}...{fr.walletAddress?.slice(-6)}</td>
                        <td className="px-3 py-2 text-gray-400">{fr.chain}</td>
                        <td className="px-3 py-2 text-right text-gray-200">${(fr.estimatedValueUsd || 0).toLocaleString()}</td>
                        <td className="px-3 py-2 text-right text-green-400">${(fr.bountyEstimateUsd || 0).toLocaleString()} <span className="text-gray-600">({fr.bountyPercentage || 10}%)</span></td>
                        <td className="px-3 py-2 font-mono text-amber-400/80">{fr.bountyWalletAddress ? `${fr.bountyWalletAddress.slice(0, 8)}...${fr.bountyWalletAddress.slice(-4)}` : <span className="text-gray-600">—</span>}</td>
                        <td className="px-3 py-2 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            fr.status === "frozen" ? "bg-cyan-900/30 text-cyan-400" :
                            fr.status === "pending" ? "bg-yellow-900/30 text-yellow-400" :
                            fr.status === "rejected" ? "bg-red-900/30 text-red-400" :
                            fr.status === "acknowledged" ? "bg-blue-900/30 text-blue-400" :
                            "bg-gray-800 text-gray-400"
                          }`}>{fr.status?.toUpperCase()}</span>
                        </td>
                        <td className="px-3 py-2 text-gray-500">{new Date(fr.createdAt).toLocaleDateString()}</td>
                        <td className="px-3 py-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            {fr.status === "pending" && (
                              <>
                                <button data-testid={`button-mark-ack-${fr.id}`} onClick={async () => {
                                  await apiRequest("PATCH", `/api/forensic/command-center/freeze-request/${fr.id}`, { status: "acknowledged" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/freeze-requests"] });
                                }} className="px-2 py-0.5 bg-blue-900/30 hover:bg-blue-800/50 text-blue-400 rounded text-[10px]">ACK</button>
                                <button data-testid={`button-mark-frozen-${fr.id}`} onClick={async () => {
                                  await apiRequest("PATCH", `/api/forensic/command-center/freeze-request/${fr.id}`, { status: "frozen" });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/freeze-requests"] });
                                  queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                                }} className="px-2 py-0.5 bg-cyan-900/30 hover:bg-cyan-800/50 text-cyan-400 rounded text-[10px]">FROZEN</button>
                              </>
                            )}
                            {fr.status === "acknowledged" && (
                              <button data-testid={`button-confirm-frozen-${fr.id}`} onClick={async () => {
                                await apiRequest("PATCH", `/api/forensic/command-center/freeze-request/${fr.id}`, { status: "frozen" });
                                queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/freeze-requests"] });
                                queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                              }} className="px-2 py-0.5 bg-cyan-900/30 hover:bg-cyan-800/50 text-cyan-400 rounded text-[10px]">FROZEN</button>
                            )}
                            <button data-testid={`button-view-request-${fr.id}`} onClick={() => {
                              const w = window.open("", "_blank");
                              if (w) { w.document.write(`<pre style="font-family:monospace;white-space:pre-wrap;background:#0a0e14;color:#e6e6e6;padding:20px;">${fr.requestBody || "No request body generated"}</pre>`); w.document.title = `Freeze Request - ${fr.exchangeName}`; }
                            }} className="px-2 py-0.5 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded text-[10px]">VIEW</button>
                            <button data-testid={`button-copy-request-${fr.id}`} onClick={() => { navigator.clipboard.writeText(fr.requestBody || ""); }} className="px-2 py-0.5 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded text-[10px]">COPY</button>
                            <button data-testid={`button-delete-freeze-${fr.id}`} onClick={async () => {
                              await apiRequest("DELETE", `/api/forensic/command-center/freeze-request/${fr.id}`);
                              queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/freeze-requests"] });
                            }} className="px-2 py-0.5 bg-red-900/20 hover:bg-red-800/30 text-red-500 rounded text-[10px]">DEL</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!freezeRequests || freezeRequests.length === 0) && (
                      <tr><td colSpan={8} className="px-3 py-8 text-center text-gray-600">No freeze requests yet. Click "+ New Freeze Request" to send one to an exchange.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {freezeRequests?.some((f: any) => f.status === "frozen") && (
                <div className="mt-4 bg-gradient-to-r from-green-900/20 to-cyan-900/20 rounded-xl border border-green-800/30 p-4">
                  <h3 className="text-sm font-bold text-green-400 mb-2">Bounty Opportunities</h3>
                  <div className="space-y-2">
                    {freezeRequests?.filter((f: any) => f.status === "frozen").map((fr: any) => (
                      <div key={fr.id} className="flex items-center justify-between bg-[#0d1117] rounded-lg p-3">
                        <div>
                          <span className="text-cyan-400 font-medium">{fr.exchangeName}</span>
                          <span className="text-gray-500 mx-2">|</span>
                          <span className="font-mono text-xs text-gray-400">{fr.walletAddress?.slice(0, 12)}...</span>
                        </div>
                        <div className="text-right">
                          <div className="text-green-400 font-bold">${(fr.bountyEstimateUsd || 0).toLocaleString()} bounty</div>
                          <div className="text-[10px] text-gray-500">Frozen {fr.frozenAt ? new Date(fr.frozenAt).toLocaleDateString() : "recently"}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "crosscase" && (
            <motion.div key="crosscase" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {crossCaseIntel && <CrossCaseCharts crossCaseData={crossCaseIntel} />}
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400" data-testid="text-crosscase-title">Cross-Case Intelligence Engine</h2>
                <button
                  data-testid="button-refresh-crosscase"
                  onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/cross-case-intelligence"] })}
                  className="px-3 py-1.5 bg-purple-600/20 border border-purple-600/40 hover:bg-purple-600/30 rounded text-purple-400 text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                  Refresh Cross-Case Links
                </button>
              </div>

              {crossCaseIntel ? (
                <>
                  <div className="grid grid-cols-4 gap-3 mb-4">
                    <div className="bg-[#161b22] rounded-xl border border-purple-900/30 p-4 text-center">
                      <div className="text-2xl font-bold text-purple-400" data-testid="text-cc-cases">{crossCaseIntel.totalCases}</div>
                      <div className="text-xs text-gray-500">Total Cases</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                      <div className="text-2xl font-bold text-cyan-400" data-testid="text-cc-wallets">{crossCaseIntel.totalWallets}</div>
                      <div className="text-xs text-gray-500">Total Wallets</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                      <div className="text-2xl font-bold text-blue-400" data-testid="text-cc-unique">{crossCaseIntel.uniqueAddresses}</div>
                      <div className="text-xs text-gray-500">Unique Addresses</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-4 text-center">
                      <div className="text-2xl font-bold text-red-400" data-testid="text-cc-shared">{crossCaseIntel.sharedAddresses?.length || 0}</div>
                      <div className="text-xs text-gray-500">Shared Addresses (Cross-Case Links)</div>
                    </div>
                  </div>

                  {crossCaseIntel.caseConnections?.length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-4 mb-4">
                      <h3 className="text-sm font-bold text-red-400 mb-3">Case Connections Detected</h3>
                      <div className="space-y-2">
                        {crossCaseIntel.caseConnections.map((conn: any, i: number) => (
                          <div key={i} className="bg-[#0d1117] rounded-lg p-3 border border-red-900/20">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="text-purple-400 font-medium">{conn.caseAName}</span>
                                <span className="text-red-400 font-bold text-lg">&harr;</span>
                                <span className="text-purple-400 font-medium">{conn.caseBName}</span>
                              </div>
                              <span className="px-2 py-0.5 bg-red-900/30 text-red-400 rounded-full text-[10px] font-bold">
                                {conn.connectionStrength} shared address{conn.connectionStrength > 1 ? "es" : ""}
                              </span>
                            </div>
                            <div className="space-y-1">
                              {conn.sharedAddresses.map((addr: string) => {
                                const details = crossCaseIntel.sharedAddresses?.find((sa: any) => sa.address === addr);
                                return (
                                  <div key={addr} className="flex items-center justify-between text-xs bg-[#161b22] rounded px-2 py-1">
                                    <span className="font-mono text-cyan-500">{addr.slice(0, 10)}...{addr.slice(-8)}</span>
                                    <div className="flex items-center gap-2">
                                      {details?.roles?.map((r: string) => (
                                        <span key={r} className="px-1.5 py-0.5 bg-gray-800 rounded text-[10px] text-gray-400">{r}</span>
                                      ))}
                                      {details?.balanceUsd > 0 && <span className="text-green-400">${details.balanceUsd.toLocaleString()}</span>}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {crossCaseIntel.sharedAddresses?.length > 0 ? (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 mb-4">
                      <h3 className="text-sm font-bold text-yellow-400 mb-3">All Shared Addresses Across Cases</h3>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-gray-800/50 text-gray-500">
                              <th className="px-3 py-2 text-left">Address</th>
                              <th className="px-3 py-2 text-center">Cases Linked</th>
                              <th className="px-3 py-2 text-left">Case Names</th>
                              <th className="px-3 py-2 text-left">Roles</th>
                              <th className="px-3 py-2 text-left">Labels</th>
                              <th className="px-3 py-2 text-right">Balance</th>
                            </tr>
                          </thead>
                          <tbody>
                            {crossCaseIntel.sharedAddresses.map((sa: any) => (
                              <tr key={sa.address} className="border-b border-gray-800/20 hover:bg-gray-800/20">
                                <td className="px-3 py-2 font-mono text-cyan-500">{sa.address.slice(0, 10)}...{sa.address.slice(-8)}</td>
                                <td className="px-3 py-2 text-center">
                                  <span className="px-2 py-0.5 bg-red-900/30 text-red-400 rounded-full font-bold">{sa.caseCount}</span>
                                </td>
                                <td className="px-3 py-2">
                                  {sa.caseNames.map((n: string) => (
                                    <span key={n} className="inline-block px-1.5 py-0.5 bg-purple-900/20 text-purple-400 rounded text-[10px] mr-1 mb-0.5">{n}</span>
                                  ))}
                                </td>
                                <td className="px-3 py-2">
                                  {sa.roles.map((r: string) => (
                                    <span key={r} className="inline-block px-1.5 py-0.5 bg-gray-800 text-gray-400 rounded text-[10px] mr-1">{r}</span>
                                  ))}
                                </td>
                                <td className="px-3 py-2 text-gray-400">{sa.labels.join(", ") || "-"}</td>
                                <td className="px-3 py-2 text-right text-green-400">{sa.balanceUsd > 0 ? `$${sa.balanceUsd.toLocaleString()}` : "-"}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center mb-4">
                      <div className="text-gray-500 text-lg mb-2">No Cross-Case Links Found</div>
                      <div className="text-gray-600 text-sm">When multiple cases share common wallet addresses (same attacker, same laundering network), connections will appear here automatically.</div>
                    </div>
                  )}

                  {crossCaseIntel.roleDistribution && Object.keys(crossCaseIntel.roleDistribution).length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">Wallet Role Distribution (All Cases)</h3>
                      <div className="grid grid-cols-4 gap-2">
                        {Object.entries(crossCaseIntel.roleDistribution).sort((a: any, b: any) => b[1] - a[1]).map(([role, count]: any) => (
                          <div key={role} className="bg-[#0d1117] rounded-lg p-2 flex items-center justify-between">
                            <span className="text-xs text-gray-400 capitalize">{role}</span>
                            <span className="text-sm font-bold text-cyan-400">{count}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mt-3 text-[10px] text-gray-600 text-right">
                    Last analyzed: {crossCaseIntel.analysisTimestamp ? new Date(crossCaseIntel.analysisTimestamp).toLocaleString() : "N/A"}
                  </div>
                </>
              ) : (
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center">
                  <div className="text-gray-500 text-lg mb-2">Loading Cross-Case Intelligence...</div>
                  <div className="text-gray-600 text-sm">Analyzing all cases for shared wallet addresses, common attackers, and linked laundering networks.</div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "osint" && (
            <motion.div key="osint" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {osintScanData && osintScanData.status === "complete" && <OsintCharts scanData={osintScanData} />}
              <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-400 mb-1" data-testid="text-osint-title">Alpha OSINT Spider&trade;</h2>
              <p className="text-xs text-gray-500 mb-4">Search the web for wallet address mentions — GitHub, Reddit, Telegram, Twitter/X, forums, blogs, ENS, blockchain labels &amp; more</p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
                <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-4">
                  <h3 className="text-sm font-bold text-green-400 mb-3">Full Case OSINT Scan</h3>
                  <p className="text-xs text-gray-500 mb-3">Scan ALL wallet addresses from a case across 14+ platforms</p>
                  <select
                    data-testid="select-osint-case"
                    value={selectedCase || ""}
                    onChange={e => setSelectedCase(e.target.value || null)}
                    className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 mb-3"
                  >
                    <option value="">Select a case...</option>
                    {cases?.map(c => (
                      <option key={c.id} value={c.id}>{c.caseName} ({wallets?.filter(w => w.caseId === c.id).length || 0} wallets)</option>
                    ))}
                  </select>
                  <button
                    data-testid="button-start-osint-scan"
                    disabled={!selectedCase || osintScanning}
                    onClick={async () => {
                      if (!selectedCase) return;
                      setOsintScanning(true);
                      try {
                        const resp = await fetch("/api/forensic/command-center/osint-scan", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          credentials: "include",
                          body: JSON.stringify({ caseId: selectedCase }),
                        });
                        if (resp.status === 403 || resp.status === 400) {
                          setOsintScanning(false);
                          return;
                        }
                        const data = await resp.json();
                        if (data.scanId) setOsintScanId(data.scanId);
                        else setOsintScanning(false);
                      } catch { setOsintScanning(false); }
                    }}
                    className="w-full px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium"
                  >
                    {osintScanning ? "Scanning..." : "Launch OSINT Spider™ Scan"}
                  </button>
                </div>

                <div className="bg-[#161b22] rounded-xl border border-emerald-900/30 p-4">
                  <h3 className="text-sm font-bold text-emerald-400 mb-3">Single Address Lookup</h3>
                  <p className="text-xs text-gray-500 mb-3">Quick OSINT scan on any individual wallet from the active case</p>
                  {selectedCase && wallets && wallets.length > 0 ? (
                    <select
                      data-testid="select-osint-single-wallet"
                      value={osintSingleAddr}
                      onChange={e => setOsintSingleAddr(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 mb-3"
                    >
                      <option value="">Select a wallet...</option>
                      {wallets.map(w => (
                        <option key={w.id} value={w.address}>
                          {w.label || w.role || "Wallet"} — {w.address.slice(0, 8)}...{w.address.slice(-6)} ({w.chain})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      data-testid="input-osint-single-address"
                      placeholder="Enter wallet address (0x..., bc1..., T...)"
                      value={osintSingleAddr}
                      onChange={e => setOsintSingleAddr(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono mb-3"
                    />
                  )}
                  <input
                    data-testid="input-osint-manual-address"
                    placeholder="Or enter any address manually..."
                    value={!wallets?.find(w => w.address === osintSingleAddr) ? osintSingleAddr : ""}
                    onChange={e => setOsintSingleAddr(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700/50 rounded text-xs text-gray-400 font-mono mb-3"
                  />
                  <button
                    data-testid="button-osint-single-search"
                    disabled={!osintSingleAddr || osintSingleLoading}
                    onClick={async () => {
                      if (!osintSingleAddr) return;
                      setOsintSingleLoading(true);
                      setOsintSingleResults(null);
                      try {
                        const resp = await fetch("/api/forensic/command-center/osint-single", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          credentials: "include",
                          body: JSON.stringify({ address: osintSingleAddr }),
                        });
                        if (resp.status === 403 || resp.status === 400) {
                          setOsintSingleResults([]);
                          setOsintSingleLoading(false);
                          return;
                        }
                        const data = await resp.json();
                        setOsintSingleResults(data.results || []);
                      } catch { setOsintSingleResults([]); }
                      setOsintSingleLoading(false);
                    }}
                    className="w-full px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium"
                  >
                    {osintSingleLoading ? "Searching..." : "Search Address"}
                  </button>
                </div>
              </div>

              {osintScanning && osintScanData && (
                <div className="bg-[#161b22] rounded-xl border border-green-900/40 p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-green-400">Scan in Progress</h3>
                    <span className="text-xs text-gray-500">{osintScanData.totalAddressesScanned}/{osintScanData.totalAddresses} addresses</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2 mb-2">
                    <div className="bg-gradient-to-r from-green-500 to-emerald-400 h-2 rounded-full transition-all duration-500" style={{ width: `${osintScanData.progress || 0}%` }} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{osintScanData.progress || 0}% complete</span>
                    <span>{osintScanData.totalHits || 0} hits found</span>
                  </div>
                </div>
              )}

              {osintScanData && osintScanData.status !== "none" && !osintScanning && (
                <div className="mb-4">
                  <div className="grid grid-cols-4 gap-3 mb-4">
                    <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-4 text-center">
                      <div className="text-2xl font-bold text-green-400" data-testid="text-osint-total-hits">{osintScanData.totalHits || 0}</div>
                      <div className="text-xs text-gray-500">Total Hits</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                      <div className="text-2xl font-bold text-cyan-400">{osintScanData.totalAddressesScanned || 0}</div>
                      <div className="text-xs text-gray-500">Addresses Scanned</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                      <div className="text-2xl font-bold text-emerald-400">{Object.keys(osintScanData.platformBreakdown || {}).length}</div>
                      <div className="text-xs text-gray-500">Platforms with Hits</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 text-center">
                      <div className={`text-2xl font-bold ${osintScanData.status === "complete" ? "text-green-400" : "text-yellow-400"}`}>
                        {osintScanData.status === "complete" ? "✓" : osintScanData.status === "error" ? "✗" : "..."}
                      </div>
                      <div className="text-xs text-gray-500">{osintScanData.status === "complete" ? "Complete" : osintScanData.status}</div>
                    </div>
                  </div>

                  {osintScanData.platformBreakdown && Object.keys(osintScanData.platformBreakdown).length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4 mb-4">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">Platform Breakdown</h3>
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                        {Object.entries(osintScanData.platformBreakdown).sort((a: any, b: any) => b[1] - a[1]).map(([platform, count]: any) => {
                          const colors: Record<string, string> = {
                            GitHub: "text-gray-200", Reddit: "text-orange-400", "Twitter/X": "text-blue-400",
                            Telegram: "text-sky-400", ENS: "text-purple-400", DeBank: "text-yellow-400",
                            Etherscan: "text-blue-300", Medium: "text-green-300", BitcoinTalk: "text-orange-300",
                            "Web (Incident Reports)": "text-red-400", "Web3 Blogs": "text-pink-400",
                            "Dark Web (.onion)": "text-red-500", "Ahmia (Tor Index)": "text-red-400",
                            "Brave Search": "text-orange-300", "Pastebin Dumps": "text-amber-400",
                            Rentry: "text-amber-300", Chainabuse: "text-red-300", Blockchair: "text-emerald-400",
                            "Underground Forums": "text-red-500", "Mixing Services": "text-violet-400",
                            "Dark Web Mentions": "text-red-400", "Exploit References": "text-rose-400",
                            "Paste/Leak Sites": "text-amber-400", "Mempool.space": "text-cyan-400",
                          };
                          return (
                            <div key={platform} className="bg-[#0d1117] rounded-lg p-2 flex items-center justify-between">
                              <span className={`text-xs ${colors[platform] || "text-gray-400"}`}>{platform}</span>
                              <span className="text-sm font-bold text-green-400">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {(osintScanData.results?.length > 0) && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4">
                      <h3 className="text-sm font-bold text-green-400 mb-3">OSINT Results ({osintScanData.results.length} mentions found)</h3>
                      <div className="space-y-2 max-h-[600px] overflow-y-auto">
                        {osintScanData.results.map((r: any, i: number) => {
                          const platformColors: Record<string, string> = {
                            GitHub: "border-gray-500/30 bg-gray-900/20", Reddit: "border-orange-500/30 bg-orange-900/10",
                            "Twitter/X": "border-blue-500/30 bg-blue-900/10", Telegram: "border-sky-500/30 bg-sky-900/10",
                            ENS: "border-purple-500/30 bg-purple-900/10", DeBank: "border-yellow-500/30 bg-yellow-900/10",
                            Etherscan: "border-blue-400/30 bg-blue-900/10", Medium: "border-green-400/30 bg-green-900/10",
                            "Web (Incident Reports)": "border-red-500/30 bg-red-900/10", "Web3 Blogs": "border-pink-500/30 bg-pink-900/10",
                            "Dark Web (.onion)": "border-red-700/40 bg-red-950/30", "Ahmia (Tor Index)": "border-red-600/30 bg-red-950/20",
                            "Brave Search": "border-orange-400/30 bg-orange-950/10", "Pastebin Dumps": "border-amber-500/30 bg-amber-950/10",
                            Rentry: "border-amber-400/30 bg-amber-950/10", Chainabuse: "border-red-400/30 bg-red-950/20",
                            Blockchair: "border-emerald-500/30 bg-emerald-950/10", "Underground Forums": "border-red-800/40 bg-red-950/30",
                            "Mixing Services": "border-violet-600/30 bg-violet-950/20", "Dark Web Mentions": "border-red-700/30 bg-red-950/20",
                            "Exploit References": "border-rose-600/30 bg-rose-950/20", "Paste/Leak Sites": "border-amber-600/30 bg-amber-950/20",
                            "Mempool.space": "border-cyan-500/30 bg-cyan-950/10",
                          };
                          const matchColors: Record<string, string> = {
                            verified: "bg-green-900/40 text-green-400", ens_linked: "bg-purple-900/40 text-purple-400",
                            label: "bg-blue-900/40 text-blue-400", web_mention: "bg-yellow-900/40 text-yellow-400",
                          };
                          return (
                            <div key={i} className={`rounded-lg border p-3 ${platformColors[r.platform] || "border-gray-800/30 bg-[#0d1117]"}`} data-testid={`osint-result-${i}`}>
                              <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center gap-2">
                                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${matchColors[r.matchType] || "bg-gray-800 text-gray-400"}`}>{r.matchType === "web_mention" ? "WEB MENTION" : r.matchType === "ens_linked" ? "ENS IDENTITY" : r.matchType === "label" ? "LABELED" : r.matchType.toUpperCase()}</span>
                                  {r.verified && <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-green-900/30 text-green-500 border border-green-800/40">VERIFIED</span>}
                                  <span className="text-xs font-bold text-gray-300">{r.platform}</span>
                                  {r.context && <span className="text-[10px] text-gray-600">{r.context}</span>}
                                </div>
                                <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-cyan-500 hover:text-cyan-400 underline" data-testid={`link-osint-${i}`}>Open &rarr;</a>
                              </div>
                              <div className="text-sm text-gray-200 font-medium mb-1">{r.title}</div>
                              <div className="text-xs text-gray-400 mb-1">{r.snippet}</div>
                              <div className="flex items-center gap-3 text-[10px] text-gray-600">
                                <span className="font-mono">{r.address.slice(0, 10)}...{r.address.slice(-6)}</span>
                                {r.author && <span>by {r.author}</span>}
                                {r.datePosted && <span>{new Date(r.datePosted).toLocaleDateString()}</span>}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {osintSingleResults !== null && (
                <div className="bg-[#161b22] rounded-xl border border-emerald-900/30 p-4 mb-4">
                  <h3 className="text-sm font-bold text-emerald-400 mb-3">
                    Single Address Results: <span className="font-mono text-cyan-400">{osintSingleAddr.slice(0, 10)}...{osintSingleAddr.slice(-6)}</span>
                    <span className="ml-2 text-gray-500 font-normal">({osintSingleResults.length} hit{osintSingleResults.length !== 1 ? "s" : ""})</span>
                  </h3>
                  {osintSingleResults.length > 0 ? (
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                      {osintSingleResults.map((r: any, i: number) => {
                        const matchColors: Record<string, string> = {
                          verified: "bg-green-900/40 text-green-400", ens_linked: "bg-purple-900/40 text-purple-400",
                          label: "bg-blue-900/40 text-blue-400", web_mention: "bg-yellow-900/40 text-yellow-400",
                        };
                        return (
                          <div key={i} className="bg-[#0d1117] rounded-lg border border-gray-800/30 p-3" data-testid={`osint-single-result-${i}`}>
                            <div className="flex items-center justify-between mb-1">
                              <div className="flex items-center gap-2">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${matchColors[r.matchType] || "bg-gray-800 text-gray-400"}`}>{r.matchType === "web_mention" ? "WEB MENTION" : r.matchType === "ens_linked" ? "ENS IDENTITY" : r.matchType === "label" ? "LABELED" : r.matchType.toUpperCase()}</span>
                                {r.verified && <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-green-900/30 text-green-500 border border-green-800/40">VERIFIED</span>}
                                <span className="text-xs font-bold text-gray-300">{r.platform}</span>
                              </div>
                              <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-cyan-500 hover:text-cyan-400 underline">Open &rarr;</a>
                            </div>
                            <div className="text-sm text-gray-200 font-medium mb-1">{r.title}</div>
                            <div className="text-xs text-gray-400">{r.snippet}</div>
                            {r.author && <div className="text-[10px] text-gray-600 mt-1">by {r.author}</div>}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <div className="text-gray-500 text-sm">No online mentions found for this address</div>
                      <div className="text-gray-600 text-xs mt-1">This wallet has no public digital footprint across the searched platforms</div>
                    </div>
                  )}
                </div>
              )}

              {!osintScanData && !osintSingleResults && !osintScanning && (
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center">
                  <div className="text-4xl mb-3">🕸️</div>
                  <div className="text-gray-400 text-lg font-bold mb-2">Alpha OSINT Spider&trade;</div>
                  <div className="text-gray-500 text-sm mb-4 max-w-xl mx-auto">
                    Searches the entire surface web, dark web, paste sites, underground forums, and blockchain analytics for wallet address mentions across 22+ platforms — including Tor hidden services via Ahmia, Brave Search, Chainabuse fraud reports, Blockchair analytics, paste dumps, mixing service references, and more. Use this to uncover the identity behind attacker wallets.
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-w-2xl mx-auto">
                    {["GitHub", "Reddit", "Twitter/X", "Telegram", "ENS Domains", "Etherscan Labels", "DeBank", "Medium", "BitcoinTalk", "Web3 Blogs", "Incident Reports", "Dark Web (.onion)", "Ahmia (Tor)", "Brave Search", "Paste Dumps", "Chainabuse", "Blockchair", "Underground Forums", "Mixing Services", "Exploit Refs", "Leak Sites", "Mempool.space"].map(p => (
                      <div key={p} className={`bg-[#0d1117] rounded-lg px-3 py-2 text-xs border border-gray-800/30 ${p.includes("Dark Web") || p.includes("Underground") || p.includes("Mixing") ? "text-red-400 border-red-900/30" : p.includes("Ahmia") || p.includes("Tor") ? "text-red-300 border-red-800/20" : "text-gray-400"}`}>{p}</div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "originintel" && (
            <motion.div key="originintel" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {originTraceData && <OriginIntelCharts traceData={originTraceData} />}
              <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400 mb-1" data-testid="text-originintel-title">Alpha Transaction Origin Intelligence&trade;</h2>
              <p className="text-gray-500 text-xs mb-4">Traces incoming transactions to attacker wallets, profiles every source address, discovers connected websites/services, performs WHOIS lookups, and identifies protocol interactions to unmask the attacker.</p>

              <div className="bg-[#161b22] rounded-xl border border-amber-900/30 p-4 mb-4">
                <h3 className="text-sm font-bold text-amber-400 mb-3">Trace Incoming Transaction Sources</h3>
                {!selectedCase && <p className="text-red-400 text-xs mb-2">Select a case first from the Cases tab</p>}
                {selectedCase && (() => {
                  const caseWallets = (wallets || []).filter((w: any) => w.caseId === selectedCase);
                  const ethWallets = caseWallets.filter((w: any) => /^0x[a-fA-F0-9]{40}$/.test(w.address));
                  return (
                    <div>
                      <div className="bg-[#0d1117] border border-gray-800 rounded-lg mb-3 max-h-56 overflow-y-auto">
                        <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-800 sticky top-0 bg-[#0d1117] z-10">
                          <span className="text-xs text-gray-500 flex-1">
                            {originSelectedAddrs.length > 0 ? <span className="text-amber-400 font-semibold">{originSelectedAddrs.length} wallet{originSelectedAddrs.length > 1 ? "s" : ""} selected</span> : "Select wallets to trace"}
                          </span>
                          <button data-testid="button-origin-select-all" onClick={() => {
                            if (originSelectedAddrs.length === ethWallets.length) setOriginSelectedAddrs([]);
                            else setOriginSelectedAddrs(ethWallets.map((w: any) => w.address));
                          }} className="text-[10px] text-blue-400 hover:text-blue-300 font-semibold">
                            {originSelectedAddrs.length === ethWallets.length ? "Deselect All" : "Select All"}
                          </button>
                          <button data-testid="button-origin-select-attackers" onClick={() => {
                            const attackerAddrs = ethWallets.filter((w: any) => {
                              const r = (w.role || "").toLowerCase();
                              return r.includes("poi") || r.includes("attacker") || r.includes("laundering") || r.includes("split") || r.includes("receiver") || r.includes("destination");
                            }).map((w: any) => w.address);
                            setOriginSelectedAddrs(attackerAddrs);
                          }} className="text-[10px] text-red-400 hover:text-red-300 font-semibold">
                            Attacker Wallets
                          </button>
                        </div>
                        {ethWallets.length === 0 && <div className="px-3 py-4 text-xs text-gray-600 text-center">No Ethereum wallets found in this case</div>}
                        {ethWallets.map((w: any) => {
                          const checked = originSelectedAddrs.includes(w.address);
                          const r = (w.role || "").toLowerCase();
                          const isAttacker = r.includes("poi") || r.includes("attacker") || r.includes("laundering") || r.includes("split");
                          return (
                            <label key={w.address} className={`flex items-center gap-2 px-3 py-1.5 hover:bg-gray-800/50 cursor-pointer border-b border-gray-900/50 ${checked ? "bg-amber-900/10" : ""}`}>
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => setOriginSelectedAddrs(prev => prev.includes(w.address) ? prev.filter(a => a !== w.address) : [...prev, w.address])}
                                className="rounded border-gray-600 text-amber-500 focus:ring-amber-500 bg-[#0d1117]"
                                data-testid={`checkbox-origin-wallet-${w.address.substring(0, 8)}`}
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className={`text-xs font-medium ${isAttacker ? "text-red-400" : "text-gray-300"}`}>{w.label || w.role}</span>
                                  <span className="text-[10px] text-gray-600">({w.chain})</span>
                                  {isAttacker && <span className="text-[9px] px-1 py-0.5 bg-red-900/40 text-red-400 rounded">POI</span>}
                                </div>
                                <div className="text-[10px] font-mono text-gray-500">{w.address}</div>
                              </div>
                              <span className={`text-xs font-medium ${(w.lastKnownBalanceUsd || 0) > 100 ? "text-green-400" : "text-gray-600"}`}>
                                ${Number(w.lastKnownBalanceUsd || 0).toLocaleString(undefined, {maximumFractionDigits: 2})}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                      <div className="flex gap-2 items-center">
                        <button
                          disabled={originBatchTracing || originSelectedAddrs.length === 0}
                          onClick={async () => {
                            setOriginBatchTracing(true);
                            setOriginBatchResults([]);
                            setOriginBatchProgress({});
                            setOriginTraceData(null);
                            const traceIds: { addr: string; traceId: string }[] = [];
                            const BATCH_SIZE = 10;
                            for (let batch = 0; batch < originSelectedAddrs.length; batch += BATCH_SIZE) {
                              const chunk = originSelectedAddrs.slice(batch, batch + BATCH_SIZE);
                              const promises = chunk.map(async (addr) => {
                                try {
                                  const resp = await fetch("/api/forensic/command-center/origin-trace", {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ targetAddress: addr, caseId: selectedCase }),
                                  });
                                  if (resp.status === 403 || resp.status === 400) {
                                    setOriginBatchProgress(prev => ({ ...prev, [addr]: { status: "error" } }));
                                    return;
                                  }
                                  const data = await resp.json();
                                  if (data.traceId) {
                                    traceIds.push({ addr, traceId: data.traceId });
                                    setOriginBatchProgress(prev => ({ ...prev, [addr]: { status: "running", traceId: data.traceId, progress: 0 } }));
                                  } else {
                                    setOriginBatchProgress(prev => ({ ...prev, [addr]: { status: "error" } }));
                                  }
                                } catch {
                                  setOriginBatchProgress(prev => ({ ...prev, [addr]: { status: "error" } }));
                                }
                              });
                              await Promise.all(promises);
                              if (batch + BATCH_SIZE < originSelectedAddrs.length) await new Promise(r => setTimeout(r, 300));
                            }
                            const pollAll = setInterval(async () => {
                              let allDone = true;
                              const POLL_BATCH = 20;
                              for (let pb = 0; pb < traceIds.length; pb += POLL_BATCH) {
                                const pollChunk = traceIds.slice(pb, pb + POLL_BATCH);
                                const pollResults = await Promise.all(pollChunk.map(async ({ addr, traceId }) => {
                                  try {
                                    const r = await fetch(`/api/forensic/command-center/origin-trace/${traceId}`);
                                    const d = await r.json();
                                    return { addr, traceId, data: d };
                                  } catch { return { addr, traceId, data: null }; }
                                }));
                                for (const { addr, traceId, data: d } of pollResults) {
                                  if (d) {
                                    setOriginBatchProgress(prev => ({ ...prev, [addr]: { ...d, traceId } }));
                                    if (d.status !== "complete" && d.status !== "error") allDone = false;
                                  } else { allDone = false; }
                                }
                              }
                              if (allDone) {
                                clearInterval(pollAll);
                                setOriginBatchTracing(false);
                                const finalResults: any[] = [];
                                for (const { addr, traceId } of traceIds) {
                                  try {
                                    const r = await fetch(`/api/forensic/command-center/origin-trace/${traceId}`);
                                    const d = await r.json();
                                    finalResults.push({ address: addr, ...d });
                                  } catch {}
                                }
                                setOriginBatchResults(finalResults);
                                if (finalResults.length === 1) setOriginTraceData(finalResults[0]);
                              }
                            }, 5000);
                          }}
                          className="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 rounded-lg text-sm font-bold text-white hover:from-amber-500 hover:to-orange-500 disabled:opacity-40"
                          data-testid="button-origin-trace-batch"
                        >
                          {originBatchTracing ? `Tracing ${originSelectedAddrs.length} wallet${originSelectedAddrs.length > 1 ? "s" : ""}...` : `Trace ${originSelectedAddrs.length > 0 ? originSelectedAddrs.length : ""} Origin${originSelectedAddrs.length !== 1 ? "s" : ""}`}
                        </button>
                        {originBatchTracing && (
                          <span className="text-xs text-amber-400/70">
                            {Object.values(originBatchProgress).filter((p: any) => p.status === "complete").length}/{originSelectedAddrs.length} complete
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>

              {(originBatchTracing || Object.keys(originBatchProgress).length > 0) && Object.keys(originBatchProgress).length > 0 && (() => {
                const entries = Object.entries(originBatchProgress);
                const completed = entries.filter(([, p]: [string, any]) => p.status === "complete").length;
                const errors = entries.filter(([, p]: [string, any]) => p.status === "error").length;
                const running = entries.filter(([, p]: [string, any]) => p.status === "running").length;
                const totalSources = entries.reduce((s, [, p]: [string, any]) => s + (p.totalSourcesAnalyzed || 0), 0);
                const totalSites = entries.reduce((s, [, p]: [string, any]) => s + (p.totalWebsitesFound || 0), 0);
                const totalHighRisk = entries.reduce((s, [, p]: [string, any]) => s + (p.riskSummary?.critical || 0) + (p.riskSummary?.high || 0), 0);
                const totalTxs = entries.reduce((s, [, p]: [string, any]) => s + (p.incomingTransactions?.length || 0), 0);

                let filtered = entries.filter(([, p]: [string, any]) => batchFilterStatus === "all" || p.status === batchFilterStatus);
                if (batchSortBy === "progress") filtered.sort(([, a], [, b]) => (b.progress || 0) - (a.progress || 0));
                else if (batchSortBy === "sources") filtered.sort(([, a], [, b]) => (b.totalSourcesAnalyzed || 0) - (a.totalSourcesAnalyzed || 0));
                else if (batchSortBy === "risk") filtered.sort(([, a], [, b]) => ((b.riskSummary?.critical || 0) + (b.riskSummary?.high || 0)) - ((a.riskSummary?.critical || 0) + (a.riskSummary?.high || 0)));
                else if (batchSortBy === "status") filtered.sort(([, a], [, b]) => { const order: Record<string, number> = { error: 0, running: 1, complete: 2 }; return (order[a.status] ?? 3) - (order[b.status] ?? 3); });

                return (
                  <div className="bg-[#161b22] rounded-xl border border-amber-900/20 p-4 mb-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs text-amber-400 font-bold">{originBatchTracing ? "BATCH TRACE IN PROGRESS" : "BATCH TRACE COMPLETE"}</span>
                      <div className="flex items-center gap-3 text-[10px]">
                        <span className="text-green-400">{completed} done</span>
                        <span className="text-amber-400">{running} running</span>
                        {errors > 0 && <span className="text-red-400">{errors} errors</span>}
                      </div>
                    </div>

                    <div className="w-full bg-gray-800 rounded-full h-2 mb-3">
                      <div className="bg-gradient-to-r from-amber-500 to-green-500 h-2 rounded-full transition-all" style={{ width: `${entries.length > 0 ? Math.round(((completed + errors) / entries.length) * 100) : 0}%` }} />
                    </div>

                    <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-3">
                      {[
                        { label: "Wallets", value: entries.length, color: "amber" },
                        { label: "Sources", value: totalSources, color: "cyan" },
                        { label: "Websites", value: totalSites, color: "green" },
                        { label: "Incoming TXs", value: totalTxs, color: "blue" },
                        { label: "High Risk", value: totalHighRisk, color: "red" },
                        { label: "Completion", value: `${entries.length > 0 ? Math.round(((completed + errors) / entries.length) * 100) : 0}%`, color: "emerald" },
                      ].map((s, i) => (
                        <div key={i} className="bg-[#0d1117] rounded-lg p-2 text-center">
                          <div className={`text-sm font-bold text-${s.color}-400`}>{typeof s.value === "number" ? s.value.toLocaleString() : s.value}</div>
                          <div className="text-[9px] text-gray-600">{s.label}</div>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-[10px] text-gray-600">Filter:</span>
                      {(["all", "running", "complete", "error"] as const).map(s => (
                        <button key={s} onClick={() => setBatchFilterStatus(s)} className={`px-2 py-0.5 rounded text-[10px] font-bold border ${batchFilterStatus === s ? "bg-amber-900/40 text-amber-400 border-amber-700" : "bg-[#0d1117] text-gray-500 border-gray-800 hover:border-gray-600"}`} data-testid={`button-batch-filter-${s}`}>
                          {s === "all" ? `All (${entries.length})` : s === "running" ? `Running (${running})` : s === "complete" ? `Done (${completed})` : `Errors (${errors})`}
                        </button>
                      ))}
                      <span className="text-[10px] text-gray-600 ml-2">Sort:</span>
                      {(["default", "progress", "sources", "risk", "status"] as const).map(s => (
                        <button key={s} onClick={() => setBatchSortBy(s)} className={`px-2 py-0.5 rounded text-[10px] font-bold border ${batchSortBy === s ? "bg-cyan-900/40 text-cyan-400 border-cyan-700" : "bg-[#0d1117] text-gray-500 border-gray-800 hover:border-gray-600"}`} data-testid={`button-batch-sort-${s}`}>
                          {s === "default" ? "Default" : s === "progress" ? "Progress" : s === "sources" ? "Sources" : s === "risk" ? "Risk" : "Status"}
                        </button>
                      ))}
                    </div>

                    <div className="space-y-1 max-h-[280px] overflow-y-auto border border-gray-800/30 rounded-lg p-2 bg-[#0d1117]">
                      {filtered.map(([addr, prog]: [string, any]) => {
                        const w = (wallets || []).find((w: any) => w.address === addr);
                        const highRisk = (prog.riskSummary?.critical || 0) + (prog.riskSummary?.high || 0);
                        return (
                          <button key={addr} onClick={() => { if (prog.status === "complete") { setOriginTraceData({ address: addr, ...prog }); } }} className={`w-full text-left flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-800/40 transition-colors ${prog.status === "complete" ? "cursor-pointer" : "cursor-default"}`} data-testid={`batch-item-${addr.slice(0, 8)}`}>
                            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${prog.status === "complete" ? "bg-green-400" : prog.status === "error" ? "bg-red-400" : "bg-amber-400 animate-pulse"}`} />
                            <span className="text-xs text-gray-400 font-mono w-[100px] flex-shrink-0">{addr.slice(0, 10)}...{addr.slice(-4)}</span>
                            <span className="text-[10px] text-gray-600 truncate max-w-[100px] flex-shrink-0">{w?.label || w?.role || ""}</span>
                            <div className="flex items-center gap-2 ml-auto flex-shrink-0 text-[10px]">
                              {prog.status === "complete" ? (
                                <>
                                  <span className="text-cyan-400">{prog.totalSourcesAnalyzed || 0} src</span>
                                  <span className="text-green-400">{prog.totalWebsitesFound || 0} sites</span>
                                  <span className="text-amber-400">{prog.incomingTransactions?.length || 0} tx</span>
                                  {highRisk > 0 && <span className="text-red-400 font-bold">{highRisk} risk</span>}
                                  <span className="text-green-500">✓</span>
                                </>
                              ) : prog.status === "error" ? (
                                <span className="text-red-400">✗ Error</span>
                              ) : (
                                <>
                                  <span className="text-amber-400">{prog.progress || 0}%</span>
                                  <span className="text-gray-600">{prog.totalSourcesAnalyzed || 0} src</span>
                                </>
                              )}
                            </div>
                          </button>
                        );
                      })}
                      {filtered.length === 0 && <div className="text-center text-gray-600 text-xs py-4">No wallets match this filter</div>}
                    </div>
                  </div>
                );
              })()}

              {originBatchResults.length > 1 && !originBatchTracing && (
                <div className="bg-[#161b22] rounded-xl border border-amber-900/30 p-4 mb-4">
                  <h3 className="text-sm font-bold text-amber-400 mb-3">Batch Trace Results ({originBatchResults.length} wallets)</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                    <div className="bg-[#0d1117] rounded-lg p-3 text-center">
                      <div className="text-xl font-bold text-amber-400">{originBatchResults.reduce((s, r) => s + (r.incomingTransactions?.length || 0), 0)}</div>
                      <div className="text-[10px] text-gray-500">Total Incoming TXs</div>
                    </div>
                    <div className="bg-[#0d1117] rounded-lg p-3 text-center">
                      <div className="text-xl font-bold text-cyan-400">{originBatchResults.reduce((s, r) => s + (r.totalSourcesAnalyzed || 0), 0)}</div>
                      <div className="text-[10px] text-gray-500">Total Sources Profiled</div>
                    </div>
                    <div className="bg-[#0d1117] rounded-lg p-3 text-center">
                      <div className="text-xl font-bold text-green-400">{originBatchResults.reduce((s, r) => s + (r.totalWebsitesFound || 0), 0)}</div>
                      <div className="text-[10px] text-gray-500">Websites Found</div>
                    </div>
                    <div className="bg-[#0d1117] rounded-lg p-3 text-center">
                      <div className="text-xl font-bold text-red-400">{originBatchResults.reduce((s, r) => s + (r.riskSummary?.critical || 0) + (r.riskSummary?.high || 0), 0)}</div>
                      <div className="text-[10px] text-gray-500">High-Risk Sources</div>
                    </div>
                  </div>
                  <div className="space-y-2 max-h-72 overflow-y-auto">
                    {originBatchResults.map((result, i) => {
                      const w = (wallets || []).find((w: any) => w.address === result.address);
                      const isAttacker = ((w?.role || "") as string).toLowerCase().includes("poi") || ((w?.role || "") as string).toLowerCase().includes("attacker");
                      return (
                        <button key={i} onClick={() => setOriginTraceData(result)} className={`w-full text-left bg-[#0d1117] rounded-lg border p-3 hover:bg-gray-800/50 transition-colors ${originTraceData?.address === result.address ? "border-amber-600" : "border-gray-800/30"}`} data-testid={`button-origin-batch-result-${i}`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className={`text-xs font-medium ${isAttacker ? "text-red-400" : "text-gray-300"}`}>{w?.label || w?.role || "Unknown"}</span>
                              {isAttacker && <span className="text-[9px] px-1 py-0.5 bg-red-900/40 text-red-400 rounded">POI</span>}
                              <span className="text-[10px] font-mono text-gray-500">{result.address?.slice(0, 12)}...</span>
                            </div>
                            <div className="flex items-center gap-3 text-[10px]">
                              <span className="text-amber-400">{result.incomingTransactions?.length || 0} TXs</span>
                              <span className="text-cyan-400">{result.totalSourcesAnalyzed || 0} sources</span>
                              <span className="text-green-400">{result.totalWebsitesFound || 0} sites</span>
                              {((result.riskSummary?.critical || 0) + (result.riskSummary?.high || 0)) > 0 && (
                                <span className="text-red-400 font-bold">{(result.riskSummary?.critical || 0) + (result.riskSummary?.high || 0)} high-risk</span>
                              )}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  {originTraceData && <div className="text-[10px] text-gray-600 mt-2">Click a wallet above to view its detailed results below</div>}
                </div>
              )}

              {originTracing && originTraceData && (
                <div className="bg-[#161b22] rounded-xl border border-amber-900/20 p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-amber-400 font-bold">TRACING IN PROGRESS...</span>
                    <span className="text-xs text-gray-500">{originTraceData.totalSourcesAnalyzed || 0} sources profiled</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2 mb-2">
                    <div className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full transition-all" style={{ width: `${originTraceData.progress || 0}%` }} />
                  </div>
                  <div className="text-[10px] text-gray-600">{originTraceData.progress || 0}% — {originTraceData.totalWebsitesFound || 0} website connections found</div>
                </div>
              )}

              {originTraceData && originTraceData.status === "complete" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-3 text-center">
                      <div className="text-2xl font-bold text-amber-400">{originTraceData.incomingTransactions?.length || 0}</div>
                      <div className="text-[10px] text-gray-500">Incoming TXs</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-3 text-center">
                      <div className="text-2xl font-bold text-cyan-400">{originTraceData.totalSourcesAnalyzed || 0}</div>
                      <div className="text-[10px] text-gray-500">Sources Profiled</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-3 text-center">
                      <div className="text-2xl font-bold text-green-400">{originTraceData.totalWebsitesFound || 0}</div>
                      <div className="text-[10px] text-gray-500">Websites Found</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-red-400">{(originTraceData.riskSummary?.critical || 0) + (originTraceData.riskSummary?.high || 0)}</div>
                      <div className="text-[10px] text-gray-500">High-Risk Sources</div>
                    </div>
                    <div className="bg-[#161b22] rounded-xl border border-violet-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-violet-400">{originTraceData.sourceProfiles?.filter((p: any) => p.ensName)?.length || 0}</div>
                      <div className="text-[10px] text-gray-500">ENS Identities</div>
                    </div>
                  </div>

                  {originTraceData.websiteConnections?.length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-green-900/30 p-4">
                      <h3 className="text-sm font-bold text-green-400 mb-3">Website/Service Connections ({originTraceData.websiteConnections.length})</h3>
                      <div className="space-y-2 max-h-[400px] overflow-y-auto">
                        {originTraceData.websiteConnections.map((w: any, i: number) => {
                          const typeColors: Record<string, string> = {
                            ens_domain: "bg-purple-900/30 text-purple-400 border-purple-800/30",
                            whois_match: "bg-blue-900/30 text-blue-400 border-blue-800/30",
                            contract_website: "bg-cyan-900/30 text-cyan-400 border-cyan-800/30",
                            nft_marketplace: "bg-pink-900/30 text-pink-400 border-pink-800/30",
                            defi_protocol: "bg-emerald-900/30 text-emerald-400 border-emerald-800/30",
                            payment_processor: "bg-yellow-900/30 text-yellow-400 border-yellow-800/30",
                          };
                          return (
                            <div key={i} className="bg-[#0d1117] rounded-lg border border-gray-800/30 p-3" data-testid={`origin-website-${i}`}>
                              <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center gap-2">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${typeColors[w.type] || "bg-gray-800 text-gray-400 border-gray-700"}`}>{w.type?.replace(/_/g, " ").toUpperCase()}</span>
                                  <span className="text-sm font-bold text-amber-300">{w.domain}</span>
                                </div>
                                <a href={w.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-cyan-500 hover:text-cyan-400 underline">Open &rarr;</a>
                              </div>
                              <div className="text-xs text-gray-400 mb-1">{w.details}</div>
                              {w.registrant && <div className="text-[10px] text-green-400">Registrant: {w.registrant}</div>}
                              {w.registrantEmail && <div className="text-[10px] text-green-300">Email: {w.registrantEmail}</div>}
                              {w.registrantOrg && <div className="text-[10px] text-green-300">Org: {w.registrantOrg}</div>}
                              {w.nameServers?.length > 0 && <div className="text-[10px] text-gray-600">NS: {w.nameServers.join(", ")}</div>}
                              {w.createdDate && <div className="text-[10px] text-gray-600">Created: {w.createdDate.slice(0, 10)}</div>}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="bg-[#161b22] rounded-xl border border-amber-900/30 p-4">
                    <h3 className="text-sm font-bold text-amber-400 mb-3">Source Wallet Profiles ({originTraceData.sourceProfiles?.length || 0})</h3>
                    <div className="space-y-2 max-h-[600px] overflow-y-auto">
                      {(originTraceData.sourceProfiles || []).map((p: any, i: number) => {
                        const riskColors: Record<string, string> = {
                          critical: "bg-red-900/40 text-red-400 border-red-800",
                          high: "bg-orange-900/40 text-orange-400 border-orange-800",
                          medium: "bg-yellow-900/40 text-yellow-400 border-yellow-800",
                          low: "bg-green-900/40 text-green-400 border-green-800",
                          unknown: "bg-gray-800 text-gray-400 border-gray-700",
                        };
                        return (
                          <div key={i} className={`rounded-xl border p-3 ${p.riskLevel === "critical" ? "border-red-900/40 bg-red-950/10" : p.riskLevel === "high" ? "border-orange-900/30 bg-orange-950/10" : "border-gray-800/30 bg-[#0d1117]"}`} data-testid={`origin-source-${i}`}>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${riskColors[p.riskLevel] || riskColors.unknown}`}>{p.riskLevel?.toUpperCase()} RISK</span>
                                <span className="font-mono text-xs text-gray-300">{p.address?.slice(0, 12)}...{p.address?.slice(-6)}</span>
                                {p.ensName && <span className="px-2 py-0.5 rounded-full bg-purple-900/30 text-purple-400 text-[10px] font-bold">{p.ensName}</span>}
                                {p.etherscanLabel && <span className="px-2 py-0.5 rounded-full bg-blue-900/30 text-blue-400 text-[10px] font-bold">{p.etherscanLabel}</span>}
                              </div>
                              <a href={`https://etherscan.io/address/${p.address}`} target="_blank" rel="noopener noreferrer" className="text-[10px] text-cyan-500 hover:text-cyan-400 underline">Etherscan &rarr;</a>
                            </div>
                            <div className="grid grid-cols-4 gap-2 mb-2 text-[10px]">
                              <div><span className="text-gray-600">Balance:</span> <span className="text-gray-300">{p.balance?.toFixed(4)} ETH</span></div>
                              <div><span className="text-gray-600">USD:</span> <span className="text-gray-300">${p.balanceUsd?.toLocaleString()}</span></div>
                              <div><span className="text-gray-600">Tokens:</span> <span className="text-gray-300">{p.tokenCount}</span></div>
                              <div><span className="text-gray-600">Contract:</span> <span className="text-gray-300">{p.isContract ? "Yes" : "No"}</span></div>
                            </div>
                            {p.riskFactors?.length > 0 && (
                              <div className="flex flex-wrap gap-1 mb-2">
                                {p.riskFactors.map((f: string, fi: number) => (
                                  <span key={fi} className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${f.includes("MIXER") || f.includes("PRIVACY") ? "bg-red-900/40 text-red-400" : f.includes("bridge") ? "bg-orange-900/30 text-orange-400" : "bg-gray-800 text-gray-400"}`}>{f}</span>
                                ))}
                              </div>
                            )}
                            {p.connectedProtocols?.length > 0 && (
                              <div className="flex flex-wrap gap-1 mb-1">
                                {p.connectedProtocols.map((proto: any, pi: number) => (
                                  <span key={pi} className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${proto.type === "mixer" ? "bg-red-900/30 text-red-400" : proto.type === "bridge" ? "bg-orange-900/20 text-orange-300" : proto.type === "dex" ? "bg-cyan-900/20 text-cyan-300" : "bg-gray-800 text-gray-400"}`}>{proto.name} ({proto.interactionCount}x)</span>
                                ))}
                              </div>
                            )}
                            {p.topTokens?.length > 0 && (
                              <div className="text-[9px] text-gray-600 mt-1">Tokens: {p.topTokens.slice(0, 5).map((t: any) => `${t.symbol}:${t.balance > 1000000 ? (t.balance/1e6).toFixed(1)+"M" : t.balance > 1000 ? (t.balance/1e3).toFixed(1)+"K" : t.balance.toFixed(2)}`).join(", ")}</div>
                            )}
                            {p.connectedWebsites?.length > 0 && (
                              <div className="mt-1 text-[10px] text-green-400 font-bold">Connected Sites: {p.connectedWebsites.map((w: any) => w.domain).join(", ")}</div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {originTraceData.incomingTransactions?.length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-4">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">Incoming Transactions ({originTraceData.incomingTransactions.length})</h3>
                      <div className="space-y-1 max-h-[300px] overflow-y-auto">
                        {originTraceData.incomingTransactions.map((tx: any, i: number) => (
                          <div key={i} className="bg-[#0d1117] rounded-lg px-3 py-2 flex items-center justify-between text-xs" data-testid={`origin-tx-${i}`}>
                            <div className="flex items-center gap-2">
                              <span className="text-green-400 font-bold">+{tx.value?.toFixed(4)} ETH</span>
                              <span className="text-gray-600">${tx.valueUsd?.toLocaleString()}</span>
                              <span className="text-gray-500">from</span>
                              <span className="font-mono text-gray-300">{tx.from?.slice(0, 10)}...{tx.from?.slice(-6)}</span>
                              {tx.sourceProfile?.ensName && <span className="text-purple-400 text-[10px]">{tx.sourceProfile.ensName}</span>}
                              {tx.sourceProfile?.riskLevel && (
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${tx.sourceProfile.riskLevel === "critical" ? "bg-red-900/30 text-red-400" : tx.sourceProfile.riskLevel === "high" ? "bg-orange-900/30 text-orange-400" : "bg-gray-800 text-gray-400"}`}>{tx.sourceProfile.riskLevel.toUpperCase()}</span>
                              )}
                            </div>
                            <span className="text-[10px] text-gray-600">{tx.timestamp ? new Date(tx.timestamp).toLocaleString() : ""}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {!originTraceData && !originTracing && (
                <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center">
                  <div className="text-4xl mb-3">🔍</div>
                  <div className="text-gray-400 text-lg font-bold mb-2">Alpha Transaction Origin Intelligence&trade;</div>
                  <div className="text-gray-500 text-sm mb-4 max-w-xl mx-auto">
                    When attackers receive incoming funds, this engine traces the source — profiling each sender wallet, discovering connected websites and services (ENS domains, WHOIS lookups, DeFi protocols, mixers, bridges), and identifying any digital footprint that could unmask the attacker's identity.
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-w-2xl mx-auto">
                    {["ENS Identity", "WHOIS Lookup", "Protocol Detection", "Mixer Flagging", "Bridge Tracking", "Website Discovery", "Token Analysis", "Risk Assessment", "Contract Detection", "Exchange Labels", "NFT Marketplace", "Wallet Profiling"].map(p => (
                      <div key={p} className={`bg-[#0d1117] rounded-lg px-3 py-2 text-xs border border-gray-800/30 ${p.includes("Mixer") || p.includes("Bridge") ? "text-red-400 border-red-900/30" : "text-gray-400"}`}>{p}</div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "networkintel" && (
            <motion.div key="networkintel" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {netScanData && <NetworkIntelCharts scanData={netScanData} />}
              <div className="mb-6">
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400 mb-1" data-testid="text-networkintel-title">Alpha Network Intelligence Tracer&trade;</h2>
                <p className="text-gray-400 text-sm">Deep network reconnaissance — Transaction timing analysis, node propagation tracking, VPN/proxy unmasking, behavioral profiling, and attacker identification</p>
              </div>

              <div className="bg-[#0d1117] border border-red-900/30 rounded-xl p-4 mb-6">
                <h3 className="text-red-400 font-bold text-sm mb-3">Launch Network Intelligence Scan</h3>
                {!selectedCase && <p className="text-yellow-400/70 text-xs mb-3">Select a case from the Cases tab first</p>}
                {selectedCase && wallets && wallets.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <select
                        data-testid="select-netscan-wallet"
                        value={netSelectedWallet}
                        onChange={e => {
                          setNetSelectedWallet(e.target.value);
                          setNetScanAddr(e.target.value);
                        }}
                        className="flex-1 bg-[#161b22] border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-200"
                      >
                        <option value="">Select a wallet to scan...</option>
                        {wallets.map(w => (
                          <option key={w.id} value={w.address}>
                            {w.label || w.role || w.address.slice(0, 10)} — {w.address.slice(0, 8)}...{w.address.slice(-6)} ({w.chain}){w.lastKnownBalanceUsd ? ` — $${w.lastKnownBalanceUsd.toLocaleString()}` : ""}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={async () => {
                          const addr = netScanAddr || netSelectedWallet;
                          if (!addr || !selectedCase) return;
                          setNetScanning(true);
                          try {
                            const resp = await fetch("/api/forensic/command-center/network-scan", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ targetAddress: addr, caseId: selectedCase }),
                            });
                            if (resp.status === 403 || resp.status === 400) {
                              setNetScanning(false);
                              return;
                            }
                            const data = await resp.json();
                            if (data.scanId) {
                              setNetScanId(data.scanId);
                              const poll = setInterval(async () => {
                                const r = await fetch(`/api/forensic/command-center/network-scan/${data.scanId}`);
                                const scanResult = await r.json();
                                setNetScanData(scanResult);
                                if (scanResult.status !== "running") {
                                  clearInterval(poll);
                                  setNetScanning(false);
                                }
                              }, 3000);
                            }
                          } catch { setNetScanning(false); }
                        }}
                        disabled={netScanning || (!netScanAddr && !netSelectedWallet) || !selectedCase}
                        className="bg-gradient-to-r from-red-600 to-orange-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:opacity-90 disabled:opacity-40"
                        data-testid="button-launch-netscan"
                      >
                        {netScanning ? "Scanning..." : "Scan Selected"}
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={netScanAddr}
                        onChange={(e) => { setNetScanAddr(e.target.value); setNetSelectedWallet(""); }}
                        placeholder="Or enter any wallet address manually..."
                        className="flex-1 bg-[#161b22] border border-gray-700 rounded-lg px-3 py-2 text-xs text-gray-400 placeholder-gray-600 font-mono"
                        data-testid="input-netscan-address"
                      />
                      <button
                        data-testid="button-netscan-all"
                        disabled={netBatchScanning || !selectedCase || !wallets?.length}
                        onClick={async () => {
                          if (!selectedCase || !wallets?.length) return;
                          setNetBatchScanning(true);
                          setNetBatchResults([]);
                          setNetBatchProgress({});
                          for (let i = 0; i < wallets.length; i++) {
                            const w = wallets[i];
                            setNetBatchProgress(p => ({ ...p, [w.address]: "scanning" }));
                            try {
                              const resp = await fetch("/api/forensic/command-center/network-scan", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ targetAddress: w.address, caseId: selectedCase }),
                              });
                              if (resp.status === 403 || resp.status === 400) {
                                setNetBatchProgress(p => ({ ...p, [w.address]: "error" }));
                                await new Promise(r => setTimeout(r, 2000));
                                continue;
                              }
                              const data = await resp.json();
                              if (data.scanId) {
                                let done = false;
                                let polls = 0;
                                while (!done && polls < 20) {
                                  await new Promise(r => setTimeout(r, 3000));
                                  polls++;
                                  const r = await fetch(`/api/forensic/command-center/network-scan/${data.scanId}`);
                                  const scanResult = await r.json();
                                  if (scanResult.status !== "running") {
                                    setNetBatchResults(prev => [...prev, { address: w.address, label: w.label || w.role, ...scanResult }]);
                                    setNetBatchProgress(p => ({ ...p, [w.address]: "done" }));
                                    done = true;
                                  }
                                }
                                if (!done) {
                                  setNetBatchResults(prev => [...prev, { address: w.address, label: w.label || w.role, status: "timeout" }]);
                                  setNetBatchProgress(p => ({ ...p, [w.address]: "done" }));
                                }
                              } else {
                                setNetBatchProgress(p => ({ ...p, [w.address]: "error" }));
                              }
                            } catch {
                              setNetBatchProgress(p => ({ ...p, [w.address]: "error" }));
                            }
                            if (i < wallets.length - 1) await new Promise(r => setTimeout(r, 500));
                          }
                          setNetBatchScanning(false);
                        }}
                        className="bg-gradient-to-r from-red-700 to-orange-700 text-white px-4 py-2 rounded-lg text-xs font-bold hover:opacity-90 disabled:opacity-40 whitespace-nowrap"
                      >
                        {netBatchScanning ? `Scanning ${Object.values(netBatchProgress).filter(v => v === "done").length}/${wallets.length}...` : `Scan All ${wallets.length} Wallets`}
                      </button>
                      <button
                        onClick={async () => {
                          if (!selectedCase) return;
                          try {
                            const resp = await fetch(`/api/forensic/command-center/network-scans/${selectedCase}`);
                            const scans = await resp.json();
                            if (Array.isArray(scans) && scans.length > 0) {
                              setNetScanData(scans[scans.length - 1]);
                            }
                          } catch {}
                        }}
                        className="bg-[#161b22] border border-gray-700 text-gray-300 px-3 py-2 rounded-lg text-xs hover:border-red-500/50 whitespace-nowrap"
                        data-testid="button-load-netscan"
                      >
                        Load Latest
                      </button>
                    </div>
                    {netBatchScanning && (
                      <div className="mt-2 space-y-1">
                        {wallets.map(w => (
                          <div key={w.id} className="flex items-center gap-2 text-xs">
                            <span className={`w-2 h-2 rounded-full ${netBatchProgress[w.address] === "done" ? "bg-green-500" : netBatchProgress[w.address] === "scanning" ? "bg-orange-500 animate-pulse" : netBatchProgress[w.address] === "error" ? "bg-red-500" : "bg-gray-700"}`} />
                            <span className="font-mono text-gray-500">{w.address.slice(0, 10)}...{w.address.slice(-6)}</span>
                            <span className="text-gray-600">{w.label || w.role || ""}</span>
                            <span className={`ml-auto ${netBatchProgress[w.address] === "done" ? "text-green-400" : netBatchProgress[w.address] === "scanning" ? "text-orange-400" : "text-gray-600"}`}>
                              {netBatchProgress[w.address] === "done" ? "Complete" : netBatchProgress[w.address] === "scanning" ? "Scanning..." : netBatchProgress[w.address] === "error" ? "Failed" : "Queued"}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
                {netScanning && netScanData && (
                  <div className="mt-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="text-xs text-gray-400">Progress: {netScanData.progress || 0}%</div>
                      <div className="text-xs text-red-400 animate-pulse">Scanning network topology...</div>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all" style={{ width: `${netScanData.progress || 0}%` }} />
                    </div>
                  </div>
                )}
              </div>

              {netBatchResults.length > 0 && !netBatchScanning && (
                <div className="bg-[#0d1117] border border-red-900/30 rounded-xl p-4 mb-6">
                  <h3 className="text-red-400 font-bold text-sm mb-3">Batch Scan Results ({netBatchResults.length} wallets)</h3>
                  <div className="space-y-2">
                    {netBatchResults.map((r, i) => (
                      <div key={i} className="bg-[#161b22] rounded-lg p-3 border border-gray-800/30 cursor-pointer hover:border-red-500/40 transition-colors"
                        onClick={() => setNetScanData(r)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-mono text-cyan-400 text-xs">{r.address?.slice(0, 10)}...{r.address?.slice(-6)}</span>
                            {r.label && <span className="ml-2 text-gray-500 text-xs">{r.label}</span>}
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            {r.attackerProfile?.identityClues?.length > 0 && (
                              <span className="text-amber-400">{r.attackerProfile.identityClues.length} clues</span>
                            )}
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${r.attackerProfile?.confidenceLevel === "high" ? "bg-green-900/40 text-green-400" : r.attackerProfile?.confidenceLevel === "medium" ? "bg-yellow-900/40 text-yellow-400" : "bg-gray-800 text-gray-500"}`}>
                              {(r.attackerProfile?.confidenceLevel || "low").toUpperCase()}
                            </span>
                            <span className="text-gray-500">Click to view &rarr;</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {netScanData && netScanData.status !== "running" && (
                <div className="space-y-4">
                  {netScanData.attackerProfile && (
                    <div className="bg-[#0d1117] border border-red-900/40 rounded-xl p-4">
                      <h3 className="text-red-400 font-bold text-sm mb-3 flex items-center gap-2">
                        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                        ATTACKER PROFILE
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Estimated Location</div>
                          <div className="text-sm font-bold text-red-300" data-testid="text-netscan-location">{netScanData.attackerProfile.estimatedLocation || "Unknown"}</div>
                        </div>
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Estimated Timezone</div>
                          <div className="text-sm font-bold text-orange-300" data-testid="text-netscan-timezone">{netScanData.attackerProfile.estimatedTimezone || "Unknown"}</div>
                        </div>
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Confidence</div>
                          <div className={`text-sm font-bold ${netScanData.attackerProfile.confidenceLevel === "high" ? "text-green-400" : netScanData.attackerProfile.confidenceLevel === "medium" ? "text-yellow-400" : "text-gray-400"}`} data-testid="text-netscan-confidence">
                            {(netScanData.attackerProfile.confidenceLevel || "low").toUpperCase()}
                          </div>
                        </div>
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Operating Pattern</div>
                          <div className="text-sm font-bold text-cyan-300">{netScanData.attackerProfile.operatingPattern || "Unknown"}</div>
                        </div>
                      </div>

                      {netScanData.attackerProfile.identityClues?.length > 0 && (
                        <div className="mb-4">
                          <h4 className="text-xs font-bold text-amber-400 mb-2 uppercase tracking-wider">Identity Clues ({netScanData.attackerProfile.identityClues.length})</h4>
                          <div className="space-y-1">
                            {netScanData.attackerProfile.identityClues.map((clue: string, i: number) => (
                              <div key={i} className="flex items-start gap-2 bg-[#161b22] rounded px-3 py-2">
                                <span className="text-amber-500 text-xs mt-0.5">&#9733;</span>
                                <span className="text-xs text-gray-300" data-testid={`text-netscan-clue-${i}`}>{clue}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {netScanData.attackerProfile.riskFactors?.length > 0 && (
                        <div className="mb-4">
                          <h4 className="text-xs font-bold text-red-400 mb-2 uppercase tracking-wider">Risk Factors</h4>
                          <div className="flex flex-wrap gap-2">
                            {netScanData.attackerProfile.riskFactors.map((rf: string, i: number) => (
                              <span key={i} className="bg-red-900/30 text-red-300 text-xs px-2 py-1 rounded border border-red-800/40" data-testid={`text-netscan-risk-${i}`}>{rf}</span>
                            ))}
                          </div>
                        </div>
                      )}

                      {netScanData.attackerProfile.recommendations?.length > 0 && (
                        <div>
                          <h4 className="text-xs font-bold text-green-400 mb-2 uppercase tracking-wider">Law Enforcement Recommendations</h4>
                          <div className="space-y-1">
                            {netScanData.attackerProfile.recommendations.map((rec: string, i: number) => (
                              <div key={i} className="flex items-start gap-2">
                                <span className="text-green-500 text-xs mt-0.5">&#10003;</span>
                                <span className="text-xs text-gray-300">{rec}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-red-400" data-testid="text-netscan-ips">{netScanData.ipSummary?.totalIpsDiscovered || 0}</div>
                      <div className="text-xs text-gray-500">IPs Discovered</div>
                    </div>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-orange-400">{netScanData.ipSummary?.vpnIps || 0}</div>
                      <div className="text-xs text-gray-500">VPN IPs</div>
                    </div>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-purple-400">{netScanData.ipSummary?.torExitNodes || 0}</div>
                      <div className="text-xs text-gray-500">Tor Nodes</div>
                    </div>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-cyan-400">{netScanData.transactionTimings?.length || 0}</div>
                      <div className="text-xs text-gray-500">Txs Analyzed</div>
                    </div>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-amber-400">{netScanData.networkTopology?.portScanResults?.length || 0}</div>
                      <div className="text-xs text-gray-500">Open Ports</div>
                    </div>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-green-400">{netScanData.networkTopology?.relatedIps?.length || 0}</div>
                      <div className="text-xs text-gray-500">Linked IPs</div>
                    </div>
                  </div>

                  {netScanData.behaviorProfile && (
                    <div className="bg-[#0d1117] border border-cyan-900/30 rounded-xl p-4">
                      <h3 className="text-cyan-400 font-bold text-sm mb-3">Wallet Behavioral Profile</h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Total Transactions</div>
                          <div className="text-sm font-bold text-gray-200">{netScanData.behaviorProfile.totalTransactions}</div>
                        </div>
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Avg Gas Price</div>
                          <div className="text-sm font-bold text-gray-200">{netScanData.behaviorProfile.avgGasPrice?.toFixed(2)} Gwei</div>
                        </div>
                        <div className="bg-[#161b22] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Activity Timezone</div>
                          <div className="text-sm font-bold text-amber-300">{netScanData.behaviorProfile.transactionTimingPattern?.timezone_estimate || "Unknown"}</div>
                        </div>
                      </div>

                      {netScanData.behaviorProfile.transactionTimingPattern?.mostActiveHours?.length > 0 && (
                        <div className="mb-3">
                          <div className="text-xs text-gray-500 mb-1">Most Active Hours (UTC)</div>
                          <div className="flex gap-1">
                            {Array.from({ length: 24 }, (_, h) => {
                              const isActive = netScanData.behaviorProfile.transactionTimingPattern.mostActiveHours.includes(h);
                              return <div key={h} className={`w-4 h-6 rounded-sm flex items-end justify-center text-[8px] ${isActive ? "bg-red-500/80 text-white" : "bg-gray-800 text-gray-600"}`}>{h}</div>;
                            })}
                          </div>
                        </div>
                      )}

                      {netScanData.behaviorProfile.interactionPatterns && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
                          {netScanData.behaviorProfile.interactionPatterns.usedDexs?.length > 0 && (
                            <div><div className="text-xs text-gray-500 mb-1">DEXes Used</div>{netScanData.behaviorProfile.interactionPatterns.usedDexs.map((d: string, i: number) => <span key={i} className="inline-block bg-blue-900/30 text-blue-300 text-xs px-2 py-0.5 rounded mr-1 mb-1">{d}</span>)}</div>
                          )}
                          {netScanData.behaviorProfile.interactionPatterns.usedBridges?.length > 0 && (
                            <div><div className="text-xs text-gray-500 mb-1">Bridges Used</div>{netScanData.behaviorProfile.interactionPatterns.usedBridges.map((b: string, i: number) => <span key={i} className="inline-block bg-purple-900/30 text-purple-300 text-xs px-2 py-0.5 rounded mr-1 mb-1">{b}</span>)}</div>
                          )}
                          {netScanData.behaviorProfile.interactionPatterns.usedMixers?.length > 0 && (
                            <div><div className="text-xs text-gray-500 mb-1">Mixers Used</div>{netScanData.behaviorProfile.interactionPatterns.usedMixers.map((m: string, i: number) => <span key={i} className="inline-block bg-red-900/30 text-red-300 text-xs px-2 py-0.5 rounded mr-1 mb-1">{m}</span>)}</div>
                          )}
                          {netScanData.behaviorProfile.interactionPatterns.usedPrivacyProtocols?.length > 0 && (
                            <div><div className="text-xs text-gray-500 mb-1">Privacy Protocols</div>{netScanData.behaviorProfile.interactionPatterns.usedPrivacyProtocols.map((p: string, i: number) => <span key={i} className="inline-block bg-orange-900/30 text-orange-300 text-xs px-2 py-0.5 rounded mr-1 mb-1">{p}</span>)}</div>
                          )}
                        </div>
                      )}

                      {netScanData.behaviorProfile.interactionPatterns?.topRecipients?.length > 0 && (
                        <div className="mt-3">
                          <div className="text-xs text-gray-500 mb-1">Top Recipients (Fund Flow)</div>
                          {netScanData.behaviorProfile.interactionPatterns.topRecipients.slice(0, 5).map((r: any, i: number) => (
                            <div key={i} className="flex items-center justify-between bg-[#161b22] rounded px-3 py-1.5 mb-1 text-xs">
                              <span className="text-gray-300 font-mono">{r.address.slice(0, 10)}...{r.address.slice(-6)}</span>
                              <span className="text-gray-400">{r.count} txs</span>
                              <span className="text-cyan-400">{r.totalValue}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {netScanData.behaviorProfile.fundingChain?.originalSource && (
                        <div className="mt-3 bg-amber-900/20 border border-amber-800/30 rounded-lg p-3">
                          <div className="text-xs text-amber-400 font-bold mb-1">Original Funding Source</div>
                          <div className="text-sm text-gray-200 font-mono" data-testid="text-netscan-funding-source">{netScanData.behaviorProfile.fundingChain.originalSource}</div>
                          <div className="text-xs text-gray-500 mt-1">Depth: {netScanData.behaviorProfile.fundingChain.depth} hop(s)</div>
                        </div>
                      )}
                    </div>
                  )}

                  {netScanData.vpnIntelligence?.length > 0 && (
                    <div className="bg-[#0d1117] border border-orange-900/30 rounded-xl p-4">
                      <h3 className="text-orange-400 font-bold text-sm mb-3">IP Intelligence & VPN Detection ({netScanData.vpnIntelligence.length} IPs)</h3>
                      <div className="space-y-2 max-h-80 overflow-y-auto">
                        {netScanData.vpnIntelligence.map((ip: any, i: number) => (
                          <div key={i} className="bg-[#161b22] rounded-lg p-3 border border-gray-800">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-mono text-gray-200">{ip.detectedIp}</span>
                              <div className="flex gap-1">
                                {ip.isVpn && <span className="bg-orange-900/40 text-orange-300 text-xs px-2 py-0.5 rounded">VPN</span>}
                                {ip.isProxy && <span className="bg-yellow-900/40 text-yellow-300 text-xs px-2 py-0.5 rounded">PROXY</span>}
                                {ip.isTor && <span className="bg-purple-900/40 text-purple-300 text-xs px-2 py-0.5 rounded">TOR</span>}
                                {ip.isDatacenter && <span className="bg-blue-900/40 text-blue-300 text-xs px-2 py-0.5 rounded">DC</span>}
                                {!ip.isVpn && !ip.isProxy && !ip.isTor && !ip.isDatacenter && <span className="bg-green-900/40 text-green-300 text-xs px-2 py-0.5 rounded">Residential</span>}
                              </div>
                            </div>
                            <div className="grid grid-cols-3 gap-2 text-xs">
                              <div><span className="text-gray-500">Country:</span> <span className="text-gray-300">{ip.country}</span></div>
                              <div><span className="text-gray-500">City:</span> <span className="text-gray-300">{ip.city}</span></div>
                              <div><span className="text-gray-500">ISP:</span> <span className="text-gray-300">{ip.isp}</span></div>
                              <div><span className="text-gray-500">ASN:</span> <span className="text-gray-300">{ip.asn}</span></div>
                              <div><span className="text-gray-500">Ports:</span> <span className="text-gray-300">{ip.openPorts?.length || 0} open</span></div>
                              <div><span className="text-gray-500">Risk:</span> <span className={`font-bold ${ip.riskScore > 50 ? "text-red-400" : ip.riskScore > 20 ? "text-yellow-400" : "text-green-400"}`}>{ip.riskScore}/100</span></div>
                            </div>
                            {ip.reverseHosts?.length > 0 && (
                              <div className="mt-2 text-xs"><span className="text-gray-500">Hostnames:</span> <span className="text-cyan-300">{ip.reverseHosts.join(", ")}</span></div>
                            )}
                            {ip.openPorts?.length > 0 && (
                              <div className="mt-1 text-xs"><span className="text-gray-500">Open Ports:</span> <span className="text-gray-400">{ip.openPorts.join(", ")}</span></div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {netScanData.networkTopology?.portScanResults?.length > 0 && (
                    <div className="bg-[#0d1117] border border-purple-900/30 rounded-xl p-4">
                      <h3 className="text-purple-400 font-bold text-sm mb-3">Network Topology — Port Scan Results ({netScanData.networkTopology.portScanResults.length})</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                        {netScanData.networkTopology.portScanResults.map((p: any, i: number) => (
                          <div key={i} className="flex items-center justify-between bg-[#161b22] rounded px-3 py-2 text-xs">
                            <span className="font-mono text-gray-300">{p.ip}:{p.port}</span>
                            <span className={`px-2 py-0.5 rounded ${
                              p.service.includes("Ethereum") ? "bg-blue-900/40 text-blue-300" :
                              p.service.includes("VPN") || p.service.includes("WireGuard") ? "bg-orange-900/40 text-orange-300" :
                              p.service.includes("Tor") ? "bg-purple-900/40 text-purple-300" :
                              p.service.includes("SSH") ? "bg-yellow-900/40 text-yellow-300" :
                              "bg-gray-800 text-gray-400"
                            }`}>{p.service}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {netScanData.transactionTimings?.length > 0 && (
                    <div className="bg-[#0d1117] border border-gray-800 rounded-xl p-4">
                      <h3 className="text-gray-400 font-bold text-sm mb-3">Transaction Timing Analysis ({netScanData.transactionTimings.length} txs)</h3>
                      <div className="max-h-48 overflow-y-auto space-y-1">
                        {netScanData.transactionTimings.slice(0, 20).map((t: any, i: number) => (
                          <div key={i} className="flex items-center justify-between bg-[#161b22] rounded px-3 py-1.5 text-xs">
                            <span className="font-mono text-gray-400">{t.txHash?.slice(0, 14)}...</span>
                            <span className="text-gray-500">{new Date(t.broadcastTime).toLocaleString()}</span>
                            <span className="text-cyan-400">{t.gasPriceGwei?.toFixed(1)} Gwei</span>
                            <span className="text-amber-300">{t.timezone_estimate?.split(" ").pop()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {!netScanData && !netScanning && (
                <div className="bg-[#0d1117] border border-gray-800 rounded-xl p-8 text-center">
                  <div className="text-gray-400 text-lg font-bold mb-2">Alpha Network Intelligence Tracer&trade;</div>
                  <div className="text-gray-500 text-sm max-w-lg mx-auto">
                    Deep network reconnaissance technology for unmasking attackers. Analyzes transaction timing patterns, Ethereum node propagation data, VPN/proxy detection via IP intelligence and port scanning, behavioral profiling, and builds comprehensive attacker identification profiles for law enforcement.
                  </div>
                  <div className="mt-4 text-xs text-gray-600">Select a case and enter a wallet address above to begin scanning.</div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "bounty" && (
            <motion.div key="bounty" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {bountyAgreements && bountyAgreements.length > 0 && <BountyCharts agreements={bountyAgreements} />}
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-400" data-testid="text-bounty-title">Bounty Recovery Agreements</h2>
                <div className="flex gap-2">
                  <button data-testid="button-new-bounty-agreement" onClick={() => { setShowBountyForm(!showBountyForm); if (!showBountyForm && selectedCase) setBountyForm(f => ({ ...f, caseId: selectedCase })); }} className="px-3 py-1.5 bg-yellow-600/20 border border-yellow-600/40 hover:bg-yellow-600/30 rounded text-yellow-400 text-xs font-medium transition-colors">
                    {showBountyForm ? "Cancel" : "+ Generate Agreement"}
                  </button>
                  <button data-testid="button-new-recovery-event" onClick={() => { setShowRecoveryForm(!showRecoveryForm); if (!showRecoveryForm && selectedCase) setRecoveryForm(f => ({ ...f, caseId: selectedCase })); }} className="px-3 py-1.5 bg-green-600/20 border border-green-600/40 hover:bg-green-600/30 rounded text-green-400 text-xs font-medium transition-colors">
                    {showRecoveryForm ? "Cancel" : "+ Log Recovery"}
                  </button>
                </div>
              </div>

              {(() => {
                const totalRecovered = (recoveryEvents || []).reduce((s: number, e: any) => s + (e.amountRecoveredUsd || 0), 0);
                const totalBountyOwed = (recoveryEvents || []).reduce((s: number, e: any) => s + (e.bountyOwed || 0), 0);
                const totalBountyPaid = (recoveryEvents || []).filter((e: any) => e.bountyPaid).reduce((s: number, e: any) => s + (e.bountyOwed || 0), 0);
                const signedAgreements = (bountyAgreements || []).filter((a: any) => a.status === "signed").length;
                const pendingAgreements = (bountyAgreements || []).filter((a: any) => a.status === "pending").length;
                return (
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                    <div className="bg-[#161b22] rounded-lg border border-yellow-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-yellow-400" data-testid="text-bounty-total-agreements">{(bountyAgreements || []).length}</div>
                      <div className="text-[10px] text-gray-500 uppercase">Total Agreements</div>
                    </div>
                    <div className="bg-[#161b22] rounded-lg border border-green-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-green-400" data-testid="text-bounty-signed">{signedAgreements}</div>
                      <div className="text-[10px] text-gray-500 uppercase">Signed</div>
                    </div>
                    <div className="bg-[#161b22] rounded-lg border border-orange-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-orange-400" data-testid="text-bounty-pending">{pendingAgreements}</div>
                      <div className="text-[10px] text-gray-500 uppercase">Pending Signature</div>
                    </div>
                    <div className="bg-[#161b22] rounded-lg border border-cyan-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-cyan-400" data-testid="text-bounty-total-recovered">${totalRecovered.toLocaleString()}</div>
                      <div className="text-[10px] text-gray-500 uppercase">Total Recovered</div>
                    </div>
                    <div className="bg-[#161b22] rounded-lg border border-emerald-900/30 p-3 text-center">
                      <div className="text-2xl font-bold text-emerald-400" data-testid="text-bounty-owed">${totalBountyOwed.toLocaleString()}</div>
                      <div className="text-[10px] text-gray-500 uppercase">Bounty Owed ({totalBountyPaid > 0 ? `$${totalBountyPaid.toLocaleString()} paid` : "unpaid"})</div>
                    </div>
                  </div>
                );
              })()}

              {showBountyForm && (
                <div className="bg-[#161b22] rounded-lg border border-yellow-900/40 p-4 mb-4">
                  <h3 className="text-sm font-bold text-yellow-400 mb-3">Generate Bounty Recovery Agreement</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Case</label>
                      <select data-testid="select-bounty-case" value={bountyForm.caseId} onChange={e => setBountyForm(f => ({ ...f, caseId: e.target.value }))} className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200">
                        <option value="">Select a case...</option>
                        {(cases || []).map((c: any) => <option key={c.id} value={c.id}>{c.caseName}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Bounty Percentage (%)</label>
                      <input data-testid="input-bounty-percentage" type="number" min="1" max="50" step="0.5" value={bountyForm.bountyPercentage} onChange={e => setBountyForm(f => ({ ...f, bountyPercentage: e.target.value }))} placeholder="10" className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                      <div className="text-[9px] text-gray-600 mt-0.5">The percentage of recovered funds owed as bounty</div>
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Client / Victim Name</label>
                      <input data-testid="input-bounty-client-name" value={bountyForm.clientName} onChange={e => setBountyForm(f => ({ ...f, clientName: e.target.value }))} placeholder="e.g. @sillytuna" className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Client Email</label>
                      <input data-testid="input-bounty-client-email" type="email" value={bountyForm.clientEmail} onChange={e => setBountyForm(f => ({ ...f, clientEmail: e.target.value }))} placeholder="victim@example.com" className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Client Wallet Address (for agreement)</label>
                      <input data-testid="input-bounty-client-wallet" value={bountyForm.clientWalletAddress} onChange={e => setBountyForm(f => ({ ...f, clientWalletAddress: e.target.value }))} placeholder="0x..." className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm font-mono text-gray-200" />
                    </div>
                  </div>
                  <button data-testid="button-generate-agreement" disabled={!bountyForm.caseId || generatingAgreement} onClick={async () => {
                    setGeneratingAgreement(true);
                    try {
                      const res = await fetch("/api/forensic/command-center/bounty-agreement", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ ...bountyForm, bountyPercentage: parseFloat(bountyForm.bountyPercentage) || 10 }) });
                      const data = await res.json();
                      if (data.success) {
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/bounty-agreements"] });
                        setShowBountyForm(false);
                        setBountyForm({ caseId: "", clientName: "", clientEmail: "", clientWalletAddress: "", bountyPercentage: "10" });
                      } else { alert(data.message || "Failed to generate agreement"); }
                    } catch (e: any) { alert(e.message); }
                    setGeneratingAgreement(false);
                  }} className="mt-3 px-4 py-2 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-500 hover:to-amber-500 text-white rounded text-sm font-medium disabled:opacity-50">
                    {generatingAgreement ? "Generating..." : "Generate Agreement"}
                  </button>
                </div>
              )}

              {showRecoveryForm && (
                <div className="bg-[#161b22] rounded-lg border border-green-900/40 p-4 mb-4">
                  <h3 className="text-sm font-bold text-green-400 mb-3">Log Recovery Event</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Case</label>
                      <select data-testid="select-recovery-case" value={recoveryForm.caseId} onChange={e => setRecoveryForm(f => ({ ...f, caseId: e.target.value }))} className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200">
                        <option value="">Select a case...</option>
                        {(cases || []).map((c: any) => <option key={c.id} value={c.id}>{c.caseName}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Source</label>
                      <select data-testid="select-recovery-source" value={recoveryForm.source} onChange={e => setRecoveryForm(f => ({ ...f, source: e.target.value }))} className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200">
                        <option value="exchange_freeze">Exchange Freeze</option>
                        <option value="voluntary_return">Voluntary Return</option>
                        <option value="law_enforcement">Law Enforcement</option>
                        <option value="court_order">Court Order</option>
                        <option value="insurance">Insurance Payout</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Amount Recovered (USD)</label>
                      <input data-testid="input-recovery-usd" type="number" min="0" step="0.01" value={recoveryForm.amountRecoveredUsd} onChange={e => setRecoveryForm(f => ({ ...f, amountRecoveredUsd: e.target.value }))} placeholder="0.00" className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Amount Recovered (Native Token)</label>
                      <input data-testid="input-recovery-native" type="number" min="0" step="0.000001" value={recoveryForm.amountRecoveredNative} onChange={e => setRecoveryForm(f => ({ ...f, amountRecoveredNative: e.target.value }))} placeholder="e.g. 10.5 ETH" className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Wallet Address</label>
                      <input data-testid="input-recovery-wallet" value={recoveryForm.walletAddress} onChange={e => setRecoveryForm(f => ({ ...f, walletAddress: e.target.value }))} placeholder="0x..." className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm font-mono text-gray-200" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Chain</label>
                      <select data-testid="select-recovery-chain" value={recoveryForm.chain} onChange={e => setRecoveryForm(f => ({ ...f, chain: e.target.value }))} className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200">
                        <option value="ethereum">Ethereum</option>
                        <option value="bitcoin">Bitcoin</option>
                        <option value="bsc">BSC</option>
                        <option value="polygon">Polygon</option>
                        <option value="solana">Solana</option>
                        <option value="arbitrum">Arbitrum</option>
                        <option value="optimism">Optimism</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Notes</label>
                      <textarea data-testid="input-recovery-notes" value={recoveryForm.notes} onChange={e => setRecoveryForm(f => ({ ...f, notes: e.target.value }))} placeholder="Details about how the funds were recovered..." rows={2} className="w-full bg-[#0d1117] border border-gray-800 rounded px-3 py-2 text-sm text-gray-200" />
                    </div>
                  </div>
                  <button data-testid="button-log-recovery" disabled={!recoveryForm.caseId || !recoveryForm.amountRecoveredUsd || loggingRecovery} onClick={async () => {
                    setLoggingRecovery(true);
                    try {
                      const res = await fetch("/api/forensic/command-center/recovery-event", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ ...recoveryForm, amountRecoveredUsd: parseFloat(recoveryForm.amountRecoveredUsd) || 0, amountRecoveredNative: parseFloat(recoveryForm.amountRecoveredNative) || undefined }) });
                      const data = await res.json();
                      if (data.success) {
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/recovery-events"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/cases"] });
                        setShowRecoveryForm(false);
                        setRecoveryForm({ caseId: "", walletAddress: "", chain: "ethereum", amountRecoveredNative: "", amountRecoveredUsd: "", source: "exchange_freeze", notes: "" });
                      } else { alert(data.message || "Failed to log recovery"); }
                    } catch (e: any) { alert(e.message); }
                    setLoggingRecovery(false);
                  }} className="mt-3 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white rounded text-sm font-medium disabled:opacity-50">
                    {loggingRecovery ? "Logging..." : "Log Recovery Event"}
                  </button>
                </div>
              )}

              <div className="space-y-3 mb-6">
                <h3 className="text-sm font-bold text-yellow-400 flex items-center gap-2">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                  Agreements ({(bountyAgreements || []).length})
                </h3>
                {(bountyAgreements || []).length === 0 ? (
                  <div className="text-center text-gray-600 py-6 text-sm">No bounty agreements generated yet. Click "+ Generate Agreement" to create one.</div>
                ) : (
                  (bountyAgreements || []).map((a: any) => {
                    const signingLink = `${window.location.origin}/agreement/${a.id}`;
                    return (
                      <div key={a.id} className={`bg-[#161b22] rounded-lg border p-4 ${a.status === "signed" ? "border-green-900/40" : "border-yellow-900/40"}`} data-testid={`card-bounty-agreement-${a.id.slice(0, 8)}`}>
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className={`text-xs px-2 py-0.5 rounded font-bold ${a.status === "signed" ? "bg-green-900/40 text-green-400" : "bg-yellow-900/40 text-yellow-400"}`}>{a.status === "signed" ? "SIGNED" : "PENDING"}</span>
                              <span className="text-sm font-medium text-gray-200">{a.clientName || "Unknown Client"}</span>
                              <span className="text-xs text-amber-400 font-bold">{a.bountyPercentage}% bounty</span>
                            </div>
                            <div className="text-[10px] text-gray-500 mt-1">Case: {(cases || []).find((c: any) => c.id === a.caseId)?.caseName || a.caseId.slice(0, 8)} | Created: {new Date(a.createdAt).toLocaleDateString()}</div>
                            {a.clientEmail && <div className="text-[10px] text-gray-500">Email: {a.clientEmail}</div>}
                            {a.clientWalletAddress && <div className="text-[10px] font-mono text-gray-500">Wallet: {a.clientWalletAddress}</div>}
                          </div>
                          <div className="text-right">
                            {a.status === "signed" && (
                              <div>
                                <div className="text-[10px] text-green-400">Signed by: {a.signerName}</div>
                                <div className="text-[10px] text-gray-500">{a.signedAt ? new Date(a.signedAt).toLocaleString() : ""}</div>
                                <div className="text-[9px] font-mono text-gray-600">Sig: {a.signatureHash?.slice(0, 16)}...</div>
                              </div>
                            )}
                          </div>
                        </div>
                        {a.status === "pending" && (
                          <div className="mt-2 flex items-center gap-2">
                            <input readOnly value={signingLink} className="flex-1 bg-[#0d1117] border border-gray-800 rounded px-2 py-1 text-[10px] font-mono text-cyan-400" data-testid={`input-signing-link-${a.id.slice(0, 8)}`} />
                            <button data-testid={`button-copy-signing-link-${a.id.slice(0, 8)}`} onClick={() => { navigator.clipboard.writeText(signingLink); }} className="px-2 py-1 bg-cyan-600/20 border border-cyan-600/40 hover:bg-cyan-600/30 rounded text-cyan-400 text-[10px]">
                              Copy Link
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-green-400 flex items-center gap-2">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  Recovery Events ({(recoveryEvents || []).length})
                </h3>
                {(recoveryEvents || []).length === 0 ? (
                  <div className="text-center text-gray-600 py-6 text-sm">No recovery events logged yet. Click "+ Log Recovery" when funds are recovered.</div>
                ) : (
                  <div className="bg-[#161b22] rounded-lg border border-green-900/30 overflow-hidden">
                    <table className="w-full text-xs">
                      <thead><tr className="bg-[#0d1117] text-gray-500 text-[10px] uppercase"><th className="px-3 py-2 text-left">Date</th><th className="px-3 py-2 text-left">Source</th><th className="px-3 py-2 text-left">Wallet</th><th className="px-3 py-2 text-right">Recovered</th><th className="px-3 py-2 text-right">Bounty Owed</th><th className="px-3 py-2 text-center">Paid</th></tr></thead>
                      <tbody>
                        {(recoveryEvents || []).map((e: any) => (
                          <tr key={e.id} className="border-t border-gray-900/50 hover:bg-gray-800/30" data-testid={`row-recovery-${e.id.slice(0, 8)}`}>
                            <td className="px-3 py-2 text-gray-400">{new Date(e.recoveredAt || e.createdAt).toLocaleDateString()}</td>
                            <td className="px-3 py-2"><span className="px-1.5 py-0.5 bg-blue-900/30 text-blue-400 rounded text-[10px]">{(e.source || "unknown").replace(/_/g, " ")}</span></td>
                            <td className="px-3 py-2 font-mono text-gray-400">{e.walletAddress ? `${e.walletAddress.slice(0, 10)}...` : "—"}</td>
                            <td className="px-3 py-2 text-right text-green-400 font-medium">${(e.amountRecoveredUsd || 0).toLocaleString()}</td>
                            <td className="px-3 py-2 text-right text-yellow-400 font-medium">${(e.bountyOwed || 0).toLocaleString()}</td>
                            <td className="px-3 py-2 text-center">{e.bountyPaid ? <span className="text-green-400">Yes</span> : <span className="text-red-400">No</span>}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "laundering" && (
            <motion.div key="laundering" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {launderingRisk && <LaunderingRiskCharts riskData={launderingRisk} />}
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400" data-testid="text-laundering-title">
                  Laundering Risk Intelligence
                </h2>
                {launderingRisk?.overallRiskScore && (
                  <div className={`px-4 py-2 rounded-lg text-sm font-bold ${launderingRisk.overallRiskScore >= 80 ? "bg-red-600/20 text-red-400 border border-red-600/30" : launderingRisk.overallRiskScore >= 60 ? "bg-orange-600/20 text-orange-400 border border-orange-600/30" : "bg-yellow-600/20 text-yellow-400 border border-yellow-600/30"}`} data-testid="text-risk-score">
                    RISK SCORE: {launderingRisk.overallRiskScore}/100
                  </div>
                )}
              </div>

              {!selectedCase && (
                <div className="bg-[#161b22] border border-gray-700 rounded-lg p-6 text-center text-gray-500" data-testid="text-select-case-prompt">
                  Select a case from the dropdown above to view laundering risk intelligence.
                </div>
              )}

              {selectedCase && !launderingRisk && (
                <div className="bg-[#161b22] border border-gray-700 rounded-lg p-6 text-center text-gray-500">
                  Loading laundering risk analysis...
                </div>
              )}

              {selectedCase && launderingRisk && (
                <div className="space-y-6">
                  <div className="bg-[#161b22] border border-red-900/40 rounded-lg p-4" data-testid="section-tornado-cash">
                    <div className="flex items-center gap-2 mb-3">
                      <div className={`w-3 h-3 rounded-full ${launderingRisk.tornadoCashExposure?.detected ? "bg-red-500 animate-pulse" : "bg-gray-600"}`}></div>
                      <h3 className="text-base font-bold text-red-400">Tornado Cash DAI Mixing Risk</h3>
                      {launderingRisk.tornadoCashExposure?.detected && <span className="px-2 py-0.5 bg-red-600/20 text-red-400 text-xs rounded">ACTIVE RISK</span>}
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{launderingRisk.tornadoCashExposure?.summary}</p>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div className="bg-[#0d1117] rounded p-3">
                        <div className="text-xs text-gray-500">DAI at Risk</div>
                        <div className="text-lg font-bold text-red-400" data-testid="text-dai-at-risk">${(launderingRisk.tornadoCashExposure?.daiAtRisk || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-[#0d1117] rounded p-3">
                        <div className="text-xs text-gray-500">ETH at Risk</div>
                        <div className="text-lg font-bold text-orange-400" data-testid="text-eth-at-risk">{(launderingRisk.tornadoCashExposure?.ethAtRisk || 0).toFixed(4)} ETH</div>
                      </div>
                    </div>
                    {launderingRisk.tornadoCashExposure?.interactions?.length > 0 && (
                      <div className="mt-3">
                        <div className="text-xs text-gray-500 mb-2">Detected Tornado Cash Interactions ({launderingRisk.tornadoCashExposure.interactions.length})</div>
                        <div className="space-y-1 max-h-40 overflow-y-auto">
                          {launderingRisk.tornadoCashExposure.interactions.map((i: any, idx: number) => (
                            <div key={idx} className="bg-[#0d1117] rounded px-3 py-1.5 text-xs flex justify-between items-center">
                              <span className="text-gray-300">{i.label} &rarr; {i.tornadoLabel}</span>
                              <span className="text-red-400 font-mono">{i.amount?.toFixed(2)} {i.token}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="mt-3 bg-red-900/10 border border-red-900/20 rounded p-2 text-xs text-red-300">
                      DAI has no admin freeze function and no blacklist capability. Unlike USDC/USDT (which can be frozen by Circle/Tether), DAI is a decentralized stablecoin that cannot be stopped, frozen, or blacklisted by any authority. This makes it the preferred token for Tornado Cash mixing.
                    </div>
                  </div>

                  <div className="bg-[#161b22] border border-purple-900/40 rounded-lg p-4" data-testid="section-monero-risk">
                    <div className="flex items-center gap-2 mb-3">
                      <div className={`w-3 h-3 rounded-full ${launderingRisk.moneroConversionRisk?.detected ? "bg-purple-500 animate-pulse" : "bg-gray-600"}`}></div>
                      <h3 className="text-base font-bold text-purple-400">Monero Conversion Risk</h3>
                      {launderingRisk.moneroConversionRisk?.detected && <span className="px-2 py-0.5 bg-purple-600/20 text-purple-400 text-xs rounded">EXTREMELY DIFFICULT TO TRACE</span>}
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{launderingRisk.moneroConversionRisk?.summary}</p>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div className="bg-[#0d1117] rounded p-3">
                        <div className="text-xs text-gray-500">Estimated Lost to Monero</div>
                        <div className="text-lg font-bold text-purple-400" data-testid="text-monero-lost">${(launderingRisk.moneroConversionRisk?.estimatedLostToMonero || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-[#0d1117] rounded p-3">
                        <div className="text-xs text-gray-500">Confirmed Conversions</div>
                        <div className="text-lg font-bold text-purple-400">{launderingRisk.moneroConversionRisk?.confirmedConversions?.length || 0}</div>
                      </div>
                    </div>
                    <div className="mt-3 bg-purple-900/10 border border-purple-900/20 rounded p-2 text-xs text-purple-300 mb-3">
                      {launderingRisk.moneroConversionRisk?.traceability}
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-gray-500 mb-2">Monitored Monero On-Ramps</div>
                      <div className="grid grid-cols-2 gap-1">
                        {launderingRisk.moneroConversionRisk?.knownOnramps && Object.entries(launderingRisk.moneroConversionRisk.knownOnramps).map(([domain, label]: [string, any]) => (
                          <div key={domain} className="bg-[#0d1117] rounded px-2 py-1 text-xs text-gray-400">
                            <span className="text-purple-400 font-mono">{domain}</span> — {label}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#161b22] border border-orange-900/40 rounded-lg p-4" data-testid="section-defi-freeze-gaps">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-3 h-3 rounded-full bg-orange-500 animate-pulse"></div>
                      <h3 className="text-base font-bold text-orange-400">DeFi Freeze Protocol Gaps</h3>
                      <span className="px-2 py-0.5 bg-orange-600/20 text-orange-400 text-xs rounded">NO UNIFIED BLACKLIST</span>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{launderingRisk.defiFreezeGaps?.summary}</p>
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="bg-[#0d1117] rounded p-3 border border-red-900/20">
                        <div className="text-xs text-gray-500">Unfreezable Token Value</div>
                        <div className="text-lg font-bold text-red-400" data-testid="text-unfreezable-value">${formatLargeValue(launderingRisk.defiFreezeGaps?.totalUnfreezableValue || 0)}</div>
                      </div>
                      <div className="bg-[#0d1117] rounded p-3 border border-green-900/20">
                        <div className="text-xs text-gray-500">Freezeable Token Value</div>
                        <div className="text-lg font-bold text-green-400" data-testid="text-freezeable-value">${formatLargeValue(launderingRisk.defiFreezeGaps?.totalFreezeableValue || 0)}</div>
                      </div>
                    </div>

                    {launderingRisk.defiFreezeGaps?.unfreezableTokensHeld?.length > 0 && (
                      <div className="mb-4">
                        <div className="text-xs text-gray-500 mb-2">Unfreezable Tokens Detected</div>
                        <div className="space-y-1">
                          {launderingRisk.defiFreezeGaps.unfreezableTokensHeld.map((t: any) => (
                            <div key={t.token} className="bg-red-900/10 border border-red-900/20 rounded px-3 py-2 flex justify-between items-center">
                              <div>
                                <span className="text-red-400 font-bold text-sm">{t.token}</span>
                                <span className="text-gray-500 text-xs ml-2">across {t.walletCount} wallet{t.walletCount > 1 ? "s" : ""}</span>
                              </div>
                              <div className="text-right">
                                <div className="text-red-400 font-mono text-sm">{formatTokenBalance(t.totalBalance)}</div>
                                <div className="text-gray-600 text-xs">{t.reason}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {launderingRisk.defiFreezeGaps?.freezeableTokensHeld?.length > 0 && (
                      <div className="mb-4">
                        <div className="text-xs text-gray-500 mb-2">Freezeable Tokens (can request freeze)</div>
                        <div className="space-y-1">
                          {launderingRisk.defiFreezeGaps.freezeableTokensHeld.map((t: any) => (
                            <div key={t.token} className="bg-green-900/10 border border-green-900/20 rounded px-3 py-2 flex justify-between items-center">
                              <div>
                                <span className="text-green-400 font-bold text-sm">{t.token}</span>
                                <span className="text-gray-500 text-xs ml-2">{t.freezeRequested ? "Freeze requested" : "No freeze requested"}</span>
                              </div>
                              <div className="text-right">
                                <div className="text-green-400 font-mono text-sm">{formatTokenBalance(t.totalBalance)}</div>
                                <div className="text-gray-600 text-xs">{t.authority}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <div className="text-xs text-gray-500 mb-2">DeFi Protocol Freeze Gaps ({launderingRisk.defiFreezeGaps?.protocolGaps?.length || 0})</div>
                      <div className="space-y-1 max-h-60 overflow-y-auto">
                        {launderingRisk.defiFreezeGaps?.protocolGaps?.map((g: any, idx: number) => (
                          <div key={idx} className="bg-[#0d1117] border border-orange-900/10 rounded px-3 py-2">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-orange-400 font-bold text-xs">{g.protocol}</span>
                            </div>
                            <div className="text-xs text-gray-500">Gap: {g.gap}</div>
                            <div className="text-xs text-red-400 mt-0.5">Risk: {g.risk}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-3 bg-orange-900/10 border border-orange-900/20 rounded p-2 text-xs text-orange-300">
                      There is currently no unified protocol for blacklisting or freezing addresses across DeFi protocols. Each protocol operates independently, and most decentralized protocols have no mechanism to block specific addresses. This fundamental gap in DeFi infrastructure allows attackers to freely swap, bridge, and mix stolen funds across the ecosystem.
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "beacon" && (
            <motion.div key="beacon" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400" data-testid="text-beacon-title">
                    Alpha Spider Beacon Protocol&trade;
                  </h2>
                  <div className="text-xs text-gray-500">Cross-chain persistent surveillance beacon intelligence system</div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    data-testid="button-scan-beacons"
                    disabled={scanningBeacons}
                    onClick={async () => {
                      setScanningBeacons(true);
                      setScanResult(null);
                      try {
                        const resp = await fetch("/api/forensic/beacon/check-now", { method: "POST", credentials: "include" });
                        const data = await resp.json();
                        setScanResult({ count: data.signalsDetected || 0, time: new Date().toLocaleTimeString() });
                        refetchBeaconSignals();
                        refetchBeaconStats();
                      } catch {}
                      setScanningBeacons(false);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-900/20 border border-cyan-700/30 rounded-lg hover:bg-cyan-900/40 transition-colors text-xs text-cyan-400 font-medium disabled:opacity-50"
                  >
                    {scanningBeacons ? (
                      <><svg className="animate-spin h-3 w-3" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Scanning...</>
                    ) : (
                      <><svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg> Scan Now</>
                    )}
                  </button>
                  {scanResult && (
                    <span className="text-[10px] text-gray-500">{scanResult.count} signals @ {scanResult.time}</span>
                  )}
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-900/20 border border-emerald-700/30 rounded-lg">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-xs text-emerald-400 font-medium">Protocol Active</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
                {[
                  { label: "Active Beacons", value: beaconStats?.activeBeacons || 0, color: "text-emerald-400", bg: "from-emerald-600/10 to-emerald-900/10" },
                  { label: "Dormant Beacons", value: beaconStats?.dormantBeacons || 0, color: "text-yellow-400", bg: "from-yellow-600/10 to-yellow-900/10" },
                  { label: "Signals Today", value: beaconStats?.signalsToday || 0, color: "text-cyan-400", bg: "from-cyan-600/10 to-cyan-900/10" },
                  { label: "Chains Covered", value: beaconStats?.chainsCovered || 0, color: "text-blue-400", bg: "from-blue-600/10 to-blue-900/10" },
                  { label: "AUC Traps Active", value: beaconStats?.aucTrapsActive || 0, color: "text-red-400", bg: "from-red-600/10 to-red-900/10" },
                ].map(card => (
                  <div key={card.label} className={`bg-gradient-to-br ${card.bg} border border-gray-800/50 rounded-xl p-4`} data-testid={`stat-${card.label.toLowerCase().replace(/\s/g, '-')}`}>
                    <div className={`text-2xl font-bold ${card.color}`}>{card.value}</div>
                    <div className="text-xs text-gray-500 mt-1">{card.label}</div>
                  </div>
                ))}
              </div>

              {!selectedCase && (
                <div className="bg-[#161b22] rounded-xl border border-yellow-900/40 p-6 text-center mb-6">
                  <div className="text-yellow-400 text-sm font-medium mb-1">Select a Case First</div>
                  <div className="text-gray-500 text-xs">Choose a forensic case from the dropdown above to deploy beacons and view signals.</div>
                </div>
              )}

              {selectedCase && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
                  <div className="bg-[#161b22] rounded-xl border border-emerald-900/30 p-5">
                    <h3 className="text-sm font-bold text-emerald-400 mb-4 flex items-center gap-2">
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>
                      DEPLOY SPIDER BEACON
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Target Address</label>
                        <select
                          data-testid="select-beacon-wallet"
                          value={(() => {
                            const match = wallets?.find((w: any) => w.address === beaconDeployForm.targetAddress && w.chain === beaconDeployForm.chain);
                            if (match) return `${match.chain}:${match.address}`;
                            const anyMatch = wallets?.find((w: any) => w.address === beaconDeployForm.targetAddress);
                            if (anyMatch) return `${anyMatch.chain}:${anyMatch.address}`;
                            return "__custom__";
                          })()}
                          onChange={e => {
                            if (e.target.value !== "__custom__") {
                              const [chain, ...addrParts] = e.target.value.split(":");
                              const addr = addrParts.join(":");
                              setBeaconDeployForm(f => ({ ...f, targetAddress: addr, chain }));
                            } else {
                              setBeaconDeployForm(f => ({ ...f, targetAddress: "" }));
                            }
                          }}
                          className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-emerald-500 outline-none mb-2"
                        >
                          <option value="__custom__">— Select wallet of interest or enter custom —</option>
                          {wallets?.map((w: any) => (
                            <option key={`${w.address}-${w.chain}`} value={`${w.chain}:${w.address}`}>
                              {w.label || w.role || "Unknown"} — {w.address?.slice(0, 10)}...{w.address?.slice(-6)} ({w.chain})
                            </option>
                          ))}
                        </select>
                        <input
                          data-testid="input-beacon-address"
                          value={beaconDeployForm.targetAddress}
                          onChange={e => setBeaconDeployForm(f => ({ ...f, targetAddress: e.target.value }))}
                          placeholder="0x... or bc1... or T... (or select from dropdown above)"
                          className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-emerald-500 outline-none"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">Blockchain</label>
                          <select
                            data-testid="select-beacon-chain"
                            value={beaconDeployForm.chain}
                            onChange={e => setBeaconDeployForm(f => ({ ...f, chain: e.target.value }))}
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                          >
                            {ALL_CHAIN_OPTIONS.map(c => (
                              <option key={c.value} value={c.value}>{c.label}</option>
                            ))}
                            <option value="auc">AUC Blockchain</option>
                            <option value="monero">Monero (Statistical)</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">Beacon Type</label>
                          <select
                            data-testid="select-beacon-type"
                            value={beaconDeployForm.type}
                            onChange={e => setBeaconDeployForm(f => ({ ...f, type: e.target.value }))}
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                          >
                            <option value="address_monitor">Address Monitor</option>
                            <option value="cross_chain">Cross-Chain (Multi-Network)</option>
                            <option value="dex_watcher">DEX Watcher</option>
                            <option value="bridge_sentinel">Bridge Sentinel</option>
                          </select>
                        </div>
                      </div>
                      {beaconDeployResult && (
                        <div className={`text-xs px-3 py-2 rounded ${beaconDeployResult.ok ? "text-emerald-400 bg-emerald-900/30 border border-emerald-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`}>
                          {beaconDeployResult.msg}
                        </div>
                      )}
                      <button
                        data-testid="button-deploy-beacon"
                        disabled={deployingBeacon || !beaconDeployForm.targetAddress}
                        onClick={async () => {
                          setDeployingBeacon(true);
                          setBeaconDeployResult(null);
                          try {
                            const resp = await fetch("/api/forensic/beacon/deploy", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              credentials: "include",
                              body: JSON.stringify({ caseId: selectedCase, ...beaconDeployForm }),
                            });
                            const data = await resp.json();
                            if (resp.ok) {
                              setBeaconDeployResult({ ok: true, msg: `Beacon ${data.beacon?.id || ''} deployed on ${beaconDeployForm.chain}. ${data.beacon?.linkedBeacons?.length ? `${data.beacon.linkedBeacons.length} dormant cross-chain beacons also deployed.` : ''}` });
                              setBeaconDeployForm(f => ({ ...f, targetAddress: "" }));
                              refetchBeaconList();
                              refetchBeaconStats();
                              refetchBeaconSignals();
                            } else {
                              setBeaconDeployResult({ ok: false, msg: data.message || "Deploy failed" });
                            }
                          } catch (e: any) {
                            setBeaconDeployResult({ ok: false, msg: e.message });
                          } finally {
                            setDeployingBeacon(false);
                          }
                        }}
                        className="w-full px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
                      >
                        {deployingBeacon ? (
                          <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Deploying...</>
                        ) : (
                          <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg> Deploy Beacon</>
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="bg-[#161b22] rounded-xl border border-red-900/30 p-5 relative">
                    <div className="absolute top-3 right-3 bg-emerald-600/20 border border-emerald-600/30 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" /> TRANSFER HOOKS ACTIVE
                    </div>
                    <h3 className="text-sm font-bold text-red-400 mb-4 flex items-center gap-2">
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                      AUC TRAP MECHANISM&trade;
                    </h3>
                    <div className="bg-emerald-900/10 border border-emerald-900/20 rounded p-2.5 text-xs text-emerald-300/80 mb-3">
                      AUC blockchain forensic transfer hooks are ACTIVE. Every AUC transaction is evaluated by the Forensic Hook Engine&trade; at the protocol level. Trapped wallets, watched addresses, and large transfers (&gt;100K AUC) trigger real-time signals.
                    </div>
                    <div className="bg-amber-900/10 border border-amber-900/20 rounded p-2.5 text-xs text-amber-300/70 mb-4">
                      Note: Internal AUC blockchain trap is fully operational. Cross-exchange tracking (swapping external stolen tokens into AUC on public exchanges) requires AUC listing on external exchanges.
                    </div>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">Original Token</label>
                          <input
                            data-testid="input-trap-token"
                            value={aucTrapForm.originalToken}
                            onChange={e => setAucTrapForm(f => ({ ...f, originalToken: e.target.value }))}
                            placeholder="e.g. DAI, USDC, ETH"
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-red-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">Original Chain</label>
                          <select
                            data-testid="select-trap-chain"
                            value={aucTrapForm.originalChain}
                            onChange={e => setAucTrapForm(f => ({ ...f, originalChain: e.target.value }))}
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                          >
                            {ALL_CHAIN_OPTIONS.map(c => (
                              <option key={c.value} value={c.value}>{c.label}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Original Theft Address</label>
                        <input
                          data-testid="input-trap-original-address"
                          value={aucTrapForm.originalAddress}
                          onChange={e => setAucTrapForm(f => ({ ...f, originalAddress: e.target.value }))}
                          placeholder="0x... wallet holding stolen funds"
                          className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-red-500 outline-none"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">AUC Wallet Address</label>
                          <input
                            data-testid="input-trap-auc-wallet"
                            value={aucTrapForm.aucWalletAddress}
                            onChange={e => setAucTrapForm(f => ({ ...f, aucWalletAddress: e.target.value }))}
                            placeholder="ALPHA_... or AUC wallet address"
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-red-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-500 mb-1 block">Amount Swapped</label>
                          <input
                            data-testid="input-trap-amount"
                            value={aucTrapForm.amountSwapped}
                            onChange={e => setAucTrapForm(f => ({ ...f, amountSwapped: e.target.value }))}
                            placeholder="e.g. 50000"
                            className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-red-500 outline-none"
                          />
                        </div>
                      </div>
                      {trapDeployResult && (
                        <div className={`text-xs px-3 py-2 rounded ${trapDeployResult.ok ? "text-emerald-400 bg-emerald-900/30 border border-emerald-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`}>
                          {trapDeployResult.msg}
                        </div>
                      )}
                      <button
                        data-testid="button-deploy-trap"
                        disabled={deployingTrap || !aucTrapForm.originalAddress || !aucTrapForm.aucWalletAddress || !aucTrapForm.amountSwapped}
                        onClick={async () => {
                          setDeployingTrap(true);
                          setTrapDeployResult(null);
                          try {
                            const resp = await fetch("/api/auc/forensic/trap-swap", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              credentials: "include",
                              body: JSON.stringify({
                                caseId: selectedCase,
                                targetAucAddress: aucTrapForm.aucWalletAddress,
                                amount: aucTrapForm.amountSwapped,
                                originalToken: aucTrapForm.originalToken || "UNKNOWN",
                                originalChain: aucTrapForm.originalChain,
                                originalAddress: aucTrapForm.originalAddress,
                              }),
                            });
                            const data = await resp.json();
                            if (resp.ok && data.success) {
                              setTrapDeployResult({ ok: true, msg: data.message || `AUC Trap deployed. Transfer hooks ACTIVE on wallet. All movements will fire forensic signals.` });
                              setAucTrapForm({ originalToken: "", originalChain: "ethereum", originalAddress: "", aucWalletAddress: "", amountSwapped: "" });
                              refetchBeaconList();
                              refetchBeaconStats();
                              refetchBeaconSignals();
                            } else {
                              setTrapDeployResult({ ok: false, msg: data.message || "Trap deploy failed" });
                            }
                          } catch (e: any) {
                            setTrapDeployResult({ ok: false, msg: e.message });
                          } finally {
                            setDeployingTrap(false);
                          }
                        }}
                        className="w-full px-4 py-2.5 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
                      >
                        {deployingTrap ? (
                          <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Deploying Trap...</>
                        ) : (
                          <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg> Deploy AUC Trap &amp; Activate Transfer Hooks</>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {selectedCase && (
                <>
                  <div className="mb-6">
                    <h3 className="text-sm font-bold text-gray-300 mb-3 flex items-center gap-2">
                      <svg className="h-4 w-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                      BEACON SIGNAL FEED
                      {beaconSignals && beaconSignals.length > 0 && (
                        <span className="text-xs text-gray-500 font-normal">({beaconSignals.length} signals)</span>
                      )}
                    </h3>
                    {(!beaconSignals || beaconSignals.length === 0) ? (
                      <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-6 text-center">
                        <div className="text-gray-500 text-sm mb-1">No beacon signals yet</div>
                        <div className="text-gray-600 text-xs">Deploy beacons above to start tracking. Signals appear here when activity is detected.</div>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-[400px] overflow-y-auto">
                        {beaconSignals.map((sig: any, idx: number) => (
                          <div key={sig.id || idx} className={`bg-[#161b22] rounded-lg border p-3 ${sig.severity === 'critical' ? 'border-red-800/50' : sig.severity === 'warning' ? 'border-yellow-800/50' : 'border-gray-800/30'}`} data-testid={`signal-${sig.id || idx}`}>
                            <div className="flex items-center justify-between mb-1.5">
                              <div className="flex items-center gap-2">
                                <span className={`relative flex h-2 w-2 ${sig.severity === 'critical' ? '' : 'opacity-70'}`}>
                                  {sig.severity === 'critical' && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>}
                                  <span className={`relative inline-flex rounded-full h-2 w-2 ${sig.severity === 'critical' ? 'bg-red-500' : sig.severity === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'}`}></span>
                                </span>
                                <span className="text-xs font-bold text-gray-300">{(sig.signalType || '').replace(/_/g, ' ').toUpperCase()}</span>
                                <span className="text-[10px] px-1.5 py-0.5 bg-gray-800 rounded text-gray-400">{sig.chain}</span>
                              </div>
                              <span className="text-[10px] text-gray-500">{sig.timestamp ? new Date(sig.timestamp).toLocaleString() : ''}</span>
                            </div>
                            <div className="flex items-center gap-3 text-xs">
                              <span className="text-gray-500">From:</span>
                              <span className="font-mono text-cyan-400">{sig.fromAddress ? shortenAddr(sig.fromAddress) : '—'}</span>
                              {sig.toAddress && (
                                <>
                                  <span className="text-gray-600">&rarr;</span>
                                  <span className="font-mono text-emerald-400">{shortenAddr(sig.toAddress)}</span>
                                </>
                              )}
                              {sig.amount && sig.amount !== '0' && sig.amount !== '0.000000' && (
                                <span className="text-white font-medium">{parseFloat(sig.amount).toFixed(4)} {sig.tokenSymbol || ''}</span>
                              )}
                            </div>
                            {sig.metadata?.message && (
                              <div className="mt-1.5 text-[11px] text-gray-400 bg-[#0d1117] rounded px-2 py-1">{sig.metadata.message}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-gray-300 mb-3 flex items-center gap-2">
                      <svg className="h-4 w-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>
                      ACTIVE BEACONS
                      {beaconList && beaconList.length > 0 && (
                        <span className="text-xs text-gray-500 font-normal">({beaconList.length} deployed)</span>
                      )}
                    </h3>
                    {(!beaconList || beaconList.length === 0) ? (
                      <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-6 text-center">
                        <div className="text-gray-500 text-sm">No beacons deployed for this case</div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {beaconList.map((beacon: any) => (
                          <div key={beacon.id} className={`bg-[#161b22] rounded-lg border p-3 ${beacon.status === 'active' ? 'border-emerald-800/40' : beacon.status === 'triggered' ? 'border-red-800/40' : beacon.status === 'dormant' ? 'border-yellow-800/40' : 'border-gray-800/30'}`} data-testid={`beacon-${beacon.id}`}>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="relative flex h-2.5 w-2.5">
                                  {(beacon.status === 'active' || beacon.status === 'triggered') && <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${beacon.status === 'triggered' ? 'bg-red-400' : 'bg-emerald-400'} opacity-75`}></span>}
                                  <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${beacon.status === 'active' ? 'bg-emerald-500' : beacon.status === 'triggered' ? 'bg-red-500' : beacon.status === 'dormant' ? 'bg-yellow-500' : 'bg-gray-600'}`}></span>
                                </span>
                                <span className={`text-[10px] font-bold uppercase ${beacon.status === 'active' ? 'text-emerald-400' : beacon.status === 'triggered' ? 'text-red-400' : beacon.status === 'dormant' ? 'text-yellow-400' : 'text-gray-500'}`}>{beacon.status}</span>
                              </div>
                              {beacon.status !== 'deactivated' && (
                                <button
                                  data-testid={`button-deactivate-${beacon.id}`}
                                  onClick={async () => {
                                    await fetch(`/api/forensic/beacon/deactivate/${beacon.id}`, { method: "POST", credentials: "include" });
                                    refetchBeaconList();
                                    refetchBeaconStats();
                                  }}
                                  className="text-[10px] text-gray-500 hover:text-red-400 transition-colors"
                                >
                                  Deactivate
                                </button>
                              )}
                            </div>
                            <div className="text-xs font-mono text-cyan-400 mb-1 truncate" title={beacon.targetAddress}>{shortenAddr(beacon.targetAddress || '')}</div>
                            <div className="flex items-center gap-2 text-[10px] text-gray-500">
                              <span className="px-1.5 py-0.5 bg-gray-800/80 rounded">{beacon.chain}</span>
                              <span className="px-1.5 py-0.5 bg-gray-800/80 rounded">{(beacon.type || '').replace(/_/g, ' ')}</span>
                            </div>
                            <div className="flex items-center justify-between mt-2 text-[10px]">
                              <span className="text-gray-600">{beacon.signalCount || 0} signals</span>
                              <span className="text-gray-600">{beacon.lastSignalAt ? timeAgo(beacon.lastSignalAt) : 'No signals'}</span>
                            </div>
                            {beacon.linkedBeacons?.length > 0 && (
                              <div className="mt-1.5 text-[10px] text-gray-600">
                                + {beacon.linkedBeacons.length} linked cross-chain beacons
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {beaconStats?.chains && beaconStats.chains.length > 0 && (
                    <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-5">
                      <h3 className="text-sm font-bold text-gray-300 mb-3">CROSS-CHAIN COVERAGE</h3>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(CHAIN_EXPLORERS).map(([chain, info]) => {
                          const isActive = beaconStats.chains.includes(chain);
                          return (
                            <div
                              key={chain}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${isActive ? 'bg-emerald-900/30 border border-emerald-600/40 text-emerald-400' : 'bg-gray-900/30 border border-gray-800/30 text-gray-600'}`}
                            >
                              <div className="flex items-center gap-1.5">
                                {isActive && (
                                  <span className="relative flex h-1.5 w-1.5">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                                  </span>
                                )}
                                {info.name}
                              </div>
                            </div>
                          );
                        })}
                        <div className={`px-3 py-1.5 rounded-lg text-xs font-medium ${beaconStats.chains.includes('auc') ? 'bg-red-900/30 border border-red-600/40 text-red-400' : 'bg-gray-900/30 border border-gray-800/30 text-gray-600'}`}>
                          <div className="flex items-center gap-1.5">
                            {beaconStats.chains.includes('auc') && (
                              <span className="relative flex h-1.5 w-1.5">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
                              </span>
                            )}
                            AUC Blockchain (Trap)
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </motion.div>
          )}

          {activeTab === "privacy" && (
            <motion.div key="privacy" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 mb-6" style={{ fontFamily: "'Orbitron', sans-serif" }} data-testid="text-privacy-tracker-title">
                Privacy Protocol Tracker
              </h2>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <div className="bg-[#161b22] rounded-xl border border-purple-800/30 p-5">
                  <h3 className="text-sm font-bold text-purple-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                    Tornado Cash Analyzer
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Deposit Transaction Hash</label>
                      <input
                        data-testid="input-tornado-deposit"
                        value={privacyTornadoDeposit}
                        onChange={e => setPrivacyTornadoDeposit(e.target.value)}
                        placeholder="0x... deposit tx hash"
                        className="w-full bg-[#0d1117] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-purple-500 focus:outline-none font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Withdrawal Transaction Hash</label>
                      <input
                        data-testid="input-tornado-withdrawal"
                        value={privacyTornadoWithdrawal}
                        onChange={e => setPrivacyTornadoWithdrawal(e.target.value)}
                        placeholder="0x... withdrawal tx hash"
                        className="w-full bg-[#0d1117] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-purple-500 focus:outline-none font-mono"
                      />
                    </div>
                    <button
                      data-testid="button-analyze-tornado"
                      disabled={privacyTornadoLoading || !privacyTornadoDeposit}
                      onClick={async () => {
                        setPrivacyTornadoLoading(true);
                        setPrivacyTornadoResult(null);
                        try {
                          const resp = await fetch("/api/forensic/privacy-tracker/analyze-tornado", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            credentials: "include",
                            body: JSON.stringify({ depositTxHash: privacyTornadoDeposit, withdrawalTxHash: privacyTornadoWithdrawal }),
                          });
                          const data = await resp.json();
                          if (!resp.ok) throw new Error(data.message || data.error || `Server error ${resp.status}`);
                          setPrivacyTornadoResult(data);
                        } catch (e: any) {
                          setPrivacyTornadoResult({ error: e.message });
                        } finally {
                          setPrivacyTornadoLoading(false);
                        }
                      }}
                      className="w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-lg text-sm font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {privacyTornadoLoading ? (
                        <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Analyzing...</>
                      ) : (
                        <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg> Analyze Tornado Cash Transactions</>
                      )}
                    </button>
                  </div>
                  {privacyTornadoResult && (
                    <div className="mt-4 space-y-2" data-testid="tornado-results">
                      {privacyTornadoResult.error || privacyTornadoResult.message ? (
                        <div className="text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{privacyTornadoResult.error || privacyTornadoResult.message}</div>
                      ) : (
                        <>
                          {privacyTornadoResult.overallRiskScore !== undefined && (
                            <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                              <div className="flex items-center gap-3">
                                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Deanonymization Risk</div>
                                <div className={`text-lg font-bold ${privacyTornadoResult.overallRiskScore > 70 ? 'text-red-400' : privacyTornadoResult.overallRiskScore > 40 ? 'text-yellow-400' : 'text-green-400'}`}>
                                  {privacyTornadoResult.overallRiskScore}/100
                                </div>
                                <div className="flex-1 bg-gray-800 rounded-full h-2">
                                  <div className={`h-2 rounded-full ${privacyTornadoResult.overallRiskScore > 70 ? 'bg-red-500' : privacyTornadoResult.overallRiskScore > 40 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{ width: `${privacyTornadoResult.overallRiskScore}%` }} />
                                </div>
                              </div>
                              {privacyTornadoResult.deanonymizationLikelihood && (
                                <div className="text-[10px] text-orange-400 mt-2 font-bold">{privacyTornadoResult.deanonymizationLikelihood}</div>
                              )}
                            </div>
                          )}
                          <div className="text-[10px] text-gray-500 uppercase tracking-wider mt-3 mb-2">Tracking Opportunities ({privacyTornadoResult.opportunities?.length || 0})</div>
                          {(privacyTornadoResult.opportunities || []).map((opp: any, i: number) => (
                            <div key={i} className={`bg-[#0d1117] rounded-lg p-3 border ${opp.actionable ? 'border-red-800/50' : 'border-gray-800/50'}`}>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-bold text-gray-200">{opp.method}</span>
                                <div className="flex items-center gap-2">
                                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${opp.actionable ? 'bg-red-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
                                    {opp.actionable ? 'ACTIONABLE' : 'LOW SIGNAL'}
                                  </span>
                                  <span className="text-[10px] text-gray-500">{opp.confidence}% confidence</span>
                                </div>
                              </div>
                              <div className="text-[10px] text-gray-500">{opp.finding}</div>
                              {opp.forensicAction && <div className="text-[10px] text-cyan-400 mt-1">{opp.forensicAction}</div>}
                            </div>
                          ))}
                          {privacyTornadoResult.recommendations && (
                            <div className="bg-[#0d1117] rounded-lg p-3 border border-cyan-800/30 mt-2">
                              <div className="text-[10px] text-cyan-400 uppercase tracking-wider mb-2 font-bold">Recommended Actions</div>
                              {privacyTornadoResult.recommendations.map((rec: string, i: number) => (
                                <div key={i} className="text-[10px] text-gray-300 mb-1">• {rec}</div>
                              ))}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  )}
                </div>

                <div className="bg-[#161b22] rounded-xl border border-orange-800/30 p-5">
                  <h3 className="text-sm font-bold text-orange-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                    Monero On-Ramp Tracker
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Source Chain Address (BTC/ETH to XMR)</label>
                      <input
                        data-testid="input-monero-source"
                        value={privacyMoneroAddr}
                        onChange={e => setPrivacyMoneroAddr(e.target.value)}
                        placeholder="Source address used for XMR conversion"
                        className="w-full bg-[#0d1117] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-orange-500 focus:outline-none font-mono"
                      />
                    </div>
                    <button
                      data-testid="button-analyze-monero"
                      disabled={privacyMoneroLoading || !privacyMoneroAddr}
                      onClick={async () => {
                        setPrivacyMoneroLoading(true);
                        setPrivacyMoneroResult(null);
                        try {
                          const resp = await fetch("/api/forensic/privacy-tracker/analyze-monero-onramp", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            credentials: "include",
                            body: JSON.stringify({ sourceChainAddress: privacyMoneroAddr }),
                          });
                          const data = await resp.json();
                          if (!resp.ok) throw new Error(data.message || data.error || `Server error ${resp.status}`);
                          setPrivacyMoneroResult(data);
                        } catch (e: any) {
                          setPrivacyMoneroResult({ error: e.message });
                        } finally {
                          setPrivacyMoneroLoading(false);
                        }
                      }}
                      className="w-full px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-lg text-sm font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {privacyMoneroLoading ? (
                        <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Analyzing...</>
                      ) : (
                        <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg> Analyze Monero On-Ramp</>
                      )}
                    </button>
                  </div>
                  {privacyMoneroResult && (
                    <div className="mt-4 space-y-2" data-testid="monero-results">
                      {privacyMoneroResult.error || privacyMoneroResult.message ? (
                        <div className="text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{privacyMoneroResult.error || privacyMoneroResult.message}</div>
                      ) : (
                        <>
                          {privacyMoneroResult.overallTrackability !== undefined && (
                            <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                              <div className="flex items-center gap-3">
                                <div className="text-[10px] text-gray-500 uppercase tracking-wider">Overall Trackability</div>
                                <div className={`text-lg font-bold ${privacyMoneroResult.overallTrackability > 70 ? 'text-red-400' : privacyMoneroResult.overallTrackability > 40 ? 'text-yellow-400' : 'text-green-400'}`}>
                                  {privacyMoneroResult.overallTrackability}%
                                </div>
                                <div className="flex-1 bg-gray-800 rounded-full h-2">
                                  <div className={`h-2 rounded-full ${privacyMoneroResult.overallTrackability > 70 ? 'bg-red-500' : privacyMoneroResult.overallTrackability > 40 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{ width: `${privacyMoneroResult.overallTrackability}%` }} />
                                </div>
                              </div>
                            </div>
                          )}
                          {privacyMoneroResult.exchangeCorrelation && (
                            <div>
                              <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Exchange Correlation</div>
                              <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50 mb-2">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-xs font-bold text-orange-400">{privacyMoneroResult.exchangeCorrelation.exchangesIdentified?.join(', ')}</span>
                                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${privacyMoneroResult.exchangeCorrelation.correlationConfidence > 70 ? 'bg-red-600 text-white' : privacyMoneroResult.exchangeCorrelation.correlationConfidence > 40 ? 'bg-yellow-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
                                    {privacyMoneroResult.exchangeCorrelation.correlationConfidence}% confidence
                                  </span>
                                </div>
                                <div className="text-[10px] text-gray-400">{privacyMoneroResult.exchangeCorrelation.kycExposure}</div>
                              </div>
                            </div>
                          )}
                          {privacyMoneroResult.timingAnalysis && (
                            <div>
                              <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Timing Analysis</div>
                              <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                                <div className="space-y-1">
                                  <div><span className="text-[10px] text-gray-500">On-Ramp Window:</span> <span className="text-xs text-gray-200">{privacyMoneroResult.timingAnalysis.onRampWindow}</span></div>
                                  <div><span className="text-[10px] text-gray-500">Confidence:</span> <span className="text-xs text-yellow-400">{privacyMoneroResult.timingAnalysis.confidence}%</span></div>
                                  {privacyMoneroResult.timingAnalysis.suspiciousPatterns?.map((p: string, i: number) => (
                                    <div key={i} className="text-[10px] text-red-400">• {p}</div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          )}
                          {privacyMoneroResult.amountMatching && (
                            <div>
                              <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Amount Matching</div>
                              {(privacyMoneroResult.amountMatching.matchedPairs || []).map((am: any, i: number) => (
                                <div key={i} className="bg-[#0d1117] rounded-lg p-2 border border-gray-800/50 mb-1 flex items-center justify-between">
                                  <span className="text-xs text-gray-300 font-mono">{am.sourceAmount} → {am.xmrEstimate}</span>
                                  <span className="text-[10px] text-gray-500">{am.confidence}% match</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-6 bg-[#161b22] rounded-xl border border-cyan-800/30 p-5">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" /></svg>
                  Behavioral Fingerprint Engine
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                  <div className="col-span-2">
                    <input
                      data-testid="input-fingerprint-address"
                      value={privacyFingerprintAddr}
                      onChange={e => setPrivacyFingerprintAddr(e.target.value)}
                      placeholder="Wallet address to fingerprint"
                      className="w-full bg-[#0d1117] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-cyan-500 focus:outline-none font-mono"
                    />
                  </div>
                  <button
                    data-testid="button-analyze-fingerprint"
                    disabled={privacyFingerprintLoading || !privacyFingerprintAddr}
                    onClick={async () => {
                      setPrivacyFingerprintLoading(true);
                      setPrivacyFingerprintResult(null);
                      try {
                        const resp = await fetch("/api/forensic/privacy-tracker/behavioral-fingerprint", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          credentials: "include",
                          body: JSON.stringify({ walletAddress: privacyFingerprintAddr }),
                        });
                        const data = await resp.json();
                        if (!resp.ok) throw new Error(data.message || data.error || `Server error ${resp.status}`);
                        setPrivacyFingerprintResult(data);
                      } catch (e: any) {
                        setPrivacyFingerprintResult({ error: e.message });
                      } finally {
                        setPrivacyFingerprintLoading(false);
                      }
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-sm font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {privacyFingerprintLoading ? (
                      <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Analyzing...</>
                    ) : (
                      <>Compute Fingerprint</>
                    )}
                  </button>
                </div>
                {privacyFingerprintResult && (
                  <div data-testid="fingerprint-results">
                    {privacyFingerprintResult.error || privacyFingerprintResult.message ? (
                      <div className="text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{privacyFingerprintResult.error || privacyFingerprintResult.message}</div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {privacyFingerprintResult.overallFingerprintStrength !== undefined && (
                          <div className="col-span-2 bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                            <div className="flex items-center gap-3">
                              <div className="text-[10px] text-gray-500 uppercase tracking-wider">Fingerprint Strength</div>
                              <div className={`text-lg font-bold ${privacyFingerprintResult.overallFingerprintStrength > 70 ? 'text-red-400' : privacyFingerprintResult.overallFingerprintStrength > 40 ? 'text-yellow-400' : 'text-green-400'}`}>
                                {privacyFingerprintResult.overallFingerprintStrength}%
                              </div>
                              <div className="flex-1 bg-gray-800 rounded-full h-2">
                                <div className={`h-2 rounded-full ${privacyFingerprintResult.overallFingerprintStrength > 70 ? 'bg-red-500' : privacyFingerprintResult.overallFingerprintStrength > 40 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{ width: `${privacyFingerprintResult.overallFingerprintStrength}%` }} />
                              </div>
                              <span className="text-[10px] text-gray-500 font-mono">{privacyFingerprintResult.fingerprintHash}</span>
                            </div>
                          </div>
                        )}
                        {privacyFingerprintResult.gasPatterns && (
                          <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Gas Price Patterns</div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Avg Gas Price</span><span className="text-gray-200">{privacyFingerprintResult.gasPatterns.averageGasPrice}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Gas Range</span><span className="text-gray-200">{privacyFingerprintResult.gasPatterns.preferredGasRange}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Consistency</span><span className={`${privacyFingerprintResult.gasPatterns.consistencyScore > 70 ? 'text-red-400' : 'text-green-400'}`}>{privacyFingerprintResult.gasPatterns.consistencyScore}%</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Uniqueness</span><span className="text-cyan-400">{privacyFingerprintResult.gasPatterns.uniqueness}</span></div>
                            </div>
                          </div>
                        )}
                        {privacyFingerprintResult.timingProfile && (
                          <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Transaction Timing Profile</div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Active Hours (UTC)</span><span className="text-gray-200">{privacyFingerprintResult.timingProfile.mostActiveHours?.join(', ')}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Est. Timezone</span><span className="text-yellow-400">{privacyFingerprintResult.timingProfile.timezone}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Day Preference</span><span className="text-gray-200">{privacyFingerprintResult.timingProfile.weekdayPreference}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Activity Pattern</span><span className="text-gray-200">{privacyFingerprintResult.timingProfile.activityPattern}</span></div>
                            </div>
                          </div>
                        )}
                        {privacyFingerprintResult.exchangePreferences && (
                          <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Exchange Preferences</div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Primary Exchange</span><span className="text-orange-400">{privacyFingerprintResult.exchangePreferences.primaryExchange}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Detected</span><span className="text-gray-200">{privacyFingerprintResult.exchangePreferences.detectedExchanges?.join(', ')}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Frequency</span><span className="text-gray-200">{privacyFingerprintResult.exchangePreferences.depositFrequency}</span></div>
                            </div>
                          </div>
                        )}
                        {privacyFingerprintResult.poolUsagePatterns && (
                          <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Pool Usage Patterns</div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Preferred Pools</span><span className="text-gray-200">{privacyFingerprintResult.poolUsagePatterns.preferredPools?.join(', ')}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Deposit Pattern</span><span className="text-gray-200">{privacyFingerprintResult.poolUsagePatterns.depositPattern}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Withdrawal Pattern</span><span className="text-gray-200">{privacyFingerprintResult.poolUsagePatterns.withdrawalPattern}</span></div>
                              <div className="flex justify-between text-xs"><span className="text-gray-400">Churning</span><span className={`${privacyFingerprintResult.poolUsagePatterns.churningDetected ? 'text-red-400' : 'text-green-400'}`}>{privacyFingerprintResult.poolUsagePatterns.churningDetected ? 'DETECTED' : 'None'}</span></div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-6 bg-[#161b22] rounded-xl border border-amber-800/30 p-5">
                <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                  Tracking Methods Reference
                </h3>
                {!privacyMethodsLoaded && (
                  <button
                    data-testid="button-load-methods"
                    onClick={async () => {
                      try {
                        const resp = await fetch("/api/forensic/privacy-tracker/tracking-methods", { credentials: "include" });
                        const data = await resp.json();
                        setPrivacyTrackingMethods(data.methods || data || []);
                        setPrivacyMethodsLoaded(true);
                      } catch {}
                    }}
                    className="px-4 py-2 bg-amber-600/20 border border-amber-600/40 hover:bg-amber-600/30 rounded-lg text-amber-400 text-xs font-medium transition-colors"
                  >
                    Load Tracking Methods
                  </button>
                )}
                {privacyMethodsLoaded && privacyTrackingMethods.length > 0 && (
                  <div className="space-y-2" data-testid="tracking-methods-list">
                    {privacyTrackingMethods.map((method: any, i: number) => (
                      <div key={method.id || i} className="bg-[#0d1117] rounded-lg border border-gray-800/50 overflow-hidden">
                        <button
                          data-testid={`button-expand-method-${i}`}
                          onClick={() => setPrivacyMethodsExpanded(privacyMethodsExpanded === (method.id || `m${i}`) ? null : (method.id || `m${i}`))}
                          className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/30 transition-colors text-left"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xs font-bold text-gray-200">{method.name}</span>
                            {method.effectiveness !== undefined && (
                              <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${method.effectiveness > 70 ? 'bg-green-600 text-white' : method.effectiveness > 40 ? 'bg-yellow-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
                                {method.effectiveness}% effective
                              </span>
                            )}
                            {method.category && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-900/30 border border-purple-700/30 text-purple-400">{method.category}</span>
                            )}
                          </div>
                          <span className="text-gray-500 text-xs">{privacyMethodsExpanded === (method.id || `m${i}`) ? '▲' : '▼'}</span>
                        </button>
                        {privacyMethodsExpanded === (method.id || `m${i}`) && (
                          <div className="px-4 pb-3 border-t border-gray-800/50">
                            <p className="text-xs text-gray-400 mt-2">{method.description}</p>
                            {method.applicableTo && (
                              <div className="mt-2 flex items-center gap-1">
                                <span className="text-[10px] text-gray-500">Applies to:</span>
                                {(Array.isArray(method.applicableTo) ? method.applicableTo : [method.applicableTo]).map((a: string, j: number) => (
                                  <span key={j} className="text-[10px] px-1.5 py-0.5 bg-cyan-900/30 border border-cyan-700/30 rounded text-cyan-400">{a}</span>
                                ))}
                              </div>
                            )}
                            {method.limitations && (
                              <div className="mt-2 text-[10px] text-gray-500">Limitations: <span className="text-gray-400">{method.limitations}</span></div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>


              <div className="mt-6 bg-[#161b22] rounded-xl border border-red-800/30 p-5">
                <h3 className="text-sm font-bold text-red-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.072 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                  Alpha Privacy Exploit Scanner™
                </h3>
                <div className="text-xs text-gray-400 mb-4">Deep security audit — scans all known protocol vulnerabilities, metadata leaks, network surveillance vectors, and operational security failures across Tornado Cash and Monero on-ramp infrastructure.</div>

                <div className="flex flex-wrap items-center gap-3 mb-4">
                  <button
                    data-testid="button-run-exploit-scan"
                    disabled={exploitScanLoading}
                    onClick={async () => {
                      setExploitScanLoading(true);
                      setExploitScanResult(null);
                      try {
                        const resp = await fetch("/api/forensic/privacy-tracker/exploit-scan", { credentials: "include" });
                        const data = await resp.json();
                        if (!resp.ok) throw new Error(data.message || `Server error ${resp.status}`);
                        setExploitScanResult(data);
                      } catch (e: any) {
                        setExploitScanResult({ error: e.message });
                      } finally {
                        setExploitScanLoading(false);
                      }
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white rounded-lg text-sm font-bold transition-all disabled:opacity-50 flex items-center gap-2"
                  >
                    {exploitScanLoading ? (
                      <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Scanning...</>
                    ) : (
                      <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg> Run Full Exploit Scan</>
                    )}
                  </button>

                  {selectedCase && (
                    <button
                      data-testid="button-scan-case-wallets"
                      disabled={caseScanLoading}
                      onClick={async () => {
                        setCaseScanLoading(true);
                        setCaseScanResult(null);
                        try {
                          const resp = await fetch("/api/forensic/privacy-tracker/scan-case-wallets", {
                            method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
                            body: JSON.stringify({ caseId: selectedCase }),
                          });
                          const data = await resp.json();
                          if (!resp.ok) throw new Error(data.message || `Server error ${resp.status}`);
                          setCaseScanResult(data);
                        } catch (e: any) {
                          setCaseScanResult({ error: e.message });
                        } finally {
                          setCaseScanLoading(false);
                        }
                      }}
                      className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-sm font-bold transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      {caseScanLoading ? (
                        <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Scanning Wallets...</>
                      ) : (
                        <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg> Scan Case Wallets</>
                      )}
                    </button>
                  )}

                  {selectedCase && (
                    <button
                      data-testid="button-scan-tc-events"
                      disabled={tcEventLoading}
                      onClick={async () => {
                        setTcEventLoading(true);
                        setTcEventResult(null);
                        try {
                          const resp = await fetch("/api/forensic/privacy-tracker/scan-tc-events", {
                            method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
                            body: JSON.stringify({ caseId: selectedCase }),
                          });
                          const data = await resp.json();
                          if (!resp.ok) throw new Error(data.message || `Server error ${resp.status}`);
                          setTcEventResult(data);
                        } catch (e: any) {
                          setTcEventResult({ error: e.message });
                        } finally {
                          setTcEventLoading(false);
                        }
                      }}
                      className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-lg text-sm font-bold transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      {tcEventLoading ? (
                        <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Querying TC Contracts...</>
                      ) : (
                        <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg> TC Event Log Exploit</>
                      )}
                    </button>
                  )}

                  <div className="flex items-center gap-2 ml-auto">
                    <input
                      data-testid="input-address-lookup"
                      value={addressLookup}
                      onChange={e => setAddressLookup(e.target.value)}
                      placeholder="Check address (0x...)"
                      className="bg-[#0d1117] border border-gray-700 rounded px-3 py-1.5 text-xs text-white placeholder-gray-600 focus:border-red-500 focus:outline-none font-mono w-64"
                    />
                    <button
                      data-testid="button-check-address"
                      disabled={!addressLookup}
                      onClick={async () => {
                        try {
                          const resp = await fetch("/api/forensic/privacy-tracker/analyze-address", {
                            method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
                            body: JSON.stringify({ address: addressLookup }),
                          });
                          const data = await resp.json();
                          if (!resp.ok) throw new Error(data.message);
                          setAddressResult(data);
                        } catch (e: any) {
                          setAddressResult({ error: e.message });
                        }
                      }}
                      className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-white rounded text-xs disabled:opacity-50"
                    >Check</button>
                  </div>
                </div>

                {addressResult && !addressResult.error && (
                  <div className="mb-4 bg-[#0d1117] rounded-lg p-3 border border-gray-800/50">
                    <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Address Analysis: {addressLookup.slice(0,10)}...</div>
                    {addressResult.isTornadoContract && (
                      <div className="text-xs text-red-400 font-bold">TORNADO CASH CONTRACT — {addressResult.contractDetails?.chain} / {addressResult.contractDetails?.pool}</div>
                    )}
                    {addressResult.isKnownRelayer && (
                      <div className="text-xs text-orange-400 font-bold">KNOWN RELAYER — {addressResult.relayerDetails?.name} | Jurisdiction: {addressResult.relayerDetails?.jurisdiction} | Subpoenable: {addressResult.relayerDetails?.subpoenable ? 'YES' : 'NO'}</div>
                    )}
                    {addressResult.isMoneroOnRamp && (
                      <div className="text-xs text-cyan-400 font-bold">MONERO ON-RAMP SERVICE — {addressResult.onRampDetails?.name} | KYC: {addressResult.onRampDetails?.kyc ? 'YES' : 'NO'} | Jurisdiction: {addressResult.onRampDetails?.jurisdiction} | Logs: {addressResult.onRampDetails?.logs}</div>
                    )}
                    {!addressResult.isTornadoContract && !addressResult.isKnownRelayer && !addressResult.isMoneroOnRamp && (
                      <div className="text-xs text-gray-400">No match in known contract/relayer/on-ramp databases.</div>
                    )}
                  </div>
                )}

                {exploitScanResult && !exploitScanResult.error && (
                  <div className="space-y-4" data-testid="exploit-scan-results">
                    <div className="bg-[#0d1117] rounded-lg p-4 border border-red-800/30">
                      <div className="text-[10px] text-red-400 uppercase tracking-wider mb-2 font-bold">Executive Summary</div>
                      <div className="text-[10px] text-gray-300 whitespace-pre-line">{exploitScanResult.executiveSummary}</div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50 text-center">
                        <div className="text-2xl font-bold text-white">{exploitScanResult.totalExploits}</div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-wider">Total Exploits</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-red-800/30 text-center">
                        <div className="text-2xl font-bold text-red-400">{exploitScanResult.bySeverity?.CRITICAL || 0}</div>
                        <div className="text-[10px] text-red-500 uppercase tracking-wider">Critical</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-orange-800/30 text-center">
                        <div className="text-2xl font-bold text-orange-400">{exploitScanResult.bySeverity?.HIGH || 0}</div>
                        <div className="text-[10px] text-orange-500 uppercase tracking-wider">High</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-yellow-800/30 text-center">
                        <div className="text-2xl font-bold text-yellow-400">{(exploitScanResult.bySeverity?.MEDIUM || 0) + (exploitScanResult.bySeverity?.LOW || 0)}</div>
                        <div className="text-[10px] text-yellow-500 uppercase tracking-wider">Med/Low</div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-2">
                      {["all", "tornado_cash", "monero", "both"].map(f => (
                        <button key={f} data-testid={`button-filter-target-${f}`} onClick={() => setExploitFilter(f)}
                          className={`px-3 py-1 rounded text-[10px] uppercase tracking-wider font-bold transition-all ${exploitFilter === f ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                        >{f === 'all' ? 'All Targets' : f.replace('_', ' ')}</button>
                      ))}
                      <div className="border-l border-gray-700 mx-1" />
                      {["all", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map(f => (
                        <button key={f} data-testid={`button-filter-severity-${f}`} onClick={() => setExploitSeverityFilter(f)}
                          className={`px-3 py-1 rounded text-[10px] uppercase tracking-wider font-bold transition-all ${exploitSeverityFilter === f ? (f === 'CRITICAL' ? 'bg-red-600' : f === 'HIGH' ? 'bg-orange-600' : f === 'MEDIUM' ? 'bg-yellow-600' : f === 'LOW' ? 'bg-blue-600' : 'bg-gray-600') + ' text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                        >{f === 'all' ? 'All Severity' : f}</button>
                      ))}
                    </div>

                    <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                      {(exploitScanResult.exploits || [])
                        .filter((e: any) => exploitFilter === 'all' || e.target === exploitFilter)
                        .filter((e: any) => exploitSeverityFilter === 'all' || e.severity === exploitSeverityFilter)
                        .map((exploit: any) => {
                          const isExpanded = exploitExpandedId === exploit.id;
                          const sevColor = exploit.severity === 'CRITICAL' ? 'red' : exploit.severity === 'HIGH' ? 'orange' : exploit.severity === 'MEDIUM' ? 'yellow' : 'blue';
                          return (
                            <div key={exploit.id} className={`bg-[#0d1117] rounded-lg border border-${sevColor}-800/30 overflow-hidden`}>
                              <button
                                data-testid={`button-exploit-${exploit.id}`}
                                onClick={() => setExploitExpandedId(isExpanded ? null : exploit.id)}
                                className="w-full px-4 py-3 flex items-center gap-3 text-left hover:bg-gray-900/50 transition-all"
                              >
                                <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${exploit.severity === 'CRITICAL' ? 'bg-red-900/40 text-red-400' : exploit.severity === 'HIGH' ? 'bg-orange-900/40 text-orange-400' : exploit.severity === 'MEDIUM' ? 'bg-yellow-900/40 text-yellow-400' : 'bg-blue-900/40 text-blue-400'}`}>
                                  {exploit.severity}
                                </span>
                                <span className="text-[10px] text-gray-600 font-mono">{exploit.id}</span>
                                <span className="text-xs text-white font-medium flex-1">{exploit.name}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded ${exploit.target === 'tornado_cash' ? 'bg-purple-900/30 text-purple-400' : exploit.target === 'monero' ? 'bg-cyan-900/30 text-cyan-400' : 'bg-pink-900/30 text-pink-400'}`}>
                                  {exploit.target === 'tornado_cash' ? 'TC' : exploit.target === 'monero' ? 'XMR' : 'BOTH'}
                                </span>
                                <span className="text-[10px] text-gray-500 font-mono w-12 text-right">{exploit.successProbability}%</span>
                                <svg className={`w-3 h-3 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                              </button>
                              {isExpanded && (
                                <div className="px-4 pb-4 space-y-3 border-t border-gray-800/50">
                                  <div className="pt-3">
                                    <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Description</div>
                                    <div className="text-[10px] text-gray-300">{exploit.description}</div>
                                  </div>
                                  <div>
                                    <div className="text-[10px] text-cyan-400 uppercase tracking-wider mb-1 font-bold">Technical Detail</div>
                                    <div className="text-[10px] text-gray-300 bg-gray-900/50 rounded p-2 font-mono">{exploit.technicalDetail}</div>
                                  </div>
                                  <div>
                                    <div className="text-[10px] text-red-400 uppercase tracking-wider mb-1 font-bold">Exploit Method</div>
                                    <div className="text-[10px] text-gray-300">{exploit.exploitMethod}</div>
                                  </div>
                                  <div>
                                    <div className="text-[10px] text-green-400 uppercase tracking-wider mb-1 font-bold">Investigator Playbook</div>
                                    <div className="text-[10px] text-gray-300 bg-green-950/20 border border-green-800/20 rounded p-2">{exploit.investigatorPlaybook}</div>
                                  </div>
                                  <div className="grid grid-cols-2 gap-3">
                                    <div>
                                      <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-1 font-bold">Data Recoverable</div>
                                      {exploit.dataRecoverable?.map((d: string, i: number) => (
                                        <div key={i} className="text-[10px] text-gray-400 flex items-start gap-1"><span className="text-amber-500 mt-0.5">•</span> {d}</div>
                                      ))}
                                    </div>
                                    <div>
                                      <div className="text-[10px] text-purple-400 uppercase tracking-wider mb-1 font-bold">Tools Required</div>
                                      {exploit.toolsRequired?.map((t: string, i: number) => (
                                        <div key={i} className="text-[10px] text-gray-400 flex items-start gap-1"><span className="text-purple-500 mt-0.5">•</span> {t}</div>
                                      ))}
                                    </div>
                                  </div>
                                  <div className="grid grid-cols-2 gap-3">
                                    <div>
                                      <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Success Probability</div>
                                      <div className="flex items-center gap-2">
                                        <div className="flex-1 bg-gray-800 rounded-full h-1.5">
                                          <div className={`h-1.5 rounded-full ${exploit.successProbability >= 70 ? 'bg-green-500' : exploit.successProbability >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{ width: `${exploit.successProbability}%` }} />
                                        </div>
                                        <span className="text-[10px] text-white font-bold">{exploit.successProbability}%</span>
                                      </div>
                                    </div>
                                    <div>
                                      <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Legal Basis</div>
                                      <div className="text-[10px] text-gray-300">{exploit.legalBasis}</div>
                                    </div>
                                  </div>
                                  {exploit.realWorldPrecedent && (
                                    <div>
                                      <div className="text-[10px] text-orange-400 uppercase tracking-wider mb-1 font-bold">Real-World Precedent</div>
                                      <div className="text-[10px] text-gray-300 bg-orange-950/20 border border-orange-800/20 rounded p-2">{exploit.realWorldPrecedent}</div>
                                    </div>
                                  )}
                                  {exploit.mitigationByAttacker && (
                                    <div className="grid grid-cols-2 gap-3">
                                      <div>
                                        <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Attacker Mitigation</div>
                                        <div className="text-[10px] text-gray-400">{exploit.mitigationByAttacker}</div>
                                      </div>
                                      {exploit.counterMitigation && (
                                        <div>
                                          <div className="text-[10px] text-red-400 uppercase tracking-wider mb-1 font-bold">Counter-Mitigation</div>
                                          <div className="text-[10px] text-gray-300">{exploit.counterMitigation}</div>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                    </div>

                    {exploitScanResult.highValueTargets && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-green-800/30">
                        <div className="text-[10px] text-green-400 uppercase tracking-wider mb-2 font-bold">High-Value Targets ({`>=`}60% Success Rate)</div>
                        {exploitScanResult.highValueTargets.map((t: string, i: number) => (
                          <div key={i} className="text-[10px] text-gray-300 mb-1 flex items-start gap-1"><span className="text-green-500 mt-0.5">&#9654;</span> {t}</div>
                        ))}
                      </div>
                    )}

                    {exploitScanResult.attackSurface && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-cyan-800/30">
                        <div className="text-[10px] text-cyan-400 uppercase tracking-wider mb-2 font-bold">Attack Surface Map</div>
                        {exploitScanResult.attackSurface.map((s: string, i: number) => (
                          <div key={i} className="text-[10px] text-gray-300 mb-1">&#8226; {s}</div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {exploitScanResult?.error && (
                  <div className="text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{exploitScanResult.error}</div>
                )}

                {caseScanResult && !caseScanResult.error && (
                  <div className="mt-6 space-y-4" data-testid="case-scan-results">
                    <div className="bg-[#0d1117] rounded-lg p-4 border border-cyan-800/30">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-bold text-cyan-400" style={{ fontFamily: "'Orbitron', sans-serif" }}>Case Wallet Exploit Scan Results</div>
                          <div className="text-[10px] text-gray-500 mt-1">Case: {caseScanResult.caseName} | Scan ID: {caseScanResult.scanId}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-[10px] text-gray-500">Duration: {(caseScanResult.scanDuration / 1000).toFixed(1)}s</div>
                          <div className="text-[10px] text-gray-500">{new Date(caseScanResult.timestamp).toLocaleString()}</div>
                        </div>
                      </div>
                      <div className={`text-xs font-bold px-3 py-1.5 rounded inline-block ${caseScanResult.overallRiskAssessment?.startsWith('CRITICAL') ? 'bg-red-900/30 text-red-400 border border-red-800/30' : caseScanResult.overallRiskAssessment?.startsWith('HIGH') ? 'bg-orange-900/30 text-orange-400 border border-orange-800/30' : 'bg-green-900/30 text-green-400 border border-green-800/30'}`}>
                        {caseScanResult.overallRiskAssessment}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50 text-center">
                        <div className="text-xl font-bold text-white">{caseScanResult.walletsScanned}</div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-wider">Scanned</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-cyan-800/30 text-center">
                        <div className="text-xl font-bold text-cyan-400">{caseScanResult.walletsWithFindings}</div>
                        <div className="text-[10px] text-cyan-500 uppercase tracking-wider">With Findings</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-red-800/30 text-center">
                        <div className="text-xl font-bold text-red-400">{caseScanResult.totalTornadoInteractions}</div>
                        <div className="text-[10px] text-red-500 uppercase tracking-wider">TC Interactions</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-orange-800/30 text-center">
                        <div className="text-xl font-bold text-orange-400">{caseScanResult.totalRelayerInteractions}</div>
                        <div className="text-[10px] text-orange-500 uppercase tracking-wider">Relayer</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-green-800/30 text-center">
                        <div className="text-xl font-bold text-green-400">{caseScanResult.totalExchangeInteractions}</div>
                        <div className="text-[10px] text-green-500 uppercase tracking-wider">Exchange</div>
                      </div>
                    </div>

                    {caseScanResult.keyFindings?.length > 0 && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-red-800/30">
                        <div className="text-[10px] text-red-400 uppercase tracking-wider mb-2 font-bold">Key Findings</div>
                        {caseScanResult.keyFindings.map((f: string, i: number) => (
                          <div key={i} className={`text-[10px] mb-1 ${f.startsWith('CRITICAL') ? 'text-red-400 font-bold' : f.startsWith('ACTIONABLE') ? 'text-orange-400 font-bold' : 'text-gray-300'}`}>&#9654; {f}</div>
                        ))}
                      </div>
                    )}

                    {caseScanResult.priorityActions?.length > 0 && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-amber-800/30">
                        <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-2 font-bold">Priority Investigator Actions</div>
                        {caseScanResult.priorityActions.map((a: string, i: number) => (
                          <div key={i} className={`text-[10px] mb-1 ${a.startsWith('PRIORITY') || a.startsWith('SUBPOENA') ? 'text-red-400 font-bold' : 'text-gray-300'}`}>&#8226; {a}</div>
                        ))}
                      </div>
                    )}

                    <div className="text-[10px] text-gray-500 uppercase tracking-wider font-bold mt-2">Wallet-by-Wallet Results ({caseScanResult.walletResults?.length || 0})</div>
                    <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                      {(caseScanResult.walletResults || []).map((wr: any) => {
                        const isExpanded = caseScanExpandedWallet === wr.walletId;
                        const hasFindings = wr.tornadoCashInteractions?.found || wr.relayerInteractions?.found || wr.exchangeInteractions?.found;
                        return (
                          <div key={wr.walletId} className={`bg-[#0d1117] rounded-lg border ${hasFindings ? 'border-red-800/30' : 'border-gray-800/30'} overflow-hidden`}>
                            <button
                              data-testid={`button-wallet-result-${wr.address?.slice(0,8)}`}
                              onClick={() => setCaseScanExpandedWallet(isExpanded ? null : wr.walletId)}
                              className="w-full px-4 py-2.5 flex items-center gap-3 text-left hover:bg-gray-900/50 transition-all"
                            >
                              <div className={`w-2 h-2 rounded-full ${wr.privacyRiskScore > 50 ? 'bg-red-500' : wr.privacyRiskScore > 0 ? 'bg-yellow-500' : hasFindings ? 'bg-green-500' : 'bg-gray-600'}`} />
                              <div className="flex-1 min-w-0">
                                <div className="text-xs font-mono text-cyan-400 truncate">{wr.address}</div>
                                <div className="text-[10px] text-gray-500">{wr.label || wr.role} | {wr.chain}</div>
                              </div>
                              {wr.scanStatus === 'api_error' && <span className="text-[10px] px-2 py-0.5 rounded bg-yellow-900/40 text-yellow-400 font-bold">API ERR</span>}
                              {wr.scanStatus === 'unsupported_chain' && <span className="text-[10px] px-2 py-0.5 rounded bg-gray-800/40 text-gray-400 font-bold">UNSUPPORTED</span>}
                              {wr.scanStatus === 'partial' && <span className="text-[10px] px-2 py-0.5 rounded bg-yellow-900/40 text-yellow-300 font-bold">PARTIAL</span>}
                              {wr.tornadoCashInteractions?.found && <span className="text-[10px] px-2 py-0.5 rounded bg-red-900/40 text-red-400 font-bold">TC</span>}
                              {wr.relayerInteractions?.found && <span className="text-[10px] px-2 py-0.5 rounded bg-orange-900/40 text-orange-400 font-bold">RELAY</span>}
                              {wr.exchangeInteractions?.found && <span className="text-[10px] px-2 py-0.5 rounded bg-green-900/40 text-green-400 font-bold">EXCH</span>}
                              {wr.privacyRiskScore > 0 && <span className="text-[10px] text-gray-500 font-mono">Risk: {wr.privacyRiskScore}%</span>}
                              <svg className={`w-3 h-3 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                            </button>
                            {isExpanded && (
                              <div className="px-4 pb-4 space-y-3 border-t border-gray-800/50 pt-3">
                                {wr.exploitableFindings?.map((f: string, i: number) => (
                                  <div key={i} className={`text-[10px] ${f.startsWith('CRITICAL') ? 'text-red-400 font-bold' : f.startsWith('ACTIONABLE') ? 'text-orange-400 font-bold' : f.startsWith('HIGH') ? 'text-yellow-400' : f.startsWith('INTEL') ? 'text-cyan-400' : f.startsWith('CLEAN') ? 'text-green-400' : 'text-gray-300'}`}>
                                    {f}
                                  </div>
                                ))}

                                {wr.tornadoCashInteractions?.deposits?.length > 0 && (
                                  <div className="bg-red-950/20 rounded p-2 border border-red-800/20">
                                    <div className="text-[10px] text-red-400 uppercase tracking-wider mb-1 font-bold">Tornado Cash Deposits ({wr.tornadoCashInteractions.deposits.length})</div>
                                    {wr.tornadoCashInteractions.deposits.map((d: any, i: number) => (
                                      <div key={i} className="text-[10px] text-gray-300 font-mono">Pool: {d.pool} | Amount: {d.amount} | Tx: {d.txHash?.slice(0,14)}... | {d.timestamp ? new Date(d.timestamp).toLocaleString() : ''}</div>
                                    ))}
                                  </div>
                                )}

                                {wr.tornadoCashInteractions?.withdrawals?.length > 0 && (
                                  <div className="bg-purple-950/20 rounded p-2 border border-purple-800/20">
                                    <div className="text-[10px] text-purple-400 uppercase tracking-wider mb-1 font-bold">Tornado Cash Withdrawals ({wr.tornadoCashInteractions.withdrawals.length})</div>
                                    {wr.tornadoCashInteractions.withdrawals.map((w: any, i: number) => (
                                      <div key={i} className="text-[10px] text-gray-300 font-mono">Pool: {w.pool} | Amount: {w.amount} | Tx: {w.txHash?.slice(0,14)}... | {w.timestamp ? new Date(w.timestamp).toLocaleString() : ''}</div>
                                    ))}
                                  </div>
                                )}

                                {wr.exchangeInteractions?.exchanges?.length > 0 && (
                                  <div className="bg-green-950/20 rounded p-2 border border-green-800/20">
                                    <div className="text-[10px] text-green-400 uppercase tracking-wider mb-1 font-bold">Exchange Interactions ({wr.exchangeInteractions.exchanges.length})</div>
                                    {wr.exchangeInteractions.exchanges.map((e: any, i: number) => (
                                      <div key={i} className="text-[10px] text-gray-300 font-mono">{e.name} | {e.direction.replace(/_/g, ' ')} | {e.amount} | Tx: {e.txHash?.slice(0,14)}... | {e.timestamp ? new Date(e.timestamp).toLocaleString() : ''}</div>
                                    ))}
                                  </div>
                                )}

                                {wr.investigatorActions?.length > 0 && (
                                  <div>
                                    <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-1 font-bold">Investigator Actions</div>
                                    {wr.investigatorActions.map((a: string, i: number) => (
                                      <div key={i} className="text-[10px] text-gray-300">&#8226; {a}</div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {caseScanResult?.error && (
                  <div className="mt-4 text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{caseScanResult.error}</div>
                )}

                {tcEventResult && !tcEventResult.error && (
                  <div className="mt-6 space-y-4" data-testid="tc-event-results">
                    <div className="bg-[#0d1117] rounded-lg p-4 border border-purple-800/30">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-bold text-purple-400" style={{ fontFamily: "'Orbitron', sans-serif" }}>Tornado Cash Event Log Exploit Results</div>
                          <div className="text-[10px] text-gray-500 mt-1">Case: {tcEventResult.caseName} | Scan ID: {tcEventResult.scanId} | Queried real TC smart contract event logs via Blockscout API</div>
                        </div>
                        <div className="text-right">
                          <div className="text-[10px] text-gray-500">Duration: {(tcEventResult.scanDuration / 1000).toFixed(1)}s</div>
                          <div className="text-[10px] text-gray-500">{new Date(tcEventResult.timestamp).toLocaleString()}</div>
                        </div>
                      </div>
                      {tcEventResult.matchedWithdrawals > 0 && (
                        <div className="text-xs font-bold px-3 py-1.5 rounded inline-block bg-red-900/30 text-red-400 border border-red-800/30 animate-pulse">
                          MATCH FOUND — {tcEventResult.matchedWithdrawals} case wallet(s) received Tornado Cash withdrawals
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-gray-800/50 text-center">
                        <div className="text-xl font-bold text-white">{tcEventResult.poolsScanned}</div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-wider">Pools Scanned</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-purple-800/30 text-center">
                        <div className="text-xl font-bold text-purple-400">{tcEventResult.totalDepositsAnalyzed}</div>
                        <div className="text-[10px] text-purple-500 uppercase tracking-wider">Deposits</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-pink-800/30 text-center">
                        <div className="text-xl font-bold text-pink-400">{tcEventResult.totalWithdrawalsAnalyzed}</div>
                        <div className="text-[10px] text-pink-500 uppercase tracking-wider">Withdrawals</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-red-800/30 text-center">
                        <div className={`text-xl font-bold ${tcEventResult.matchedWithdrawals > 0 ? 'text-red-400 animate-pulse' : 'text-gray-500'}`}>{tcEventResult.matchedWithdrawals}</div>
                        <div className="text-[10px] text-red-500 uppercase tracking-wider">Wallet Matches</div>
                      </div>
                      <div className="bg-[#0d1117] rounded-lg p-3 border border-orange-800/30 text-center">
                        <div className="text-xl font-bold text-orange-400">{tcEventResult.relayerIntelligence?.length || 0}</div>
                        <div className="text-[10px] text-orange-500 uppercase tracking-wider">Relayers Found</div>
                      </div>
                    </div>

                    {tcEventResult.exploitFindings?.length > 0 && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-purple-800/30">
                        <div className="text-[10px] text-purple-400 uppercase tracking-wider mb-2 font-bold">Exploit Findings</div>
                        {tcEventResult.exploitFindings.map((f: string, i: number) => (
                          <div key={i} className={`text-[10px] mb-1 ${f.startsWith('CRITICAL') ? 'text-red-400 font-bold' : f.startsWith('HIGH') ? 'text-orange-400 font-bold' : f.startsWith('INTEL') ? 'text-cyan-400' : 'text-gray-300'}`}>&#9654; {f}</div>
                        ))}
                      </div>
                    )}

                    {tcEventResult.investigatorActions?.length > 0 && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-amber-800/30">
                        <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-2 font-bold">Investigator Actions</div>
                        {tcEventResult.investigatorActions.map((a: string, i: number) => (
                          <div key={i} className={`text-[10px] mb-1 ${a.startsWith('SUBPOENA') ? 'text-red-400 font-bold' : a.startsWith('TOP RELAYER') || a.startsWith('MERKLE') || a.startsWith('NULLIFIER') ? 'text-orange-400 font-bold' : 'text-gray-300'}`}>&#8226; {a}</div>
                        ))}
                      </div>
                    )}

                    {tcEventResult.relayerIntelligence?.length > 0 && (
                      <div className="bg-[#0d1117] rounded-lg p-4 border border-orange-800/30">
                        <div className="text-[10px] text-orange-400 uppercase tracking-wider mb-2 font-bold">Relayer Intelligence ({tcEventResult.relayerIntelligence.length})</div>
                        <div className="space-y-1">
                          {tcEventResult.relayerIntelligence.map((r: any, i: number) => (
                            <div key={i} className="flex items-center gap-3 text-[10px]">
                              <span className="font-mono text-orange-300">{r.address.slice(0, 14)}...{r.address.slice(-6)}</span>
                              <span className="text-gray-400">|</span>
                              <span className="text-white font-bold">{r.withdrawalCount} withdrawals</span>
                              <span className="text-gray-400">|</span>
                              <span className="text-gray-300">Pools: {r.poolsUsed.join(', ')}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="text-[10px] text-gray-500 uppercase tracking-wider font-bold mt-2">Pool-by-Pool Event Analysis ({tcEventResult.poolResults?.length || 0})</div>
                    <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                      {(tcEventResult.poolResults || []).map((pr: any) => {
                        const isExpanded = tcEventExpandedPool === pr.poolAddress;
                        const hasMatch = pr.matchedWalletWithdrawals > 0;
                        return (
                          <div key={pr.poolAddress} className={`bg-[#0d1117] rounded-lg border ${hasMatch ? 'border-red-800/30' : 'border-gray-800/30'} overflow-hidden`}>
                            <button
                              data-testid={`button-tc-pool-${pr.pool?.replace(/\s/g,'-')}`}
                              onClick={() => setTcEventExpandedPool(isExpanded ? null : pr.poolAddress)}
                              className="w-full px-4 py-2.5 flex items-center gap-3 text-left hover:bg-gray-900/50 transition-all"
                            >
                              <div className={`w-2 h-2 rounded-full ${hasMatch ? 'bg-red-500 animate-pulse' : pr.recentWithdrawals?.length > 0 ? 'bg-purple-500' : 'bg-gray-600'}`} />
                              <div className="flex-1">
                                <div className="text-xs font-bold text-purple-400">{pr.pool}</div>
                                <div className="text-[10px] text-gray-500 font-mono">{pr.poolAddress.slice(0,14)}... | {pr.chain}</div>
                              </div>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-900/30 text-purple-300">{pr.recentDeposits?.length || 0} dep</span>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-pink-900/30 text-pink-300">{pr.recentWithdrawals?.length || 0} wd</span>
                              {hasMatch && <span className="text-[10px] px-2 py-0.5 rounded bg-red-900/40 text-red-400 font-bold animate-pulse">{pr.matchedWalletWithdrawals} MATCH</span>}
                              <svg className={`w-3 h-3 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                            </button>
                            {isExpanded && (
                              <div className="px-4 pb-4 space-y-3 border-t border-gray-800/50 pt-3">
                                {pr.timingPatterns?.length > 0 && (
                                  <div className="bg-amber-950/20 rounded p-2 border border-amber-800/20">
                                    <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-1 font-bold">Timing Patterns</div>
                                    {pr.timingPatterns.map((tp: any, i: number) => (
                                      <div key={i} className="text-[10px] text-gray-300"><span className="text-amber-400 font-bold">[{tp.confidence}]</span> {tp.type}: {tp.detail}</div>
                                    ))}
                                  </div>
                                )}

                                {pr.recentWithdrawals?.filter((w: any) => w.matchedCaseWallet).length > 0 && (
                                  <div className="bg-red-950/20 rounded p-2 border border-red-800/20">
                                    <div className="text-[10px] text-red-400 uppercase tracking-wider mb-1 font-bold">MATCHED CASE WALLET WITHDRAWALS</div>
                                    {pr.recentWithdrawals.filter((w: any) => w.matchedCaseWallet).map((w: any, i: number) => (
                                      <div key={i} className="text-[10px] text-red-300 font-mono mb-1">
                                        Recipient: <span className="text-white font-bold">{w.walletLabel}</span> ({w.recipientAddress.slice(0,14)}...)
                                        {w.relayerAddress !== '0x0000000000000000000000000000000000000000' && <> | Relayer: {w.relayerAddress.slice(0,14)}...</>}
                                        | Nullifier: {w.nullifierHash.slice(0,18)}...
                                        | Fee: {w.fee} ETH
                                        | Block: {w.blockNumber}
                                      </div>
                                    ))}
                                  </div>
                                )}

                                {pr.uniqueRelayers?.length > 0 && (
                                  <div className="text-[10px] text-orange-400">Relayers active in pool: {pr.uniqueRelayers.map((r: string) => r.slice(0,12)+'...').join(', ')}</div>
                                )}

                                <div className="grid grid-cols-2 gap-3">
                                  <div>
                                    <div className="text-[10px] text-purple-400 uppercase tracking-wider mb-1 font-bold">Recent Deposits ({pr.recentDeposits?.length || 0})</div>
                                    <div className="max-h-32 overflow-y-auto space-y-0.5">
                                      {(pr.recentDeposits || []).slice(0, 20).map((d: any, i: number) => (
                                        <div key={i} className="text-[9px] text-gray-400 font-mono">
                                          Leaf #{d.leafIndex} | {d.timestamp ? new Date(d.timestamp).toLocaleString() : `Block ${d.blockNumber}`} | {d.commitment?.slice(0,14)}...
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <div className="text-[10px] text-pink-400 uppercase tracking-wider mb-1 font-bold">Recent Withdrawals ({pr.recentWithdrawals?.length || 0})</div>
                                    <div className="max-h-32 overflow-y-auto space-y-0.5">
                                      {(pr.recentWithdrawals || []).slice(0, 20).map((w: any, i: number) => (
                                        <div key={i} className={`text-[9px] font-mono ${w.matchedCaseWallet ? 'text-red-400 font-bold' : 'text-gray-400'}`}>
                                          To: {w.recipientAddress.slice(0,12)}... | Null: {w.nullifierHash?.slice(0,12)}... | Fee: {w.fee}
                                          {w.matchedCaseWallet && ' ★ CASE WALLET'}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {tcEventResult?.error && (
                  <div className="mt-4 text-red-400 text-xs bg-red-900/20 border border-red-800/30 rounded p-3">{tcEventResult.error}</div>
                )}
              </div>

              <div className="mt-6 bg-[#161b22] rounded-xl border border-green-800/30 p-5">
                <h3 className="text-sm font-bold text-green-400 uppercase tracking-wider mb-4 flex items-center gap-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z" /></svg>
                  Active Monitoring Dashboard
                </h3>
                <div className="text-xs text-gray-400 mb-4">Real-time tracking status of privacy protocol interactions from watched wallets.</div>
                {wallets && wallets.length > 0 ? (
                  <div className="space-y-2" data-testid="privacy-monitoring-list">
                    {wallets.slice(0, 20).map((w) => {
                      const hasPrivacyInteraction = w.label?.toLowerCase().includes('tornado') || w.label?.toLowerCase().includes('privacy') || w.role?.toLowerCase().includes('mixer') || w.role?.toLowerCase().includes('privacy');
                      return (
                        <div key={w.id} className={`bg-[#0d1117] rounded-lg p-3 border ${hasPrivacyInteraction ? 'border-red-800/50' : 'border-gray-800/50'} flex items-center justify-between`}>
                          <div className="flex items-center gap-3">
                            <div className={`w-2 h-2 rounded-full ${w.status === 'monitoring' ? 'bg-green-500 animate-pulse' : 'bg-gray-600'}`} />
                            <div>
                              <div className="text-xs font-mono text-cyan-400">{shortenAddr(w.address)}</div>
                              <div className="text-[10px] text-gray-500">{w.chain} {w.label ? `• ${w.label}` : ''}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {hasPrivacyInteraction && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-red-900/30 border border-red-700/30 text-red-400 font-bold animate-pulse">PRIVACY PROTOCOL</span>
                            )}
                            <div className="text-right">
                              <div className="text-xs text-gray-300">{w.lastKnownBalanceUsd ? formatUsd(w.lastKnownBalanceUsd) : '—'}</div>
                              <div className="text-[10px] text-gray-500">Last: {timeAgo(w.lastChecked)}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500 text-sm">
                    <p>No wallets being monitored.</p>
                    <p className="text-[10px] mt-1">Add wallets to a case and they will appear here with privacy protocol tracking status.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "intelligence" && (
            <motion.div key="intelligence" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <IntelligenceSuiteTab selectedCase={selectedCase} wallets={wallets} />
            </motion.div>
          )}

          {activeTab === "dossier" && (
            <motion.div key="dossier" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {!selectedCase && (
                <div className="bg-[#161b22] rounded-xl border border-yellow-900/30 p-6 text-center">
                  <div className="text-yellow-400 text-lg mb-2">Select a Case First</div>
                  <div className="text-gray-500 text-sm">Use the case dropdown at the top to select a case to generate the Recovery Dossier.</div>
                </div>
              )}
              {selectedCase && (() => {
                const caseData = cases?.find((c: any) => c.id === selectedCase);
                const { flowNodes, flowEdges } = buildCaseFlowData(wallets || [], caseData);
                const coreWallets = (wallets || []).filter((w: any) => !["token_recipient"].includes(w.role));
                const dossierWallets = coreWallets.map((w: any) => ({
                  address: w.address,
                  label: w.label || w.role,
                  role: w.role,
                  chain: w.chain || "ethereum",
                  amount: w.last_known_balance_eth ? `${parseFloat(w.last_known_balance_eth).toFixed(4)}` : undefined,
                  token: w.last_known_balance_eth ? "ETH" : undefined,
                }));
                const exchangeTargets = buildDossierExchangeTargets();
                return (
                  <RecoveryDossier
                    caseName={caseData?.caseName || caseData?.case_name || "Investigation"}
                    caseId={selectedCase}
                    victimHandle={caseData?.victimHandle || caseData?.victim_handle || "@unknown"}
                    victimAddress={caseData?.victimAddress || caseData?.victim_address || "0x..."}
                    totalStolen={caseData?.totalStolenUsd ? `$${parseFloat(caseData.totalStolenUsd || caseData.total_stolen_usd || "0").toLocaleString()}` : "~$24,000,000"}
                    totalStolenUSD={caseData?.totalStolenUsd || caseData?.total_stolen_usd ? `$${parseFloat(caseData.totalStolenUsd || caseData.total_stolen_usd || "0").toLocaleString()}` : "~$24,000,000"}
                    theftDate="2025-12-01"
                    blockchain="ETH (Ethereum) + Arbitrum"
                    description={caseData?.description || "EIP-7702 delegation exploit targeting victim wallet. Stolen funds dispersed through laundering hub, split wallets, DAI conversion, and deposited into multiple centralized exchanges."}
                    wallets={dossierWallets}
                    exchangeTargets={exchangeTargets}
                    flowNodes={flowNodes}
                    flowEdges={flowEdges}
                    scanSummary={{
                      walletsScanned: 100,
                      walletsWithFindings: 22,
                      tornadoCashInteractions: 0,
                      exchangeInteractions: 22,
                      relayerInteractions: 0,
                      riskAssessment: "HIGH — Multiple exchange interactions detected, no privacy protocol usage",
                      poolsScanned: 17,
                      depositsAnalyzed: 982,
                      withdrawalsAnalyzed: 1126,
                    }}
                  />
                );
              })()}
            </motion.div>
          )}

          {activeTab === "cases" && (
            <motion.div key="cases" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-cyan-400">Forensic Cases ({cases?.length || 0})</h2>
                <button
                  data-testid="button-new-case"
                  onClick={() => setShowNewCaseForm(!showNewCaseForm)}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-sm font-medium"
                >
                  {showNewCaseForm ? "Cancel" : "+ New Case"}
                </button>
              </div>

              {showNewCaseForm && (
                <div className="bg-[#161b22] rounded-xl border border-cyan-900/40 p-5 mb-4">
                  <h3 className="text-sm font-bold text-cyan-400 mb-4">CREATE NEW FORENSIC CASE</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Case Name *</label>
                      <input
                        data-testid="input-case-name"
                        placeholder="e.g. Victim Twitter Hack Recovery"
                        value={newCase.caseName}
                        onChange={e => setNewCase(p => ({ ...p, caseName: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Victim Handle (Twitter/Discord/etc)</label>
                      <input
                        data-testid="input-victim-handle"
                        placeholder="e.g. @username"
                        value={newCase.victimHandle}
                        onChange={e => setNewCase(p => ({ ...p, victimHandle: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Victim Wallet Address</label>
                      <input
                        data-testid="input-victim-address"
                        placeholder="0x... (the wallet that was drained)"
                        value={newCase.victimAddress}
                        onChange={e => setNewCase(p => ({ ...p, victimAddress: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Estimated Total Stolen (USD)</label>
                      <input
                        data-testid="input-stolen-amount"
                        placeholder="e.g. 500000"
                        type="number"
                        value={newCase.totalStolenUsd}
                        onChange={e => setNewCase(p => ({ ...p, totalStolenUsd: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Blockchain(s)</label>
                      <select
                        data-testid="select-case-chains"
                        value={newCase.chains}
                        onChange={e => setNewCase(p => ({ ...p, chains: e.target.value }))}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200"
                      >
                        <option value="ethereum">Ethereum</option>
                        <option value="ethereum,arbitrum">Ethereum + Arbitrum</option>
                        <option value="ethereum,polygon">Ethereum + Polygon</option>
                        <option value="ethereum,bsc">Ethereum + BSC</option>
                        <option value="ethereum,optimism">Ethereum + Optimism</option>
                        <option value="ethereum,base">Ethereum + Base</option>
                        <option value="ethereum,arbitrum,optimism,base">Ethereum + L2s</option>
                        <option value="ethereum,arbitrum,polygon,bsc,optimism,base,avalanche,fantom,gnosis,linea,scroll,zksync,blast,mantle,cronos,celo,moonbeam">All EVM Chains</option>
                        <option value="ethereum,arbitrum,polygon,bsc,optimism,base,avalanche,fantom,gnosis,linea,scroll,zksync,blast,mantle,cronos,celo,moonbeam,bitcoin,solana,tron">All Chains (EVM + Non-EVM)</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-xs text-gray-500 mb-1 block">Description / Notes</label>
                      <textarea
                        data-testid="input-case-description"
                        placeholder="Describe the incident — what happened, when, how the funds were taken..."
                        value={newCase.description}
                        onChange={e => setNewCase(p => ({ ...p, description: e.target.value }))}
                        rows={3}
                        className="w-full px-3 py-2 bg-[#0d1117] border border-gray-700 rounded text-sm text-gray-200 focus:border-cyan-500 outline-none resize-y"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          data-testid="checkbox-auto-trace"
                          checked={autoTraceOnCreate}
                          onChange={e => setAutoTraceOnCreate(e.target.checked)}
                          className="w-4 h-4 rounded border-gray-600 bg-gray-800 text-cyan-500 focus:ring-cyan-500"
                        />
                        <span className="text-xs text-cyan-400 font-medium">Auto-launch Spider Trace on victim wallet</span>
                      </label>
                      <div className="text-xs text-gray-600">Automatically traces where stolen funds went</div>
                    </div>
                    <button
                      data-testid="button-create-case"
                      onClick={() => {
                        if (newCase.caseName) {
                          createCaseMutation.mutate({
                            caseName: newCase.caseName,
                            victimAddress: newCase.victimAddress || null,
                            victimHandle: newCase.victimHandle || null,
                            description: newCase.description || null,
                            totalStolenUsd: newCase.totalStolenUsd ? parseFloat(newCase.totalStolenUsd) : null,
                            chains: newCase.chains.split(","),
                          });
                        }
                      }}
                      disabled={!newCase.caseName || createCaseMutation.isPending}
                      className="px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-700 disabled:to-gray-700 text-white rounded-lg text-sm font-medium"
                    >
                      {createCaseMutation.isPending ? "Creating..." : "Create Case"}
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {cases?.map(c => {
                  const caseWallets = wallets?.filter(w => w.caseId === c.id) || [];
                  const caseAlerts = alerts?.filter(a => a.caseId === c.id) || [];
                  const unack = caseAlerts.filter(a => !a.acknowledged).length;
                  return (
                    <div key={c.id} className={`bg-[#161b22] rounded-xl border p-5 transition-colors ${selectedCase === c.id ? "border-cyan-700/50" : "border-gray-800/50"}`} data-testid={`case-detail-${c.id}`}>
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-bold text-gray-200">{c.caseName}</h3>
                          {c.victimHandle && <span className="text-sm text-gray-500">{c.victimHandle}</span>}
                        </div>
                        <div className="flex items-center gap-2">
                          {c.victimAddress && (
                            <button
                              data-testid={`button-trace-case-${c.id}`}
                              onClick={() => {
                                setSelectedCase(c.id);
                                setSpiderConfig(p => ({ ...p, address: c.victimAddress! }));
                                setActiveTab("spider");
                              }}
                              className="px-3 py-1 rounded text-xs font-medium bg-purple-600/20 border border-purple-600/30 text-purple-400 hover:bg-purple-600/30 transition-colors"
                            >
                              Spider Trace
                            </button>
                          )}
                          <button
                            data-testid={`button-select-case-${c.id}`}
                            onClick={() => setSelectedCase(selectedCase === c.id ? null : c.id)}
                            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                              selectedCase === c.id
                                ? "bg-cyan-600/20 border border-cyan-600/30 text-cyan-400"
                                : "bg-gray-800/50 border border-gray-700/30 text-gray-400 hover:text-gray-200"
                            }`}
                          >
                            {selectedCase === c.id ? "Selected" : "Select"}
                          </button>
                          <StatusBadge status={c.status} />
                        </div>
                      </div>
                      {c.description && <div className="text-sm text-gray-400 mb-3">{c.description}</div>}
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                        <div className="bg-[#0d1117] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Stolen</div>
                          <div className="text-lg font-bold text-red-400">{formatUsd(c.totalStolenUsd)}</div>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Recovered</div>
                          <div className="text-lg font-bold text-green-400">{formatUsd(c.totalRecoveredUsd)}</div>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Wallets Tracked</div>
                          <div className="text-lg font-bold text-cyan-400">{caseWallets.length}</div>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Alerts</div>
                          <div className="text-lg font-bold text-yellow-400">{caseAlerts.length}</div>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-3">
                          <div className="text-xs text-gray-500">Unacknowledged</div>
                          <div className={`text-lg font-bold ${unack > 0 ? "text-red-400" : "text-gray-600"}`}>{unack}</div>
                        </div>
                      </div>
                      {c.victimAddress && (
                        <div className="mt-2 text-xs text-gray-500">
                          Victim: <span className="font-mono text-cyan-500">{c.victimAddress}</span>
                        </div>
                      )}
                      {c.chains && (
                        <div className="mt-1 flex gap-1">
                          {c.chains.map(ch => (
                            <span key={ch} className="text-[10px] px-1.5 py-0.5 bg-gray-800 rounded text-gray-400">{ch}</span>
                          ))}
                        </div>
                      )}
                      <div className="mt-2 text-xs text-gray-600">
                        Created: {new Date(c.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  );
                })}
                {(!cases || cases.length === 0) && (
                  <div className="bg-[#161b22] rounded-xl border border-gray-800/30 p-8 text-center">
                    <div className="text-gray-500 text-lg mb-2">No cases yet</div>
                    <div className="text-gray-600 text-sm">Click "+ New Case" to start tracking a victim's stolen funds.</div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {showSendReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={() => setShowSendReport(false)}>
          <div className="bg-[#0d1117] border border-amber-600/40 rounded-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()} data-testid="modal-send-report">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-amber-400 flex items-center gap-2">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                Send Forensic Report to Victim
              </h3>
              <button onClick={() => setShowSendReport(false)} className="text-gray-500 hover:text-white text-xl" data-testid="button-close-send-report">&times;</button>
            </div>

            {reportEmailInfo?.preferredFrom && (
              <div className="mb-3 text-xs bg-gray-800/50 border border-gray-700/30 rounded p-2">
                <span className="text-gray-400">Sending from: </span>
                <span className="text-cyan-400 font-mono">{reportEmailInfo.preferredFrom}</span>
              </div>
            )}

            {!reportDataSummary && selectedCase && (
              <div className="mb-4 bg-[#161b22] border border-gray-800/30 rounded-xl p-4 text-center">
                <div className="text-xs text-gray-500">Loading intelligence data summary...</div>
              </div>
            )}
            {reportDataSummary && selectedCase && (
              <div className="mb-4 bg-[#161b22] border border-amber-900/30 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-sm font-bold text-amber-400">Intelligence Data Available</h4>
                    <div className="text-[10px] text-gray-600">Case: {reportDataSummary.caseName} — Last checked: {new Date(reportDataSummary.lastUpdated).toLocaleString()}</div>
                  </div>
                  <button
                    data-testid="button-refresh-intel"
                    disabled={refreshingIntel}
                    onClick={async () => {
                      setRefreshingIntel(true);
                      setRefreshIntelResult(null);
                      try {
                        const resp = await fetch("/api/forensic/command-center/rescan-all", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          credentials: "include",
                          body: JSON.stringify({ caseId: selectedCase }),
                        });
                        const data = await resp.json();
                        if (resp.ok) {
                          setRefreshIntelResult({ ok: true, msg: `Scans launched: ${data.launched?.join(", ") || "all"} — refreshing data...` });
                          setTimeout(async () => {
                            try {
                              const r2 = await fetch(`/api/forensic/command-center/report-data-summary?caseId=${selectedCase}`, { credentials: "include" });
                              const d2 = await r2.json();
                              setReportDataSummary(d2);
                            } catch {}
                          }, 8000);
                          setTimeout(async () => {
                            try {
                              const r3 = await fetch(`/api/forensic/command-center/report-data-summary?caseId=${selectedCase}`, { credentials: "include" });
                              const d3 = await r3.json();
                              setReportDataSummary(d3);
                            } catch {}
                            setRefreshingIntel(false);
                          }, 20000);
                        } else {
                          setRefreshIntelResult({ ok: false, msg: data.message || "Failed to refresh" });
                          setRefreshingIntel(false);
                        }
                      } catch (e: any) {
                        setRefreshIntelResult({ ok: false, msg: e.message });
                        setRefreshingIntel(false);
                      }
                    }}
                    className="px-3 py-1.5 bg-purple-600/20 border border-purple-600/40 hover:bg-purple-600/30 disabled:opacity-50 rounded text-purple-400 text-xs font-medium transition-colors flex items-center gap-1.5"
                  >
                    {refreshingIntel ? (
                      <><svg className="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Refreshing...</>
                    ) : (
                      <><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg> Refresh All Intel</>
                    )}
                  </button>
                </div>
                {refreshIntelResult && (
                  <div className={`mb-3 text-xs px-3 py-2 rounded ${refreshIntelResult.ok ? "text-purple-400 bg-purple-900/30 border border-purple-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`}>
                    {refreshIntelResult.msg}
                  </div>
                )}
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: "Wallets", value: reportDataSummary.wallets, color: "text-blue-400" },
                    { label: "Alerts", value: reportDataSummary.alerts, color: "text-yellow-400" },
                    { label: "OSINT Hits", value: reportDataSummary.osintHits, color: "text-green-400" },
                    { label: "Origin Traces", value: reportDataSummary.originTraces, color: "text-amber-400" },
                    { label: "Network Scans", value: reportDataSummary.networkScans, color: "text-cyan-400" },
                    { label: "Spider Traces", value: reportDataSummary.spiderTraces, color: "text-violet-400" },
                    { label: "Freeze Requests", value: reportDataSummary.freezeRequests, color: "text-red-400" },
                  ].map(item => (
                    <div key={item.label} className="bg-[#0d1117] rounded-lg p-2 text-center">
                      <div className={`text-lg font-bold ${item.color}`}>{item.value || 0}</div>
                      <div className="text-[9px] text-gray-500">{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Victim Email Address *</label>
                  <input
                    data-testid="input-recipient-email"
                    type="email"
                    value={sendReportForm.recipientEmail}
                    onChange={e => setSendReportForm(f => ({ ...f, recipientEmail: e.target.value }))}
                    placeholder="victim@email.com"
                    className="w-full bg-[#161b22] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Victim Name</label>
                  <input
                    data-testid="input-recipient-name"
                    type="text"
                    value={sendReportForm.recipientName}
                    onChange={e => setSendReportForm(f => ({ ...f, recipientName: e.target.value }))}
                    placeholder="John Doe"
                    className="w-full bg-[#161b22] border border-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-600 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-2 block">Include in Report</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: "includeWallets", label: "Wallet Data", count: reportDataSummary?.wallets },
                    { key: "includeAlerts", label: "Forensic Alerts", count: reportDataSummary?.alerts },
                    { key: "includeOsint", label: "OSINT Evidence", count: reportDataSummary?.osintHits },
                    { key: "includeOriginIntel", label: "Origin Intelligence", count: reportDataSummary?.originTraces },
                    { key: "includeNetworkIntel", label: "Network Intelligence", count: reportDataSummary?.networkScans },
                    { key: "includeSpiderTrace", label: "Spider Traces", count: reportDataSummary?.spiderTraces },
                    { key: "includeFreezeRequests", label: "Freeze Requests", count: reportDataSummary?.freezeRequests },
                  ].map(item => (
                    <label key={item.key} className="flex items-center gap-2 text-xs text-gray-300 cursor-pointer hover:text-white">
                      <input
                        type="checkbox"
                        data-testid={`checkbox-${item.key}`}
                        checked={(sendReportForm as any)[item.key]}
                        onChange={e => setSendReportForm(f => ({ ...f, [item.key]: e.target.checked }))}
                        className="rounded border-gray-600 bg-gray-800 text-amber-500 focus:ring-amber-500"
                      />
                      {item.label} {item.count !== undefined && <span className="text-gray-600">({item.count})</span>}
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {sendReportResult && (
              <div className={`mt-3 text-xs px-3 py-2 rounded ${sendReportResult.ok ? "text-green-400 bg-green-900/30 border border-green-700/30" : "text-red-400 bg-red-900/30 border border-red-700/30"}`} data-testid="text-send-report-result">
                {sendReportResult.msg}
                {sendReportResult.fromAddress && (
                  <div className="mt-1 text-gray-400">From: <span className="text-cyan-400 font-mono">{sendReportResult.fromAddress}</span></div>
                )}
              </div>
            )}

            <div className="mt-4 flex gap-3">
              <button
                data-testid="button-confirm-send-report"
                disabled={sendingReport || !sendReportForm.recipientEmail || !selectedCase}
                onClick={async () => {
                  setSendingReport(true);
                  setSendReportResult(null);
                  try {
                    const resp = await fetch("/api/forensic/command-center/send-report", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      credentials: "include",
                      body: JSON.stringify({ caseId: selectedCase, ...sendReportForm })
                    });
                    const data = await resp.json();
                    if (data.success) {
                      setSendReportResult({ ok: true, msg: `Report sent successfully via ${data.provider || "email"}!`, fromAddress: data.fromAddress });
                      queryClient.invalidateQueries({ queryKey: ["/api/forensic/command-center/alerts"] });
                    } else {
                      setSendReportResult({ ok: false, msg: data.error || data.message || "Failed to send" });
                    }
                  } catch (e: any) {
                    setSendReportResult({ ok: false, msg: e.message });
                  } finally {
                    setSendingReport(false);
                  }
                }}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-lg text-sm font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {sendingReport ? (
                  <><svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Sending Full Report...</>
                ) : (
                  <><svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg> Send Full Report to Victim</>
                )}
              </button>
              <button
                onClick={() => setShowSendReport(false)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded-lg text-sm transition-colors"
                data-testid="button-cancel-send-report"
              >
                Cancel
              </button>
            </div>

            {!selectedCase && (
              <div className="mt-2 text-xs text-yellow-500">Select a case from the dropdown first to send its report.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
