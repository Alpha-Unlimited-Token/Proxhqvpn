/**
 * Bridge Fusion™ Composite Indicator - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { GitMerge, ChevronDown, ChevronUp, Plus, X, RefreshCw } from 'lucide-react';
import { type CandleData, type SignalOutput, computeBridgeFusion, computeWSI, computeERT, computeMFT, isOfficiallySupported, TECHNOLOGY_METADATA } from '@/lib/standalone/signal-sdk';
import {
  ALL_TECHNOLOGIES, BRIDGE_FUSION_COLORS, BRIDGE_FUSION_LABELS, POSITION_ROLES, checkCompatibility,
  computeTechScoreFromCandles, computeBridgeCascadeScore, computeBridgeHistoryWithBreakpoints,
  type BridgeBreakpoint,
} from '@/lib/standalone/bridge-fusion-engine';

interface BridgeGroup {
  active: boolean;
  selections: string[];
  result: { compositeScore: number; signal: string; confidence: number } | null;
  lineData: { time: number; value: number }[];
  breakpoints: BridgeBreakpoint[];
}

const SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'DOTUSDT', 'MATICUSDT'];
const INTERVALS = [
  { value: '1m', label: '1m' },
  { value: '5m', label: '5m' },
  { value: '15m', label: '15m' },
  { value: '1h', label: '1H' },
  { value: '4h', label: '4H' },
  { value: '1d', label: '1D' },
];

const SIGNAL_LABELS: Record<string, string> = {
  'strong_bullish': 'STRONG BUY', 'bullish': 'BUY', 'lean_bullish': 'LEAN BUY',
  'strong_bearish': 'STRONG SELL', 'bearish': 'SELL', 'lean_bearish': 'LEAN SELL',
  'reversal_up': 'REVERSAL UP', 'reversal_down': 'REVERSAL DOWN', 'momentum_shift': 'MOM SHIFT',
};

const SUPPORTED_EXCHANGES = ['binanceus', 'binance', 'coinbase', 'kraken', 'bybit', 'okx', 'kucoin', 'bitget', 'gateio'];

function BridgeChart({ candles, bridgeGroups, height = 260 }: { candles: CandleData[]; bridgeGroups: BridgeGroup[]; height?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = height * 2;
    ctx.scale(2, 2);

    const w = rect.width;
    const h = height;
    const padding = { top: 10, right: 65, bottom: 25, left: 5 };
    const chartW = w - padding.left - padding.right;
    const chartH = (h - padding.top - padding.bottom) * 0.55;
    const bridgeH = (h - padding.top - padding.bottom) * 0.4;
    const bridgeTop = padding.top + chartH + 8;

    ctx.fillStyle = '#0D1117';
    ctx.fillRect(0, 0, w, h);

    const displayCandles = candles.slice(-80);
    let minP = Infinity, maxP = -Infinity;
    displayCandles.forEach(c => { minP = Math.min(minP, c.low); maxP = Math.max(maxP, c.high); });
    const priceRange = maxP - minP || 1;
    const candleW = chartW / displayCandles.length;

    const priceToY = (p: number) => padding.top + chartH - ((p - minP) / priceRange) * chartH;

    displayCandles.forEach((c, i) => {
      const x = padding.left + i * candleW;
      const isBullish = c.close >= c.open;
      ctx.strokeStyle = isBullish ? '#22c55e' : '#ef4444';
      ctx.fillStyle = isBullish ? '#22c55e' : '#ef4444';

      ctx.beginPath();
      ctx.moveTo(x + candleW / 2, priceToY(c.high));
      ctx.lineTo(x + candleW / 2, priceToY(c.low));
      ctx.lineWidth = 1;
      ctx.stroke();

      const bodyTop = priceToY(Math.max(c.open, c.close));
      const bodyBottom = priceToY(Math.min(c.open, c.close));
      const bodyH = Math.max(1, bodyBottom - bodyTop);
      ctx.fillRect(x + 1, bodyTop, candleW - 2, bodyH);
    });

    if (displayCandles.length >= 20) {
      ctx.beginPath();
      ctx.strokeStyle = '#3b82f680';
      ctx.lineWidth = 1;
      for (let i = 19; i < displayCandles.length; i++) {
        const smaSlice = displayCandles.slice(i - 19, i + 1);
        const sma = smaSlice.reduce((a, c) => a + c.close, 0) / 20;
        const x = padding.left + i * candleW + candleW / 2;
        const y = priceToY(sma);
        if (i === 19) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    const lastPrice = displayCandles[displayCandles.length - 1]?.close;
    if (lastPrice) {
      const y = priceToY(lastPrice);
      ctx.fillStyle = '#FFD700';
      ctx.font = '9px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(lastPrice.toFixed(2), w - padding.right + 4, y + 3);
      ctx.setLineDash([2, 2]);
      ctx.strokeStyle = '#FFD70044';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(w - padding.right, y);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.strokeStyle = '#21262D';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(padding.left, bridgeTop - 4);
    ctx.lineTo(w - padding.right, bridgeTop - 4);
    ctx.stroke();

    ctx.fillStyle = '#6b728066';
    ctx.font = '8px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('BRIDGE FUSION', padding.left + 2, bridgeTop + 8);

    const bridgeScoreToY = (score: number) => bridgeTop + bridgeH / 2 - (score / 100) * (bridgeH / 2);

    ctx.setLineDash([2, 3]);
    ctx.strokeStyle = '#21262D';
    ctx.lineWidth = 0.5;
    for (const level of [-40, -20, 0, 20, 40]) {
      const y = bridgeScoreToY(level);
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(w - padding.right, y);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    ctx.fillStyle = '#4b5563';
    ctx.font = '7px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('+40', w - padding.right + 4, bridgeScoreToY(40) + 3);
    ctx.fillText('  0', w - padding.right + 4, bridgeScoreToY(0) + 3);
    ctx.fillText('-40', w - padding.right + 4, bridgeScoreToY(-40) + 3);

    const candleTimeMap = new Map<number, number>();
    displayCandles.forEach((c, i) => candleTimeMap.set(c.time, i));
    const firstTime = displayCandles[0].time;
    const lastTime = displayCandles[displayCandles.length - 1].time;

    const indexToX = (idx: number) => padding.left + idx * candleW + candleW / 2;
    const findNearestIndex = (time: number) => {
      let best = 0, bestDist = Infinity;
      for (let i = 0; i < displayCandles.length; i++) {
        const d = Math.abs(displayCandles[i].time - time);
        if (d < bestDist) { bestDist = d; best = i; }
      }
      return best;
    };

    bridgeGroups.forEach((group, gi) => {
      if (!group.active || group.lineData.length < 2) return;
      const color = BRIDGE_FUSION_COLORS[gi];

      const visiblePoints = group.lineData
        .filter(p => p.time >= firstTime && p.time <= lastTime)
        .map(p => ({ ...p, idx: findNearestIndex(p.time) }));
      if (visiblePoints.length < 2) return;

      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      visiblePoints.forEach((p, i) => {
        const x = indexToX(p.idx);
        const y = bridgeScoreToY(p.value);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      ctx.fillStyle = color;
      ctx.globalAlpha = 0.08;
      ctx.beginPath();
      visiblePoints.forEach((p, i) => {
        const x = indexToX(p.idx);
        const y = bridgeScoreToY(p.value);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.lineTo(indexToX(visiblePoints[visiblePoints.length - 1].idx), bridgeScoreToY(0));
      ctx.lineTo(indexToX(visiblePoints[0].idx), bridgeScoreToY(0));
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1;

      group.breakpoints.forEach(bp => {
        if (bp.time < firstTime || bp.time > lastTime) return;
        const bpIdx = findNearestIndex(bp.time);
        const x = indexToX(bpIdx);
        const y = bridgeScoreToY(bp.score);
        const isBull = bp.type.includes('bullish') || bp.type === 'reversal_up';

        ctx.beginPath();
        ctx.fillStyle = color;
        if (isBull) {
          ctx.moveTo(x, y + 6);
          ctx.lineTo(x - 4, y + 12);
          ctx.lineTo(x + 4, y + 12);
        } else {
          ctx.moveTo(x, y - 6);
          ctx.lineTo(x - 4, y - 12);
          ctx.lineTo(x + 4, y - 12);
        }
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = color;
        ctx.font = '7px monospace';
        ctx.textAlign = 'center';
        const label = SIGNAL_LABELS[bp.type] || bp.type;
        ctx.fillText(label, x, isBull ? y + 20 : y - 14);
      });

      const lastPt = visiblePoints[visiblePoints.length - 1];
      if (lastPt) {
        const lx = indexToX(lastPt.idx);
        const ly = bridgeScoreToY(lastPt.value);
        ctx.beginPath();
        ctx.arc(lx, ly, 3, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
        ctx.fillStyle = color;
        ctx.font = '8px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`${BRIDGE_FUSION_LABELS[gi].replace('Bridge ', '')} ${lastPt.value}`, lx + 6, ly + 3);
      }
    });

    ctx.fillStyle = '#6b7280';
    ctx.font = '8px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(maxP.toFixed(2), w - padding.right + 4, padding.top + 10);
    ctx.fillText(minP.toFixed(2), w - padding.right + 4, padding.top + chartH - 2);

  }, [candles, bridgeGroups, height]);

  return <canvas ref={canvasRef} style={{ width: '100%', height, display: 'block', borderRadius: 4 }} />;
}

function TechSelector({ selections, onChange, groupIndex }: { selections: string[]; onChange: (s: string[]) => void; groupIndex: number }) {
  const [showPicker, setShowPicker] = useState(false);
  const color = BRIDGE_FUSION_COLORS[groupIndex];

  const addTech = (key: string) => {
    if (selections.length >= 4 || selections.includes(key)) return;
    onChange([...selections, key]);
  };

  const removeTech = (key: string) => {
    onChange(selections.filter(s => s !== key));
  };

  const moveTech = (idx: number, dir: number) => {
    const next = [...selections];
    const target = idx + dir;
    if (target < 0 || target >= next.length) return;
    [next[idx], next[target]] = [next[target], next[idx]];
    onChange(next);
  };

  return (
    <div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, marginBottom: 4 }}>
        {selections.map((key, i) => {
          const tech = ALL_TECHNOLOGIES.find(t => t.key === key);
          const role = POSITION_ROLES[Math.min(i, 3)];
          return (
            <div key={key} data-testid={`tech-chip-${groupIndex}-${key}`} style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '2px 6px', borderRadius: 4, background: `${color}18`, border: `1px solid ${color}44`, fontSize: 9 }}>
              <span style={{ color: '#6b7280', fontSize: 7, fontWeight: 700 }}>{role.name[0]}</span>
              <span style={{ color, fontWeight: 700 }}>{key}</span>
              {i > 0 && <button data-testid={`btn-move-up-${groupIndex}-${key}`} onClick={() => moveTech(i, -1)} style={{ background: 'none', border: 'none', color: '#6b7280', cursor: 'pointer', fontSize: 8, padding: 0 }}>&#9650;</button>}
              {i < selections.length - 1 && <button data-testid={`btn-move-down-${groupIndex}-${key}`} onClick={() => moveTech(i, 1)} style={{ background: 'none', border: 'none', color: '#6b7280', cursor: 'pointer', fontSize: 8, padding: 0 }}>&#9660;</button>}
              <button data-testid={`btn-remove-${groupIndex}-${key}`} onClick={() => removeTech(key)} style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 10, padding: 0, marginLeft: 2 }}><X size={10} /></button>
            </div>
          );
        })}
        {selections.length < 4 && (
          <button data-testid={`btn-add-tech-${groupIndex}`} onClick={() => setShowPicker(!showPicker)} style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '2px 6px', borderRadius: 4, background: '#21262D', border: '1px dashed #30363D', color: '#6b7280', cursor: 'pointer', fontSize: 9 }}>
            <Plus size={10} /> Add
          </button>
        )}
      </div>
      {selections.length >= 2 && (
        <div style={{ fontSize: 7, color: '#4b5563', marginBottom: 2 }}>
          {selections.map((k, i) => `${POSITION_ROLES[Math.min(i, 3)].name}: ${k}`).join(' → ')}
        </div>
      )}
      {showPicker && (
        <div style={{ padding: 6, background: '#161B22', border: '1px solid #30363D', borderRadius: 6, marginTop: 2, maxHeight: 160, overflowY: 'auto' }}>
          {selections.length > 0 && (
            <div style={{ display: 'flex', gap: 6, fontSize: 7, color: '#9ca3af', marginBottom: 4, paddingBottom: 4, borderBottom: '1px solid #21262D', flexWrap: 'wrap' }}>
              <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#10b981', borderRadius: 2, marginRight: 2 }} />Excellent</span>
              <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#3b82f6', borderRadius: 2, marginRight: 2 }} />Good</span>
              <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#6b7280', borderRadius: 2, marginRight: 2 }} />Neutral</span>
              <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#f59e0b', borderRadius: 2, marginRight: 2 }} />Marginal</span>
              <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#374151', borderRadius: 2, marginRight: 2 }} />Incompatible</span>
            </div>
          )}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
            {ALL_TECHNOLOGIES.filter(t => !selections.includes(t.key)).map(t => {
              const compat = checkCompatibility(selections, t.key);
              const isIncompat = compat.level === 'incompatible';
              const styleByLevel: Record<string, { bg: string; border: string; color: string }> = {
                excellent:    { bg: '#10b98122', border: '#10b98166', color: '#10b981' },
                good:         { bg: '#3b82f622', border: '#3b82f666', color: '#60a5fa' },
                neutral:      { bg: '#21262D',  border: '#30363D',   color: '#e5e7eb' },
                marginal:     { bg: '#f59e0b18', border: '#f59e0b55', color: '#fbbf24' },
                incompatible: { bg: '#0d1117',  border: '#21262D',   color: '#4b5563' },
              };
              const s = styleByLevel[compat.level];
              return (
                <button
                  key={t.key}
                  data-testid={`btn-pick-${groupIndex}-${t.key}`}
                  disabled={isIncompat}
                  onClick={() => {
                    if (isIncompat) return;
                    addTech(t.key);
                    if (selections.length >= 3) setShowPicker(false);
                  }}
                  style={{
                    padding: '2px 5px',
                    borderRadius: 3,
                    background: s.bg,
                    border: `1px solid ${s.border}`,
                    color: s.color,
                    cursor: isIncompat ? 'not-allowed' : 'pointer',
                    fontSize: 8,
                    fontFamily: 'monospace',
                    opacity: isIncompat ? 0.5 : 1,
                    textDecoration: isIncompat ? 'line-through' : 'none',
                  }}
                  title={`${t.label}\n${compat.reason}`}
                >
                  {t.key}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default function StandaloneBridgeFusionApp() {
  const [showSplash, setShowSplash] = useState(true);
  const [showValidatedPairings, setShowValidatedPairings] = useState(true);
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [interval_, setInterval_] = useState('5m');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const refreshTimer = useRef<any>(null);
  const [connections, setConnections] = useState<any[]>([]);
  const [selectedConnection, setSelectedConnection] = useState('');
  const [showConnect, setShowConnect] = useState(false);
  const [newApiKey, setNewApiKey] = useState('');
  const [newApiSecret, setNewApiSecret] = useState('');
  const [newExchange, setNewExchange] = useState('binanceus');
  const [connecting, setConnecting] = useState(false);
  const [expandedBridge, setExpandedBridge] = useState<number | null>(0);
  const [legacySignal, setLegacySignal] = useState<SignalOutput | null>(null);

  const [bridgeGroups, setBridgeGroups] = useState<BridgeGroup[]>([
    { active: true, selections: ['ACM', 'QFRM'], result: null, lineData: [], breakpoints: [] },
    { active: false, selections: ['BIF', 'SBPE'], result: null, lineData: [], breakpoints: [] },
    { active: false, selections: ['ANCE', 'RSI'], result: null, lineData: [], breakpoints: [] },
    { active: false, selections: ['TMDE', 'MACD'], result: null, lineData: [], breakpoints: [] },
  ]);

  const activeExchangeId = useMemo(() => {
    if (!selectedConnection) return 'binanceus';
    const conn = connections.find((c: any) => String(c.id) === selectedConnection);
    return conn?.exchangeName || 'unknown';
  }, [selectedConnection, connections]);

  useEffect(() => {
    fetch('/api/standalone/exchange/connections', { credentials: 'include' })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setConnections(data); })
      .catch(() => {});
  }, []);

  const computeBridgesRef = useRef<(candleData: CandleData[]) => void>(() => {});
  computeBridgesRef.current = (candleData: CandleData[]) => {
    if (candleData.length < 30) return;
    setBridgeGroups(prev => prev.map((group, gi) => {
      if (!group.active || group.selections.length < 2) return group;
      const { lineData, breakpoints } = computeBridgeHistoryWithBreakpoints(group.selections, candleData);
      const scores = group.selections.map(t => computeTechScoreFromCandles(t, candleData));
      const composite = computeBridgeCascadeScore(group.selections, scores);
      const avgConf = Math.min(95, 50 + Math.abs(composite) * 0.3 + (group.selections.length - 1) * 8);
      const signal = composite > 40 ? 'strong_buy' : composite > 20 ? 'buy' : composite < -40 ? 'strong_sell' : composite < -20 ? 'sell' : 'neutral';
      return { ...group, result: { compositeScore: composite, signal, confidence: Math.round(avgConf) }, lineData, breakpoints };
    }));
  };

  const fetchCandles = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ symbol, interval: interval_, limit: '200' });
      if (selectedConnection) params.set('connectionId', selectedConnection);
      const res = await fetch(`/api/standalone/exchange/candles?${params}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch data');
      const data = await res.json();
      if (data.candles && data.candles.length > 0) {
        setCandles(data.candles);
        setLastUpdate(new Date());
        const sig = computeBridgeFusion(data.candles, activeExchangeId);
        setLegacySignal(sig);
        computeBridgesRef.current(data.candles);
      }
    } catch (e: any) {
      setError(e.message || 'Connection error');
    } finally {
      setLoading(false);
    }
  }, [symbol, interval_, selectedConnection, activeExchangeId]);

  useEffect(() => {
    fetchCandles();
    if (autoRefresh) {
      const ms = interval_ === '1m' ? 10000 : interval_ === '5m' ? 30000 : 60000;
      refreshTimer.current = setInterval(fetchCandles, ms);
    }
    return () => { if (refreshTimer.current) clearInterval(refreshTimer.current); };
  }, [fetchCandles, autoRefresh, interval_]);

  const bridgeConfigKey = bridgeGroups.map(g => `${g.active}:${g.selections.join(',')}`).join('|');
  useEffect(() => {
    if (candles.length > 0) computeBridgesRef.current(candles);
  }, [bridgeConfigKey, candles]);

  const handleConnect = async () => {
    if (!newApiKey || !newApiSecret) return;
    setConnecting(true);
    try {
      const res = await fetch('/api/standalone/exchange/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ exchangeId: newExchange, apiKey: newApiKey, apiSecret: newApiSecret }),
      });
      const data = await res.json();
      if (data.success) {
        setConnections(prev => [...prev, { id: data.connectionId, exchangeName: newExchange, isActive: true }]);
        setSelectedConnection(String(data.connectionId));
        setShowConnect(false);
        setNewApiKey('');
        setNewApiSecret('');
      }
    } catch (e) {}
    setConnecting(false);
  };

  const updateSelections = (gi: number, selections: string[]) => {
    setBridgeGroups(prev => {
      const next = [...prev];
      next[gi] = { ...next[gi], selections, result: null, lineData: [], breakpoints: [] };
      return next;
    });
  };

  const toggleBridge = (gi: number) => {
    setBridgeGroups(prev => {
      const next = [...prev];
      next[gi] = { ...next[gi], active: !next[gi].active, result: null, lineData: [], breakpoints: [] };
      return next;
    });
  };

  const activeCount = bridgeGroups.filter(g => g.active && g.result).length;
  const avgScore = activeCount > 0 ? Math.round(bridgeGroups.filter(g => g.active && g.result).reduce((s, g) => s + g.result!.compositeScore, 0) / activeCount) : 0;
  const avgConf = activeCount > 0 ? Math.round(bridgeGroups.filter(g => g.active && g.result).reduce((s, g) => s + g.result!.confidence, 0) / activeCount) : 0;
  const overallSignal = avgScore > 40 ? 'STRONG BUY' : avgScore > 20 ? 'BUY' : avgScore < -40 ? 'STRONG SELL' : avgScore < -20 ? 'SELL' : 'NEUTRAL';
  const overallColor = avgScore > 20 ? '#22c55e' : avgScore < -20 ? '#ef4444' : '#9ca3af';

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="bridge_fusion"
        techName="Bridge Fusion™ Composite Indicator"
        techShortName="Bridge Fusion"
        techColor="#f59e0b"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="bridge_fusion" techName="Bridge Fusion™ Composite Indicator" techColor="#f59e0b">
      <div data-testid="standalone-bridge-fusion" style={{ maxWidth: 700, margin: '20px auto', padding: '0 12px' }}>
        <div style={{ textAlign: 'center', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <GitMerge size={20} style={{ color: '#f59e0b' }} />
            <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 18, margin: 0 }}>Bridge Fusion™</h1>
          </div>
          <p style={{ color: '#6b7280', fontSize: 11, marginTop: 4 }}>Permutation-sensitive multi-technology composite with 351 interaction coefficients across 27 technologies</p>
        </div>

        <div style={{ background: '#0D1117', borderRadius: 8, border: '1px solid #f59e0b33', overflow: 'hidden' }}>
          <div style={{ display: 'flex', gap: 6, padding: '6px 10px', flexWrap: 'wrap', background: '#161B2288', borderBottom: '1px solid #21262D' }}>
            <select data-testid="select-symbol" value={symbol} onChange={e => setSymbol(e.target.value)} style={{ background: '#21262D', color: '#e5e7eb', border: '1px solid #30363D', borderRadius: 4, padding: '3px 6px', fontSize: 11, fontFamily: 'monospace' }}>
              {SYMBOLS.map(s => <option key={s} value={s}>{s.replace('USDT', '/USDT')}</option>)}
            </select>
            <div style={{ display: 'flex', gap: 2 }}>
              {INTERVALS.map(iv => (
                <button key={iv.value} data-testid={`button-interval-${iv.value}`} onClick={() => setInterval_(iv.value)} style={{ background: interval_ === iv.value ? '#f59e0b' : '#21262D', color: interval_ === iv.value ? '#000' : '#9ca3af', border: 'none', borderRadius: 3, padding: '3px 6px', fontSize: 10, fontWeight: 700, cursor: 'pointer' }}>{iv.label}</button>
              ))}
            </div>
            <select data-testid="select-exchange" value={selectedConnection} onChange={e => { if (e.target.value === 'new') setShowConnect(true); else setSelectedConnection(e.target.value); }} style={{ background: '#21262D', color: '#e5e7eb', border: '1px solid #30363D', borderRadius: 4, padding: '3px 6px', fontSize: 11, marginLeft: 'auto' }}>
              <option value="">Binance.US (Public)</option>
              {connections.filter((c: any) => c.isActive).map((c: any) => <option key={c.id} value={c.id}>{c.exchangeName}</option>)}
              <option value="new">+ Connect Exchange</option>
            </select>
          </div>

          {!isOfficiallySupported(activeExchangeId) && (
            <div style={{ padding: '4px 10px', background: '#7c2d1233', borderBottom: '1px solid #ef444433', fontSize: 9, color: '#fca5a5' }}>
              <span style={{ fontWeight: 700, color: '#ef4444' }}>NOTICE:</span> Unsupported exchange. Signal accuracy may vary.
            </div>
          )}

          <div style={{ padding: '4px 8px' }}>
            {candles.length > 0 ? (
              <BridgeChart candles={candles} bridgeGroups={bridgeGroups} height={280} />
            ) : loading ? (
              <div style={{ height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#6b7280' }}>Loading chart data...</div>
            ) : error ? (
              <div style={{ height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ef4444' }}>{error}</div>
            ) : null}
          </div>

          {activeCount > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 10px', background: '#161B22', borderTop: '1px solid #21262D', borderBottom: '1px solid #21262D' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontFamily: 'Orbitron, monospace', fontSize: 14, fontWeight: 700, color: overallColor }}>{overallSignal}</span>
                <span style={{ fontSize: 11, color: '#6b7280' }}>Score: <span style={{ color: overallColor, fontWeight: 700 }}>{avgScore}</span></span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Confidence: <span style={{ color: '#f59e0b', fontWeight: 700 }}>{avgConf}%</span></span>
                <span style={{ fontSize: 10, color: '#6b7280' }}>{activeCount} bridge{activeCount > 1 ? 's' : ''} active</span>
              </div>
            </div>
          )}

          <div style={{ padding: '8px 10px' }}>
            <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 700, letterSpacing: '0.5px', marginBottom: 6 }}>BRIDGE GROUPS</div>
            {bridgeGroups.map((group, gi) => (
              <div key={gi} data-testid={`bridge-group-${gi}`} style={{ marginBottom: 6, borderRadius: 6, border: `1px solid ${group.active ? BRIDGE_FUSION_COLORS[gi] + '66' : '#21262D'}`, background: group.active ? `${BRIDGE_FUSION_COLORS[gi]}08` : '#0D1117', overflow: 'hidden' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 8px', cursor: 'pointer' }} onClick={() => setExpandedBridge(expandedBridge === gi ? null : gi)}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: BRIDGE_FUSION_COLORS[gi], display: 'inline-block', opacity: group.active ? 1 : 0.3 }} />
                    <span style={{ fontFamily: 'Orbitron, monospace', fontSize: 11, fontWeight: 700, color: group.active ? BRIDGE_FUSION_COLORS[gi] : '#6b7280' }}>{BRIDGE_FUSION_LABELS[gi]}</span>
                    {group.result && group.active && (
                      <span style={{ fontSize: 10, fontWeight: 700, color: group.result.compositeScore > 20 ? '#22c55e' : group.result.compositeScore < -20 ? '#ef4444' : '#9ca3af', fontFamily: 'monospace' }}>
                        {group.result.compositeScore > 0 ? '+' : ''}{group.result.compositeScore} ({group.result.confidence}%)
                      </span>
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <button data-testid={`btn-toggle-bridge-${gi}`} onClick={e => { e.stopPropagation(); toggleBridge(gi); }} style={{ background: group.active ? BRIDGE_FUSION_COLORS[gi] : '#21262D', color: group.active ? '#000' : '#6b7280', border: 'none', borderRadius: 3, padding: '2px 8px', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>{group.active ? 'ON' : 'OFF'}</button>
                    {expandedBridge === gi ? <ChevronUp size={14} style={{ color: '#6b7280' }} /> : <ChevronDown size={14} style={{ color: '#6b7280' }} />}
                  </div>
                </div>

                {expandedBridge === gi && (
                  <div style={{ padding: '4px 8px 8px', borderTop: '1px solid #21262D' }}>
                    <div style={{ fontSize: 9, color: '#6b7280', marginBottom: 4 }}>Technologies (order matters - position determines role):</div>
                    <TechSelector selections={group.selections} onChange={s => updateSelections(gi, s)} groupIndex={gi} />

                    {group.result && group.active && (
                      <div style={{ marginTop: 8, fontSize: 10 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                          <span style={{ color: '#6b7280' }}>Composite Score</span>
                          <span style={{ color: group.result.compositeScore > 20 ? '#22c55e' : group.result.compositeScore < -20 ? '#ef4444' : '#e5e7eb', fontWeight: 700, fontFamily: 'monospace' }}>{group.result.compositeScore}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                          <span style={{ color: '#6b7280' }}>Signal</span>
                          <span style={{ color: group.result.compositeScore > 20 ? '#22c55e' : group.result.compositeScore < -20 ? '#ef4444' : '#e5e7eb', fontWeight: 700 }}>{group.result.signal.replace(/_/g, ' ').toUpperCase()}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                          <span style={{ color: '#6b7280' }}>Breakpoints Detected</span>
                          <span style={{ color: BRIDGE_FUSION_COLORS[gi], fontFamily: 'monospace', fontWeight: 700 }}>{group.breakpoints.length}</span>
                        </div>

                        {group.selections.length >= 2 && (
                          <div style={{ marginTop: 6 }}>
                            <div style={{ fontSize: 9, color: BRIDGE_FUSION_COLORS[gi], fontWeight: 700, marginBottom: 3 }}>INDIVIDUAL TECH SCORES</div>
                            {group.selections.map((key, i) => {
                              const score = computeTechScoreFromCandles(key, candles);
                              const role = POSITION_ROLES[Math.min(i, 3)];
                              return (
                                <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22' }}>
                                  <span style={{ color: '#6b7280', fontSize: 9 }}>{role.name}: {key}</span>
                                  <span style={{ color: score > 20 ? '#22c55e' : score < -20 ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 9, fontWeight: 700 }}>{score > 0 ? '+' : ''}{score}</span>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {group.breakpoints.length > 0 && (
                          <div style={{ marginTop: 6 }}>
                            <div style={{ fontSize: 9, color: BRIDGE_FUSION_COLORS[gi], fontWeight: 700, marginBottom: 3 }}>RECENT BREAKPOINTS</div>
                            {group.breakpoints.slice(-5).reverse().map((bp, i) => (
                              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22' }}>
                                <span style={{ color: BRIDGE_FUSION_COLORS[gi], fontSize: 9 }}>{SIGNAL_LABELS[bp.type] || bp.type}</span>
                                <span style={{ color: '#6b7280', fontFamily: 'monospace', fontSize: 9 }}>S:{bp.score} C:{bp.confidence}%</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {legacySignal && (
            <div style={{ padding: '8px 10px', borderTop: '1px solid #21262D' }}>
              <div style={{ fontSize: 9, color: '#6b7280', fontWeight: 700, letterSpacing: '0.5px', marginBottom: 4 }}>LEGACY 4-TECH FUSION (ACM+QFRM+BIF+SBPE)</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D', fontSize: 10 }}>
                <span style={{ color: '#f59e0b', fontWeight: 700 }}>Consensus</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{legacySignal.details.consensus ?? 'N/A'}/4</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D', fontSize: 10 }}>
                <span style={{ color: '#6b7280' }}>Signal</span>
                <span style={{ color: legacySignal.signal.includes('buy') ? '#22c55e' : legacySignal.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontWeight: 700 }}>{legacySignal.signal.replace(/_/g, ' ').toUpperCase()} ({legacySignal.confidence}%)</span>
              </div>
              {legacySignal.details.components && typeof legacySignal.details.components === 'object' && (
                <>
                  {Object.entries(legacySignal.details.components as Record<string, { signal: string; strength: number; confidence: number }>).map(([key, comp]) => (
                    <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22', fontSize: 9 }}>
                      <span style={{ color: '#6b7280' }}>{key.toUpperCase()}</span>
                      <span style={{ color: comp.signal === 'buy' || comp.signal === 'strong_buy' ? '#22c55e' : comp.signal === 'sell' || comp.signal === 'strong_sell' ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>
                        {comp.signal.replace('_', ' ').toUpperCase()} ({comp.strength}%)
                      </span>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}

          {candles.length > 0 && (() => {
            const wsi = computeWSI(candles);
            const ert = computeERT(candles);
            const mft = computeMFT(candles);
            return (
              <div style={{ padding: '6px 10px', borderTop: '1px solid #21262D' }}>
                <div style={{ fontSize: 9, color: '#6b7280', fontWeight: 700, letterSpacing: '0.5px', marginBottom: 4 }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                {[
                  { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                  { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                  { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                ].map(s => (
                  <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22', fontSize: 9 }}>
                    <span style={{ color: s.color }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                    <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                      {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                    </span>
                  </div>
                ))}
              </div>
            );
          })()}

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 10px', borderTop: '1px solid #21262D', fontSize: 9, color: '#6b7280' }}>
            <span>{lastUpdate ? `Updated ${lastUpdate.toLocaleTimeString()}` : 'Waiting...'}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <button data-testid="button-refresh" onClick={fetchCandles} disabled={loading} style={{ background: 'none', border: 'none', color: '#f59e0b', cursor: 'pointer', fontSize: 11, display: 'flex', alignItems: 'center' }}><RefreshCw size={12} /></button>
              <label style={{ display: 'flex', alignItems: 'center', gap: 3, cursor: 'pointer' }}>
                <input data-testid="checkbox-auto-refresh" type="checkbox" checked={autoRefresh} onChange={e => setAutoRefresh(e.target.checked)} style={{ accentColor: '#f59e0b' }} />
                Auto
              </label>
            </div>
          </div>
        </div>

        {showConnect && (
          <div style={{ position: 'fixed', inset: 0, background: '#000000cc', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100000 }} onClick={() => setShowConnect(false)}>
            <div data-testid="modal-connect-exchange" onClick={e => e.stopPropagation()} style={{ background: '#161B22', border: '1px solid #30363D', borderRadius: 12, padding: 24, maxWidth: 400, width: '90%' }}>
              <h3 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', marginBottom: 16, fontSize: 15 }}>Connect Exchange</h3>
              <select data-testid="select-new-exchange" value={newExchange} onChange={e => setNewExchange(e.target.value)} style={{ width: '100%', background: '#21262D', color: '#e5e7eb', border: '1px solid #30363D', borderRadius: 6, padding: '8px 12px', marginBottom: 12 }}>
                {SUPPORTED_EXCHANGES.map(ex => <option key={ex} value={ex}>{ex}</option>)}
              </select>
              <input data-testid="input-api-key" type="password" placeholder="API Key" value={newApiKey} onChange={e => setNewApiKey(e.target.value)} style={{ width: '100%', background: '#21262D', color: '#e5e7eb', border: '1px solid #30363D', borderRadius: 6, padding: '8px 12px', marginBottom: 8, boxSizing: 'border-box' }} />
              <input data-testid="input-api-secret" type="password" placeholder="API Secret" value={newApiSecret} onChange={e => setNewApiSecret(e.target.value)} style={{ width: '100%', background: '#21262D', color: '#e5e7eb', border: '1px solid #30363D', borderRadius: 6, padding: '8px 12px', marginBottom: 12, boxSizing: 'border-box' }} />
              <p style={{ fontSize: 10, color: '#6b7280', marginBottom: 8 }}>Your keys are encrypted and stored securely. Read-only access only.</p>
              <div style={{ display: 'flex', gap: 8 }}>
                <button data-testid="button-cancel-connect" onClick={() => setShowConnect(false)} style={{ flex: 1, background: '#21262D', color: '#e5e7eb', border: 'none', borderRadius: 6, padding: '8px 12px', cursor: 'pointer' }}>Cancel</button>
                <button data-testid="button-confirm-connect" onClick={handleConnect} disabled={connecting || !newApiKey || !newApiSecret} style={{ flex: 1, background: '#FFD700', color: '#000', border: 'none', borderRadius: 6, padding: '8px 12px', cursor: 'pointer', fontWeight: 700, opacity: connecting ? 0.5 : 1 }}>{connecting ? 'Connecting...' : 'Connect'}</button>
              </div>
            </div>
          </div>
        )}

        <div data-testid="validated-pairings-panel" style={{ marginTop: 12, padding: '8px 12px', background: 'linear-gradient(135deg, #064e3b22, #05966911)', borderRadius: 8, border: '1px solid #05966930' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, cursor: 'pointer' }} onClick={() => setShowValidatedPairings(!showValidatedPairings)}>
            <span style={{ fontSize: 10, color: '#10b981', fontWeight: 700, letterSpacing: '0.5px' }}>VALIDATED BEST FUSIONS</span>
            <span style={{ fontSize: 9, color: '#6b7280' }}>241,977 events / 48 coins / 1,368 fusions</span>
            {showValidatedPairings ? <ChevronUp size={10} style={{ color: '#10b981', marginLeft: 'auto' }} /> : <ChevronDown size={10} style={{ color: '#10b981', marginLeft: 'auto' }} />}
          </div>
          {showValidatedPairings && <div>
            <div style={{ fontSize: 8, color: '#f59e0b', fontWeight: 700, marginBottom: 3, letterSpacing: '0.5px' }}>TOP 4-WAY FUSIONS</div>
            {[
              { combo: 'SBPE+ANCE+H/S+Filters', lean: 'sBear', acc: '100%', n: 24 },
              { combo: 'SBPE+WSI+H/S+Filters', lean: 'sBear', acc: '100%', n: 20 },
              { combo: 'ACM+BIF+TMDE+Filters', lean: 'sBear', acc: '100%', n: 17 },
              { combo: 'SBPE+ANCE+MFT+H/S', lean: 'sBull', acc: '100%', n: 16 },
              { combo: 'TMDE+QMGE+MFT+Filters', lean: 'sBear', acc: '100%', n: 9 },
              { combo: 'SBPE+TMDE+QMGE+ERT', lean: 'sBear', acc: '100%', n: 7 },
              { combo: 'QFRM+SBPE+H/S+Filters', lean: 'sBear', acc: '93.1%', n: 29 },
              { combo: 'SBPE+ERT+H/S+Filters', lean: 'sBear', acc: '90.9%', n: 22 },
              { combo: 'ACM+BIF+SBPE+Filters', lean: 'sBear', acc: '87.5%', n: 40 },
              { combo: 'BIF+SBPE+WSI+Filters', lean: 'sBear', acc: '84.7%', n: 59 },
            ].map((p, i) => (
              <div key={`4w-${i}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22', fontSize: 9 }} data-testid={`bf-4way-${i}`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                  {p.combo.split('+').map((t, ti) => (
                    <span key={ti} style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      {ti > 0 && <span style={{ color: '#374151' }}>+</span>}
                      <span style={{ color: '#f59e0b', fontWeight: 700, fontFamily: 'monospace' }}>{t}</span>
                    </span>
                  ))}
                  <span style={{ color: '#4b5563' }}>({p.lean})</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ color: '#4b5563' }}>n={p.n}</span>
                  <span style={{ color: parseFloat(p.acc) >= 90 ? '#22c55e' : parseFloat(p.acc) >= 80 ? '#10b981' : '#eab308', fontWeight: 700, fontFamily: 'monospace' }}>{p.acc}</span>
                </div>
              </div>
            ))}

            <div style={{ fontSize: 8, color: '#06b6d4', fontWeight: 700, marginTop: 6, marginBottom: 3, letterSpacing: '0.5px' }}>TOP 3-WAY FUSIONS</div>
            {[
              { combo: 'SBPE+H/S+Filters', lean: 'sBear', acc: '93.8%', n: 32 },
              { combo: 'ACM+MFT+H/S', lean: 'sBear', acc: '83.7%', n: 43 },
              { combo: 'QMGE+MFT+Filters', lean: 'sBear', acc: '77%', n: 100 },
              { combo: 'BIF+SBPE+Filters', lean: 'sBear', acc: '76.7%', n: 103 },
              { combo: 'TMDE+H/S+Filters', lean: 'sBull', acc: '76.3%', n: 38 },
              { combo: 'ACM+TMDE+Filters', lean: 'sBear', acc: '74.5%', n: 106 },
              { combo: 'SBPE+ANCE+TMDE', lean: 'sBear', acc: '72%', n: 25 },
              { combo: 'TMDE+QMGE+Filters', lean: 'sBear', acc: '71%', n: 62 },
              { combo: 'SBPE+ANCE+TMDE', lean: 'sBull', acc: '70.3%', n: 91 },
            ].map((p, i) => (
              <div key={`3w-${i}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22', fontSize: 9 }} data-testid={`bf-3way-${i}`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                  {p.combo.split('+').map((t, ti) => (
                    <span key={ti} style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      {ti > 0 && <span style={{ color: '#374151' }}>+</span>}
                      <span style={{ color: '#06b6d4', fontWeight: 700, fontFamily: 'monospace' }}>{t}</span>
                    </span>
                  ))}
                  <span style={{ color: '#4b5563' }}>({p.lean})</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ color: '#4b5563' }}>n={p.n}</span>
                  <span style={{ color: parseFloat(p.acc) >= 90 ? '#22c55e' : parseFloat(p.acc) >= 75 ? '#10b981' : parseFloat(p.acc) >= 65 ? '#eab308' : '#9ca3af', fontWeight: 700, fontFamily: 'monospace' }}>{p.acc}</span>
                </div>
              </div>
            ))}

            <div style={{ fontSize: 8, color: '#a855f7', fontWeight: 700, marginTop: 6, marginBottom: 3, letterSpacing: '0.5px' }}>TOP 2-WAY FUSIONS</div>
            {[
              { combo: 'MFT+Filters', lean: 'sBear', acc: '63%', n: 300 },
              { combo: 'QMGE+Filters', lean: 'sBear', acc: '62.9%', n: 342 },
              { combo: 'SBPE+Filters', lean: 'sBear', acc: '61.8%', n: 251 },
              { combo: 'SBPE+TMDE', lean: 'sBear', acc: '61.3%', n: 651 },
              { combo: 'SBPE+H/S', lean: 'bLean', acc: '60.7%', n: 476 },
              { combo: 'BIF+SBPE', lean: 'sBear', acc: '60.4%', n: 2244 },
            ].map((p, i) => (
              <div key={`2w-${i}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid #161B22', fontSize: 9 }} data-testid={`bf-2way-${i}`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                  {p.combo.split('+').map((t, ti) => (
                    <span key={ti} style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      {ti > 0 && <span style={{ color: '#374151' }}>+</span>}
                      <span style={{ color: '#a855f7', fontWeight: 700, fontFamily: 'monospace' }}>{t}</span>
                    </span>
                  ))}
                  <span style={{ color: '#4b5563' }}>({p.lean})</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ color: '#4b5563' }}>n={p.n.toLocaleString()}</span>
                  <span style={{ color: parseFloat(p.acc) >= 62 ? '#eab308' : '#9ca3af', fontWeight: 700, fontFamily: 'monospace' }}>{p.acc}</span>
                </div>
              </div>
            ))}

            <p style={{ fontSize: 8, color: '#4b5563', marginTop: 4, margin: '4px 0 0' }}>241,977 events, 48 coins, 65/35 train/holdout, 6-month period, 1h candles, 24h forward prediction. Select these combinations in Bridge Fusion for data-validated accuracy.</p>
          </div>}
        </div>

        {(() => {
          const meta = TECHNOLOGY_METADATA.bridge_fusion;
          return (
            <div data-testid="tech-metadata-bridge_fusion" style={{ marginTop: 12, padding: '8px 12px', background: '#0D111799', borderRadius: 8, border: '1px solid #21262D' }}>
              <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 700, letterSpacing: '0.5px', marginBottom: 6 }}>TECHNOLOGY INFO</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #161B22' }}>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Recommended Timeframes</span>
                <span style={{ fontSize: 10, color: '#f59e0b', fontFamily: 'monospace', fontWeight: 700 }}>{meta.recommendedTimeframes.join(', ')}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #161B22' }}>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Optimal Timeframe</span>
                <span style={{ fontSize: 10, color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{meta.optimalTimeframe}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #161B22' }}>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Category</span>
                <span style={{ fontSize: 10, color: '#9ca3af', fontFamily: 'monospace', textTransform: 'capitalize' }}>{meta.category}</span>
              </div>
              <div style={{ marginTop: 6, padding: '6px 8px', background: '#161B22', borderRadius: 4, border: '1px solid #21262D' }}>
                <div style={{ fontSize: 9, color: '#6b7280', fontWeight: 700, marginBottom: 3, letterSpacing: '0.3px' }}>MATHEMATICAL BACKING</div>
                <p style={{ fontSize: 9, color: '#9ca3af', lineHeight: 1.5, margin: 0 }}>{meta.mathematicalBacking}</p>
              </div>
            </div>
          );
        })()}

        <div style={{ marginTop: 12, padding: 10, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 9, color: '#6b7280', textAlign: 'center', margin: 0 }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology. Signals are for informational purposes only.
          </p>
        </div>

        <div data-testid="exchange-disclaimer" style={{ padding: '6px 0', fontSize: 8, color: '#4b5563', lineHeight: 1.4, textAlign: 'center' }}>
          Optimized for: Binance.US, Binance, Coinbase, Kraken, Bybit, OKX, KuCoin, Bitget, Gate.io. Alpha Unlimited Trading provides signals for informational purposes only and assumes no liability for trading decisions. Use at your own risk.
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
