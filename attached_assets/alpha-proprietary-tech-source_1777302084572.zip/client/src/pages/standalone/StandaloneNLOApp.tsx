/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha NLO™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_253010d3297bb298d3c03117
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeNLO, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Wifi } from 'lucide-react';

export default function StandaloneNLOApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="nlo"
        techName="Network Latency Optimizer™"
        techShortName="NLO"
        techColor="#8b5cf6"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="nlo" techName="Network Latency Optimizer™" techColor="#8b5cf6">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <span style={{ display: 'inline-block', padding: '3px 10px', background: '#22c55e22', border: '1px solid #22c55e44', borderRadius: 12, fontSize: 10, color: '#22c55e', fontFamily: 'Orbitron, monospace', letterSpacing: 1, marginBottom: 8 }} data-testid="badge-free">FREE</span>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#8b5cf6', fontSize: 20, marginBottom: 8 }} data-testid="text-title">Network Latency Optimizer™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Mining network health monitoring with block propagation scoring and jitter analysis</p>
        </div>
        <StandaloneShell
          techId="nlo"
          techName="Network Latency Optimizer™"
          techShortName="NLO"
          techDescription="Network health monitoring with propagation scoring and latency jitter analysis"
          techColor="#8b5cf6"
          techIcon={<Wifi size={18} />}
          signalComputer={computeNLO}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => {
            const connectionScore = signal.details.connectionScore ?? 0;
            const healthColor = signal.details.networkHealth === 'optimal' ? '#22c55e' :
                               signal.details.networkHealth === 'acceptable' ? '#eab308' :
                               signal.details.networkHealth === 'degraded' ? '#f97316' : '#ef4444';
            return (
              <>
              <div style={{ fontSize: 11 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#8b5cf6', fontWeight: 700 }}>Network Health</span>
                  <span style={{ color: healthColor, fontFamily: 'monospace', fontWeight: 700 }} data-testid="text-health">{(signal.details.networkHealth || 'unknown').toUpperCase()}</span>
                </div>
                <div style={{ padding: '5px 0', borderBottom: '1px solid #21262D' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                    <span style={{ color: '#6b7280' }}>Connection Score</span>
                    <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-connection-score">{connectionScore}/100</span>
                  </div>
                  <div style={{ height: 4, background: '#21262D', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${connectionScore}%`, height: '100%', background: healthColor, borderRadius: 2, transition: 'width 0.3s' }} />
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Propagation Score</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-propagation">{signal.details.propagationScore ?? 0}/100</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Latency Jitter</span>
                  <span style={{ color: (signal.details.latencyJitter ?? 0) > 20 ? '#ef4444' : '#22c55e', fontFamily: 'monospace' }} data-testid="text-jitter">{signal.details.latencyJitter ?? 'N/A'}%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Spread Health</span>
                  <span style={{ color: signal.details.spreadHealth === 'excellent' ? '#22c55e' : signal.details.spreadHealth === 'good' ? '#eab308' : '#ef4444', fontFamily: 'monospace' }} data-testid="text-spread">{(signal.details.spreadHealth || 'N/A').toUpperCase()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Throughput Index</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.throughputIndex ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Est. Packet Loss</span>
                  <span style={{ color: (signal.details.estimatedPacketLoss ?? 0) > 10 ? '#ef4444' : '#22c55e', fontFamily: 'monospace' }}>{signal.details.estimatedPacketLoss ?? 0}%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Avg Block Interval</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.avgBlockInterval ?? 'N/A'}s</span>
                </div>
                {signal.details.miningNote && (
                  <div style={{ marginTop: 6, padding: '6px 8px', background: '#8b5cf611', borderRadius: 6, border: '1px solid #8b5cf622' }}>
                    <p style={{ color: '#8b5cf6', fontSize: 10, margin: 0 }} data-testid="text-mining-note">{signal.details.miningNote}</p>
                  </div>
                )}
              </div>
              {(() => {
                const wsi = computeWSI(candles);
                const ert = computeERT(candles);
                const mft = computeMFT(candles);
                return (
                  <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                    <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                    {[
                      { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                      { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                      { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                    ].map(s => (
                      <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                        <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                          {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              </>
            );
          }}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center', marginBottom: 4 }}>
            This is a free mining network tool. For advanced trading signals, explore our{' '}
            <a href="/technology-packages" style={{ color: '#FFD700', textDecoration: 'underline' }}>Premium Technologies</a>.
          </p>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
