/**
 * Quantum Flow Resonance Matrix™ (QFRM) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeQFRM, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Waves } from 'lucide-react';

export default function StandaloneQFRMApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="qfrm"
        techName="Quantum Flow Resonance Matrix™"
        techShortName="QFRM"
        techColor="#3b82f6"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="qfrm" techName="Quantum Flow Resonance Matrix™" techColor="#3b82f6">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Quantum Flow Resonance Matrix™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Flow momentum analysis with volume-price correlation and harmonic cycle detection</p>
        </div>
        <StandaloneShell
          techId="qfrm"
          techName="Quantum Flow Resonance Matrix™"
          techShortName="QFRM"
          techDescription="Flow momentum analysis with volume-price correlation and harmonic cycle detection"
          techColor="#3b82f6"
          techIcon={<Waves size={18} />}
          signalComputer={computeQFRM}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#3b82f6', fontWeight: 700 }}>Resonance Score</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Flow Momentum</span>
                <span style={{ color: typeof signal.details.flowMomentum === 'number' && signal.details.flowMomentum > 0 ? '#22c55e' : typeof signal.details.flowMomentum === 'number' && signal.details.flowMomentum < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.flowMomentum === 'number' ? signal.details.flowMomentum.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Volume Correlation</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.vpCorrelation === 'number' ? signal.details.vpCorrelation.toFixed(3) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Harmonic Cycle</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.harmonicScore === 'number' ? signal.details.harmonicScore.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Order Imbalance</span>
                <span style={{ color: typeof signal.details.orderImbalance === 'number' && signal.details.orderImbalance > 0 ? '#22c55e' : typeof signal.details.orderImbalance === 'number' && signal.details.orderImbalance < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.orderImbalance === 'number' ? signal.details.orderImbalance.toFixed(2) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Stability</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.stability === 'number' ? signal.details.stability.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
