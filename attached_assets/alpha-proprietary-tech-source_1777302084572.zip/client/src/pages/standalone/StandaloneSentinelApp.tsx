/**
 * Alpha Sentinel™ - Standalone Rug Pull Detection App
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeSentinel, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { ShieldAlert, AlertTriangle } from 'lucide-react';

function RiskGauge({ probability }: { probability: number }) {
  const clampedProb = Math.max(0, Math.min(100, probability));
  const angle = -90 + (clampedProb / 100) * 180;
  const radians = (angle * Math.PI) / 180;
  const needleX = 100 + 55 * Math.cos(radians);
  const needleY = 100 - 55 * Math.sin(radians);
  const color = clampedProb < 15 ? '#22c55e' : clampedProb < 35 ? '#3b82f6' : clampedProb < 55 ? '#f59e0b' : clampedProb < 75 ? '#f97316' : '#ef4444';
  const label = clampedProb < 15 ? 'SAFE' : clampedProb < 35 ? 'LOW RISK' : clampedProb < 55 ? 'MODERATE' : clampedProb < 75 ? 'HIGH RISK' : 'EXTREME DANGER';

  return (
    <div style={{ textAlign: 'center', marginBottom: 12 }}>
      <svg width="220" height="130" viewBox="0 0 220 130" style={{ margin: '0 auto', display: 'block' }}>
        <defs>
          <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#22c55e" />
            <stop offset="25%" stopColor="#3b82f6" />
            <stop offset="50%" stopColor="#f59e0b" />
            <stop offset="75%" stopColor="#f97316" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>
        <path d="M 20 110 A 90 90 0 0 1 200 110" fill="none" stroke="#161B22" strokeWidth="16" strokeLinecap="round" />
        <path d="M 20 110 A 90 90 0 0 1 200 110" fill="none" stroke="url(#gaugeGrad)" strokeWidth="14" strokeLinecap="round" opacity="0.8" />
        <line x1="110" y1="110" x2={needleX + 10} y2={needleY + 10} stroke={color} strokeWidth="3" strokeLinecap="round" />
        <circle cx="110" cy="110" r="6" fill={color} />
        <circle cx="110" cy="110" r="3" fill="#0D1117" />
        <text x="25" y="125" fill="#6b7280" fontSize="8" fontFamily="monospace">0%</text>
        <text x="185" y="125" fill="#6b7280" fontSize="8" fontFamily="monospace">100%</text>
      </svg>
      <div style={{ fontFamily: 'Orbitron, monospace', fontSize: 28, fontWeight: 900, color, marginTop: -8 }}>
        {clampedProb.toFixed(1)}%
      </div>
      <div style={{ fontSize: 10, color, fontWeight: 700, letterSpacing: '2px', marginTop: 2 }}>
        RUG PULL PROBABILITY: {label}
      </div>
    </div>
  );
}

export default function StandaloneSentinelApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="sentinel"
        techName="Alpha Sentinel™"
        techShortName="SENTINEL"
        techColor="#ef4444"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="sentinel" techName="Alpha Sentinel™" techColor="#ef4444">
      <div style={{ maxWidth: 640, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#ef4444', fontSize: 20, marginBottom: 4 }} data-testid="text-sentinel-title">Alpha Sentinel™</h1>
          <p style={{ color: '#9ca3af', fontSize: 12 }}>14-Dimensional AI-Powered Rug Pull & Bot Detection Early Warning System</p>
          <div style={{ display: 'inline-block', marginTop: 6, padding: '2px 10px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 12, fontSize: 9, color: '#ef4444', fontWeight: 700, letterSpacing: '1px' }}>
            DETECTS RUG PULLS BEFORE THEY HAPPEN
          </div>
        </div>
        <StandaloneShell
          techId="sentinel"
          techName="Alpha Sentinel™"
          techShortName="SENTINEL"
          techDescription="14-Dimensional AI-Powered Rug Pull & Bot Detection with Early Warning System"
          techColor="#ef4444"
          techIcon={<ShieldAlert size={18} />}
          signalComputer={computeSentinel}
          renderDetails={(signal: SignalOutput, _candles: CandleData[]) => (
            <>
            <RiskGauge probability={typeof signal.details.rugPullProbability === 'number' ? signal.details.rugPullProbability : 0} />

            {/* Early Warning Alerts */}
            {Array.isArray(signal.details.earlyWarnings) && signal.details.earlyWarnings.length > 0 && (
              <div style={{ marginBottom: 12, padding: 10, background: signal.details.hasCriticalAlert ? 'rgba(239,68,68,0.12)' : 'rgba(245,158,11,0.10)', border: `1px solid ${signal.details.hasCriticalAlert ? 'rgba(239,68,68,0.4)' : 'rgba(245,158,11,0.3)'}`, borderRadius: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                  <AlertTriangle size={14} color={signal.details.hasCriticalAlert ? '#ef4444' : '#f59e0b'} />
                  <span style={{ fontSize: 10, fontWeight: 700, color: signal.details.hasCriticalAlert ? '#ef4444' : '#f59e0b', letterSpacing: '1px' }}>
                    {signal.details.hasCriticalAlert ? 'CRITICAL ALERTS' : 'EARLY WARNINGS'} ({signal.details.earlyWarnings.length})
                  </span>
                </div>
                {signal.details.earlyWarnings.map((w: string, i: number) => (
                  <div key={i} style={{ fontSize: 10, color: '#e5e7eb', padding: '3px 0', borderTop: i > 0 ? '1px solid rgba(255,255,255,0.05)' : 'none', display: 'flex', gap: 6, alignItems: 'flex-start' }} data-testid={`text-sentinel-warning-${i}`}>
                    <span style={{ color: signal.details.hasCriticalAlert ? '#ef4444' : '#f59e0b', flexShrink: 0 }}>!</span>
                    <span>{w}</span>
                  </div>
                ))}
              </div>
            )}

            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#ef4444', fontWeight: 700 }}>Risk Level</span>
                <span data-testid="text-sentinel-risk-level" style={{
                  color: signal.details.riskLevel === 'SAFE' ? '#22c55e' : signal.details.riskLevel === 'LOW' ? '#3b82f6' : signal.details.riskLevel === 'MODERATE' ? '#f59e0b' : signal.details.riskLevel === 'HIGH' ? '#f97316' : '#ef4444',
                  fontFamily: 'monospace', fontWeight: 700
                }}>
                  {signal.details.riskLevel === 'SAFE' ? '✓ SAFE' : signal.details.riskLevel === 'LOW' ? '○ LOW RISK' : signal.details.riskLevel === 'MODERATE' ? '⚠ MODERATE' : signal.details.riskLevel === 'HIGH' ? '▲ HIGH RISK' : '⛔ EXTREME'}
                </span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Analysis Dimensions</span>
                <span style={{ color: '#9ca3af', fontFamily: 'monospace' }}>{signal.details.dimensionCount || 12} active</span>
              </div>

              <div style={{ fontSize: 10, color: '#ef4444', marginTop: 12, marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>12 RISK DIMENSIONS</div>

              {[
                { label: 'Liquidity Depth', key: 'liquidityScore', desc: 'Thin liquidity = easy to dump and drain', icon: '💧' },
                { label: 'Volume Authenticity', key: 'volumeAuthenticityScore', desc: 'Benford\'s Law + entropy wash trading detection', icon: '🔍' },
                { label: 'Pump & Dump Pattern', key: 'pumpDetected', numKey: 'maxPumpGain', desc: 'Rapid price inflation with volume decline', icon: '📈' },
                { label: 'Holder Concentration', key: 'holderConcentrationRisk', desc: 'HHI + Gini coefficient whale dominance', icon: '🐋' },
                { label: 'Contract Risk Proxy', key: 'contractRiskScore', desc: 'Price-volume correlation anomalies', icon: '📜' },
                { label: 'Honeypot Detection', key: 'honeypotScore', desc: 'Sell-side suppression & buy/sell imbalance', icon: '🍯' },
                { label: 'Liquidity Drain Speed', key: 'liquidityDrainScore', desc: 'Volume draining before price collapses', icon: '🚰' },
                { label: 'Insider Trading', key: 'insiderScore', desc: 'Volume spikes preceding major price moves', icon: '🕵️' },
                { label: 'Wash Trading', key: 'washTradeScore', desc: 'Identical price-volume pairs = bot activity', icon: '🔄' },
                { label: 'Stability Illusion', key: 'stabilityScore', desc: 'Artificial calm masking extreme tail risk', icon: '🎭' },
                { label: 'Social Media Pump', key: 'socialPumpScore', desc: 'Price surge without volume conviction', icon: '📢' },
                { label: 'Momentum Divergence', key: 'momentumDivergenceScore', desc: 'RSI + OBV divergence = early rug warning', icon: '⚡' },
                { label: 'Spam Bot Detection', key: 'spamBotScore', desc: 'Rapid-fire trades, uniform intervals, identical amounts', icon: '🤖' },
                { label: 'Coordinated Bot Network', key: 'coordinatedBotScore', desc: 'Multi-wallet sync bursts, mirror patterns, round-number clustering', icon: '🕸️' },
              ].map(dim => {
                const val = dim.numKey ? signal.details[dim.numKey] : signal.details[dim.key];
                const displayVal = signal.details[dim.key];
                const numVal = typeof displayVal === 'number' ? displayVal : (displayVal === true ? 100 : 0);
                const barColor = numVal < 25 ? '#22c55e' : numVal < 50 ? '#f59e0b' : numVal < 75 ? '#f97316' : '#ef4444';
                const isBool = dim.key === 'pumpDetected';
                return (
                  <div key={dim.key} style={{ marginBottom: 6 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                      <span style={{ color: '#9ca3af', fontSize: 10 }}>{dim.icon} {dim.label}</span>
                      <span style={{ color: barColor, fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-sentinel-${dim.key}`}>
                        {isBool
                          ? (signal.details.pumpDetected ? `DETECTED (${typeof signal.details.maxPumpGain === 'number' ? signal.details.maxPumpGain.toFixed(1) : 0}% gain)` : 'CLEAN')
                          : (typeof displayVal === 'number' ? displayVal.toFixed(1) + '%' : 'N/A')}
                      </span>
                    </div>
                    <div style={{ height: 3, background: '#21262D', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${Math.min(numVal, 100)}%`, background: barColor, borderRadius: 2, transition: 'width 0.5s ease' }} />
                    </div>
                    <div style={{ fontSize: 8, color: '#4b5563', marginTop: 1 }}>{dim.desc}</div>
                  </div>
                );
              })}

              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderTop: '1px solid #30363D', marginTop: 8 }}>
                <span style={{ color: '#6b7280', fontWeight: 700 }}>Overall Risk Score</span>
                <span data-testid="text-sentinel-overall" style={{
                  color: signal.details.overallScore < 25 ? '#22c55e' : signal.details.overallScore < 50 ? '#f59e0b' : '#ef4444',
                  fontFamily: 'monospace', fontWeight: 700
                }}>{typeof signal.details.overallScore === 'number' ? signal.details.overallScore + '/100' : 'N/A'}</span>
              </div>

              {signal.details.hasCriticalAlert && (
                <div style={{ marginTop: 8, padding: 8, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 6, textAlign: 'center' }}>
                  <span style={{ fontSize: 10, color: '#ef4444', fontWeight: 700 }}>CRITICAL ALERT MULTIPLIER ACTIVE</span>
                  <div style={{ fontSize: 9, color: '#9ca3af', marginTop: 2 }}>One or more risk dimensions exceeded 80% threshold — overall risk amplified by 1.3x</div>
                </div>
              )}
            </div>
            </>
          )}
        />

        <div style={{ marginTop: 12, padding: 10, background: 'linear-gradient(135deg, rgba(239,68,68,0.05), rgba(239,68,68,0.1), rgba(239,68,68,0.05))', borderRadius: 8, border: '1px solid rgba(239,68,68,0.2)' }}>
          <p style={{ fontSize: 10, color: '#ef4444', textAlign: 'center', fontWeight: 700, marginBottom: 4 }}>
            SUPERIOR TO GMGN — 12 Risk Dimensions vs Their 6
          </p>
          <div style={{ fontSize: 9, color: '#6b7280', textAlign: 'center', lineHeight: '1.5' }}>
            Alpha Sentinel™ adds Honeypot Detection, Liquidity Drain Velocity, Insider Trading Patterns, Wash Trading Analysis,
            Stability Illusion Detection, Social Media Pump Proxy, and Early Warning Momentum Divergence — detecting rug pulls
            before they happen, not just flagging them after.
          </div>
        </div>

        <div style={{ marginTop: 8, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
