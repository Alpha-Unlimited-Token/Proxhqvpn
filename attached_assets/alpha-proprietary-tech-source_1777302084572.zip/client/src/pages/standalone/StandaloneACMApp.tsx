/**
 * Alpha Convergence Matrix™ (ACM) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeACM, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Target } from 'lucide-react';

export default function StandaloneACMApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="acm"
        techName="Alpha Convergence Matrix™"
        techShortName="ACM"
        techColor="#22c55e"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="acm" techName="Alpha Convergence Matrix™" techColor="#22c55e">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Alpha Convergence Matrix™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Multi-indicator convergence analysis with RSI, MACD, Bollinger Bands, and OBV tracking</p>
        </div>
        <StandaloneShell
          techId="acm"
          techName="Alpha Convergence Matrix™"
          techShortName="ACM"
          techDescription="Multi-indicator convergence analysis with RSI, MACD, Bollinger Bands, and OBV tracking"
          techColor="#22c55e"
          techIcon={<Target size={18} />}
          signalComputer={computeACM}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#22c55e', fontWeight: 700 }}>Convergence Count</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{signal.details.bullCount ?? 0} Bull / {signal.details.bearCount ?? 0} Bear</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>RSI Value</span>
                <span style={{ color: typeof signal.details.rsi === 'number' && signal.details.rsi < 30 ? '#22c55e' : typeof signal.details.rsi === 'number' && signal.details.rsi > 70 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rsi === 'number' ? signal.details.rsi.toFixed(1) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>MACD Histogram</span>
                <span style={{ color: signal.details.macd?.histogram > 0 ? '#22c55e' : signal.details.macd?.histogram < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.macd?.histogram === 'number' ? signal.details.macd.histogram.toFixed(4) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Bollinger Width</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.bbWidth === 'number' ? signal.details.bbWidth.toFixed(2) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>OBV Trend</span>
                <span style={{ color: signal.details.obvTrend === 'up' ? '#22c55e' : '#ef4444', fontFamily: 'monospace' }}>{signal.details.obvTrend === 'up' ? '▲ Bullish' : '▼ Bearish'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Raw Score</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
