/**
 * 8 Advanced Market Filters™ Pack - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeFilters, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Filter } from 'lucide-react';

const FILTER_LABELS: Record<string, { abbr: string; name: string }> = {
  ofi: { abbr: 'OFI', name: 'Order Flow Imbalance' },
  fvg: { abbr: 'FVG', name: 'Fair Value Gap' },
  abs: { abbr: 'ABS', name: 'Absorption' },
  fe: { abbr: 'FE', name: 'Fibonacci Extension' },
  wyk: { abbr: 'WYK', name: 'Wyckoff' },
  ent: { abbr: 'ENT', name: 'Entropy' },
  hur: { abbr: 'HUR', name: 'Hurst' },
  dd: { abbr: 'DD', name: 'Drawdown' },
};

function getSignalColor(signal: string): string {
  if (signal === 'strong_buy' || signal === 'buy') return '#22c55e';
  if (signal === 'strong_sell' || signal === 'sell') return '#ef4444';
  return '#6b7280';
}

function getSignalArrow(signal: string): string {
  if (signal === 'strong_buy') return '▲▲';
  if (signal === 'buy') return '▲';
  if (signal === 'strong_sell') return '▼▼';
  if (signal === 'sell') return '▼';
  return '—';
}

export default function StandaloneFiltersApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="filters_pack"
        techName="8 Advanced Market Filters™ — Bearish Lean Confirmation"
        techShortName="Filters"
        techColor="#eab308"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="filters_pack" techName="8 Advanced Market Filters™ — Bearish Lean Confirmation" techColor="#eab308">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>8 Advanced Market Filters™ — Bearish Lean Confirmation</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Bearish lean confirmation layer — validates sell signals from other technologies using 8 microstructure filters</p>
        </div>
        <div data-testid="filters-info-banner" style={{ marginBottom: 16, padding: '10px 14px', background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)', borderRadius: 8, border: '1px solid #eab30833' }}>
          <p style={{ fontSize: 11, color: '#d1d5db', lineHeight: 1.5, margin: 0 }}>
            <span style={{ color: '#eab308', fontWeight: 700 }}>⚡ Confirmation Layer:</span>{' '}
            Filters works best as a confirmation layer. When other technologies (MFT, ACM, ERT) generate sell signals, the Filters bearish lean validates and strengthens those signals — achieving up to 56.5% holdout accuracy across 48 cryptocurrencies.
          </p>
        </div>
        <StandaloneShell
          techId="filters_pack"
          techName="8 Advanced Market Filters™ — Bearish Lean Confirmation"
          techShortName="Filters"
          techDescription="Bearish lean confirmation layer — validates sell signals from other technologies using 8 microstructure filters"
          techColor="#eab308"
          techIcon={<Filter size={18} />}
          signalComputer={(candles, exchangeId) => computeFilters(candles, exchangeId)}
          renderDetails={(signal: SignalOutput, candles: CandleData[], fullResult?: any) => {
            const individual = fullResult?.individual || {};
            return (
              <>
              <div style={{ fontSize: 11 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D', marginBottom: 6 }}>
                  <span style={{ color: '#eab308', fontWeight: 700 }}>Bearish Lean Score</span>
                  <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore : 'N/A'}</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
                  {Object.entries(FILTER_LABELS).map(([key, { abbr, name }]) => {
                    const filterSignal = individual[key];
                    if (!filterSignal) return null;
                    const color = getSignalColor(filterSignal.signal);
                    const arrow = getSignalArrow(filterSignal.signal);
                    return (
                      <div key={key} data-testid={`filter-signal-${key}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 8px', background: '#161B22', borderRadius: 4, border: `1px solid ${color}22` }}>
                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                          <span style={{ color: '#e5e7eb', fontWeight: 700, fontSize: 10 }}>{abbr}</span>
                          <span style={{ color: '#6b7280', fontSize: 8 }}>{name}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <span style={{ color, fontFamily: 'monospace', fontSize: 12 }}>{arrow}</span>
                          <span style={{ color, fontFamily: 'monospace', fontWeight: 700, fontSize: 10 }}>{filterSignal.strength}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              {(() => {
                const wsi = computeWSI(candles);
                const ert = computeERT(candles);
                const mft = computeMFT(candles);
                return (
                  <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                    <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                    {[
                      { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                      { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                      { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                    ].map(s => (
                      <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                        <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                          {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              </>
            );
          }}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
