/**
 * Temporal Momentum Divergence Engine™ (TMDE) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeTMDE, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Clock } from 'lucide-react';

const DIVERGENCE_COLORS: Record<string, string> = {
  alignment_cascade: '#22c55e',
  expansion: '#eab308',
  compression: '#ef4444',
  neutral: '#9ca3af',
};

const DIVERGENCE_LABELS: Record<string, string> = {
  alignment_cascade: 'Alignment Cascade',
  expansion: 'Expansion',
  compression: 'Compression',
  neutral: 'Neutral',
};

const TIMEFRAME_LABELS: Record<string, string> = {
  fast: 'Fast (5)',
  medium: 'Medium (15)',
  slow: 'Slow (30)',
  extraSlow: 'Extra Slow (50)',
};

export default function StandaloneTMDEApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="tmde"
        techName="Temporal Momentum Divergence Engine™"
        techShortName="TMDE"
        techColor="#06b6d4"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="tmde" techName="Temporal Momentum Divergence Engine™" techColor="#06b6d4">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Temporal Momentum Divergence Engine™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Multi-timeframe momentum cascade analysis with divergence classification</p>
        </div>
        <StandaloneShell
          techId="tmde"
          techName="Temporal Momentum Divergence Engine™"
          techShortName="TMDE"
          techDescription="Multi-timeframe momentum cascade analysis with divergence classification"
          techColor="#06b6d4"
          techIcon={<Clock size={18} />}
          signalComputer={computeTMDE}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => {
            const divType = signal.details.divergenceType as string || 'neutral';
            return (
              <>
              <div style={{ fontSize: 11 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#06b6d4', fontWeight: 700 }}>Cascade Classification</span>
                  <span style={{ color: DIVERGENCE_COLORS[divType] || '#9ca3af', fontFamily: 'monospace', fontWeight: 700 }}>{DIVERGENCE_LABELS[divType] || divType}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Timeframe Agreement</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.timeframeAgreement === 'number' ? signal.details.timeframeAgreement.toFixed(0) : 'N/A'}%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Momentum Velocity</span>
                  <span style={{ color: typeof signal.details.momentumVelocity === 'number' && signal.details.momentumVelocity > 0 ? '#22c55e' : typeof signal.details.momentumVelocity === 'number' && signal.details.momentumVelocity < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.momentumVelocity === 'number' ? signal.details.momentumVelocity.toFixed(2) : 'N/A'}</span>
                </div>
                {signal.details.timeframes && typeof signal.details.timeframes === 'object' && (
                  <>
                    <div style={{ padding: '6px 0 3px', color: '#06b6d4', fontWeight: 600, fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>Timeframe Signals</div>
                    {Object.entries(signal.details.timeframes as Record<string, string>).map(([key, val]) => (
                      <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: '#6b7280' }}>{TIMEFRAME_LABELS[key] || key}</span>
                        <span style={{ color: val === 'bullish' ? '#22c55e' : val === 'bearish' ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontWeight: 600 }}>{String(val).toUpperCase()}</span>
                      </div>
                    ))}
                  </>
                )}
                {signal.details.momentums && typeof signal.details.momentums === 'object' && (
                  <>
                    <div style={{ padding: '6px 0 3px', color: '#06b6d4', fontWeight: 600, fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>Momentum Values</div>
                    {Object.entries(signal.details.momentums as Record<string, number>).map(([key, val]) => (
                      <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: '#6b7280' }}>{TIMEFRAME_LABELS[key] || key}</span>
                        <span style={{ color: typeof val === 'number' && val > 0 ? '#22c55e' : typeof val === 'number' && val < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof val === 'number' ? val.toFixed(3) : String(val)}</span>
                      </div>
                    ))}
                  </>
                )}
              </div>
              {(() => {
                const wsi = computeWSI(candles);
                const ert = computeERT(candles);
                const mft = computeMFT(candles);
                return (
                  <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                    <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                    {[
                      { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                      { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                      { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                    ].map(s => (
                      <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                        <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                          {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              </>
            );
          }}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
