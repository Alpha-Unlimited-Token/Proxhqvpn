/**
 * Head & Shoulders Detector™ (H/S) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeHS, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Users } from 'lucide-react';

export default function StandaloneHSApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="hs"
        techName="Head & Shoulders Detector™"
        techShortName="H/S"
        techColor="#E11D48"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="hs" techName="Head & Shoulders Detector™" techColor="#E11D48">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Head & Shoulders Detector™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Identifies Head & Shoulders formations on charts — pattern recognition only</p>
        </div>
        <StandaloneShell
          techId="hs"
          techName="Head & Shoulders Detector™"
          techShortName="H/S"
          techDescription="Identifies Head & Shoulders formations on the chart — pattern recognition only, no buy/sell signals"
          techColor="#E11D48"
          techIcon={<Users size={18} />}
          signalComputer={computeHS}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span data-testid="text-hs-pattern-label" style={{ color: '#E11D48', fontWeight: 700 }}>Pattern</span>
                <span data-testid="text-hs-pattern-value" style={{ color: signal.details.patternDetected ? '#A78BFA' : '#6b7280', fontFamily: 'monospace', fontWeight: 700 }}>
                  {signal.details.patternDetected ? signal.details.patternType : 'NO PATTERN DETECTED'}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Status</span>
                <span data-testid="text-hs-breakout" style={{ color: signal.details.status === 'NECKLINE BROKEN' ? '#A78BFA' : signal.details.status === 'TESTING NECKLINE' ? '#f59e0b' : '#9ca3af', fontFamily: 'monospace', fontWeight: 600 }}>
                  {signal.details.status || 'N/A'}
                </span>
              </div>
              {signal.details.patternDetected && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Head Price</span>
                    <span data-testid="text-hs-head-price" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>${signal.details.headPrice?.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Left Shoulder</span>
                    <span data-testid="text-hs-ls-price" style={{ color: '#f59e0b', fontFamily: 'monospace' }}>${signal.details.leftShoulderPrice?.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Right Shoulder</span>
                    <span data-testid="text-hs-rs-price" style={{ color: '#f59e0b', fontFamily: 'monospace' }}>${signal.details.rightShoulderPrice?.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Neckline</span>
                    <span data-testid="text-hs-neckline" style={{ color: '#FFD700', fontFamily: 'monospace' }}>${signal.details.necklinePrice?.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Shoulder Symmetry</span>
                    <span data-testid="text-hs-symmetry" style={{ color: signal.details.shoulderSymmetry > 90 ? '#22c55e' : signal.details.shoulderSymmetry > 80 ? '#f59e0b' : '#ef4444', fontFamily: 'monospace' }}>{signal.details.shoulderSymmetry}%</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                    <span style={{ color: '#6b7280' }}>Volume Profile</span>
                    <span data-testid="text-hs-volume" style={{ color: signal.details.volumeProfile === 'declining' ? '#22c55e' : '#f59e0b', fontFamily: 'monospace' }}>
                      {signal.details.volumeProfile === 'declining' ? '📉 Declining (Ideal)' : signal.details.volumeProfile === 'increasing' ? '📈 Increasing' : '➡️ Mixed'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0' }}>
                    <span style={{ color: '#6b7280' }}>Time Symmetry</span>
                    <span data-testid="text-hs-time-sym" style={{ color: signal.details.timeSymmetry > 70 ? '#22c55e' : '#f59e0b', fontFamily: 'monospace' }}>{signal.details.timeSymmetry}%</span>
                  </div>
                </>
              )}
            </div>
          )}
        />
        <div style={{ marginTop: 12, padding: 10, background: 'linear-gradient(135deg, rgba(225,29,72,0.05), rgba(225,29,72,0.1), rgba(225,29,72,0.05))', borderRadius: 8, border: '1px solid rgba(225,29,72,0.2)' }}>
          <p style={{ fontSize: 10, color: '#E11D48', textAlign: 'center', fontWeight: 700, marginBottom: 2 }}>
            Pattern identification only — H/S does not generate buy or sell signals
          </p>
          <p style={{ fontSize: 9, color: '#6b7280', textAlign: 'center' }}>
            Head & Shoulders Detector™ uses multi-resolution pivot detection, volume profile analysis, shoulder symmetry scoring, and neckline slope tracking to identify the classic H&S formation
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
