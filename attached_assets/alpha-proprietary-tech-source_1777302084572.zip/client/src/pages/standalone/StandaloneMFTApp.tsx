/**
 * Micro-Structure Fractal Trap™ (MFT) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Target } from 'lucide-react';

export default function StandaloneMFTApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="mft"
        techName="Micro-Structure Fractal Trap™"
        techShortName="MFT"
        techColor="#FF6B35"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="mft" techName="Micro-Structure Fractal Trap™" techColor="#FF6B35">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Micro-Structure Fractal Trap™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Smart money trap detection via contradictory micro-pattern analysis</p>
        </div>
        <StandaloneShell
          techId="mft"
          techName="Micro-Structure Fractal Trap™"
          techShortName="MFT"
          techDescription="Smart money trap detection via contradictory micro-pattern analysis"
          techColor="#FF6B35"
          techIcon={<Target size={18} />}
          signalComputer={computeMFT}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span data-testid="text-mft-trap-label" style={{ color: '#FF6B35', fontWeight: 700 }}>Trap Type</span>
                <span data-testid="text-mft-trap-value" style={{ color: signal.details.trapType === 'bull_trap' ? '#ef4444' : signal.details.trapType === 'bear_trap' ? '#22c55e' : '#f59e0b', fontFamily: 'monospace', fontWeight: 700 }}>{signal.details.trapType === 'bull_trap' ? '🐂 BULL TRAP (Bearish)' : signal.details.trapType === 'bear_trap' ? '🐻 BEAR TRAP (Bullish)' : 'NO TRAP DETECTED'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Low Pattern</span>
                <span data-testid="text-mft-low-pattern" style={{ color: signal.details.lowPattern === 'higher_lows' ? '#22c55e' : signal.details.lowPattern === 'lower_lows' ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.lowPattern === 'higher_lows' ? '▲ Higher Lows' : signal.details.lowPattern === 'lower_lows' ? '▼ Lower Lows' : 'Mixed'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>High Pattern</span>
                <span data-testid="text-mft-high-pattern" style={{ color: signal.details.highPattern === 'higher_highs' ? '#22c55e' : signal.details.highPattern === 'lower_highs' ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.highPattern === 'higher_highs' ? '▲ Higher Highs' : signal.details.highPattern === 'lower_highs' ? '▼ Lower Highs' : 'Mixed'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Close Pattern</span>
                <span data-testid="text-mft-close-pattern" style={{ color: signal.details.closePattern === 'higher_closes' ? '#22c55e' : signal.details.closePattern === 'lower_closes' ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.closePattern === 'higher_closes' ? '▲ Higher Closes' : signal.details.closePattern === 'lower_closes' ? '▼ Lower Closes' : 'Mixed'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Raw Score</span>
                <span data-testid="text-mft-raw-score" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
          )}
        />
        <div style={{ marginTop: 12, padding: 10, background: 'linear-gradient(135deg, rgba(34,197,94,0.05), rgba(34,197,94,0.1), rgba(34,197,94,0.05))', borderRadius: 8, border: '1px solid rgba(34,197,94,0.2)' }}>
          <p style={{ fontSize: 10, color: '#22c55e', textAlign: 'center', fontWeight: 700, marginBottom: 2 }}>
            This signal is included as a free bonus cross-reference in all proprietary technology apps
          </p>
          <p style={{ fontSize: 9, color: '#6b7280', textAlign: 'center' }}>
            ACM, QFRM, BIF, SBPE, ANCE, ANCE², TMDE, QMGE, Bridge Fusion &amp; more — MFT appears automatically as supplementary data
          </p>
        </div>
        <div style={{ marginTop: 8, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
