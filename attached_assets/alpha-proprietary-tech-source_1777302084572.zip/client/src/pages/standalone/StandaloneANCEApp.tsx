/**
 * Adaptive Neural Confluence Engine™ (ANCE) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeANCE, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Brain } from 'lucide-react';

const LAYER_LABELS: Record<string, string> = {
  priceAction: 'Price Action',
  momentum: 'Momentum',
  volume: 'Volume Analysis',
  volatility: 'Volatility',
  trendStrength: 'Trend Strength',
  supportResistance: 'Support / Resistance',
  sentiment: 'Sentiment',
};

export default function StandaloneANCEApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="ance"
        techName="Adaptive Neural Confluence Engine™"
        techShortName="ANCE"
        techColor="#8B5CF6"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="ance" techName="Adaptive Neural Confluence Engine™" techColor="#8B5CF6">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Adaptive Neural Confluence Engine™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>7-layer neural analysis combining price action, momentum, volume, volatility, trend, S/R, and sentiment</p>
        </div>
        <StandaloneShell
          techId="ance"
          techName="Adaptive Neural Confluence Engine™"
          techShortName="ANCE"
          techDescription="7-layer neural analysis combining price action, momentum, volume, volatility, trend, S/R, and sentiment"
          techColor="#8B5CF6"
          techIcon={<Brain size={18} />}
          signalComputer={computeANCE}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#8B5CF6', fontWeight: 700 }}>Composite Score</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{typeof signal.details.composite === 'number' ? signal.details.composite.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>RSI</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rsi === 'number' ? signal.details.rsi.toFixed(1) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>ADX Proxy</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.adxProxy === 'number' ? signal.details.adxProxy.toFixed(1) : 'N/A'}</span>
              </div>
              {signal.details.layers && typeof signal.details.layers === 'object' && (
                <>
                  <div style={{ padding: '6px 0 3px', color: '#8B5CF6', fontWeight: 600, fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>7-Layer Scores</div>
                  {Object.entries(signal.details.layers as Record<string, number>).map(([key, val]) => (
                    <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: '#6b7280' }}>{LAYER_LABELS[key] || key}</span>
                      <span style={{ color: typeof val === 'number' && val > 0 ? '#22c55e' : typeof val === 'number' && val < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof val === 'number' ? val.toFixed(2) : String(val)}</span>
                    </div>
                  ))}
                </>
              )}
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
