/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha MemeCoinScanner™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_b5b8438bf0ef47bd3460678f
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState, useEffect, useCallback, useRef } from 'react';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Scan, RefreshCw, TrendingUp, TrendingDown, AlertTriangle, Search, ChevronDown, ChevronUp, ArrowUpDown, Shield, ExternalLink, Zap, BarChart3, Activity, Eye } from 'lucide-react';

interface CoinData {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  marketCap: number;
  totalVolume: number;
  priceChange1h: number;
  priceChange24h: number;
  priceChange7d: number;
  volumeToMcap: number;
  volatility: number;
  potentialScore: number;
  potentialRange: { low: number; high: number };
  riskLevel: string;
  sparkline: number[];
  marketCapRank: number;
  ath: number;
  athChangePercentage: number;
}

interface ScanResult {
  coins: CoinData[];
  lastUpdated: number;
  disclaimer: string;
}

type SortField = 'potentialScore' | 'priceChange24h' | 'priceChange7d' | 'totalVolume' | 'volatility' | 'currentPrice';

function MiniSparkline({ data, color, width = 120, height = 32 }: { data: number[]; color: string; width?: number; height?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || data.length < 2) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = width * 2;
    canvas.height = height * 2;
    ctx.scale(2, 2);
    ctx.clearRect(0, 0, width, height);
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const step = width / (data.length - 1);
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    data.forEach((v, i) => {
      const x = i * step;
      const y = height - ((v - min) / range) * (height - 4) - 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }, [data, color, width, height]);
  return <canvas ref={canvasRef} style={{ width, height }} />;
}

function formatPrice(price: number): string {
  if (price >= 1) return '$' + price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (price >= 0.01) return '$' + price.toFixed(4);
  if (price >= 0.0001) return '$' + price.toFixed(6);
  return '$' + price.toFixed(8);
}

function formatVolume(vol: number): string {
  if (vol >= 1e9) return '$' + (vol / 1e9).toFixed(2) + 'B';
  if (vol >= 1e6) return '$' + (vol / 1e6).toFixed(2) + 'M';
  if (vol >= 1e3) return '$' + (vol / 1e3).toFixed(1) + 'K';
  return '$' + vol.toFixed(0);
}

function formatMarketCap(mc: number): string {
  if (mc >= 1e9) return '$' + (mc / 1e9).toFixed(2) + 'B';
  if (mc >= 1e6) return '$' + (mc / 1e6).toFixed(1) + 'M';
  if (mc >= 1e3) return '$' + (mc / 1e3).toFixed(0) + 'K';
  return '$' + mc.toFixed(0);
}

function PotentialBadge({ score, range }: { score: number; range: { low: number; high: number } }) {
  let bg = '#1a1a2e';
  let border = '#333';
  let textColor = '#9ca3af';
  if (score >= 70) { bg = '#0f2e1a'; border = '#22c55e'; textColor = '#22c55e'; }
  else if (score >= 55) { bg = '#2e2a0f'; border = '#eab308'; textColor = '#eab308'; }
  else if (score >= 40) { bg = '#2e1f0f'; border = '#f97316'; textColor = '#f97316'; }
  else { bg = '#2e0f0f'; border = '#ef4444'; textColor = '#ef4444'; }

  return (
    <div style={{ background: bg, border: `1px solid ${border}`, borderRadius: 8, padding: '6px 10px', textAlign: 'center' }}>
      <div style={{ color: textColor, fontFamily: 'Orbitron, monospace', fontSize: 18, fontWeight: 700 }}>{score}</div>
      <div style={{ color: '#6b7280', fontSize: 9, marginTop: 2 }}>POTENTIAL</div>
      <div style={{ color: textColor, fontSize: 10, fontWeight: 600, marginTop: 2 }}>
        {range.low > 0 ? '+' : ''}{range.low}% to +{range.high}%
      </div>
    </div>
  );
}

function RiskBadge({ level }: { level: string }) {
  const colors: Record<string, { bg: string; text: string; label: string }> = {
    extreme: { bg: '#3b0f0f', text: '#ef4444', label: 'EXTREME RISK' },
    high: { bg: '#2e1f0f', text: '#f97316', label: 'HIGH RISK' },
    medium: { bg: '#2e2a0f', text: '#eab308', label: 'MEDIUM RISK' },
    low: { bg: '#0f2e1a', text: '#22c55e', label: 'LOWER RISK' },
  };
  const c = colors[level] || colors.high;
  return (
    <span style={{ background: c.bg, color: c.text, fontSize: 9, fontWeight: 700, padding: '2px 6px', borderRadius: 4, letterSpacing: 1 }}>
      {c.label}
    </span>
  );
}

function ChangeCell({ value }: { value: number }) {
  const positive = value > 0;
  const color = positive ? '#22c55e' : value < 0 ? '#ef4444' : '#6b7280';
  return (
    <span style={{ color, fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>
      {positive ? '+' : ''}{value.toFixed(2)}%
    </span>
  );
}

function MemeCoinScannerContent() {
  const [data, setData] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('potentialScore');
  const [sortAsc, setSortAsc] = useState(false);
  const [expandedCoin, setExpandedCoin] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = useCallback(async (forceRefresh = false) => {
    setLoading(!data);
    setRefreshing(!!data);
    setError(null);
    try {
      const url = '/api/meme-coin-scanner' + (forceRefresh ? '?_t=' + Date.now() : '');
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch scanner data');
      const result = await res.json();
      setData(result);
      setLastRefresh(new Date());
    } catch (e: any) {
      setError(e.message || 'Connection error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [data]);

  useEffect(() => { fetchData(); }, []);

  const handleRefresh = () => {
    mcsCache_bust++;
    fetchData(true);
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) setSortAsc(!sortAsc);
    else { setSortField(field); setSortAsc(false); }
  };

  const filteredCoins = (data?.coins || [])
    .filter(c => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.symbol.toLowerCase().includes(q);
    })
    .sort((a, b) => {
      const mult = sortAsc ? 1 : -1;
      return ((a[sortField] as number) - (b[sortField] as number)) * mult;
    });

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px 16px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #0D1117 0%, #1a0a2e 50%, #0D1117 100%)',
        border: '1px solid #a855f7',
        borderRadius: 16,
        padding: '24px',
        marginBottom: 20,
        textAlign: 'center'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginBottom: 8 }}>
          <Scan size={28} color="#a855f7" />
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 22, margin: 0 }}>
            Meme Coin Scanner™
          </h1>
        </div>
        <p style={{ color: '#9ca3af', fontSize: 13, margin: '8px 0 0' }}>
          Real-Time Meme Coin Discovery & Potential Analysis Engine
        </p>
      </div>

      <div style={{
        background: '#1a0f0f',
        border: '1px solid #ef4444',
        borderRadius: 12,
        padding: '14px 18px',
        marginBottom: 20,
        display: 'flex',
        alignItems: 'flex-start',
        gap: 12
      }}>
        <AlertTriangle size={20} color="#ef4444" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div style={{ color: '#ef4444', fontWeight: 700, fontSize: 12, marginBottom: 4 }}>DISCLAIMER - FOR EDUCATIONAL PURPOSES ONLY</div>
          <div style={{ color: '#d4a0a0', fontSize: 11, lineHeight: 1.5 }}>
            This tool is NOT financial advice. All potential scores and percentage ranges shown are based on mathematical analysis of historical market data and do NOT guarantee future performance. Cryptocurrency investments carry EXTREME risk. Meme coins are especially volatile and most lose significant value. Never invest more than you can afford to lose. Always do your own research (DYOR). Alpha Unlimited Trading is not responsible for any financial decisions made based on this educational tool.
          </div>
        </div>
      </div>

      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: 12,
        alignItems: 'center',
        marginBottom: 20
      }}>
        <div style={{ position: 'relative', flex: '1 1 250px', minWidth: 200 }}>
          <Search size={16} color="#6b7280" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
          <input
            data-testid="input-mcs-search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by name or symbol..."
            style={{
              width: '100%',
              background: '#161B22',
              border: '1px solid #30363D',
              borderRadius: 8,
              padding: '10px 12px 10px 36px',
              color: '#e6edf3',
              fontSize: 13,
              outline: 'none',
              boxSizing: 'border-box'
            }}
          />
        </div>
        <button
          data-testid="button-mcs-refresh"
          onClick={handleRefresh}
          disabled={refreshing || loading}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            background: refreshing ? '#1a1a2e' : 'linear-gradient(135deg, #a855f7, #7c3aed)',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            padding: '10px 20px',
            fontFamily: 'Orbitron, monospace',
            fontSize: 12,
            fontWeight: 700,
            cursor: refreshing ? 'not-allowed' : 'pointer',
            opacity: refreshing ? 0.6 : 1,
          }}
        >
          <RefreshCw size={16} style={{ animation: refreshing ? 'spin 1s linear infinite' : 'none' }} />
          {refreshing ? 'SCANNING...' : 'REFRESH SCAN'}
        </button>
        {lastRefresh && (
          <span style={{ color: '#6b7280', fontSize: 11 }}>
            Last scan: {lastRefresh.toLocaleTimeString()}
          </span>
        )}
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
        gap: 10,
        marginBottom: 20
      }}>
        {[
          { label: 'Total Scanned', value: data?.coins?.length || 0, color: '#a855f7', icon: Scan },
          { label: 'High Potential', value: filteredCoins.filter(c => c.potentialScore >= 60).length, color: '#22c55e', icon: TrendingUp },
          { label: 'Trending Up', value: filteredCoins.filter(c => c.priceChange24h > 0).length, color: '#3b82f6', icon: Zap },
          { label: 'High Volume', value: filteredCoins.filter(c => c.volumeToMcap > 0.2).length, color: '#eab308', icon: BarChart3 },
        ].map(s => (
          <div key={s.label} style={{
            background: '#161B22',
            border: '1px solid #30363D',
            borderRadius: 10,
            padding: '14px 16px',
            textAlign: 'center'
          }}>
            <s.icon size={18} color={s.color} style={{ marginBottom: 4 }} />
            <div style={{ color: s.color, fontFamily: 'Orbitron, monospace', fontSize: 20, fontWeight: 700 }}>{s.value}</div>
            <div style={{ color: '#6b7280', fontSize: 10 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {loading && !data && (
        <div style={{ textAlign: 'center', padding: 60 }}>
          <Scan size={40} color="#a855f7" style={{ animation: 'spin 2s linear infinite', marginBottom: 16 }} />
          <div style={{ color: '#a855f7', fontFamily: 'Orbitron, monospace', fontSize: 14 }}>Scanning meme coin markets...</div>
        </div>
      )}

      {error && (
        <div style={{ textAlign: 'center', padding: 40, color: '#ef4444' }}>
          <AlertTriangle size={32} style={{ marginBottom: 8 }} />
          <div>{error}</div>
          <button onClick={() => fetchData(true)} style={{ marginTop: 12, color: '#a855f7', background: 'none', border: '1px solid #a855f7', borderRadius: 6, padding: '6px 16px', cursor: 'pointer' }}>
            Retry
          </button>
        </div>
      )}

      {data && filteredCoins.length > 0 && (
        <>
          <div style={{
            display: 'flex',
            gap: 8,
            flexWrap: 'wrap',
            marginBottom: 12,
            alignItems: 'center'
          }}>
            <span style={{ color: '#6b7280', fontSize: 11, marginRight: 4 }}>Sort by:</span>
            {[
              { field: 'potentialScore' as SortField, label: 'Potential' },
              { field: 'priceChange24h' as SortField, label: '24h Change' },
              { field: 'priceChange7d' as SortField, label: '7d Change' },
              { field: 'totalVolume' as SortField, label: 'Volume' },
              { field: 'volatility' as SortField, label: 'Volatility' },
            ].map(s => (
              <button
                key={s.field}
                data-testid={`button-sort-${s.field}`}
                onClick={() => handleSort(s.field)}
                style={{
                  background: sortField === s.field ? '#a855f722' : '#161B22',
                  border: `1px solid ${sortField === s.field ? '#a855f7' : '#30363D'}`,
                  color: sortField === s.field ? '#a855f7' : '#9ca3af',
                  borderRadius: 6,
                  padding: '4px 10px',
                  fontSize: 11,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4
                }}
              >
                {s.label}
                {sortField === s.field && (sortAsc ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {filteredCoins.map((coin, idx) => (
              <div
                key={coin.id}
                data-testid={`card-mcs-coin-${coin.id}`}
                style={{
                  background: '#161B22',
                  border: `1px solid ${expandedCoin === coin.id ? '#a855f7' : '#30363D'}`,
                  borderRadius: 12,
                  overflow: 'hidden',
                  cursor: 'pointer',
                  transition: 'border-color 0.2s'
                }}
                onClick={() => setExpandedCoin(expandedCoin === coin.id ? null : coin.id)}
              >
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'auto 1fr auto auto auto',
                  gap: 16,
                  alignItems: 'center',
                  padding: '14px 18px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ color: '#6b7280', fontFamily: 'monospace', fontSize: 12, width: 24, textAlign: 'right' }}>#{idx + 1}</span>
                    <img src={coin.image} alt={coin.name} width={28} height={28} style={{ borderRadius: '50%' }} />
                    <div>
                      <div style={{ color: '#e6edf3', fontWeight: 600, fontSize: 14 }}>{coin.name}</div>
                      <div style={{ color: '#6b7280', fontSize: 11 }}>{coin.symbol}</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 24, alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap' }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ color: '#6b7280', fontSize: 9 }}>PRICE</div>
                      <div style={{ color: '#e6edf3', fontFamily: 'monospace', fontSize: 13, fontWeight: 600 }}>{formatPrice(coin.currentPrice)}</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ color: '#6b7280', fontSize: 9 }}>1H</div>
                      <ChangeCell value={coin.priceChange1h} />
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ color: '#6b7280', fontSize: 9 }}>24H</div>
                      <ChangeCell value={coin.priceChange24h} />
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ color: '#6b7280', fontSize: 9 }}>7D</div>
                      <ChangeCell value={coin.priceChange7d} />
                    </div>
                  </div>

                  <div>
                    {coin.sparkline.length > 0 && (
                      <MiniSparkline
                        data={coin.sparkline.slice(-48)}
                        color={coin.priceChange7d >= 0 ? '#22c55e' : '#ef4444'}
                      />
                    )}
                  </div>

                  <div>
                    <RiskBadge level={coin.riskLevel} />
                  </div>

                  <PotentialBadge score={coin.potentialScore} range={coin.potentialRange} />
                </div>

                {expandedCoin === coin.id && (
                  <div style={{
                    borderTop: '1px solid #21262D',
                    padding: '16px 18px',
                    background: '#0D1117',
                  }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 14 }}>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>Market Cap</div>
                        <div style={{ color: '#e6edf3', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{formatMarketCap(coin.marketCap)}</div>
                      </div>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>24h Volume</div>
                        <div style={{ color: '#e6edf3', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{formatVolume(coin.totalVolume)}</div>
                      </div>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>Vol/MCap Ratio</div>
                        <div style={{ color: coin.volumeToMcap > 0.2 ? '#22c55e' : '#eab308', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{coin.volumeToMcap.toFixed(3)}</div>
                      </div>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>Volatility (7d)</div>
                        <div style={{ color: coin.volatility > 5 ? '#f97316' : '#3b82f6', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{coin.volatility.toFixed(2)}%</div>
                      </div>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>ATH</div>
                        <div style={{ color: '#e6edf3', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{formatPrice(coin.ath)}</div>
                      </div>
                      <div style={{ background: '#161B22', borderRadius: 8, padding: '10px 14px' }}>
                        <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>From ATH</div>
                        <div style={{ color: '#ef4444', fontFamily: 'monospace', fontSize: 14, fontWeight: 600 }}>{coin.athChangePercentage.toFixed(1)}%</div>
                      </div>
                    </div>
                    <div style={{
                      background: '#161B22',
                      borderRadius: 8,
                      padding: '12px 16px',
                    }}>
                      <div style={{ color: '#a855f7', fontSize: 11, fontWeight: 700, marginBottom: 8 }}>POTENTIAL ANALYSIS</div>
                      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                        <div>
                          <span style={{ color: '#6b7280', fontSize: 10 }}>Momentum: </span>
                          <span style={{ color: coin.priceChange24h > 0 ? '#22c55e' : '#ef4444', fontSize: 12, fontWeight: 600 }}>
                            {coin.priceChange24h > 10 ? 'Strong' : coin.priceChange24h > 0 ? 'Positive' : 'Weak'}
                          </span>
                        </div>
                        <div>
                          <span style={{ color: '#6b7280', fontSize: 10 }}>Volume Pressure: </span>
                          <span style={{ color: coin.volumeToMcap > 0.2 ? '#22c55e' : '#eab308', fontSize: 12, fontWeight: 600 }}>
                            {coin.volumeToMcap > 0.5 ? 'Very High' : coin.volumeToMcap > 0.2 ? 'High' : coin.volumeToMcap > 0.1 ? 'Moderate' : 'Low'}
                          </span>
                        </div>
                        <div>
                          <span style={{ color: '#6b7280', fontSize: 10 }}>Volatility Level: </span>
                          <span style={{ color: coin.volatility > 5 ? '#f97316' : '#3b82f6', fontSize: 12, fontWeight: 600 }}>
                            {coin.volatility > 10 ? 'Extreme' : coin.volatility > 5 ? 'High' : coin.volatility > 2 ? 'Moderate' : 'Low'}
                          </span>
                        </div>
                      </div>
                      <div style={{ marginTop: 10, padding: '8px 12px', background: '#0D1117', borderRadius: 6, border: '1px solid #30363D' }}>
                        <div style={{ color: '#eab308', fontSize: 10, marginBottom: 4 }}>ESTIMATED POTENTIAL RANGE (30 DAYS)</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                          <span style={{ color: coin.potentialRange.low >= 0 ? '#22c55e' : '#ef4444', fontFamily: 'Orbitron, monospace', fontSize: 16 }}>
                            {coin.potentialRange.low > 0 ? '+' : ''}{coin.potentialRange.low}%
                          </span>
                          <span style={{ color: '#6b7280' }}>to</span>
                          <span style={{ color: '#22c55e', fontFamily: 'Orbitron, monospace', fontSize: 16 }}>+{coin.potentialRange.high}%</span>
                        </div>
                        <div style={{ color: '#6b7280', fontSize: 9, marginTop: 4 }}>
                          Based on current momentum, volume, and volatility metrics. NOT a guarantee.
                        </div>
                      </div>
                    </div>
                    <div style={{ marginTop: 10, textAlign: 'right' }}>
                      <a
                        href={`https://www.coingecko.com/en/coins/${coin.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={e => e.stopPropagation()}
                        style={{
                          color: '#a855f7',
                          fontSize: 11,
                          textDecoration: 'none',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 4
                        }}
                      >
                        View on CoinGecko <ExternalLink size={11} />
                      </a>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredCoins.length === 0 && searchQuery && (
            <div style={{ textAlign: 'center', padding: 40, color: '#6b7280' }}>
              No coins match your search "{searchQuery}"
            </div>
          )}
        </>
      )}

      <div style={{
        marginTop: 24,
        background: '#1a0f0f',
        border: '1px solid #ef4444',
        borderRadius: 10,
        padding: '14px 18px',
      }}>
        <div style={{ color: '#ef4444', fontWeight: 700, fontSize: 11, marginBottom: 6 }}>IMPORTANT RISK DISCLOSURE</div>
        <div style={{ color: '#d4a0a0', fontSize: 10, lineHeight: 1.6 }}>
          {data?.disclaimer || 'This tool is for educational purposes only. It is NOT financial advice. Cryptocurrency investments carry extreme risk.'}
        </div>
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

let mcsCache_bust = 0;

export default function StandaloneMemeCoinScanner() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="mcs"
        techName="Meme Coin Scanner™"
        techShortName="MCS"
        techColor="#a855f7"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="mcs" techName="Meme Coin Scanner™" techColor="#a855f7">
        <MemeCoinScannerContent />
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
