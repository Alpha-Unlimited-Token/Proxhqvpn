/**
 * Whale Shadow Imprint™ (WSI) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeWSI, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Eye } from 'lucide-react';

export default function StandaloneWSIApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="wsi"
        techName="Whale Shadow Imprint™"
        techShortName="WSI"
        techColor="#FFD700"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="wsi" techName="Whale Shadow Imprint™" techColor="#FFD700">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Whale Shadow Imprint™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Institutional order absorption detection with volume-wick analysis</p>
        </div>
        <StandaloneShell
          techId="wsi"
          techName="Whale Shadow Imprint™"
          techShortName="WSI"
          techDescription="Institutional order absorption detection with volume-wick analysis"
          techColor="#FFD700"
          techIcon={<Eye size={18} />}
          signalComputer={computeWSI}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span data-testid="text-wsi-signal-label" style={{ color: '#FFD700', fontWeight: 700 }}>Signal Type</span>
                <span data-testid="text-wsi-signal-value" style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{signal.signal === 'strong_buy' || signal.signal === 'buy' ? '▲ BULLISH ABSORPTION' : signal.signal === 'strong_sell' || signal.signal === 'sell' ? '▼ BEARISH REJECTION' : 'NEUTRAL'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Volume Ratio</span>
                <span data-testid="text-wsi-volume-ratio" style={{ color: typeof signal.details.volumeRatio === 'number' && signal.details.volumeRatio > 3 ? '#22c55e' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.volumeRatio === 'number' ? signal.details.volumeRatio.toFixed(2) + 'x' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Body Ratio</span>
                <span data-testid="text-wsi-body-ratio" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.bodyRatio === 'number' ? (signal.details.bodyRatio * 100).toFixed(1) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Wick Direction</span>
                <span data-testid="text-wsi-wick-direction" style={{ color: signal.details.wickDirection === 'lower' ? '#22c55e' : signal.details.wickDirection === 'upper' ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.wickDirection === 'lower' ? '▼ Lower (Bullish)' : signal.details.wickDirection === 'upper' ? '▲ Upper (Bearish)' : 'None'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Confirmation Candles</span>
                <span data-testid="text-wsi-confirmation" style={{ color: signal.details.confirmationCandles === 2 ? '#22c55e' : '#f59e0b', fontFamily: 'monospace' }}>{typeof signal.details.confirmationCandles === 'number' ? signal.details.confirmationCandles + '/2' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Raw Score</span>
                <span data-testid="text-wsi-raw-score" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
          )}
        />
        <div style={{ marginTop: 12, padding: 10, background: 'linear-gradient(135deg, rgba(34,197,94,0.05), rgba(34,197,94,0.1), rgba(34,197,94,0.05))', borderRadius: 8, border: '1px solid rgba(34,197,94,0.2)' }}>
          <p style={{ fontSize: 10, color: '#22c55e', textAlign: 'center', fontWeight: 700, marginBottom: 2 }}>
            This signal is included as a free bonus cross-reference in all proprietary technology apps
          </p>
          <p style={{ fontSize: 9, color: '#6b7280', textAlign: 'center' }}>
            ACM, QFRM, BIF, SBPE, ANCE, ANCE², TMDE, QMGE, Bridge Fusion &amp; more — WSI appears automatically as supplementary data
          </p>
        </div>
        <div style={{ marginTop: 8, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
