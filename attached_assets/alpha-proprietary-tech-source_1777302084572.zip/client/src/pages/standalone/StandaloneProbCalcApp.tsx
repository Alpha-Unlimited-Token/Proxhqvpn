/**
 * Trading Probability Calculator - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeProbabilityCalculator, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Calculator } from 'lucide-react';

const TECH_LABELS: Record<string, string> = {
  acm: 'ACM',
  qfrm: 'QFRM',
  bif: 'BIF',
  sbpe: 'SBPE',
  ance: 'ANCE',
  ance2: 'ANCE²',
  tmde: 'TMDE',
  bridge_fusion: 'Bridge Fusion',
  qmge: 'QMGE',
  filters: 'Filters Pack',
};

function getSignalColor(signal: string): string {
  if (signal === 'strong_buy' || signal === 'buy') return '#22c55e';
  if (signal === 'strong_sell' || signal === 'sell') return '#ef4444';
  return '#6b7280';
}

export default function StandaloneProbCalcApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="prob_calc"
        techName="Trading Probability Calculator"
        techShortName="Prob Calc"
        techColor="#10b981"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="prob_calc" techName="Trading Probability Calculator" techColor="#10b981">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Trading Probability Calculator</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Aggregated probability analysis across all 10 proprietary technologies</p>
        </div>
        <StandaloneShell
          techId="prob_calc"
          techName="Trading Probability Calculator"
          techShortName="Prob Calc"
          techDescription="Aggregated probability analysis across all 10 proprietary technologies"
          techColor="#10b981"
          techIcon={<Calculator size={18} />}
          signalComputer={computeProbabilityCalculator}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => {
            const profitProb = signal.details.profitProbability;
            const allScores = signal.details.allScores as Record<string, { signal: string; strength: number; confidence: number }> | undefined;
            return (
              <>
              <div style={{ fontSize: 11 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #21262D', marginBottom: 4 }}>
                  <span style={{ color: '#10b981', fontWeight: 700 }}>Profit Probability</span>
                  <span style={{ color: typeof profitProb === 'number' && profitProb >= 60 ? '#22c55e' : typeof profitProb === 'number' && profitProb <= 40 ? '#ef4444' : '#FFD700', fontFamily: 'monospace', fontWeight: 700, fontSize: 14 }}>{typeof profitProb === 'number' ? profitProb + '%' : 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Consensus</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>
                    <span style={{ color: '#22c55e' }}>{signal.details.bullishCount ?? 0} Bull</span>
                    {' / '}
                    <span style={{ color: '#ef4444' }}>{signal.details.bearishCount ?? 0} Bear</span>
                    {' / '}
                    <span style={{ color: '#6b7280' }}>{signal.details.neutralCount ?? 0} Neutral</span>
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Overall Confidence</span>
                  <span style={{ color: '#10b981', fontFamily: 'monospace', fontWeight: 700 }}>{signal.confidence}%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D', marginBottom: 8 }}>
                  <span style={{ color: '#6b7280' }}>Raw Score</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore : 'N/A'}</span>
                </div>
                {allScores && (
                  <div>
                    <div style={{ color: '#9ca3af', fontSize: 10, fontWeight: 700, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 1 }}>Technology Contributions</div>
                    {Object.entries(TECH_LABELS).map(([key, label]) => {
                      const score = allScores[key];
                      if (!score) return null;
                      const color = getSignalColor(score.signal);
                      return (
                        <div key={key} data-testid={`prob-tech-${key}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                          <span style={{ color: '#e5e7eb', fontSize: 10 }}>{label}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ color, fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }}>{score.signal.replace('_', ' ').toUpperCase()}</span>
                            <span style={{ color: '#9ca3af', fontFamily: 'monospace', fontSize: 9 }}>{score.strength}%</span>
                            <span style={{ color: '#6b7280', fontFamily: 'monospace', fontSize: 9 }}>C:{score.confidence}%</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              {(() => {
                const wsi = computeWSI(candles);
                const ert = computeERT(candles);
                const mft = computeMFT(candles);
                return (
                  <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                    <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                    {[
                      { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                      { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                      { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                    ].map(s => (
                      <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                        <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                          {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              </>
            );
          }}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
