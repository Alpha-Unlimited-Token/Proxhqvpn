/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha AACC™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_dfd0623961c6ee9e3f577fff
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { motion } from 'framer-motion';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Link } from 'wouter';
import aaccLogo from '../../assets/images/tech-aacc-logo.png';
import { Radar, Bot, Wallet, ArrowLeftRight, Activity, BarChart3, Bell, ArrowRight } from 'lucide-react';

const FEATURES = [
  {
    icon: Radar,
    title: 'Autonomous Market Scanner',
    description: 'Scans 200+ coins every 30 seconds with real-time technical analysis',
  },
  {
    icon: Bot,
    title: 'AI Bot Deployment',
    description: 'Automatically deploys the optimal bot type based on market conditions',
  },
  {
    icon: Wallet,
    title: 'Smart Capital Allocation\u2122',
    description: 'Intelligently distributes capital across multiple strategies',
  },
  {
    icon: ArrowLeftRight,
    title: 'Cross-Exchange Arbitrage\u2122',
    description: 'Detects profitable price differences across connected exchanges',
  },
  {
    icon: Activity,
    title: 'ATR-Adaptive Settings',
    description: 'Dynamic take profit and stop loss calibrated to real market volatility',
  },
  {
    icon: BarChart3,
    title: 'ADMIE\u2122 Technical Analysis',
    description: 'Full 30-day historical analysis with RSI, MACD, Bollinger Bands, and more',
  },
];

export default function StandaloneAACCApp() {
  const [showSplash, setShowSplash] = useState(true);
  const [notified, setNotified] = useState(false);
  const [email, setEmail] = useState('');

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="aacc"
        techName="Alpha Autonomous Command Center\u2122"
        techShortName="AACC"
        techColor="#FFD700"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 16px 60px' }}>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 40 }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            style={{ display: 'inline-block', marginBottom: 24 }}
          >
            <img
              src={aaccLogo}
              alt="AACC Logo"
              data-testid="img-aacc-logo"
              style={{
                width: 140,
                height: 140,
                borderRadius: 24,
                border: '2px solid rgba(255, 215, 0, 0.3)',
                boxShadow: '0 0 60px rgba(255, 215, 0, 0.2), 0 0 120px rgba(255, 215, 0, 0.1)',
              }}
            />
          </motion.div>

          <h1
            data-testid="text-aacc-title"
            style={{
              fontFamily: 'Orbitron, monospace',
              fontSize: 24,
              fontWeight: 900,
              color: '#FFD700',
              letterSpacing: 3,
              textShadow: '0 0 30px rgba(255, 215, 0, 0.3)',
              marginBottom: 16,
            }}
          >
            ALPHA AUTONOMOUS COMMAND CENTER&trade;
          </h1>

          <motion.div
            animate={{
              boxShadow: [
                '0 0 20px rgba(255, 215, 0, 0.3)',
                '0 0 40px rgba(255, 215, 0, 0.5)',
                '0 0 20px rgba(255, 215, 0, 0.3)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            style={{
              display: 'inline-block',
              padding: '8px 32px',
              background: 'linear-gradient(135deg, rgba(255, 215, 0, 0.15), rgba(255, 215, 0, 0.05))',
              border: '1px solid rgba(255, 215, 0, 0.4)',
              borderRadius: 8,
              marginBottom: 20,
            }}
          >
            <span
              data-testid="badge-coming-soon"
              style={{
                fontFamily: 'Orbitron, monospace',
                fontSize: 16,
                fontWeight: 700,
                color: '#FFD700',
                letterSpacing: 6,
              }}
            >
              COMING SOON
            </span>
          </motion.div>

          <p
            data-testid="text-aacc-description"
            style={{
              color: '#9ca3af',
              fontSize: 15,
              lineHeight: 1.7,
              maxWidth: 700,
              margin: '0 auto',
            }}
          >
            The world's first fully autonomous AI trading system. Market scanning, bot deployment,
            capital rotation, and cross-exchange arbitrage &mdash; all running 24/7 without human intervention.
          </p>
        </motion.div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
            gap: 16,
            marginBottom: 48,
          }}
        >
          {FEATURES.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              data-testid={`card-feature-${index}`}
              style={{
                background: 'rgba(13, 17, 23, 0.8)',
                border: '1px solid rgba(255, 215, 0, 0.12)',
                borderRadius: 12,
                padding: 20,
                transition: 'border-color 0.3s, box-shadow 0.3s',
              }}
              whileHover={{
                borderColor: 'rgba(255, 215, 0, 0.3)',
                boxShadow: '0 0 20px rgba(255, 215, 0, 0.08)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 8,
                    background: 'rgba(255, 215, 0, 0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <feature.icon size={18} color="#FFD700" />
                </div>
                <h3
                  style={{
                    fontFamily: 'Orbitron, monospace',
                    fontSize: 12,
                    fontWeight: 700,
                    color: '#FFD700',
                    letterSpacing: 1,
                  }}
                >
                  {feature.title}
                </h3>
              </div>
              <p style={{ color: '#9ca3af', fontSize: 13, lineHeight: 1.5 }}>{feature.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          style={{
            background: 'rgba(13, 17, 23, 0.8)',
            border: '1px solid rgba(255, 215, 0, 0.15)',
            borderRadius: 12,
            padding: 28,
            textAlign: 'center',
            marginBottom: 32,
          }}
        >
          <Bell size={24} color="#FFD700" style={{ marginBottom: 12 }} />
          <h3
            style={{
              fontFamily: 'Orbitron, monospace',
              fontSize: 16,
              fontWeight: 700,
              color: '#FFD700',
              marginBottom: 8,
            }}
          >
            GET NOTIFIED
          </h3>
          <p style={{ color: '#6b7280', fontSize: 13, marginBottom: 16 }}>
            Be the first to know when AACC launches
          </p>
          {notified ? (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              data-testid="text-notify-success"
              style={{
                color: '#FFD700',
                fontFamily: 'Orbitron, monospace',
                fontSize: 14,
                fontWeight: 700,
              }}
            >
              You'll be the first to know!
            </motion.div>
          ) : (
            <div style={{ display: 'flex', gap: 8, maxWidth: 400, margin: '0 auto' }}>
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                data-testid="input-notify-email"
                style={{
                  flex: 1,
                  padding: '10px 14px',
                  background: '#161B22',
                  border: '1px solid rgba(255, 215, 0, 0.2)',
                  borderRadius: 8,
                  color: '#e5e7eb',
                  fontSize: 13,
                  outline: 'none',
                }}
              />
              <button
                onClick={() => setNotified(true)}
                data-testid="button-notify"
                style={{
                  padding: '10px 20px',
                  background: 'linear-gradient(135deg, #FFD700, #FFA500)',
                  border: 'none',
                  borderRadius: 8,
                  color: '#0D1117',
                  fontFamily: 'Orbitron, monospace',
                  fontSize: 11,
                  fontWeight: 700,
                  cursor: 'pointer',
                  letterSpacing: 1,
                }}
              >
                NOTIFY ME
              </button>
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          style={{ textAlign: 'center', marginBottom: 32 }}
        >
          <Link href="/command-center" data-testid="link-command-center">
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 8,
                color: '#FFD700',
                fontFamily: 'Orbitron, monospace',
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: 1,
                textDecoration: 'none',
                padding: '10px 24px',
                border: '1px solid rgba(255, 215, 0, 0.3)',
                borderRadius: 8,
                transition: 'background 0.3s',
                cursor: 'pointer',
              }}
            >
              Experience the preview on our trading platform
              <ArrowRight size={16} />
            </span>
          </Link>
        </motion.div>

        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <p style={{ fontSize: 10, color: '#6b7280' }}>
            &copy; Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
          </p>
          <p style={{ fontSize: 9, color: '#4b5563', marginTop: 4 }}>
            Proprietary Technology &mdash; Patent Pending &mdash; Trademark Registered
          </p>
        </div>
      </div>
    </TradingPlatformLayout>
  );
}
