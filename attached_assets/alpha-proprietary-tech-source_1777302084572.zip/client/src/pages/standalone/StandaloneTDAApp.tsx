/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha TDA™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_bed9e3664b1f5d082f25806d
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeTDA, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Clock } from 'lucide-react';

export default function StandaloneTDAApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="tda"
        techName="Temporal Difficulty Analysis™"
        techShortName="TDA"
        techColor="#00D4FF"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="tda" techName="Temporal Difficulty Analysis™" techColor="#00D4FF">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <span style={{ display: 'inline-block', padding: '3px 10px', background: '#22c55e22', border: '1px solid #22c55e44', borderRadius: 12, fontSize: 10, color: '#22c55e', fontFamily: 'Orbitron, monospace', letterSpacing: 1, marginBottom: 8 }} data-testid="badge-free">FREE</span>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#00D4FF', fontSize: 20, marginBottom: 8 }} data-testid="text-title">Temporal Difficulty Analysis™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Mining difficulty trend monitoring with epoch progress tracking and block interval estimation</p>
        </div>
        <StandaloneShell
          techId="tda"
          techName="Temporal Difficulty Analysis™"
          techShortName="TDA"
          techDescription="Mining difficulty trend monitoring with epoch progress and block interval estimation"
          techColor="#00D4FF"
          techIcon={<Clock size={18} />}
          signalComputer={computeTDA}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#00D4FF', fontWeight: 700 }}>Difficulty Phase</span>
                <span style={{ color: signal.details.adjustmentPhase === 'decreasing' ? '#22c55e' : signal.details.adjustmentPhase === 'increasing' ? '#ef4444' : '#eab308', fontFamily: 'monospace', fontWeight: 700 }} data-testid="text-phase">{(signal.details.adjustmentPhase || 'stable').toUpperCase()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Difficulty Index</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-difficulty">{signal.details.difficultyProxy ?? 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Epoch Progress</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-epoch">{signal.details.epochProgress ?? 0}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Network Load</span>
                <span style={{ color: (signal.details.networkLoad ?? 0) > 70 ? '#ef4444' : (signal.details.networkLoad ?? 0) > 40 ? '#eab308' : '#22c55e', fontFamily: 'monospace' }} data-testid="text-network-load">{signal.details.networkLoad ?? 0}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Est. Block Interval</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-block-interval">{signal.details.estimatedBlockInterval ?? 'N/A'}min</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>ATR %</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.atrPercent ?? 'N/A'}%</span>
              </div>
              {signal.details.miningNote && (
                <div style={{ marginTop: 6, padding: '6px 8px', background: '#00D4FF11', borderRadius: 6, border: '1px solid #00D4FF22' }}>
                  <p style={{ color: '#00D4FF', fontSize: 10, margin: 0 }} data-testid="text-mining-note">{signal.details.miningNote}</p>
                </div>
              )}
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center', marginBottom: 4 }}>
            This is a free mining monitoring tool. For advanced trading signals, explore our{' '}
            <a href="/technology-packages" style={{ color: '#FFD700', textDecoration: 'underline' }}>Premium Technologies</a>.
          </p>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
