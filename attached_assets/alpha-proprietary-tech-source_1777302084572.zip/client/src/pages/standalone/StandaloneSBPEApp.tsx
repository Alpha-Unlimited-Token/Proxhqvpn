/**
 * Stochastic Block Prediction Engine™ (SBPE) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeSBPE, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { BarChart3 } from 'lucide-react';

export default function StandaloneSBPEApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="sbpe"
        techName="Stochastic Block Prediction Engine™"
        techShortName="SBPE"
        techColor="#f97316"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="sbpe" techName="Stochastic Block Prediction Engine™" techColor="#f97316">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>Stochastic Block Prediction Engine™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Statistical prediction analysis with z-score, percentile ranking, and distribution modeling</p>
        </div>
        <StandaloneShell
          techId="sbpe"
          techName="Stochastic Block Prediction Engine™"
          techShortName="SBPE"
          techDescription="Statistical prediction analysis with z-score, percentile ranking, and distribution modeling"
          techColor="#f97316"
          techIcon={<BarChart3 size={18} />}
          signalComputer={computeSBPE}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#f97316', fontWeight: 700 }}>Prediction Probability</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{typeof signal.details.stochK === 'number' ? signal.details.stochK.toFixed(2) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Z-Score</span>
                <span style={{ color: typeof signal.details.zScore === 'number' && signal.details.zScore > 1 ? '#ef4444' : typeof signal.details.zScore === 'number' && signal.details.zScore < -1 ? '#22c55e' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.zScore === 'number' ? signal.details.zScore.toFixed(3) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Percentile Rank</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.percentileRank === 'number' ? signal.details.percentileRank.toFixed(1) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Std Deviation</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.stdDev === 'number' ? signal.details.stdDev.toFixed(3) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Mean Reversion</span>
                <span style={{ color: typeof signal.details.meanReversion === 'number' && signal.details.meanReversion > 0 ? '#22c55e' : typeof signal.details.meanReversion === 'number' && signal.details.meanReversion < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.meanReversion === 'number' ? signal.details.meanReversion.toFixed(2) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Drift</span>
                <span style={{ color: typeof signal.details.drift === 'number' && signal.details.drift > 0 ? '#22c55e' : typeof signal.details.drift === 'number' && signal.details.drift < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.drift === 'number' ? signal.details.drift.toFixed(3) : 'N/A'}</span>
              </div>
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
