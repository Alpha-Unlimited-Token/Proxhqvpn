/**
 * ANCE² Meta-Intelligence Layer - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeANCE2, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Layers } from 'lucide-react';

export default function StandaloneANCE2App() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="ance2"
        techName="ANCE² Meta-Intelligence Layer"
        techShortName="ANCE²"
        techColor="#7c3aed"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="ance2" techName="ANCE² Meta-Intelligence Layer" techColor="#7c3aed">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>ANCE² Meta-Intelligence Layer</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Meta-analysis layer that monitors ANCE signal stability, divergence, and adaptive confidence</p>
        </div>
        <StandaloneShell
          techId="ance2"
          techName="ANCE² Meta-Intelligence Layer"
          techShortName="ANCE²"
          techDescription="Meta-analysis layer that monitors ANCE signal stability, divergence, and adaptive confidence"
          techColor="#7c3aed"
          techIcon={<Layers size={18} />}
          signalComputer={computeANCE2}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <>
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#7c3aed', fontWeight: 700 }}>Meta Signal</span>
                <span style={{ color: '#FFD700', fontFamily: 'monospace', fontWeight: 700 }}>{signal.details.metaSignal || 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Meta Confidence</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.convergenceIndex === 'number' ? signal.details.convergenceIndex.toFixed(1) : 'N/A'}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Divergence Detected</span>
                <span style={{ color: signal.details.divergenceFlag ? '#ef4444' : '#22c55e', fontFamily: 'monospace', fontWeight: 600 }}>{signal.details.divergenceFlag ? 'YES' : 'NO'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Stability Score</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.stabilityScore === 'number' ? signal.details.stabilityScore.toFixed(1) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Primary ANCE Score</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.anceBaseScore === 'number' ? signal.details.anceBaseScore.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Signal Momentum</span>
                <span style={{ color: typeof signal.details.signalMomentum === 'number' && signal.details.signalMomentum > 0 ? '#22c55e' : typeof signal.details.signalMomentum === 'number' && signal.details.signalMomentum < 0 ? '#ef4444' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.signalMomentum === 'number' ? signal.details.signalMomentum.toFixed(2) : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Adaptive Boost</span>
                <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.adaptiveBoost === 'number' ? signal.details.adaptiveBoost.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
            {(() => {
              const wsi = computeWSI(candles);
              const ert = computeERT(candles);
              const mft = computeMFT(candles);
              return (
                <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                  <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                  {[
                    { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                    { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                    { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                  ].map(s => (
                    <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                      <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                      <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                        {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
            </>
          )}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
