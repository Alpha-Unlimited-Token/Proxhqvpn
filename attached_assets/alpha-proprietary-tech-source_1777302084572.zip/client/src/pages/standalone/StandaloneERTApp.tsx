/**
 * EMA Ribbon Twist™ (ERT) - Standalone App Page
 * Copyright (c) 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 *
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * U.S. Copyright Registration Pending | International Copyright Protected
 *
 * ALL RIGHTS RESERVED. Unauthorized reproduction or distribution is strictly prohibited.
 * Patent Pending. Trademark Registered.
 * Contact: legal@alphaunlimitedtrading.com
 */

import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeERT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { TrendingUp } from 'lucide-react';

export default function StandaloneERTApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="ert"
        techName="EMA Ribbon Twist™"
        techShortName="ERT"
        techColor="#00FFCC"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="ert" techName="EMA Ribbon Twist™" techColor="#00FFCC">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }}>EMA Ribbon Twist™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Multi-EMA convergence and expansion detection for trend birth identification</p>
        </div>
        <StandaloneShell
          techId="ert"
          techName="EMA Ribbon Twist™"
          techShortName="ERT"
          techDescription="Multi-EMA convergence and expansion detection for trend birth identification"
          techColor="#00FFCC"
          techIcon={<TrendingUp size={18} />}
          signalComputer={computeERT}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => (
            <div style={{ fontSize: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span data-testid="text-ert-order-label" style={{ color: '#00FFCC', fontWeight: 700 }}>EMA Order</span>
                <span data-testid="text-ert-order-value" style={{ color: signal.details.emaOrder === 'bullish' ? '#22c55e' : signal.details.emaOrder === 'bearish' ? '#ef4444' : '#f59e0b', fontFamily: 'monospace', fontWeight: 700 }}>{signal.details.emaOrder === 'bullish' ? '▲ BULLISH (8>13>21>34>55)' : signal.details.emaOrder === 'bearish' ? '▼ BEARISH (55>34>21>13>8)' : 'MIXED'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Previous Spread</span>
                <span data-testid="text-ert-prev-spread" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.prevSpread === 'number' ? signal.details.prevSpread.toFixed(3) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Current Spread</span>
                <span data-testid="text-ert-current-spread" style={{ color: typeof signal.details.currentSpread === 'number' && signal.details.currentSpread > 0.5 ? '#22c55e' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.currentSpread === 'number' ? signal.details.currentSpread.toFixed(3) + '%' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Expansion Ratio</span>
                <span data-testid="text-ert-expansion-ratio" style={{ color: typeof signal.details.expansionRatio === 'number' && signal.details.expansionRatio > 2 ? '#22c55e' : '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.expansionRatio === 'number' ? signal.details.expansionRatio.toFixed(2) + 'x' : 'N/A'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                <span style={{ color: '#6b7280' }}>Raw Score</span>
                <span data-testid="text-ert-raw-score" style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{typeof signal.details.rawScore === 'number' ? signal.details.rawScore.toFixed(2) : 'N/A'}</span>
              </div>
            </div>
          )}
        />
        <div style={{ marginTop: 12, padding: 10, background: 'linear-gradient(135deg, rgba(34,197,94,0.05), rgba(34,197,94,0.1), rgba(34,197,94,0.05))', borderRadius: 8, border: '1px solid rgba(34,197,94,0.2)' }}>
          <p style={{ fontSize: 10, color: '#22c55e', textAlign: 'center', fontWeight: 700, marginBottom: 2 }}>
            This signal is included as a free bonus cross-reference in all proprietary technology apps
          </p>
          <p style={{ fontSize: 9, color: '#6b7280', textAlign: 'center' }}>
            ACM, QFRM, BIF, SBPE, ANCE, ANCE², TMDE, QMGE, Bridge Fusion &amp; more — ERT appears automatically as supplementary data
          </p>
        </div>
        <div style={{ marginTop: 8, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
