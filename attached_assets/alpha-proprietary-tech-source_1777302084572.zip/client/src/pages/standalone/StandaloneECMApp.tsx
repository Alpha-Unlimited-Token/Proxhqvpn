/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha ECM™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Seal: AUT_46fca9395fd7aebc69437af7
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { useState } from 'react';
import { StandaloneShell } from '@/components/standalone/StandaloneShell';
import { computeECM, computeWSI, computeERT, computeMFT, type CandleData, type SignalOutput } from '@/lib/standalone/signal-sdk';
import { TradingPlatformLayout } from '@/components/trading-platform/TradingPlatformLayout';
import { LicenseGate } from '@/components/standalone/LicenseGate';
import { TechSplashScreen } from '@/components/standalone/TechSplashScreen';
import { Atom } from 'lucide-react';

export default function StandaloneECMApp() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <TechSplashScreen
        techSlug="ecm"
        techName="Entropy Cascade Mapping™"
        techShortName="ECM"
        techColor="#FFD700"
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  return (
    <TradingPlatformLayout>
      <LicenseGate techSlug="ecm" techName="Entropy Cascade Mapping™" techColor="#FFD700">
      <div style={{ maxWidth: 600, margin: '40px auto', padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <span style={{ display: 'inline-block', padding: '3px 10px', background: '#22c55e22', border: '1px solid #22c55e44', borderRadius: 12, fontSize: 10, color: '#22c55e', fontFamily: 'Orbitron, monospace', letterSpacing: 1, marginBottom: 8 }} data-testid="badge-free">FREE</span>
          <h1 style={{ fontFamily: 'Orbitron, monospace', color: '#FFD700', fontSize: 20, marginBottom: 8 }} data-testid="text-title">Entropy Cascade Mapping™</h1>
          <p style={{ color: '#9ca3af', fontSize: 13 }}>Shannon entropy analysis of hash distribution patterns with kurtosis and skewness profiling</p>
        </div>
        <StandaloneShell
          techId="ecm"
          techName="Entropy Cascade Mapping™"
          techShortName="ECM"
          techDescription="Shannon entropy analysis of hash distribution with kurtosis and cascade detection"
          techColor="#FFD700"
          techIcon={<Atom size={18} />}
          signalComputer={computeECM}
          renderDetails={(signal: SignalOutput, candles: CandleData[]) => {
            const histogram = signal.details.histogram as { bin: number; count: number; probability: number }[] || [];
            const maxCount = Math.max(...histogram.map(h => h.count), 1);
            return (
              <>
              <div style={{ fontSize: 11 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#FFD700', fontWeight: 700 }}>Entropy Regime</span>
                  <span style={{ color: signal.details.entropyRegime === 'low_entropy' ? '#22c55e' : signal.details.entropyRegime === 'high_entropy' ? '#ef4444' : '#eab308', fontFamily: 'monospace', fontWeight: 700 }} data-testid="text-regime">{(signal.details.entropyRegime || 'unknown').replace('_', ' ').toUpperCase()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Shannon Entropy</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-entropy">{signal.details.shannonEntropy ?? 'N/A'} / {signal.details.maxEntropy ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Normalized Entropy</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-norm-entropy">{signal.details.normalizedEntropy ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Distribution Type</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }} data-testid="text-distribution">{signal.details.distributionType ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Kurtosis</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.kurtosis ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Skewness</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.skewness ?? 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Cascade Ratio</span>
                  <span style={{ color: signal.details.cascadeRatio > 1.5 ? '#ef4444' : signal.details.cascadeRatio < 0.5 ? '#22c55e' : '#eab308', fontFamily: 'monospace' }}>{signal.details.cascadeRatio ?? 'N/A'}x</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                  <span style={{ color: '#6b7280' }}>Volatility</span>
                  <span style={{ color: '#e5e7eb', fontFamily: 'monospace' }}>{signal.details.volatility ?? 'N/A'}%</span>
                </div>
                {histogram.length > 0 && (
                  <div style={{ marginTop: 6 }}>
                    <div style={{ color: '#6b7280', fontSize: 10, marginBottom: 4 }}>Return Distribution Histogram</div>
                    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 1, height: 30 }}>
                      {histogram.map((h, i) => (
                        <div key={i} style={{ flex: 1, background: i < histogram.length / 2 ? '#ef4444' : '#22c55e', height: `${(h.count / maxCount) * 100}%`, borderRadius: '2px 2px 0 0', minHeight: 1 }} title={`Bin ${i}: ${h.count} (${(h.probability * 100).toFixed(1)}%)`} />
                      ))}
                    </div>
                  </div>
                )}
                {signal.details.miningNote && (
                  <div style={{ marginTop: 6, padding: '6px 8px', background: '#FFD70011', borderRadius: 6, border: '1px solid #FFD70022' }}>
                    <p style={{ color: '#FFD700', fontSize: 10, margin: 0 }} data-testid="text-mining-note">{signal.details.miningNote}</p>
                  </div>
                )}
              </div>
              {(() => {
                const wsi = computeWSI(candles);
                const ert = computeERT(candles);
                const mft = computeMFT(candles);
                return (
                  <div style={{ marginTop: 12, paddingTop: 8, borderTop: '1px solid #30363D' }}>
                    <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, letterSpacing: '0.5px' }}>NOVEL SIGNAL CROSS-REFERENCE</div>
                    {[
                      { name: 'WSI', label: 'Whale Shadow Imprint™', color: '#FFD700', result: wsi, accuracy: '54.5%' },
                      { name: 'ERT', label: 'EMA Ribbon Twist™', color: '#00FFCC', result: ert, accuracy: '60.3%' },
                      { name: 'MFT', label: 'Micro-Structure Fractal Trap™', color: '#FF6B35', result: mft, accuracy: '44.3%' },
                    ].map(s => (
                      <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #21262D' }}>
                        <span style={{ color: s.color, fontSize: 10 }}>{s.name} <span style={{ color: '#6b7280' }}>({s.accuracy})</span></span>
                        <span style={{ color: s.result.signal.includes('buy') ? '#22c55e' : s.result.signal.includes('sell') ? '#ef4444' : '#9ca3af', fontFamily: 'monospace', fontSize: 10, fontWeight: 700 }} data-testid={`text-novel-${s.name.toLowerCase()}`}>
                          {s.result.signal.replace(/_/g, ' ').toUpperCase()} ({s.result.confidence}%)
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              </>
            );
          }}
        />
        <div style={{ marginTop: 16, padding: 12, background: '#161B22', borderRadius: 8, border: '1px solid #30363D' }}>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center', marginBottom: 4 }}>
            This is a free mining analytics tool. For advanced trading signals, explore our{' '}
            <a href="/technology-packages" style={{ color: '#FFD700', textDecoration: 'underline' }}>Premium Technologies</a>.
          </p>
          <p style={{ fontSize: 10, color: '#6b7280', textAlign: 'center' }}>
            © Alpha Unlimited Trading Company. All Rights Reserved. Proprietary Technology.
          </p>
        </div>
      </div>
      </LicenseGate>
    </TradingPlatformLayout>
  );
}
