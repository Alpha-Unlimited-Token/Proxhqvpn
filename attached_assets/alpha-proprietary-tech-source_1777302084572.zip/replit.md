# Alpha Unlimited Token

## Overview
Alpha Unlimited Token is a cryptocurrency ecosystem designed to integrate community engagement with advanced trading functionalities. It comprises two main platforms: `alphaunlimitedtoken.com` for NFTs, gaming, and community, and `AlphaUnlimitedTrading.com` for sophisticated crypto trading. The project aims to provide a secure, feature-rich experience using proprietary technologies, real-time data, and AI-driven tools for market analysis, mining optimization, and an enhanced trading environment. The overarching goal is to become a leader in decentralized finance and blockchain gaming, serving both casual users and professional traders.

## User Preferences
Preferred communication style: Simple, everyday language.
CRITICAL: No mock data EVER. All data displayed on the website must be real, live data from real APIs (Binance, blockchain explorers, etc.). Never use Math.random() to generate fake prices, fake order books, fake volumes, or any simulated trading data. If real data isn't available, show a loading state or "Connect to view" message instead of fake numbers.
CRITICAL: HTML APP SYNC RULE. Every feature, technology, or content change made to the website MUST also be reflected in ALL standalone HTML apps and reports. These include: `public/downloads/QMGE-Standalone.html` (footer ecosystem list), the forensic report HTML generator in `server/routes.ts` (~line 18322), `SillyTuna_Forensic/sillytuna_forensic_report.html` (technologies deployed section), and `private/dossier-package/Recovery-Dossier.html` (technologies deployed section). Never make a change to the website without updating the corresponding HTML outputs.
CRITICAL: STRICT SITE SEPARATION. The token website (alphaunlimitedtoken.com) must NEVER contain any trading platform features, content, routes, or references. The token site is ONLY for community, NFTs, gaming, and a hyperlink to the trading site. When updating trading features, NEVER add anything to the token site (Home.tsx, Navbar.tsx, Footer.tsx, or the non-trading routes in App.tsx). All trading features belong exclusively on alphaunlimitedtrading.com.
CRITICAL: PROPRIETARY PROTECTION RULE. EVERY new Alpha proprietary technology (forensic engines, trading bots, security tools, on-chain modules, etc.) MUST: (1) `import { enforceProprietaryLicense, proprietaryHeader } from '<path>/private/security/alpha_proprietary_guard.js'` and call `enforceProprietaryLicense('Tech Name™')` at the top before any logic; (2) include the standard 8-line copyright header citing Title 17 / DMCA / CFAA / DTSA; (3) embed `proprietaryHeader('Tech Name™')` in every JSON/HTML/PDF output; (4) be registered as a `<tr>` row in `SillyTuna_Forensic/sillytuna_forensic_report.html`, `private/dossier-package/Recovery-Dossier.html`, and as a `<div class="stat">` in the forensic-report HTML in `server/routes.ts` (~line 18549); (5) be added to the ecosystem footer list in `public/downloads/QMGE-Standalone.html`.

## System Architecture

### Frontend
The frontend utilizes React 18, TypeScript, Wouter for routing, and TanStack React Query for state management. Styling is implemented with Tailwind CSS v4, shadcn/ui, and Radix UI, complemented by Framer Motion for animations and React Three Fiber for 3D graphics. The UI/UX design features a dark charcoal and gold color scheme with Orbitron, Poppins, and Roboto fonts, offering PWA support, landscape trading views, charting, AI signals, arbitrage scanning, and fixed bottom navigation.

### Backend
The backend is developed with Node.js and Express.js, using TypeScript and ESM modules. It provides a RESTful API and manages user sessions via Express sessions backed by a PostgreSQL store. Authentication is handled through Replit Auth (OpenID Connect) and Passport.js.

### Data Storage
PostgreSQL is the primary database, managed using Drizzle ORM.

### Core Features

#### Alpha Unlimited Token Site (`alphaunlimitedtoken.com`)
This platform focuses on community, providing an AI-generated NFT marketplace, a play-to-earn Alpha Game, and social functionalities.

#### Alpha Unlimited Trading Platform (`AlphaUnlimitedTrading.com`)
This platform offers comprehensive trading tools, including:
-   **Advanced Trading Terminal**: Real-time charts, proprietary indicators, AI signals, exchange integration, and advanced order types.
-   **AI-Powered Systems**: Features 14 types of AI trading bots, the Alpha Autonomous Command Center™ (AACC™) for market scanning, and AI-powered blockchain solving for mining optimization.
-   **Market Intelligence**: Provides real-time data feeds, Whale Watch, Rug Pull Detector, News Sentiment Analysis, and a 4-Agent Prediction Market Arbitrage Engine.
-   **Wallet & Asset Management**: Multi-chain wallet dashboard, Portfolio Health Score, and Tax Report Generator.
-   **Security & Compliance**: Implements Alpha SafeSend Protocol™, Alpha SafeAsset Protocol™ for RWA tokenization, and a 10-Layer Security Architecture with a Quantum Security Engine™ using 5 post-quantum cryptographic technologies.
-   **Forensic Tools**: Includes a Forensic Intelligence Engine™, Autonomous Blockchain Spider™, Privacy Protocol Tracker, Alpha Auto-Pivot Surveillance Engine™, Alpha Amount Correlation Scanner™, Monero Cross-Chain Correlation Engine™, and DAU v2 "Dye Pack Protocol"™ for forensic tracking.
-   **AUC Exchange**: A built-in exchange for Alpha Unlimited Coin (AUC) with order books and Stripe integration.
-   **User Dashboard**: Comprehensive account management with user data, subscriptions, NFT collections, and trading analytics.
-   **Educational Resources**: A Crypto Learning Center (`/learning-center`).
-   **Accessibility**: Voice Command Widget for hands-free navigation.
-   **Team Portals**: Dedicated portals for forensic team members (`/team-portal`) and an admin-only page for team management (`/team-management`).

## External Dependencies

### Database
-   PostgreSQL

### Authentication
-   Replit Auth
-   Passport.js
-   express-session

### Real Data API Endpoints
-   Binance.com (OHLCV klines, real-time kline streams, trading data)
-   Blockchain.info, Blockchair (whale transactions)

### Proprietary On-Chain/Off-Chain Technologies
-   **Alpha Tracking Coin™ (ATC)**: ERC-20 Solidity contract.
-   **Alpha Auto-Pivot Surveillance Engine™**: Module for wallet-level surveillance and email alerts.
-   **Alpha Amount Correlation Scanner™**: Module for cross-chain amount fingerprinting.
-   **Monero Cross-Chain Correlation Engine™**: Module for real-time and historical backtrace of attacker wallets.
-   **DAU v2 "Dye Pack Protocol"™**: Deployed forensic tracking token with off-chain listener and full trace engine.
-   **Alpha Proceeds Forward-Trace Engine™**: Module for BFS forward-tracing from top dumpers.
-   **Alpha Dev-Dumper Collusion Detector™**: Embedded in dump analysis scripts.
-   **RAVEDAO_DUMP Case Tools**: Master script for coordinated dump forensic analysis.
-   **Alpha Proprietary Software Guard™**: Module for license enforcement and anti-tamper.
-   **Alpha Multi-Chain Wallet Tracer™**: Module for unified ETH/Polygon/Arbitrum/Optimism/Base wallet activity feeds.
-   **Alpha Web Archive Forensic Snapshotter™**: Module for Wayback Machine CDX integration and rug-pull scoring.
-   **Alpha Smart-Money Flow Signal™**: Module for tracking smart-money on-chain movements and emitting trading signals.
-   **Alpha Bridge Capital-Rotation Signal™**: Module for monitoring L1→L2 bridges and emitting ecosystem-rotation signals.
-   **Alpha Universal Chain Adapter Layer™ (UCAL)**: Cross-ecosystem adapter providing parity coverage across **EVM** (Ethereum/Polygon/Arbitrum/Optimism/Base via Alchemy), **Solana** (Alchemy SOL RPC), **Bitcoin** (mempool.space, UTXO-aware), **Tron** (TronGrid), **TON** (TonAPI), and **XRP Ledger** (xrplcluster.com public JSON-RPC + XRPSCAN labels). It offers unified primitives like `getNativeBalance`, `getAddressProfile`, `getTransfers`, `getCounterparties`, and `explorerUrl`. Every UCAL-aware tech (Universal Forensics Engine, Multi-Chain Wallet Tracer, Spider Trace, Pivot Surveillance, Amount Correlation Scanner, register_and_trace tooling, etc.) automatically inherits XRPL coverage.
-   **Alpha Universal Forensics Engine™**: Exposes functions like `traceWalletUniversal()`, `traceWalletAcrossEcosystem()`, `runSpiderTraceUniversal()`, `pivotSurveillanceUniversal()`, and `correlateAmountUniversal()` which leverage UCAL for multi-chain forensic analysis.
-   **Alpha Solana On-Chain Rug-Risk Scorer™**: Computes a 0–100 rug-pull risk score for any Solana SPL token using live on-chain data — mint authority status, freeze authority status, top-10 holder concentration, and pump.fun bonding-curve status. Correct tool for memecoins (which lack project websites required by the Web Archive Snapshotter).
-   **Alpha Forensic Flow Visualizer™**: TRM-Labs / Chainalysis-Reactor-style SVG flow diagram generator for any wallet trace (forward, backward, or bidirectional). Renders hop-lane columns, root hexagons, intermediary/exchange/mixer/bridge node classification, and edges labeled with amount + asset + timestamp. Ingests `{nodes, edges}` from any forensic trace JSON. Used by `private/tools/generateFlowDiagram.ts` (CLI runner: `npx tsx private/tools/generateFlowDiagram.ts <traceJson> [--title=... --case=... --chain=... --direction=forward|backward|bidirectional]`). Outputs `.svg` + standalone `.html`. **Auto-emitted by every theft/trace tool** via the universal helper `private/forensics/autoEmitFlowDiagram.ts` — wired into: `private/tools/maga_rug_and_100wallet_trace.ts`, `private/tools/maga_44k_case_report.ts`, `private/tools/maga_universal_rerun.ts`, `contracts/atc/ravedao_forward_trace.ts`, `contracts/atc/ravedao_deep_forward_trace.ts`, `contracts/atc/ravedao_dump_analysis.ts`, `contracts/atc/sillytuna_full_backtrace.ts`, `contracts/atc/sillytuna_attacker_verification.ts`, `contracts/atc/sillytuna_victim_distinction.ts`, `contracts/atc/sillytuna_activity_overlay.ts`, `contracts/atc/DAUv2_FullTrace.ts`, and `server/scripts/sendComprehensiveSillyTunaForensics.ts`. The helper auto-detects 6+ JSON shapes (`{nodes,edges}`, `{wallets,transfers}`, `{transactions}`, `{traces[].transfers}`, `{dumpers[].sentTo+backTrace}`, `{walletReports[].chains[].topCounterparties}`, `{allWallets[].discoveredVia}`, `{reports[].backTraceNodes[].fundedBy}`) and never throws — failures are logged and swallowed so report writes are never blocked.

### API Services
-   SEAL Team DAU Monitoring API

### Third-Party Integrations
-   **AI Integrations**: OpenAI GPT-4o-mini (via Replit AI Integrations).
-   **Payment Processing**: Stripe.
-   **Email Service**: SendGrid, AgentMail.
-   **Mining Companion**: AlphaUnlimited-Miner.replit.app.
-   **Prediction Markets**: Polymarket, Kalshi, Manifold Markets.

### HTML-Based Apps & Reports
-   `public/downloads/QMGE-Standalone.html`
-   **Alpha Universal Scanner™ v4.0.0**: A private, authorized-use-only Python tool for code, network, security, exploit, and quality analysis across 36 languages, distributed in OS-specific zip bundles.
-   **Alpha Vulnerability Verifier™ v2.0.0**: A private, authorized-use-only Python tool to re-probe findings from Alpha Scanner reports against live targets.
-   **Alpha Web Scraper™**: Standalone HTML application for web scraping (not web-accessible).
-   Dynamic HTML forensic report generator in `server/routes.ts`
-   `SillyTuna_Forensic/sillytuna_forensic_report.html`
-   `private/dossier-package/Recovery-Dossier.html`
-   PPTX generator for Law Enforcement Briefing in `server/routes.ts`