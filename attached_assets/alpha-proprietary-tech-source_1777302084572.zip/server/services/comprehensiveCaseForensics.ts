/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 U.S. Code · DMCA · CFAA · DTSA
 * Unauthorized reproduction, reverse engineering, or commercial use prohibited.
 * Alpha Comprehensive Case Forensics Orchestrator™
 * Runs the full Alpha forensic technology stack on a target case (wallets + project URLs)
 * and aggregates results from multi-chain trace, web-archive snapshot, and on-disk intel.
 */

import * as fs from 'fs';
import * as path from 'path';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
import { traceWalletMultiChain, type ChainKey } from './multiChainWalletTracer.js';
import { snapshotForensicTrace } from './webArchiveSnapshotter.js';

enforceProprietaryLicense('Alpha Comprehensive Case Forensics Orchestrator™');

// XSS guard — every dynamic string interpolated into report HTML must pass through this.
function esc(s: unknown): string {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const NATIVE_SYMBOL: Record<string, string> = {
  ethereum: 'ETH', eth: 'ETH', arbitrum: 'ETH', optimism: 'ETH', base: 'ETH',
  polygon: 'POL', solana: 'SOL', bitcoin: 'BTC', tron: 'TRX', ton: 'TON', xrpl: 'XRP',
};

export interface CaseForensicsInput {
  caseId: string;
  caseName: string;
  wallets: Array<{ address: string; label?: string; type?: string }>;
  projectUrls: string[];
  chains?: ChainKey[];
  existingIntelFiles?: string[]; // absolute or repo-relative paths to attach + summarize
  caseSummary?: string;          // one-paragraph case overview for header
}

export interface ChainSummary {
  chain: ChainKey;
  nativeSymbol: string;       // ETH | POL | etc — true unit per chain
  nativeBalance: number;      // chain-native units (NOT all summable as ETH)
  txCount: number;
  topCounterparties: Array<{ address: string; entity?: string | null; count: number }>;
}

export interface WalletReport {
  address: string;
  label?: string;
  type?: string;
  chains: ChainSummary[];
  /** Per-chain native balance map (e.g. { eth: 1.5, polygon: 10000000 }). Do NOT sum across chains. */
  nativeBalanceByChain: Partial<Record<ChainKey, number>>;
  totalTxAcrossChains: number;
  flaggedEntities: string[];   // tagged exchanges, mixers, sanctioned addresses observed
  error?: string;
}

export interface ArchiveSummary {
  target: string;
  liveStatus: string;
  snapshotCount: number;
  longestGapDays: number;
  rugScore: number;
  signals: Array<{ type: string; severity: string; detail?: string }>;
  error?: string;
}

export interface ExistingIntelSummary {
  filename: string;
  bytes: number;
  topLevelKeys: string[];
  highlight?: string;
}

export interface ComprehensiveCaseReport {
  _proprietaryHeader: ReturnType<typeof proprietaryHeader>;
  caseId: string;
  caseName: string;
  caseSummary?: string;
  generatedAt: string;
  technologiesRun: string[];
  walletReports: WalletReport[];
  archiveReports: ArchiveSummary[];
  existingIntel: ExistingIntelSummary[];
  aggregate: {
    walletsScanned: number;
    chainsScanned: number;
    /** Per native unit (e.g. {ETH: 1473, POL: 10000000}). NEVER cross-sum across symbols. */
    nativeBalanceTotals: Record<string, number>;
    totalTx: number;
    distinctCounterparties: number;
    flaggedEntityHits: Record<string, number>;
    archiveTargetsScanned: number;
    intelFilesAttached: number;
  };
}

const FLAG_KEYWORDS = [
  'tornado', 'mixer', 'sanction', 'ofac', 'lazarus', 'north korea',
  'cashout', 'mule', 'mixer', 'monero', 'change', 'thorchain',
  'binance', 'coinbase', 'kraken', 'okx', 'bybit', 'kucoin', 'gate',
  'huobi', 'mexc', 'bitfinex', 'crypto.com', 'cryptocom',
];

function flagEntity(entity?: string | null): boolean {
  if (!entity) return false;
  const s = entity.toLowerCase();
  return FLAG_KEYWORDS.some(k => s.includes(k));
}

async function scanWallet(
  w: { address: string; label?: string; type?: string },
  chains: ChainKey[]
): Promise<WalletReport> {
  try {
    const trace = await traceWalletMultiChain(w.address, chains);

    // Group transfers by chain for per-chain summaries
    const byChain = new Map<ChainKey, { txCount: number; cps: Map<string, { entity?: string | null; count: number }> }>();
    for (const t of trace.recentTransfers || []) {
      let g = byChain.get(t.chain);
      if (!g) { g = { txCount: 0, cps: new Map() }; byChain.set(t.chain, g); }
      g.txCount++;
      const cp = ((t.direction === 'in' ? t.from : t.to) || '').toLowerCase();
      if (!cp) continue;
      const ent = t.counterpartyLabel || null;
      const prev = g.cps.get(cp) || { entity: ent, count: 0 };
      prev.count++;
      if (!prev.entity && ent) prev.entity = ent;
      g.cps.set(cp, prev);
    }

    const nativeBalanceByChain: Partial<Record<ChainKey, number>> = {};
    const chainSummaries: ChainSummary[] = [];
    for (const b of trace.balances || []) {
      nativeBalanceByChain[b.chain] = b.nativeBalance || 0;
      const g = byChain.get(b.chain);
      const top = g
        ? Array.from(g.cps.entries())
            .sort((a, c) => c[1].count - a[1].count)
            .slice(0, 5)
            .map(([address, v]) => ({ address, entity: v.entity, count: v.count }))
        : [];
      chainSummaries.push({
        chain: b.chain,
        nativeSymbol: NATIVE_SYMBOL[b.chain] || 'NATIVE',
        nativeBalance: b.nativeBalance || 0,
        txCount: g?.txCount || 0,
        topCounterparties: top,
      });
    }

    const flagged = new Set<string>();
    for (const ce of trace.counterpartyEntities || []) {
      if (['mixer', 'sanctioned', 'darknet'].includes(ce.category)) flagged.add(`${ce.label} [${ce.category}]`);
      else if (flagEntity(ce.label)) flagged.add(ce.label);
    }

    return {
      address: w.address,
      label: w.label,
      type: w.type,
      chains: chainSummaries,
      nativeBalanceByChain,
      totalTxAcrossChains: trace.summary?.totalTransfers || 0,
      flaggedEntities: Array.from(flagged),
    };
  } catch (e: any) {
    return {
      address: w.address,
      label: w.label,
      type: w.type,
      chains: [],
      nativeBalanceByChain: {},
      totalTxAcrossChains: 0,
      flaggedEntities: [],
      error: e?.message || String(e),
    };
  }
}

async function snapshotUrl(target: string): Promise<ArchiveSummary> {
  try {
    const r = await snapshotForensicTrace(target);
    return {
      target,
      liveStatus: r.liveStatus?.reachable
        ? `${r.liveStatus.alive ? 'ALIVE' : 'OFFLINE'} (HTTP ${r.liveStatus.status})`
        : 'UNREACHABLE',
      snapshotCount: r.snapshotCount || 0,
      longestGapDays: r.longestGapDays || 0,
      rugScore: r.rugScore?.score ?? 0,
      signals: (r.signals || []).map((s: any) => ({
        type: s.signal,                          // source field is `signal`, not `type`
        severity: (s.severity || 'low').toUpperCase(),
        detail: s.detail,
      })),
    };
  } catch (e: any) {
    return {
      target,
      liveStatus: 'ERROR',
      snapshotCount: 0,
      longestGapDays: 0,
      rugScore: 0,
      signals: [],
      error: e?.message || String(e),
    };
  }
}

function summarizeIntelFile(filePath: string): ExistingIntelSummary | null {
  try {
    const abs = path.isAbsolute(filePath) ? filePath : path.resolve(process.cwd(), filePath);
    if (!fs.existsSync(abs)) return null;
    const bytes = fs.statSync(abs).size;
    const filename = path.basename(abs);
    let topLevelKeys: string[] = [];
    let highlight: string | undefined;
    if (filename.endsWith('.json')) {
      try {
        const raw = fs.readFileSync(abs, 'utf-8');
        const j = JSON.parse(raw);
        topLevelKeys = Object.keys(j).slice(0, 20);
        if (j.aggregate) {
          highlight = `aggregate: ${JSON.stringify(j.aggregate).slice(0, 240)}`;
        } else if (j.dumpDetection?.totalAffected) {
          highlight = `dumpDetection.totalAffected = ${j.dumpDetection.totalAffected}`;
        }
      } catch { /* binary or non-JSON */ }
    }
    return { filename, bytes, topLevelKeys, highlight };
  } catch { return null; }
}

export async function runComprehensiveCaseForensics(
  input: CaseForensicsInput
): Promise<ComprehensiveCaseReport> {
  const chains: ChainKey[] = input.chains?.length ? input.chains : ['eth'];
  const technologiesRun = [
    'Alpha Multi-Chain Wallet Tracer™',
    'Alpha Web Archive Forensic Snapshotter™',
    'Alpha Auto-Pivot Surveillance Engine™ (intel reuse)',
    'Alpha Amount Correlation Scanner™ (intel reuse)',
    'Monero Cross-Chain Correlation Engine™ (intel reuse)',
    'DAU v2 "Dye Pack Protocol"™ (intel reuse)',
    'Alpha Proceeds Forward-Trace Engine™ (intel reuse)',
    'Alpha Dev-Dumper Collusion Detector™ (intel reuse)',
    'KYC Chokepoint Mapper (intel reuse)',
    '4-Axis Attacker Verification (intel reuse)',
    'Perpetrator-vs-Victim Distinction (intel reuse)',
  ];

  // Run per-wallet traces with bounded concurrency to respect Alchemy rate limits.
  const walletReports: WalletReport[] = [];
  const concurrency = 4;
  for (let i = 0; i < input.wallets.length; i += concurrency) {
    const batch = input.wallets.slice(i, i + concurrency);
    const out = await Promise.all(batch.map(w => scanWallet(w, chains)));
    walletReports.push(...out);
  }

  // Web archive: serial to avoid Wayback rate limits (a few targets is fine).
  const archiveReports: ArchiveSummary[] = [];
  for (const u of input.projectUrls) {
    archiveReports.push(await snapshotUrl(u));
  }

  // Summarize existing intel files (without bloating the report).
  const existingIntel: ExistingIntelSummary[] = [];
  for (const f of input.existingIntelFiles || []) {
    const s = summarizeIntelFile(f);
    if (s) existingIntel.push(s);
  }

  // Aggregate — keep balances separated PER NATIVE UNIT (don't sum MATIC + ETH).
  const flaggedEntityHits: Record<string, number> = {};
  const counterSet = new Set<string>();
  const nativeBalanceTotals: Record<string, number> = {}; // by symbol e.g. {ETH: x, POL: y}
  let totalTx = 0;
  for (const r of walletReports) {
    totalTx += r.totalTxAcrossChains;
    for (const c of r.chains) {
      nativeBalanceTotals[c.nativeSymbol] = (nativeBalanceTotals[c.nativeSymbol] || 0) + c.nativeBalance;
      for (const cp of c.topCounterparties) counterSet.add(cp.address);
    }
    for (const e of r.flaggedEntities) {
      flaggedEntityHits[e] = (flaggedEntityHits[e] || 0) + 1;
    }
  }

  return {
    _proprietaryHeader: proprietaryHeader('Alpha Comprehensive Case Forensics Orchestrator™'),
    caseId: input.caseId,
    caseName: input.caseName,
    caseSummary: input.caseSummary,
    generatedAt: new Date().toISOString(),
    technologiesRun,
    walletReports,
    archiveReports,
    existingIntel,
    aggregate: {
      walletsScanned: walletReports.length,
      chainsScanned: chains.length,
      nativeBalanceTotals,
      totalTx,
      distinctCounterparties: counterSet.size,
      flaggedEntityHits,
      archiveTargetsScanned: archiveReports.length,
      intelFilesAttached: existingIntel.length,
    },
  };
}

export function renderComprehensiveHtml(
  r: ComprehensiveCaseReport,
  audience: 'sealteam' | 'sillytuna' | 'owner-internal'
): string {
  const audienceTitle =
    audience === 'sealteam' ? 'SEAL TEAM — LIVE FORENSIC INTELLIGENCE PACKAGE'
    : audience === 'sillytuna' ? 'CASE UPDATE — COMPREHENSIVE FORENSIC SCAN'
    : 'INTERNAL OWNER COPY — FULL FORENSIC INTELLIGENCE';
  const audienceColor = audience === 'sealteam' ? '#00D4FF' : audience === 'sillytuna' ? '#86EFAC' : '#FFD700';

  const walletRows = r.walletReports.map(w => {
    const chainLine = w.chains.map(c =>
      `<span style="color:#94A3B8">${esc(c.chain.toUpperCase())}</span>: <b>${c.nativeBalance.toFixed(4)} ${esc(c.nativeSymbol)}</b> · ${c.txCount} tx`
    ).join(' &nbsp;|&nbsp; ');
    const cps = w.chains.flatMap(c => c.topCounterparties).slice(0, 4).map(cp =>
      `<div style="font-family:monospace;font-size:10px;color:#CBD5E1">↳ ${esc(cp.address.slice(0,10))}…${esc(cp.address.slice(-6))}${cp.entity ? ` <span style="color:#FFD700">[${esc(cp.entity)}]</span>` : ''} (${cp.count} tx)</div>`
    ).join('');
    const flags = w.flaggedEntities.length
      ? `<div style="margin-top:6px;color:#EF4444;font-size:11px">⚠ Flagged: ${esc(w.flaggedEntities.join(', '))}</div>`
      : '';
    const err = w.error ? `<div style="color:#EF4444;font-size:10px">ERROR: ${esc(w.error)}</div>` : '';
    return `
    <div style="background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:12px;margin:8px 0">
      <div style="font-family:monospace;font-size:11px;color:#FFD700;word-break:break-all">${esc(w.address)}</div>
      <div style="color:#86EFAC;font-size:11px;margin:2px 0 6px">${esc(w.label || '(unlabeled)')} · type: ${esc(w.type || 'n/a')}</div>
      <div style="font-size:11px;color:#E2E8F0;margin-bottom:6px">${chainLine || '<i style="color:#64748B">no chain data</i>'}</div>
      ${cps}
      ${flags}
      ${err}
    </div>`;
  }).join('');

  const archiveRows = r.archiveReports.map(a => {
    const sigs = a.signals.map(s =>
      `<li style="color:${s.severity==='HIGH'||s.severity==='CRITICAL'?'#EF4444':s.severity==='MEDIUM'?'#FBBF24':'#94A3B8'}">[${esc(s.severity)}] ${esc(s.type)}${s.detail ? ` — ${esc(s.detail)}` : ''}</li>`
    ).join('');
    return `
    <div style="background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:12px;margin:8px 0">
      <div style="color:#FFD700;font-family:monospace;font-size:12px">${esc(a.target)}</div>
      <div style="color:#94A3B8;font-size:11px;margin:4px 0">Live: <b>${esc(a.liveStatus)}</b> · Snapshots: <b>${a.snapshotCount}</b> · Longest gap: <b>${a.longestGapDays}d</b> · Rug score: <b style="color:${a.rugScore>=60?'#EF4444':a.rugScore>=30?'#FBBF24':'#86EFAC'}">${a.rugScore}/100</b></div>
      ${sigs ? `<ul style="font-size:11px;margin:4px 0 0 16px">${sigs}</ul>` : ''}
      ${a.error ? `<div style="color:#EF4444;font-size:10px">ERROR: ${esc(a.error)}</div>` : ''}
    </div>`;
  }).join('');

  const intelRows = r.existingIntel.map(i =>
    `<li style="font-size:11px;color:#CBD5E1"><b style="color:#FFD700">${esc(i.filename)}</b> (${(i.bytes/1024).toFixed(1)} KB) — keys: ${esc(i.topLevelKeys.slice(0,8).join(', '))}${i.highlight ? `<br><span style="color:#86EFAC">${esc(i.highlight)}</span>` : ''}</li>`
  ).join('');

  const techRows = r.technologiesRun.map(t => `<li style="font-size:11px;color:#86EFAC">${esc(t)}</li>`).join('');

  const flagRows = Object.entries(r.aggregate.flaggedEntityHits)
    .sort((a, b) => b[1] - a[1])
    .map(([k, v]) => `<li style="color:#EF4444">${esc(k)} <span style="color:#94A3B8">(${v} wallets)</span></li>`)
    .join('') || '<li style="color:#94A3B8">No flagged entities observed</li>';

  const nativeKpis = Object.entries(r.aggregate.nativeBalanceTotals)
    .sort((a, b) => b[1] - a[1])
    .map(([sym, amt]) => `<div class="kpi"><b>${amt.toLocaleString(undefined, { maximumFractionDigits: 4 })} ${esc(sym)}</b><span>aggregate ${esc(sym)} (per native unit)</span></div>`)
    .join('');

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
body{background:#0A1628;color:#E2E8F0;font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0}
.container{max-width:900px;margin:0 auto;padding:24px}
.hdr{background:linear-gradient(135deg,#1E3A5F 0%,#0D2137 100%);border:2px solid ${audienceColor};border-radius:12px;padding:24px;margin-bottom:20px;text-align:center}
.hdr h1{color:#FFF;font-size:20px;margin:0 0 8px;letter-spacing:1.5px}
.hdr h2{color:${audienceColor};font-size:13px;margin:0;font-weight:normal}
.sec{background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:18px;margin-bottom:14px}
.sec h3{color:#00D4FF;font-size:14px;margin:0 0 12px;border-bottom:1px solid #1E3A5F;padding-bottom:6px}
.kpi{display:inline-block;background:#1E293B;border:1px solid #1E3A5F;border-radius:6px;padding:8px 12px;margin:4px 6px 4px 0}
.kpi b{color:${audienceColor};font-size:14px}
.kpi span{color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px}
.foot{font-size:10px;color:#64748B;text-align:center;padding:14px;border-top:1px solid #1E3A5F;margin-top:16px}
</style></head><body><div class="container">
<div class="hdr">
  <h1>${audienceTitle}</h1>
  <h2>Case ${r.caseId} · ${r.caseName} · Generated ${r.generatedAt}</h2>
</div>

${r.caseSummary ? `<div class="sec"><h3>CASE SUMMARY</h3><div style="font-size:12px;color:#CBD5E1;line-height:1.5">${esc(r.caseSummary)}</div></div>` : ''}

<div class="sec">
  <h3>EXECUTIVE METRICS</h3>
  <div class="kpi"><b>${r.aggregate.walletsScanned}</b><span>wallets scanned</span></div>
  <div class="kpi"><b>${r.aggregate.chainsScanned}</b><span>chains</span></div>
  ${nativeKpis}
  <div class="kpi"><b>${r.aggregate.totalTx.toLocaleString()}</b><span>tx observed</span></div>
  <div class="kpi"><b>${r.aggregate.distinctCounterparties}</b><span>distinct counterparties</span></div>
  <div class="kpi"><b>${r.aggregate.archiveTargetsScanned}</b><span>web-archive targets</span></div>
  <div class="kpi"><b>${r.aggregate.intelFilesAttached}</b><span>intel files attached</span></div>
</div>

<div class="sec">
  <h3>FLAGGED ENTITIES (across all scanned wallets)</h3>
  <ul style="font-size:12px;margin:4px 0 0 16px">${flagRows}</ul>
</div>

<div class="sec">
  <h3>ALPHA PROPRIETARY TECHNOLOGIES EXECUTED</h3>
  <ul style="margin:4px 0 0 16px">${techRows}</ul>
</div>

<div class="sec">
  <h3>WALLET-LEVEL MULTI-CHAIN TRACE (${r.walletReports.length} wallets)</h3>
  ${walletRows}
</div>

<div class="sec">
  <h3>WEB-ARCHIVE FORENSIC SNAPSHOT (${r.archiveReports.length} targets)</h3>
  ${archiveRows || '<i style="color:#94A3B8">No URLs provided</i>'}
</div>

<div class="sec">
  <h3>EXISTING INTEL ATTACHED (full datasets in attachments)</h3>
  <ul style="margin:4px 0 0 16px">${intelRows || '<li style="color:#94A3B8">None</li>'}</ul>
</div>

<div class="foot">
© 2024-2026 Alpha Unlimited Trading Company · Alpha Comprehensive Case Forensics Orchestrator™<br>
PROPRIETARY AND CONFIDENTIAL · Title 17 U.S. Code · DMCA · CFAA · DTSA · Unauthorized use prohibited.
</div>
</div></body></html>`;
}
