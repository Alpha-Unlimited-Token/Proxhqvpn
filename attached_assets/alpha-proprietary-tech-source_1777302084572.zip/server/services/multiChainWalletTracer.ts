/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Multi-Chain Wallet Tracer™
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws (Title 17 / DMCA / CFAA / DTSA).
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Patent Pending. Trade Secret Protected.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
import { lookupAddress } from './addressLabelDatabase.js';

enforceProprietaryLicense('Alpha Multi-Chain Wallet Tracer™');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';

export const SUPPORTED_CHAINS = {
  ethereum:  { name: 'Ethereum',  alchemy: 'eth-mainnet',  nativeSymbol: 'ETH'  },
  polygon:   { name: 'Polygon',   alchemy: 'polygon-mainnet', nativeSymbol: 'MATIC' },
  arbitrum:  { name: 'Arbitrum',  alchemy: 'arb-mainnet',  nativeSymbol: 'ETH'  },
  optimism:  { name: 'Optimism',  alchemy: 'opt-mainnet',  nativeSymbol: 'ETH'  },
  base:      { name: 'Base',      alchemy: 'base-mainnet', nativeSymbol: 'ETH'  },
} as const;

export type ChainKey = keyof typeof SUPPORTED_CHAINS;

interface TraceTransfer {
  chain: ChainKey;
  hash: string;
  blockNum: number;
  ts: number | null;
  from: string;
  to: string;
  asset: string;
  category: string;
  rawValue: string;
  value: number;
  direction: 'in' | 'out';
  counterpartyLabel: string | null;
  counterpartyCategory: string | null;
}

interface ChainBalance {
  chain: ChainKey;
  nativeBalance: number;
  tokenCount: number;
  topTokens: { symbol: string; balance: number; contract: string }[];
}

export interface WalletTraceReport {
  _proprietaryHeader: string;
  wallet: string;
  generatedAt: string;
  chainsScanned: ChainKey[];
  balances: ChainBalance[];
  recentTransfers: TraceTransfer[];
  counterpartyEntities: { address: string; label: string; category: string; hits: number }[];
  summary: {
    totalTransfers: number;
    inboundCount: number;
    outboundCount: number;
    uniqueCounterparties: number;
    flaggedCounterparties: number;
  };
}

async function alchemyRpc<T = any>(chain: ChainKey, method: string, params: any[]): Promise<T> {
  const url = `https://${SUPPORTED_CHAINS[chain].alchemy}.g.alchemy.com/v2/${ALCHEMY_KEY}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  if (!r.ok) throw new Error(`Alchemy ${chain} ${method} failed: ${r.status}`);
  const j = await r.json();
  if (j.error) throw new Error(`Alchemy ${chain} ${method} error: ${j.error.message}`);
  return j.result;
}

async function getNativeBalance(chain: ChainKey, address: string): Promise<number> {
  const hex: string = await alchemyRpc(chain, 'eth_getBalance', [address, 'latest']);
  return Number(BigInt(hex)) / 1e18;
}

async function getTokenBalances(chain: ChainKey, address: string): Promise<{ symbol: string; balance: number; contract: string }[]> {
  try {
    const res: any = await alchemyRpc(chain, 'alchemy_getTokenBalances', [address, 'erc20']);
    const balances = (res?.tokenBalances || []).filter((b: any) => b.tokenBalance && b.tokenBalance !== '0x' && b.tokenBalance !== '0x0');
    const top = balances.slice(0, 10);
    const enriched = await Promise.all(top.map(async (b: any) => {
      try {
        const meta: any = await alchemyRpc(chain, 'alchemy_getTokenMetadata', [b.contractAddress]);
        const decimals = meta?.decimals ?? 18;
        const raw = BigInt(b.tokenBalance);
        const divisor = BigInt(10) ** BigInt(decimals);
        const intPart = raw / divisor;
        const fracPart = raw % divisor;
        const balance = Number(intPart) + Number(fracPart) / Number(divisor);
        return { symbol: meta?.symbol || 'UNKNOWN', balance, contract: b.contractAddress };
      } catch {
        return { symbol: 'UNKNOWN', balance: 0, contract: b.contractAddress };
      }
    }));
    return enriched.filter(t => t.balance > 0);
  } catch {
    return [];
  }
}

async function getTransfers(chain: ChainKey, address: string, direction: 'in' | 'out', maxCount = 25): Promise<TraceTransfer[]> {
  const params = direction === 'in'
    ? { toAddress: address, category: ['external', 'erc20', 'internal'], maxCount: `0x${maxCount.toString(16)}`, withMetadata: true, order: 'desc' }
    : { fromAddress: address, category: ['external', 'erc20', 'internal'], maxCount: `0x${maxCount.toString(16)}`, withMetadata: true, order: 'desc' };
  try {
    const res: any = await alchemyRpc(chain, 'alchemy_getAssetTransfers', [params]);
    return (res?.transfers || []).map((t: any) => {
      const counterparty = (direction === 'in' ? t.from : t.to)?.toLowerCase() || '';
      const lbl = counterparty ? lookupAddress(counterparty) : null;
      return {
        chain,
        hash: t.hash,
        blockNum: parseInt(t.blockNum, 16),
        ts: t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).getTime() : null,
        from: (t.from || '').toLowerCase(),
        to: (t.to || '').toLowerCase(),
        asset: t.asset || 'UNKNOWN',
        category: t.category,
        rawValue: t.rawContract?.value || '0x0',
        value: typeof t.value === 'number' ? t.value : 0,
        direction,
        counterpartyLabel: lbl?.name || null,
        counterpartyCategory: lbl?.category || null,
      } as TraceTransfer;
    });
  } catch {
    return [];
  }
}

export async function traceWalletMultiChain(
  wallet: string,
  chains: ChainKey[] = ['ethereum', 'polygon', 'arbitrum', 'optimism', 'base'],
  perDirectionCount = 20,
): Promise<WalletTraceReport> {
  if (!ALCHEMY_KEY) throw new Error('ALCHEMY_API_KEY is not set');
  const w = wallet.toLowerCase();

  const balances: ChainBalance[] = [];
  const allTransfers: TraceTransfer[] = [];

  for (const chain of chains) {
    try {
      const [nativeBalance, tokens, ins, outs] = await Promise.all([
        getNativeBalance(chain, w),
        getTokenBalances(chain, w),
        getTransfers(chain, w, 'in', perDirectionCount),
        getTransfers(chain, w, 'out', perDirectionCount),
      ]);
      balances.push({ chain, nativeBalance, tokenCount: tokens.length, topTokens: tokens.slice(0, 5) });
      allTransfers.push(...ins, ...outs);
    } catch (err) {
      balances.push({ chain, nativeBalance: 0, tokenCount: 0, topTokens: [] });
    }
  }

  allTransfers.sort((a, b) => (b.ts || 0) - (a.ts || 0));

  const counterpartyMap: Record<string, { address: string; label: string; category: string; hits: number }> = {};
  for (const t of allTransfers) {
    if (!t.counterpartyLabel) continue;
    const cp = t.direction === 'in' ? t.from : t.to;
    if (!counterpartyMap[cp]) counterpartyMap[cp] = { address: cp, label: t.counterpartyLabel, category: t.counterpartyCategory || 'unknown', hits: 0 };
    counterpartyMap[cp].hits++;
  }

  const inboundCount = allTransfers.filter(t => t.direction === 'in').length;
  const outboundCount = allTransfers.filter(t => t.direction === 'out').length;
  const uniqueCps = new Set([...allTransfers.map(t => t.direction === 'in' ? t.from : t.to)]);
  const flagged = Object.values(counterpartyMap).filter(c => ['mixer', 'sanctioned', 'darknet'].includes(c.category)).length;

  return {
    _proprietaryHeader: proprietaryHeader('Alpha Multi-Chain Wallet Tracer™'),
    wallet: w,
    generatedAt: new Date().toISOString(),
    chainsScanned: chains,
    balances,
    recentTransfers: allTransfers.slice(0, 100),
    counterpartyEntities: Object.values(counterpartyMap).sort((a, b) => b.hits - a.hits),
    summary: {
      totalTransfers: allTransfers.length,
      inboundCount,
      outboundCount,
      uniqueCounterparties: uniqueCps.size,
      flaggedCounterparties: flagged,
    },
  };
}
