/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Bot Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import crypto from "crypto";
import WebSocket from "ws";
import { storage } from "../storage";
import type { ServerBot } from "@shared/schema";
import { registerBeacon } from "./integrityBeacon.js";
import { executeOrder as executeExchangeOrder, SUPPORTED_EXCHANGES, FUTURES_SUPPORTED_EXCHANGES, executeFuturesOrder, closeFuturesPosition } from "./exchangeAdapter.js";
import type { FuturesOrderParams } from "./exchangeAdapter.js";

export const _botEngineCalibration = 'AUT_f1bd010095eb0bf6665ef6be';
const _botIntegrityValid = registerBeacon('botEngine', _botEngineCalibration);
if (!_botEngineCalibration?.startsWith('AUT_') || !_botIntegrityValid) {
  throw new Error('Bot Engine™ module integrity compromised — unauthorized modification detected');
}

const ENCRYPTION_ALGORITHM = "aes-256-gcm";

function getEncryptionKey(): Buffer {
  const key = process.env.ENCRYPTION_KEY || process.env.SESSION_SECRET || "alpha-unlimited-default-key-32ch";
  return crypto.createHash("sha256").update(key).digest();
}

export function decryptApiKey(encryptedText: string): string {
  const [ivHex, authTagHex, encrypted] = encryptedText.split(":");
  const key = getEncryptionKey();
  const iv = Buffer.from(ivHex, "hex");
  const authTag = Buffer.from(authTagHex, "hex");
  const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv, { authTagLength: 16 });
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encrypted, "hex", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted.trim();
}

interface PriceData {
  symbol: string;
  price: number;
  priceChange: number;
  priceChangePercent: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  updatedAt: number;
}

interface Signal {
  direction: "BUY" | "SELL" | "HOLD";
  strength: number;
  confidence: number;
  reason: string;
}

interface ExchangeFees {
  maker: number;
  taker: number;
  name: string;
}

const EXCHANGE_FEE_SCHEDULE: Record<string, ExchangeFees> = {
  kraken:     { maker: 0.0016, taker: 0.0026, name: "Kraken" },
  binance:    { maker: 0.001,  taker: 0.001,  name: "Binance" },
  binanceus:  { maker: 0.001,  taker: 0.001,  name: "Binance.US" },
  coinbase:   { maker: 0.004,  taker: 0.006,  name: "Coinbase" },
  bybit:      { maker: 0.001,  taker: 0.001,  name: "Bybit" },
  okx:        { maker: 0.0008, taker: 0.001,  name: "OKX" },
  gateio:     { maker: 0.002,  taker: 0.002,  name: "Gate.io" },
  bitget:     { maker: 0.001,  taker: 0.001,  name: "Bitget" },
  kucoin:     { maker: 0.001,  taker: 0.001,  name: "KuCoin" },
  mexc:       { maker: 0.0,    taker: 0.001,  name: "MEXC" },
  htx:        { maker: 0.002,  taker: 0.002,  name: "HTX" },
  bitfinex:   { maker: 0.001,  taker: 0.002,  name: "Bitfinex" },
  bitstamp:   { maker: 0.003,  taker: 0.005,  name: "Bitstamp" },
  gemini:     { maker: 0.002,  taker: 0.004,  name: "Gemini" },
  cryptocom:  { maker: 0.0014, taker: 0.0016, name: "Crypto.com" },
  deribit:    { maker: 0.0001, taker: 0.0005, name: "Deribit" },
  bitmex:     { maker: -0.00025, taker: 0.00075, name: "BitMEX" },
  primexbt:   { maker: 0.0005, taker: 0.0005, name: "PrimeXBT" },
  phemex:     { maker: 0.001,  taker: 0.001,  name: "Phemex" },
  lbank:      { maker: 0.001,  taker: 0.001,  name: "LBank" },
  coinex:     { maker: 0.002,  taker: 0.002,  name: "CoinEx" },
  bitflyer:   { maker: 0.0015, taker: 0.0015, name: "bitFlyer" },
  bithumb:    { maker: 0.0025, taker: 0.0025, name: "Bithumb" },
  upbit:      { maker: 0.0025, taker: 0.0025, name: "Upbit" },
};

export function getExchangeFees(exchange: string): ExchangeFees {
  return EXCHANGE_FEE_SCHEDULE[exchange.toLowerCase()] || { maker: 0.002, taker: 0.002, name: exchange };
}

function calcRoundTripFees(exchange: string, investment: number): { buyFee: number; sellFee: number; totalFees: number; feePercent: number } {
  const fees = getExchangeFees(exchange);
  const buyFee = investment * fees.taker;
  const sellFee = investment * fees.taker;
  const totalFees = buyFee + sellFee;
  return { buyFee, sellFee, totalFees, feePercent: (totalFees / investment) * 100 };
}

function isSellProfitableAfterFees(
  entryPrice: number,
  currentPrice: number,
  quantity: number,
  exchange: string,
  signalStrength: number
): { profitable: boolean; grossPnl: number; netPnl: number; fees: number; feeBreakdown: string; minProfitPrice: number } {
  const fees = getExchangeFees(exchange);
  const buyValue = entryPrice * quantity;
  const sellValue = currentPrice * quantity;
  const buyFee = buyValue * fees.taker;
  const sellFee = sellValue * fees.taker;
  const totalFees = buyFee + sellFee;
  const grossPnl = sellValue - buyValue;
  const netPnl = grossPnl - totalFees;

  const strengthMultiplier = signalStrength >= 80 ? 1.0 : signalStrength >= 65 ? 1.5 : 2.0;
  const minNetProfit = totalFees * (strengthMultiplier - 1);
  const profitable = netPnl > minNetProfit;

  const feeRatio = fees.taker * 2;
  const minProfitPrice = entryPrice * (1 + feeRatio + feeRatio * (strengthMultiplier - 1)) / (1 - fees.taker);

  const feeBreakdown = `${fees.name} fees: buy $${buyFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) + sell $${sellFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) = $${totalFees.toFixed(4)} total`;

  return { profitable, grossPnl, netPnl, fees: totalFees, feeBreakdown, minProfitPrice };
}

interface OpenPosition {
  entryPrice: number;
  quantity: number;
  entryTime: number;
  side: "long" | "short";
  investment: number;
  leverage?: number;
  marginMode?: "cross" | "isolated";
  futuresMode?: boolean;
  highWaterMark?: number;
  trailingActivated?: boolean;
  atrStopLossPct?: number;
  atrTakeProfitPct?: number;
}

function isFuturesCapable(exchange: string): boolean {
  return FUTURES_SUPPORTED_EXCHANGES.includes(exchange.toLowerCase());
}

function calcPositionPnl(position: OpenPosition, currentPrice: number): { grossPnl: number; pnlPercent: number } {
  if (position.side === "short") {
    const grossPnl = (position.entryPrice - currentPrice) * position.quantity;
    const pnlPercent = ((position.entryPrice - currentPrice) / position.entryPrice) * 100;
    return { grossPnl, pnlPercent };
  }
  const grossPnl = (currentPrice - position.entryPrice) * position.quantity;
  const pnlPercent = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;
  return { grossPnl, pnlPercent };
}

function isCloseProfitableAfterFees(
  position: OpenPosition,
  currentPrice: number,
  exchange: string,
  signalStrength: number
): { profitable: boolean; grossPnl: number; netPnl: number; fees: number; feeBreakdown: string; minProfitPrice: number } {
  if (position.side === "short") {
    const fees = getExchangeFees(exchange);
    const entryValue = position.entryPrice * position.quantity;
    const closeValue = currentPrice * position.quantity;
    const entryFee = entryValue * fees.taker;
    const closeFee = closeValue * fees.taker;
    const totalFees = entryFee + closeFee;
    const { grossPnl } = calcPositionPnl(position, currentPrice);
    const netPnl = grossPnl - totalFees;

    const strengthMultiplier = signalStrength >= 80 ? 1.0 : signalStrength >= 65 ? 1.5 : 2.0;
    const minNetProfit = totalFees * (strengthMultiplier - 1);
    const profitable = netPnl > minNetProfit;

    const feeRatio = fees.taker * 2;
    const minProfitPrice = position.entryPrice * (1 - feeRatio - feeRatio * (strengthMultiplier - 1)) / (1 + fees.taker);

    const feeBreakdown = `${fees.name} fees: open $${entryFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) + close $${closeFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) = $${totalFees.toFixed(4)} total`;
    return { profitable, grossPnl, netPnl, fees: totalFees, feeBreakdown, minProfitPrice };
  }
  return isSellProfitableAfterFees(position.entryPrice, currentPrice, position.quantity, exchange, signalStrength);
}

const botPositions: Map<number, OpenPosition> = new Map();

const botConsecutiveLosses: Map<number, number> = new Map();
const botLossCooldownUntil: Map<number, number> = new Map();
const botLastLossTime: Map<number, number> = new Map();

function recordBotTradeOutcome(botId: number, netPnl: number): void {
  if (netPnl < 0) {
    const current = botConsecutiveLosses.get(botId) || 0;
    const newCount = current + 1;
    botConsecutiveLosses.set(botId, newCount);
    botLastLossTime.set(botId, Date.now());
    const baseCooldownMs = 5 * 60 * 1000;
    let cooldownMs: number;
    if (newCount >= 4) {
      cooldownMs = 60 * 60 * 1000;
    } else if (newCount >= 3) {
      cooldownMs = 30 * 60 * 1000;
    } else if (newCount >= 2) {
      cooldownMs = 15 * 60 * 1000;
    } else {
      cooldownMs = baseCooldownMs;
    }
    botLossCooldownUntil.set(botId, Date.now() + cooldownMs);
    console.log(`[BotEngine] Bot #${botId} consecutive losses: ${newCount} — cooldown ${cooldownMs / 60000}min`);
  } else {
    botConsecutiveLosses.set(botId, 0);
    botLossCooldownUntil.delete(botId);
    botLastLossTime.delete(botId);
  }
}

function isBotOnLossCooldown(botId: number): { blocked: boolean; reason: string } {
  const cooldownUntil = botLossCooldownUntil.get(botId);
  if (!cooldownUntil || Date.now() >= cooldownUntil) return { blocked: false, reason: '' };
  const losses = botConsecutiveLosses.get(botId) || 0;
  const remainMs = cooldownUntil - Date.now();
  return { blocked: true, reason: `${losses} consecutive losses — cooling down ${(remainMs / 60000).toFixed(1)}min remaining` };
}

function calcATR(symbol: string, period: number = 14): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < period + 1) return 0;
  const prices = history.prices;
  let atrSum = 0;
  for (let i = prices.length - period; i < prices.length; i++) {
    const tr = Math.abs(prices[i] - prices[i - 1]);
    atrSum += tr;
  }
  return atrSum / period;
}

function calcATRPercent(symbol: string, period: number = 14): number {
  const atr = calcATR(symbol, period);
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length === 0 || atr === 0) return 0;
  const currentPrice = history.prices[history.prices.length - 1];
  return (atr / currentPrice) * 100;
}

function isRSITurningUp(symbol: string): boolean {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 20) return false;
  const prices3ago = history.prices.slice(0, -2);
  const prices2ago = history.prices.slice(0, -1);
  const pricesNow = history.prices;
  const calcRSIFromPrices = (p: number[]) => {
    if (p.length < 15) return 50;
    const changes = [];
    for (let i = p.length - 14; i < p.length; i++) {
      changes.push(p[i] - p[i - 1]);
    }
    const gains = changes.filter(c => c > 0);
    const losses = changes.filter(c => c < 0).map(c => Math.abs(c));
    const avgGain = gains.length > 0 ? gains.reduce((a, b) => a + b, 0) / 14 : 0;
    const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / 14 : 0;
    if (avgLoss === 0) return 100;
    return 100 - (100 / (1 + avgGain / avgLoss));
  };
  const rsiPrev2 = calcRSIFromPrices(prices3ago);
  const rsiPrev1 = calcRSIFromPrices(prices2ago);
  const rsiNow = calcRSIFromPrices(pricesNow);
  return rsiNow > rsiPrev1 && (rsiNow > rsiPrev2 || rsiPrev1 > rsiPrev2);
}

async function loadBotPositions(): Promise<void> {
  try {
    const bots = await storage.getActiveServerBots();
    for (const bot of bots) {
      const settings = bot.settings as Record<string, any>;
      if (settings._openPosition) {
        botPositions.set(bot.id, settings._openPosition as OpenPosition);
      }
    }
    console.log(`[BotEngine] Loaded ${botPositions.size} open positions from DB`);
  } catch (err: any) {
    console.error("[BotEngine] Failed to load positions:", err.message);
  }
}

export async function savePosition(botId: number, position: OpenPosition | null): Promise<void> {
  if (position) {
    botPositions.set(botId, position);
  } else {
    botPositions.delete(botId);
  }
  const bot = await storage.getServerBot(botId);
  if (bot) {
    const settings = { ...(bot.settings as Record<string, any>) };
    if (position) {
      settings._openPosition = position;
    } else {
      delete settings._openPosition;
    }
    await storage.updateServerBot(botId, { settings });
  }
}

const livePrices: Map<string, PriceData> = new Map();
const trendCache: Map<string, { result: { confirmed: boolean; reason: string }; ts: number }> = new Map();
const TREND_CACHE_TTL = 3 * 60 * 1000;

async function verifyUptrendBeforeBuy(symbol: string, currentPrice: number): Promise<{ confirmed: boolean; reason: string }> {
  const cacheKey = symbol.toUpperCase();
  const cached = trendCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < TREND_CACHE_TTL) return cached.result;

  try {
    let binanceSymbol = cacheKey.replace('/', '');
    if (binanceSymbol.endsWith('USD') && !binanceSymbol.endsWith('USDT') && !binanceSymbol.endsWith('BUSD')) {
      binanceSymbol = binanceSymbol + 'T';
    }
    const [candles1h, candles4h] = await Promise.all([
      fetchTrendCandles(binanceSymbol, '1h', 50),
      fetchTrendCandles(binanceSymbol, '4h', 30),
    ]);

    if (candles1h.length < 10 && candles4h.length < 5) {
      const result = { confirmed: false, reason: `Insufficient candle data for ${binanceSymbol} (1h: ${candles1h.length}, 4h: ${candles4h.length}) — cannot confirm uptrend, blocking` };
      trendCache.set(cacheKey, { result, ts: Date.now() });
      return result;
    }

    let downtrendSignals = 0;
    let uptrendSignals = 0;
    const details: string[] = [];

    if (candles1h.length >= 20) {
      const closes1h = candles1h.map(c => c.close);
      const ema20_1h = simpleEMA(closes1h, 20);
      const ema50_1h = closes1h.length >= 50 ? simpleEMA(closes1h, 50) : null;
      const sma20_1h = closes1h.slice(-20).reduce((a, b) => a + b, 0) / 20;

      if (currentPrice < ema20_1h) { downtrendSignals += 2; details.push(`price < EMA20(1h) $${ema20_1h.toFixed(6)}`); }
      else { uptrendSignals += 2; details.push(`price > EMA20(1h)`); }

      if (ema50_1h !== null) {
        if (currentPrice < ema50_1h) { downtrendSignals += 2; details.push(`price < EMA50(1h)`); }
        else { uptrendSignals += 1; }
        if (ema20_1h < ema50_1h) { downtrendSignals += 2; details.push(`EMA20 < EMA50(1h) death cross`); }
        else { uptrendSignals += 2; details.push(`EMA20 > EMA50(1h) golden cross`); }
      }

      if (currentPrice < sma20_1h) { downtrendSignals += 1; details.push(`price < SMA20(1h)`); }
      else { uptrendSignals += 1; }

      const recent5 = closes1h.slice(-5);
      const lowerHighs = recent5.length >= 3 && recent5[recent5.length - 1] < recent5[recent5.length - 3] && recent5[recent5.length - 2] < recent5[recent5.length - 3];
      if (lowerHighs) { downtrendSignals += 1; details.push('lower highs(1h)'); }
    }

    if (candles4h.length >= 10) {
      const closes4h = candles4h.map(c => c.close);
      const ema20_4h = simpleEMA(closes4h, 20);

      if (currentPrice < ema20_4h) { downtrendSignals += 3; details.push(`price < EMA20(4h) $${ema20_4h.toFixed(6)}`); }
      else { uptrendSignals += 3; details.push(`price > EMA20(4h)`); }

      const change4h = closes4h.length >= 6 ? ((closes4h[closes4h.length - 1] - closes4h[closes4h.length - 6]) / closes4h[closes4h.length - 6]) * 100 : 0;
      if (change4h < -3) { downtrendSignals += 2; details.push(`4h trend ${change4h.toFixed(1)}%`); }
      else if (change4h > 1) { uptrendSignals += 2; details.push(`4h trend +${change4h.toFixed(1)}%`); }
    }

    const confirmed = uptrendSignals > downtrendSignals && downtrendSignals < 5;
    const reason = confirmed
      ? `Uptrend confirmed (up:${uptrendSignals} vs down:${downtrendSignals}) | ${details.slice(0, 4).join(', ')}`
      : `DOWNTREND detected (up:${uptrendSignals} vs down:${downtrendSignals}) | ${details.slice(0, 4).join(', ')}`;

    const result = { confirmed, reason };
    trendCache.set(cacheKey, { result, ts: Date.now() });
    return result;
  } catch (err: any) {
    return { confirmed: true, reason: `Trend check failed (${err.message}), allowing trade` };
  }
}

function simpleEMA(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;
  const k = 2 / (period + 1);
  let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < data.length; i++) {
    ema = data[i] * k + ema * (1 - k);
  }
  return ema;
}

async function fetchTrendCandles(symbol: string, interval: string, limit: number): Promise<{ close: number; high: number; low: number }[]> {
  try {
    const url = `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
    const res = await globalThis.fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return [];
    const data = await res.json();
    return data.map((k: any[]) => ({ close: parseFloat(k[4]), high: parseFloat(k[2]), low: parseFloat(k[3]) }));
  } catch { return []; }
}

const priceHistory: Map<string, { prices: number[]; timestamps: number[]; volumes: number[] }> = new Map();
const lastCumulativeVolume: Map<string, number> = new Map();
const botFailCounts: Map<string, number> = new Map();
let _onBotPairFailed: ((pair: string, error?: string) => void) | null = null;

export function setOnBotPairFailed(callback: (pair: string, error?: string) => void) {
  _onBotPairFailed = callback;
}
const MAX_HISTORY = 200;

function updatePriceHistory(symbol: string, price: number, volume?: number) {
  let history = priceHistory.get(symbol);
  if (!history) {
    history = { prices: [], timestamps: [], volumes: [] };
    priceHistory.set(symbol, history);
  }
  history.prices.push(price);
  history.timestamps.push(Date.now());
  if (!history.volumes) history.volumes = [];
  let deltaVol = 0;
  if (volume && volume > 0) {
    const prevCumVol = lastCumulativeVolume.get(symbol) || 0;
    deltaVol = volume > prevCumVol ? volume - prevCumVol : volume * 0.01;
    lastCumulativeVolume.set(symbol, volume);
  }
  history.volumes.push(deltaVol);
  if (history.prices.length > MAX_HISTORY) {
    history.prices.shift();
    history.timestamps.shift();
    history.volumes.shift();
  }
}

function calcMomentum(symbol: string, lookback: number = 10): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < lookback + 1) return 0;
  const current = history.prices[history.prices.length - 1];
  const past = history.prices[history.prices.length - 1 - lookback];
  return ((current - past) / past) * 100;
}

function calcVolatility(symbol: string, lookback: number = 20): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < lookback) return 0;
  const recent = history.prices.slice(-lookback);
  const mean = recent.reduce((a, b) => a + b, 0) / recent.length;
  const variance = recent.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / recent.length;
  return Math.sqrt(variance) / mean * 100;
}

function calcRSI(symbol: string, period: number = 14): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < period + 1) return 50;
  const changes = [];
  for (let i = history.prices.length - period; i < history.prices.length; i++) {
    changes.push(history.prices[i] - history.prices[i - 1]);
  }
  const gains = changes.filter(c => c > 0);
  const losses = changes.filter(c => c < 0).map(c => Math.abs(c));
  const avgGain = gains.length > 0 ? gains.reduce((a, b) => a + b, 0) / period : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / period : 0;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calcEMA(prices: number[], period: number): number[] {
  if (prices.length < period) return [];
  const k = 2 / (period + 1);
  const ema: number[] = [];
  let sum = 0;
  for (let i = 0; i < period; i++) sum += prices[i];
  ema.push(sum / period);
  for (let i = period; i < prices.length; i++) {
    ema.push(prices[i] * k + ema[ema.length - 1] * (1 - k));
  }
  return ema;
}

function calcEMACrossover(symbol: string): { signal: 'golden_cross' | 'death_cross' | 'none'; emaFast: number; emaSlow: number } {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 26) return { signal: 'none', emaFast: 0, emaSlow: 0 };
  const ema9 = calcEMA(history.prices, 9);
  const ema21 = calcEMA(history.prices, 21);
  if (ema9.length < 2 || ema21.length < 2) return { signal: 'none', emaFast: 0, emaSlow: 0 };
  const offset = ema9.length - ema21.length;
  const fast = ema9[ema9.length - 1];
  const fastPrev = ema9[ema9.length - 2];
  const slow = ema21[ema21.length - 1];
  const slowPrev = ema21[ema21.length - 2];
  if (fastPrev <= slowPrev && fast > slow) return { signal: 'golden_cross', emaFast: fast, emaSlow: slow };
  if (fastPrev >= slowPrev && fast < slow) return { signal: 'death_cross', emaFast: fast, emaSlow: slow };
  return { signal: 'none', emaFast: fast, emaSlow: slow };
}

function calcMACD(symbol: string): { macd: number; signal: number; histogram: number; crossover: 'bullish' | 'bearish' | 'none' } {
  const history = priceHistory.get(symbol);
  const nil = { macd: 0, signal: 0, histogram: 0, crossover: 'none' as const };
  if (!history || history.prices.length < 30) return nil;
  const ema12 = calcEMA(history.prices, 12);
  const ema26 = calcEMA(history.prices, 26);
  if (ema12.length === 0 || ema26.length === 0) return nil;
  const offset = ema12.length - ema26.length;
  const macdLine: number[] = [];
  for (let i = 0; i < ema26.length; i++) {
    macdLine.push(ema12[i + offset] - ema26[i]);
  }
  if (macdLine.length < 9) return nil;
  const signalLine = calcEMA(macdLine, 9);
  if (signalLine.length < 2) return nil;
  const sOffset = macdLine.length - signalLine.length;
  const macdVal = macdLine[macdLine.length - 1];
  const macdPrev = macdLine[macdLine.length - 2];
  const sigVal = signalLine[signalLine.length - 1];
  const sigPrev = signalLine[signalLine.length - 2];
  const histogram = macdVal - sigVal;
  let crossover: 'bullish' | 'bearish' | 'none' = 'none';
  if (macdPrev <= sigPrev && macdVal > sigVal) crossover = 'bullish';
  if (macdPrev >= sigPrev && macdVal < sigVal) crossover = 'bearish';
  return { macd: macdVal, signal: sigVal, histogram, crossover };
}

function calcBollingerBands(symbol: string, period: number = 20, stdMult: number = 2): { upper: number; middle: number; lower: number; percentB: number; squeeze: boolean } {
  const history = priceHistory.get(symbol);
  const nil = { upper: 0, middle: 0, lower: 0, percentB: 0.5, squeeze: false };
  if (!history || history.prices.length < period) return nil;
  const recent = history.prices.slice(-period);
  const mean = recent.reduce((a, b) => a + b, 0) / period;
  const variance = recent.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / period;
  const std = Math.sqrt(variance);
  const upper = mean + stdMult * std;
  const lower = mean - stdMult * std;
  const currentPrice = history.prices[history.prices.length - 1];
  const percentB = upper !== lower ? (currentPrice - lower) / (upper - lower) : 0.5;
  const bandwidth = mean > 0 ? (upper - lower) / mean * 100 : 0;
  const squeeze = bandwidth < 2;
  return { upper, middle: mean, lower, percentB, squeeze };
}

function calcVWAP(symbol: string, lookback: number = 30): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < lookback || !history.volumes) return 0;
  const prices = history.prices.slice(-lookback);
  const volumes = history.volumes.slice(-lookback);
  let totalPV = 0, totalV = 0;
  for (let i = 0; i < prices.length; i++) {
    const vol = volumes[i] || 1;
    totalPV += prices[i] * vol;
    totalV += vol;
  }
  return totalV > 0 ? totalPV / totalV : 0;
}

function calcVolumeSpike(symbol: string, lookback: number = 20, threshold: number = 3): { spike: boolean; ratio: number } {
  const history = priceHistory.get(symbol);
  if (!history || !history.volumes || history.volumes.length < lookback + 1) return { spike: false, ratio: 1 };
  const recentVols = history.volumes.slice(-(lookback + 1), -1);
  const avgVol = recentVols.reduce((a, b) => a + b, 0) / recentVols.length;
  const currentVol = history.volumes[history.volumes.length - 1];
  if (avgVol <= 0) return { spike: false, ratio: 1 };
  const ratio = currentVol / avgVol;
  return { spike: ratio >= threshold, ratio };
}

function calcZScore(symbol: string, lookback: number = 20): number {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < lookback) return 0;
  const recent = history.prices.slice(-lookback);
  const mean = recent.reduce((a, b) => a + b, 0) / lookback;
  const variance = recent.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / lookback;
  const std = Math.sqrt(variance);
  if (std === 0) return 0;
  const current = history.prices[history.prices.length - 1];
  return (current - mean) / std;
}

function calcADX(symbol: string, period: number = 14): { adx: number; plusDI: number; minusDI: number } {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < period * 2 + 1) return { adx: 25, plusDI: 0, minusDI: 0 };
  const prices = history.prices;
  const len = prices.length;
  let plusDMSum = 0, minusDMSum = 0, trSum = 0;
  for (let i = len - period * 2; i < len - period; i++) {
    const high = prices[i], prevHigh = prices[i - 1];
    const low = prices[i], prevLow = prices[i - 1];
    const upMove = high - prevHigh;
    const downMove = prevLow - low;
    plusDMSum += (upMove > downMove && upMove > 0) ? upMove : 0;
    minusDMSum += (downMove > upMove && downMove > 0) ? downMove : 0;
    const tr = Math.abs(high - low) || Math.abs(prices[i] - prices[i - 1]);
    trSum += tr > 0 ? tr : Math.abs(prices[i] - prices[i - 1]) * 0.01;
  }
  if (trSum === 0) trSum = 1;
  let smoothPlusDM = plusDMSum, smoothMinusDM = minusDMSum, smoothTR = trSum;
  const dxValues: number[] = [];
  for (let i = len - period; i < len; i++) {
    const upMove = prices[i] - prices[i - 1];
    const downMove = prices[i - 1] - prices[i];
    const plusDM = (upMove > downMove && upMove > 0) ? upMove : 0;
    const minusDM = (downMove > upMove && downMove > 0) ? downMove : 0;
    const tr = Math.abs(prices[i] - prices[i - 1]) || 0.0001;
    smoothPlusDM = smoothPlusDM - (smoothPlusDM / period) + plusDM;
    smoothMinusDM = smoothMinusDM - (smoothMinusDM / period) + minusDM;
    smoothTR = smoothTR - (smoothTR / period) + tr;
    const plusDI = smoothTR > 0 ? (smoothPlusDM / smoothTR) * 100 : 0;
    const minusDI = smoothTR > 0 ? (smoothMinusDM / smoothTR) * 100 : 0;
    const diSum = plusDI + minusDI;
    const dx = diSum > 0 ? (Math.abs(plusDI - minusDI) / diSum) * 100 : 0;
    dxValues.push(dx);
  }
  const adx = dxValues.length > 0 ? dxValues.reduce((a, b) => a + b, 0) / dxValues.length : 25;
  const lastPlusDI = smoothTR > 0 ? (smoothPlusDM / smoothTR) * 100 : 0;
  const lastMinusDI = smoothTR > 0 ? (smoothMinusDM / smoothTR) * 100 : 0;
  return { adx: Math.min(100, adx), plusDI: lastPlusDI, minusDI: lastMinusDI };
}

// ═══════════════════════════════════════════════════════════════════════════
// PROPRIETARY TECHNOLOGY ENGINES — Real analytical computations
// ═══════════════════════════════════════════════════════════════════════════

interface TechResult {
  signal: 'bullish' | 'bearish' | 'neutral';
  strength: number;  // 0-100
  detail: string;
}

interface FilterResult {
  allow: boolean;
  confidence: number;  // 0-100 how confident the filter is
  detail: string;
}

function techACM(symbol: string, price: PriceData): TechResult {
  const rsi = calcRSI(symbol, 14);
  const macd = calcMACD(symbol);
  const ema = calcEMACrossover(symbol);
  const bb = calcBollingerBands(symbol);
  const adx = calcADX(symbol);
  const zScore = calcZScore(symbol);

  let bullCount = 0, bearCount = 0;
  if (rsi < 40) bullCount++; if (rsi > 60) bearCount++;
  if (macd.histogram > 0) bullCount++; if (macd.histogram < 0) bearCount++;
  if (ema.emaFast > ema.emaSlow) bullCount++; if (ema.emaFast < ema.emaSlow) bearCount++;
  if (bb.percentB < 0.3) bullCount++; if (bb.percentB > 0.7) bearCount++;
  if (adx.plusDI > adx.minusDI) bullCount++; if (adx.plusDI < adx.minusDI) bearCount++;
  if (zScore < -1) bullCount++; if (zScore > 1) bearCount++;

  const total = 6;
  const maxAgree = Math.max(bullCount, bearCount);
  const convergenceScore = (maxAgree / total) * 100;

  if (maxAgree >= 5) {
    return { signal: bullCount > bearCount ? 'bullish' : 'bearish', strength: convergenceScore, detail: `ACM ${maxAgree}/${total} converge` };
  } else if (maxAgree >= 4) {
    return { signal: bullCount > bearCount ? 'bullish' : 'bearish', strength: convergenceScore * 0.7, detail: `ACM ${maxAgree}/${total} align` };
  }
  return { signal: 'neutral', strength: convergenceScore * 0.3, detail: `ACM ${maxAgree}/${total} mixed` };
}

function techQFRM(symbol: string): TechResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 20) return { signal: 'neutral', strength: 0, detail: 'QFRM insufficient data' };

  const prices = history.prices;
  const len = prices.length;
  const returns: number[] = [];
  for (let i = 1; i < len; i++) {
    returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
  }

  const accel: number[] = [];
  for (let i = 1; i < returns.length; i++) {
    accel.push(returns[i] - returns[i - 1]);
  }
  if (accel.length < 5) return { signal: 'neutral', strength: 0, detail: 'QFRM insufficient data' };

  const recentAccel = accel.slice(-5);
  const avgAccel = recentAccel.reduce((a, b) => a + b, 0) / recentAccel.length;
  const recentReturns = returns.slice(-5);
  const avgReturn = recentReturns.reduce((a, b) => a + b, 0) / recentReturns.length;

  const accelerating = avgAccel > 0 && avgReturn > 0;
  const decelerating = avgAccel < 0 && avgReturn < 0;
  const reversalUp = avgAccel > 0.001 && avgReturn < 0;
  const reversalDown = avgAccel < -0.001 && avgReturn > 0;

  if (accelerating) return { signal: 'bullish', strength: Math.min(85, Math.abs(avgAccel) * 50000), detail: `QFRM accel↑ ${(avgAccel*10000).toFixed(1)}bp/s` };
  if (decelerating) return { signal: 'bearish', strength: Math.min(85, Math.abs(avgAccel) * 50000), detail: `QFRM decel↓ ${(avgAccel*10000).toFixed(1)}bp/s` };
  if (reversalUp) return { signal: 'bullish', strength: Math.min(90, Math.abs(avgAccel) * 60000), detail: `QFRM reversal↑ detected` };
  if (reversalDown) return { signal: 'bearish', strength: Math.min(90, Math.abs(avgAccel) * 60000), detail: `QFRM reversal↓ detected` };

  return { signal: 'neutral', strength: 15, detail: 'QFRM stable flow' };
}

function techBIF(symbol: string): TechResult {
  const mom3 = calcMomentum(symbol, 3);
  const mom10 = calcMomentum(symbol, 10);
  const mom30 = calcMomentum(symbol, 30);

  const allBull = mom3 > 0 && mom10 > 0 && mom30 > 0;
  const allBear = mom3 < 0 && mom10 < 0 && mom30 < 0;
  const shortBullLongBear = mom3 > 0.05 && mom30 < -0.1;
  const shortBearLongBull = mom3 < -0.05 && mom30 > 0.1;

  if (allBull) {
    const alignment = Math.min(95, (Math.abs(mom3) + Math.abs(mom10) + Math.abs(mom30)) * 10);
    return { signal: 'bullish', strength: alignment, detail: `BIF all-timeframe bull (3m:${mom3.toFixed(2)}% 10m:${mom10.toFixed(2)}% 30m:${mom30.toFixed(2)}%)` };
  }
  if (allBear) {
    const alignment = Math.min(95, (Math.abs(mom3) + Math.abs(mom10) + Math.abs(mom30)) * 10);
    return { signal: 'bearish', strength: alignment, detail: `BIF all-timeframe bear` };
  }
  if (shortBullLongBear) {
    return { signal: 'bullish', strength: 65, detail: `BIF short-term reversal↑ (3m:+${mom3.toFixed(2)}% vs 30m:${mom30.toFixed(2)}%)` };
  }
  if (shortBearLongBull) {
    return { signal: 'bearish', strength: 60, detail: `BIF short-term reversal↓` };
  }
  return { signal: 'neutral', strength: 20, detail: 'BIF mixed timeframes' };
}

function techSBPE(symbol: string): TechResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 30) return { signal: 'neutral', strength: 0, detail: 'SBPE insufficient data' };

  const prices = history.prices;
  const len = prices.length;
  let ups = 0, downs = 0;
  for (let i = len - 20; i < len; i++) {
    if (prices[i] > prices[i - 1]) ups++;
    else downs++;
  }

  const recentReturn = (prices[len - 1] - prices[len - 6]) / prices[len - 6];
  const longerReturn = (prices[len - 1] - prices[len - 15]) / prices[len - 15];

  const upProb = ups / 20;
  const posterior = upProb * 0.6 + (recentReturn > 0 ? 0.3 : -0.1) + (longerReturn > 0 ? 0.1 : -0.05);

  if (posterior > 0.7) return { signal: 'bullish', strength: Math.min(90, posterior * 100), detail: `SBPE P(up)=${(posterior*100).toFixed(0)}%` };
  if (posterior < 0.3) return { signal: 'bearish', strength: Math.min(90, (1 - posterior) * 100), detail: `SBPE P(down)=${((1-posterior)*100).toFixed(0)}%` };
  return { signal: 'neutral', strength: 30, detail: `SBPE P(up)=${(posterior*100).toFixed(0)}% — inconclusive` };
}

const recentTradeResults: Map<string, { wins: number; losses: number; total: number }> = new Map();

export function recordTradeResult(symbol: string, won: boolean) {
  let rec = recentTradeResults.get(symbol);
  if (!rec) rec = { wins: 0, losses: 0, total: 0 };
  if (won) rec.wins++; else rec.losses++;
  rec.total++;
  if (rec.total > 50) { rec.wins = Math.round(rec.wins * 0.8); rec.losses = Math.round(rec.losses * 0.8); rec.total = rec.wins + rec.losses; }
  recentTradeResults.set(symbol, rec);
}

function techANCE(symbol: string, price: PriceData): TechResult {
  const rec = recentTradeResults.get(symbol) || { wins: 0, losses: 0, total: 0 };
  const winRate = rec.total > 3 ? rec.wins / rec.total : 0.5;
  const rsi = calcRSI(symbol, 14);
  const mom = calcMomentum(symbol, 5);

  let adaptiveThreshold = 60;
  if (winRate > 0.7) adaptiveThreshold = 50;
  else if (winRate < 0.4 && rec.total > 5) adaptiveThreshold = 75;

  const signalStrength = Math.abs(mom) * 30 + Math.abs(rsi - 50) * 0.5;
  if (signalStrength > adaptiveThreshold) {
    const dir = mom > 0 && rsi < 60 ? 'bullish' : mom < 0 && rsi > 40 ? 'bearish' : 'neutral';
    return { signal: dir, strength: Math.min(85, signalStrength), detail: `ANCE adaptive(WR:${(winRate*100).toFixed(0)}% thresh:${adaptiveThreshold})` };
  }
  return { signal: 'neutral', strength: 20, detail: `ANCE below adaptive threshold ${adaptiveThreshold}` };
}

function techANCE2(symbol: string, price: PriceData): TechResult {
  const base = techANCE(symbol, price);
  const volatility = calcVolatility(symbol, 20);
  const bb = calcBollingerBands(symbol);

  let regime: 'trending' | 'ranging' | 'volatile' = 'ranging';
  const adx = calcADX(symbol);
  if (adx.adx > 30) regime = 'trending';
  else if (volatility > 1.5 || bb.squeeze) regime = 'volatile';

  let adjustment = 0;
  if (regime === 'trending' && base.signal !== 'neutral') {
    adjustment = 15;
  } else if (regime === 'volatile') {
    adjustment = -10;
  } else if (regime === 'ranging' && bb.percentB < 0.1) {
    adjustment = 12;
    if (base.signal === 'neutral') return { signal: 'bullish', strength: 70, detail: `ANCE2 range-bottom bounce (BB:${(bb.percentB*100).toFixed(0)}%)` };
  } else if (regime === 'ranging' && bb.percentB > 0.9) {
    adjustment = 12;
    if (base.signal === 'neutral') return { signal: 'bearish', strength: 70, detail: `ANCE2 range-top fade (BB:${(bb.percentB*100).toFixed(0)}%)` };
  }

  return {
    signal: base.signal,
    strength: Math.min(95, base.strength + adjustment),
    detail: `ANCE2 ${regime} regime | ${base.detail}`,
  };
}

function runTech(techId: string, symbol: string, price: PriceData): TechResult {
  switch (techId) {
    case 'acm': return techACM(symbol, price);
    case 'qfrm': return techQFRM(symbol);
    case 'bif': return techBIF(symbol);
    case 'sbpe': return techSBPE(symbol);
    case 'ance': return techANCE(symbol, price);
    case 'ance2': return techANCE2(symbol, price);
    default: return { signal: 'neutral', strength: 0, detail: `Unknown tech: ${techId}` };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PROPRIETARY FILTER ENGINES — Gate/confirm trades with real analysis
// ═══════════════════════════════════════════════════════════════════════════

function filterOrderFlow(symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 10 || !history.volumes) return { allow: true, confidence: 30, detail: 'OFI: insufficient data' };

  const len = history.prices.length;
  let buyVol = 0, sellVol = 0;
  for (let i = len - 10; i < len; i++) {
    const vol = history.volumes[i] || 0;
    if (history.prices[i] > history.prices[i - 1]) buyVol += vol;
    else sellVol += vol;
  }
  const total = buyVol + sellVol;
  if (total === 0) return { allow: true, confidence: 30, detail: 'OFI: no volume data' };

  const buyRatio = buyVol / total;
  if (direction === 'BUY' && buyRatio > 0.55) return { allow: true, confidence: Math.min(90, buyRatio * 100), detail: `OFI buy pressure ${(buyRatio*100).toFixed(0)}%` };
  if (direction === 'SELL' && buyRatio < 0.45) return { allow: true, confidence: Math.min(90, (1 - buyRatio) * 100), detail: `OFI sell pressure ${((1-buyRatio)*100).toFixed(0)}%` };
  if (direction === 'BUY' && buyRatio < 0.35) return { allow: false, confidence: 75, detail: `OFI BLOCKED: selling dominates ${((1-buyRatio)*100).toFixed(0)}%` };
  if (direction === 'SELL' && buyRatio > 0.65) return { allow: false, confidence: 75, detail: `OFI BLOCKED: buying dominates ${(buyRatio*100).toFixed(0)}%` };
  return { allow: true, confidence: 50, detail: `OFI neutral ${(buyRatio*100).toFixed(0)}% buy` };
}

function filterFairValueGap(symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 10) return { allow: true, confidence: 30, detail: 'FVG: insufficient data' };

  const prices = history.prices;
  const len = prices.length;

  for (let i = len - 2; i >= Math.max(len - 8, 2); i--) {
    const candle1High = Math.max(prices[i - 1], prices[i - 2]);
    const candle3Low = Math.min(prices[i + 1] || prices[i], prices[i]);
    if (candle3Low > candle1High) {
      const gapSize = ((candle3Low - candle1High) / candle1High) * 100;
      if (gapSize > 0.15) {
        const currentPrice = prices[len - 1];
        const gapMidpoint = (candle1High + candle3Low) / 2;
        if (direction === 'BUY' && currentPrice <= gapMidpoint) {
          return { allow: true, confidence: 85, detail: `FVG bullish gap fill opportunity (${gapSize.toFixed(2)}% gap)` };
        }
        if (direction === 'SELL' && currentPrice >= gapMidpoint) {
          return { allow: true, confidence: 80, detail: `FVG bearish rejection at gap (${gapSize.toFixed(2)}% gap)` };
        }
      }
    }
    if (candle1High > candle3Low && prices[i] < prices[i - 1]) {
      const gapSize = ((candle1High - candle3Low) / candle3Low) * 100;
      if (gapSize > 0.15) {
        const currentPrice = prices[len - 1];
        const gapMidpoint = (candle1High + candle3Low) / 2;
        if (direction === 'SELL' && currentPrice >= gapMidpoint) {
          return { allow: true, confidence: 85, detail: `FVG bearish gap fill (${gapSize.toFixed(2)}% gap)` };
        }
      }
    }
  }
  return { allow: true, confidence: 40, detail: 'FVG: no actionable gaps' };
}

function filterAbsorption(symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 10 || !history.volumes) return { allow: true, confidence: 30, detail: 'ABS: insufficient data' };

  const prices = history.prices;
  const volumes = history.volumes;
  const len = prices.length;

  let wickAbsorption = 0;
  for (let i = Math.max(0, len - 5); i < len; i++) {
    const body = Math.abs(prices[i] - (prices[i - 1] || prices[i]));
    const range = Math.max(body, Math.abs(prices[i] - prices[Math.max(0, i - 1)])) * 2;
    if (range > 0) {
      const wickRatio = 1 - (body / range);
      if (wickRatio > 0.6 && (volumes[i] || 0) > (volumes[Math.max(0, i - 1)] || 1) * 1.5) {
        wickAbsorption++;
      }
    }
  }

  if (wickAbsorption >= 2) {
    const recentTrend = prices[len - 1] > prices[Math.max(0, len - 5)];
    if (direction === 'BUY' && !recentTrend) return { allow: true, confidence: 85, detail: `ABS: ${wickAbsorption} absorption candles — institutional buying detected` };
    if (direction === 'SELL' && recentTrend) return { allow: true, confidence: 85, detail: `ABS: ${wickAbsorption} absorption candles — institutional selling detected` };
    return { allow: false, confidence: 70, detail: `ABS: absorption against trade direction` };
  }
  return { allow: true, confidence: 50, detail: 'ABS: no significant absorption' };
}

function filterFractalEnergy(symbol: string): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 30) return { allow: true, confidence: 30, detail: 'FE: insufficient data' };

  const prices = history.prices.slice(-30);
  const returns = [];
  for (let i = 1; i < prices.length; i++) returns.push(Math.abs((prices[i] - prices[i - 1]) / prices[i - 1]));

  const totalRange = Math.abs(prices[prices.length - 1] - prices[0]);
  const pathLength = returns.reduce((sum, r) => sum + r, 0);
  const efficiency = pathLength > 0 ? (totalRange / prices[0]) / pathLength : 0;

  if (efficiency > 0.6) return { allow: true, confidence: 85, detail: `FE: high energy ${(efficiency*100).toFixed(0)}% — strong directional move` };
  if (efficiency < 0.15) return { allow: false, confidence: 70, detail: `FE: exhausted ${(efficiency*100).toFixed(0)}% — choppy, avoid trading` };
  return { allow: true, confidence: 55, detail: `FE: moderate energy ${(efficiency*100).toFixed(0)}%` };
}

function filterWyckoff(symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 30 || !history.volumes) return { allow: true, confidence: 30, detail: 'WY: insufficient data' };

  const prices = history.prices;
  const volumes = history.volumes;
  const len = prices.length;

  const priceRange = prices.slice(-20);
  const high = Math.max(...priceRange);
  const low = Math.min(...priceRange);
  const range = high - low;
  if (range === 0) return { allow: true, confidence: 30, detail: 'WY: flat market' };

  const currentPos = (prices[len - 1] - low) / range;
  const avgVolRecent = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const avgVolOlder = volumes.slice(-20, -10).reduce((a, b) => a + b, 0) / 10;
  const volExpanding = avgVolRecent > avgVolOlder * 1.3;
  const volContracting = avgVolRecent < avgVolOlder * 0.7;

  if (currentPos < 0.25 && volContracting) {
    if (direction === 'BUY') return { allow: true, confidence: 85, detail: 'WY: accumulation phase — buy zone' };
    return { allow: false, confidence: 70, detail: 'WY: accumulation phase — avoid selling' };
  }
  if (currentPos > 0.75 && volContracting) {
    if (direction === 'SELL') return { allow: true, confidence: 85, detail: 'WY: distribution phase — sell zone' };
    return { allow: false, confidence: 65, detail: 'WY: distribution phase — caution buying' };
  }
  if (currentPos < 0.25 && volExpanding) {
    return { allow: true, confidence: 80, detail: 'WY: spring — breakout potential' };
  }
  if (currentPos > 0.75 && volExpanding) {
    return { allow: true, confidence: 75, detail: 'WY: UTAD — potential breakdown' };
  }
  return { allow: true, confidence: 50, detail: `WY: mid-range (${(currentPos*100).toFixed(0)}%)` };
}

function filterEntropy(symbol: string): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 20) return { allow: true, confidence: 30, detail: 'ENT: insufficient data' };

  const prices = history.prices.slice(-20);
  const changes: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    const pctChange = ((prices[i] - prices[i - 1]) / prices[i - 1]) * 100;
    changes.push(pctChange);
  }

  const bins = [-Infinity, -0.5, -0.2, -0.05, 0.05, 0.2, 0.5, Infinity];
  const counts = new Array(bins.length - 1).fill(0);
  for (const c of changes) {
    for (let b = 0; b < bins.length - 1; b++) {
      if (c >= bins[b] && c < bins[b + 1]) { counts[b]++; break; }
    }
  }
  const total = changes.length;
  let entropy = 0;
  for (const count of counts) {
    if (count > 0) {
      const p = count / total;
      entropy -= p * Math.log2(p);
    }
  }
  const maxEntropy = Math.log2(bins.length - 1);
  const normalizedEntropy = entropy / maxEntropy;

  if (normalizedEntropy > 0.85) return { allow: false, confidence: 80, detail: `ENT: high randomness ${(normalizedEntropy*100).toFixed(0)}% — unpredictable, avoid` };
  if (normalizedEntropy < 0.4) return { allow: true, confidence: 85, detail: `ENT: low entropy ${(normalizedEntropy*100).toFixed(0)}% — predictable pattern` };
  return { allow: true, confidence: 55, detail: `ENT: moderate ${(normalizedEntropy*100).toFixed(0)}%` };
}

function filterHurst(symbol: string): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 30) return { allow: true, confidence: 30, detail: 'HUR: insufficient data' };

  const prices = history.prices.slice(-30);
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) returns.push(Math.log(prices[i] / prices[i - 1]));

  const n = returns.length;
  const mean = returns.reduce((a, b) => a + b, 0) / n;
  const deviations = returns.map(r => r - mean);
  const cumDev: number[] = [];
  let sum = 0;
  for (const d of deviations) { sum += d; cumDev.push(sum); }

  const R = Math.max(...cumDev) - Math.min(...cumDev);
  const S = Math.sqrt(deviations.reduce((s, d) => s + d * d, 0) / n);
  if (S === 0) return { allow: true, confidence: 30, detail: 'HUR: zero variance' };

  const RS = R / S;
  const H = Math.log(RS) / Math.log(n);
  const hurstExponent = Math.max(0, Math.min(1, H));

  if (hurstExponent > 0.6) return { allow: true, confidence: Math.min(90, hurstExponent * 100), detail: `HUR: trending H=${hurstExponent.toFixed(2)} — momentum trades favored` };
  if (hurstExponent < 0.4) return { allow: true, confidence: Math.min(85, (1 - hurstExponent) * 100), detail: `HUR: mean-reverting H=${hurstExponent.toFixed(2)} — reversion trades favored` };
  return { allow: true, confidence: 40, detail: `HUR: random walk H=${hurstExponent.toFixed(2)} — weak edge` };
}

function filterDeltaDivergence(symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  const history = priceHistory.get(symbol);
  if (!history || history.prices.length < 10 || !history.volumes) return { allow: true, confidence: 30, detail: 'DD: insufficient data' };

  const prices = history.prices;
  const volumes = history.volumes;
  const len = prices.length;

  const priceTrend = (prices[len - 1] - prices[Math.max(0, len - 8)]) / prices[Math.max(0, len - 8)];
  const recentVol = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const olderVol = volumes.slice(-10, -5).reduce((a, b) => a + b, 0) / 5;
  const volTrend = olderVol > 0 ? (recentVol - olderVol) / olderVol : 0;

  const priceUp = priceTrend > 0.002;
  const priceDown = priceTrend < -0.002;
  const volUp = volTrend > 0.15;
  const volDown = volTrend < -0.15;

  if (priceUp && volDown) {
    if (direction === 'SELL') return { allow: true, confidence: 80, detail: `DD: bearish divergence — price↑ volume↓` };
    return { allow: false, confidence: 75, detail: `DD: BLOCKED — bearish divergence (price↑ vol↓), risky to buy` };
  }
  if (priceDown && volDown) {
    if (direction === 'BUY') return { allow: true, confidence: 80, detail: `DD: bullish divergence — selling exhaustion` };
    return { allow: false, confidence: 70, detail: `DD: selling exhaustion — risky to sell more` };
  }
  if (priceUp && volUp) {
    if (direction === 'BUY') return { allow: true, confidence: 85, detail: `DD: healthy trend — price↑ volume↑ confirmed` };
  }
  if (priceDown && volUp) {
    if (direction === 'SELL') return { allow: true, confidence: 85, detail: `DD: confirmed breakdown — price↓ volume↑` };
  }
  return { allow: true, confidence: 50, detail: 'DD: no significant divergence' };
}

function runFilter(filterId: string, symbol: string, direction: 'BUY' | 'SELL'): FilterResult {
  switch (filterId) {
    case 'order_flow': return filterOrderFlow(symbol, direction);
    case 'fair_value_gap': return filterFairValueGap(symbol, direction);
    case 'absorption': return filterAbsorption(symbol, direction);
    case 'fractal_energy': return filterFractalEnergy(symbol);
    case 'wyckoff': return filterWyckoff(symbol, direction);
    case 'entropy': return filterEntropy(symbol);
    case 'hurst': return filterHurst(symbol);
    case 'delta_divergence': return filterDeltaDivergence(symbol, direction);
    default: return { allow: true, confidence: 50, detail: `Unknown filter: ${filterId}` };
  }
}

function calcPricePosition(priceData: PriceData): number {
  if (!priceData.high24h || !priceData.low24h || priceData.high24h === priceData.low24h) return 0.5;
  return (priceData.price - priceData.low24h) / (priceData.high24h - priceData.low24h);
}

function calcDailySwing(priceData: PriceData): number {
  if (!priceData.low24h || priceData.low24h <= 0) return 0;
  return ((priceData.high24h - priceData.low24h) / priceData.low24h) * 100;
}

function calcAutoCooldown(priceData: PriceData, baseCooldown: number): { cooldownMs: number; dailySwing: number; volatilityLevel: string } {
  const dailySwing = calcDailySwing(priceData);

  let multiplier = 1;
  let volatilityLevel = "normal";

  if (dailySwing >= 15) {
    multiplier = 0.25;
    volatilityLevel = "extreme";
  } else if (dailySwing >= 10) {
    multiplier = 0.4;
    volatilityLevel = "very_high";
  } else if (dailySwing >= 7) {
    multiplier = 0.5;
    volatilityLevel = "high";
  } else if (dailySwing >= 4) {
    multiplier = 0.75;
    volatilityLevel = "elevated";
  } else if (dailySwing >= 2) {
    multiplier = 1;
    volatilityLevel = "normal";
  } else {
    multiplier = 1.5;
    volatilityLevel = "low";
  }

  const adjusted = Math.max(5000, Math.min(300000, baseCooldown * 1000 * multiplier));
  return { cooldownMs: Math.round(adjusted), dailySwing, volatilityLevel };
}

interface AutoParams {
  cooldownMs: number;
  takeProfit: number;
  stopLoss: number;
  trailingPercent: number;
  signalThreshold: number;
  dailySwing: number;
  volatilityLevel: string;
  trendDirection: "bullish" | "bearish" | "neutral";
  trendStrength: number;
  rsi: number;
}

function calcAllAutoParams(
  priceData: PriceData,
  pairSymbol: string,
  base: { cooldownSeconds: number; takeProfit: number; stopLoss: number; trailingPercent: number; signalThreshold: number }
): AutoParams {
  const dailySwing = calcDailySwing(priceData);
  const { cooldownMs, volatilityLevel } = calcAutoCooldown(priceData, base.cooldownSeconds);

  const momentum = calcMomentum(pairSymbol, 10);
  const shortMom = calcMomentum(pairSymbol, 3);
  const rsi = calcRSI(pairSymbol, 14);
  const volatility = calcVolatility(pairSymbol, 20);

  let trendDirection: "bullish" | "bearish" | "neutral" = "neutral";
  let trendStrength = 0;
  if (momentum > 0.1 && priceData.priceChangePercent > 0.5) {
    trendDirection = "bullish";
    trendStrength = Math.min(100, Math.abs(momentum) * 20 + Math.abs(priceData.priceChangePercent) * 5);
  } else if (momentum < -0.1 && priceData.priceChangePercent < -0.5) {
    trendDirection = "bearish";
    trendStrength = Math.min(100, Math.abs(momentum) * 20 + Math.abs(priceData.priceChangePercent) * 5);
  } else {
    trendStrength = Math.min(40, Math.abs(momentum) * 10);
  }

  const roundTripFeePct = 0.6;
  const feeFloor = roundTripFeePct * 3;

  let tpMultiplier = 1;
  if (dailySwing >= 15) tpMultiplier = 2.0;
  else if (dailySwing >= 10) tpMultiplier = 1.6;
  else if (dailySwing >= 7) tpMultiplier = 1.4;
  else if (dailySwing >= 4) tpMultiplier = 1.2;
  else if (dailySwing < 2) tpMultiplier = 1.0;

  if (trendDirection !== "neutral" && trendStrength > 50) {
    tpMultiplier *= 1.2;
  }
  const rawTP = base.takeProfit * tpMultiplier;
  const autoTP = Math.max(feeFloor, Math.min(30, rawTP));

  let slMultiplier = 1;
  if (dailySwing >= 15) slMultiplier = 1.8;
  else if (dailySwing >= 10) slMultiplier = 1.5;
  else if (dailySwing >= 7) slMultiplier = 1.3;
  else if (dailySwing >= 4) slMultiplier = 1.1;
  else if (dailySwing < 2) slMultiplier = 1.0;

  if (volatility > 0.8) slMultiplier *= 1.15;
  const rawSL = base.stopLoss * slMultiplier;
  const autoSL = Math.max(feeFloor * 0.8, Math.min(20, rawSL));

  let trailMultiplier = 1;
  if (dailySwing >= 15) trailMultiplier = 0.7;
  else if (dailySwing >= 10) trailMultiplier = 0.8;
  else if (dailySwing >= 7) trailMultiplier = 0.85;
  else if (dailySwing >= 4) trailMultiplier = 0.9;
  else if (dailySwing < 2) trailMultiplier = 1.2;

  if (trendDirection !== "neutral" && trendStrength > 40) {
    trailMultiplier *= 1.1;
  }
  const autoTrailing = Math.max(1.0, Math.min(10, base.trailingPercent * trailMultiplier));

  let threshMultiplier = 1;
  if (trendDirection !== "neutral" && trendStrength > 50) {
    threshMultiplier = 0.85;
  } else if (trendDirection !== "neutral" && trendStrength > 30) {
    threshMultiplier = 0.92;
  }

  if (rsi < 25 || rsi > 75) {
    threshMultiplier *= 0.9;
  }

  if (volatility > 1.0) {
    threshMultiplier *= 1.1;
  } else if (volatility < 0.2 && dailySwing < 2) {
    threshMultiplier *= 1.15;
  }
  const autoThreshold = Math.max(30, Math.min(90, Math.round(base.signalThreshold * threshMultiplier)));

  return {
    cooldownMs,
    takeProfit: Math.round(autoTP * 10) / 10,
    stopLoss: Math.round(autoSL * 10) / 10,
    trailingPercent: Math.round(autoTrailing * 10) / 10,
    signalThreshold: autoThreshold,
    dailySwing,
    volatilityLevel,
    trendDirection,
    trendStrength: Math.round(trendStrength),
    rsi: Math.round(rsi * 10) / 10,
  };
}

export function getVolatilityInfo(pair: string, baseSettings: { cooldownSeconds?: number; takeProfit?: number; stopLoss?: number; trailingPercent?: number; signalThreshold?: number } = {}): {
  available: boolean;
  dailySwing: number;
  volatilityLevel: string;
  suggestedCooldown: number;
  currentPrice: number;
  high24h: number;
  low24h: number;
  autoParams: AutoParams;
} | null {
  const symbol = pair.replace("/", "").toUpperCase();
  const priceData = livePrices.get(symbol);
  if (!priceData) return null;

  const base = {
    cooldownSeconds: baseSettings.cooldownSeconds || 60,
    takeProfit: baseSettings.takeProfit || 10,
    stopLoss: baseSettings.stopLoss || 5,
    trailingPercent: baseSettings.trailingPercent || 3,
    signalThreshold: baseSettings.signalThreshold || 70,
  };

  const autoParams = calcAllAutoParams(priceData, symbol, base);
  return {
    available: true,
    dailySwing: autoParams.dailySwing,
    volatilityLevel: autoParams.volatilityLevel,
    suggestedCooldown: Math.round(autoParams.cooldownMs / 1000),
    currentPrice: priceData.price,
    high24h: priceData.high24h,
    low24h: priceData.low24h,
    autoParams,
  };
}

function generateSignal(price: PriceData, bot: ServerBot): Signal {
  let baseConfidence = 35;
  const activeTech = (bot.activeTech || []) as string[];
  const activeFilters = (bot.activeFilters || []) as string[];

  const changePercent = price.priceChangePercent;
  const pairSymbol = bot.pair.replace("/", "");
  const momentum = calcMomentum(pairSymbol, 10);
  const shortMomentum = calcMomentum(pairSymbol, 3);
  const longMomentum = calcMomentum(pairSymbol, 50);
  const volatility = calcVolatility(pairSymbol, 20);
  const rsi = calcRSI(pairSymbol, 14);

  const macd = calcMACD(pairSymbol);
  const emaCross = calcEMACrossover(pairSymbol);
  const bb = calcBollingerBands(pairSymbol);
  const vwap = calcVWAP(pairSymbol);
  const volSpike = calcVolumeSpike(pairSymbol, 20, 3);
  const zScore = calcZScore(pairSymbol);
  const adx = calcADX(pairSymbol);
  const pricePos = calcPricePosition(price);

  let direction: "BUY" | "SELL" | "HOLD" = "HOLD";
  let strength = 50;
  const reasons: string[] = [];

  let bullSignals = 0;
  let bearSignals = 0;

  if (changePercent > 0.3) { bullSignals++; reasons.push(`24h +${changePercent.toFixed(2)}%`); }
  if (changePercent < -0.3) { bearSignals++; reasons.push(`24h ${changePercent.toFixed(2)}%`); }

  if (momentum > 0.15) { bullSignals++; reasons.push(`mom +${momentum.toFixed(3)}%`); }
  if (momentum < -0.15) { bearSignals++; reasons.push(`mom ${momentum.toFixed(3)}%`); }

  if (shortMomentum > 0.05) { bullSignals++; reasons.push(`accel +${shortMomentum.toFixed(3)}%`); }
  if (shortMomentum < -0.05) { bearSignals++; reasons.push(`accel ${shortMomentum.toFixed(3)}%`); }

  const rsiTurningUp = isRSITurningUp(pairSymbol);
  if (rsi < 30 && rsiTurningUp) { bullSignals += 3; reasons.push(`RSI oversold+rising ${rsi.toFixed(1)}`); }
  else if (rsi < 30) { bullSignals += 1; reasons.push(`RSI oversold(falling) ${rsi.toFixed(1)}`); }
  else if (rsi < 35 && rsiTurningUp) { bullSignals += 2; reasons.push(`RSI low+rising ${rsi.toFixed(1)}`); }
  else if (rsi > 75) { bearSignals += 3; reasons.push(`RSI overbought ${rsi.toFixed(1)}`); }
  else if (rsi > 65) { bearSignals += 2; reasons.push(`RSI high ${rsi.toFixed(1)}`); }

  if (macd.crossover === 'bullish') { bullSignals += 2; reasons.push('MACD bullish cross'); }
  if (macd.crossover === 'bearish') { bearSignals += 2; reasons.push('MACD bearish cross'); }
  if (macd.histogram > 0 && macd.crossover === 'none') { bullSignals++; }
  if (macd.histogram < 0 && macd.crossover === 'none') { bearSignals++; }

  if (emaCross.signal === 'golden_cross') { bullSignals += 2; reasons.push('EMA golden cross'); }
  if (emaCross.signal === 'death_cross') { bearSignals += 2; reasons.push('EMA death cross'); }
  if (emaCross.emaFast > 0 && emaCross.emaSlow > 0) {
    if (emaCross.emaFast > emaCross.emaSlow) bullSignals++;
    else { bearSignals += 2; reasons.push('price below EMA trend'); }
  }

  if (bb.percentB < 0.05) { bullSignals += 2; reasons.push(`BB oversold ${(bb.percentB*100).toFixed(0)}%`); }
  else if (bb.percentB < 0.2) { bullSignals++; reasons.push(`BB low ${(bb.percentB*100).toFixed(0)}%`); }
  if (bb.percentB > 0.95) { bearSignals += 2; reasons.push(`BB overbought ${(bb.percentB*100).toFixed(0)}%`); }
  else if (bb.percentB > 0.8) { bearSignals++; reasons.push(`BB high ${(bb.percentB*100).toFixed(0)}%`); }
  if (bb.squeeze) { reasons.push('BB squeeze'); }

  if (vwap > 0) {
    const vwapDev = ((price.price - vwap) / vwap) * 100;
    if (vwapDev < -1.5) { bullSignals++; reasons.push(`below VWAP ${vwapDev.toFixed(1)}%`); }
    if (vwapDev > 1.5) { bearSignals++; reasons.push(`above VWAP +${vwapDev.toFixed(1)}%`); }
  }

  if (volSpike.spike) {
    if (changePercent > 0.5 || momentum > 0.1) { bullSignals += 2; reasons.push(`VOL SPIKE ${volSpike.ratio.toFixed(1)}x ↑`); }
    else if (changePercent < -0.5 || momentum < -0.1) { bearSignals += 2; reasons.push(`VOL SPIKE ${volSpike.ratio.toFixed(1)}x ↓`); }
    else { reasons.push(`VOL spike ${volSpike.ratio.toFixed(1)}x`); }
  }

  if (zScore <= -2) { bullSignals += 2; reasons.push(`Z-score ${zScore.toFixed(2)} (mean revert)`); }
  else if (zScore <= -1.5) { bullSignals++; reasons.push(`Z-score ${zScore.toFixed(2)}`); }
  if (zScore >= 2) { bearSignals += 2; reasons.push(`Z-score +${zScore.toFixed(2)} (mean revert)`); }
  else if (zScore >= 1.5) { bearSignals++; reasons.push(`Z-score +${zScore.toFixed(2)}`); }

  const isTrending = adx.adx > 20;
  const isStrongTrend = adx.adx > 30;
  if (isTrending) {
    if (adx.plusDI > adx.minusDI) {
      bullSignals += isStrongTrend ? 2 : 1;
      reasons.push(`ADX ${adx.adx.toFixed(0)} trend↑ (+DI:${adx.plusDI.toFixed(0)} > -DI:${adx.minusDI.toFixed(0)})`);
    } else {
      bearSignals += isStrongTrend ? 3 : 2;
      reasons.push(`ADX ${adx.adx.toFixed(0)} trend↓ (-DI:${adx.minusDI.toFixed(0)} > +DI:${adx.plusDI.toFixed(0)})`);
    }
  } else {
    bearSignals += 1;
    reasons.push(`ADX ${adx.adx.toFixed(0)} CHOPPY — no clear trend`);
  }

  if (pricePos < 0.15 && rsi < 45) { bullSignals++; reasons.push('near 24h low'); }
  if (pricePos > 0.85 && rsi > 55) { bearSignals++; reasons.push('near 24h high'); }

  if (longMomentum < -1.0) { bearSignals += 3; reasons.push(`long-term downtrend ${longMomentum.toFixed(2)}%`); }
  else if (longMomentum < -0.3) { bearSignals += 2; reasons.push(`medium-term decline ${longMomentum.toFixed(2)}%`); }
  else if (longMomentum > 1.0) { bullSignals += 2; reasons.push(`long-term uptrend +${longMomentum.toFixed(2)}%`); }
  else if (longMomentum > 0.3) { bullSignals += 1; reasons.push(`medium-term rise +${longMomentum.toFixed(2)}%`); }

  // ═══ PROPRIETARY TECHNOLOGY ENGINE INTEGRATION ═══
  // Tech votes participate in signal formation BEFORE direction is determined
  let techStrengthSum = 0, techVoteCount = 0;
  const techDetails: string[] = [];
  for (const t of activeTech) {
    const result = runTech(t, pairSymbol, price);
    if (result.signal === 'bullish') {
      bullSignals += (result.strength > 70 ? 2 : 1);
      techStrengthSum += result.strength;
      techVoteCount++;
    } else if (result.signal === 'bearish') {
      bearSignals += (result.strength > 70 ? 2 : 1);
      techStrengthSum += result.strength;
      techVoteCount++;
    }
    techDetails.push(result.detail);
  }
  if (techVoteCount > 0) {
    baseConfidence += Math.min(25, techVoteCount * 4 + (techStrengthSum / techVoteCount) * 0.15);
  }

  // ═══ DIRECTION DETERMINATION (with tech votes included) ═══
  const confluence = Math.max(bullSignals, bearSignals);
  const requiredConfluence = 4;
  const signalMargin = bullSignals - bearSignals;

  if (signalMargin >= 2 && bullSignals >= requiredConfluence) {
    direction = "BUY";
    strength = Math.min(95, 40 + confluence * 4 + Math.abs(changePercent) * 2 + Math.abs(momentum) * 3 + signalMargin * 3);
    if (volSpike.spike && changePercent > 0) strength = Math.min(95, strength + 10);
    if (macd.crossover === 'bullish') strength = Math.min(95, strength + 5);
    if (bb.squeeze && changePercent > 0.3) strength = Math.min(95, strength + 7);
    if (rsiTurningUp && rsi < 35) strength = Math.min(95, strength + 5);
    if (!isTrending) strength = Math.max(30, strength - 15);
    if (techVoteCount > 0) strength = Math.min(95, strength + (techStrengthSum / techVoteCount) * 0.15);
  } else if (signalMargin <= -2 && bearSignals >= requiredConfluence) {
    direction = "SELL";
    strength = Math.min(95, 40 + confluence * 4 + Math.abs(changePercent) * 2 + Math.abs(momentum) * 3 + Math.abs(signalMargin) * 3);
    if (volSpike.spike && changePercent < 0) strength = Math.min(95, strength + 10);
    if (macd.crossover === 'bearish') strength = Math.min(95, strength + 5);
    if (techVoteCount > 0) strength = Math.min(95, strength + (techStrengthSum / techVoteCount) * 0.15);
  } else {
    direction = "HOLD";
    strength = 20 + Math.abs(signalMargin) * 3;
  }

  if (volatility > 0.5) { reasons.push(`vol ${volatility.toFixed(2)}%`); }

  // ═══ PROPRIETARY FILTER ENGINE INTEGRATION ═══
  // Filters act as gates — can block bad trades or boost confidence on confirmed ones
  let filterBlocked = false;
  let filterConfidenceBoost = 0;
  const filterDetails: string[] = [];
  if (direction !== 'HOLD' && activeFilters.length > 0) {
    let blockedCount = 0;
    let totalFilterConf = 0;
    for (const f of activeFilters) {
      const result = runFilter(f, pairSymbol, direction as 'BUY' | 'SELL');
      if (!result.allow && result.confidence >= 65) {
        blockedCount++;
        filterDetails.push(result.detail);
      } else if (result.allow && result.confidence > 60) {
        filterConfidenceBoost += (result.confidence - 50) * 0.3;
        filterDetails.push(result.detail);
      }
      totalFilterConf += result.confidence;
    }

    if (blockedCount >= 2) {
      filterBlocked = true;
      direction = 'HOLD';
      reasons.push(`FILTERED: ${blockedCount} filters blocked trade`);
    } else if (blockedCount === 1 && totalFilterConf / activeFilters.length < 55) {
      filterBlocked = true;
      direction = 'HOLD';
      reasons.push(`FILTERED: marginal signal + filter block`);
    }

    if (!filterBlocked) {
      strength = Math.min(95, strength + filterConfidenceBoost);
      baseConfidence = Math.min(95, baseConfidence + filterConfidenceBoost * 0.5);
    }
  }

  const confidence = Math.min(95, baseConfidence + (confluence >= 4 ? 10 : confluence >= 3 ? 5 : 0));
  const indicatorSummary = `bull:${bullSignals} bear:${bearSignals} conf:${confluence}`;
  const allDetails = [...reasons];
  if (techDetails.length > 0) allDetails.push(`Tech: ${techDetails.join('; ')}`);
  if (filterDetails.length > 0) allDetails.push(`Filters: ${filterDetails.join('; ')}`);
  const reason = `${direction}: ${indicatorSummary} | ${allDetails.join(" | ")}`;

  return { direction, strength, confidence, reason };
}

export async function executeKrakenOrder(
  apiKey: string,
  apiSecret: string,
  pair: string,
  side: string,
  quantity: number
): Promise<{ success: boolean; orderId?: string; error?: string }> {
  const krakenAssetMap: Record<string, string> = { BTC: "XBT", DOGE: "XDG" };
  const [base, quote] = pair.split("/");
  const krakenBase = krakenAssetMap[base] || base;
  const krakenQuote = quote === "USDT" ? "USDT" : quote === "USD" ? "USD" : quote;
  let krakenPair = `${krakenBase}${krakenQuote}`;

  try {
    const validateRes = await fetch(`https://api.kraken.com/0/public/AssetPairs?pair=${krakenPair}`, { signal: AbortSignal.timeout(8000) });
    const validateData = (await validateRes.json()) as any;
    if (validateData.error?.length > 0 || !validateData.result || Object.keys(validateData.result).length === 0) {
      const altQuote = quote === "USDT" ? "USD" : "USDT";
      const altPair = `${krakenBase}${altQuote}`;
      const altRes = await fetch(`https://api.kraken.com/0/public/AssetPairs?pair=${altPair}`, { signal: AbortSignal.timeout(8000) });
      const altData = (await altRes.json()) as any;
      if (!altData.error?.length && altData.result && Object.keys(altData.result).length > 0) {
        krakenPair = altPair;
      } else {
        return { success: false, error: `Pair ${pair} (${krakenPair}) not available on Kraken` };
      }
    }
  } catch {}


  const nonce = (Date.now() * 1000).toString();
  const orderSide = side.toLowerCase();
  const postData = `nonce=${nonce}&ordertype=market&type=${orderSide}&volume=${quantity}&pair=${krakenPair}`;
  const apiPath = "/0/private/AddOrder";

  const sha256Hash = crypto.createHash("sha256").update(nonce + postData).digest();
  const hmacKey = Buffer.from(apiSecret, "base64");
  const hmac = crypto.createHmac("sha512", hmacKey);
  hmac.update(Buffer.concat([Buffer.from(apiPath), sha256Hash]));
  const signature = hmac.digest("base64");

  try {
    const res = await fetch(`https://api.kraken.com${apiPath}`, {
      method: "POST",
      headers: {
        "API-Key": apiKey,
        "API-Sign": signature,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: postData,
      signal: AbortSignal.timeout(15000),
    });

    const data = (await res.json()) as any;

    if (data.error && data.error.length > 0) {
      return { success: false, error: data.error.join(", ") };
    }

    return {
      success: true,
      orderId: data.result?.txid?.[0] || "unknown",
    };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

const COOLDOWN_MS = 60000;

async function processBot(bot: ServerBot, priceData: PriceData): Promise<void> {
  const settings = bot.settings as Record<string, any>;

  try {
    const signal = generateSignal(priceData, bot);
    const position = botPositions.get(bot.id);
    const exchangeFees = getExchangeFees(bot.exchange);

    const positionPnl = position ? calcPositionPnl(position, priceData.price) : null;
    const positionInfo = position
      ? ` | Position: ${position.side.toUpperCase()} ${position.quantity.toFixed(6)} @ $${position.entryPrice.toFixed(2)} (${positionPnl!.pnlPercent.toFixed(2)}%)${position.futuresMode ? ` [Futures ${position.leverage || 1}x]` : ''}`
      : " | No position";

    await storage.updateServerBot(bot.id, {
      lastSignalData: {
        direction: signal.direction,
        strength: signal.strength,
        confidence: signal.confidence,
        reason: signal.reason,
        price: priceData.price,
        timestamp: Date.now(),
        hasPosition: !!position,
        positionEntry: position?.entryPrice,
        positionQty: position?.quantity,
        exchangeFees: { maker: exchangeFees.maker * 100, taker: exchangeFees.taker * 100, name: exchangeFees.name },
      },
    });

    let effectiveThreshold = (settings.signalThreshold as number) || 55;
    let effectiveCooldownMs = (settings.cooldownSeconds ? (settings.cooldownSeconds as number) : COOLDOWN_MS / 1000) * 1000;
    let effectiveTP = settings.takeProfit as number | undefined;
    let effectiveSL = settings.stopLoss as number | undefined;
    let autoInfo = "";

    const pairSymbol = bot.pair.replace("/", "");
    const isAutoMode = settings.autoCooldown || settings.autoTakeProfit || settings.autoStopLoss || settings.autoThreshold || settings.autoTrailing;

    if (isAutoMode) {
      const autoParams = calcAllAutoParams(priceData, pairSymbol, {
        cooldownSeconds: (settings.cooldownSeconds as number) || 60,
        takeProfit: (settings.takeProfit as number) || 10,
        stopLoss: (settings.stopLoss as number) || 5,
        trailingPercent: (settings.trailingPercent as number) || 3,
        signalThreshold: (settings.signalThreshold as number) || 70,
      });

      if (settings.autoCooldown) effectiveCooldownMs = autoParams.cooldownMs;
      if (settings.autoTakeProfit) effectiveTP = autoParams.takeProfit;
      if (settings.autoStopLoss) effectiveSL = autoParams.stopLoss;
      if (settings.autoThreshold) effectiveThreshold = autoParams.signalThreshold;

      const parts: string[] = [];
      if (settings.autoCooldown) parts.push(`CD:${(autoParams.cooldownMs / 1000).toFixed(0)}s`);
      if (settings.autoTakeProfit) parts.push(`TP:${autoParams.takeProfit}%`);
      if (settings.autoStopLoss) parts.push(`SL:${autoParams.stopLoss}%`);
      if (settings.autoThreshold) parts.push(`TH:${autoParams.signalThreshold}`);
      if (settings.autoTrailing) parts.push(`TR:${autoParams.trailingPercent}%`);
      autoInfo = ` | Auto[${parts.join(", ")}] ${autoParams.volatilityLevel} swing:${autoParams.dailySwing.toFixed(1)}% trend:${autoParams.trendDirection}(${autoParams.trendStrength}%)`;
    }

    if (position) {
      const { pnlPercent } = calcPositionPnl(position, priceData.price);

      // Locked-pair take-profit: sell at 2.87%+ BUT only on SELL signal (ride the wave up)
      const lockedTPMin = settings._takeProfitMin as number | undefined;
      const lockedTPMax = settings._takeProfitMax as number | undefined;
      if (lockedTPMin && lockedTPMax && pnlPercent >= lockedTPMin) {
        if (signal.direction === "SELL") {
          const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, 90);
          await storage.createServerBotLog({
            botId: bot.id, userId: bot.userId, logType: "signal",
            message: `LOCKED TP + SELL signal @ $${priceData.price.toFixed(6)} | +${pnlPercent.toFixed(2)}% profit (min: ${lockedTPMin}%) | Selling on reversal | Net P&L: $${profitCheck.netPnl.toFixed(4)} | ${profitCheck.feeBreakdown}${positionInfo}`,
            data: { price: priceData.price, pnlPercent, lockedTPMin, lockedTPMax, signalDirection: signal.direction, fees: profitCheck },
          });
          const updatedSettings = { ...settings, _lastSellPrice: priceData.price };
          await storage.updateServerBot(bot.id, { settings: updatedSettings });
          await executeCloseOrder(bot, priceData, position, signal, "TAKE_PROFIT", profitCheck, settings);
          return;
        }
      }

      const isLockedPair = !!(lockedTPMin && lockedTPMax);

      // Locked-pair bots: skip trailing stop, only use locked TP + hard stop loss
      if (!isLockedPair) {
        const trailingPct = isAutoMode
          ? (calcAllAutoParams(priceData, bot.pair.replace("/", ""), {
              cooldownSeconds: (settings.cooldownSeconds as number) || 60,
              takeProfit: (settings.takeProfit as number) || 10,
              stopLoss: (settings.stopLoss as number) || 5,
              trailingPercent: (settings.trailingPercent as number) || 3,
              signalThreshold: (settings.signalThreshold as number) || 70,
            }).trailingPercent)
          : ((settings.trailingPercent as number) || 3);
        const trailingActivationPct = Math.max(1.2, trailingPct * 0.5);

        if (position.side === "long") {
          if (!position.highWaterMark || priceData.price > position.highWaterMark) {
            position.highWaterMark = priceData.price;
          }
        } else {
          if (!position.highWaterMark || priceData.price < position.highWaterMark) {
            position.highWaterMark = priceData.price;
          }
        }

        if (pnlPercent >= trailingActivationPct && !position.trailingActivated) {
          position.trailingActivated = true;
          console.log(`[BotEngine] Trailing stop ACTIVATED for bot #${bot.id} (${bot.pair}) at +${pnlPercent.toFixed(2)}% profit | Trail: ${trailingPct}% from peak`);
        }

        if (position.trailingActivated && position.highWaterMark) {
          let dropFromPeak: number;
          if (position.side === "long") {
            dropFromPeak = ((position.highWaterMark - priceData.price) / position.highWaterMark) * 100;
          } else {
            dropFromPeak = ((priceData.price - position.highWaterMark) / position.highWaterMark) * 100;
          }

          if (dropFromPeak >= trailingPct) {
            const peakPnlPct = position.side === "long"
              ? ((position.highWaterMark - position.entryPrice) / position.entryPrice) * 100
              : ((position.entryPrice - position.highWaterMark) / position.entryPrice) * 100;
            const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, 90);
            await storage.createServerBotLog({
              botId: bot.id, userId: bot.userId, logType: "signal",
              message: `TRAILING-STOP triggered @ $${priceData.price.toFixed(6)} | Dropped ${dropFromPeak.toFixed(2)}% from peak $${position.highWaterMark.toFixed(6)} (peak was +${peakPnlPct.toFixed(2)}%) | Locking in +${pnlPercent.toFixed(2)}% profit | Trail: ${trailingPct}% | Net P&L: $${profitCheck.netPnl.toFixed(4)} | ${profitCheck.feeBreakdown}${positionInfo}${autoInfo}`,
              data: { signal, price: priceData.price, pnlPercent, peakPrice: position.highWaterMark, peakPnlPct, dropFromPeak, trailingPct, fees: profitCheck },
            });
            await executeCloseOrder(bot, priceData, position, signal, "TAKE_PROFIT", profitCheck, settings);
            return;
          }
        }
      }

      if (position.atrStopLossPct && (!effectiveSL || position.atrStopLossPct > effectiveSL)) {
        effectiveSL = position.atrStopLossPct;
      }
      if (position.atrTakeProfitPct && (!effectiveTP || position.atrTakeProfitPct > effectiveTP)) {
        effectiveTP = position.atrTakeProfitPct;
      }

      // Stop loss: for locked-pair bots, always check (ignore trailingActivated); for normal bots, only if trailing not active
      if ((isLockedPair || !position.trailingActivated) && effectiveSL && pnlPercent <= -effectiveSL) {
        const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, 90);
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "signal",
          message: `STOP-LOSS triggered @ $${priceData.price.toFixed(6)} (${pnlPercent.toFixed(2)}% loss, SL: -${effectiveSL}%) | ${profitCheck.feeBreakdown}${positionInfo}${autoInfo}`,
          data: { signal, price: priceData.price, pnlPercent, stopLoss: effectiveSL, fees: profitCheck },
        });
        await executeCloseOrder(bot, priceData, position, signal, "STOP_LOSS", profitCheck, settings);
        return;
      }

      if (!isLockedPair && position.trailingActivated && pnlPercent <= 0) {
        const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, 90);
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "signal",
          message: `TRAILING-STOP EMERGENCY EXIT @ $${priceData.price.toFixed(6)} | Was in profit (trailing active) but dropped to ${pnlPercent.toFixed(2)}% | Protecting capital${positionInfo}${autoInfo}`,
          data: { signal, price: priceData.price, pnlPercent, fees: profitCheck },
        });
        await executeCloseOrder(bot, priceData, position, signal, "STOP_LOSS", profitCheck, settings);
        return;
      }
    }

    if (signal.direction === "HOLD" || signal.strength < effectiveThreshold || signal.confidence < 50) {
      return;
    }

    if (bot.lastTradeAt) {
      const timeSinceLastTrade = Date.now() - new Date(bot.lastTradeAt).getTime();
      if (timeSinceLastTrade < effectiveCooldownMs) {
        return;
      }
    }

    const enableFuturesShort = (settings.enableFuturesShort || settings.autoFuturesShort) && isFuturesCapable(bot.exchange);
    const futuresLeverage = (settings.futuresLeverage as number) || 1;
    const futuresMarginMode = ((settings.futuresMarginMode as string) || "cross") as "cross" | "isolated";

    if (signal.direction === "SELL") {
      if (position && position.side === "short") {
        return;
      }

      if (position && position.side === "long") {
        const holdTimeMs = Date.now() - position.entryTime;
        const minHoldMs = 5 * 60 * 1000;
        if (holdTimeMs < minHoldMs) {
          return;
        }

        const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, signal.strength);
        const { pnlPercent } = calcPositionPnl(position, priceData.price);

        const minProfitPct = 1.2;
        if (profitCheck.profitable && pnlPercent < minProfitPct) {
          return;
        }

        if (!profitCheck.profitable) {
          await storage.createServerBotLog({
            botId: bot.id, userId: bot.userId, logType: "info",
            message: `SELL signal (str: ${signal.strength.toFixed(1)}%) SKIPPED — not profitable after fees | Gross: $${profitCheck.grossPnl.toFixed(4)} - Fees: $${profitCheck.fees.toFixed(4)} = Net: $${profitCheck.netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | Need price > $${profitCheck.minProfitPrice.toFixed(6)} | ${profitCheck.feeBreakdown}${positionInfo}${autoInfo}`,
            data: { signal, price: priceData.price, profitCheck, pnlPercent, entryPrice: position.entryPrice },
          });
          return;
        }

        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "signal",
          message: `SELL signal fired (str: ${signal.strength.toFixed(1)}%, conf: ${signal.confidence.toFixed(1)}%) — PROFITABLE after fees | Net P&L: $${profitCheck.netPnl.toFixed(4)} | ${profitCheck.feeBreakdown}${positionInfo}${autoInfo}`,
          data: { signal, price: priceData.price, profitCheck },
        });

        await executeCloseOrder(bot, priceData, position, signal, "SIGNAL", profitCheck, settings);
        return;
      }

      if (!position && enableFuturesShort) {
        const investment = (settings.investment as number) || 100;
        const roundTripFees = calcRoundTripFees(bot.exchange, investment);

        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "signal",
          message: `SHORT signal fired (str: ${signal.strength.toFixed(1)}%, conf: ${signal.confidence.toFixed(1)}%) @ $${priceData.price.toFixed(6)} | Leverage: ${futuresLeverage}x ${futuresMarginMode} | Round-trip fees: $${roundTripFees.totalFees.toFixed(4)} (${roundTripFees.feePercent.toFixed(3)}%) | ${exchangeFees.name}: ${(exchangeFees.taker * 100).toFixed(2)}% taker${autoInfo}`,
          data: { signal, price: priceData.price, roundTripFees, exchangeFees: { maker: exchangeFees.maker, taker: exchangeFees.taker }, futures: true, leverage: futuresLeverage, marginMode: futuresMarginMode },
        });

        await executeShortOrder(bot, priceData, signal, settings, futuresLeverage, futuresMarginMode);
        return;
      }

      if (!position) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `SELL signal fired (str: ${signal.strength.toFixed(1)}%) but no open position to sell.${enableFuturesShort ? '' : ' Futures shorting disabled.'} Waiting for BUY entry.${autoInfo}`,
          data: { signal, price: priceData.price },
        });
        return;
      }
    }

    if (signal.direction === "BUY") {
      if (position && position.side === "short") {
        const profitCheck = isCloseProfitableAfterFees(position, priceData.price, bot.exchange, signal.strength);
        const { pnlPercent } = calcPositionPnl(position, priceData.price);

        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "signal",
          message: `BUY signal closing SHORT position (str: ${signal.strength.toFixed(1)}%, conf: ${signal.confidence.toFixed(1)}%) @ $${priceData.price.toFixed(6)} | Net P&L: $${profitCheck.netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | ${profitCheck.feeBreakdown}${positionInfo}${autoInfo}`,
          data: { signal, price: priceData.price, profitCheck, pnlPercent },
        });

        await executeCloseOrder(bot, priceData, position, signal, "SIGNAL", profitCheck, settings);
        return;
      }

      if (position) {
        return;
      }

      // Locked-pair re-entry: wait for price to drop 1.87% below last sell price
      const reentryDipPct = settings._reentryDipPct as number | undefined;
      const lastSellPrice = settings._lastSellPrice as number | undefined;
      if (reentryDipPct && lastSellPrice && lastSellPrice > 0) {
        const reentryTarget = lastSellPrice * (1 - reentryDipPct / 100);
        if (priceData.price > reentryTarget) {
          return;
        }
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `Re-entry dip met: price $${priceData.price.toFixed(6)} dropped ${reentryDipPct}% below last sell $${lastSellPrice.toFixed(6)} (target: $${reentryTarget.toFixed(6)}) | Proceeding with BUY checks${autoInfo}`,
          data: { price: priceData.price, lastSellPrice, reentryTarget, reentryDipPct },
        });
      }

      const lossCooldown = isBotOnLossCooldown(bot.id);
      if (lossCooldown.blocked) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `BUY signal (str: ${signal.strength.toFixed(1)}%) BLOCKED by loss protection — ${lossCooldown.reason} | Price: $${priceData.price.toFixed(6)}${autoInfo}`,
          data: { signal, price: priceData.price, lossCooldown },
        });
        return;
      }

      const trendCheck = await verifyUptrendBeforeBuy(pairSymbol, priceData.price);
      if (!trendCheck.confirmed) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `BUY signal (str: ${signal.strength.toFixed(1)}%) BLOCKED by trend filter — ${trendCheck.reason} | Price: $${priceData.price.toFixed(6)}${autoInfo}`,
          data: { signal, price: priceData.price, trendCheck },
        });
        return;
      }

      const adxCheck = calcADX(pairSymbol);
      const volCheck = calcVolumeSpike(pairSymbol, 20, 1.5);
      const atrPct = calcATRPercent(pairSymbol);

      if (adxCheck.adx <= 20 || adxCheck.plusDI <= adxCheck.minusDI) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `BUY signal (str: ${signal.strength.toFixed(1)}%) BLOCKED by ADX filter — ADX: ${adxCheck.adx.toFixed(0)} (need >20), +DI: ${adxCheck.plusDI.toFixed(0)}, -DI: ${adxCheck.minusDI.toFixed(0)} ${adxCheck.adx < 20 ? '(choppy market)' : '(bearish direction)'} | Price: $${priceData.price.toFixed(6)}${autoInfo}`,
          data: { signal, price: priceData.price, adxCheck },
        });
        return;
      }

      const rsiTurningUpForEntry = isRSITurningUp(pairSymbol);
      const currentRSI = calcRSI(pairSymbol, 14);
      if (!rsiTurningUpForEntry && currentRSI < 45) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `BUY signal (str: ${signal.strength.toFixed(1)}%) BLOCKED by RSI momentum — RSI ${currentRSI.toFixed(1)} still falling (need rising RSI to confirm reversal, not catch falling knife) | Price: $${priceData.price.toFixed(6)}${autoInfo}`,
          data: { signal, price: priceData.price, rsi: currentRSI, rsiTurningUp: rsiTurningUpForEntry },
        });
        return;
      }

      if (!volCheck.spike && signal.strength <= 75) {
        await storage.createServerBotLog({
          botId: bot.id, userId: bot.userId, logType: "info",
          message: `BUY signal (str: ${signal.strength.toFixed(1)}%) BLOCKED by volume filter — Vol ratio: ${volCheck.ratio.toFixed(2)}x (need 1.5x+) | Weak volume = unreliable entry | Price: $${priceData.price.toFixed(6)}${autoInfo}`,
          data: { signal, price: priceData.price, volCheck },
        });
        return;
      }

      const investment = (settings.investment as number) || 100;
      const roundTripFees = calcRoundTripFees(bot.exchange, investment);

      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "signal",
        message: `BUY signal fired (str: ${signal.strength.toFixed(1)}%, conf: ${signal.confidence.toFixed(1)}%) @ $${priceData.price.toFixed(6)} | Trend: ${trendCheck.reason} | ADX: ${adxCheck.adx.toFixed(0)} +DI>${adxCheck.plusDI.toFixed(0)} | Vol: ${volCheck.ratio.toFixed(1)}x | ATR: ${atrPct.toFixed(2)}% | Round-trip fees: $${roundTripFees.totalFees.toFixed(4)} (${roundTripFees.feePercent.toFixed(3)}%) | ${exchangeFees.name}: ${(exchangeFees.taker * 100).toFixed(2)}% taker${autoInfo}`,
        data: { signal, price: priceData.price, roundTripFees, exchangeFees: { maker: exchangeFees.maker, taker: exchangeFees.taker }, trendCheck, adxCheck, volCheck: { ratio: volCheck.ratio }, atrPct },
      });

      await executeBuyOrder(bot, priceData, signal, settings);
      return;
    }
  } catch (err: any) {
    console.error(`[BotEngine] Error processing bot #${bot.id}:`, err.message);
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `Engine error: ${err.message}`,
      data: null,
    });
  }
}

async function executeBuyOrder(
  bot: ServerBot,
  priceData: PriceData,
  signal: Signal,
  settings: Record<string, any>
): Promise<void> {
  const investment = (settings.investment as number) || 100;
  const quantity = investment / priceData.price;
  const exchangeFees = getExchangeFees(bot.exchange);
  const buyFee = investment * exchangeFees.taker;
  const effectiveQuantity = (investment - buyFee) / priceData.price;

  const pairSymbol = bot.pair.replace("/", "");
  const atrPctAtEntry = calcATRPercent(pairSymbol);
  const entryAtrSL = atrPctAtEntry > 0 ? Math.max(1.8, Math.min(15, atrPctAtEntry * 2.0)) : undefined;
  const entryAtrTP = atrPctAtEntry > 0 ? Math.max(2.7, Math.min(20, atrPctAtEntry * 3.0)) : undefined;

  if (settings.paperTrading) {
    const position: OpenPosition = {
      entryPrice: priceData.price,
      quantity: effectiveQuantity,
      entryTime: Date.now(),
      side: "long",
      investment,
      atrStopLossPct: entryAtrSL,
      atrTakeProfitPct: entryAtrTP,
    };
    await savePosition(bot.id, position);
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `[PAPER] BUY ${effectiveQuantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} ($${investment} - $${buyFee.toFixed(4)} fee) | Position opened`,
      data: { signal, price: priceData.price, paper: true, quantity: effectiveQuantity, investment, fee: buyFee, position },
    });
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
    });
    return;
  }

  const usage = await storage.getUserTradeUsage(bot.userId);
  if (usage.maxTrades !== -1 && usage.tradesUsed >= usage.maxTrades) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "warning",
      message: `Daily trade limit reached (${usage.tradesUsed}/${usage.maxTrades}). Skipping BUY.`,
      data: { signal, price: priceData.price },
    });
    return;
  }

  let connections = await storage.getUserExchangeConnections(bot.userId);
  let conn = connections.find((c) => c.exchangeName === bot.exchange && c.isActive);
  if (!conn) {
    const DEV_USER_ID = "50777126";
    if (bot.userId !== DEV_USER_ID) {
      const fallbackConns = await storage.getUserExchangeConnections(DEV_USER_ID);
      conn = fallbackConns.find((c) => c.exchangeName === bot.exchange && c.isActive);
      if (conn) {
        console.log(`[BotEngine] Using fallback ${bot.exchange} connection from dev user for bot #${bot.id} (user ${bot.userId})`);
      }
    }
  }
  if (!conn) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `No active ${bot.exchange} connection. Cannot execute BUY.`,
      data: { signal },
    });
    return;
  }

  const apiKey = decryptApiKey(conn.apiKeyEncrypted);
  const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
  const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

  console.log(`[BotEngine] LIVE BUY bot #${bot.id} (${bot.name}): ${quantity.toFixed(6)} ${bot.pair} @ $${priceData.price} | Fee: $${buyFee.toFixed(4)} | Exchange: ${bot.exchange}`);

  const result = await executeExchangeOrder(bot.exchange, apiKey, apiSecret, bot.pair, "BUY", quantity, passphrase);

  if (result.success) {
    const position: OpenPosition = {
      entryPrice: priceData.price,
      quantity: effectiveQuantity,
      entryTime: Date.now(),
      side: "long",
      investment,
      atrStopLossPct: entryAtrSL,
      atrTakeProfitPct: entryAtrTP,
    };
    await savePosition(bot.id, position);
    await storage.incrementTradeUsage(bot.userId);
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
    });
    const atrInfo = entryAtrSL ? ` | ATR SL:${entryAtrSL.toFixed(1)}% TP:${entryAtrTP?.toFixed(1)}%` : '';
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `BUY ${quantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} - FILLED (${result.orderId}) | Fee: $${buyFee.toFixed(4)} (${(exchangeFees.taker * 100).toFixed(2)}%) | Position opened | Exchange: ${exchangeFees.name}${atrInfo}`,
      data: { signal, price: priceData.price, orderId: result.orderId, quantity, investment, fee: buyFee, position, exchange: bot.exchange },
    });
    console.log(`[BotEngine] BUY filled: ${result.orderId} | Position opened @ $${priceData.price} on ${bot.exchange}${atrInfo}`);
  } else {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `BUY order FAILED on ${exchangeFees.name}: ${result.error}`,
      data: { signal, price: priceData.price, error: result.error, quantity, exchange: bot.exchange },
    });
    console.log(`[BotEngine] BUY failed on ${bot.exchange}: ${result.error}`);

    const failKey = `buy_fail_${bot.id}`;
    const prevFails = (botFailCounts.get(failKey) || 0) + 1;
    botFailCounts.set(failKey, prevFails);

    const isPairError = result.error?.includes('not available') || result.error?.includes('Unknown asset pair') || result.error?.includes('Invalid symbol') || result.error?.includes('not implemented') || result.error?.includes('trading restricted');
    const isFundsError = result.error?.includes('Insufficient funds') || result.error?.includes('insufficient') || result.error?.includes('not enough');

    if (isPairError && prevFails >= 3) {
      console.log(`[BotEngine] Auto-pausing bot #${bot.id} (${bot.pair}) — pair not available on ${bot.exchange} after ${prevFails} failures`);
      await storage.updateServerBot(bot.id, { status: 'paused' });
      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "error",
        message: `AUTO-PAUSED: ${bot.pair} is not a valid trading pair on ${bot.exchange}. Bot paused after ${prevFails} consecutive failures.`,
        data: { error: result.error, failCount: prevFails },
      });
      botFailCounts.delete(failKey);
    } else if (isFundsError && prevFails >= 2) {
      console.log(`[BotEngine] Auto-pausing bot #${bot.id} (${bot.pair}) — insufficient funds on ${bot.exchange} after ${prevFails} failures`);
      await storage.updateServerBot(bot.id, { status: 'paused' });
      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "error",
        message: `AUTO-PAUSED: Insufficient funds on ${bot.exchange} for ${bot.pair}. Allocated $${bot.investment} exceeds available balance. Bot paused after ${prevFails} failures.`,
        data: { error: result.error, failCount: prevFails, investment: bot.investment },
      });
      botFailCounts.delete(failKey);
      if (_onBotPairFailed) _onBotPairFailed(bot.pair, result.error);
    } else if (isPairError && prevFails >= 1) {
      if (_onBotPairFailed) _onBotPairFailed(bot.pair, result.error);
    }
  }
}

async function executeCloseOrder(
  bot: ServerBot,
  priceData: PriceData,
  position: OpenPosition,
  signal: Signal,
  reason: "SIGNAL" | "STOP_LOSS" | "TAKE_PROFIT",
  profitCheck: ReturnType<typeof isSellProfitableAfterFees>,
  settings: Record<string, any>
): Promise<void> {
  const exchangeFees = getExchangeFees(bot.exchange);
  const closeValue = priceData.price * position.quantity;
  const closeFee = closeValue * exchangeFees.taker;
  const { pnlPercent } = calcPositionPnl(position, priceData.price);
  const holdTime = Date.now() - position.entryTime;
  const holdTimeStr = holdTime > 3600000 ? `${(holdTime / 3600000).toFixed(1)}h` : `${(holdTime / 60000).toFixed(0)}m`;
  const actionLabel = position.side === "short" ? "CLOSE SHORT" : "SELL";
  const isShort = position.side === "short";
  const pairSymbol = bot.pair.replace("/", "");

  if (settings.paperTrading) {
    recordTradeResult(pairSymbol, profitCheck.netPnl > 0);
    recordBotTradeOutcome(bot.id, profitCheck.netPnl);
    await savePosition(bot.id, null);
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
      totalPnl: (bot.totalPnl || 0) + profitCheck.netPnl,
    });
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `[PAPER] ${actionLabel} ${position.quantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} (${reason}) | Entry: $${position.entryPrice.toFixed(6)} | Gross: $${profitCheck.grossPnl.toFixed(4)} | Fees: $${profitCheck.fees.toFixed(4)} | Net P&L: $${profitCheck.netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | Held: ${holdTimeStr}${isShort ? ` [Futures ${position.leverage || 1}x]` : ''}`,
      data: { signal, price: priceData.price, paper: true, reason, profitCheck, position, holdTime, pnlPercent, side: position.side },
    });
    return;
  }

  const usage = await storage.getUserTradeUsage(bot.userId);
  if (usage.maxTrades !== -1 && usage.tradesUsed >= usage.maxTrades) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "warning",
      message: `Daily trade limit reached (${usage.tradesUsed}/${usage.maxTrades}). Cannot execute ${actionLabel}.`,
      data: { signal, price: priceData.price },
    });
    return;
  }

  let connections = await storage.getUserExchangeConnections(bot.userId);
  let conn = connections.find((c) => c.exchangeName === bot.exchange && c.isActive);
  if (!conn) {
    const DEV_USER_ID = "50777126";
    if (bot.userId !== DEV_USER_ID) {
      const fallbackConns = await storage.getUserExchangeConnections(DEV_USER_ID);
      conn = fallbackConns.find((c) => c.exchangeName === bot.exchange && c.isActive);
      if (conn) {
        console.log(`[BotEngine] Using fallback ${bot.exchange} connection from dev user for bot #${bot.id} (user ${bot.userId})`);
      }
    }
  }
  if (!conn) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `No active ${bot.exchange} connection. Cannot execute ${actionLabel}.`,
      data: { signal },
    });
    return;
  }

  const apiKey = decryptApiKey(conn.apiKeyEncrypted);
  const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
  const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

  console.log(`[BotEngine] LIVE ${actionLabel} bot #${bot.id} (${bot.name}): ${position.quantity.toFixed(6)} ${bot.pair} @ $${priceData.price} (${reason}) | Net P&L: $${profitCheck.netPnl.toFixed(4)} | Exchange: ${bot.exchange}`);

  let result;
  if (isShort && position.futuresMode) {
    result = await closeFuturesPosition(bot.exchange, apiKey, apiSecret, bot.pair, "short", position.quantity, passphrase);
  } else {
    result = await executeExchangeOrder(bot.exchange, apiKey, apiSecret, bot.pair, "SELL", position.quantity, passphrase);
  }

  if (result.success) {
    recordTradeResult(pairSymbol, profitCheck.netPnl > 0);
    recordBotTradeOutcome(bot.id, profitCheck.netPnl);
    await savePosition(bot.id, null);
    await storage.incrementTradeUsage(bot.userId);
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
      totalPnl: (bot.totalPnl || 0) + profitCheck.netPnl,
    });
    const consecutiveLosses = botConsecutiveLosses.get(bot.id) || 0;
    const lossCooldownInfo = consecutiveLosses > 0 ? ` | ConsecLosses: ${consecutiveLosses}` : '';
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `${actionLabel} ${position.quantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} - FILLED (${result.orderId}) (${reason}) | Entry: $${position.entryPrice.toFixed(6)} | Gross: $${profitCheck.grossPnl.toFixed(4)} | Fees: $${profitCheck.fees.toFixed(4)} (${exchangeFees.name} ${(exchangeFees.taker * 100).toFixed(2)}%) | Net P&L: $${profitCheck.netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | Held: ${holdTimeStr} | Exchange: ${exchangeFees.name}${isShort ? ` [Futures ${position.leverage || 1}x]` : ''}${lossCooldownInfo}`,
      data: { signal, price: priceData.price, orderId: result.orderId, reason, profitCheck, position, holdTime, pnlPercent, exchange: bot.exchange, side: position.side },
    });
    console.log(`[BotEngine] ${actionLabel} filled: ${result.orderId} | Net P&L: $${profitCheck.netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | Held: ${holdTimeStr} on ${bot.exchange}`);
  } else {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `${actionLabel} order FAILED on ${exchangeFees.name}: ${result.error} (${reason})`,
      data: { signal, price: priceData.price, error: result.error, reason, position, exchange: bot.exchange },
    });
    console.log(`[BotEngine] ${actionLabel} failed on ${bot.exchange}: ${result.error}`);
  }
}

async function executeShortOrder(
  bot: ServerBot,
  priceData: PriceData,
  signal: Signal,
  settings: Record<string, any>,
  leverage: number,
  marginMode: "cross" | "isolated"
): Promise<void> {
  const investment = (settings.investment as number) || 100;
  const quantity = investment / priceData.price;
  const exchangeFees = getExchangeFees(bot.exchange);
  const entryFee = investment * exchangeFees.taker;
  const effectiveQuantity = (investment - entryFee) / priceData.price;

  if (settings.paperTrading) {
    const position: OpenPosition = {
      entryPrice: priceData.price,
      quantity: effectiveQuantity,
      entryTime: Date.now(),
      side: "short",
      investment,
      leverage,
      marginMode,
      futuresMode: true,
    };
    await savePosition(bot.id, position);
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `[PAPER] SHORT ${effectiveQuantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} ($${investment} - $${entryFee.toFixed(4)} fee) | ${leverage}x ${marginMode} | Position opened`,
      data: { signal, price: priceData.price, paper: true, quantity: effectiveQuantity, investment, fee: entryFee, position, side: "short", leverage, marginMode },
    });
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
    });
    return;
  }

  const usage = await storage.getUserTradeUsage(bot.userId);
  if (usage.maxTrades !== -1 && usage.tradesUsed >= usage.maxTrades) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "warning",
      message: `Daily trade limit reached (${usage.tradesUsed}/${usage.maxTrades}). Skipping SHORT.`,
      data: { signal, price: priceData.price },
    });
    return;
  }

  let connections = await storage.getUserExchangeConnections(bot.userId);
  let conn = connections.find((c) => c.exchangeName === bot.exchange && c.isActive);
  if (!conn) {
    const DEV_USER_ID = "50777126";
    if (bot.userId !== DEV_USER_ID) {
      const fallbackConns = await storage.getUserExchangeConnections(DEV_USER_ID);
      conn = fallbackConns.find((c) => c.exchangeName === bot.exchange && c.isActive);
      if (conn) {
        console.log(`[BotEngine] Using fallback ${bot.exchange} connection from dev user for bot #${bot.id} (user ${bot.userId})`);
      }
    }
  }
  if (!conn) {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `No active ${bot.exchange} connection. Cannot execute SHORT.`,
      data: { signal },
    });
    return;
  }

  const apiKey = decryptApiKey(conn.apiKeyEncrypted);
  const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
  const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

  console.log(`[BotEngine] LIVE SHORT bot #${bot.id} (${bot.name}): ${quantity.toFixed(6)} ${bot.pair} @ $${priceData.price} | Leverage: ${leverage}x ${marginMode} | Fee: $${entryFee.toFixed(4)} | Exchange: ${bot.exchange}`);

  const result = await executeFuturesOrder({
    exchange: bot.exchange,
    apiKey,
    apiSecret,
    pair: bot.pair,
    side: "SHORT",
    quantity,
    leverage,
    marginMode,
    orderType: "market",
    passphrase,
  });

  if (result.success) {
    const position: OpenPosition = {
      entryPrice: priceData.price,
      quantity: effectiveQuantity,
      entryTime: Date.now(),
      side: "short",
      investment,
      leverage,
      marginMode,
      futuresMode: true,
    };
    await savePosition(bot.id, position);
    await storage.incrementTradeUsage(bot.userId);
    await storage.updateServerBot(bot.id, {
      lastTradeAt: new Date(),
      totalTrades: (bot.totalTrades || 0) + 1,
    });
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "trade",
      message: `SHORT ${quantity.toFixed(6)} ${bot.pair} @ $${priceData.price.toFixed(6)} - FILLED (${result.orderId}) | ${leverage}x ${marginMode} | Fee: $${entryFee.toFixed(4)} (${(exchangeFees.taker * 100).toFixed(2)}%) | Position opened | Exchange: ${exchangeFees.name}`,
      data: { signal, price: priceData.price, orderId: result.orderId, quantity, investment, fee: entryFee, position, exchange: bot.exchange, side: "short", leverage, marginMode },
    });
    console.log(`[BotEngine] SHORT filled: ${result.orderId} | Position opened @ $${priceData.price} on ${bot.exchange} (${leverage}x ${marginMode})`);
  } else {
    await storage.createServerBotLog({
      botId: bot.id, userId: bot.userId, logType: "error",
      message: `SHORT order FAILED on ${exchangeFees.name}: ${result.error}`,
      data: { signal, price: priceData.price, error: result.error, quantity, exchange: bot.exchange, leverage, marginMode },
    });
    console.log(`[BotEngine] SHORT failed on ${bot.exchange}: ${result.error}`);

    const failKey = `short_fail_${bot.id}`;
    const prevFails = (botFailCounts.get(failKey) || 0) + 1;
    botFailCounts.set(failKey, prevFails);

    const isPairError = result.error?.includes('not available') || result.error?.includes('Unknown asset pair') || result.error?.includes('Invalid symbol') || result.error?.includes('not support');
    if (isPairError && prevFails >= 3) {
      console.log(`[BotEngine] Disabling futures shorting for bot #${bot.id} (${bot.pair}) — not supported on ${bot.exchange} after ${prevFails} failures`);
      const currentSettings = { ...(settings as Record<string, any>) };
      currentSettings.enableFuturesShort = false;
      currentSettings.autoFuturesShort = false;
      await storage.updateServerBot(bot.id, { settings: currentSettings });
      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "warning",
        message: `Futures shorting disabled for ${bot.pair} on ${bot.exchange} after ${prevFails} consecutive failures. Pair may not support futures.`,
        data: { error: result.error, failCount: prevFails },
      });
      botFailCounts.delete(failKey);
    }
  }
}

let wsConnection: WebSocket | null = null;
let subscribedSymbols: Set<string> = new Set();
let botRefreshInterval: NodeJS.Timeout | null = null;
let engineActive = false;
let activeBots: ServerBot[] = [];
let reconnectTimeout: NodeJS.Timeout | null = null;
let processingQueue: Map<string, boolean> = new Map();

const BOT_REFRESH_MS = 5000;

async function refreshActiveBots(): Promise<void> {
  try {
    activeBots = await storage.getActiveServerBots();
    const neededSymbols = new Set<string>();
    for (const bot of activeBots) {
      neededSymbols.add(bot.pair.replace("/", "").toLowerCase());
    }

    let needsReconnect = false;
    for (const sym of neededSymbols) {
      if (!subscribedSymbols.has(sym)) {
        needsReconnect = true;
        break;
      }
    }
    for (const sym of subscribedSymbols) {
      if (!neededSymbols.has(sym)) {
        needsReconnect = true;
        break;
      }
    }

    if (needsReconnect && neededSymbols.size > 0) {
      subscribedSymbols = neededSymbols;
      connectWebSocket();
    } else if (neededSymbols.size === 0 && wsConnection) {
      wsConnection.close();
      wsConnection = null;
      subscribedSymbols.clear();
    }
  } catch (err: any) {
    console.error("[BotEngine] Failed to refresh bots:", err.message);
  }
}

function connectWebSocket(): void {
  if (wsConnection) {
    wsConnection.removeAllListeners();
    wsConnection.close();
    wsConnection = null;
  }

  if (subscribedSymbols.size === 0) return;

  const streams = Array.from(subscribedSymbols).map(s => `${s}@ticker`).join("/");
  const wsUrl = `wss://stream.binance.com:9443/ws/${streams}`;

  console.log(`[BotEngine] Connecting real-time WebSocket for ${subscribedSymbols.size} pair(s): ${Array.from(subscribedSymbols).join(", ")}`);

  wsConnection = new WebSocket(wsUrl);

  wsConnection.on("open", () => {
    wsFailCount = 0;
    console.log(`[BotEngine] WebSocket LIVE — streaming real-time prices for: ${Array.from(subscribedSymbols).join(", ")}`);
  });

  wsConnection.on("message", async (data: Buffer) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.e !== "24hrTicker") return;

      const symbol = msg.s;
      const priceData: PriceData = {
        symbol,
        price: parseFloat(msg.c),
        priceChange: parseFloat(msg.p),
        priceChangePercent: parseFloat(msg.P),
        high24h: parseFloat(msg.h),
        low24h: parseFloat(msg.l),
        volume24h: parseFloat(msg.v),
        updatedAt: Date.now(),
      };

      livePrices.set(symbol, priceData);
      updatePriceHistory(symbol, priceData.price, priceData.volume24h);

      if (processingQueue.get(symbol)) return;
      processingQueue.set(symbol, true);

      try {
        const matchingBots = activeBots.filter(
          (b) => b.pair.replace("/", "").toUpperCase() === symbol.toUpperCase() && b.status === "running"
        );

        for (const bot of matchingBots) {
          await processBot(bot, priceData);
        }
      } finally {
        processingQueue.set(symbol, false);
      }
    } catch (err: any) {
      if (err.message !== "Unexpected end of JSON input") {
        console.error("[BotEngine] WS message error:", err.message);
      }
    }
  });

  wsConnection.on("error", (err) => {
    wsFailCount++;
    if (wsFailCount <= 3 || wsFailCount % 100 === 0) {
      console.error(`[BotEngine] WebSocket error (${wsFailCount}x): ${err.message}`);
    }
    if (wsFailCount === 3) {
      console.log("[BotEngine] WebSocket blocked/unavailable — switching to REST API polling with multi-source fallback (Binance, Binance.US, CoinGecko)");
    }
  });

  wsConnection.on("close", (code, reason) => {
    wsConnection = null;
    if (wsFailCount >= 3) {
      if (wsFailCount === 3) {
        console.log("[BotEngine] WebSocket disabled after repeated failures. REST fallback active.");
      }
      return;
    }
    console.log(`[BotEngine] WebSocket closed (${code}). Reconnecting in 3s...`);
    if (engineActive) {
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      reconnectTimeout = setTimeout(() => {
        if (engineActive && subscribedSymbols.size > 0) {
          connectWebSocket();
        }
      }, 3000);
    }
  });
}

let wsFailCount = 0;
let lastFallbackLog = 0;

async function fetchPriceFromBinance(symbol: string): Promise<PriceData | null> {
  try {
    const res = await fetch(`https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${symbol}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as any;
    return {
      symbol,
      price: parseFloat(data.lastPrice),
      priceChange: parseFloat(data.priceChange),
      priceChangePercent: parseFloat(data.priceChangePercent),
      high24h: parseFloat(data.highPrice),
      low24h: parseFloat(data.lowPrice),
      volume24h: parseFloat(data.volume),
      updatedAt: Date.now(),
    };
  } catch { return null; }
}

async function fetchPriceFromBinanceUS(symbol: string): Promise<PriceData | null> {
  try {
    const res = await fetch(`https://api.binance.us/api/v3/ticker/24hr?symbol=${symbol}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as any;
    return {
      symbol,
      price: parseFloat(data.lastPrice),
      priceChange: parseFloat(data.priceChange),
      priceChangePercent: parseFloat(data.priceChangePercent),
      high24h: parseFloat(data.highPrice),
      low24h: parseFloat(data.lowPrice),
      volume24h: parseFloat(data.volume),
      updatedAt: Date.now(),
    };
  } catch { return null; }
}

async function fetchPriceFromCoinGecko(pair: string): Promise<PriceData | null> {
  try {
    const coinMap: Record<string, string> = {
      BTC: "bitcoin", ETH: "ethereum", XRP: "ripple", SOL: "solana", DOGE: "dogecoin",
      ADA: "cardano", DOT: "polkadot", AVAX: "avalanche-2", LINK: "chainlink",
      MATIC: "matic-network", LTC: "litecoin", UNI: "uniswap", ATOM: "cosmos",
      SHIB: "shiba-inu", BNB: "binancecoin", TRX: "tron",
    };
    const base = pair.split("/")[0];
    const coinId = coinMap[base];
    if (!coinId) return null;
    const res = await fetch(`https://api.coingecko.com/api/v3/coins/${coinId}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as any;
    const md = data?.market_data;
    if (!md?.current_price?.usd) return null;
    const symbol = pair.replace("/", "").toUpperCase();
    const price = md.current_price.usd;
    const change24h = md.price_change_24h || 0;
    return {
      symbol,
      price,
      priceChange: change24h,
      priceChangePercent: md.price_change_percentage_24h || 0,
      high24h: md.high_24h?.usd || price,
      low24h: md.low_24h?.usd || price,
      volume24h: md.total_volume?.usd || 0,
      updatedAt: Date.now(),
    };
  } catch { return null; }
}

async function fetchPriceFromKraken(pair: string): Promise<PriceData | null> {
  try {
    const [base, quote] = pair.split("/");
    const krakenAliases: Record<string, string> = { BTC: 'XBT', DOGE: 'XDG' };
    const krakenBase = krakenAliases[base] || base;
    const krakenQuote = quote === 'USD' ? 'USD' : quote === 'USDT' ? 'USDT' : quote;

    const candidates = [
      `${krakenBase}${krakenQuote}`,
      `X${krakenBase}Z${krakenQuote}`,
      `${base}${krakenQuote}`,
    ];

    for (const krakenPair of candidates) {
      const res = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${krakenPair}`, { signal: AbortSignal.timeout(5000) });
      if (!res.ok) continue;
      const data = (await res.json()) as any;
      if (data.error?.length > 0) continue;
      const result = data.result;
      if (!result) continue;
      const key = Object.keys(result)[0];
      if (!key) continue;
      const t = result[key];
      const price = parseFloat(t.c?.[0] || '0');
      if (price <= 0) continue;
      const high = parseFloat(t.h?.[1] || '0');
      const low = parseFloat(t.l?.[1] || '0');
      const volume = parseFloat(t.v?.[1] || '0');
      return {
        symbol: pair.replace("/", "").toUpperCase(),
        price,
        high24h: high,
        low24h: low,
        volume24h: volume * price,
        change24h: 0,
        updatedAt: Date.now(),
      };
    }
  } catch {}
  return null;
}

async function fetchPriceWithFallback(symbol: string, pair: string): Promise<PriceData | null> {
  const isUsdPair = pair.endsWith('/USD');

  if (isUsdPair) {
    let priceData = await fetchPriceFromKraken(pair);
    if (priceData) return priceData;

    const usdtSymbol = symbol.replace(/USD$/, 'USDT');
    priceData = await fetchPriceFromBinance(usdtSymbol);
    if (priceData) return priceData;

    priceData = await fetchPriceFromCoinGecko(pair);
    if (priceData) return priceData;

    return null;
  }

  let priceData = await fetchPriceFromBinance(symbol);
  if (priceData) return priceData;

  priceData = await fetchPriceFromBinanceUS(symbol);
  if (priceData) {
    if (Date.now() - lastFallbackLog > 60000) {
      console.log(`[BotEngine] Using Binance.US fallback for ${symbol}`);
      lastFallbackLog = Date.now();
    }
    return priceData;
  }

  priceData = await fetchPriceFromKraken(pair);
  if (priceData) {
    if (Date.now() - lastFallbackLog > 60000) {
      console.log(`[BotEngine] Using Kraken fallback for ${pair}`);
      lastFallbackLog = Date.now();
    }
    return priceData;
  }

  priceData = await fetchPriceFromCoinGecko(pair);
  if (priceData) {
    if (Date.now() - lastFallbackLog > 60000) {
      console.log(`[BotEngine] Using CoinGecko fallback for ${pair}`);
      lastFallbackLog = Date.now();
    }
    return priceData;
  }

  return null;
}

let fallbackTickCount = 0;

async function fallbackTick(): Promise<void> {
  if (!engineActive || activeBots.length === 0) return;
  fallbackTickCount++;

  if (fallbackTickCount % 20 === 1) {
    const historyDepths: string[] = [];
    for (const bot of activeBots) {
      const sym = bot.pair.replace("/", "").toUpperCase();
      const h = priceHistory.get(sym);
      historyDepths.push(`${sym}:${h?.prices.length || 0}`);
    }
    console.log(`[BotEngine] Fallback tick #${fallbackTickCount} | Active: ${activeBots.length} bots | History: ${historyDepths.join(', ')}`);
  }

  for (const bot of activeBots) {
    const symbol = bot.pair.replace("/", "").toUpperCase();
    const cached = livePrices.get(symbol);
    if (cached && Date.now() - cached.updatedAt < 10000) continue;

    const priceData = await fetchPriceWithFallback(symbol, bot.pair);
    if (priceData) {
      livePrices.set(symbol, priceData);
      updatePriceHistory(symbol, priceData.price, priceData.volume24h);
      await processBot(bot, priceData);
    }
  }
}

let fallbackInterval: NodeJS.Timeout | null = null;

export function startBotEngine(): void {
  if (engineActive) return;
  engineActive = true;

  console.log("[BotEngine] Starting REAL-TIME server-side bot engine (WebSocket streaming)");
  console.log(`[BotEngine] Exchange fee engine loaded: ${Object.keys(EXCHANGE_FEE_SCHEDULE).length} exchanges`);

  loadBotPositions().then(() => {
    console.log("[BotEngine] Position tracker initialized");
  });

  botRefreshInterval = setInterval(refreshActiveBots, BOT_REFRESH_MS);

  fallbackInterval = setInterval(fallbackTick, 3000);

  setTimeout(refreshActiveBots, 2000);
}

export function getExchangeFeeSchedule(): Record<string, ExchangeFees> {
  return { ...EXCHANGE_FEE_SCHEDULE };
}

export function getBotPosition(botId: number): OpenPosition | undefined {
  return botPositions.get(botId);
}

export function getAllPositions(): Map<number, OpenPosition> {
  return new Map(botPositions);
}

export function stopBotEngine(): void {
  engineActive = false;

  if (botRefreshInterval) {
    clearInterval(botRefreshInterval);
    botRefreshInterval = null;
  }
  if (fallbackInterval) {
    clearInterval(fallbackInterval);
    fallbackInterval = null;
  }
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }
  if (wsConnection) {
    wsConnection.close();
    wsConnection = null;
  }

  subscribedSymbols.clear();
  activeBots = [];
  console.log("[BotEngine] Stopped real-time bot engine");
}

export function isBotEngineRunning(): boolean {
  return engineActive;
}

export async function forceCloseAllPositions(filterFn?: (bot: any, position: OpenPosition) => boolean): Promise<{ closed: number; errors: string[]; results: any[] }> {
  const results: any[] = [];
  const errors: string[] = [];
  let closed = 0;

  const allBots = activeBots.length > 0 ? activeBots : [];
  if (allBots.length === 0) {
    const dbBots = await storage.getServerBotsByStatus("running");
    allBots.push(...dbBots);
  }

  for (const bot of allBots) {
    const position = botPositions.get(bot.id);
    if (!position) continue;
    if (filterFn && !filterFn(bot, position)) continue;

    const pairSymbol = bot.pair.replace("/", "");
    let currentPrice = livePrices.get(pairSymbol.toUpperCase())?.price || livePrices.get(pairSymbol.toLowerCase())?.price;

    if (!currentPrice) {
      try {
        const resp = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${pairSymbol.toUpperCase()}`);
        if (resp.ok) {
          const data = await resp.json() as any;
          currentPrice = parseFloat(data.price);
        }
      } catch {}
    }
    if (!currentPrice) {
      try {
        const resp = await fetch(`https://api.binance.us/api/v3/ticker/price?symbol=${pairSymbol.toUpperCase()}`);
        if (resp.ok) {
          const data = await resp.json() as any;
          currentPrice = parseFloat(data.price);
        }
      } catch {}
    }
    if (!currentPrice) {
      try {
        const base = bot.pair.split("/")[0].toLowerCase();
        const resp = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${base}&vs_currencies=usd`);
        if (resp.ok) {
          const data = await resp.json() as any;
          currentPrice = data[base]?.usd;
        }
      } catch {}
    }

    if (!currentPrice) {
      errors.push(`Bot #${bot.id} (${bot.pair}): Could not fetch current price`);
      continue;
    }

    const settings = (bot.settings as Record<string, any>) || {};
    const { pnlPercent } = calcPositionPnl(position, currentPrice);
    const exchangeFees = getExchangeFees(bot.exchange);
    const closeValue = currentPrice * position.quantity;
    const closeFee = closeValue * exchangeFees.taker;
    const buyFee = position.investment * exchangeFees.taker;
    const netPnl = (currentPrice - position.entryPrice) * position.quantity - buyFee - closeFee;

    let connections = await storage.getUserExchangeConnections(bot.userId);
    let conn = connections.find((c) => c.exchangeName === bot.exchange && c.isActive);
    if (!conn) {
      const DEV_USER_ID = "50777126";
      const fallbackConns = await storage.getUserExchangeConnections(DEV_USER_ID);
      conn = fallbackConns.find((c) => c.exchangeName === bot.exchange && c.isActive);
    }

    if (!conn) {
      errors.push(`Bot #${bot.id} (${bot.pair}): No exchange connection`);
      continue;
    }

    const apiKey = decryptApiKey(conn.apiKeyEncrypted);
    const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
    const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

    console.log(`[BotEngine] FORCE SELL bot #${bot.id} (${bot.name}): ${position.quantity.toFixed(6)} ${bot.pair} @ $${currentPrice} | P&L: $${netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%)`);

    const result = await executeExchangeOrder(bot.exchange, apiKey, apiSecret, bot.pair, "SELL", position.quantity, passphrase);

    if (result.success) {
      recordTradeResult(pairSymbol, netPnl > 0);
      recordBotTradeOutcome(bot.id, netPnl);
      await savePosition(bot.id, null);
      await storage.updateServerBot(bot.id, {
        lastTradeAt: new Date(),
        totalTrades: (bot.totalTrades || 0) + 1,
        totalPnl: (bot.totalPnl || 0) + netPnl,
        status: 'paused',
      });
      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "trade",
        message: `FORCE SELL ${position.quantity.toFixed(6)} ${bot.pair} @ $${currentPrice.toFixed(6)} (${result.orderId}) | Entry: $${position.entryPrice.toFixed(6)} | Net P&L: $${netPnl.toFixed(4)} (${pnlPercent.toFixed(2)}%) | Reason: Manual close-all | Bot paused`,
        data: { price: currentPrice, orderId: result.orderId, netPnl, pnlPercent, position, reason: "FORCE_CLOSE" },
      });
      results.push({ botId: bot.id, pair: bot.pair, orderId: result.orderId, netPnl, pnlPercent, price: currentPrice });
      closed++;
    } else {
      errors.push(`Bot #${bot.id} (${bot.pair}): SELL failed — ${result.error}`);
      await storage.createServerBotLog({
        botId: bot.id, userId: bot.userId, logType: "error",
        message: `FORCE SELL FAILED: ${result.error} | Pair: ${bot.pair} | Qty: ${position.quantity.toFixed(6)}`,
        data: { error: result.error, position },
      });
    }
  }

  return { closed, errors, results };
}

export async function forceBuyOrder(pair: string, exchange: string, userId: string, investment: number): Promise<{ success: boolean; error?: string; orderId?: string; position?: any }> {
  let connections = await storage.getUserExchangeConnections(userId);
  let conn = connections.find((c) => c.exchangeName === exchange && c.isActive);
  if (!conn) {
    const DEV_USER_ID = "50777126";
    const fallbackConns = await storage.getUserExchangeConnections(DEV_USER_ID);
    conn = fallbackConns.find((c) => c.exchangeName === exchange && c.isActive);
  }
  if (!conn) return { success: false, error: "No exchange connection" };

  const apiKey = decryptApiKey(conn.apiKeyEncrypted);
  const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
  const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

  const pairSymbol = pair.replace("/", "");
  let currentPrice = livePrices.get(pairSymbol.toUpperCase())?.price || livePrices.get(pairSymbol.toLowerCase())?.price;
  if (!currentPrice) {
    try {
      const resp = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${pairSymbol.toUpperCase()}`);
      if (resp.ok) { const d = await resp.json() as any; currentPrice = parseFloat(d.price); }
    } catch {}
  }
  if (!currentPrice) return { success: false, error: "Could not fetch price for " + pair };

  const exchangeFees = getExchangeFees(exchange);
  const buyFee = investment * exchangeFees.taker;
  const quantity = (investment - buyFee) / currentPrice;

  console.log(`[BotEngine] FORCE BUY: ${quantity.toFixed(6)} ${pair} @ $${currentPrice} | Investment: $${investment}`);
  const result = await executeExchangeOrder(exchange, apiKey, apiSecret, pair, "BUY", quantity, passphrase);

  if (result.success) {
    return { success: true, orderId: result.orderId, position: { entryPrice: currentPrice, quantity, investment, pair } };
  }
  return { success: false, error: result.error };
}

export function getEngineStatus(): {
  active: boolean;
  wsConnected: boolean;
  subscribedPairs: string[];
  activeBotCount: number;
  livePriceCount: number;
  priceHistoryDepth: Record<string, number>;
} {
  const depth: Record<string, number> = {};
  priceHistory.forEach((v, k) => { depth[k] = v.prices.length; });
  return {
    active: engineActive,
    wsConnected: wsConnection !== null && wsConnection.readyState === WebSocket.OPEN,
    subscribedPairs: Array.from(subscribedSymbols),
    activeBotCount: activeBots.length,
    livePriceCount: livePrices.size,
    priceHistoryDepth: depth,
  };
}
