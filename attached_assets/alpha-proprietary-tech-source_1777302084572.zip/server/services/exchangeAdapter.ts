/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Exchange Adapter™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import crypto from "crypto";

export interface OrderResult {
  success: boolean;
  orderId?: string;
  error?: string;
}

export interface ExchangeBalance {
  total: number;
  available: number;
  currency: string;
}

interface ExchangePairInfo {
  pairs: Map<string, string>;
  bases: Set<string>;
  ts: number;
}

const pairCaches = new Map<string, ExchangePairInfo>();

let lastKrakenNonce = 0;
function krakenNonce(): string {
  const n = Date.now() * 1000;
  lastKrakenNonce = n > lastKrakenNonce ? n : lastKrakenNonce + 1;
  return lastKrakenNonce.toString();
}

const ASSET_MAPS: Record<string, Record<string, string>> = {
  kraken: { BTC: "XBT", DOGE: "XDG" },
};

const KRAKEN_TO_STANDARD: Record<string, string> = {
  XBT: "BTC", XXBT: "BTC", XDG: "DOGE", XXDG: "DOGE",
  XETH: "ETH", XLTC: "LTC", XXLM: "XLM", XXMR: "XMR",
  XXRP: "XRP", XZEC: "ZEC", XETC: "ETC", XREP: "REP", XMLN: "MLN",
};

function log(msg: string) {
  console.log(`[ExchangeAdapter] ${msg}`);
}

function signKraken(apiSecret: string, path: string, nonce: string, postData: string): string {
  const sha256Hash = crypto.createHash("sha256").update(nonce + postData).digest();
  const hmac = crypto.createHmac("sha512", Buffer.from(apiSecret, "base64"));
  hmac.update(Buffer.concat([Buffer.from(path), sha256Hash]));
  return hmac.digest("base64");
}

function signBinance(apiSecret: string, queryString: string): string {
  return crypto.createHmac("sha256", apiSecret).update(queryString).digest("hex");
}

function signBybit(apiSecret: string, paramStr: string): string {
  return crypto.createHmac("sha256", apiSecret).update(paramStr).digest("hex");
}

function signOkx(apiSecret: string, timestamp: string, method: string, path: string, body: string = ""): string {
  return crypto.createHmac("sha256", apiSecret).update(timestamp + method + path + body).digest("base64");
}

function signKucoin(apiSecret: string, timestamp: string, method: string, path: string, body: string = ""): string {
  return crypto.createHmac("sha256", apiSecret).update(timestamp + method + path + body).digest("base64");
}

function signGateio(apiSecret: string, method: string, url: string, queryString: string, hashedBody: string, timestamp: string): string {
  const sigStr = `${method}\n${url}\n${queryString}\n${hashedBody}\n${timestamp}`;
  return crypto.createHmac("sha512", apiSecret).update(sigStr).digest("hex");
}

function signBitget(apiSecret: string, timestamp: string, method: string, path: string, body: string = ""): string {
  return crypto.createHmac("sha256", apiSecret).update(timestamp + method + path + body).digest("base64");
}

export async function getExchangeValidPairs(exchange: string): Promise<ExchangePairInfo> {
  const cached = pairCaches.get(exchange);
  if (cached && Date.now() - cached.ts < 3600000 && cached.bases.size > 0) {
    return cached;
  }

  const info: ExchangePairInfo = { pairs: new Map(), bases: new Set(), ts: Date.now() };

  try {
    if (exchange === "kraken") {
      const res = await fetch("https://api.kraken.com/0/public/AssetPairs", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Kraken API ${res.status}`);
      const data = (await res.json()) as any;
      for (const [pairName, pairData] of Object.entries(data.result || {}) as any[]) {
        if (pairName.endsWith(".d")) continue;
        const base = pairData.base || "";
        const quote = pairData.quote || "";
        const altname = pairData.altname || pairName;
        const standardBase = KRAKEN_TO_STANDARD[base] || base;
        const isUsd = quote === "ZUSD" || quote === "USD";
        const isUsdt = quote === "USDT";
        if (isUsd || isUsdt) {
          info.pairs.set(`${standardBase}/${isUsdt ? "USDT" : "USD"}`, altname);
          info.bases.add(standardBase);
        }
      }
    } else if (exchange === "binance" || exchange === "binanceus") {
      const url = exchange === "binanceus"
        ? "https://api.binance.us/api/v3/exchangeInfo"
        : "https://data-api.binance.vision/api/v3/exchangeInfo";
      const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`${exchange} API ${res.status}`);
      const data = (await res.json()) as any;
      for (const sym of data.symbols || []) {
        if (sym.status === "TRADING" && (sym.quoteAsset === "USDT" || sym.quoteAsset === "USD")) {
          info.pairs.set(`${sym.baseAsset}/${sym.quoteAsset}`, sym.symbol);
          info.bases.add(sym.baseAsset);
        }
      }
    } else if (exchange === "coinbase") {
      const res = await fetch("https://api.exchange.coinbase.com/products", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Coinbase API ${res.status}`);
      const data = (await res.json()) as any;
      for (const p of data) {
        if (!p.trading_disabled && (p.quote_currency === "USD" || p.quote_currency === "USDT")) {
          info.pairs.set(`${p.base_currency}/${p.quote_currency}`, p.id);
          info.bases.add(p.base_currency);
        }
      }
    } else if (exchange === "bybit") {
      const res = await fetch("https://api.bybit.com/v5/market/instruments-info?category=spot&limit=1000", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Bybit API ${res.status}`);
      const data = (await res.json()) as any;
      for (const item of data.result?.list || []) {
        if (item.status === "Trading" && (item.quoteCoin === "USDT" || item.quoteCoin === "USD")) {
          info.pairs.set(`${item.baseCoin}/${item.quoteCoin}`, item.symbol);
          info.bases.add(item.baseCoin);
        }
      }
    } else if (exchange === "okx") {
      const res = await fetch("https://www.okx.com/api/v5/public/instruments?instType=SPOT", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`OKX API ${res.status}`);
      const data = (await res.json()) as any;
      for (const inst of data.data || []) {
        if (inst.state === "live" && (inst.quoteCcy === "USDT" || inst.quoteCcy === "USD")) {
          info.pairs.set(`${inst.baseCcy}/${inst.quoteCcy}`, inst.instId);
          info.bases.add(inst.baseCcy);
        }
      }
    } else if (exchange === "kucoin") {
      const res = await fetch("https://api.kucoin.com/api/v1/symbols", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`KuCoin API ${res.status}`);
      const data = (await res.json()) as any;
      for (const sym of data.data || []) {
        if (sym.enableTrading && (sym.quoteCurrency === "USDT" || sym.quoteCurrency === "USD")) {
          info.pairs.set(`${sym.baseCurrency}/${sym.quoteCurrency}`, sym.symbol);
          info.bases.add(sym.baseCurrency);
        }
      }
    } else if (exchange === "gateio" || exchange === "gate") {
      const res = await fetch("https://api.gateio.ws/api/v4/spot/currency_pairs", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Gate.io API ${res.status}`);
      const data = (await res.json()) as any;
      for (const cp of data) {
        if (cp.trade_status === "tradable" && (cp.quote === "USDT" || cp.quote === "USD")) {
          info.pairs.set(`${cp.base}/${cp.quote}`, cp.id);
          info.bases.add(cp.base);
        }
      }
    } else if (exchange === "bitget") {
      const res = await fetch("https://api.bitget.com/api/v2/spot/public/symbols", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Bitget API ${res.status}`);
      const data = (await res.json()) as any;
      for (const sym of data.data || []) {
        if (sym.status === "online" && (sym.quoteCoin === "USDT" || sym.quoteCoin === "USD")) {
          info.pairs.set(`${sym.baseCoin}/${sym.quoteCoin}`, sym.symbol);
          info.bases.add(sym.baseCoin);
        }
      }
    } else if (exchange === "mexc") {
      const res = await fetch("https://api.mexc.com/api/v3/exchangeInfo", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`MEXC API ${res.status}`);
      const data = (await res.json()) as any;
      for (const sym of data.symbols || []) {
        if (sym.status === "ENABLED" && (sym.quoteAsset === "USDT" || sym.quoteAsset === "USD")) {
          info.pairs.set(`${sym.baseAsset}/${sym.quoteAsset}`, sym.symbol);
          info.bases.add(sym.baseAsset);
        }
      }
    } else if (exchange === "htx") {
      const res = await fetch("https://api.huobi.pro/v1/common/symbols", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`HTX API ${res.status}`);
      const data = (await res.json()) as any;
      for (const sym of data.data || []) {
        if (sym.state === "online" && (sym["quote-currency"] === "usdt" || sym["quote-currency"] === "usd")) {
          const base = sym["base-currency"].toUpperCase();
          const quote = sym["quote-currency"].toUpperCase();
          info.pairs.set(`${base}/${quote}`, sym.symbol);
          info.bases.add(base);
        }
      }
    } else if (exchange === "bitfinex") {
      const res = await fetch("https://api-pub.bitfinex.com/v2/conf/pub:list:pair:exchange", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Bitfinex API ${res.status}`);
      const data = (await res.json()) as any;
      for (const pair of data[0] || []) {
        const p = pair.toUpperCase();
        if (p.endsWith("UST") || p.endsWith("USD")) {
          const quote = p.endsWith("UST") ? "USDT" : "USD";
          const base = p.replace(/US[DT]$/, "");
          if (base.length >= 2) {
            info.pairs.set(`${base}/${quote}`, `t${pair}`);
            info.bases.add(base);
          }
        }
      }
    } else if (exchange === "bitstamp") {
      const res = await fetch("https://www.bitstamp.net/api/v2/trading-pairs-info/", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Bitstamp API ${res.status}`);
      const data = (await res.json()) as any;
      for (const tp of data) {
        if (tp.trading === "Enabled") {
          const [base, quote] = tp.name.split("/");
          if (quote === "USD" || quote === "USDT") {
            info.pairs.set(`${base}/${quote}`, tp.url_symbol);
            info.bases.add(base);
          }
        }
      }
    } else if (exchange === "gemini") {
      const res = await fetch("https://api.gemini.com/v1/symbols/details/btcusd", { signal: AbortSignal.timeout(5000) });
      const allRes = await fetch("https://api.gemini.com/v1/symbols", { signal: AbortSignal.timeout(15000) });
      if (allRes.ok) {
        const symbols = (await allRes.json()) as string[];
        for (const sym of symbols) {
          const s = sym.toUpperCase();
          if (s.endsWith("USD") || s.endsWith("USDT")) {
            const quote = s.endsWith("USDT") ? "USDT" : "USD";
            const base = s.replace(/USDT?$/, "");
            if (base.length >= 2) {
              info.pairs.set(`${base}/${quote}`, sym);
              info.bases.add(base);
            }
          }
        }
      }
    } else if (exchange === "cryptocom") {
      const res = await fetch("https://api.crypto.com/exchange/v1/public/get-instruments", { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`Crypto.com API ${res.status}`);
      const data = (await res.json()) as any;
      for (const inst of data.result?.data || []) {
        if (inst.tradable && (inst.quote_currency === "USD" || inst.quote_currency === "USDT")) {
          info.pairs.set(`${inst.base_currency}/${inst.quote_currency}`, inst.symbol);
          info.bases.add(inst.base_currency);
        }
      }
    }
  } catch (err: any) {
    log(`Failed to load ${exchange} pairs: ${err.message}`);
  }

  if (info.bases.size > 0) {
    pairCaches.set(exchange, info);
    log(`${exchange} pair cache loaded: ${info.pairs.size} tradeable pairs, ${info.bases.size} unique assets`);
  }

  return info;
}

export function resolveExchangePairName(pair: string, exchange: string, exchangePairs: Map<string, string>): string | null {
  const direct = exchangePairs.get(pair);
  if (direct) return direct;

  const [base, quote] = pair.split("/");
  if (quote === "USDT") {
    const usdAlt = exchangePairs.get(`${base}/USD`);
    if (usdAlt) return usdAlt;
  }
  if (quote === "USD") {
    const usdtAlt = exchangePairs.get(`${base}/USDT`);
    if (usdtAlt) return usdtAlt;
  }
  return null;
}

export function isPairAvailableOnExchange(pair: string, exchange: string): boolean {
  const cached = pairCaches.get(exchange);
  if (!cached || cached.bases.size === 0) return true;
  const [base] = pair.split("/");
  return cached.bases.has(base);
}

export async function executeOrder(
  exchange: string,
  apiKey: string,
  apiSecret: string,
  pair: string,
  side: "BUY" | "SELL",
  quantity: number,
  passphrase?: string
): Promise<OrderResult> {
  const orderSide = side.toLowerCase();
  const [base, quote] = pair.split("/");

  try {
    if (exchange === "kraken") {
      return await executeKrakenOrderInternal(apiKey, apiSecret, base, quote, pair, orderSide, quantity);
    } else if (exchange === "binance") {
      return await executeBinanceOrder(apiKey, apiSecret, "https://data-api.binance.vision", base, quote, orderSide, quantity);
    } else if (exchange === "binanceus") {
      return await executeBinanceOrder(apiKey, apiSecret, "https://api.binance.us", base, quote, orderSide, quantity);
    } else if (exchange === "coinbase") {
      return await executeCoinbaseOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity);
    } else if (exchange === "bybit") {
      return await executeBybitOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "okx") {
      return await executeOkxOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity);
    } else if (exchange === "kucoin") {
      return await executeKucoinOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity);
    } else if (exchange === "gateio" || exchange === "gate") {
      return await executeGateioOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "bitget") {
      return await executeBitgetOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity);
    } else if (exchange === "mexc") {
      return await executeMexcOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "htx") {
      return await executeHtxOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "bitfinex") {
      return await executeBitfinexOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "bitstamp") {
      return await executeBitstampOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "gemini") {
      return await executeGeminiOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    } else if (exchange === "cryptocom") {
      return await executeCryptocomOrder(apiKey, apiSecret, base, quote, orderSide, quantity);
    }
    return { success: false, error: `Exchange '${exchange}' order execution not implemented` };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

async function executeKrakenOrderInternal(apiKey: string, apiSecret: string, base: string, quote: string, pair: string, side: string, quantity: number): Promise<OrderResult> {
  const krakenBase = ASSET_MAPS.kraken[base] || base;
  let krakenPair = "";

  const cached = pairCaches.get("kraken");
  if (cached && cached.pairs.size > 0) {
    const usdPair = cached.pairs.get(`${base}/USD`);
    const usdtPair = cached.pairs.get(`${base}/USDT`);
    if (quote === "USDT" && usdtPair) krakenPair = usdtPair;
    else if (quote === "USDT" && usdPair) krakenPair = usdPair;
    else if (quote === "USD" && usdPair) krakenPair = usdPair;
    else if (quote === "USD" && usdtPair) krakenPair = usdtPair;
    else if (usdPair) krakenPair = usdPair;
    else if (usdtPair) krakenPair = usdtPair;
  }

  if (!krakenPair) {
    const krakenQuote = quote === "USDT" ? "USDT" : quote === "USD" ? "USD" : quote;
    krakenPair = `${krakenBase}${krakenQuote}`;

    try {
      const validateRes = await fetch(`https://api.kraken.com/0/public/AssetPairs?pair=${krakenPair}`, { signal: AbortSignal.timeout(8000) });
      const validateData = (await validateRes.json()) as any;
      if (validateData.error?.length > 0 || !validateData.result || Object.keys(validateData.result).length === 0) {
        const altQuote = quote === "USDT" ? "USD" : "USDT";
        const altPair = `${krakenBase}${altQuote}`;
        const altRes = await fetch(`https://api.kraken.com/0/public/AssetPairs?pair=${altPair}`, { signal: AbortSignal.timeout(8000) });
        const altData = (await altRes.json()) as any;
        if (!altData.error?.length && altData.result && Object.keys(altData.result).length > 0) {
          krakenPair = altPair;
        } else {
          return { success: false, error: `Pair ${pair} (${krakenPair}) not available on Kraken` };
        }
      }
    } catch {}
  }

  const nonce = krakenNonce();
  const postData = `nonce=${nonce}&ordertype=market&type=${side}&volume=${quantity}&pair=${krakenPair}`;
  const apiPath = "/0/private/AddOrder";
  const signature = signKraken(apiSecret, apiPath, nonce, postData);

  const res = await fetch(`https://api.kraken.com${apiPath}`, {
    method: "POST",
    headers: { "API-Key": apiKey, "API-Sign": signature, "Content-Type": "application/x-www-form-urlencoded" },
    body: postData,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.error && data.error.length > 0) {
    return { success: false, error: data.error.join(", ") };
  }
  return { success: true, orderId: data.result?.txid?.[0] || "unknown" };
}

async function executeBinanceOrder(apiKey: string, apiSecret: string, baseUrl: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now();
  const queryString = `symbol=${symbol}&side=${side.toUpperCase()}&type=MARKET&quantity=${quantity}&timestamp=${timestamp}`;
  const signature = signBinance(apiSecret, queryString);

  const res = await fetch(`${baseUrl}/api/v3/order?${queryString}&signature=${signature}`, {
    method: "POST",
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.orderId) {
    return { success: true, orderId: String(data.orderId) };
  }
  return { success: false, error: data.msg || "Binance order failed" };
}

async function executeCoinbaseOrder(apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const productId = `${base}-${quote}`;
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const method = "POST";
  const path = "/orders";
  const body = JSON.stringify({
    product_id: productId,
    side,
    type: "market",
    size: String(quantity),
  });

  const sigData = timestamp + method + path + body;
  const key = Buffer.from(apiSecret, "base64");
  const signature = crypto.createHmac("sha256", key).update(sigData).digest("base64");

  const res = await fetch(`https://api.exchange.coinbase.com${path}`, {
    method,
    headers: {
      "CB-ACCESS-KEY": apiKey,
      "CB-ACCESS-SIGN": signature,
      "CB-ACCESS-TIMESTAMP": timestamp,
      "CB-ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.id) {
    return { success: true, orderId: data.id };
  }
  return { success: false, error: data.message || "Coinbase order failed" };
}

async function executeBybitOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now().toString();
  const recvWindow = "5000";
  const body = JSON.stringify({
    category: "spot",
    symbol,
    side: side === "buy" ? "Buy" : "Sell",
    orderType: "Market",
    qty: String(quantity),
  });

  const paramStr = `${timestamp}${apiKey}${recvWindow}${body}`;
  const signature = signBybit(apiSecret, paramStr);

  const res = await fetch("https://api.bybit.com/v5/order/create", {
    method: "POST",
    headers: {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-SIGN": signature,
      "X-BAPI-TIMESTAMP": timestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.retCode === 0 && data.result?.orderId) {
    return { success: true, orderId: data.result.orderId };
  }
  return { success: false, error: data.retMsg || "Bybit order failed" };
}

async function executeOkxOrder(apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const instId = `${base}-${quote}`;
  const timestamp = new Date().toISOString();
  const method = "POST";
  const path = "/api/v5/trade/order";
  const body = JSON.stringify({
    instId,
    tdMode: "cash",
    side,
    ordType: "market",
    sz: String(quantity),
  });

  const signature = signOkx(apiSecret, timestamp, method, path, body);

  const res = await fetch(`https://www.okx.com${path}`, {
    method,
    headers: {
      "OK-ACCESS-KEY": apiKey,
      "OK-ACCESS-SIGN": signature,
      "OK-ACCESS-TIMESTAMP": timestamp,
      "OK-ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "0" && data.data?.[0]?.ordId) {
    return { success: true, orderId: data.data[0].ordId };
  }
  return { success: false, error: data.data?.[0]?.sMsg || data.msg || "OKX order failed" };
}

async function executeKucoinOrder(apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base}-${quote}`;
  const timestamp = Date.now().toString();
  const method = "POST";
  const path = "/api/v1/orders";
  const body = JSON.stringify({
    clientOid: `aut_${Date.now()}`,
    side,
    symbol,
    type: "market",
    size: String(quantity),
  });

  const signature = signKucoin(apiSecret, timestamp, method, path, body);
  const passphraseHash = crypto.createHmac("sha256", apiSecret).update(passphrase).digest("base64");

  const res = await fetch(`https://api.kucoin.com${path}`, {
    method,
    headers: {
      "KC-API-KEY": apiKey,
      "KC-API-SIGN": signature,
      "KC-API-TIMESTAMP": timestamp,
      "KC-API-PASSPHRASE": passphraseHash,
      "KC-API-KEY-VERSION": "2",
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "200000" && data.data?.orderId) {
    return { success: true, orderId: data.data.orderId };
  }
  return { success: false, error: data.msg || "KuCoin order failed" };
}

async function executeGateioOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const currencyPair = `${base}_${quote}`;
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const method = "POST";
  const urlPath = "/api/v4/spot/orders";
  const body = JSON.stringify({
    currency_pair: currencyPair,
    side,
    type: "market",
    amount: String(quantity),
    time_in_force: "ioc",
  });

  const bodyHash = crypto.createHash("sha512").update(body).digest("hex");
  const signature = signGateio(apiSecret, method, urlPath, "", bodyHash, timestamp);

  const res = await fetch(`https://api.gateio.ws${urlPath}`, {
    method,
    headers: {
      KEY: apiKey,
      SIGN: signature,
      Timestamp: timestamp,
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.id) {
    return { success: true, orderId: String(data.id) };
  }
  return { success: false, error: data.message || data.label || "Gate.io order failed" };
}

async function executeBitgetOrder(apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now().toString();
  const method = "POST";
  const path = "/api/v2/spot/trade/place-order";
  const body = JSON.stringify({
    symbol,
    side,
    orderType: "market",
    size: String(quantity),
    force: "gtc",
  });

  const signature = signBitget(apiSecret, timestamp, method, path, body);

  const res = await fetch(`https://api.bitget.com${path}`, {
    method,
    headers: {
      "ACCESS-KEY": apiKey,
      "ACCESS-SIGN": signature,
      "ACCESS-TIMESTAMP": timestamp,
      "ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
      locale: "en-US",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "00000" && data.data?.orderId) {
    return { success: true, orderId: data.data.orderId };
  }
  return { success: false, error: data.msg || "Bitget order failed" };
}

async function executeMexcOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now();
  const queryString = `symbol=${symbol}&side=${side.toUpperCase()}&type=MARKET&quantity=${quantity}&timestamp=${timestamp}`;
  const signature = signBinance(apiSecret, queryString);

  const res = await fetch(`https://api.mexc.com/api/v3/order?${queryString}&signature=${signature}`, {
    method: "POST",
    headers: { "X-MEXC-APIKEY": apiKey },
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.orderId) {
    return { success: true, orderId: String(data.orderId) };
  }
  return { success: false, error: data.msg || "MEXC order failed" };
}

async function executeHtxOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base.toLowerCase()}${quote.toLowerCase()}`;
  const timestamp = new Date().toISOString().replace(/\.\d{3}Z/, "");
  const method = "POST";
  const host = "api.huobi.pro";
  const path = "/v1/order/orders/place";

  const params = new URLSearchParams({
    AccessKeyId: apiKey,
    SignatureMethod: "HmacSHA256",
    SignatureVersion: "2",
    Timestamp: timestamp,
  });
  params.sort();

  const sigPayload = `${method}\n${host}\n${path}\n${params.toString()}`;
  const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("base64");
  params.append("Signature", signature);

  let accountId = "0";
  try {
    const acctRes = await fetch(`https://${host}/v1/account/accounts?${params.toString()}`, { signal: AbortSignal.timeout(8000) });
    const acctData = (await acctRes.json()) as any;
    accountId = acctData.data?.[0]?.id?.toString() || "0";
  } catch {}

  const body = JSON.stringify({
    "account-id": accountId,
    symbol,
    type: `${side}-market`,
    amount: String(quantity),
  });

  const res = await fetch(`https://${host}${path}?${params.toString()}&Signature=${encodeURIComponent(signature)}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.status === "ok" && data.data) {
    return { success: true, orderId: String(data.data) };
  }
  return { success: false, error: data["err-msg"] || "HTX order failed" };
}

async function executeBitfinexOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `t${base}${quote}`;
  const nonce = (Date.now() * 1000).toString();
  const path = "/v2/auth/w/order/submit";
  const body = JSON.stringify({
    type: "EXCHANGE MARKET",
    symbol,
    amount: side === "buy" ? String(quantity) : String(-quantity),
  });

  const sigPayload = `/api${path}${nonce}${body}`;
  const signature = crypto.createHmac("sha384", apiSecret).update(sigPayload).digest("hex");

  const res = await fetch(`https://api.bitfinex.com${path}`, {
    method: "POST",
    headers: {
      "bfx-nonce": nonce,
      "bfx-apikey": apiKey,
      "bfx-signature": signature,
      "Content-Type": "application/json",
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (Array.isArray(data) && data[6] === "SUCCESS") {
    return { success: true, orderId: String(data[4]?.[0]?.[0] || "unknown") };
  }
  return { success: false, error: data[2] || (Array.isArray(data) ? data.join(", ") : "Bitfinex order failed") };
}

async function executeBitstampOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const pairSymbol = `${base.toLowerCase()}${quote.toLowerCase()}`;
  const nonce = crypto.randomUUID();
  const timestamp = Date.now().toString();
  const contentType = "application/x-www-form-urlencoded";
  const version = "v2";
  const body = `amount=${quantity}`;

  const sigPayload = `BITSTAMP ${apiKey}POST www.bitstamp.net/api/${version}/${side}/market/${pairSymbol}/${contentType}${nonce}${timestamp}v2${body}`;
  const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("hex");

  const res = await fetch(`https://www.bitstamp.net/api/${version}/${side}/market/${pairSymbol}/`, {
    method: "POST",
    headers: {
      "X-Auth": `BITSTAMP ${apiKey}`,
      "X-Auth-Signature": signature,
      "X-Auth-Nonce": nonce,
      "X-Auth-Timestamp": timestamp,
      "X-Auth-Version": "v2",
      "Content-Type": contentType,
    },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.id) {
    return { success: true, orderId: String(data.id) };
  }
  return { success: false, error: data.reason?.__all__?.[0] || data.error || "Bitstamp order failed" };
}

async function executeGeminiOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const symbol = `${base.toLowerCase()}${quote.toLowerCase()}`;
  const nonce = Date.now();
  const path = "/v1/order/new";
  const payload = {
    request: path,
    nonce,
    symbol,
    amount: String(quantity),
    side,
    type: "exchange market",
  };

  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString("base64");
  const signature = crypto.createHmac("sha384", apiSecret).update(encodedPayload).digest("hex");

  const res = await fetch(`https://api.gemini.com${path}`, {
    method: "POST",
    headers: {
      "X-GEMINI-APIKEY": apiKey,
      "X-GEMINI-PAYLOAD": encodedPayload,
      "X-GEMINI-SIGNATURE": signature,
      "Content-Type": "text/plain",
    },
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.order_id) {
    return { success: true, orderId: data.order_id };
  }
  return { success: false, error: data.message || data.reason || "Gemini order failed" };
}

async function executeCryptocomOrder(apiKey: string, apiSecret: string, base: string, quote: string, side: string, quantity: number): Promise<OrderResult> {
  const instrumentName = `${base}_${quote}`;
  const nonce = Date.now();
  const id = nonce;
  const method = "private/create-order";
  const params: Record<string, any> = {
    instrument_name: instrumentName,
    side: side.toUpperCase(),
    type: "MARKET",
    quantity: String(quantity),
  };

  const paramKeys = Object.keys(params).sort();
  let sigPayload = method + String(id);
  for (const key of paramKeys) {
    sigPayload += key + params[key];
  }
  sigPayload += String(nonce);
  const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("hex");

  const body = JSON.stringify({
    id,
    method,
    params,
    nonce,
    sig: signature,
    api_key: apiKey,
  });

  const res = await fetch("https://api.crypto.com/exchange/v1/private/create-order", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === 0 && data.result?.order_id) {
    return { success: true, orderId: data.result.order_id };
  }
  return { success: false, error: data.message || "Crypto.com order failed" };
}

export async function fetchExchangeBalance(
  exchange: string,
  apiKey: string,
  apiSecret: string,
  passphrase?: string
): Promise<ExchangeBalance> {
  const defaultResult: ExchangeBalance = { total: 0, available: 0, currency: "USD" };

  try {
    if (exchange === "kraken") {
      const nonce = krakenNonce();
      const path = "/0/private/TradeBalance";
      const body = `nonce=${nonce}&asset=ZUSD`;
      const signature = signKraken(apiSecret, path, nonce, body);

      const res = await fetch("https://api.kraken.com" + path, {
        method: "POST",
        headers: { "API-Key": apiKey, "API-Sign": signature, "Content-Type": "application/x-www-form-urlencoded" },
        body,
        signal: AbortSignal.timeout(8000),
      });
      const data = (await res.json()) as any;
      if (data.error && data.error.length > 0) {
        log(`Kraken balance error: ${data.error.join(", ")}`);
      }
      if (data.result?.eb) {
        const total = parseFloat(data.result.eb);
        const free = parseFloat(data.result.mf || data.result.eb);
        return { total, available: free, currency: "USD" };
      }
      if (data.result) {
        const tb = parseFloat(data.result.tb || "0");
        const e = parseFloat(data.result.e || "0");
        if (tb > 0 || e > 0) {
          return { total: e || tb, available: e || tb, currency: "USD" };
        }
      }
    } else if (exchange === "kraken_assets") {
      const nonce = krakenNonce();
      const path = "/0/private/Balance";
      const body = `nonce=${nonce}`;
      const signature = signKraken(apiSecret, path, nonce, body);

      const res = await fetch("https://api.kraken.com" + path, {
        method: "POST",
        headers: { "API-Key": apiKey, "API-Sign": signature, "Content-Type": "application/x-www-form-urlencoded" },
        body,
        signal: AbortSignal.timeout(8000),
      });
      const data = (await res.json()) as any;
      if (data.result) {
        const assets: Record<string, number> = {};
        for (const [asset, balance] of Object.entries(data.result)) {
          const bal = parseFloat(balance as string);
          if (bal > 0.000001) assets[asset] = bal;
        }
        return { total: 0, available: 0, currency: "USD", assets } as any;
      }
    } else if (exchange === "binance" || exchange === "binanceus") {
      const timestamp = Date.now();
      const queryString = `timestamp=${timestamp}`;
      const signature = signBinance(apiSecret, queryString);
      const baseUrl = exchange === "binanceus" ? "https://api.binance.us" : "https://api.binance.com";

      const res = await fetch(`${baseUrl}/api/v3/account?${queryString}&signature=${signature}`, {
        headers: { "X-MBX-APIKEY": apiKey },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdtBal = data.balances?.find((b: any) => b.asset === "USDT");
        if (usdtBal) {
          const free = parseFloat(usdtBal.free);
          const locked = parseFloat(usdtBal.locked || "0");
          return { total: free + locked, available: free, currency: "USDT" };
        }
      }
    } else if (exchange === "bybit") {
      const timestamp = Date.now().toString();
      const recvWindow = "5000";
      const paramStr = `${timestamp}${apiKey}${recvWindow}`;
      const signature = signBybit(apiSecret, paramStr);

      const res = await fetch("https://api.bybit.com/v5/account/wallet-balance?accountType=UNIFIED", {
        headers: { "X-BAPI-API-KEY": apiKey, "X-BAPI-SIGN": signature, "X-BAPI-TIMESTAMP": timestamp, "X-BAPI-RECV-WINDOW": recvWindow },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const equity = parseFloat(data.result?.list?.[0]?.totalEquity || "0");
        const available = parseFloat(data.result?.list?.[0]?.totalAvailableBalance || data.result?.list?.[0]?.totalEquity || "0");
        return { total: equity, available, currency: "USD" };
      }
    } else if (exchange === "coinbase") {
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const method = "GET";
      const path = "/accounts";
      const sigData = timestamp + method + path;
      const key = Buffer.from(apiSecret, "base64");
      const signature = crypto.createHmac("sha256", key).update(sigData).digest("base64");

      const res = await fetch(`https://api.exchange.coinbase.com${path}`, {
        headers: {
          "CB-ACCESS-KEY": apiKey,
          "CB-ACCESS-SIGN": signature,
          "CB-ACCESS-TIMESTAMP": timestamp,
          "CB-ACCESS-PASSPHRASE": passphrase || "",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdAccount = data.find?.((a: any) => a.currency === "USD" || a.currency === "USDT");
        if (usdAccount) {
          return { total: parseFloat(usdAccount.balance), available: parseFloat(usdAccount.available), currency: usdAccount.currency };
        }
      }
    } else if (exchange === "okx") {
      const timestamp = new Date().toISOString();
      const method = "GET";
      const path = "/api/v5/account/balance";
      const signature = signOkx(apiSecret, timestamp, method, path);

      const res = await fetch(`https://www.okx.com${path}`, {
        headers: {
          "OK-ACCESS-KEY": apiKey,
          "OK-ACCESS-SIGN": signature,
          "OK-ACCESS-TIMESTAMP": timestamp,
          "OK-ACCESS-PASSPHRASE": passphrase || "",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const totalEq = parseFloat(data.data?.[0]?.totalEq || "0");
        return { total: totalEq, available: totalEq, currency: "USD" };
      }
    } else if (exchange === "kucoin") {
      const timestamp = Date.now().toString();
      const method = "GET";
      const path = "/api/v1/accounts?currency=USDT&type=trade";
      const signature = signKucoin(apiSecret, timestamp, method, path);
      const passphraseHash = crypto.createHmac("sha256", apiSecret).update(passphrase || "").digest("base64");

      const res = await fetch(`https://api.kucoin.com${path}`, {
        headers: {
          "KC-API-KEY": apiKey,
          "KC-API-SIGN": signature,
          "KC-API-TIMESTAMP": timestamp,
          "KC-API-PASSPHRASE": passphraseHash,
          "KC-API-KEY-VERSION": "2",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const acct = data.data?.[0];
        if (acct) {
          return { total: parseFloat(acct.balance), available: parseFloat(acct.available), currency: "USDT" };
        }
      }
    } else if (exchange === "gateio" || exchange === "gate") {
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const method = "GET";
      const urlPath = "/api/v4/spot/accounts";
      const bodyHash = crypto.createHash("sha512").update("").digest("hex");
      const signature = signGateio(apiSecret, method, urlPath, "", bodyHash, timestamp);

      const res = await fetch(`https://api.gateio.ws${urlPath}`, {
        headers: { KEY: apiKey, SIGN: signature, Timestamp: timestamp },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdtAcct = data.find?.((a: any) => a.currency === "USDT");
        if (usdtAcct) {
          const avail = parseFloat(usdtAcct.available || "0");
          const locked = parseFloat(usdtAcct.locked || "0");
          return { total: avail + locked, available: avail, currency: "USDT" };
        }
      }
    } else if (exchange === "bitget") {
      const timestamp = Date.now().toString();
      const method = "GET";
      const path = "/api/v2/spot/account/assets";
      const signature = signBitget(apiSecret, timestamp, method, path);

      const res = await fetch(`https://api.bitget.com${path}`, {
        headers: {
          "ACCESS-KEY": apiKey,
          "ACCESS-SIGN": signature,
          "ACCESS-TIMESTAMP": timestamp,
          "ACCESS-PASSPHRASE": passphrase || "",
          locale: "en-US",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdtAsset = (data.data || []).find((a: any) => a.coin === "USDT");
        if (usdtAsset) {
          const avail = parseFloat(usdtAsset.available || "0");
          const frozen = parseFloat(usdtAsset.frozen || "0");
          return { total: avail + frozen, available: avail, currency: "USDT" };
        }
      }
    } else if (exchange === "mexc") {
      const timestamp = Date.now();
      const queryString = `timestamp=${timestamp}`;
      const signature = signBinance(apiSecret, queryString);

      const res = await fetch(`https://api.mexc.com/api/v3/account?${queryString}&signature=${signature}`, {
        headers: { "X-MEXC-APIKEY": apiKey },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdtBal = data.balances?.find((b: any) => b.asset === "USDT");
        if (usdtBal) {
          const free = parseFloat(usdtBal.free || "0");
          const locked = parseFloat(usdtBal.locked || "0");
          return { total: free + locked, available: free, currency: "USDT" };
        }
      }
    } else if (exchange === "htx") {
      const timestamp = new Date().toISOString().replace(/\.\d{3}Z/, "");
      const host = "api.huobi.pro";
      const path = "/v1/account/accounts";
      const params = new URLSearchParams({
        AccessKeyId: apiKey,
        SignatureMethod: "HmacSHA256",
        SignatureVersion: "2",
        Timestamp: timestamp,
      });
      params.sort();
      const sigPayload = `GET\n${host}\n${path}\n${params.toString()}`;
      const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("base64");
      params.append("Signature", signature);

      const acctRes = await fetch(`https://${host}${path}?${params.toString()}`, { signal: AbortSignal.timeout(8000) });
      if (acctRes.ok) {
        const acctData = (await acctRes.json()) as any;
        const accountId = acctData.data?.[0]?.id;
        if (accountId) {
          const balPath = `/v1/account/accounts/${accountId}/balance`;
          const balParams = new URLSearchParams({
            AccessKeyId: apiKey,
            SignatureMethod: "HmacSHA256",
            SignatureVersion: "2",
            Timestamp: new Date().toISOString().replace(/\.\d{3}Z/, ""),
          });
          balParams.sort();
          const balSigPayload = `GET\n${host}\n${balPath}\n${balParams.toString()}`;
          const balSig = crypto.createHmac("sha256", apiSecret).update(balSigPayload).digest("base64");
          balParams.append("Signature", balSig);

          const balRes = await fetch(`https://${host}${balPath}?${balParams.toString()}`, { signal: AbortSignal.timeout(8000) });
          if (balRes.ok) {
            const balData = (await balRes.json()) as any;
            const usdtTrade = (balData.data?.list || []).find((b: any) => b.currency === "usdt" && b.type === "trade");
            if (usdtTrade) {
              return { total: parseFloat(usdtTrade.balance), available: parseFloat(usdtTrade.balance), currency: "USDT" };
            }
          }
        }
      }
    } else if (exchange === "bitfinex") {
      const nonce = (Date.now() * 1000).toString();
      const path = "/v2/auth/r/wallets";
      const body = "{}";
      const sigPayload = `/api${path}${nonce}${body}`;
      const signature = crypto.createHmac("sha384", apiSecret).update(sigPayload).digest("hex");

      const res = await fetch(`https://api.bitfinex.com${path}`, {
        method: "POST",
        headers: {
          "bfx-nonce": nonce,
          "bfx-apikey": apiKey,
          "bfx-signature": signature,
          "Content-Type": "application/json",
        },
        body,
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdWallet = data.find?.((w: any[]) => w[0] === "exchange" && (w[1] === "UST" || w[1] === "USD"));
        if (usdWallet) {
          return { total: usdWallet[2], available: usdWallet[4] || usdWallet[2], currency: usdWallet[1] === "UST" ? "USDT" : "USD" };
        }
      }
    } else if (exchange === "gemini") {
      const nonce = Date.now();
      const path = "/v1/balances";
      const payload = { request: path, nonce };
      const encodedPayload = Buffer.from(JSON.stringify(payload)).toString("base64");
      const signature = crypto.createHmac("sha384", apiSecret).update(encodedPayload).digest("hex");

      const res = await fetch(`https://api.gemini.com${path}`, {
        method: "POST",
        headers: {
          "X-GEMINI-APIKEY": apiKey,
          "X-GEMINI-PAYLOAD": encodedPayload,
          "X-GEMINI-SIGNATURE": signature,
          "Content-Type": "text/plain",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdBal = data.find?.((b: any) => b.currency === "USD" || b.currency === "USDT");
        if (usdBal) {
          return { total: parseFloat(usdBal.amount), available: parseFloat(usdBal.available), currency: usdBal.currency };
        }
      }
    } else if (exchange === "bitstamp") {
      const nonce = crypto.randomUUID();
      const timestamp = Date.now().toString();
      const version = "v2";
      const contentType = "";
      const path = `/api/${version}/balance/`;

      const sigPayload = `BITSTAMP ${apiKey}POST www.bitstamp.net${path}${contentType}${nonce}${timestamp}v2`;
      const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("hex");

      const res = await fetch(`https://www.bitstamp.net${path}`, {
        method: "POST",
        headers: {
          "X-Auth": `BITSTAMP ${apiKey}`,
          "X-Auth-Signature": signature,
          "X-Auth-Nonce": nonce,
          "X-Auth-Timestamp": timestamp,
          "X-Auth-Version": "v2",
        },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdBal = parseFloat(data.usd_balance || data.usdt_balance || "0");
        const usdAvail = parseFloat(data.usd_available || data.usdt_available || "0");
        return { total: usdBal, available: usdAvail, currency: "USD" };
      }
    } else if (exchange === "cryptocom") {
      const nonce = Date.now();
      const id = nonce;
      const method = "private/get-account-summary";
      const params: Record<string, any> = {};
      const paramKeys = Object.keys(params).sort();
      let sigPayload = method + String(id);
      for (const key of paramKeys) {
        sigPayload += key + params[key];
      }
      sigPayload += String(nonce);
      const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("hex");

      const res = await fetch("https://api.crypto.com/exchange/v1/private/get-account-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, method, params, nonce, sig: signature, api_key: apiKey }),
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = (await res.json()) as any;
        const usdtAcct = (data.result?.data || []).find((a: any) => a.currency === "USDT" || a.currency === "USD");
        if (usdtAcct) {
          return { total: parseFloat(usdtAcct.balance || "0"), available: parseFloat(usdtAcct.available || "0"), currency: usdtAcct.currency };
        }
      }
    }
  } catch (err: any) {
    log(`Balance fetch failed for ${exchange}: ${err.message}`);
  }

  return defaultResult;
}

export function getExchangePairCache(exchange: string): ExchangePairInfo | undefined {
  return pairCaches.get(exchange);
}

export function clearPairCache(exchange: string): void {
  pairCaches.delete(exchange);
}

export const SUPPORTED_EXCHANGES = [
  "kraken", "binance", "binanceus", "coinbase", "bybit", "okx",
  "kucoin", "gateio", "bitget", "mexc", "htx", "bitfinex",
  "bitstamp", "gemini", "cryptocom"
];

export const FUTURES_SUPPORTED_EXCHANGES = [
  "binance", "bybit", "okx", "bitget", "kucoin", "gateio", "mexc", "htx"
];

export interface FuturesOrderParams {
  exchange: string;
  apiKey: string;
  apiSecret: string;
  pair: string;
  side: "LONG" | "SHORT";
  quantity: number;
  leverage: number;
  marginMode: "cross" | "isolated";
  orderType: "market" | "limit";
  price?: number;
  passphrase?: string;
  reduceOnly?: boolean;
}

export interface FuturesPosition {
  symbol: string;
  side: "long" | "short";
  size: number;
  entryPrice: number;
  markPrice: number;
  unrealizedPnl: number;
  leverage: number;
  marginMode: string;
  liquidationPrice: number;
}

export interface FuturesOrderResult {
  success: boolean;
  orderId?: string;
  error?: string;
}

export async function executeFuturesOrder(params: FuturesOrderParams): Promise<FuturesOrderResult> {
  const { exchange, apiKey, apiSecret, pair, side, quantity, leverage, marginMode, orderType, price, passphrase, reduceOnly } = params;
  const [base, quote] = pair.split("/");
  const orderSide = side === "LONG" ? "buy" : "sell";

  try {
    if (exchange === "binance") {
      return await executeBinanceFuturesOrder(apiKey, apiSecret, base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "bybit") {
      return await executeBybitFuturesOrder(apiKey, apiSecret, base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "okx") {
      return await executeOkxFuturesOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "bitget") {
      return await executeBitgetFuturesOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "kucoin") {
      return await executeKucoinFuturesOrder(apiKey, apiSecret, passphrase || "", base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "gateio" || exchange === "gate") {
      return await executeGateioFuturesOrder(apiKey, apiSecret, base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    } else if (exchange === "mexc") {
      return await executeMexcFuturesOrder(apiKey, apiSecret, base, quote, orderSide, quantity, leverage, orderType, price, reduceOnly);
    } else if (exchange === "htx") {
      return await executeHtxFuturesOrder(apiKey, apiSecret, base, quote, orderSide, quantity, leverage, marginMode, orderType, price, reduceOnly);
    }
    return { success: false, error: `Exchange '${exchange}' does not support futures trading` };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

async function executeBinanceFuturesOrder(
  apiKey: string, apiSecret: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const symbol = `${base}${quote}`;
  const baseUrl = "https://fapi.binance.com";

  const levTs = Date.now();
  const levQs = `symbol=${symbol}&leverage=${leverage}&timestamp=${levTs}`;
  const levSig = signBinance(apiSecret, levQs);
  await fetch(`${baseUrl}/fapi/v1/leverage?${levQs}&signature=${levSig}`, {
    method: "POST",
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(10000),
  });

  const mrgTs = Date.now();
  const mrgType = marginMode === "isolated" ? "TRUE" : "FALSE";
  const mrgQs = `symbol=${symbol}&marginType=${marginMode.toUpperCase()}&timestamp=${mrgTs}`;
  const mrgSig = signBinance(apiSecret, mrgQs);
  await fetch(`${baseUrl}/fapi/v1/marginType?${mrgQs}&signature=${mrgSig}`, {
    method: "POST",
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(10000),
  }).catch(() => {});

  const timestamp = Date.now();
  let qs = `symbol=${symbol}&side=${side.toUpperCase()}&type=${orderType.toUpperCase()}&quantity=${quantity}&timestamp=${timestamp}`;
  if (reduceOnly) qs += `&reduceOnly=true`;
  if (orderType === "limit" && price) {
    qs += `&price=${price}&timeInForce=GTC`;
  }
  const signature = signBinance(apiSecret, qs);

  const res = await fetch(`${baseUrl}/fapi/v1/order?${qs}&signature=${signature}`, {
    method: "POST",
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.orderId) {
    return { success: true, orderId: String(data.orderId) };
  }
  return { success: false, error: data.msg || "Binance futures order failed" };
}

async function executeBybitFuturesOrder(
  apiKey: string, apiSecret: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now().toString();
  const recvWindow = "5000";

  const levBody = JSON.stringify({
    category: "linear",
    symbol,
    buyLeverage: String(leverage),
    sellLeverage: String(leverage),
  });
  const levParamStr = `${timestamp}${apiKey}${recvWindow}${levBody}`;
  const levSig = signBybit(apiSecret, levParamStr);
  await fetch("https://api.bybit.com/v5/position/set-leverage", {
    method: "POST",
    headers: {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-SIGN": levSig,
      "X-BAPI-TIMESTAMP": timestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "Content-Type": "application/json",
    },
    body: levBody,
    signal: AbortSignal.timeout(10000),
  }).catch(() => {});

  const orderTs = Date.now().toString();
  const orderBody: any = {
    category: "linear",
    symbol,
    side: side === "buy" ? "Buy" : "Sell",
    orderType: orderType === "market" ? "Market" : "Limit",
    qty: String(quantity),
  };
  if (reduceOnly) orderBody.reduceOnly = true;
  if (orderType === "limit" && price) orderBody.price = String(price);

  const bodyStr = JSON.stringify(orderBody);
  const paramStr = `${orderTs}${apiKey}${recvWindow}${bodyStr}`;
  const signature = signBybit(apiSecret, paramStr);

  const res = await fetch("https://api.bybit.com/v5/order/create", {
    method: "POST",
    headers: {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-SIGN": signature,
      "X-BAPI-TIMESTAMP": orderTs,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "Content-Type": "application/json",
    },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.retCode === 0 && data.result?.orderId) {
    return { success: true, orderId: data.result.orderId };
  }
  return { success: false, error: data.retMsg || "Bybit futures order failed" };
}

async function executeOkxFuturesOrder(
  apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const instId = `${base}-${quote}-SWAP`;
  const baseUrl = "https://www.okx.com";

  const levTs = new Date().toISOString();
  const levPath = "/api/v5/account/set-leverage";
  const levBody = JSON.stringify({
    instId,
    lever: String(leverage),
    mgnMode: marginMode,
  });
  const levSig = signOkx(apiSecret, levTs, "POST", levPath, levBody);
  await fetch(`${baseUrl}${levPath}`, {
    method: "POST",
    headers: {
      "OK-ACCESS-KEY": apiKey,
      "OK-ACCESS-SIGN": levSig,
      "OK-ACCESS-TIMESTAMP": levTs,
      "OK-ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body: levBody,
    signal: AbortSignal.timeout(10000),
  }).catch(() => {});

  const timestamp = new Date().toISOString();
  const path = "/api/v5/trade/order";
  const body: any = {
    instId,
    tdMode: marginMode,
    side,
    ordType: orderType === "market" ? "market" : "limit",
    sz: String(quantity),
  };
  if (reduceOnly) body.reduceOnly = true;
  if (orderType === "limit" && price) body.px = String(price);

  const bodyStr = JSON.stringify(body);
  const signature = signOkx(apiSecret, timestamp, "POST", path, bodyStr);

  const res = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: {
      "OK-ACCESS-KEY": apiKey,
      "OK-ACCESS-SIGN": signature,
      "OK-ACCESS-TIMESTAMP": timestamp,
      "OK-ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "0" && data.data?.[0]?.ordId) {
    return { success: true, orderId: data.data[0].ordId };
  }
  return { success: false, error: data.data?.[0]?.sMsg || data.msg || "OKX futures order failed" };
}

async function executeBitgetFuturesOrder(
  apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const symbol = `${base}${quote}`;
  const baseUrl = "https://api.bitget.com";

  const levTs = Date.now().toString();
  const levPath = "/api/v2/mix/account/set-leverage";
  const levBody = JSON.stringify({
    symbol,
    productType: "USDT-FUTURES",
    marginCoin: "USDT",
    leverage: String(leverage),
  });
  const levSig = signBitget(apiSecret, levTs, "POST", levPath, levBody);
  await fetch(`${baseUrl}${levPath}`, {
    method: "POST",
    headers: {
      "ACCESS-KEY": apiKey,
      "ACCESS-SIGN": levSig,
      "ACCESS-TIMESTAMP": levTs,
      "ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body: levBody,
    signal: AbortSignal.timeout(10000),
  }).catch(() => {});

  const timestamp = Date.now().toString();
  const path = "/api/v2/mix/order/place-order";
  const body: any = {
    symbol,
    productType: "USDT-FUTURES",
    marginMode,
    marginCoin: "USDT",
    side: side === "buy" ? "buy" : "sell",
    tradeSide: side === "buy" ? "open" : "open",
    orderType: orderType === "market" ? "market" : "limit",
    size: String(quantity),
  };
  if (reduceOnly) body.tradeSide = "close";
  if (orderType === "limit" && price) body.price = String(price);

  const bodyStr = JSON.stringify(body);
  const sig = signBitget(apiSecret, timestamp, "POST", path, bodyStr);

  const res = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: {
      "ACCESS-KEY": apiKey,
      "ACCESS-SIGN": sig,
      "ACCESS-TIMESTAMP": timestamp,
      "ACCESS-PASSPHRASE": passphrase,
      "Content-Type": "application/json",
    },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "00000" && data.data?.orderId) {
    return { success: true, orderId: data.data.orderId };
  }
  return { success: false, error: data.msg || "Bitget futures order failed" };
}

async function executeKucoinFuturesOrder(
  apiKey: string, apiSecret: string, passphrase: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const symbol = `${base}${quote}M`;
  const timestamp = Date.now().toString();
  const path = "/api/v1/orders";
  const body: any = {
    clientOid: `alpha_${Date.now()}`,
    symbol,
    side,
    type: orderType,
    leverage: String(leverage),
    size: quantity,
  };
  if (reduceOnly) body.reduceOnly = true;
  if (orderType === "limit" && price) body.price = String(price);

  const bodyStr = JSON.stringify(body);
  const sig = signKucoin(apiSecret, timestamp, "POST", path, bodyStr);

  const res = await fetch(`https://api-futures.kucoin.com${path}`, {
    method: "POST",
    headers: {
      "KC-API-KEY": apiKey,
      "KC-API-SIGN": sig,
      "KC-API-TIMESTAMP": timestamp,
      "KC-API-PASSPHRASE": passphrase,
      "KC-API-KEY-VERSION": "2",
      "Content-Type": "application/json",
    },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.code === "200000" && data.data?.orderId) {
    return { success: true, orderId: data.data.orderId };
  }
  return { success: false, error: data.msg || "KuCoin futures order failed" };
}

async function executeGateioFuturesOrder(
  apiKey: string, apiSecret: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const contract = `${base}_${quote}`;
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const path = "/api/v4/futures/usdt/orders";
  const body: any = {
    contract,
    size: side === "buy" ? quantity : -quantity,
    price: orderType === "limit" && price ? String(price) : "0",
    tif: orderType === "market" ? "ioc" : "gtc",
  };
  if (reduceOnly) body.reduce_only = true;

  const bodyStr = JSON.stringify(body);
  const hashedBody = crypto.createHash("sha512").update(bodyStr).digest("hex");
  const sig = signGateio(apiSecret, "POST", path, "", hashedBody, timestamp);

  const res = await fetch(`https://api.gateio.ws${path}`, {
    method: "POST",
    headers: {
      KEY: apiKey,
      SIGN: sig,
      Timestamp: timestamp,
      "Content-Type": "application/json",
    },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.id) {
    return { success: true, orderId: String(data.id) };
  }
  return { success: false, error: data.message || "Gate.io futures order failed" };
}

async function executeMexcFuturesOrder(
  apiKey: string, apiSecret: string, base: string, quote: string,
  side: string, quantity: number, leverage: number,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const symbol = `${base}${quote}`;
  const timestamp = Date.now();
  let qs = `symbol=${symbol}&side=${side.toUpperCase()}&type=${orderType.toUpperCase()}&quantity=${quantity}&leverage=${leverage}&timestamp=${timestamp}`;
  if (reduceOnly) qs += `&reduceOnly=true`;
  if (orderType === "limit" && price) qs += `&price=${price}&timeInForce=GTC`;
  const signature = signBinance(apiSecret, qs);

  const res = await fetch(`https://contract.mexc.com/api/v1/private/order/submit?${qs}&signature=${signature}`, {
    method: "POST",
    headers: { "ApiKey": apiKey, "Content-Type": "application/json" },
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.success && data.data) {
    return { success: true, orderId: String(data.data) };
  }
  return { success: false, error: data.message || "MEXC futures order failed" };
}

async function executeHtxFuturesOrder(
  apiKey: string, apiSecret: string, base: string, quote: string,
  side: string, quantity: number, leverage: number, marginMode: string,
  orderType: string, price?: number, reduceOnly?: boolean
): Promise<FuturesOrderResult> {
  const contractCode = `${base}-${quote}`;
  const timestamp = new Date().toISOString().replace(/\.\d{3}Z$/, "");
  const method = "POST";
  const path = "/linear-swap-api/v1/swap_cross_order";

  const body: any = {
    contract_code: contractCode,
    volume: quantity,
    direction: side === "buy" ? "buy" : "sell",
    offset: reduceOnly ? "close" : "open",
    lever_rate: leverage,
    order_price_type: orderType === "market" ? "opponent" : "limit",
  };
  if (orderType === "limit" && price) body.price = price;

  const bodyStr = JSON.stringify(body);
  const sigParams = `AccessKeyId=${apiKey}&SignatureMethod=HmacSHA256&SignatureVersion=2&Timestamp=${encodeURIComponent(timestamp)}`;
  const sigPayload = `${method}\napi.hbdm.com\n${path}\n${sigParams}`;
  const signature = crypto.createHmac("sha256", apiSecret).update(sigPayload).digest("base64");

  const res = await fetch(`https://api.hbdm.com${path}?${sigParams}&Signature=${encodeURIComponent(signature)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: bodyStr,
    signal: AbortSignal.timeout(15000),
  });

  const data = (await res.json()) as any;
  if (data.status === "ok" && data.data?.order_id) {
    return { success: true, orderId: String(data.data.order_id) };
  }
  return { success: false, error: data.err_msg || "HTX futures order failed" };
}

export async function getFuturesPositions(
  exchange: string, apiKey: string, apiSecret: string, passphrase?: string
): Promise<FuturesPosition[]> {
  try {
    if (exchange === "binance") {
      const timestamp = Date.now();
      const qs = `timestamp=${timestamp}`;
      const signature = signBinance(apiSecret, qs);
      const res = await fetch(`https://fapi.binance.com/fapi/v2/positionRisk?${qs}&signature=${signature}`, {
        headers: { "X-MBX-APIKEY": apiKey },
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any[];
      return (data || [])
        .filter((p: any) => parseFloat(p.positionAmt) !== 0)
        .map((p: any) => ({
          symbol: p.symbol,
          side: parseFloat(p.positionAmt) > 0 ? "long" as const : "short" as const,
          size: Math.abs(parseFloat(p.positionAmt)),
          entryPrice: parseFloat(p.entryPrice),
          markPrice: parseFloat(p.markPrice),
          unrealizedPnl: parseFloat(p.unRealizedProfit),
          leverage: parseInt(p.leverage),
          marginMode: p.marginType?.toLowerCase() || "cross",
          liquidationPrice: parseFloat(p.liquidationPrice),
        }));
    } else if (exchange === "bybit") {
      const timestamp = Date.now().toString();
      const recvWindow = "5000";
      const paramStr = `${timestamp}${apiKey}${recvWindow}category=linear&settleCoin=USDT`;
      const signature = signBybit(apiSecret, paramStr);
      const res = await fetch(`https://api.bybit.com/v5/position/list?category=linear&settleCoin=USDT`, {
        headers: {
          "X-BAPI-API-KEY": apiKey,
          "X-BAPI-SIGN": signature,
          "X-BAPI-TIMESTAMP": timestamp,
          "X-BAPI-RECV-WINDOW": recvWindow,
        },
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      return (data.result?.list || [])
        .filter((p: any) => parseFloat(p.size) > 0)
        .map((p: any) => ({
          symbol: p.symbol,
          side: p.side === "Buy" ? "long" as const : "short" as const,
          size: parseFloat(p.size),
          entryPrice: parseFloat(p.avgPrice),
          markPrice: parseFloat(p.markPrice),
          unrealizedPnl: parseFloat(p.unrealisedPnl),
          leverage: parseFloat(p.leverage),
          marginMode: p.tradeMode === "0" ? "cross" : "isolated",
          liquidationPrice: parseFloat(p.liqPrice || "0"),
        }));
    } else if (exchange === "okx") {
      const timestamp = new Date().toISOString();
      const path = "/api/v5/account/positions?instType=SWAP";
      const signature = signOkx(apiSecret, timestamp, "GET", path);
      const res = await fetch(`https://www.okx.com${path}`, {
        headers: {
          "OK-ACCESS-KEY": apiKey,
          "OK-ACCESS-SIGN": signature,
          "OK-ACCESS-TIMESTAMP": timestamp,
          "OK-ACCESS-PASSPHRASE": passphrase || "",
          "Content-Type": "application/json",
        },
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      return (data.data || [])
        .filter((p: any) => parseFloat(p.pos) !== 0)
        .map((p: any) => ({
          symbol: p.instId,
          side: p.posSide === "long" ? "long" as const : "short" as const,
          size: Math.abs(parseFloat(p.pos)),
          entryPrice: parseFloat(p.avgPx),
          markPrice: parseFloat(p.markPx || "0"),
          unrealizedPnl: parseFloat(p.upl),
          leverage: parseFloat(p.lever),
          marginMode: p.mgnMode,
          liquidationPrice: parseFloat(p.liqPx || "0"),
        }));
    } else if (exchange === "bitget") {
      const timestamp = Date.now().toString();
      const path = "/api/v2/mix/position/all-position?productType=USDT-FUTURES";
      const sig = signBitget(apiSecret, timestamp, "GET", path);
      const res = await fetch(`https://api.bitget.com${path}`, {
        headers: {
          "ACCESS-KEY": apiKey,
          "ACCESS-SIGN": sig,
          "ACCESS-TIMESTAMP": timestamp,
          "ACCESS-PASSPHRASE": passphrase || "",
          "Content-Type": "application/json",
        },
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      return (data.data || [])
        .filter((p: any) => parseFloat(p.total) > 0)
        .map((p: any) => ({
          symbol: p.symbol,
          side: p.holdSide === "long" ? "long" as const : "short" as const,
          size: parseFloat(p.total),
          entryPrice: parseFloat(p.averageOpenPrice || "0"),
          markPrice: parseFloat(p.markPrice || "0"),
          unrealizedPnl: parseFloat(p.unrealizedPL || "0"),
          leverage: parseFloat(p.leverage || "1"),
          marginMode: p.marginMode || "cross",
          liquidationPrice: parseFloat(p.liquidationPrice || "0"),
        }));
    }
  } catch (err: any) {
    log(`Futures positions fetch failed for ${exchange}: ${err.message}`);
  }
  return [];
}

export async function closeFuturesPosition(
  exchange: string, apiKey: string, apiSecret: string, symbol: string,
  side: "long" | "short", quantity: number, passphrase?: string
): Promise<FuturesOrderResult> {
  const closeSide = side === "long" ? "SELL" : "BUY";
  let base: string, quote: string;

  const cleaned = symbol
    .replace(/-SWAP$/i, "")
    .replace(/_SWAP$/i, "")
    .replace(/M$/, "");

  if (cleaned.includes("/")) {
    [base, quote] = cleaned.split("/");
  } else if (cleaned.includes("-")) {
    [base, quote] = cleaned.split("-");
  } else {
    base = cleaned.replace(/USDT$/i, "");
    quote = "USDT";
  }

  const orderSide = closeSide === "BUY" ? "buy" : "sell";

  try {
    if (exchange === "binance") {
      const sym = `${base}${quote}`;
      const timestamp = Date.now();
      let qs = `symbol=${sym}&side=${closeSide}&type=MARKET&quantity=${quantity}&reduceOnly=true&timestamp=${timestamp}`;
      const signature = signBinance(apiSecret, qs);
      const res = await fetch(`https://fapi.binance.com/fapi/v1/order?${qs}&signature=${signature}`, {
        method: "POST",
        headers: { "X-MBX-APIKEY": apiKey },
        signal: AbortSignal.timeout(15000),
      });
      const data = (await res.json()) as any;
      if (data.orderId) return { success: true, orderId: String(data.orderId) };
      return { success: false, error: data.msg || "Binance close failed" };
    } else if (exchange === "bybit") {
      const sym = `${base}${quote}`;
      const timestamp = Date.now().toString();
      const recvWindow = "5000";
      const body = JSON.stringify({
        category: "linear",
        symbol: sym,
        side: closeSide === "BUY" ? "Buy" : "Sell",
        orderType: "Market",
        qty: String(quantity),
        reduceOnly: true,
      });
      const paramStr = `${timestamp}${apiKey}${recvWindow}${body}`;
      const sig = signBybit(apiSecret, paramStr);
      const res = await fetch("https://api.bybit.com/v5/order/create", {
        method: "POST",
        headers: {
          "X-BAPI-API-KEY": apiKey,
          "X-BAPI-SIGN": sig,
          "X-BAPI-TIMESTAMP": timestamp,
          "X-BAPI-RECV-WINDOW": recvWindow,
          "Content-Type": "application/json",
        },
        body,
        signal: AbortSignal.timeout(15000),
      });
      const data = (await res.json()) as any;
      if (data.retCode === 0 && data.result?.orderId) return { success: true, orderId: data.result.orderId };
      return { success: false, error: data.retMsg || "Bybit close failed" };
    } else if (exchange === "okx") {
      const instId = `${base}-${quote}-SWAP`;
      const timestamp = new Date().toISOString();
      const path = "/api/v5/trade/order";
      const bodyObj = {
        instId,
        tdMode: "cross",
        side: orderSide,
        ordType: "market",
        sz: String(quantity),
        reduceOnly: true,
      };
      const bodyStr = JSON.stringify(bodyObj);
      const sig = signOkx(apiSecret, timestamp, "POST", path, bodyStr);
      const res = await fetch(`https://www.okx.com${path}`, {
        method: "POST",
        headers: {
          "OK-ACCESS-KEY": apiKey,
          "OK-ACCESS-SIGN": sig,
          "OK-ACCESS-TIMESTAMP": timestamp,
          "OK-ACCESS-PASSPHRASE": passphrase || "",
          "Content-Type": "application/json",
        },
        body: bodyStr,
        signal: AbortSignal.timeout(15000),
      });
      const data = (await res.json()) as any;
      if (data.code === "0" && data.data?.[0]?.ordId) return { success: true, orderId: data.data[0].ordId };
      return { success: false, error: data.data?.[0]?.sMsg || data.msg || "OKX close failed" };
    }
    return executeFuturesOrder({
      exchange, apiKey, apiSecret,
      pair: `${base}/${quote}`,
      side: closeSide === "BUY" ? "LONG" : "SHORT",
      quantity, leverage: 1, marginMode: "cross", orderType: "market",
      passphrase, reduceOnly: true,
    });
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function setFuturesLeverage(
  exchange: string, apiKey: string, apiSecret: string, pair: string,
  leverage: number, passphrase?: string
): Promise<{ success: boolean; error?: string }> {
  const [base, quote] = pair.split("/");
  try {
    if (exchange === "binance") {
      const symbol = `${base}${quote}`;
      const timestamp = Date.now();
      const qs = `symbol=${symbol}&leverage=${leverage}&timestamp=${timestamp}`;
      const sig = signBinance(apiSecret, qs);
      const res = await fetch(`https://fapi.binance.com/fapi/v1/leverage?${qs}&signature=${sig}`, {
        method: "POST",
        headers: { "X-MBX-APIKEY": apiKey },
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      if (data.leverage) return { success: true };
      return { success: false, error: data.msg || "Failed to set leverage" };
    } else if (exchange === "bybit") {
      const symbol = `${base}${quote}`;
      const timestamp = Date.now().toString();
      const recvWindow = "5000";
      const body = JSON.stringify({
        category: "linear",
        symbol,
        buyLeverage: String(leverage),
        sellLeverage: String(leverage),
      });
      const paramStr = `${timestamp}${apiKey}${recvWindow}${body}`;
      const sig = signBybit(apiSecret, paramStr);
      const res = await fetch("https://api.bybit.com/v5/position/set-leverage", {
        method: "POST",
        headers: {
          "X-BAPI-API-KEY": apiKey,
          "X-BAPI-SIGN": sig,
          "X-BAPI-TIMESTAMP": timestamp,
          "X-BAPI-RECV-WINDOW": recvWindow,
          "Content-Type": "application/json",
        },
        body,
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      if (data.retCode === 0) return { success: true };
      return { success: false, error: data.retMsg || "Failed to set leverage" };
    } else if (exchange === "okx") {
      const instId = `${base}-${quote}-SWAP`;
      const timestamp = new Date().toISOString();
      const path = "/api/v5/account/set-leverage";
      const body = JSON.stringify({ instId, lever: String(leverage), mgnMode: "cross" });
      const sig = signOkx(apiSecret, timestamp, "POST", path, body);
      const res = await fetch(`https://www.okx.com${path}`, {
        method: "POST",
        headers: {
          "OK-ACCESS-KEY": apiKey,
          "OK-ACCESS-SIGN": sig,
          "OK-ACCESS-TIMESTAMP": timestamp,
          "OK-ACCESS-PASSPHRASE": passphrase || "",
          "Content-Type": "application/json",
        },
        body,
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json()) as any;
      if (data.code === "0") return { success: true };
      return { success: false, error: data.msg || "Failed to set leverage" };
    }
    return { success: false, error: `Exchange '${exchange}' leverage setting not supported` };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}
