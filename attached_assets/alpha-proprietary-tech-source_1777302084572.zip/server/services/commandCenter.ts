/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Autonomous Command Center™ (AACC™) is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import { db } from "../db";
import { eq, and, desc, inArray, sql } from "drizzle-orm";
import { commandCenterConfigs, commandCenterLogs, serverBots, serverBotLogs, userExchangeConnections } from "@shared/models/trading";
import { storage } from "../storage";
import { getVolatilityInfo, getBotPosition, getAllPositions, isBotEngineRunning, getExchangeFees, decryptApiKey, setOnBotPairFailed } from "./botEngine";
import { registerBeacon } from "./integrityBeacon.js";
import { getExchangeValidPairs, resolveExchangePairName, fetchExchangeBalance, executeOrder as executeExchangeOrder, SUPPORTED_EXCHANGES } from "./exchangeAdapter.js";
import { analyzeCoin, analyzeTopCoins, type TechnicalProfile } from "./technicalAnalysis.js";

export const _aaccRuntimeSeal = 'AUT_c9d533ac2874ede52bbb996b';
const _aaccIntegrityValid = registerBeacon('commandCenter', _aaccRuntimeSeal);

async function isLockedPairModeActive(userId: number): Promise<boolean> {
  const bots = await db.select().from(serverBots).where(
    and(eq(serverBots.userId, userId), eq(serverBots.status, 'running'))
  );
  return bots.some((b: any) => (b.settings as any)?._lockedPair === true);
}
if (!_aaccRuntimeSeal?.startsWith('AUT_') || !_aaccIntegrityValid) {
  throw new Error('AACC™ module integrity compromised — unauthorized modification detected');
}

interface SmartAllocation {
  pair: string;
  botType: string;
  investment: number;
  gridLevels?: number;
  perGridAmount?: number;
  safetyOrders?: number;
  perOrderAmount?: number;
  score: number;
  rationale: string;
  allocationReason: string;
}

interface ArbitrageOpportunity {
  pair: string;
  buyExchange: string;
  sellExchange: string;
  buyPrice: number;
  sellPrice: number;
  spreadPercent: number;
  buyFee: number;
  sellFee: number;
  withdrawalFee: number;
  networkFee: number;
  totalFees: number;
  netProfitPercent: number;
  netProfitUsd: number;
  tradeAmount: number;
  profitable: boolean;
  feeBreakdown: string;
}

const WITHDRAWAL_FEES: Record<string, number> = {
  kraken: 2.50, binance: 1.00, binanceus: 1.00, coinbase: 2.00,
  bybit: 1.00, okx: 0.50, kucoin: 1.00, gate: 0.80,
  bitget: 1.00, mexc: 0.50, htx: 1.50, bitfinex: 5.00,
  bitstamp: 3.00, gemini: 0.00, crypto_com: 2.00, robinhood: 0.00,
};

interface CoinOpportunity {
  pair: string;
  baseAsset: string;
  quoteAsset: string;
  score: number;
  price: number;
  change1h: number;
  change24h: number;
  volume24h: number;
  volatility: number;
  momentum: number;
  rsiEstimate: number;
  trendDirection: 'bullish' | 'bearish' | 'neutral';
  reason: string;
  technicalProfile?: TechnicalProfile;
  rsi14?: number;
  macdCrossover?: 'bullish' | 'bearish' | 'none';
  emaCrossover?: 'golden_cross' | 'death_cross' | 'none';
  adx14?: number;
  trendStrength?: 'strong' | 'moderate' | 'weak' | 'no_trend';
  bollingerPosition?: number;
  atrPercent?: number;
  supportLevel?: number;
  resistanceLevel?: number;
  meanReversionSignal?: 'oversold_bounce' | 'overbought_reversal' | 'none';
  breakoutSignal?: 'bullish_breakout' | 'bearish_breakdown' | 'none';
  recommendation?: 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell';
  taConfidence?: number;
  volumeProfile?: 'above_average' | 'average' | 'below_average';
  multiTimeframeTrend?: 'strong_buy' | 'buy' | 'neutral' | 'sell' | 'strong_sell';
  multiTimeframeAlignment?: number;
  buyVolumePressure?: number;
  sellVolumePressure?: number;
  overallVolumeBias?: 'strong_buying' | 'buying' | 'neutral' | 'selling' | 'strong_selling';
  marketCap?: number;
  marketCapRank?: 'mega' | 'large' | 'mid' | 'small' | 'micro';
  volume24hUsd?: number;
  tf1mTrend?: string;
  tf5mTrend?: string;
  tf1hTrend?: string;
  tf24hTrend?: string;
}

const failedPairBlacklist = new Map<string, number>();
const BLACKLIST_COOLDOWN_MS = 30 * 60 * 1000;
const geoRestrictedPairs = new Set<string>();

function blacklistPair(pair: string) {
  failedPairBlacklist.set(pair, Date.now());
  ccLog(`Blacklisted ${pair} for ${BLACKLIST_COOLDOWN_MS / 60000} minutes after repeated failures`);
}

function isPairBlacklisted(pair: string): boolean {
  if (geoRestrictedPairs.has(pair)) return true;
  const ts = failedPairBlacklist.get(pair);
  if (!ts) return false;
  if (Date.now() - ts > BLACKLIST_COOLDOWN_MS) {
    failedPairBlacklist.delete(pair);
    return false;
  }
  return true;
}

export function getBlacklistedPairs(): { pair: string; expiresAt: number }[] {
  const result: { pair: string; expiresAt: number }[] = [];
  for (const [pair, ts] of failedPairBlacklist) {
    if (Date.now() - ts <= BLACKLIST_COOLDOWN_MS) {
      result.push({ pair, expiresAt: ts + BLACKLIST_COOLDOWN_MS });
    } else {
      failedPairBlacklist.delete(pair);
    }
  }
  return result;
}

interface ManagedBotPerformance {
  botId: number;
  pair: string;
  type: string;
  status: string;
  pnl: number;
  pnlPercent: number;
  holdTimeMinutes: number;
  lastTradeMinutesAgo: number;
  isUnderperforming: boolean;
  signalStrength: number;
  investment: number;
}

type MarketCondition = 'trending_up' | 'trending_down' | 'ranging' | 'volatile' | 'breakout';

interface BotTypeSelection {
  type: string;
  condition: MarketCondition;
  rationale: string;
}

let _cachedMarketRegime: { regime: 'bull' | 'bear' | 'sideways' | 'crash'; btcChange: number; ethChange: number; ts: number } | null = null;

async function detectMarketRegime(): Promise<{ regime: 'bull' | 'bear' | 'sideways' | 'crash'; btcChange: number; ethChange: number; confidence: number }> {
  if (_cachedMarketRegime && Date.now() - _cachedMarketRegime.ts < 120000) {
    const { regime, btcChange, ethChange } = _cachedMarketRegime;
    return { regime, btcChange, ethChange, confidence: 80 };
  }
  try {
    const sources = [
      { url: 'https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT', fallback: 'https://api.binance.us/api/v3/ticker/24hr?symbol=BTCUSDT' },
      { url: 'https://api.binance.com/api/v3/ticker/24hr?symbol=ETHUSDT', fallback: 'https://api.binance.us/api/v3/ticker/24hr?symbol=ETHUSDT' },
    ];
    const fetchTicker = async (src: { url: string; fallback: string }) => {
      try {
        const res = await globalThis.fetch(src.url, { signal: AbortSignal.timeout(6000) });
        if (res.ok) {
          const data = await res.json() as any;
          if (data.priceChangePercent) return data;
        }
      } catch {}
      const res2 = await globalThis.fetch(src.fallback, { signal: AbortSignal.timeout(6000) });
      if (res2.ok) {
        const data2 = await res2.json() as any;
        if (data2.priceChangePercent) return data2;
      }
      return null;
    };
    const [btc, eth] = await Promise.all(sources.map(fetchTicker));
    if (!btc || !eth) {
      ccLog(`Market regime: Unable to fetch BTC/ETH data — defaulting to SIDEWAYS`);
      _cachedMarketRegime = { regime: 'sideways', btcChange: 0, ethChange: 0, ts: Date.now() };
      return { regime: 'sideways', btcChange: 0, ethChange: 0, confidence: 30 };
    }
    const btcChange = parseFloat(btc.priceChangePercent);
    const ethChange = parseFloat(eth.priceChangePercent);
    const avg = (btcChange + ethChange) / 2;

    let regime: 'bull' | 'bear' | 'sideways' | 'crash';
    if (avg < -5) regime = 'crash';
    else if (avg < -1.5) regime = 'bear';
    else if (avg > 2) regime = 'bull';
    else regime = 'sideways';

    const confidence = Math.min(95, 60 + Math.abs(avg) * 5);
    _cachedMarketRegime = { regime, btcChange, ethChange, ts: Date.now() };
    ccLog(`Market regime: ${regime.toUpperCase()} | BTC: ${btcChange > 0 ? '+' : ''}${btcChange.toFixed(2)}% | ETH: ${ethChange > 0 ? '+' : ''}${ethChange.toFixed(2)}% | Confidence: ${confidence.toFixed(0)}%`);
    return { regime, btcChange, ethChange, confidence };
  } catch {
    return { regime: 'sideways', btcChange: 0, ethChange: 0, confidence: 30 };
  }
}

function getAdaptiveMinScore(baseScore: number, regime: 'bull' | 'bear' | 'sideways' | 'crash'): number {
  switch (regime) {
    case 'crash': return Math.max(baseScore, 85);
    case 'bear': return Math.max(baseScore, 78);
    case 'sideways': return Math.max(baseScore, 73);
    case 'bull': return baseScore;
    default: return baseScore;
  }
}

function selectBotType(opportunity: CoinOpportunity, marketRegime: 'bull' | 'bear' | 'sideways' | 'crash' = 'sideways'): BotTypeSelection {
  const { momentum, volatility, change1h, change24h, rsiEstimate, trendDirection, volume24h } = opportunity;
  const absMomentum = Math.abs(momentum);
  const ta = opportunity.technicalProfile;
  const rsi = ta?.rsi14 ?? rsiEstimate;
  const adx = ta?.adx14 ?? 25;
  const macdX = ta?.macdCrossover ?? 'none';
  const emaX = ta?.emaCrossover ?? 'none';
  const bbPos = ta?.bollingerPosition ?? 0.5;
  const breakout = ta?.breakoutSignal ?? 'none';
  const meanRev = ta?.meanReversionSignal ?? 'none';
  const tStrength = ta?.trendStrength ?? 'moderate';
  const atrPct = ta?.atrPercent ?? volatility;
  const mtfTrend = opportunity.multiTimeframeTrend ?? 'neutral';
  const mtfAlignment = opportunity.multiTimeframeAlignment ?? 50;
  const volBias = opportunity.overallVolumeBias ?? 'neutral';

  if (mtfTrend === 'strong_sell') {
    return {
      type: 'skip',
      condition: 'bearish',
      rationale: `Multi-timeframe strong sell (1m/5m/1h/24h/30d aligned ${mtfAlignment}%, vol bias: ${volBias}) — downtrend, skip`
    };
  }

  if (mtfTrend === 'sell') {
    return {
      type: 'skip',
      condition: 'bearish',
      rationale: `Multi-timeframe sell trend (alignment ${mtfAlignment}%, vol bias: ${volBias}) — downtrend, skip`
    };
  }

  if (trendDirection === 'bearish' && mtfTrend === 'neutral' && marketRegime !== 'bull') {
    return {
      type: 'skip',
      condition: 'bearish',
      rationale: `Bearish 24h (${change24h.toFixed(1)}%) with neutral MTF in ${marketRegime} market — no confirmed uptrend, skip`
    };
  }

  const tf1h = opportunity.tf1hTrend;
  const tf24h = opportunity.tf24hTrend;
  if ((tf1h === 'sell' || tf1h === 'strong_sell') && (tf24h === 'sell' || tf24h === 'strong_sell')) {
    return {
      type: 'skip',
      condition: 'bearish',
      rationale: `1h trend: ${tf1h}, 24h trend: ${tf24h} — both bearish, coin is in a downtrend, skip`
    };
  }

  if (breakout === 'bullish_breakout' && volume24h > 50000000 && adx > 25) {
    return {
      type: 'trailing_stop',
      condition: 'breakout',
      rationale: `Bullish breakout confirmed (ADX ${adx.toFixed(0)}, RSI ${rsi.toFixed(0)}, volume spike) — trailing stop to capture max move`
    };
  }

  if (meanRev === 'oversold_bounce' && rsi < 30 && bbPos < 0.15 && trendDirection === 'bullish') {
    return {
      type: 'dca',
      condition: 'volatile',
      rationale: `Oversold bounce in uptrend (RSI ${rsi.toFixed(0)}, BB pos ${(bbPos * 100).toFixed(0)}%) — DCA to accumulate near support`
    };
  }

  if (trendDirection === 'bullish' && adx > 30 && tStrength === 'strong' && macdX === 'bullish' && rsi < 70) {
    return {
      type: 'signal',
      condition: 'trending_up',
      rationale: `Strong bullish trend (ADX ${adx.toFixed(0)}, MACD bullish crossover, RSI ${rsi.toFixed(0)}) — AI signal for trend following`
    };
  }

  if (trendDirection === 'bullish' && rsi < 75 && (emaX === 'golden_cross' || (momentum > 50 && adx > 20))) {
    return {
      type: 'signal',
      condition: 'trending_up',
      rationale: `Bullish (RSI ${rsi.toFixed(0)}, EMA ${emaX}, ADX ${adx.toFixed(0)}) — AI signal bot for trend capture`
    };
  }

  if (trendDirection === 'bearish' && (adx > 25 || momentum < -30)) {
    return {
      type: 'skip',
      condition: 'trending_down',
      rationale: `Bearish trend (ADX ${adx.toFixed(0)}, RSI ${rsi.toFixed(0)}, momentum ${momentum.toFixed(0)}) — downtrend, SKIP. Small bounces within downtrends are traps.`
    };
  }

  if (trendDirection === 'bearish') {
    return {
      type: 'skip',
      condition: 'trending_down',
      rationale: `Bearish 24h trend (${change24h.toFixed(1)}%) — not buying into downtrend`
    };
  }

  if (atrPct > 5 && adx < 20 && tStrength === 'no_trend' && bbPos > 0.3 && bbPos < 0.7) {
    return {
      type: 'grid',
      condition: 'ranging',
      rationale: `Range-bound (ADX ${adx.toFixed(0)}, ATR ${atrPct.toFixed(1)}%, BB mid-range) — grid bot for oscillation capture`
    };
  }

  if (volatility > 12 && absMomentum < 40 && adx < 25 && trendDirection !== 'bearish') {
    return {
      type: 'dca',
      condition: 'volatile',
      rationale: `High volatility (${volatility.toFixed(1)}%, ADX ${adx.toFixed(0)}) no bearish trend — DCA to average position`
    };
  }

  if (trendDirection === 'bullish' && volatility > 8 && rsi < 70 && adx > 15) {
    return {
      type: 'infinity_grid',
      condition: 'trending_up',
      rationale: `Bullish with volatility (${volatility.toFixed(1)}%, ADX ${adx.toFixed(0)}) — infinity grid for trending market`
    };
  }

  if (trendDirection === 'neutral' && adx < 20 && rsi > 40 && rsi < 60 && bbPos > 0.35 && bbPos < 0.65) {
    return {
      type: 'grid',
      condition: 'ranging',
      rationale: `Neutral range (RSI ${rsi.toFixed(0)}, ADX ${adx.toFixed(0)}, BB mid ${(bbPos * 100).toFixed(0)}%) — grid for sideways oscillation`
    };
  }

  return {
    type: 'signal',
    condition: absMomentum > 30 ? (momentum > 0 ? 'trending_up' : 'trending_down') : 'ranging',
    rationale: `AI signal — RSI ${rsi.toFixed(0)}, ADX ${adx.toFixed(0)}, MACD ${macdX}, ${trendDirection}`
  };
}

function detectMarketCondition(opportunities: CoinOpportunity[]): MarketCondition {
  if (opportunities.length === 0) return 'ranging';
  const avgMomentum = opportunities.slice(0, 20).reduce((s, o) => s + o.momentum, 0) / Math.min(opportunities.length, 20);
  const avgVolatility = opportunities.slice(0, 20).reduce((s, o) => s + o.volatility, 0) / Math.min(opportunities.length, 20);
  const bullishCount = opportunities.slice(0, 20).filter(o => o.trendDirection === 'bullish').length;
  const bearishCount = opportunities.slice(0, 20).filter(o => o.trendDirection === 'bearish').length;

  if (avgVolatility > 12) return 'volatile';
  if (bullishCount > 14) return 'trending_up';
  if (bearishCount > 14) return 'trending_down';
  if (avgMomentum > 60) return 'breakout';
  return 'ranging';
}

const ALL_TECH = ['acm', 'qfrm', 'bif', 'sbpe', 'ance', 'ance2'];
const ALL_FILTERS = ['order_flow', 'fair_value_gap', 'absorption', 'fractal_energy', 'wyckoff', 'entropy', 'hurst', 'delta_divergence'];

const activeEngines = new Map<string, NodeJS.Timeout>();
const scanCache = new Map<string, { data: CoinOpportunity[]; ts: number }>();

async function getExchangeValidPairsForCC(exchange: string): Promise<{ pairs: Map<string, string>; bases: Set<string> }> {
  const result = await getExchangeValidPairs(exchange);
  return { pairs: result.pairs, bases: result.bases };
}

interface PriceSnapshot {
  pair: string;
  priceAtSignal: number;
  score: number;
  botType: string;
  condition: MarketCondition;
  timestamp: number;
  exchange: string;
  configId: number;
  userId: string;
}

interface PriceOutcome {
  pair: string;
  userId: string;
  priceAtSignal: number;
  priceAfter5m: number | null;
  priceAfter15m: number | null;
  priceAfter30m: number | null;
  priceAfter60m: number | null;
  profitPotential5m: number | null;
  profitPotential15m: number | null;
  profitPotential30m: number | null;
  profitPotential60m: number | null;
  score: number;
  botType: string;
  condition: MarketCondition;
  timestamp: number;
}

const priceTracker = new Map<string, PriceSnapshot[]>();
const priceOutcomes: PriceOutcome[] = [];
const MAX_OUTCOMES = 5000;

function ccLog(msg: string) {
  console.log(`[CommandCenter] ${msg}`);
}

function calculateRotationFees(exchange: string, investmentPerBot: number): { sellFee: number; buyFee: number; totalRoundTrip: number; feePercent: number; feeBreakdown: string } {
  const fees = getExchangeFees(exchange);
  const sellFee = investmentPerBot * fees.taker;
  const buyFee = investmentPerBot * fees.taker;
  const totalRoundTrip = sellFee + buyFee;
  const feePercent = (totalRoundTrip / investmentPerBot) * 100;
  const feeBreakdown = `${fees.name} rotation fees: sell $${sellFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) + buy $${buyFee.toFixed(4)} (${(fees.taker * 100).toFixed(2)}%) = $${totalRoundTrip.toFixed(4)} total (${feePercent.toFixed(3)}% round-trip)`;
  return { sellFee, buyFee, totalRoundTrip, feePercent, feeBreakdown };
}

function isRotationProfitable(
  exchange: string,
  investmentPerBot: number,
  currentPnlPercent: number,
  newScore: number,
  volatility24h: number
): { profitable: boolean; estimatedNetGain: number; totalFees: number; feeBreakdown: string; reason: string } {
  const { totalRoundTrip, feePercent, feeBreakdown } = calculateRotationFees(exchange, investmentPerBot);

  const scoreGainFactor = Math.min(1, newScore / 100);
  const volatilityFactor = Math.min(2, Math.max(0.5, volatility24h / 5));
  const estimatedGainPercent = scoreGainFactor * volatilityFactor * 2.5;

  const currentTrajectory = currentPnlPercent > 0 ? currentPnlPercent * 0.3 : currentPnlPercent * 0.1;

  const netGainPercent = estimatedGainPercent - feePercent - currentTrajectory;
  const estimatedNetGain = (netGainPercent / 100) * investmentPerBot;

  const profitable = netGainPercent > feePercent * 0.25;

  let reason: string;
  if (profitable) {
    reason = `Rotation profitable: est. gain ${estimatedGainPercent.toFixed(2)}% - fees ${feePercent.toFixed(3)}% - current trajectory ${currentTrajectory.toFixed(2)}% = net ${netGainPercent.toFixed(2)}% ($${estimatedNetGain.toFixed(4)})`;
  } else {
    reason = `Rotation NOT profitable: est. gain ${estimatedGainPercent.toFixed(2)}% insufficient to cover fees ${feePercent.toFixed(3)}% + current trajectory ${currentTrajectory.toFixed(2)}% (net ${netGainPercent.toFixed(2)}%)`;
  }

  return { profitable, estimatedNetGain, totalFees: totalRoundTrip, feeBreakdown, reason };
}

function calculateSmartAllocations(
  opportunities: CoinOpportunity[],
  availableCapital: number,
  exchange: string,
  riskLevel: string,
  reservePercent: number = 20
): SmartAllocation[] {
  if (opportunities.length === 0 || availableCapital <= 0) return [];

  const top5 = opportunities.slice(0, 5);
  const fees = getExchangeFees(exchange);
  const roundTripRate = fees.taker * 2;

  const scored = top5.map(opp => {
    const botSelection = selectBotType(opp);
    const potentialGain = (opp.score / 100) * Math.min(2, Math.max(0.5, opp.volatility / 5)) * 2.5;
    const feeImpact = roundTripRate * 100;
    const netPotential = potentialGain - feeImpact;
    const profitabilityScore = netPotential * (opp.volume24h > 100000000 ? 1.3 : opp.volume24h > 10000000 ? 1.1 : 0.9);
    return { opp, botSelection, profitabilityScore, netPotential };
  });

  scored.sort((a, b) => b.profitabilityScore - a.profitabilityScore);
  const top3 = scored.filter(s => s.netPotential > 0).slice(0, 3);
  if (top3.length === 0) return [];

  const reserveAmount = availableCapital * (reservePercent / 100);
  const deployableCapital = availableCapital - reserveAmount;
  if (deployableCapital < 10) return [];

  const totalScore = top3.reduce((s, t) => s + t.profitabilityScore, 0);
  const allocations: SmartAllocation[] = [];

  for (const item of top3) {
    const weight = totalScore > 0 ? item.profitabilityScore / totalScore : 1 / top3.length;
    let investment = Math.floor(deployableCapital * weight * 100) / 100;
    investment = Math.max(10, Math.min(investment, deployableCapital * 0.6));

    const botType = item.botSelection.type;
    const allocation: SmartAllocation = {
      pair: item.opp.pair,
      botType,
      investment,
      score: item.opp.score,
      rationale: item.botSelection.rationale,
      allocationReason: '',
    };

    if (botType === 'grid' || botType === 'infinity_grid' || botType === 'reverse_grid') {
      const gridLevels = item.opp.volatility > 8 ? 20 : item.opp.volatility > 4 ? 15 : 10;
      const perGrid = Math.round((investment / gridLevels) * 100) / 100;
      allocation.gridLevels = gridLevels;
      allocation.perGridAmount = perGrid;
      allocation.allocationReason = `$${investment} total ÷ ${gridLevels} grids = $${perGrid}/grid | Score weight: ${(weight * 100).toFixed(0)}% of deployable capital`;
    } else if (botType === 'dca') {
      const safetyOrders = riskLevel === 'aggressive' ? 8 : riskLevel === 'conservative' ? 3 : 5;
      const baseOrder = investment * 0.3;
      const safetyBudget = investment - baseOrder;
      const perOrder = Math.round((safetyBudget / safetyOrders) * 100) / 100;
      allocation.safetyOrders = safetyOrders;
      allocation.perOrderAmount = perOrder;
      allocation.allocationReason = `$${baseOrder.toFixed(2)} base + ${safetyOrders} safety orders × $${perOrder}/order = $${investment} | Score weight: ${(weight * 100).toFixed(0)}%`;
    } else {
      allocation.allocationReason = `$${investment} full position | Score weight: ${(weight * 100).toFixed(0)}% of deployable capital | ${botType} bot`;
    }

    allocations.push(allocation);
  }

  const totalAllocated = allocations.reduce((s, a) => s + a.investment, 0);
  if (totalAllocated > deployableCapital) {
    const scaleFactor = deployableCapital / totalAllocated;
    for (const a of allocations) {
      a.investment = Math.floor(a.investment * scaleFactor * 100) / 100;
      if (a.gridLevels) a.perGridAmount = Math.round((a.investment / a.gridLevels) * 100) / 100;
      if (a.safetyOrders) {
        const baseOrder = a.investment * 0.3;
        a.perOrderAmount = Math.round(((a.investment - baseOrder) / a.safetyOrders) * 100) / 100;
      }
    }
  }

  return allocations;
}

async function fetchExchangeBalanceForCC(userId: string, exchangeId: string): Promise<number> {
  try {
    const connections = await db.select().from(userExchangeConnections)
      .where(and(
        eq(userExchangeConnections.userId, userId),
        eq(userExchangeConnections.exchangeName, exchangeId),
        eq(userExchangeConnections.isActive, true)
      ));

    if (connections.length === 0) {
      const fallback = await db.select().from(userExchangeConnections)
        .where(and(
          eq(userExchangeConnections.exchangeName, exchangeId),
          eq(userExchangeConnections.isActive, true)
        )).limit(1);
      if (fallback.length === 0) return 0;
      ccLog(`No ${exchangeId} connection for user ${userId} — using fallback connection`);
      connections.push(fallback[0]);
    }
    const conn = connections[connections.length - 1];

    const apiKey = decryptApiKey(conn.apiKeyEncrypted);
    const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
    const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;

    const balance = await fetchExchangeBalance(exchangeId, apiKey, apiSecret, passphrase);
    const result = balance.total > 0 ? balance.total : balance.available;
    if (result > 0) {
      ccLog(`Real ${exchangeId} balance: $${result.toFixed(2)} (total: $${balance.total.toFixed(2)}, available: $${balance.available.toFixed(2)})`);
    } else {
      ccLog(`${exchangeId} balance returned $0 — API may have returned empty response`);
    }
    return result;
  } catch (err: any) {
    ccLog(`Failed to fetch balance for ${exchangeId}: ${err.message}`);
    return 0;
  }
}

export async function fetchKrakenAssetBreakdown(userId: string): Promise<Record<string, number>> {
  try {
    const connections = await db.select().from(userExchangeConnections)
      .where(and(
        eq(userExchangeConnections.userId, userId),
        eq(userExchangeConnections.exchangeName, 'kraken'),
        eq(userExchangeConnections.isActive, true)
      ));
    if (connections.length === 0) {
      ccLog(`No Kraken connection for user ${userId} — skipping asset breakdown`);
      return {};
    }
    const conn = connections[connections.length - 1];
    const apiKey = decryptApiKey(conn.apiKeyEncrypted);
    const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
    const result = await fetchExchangeBalance('kraken_assets' as any, apiKey, apiSecret);
    return (result as any).assets || {};
  } catch (err: any) {
    ccLog(`Failed to fetch Kraken asset breakdown: ${err.message}`);
    return {};
  }
}

export async function detectAndRecoverOrphanedAssets(config: any): Promise<void> {
  try {
    if (config.exchange !== 'kraken') return;

    if (await isLockedPairModeActive(config.userId)) {
      ccLog(`LOCKED MODE — orphan recovery skipped, only locked-pair bots allowed`);
      return;
    }

    await new Promise(r => setTimeout(r, 2000));
    const assets = await fetchKrakenAssetBreakdown(config.userId);
    if (Object.keys(assets).length === 0) return;

    const stableAssets = new Set(['ZUSD', 'USDT', 'USDC', 'USD', 'USD.HOLD', 'USD.M']);
    const krakenAssetToSymbol: Record<string, string> = {
      'XXBT': 'BTC', 'XETH': 'ETH', 'XXRP': 'XRP', 'XXLM': 'XLM',
      'XLTC': 'LTC', 'XXDG': 'DOGE', 'XREP': 'REP', 'XXMR': 'XMR',
      'XZEC': 'ZEC', 'XETC': 'ETC',
    };

    const activeBots = await db.select({ pair: serverBots.pair, status: serverBots.status, settings: serverBots.settings })
      .from(serverBots)
      .where(and(eq(serverBots.userId, config.userId), eq(serverBots.status, 'running')));

    const managedPairs = new Set(activeBots.map(b => {
      const base = b.pair.split('/')[0];
      return base.toUpperCase();
    }));

    const orphanedAssets: { asset: string; symbol: string; quantity: number; usdValue: number; pair: string }[] = [];

    for (const [krakenAsset, qty] of Object.entries(assets)) {
      if (stableAssets.has(krakenAsset)) continue;
      if (qty < 0.01) continue;

      const symbol = krakenAssetToSymbol[krakenAsset] || krakenAsset.replace(/^X/, '').replace(/^Z/, '');
      if (managedPairs.has(symbol.toUpperCase())) continue;

      let price = 0;
      try {
        const pairStr = `${symbol}USD`;
        const res = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${pairStr}`, { signal: AbortSignal.timeout(5000) });
        const data = await res.json() as any;
        if (data.result) {
          const firstKey = Object.keys(data.result)[0];
          if (firstKey) price = parseFloat(data.result[firstKey].c?.[0] || '0');
        }
      } catch {}

      if (price === 0) {
        try {
          const usdtPair = `${symbol}USDT`;
          const res = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${usdtPair}`, { signal: AbortSignal.timeout(5000) });
          const data = await res.json() as any;
          if (data.result) {
            const firstKey = Object.keys(data.result)[0];
            if (firstKey) price = parseFloat(data.result[firstKey].c?.[0] || '0');
          }
        } catch {}
      }

      const usdValue = qty * price;
      if (usdValue < 5) continue;

      let quoteCurrency = 'USD';
      try {
        const usdCheck = await fetch(`https://api.kraken.com/0/public/AssetPairs?pair=${symbol}USD`, { signal: AbortSignal.timeout(5000) });
        const usdData = await usdCheck.json() as any;
        if (usdData.error?.length > 0 || !usdData.result || Object.keys(usdData.result).length === 0) {
          quoteCurrency = 'USDT';
        }
      } catch { quoteCurrency = 'USDT'; }

      orphanedAssets.push({
        asset: krakenAsset,
        symbol,
        quantity: qty,
        usdValue,
        pair: `${symbol}/${quoteCurrency}`,
      });
    }

    if (orphanedAssets.length === 0) return;

    ccLog(`🔍 ORPHAN DETECTION: Found ${orphanedAssets.length} unmanaged asset(s) worth $${orphanedAssets.reduce((s, a) => s + a.usdValue, 0).toFixed(2)}: ${orphanedAssets.map(a => `${a.symbol} (${a.quantity.toFixed(4)} = $${a.usdValue.toFixed(2)})`).join(', ')}`);

    for (const orphan of orphanedAssets) {
      const existingBot = activeBots.find(b => {
        const base = b.pair.split('/')[0].toUpperCase();
        return base === orphan.symbol.toUpperCase();
      });
      if (existingBot) continue;

      const existingRecovery = await db.select({ id: serverBots.id })
        .from(serverBots)
        .where(and(
          eq(serverBots.userId, config.userId),
          eq(serverBots.status, 'running'),
          sql`${serverBots.name} LIKE ${'%' + orphan.symbol + ' RECOVERY%'}`
        ))
        .limit(1);
      if (existingRecovery.length > 0) continue;

      const settings = config.settings || {};
      const riskLevel = settings.riskLevel || 'aggressive';

      const botSettings = {
        investment: orphan.usdValue,
        takeProfit: 2.5,
        stopLoss: 3.0,
        trailingPercent: 1.5,
        cooldownSeconds: 30,
        signalThreshold: 45,
        paperTrading: false,
        ocoEnabled: true,
        autoCooldown: true,
        autoTakeProfit: true,
        autoStopLoss: true,
        autoThreshold: true,
        autoTrailing: true,
        maxDailyTrades: 0,
        maxDailyLossPercent: 5,
        positionSizePercent: 100,
        signalSource: 'ai',
        bridgeFusion: true,
        bridgeFusionMode: 'auto',
        _managedByCC: true,
        _orphanRecovery: true,
        _orphanAsset: orphan.symbol,
        _orphanQuantity: orphan.quantity,
      };

      const { tech, filters } = selectTechAndFilters({
        pair: orphan.pair,
        baseAsset: orphan.symbol,
        quoteAsset: orphan.pair.split('/')[1],
        score: 70,
        price: orphan.usdValue / orphan.quantity,
        change1h: 0, change24h: 0,
        volume24h: 1000000,
        volatility: 8,
        momentum: 0,
        rsiEstimate: 50,
        trendDirection: 'neutral',
        reason: 'orphan recovery',
      }, riskLevel);

      const { savePosition } = await import("./botEngine.js");

      const botData = {
        userId: config.userId,
        name: `AACC™: ${orphan.symbol} RECOVERY (orphaned $${orphan.usdValue.toFixed(2)})`,
        type: 'signal' as const,
        pair: orphan.pair,
        exchange: config.exchange,
        status: 'running' as const,
        settings: botSettings,
        activeTech: tech,
        activeFilters: filters,
        totalTrades: 0,
        totalPnl: 0,
      };

      const [newBot] = await db.insert(serverBots).values(botData).returning({ id: serverBots.id });
      if (!newBot) continue;

      const entryPrice = orphan.usdValue / orphan.quantity;
      await savePosition(newBot.id, {
        side: 'long',
        quantity: orphan.quantity,
        entryPrice,
        entryTime: Date.now(),
        investment: orphan.usdValue,
      });

      const managedIds = [...(config.managedBotIds || []), newBot.id];
      await db.update(commandCenterConfigs)
        .set({ managedBotIds: managedIds, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));
      config.managedBotIds = managedIds;

      ccLog(`🔧 RECOVERY BOT #${newBot.id} created for orphaned ${orphan.symbol} — ${orphan.quantity.toFixed(6)} units worth $${orphan.usdValue.toFixed(2)} | Pair: ${orphan.pair} | Entry: $${entryPrice.toFixed(6)} | Will sell at profit`);

      await logCC(config.id, config.userId, 'orphan_recovery',
        `Created recovery bot #${newBot.id} for orphaned ${orphan.symbol} asset — ${orphan.quantity.toFixed(6)} units worth $${orphan.usdValue.toFixed(2)}`,
        { botId: newBot.id, asset: orphan.symbol, quantity: orphan.quantity, usdValue: orphan.usdValue, entryPrice }
      );
    }
  } catch (err: any) {
    ccLog(`Orphan detection error: ${err.message}`);
  }
}

async function getConnectedExchanges(userId: string): Promise<string[]> {
  const connections = await db.select().from(userExchangeConnections)
    .where(and(
      eq(userExchangeConnections.userId, userId),
      eq(userExchangeConnections.isActive, true)
    ));

  const uniqueExchanges = [...new Set(connections.map(c => c.exchangeName))];
  return uniqueExchanges;
}

async function fetchPriceFromExchange(pair: string, exchange: string): Promise<number> {
  const symbol = pair.replace('/', '');
  const base = pair.split('/')[0];
  try {
    if (exchange === 'kraken') {
      const krakenPair = symbol.replace('BTC', 'XBT');
      const res = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${krakenPair}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        const key = Object.keys(data.result || {})[0];
        if (key) return parseFloat(data.result[key].c[0]);
      }
    }

    if (exchange === 'coinbase') {
      const quote = pair.split('/')[1] || 'USD';
      const res = await fetch(`https://api.coinbase.com/v2/prices/${base}-${quote}/spot`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        return parseFloat(data.data?.amount || 0);
      }
    }

    if (exchange === 'bybit') {
      const res = await fetch(`https://api.bybit.com/v5/market/tickers?category=spot&symbol=${symbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        const ticker = data.result?.list?.[0];
        if (ticker) return parseFloat(ticker.lastPrice || 0);
      }
    }

    if (exchange === 'okx') {
      const okxSymbol = `${base}-USDT`;
      const res = await fetch(`https://www.okx.com/api/v5/market/ticker?instId=${okxSymbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        if (data.data?.[0]) return parseFloat(data.data[0].last || 0);
      }
    }

    if (exchange === 'kucoin') {
      const kucoinSymbol = `${base}-USDT`;
      const res = await fetch(`https://api.kucoin.com/api/v1/market/orderbook/level1?symbol=${kucoinSymbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        if (data.data?.price) return parseFloat(data.data.price);
      }
    }

    if (exchange === 'gate' || exchange === 'gateio') {
      const gateSymbol = `${base}_USDT`;
      const res = await fetch(`https://api.gateio.ws/api/v4/spot/tickers?currency_pair=${gateSymbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        if (Array.isArray(data) && data[0]) return parseFloat(data[0].last || 0);
      }
    }

    if (exchange === 'bitget') {
      const res = await fetch(`https://api.bitget.com/api/v2/spot/market/tickers?symbol=${symbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        if (data.data?.[0]) return parseFloat(data.data[0].lastPr || 0);
      }
    }

    if (exchange === 'mexc') {
      const res = await fetch(`https://api.mexc.com/api/v3/ticker/price?symbol=${symbol}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        return parseFloat(data.price || 0);
      }
    }

    if (exchange === 'binance' || exchange === 'binanceus') {
      const url = exchange === 'binanceus'
        ? `https://api.binance.us/api/v3/ticker/price?symbol=${symbol}`
        : `https://data-api.binance.vision/api/v3/ticker/price?symbol=${symbol}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = await res.json() as any;
        return parseFloat(data.price || 0);
      }
    }
  } catch {}
  return 0;
}

async function scanCrossExchangeArbitrage(
  userId: string,
  exchanges: string[],
  availableCapital: number
): Promise<ArbitrageOpportunity[]> {
  if (exchanges.length < 2) return [];
  if (availableCapital <= 0) return [];

  const topPairs = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT', 'ADA/USDT',
    'DOGE/USDT', 'AVAX/USDT', 'DOT/USDT', 'LINK/USDT', 'MATIC/USDT'];

  const opportunities: ArbitrageOpportunity[] = [];
  const tradeAmount = Math.max(10, Math.min(availableCapital * 0.3, 500));

  for (const pair of topPairs) {
    const prices: { exchange: string; price: number }[] = [];

    const pricePromises = exchanges.map(async (ex) => {
      const price = await fetchPriceFromExchange(pair, ex);
      if (price > 0) prices.push({ exchange: ex, price });
    });
    await Promise.all(pricePromises);

    if (prices.length < 2) continue;

    prices.sort((a, b) => a.price - b.price);
    const cheapest = prices[0];
    const expensive = prices[prices.length - 1];

    const spreadPercent = ((expensive.price - cheapest.price) / cheapest.price) * 100;
    if (spreadPercent < 0.1) continue;

    const buyFees = getExchangeFees(cheapest.exchange);
    const sellFees = getExchangeFees(expensive.exchange);
    const buyFee = tradeAmount * buyFees.taker;
    const sellFee = tradeAmount * sellFees.taker;
    const withdrawalFee = WITHDRAWAL_FEES[cheapest.exchange] || 2.0;
    const networkFee = 1.0;
    const totalFees = buyFee + sellFee + withdrawalFee + networkFee;

    const grossProfit = tradeAmount * (spreadPercent / 100);
    const netProfit = grossProfit - totalFees;
    const netProfitPercent = (netProfit / tradeAmount) * 100;

    const returnTransferFee = WITHDRAWAL_FEES[expensive.exchange] || 2.0;
    const netAfterReturn = netProfit - returnTransferFee;
    const profitable = netAfterReturn > 0 && netProfitPercent > 0.1;

    const feeBreakdown = `Buy fee ($${buyFee.toFixed(2)}) + Sell fee ($${sellFee.toFixed(2)}) + Withdrawal ($${withdrawalFee.toFixed(2)}) + Network ($${networkFee.toFixed(2)}) + Return transfer ($${returnTransferFee.toFixed(2)}) = $${(totalFees + returnTransferFee).toFixed(2)} total fees`;

    opportunities.push({
      pair,
      buyExchange: cheapest.exchange,
      sellExchange: expensive.exchange,
      buyPrice: cheapest.price,
      sellPrice: expensive.price,
      spreadPercent: Math.round(spreadPercent * 1000) / 1000,
      buyFee,
      sellFee,
      withdrawalFee,
      networkFee,
      totalFees: totalFees + returnTransferFee,
      netProfitPercent: Math.round(netProfitPercent * 1000) / 1000,
      netProfitUsd: Math.round(netAfterReturn * 100) / 100,
      tradeAmount,
      profitable,
      feeBreakdown,
    });
  }

  opportunities.sort((a, b) => b.netProfitUsd - a.netProfitUsd);
  return opportunities;
}

async function logCC(configId: number, userId: string, logType: string, message: string, data?: any) {
  try {
    await db.insert(commandCenterLogs).values({ configId, userId, logType, message, data: data || null });
  } catch {}
}

async function trackPriceOutcome(snapshot: PriceSnapshot) {
  const delays = [
    { minutes: 5, field: 'priceAfter5m', profitField: 'profitPotential5m' },
    { minutes: 15, field: 'priceAfter15m', profitField: 'profitPotential15m' },
    { minutes: 30, field: 'priceAfter30m', profitField: 'profitPotential30m' },
    { minutes: 60, field: 'priceAfter60m', profitField: 'profitPotential60m' },
  ];

  const outcome: PriceOutcome = {
    pair: snapshot.pair,
    userId: snapshot.userId,
    priceAtSignal: snapshot.priceAtSignal,
    priceAfter5m: null,
    priceAfter15m: null,
    priceAfter30m: null,
    priceAfter60m: null,
    profitPotential5m: null,
    profitPotential15m: null,
    profitPotential30m: null,
    profitPotential60m: null,
    score: snapshot.score,
    botType: snapshot.botType,
    condition: snapshot.condition,
    timestamp: snapshot.timestamp,
  };

  if (priceOutcomes.length >= MAX_OUTCOMES) {
    priceOutcomes.splice(0, 500);
  }
  priceOutcomes.push(outcome);
  const outcomeIdx = priceOutcomes.length - 1;

  for (const delay of delays) {
    setTimeout(async () => {
      try {
        const tickerUrl = snapshot.exchange === 'binanceus'
          ? `https://api.binance.us/api/v3/ticker/price?symbol=${snapshot.pair.replace('/', '')}`
          : `https://data-api.binance.vision/api/v3/ticker/price?symbol=${snapshot.pair.replace('/', '')}`;
        const res = await fetch(tickerUrl);
        if (res.ok) {
          const data = await res.json();
          const currentPrice = parseFloat(data.price);
          const profitPercent = ((currentPrice - snapshot.priceAtSignal) / snapshot.priceAtSignal) * 100;

          if (outcomeIdx < priceOutcomes.length && priceOutcomes[outcomeIdx]?.pair === snapshot.pair) {
            (priceOutcomes[outcomeIdx] as any)[delay.field] = currentPrice;
            (priceOutcomes[outcomeIdx] as any)[delay.profitField] = Math.round(profitPercent * 100) / 100;
          }

          await logCC(snapshot.configId, snapshot.userId, 'price_track',
            `${snapshot.pair} @ ${delay.minutes}m: $${currentPrice.toFixed(6)} (${profitPercent >= 0 ? '+' : ''}${profitPercent.toFixed(2)}% from signal price $${snapshot.priceAtSignal.toFixed(6)})`,
            {
              pair: snapshot.pair,
              minutesAfter: delay.minutes,
              priceAtSignal: snapshot.priceAtSignal,
              priceNow: currentPrice,
              profitPercent: Math.round(profitPercent * 100) / 100,
              score: snapshot.score,
              botType: snapshot.botType,
              condition: snapshot.condition,
            }
          );
        }
      } catch {}
    }, delay.minutes * 60 * 1000);
  }
}

function computeAnalytics(userId?: string): any {
  const filtered = userId ? priceOutcomes.filter(o => o.userId === userId) : priceOutcomes;
  const outcomes = filtered.filter(o => o.profitPotential5m !== null);
  if (outcomes.length === 0) {
    return {
      totalSignals: filtered.length,
      completedTracking: 0,
      avgProfitPotential5m: null,
      avgProfitPotential15m: null,
      avgProfitPotential30m: null,
      avgProfitPotential60m: null,
      winRate5m: null,
      winRate15m: null,
      winRate30m: null,
      winRate60m: null,
      bestSignal: null,
      worstSignal: null,
      byBotType: {},
      byMarketCondition: {},
      byScoreRange: {},
      recentOutcomes: [],
    };
  }

  const avg = (arr: (number | null)[]): number | null => {
    const valid = arr.filter((v): v is number => v !== null);
    return valid.length > 0 ? Math.round((valid.reduce((s, v) => s + v, 0) / valid.length) * 100) / 100 : null;
  };

  const winRate = (arr: (number | null)[]): number | null => {
    const valid = arr.filter((v): v is number => v !== null);
    return valid.length > 0 ? Math.round((valid.filter(v => v > 0).length / valid.length) * 10000) / 100 : null;
  };

  const byBotType: Record<string, any> = {};
  const byCondition: Record<string, any> = {};
  const byScore: Record<string, any> = { '90-100': [], '80-89': [], '70-79': [], '60-69': [], 'below-60': [] };

  for (const o of outcomes) {
    if (!byBotType[o.botType]) byBotType[o.botType] = [];
    byBotType[o.botType].push(o);

    if (!byCondition[o.condition]) byCondition[o.condition] = [];
    byCondition[o.condition].push(o);

    if (o.score >= 90) byScore['90-100'].push(o);
    else if (o.score >= 80) byScore['80-89'].push(o);
    else if (o.score >= 70) byScore['70-79'].push(o);
    else if (o.score >= 60) byScore['60-69'].push(o);
    else byScore['below-60'].push(o);
  }

  const summarizeGroup = (group: PriceOutcome[]) => ({
    count: group.length,
    avgProfit5m: avg(group.map(o => o.profitPotential5m)),
    avgProfit15m: avg(group.map(o => o.profitPotential15m)),
    avgProfit30m: avg(group.map(o => o.profitPotential30m)),
    avgProfit60m: avg(group.map(o => o.profitPotential60m)),
    winRate5m: winRate(group.map(o => o.profitPotential5m)),
    winRate15m: winRate(group.map(o => o.profitPotential15m)),
    winRate30m: winRate(group.map(o => o.profitPotential30m)),
    winRate60m: winRate(group.map(o => o.profitPotential60m)),
  });

  const allProfits5m = outcomes.map(o => o.profitPotential5m);
  const allProfits15m = outcomes.map(o => o.profitPotential15m);
  const allProfits30m = outcomes.map(o => o.profitPotential30m);
  const allProfits60m = outcomes.map(o => o.profitPotential60m);

  const completedFull = outcomes.filter(o => o.profitPotential60m !== null);
  const best = completedFull.length > 0 ? completedFull.reduce((a, b) => (b.profitPotential60m || 0) > (a.profitPotential60m || 0) ? b : a) : null;
  const worst = completedFull.length > 0 ? completedFull.reduce((a, b) => (b.profitPotential60m || 0) < (a.profitPotential60m || 0) ? b : a) : null;

  const byBotTypeSummary: Record<string, any> = {};
  for (const [type, group] of Object.entries(byBotType)) {
    byBotTypeSummary[type] = summarizeGroup(group as PriceOutcome[]);
  }

  const byConditionSummary: Record<string, any> = {};
  for (const [cond, group] of Object.entries(byCondition)) {
    byConditionSummary[cond] = summarizeGroup(group as PriceOutcome[]);
  }

  const byScoreSummary: Record<string, any> = {};
  for (const [range, group] of Object.entries(byScore)) {
    if ((group as PriceOutcome[]).length > 0) {
      byScoreSummary[range] = summarizeGroup(group as PriceOutcome[]);
    }
  }

  return {
    totalSignals: filtered.length,
    completedTracking: outcomes.length,
    avgProfitPotential5m: avg(allProfits5m),
    avgProfitPotential15m: avg(allProfits15m),
    avgProfitPotential30m: avg(allProfits30m),
    avgProfitPotential60m: avg(allProfits60m),
    winRate5m: winRate(allProfits5m),
    winRate15m: winRate(allProfits15m),
    winRate30m: winRate(allProfits30m),
    winRate60m: winRate(allProfits60m),
    bestSignal: best ? { pair: best.pair, score: best.score, profit60m: best.profitPotential60m, botType: best.botType } : null,
    worstSignal: worst ? { pair: worst.pair, score: worst.score, profit60m: worst.profitPotential60m, botType: worst.botType } : null,
    byBotType: byBotTypeSummary,
    byMarketCondition: byConditionSummary,
    byScoreRange: byScoreSummary,
    recentOutcomes: priceOutcomes.slice(-20).reverse(),
  };
}

async function fetchTopMovers(exchange: string): Promise<CoinOpportunity[]> {
  const cacheKey = `movers_${exchange}`;
  const cached = scanCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < 15000) return cached.data;

  const opportunities: CoinOpportunity[] = [];

  try {
    const tickerUrl = exchange === 'binanceus'
      ? 'https://api.binance.us/api/v3/ticker/24hr'
      : 'https://data-api.binance.vision/api/v3/ticker/24hr';

    const res = await globalThis.fetch(tickerUrl, { signal: AbortSignal.timeout(10000) });
    if (!res.ok) throw new Error(`Ticker fetch failed: ${res.status}`);

    const tickers = (await res.json()) as any[];

    const minVolume = (exchange === 'binance' || exchange === 'binanceus') ? 100000 : 500000;
    const usdtPairs = tickers
      .filter((t: any) => t.symbol?.endsWith('USDT') && parseFloat(t.quoteVolume) > minVolume && parseFloat(t.lastPrice) > 0.0001)
      .sort((a: any, b: any) => parseFloat(b.quoteVolume) - parseFloat(a.quoteVolume));

    for (const t of usdtPairs) {
      const price = parseFloat(t.lastPrice);
      const change24h = parseFloat(t.priceChangePercent);
      const high = parseFloat(t.highPrice);
      const low = parseFloat(t.lowPrice);
      const volume = parseFloat(t.quoteVolume);
      const baseAsset = t.symbol.replace('USDT', '');

      const volatility = low > 0 ? ((high - low) / low) * 100 : 0;

      let momentumScore = 0;
      if (change24h > 5) momentumScore = 20;
      else if (change24h > 2) momentumScore = 15;
      else if (change24h > 0) momentumScore = 10;
      else if (change24h > -2) momentumScore = 5;

      let volumeScore = 0;
      if (volume > 500000000) volumeScore = 20;
      else if (volume > 100000000) volumeScore = 15;
      else if (volume > 10000000) volumeScore = 10;
      else if (volume > 1000000) volumeScore = 5;

      let volatilityScore = 0;
      if (volatility >= 3 && volatility <= 15) volatilityScore = 20;
      else if (volatility >= 1.5 && volatility < 3) volatilityScore = 12;
      else if (volatility > 15 && volatility <= 25) volatilityScore = 8;
      else volatilityScore = 3;

      const priceVsRange = high > low ? (price - low) / (high - low) : 0.5;
      let positionScore = 0;
      if (priceVsRange < 0.3) positionScore = 15;
      else if (priceVsRange < 0.5) positionScore = 10;
      else if (priceVsRange > 0.8) positionScore = 5;
      else positionScore = 8;

      let trendScore = 0;
      const trendDirection = change24h > 2 ? 'bullish' : change24h < -2 ? 'bearish' : 'neutral';
      if (trendDirection === 'bullish' && priceVsRange < 0.7) trendScore = 15;
      else if (trendDirection === 'bullish') trendScore = 10;
      else if (trendDirection === 'neutral') trendScore = 5;
      else if (trendDirection === 'bearish') trendScore = -15;

      const rsiEstimate = 30 + (priceVsRange * 40) + (change24h > 0 ? 10 : -5);

      let regimeAdj = 0;
      if (_cachedMarketRegime) {
        const r = _cachedMarketRegime.regime;
        if (r === 'crash') regimeAdj = trendDirection === 'bearish' ? -20 : (trendDirection === 'bullish' ? -5 : -15);
        else if (r === 'bear') regimeAdj = trendDirection === 'bearish' ? -15 : (trendDirection === 'bullish' ? 0 : -8);
        else if (r === 'bull') regimeAdj = trendDirection === 'bullish' ? 5 : 0;
      }

      const score = Math.min(100, Math.max(0,
        momentumScore + volumeScore + volatilityScore + positionScore + trendScore + regimeAdj +
        (rsiEstimate > 40 && rsiEstimate < 70 ? 10 : 0)
      ));

      let reason = '';
      if (score >= 80) reason = 'Strong momentum with high volume and favorable position';
      else if (score >= 60) reason = 'Good momentum and volume with moderate opportunity';
      else if (score >= 40) reason = 'Moderate opportunity, watching for breakout';
      else reason = 'Low opportunity score';

      opportunities.push({
        pair: `${baseAsset}/USDT`,
        baseAsset,
        quoteAsset: 'USDT',
        score: Math.round(score),
        price,
        change1h: change24h / 6,
        change24h,
        volume24h: volume,
        volatility: Math.round(volatility * 100) / 100,
        momentum: momentumScore,
        rsiEstimate: Math.round(rsiEstimate),
        trendDirection: trendDirection as 'bullish' | 'bearish' | 'neutral',
        reason,
      });
    }

    for (const t of usdtPairs) {
      const sym = t.symbol.replace('USDT', '');
      const change5m = parseFloat(t.priceChangePercent || '0');
      const vol = parseFloat(t.quoteVolume || '0');
      const price = parseFloat(t.lastPrice || '0');
      const prevClose = parseFloat(t.prevClosePrice || '0');
      const instantChange = prevClose > 0 ? ((price - prevClose) / prevClose) * 100 : 0;

      if (instantChange > 3 && vol > 200000) {
        const existing = opportunities.find(o => o.baseAsset === sym);
        if (existing) {
          existing.score = Math.min(100, existing.score + 15);
          existing.reason = `SPIKE DETECTED: +${instantChange.toFixed(1)}% sudden move | ${existing.reason}`;
        }
      }
    }

    opportunities.sort((a, b) => b.score - a.score);

    const topSymbols = opportunities.slice(0, 150).map(o => o.pair.replace('/', ''));
    try {
      const profiles = await analyzeTopCoins(topSymbols, 5);
      for (const op of opportunities.slice(0, 150)) {
        const sym = op.pair.replace('/', '');
        const ta = profiles.get(sym);
        if (!ta) continue;

        op.technicalProfile = ta;
        op.rsi14 = ta.rsi14;
        op.rsiEstimate = Math.round(ta.rsi14);
        op.macdCrossover = ta.macdCrossover;
        op.emaCrossover = ta.emaCrossover;
        op.adx14 = ta.adx14;
        op.trendStrength = ta.trendStrength;
        op.bollingerPosition = ta.bollingerPosition;
        op.atrPercent = ta.atrPercent;
        op.supportLevel = ta.supportLevel;
        op.resistanceLevel = ta.resistanceLevel;
        op.meanReversionSignal = ta.meanReversionSignal;
        op.breakoutSignal = ta.breakoutSignal;
        op.recommendation = ta.recommendation;
        op.taConfidence = ta.confidence;
        op.volumeProfile = ta.volumeProfile;

        op.multiTimeframeTrend = ta.multiTimeframeTrend;
        op.multiTimeframeAlignment = ta.multiTimeframeAlignment;
        op.buyVolumePressure = ta.buyVolumePressure;
        op.sellVolumePressure = ta.sellVolumePressure;
        op.overallVolumeBias = ta.overallVolumeBias;
        op.marketCap = ta.marketCap;
        op.marketCapRank = ta.marketCapRank;
        op.volume24hUsd = ta.volume24hUsd;
        op.tf1mTrend = ta.timeframes?.tf1m?.trend;
        op.tf5mTrend = ta.timeframes?.tf5m?.trend;
        op.tf1hTrend = ta.timeframes?.tf1h?.trend;
        op.tf24hTrend = ta.timeframes?.tf24h?.trend;

        if (ta.multiTimeframeTrend === 'strong_buy' || ta.multiTimeframeTrend === 'buy') op.trendDirection = 'bullish';
        else if (ta.multiTimeframeTrend === 'strong_sell' || ta.multiTimeframeTrend === 'sell') op.trendDirection = 'bearish';
        else if (ta.trendDirection30d === 'strong_bullish' || ta.trendDirection30d === 'bullish') op.trendDirection = 'bullish';
        else if (ta.trendDirection30d === 'strong_bearish' || ta.trendDirection30d === 'bearish') op.trendDirection = 'bearish';
        else op.trendDirection = 'neutral';

        let taScore = ta.overallScore;
        if (ta.macdCrossover === 'bullish') taScore += 5;
        if (ta.emaCrossover === 'golden_cross') taScore += 8;
        if (ta.emaCrossover === 'death_cross') taScore -= 8;
        if (ta.breakoutSignal === 'bullish_breakout') taScore += 10;
        if (ta.breakoutSignal === 'bearish_breakdown') taScore -= 10;
        if (ta.meanReversionSignal === 'oversold_bounce') taScore += 7;
        if (ta.rsi14 > 80) taScore -= 15;
        if (ta.rsi14 < 20) taScore += 5;
        if (ta.adx14 > 30 && ta.plusDI > ta.minusDI) taScore += 5;

        if (ta.multiTimeframeTrend === 'strong_sell') taScore -= 30;
        else if (ta.multiTimeframeTrend === 'sell') taScore -= 18;
        else if (ta.multiTimeframeTrend === 'neutral') taScore -= 5;
        if (ta.overallVolumeBias === 'strong_selling') taScore -= 12;
        else if (ta.overallVolumeBias === 'strong_buying') taScore += 8;
        if (ta.multiTimeframeAlignment > 80 && (ta.multiTimeframeTrend === 'strong_buy' || ta.multiTimeframeTrend === 'buy')) taScore += 5;

        if (ta.trendDirection30d === 'strong_bearish' || ta.trendDirection30d === 'bearish') taScore -= 15;
        if (ta.timeframes?.tf1h?.trend === 'sell' || ta.timeframes?.tf1h?.trend === 'strong_sell') taScore -= 10;

        if (ta.marketCapRank === 'micro') taScore -= 5;

        const rawBlended = op.score * 0.3 + taScore * 0.7;
        const blendedScore = Number.isFinite(rawBlended) ? Math.round(Math.max(0, Math.min(100, rawBlended))) : op.score;
        op.score = blendedScore;
        op.momentum = Number.isFinite(ta.momentumScore) ? ta.momentumScore : op.momentum;

        const mtfLabel = `MTF:${ta.multiTimeframeTrend}(${ta.multiTimeframeAlignment}% aligned)`;
        const volBiasLabel = `VolBias:${ta.overallVolumeBias}(buy:${ta.buyVolumePressure?.toFixed(0)}%)`;
        const mcapLabel = ta.marketCapRank ? `MCap:${ta.marketCapRank}` : '';
        const tfBreakdown = `1m:${ta.timeframes?.tf1m?.trend} 5m:${ta.timeframes?.tf5m?.trend} 1h:${ta.timeframes?.tf1h?.trend} 24h:${ta.timeframes?.tf24h?.trend} 30d:${ta.trendDirection30d}`;

        if (blendedScore >= 80) op.reason = `Strong buy — ${ta.recommendation} | ${mtfLabel} | ${volBiasLabel} | RSI ${ta.rsi14.toFixed(0)}, ADX ${ta.adx14.toFixed(0)}, MACD ${ta.macdCrossover} | ${mcapLabel}`;
        else if (blendedScore >= 65) op.reason = `Buy signal — ${ta.recommendation} | ${mtfLabel} | ${volBiasLabel} | ${tfBreakdown}`;
        else if (blendedScore >= 50) op.reason = `Watch — ${mtfLabel} | ${volBiasLabel} | RSI ${ta.rsi14.toFixed(0)}, ${ta.trendStrength} trend | ${mcapLabel}`;
        else op.reason = `Weak — ${mtfLabel} | ${volBiasLabel} | ${tfBreakdown} | conf ${ta.confidence}%`;
      }

      opportunities.sort((a, b) => b.score - a.score);
      ccLog(`ADMIE™ enriched ${profiles.size}/${topSymbols.length} coins — Multi-timeframe (30d/24h/1h/5m/1m) + buy/sell volume + market cap analysis (${opportunities.length} total scanned)`);
    } catch (taErr: any) {
      ccLog(`ADMIE™ enrichment failed (using ticker-only scoring): ${taErr.message}`);
    }

    if (exchange === 'kraken') {
      try {
        const krakenRes = await globalThis.fetch('https://api.kraken.com/0/public/Ticker', { signal: AbortSignal.timeout(10000) });
        if (krakenRes.ok) {
          const krakenData = (await krakenRes.json()) as any;
          const krakenTickers = krakenData?.result || {};
          const existingBases = new Set(opportunities.map(o => o.baseAsset));

          const krakenAliases: Record<string, string> = {
            XXBT: 'BTC', XBT: 'BTC', XETH: 'ETH', XXRP: 'XRP', XLTC: 'LTC',
            XXLM: 'XLM', XDOGE: 'DOGE', XDG: 'DOGE', XXDG: 'DOGE', XXMR: 'XMR',
            XZEC: 'ZEC', XETC: 'ETC', XREP: 'REP', XMLN: 'MLN',
          };

          for (const [pairName, ticker] of Object.entries(krakenTickers)) {
            const t = ticker as any;
            const isUsd = pairName.endsWith('USD') && !pairName.endsWith('USDT') && !pairName.endsWith('AUSD') && !pairName.endsWith('BUSD');
            const isUsdt = pairName.endsWith('USDT');
            if (!isUsd && !isUsdt) continue;

            const quote = isUsdt ? 'USDT' : 'USD';
            let rawBase = pairName.replace(/USDT$/, '').replace(/USD$/, '');
            if (rawBase.startsWith('Z') && rawBase.length === 4) rawBase = rawBase.substring(1);
            const base = krakenAliases[rawBase] || rawBase;

            if (existingBases.has(base)) continue;
            if (base.length > 10 || base.length < 2) continue;

            const price = parseFloat(t.c?.[0] || '0');
            const volume24h = parseFloat(t.v?.[1] || '0') * price;
            const high = parseFloat(t.h?.[1] || '0');
            const low = parseFloat(t.l?.[1] || '0');
            const open = parseFloat(t.o || '0');

            if (price <= 0 || volume24h < 50000) continue;

            const change24h = open > 0 ? ((price - open) / open) * 100 : 0;
            const volatility = low > 0 ? ((high - low) / low) * 100 : 0;

            let momentumScore = 0;
            if (change24h > 5) momentumScore = 20;
            else if (change24h > 2) momentumScore = 15;
            else if (change24h > 0) momentumScore = 10;
            else if (change24h > -2) momentumScore = 5;

            let volumeScore = 0;
            if (volume24h > 50000000) volumeScore = 20;
            else if (volume24h > 10000000) volumeScore = 15;
            else if (volume24h > 1000000) volumeScore = 10;
            else if (volume24h > 100000) volumeScore = 5;

            let volatilityScore = 0;
            if (volatility >= 3 && volatility <= 15) volatilityScore = 20;
            else if (volatility >= 1.5 && volatility < 3) volatilityScore = 12;
            else if (volatility > 15 && volatility <= 25) volatilityScore = 8;
            else volatilityScore = 3;

            const priceVsRange = high > low ? (price - low) / (high - low) : 0.5;
            let positionScore = priceVsRange < 0.3 ? 15 : priceVsRange < 0.5 ? 10 : priceVsRange > 0.8 ? 5 : 8;

            const trendDirection = change24h > 2 ? 'bullish' : change24h < -2 ? 'bearish' : 'neutral';
            let trendScore = 0;
            if (trendDirection === 'bullish' && priceVsRange < 0.7) trendScore = 15;
            else if (trendDirection === 'bullish') trendScore = 10;
            else if (trendDirection === 'neutral') trendScore = 5;
            else if (trendDirection === 'bearish') trendScore = -15;

            let regimeAdj = 0;
            if (_cachedMarketRegime) {
              const r = _cachedMarketRegime.regime;
              if (r === 'crash') regimeAdj = trendDirection === 'bearish' ? -20 : -5;
              else if (r === 'bear') regimeAdj = trendDirection === 'bearish' ? -15 : 0;
              else if (r === 'bull') regimeAdj = trendDirection === 'bullish' ? 5 : 0;
            }

            const rsiEstimate = 30 + (priceVsRange * 40) + (change24h > 0 ? 10 : -5);
            const score = Math.min(100, Math.max(0,
              momentumScore + volumeScore + volatilityScore + positionScore + trendScore + regimeAdj +
              (rsiEstimate > 40 && rsiEstimate < 70 ? 10 : 0)
            ));

            let reason = '';
            if (score >= 80) reason = `Strong momentum on Kraken (${quote}) with favorable position`;
            else if (score >= 60) reason = `Good opportunity on Kraken (${quote})`;
            else if (score >= 40) reason = `Moderate opportunity on Kraken (${quote})`;
            else reason = `Low score on Kraken (${quote})`;

            existingBases.add(base);
            opportunities.push({
              pair: `${base}/${quote}`,
              baseAsset: base,
              quoteAsset: quote,
              score: Math.round(score),
              price,
              change1h: change24h / 6,
              change24h,
              volume24h,
              volatility: Math.round(volatility * 100) / 100,
              momentum: momentumScore,
              rsiEstimate: Math.round(rsiEstimate),
              trendDirection: trendDirection as 'bullish' | 'bearish' | 'neutral',
              reason,
            });
          }

          opportunities.sort((a, b) => b.score - a.score);
          const krakenOnly = opportunities.filter(o => o.quoteAsset === 'USD');
          if (krakenOnly.length > 0) {
            ccLog(`Kraken native scan added ${krakenOnly.length} USD-quoted pairs (PEPE, PUMP, etc.) to opportunity pool`);
          }
        }
      } catch (krakenErr: any) {
        ccLog(`Kraken native scan failed (using Binance data only): ${krakenErr.message}`);
      }
    }

    if (exchange !== 'binance' && exchange !== 'binanceus') {
      const { pairs: exchangePairs, bases: exchangeBases } = await getExchangeValidPairsForCC(exchange);
      if (exchangeBases.size > 0) {
        const filtered = opportunities.filter(o => {
          const resolved = resolveExchangePairName(o.pair, exchange, exchangePairs);
          return resolved !== null;
        });
        ccLog(`${exchange} pair filter: ${opportunities.length} scanned → ${filtered.length} tradeable on ${exchange}`);
        scanCache.set(cacheKey, { data: filtered, ts: Date.now() });
        return filtered;
      }
    }

    scanCache.set(cacheKey, { data: opportunities, ts: Date.now() });
  } catch (err: any) {
    ccLog(`Market scan error: ${err.message}`);
  }

  return opportunities;
}

async function evaluateBotPerformance(config: any): Promise<ManagedBotPerformance[]> {
  const results: ManagedBotPerformance[] = [];
  const managedIds: number[] = config.managedBotIds || [];

  for (const botId of managedIds) {
    try {
      const [bot] = await db.select().from(serverBots)
        .where(and(eq(serverBots.id, botId), eq(serverBots.userId, config.userId)))
        .limit(1);

      if (!bot) continue;

      const position = getBotPosition(botId);
      const now = Date.now();
      const holdTimeMinutes = position ? (now - position.entryTime) / 60000 : 0;
      const lastTradeMinutesAgo = bot.lastTradeAt ? (now - new Date(bot.lastTradeAt).getTime()) / 60000 : 999;
      const pnl = bot.totalPnl || 0;
      const investment = bot.settings?.investment || 100;
      const pnlPercent = investment > 0 ? (pnl / investment) * 100 : 0;
      const signalStrength = bot.lastSignalData?.strength || 0;

      const settings = config.settings || {};
      const underperformMinutes = settings.underperformMinutes || 15;
      const profitLockThreshold = settings.profitLockThreshold || 3;

      const isAggressive = (config.settings?.riskLevel === 'aggressive') || (config.settings?.aggressiveRotation === true);
      const isUnderperforming =
        (pnlPercent < -2 && holdTimeMinutes > underperformMinutes * 2) ||
        (pnlPercent < profitLockThreshold && lastTradeMinutesAgo > underperformMinutes * 4) ||
        (signalStrength < 20 && holdTimeMinutes > underperformMinutes * 2) ||
        (isAggressive && pnlPercent < -1 && holdTimeMinutes > underperformMinutes) ||
        (isAggressive && pnlPercent < -3 && holdTimeMinutes > 10);

      results.push({
        botId,
        pair: bot.pair,
        type: bot.type || 'signal',
        status: bot.status,
        pnl,
        pnlPercent: Math.round(pnlPercent * 100) / 100,
        holdTimeMinutes: Math.round(holdTimeMinutes),
        lastTradeMinutesAgo: Math.round(lastTradeMinutesAgo),
        isUnderperforming,
        signalStrength,
        investment,
      });
    } catch {}
  }

  return results;
}

function selectTechAndFilters(opportunity: CoinOpportunity, riskLevel: string): { tech: string[]; filters: string[] } {
  if (riskLevel === 'aggressive') {
    return { tech: [...ALL_TECH], filters: [...ALL_FILTERS] };
  }

  const tech = ['ance', 'ance2', 'acm'];
  const filters = ['order_flow', 'wyckoff', 'entropy'];

  if (opportunity.volatility > 10) {
    tech.push('qfrm');
    filters.push('absorption', 'delta_divergence');
  }
  if (opportunity.volume24h > 100000000) {
    if (!tech.includes('bif')) tech.push('bif');
    if (!filters.includes('fair_value_gap')) filters.push('fair_value_gap');
  }
  if (opportunity.trendDirection !== 'neutral') {
    if (!tech.includes('sbpe')) tech.push('sbpe');
    if (!filters.includes('fractal_energy')) filters.push('fractal_energy');
    if (!filters.includes('hurst')) filters.push('hurst');
  }

  if (riskLevel === 'conservative') {
    return { tech: tech.slice(0, 4), filters: filters.slice(0, 4) };
  }

  return { tech, filters };
}

function computeBotSettings(opportunity: CoinOpportunity, riskLevel: string, investment: number, quickProfitMode?: boolean) {
  let takeProfit = 5;
  let stopLoss = 3;
  let trailingPercent = 2;
  let cooldownSeconds = 60;
  let signalThreshold = 65;

  const atr = opportunity.atrPercent || opportunity.volatility;
  const rsi = opportunity.rsi14 || opportunity.rsiEstimate;
  const adx = opportunity.adx14 || 25;

  const roundTripFeePct = 0.6;
  const feeFloor = roundTripFeePct * 3;

  if (quickProfitMode) {
    takeProfit = Math.max(feeFloor, Math.min(8, atr * 1.2));
    stopLoss = Math.max(feeFloor * 0.8, Math.min(5, atr * 0.8));
    trailingPercent = Math.max(1.2, atr * 0.5);
    cooldownSeconds = 30;
    signalThreshold = adx > 30 ? 45 : 50;
  } else if (riskLevel === 'aggressive') {
    takeProfit = Math.max(feeFloor * 1.5, Math.min(15, atr * 2.5));
    stopLoss = Math.max(feeFloor, Math.min(8, atr * 1.5));
    trailingPercent = Math.max(2, atr * 0.8);
    cooldownSeconds = 45;
    signalThreshold = adx > 30 ? 50 : 55;
  } else if (riskLevel === 'conservative') {
    takeProfit = Math.max(feeFloor * 2, Math.min(10, atr * 2));
    stopLoss = Math.max(feeFloor, Math.min(5, atr * 1.2));
    trailingPercent = Math.max(1.5, atr * 0.6);
    cooldownSeconds = 120;
    signalThreshold = adx > 30 ? 70 : 75;
  } else {
    takeProfit = Math.max(feeFloor * 1.5, Math.min(12, atr * 2));
    stopLoss = Math.max(feeFloor, Math.min(6, atr * 1.2));
    trailingPercent = Math.max(1.5, atr * 0.6);
    cooldownSeconds = 60;
    signalThreshold = adx > 30 ? 60 : 65;
  }

  takeProfit = Math.round(takeProfit * 10) / 10;
  stopLoss = Math.round(stopLoss * 10) / 10;
  trailingPercent = Math.round(trailingPercent * 10) / 10;

  return {
    investment,
    takeProfit,
    stopLoss,
    trailingPercent,
    cooldownSeconds,
    signalThreshold,
    paperTrading: false,
    ocoEnabled: true,
    autoCooldown: true,
    autoTakeProfit: true,
    autoStopLoss: true,
    autoThreshold: true,
    autoTrailing: true,
    maxDailyTrades: 0,
    maxDailyLossPercent: 5,
    positionSizePercent: 100,
    signalSource: 'ai',
    bridgeFusion: true,
    bridgeFusionMode: 'auto',
    _managedByCC: true,
  };
}

async function createManagedBot(
  config: any,
  opportunity: CoinOpportunity
): Promise<number | null> {
  try {
    if (await isLockedPairModeActive(config.userId)) {
      ccLog(`LOCKED MODE — blocked creation of ${opportunity.pair} bot, only locked-pair bots allowed`);
      return null;
    }
    const settings = config.settings || {};
    const investment = settings.investmentPerBot || 100;
    const riskLevel = settings.riskLevel || 'moderate';
    const { tech, filters } = selectTechAndFilters(opportunity, riskLevel);
    const botSettings = computeBotSettings(opportunity, riskLevel, investment, settings.quickProfitMode === true);
    botSettings.paperTrading = settings.paperTrading === true;

    const botTypeSelection = selectBotType(opportunity);
    const botType = botTypeSelection.type;
    const marketCondition = botTypeSelection.condition;

    if (botType === 'grid' || botType === 'infinity_grid' || botType === 'reverse_grid') {
      (botSettings as any).gridLevels = opportunity.volatility > 8 ? 20 : 10;
      (botSettings as any).gridSpacing = opportunity.volatility > 8 ? 1.5 : 1.0;
    }
    if (botType === 'dca') {
      (botSettings as any).safetyOrderCount = riskLevel === 'aggressive' ? 8 : riskLevel === 'conservative' ? 3 : 5;
      (botSettings as any).safetyOrderDeviation = 2;
      (botSettings as any).safetyOrderMultiplier = 1.5;
    }
    if (botType === 'trailing_stop') {
      (botSettings as any).trailingPercent = opportunity.volatility > 10 ? 5 : 3;
      (botSettings as any).activationPercent = 1;
    }

    const botData = {
      userId: config.userId,
      name: `AACC™: ${opportunity.baseAsset} ${botType.toUpperCase()} (${opportunity.score}%)`,
      type: botType,
      pair: opportunity.pair,
      exchange: config.exchange,
      status: 'running',
      settings: { ...botSettings, _botTypeRationale: botTypeSelection.rationale, _marketCondition: marketCondition },
      activeTech: tech,
      activeFilters: filters,
    };

    const [newBot] = await db.insert(serverBots).values(botData).returning();

    if (newBot) {
      const managedIds = [...(config.managedBotIds || []), newBot.id];
      await db.update(commandCenterConfigs)
        .set({ managedBotIds: managedIds, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));

      await logCC(config.id, config.userId, 'create',
        `Created ${botType.toUpperCase()} bot for ${opportunity.pair} (score: ${opportunity.score}%) — ${botTypeSelection.rationale}`,
        { botId: newBot.id, pair: opportunity.pair, score: opportunity.score, botType, marketCondition, rationale: botTypeSelection.rationale, tech, filters, settings: botSettings }
      );

      ccLog(`Created managed ${botType} bot #${newBot.id} for ${opportunity.pair} (score ${opportunity.score}, condition: ${marketCondition})`);
      return newBot.id;
    }
  } catch (err: any) {
    ccLog(`Failed to create bot: ${err.message}`);
    await logCC(config.id, config.userId, 'error', `Failed to create bot for ${opportunity.pair}: ${err.message}`);
  }
  return null;
}

async function createManagedBotWithAllocation(
  config: any,
  opportunity: CoinOpportunity,
  allocation?: SmartAllocation | null
): Promise<number | null> {
  if (!allocation) return createManagedBot(config, opportunity);

  try {
    const settings = config.settings || {};
    const riskLevel = settings.riskLevel || 'moderate';
    const { tech, filters } = selectTechAndFilters(opportunity, riskLevel);
    const botSettings = computeBotSettings(opportunity, riskLevel, allocation.investment, settings.quickProfitMode === true);
    botSettings.paperTrading = settings.paperTrading === true;
    (botSettings as any).investment = allocation.investment;

    const botType = allocation.botType;
    const botTypeSelection = selectBotType(opportunity);

    if (botType === 'grid' || botType === 'infinity_grid' || botType === 'reverse_grid') {
      const gridLevels = allocation.gridLevels || (opportunity.volatility > 8 ? 20 : 10);
      (botSettings as any).gridLevels = gridLevels;
      (botSettings as any).gridSpacing = opportunity.volatility > 8 ? 1.5 : 1.0;
      (botSettings as any).perGridAmount = allocation.perGridAmount || (allocation.investment / gridLevels);
    }
    if (botType === 'dca') {
      const safetyOrders = allocation.safetyOrders || (riskLevel === 'aggressive' ? 8 : riskLevel === 'conservative' ? 3 : 5);
      (botSettings as any).safetyOrderCount = safetyOrders;
      (botSettings as any).safetyOrderDeviation = 2;
      (botSettings as any).safetyOrderMultiplier = 1.5;
      (botSettings as any).perOrderAmount = allocation.perOrderAmount;
      (botSettings as any).baseOrderAmount = allocation.investment * 0.3;
    }
    if (botType === 'trailing_stop') {
      (botSettings as any).trailingPercent = opportunity.volatility > 10 ? 5 : 3;
      (botSettings as any).activationPercent = 1;
    }

    const botData = {
      userId: config.userId,
      name: `AACC™: ${opportunity.baseAsset} ${botType.toUpperCase()} $${allocation.investment} (${opportunity.score}%)`,
      type: botType,
      pair: opportunity.pair,
      exchange: config.exchange,
      status: 'running',
      settings: {
        ...botSettings,
        _botTypeRationale: botTypeSelection.rationale,
        _marketCondition: botTypeSelection.condition,
        _smartAllocation: allocation.allocationReason,
        _managedByCC: true,
      },
      activeTech: tech,
      activeFilters: filters,
    };

    const [newBot] = await db.insert(serverBots).values(botData).returning();

    if (newBot) {
      const managedIds = [...(config.managedBotIds || []), newBot.id];
      await db.update(commandCenterConfigs)
        .set({ managedBotIds: managedIds, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));

      await logCC(config.id, config.userId, 'create',
        `Smart-created ${botType.toUpperCase()} bot for ${opportunity.pair} | $${allocation.investment} | ${allocation.allocationReason} | Score: ${opportunity.score}%`,
        { botId: newBot.id, pair: opportunity.pair, score: opportunity.score, botType, allocation, tech, filters, settings: botSettings }
      );

      ccLog(`Smart-created ${botType} bot #${newBot.id} for ${opportunity.pair} ($${allocation.investment})`);
      return newBot.id;
    }
  } catch (err: any) {
    ccLog(`Failed to smart-create bot: ${err.message}`);
    await logCC(config.id, config.userId, 'error', `Failed to smart-create bot for ${opportunity.pair}: ${err.message}`);
  }
  return null;
}

const BLOCKCHAIN_MAP: Record<string, string> = {
  BTC: 'bitcoin',
  ETH: 'ethereum', LINK: 'ethereum', UNI: 'ethereum', AAVE: 'ethereum', MKR: 'ethereum',
  COMP: 'ethereum', SNX: 'ethereum', CRV: 'ethereum', SUSHI: 'ethereum', YFI: 'ethereum',
  MANA: 'ethereum', SAND: 'ethereum', AXS: 'ethereum', ENJ: 'ethereum', LRC: 'ethereum',
  BAT: 'ethereum', GRT: 'ethereum', '1INCH': 'ethereum', ENS: 'ethereum', APE: 'ethereum',
  SHIB: 'ethereum', PEPE: 'ethereum', DYDX: 'ethereum', IMX: 'ethereum', BLUR: 'ethereum',
  LDO: 'ethereum', RPL: 'ethereum', SSV: 'ethereum', FXS: 'ethereum', CVX: 'ethereum',
  MATIC: 'ethereum', WBTC: 'ethereum', DAI: 'ethereum', USDC: 'ethereum',
  PENDLE: 'ethereum', ENA: 'ethereum', ETHFI: 'ethereum', ONDO: 'ethereum',
  SOL: 'solana', RAY: 'solana', SRM: 'solana', MNGO: 'solana', ORCA: 'solana',
  BONK: 'solana', WIF: 'solana', JTO: 'solana', JUP: 'solana', PYTH: 'solana',
  RENDER: 'solana', HNT: 'solana', MOBILE: 'solana', W: 'solana', TENSOR: 'solana',
  BNB: 'bsc', CAKE: 'bsc', XVS: 'bsc', BAKE: 'bsc', ALPACA: 'bsc',
  TWT: 'bsc', FLOKI: 'bsc', ID: 'bsc',
  ADA: 'cardano',
  DOT: 'polkadot', KSM: 'polkadot', GLMR: 'polkadot', ASTR: 'polkadot',
  AVAX: 'avalanche', JOE: 'avalanche', GMX: 'avalanche', COQINU: 'avalanche',
  ATOM: 'cosmos', OSMO: 'cosmos', INJ: 'cosmos', TIA: 'cosmos', SEI: 'cosmos',
  FET: 'cosmos', SCRT: 'cosmos', AKT: 'cosmos', RUNE: 'cosmos',
  NEAR: 'near', AURORA: 'near',
  FTM: 'fantom', BEETS: 'fantom',
  ALGO: 'algorand',
  XRP: 'xrpl',
  DOGE: 'dogecoin',
  LTC: 'litecoin',
  TRX: 'tron', SUN: 'tron', JST: 'tron', BTT: 'tron', WIN: 'tron',
  XLM: 'stellar',
  HBAR: 'hedera',
  ICP: 'icp',
  FIL: 'filecoin',
  ARB: 'arbitrum', MAGIC: 'arbitrum', RDNT: 'arbitrum', GRAIL: 'arbitrum',
  OP: 'optimism', VELO: 'optimism', KWENTA: 'optimism',
  SUI: 'sui', CETUS: 'sui', NAVI: 'sui',
  APT: 'aptos',
  TON: 'ton', NOT: 'ton', DOGS: 'ton',
  EGLD: 'multiversx',
  VET: 'vechain',
  EOS: 'eos',
  XTZ: 'tezos',
  FLOW: 'flow',
  MINA: 'mina',
  KAVA: 'kava',
  ZIL: 'zilliqa',
  ONE: 'harmony',
  CKB: 'nervos',
  STX: 'stacks', ALEX: 'stacks',
  ROSE: 'oasis',
  ZEC: 'zcash',
  THETA: 'theta', TFUEL: 'theta',
};

function extractBaseAsset(pair: string): string {
  return pair.replace(/\/.*$/, '').replace(/USDT$|BUSD$|USDC$|BTC$/, '');
}

function pairToSymbol(pair: string): string {
  return pair.replace('/', '');
}

function getBlockchain(pair: string): string | null {
  const baseAsset = extractBaseAsset(pair);
  return BLOCKCHAIN_MAP[baseAsset] || null;
}

function canDirectSwap(fromPair: string, toPair: string): { sameChain: boolean; chain: string | null; fromAsset: string; toAsset: string } {
  const fromAsset = extractBaseAsset(fromPair);
  const toAsset = extractBaseAsset(toPair);
  const fromChain = BLOCKCHAIN_MAP[fromAsset] || null;
  const toChain = BLOCKCHAIN_MAP[toAsset] || null;

  if (fromChain && toChain && fromChain === toChain && fromAsset !== toAsset) {
    return { sameChain: true, chain: fromChain, fromAsset, toAsset };
  }
  return { sameChain: false, chain: null, fromAsset, toAsset };
}

async function pauseManagedBot(config: any, botId: number, reason: string, targetPair?: string): Promise<{ success: boolean; releasedCapital: number; directSwap: boolean; swapInfo: string }> {
  try {
    const [bot] = await db.select().from(serverBots).where(eq(serverBots.id, botId)).limit(1);
    if (!bot) return { success: false, releasedCapital: 0, directSwap: false, swapInfo: '' };

    const position = getBotPosition(botId);
    let releasedCapital = 0;
    let sellInfo = '';
    let directSwap = false;
    let swapInfo = '';

    if (position) {
      const pair = bot.pair || '';
      const baseAsset = extractBaseAsset(pair);
      const symbol = pairToSymbol(pair);
      let currentPrice = 0;

      try {
        const tickerRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
        if (tickerRes.ok) {
          const ticker = await tickerRes.json();
          currentPrice = parseFloat(ticker.price);
        }
      } catch {}

      if (!currentPrice) currentPrice = position.entryPrice;

      const positionValue = currentPrice * position.quantity;
      const pnlPercent = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;
      const pnlAmount = (currentPrice - position.entryPrice) * position.quantity;

      const swapCheck = targetPair ? canDirectSwap(pair, targetPair) : { sameChain: false, chain: null, fromAsset: baseAsset, toAsset: '' };

      if (swapCheck.sameChain && targetPair) {
        directSwap = true;
        const targetSymbol = pairToSymbol(targetPair);
        let targetPrice = 0;
        try {
          const targetTickerRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${targetSymbol}`);
          if (targetTickerRes.ok) {
            const targetTicker = await targetTickerRes.json();
            targetPrice = parseFloat(targetTicker.price);
          }
        } catch {}

        const swapQuantity = targetPrice > 0 ? (positionValue / targetPrice) : 0;
        swapInfo = `Direct swap on ${swapCheck.chain} chain: ${position.quantity.toFixed(6)} ${swapCheck.fromAsset} → ${swapQuantity.toFixed(6)} ${swapCheck.toAsset} (skipping USDT fees)`;

        const settings = bot.settings as any || {};
        if (!settings.paperTrading) {
          const connections = await storage.getUserExchangeConnections(config.userId);
          const conn = connections.find((c: any) => c.exchangeName === bot.exchange && c.isActive);
          if (conn) {
            try {
              const apiKey = decryptApiKey(conn.apiKeyEncrypted);
              const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
              const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;
              await executeExchangeOrder(bot.exchange, apiKey, apiSecret, pair, 'SELL', position.quantity, passphrase);
              ccLog(`LIVE DIRECT SWAP step 1: Sold ${position.quantity} ${swapCheck.fromAsset} on ${bot.exchange}`);
              if (swapQuantity > 0) {
                await executeExchangeOrder(bot.exchange, apiKey, apiSecret, targetPair, 'BUY', swapQuantity, passphrase);
                ccLog(`LIVE DIRECT SWAP step 2 (${swapCheck.chain}): Bought ${swapQuantity} ${swapCheck.toAsset} on ${bot.exchange}`);
              }
            } catch (execErr: any) {
              ccLog(`Live direct swap failed for ${pair} → ${targetPair} on ${bot.exchange}: ${execErr.message}`);
            }
          }
        }

        releasedCapital = positionValue;
        sellInfo = ` | DIRECT SWAP (${swapCheck.chain} chain): ${position.quantity.toFixed(6)} ${swapCheck.fromAsset} → ${swapQuantity.toFixed(6)} ${swapCheck.toAsset} = $${positionValue.toFixed(2)} (${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(2)}%) — fees saved by staying on-chain`;

        await storage.createServerBotLog({
          botId, userId: config.userId, logType: 'trade',
          message: `[CC DIRECT SWAP] ${swapCheck.chain} chain: ${position.quantity.toFixed(6)} ${swapCheck.fromAsset} → ${swapQuantity.toFixed(6)} ${swapCheck.toAsset} | Value: $${positionValue.toFixed(2)} | P&L: $${pnlAmount.toFixed(2)} (${pnlPercent.toFixed(2)}%) | Fees saved by same-chain swap | ${reason}`,
          data: { fromAsset: swapCheck.fromAsset, toAsset: swapCheck.toAsset, chain: swapCheck.chain, price: currentPrice, targetPrice, quantity: position.quantity, swapQuantity, pnl: pnlAmount, pnlPercent, reason, capitalValue: positionValue, directSwap: true },
        });
      } else {
        const settings = bot.settings as any || {};
        if (!settings.paperTrading) {
          const connections = await storage.getUserExchangeConnections(config.userId);
          const conn = connections.find((c: any) => c.exchangeName === bot.exchange && c.isActive);
          if (conn) {
            try {
              const apiKey = decryptApiKey(conn.apiKeyEncrypted);
              const apiSecret = decryptApiKey(conn.apiSecretEncrypted);
              const passphrase = conn.passphraseEncrypted ? decryptApiKey(conn.passphraseEncrypted) : undefined;
              await executeExchangeOrder(bot.exchange, apiKey, apiSecret, pair, 'SELL', position.quantity, passphrase);
              ccLog(`LIVE SELL: ${position.quantity} ${pair} @ ~$${currentPrice} during rotation on ${bot.exchange}`);
            } catch (execErr: any) {
              ccLog(`Live sell failed for ${pair} on ${bot.exchange}: ${execErr.message}`);
            }
          }
        }

        const fromChain = getBlockchain(pair);
        const toChain = targetPair ? getBlockchain(targetPair) : null;
        const chainNote = fromChain && toChain ? ` (${fromChain} → ${toChain}, different chains)` : '';

        releasedCapital = positionValue;
        sellInfo = ` | Closed position: ${position.quantity.toFixed(6)} ${baseAsset} @ $${currentPrice.toFixed(4)} → USDT ($${positionValue.toFixed(2)}) → ${targetPair || 'new pair'}${chainNote} (${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(2)}%)`;

        await storage.createServerBotLog({
          botId, userId: config.userId, logType: 'trade',
          message: `[CC ROTATION] SELL ${position.quantity.toFixed(6)} ${pair} @ $${currentPrice.toFixed(4)} → USDT | P&L: $${pnlAmount.toFixed(2)} (${pnlPercent.toFixed(2)}%) | Capital released: $${positionValue.toFixed(2)}${chainNote} | ${reason}`,
          data: { price: currentPrice, quantity: position.quantity, pnl: pnlAmount, pnlPercent, reason, capitalReleased: positionValue, fromChain, toChain, directSwap: false },
        });
      }

      const { savePosition } = await import("./botEngine.js");
      await savePosition(botId, null);

      await storage.updateServerBot(botId, {
        totalTrades: (bot.totalTrades || 0) + 1,
        totalPnl: (bot.totalPnl || 0) + pnlAmount,
      });

      if (pnlAmount < 0 && bot.pair) {
        blacklistPair(bot.pair);
        ccLog(`Anti-churn: blacklisted ${bot.pair} for 30min after -$${Math.abs(pnlAmount).toFixed(2)} loss rotation`);
      }
    } else {
      releasedCapital = (bot.settings as any)?.investment || config.settings?.investmentPerBot || 100;
      sellInfo = ` | No open position, releasing allocated capital: $${releasedCapital.toFixed(2)}`;
    }

    await db.update(serverBots)
      .set({ status: 'paused', updatedAt: new Date() })
      .where(and(eq(serverBots.id, botId), eq(serverBots.userId, config.userId)));

    await logCC(config.id, config.userId, 'pause',
      `Paused bot #${botId} (${bot.pair || 'unknown'}) — ${reason}${sellInfo}`,
      { botId, pair: bot.pair, pnl: bot.totalPnl, reason, releasedCapital, hadPosition: !!position, directSwap, swapInfo }
    );

    ccLog(`Paused bot #${botId} — ${reason}${sellInfo}`);
    return { success: true, releasedCapital, directSwap, swapInfo };
  } catch (err: any) {
    ccLog(`Failed to pause bot #${botId}: ${err.message}`);
    return { success: false, releasedCapital: 0, directSwap: false, swapInfo: '' };
  }
}

async function runScanCycle(config: any) {
  const settings = config.settings || {};
  const minScore = settings.minOpportunityScore || 70;
  const maxBots = settings.maxManagedBots || 5;
  const rotationCooldown = (settings.rotationCooldownMinutes || 15) * 60000;
  const minHold = (settings.minHoldMinutes || 30) * 60000;
  const baseInvestmentPerBot = settings.investmentPerBot || 100;
  const totalCapital = settings.totalCapital || 1000;
  const currentAllocated = config.allocatedCapital || 0;
  const availableCapital = totalCapital - currentAllocated;

  const compoundGrowth = totalCapital > 160 ? totalCapital / 160 : 1;
  const investmentPerBot = settings.quickProfitMode
    ? Math.min(totalCapital / (settings.maxManagedBots || 5), baseInvestmentPerBot * compoundGrowth)
    : baseInvestmentPerBot;

  const marketRegimeData = await detectMarketRegime();
  const marketRegime = marketRegimeData.regime;
  const adaptiveMinScore = getAdaptiveMinScore(minScore, marketRegime);

  // Check if user has locked-pair bots — if so, Command Center must NOT deploy new bots
  const lockedBots = await db.select().from(serverBots).where(
    and(eq(serverBots.userId, config.userId), eq(serverBots.status, 'running'))
  );
  const hasLockedBots = lockedBots.some((b: any) => {
    const s = b.settings as any;
    return s?._lockedPair === true;
  });
  if (hasLockedBots) {
    ccLog(`LOCKED MODE — ${lockedBots.filter((b: any) => (b.settings as any)?._lockedPair).length} locked-pair bots active. Command Center will NOT deploy new bots or rotate capital. Only locked bots trade.`);
    return;
  }

  ccLog(`Scan cycle for user ${config.userId} on ${config.exchange} | Capital: $${availableCapital.toFixed(2)} available / $${totalCapital.toFixed(2)} total ($${currentAllocated.toFixed(2)} allocated) | Market: ${marketRegime.toUpperCase()} | Min score: ${adaptiveMinScore}`);

  let realBalance = 0;
  try {
    realBalance = await fetchExchangeBalanceForCC(config.userId, config.exchange);
    if (realBalance > 0 && Math.abs(realBalance - totalCapital) > 1) {
      ccLog(`Syncing totalCapital from ${config.exchange}: $${realBalance.toFixed(2)} (was $${totalCapital})`);
      const updatedSettings = { ...settings, totalCapital: realBalance };
      await db.update(commandCenterConfigs)
        .set({ settings: updatedSettings, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));
    }
  } catch (balErr: any) {
    ccLog(`Balance sync error for ${config.exchange}: ${balErr.message}`);
  }
  const effectiveCapital = realBalance > 0 ? realBalance : totalCapital;
  const effectiveAvailable = effectiveCapital - currentAllocated;

  if (effectiveAvailable < 0 && realBalance > 0) {
    ccLog(`Over-allocated: $${currentAllocated.toFixed(2)} allocated but only $${effectiveCapital.toFixed(2)} available — adjusting allocatedCapital to match real balance`);
    await db.update(commandCenterConfigs)
      .set({
        allocatedCapital: Math.max(0, realBalance),
        lastScanAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(commandCenterConfigs.id, config.id));
  }

  const opportunities = await fetchTopMovers(config.exchange);
  const topOpportunities = opportunities.slice(0, 100);

  await db.update(commandCenterConfigs)
    .set({
      currentOpportunities: topOpportunities.slice(0, 10),
      lastScanAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(commandCenterConfigs.id, config.id));

  const performance = await evaluateBotPerformance(config);
  const activeManagedBots = performance.filter(p => p.status === 'running');
  const underperformers = performance.filter(p => p.isUnderperforming && p.status === 'running');

  const pausedManagedBots = performance.filter(p => p.status === 'paused');
  if (pausedManagedBots.length > 0) {
    let releasedTotal = 0;
    const removableIds: number[] = [];
    for (const paused of pausedManagedBots) {
      const hasPosition = getBotPosition(paused.botId);
      if (hasPosition) {
        ccLog(`Paused bot #${paused.botId} (${paused.pair}) still has open position — keeping in managed list`);
        continue;
      }
      releasedTotal += paused.investment || 0;
      removableIds.push(paused.botId);
    }
    if (removableIds.length > 0) {
      const removeSet = new Set(removableIds);
      const updatedManagedIds = (config.managedBotIds || []).filter((id: number) => !removeSet.has(id));
      const currentAlloc = config.allocatedCapital || 0;
      const newAlloc = Math.max(0, currentAlloc - releasedTotal);
      for (const botId of removableIds) {
        try {
          await db.delete(serverBotLogs).where(eq(serverBotLogs.botId, botId));
          await db.delete(serverBots).where(eq(serverBots.id, botId));
        } catch {}
      }
      ccLog(`Deleted ${removableIds.length} paused bot(s) [#${removableIds.join(', #')}] — released $${releasedTotal.toFixed(2)} | allocated: $${currentAlloc.toFixed(2)} → $${newAlloc.toFixed(2)}`);
      await db.update(commandCenterConfigs)
        .set({ allocatedCapital: newAlloc, managedBotIds: updatedManagedIds, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));
      config.allocatedCapital = newAlloc;
      config.managedBotIds = updatedManagedIds;
    }
  }

  try {
    const allUserBots = await db.select({ id: serverBots.id, status: serverBots.status, pair: serverBots.pair })
      .from(serverBots)
      .where(eq(serverBots.userId, config.userId));
    const managedSet = new Set(config.managedBotIds || []);
    const orphanedBots = allUserBots.filter(b => 
      b.status !== 'running' && !managedSet.has(b.id) && !getBotPosition(b.id)
    );
    if (orphanedBots.length > 0) {
      for (const orphan of orphanedBots) {
        try {
          await db.delete(serverBotLogs).where(eq(serverBotLogs.botId, orphan.id));
          await db.delete(serverBots).where(eq(serverBots.id, orphan.id));
        } catch {}
      }
      ccLog(`Cleanup: deleted ${orphanedBots.length} orphaned bot(s) [#${orphanedBots.map(b => b.id).join(', #')}]`);
    }
  } catch (cleanupErr: any) {
    ccLog(`Cleanup error: ${cleanupErr.message}`);
  }

  try {
    await detectAndRecoverOrphanedAssets(config);
  } catch (orphanErr: any) {
    ccLog(`Orphan asset detection error: ${orphanErr.message}`);
  }

  if (activeManagedBots.length > 0 && (marketRegime === 'bear' || marketRegime === 'crash')) {
    const bearStopLoss = marketRegime === 'crash' ? 3.0 : 4.5;
    const bearTakeProfit = marketRegime === 'crash' ? 4.0 : 6.0;

    for (const perf of activeManagedBots) {
      const position = getBotPosition(perf.botId);
      if (!position) continue;

      const [bot] = await db.select().from(serverBots)
        .where(and(eq(serverBots.id, perf.botId), eq(serverBots.userId, config.userId)))
        .limit(1);
      if (!bot) continue;

      const currentSettings = (bot.settings as any) || {};
      const currentSL = currentSettings.stopLoss || 6;

      if (currentSL > bearStopLoss) {
        const updatedSettings = { ...currentSettings, stopLoss: bearStopLoss, takeProfit: Math.min(currentSettings.takeProfit || 12, bearTakeProfit) };
        await db.update(serverBots)
          .set({ settings: updatedSettings, updatedAt: new Date() })
          .where(eq(serverBots.id, perf.botId));

        ccLog(`[${marketRegime.toUpperCase()} PROTECTION] Tightened bot #${perf.botId} (${perf.pair}) stop loss: ${currentSL}% → ${bearStopLoss}% | TP: ${currentSettings.takeProfit || 12}% → ${Math.min(currentSettings.takeProfit || 12, bearTakeProfit)}%`);
      }

      const pnlPercent = position.entryPrice > 0
        ? ((position.currentPrice || position.entryPrice) - position.entryPrice) / position.entryPrice * 100
        : perf.pnlPercent;

      let currentPrice = 0;
      const symbol = pairToSymbol(perf.pair);
      try {
        const tickerRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
        if (tickerRes.ok) {
          const ticker = await tickerRes.json();
          currentPrice = parseFloat(ticker.price);
        }
      } catch {}
      if (!currentPrice) {
        try {
          const fallbackRes = await fetch(`https://api.binance.us/api/v3/ticker/price?symbol=${symbol}`);
          if (fallbackRes.ok) {
            const ticker = await fallbackRes.json();
            currentPrice = parseFloat(ticker.price);
          }
        } catch {}
      }

      const livePnlPercent = currentPrice > 0
        ? ((currentPrice - position.entryPrice) / position.entryPrice) * 100
        : pnlPercent;

      if (livePnlPercent <= -bearStopLoss) {
        ccLog(`[${marketRegime.toUpperCase()} STOP LOSS] Bot #${perf.botId} (${perf.pair}) at ${livePnlPercent.toFixed(2)}% loss — exceeds ${marketRegime} SL of -${bearStopLoss}% — force-selling to minimize losses`);

        const pauseResult = await pauseManagedBot(config, perf.botId,
          `${marketRegime.toUpperCase()} market stop loss: ${livePnlPercent.toFixed(2)}% loss exceeds adaptive SL of -${bearStopLoss}% | Entry: $${position.entryPrice.toFixed(6)} → Current: $${currentPrice > 0 ? currentPrice.toFixed(6) : 'unknown'}`
        );

        if (pauseResult.success) {
          const newAllocated = Math.max(0, (config.allocatedCapital || 0) - pauseResult.releasedCapital);
          const updatedManagedIds = (config.managedBotIds || []).filter((id: number) => id !== perf.botId);

          try {
            await db.delete(serverBotLogs).where(eq(serverBotLogs.botId, perf.botId));
            await db.delete(serverBots).where(eq(serverBots.id, perf.botId));
          } catch {}

          await db.update(commandCenterConfigs)
            .set({ allocatedCapital: newAllocated, managedBotIds: updatedManagedIds, updatedAt: new Date() })
            .where(eq(commandCenterConfigs.id, config.id));
          config.allocatedCapital = newAllocated;
          config.managedBotIds = updatedManagedIds;

          await logCC(config.id, config.userId, 'stop_loss',
            `${marketRegime.toUpperCase()} STOP LOSS: Force-sold bot #${perf.botId} (${perf.pair}) | Loss: ${livePnlPercent.toFixed(2)}% | Threshold: -${bearStopLoss}% | Capital released: $${pauseResult.releasedCapital.toFixed(2)} | Market: BTC ${marketRegimeData.btcChange.toFixed(2)}%, ETH ${marketRegimeData.ethChange.toFixed(2)}%`,
            { botId: perf.botId, pair: perf.pair, pnlPercent: livePnlPercent, stopLoss: bearStopLoss, regime: marketRegime, releasedCapital: pauseResult.releasedCapital, entryPrice: position.entryPrice, exitPrice: currentPrice }
          );

          addBlacklistedPair(perf.pair);
        }
      }
    }

    const recalcPerformance = await evaluateBotPerformance(config);
    const stillActive = recalcPerformance.filter(p => p.status === 'running');
    if (stillActive.length < activeManagedBots.length) {
      ccLog(`[${marketRegime.toUpperCase()} PROTECTION] Exited ${activeManagedBots.length - stillActive.length} position(s) — ${stillActive.length} remaining`);
    }
  }

  const performancePairs = new Set(performance.map(p => p.pair));
  const managedBotPairs = new Set<string>();
  if (config.managedBotIds && config.managedBotIds.length > 0) {
    const managedBots = await db.select({ pair: serverBots.pair })
      .from(serverBots)
      .where(inArray(serverBots.id, config.managedBotIds));
    for (const b of managedBots) managedBotPairs.add(b.pair);
  }
  const currentPairs = new Set([...performancePairs, ...managedBotPairs]);
  const bestNew = topOpportunities.filter(o => {
    if (o.score < adaptiveMinScore) return false;
    if (currentPairs.has(o.pair)) return false;
    if (isPairBlacklisted(o.pair)) return false;
    const botType = selectBotType(o, marketRegime);
    if (botType.type === 'skip') return false;
    return true;
  });
  const blacklisted = getBlacklistedPairs();
  if (blacklisted.length > 0) {
    ccLog(`Blacklisted pairs (${blacklisted.length}): ${blacklisted.map(b => `${b.pair} (${Math.round((b.expiresAt - Date.now()) / 60000)}m remaining)`).join(', ')}`);
  }

  let smartAllocations: any[] = [];

  const riskLevel = settings.riskLevel || 'moderate';
  const baseReserve = settings.reservePercent || 20;
  const reservePercent = marketRegime === 'crash' ? Math.max(baseReserve, 50)
    : marketRegime === 'bear' ? Math.max(baseReserve, 35)
    : Math.max(baseReserve, 25);
  const reserveAmount = effectiveCapital * (reservePercent / 100);
  const clampedAvailable = Math.max(0, effectiveAvailable - reserveAmount);

  const now = Date.now();
  const lastRotation = config.lastRotationAt ? new Date(config.lastRotationAt).getTime() : 0;
  const canRotate = (now - lastRotation) > rotationCooldown;

  const skippedBearish = topOpportunities.filter(o => {
    if (o.score < adaptiveMinScore || currentPairs.has(o.pair) || isPairBlacklisted(o.pair)) return false;
    const bt = selectBotType(o, marketRegime);
    return bt.type === 'skip';
  });
  if (skippedBearish.length > 0) {
    ccLog(`Filtered out ${skippedBearish.length} bearish coin(s) in ${marketRegime} market: ${skippedBearish.slice(0, 3).map(o => `${o.pair} (${o.trendDirection})`).join(', ')}`);
  }

  if (bestNew.length > 0) {
    const watchlistSummary = bestNew.slice(0, 5).map(o => {
      const bt = selectBotType(o, marketRegime);
      return `${o.pair} (score: ${o.score}%, ${bt.type}, ${o.trendDirection}, vol: ${o.volatility.toFixed(1)}%)`;
    }).join(' | ');
    ccLog(`Watchlist: ${bestNew.length} tradeable candidate(s) — ${watchlistSummary}`);
  } else if (topOpportunities.length > 0) {
    ccLog(`No coins pass ${marketRegime} market threshold (min score: ${adaptiveMinScore}) — ${topOpportunities.length} scanned, ${skippedBearish.length} bearish filtered, continuing to monitor`);
  }

  if (marketRegime === 'crash') {
    ccLog(`CRASH PROTECTION ACTIVE — market down >5%, halting new deployments, monitoring existing positions`);
    await logCC(config.id, config.userId, 'market_regime',
      `Crash protection: BTC ${marketRegimeData.btcChange > 0 ? '+' : ''}${marketRegimeData.btcChange.toFixed(2)}%, ETH ${marketRegimeData.ethChange > 0 ? '+' : ''}${marketRegimeData.ethChange.toFixed(2)}% — no new bots deployed`,
      { regime: marketRegime, btcChange: marketRegimeData.btcChange, ethChange: marketRegimeData.ethChange }
    );
  } else if (underperformers.length > 0 && bestNew.length > 0 && canRotate) {
    const worst = underperformers.sort((a, b) => a.pnlPercent - b.pnlPercent)[0];
    const holdTime = worst.holdTimeMinutes * 60000;

    if (holdTime >= minHold) {
      const bestOpportunity = bestNew[0];
      smartAllocations = calculateSmartAllocations(
        [bestOpportunity], clampedAvailable + (worst.investment || investmentPerBot), config.exchange, riskLevel, reservePercent
      );
      const smartAlloc = smartAllocations[0];
      const rotationInvestment = smartAlloc?.investment || investmentPerBot;

      const feeAnalysis = isRotationProfitable(
        config.exchange,
        rotationInvestment,
        worst.pnlPercent,
        bestOpportunity.score,
        bestOpportunity.volatility
      );

      ccLog(`Fee analysis for ${worst.pair} → ${bestOpportunity.pair}: ${feeAnalysis.reason}`);
      await logCC(config.id, config.userId, 'fee_analysis',
        `${worst.pair} → ${bestOpportunity.pair}: ${feeAnalysis.reason} | ${feeAnalysis.feeBreakdown}`,
        { from: worst.pair, to: bestOpportunity.pair, ...feeAnalysis, currentPnlPercent: worst.pnlPercent, newScore: bestOpportunity.score, volatility: bestOpportunity.volatility, smartAllocation: smartAlloc }
      );

      if (!feeAnalysis.profitable) {
        ccLog(`Skipping rotation ${worst.pair} → ${bestOpportunity.pair} — not profitable after fees`);
        await logCC(config.id, config.userId, 'rotation_skipped',
          `Rotation skipped: ${worst.pair} → ${bestOpportunity.pair} | ${feeAnalysis.reason}`,
          { from: worst, to: bestOpportunity, feeAnalysis }
        );
      } else {
        const pauseResult = await pauseManagedBot(config, worst.botId, `Underperforming (PnL: ${worst.pnlPercent}%), rotating to ${bestOpportunity.pair} | Fee-cleared: ${feeAnalysis.feeBreakdown}`, bestOpportunity.pair);

        const newAllocated = Math.max(0, (config.allocatedCapital || 0) - pauseResult.releasedCapital);
        const originalInvestment = worst.investment || investmentPerBot;
        const profitFromRotation = pauseResult.releasedCapital - originalInvestment;

        const updatedSettings = { ...settings };
        if (profitFromRotation > 0) {
          updatedSettings.totalCapital = (updatedSettings.totalCapital || totalCapital) + profitFromRotation;
          updatedSettings.compoundedProfit = (updatedSettings.compoundedProfit || 0) + profitFromRotation;
          ccLog(`COMPOUND: +$${profitFromRotation.toFixed(2)} profit reinvested | Total capital: $${updatedSettings.totalCapital.toFixed(2)} (started: $160, compounded: $${updatedSettings.compoundedProfit.toFixed(2)})`);
        }

        await db.update(commandCenterConfigs)
          .set({ allocatedCapital: newAllocated, settings: updatedSettings, updatedAt: new Date() })
          .where(eq(commandCenterConfigs.id, config.id));
        config.allocatedCapital = newAllocated;
        config.settings = updatedSettings;

        const routeDesc = pauseResult.directSwap
          ? `${pauseResult.swapInfo}`
          : `Sold ${worst.pair} → USDT ($${pauseResult.releasedCapital.toFixed(2)}) → Buying ${bestOpportunity.pair}`;

        await logCC(config.id, config.userId, 'rotation',
          `Rotating: ${worst.pair} → ${bestOpportunity.pair} | ${routeDesc} (score: ${bestOpportunity.score}%) | Capital freed: $${pauseResult.releasedCapital.toFixed(2)} | ${feeAnalysis.feeBreakdown}`,
          { from: worst, to: bestOpportunity, releasedCapital: pauseResult.releasedCapital, directSwap: pauseResult.directSwap, swapInfo: pauseResult.swapInfo, feeAnalysis, smartAllocation: smartAlloc }
        );

        const newBotId = await createManagedBotWithAllocation(config, bestOpportunity, smartAlloc);

        if (newBotId) {
          const allocAfterCreate = (config.allocatedCapital || 0) + rotationInvestment;
          const managedIds = (config.managedBotIds || []).filter((id: number) => id !== worst.botId);
          managedIds.push(newBotId);

          try {
            await db.delete(serverBotLogs).where(eq(serverBotLogs.botId, worst.botId));
            await db.delete(serverBots).where(eq(serverBots.id, worst.botId));
            ccLog(`Deleted rotated-out bot #${worst.botId} (${worst.pair})`);
          } catch {}

          await db.update(commandCenterConfigs)
            .set({
              managedBotIds: managedIds,
              allocatedCapital: allocAfterCreate,
              totalRotations: (config.totalRotations || 0) + 1,
              lastRotationAt: new Date(),
              updatedAt: new Date(),
            })
            .where(eq(commandCenterConfigs.id, config.id));
          config.allocatedCapital = allocAfterCreate;
        }
      }
    }
  } else if (activeManagedBots.length < maxBots && bestNew.length > 0 && clampedAvailable >= investmentPerBot) {
    const bestOpportunity = bestNew[0];
    smartAllocations = calculateSmartAllocations(
      [bestOpportunity], clampedAvailable, config.exchange, riskLevel, reservePercent
    );
    const smartAlloc = smartAllocations[0];
    const deployAmount = smartAlloc?.investment || investmentPerBot;

    if (clampedAvailable >= deployAmount) {
      ccLog(`Deploying to #1 opportunity: ${bestOpportunity.pair} (score: ${bestOpportunity.score}%) — ${activeManagedBots.length}/${maxBots} bots active, $${clampedAvailable.toFixed(2)} available`);

      const newBotId = smartAlloc
        ? await createManagedBotWithAllocation(config, bestOpportunity, smartAlloc)
        : await createManagedBot(config, bestOpportunity);

      if (newBotId) {
        const allocAfterCreate = (config.allocatedCapital || 0) + deployAmount;
        const managedIds = [...(config.managedBotIds || []), newBotId];
        await db.update(commandCenterConfigs)
          .set({
            managedBotIds: managedIds,
            allocatedCapital: allocAfterCreate,
            updatedAt: new Date(),
          })
          .where(eq(commandCenterConfigs.id, config.id));
        config.allocatedCapital = allocAfterCreate;
        config.managedBotIds = managedIds;

        await logCC(config.id, config.userId, 'capital',
          `Deployed $${deployAmount.toFixed(2)} to ${(smartAlloc?.botType || 'signal').toUpperCase()} bot for ${bestOpportunity.pair} (score: ${bestOpportunity.score}%) | ${activeManagedBots.length + 1}/${maxBots} bots active | Available: $${(effectiveCapital - allocAfterCreate).toFixed(2)} / $${effectiveCapital.toFixed(2)}`,
          { invested: deployAmount, allocated: allocAfterCreate, available: effectiveCapital - allocAfterCreate, total: effectiveCapital, pair: bestOpportunity.pair, allocation: smartAlloc }
        );
      }
    }
  } else if (activeManagedBots.length >= maxBots && bestNew.length > 0) {
    ccLog(`All ${maxBots} bot slots filled — watching ${bestNew.length} candidate(s), waiting for active bots to take profit before deploying`);
  } else if (clampedAvailable < investmentPerBot && bestNew.length > 0) {
    ccLog(`Capital fully allocated ($${currentAllocated.toFixed(2)}/$${effectiveCapital.toFixed(2)}) — scanning continues, waiting for bots to take profit | Next best: ${bestNew[0].pair} (score: ${bestNew[0].score}%)`);
  }

  const connectedExchanges = await getConnectedExchanges(config.userId);
  if (connectedExchanges.length >= 2 && settings.enableArbitrage !== false) {
    try {
      const arbOpps = await scanCrossExchangeArbitrage(config.userId, connectedExchanges, effectiveAvailable);
      const profitableArbs = arbOpps.filter(a => a.profitable);
      if (profitableArbs.length > 0) {
        const bestArb = profitableArbs[0];
        await logCC(config.id, config.userId, 'arbitrage',
          `Cross-exchange arbitrage found: ${bestArb.pair} — Buy on ${bestArb.buyExchange} @ $${bestArb.buyPrice.toFixed(2)}, Sell on ${bestArb.sellExchange} @ $${bestArb.sellPrice.toFixed(2)} | Spread: ${bestArb.spreadPercent}% | Net profit: $${bestArb.netProfitUsd} (${bestArb.netProfitPercent}%) after ALL fees | ${bestArb.feeBreakdown}`,
          { arbitrage: bestArb, allOpportunities: profitableArbs.slice(0, 5), connectedExchanges }
        );
      }
    } catch (arbErr: any) {
      ccLog(`Arbitrage scan error: ${arbErr.message}`);
    }
  }

  const marketCondition = detectMarketCondition(topOpportunities);
  const totalManagedPnl = performance.reduce((s, p) => s + p.pnl, 0);
  const totalManagedInvestment = performance.length * (settings.investmentPerBot || 100);
  const overallPnlPercent = totalManagedInvestment > 0 ? (totalManagedPnl / totalManagedInvestment) * 100 : 0;

  const topScoredOpportunities = topOpportunities.slice(0, 5).map(o => {
    const botSelection = selectBotType(o);
    return {
      pair: o.pair,
      score: o.score,
      price: o.price,
      change1h: o.change1h,
      change24h: o.change24h,
      volume24h: o.volume24h,
      volatility: o.volatility,
      momentum: o.momentum,
      rsiEstimate: o.rsiEstimate,
      trendDirection: o.trendDirection,
      suggestedBotType: botSelection.type,
      marketCondition: botSelection.condition,
      rationale: botSelection.rationale,
      rsi14: o.rsi14,
      macdCrossover: o.macdCrossover,
      emaCrossover: o.emaCrossover,
      adx14: o.adx14,
      trendStrength: o.trendStrength,
      bollingerPosition: o.bollingerPosition,
      atrPercent: o.atrPercent,
      meanReversionSignal: o.meanReversionSignal,
      breakoutSignal: o.breakoutSignal,
      recommendation: o.recommendation,
      taConfidence: o.taConfidence,
      volumeProfile: o.volumeProfile,
      multiTimeframeTrend: o.multiTimeframeTrend,
      multiTimeframeAlignment: o.multiTimeframeAlignment,
      overallVolumeBias: o.overallVolumeBias,
      buyVolumePressure: o.buyVolumePressure,
      sellVolumePressure: o.sellVolumePressure,
      marketCapRank: o.marketCapRank,
      volume24hUsd: o.volume24hUsd,
      tf1mTrend: o.tf1mTrend,
      tf5mTrend: o.tf5mTrend,
      tf1hTrend: o.tf1hTrend,
      tf24hTrend: o.tf24hTrend,
    };
  });

  for (const op of topOpportunities.slice(0, 3)) {
    const botSelection = selectBotType(op);
    trackPriceOutcome({
      pair: op.pair,
      priceAtSignal: op.price,
      score: op.score,
      botType: botSelection.type,
      condition: botSelection.condition,
      timestamp: Date.now(),
      exchange: config.exchange,
      configId: config.id,
      userId: config.userId,
    });
  }

  await logCC(config.id, config.userId, 'scan',
    `Scanned ${opportunities.length} coins — Top: ${topOpportunities[0]?.pair || 'none'} (${topOpportunities[0]?.score || 0}%) — Market: ${marketCondition} — Active: ${activeManagedBots.length}/${maxBots} — Fleet PnL: $${totalManagedPnl.toFixed(2)} (${overallPnlPercent.toFixed(2)}%) — Underperforming: ${underperformers.length} — Balance: $${effectiveCapital.toFixed(2)}`,
    {
      totalScanned: opportunities.length,
      topOpportunities: topScoredOpportunities,
      smartAllocations: smartAllocations.length > 0 ? smartAllocations : undefined,
      marketCondition,
      activeBots: activeManagedBots.length,
      maxBots,
      underperformers: underperformers.length,
      canRotate,
      fleetPnl: Math.round(totalManagedPnl * 100) / 100,
      fleetPnlPercent: Math.round(overallPnlPercent * 100) / 100,
      fleetInvestment: totalManagedInvestment,
      effectiveCapital,
      exchangeBalance: realBalance > 0 ? realBalance : undefined,
      reservePercent,
      botPerformance: performance.map(p => ({
        botId: p.botId,
        pair: p.pair,
        type: p.type,
        pnl: p.pnl,
        pnlPercent: p.pnlPercent,
        holdTime: p.holdTimeMinutes,
        isUnderperforming: p.isUnderperforming,
        signalStrength: p.signalStrength,
      })),
      signalsTracked: priceOutcomes.length,
    }
  );
}

setOnBotPairFailed((pair: string, error?: string) => {
  if (error?.includes('trading restricted')) {
    geoRestrictedPairs.add(pair);
    ccLog(`GEO-RESTRICTED: ${pair} permanently blacklisted — trading restricted in your jurisdiction`);
  } else {
    blacklistPair(pair);
  }
});

export async function startCommandCenter(userId: string): Promise<any> {
  const [existing] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  let config = existing;
  if (!config) {
    const [newConfig] = await db.insert(commandCenterConfigs)
      .values({ userId, isActive: true })
      .returning();
    config = newConfig;
  } else {
    await db.update(commandCenterConfigs)
      .set({ isActive: true, updatedAt: new Date() })
      .where(eq(commandCenterConfigs.id, config.id));
    config = { ...config, isActive: true };
  }

  if (activeEngines.has(userId)) {
    clearInterval(activeEngines.get(userId)!);
  }

  const scanInterval = (config.settings as any)?.scanIntervalSeconds || 30;

  const interval = setInterval(async () => {
    try {
      const [fresh] = await db.select().from(commandCenterConfigs)
        .where(eq(commandCenterConfigs.id, config.id)).limit(1);
      if (!fresh || !fresh.isActive) {
        clearInterval(interval);
        activeEngines.delete(userId);
        ccLog(`Stopped for user ${userId} (deactivated)`);
        return;
      }
      await runScanCycle(fresh);
    } catch (err: any) {
      ccLog(`Scan error for user ${userId}: ${err.message}`);
    }
  }, scanInterval * 1000);

  activeEngines.set(userId, interval);

  await logCC(config.id, userId, 'start', 'Command Center activated');
  ccLog(`Started for user ${userId} (scan every ${scanInterval}s)`);

  runScanCycle(config).catch(() => {});

  return config;
}

export async function stopCommandCenter(userId: string): Promise<boolean> {
  if (activeEngines.has(userId)) {
    clearInterval(activeEngines.get(userId)!);
    activeEngines.delete(userId);
    ccLog(`Cleared active engine interval for user ${userId}`);
  }

  const configs = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId));

  for (const config of configs) {
    if (config.isActive) {
      await db.update(commandCenterConfigs)
        .set({ isActive: false, updatedAt: new Date() })
        .where(eq(commandCenterConfigs.id, config.id));
      await logCC(config.id, userId, 'stop', 'Command Center deactivated');
    }
  }

  ccLog(`Stopped for user ${userId} (${configs.length} config(s) deactivated)`);
  return true;
}

export async function getCommandCenterStatus(userId: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) {
    return { active: false, config: null, managedBots: [], opportunities: [], performance: [] };
  }

  const performance = await evaluateBotPerformance(config);
  const isEngineRunning = activeEngines.has(userId);
  const opportunities: CoinOpportunity[] = config.currentOpportunities || [];
  const marketCondition = detectMarketCondition(opportunities);
  const botTypesActive = [...new Set(performance.map(b => b.type))];

  const connectedExchanges = await getConnectedExchanges(userId);

  return {
    active: config.isActive && isEngineRunning,
    config: {
      id: config.id,
      exchange: config.exchange,
      settings: config.settings,
      allocatedCapital: config.allocatedCapital || 0,
      totalRotations: config.totalRotations,
      totalProfit: config.totalProfit,
      lastScanAt: config.lastScanAt,
      lastRotationAt: config.lastRotationAt,
    },
    managedBots: performance,
    opportunities,
    marketCondition,
    botTypesActive,
    botEngineRunning: isBotEngineRunning(),
    connectedExchanges,
    multiExchangeEnabled: connectedExchanges.length >= 2,
    arbitrageEnabled: connectedExchanges.length >= 2,
  };
}

export async function getCommandCenterLogs(userId: string, limit = 50) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) return [];

  return db.select().from(commandCenterLogs)
    .where(eq(commandCenterLogs.configId, config.id))
    .orderBy(desc(commandCenterLogs.createdAt))
    .limit(limit);
}

export async function updateCommandCenterSettings(userId: string, updates: any) {
  let [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) {
    const defaultSettings = {
      scanIntervalSeconds: 60,
      minOpportunityScore: 75,
      maxManagedBots: 5,
      rotationCooldownMinutes: 5,
      minHoldMinutes: 10,
      riskLevel: 'moderate',
      investmentPerBot: 100,
      profitLockThreshold: 2,
      underperformMinutes: 15,
      autoTechSelection: true,
      paperTrading: false,
      ...updates,
    };
    const [newConfig] = await db.insert(commandCenterConfigs).values({
      userId,
      exchange: 'binance',
      isActive: false,
      settings: defaultSettings,
      managedBotIds: [],
      currentOpportunities: [],
      totalRotations: 0,
      totalProfit: 0,
    }).returning();
    await logCC(newConfig.id, userId, 'settings', 'Command center configured with initial settings');
    return defaultSettings;
  }

  const currentSettings = (config.settings || {}) as any;
  const newSettings = { ...currentSettings, ...updates };

  await db.update(commandCenterConfigs)
    .set({ settings: newSettings, updatedAt: new Date() })
    .where(eq(commandCenterConfigs.id, config.id));

  if (config.isActive && activeEngines.has(userId)) {
    clearInterval(activeEngines.get(userId)!);
    const scanInterval = newSettings.scanIntervalSeconds || 30;
    const interval = setInterval(async () => {
      try {
        const [fresh] = await db.select().from(commandCenterConfigs)
          .where(eq(commandCenterConfigs.id, config.id)).limit(1);
        if (!fresh || !fresh.isActive) {
          clearInterval(interval);
          activeEngines.delete(userId);
          return;
        }
        await runScanCycle(fresh);
      } catch {}
    }, scanInterval * 1000);
    activeEngines.set(userId, interval);
  }

  await logCC(config.id, userId, 'settings', 'Settings updated', updates);
  return newSettings;
}

export async function updateCommandCenterExchange(userId: string, exchange: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) throw new Error('Command center not configured');

  await db.update(commandCenterConfigs)
    .set({ exchange, updatedAt: new Date() })
    .where(eq(commandCenterConfigs.id, config.id));

  scanCache.delete(`movers_${config.exchange}`);

  await logCC(config.id, userId, 'settings', `Exchange changed to ${exchange}`);
}

export async function recommendInvestmentPerBot(userId: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) throw new Error('Command center not configured');

  const settings = (config.settings || {}) as any;
  const totalCapital = settings.totalCapital || 1000;
  const maxBots = settings.maxManagedBots || 5;
  const exchange = config.exchange || 'binance';
  const allocated = config.allocatedCapital || 0;
  const available = Math.max(0, totalCapital - allocated);

  const fees = getExchangeFees(exchange);
  const takerRate = fees.taker;
  const roundTripRate = takerRate * 2;

  const minProfitableInvestment = roundTripRate > 0 ? Math.ceil((roundTripRate * 2) / roundTripRate * 10) : 10;

  const scenarios: Array<{
    investmentPerBot: number;
    feesPerTrade: number;
    feePercent: number;
    effectiveBots: number;
    capitalUtilization: number;
    breakEvenMove: number;
    recommendation: string;
    score: number;
  }> = [];

  const testAmounts = [5, 10, 15, 20, 25, 50, 75, 100, 150, 200, 250, 500];

  for (const amount of testAmounts) {
    if (amount > available) continue;

    const feesPerTrade = amount * roundTripRate;
    const feePercent = roundTripRate * 100;
    const effectiveBots = Math.min(maxBots, Math.floor(available / amount));
    if (effectiveBots < 1) continue;

    const capitalUtilization = (effectiveBots * amount) / totalCapital * 100;
    const breakEvenMove = feePercent;

    let score = 0;
    score += Math.min(30, capitalUtilization * 0.3);
    score += effectiveBots >= 3 ? 20 : effectiveBots * 7;
    score += feePercent < 0.5 ? 25 : feePercent < 1 ? 15 : feePercent < 2 ? 5 : 0;
    score += amount >= 20 ? 15 : amount >= 10 ? 10 : 5;
    if (capitalUtilization > 90) score -= 10;
    if (effectiveBots < 2) score -= 10;

    let recommendation = '';
    if (feesPerTrade > amount * 0.03) {
      recommendation = 'Fees eat >3% per trade — increase investment or find lower-fee exchange';
    } else if (feesPerTrade > amount * 0.015) {
      recommendation = 'Moderate fees — each trade needs >' + breakEvenMove.toFixed(2) + '% move to profit';
    } else {
      recommendation = 'Good fee ratio — trades only need >' + breakEvenMove.toFixed(2) + '% move to profit';
    }

    scenarios.push({
      investmentPerBot: amount,
      feesPerTrade: Math.round(feesPerTrade * 10000) / 10000,
      feePercent: Math.round(feePercent * 1000) / 1000,
      effectiveBots,
      capitalUtilization: Math.round(capitalUtilization * 10) / 10,
      breakEvenMove: Math.round(breakEvenMove * 1000) / 1000,
      recommendation,
      score: Math.round(score),
    });
  }

  scenarios.sort((a, b) => b.score - a.score);
  const optimal = scenarios[0] || null;

  return {
    exchange: fees.name,
    exchangeFees: { maker: fees.maker, taker: fees.taker, roundTrip: roundTripRate },
    totalCapital,
    availableCapital: available,
    allocatedCapital: allocated,
    maxBots,
    minProfitableInvestment,
    optimal,
    scenarios,
  };
}

export async function getCommandCenterOpportunities(userId: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  const exchange = config?.exchange || 'binance';
  const opportunities = await fetchTopMovers(exchange);
  return opportunities.slice(0, 50);
}

export async function getCommandCenterAnalytics(userId: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) return { error: 'No command center configured' };

  const analytics = computeAnalytics(userId);

  const scanLogs = await db.select().from(commandCenterLogs)
    .where(and(eq(commandCenterLogs.configId, config.id), eq(commandCenterLogs.logType, 'scan')))
    .orderBy(desc(commandCenterLogs.createdAt))
    .limit(100);

  const rotationLogs = await db.select().from(commandCenterLogs)
    .where(and(eq(commandCenterLogs.configId, config.id), eq(commandCenterLogs.logType, 'rotation')))
    .orderBy(desc(commandCenterLogs.createdAt))
    .limit(50);

  const createLogs = await db.select().from(commandCenterLogs)
    .where(and(eq(commandCenterLogs.configId, config.id), eq(commandCenterLogs.logType, 'create')))
    .orderBy(desc(commandCenterLogs.createdAt))
    .limit(50);

  const priceTrackLogs = await db.select().from(commandCenterLogs)
    .where(and(eq(commandCenterLogs.configId, config.id), eq(commandCenterLogs.logType, 'price_track')))
    .orderBy(desc(commandCenterLogs.createdAt))
    .limit(200);

  const profitableSignals = priceTrackLogs.filter(l => l.data && (l.data as any).profitPercent > 0).length;
  const unprofitableSignals = priceTrackLogs.filter(l => l.data && (l.data as any).profitPercent <= 0).length;
  const avgSignalProfit = priceTrackLogs.length > 0
    ? priceTrackLogs.reduce((s, l) => s + ((l.data as any)?.profitPercent || 0), 0) / priceTrackLogs.length
    : 0;

  return {
    config: {
      exchange: config.exchange,
      totalRotations: config.totalRotations,
      totalProfit: config.totalProfit,
      isActive: config.isActive,
      createdAt: config.createdAt,
      lastScanAt: config.lastScanAt,
    },
    liveAnalytics: analytics,
    dbAnalytics: {
      totalScans: scanLogs.length,
      totalRotations: rotationLogs.length,
      totalBotsCreated: createLogs.length,
      totalPriceTracked: priceTrackLogs.length,
      profitableSignals,
      unprofitableSignals,
      dbWinRate: priceTrackLogs.length > 0
        ? Math.round((profitableSignals / priceTrackLogs.length) * 10000) / 100
        : null,
      avgSignalProfit: Math.round(avgSignalProfit * 100) / 100,
    },
    recentScans: scanLogs.slice(0, 10).map(l => ({
      message: l.message,
      data: l.data,
      time: l.createdAt,
    })),
    recentRotations: rotationLogs.slice(0, 10).map(l => ({
      message: l.message,
      data: l.data,
      time: l.createdAt,
    })),
    recentPriceTracking: priceTrackLogs.slice(0, 30).map(l => ({
      message: l.message,
      data: l.data,
      time: l.createdAt,
    })),
  };
}

export async function getSmartAllocations(userId: string) {
  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  if (!config) throw new Error('Command center not configured');

  const settings = (config.settings || {}) as any;
  const exchange = config.exchange || 'binance';
  const totalCapital = settings.totalCapital || 1000;
  const allocated = config.allocatedCapital || 0;
  const available = Math.max(0, totalCapital - allocated);
  const riskLevel = settings.riskLevel || 'moderate';
  const reservePercent = settings.reservePercent || 20;

  let exchangeBalance = 0;
  try {
    exchangeBalance = await fetchExchangeBalanceForCC(userId, exchange);
  } catch {}

  const effectiveAvailable = exchangeBalance > 0 ? Math.max(0, exchangeBalance - allocated) : available;

  const opportunities = await fetchTopMovers(exchange);
  const managedBotPairsForAlloc = new Set<string>();
  const managedIds = config.managedBotIds || [];
  if (managedIds.length > 0) {
    const managedBots = await db.select({ pair: serverBots.pair })
      .from(serverBots)
      .where(inArray(serverBots.id, managedIds));
    for (const b of managedBots) managedBotPairsForAlloc.add(b.pair);
  }
  const currentPairs = managedBotPairsForAlloc;
  const bestNew = opportunities.filter(o => o.score >= (settings.minOpportunityScore || 70) && !currentPairs.has(o.pair));

  const allocations = calculateSmartAllocations(
    bestNew, effectiveAvailable, exchange, riskLevel, reservePercent
  );

  const top5 = opportunities.slice(0, 5).map(o => {
    const bt = selectBotType(o);
    return { pair: o.pair, score: o.score, price: o.price, change24h: o.change24h, volatility: o.volatility, volume24h: o.volume24h, suggestedBotType: bt.type, rationale: bt.rationale };
  });

  const totalDeploying = allocations.reduce((s, a) => s + a.investment, 0);

  return {
    exchange,
    exchangeBalance: exchangeBalance > 0 ? exchangeBalance : null,
    totalCapital,
    allocatedCapital: allocated,
    availableCapital: effectiveAvailable,
    reservePercent,
    reserveAmount: effectiveAvailable * (reservePercent / 100),
    deployableCapital: effectiveAvailable * (1 - reservePercent / 100),
    top5Coins: top5,
    smartAllocations: allocations,
    totalDeploying,
    remainingAfterDeploy: effectiveAvailable - totalDeploying,
  };
}

export async function getCrossExchangeArbitrage(userId: string) {
  const connectedExchanges = await getConnectedExchanges(userId);
  if (connectedExchanges.length < 2) {
    return { arbitrageEnabled: false, reason: 'Need at least 2 connected exchanges for cross-exchange arbitrage', connectedExchanges, opportunities: [] };
  }

  const [config] = await db.select().from(commandCenterConfigs)
    .where(eq(commandCenterConfigs.userId, userId)).limit(1);

  const settings = (config?.settings || {}) as any;
  const totalCapital = settings.totalCapital || 1000;
  const allocated = config?.allocatedCapital || 0;
  const available = Math.max(0, totalCapital - allocated);

  const opportunities = await scanCrossExchangeArbitrage(userId, connectedExchanges, available);
  const profitable = opportunities.filter(o => o.profitable);

  return {
    arbitrageEnabled: true,
    connectedExchanges,
    totalOpportunities: opportunities.length,
    profitableOpportunities: profitable.length,
    opportunities: opportunities.slice(0, 20),
    availableCapital: available,
  };
}

export async function resumeActiveCommandCenters(): Promise<void> {
  try {
    const activeConfigs = await db.select().from(commandCenterConfigs)
      .where(eq(commandCenterConfigs.isActive, true));

    if (activeConfigs.length === 0) {
      ccLog('No active Command Centers to resume');
      return;
    }

    for (const config of activeConfigs) {
      if (activeEngines.has(config.userId)) continue;

      const scanInterval = (config.settings as any)?.scanIntervalSeconds || 30;

      const interval = setInterval(async () => {
        try {
          const [fresh] = await db.select().from(commandCenterConfigs)
            .where(eq(commandCenterConfigs.id, config.id)).limit(1);
          if (!fresh || !fresh.isActive) {
            clearInterval(interval);
            activeEngines.delete(config.userId);
            ccLog(`Stopped for user ${config.userId} (deactivated)`);
            return;
          }
          await runScanCycle(fresh);
        } catch (err: any) {
          ccLog(`Scan error for user ${config.userId}: ${err.message}`);
        }
      }, scanInterval * 1000);

      activeEngines.set(config.userId, interval);
      ccLog(`Resumed Command Center for user ${config.userId} (scan every ${scanInterval}s)`);
      await logCC(config.id, config.userId, 'resume', 'Command Center resumed after server restart');
      runScanCycle(config).catch((err) => ccLog(`Initial resume scan error: ${err.message}`));
    }

    ccLog(`Resumed ${activeConfigs.length} active Command Center(s)`);
  } catch (err: any) {
    ccLog(`Failed to resume Command Centers: ${err.message}`);
  }
}

export async function getMultiExchangeStatus(userId: string) {
  const connectedExchanges = await getConnectedExchanges(userId);
  const balances: { exchange: string; balance: number; error?: string }[] = [];

  for (const exchange of connectedExchanges) {
    try {
      const balance = await fetchExchangeBalanceForCC(userId, exchange);
      balances.push({ exchange, balance });
    } catch (err: any) {
      balances.push({ exchange, balance: 0, error: err.message });
    }
  }

  const totalBalance = balances.reduce((s, b) => s + b.balance, 0);

  return {
    connectedExchanges,
    exchangeCount: connectedExchanges.length,
    balances,
    totalBalance,
    multiExchangeEnabled: connectedExchanges.length >= 2,
    arbitrageCapable: connectedExchanges.length >= 2,
  };
}
