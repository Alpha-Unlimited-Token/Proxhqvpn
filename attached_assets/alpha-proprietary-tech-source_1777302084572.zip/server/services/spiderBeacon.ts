/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Spider Beacon Protocol™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements the Alpha Spider Beacon Protocol™ — a cross-chain forensic tracking
 * intelligence system that deploys persistent surveillance beacons across blockchain networks.
 * Part of the Alpha Forensic Intelligence Engine™ ecosystem.
 *
 * Technologies Protected:
 * - Alpha Spider Beacon Protocol™
 * - AUC Trap Mechanism™ (swap-based tracking via Alpha Unlimited Coin)
 * - Cross-Chain Beacon Intelligence Layer™
 * - Beacon Signal Relay System™
 * - DEX Transaction Fingerprinting Engine™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: SPIDER_BEACON_v1.0_PROTECTED
 */

import { db } from "../db";
import { forensicCases, forensicAlerts } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { registerBeacon } from "./integrityBeacon.js";
import crypto from "crypto";

export const _spiderBeaconModuleHash = 'AUT_8989145b3704ba994fa4ed1d';
const _sbIntegrityValid = registerBeacon('spiderBeacon', _spiderBeaconModuleHash);
if (!_spiderBeaconModuleHash?.startsWith('AUT_') || !_sbIntegrityValid) {
  throw new Error('Spider Beacon Protocol™ module integrity compromised — unauthorized modification detected');
}

const BLOCKSCOUT_ENDPOINTS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  bsc: "https://bsc.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  avalanche: "https://avalanche.blockscout.com/api/v2",
  fantom: "https://fantom.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
  celo: "https://celo.blockscout.com/api/v2",
  blast: "https://blast.blockscout.com/api/v2",
  mantle: "https://explorer.mantle.xyz/api/v2",
  moonbeam: "https://moonbeam.blockscout.com/api/v2",
  cronos: "https://cronos.blockscout.com/api/v2",
};

const CHAIN_LABELS: Record<string, string> = {
  ethereum: "Ethereum", arbitrum: "Arbitrum", optimism: "Optimism", base: "Base",
  polygon: "Polygon", bsc: "BSC", gnosis: "Gnosis", avalanche: "Avalanche",
  fantom: "Fantom", zksync: "zkSync", linea: "Linea", scroll: "Scroll",
  celo: "Celo", blast: "Blast", mantle: "Mantle", moonbeam: "Moonbeam",
  cronos: "Cronos", bitcoin: "Bitcoin", solana: "Solana", tron: "TRON",
  monero: "Monero (Statistical)", auc: "AUC Blockchain",
};

export type BeaconType = 'address_monitor' | 'auc_trap' | 'cross_chain' | 'dex_watcher' | 'bridge_sentinel' | 'token_tracker' | 'approval_watcher' | 'gas_profiler';
export type BeaconStatus = 'active' | 'dormant' | 'triggered' | 'deactivated' | 'self_destructed';
export type SignalType = 'movement_detected' | 'swap_detected' | 'bridge_detected' | 'exchange_deposit' | 'auc_trap_triggered' | 'dex_interaction' | 'cross_chain_hop' | 'dormant_activation' | 'balance_change' | 'token_transfer_detected' | 'token_approval_detected' | 'bridge_departure' | 'exchange_deposit_identified' | 'gas_source_identified' | 'behavioral_pattern' | 'self_destruct_executed' | 'evidence_archived';

const KNOWN_BRIDGE_CONTRACTS: Record<string, string> = {
  '0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae': 'LI.FI Diamond Bridge',
  '0x3a23f943181408eac424116af7b7790c94cb97a5': 'Socket Gateway',
  '0xd9e1ce17f2641f24ae83637ab66a2cca9c378b9f': 'SushiSwap Router',
  '0x8731d54e9d02c286767d56ac03e8037c07e01e98': 'Stargate Router',
  '0xb8901acb165ed027e32754e0ffe830802c896272': 'Hop Protocol Bridge',
  '0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f': 'Arbitrum Inbox',
  '0x99c9fc46f92e8a1c0dec1b1747d010903e884be1': 'Optimism Gateway',
  '0xa0c68c638235ee32657e8f720a23cec1bfc6c9a8': 'Polygon Bridge',
  '0x3ee18b2214aff97000d974cf647e7c347e8fa585': 'Wormhole Bridge',
  '0xcda72070e455bb31c7690a170224ce43623d0b6f': 'Across Bridge',
  '0x5427fefa711eff984124bfbb1ab6fbf5e3da1820': 'Synapse Bridge',
  '0xf5b0a3efb8e8e4c201e2a935f110eaaf3ffecb8d': 'Axelar Gateway',
  '0xe4e2121b479017955be0b175305b35f312330bae': 'Multichain Router',
  '0x2796317b0ff8538f253012862c06787adfb8ceb6': 'Orbiter Finance',
  '0xabea9132b05a70803a4e85094fd0e1800777fbef': 'zkSync Bridge',
};

const KNOWN_EXCHANGE_ADDRESSES: Record<string, string> = {
  '0x28c6c06298d514db089934071d89d323e204f8a7': 'Binance Hot Wallet 14',
  '0x21a31ee1afc51d94c2efccaa2092ad1028285549': 'Binance Hot Wallet 7',
  '0xdfd5293d8e347dfe59e90efd55b2956a1343963d': 'Binance Hot Wallet 8',
  '0x56eddb7aa87536c09ccc2793473599fd21a8b17f': 'Binance Hot Wallet 16',
  '0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43': 'Coinbase Commerce',
  '0x71660c4005ba85c37ccec55d0c4493e66fe775d3': 'Coinbase Hot Wallet 1',
  '0x503828976d22510aad0201ac7ec88293211d23da': 'Coinbase Hot Wallet 2',
  '0xeb2629a2734e272bcc07bda959863f316f4bd4cf': 'Coinbase Hot Wallet 6',
  '0x2910543af39aba0cd09dbb2d50200b3e800a63d2': 'Kraken Hot Wallet 13',
  '0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0': 'Kraken Hot Wallet 4',
  '0xf89d7b9c864f589bbf53a82105107622b35eaa40': 'Bybit Hot Wallet 1',
  '0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23': 'Gate.io Hot Wallet',
  '0x0d0707963952f2fba59dd06f2b425ace40b492fe': 'OKX Hot Wallet 1',
  '0x6cc5f688a315f3dc28a7781717a9a798a59fda7b': 'OKX Hot Wallet 2',
  '0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88': 'MEXC Hot Wallet',
  '0x0681d8db095565fe8a346fa0277bffde9c0edbbf': 'Bitfinex Hot Wallet 1',
  '0x742d35cc6634c0532925a3b844bc9e7595f2bd3e': 'Bitfinex Hot Wallet 2',
  '0xe17ee7b3c676701c66b395a35f0df4c2276a344e': 'KuCoin Hot Wallet',
  '0x2faf487a4414fe77e2327f0bf4ae2a264a776ad2': 'FTX (claims/recovery)',
  '0xf3b0073e3a7f747c7a38b36b805247b222c302a3': 'Gemini Hot Wallet',
  '0x9008d19f58aabd9ed0d60971565aa8510560ab41': 'CoW Protocol (GPv2Settlement)',
  '0xdef1c0ded9bec7f1a1670819833240f027b25eff': '0x Exchange Proxy',
  '0x881d40237659c251811cec9c364ef91dc08d300c': 'MetaMask Swap Router',
  '0x1111111254eeb25477b68fb85ed929f73a960582': '1inch v5 Router',
  '0x6131b5fae19ea4f9d964eac0408e4408b66337b5': 'KyberSwap Router',
  '0x7a250d5630b4cf539739df2c5dacb4c659f2488d': 'Uniswap V2 Router',
  '0xe592427a0aece92de3edee1f18e0157c05861564': 'Uniswap V3 Router',
  '0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad': 'Uniswap Universal Router',
};

export interface SpiderBeaconConfig {
  id: string;
  caseId: string;
  targetAddress: string;
  chain: string;
  type: BeaconType;
  status: BeaconStatus;
  deployedAt: Date;
  lastSignalAt: Date | null;
  signalCount: number;
  metadata: Record<string, any>;
  lastKnownBalance: string | null;
  linkedBeacons: string[];
}

export interface BeaconSignal {
  id: string;
  beaconId: string;
  caseId: string;
  signalType: SignalType;
  chain: string;
  fromAddress: string;
  toAddress: string | null;
  amount: string;
  tokenSymbol: string;
  txHash: string | null;
  timestamp: Date;
  severity: 'info' | 'warning' | 'critical';
  metadata: Record<string, any>;
}

export interface AucTrapRecord {
  id: string;
  caseId: string;
  originalToken: string;
  originalChain: string;
  originalAddress: string;
  aucWalletAddress: string;
  amountSwapped: string;
  swapTimestamp: Date;
  status: 'pending' | 'active' | 'triggered' | 'recovered';
  beaconId: string;
  signals: BeaconSignal[];
}

interface BehavioralProfile {
  address: string;
  activeHoursUTC: number[];
  avgTimeBetweenTxs: number;
  preferredGasPrice: string;
  contractInteractions: Record<string, number>;
  peerWallets: Set<string>;
  bridgeUsage: { bridge: string; count: number; totalValue: string }[];
  exchangeDeposits: { exchange: string; count: number; totalValue: string }[];
  tokenApprovals: { spender: string; token: string; timestamp: Date }[];
  firstSeen: Date;
  lastSeen: Date;
  totalTxCount: number;
  inferredTimezone: string | null;
}

interface EvidenceArchive {
  archiveId: string;
  beaconId: string;
  caseId: string;
  targetAddress: string;
  chain: string;
  deployedAt: Date;
  destructedAt: Date;
  totalSignals: number;
  signalArchive: BeaconSignal[];
  behavioralProfile: BehavioralProfile | null;
  linkedBeaconArchives: string[];
  evidenceHash: string;
}

class SpiderBeaconProtocol {
  private beacons: Map<string, SpiderBeaconConfig> = new Map();
  private signals: BeaconSignal[] = [];
  private aucTraps: Map<string, AucTrapRecord> = new Map();
  private checkInterval: NodeJS.Timeout | null = null;
  private isRunning = false;
  private processedTxHashes: Set<string> = new Set();
  private processedTxHashExpiry: Map<string, number> = new Map();
  private behavioralProfiles: Map<string, BehavioralProfile> = new Map();
  private evidenceArchives: Map<string, EvidenceArchive> = new Map();
  private alertCallbacks: ((signal: BeaconSignal) => Promise<void>)[] = [];

  constructor() {
    console.log('[SpiderBeacon] Alpha Spider Beacon Protocol™ v2.0 initialized');
    console.log('[SpiderBeacon] Cross-chain beacon intelligence layer ready');
    console.log('[SpiderBeacon] ERC-20 Token Tracking Engine™ — ACTIVE');
    console.log('[SpiderBeacon] Bridge Departure Detection™ — ACTIVE');
    console.log('[SpiderBeacon] Exchange Deposit Identification™ — ACTIVE');
    console.log('[SpiderBeacon] Gas Source Profiling Engine™ — ACTIVE');
    console.log('[SpiderBeacon] Behavioral Fingerprinting Engine™ — ACTIVE');
    console.log('[SpiderBeacon] Evidence Archival & Self-Destruct Protocol™ — ARMED');
    console.log('[SpiderBeacon] Signal Deduplication Engine™ — ACTIVE');
    console.log(`[SpiderBeacon] Monitoring ${Object.keys(BLOCKSCOUT_ENDPOINTS).length + 3} blockchain networks`);
    console.log(`[SpiderBeacon] Tracking ${Object.keys(KNOWN_BRIDGE_CONTRACTS).length} bridge contracts`);
    console.log(`[SpiderBeacon] Identifying ${Object.keys(KNOWN_EXCHANGE_ADDRESSES).length} exchange/DEX addresses`);

    setInterval(() => this.cleanupProcessedTxCache(), 600000);
  }

  registerAlertCallback(callback: (signal: BeaconSignal) => Promise<void>) {
    this.alertCallbacks.push(callback);
    console.log(`[SpiderBeacon] Alert callback registered (${this.alertCallbacks.length} total)`);
  }

  private cleanupProcessedTxCache() {
    const now = Date.now();
    let cleaned = 0;
    const entries = Array.from(this.processedTxHashExpiry.entries());
    for (const [hash, expiry] of entries) {
      if (now > expiry) {
        this.processedTxHashes.delete(hash);
        this.processedTxHashExpiry.delete(hash);
        cleaned++;
      }
    }
    if (cleaned > 0) {
      console.log(`[SpiderBeacon] Dedup cache cleanup: ${cleaned} expired entries removed, ${this.processedTxHashes.size} active`);
    }
  }

  private markTxProcessed(txHash: string, ttlMs = 3600000) {
    this.processedTxHashes.add(txHash);
    this.processedTxHashExpiry.set(txHash, Date.now() + ttlMs);
  }

  private isTxProcessed(txHash: string): boolean {
    return this.processedTxHashes.has(txHash);
  }

  generateBeaconId(): string {
    return 'BEACON_' + crypto.randomBytes(12).toString('hex').toUpperCase();
  }

  generateSignalId(): string {
    return 'SIG_' + crypto.randomBytes(8).toString('hex').toUpperCase();
  }

  generateTrapId(): string {
    return 'TRAP_' + crypto.randomBytes(8).toString('hex').toUpperCase();
  }

  async deployBeacon(
    caseId: string,
    targetAddress: string,
    chain: string,
    type: BeaconType,
    metadata: Record<string, any> = {}
  ): Promise<SpiderBeaconConfig> {
    const beacon: SpiderBeaconConfig = {
      id: this.generateBeaconId(),
      caseId,
      targetAddress: targetAddress.toLowerCase(),
      chain,
      type,
      status: 'active',
      deployedAt: new Date(),
      lastSignalAt: null,
      signalCount: 0,
      metadata,
      lastKnownBalance: null,
      linkedBeacons: [],
    };

    this.beacons.set(beacon.id, beacon);

    const initialBalance = await this.checkAddressBalance(targetAddress, chain);
    if (initialBalance) {
      beacon.lastKnownBalance = initialBalance;
    }

    console.log(`[SpiderBeacon] Deployed ${type} beacon ${beacon.id} on ${CHAIN_LABELS[chain] || chain} for ${targetAddress.slice(0, 10)}...`);

    if (type === 'cross_chain') {
      const allChains = [...Object.keys(BLOCKSCOUT_ENDPOINTS), 'bitcoin', 'solana', 'tron'];
      const linkedChains = allChains.filter(c => c !== chain);
      for (const linkedChain of linkedChains) {
        const linkedBeacon: SpiderBeaconConfig = {
          id: this.generateBeaconId(),
          caseId,
          targetAddress: targetAddress.toLowerCase(),
          chain: linkedChain,
          type: 'address_monitor',
          status: 'dormant',
          deployedAt: new Date(),
          lastSignalAt: null,
          signalCount: 0,
          metadata: { parentBeacon: beacon.id, autoDeployed: true },
          lastKnownBalance: null,
          linkedBeacons: [],
        };
        this.beacons.set(linkedBeacon.id, linkedBeacon);
        beacon.linkedBeacons.push(linkedBeacon.id);
      }
      console.log(`[SpiderBeacon] Cross-chain expansion: ${beacon.linkedBeacons.length} dormant beacons deployed across chains`);
    }

    return beacon;
  }

  async deployAucTrap(
    caseId: string,
    originalToken: string,
    originalChain: string,
    originalAddress: string,
    aucWalletAddress: string,
    amountSwapped: string
  ): Promise<AucTrapRecord> {
    const beaconId = this.generateBeaconId();
    const beacon: SpiderBeaconConfig = {
      id: beaconId,
      caseId,
      targetAddress: aucWalletAddress.toLowerCase(),
      chain: 'auc',
      type: 'auc_trap',
      status: 'active',
      deployedAt: new Date(),
      lastSignalAt: null,
      signalCount: 0,
      metadata: {
        originalToken,
        originalChain,
        originalAddress,
        amountSwapped,
        trapType: 'token_swap',
      },
      lastKnownBalance: amountSwapped,
      linkedBeacons: [],
    };
    this.beacons.set(beaconId, beacon);

    const trap: AucTrapRecord = {
      id: this.generateTrapId(),
      caseId,
      originalToken,
      originalChain,
      originalAddress: originalAddress.toLowerCase(),
      aucWalletAddress: aucWalletAddress.toLowerCase(),
      amountSwapped,
      swapTimestamp: new Date(),
      status: 'active',
      beaconId,
      signals: [],
    };
    this.aucTraps.set(trap.id, trap);

    const originBeacon = await this.deployBeacon(caseId, originalAddress, originalChain, 'address_monitor', {
      linkedTrap: trap.id,
      purpose: 'Monitor original theft address for swap-back activity',
    });
    beacon.linkedBeacons.push(originBeacon.id);

    this.emitSignal({
      beaconId,
      caseId,
      signalType: 'auc_trap_triggered',
      chain: 'auc',
      fromAddress: originalAddress,
      toAddress: aucWalletAddress,
      amount: amountSwapped,
      tokenSymbol: 'AUC',
      txHash: null,
      severity: 'critical',
      metadata: {
        originalToken,
        originalChain,
        trapId: trap.id,
        message: `AUC Trap deployed: ${amountSwapped} ${originalToken} swapped to AUC. All AUC movements from ${aucWalletAddress.slice(0, 10)}... will trigger beacon signals.`,
      },
    });

    console.log(`[SpiderBeacon] AUC Trap ${trap.id} deployed — ${amountSwapped} ${originalToken} → AUC`);
    console.log(`[SpiderBeacon] Any AUC movement from wallet ${aucWalletAddress.slice(0, 10)}... will send signals to command center`);

    return trap;
  }

  ingestOnChainSignal(params: Omit<BeaconSignal, 'id' | 'timestamp'>): BeaconSignal {
    return this.emitSignal(params);
  }

  private emitSignal(params: Omit<BeaconSignal, 'id' | 'timestamp'>): BeaconSignal {
    const signal: BeaconSignal = {
      ...params,
      id: this.generateSignalId(),
      timestamp: new Date(),
    };

    this.signals.push(signal);

    const beacon = this.beacons.get(params.beaconId);
    if (beacon) {
      beacon.signalCount++;
      beacon.lastSignalAt = signal.timestamp;
      if (beacon.status === 'dormant') {
        beacon.status = 'triggered';
        console.log(`[SpiderBeacon] DORMANT BEACON ACTIVATED: ${beacon.id} on ${CHAIN_LABELS[beacon.chain] || beacon.chain}`);
      }
    }

    const trap = Array.from(this.aucTraps.values()).find(t => t.beaconId === params.beaconId);
    if (trap) {
      trap.signals.push(signal);
      if (params.signalType === 'auc_trap_triggered') {
        trap.status = 'triggered';
      }
    }

    this.updateBehavioralProfile(params.fromAddress, params.chain, signal);

    if (params.severity === 'critical' || params.severity === 'warning') {
      for (const callback of this.alertCallbacks) {
        callback(signal).catch(err => console.error('[SpiderBeacon] Alert callback error:', err));
      }
    }

    const severityIcon = params.severity === 'critical' ? '🚨' : params.severity === 'warning' ? '⚠️' : 'ℹ️';
    console.log(`[SpiderBeacon] ${severityIcon} Signal ${signal.id}: ${params.signalType} on ${CHAIN_LABELS[params.chain] || params.chain} — ${params.amount} ${params.tokenSymbol || ''} from ${params.fromAddress.slice(0, 10)}...`);

    return signal;
  }

  private async checkAddressBalance(address: string, chain: string): Promise<string | null> {
    try {
      if (chain === 'auc' || chain === 'monero') return null;

      if (chain === 'bitcoin') {
        const res = await fetch(`https://blockchain.info/rawaddr/${address}?limit=0`, { signal: AbortSignal.timeout(8000) });
        if (!res.ok) return null;
        const data = await res.json();
        return (data.final_balance / 1e8).toString();
      }

      if (chain === 'solana') {
        const res = await fetch('https://api.mainnet-beta.solana.com', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'getBalance', params: [address] }),
          signal: AbortSignal.timeout(8000),
        });
        if (!res.ok) return null;
        const data = await res.json();
        return ((data.result?.value || 0) / 1e9).toString();
      }

      const endpoint = BLOCKSCOUT_ENDPOINTS[chain];
      if (!endpoint) return null;

      const res = await fetch(`${endpoint}/addresses/${address.toLowerCase()}`, { signal: AbortSignal.timeout(8000) });
      if (!res.ok) return null;
      const data = await res.json();
      const weiBalance = data.coin_balance || '0';
      return (parseInt(weiBalance) / 1e18).toFixed(6);
    } catch {
      return null;
    }
  }

  private async checkAddressTransactions(address: string, chain: string): Promise<any[]> {
    try {
      if (chain === 'auc' || chain === 'monero') return [];

      if (chain === 'bitcoin') {
        return this.checkBitcoinTransactions(address);
      }
      if (chain === 'solana') {
        return this.checkSolanaTransactions(address);
      }

      const endpoint = BLOCKSCOUT_ENDPOINTS[chain];
      if (!endpoint) return [];

      const res = await fetch(`${endpoint}/addresses/${address.toLowerCase()}/transactions`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      return data.items || [];
    } catch {
      return [];
    }
  }

  private async checkBitcoinTransactions(address: string): Promise<any[]> {
    try {
      const res = await fetch(`https://blockchain.info/rawaddr/${address}?limit=5`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.txs || []).map((tx: any) => ({
        hash: tx.hash,
        timestamp: new Date(tx.time * 1000).toISOString(),
        from: { hash: tx.inputs?.[0]?.prev_out?.addr || 'coinbase' },
        to: { hash: tx.out?.[0]?.addr || 'unknown' },
        value: String(tx.out?.reduce((sum: number, o: any) => sum + (o.value || 0), 0) || 0),
        _isBitcoin: true,
        _allOutputs: tx.out?.map((o: any) => ({ addr: o.addr, value: o.value / 1e8 })) || [],
        _allInputs: tx.inputs?.map((i: any) => ({ addr: i.prev_out?.addr, value: (i.prev_out?.value || 0) / 1e8 })) || [],
        gas_used: tx.fee?.toString() || '0',
      }));
    } catch {
      return [];
    }
  }

  private async checkSolanaTransactions(address: string): Promise<any[]> {
    try {
      const sigRes = await fetch('https://api.mainnet-beta.solana.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 1,
          method: 'getSignaturesForAddress',
          params: [address, { limit: 5 }],
        }),
        signal: AbortSignal.timeout(10000),
      });
      if (!sigRes.ok) return [];
      const sigData = await sigRes.json();
      const sigs = sigData.result || [];
      return sigs.map((sig: any) => ({
        hash: sig.signature,
        timestamp: sig.blockTime ? new Date(sig.blockTime * 1000).toISOString() : null,
        from: { hash: address },
        to: { hash: 'unknown' },
        value: '0',
        _isSolana: true,
        _memo: sig.memo,
        _err: sig.err,
      }));
    } catch {
      return [];
    }
  }

  private async checkTokenTransfers(address: string, chain: string): Promise<any[]> {
    try {
      if (chain === 'auc' || chain === 'monero') return [];

      if (chain === 'bitcoin') {
        return [];
      }

      if (chain === 'solana') {
        return this.checkSolanaTokenTransfers(address);
      }

      if (chain === 'tron') {
        return this.checkTronTokenTransfers(address);
      }

      const endpoint = BLOCKSCOUT_ENDPOINTS[chain];
      if (!endpoint) return [];

      const res = await fetch(`${endpoint}/addresses/${address.toLowerCase()}/token-transfers?type=ERC-20,ERC-721,ERC-1155`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.items || []).map((item: any) => ({
        ...item,
        _tokenStandard: this.detectEVMTokenStandard(item),
        _chain: chain,
      }));
    } catch {
      return [];
    }
  }

  private detectEVMTokenStandard(transfer: any): string {
    const tokenType = transfer.token?.type?.toLowerCase() || '';
    if (tokenType.includes('erc-1155') || tokenType.includes('erc1155')) return 'ERC-1155';
    if (tokenType.includes('erc-721') || tokenType.includes('erc721')) return 'ERC-721';
    if (tokenType.includes('erc-20') || tokenType.includes('erc20')) return 'ERC-20';
    if (transfer.token_id || transfer.tokenId) return 'ERC-721';
    if (transfer.amount && !transfer.token_id) return 'ERC-20';
    return 'ERC-20';
  }

  private async checkSolanaTokenTransfers(address: string): Promise<any[]> {
    try {
      const res = await fetch('https://api.mainnet-beta.solana.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 1,
          method: 'getTokenAccountsByOwner',
          params: [address, { programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA' }, { encoding: 'jsonParsed' }],
        }),
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const accounts = data.result?.value || [];
      return accounts.map((acc: any) => {
        const parsed = acc.account?.data?.parsed?.info || {};
        return {
          _tokenStandard: 'SPL',
          _chain: 'solana',
          _solanaAccount: acc.pubkey,
          from: { hash: parsed.owner || address },
          to: { hash: address },
          token: {
            symbol: 'SPL',
            name: 'Solana Program Library Token',
            address: parsed.mint,
            type: 'SPL',
            decimals: parsed.tokenAmount?.decimals || 0,
          },
          total: { value: parsed.tokenAmount?.amount || '0', decimals: parsed.tokenAmount?.decimals || 0 },
          _balance: parsed.tokenAmount?.uiAmountString || '0',
        };
      });
    } catch {
      return [];
    }
  }

  private async checkSolanaToken2022Transfers(address: string): Promise<any[]> {
    try {
      const res = await fetch('https://api.mainnet-beta.solana.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0', id: 1,
          method: 'getTokenAccountsByOwner',
          params: [address, { programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb' }, { encoding: 'jsonParsed' }],
        }),
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const accounts = data.result?.value || [];
      return accounts.map((acc: any) => {
        const parsed = acc.account?.data?.parsed?.info || {};
        return {
          _tokenStandard: 'SPL-Token-2022',
          _chain: 'solana',
          _solanaAccount: acc.pubkey,
          from: { hash: parsed.owner || address },
          to: { hash: address },
          token: {
            symbol: 'SPL-2022',
            name: 'Token-2022 Program Token',
            address: parsed.mint,
            type: 'SPL-Token-2022',
            decimals: parsed.tokenAmount?.decimals || 0,
          },
          total: { value: parsed.tokenAmount?.amount || '0', decimals: parsed.tokenAmount?.decimals || 0 },
          _balance: parsed.tokenAmount?.uiAmountString || '0',
        };
      });
    } catch {
      return [];
    }
  }

  private async checkTronTokenTransfers(address: string): Promise<any[]> {
    try {
      const res = await fetch(`https://apilist.tronscanapi.com/api/token_trc20/transfers?relatedAddress=${address}&limit=10&start=0`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const transfers = data.token_transfers || [];
      return transfers.map((tx: any) => ({
        _tokenStandard: 'TRC-20',
        _chain: 'tron',
        hash: tx.transaction_id,
        timestamp: tx.block_ts ? new Date(tx.block_ts).toISOString() : null,
        from: { hash: tx.from_address },
        to: { hash: tx.to_address },
        token: {
          symbol: tx.tokenInfo?.tokenAbbr || 'TRC20',
          name: tx.tokenInfo?.tokenName || 'Unknown',
          address: tx.contract_address,
          type: 'TRC-20',
          decimals: tx.tokenInfo?.tokenDecimal || 6,
        },
        total: { value: tx.quant || '0', decimals: tx.tokenInfo?.tokenDecimal || 6 },
      }));
    } catch {
      return [];
    }
  }

  private async checkTronTRC10Transfers(address: string): Promise<any[]> {
    try {
      const res = await fetch(`https://apilist.tronscanapi.com/api/transfer/token?address=${address}&limit=10&start=0`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const transfers = data.data || [];
      return transfers.map((tx: any) => ({
        _tokenStandard: 'TRC-10',
        _chain: 'tron',
        hash: tx.transactionHash,
        timestamp: tx.timestamp ? new Date(tx.timestamp).toISOString() : null,
        from: { hash: tx.transferFromAddress },
        to: { hash: tx.transferToAddress },
        token: {
          symbol: tx.tokenName || 'TRC10',
          name: tx.tokenName || 'Unknown',
          address: tx.tokenId?.toString() || '',
          type: 'TRC-10',
          decimals: tx.decimals || 0,
        },
        total: { value: tx.amount || '0', decimals: tx.decimals || 0 },
      }));
    } catch {
      return [];
    }
  }

  private async checkBRC20Tokens(address: string): Promise<any[]> {
    try {
      const res = await fetch(`https://api.hiro.so/ordinals/v1/brc-20/balances/${address}`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const results = data.results || [];
      return results.map((token: any) => ({
        _tokenStandard: 'BRC-20',
        _chain: 'bitcoin',
        from: { hash: 'inscription' },
        to: { hash: address },
        token: {
          symbol: token.ticker || 'BRC20',
          name: token.ticker || 'Unknown',
          address: `brc20:${token.ticker}`,
          type: 'BRC-20',
          decimals: 18,
        },
        total: { value: token.overall_balance || '0', decimals: 18 },
        _balance: token.overall_balance || '0',
        _availableBalance: token.available_balance || '0',
        _transferableBalance: token.transferable_balance || '0',
      }));
    } catch {
      return [];
    }
  }

  private getTokenStandardsForChain(chain: string): string[] {
    const standards: Record<string, string[]> = {
      ethereum: ['ERC-20', 'ERC-721', 'ERC-1155'],
      arbitrum: ['ERC-20', 'ERC-721', 'ERC-1155'],
      optimism: ['ERC-20', 'ERC-721', 'ERC-1155'],
      base: ['ERC-20', 'ERC-721', 'ERC-1155'],
      polygon: ['ERC-20', 'ERC-721', 'ERC-1155'],
      bsc: ['BEP-20', 'BEP-721', 'BEP-1155'],
      avalanche: ['ERC-20', 'ERC-721', 'ERC-1155'],
      fantom: ['ERC-20', 'ERC-721', 'ERC-1155'],
      gnosis: ['ERC-20', 'ERC-721', 'ERC-1155'],
      zksync: ['ERC-20', 'ERC-721'],
      linea: ['ERC-20', 'ERC-721'],
      scroll: ['ERC-20', 'ERC-721'],
      celo: ['ERC-20', 'ERC-721', 'ERC-1155'],
      blast: ['ERC-20', 'ERC-721'],
      mantle: ['ERC-20', 'ERC-721'],
      moonbeam: ['ERC-20', 'ERC-721', 'ERC-1155'],
      cronos: ['ERC-20', 'ERC-721', 'CRC-20'],
      solana: ['SPL', 'SPL-Token-2022'],
      bitcoin: ['BRC-20', 'Ordinals', 'Runes'],
      tron: ['TRC-20', 'TRC-10', 'TRC-721'],
      auc: ['AUC-Native'],
    };
    return standards[chain] || ['Unknown'];
  }

  private identifyBridgeContract(address: string): string | null {
    return KNOWN_BRIDGE_CONTRACTS[address.toLowerCase()] || null;
  }

  private identifyExchange(address: string): string | null {
    return KNOWN_EXCHANGE_ADDRESSES[address.toLowerCase()] || null;
  }

  private updateBehavioralProfile(address: string, chain: string, signal: BeaconSignal) {
    if (!address || address === 'unknown') return;
    const key = address.toLowerCase();
    let profile = this.behavioralProfiles.get(key);
    if (!profile) {
      profile = {
        address: key,
        activeHoursUTC: [],
        avgTimeBetweenTxs: 0,
        preferredGasPrice: '0',
        contractInteractions: {},
        peerWallets: new Set(),
        bridgeUsage: [],
        exchangeDeposits: [],
        tokenApprovals: [],
        firstSeen: signal.timestamp,
        lastSeen: signal.timestamp,
        totalTxCount: 0,
        inferredTimezone: null,
      };
      this.behavioralProfiles.set(key, profile);
    }

    profile.lastSeen = signal.timestamp;
    profile.totalTxCount++;
    profile.activeHoursUTC.push(signal.timestamp.getUTCHours());

    if (profile.activeHoursUTC.length > 200) {
      profile.activeHoursUTC = profile.activeHoursUTC.slice(-200);
    }

    if (signal.toAddress && signal.toAddress !== key) {
      profile.peerWallets.add(signal.toAddress);
    }

    if (signal.metadata?.method) {
      const method = signal.metadata.method as string;
      profile.contractInteractions[method] = (profile.contractInteractions[method] || 0) + 1;
    }

    if (signal.metadata?.bridgeName) {
      const existing = profile.bridgeUsage.find(b => b.bridge === signal.metadata.bridgeName);
      if (existing) {
        existing.count++;
        existing.totalValue = (parseFloat(existing.totalValue) + parseFloat(signal.amount)).toString();
      } else {
        profile.bridgeUsage.push({ bridge: signal.metadata.bridgeName as string, count: 1, totalValue: signal.amount });
      }
    }

    if (signal.metadata?.exchangeName) {
      const existing = profile.exchangeDeposits.find(e => e.exchange === signal.metadata.exchangeName);
      if (existing) {
        existing.count++;
        existing.totalValue = (parseFloat(existing.totalValue) + parseFloat(signal.amount)).toString();
      } else {
        profile.exchangeDeposits.push({ exchange: signal.metadata.exchangeName as string, count: 1, totalValue: signal.amount });
      }
    }

    if (profile.activeHoursUTC.length >= 10) {
      const hourCounts: Record<number, number> = {};
      for (const h of profile.activeHoursUTC) {
        hourCounts[h] = (hourCounts[h] || 0) + 1;
      }
      const peakHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0];
      if (peakHour) {
        const peak = parseInt(peakHour[0]);
        if (peak >= 6 && peak <= 18) {
          const offset = 12 - peak;
          profile.inferredTimezone = `UTC${offset >= 0 ? '+' : ''}${offset}`;
        } else {
          const offset = peak > 18 ? -(peak - 12) : 12 - peak;
          profile.inferredTimezone = `UTC${offset >= 0 ? '+' : ''}${offset}`;
        }
      }
    }
  }

  getBehavioralProfile(address: string): BehavioralProfile | null {
    return this.behavioralProfiles.get(address.toLowerCase()) || null;
  }

  getAllBehavioralProfiles(caseId?: string): BehavioralProfile[] {
    if (!caseId) return Array.from(this.behavioralProfiles.values());
    const caseAddresses = new Set(
      Array.from(this.beacons.values())
        .filter(b => b.caseId === caseId)
        .map(b => b.targetAddress)
    );
    return Array.from(this.behavioralProfiles.values())
      .filter(p => caseAddresses.has(p.address));
  }

  async checkAllBeacons(): Promise<BeaconSignal[]> {
    const newSignals: BeaconSignal[] = [];
    const activeBeacons = Array.from(this.beacons.values()).filter(b =>
      b.status === 'active' || b.status === 'triggered'
    );

    for (const beacon of activeBeacons) {
      try {
        if (beacon.chain === 'auc') continue;

        const currentBalance = await this.checkAddressBalance(beacon.targetAddress, beacon.chain);

        if (currentBalance && beacon.lastKnownBalance && currentBalance !== beacon.lastKnownBalance) {
          const prevBal = parseFloat(beacon.lastKnownBalance);
          const currBal = parseFloat(currentBalance);
          const diff = currBal - prevBal;
          if (Math.abs(diff) > 0.000001) {
            const nativeSymbol = beacon.chain === 'bitcoin' ? 'BTC' : beacon.chain === 'solana' ? 'SOL' : beacon.chain === 'tron' ? 'TRX' : beacon.chain === 'bsc' ? 'BNB' : beacon.chain === 'polygon' ? 'MATIC' : beacon.chain === 'avalanche' ? 'AVAX' : 'ETH';
            const signal = this.emitSignal({
              beaconId: beacon.id,
              caseId: beacon.caseId,
              signalType: diff > 0 ? 'movement_detected' : 'balance_change',
              chain: beacon.chain,
              fromAddress: beacon.targetAddress,
              toAddress: null,
              amount: Math.abs(diff).toFixed(6),
              tokenSymbol: nativeSymbol,
              txHash: null,
              severity: Math.abs(diff) > 1 ? 'critical' : Math.abs(diff) > 0.1 ? 'warning' : 'info',
              metadata: {
                previousBalance: beacon.lastKnownBalance,
                currentBalance,
                changeDirection: diff > 0 ? 'inflow' : 'outflow',
                beaconType: beacon.type,
              },
            });
            newSignals.push(signal);
          }
          beacon.lastKnownBalance = currentBalance;
        } else if (currentBalance && !beacon.lastKnownBalance) {
          beacon.lastKnownBalance = currentBalance;
        }

        const txs = await this.checkAddressTransactions(beacon.targetAddress, beacon.chain);
        const recentTxs = txs.filter((tx: any) => {
          const txTime = new Date(tx.timestamp || tx.block?.timestamp).getTime();
          const tenMinAgo = Date.now() - 10 * 60 * 1000;
          return txTime > tenMinAgo;
        });

        for (const tx of recentTxs.slice(0, 5)) {
          const txHash = tx.hash || '';
          if (txHash && this.isTxProcessed(txHash)) continue;
          if (txHash) this.markTxProcessed(txHash);

          const from = (tx.from?.hash || tx.from || '').toLowerCase();
          const to = (tx.to?.hash || tx.to || '').toLowerCase();
          const isBtc = tx._isBitcoin;
          const isSol = tx._isSolana;
          const value = isBtc
            ? (parseInt(tx.value || '0') / 1e8).toFixed(8)
            : isSol ? '0'
            : tx.value ? (parseInt(tx.value) / 1e18).toFixed(6) : '0';

          let signalType: SignalType = 'movement_detected';
          let severity: 'info' | 'warning' | 'critical' = 'warning';
          const extraMeta: Record<string, any> = {
            blockNumber: tx.block_number || tx.block?.number,
            gasUsed: tx.gas_used,
            isContract: tx.to?.is_contract || false,
            method: tx.method || null,
            gasPayer: from,
          };

          if (isBtc) {
            extraMeta.bitcoinInputs = tx._allInputs;
            extraMeta.bitcoinOutputs = tx._allOutputs;
            extraMeta.allOutputAddresses = tx._allOutputs?.map((o: any) => o.addr).filter(Boolean);
          }

          const bridgeName = this.identifyBridgeContract(to);
          if (bridgeName) {
            signalType = 'bridge_departure';
            severity = 'critical';
            extraMeta.bridgeName = bridgeName;
            extraMeta.bridgeContract = to;
            extraMeta.possibleDestinationChains = this.inferBridgeDestinations(bridgeName);
          }

          const exchangeName = this.identifyExchange(to);
          if (exchangeName) {
            signalType = 'exchange_deposit_identified';
            severity = 'critical';
            extraMeta.exchangeName = exchangeName;
            extraMeta.exchangeAddress = to;
            extraMeta.subpoenaTarget = true;
          }

          if (!bridgeName && !exchangeName && tx.to?.is_contract) {
            signalType = 'dex_interaction';
            severity = 'critical';
          }

          const signal = this.emitSignal({
            beaconId: beacon.id,
            caseId: beacon.caseId,
            signalType,
            chain: beacon.chain,
            fromAddress: from,
            toAddress: to,
            amount: value,
            tokenSymbol: isBtc ? 'BTC' : isSol ? 'SOL' : '',
            txHash: txHash || null,
            severity,
            metadata: extraMeta,
          });
          newSignals.push(signal);
        }

        const tokenTransfers = await this.checkTokenTransfers(beacon.targetAddress, beacon.chain);
        const recentTokenTxs = tokenTransfers.filter((tt: any) => {
          const ttTime = new Date(tt.timestamp || tt.block?.timestamp || 0).getTime();
          const tenMinAgo = Date.now() - 10 * 60 * 1000;
          return ttTime > tenMinAgo;
        });

        for (const tt of recentTokenTxs.slice(0, 5)) {
          const ttHash = tt.tx_hash || tt.hash || '';
          const dedupKey = `token_${ttHash}_${tt.token?.address || ''}`;
          if (dedupKey && this.isTxProcessed(dedupKey)) continue;
          if (dedupKey) this.markTxProcessed(dedupKey);

          const ttFrom = (tt.from?.hash || tt.from || '').toLowerCase();
          const ttTo = (tt.to?.hash || tt.to || '').toLowerCase();
          const tokenSymbol = tt.token?.symbol || 'UNKNOWN';
          const tokenName = tt.token?.name || 'Unknown Token';
          const tokenAddress = tt.token?.address || '';
          const tokenStandard = tt._tokenStandard || 'ERC-20';
          const decimals = parseInt(tt.total?.decimals || tt.token?.decimals || '18');
          const rawValue = tt.total?.value || tt.value || '0';
          const humanValue = (parseFloat(rawValue) / Math.pow(10, decimals)).toFixed(6);

          let ttSeverity: 'info' | 'warning' | 'critical' = 'warning';
          const ttMeta: Record<string, any> = {
            tokenSymbol,
            tokenName,
            tokenAddress,
            tokenStandard,
            tokenChain: beacon.chain,
            supportedStandards: this.getTokenStandardsForChain(beacon.chain),
            rawValue,
            decimals,
          };

          const ttBridge = this.identifyBridgeContract(ttTo);
          if (ttBridge) {
            ttSeverity = 'critical';
            ttMeta.bridgeName = ttBridge;
            ttMeta.bridgeContract = ttTo;
            ttMeta.possibleDestinationChains = this.inferBridgeDestinations(ttBridge);
          }

          const ttExchange = this.identifyExchange(ttTo);
          if (ttExchange) {
            ttSeverity = 'critical';
            ttMeta.exchangeName = ttExchange;
            ttMeta.subpoenaTarget = true;
          }

          if (parseFloat(humanValue) > 10000) ttSeverity = 'critical';

          const signal = this.emitSignal({
            beaconId: beacon.id,
            caseId: beacon.caseId,
            signalType: 'token_transfer_detected',
            chain: beacon.chain,
            fromAddress: ttFrom,
            toAddress: ttTo,
            amount: humanValue,
            tokenSymbol,
            txHash: ttHash || null,
            severity: ttSeverity,
            metadata: ttMeta,
          });
          newSignals.push(signal);
        }

        if (beacon.chain === 'solana') {
          const spl2022 = await this.checkSolanaToken2022Transfers(beacon.targetAddress);
          for (const token of spl2022) {
            if (parseFloat(token._balance || '0') > 0) {
              this.emitSignal({
                beaconId: beacon.id,
                caseId: beacon.caseId,
                signalType: 'token_transfer_detected',
                chain: 'solana',
                fromAddress: beacon.targetAddress,
                toAddress: beacon.targetAddress,
                amount: token._balance,
                tokenSymbol: 'SPL-2022',
                txHash: null,
                severity: 'info',
                metadata: {
                  tokenStandard: 'SPL-Token-2022',
                  tokenAddress: token.token?.address,
                  solanaAccount: token._solanaAccount,
                  supportedStandards: ['SPL', 'SPL-Token-2022'],
                },
              });
            }
          }
        }

        if (beacon.chain === 'bitcoin') {
          const brc20 = await this.checkBRC20Tokens(beacon.targetAddress);
          for (const token of brc20) {
            if (parseFloat(token._balance || '0') > 0) {
              const dedupKey = `brc20_${beacon.targetAddress}_${token.token?.symbol}`;
              if (this.isTxProcessed(dedupKey)) continue;
              this.markTxProcessed(dedupKey, 1800000);

              this.emitSignal({
                beaconId: beacon.id,
                caseId: beacon.caseId,
                signalType: 'token_transfer_detected',
                chain: 'bitcoin',
                fromAddress: beacon.targetAddress,
                toAddress: beacon.targetAddress,
                amount: token._balance,
                tokenSymbol: token.token?.symbol || 'BRC20',
                txHash: null,
                severity: 'warning',
                metadata: {
                  tokenStandard: 'BRC-20',
                  availableBalance: token._availableBalance,
                  transferableBalance: token._transferableBalance,
                  supportedStandards: ['BRC-20', 'Ordinals', 'Runes'],
                },
              });
            }
          }
        }

        if (beacon.chain === 'tron') {
          const trc10 = await this.checkTronTRC10Transfers(beacon.targetAddress);
          const recentTrc10 = trc10.filter((tx: any) => {
            const txTime = new Date(tx.timestamp || 0).getTime();
            return txTime > Date.now() - 10 * 60 * 1000;
          });
          for (const tx of recentTrc10.slice(0, 3)) {
            const dedupKey = `trc10_${tx.hash}`;
            if (this.isTxProcessed(dedupKey)) continue;
            this.markTxProcessed(dedupKey);

            this.emitSignal({
              beaconId: beacon.id,
              caseId: beacon.caseId,
              signalType: 'token_transfer_detected',
              chain: 'tron',
              fromAddress: (tx.from?.hash || '').toLowerCase(),
              toAddress: (tx.to?.hash || '').toLowerCase(),
              amount: tx.total?.value || '0',
              tokenSymbol: tx.token?.symbol || 'TRC10',
              txHash: tx.hash || null,
              severity: 'warning',
              metadata: {
                tokenStandard: 'TRC-10',
                supportedStandards: ['TRC-20', 'TRC-10', 'TRC-721'],
              },
            });
          }
        }

        await new Promise(r => setTimeout(r, 200));
      } catch (err) {
        // Silent continue for individual beacon failures
      }
    }

    return newSignals;
  }

  private inferBridgeDestinations(bridgeName: string): string[] {
    const bridgeDestinations: Record<string, string[]> = {
      'LI.FI Diamond Bridge': ['Arbitrum', 'Optimism', 'Base', 'Polygon', 'BSC', 'Avalanche', 'Fantom', 'zkSync', 'Solana'],
      'Socket Gateway': ['Arbitrum', 'Optimism', 'Base', 'Polygon', 'BSC', 'Avalanche', 'Gnosis'],
      'Stargate Router': ['Arbitrum', 'Optimism', 'Base', 'Polygon', 'BSC', 'Avalanche', 'Fantom'],
      'Hop Protocol Bridge': ['Arbitrum', 'Optimism', 'Polygon', 'Gnosis'],
      'Arbitrum Inbox': ['Arbitrum'],
      'Optimism Gateway': ['Optimism'],
      'Polygon Bridge': ['Polygon'],
      'Wormhole Bridge': ['Solana', 'BSC', 'Avalanche', 'Polygon', 'Fantom', 'Celo', 'Moonbeam'],
      'Across Bridge': ['Arbitrum', 'Optimism', 'Base', 'Polygon', 'zkSync', 'Linea'],
      'Synapse Bridge': ['Arbitrum', 'Optimism', 'BSC', 'Avalanche', 'Polygon', 'Fantom', 'Moonbeam', 'Cronos'],
      'Axelar Gateway': ['Avalanche', 'Polygon', 'BSC', 'Fantom', 'Moonbeam', 'Celo'],
      'Multichain Router': ['Arbitrum', 'Optimism', 'BSC', 'Avalanche', 'Polygon', 'Fantom', 'Cronos'],
      'Orbiter Finance': ['Arbitrum', 'Optimism', 'Base', 'zkSync', 'Linea', 'Scroll', 'Starknet'],
      'zkSync Bridge': ['zkSync'],
    };
    return bridgeDestinations[bridgeName] || ['Unknown'];
  }

  checkAucBlockchainTransfers(fromAddress: string, toAddress: string, amount: number): BeaconSignal[] {
    const signals: BeaconSignal[] = [];
    const fromLower = fromAddress.toLowerCase();
    const toLower = toAddress.toLowerCase();

    const allBeacons = Array.from(this.beacons.values());
    for (const beacon of allBeacons) {
      if (beacon.type !== 'auc_trap' || beacon.status === 'deactivated' || beacon.status === 'self_destructed') continue;

      if (beacon.targetAddress === fromLower || beacon.targetAddress === toLower) {
        const signal = this.emitSignal({
          beaconId: beacon.id,
          caseId: beacon.caseId,
          signalType: 'auc_trap_triggered',
          chain: 'auc',
          fromAddress: fromLower,
          toAddress: toLower,
          amount: amount.toString(),
          tokenSymbol: 'AUC',
          txHash: null,
          severity: 'critical',
          metadata: {
            trapType: 'auc_transfer',
            direction: beacon.targetAddress === fromLower ? 'outgoing' : 'incoming',
            originalToken: beacon.metadata.originalToken,
            message: `AUC Trap TRIGGERED: ${amount} AUC ${beacon.targetAddress === fromLower ? 'sent from' : 'received at'} trapped wallet`,
          },
        });
        signals.push(signal);
      }
    }

    return signals;
  }

  async selfDestructBeacon(beaconId: string, reason: string = 'manual'): Promise<EvidenceArchive | null> {
    const beacon = this.beacons.get(beaconId);
    if (!beacon) return null;

    const beaconSignals = this.signals.filter(s => s.beaconId === beaconId);
    const profile = this.behavioralProfiles.get(beacon.targetAddress) || null;

    const archiveData = JSON.stringify({
      beacon, signals: beaconSignals, profile,
      destructReason: reason, destructTime: new Date().toISOString(),
    });
    const evidenceHash = crypto.createHash('sha256').update(archiveData).digest('hex');

    const archive: EvidenceArchive = {
      archiveId: 'ARCHIVE_' + crypto.randomBytes(8).toString('hex').toUpperCase(),
      beaconId,
      caseId: beacon.caseId,
      targetAddress: beacon.targetAddress,
      chain: beacon.chain,
      deployedAt: beacon.deployedAt,
      destructedAt: new Date(),
      totalSignals: beaconSignals.length,
      signalArchive: [...beaconSignals],
      behavioralProfile: profile ? { ...profile, peerWallets: new Set(Array.from(profile.peerWallets)) } : null,
      linkedBeaconArchives: [],
      evidenceHash,
    };

    this.emitSignal({
      beaconId,
      caseId: beacon.caseId,
      signalType: 'evidence_archived',
      chain: beacon.chain,
      fromAddress: beacon.targetAddress,
      toAddress: null,
      amount: '0',
      tokenSymbol: '',
      txHash: null,
      severity: 'critical',
      metadata: {
        archiveId: archive.archiveId,
        evidenceHash,
        totalSignalsArchived: beaconSignals.length,
        reason,
      },
    });

    for (const linkedId of beacon.linkedBeacons) {
      const linkedArchive = await this.selfDestructBeacon(linkedId, `parent_destruct_${beaconId}`);
      if (linkedArchive) {
        archive.linkedBeaconArchives.push(linkedArchive.archiveId);
      }
    }

    beacon.status = 'self_destructed';
    this.evidenceArchives.set(archive.archiveId, archive);

    this.emitSignal({
      beaconId,
      caseId: beacon.caseId,
      signalType: 'self_destruct_executed',
      chain: beacon.chain,
      fromAddress: beacon.targetAddress,
      toAddress: null,
      amount: '0',
      tokenSymbol: '',
      txHash: null,
      severity: 'critical',
      metadata: {
        archiveId: archive.archiveId,
        evidenceHash,
        linkedDestructed: archive.linkedBeaconArchives.length,
        reason,
      },
    });

    console.log(`[SpiderBeacon] 💀 SELF-DESTRUCT: Beacon ${beaconId} destroyed. Evidence archived as ${archive.archiveId} (SHA-256: ${evidenceHash.slice(0, 16)}...)`);

    return archive;
  }

  async selfDestructAllForCase(caseId: string, reason: string = 'case_closure'): Promise<EvidenceArchive[]> {
    const caseBeacons = Array.from(this.beacons.values()).filter(
      b => b.caseId === caseId && b.status !== 'self_destructed' && b.status !== 'deactivated'
    );
    const archives: EvidenceArchive[] = [];
    for (const beacon of caseBeacons) {
      const archive = await this.selfDestructBeacon(beacon.id, reason);
      if (archive) archives.push(archive);
    }
    console.log(`[SpiderBeacon] 💀 CASE SELF-DESTRUCT: ${archives.length} beacons destroyed for case ${caseId.slice(0, 8)}...`);
    return archives;
  }

  getEvidenceArchive(archiveId: string): EvidenceArchive | null {
    return this.evidenceArchives.get(archiveId) || null;
  }

  getAllEvidenceArchives(caseId?: string): EvidenceArchive[] {
    const all = Array.from(this.evidenceArchives.values());
    if (caseId) return all.filter(a => a.caseId === caseId);
    return all;
  }

  async deactivateBeacon(beaconId: string): Promise<boolean> {
    const beacon = this.beacons.get(beaconId);
    if (!beacon) return false;

    beacon.status = 'deactivated';

    for (const linkedId of beacon.linkedBeacons) {
      const linked = this.beacons.get(linkedId);
      if (linked) linked.status = 'deactivated';
    }

    console.log(`[SpiderBeacon] Beacon ${beaconId} deactivated (${beacon.linkedBeacons.length} linked beacons also deactivated)`);
    return true;
  }

  getBeacons(caseId?: string): SpiderBeaconConfig[] {
    const all = Array.from(this.beacons.values());
    if (caseId) return all.filter(b => b.caseId === caseId);
    return all;
  }

  getSignals(caseId?: string, limit = 100): BeaconSignal[] {
    let filtered = caseId ? this.signals.filter(s => s.caseId === caseId) : [...this.signals];
    filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return filtered.slice(0, limit);
  }

  getAucTraps(caseId?: string): AucTrapRecord[] {
    const all = Array.from(this.aucTraps.values());
    if (caseId) return all.filter(t => t.caseId === caseId);
    return all;
  }

  getStats() {
    const beacons = Array.from(this.beacons.values());
    const active = beacons.filter(b => b.status === 'active' || b.status === 'triggered');
    const dormant = beacons.filter(b => b.status === 'dormant');
    const destructed = beacons.filter(b => b.status === 'self_destructed');
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const signalsToday = this.signals.filter(s => s.timestamp >= todayStart);

    const chainCoverage = new Set(active.map(b => b.chain));
    const typeBreakdown: Record<string, number> = {};
    for (const b of active) {
      typeBreakdown[b.type] = (typeBreakdown[b.type] || 0) + 1;
    }

    const tokenStandardsCovered = new Set<string>();
    for (const chain of chainCoverage) {
      for (const std of this.getTokenStandardsForChain(chain)) {
        tokenStandardsCovered.add(std);
      }
    }

    return {
      totalBeacons: beacons.length,
      activeBeacons: active.length,
      dormantBeacons: dormant.length,
      deactivatedBeacons: beacons.filter(b => b.status === 'deactivated').length,
      selfDestructedBeacons: destructed.length,
      totalSignals: this.signals.length,
      signalsToday: signalsToday.length,
      criticalSignals: signalsToday.filter(s => s.severity === 'critical').length,
      chainsCovered: chainCoverage.size,
      chains: Array.from(chainCoverage),
      tokenStandardsCovered: Array.from(tokenStandardsCovered),
      aucTrapsActive: Array.from(this.aucTraps.values()).filter(t => t.status === 'active' || t.status === 'triggered').length,
      typeBreakdown,
      casesMonitored: new Set(active.map(b => b.caseId)).size,
      behavioralProfiles: this.behavioralProfiles.size,
      evidenceArchives: this.evidenceArchives.size,
      deduplicationCacheSize: this.processedTxHashes.size,
      bridgeContractsTracked: Object.keys(KNOWN_BRIDGE_CONTRACTS).length,
      exchangeAddressesTracked: Object.keys(KNOWN_EXCHANGE_ADDRESSES).length,
    };
  }

  startPeriodicCheck(intervalMs = 300000) {
    if (this.isRunning) return;
    this.isRunning = true;

    console.log(`[SpiderBeacon] Starting periodic beacon check (every ${intervalMs / 1000}s)`);

    this.checkInterval = setInterval(async () => {
      try {
        const active = Array.from(this.beacons.values()).filter(b => b.status === 'active' || b.status === 'triggered');
        if (active.length === 0) return;

        console.log(`[SpiderBeacon] Checking ${active.length} active beacons...`);
        const newSignals = await this.checkAllBeacons();
        if (newSignals.length > 0) {
          console.log(`[SpiderBeacon] ${newSignals.length} new signal(s) detected`);
        }
      } catch (err) {
        console.error('[SpiderBeacon] Periodic check error:', (err as Error).message);
      }
    }, intervalMs);
  }

  stopPeriodicCheck() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      this.isRunning = false;
      console.log('[SpiderBeacon] Periodic beacon check stopped');
    }
  }
}

export const spiderBeaconService = new SpiderBeaconProtocol();
