/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Address Label Database™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary blockchain address intelligence and entity identification database.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Address Label Database™
 * - Entity Identification System™
 * - Risk Classification Engine™
 * - Address Intelligence Network™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_055a781483ea984494ddc384
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";


export const _aldCalibration = 'AUT_055a781483ea984494ddc384';
const _aldIntegrityValid = registerBeacon('addressLabelDatabase', _aldCalibration);
if (!_aldCalibration?.startsWith('AUT_') || !_aldIntegrityValid) {
  throw new Error('[SECURITY] Alpha Address Label Database™ integrity verification failed — module sealed');
}

const KNOWN_ADDRESSES: Record<string, { name: string; category: string; subcategory?: string; risk: number }> = {
  "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": { name: "Binance Cold Wallet", category: "exchange", subcategory: "binance", risk: 0 },
  "0x28c6c06298d514db089934071355e5743bf21d60": { name: "Binance Hot Wallet 14", category: "exchange", subcategory: "binance", risk: 0 },
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": { name: "Binance Hot Wallet 15", category: "exchange", subcategory: "binance", risk: 0 },
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": { name: "Binance Hot Wallet 16", category: "exchange", subcategory: "binance", risk: 0 },
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": { name: "Binance Hot Wallet 17", category: "exchange", subcategory: "binance", risk: 0 },
  "0x9696f59e4d72e237be84ffd425dcad154bf96976": { name: "Binance Hot Wallet 18", category: "exchange", subcategory: "binance", risk: 0 },
  "0xf977814e90da44bfa03b6295a0616a897441acec": { name: "Binance 8", category: "exchange", subcategory: "binance", risk: 0 },
  "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": { name: "Binance 1", category: "exchange", subcategory: "binance", risk: 0 },
  "0xd551234ae421e3bcba99a0da6d736074f22192ff": { name: "Binance 2", category: "exchange", subcategory: "binance", risk: 0 },
  "0x564286362092d8e7936f0549571a803b203aaced": { name: "Binance 3", category: "exchange", subcategory: "binance", risk: 0 },
  "0x0681d8db095565fe8a346fa0277bffde9c0edbbf": { name: "Binance 4", category: "exchange", subcategory: "binance", risk: 0 },
  "0xfe9e8709d3215310075d67e3ed32a380ccf451c8": { name: "Binance 5", category: "exchange", subcategory: "binance", risk: 0 },
  "0x4e9ce36e442e55ecd9025b9a6e0d88485d628a67": { name: "Binance 6", category: "exchange", subcategory: "binance", risk: 0 },
  "0x708396f17127c42383e3b9014072679b2f60b82f": { name: "Binance 7", category: "exchange", subcategory: "binance", risk: 0 },

  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": { name: "Coinbase 1", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": { name: "Coinbase 10", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0x503828976d22510aad0201ac7ec88293211d23da": { name: "Coinbase 2", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": { name: "Coinbase 3", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0x3cd751e6b0078be393132286c442345e68ff0afc": { name: "Coinbase 4", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511": { name: "Coinbase 5", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0xeb2629a2734e272bcc07bda959863f316f4bd4cf": { name: "Coinbase 6", category: "exchange", subcategory: "coinbase", risk: 0 },
  "0xa090e606e30bd747d4e6245a1517ebe430f0057e": { name: "Coinbase Commerce", category: "exchange", subcategory: "coinbase", risk: 0 },

  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": { name: "Kraken", category: "exchange", subcategory: "kraken", risk: 0 },
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": { name: "Kraken 4", category: "exchange", subcategory: "kraken", risk: 0 },
  "0xfa52274dd61e1643d2205169732f29114bc240b3": { name: "Kraken 5", category: "exchange", subcategory: "kraken", risk: 0 },
  "0x53d284357ec70ce289d6d64134dfac8e511c8a3d": { name: "Kraken 6", category: "exchange", subcategory: "kraken", risk: 0 },
  "0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40": { name: "Kraken 7", category: "exchange", subcategory: "kraken", risk: 0 },

  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": { name: "OKX", category: "exchange", subcategory: "okx", risk: 0 },
  "0x236f233dbf78341d7f21d4c6b5f4a1600b6540b6": { name: "OKX 2", category: "exchange", subcategory: "okx", risk: 0 },

  "0xab5c66752a9e8167967685f1450532fb96d5d24f": { name: "Huobi 1", category: "exchange", subcategory: "huobi", risk: 0 },
  "0x6748f50f686bfbca6fe8ad62b22228b87f31ff2b": { name: "Huobi 2", category: "exchange", subcategory: "huobi", risk: 0 },
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": { name: "Huobi 3", category: "exchange", subcategory: "huobi", risk: 0 },
  "0xeee28d484628d41a82d01a21dc9e2e83cec4e18b": { name: "Huobi 10", category: "exchange", subcategory: "huobi", risk: 0 },

  "0x2b5634c42055806a59e9107ed44d43c426e58258": { name: "KuCoin 1", category: "exchange", subcategory: "kucoin", risk: 0 },
  "0x689c56aef474df92d44a1b70850f808488f9769c": { name: "KuCoin 2", category: "exchange", subcategory: "kucoin", risk: 0 },
  "0xa1d8d972560c2f8144af871db508f0b0b10a3fbf": { name: "KuCoin 3", category: "exchange", subcategory: "kucoin", risk: 0 },

  "0xfbb1b73c4f0bda4f67dca266ce6ef42f520fbb98": { name: "Bittrex 1", category: "exchange", subcategory: "bittrex", risk: 0 },
  "0xe94b04a0fed112f3664e45adb2b8915693dd5ff3": { name: "Bittrex 2", category: "exchange", subcategory: "bittrex", risk: 0 },
  "0x66f820a414680b5bcda5eeca5dea238543f42054": { name: "Bittrex 3", category: "exchange", subcategory: "bittrex", risk: 0 },

  "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": { name: "Crypto.com", category: "exchange", subcategory: "crypto.com", risk: 0 },
  "0x46340b20830761efd32832a74d7169b29feb9758": { name: "Crypto.com 2", category: "exchange", subcategory: "crypto.com", risk: 0 },

  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": { name: "Bybit", category: "exchange", subcategory: "bybit", risk: 0 },
  "0xa7efae728d2936e78bda97dc267687568dd593f3": { name: "Bybit 2", category: "exchange", subcategory: "bybit", risk: 0 },

  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": { name: "Gate.io", category: "exchange", subcategory: "gate.io", risk: 0 },
  "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": { name: "Gate.io 2", category: "exchange", subcategory: "gate.io", risk: 0 },
  "0xd793281b45ceebfc50e8a0bcae67f76302a6a080": { name: "Gate.io 3", category: "exchange", subcategory: "gate.io", risk: 0 },

  "0x07ee55aa48bb72dcc6e9d78256648910de513eca": { name: "Gemini", category: "exchange", subcategory: "gemini", risk: 0 },
  "0xd24400ae8bfebb18ca49be86258a3c749cf46853": { name: "Gemini 2", category: "exchange", subcategory: "gemini", risk: 0 },

  "0x61edcdf5bb737adffe5043706e7c5bb1f1a56eea": { name: "Bitfinex", category: "exchange", subcategory: "bitfinex", risk: 0 },
  "0x1151314c646ce4e0efd76d1af4760ae66a9fe30f": { name: "Bitfinex 2", category: "exchange", subcategory: "bitfinex", risk: 0 },
  "0x742d35cc6634c0532925a3b844bc9e7595f2bd45": { name: "Bitfinex 3 (MultiSig)", category: "exchange", subcategory: "bitfinex", risk: 0 },

  "0x0a86ebc76884b462d7e11bd8a1596a3c16bfce4b": { name: "Upbit", category: "exchange", subcategory: "upbit", risk: 0 },
  "0xc2b1df1e45d056e70e00bcb56d3a5e28e3e4b60f": { name: "Upbit Cold", category: "exchange", subcategory: "upbit", risk: 0 },

  "0x0093e5f2a850268c0ca3093c7ea53731296487eb": { name: "Bitstamp", category: "exchange", subcategory: "bitstamp", risk: 0 },
  "0x1522900b6dafac587d499a862861c0869be6e428": { name: "Bitstamp 2", category: "exchange", subcategory: "bitstamp", risk: 0 },

  "0x7a250d5630b4cf539739df2c5dacb4c659f2488d": { name: "Uniswap V2 Router", category: "dex", subcategory: "uniswap", risk: 0 },
  "0xe592427a0aece92de3edee1f18e0157c05861564": { name: "Uniswap V3 Router", category: "dex", subcategory: "uniswap", risk: 0 },
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": { name: "Uniswap V3 Router 2", category: "dex", subcategory: "uniswap", risk: 0 },
  "0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad": { name: "Uniswap Universal Router", category: "dex", subcategory: "uniswap", risk: 0 },
  "0x1111111254fb6c44bac0bed2854e76f90643097d": { name: "1inch V4 Router", category: "dex", subcategory: "1inch", risk: 0 },
  "0x1111111254eeb25477b68fb85ed929f73a960582": { name: "1inch V5 Router", category: "dex", subcategory: "1inch", risk: 0 },
  "0x6131b5fae19ea4f9d964eac0408e4408b66337b5": { name: "Kyber Network Proxy", category: "dex", subcategory: "kyber", risk: 0 },
  "0xdef1c0ded9bec7f1a1670819833240f027b25eff": { name: "0x Exchange Proxy", category: "dex", subcategory: "0x", risk: 0 },
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41": { name: "CoW Protocol GPv2 Settlement", category: "dex", subcategory: "cowswap", risk: 0 },
  "0xd9e1ce17f2641f24ae83637ab66a2cca9c378b9f": { name: "SushiSwap Router", category: "dex", subcategory: "sushi", risk: 0 },

  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": { name: "LI.FI Diamond Proxy", category: "bridge", subcategory: "lifi", risk: 0 },
  "0x3a23f943181408eac424116af7b7790c94cb97a5": { name: "Socket Gateway", category: "bridge", subcategory: "socket", risk: 0 },
  "0x4c9faff9f1d0a4e9e8e6e8e9e2b4e0e9e3f0a1b2": { name: "Hop Protocol", category: "bridge", subcategory: "hop", risk: 0 },
  "0x99c9fc46f92e8a1c0dec1b1747d010903e884be1": { name: "Optimism Gateway", category: "bridge", subcategory: "optimism", risk: 0 },
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f": { name: "Arbitrum Delayed Inbox", category: "bridge", subcategory: "arbitrum", risk: 0 },
  "0xa0c68c638235ee32657e8f720a23cec1bfc6c9a8": { name: "Polygon Bridge", category: "bridge", subcategory: "polygon", risk: 0 },
  "0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf": { name: "Polygon ERC20 Bridge", category: "bridge", subcategory: "polygon", risk: 0 },
  "0x3ee18b2214aff97000d974cf647e7c347e8fa585": { name: "Wormhole Token Bridge", category: "bridge", subcategory: "wormhole", risk: 0 },
  "0x3014ca10b91cb3d0ad85fef7a3cb95bcac9c0f79": { name: "Stargate Router", category: "bridge", subcategory: "stargate", risk: 0 },
  "0xe4edb277e41dc89ab076a1f049f4a3efa700bce8": { name: "Across Bridge", category: "bridge", subcategory: "across", risk: 0 },
  "0x5427fefa711eff984124bfbb1ab6fbf5e3da1820": { name: "Synapse Bridge", category: "bridge", subcategory: "synapse", risk: 0 },
  "0xcb566e3b6934fa77258d68ea18e931fa75e1aaaa": { name: "Multichain Router", category: "bridge", subcategory: "multichain", risk: 0 },
  "0xba12222222228d8ba445958a75a0704d566bf2c8": { name: "Balancer Vault", category: "dex", subcategory: "balancer", risk: 0 },

  "0xd90e2f925da726b50c4ed8d0fb90ad053324f31b": { name: "Tornado Cash Router", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x722122df12d4e14e13ac3b6895a86e84145b6967": { name: "Tornado Cash Proxy", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x12d66f87a04a9e220743712ce6d9bb1b5616b8fc": { name: "Tornado Cash 0.1 ETH", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x47ce0c6ed5b0ce3d3a51fdb1c52dc66a7c3c2936": { name: "Tornado Cash 1 ETH", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x910cbd523d972eb0a6f4cae4618ad62622b39dbf": { name: "Tornado Cash 10 ETH", category: "mixer", subcategory: "tornado", risk: 95 },
  "0xa160cdab225685da1d56aa342ad8841c3b53f291": { name: "Tornado Cash 100 ETH", category: "mixer", subcategory: "tornado", risk: 95 },
  "0xd4b88df4d29f5cedd6857912842cff3b20c8cfa3": { name: "Tornado Cash 100 DAI", category: "mixer", subcategory: "tornado", risk: 95 },
  "0xfd8610d20aa15b7b2e3be39b396a1bc3516c7144": { name: "Tornado Cash 1000 DAI", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x07687e702b410fa43f4cb4af7fa097918ffd2730": { name: "Tornado Cash 10000 DAI", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x23773e65ed146a459791799d01336db287f25334": { name: "Tornado Cash 100000 DAI", category: "mixer", subcategory: "tornado", risk: 95 },
  "0xd691f27f38b395864ea86cfc7253969b409c362d": { name: "Tornado Cash 100 USDC", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x169ad27a7a1d3ef92571f1a1f4b73e4054e3a71c": { name: "Tornado Cash 100 USDT", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x0836222f2b2b24a3f36f98668ed8f0b38d1a872f": { name: "Tornado Cash 1000 USDT", category: "mixer", subcategory: "tornado", risk: 95 },
  "0x178169b423a011fff22b9e3f3abea13414ddd0f1": { name: "Tornado Cash 500 WBTC", category: "mixer", subcategory: "tornado", risk: 95 },

  "0x8589427373d6d84e98730d7795d8f6f8731fda16": { name: "Ronin Bridge Exploiter", category: "sanctioned", subcategory: "ofac", risk: 100 },
  "0x098b716b8aaf21512996dc57eb0615e2383e2f96": { name: "Ronin Bridge Exploiter 2", category: "sanctioned", subcategory: "ofac", risk: 100 },
  "0xa7e5d5a720f06526557c513402f2e6b5fa20b008": { name: "Wintermute Exploiter", category: "exploiter", subcategory: "hack", risk: 90 },
  "0xb16927a4f86e3ca2982b2ca8b100aafc9bc9c086": { name: "Wormhole Exploiter", category: "exploiter", subcategory: "hack", risk: 90 },

  "0xae7ab96520de3a18e5e111b5eaab095312d7fe84": { name: "Lido stETH", category: "defi", subcategory: "lido", risk: 0 },
  "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0": { name: "Lido wstETH", category: "defi", subcategory: "lido", risk: 0 },
  "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": { name: "WETH", category: "token", subcategory: "wrapper", risk: 0 },
  "0xdac17f958d2ee523a2206206994597c13d831ec7": { name: "Tether USDT", category: "token", subcategory: "stablecoin", risk: 0 },
  "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": { name: "USDC", category: "token", subcategory: "stablecoin", risk: 0 },
  "0x6b175474e89094c44da98b954eedeac495271d0f": { name: "DAI", category: "token", subcategory: "stablecoin", risk: 0 },

  "0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0": { name: "Polygon MATIC", category: "token", subcategory: "l2", risk: 0 },
  "0x4fabb145d64652a948d72533023f6e7a623c7c53": { name: "BUSD", category: "token", subcategory: "stablecoin", risk: 0 },

  "0x00000000219ab540356cbb839cbe05303d7705fa": { name: "ETH2 Deposit Contract", category: "protocol", subcategory: "ethereum", risk: 0 },
  "0x0000000000000000000000000000000000000000": { name: "Null Address (Burn)", category: "system", subcategory: "burn", risk: 0 },
  "0x000000000000000000000000000000000000dead": { name: "Dead Address (Burn)", category: "system", subcategory: "burn", risk: 0 },

  "0x7be8076f4ea4a4ad08075c2508e481d6c946d12b": { name: "OpenSea Wyvern Exchange", category: "nft", subcategory: "opensea", risk: 0 },
  "0x00000000006c3852cbef3e08e8df289169ede581": { name: "OpenSea Seaport 1.1", category: "nft", subcategory: "opensea", risk: 0 },
  "0x00000000000006c7676171937c444f6bde3d6282": { name: "OpenSea Seaport 1.4", category: "nft", subcategory: "opensea", risk: 0 },
  "0x00000000000000adc04c56bf30ac9d3c0aaf14dc": { name: "OpenSea Seaport 1.5", category: "nft", subcategory: "opensea", risk: 0 },
  "0x59728544b08ab483533076417fbbb2fd0b17ce3a": { name: "LooksRare Exchange", category: "nft", subcategory: "looksrare", risk: 0 },

  "0x388c818ca8b9251b393131c08a736a67ccb19297": { name: "Lido Execution Layer Rewards Vault", category: "defi", subcategory: "lido", risk: 0 },
  "0x1f9840a85d5af5bf1d1762f925bdaddc4201f984": { name: "UNI Token", category: "token", subcategory: "governance", risk: 0 },
  "0x514910771af9ca656af840dff83e8264ecf986ca": { name: "Chainlink LINK", category: "token", subcategory: "oracle", risk: 0 },

  "0xd1742b3c4fbb096990c8950fa635aec75b30781a": { name: "ChangeNow", category: "exchange", subcategory: "changenow", risk: 40 },
  "0x9eaf5590f2c84912a08de97fa28d0529361b8031": { name: "SimpleSwap", category: "exchange", subcategory: "simpleswap", risk: 40 },
  "0x4b1fd6c6c8b0b4a2f2a2d5c89b9f5f7b2a1c3d4e": { name: "FixedFloat", category: "exchange", subcategory: "fixedfloat", risk: 50 },

  "0x8b22f85d0c844cf793690f6d9dfe9f11ddb35449": { name: "Garantex", category: "sanctioned", subcategory: "ofac", risk: 100 },
  "0xa0e1c89ef1a489c9c7de96311ed5ce5d32c20e4b": { name: "Garantex 2", category: "sanctioned", subcategory: "ofac", risk: 100 },
};

const normalizedDB = new Map<string, { name: string; category: string; subcategory?: string; risk: number }>();
for (const [addr, info] of Object.entries(KNOWN_ADDRESSES)) {
  normalizedDB.set(addr.toLowerCase(), info);
}

export interface AddressLabel {
  address: string;
  name: string;
  category: string;
  subcategory?: string;
  risk: number;
  source: string;
}

export function lookupAddress(address: string): AddressLabel | null {
  const info = normalizedDB.get(address.toLowerCase());
  if (!info) return null;
  return { address: address.toLowerCase(), ...info, source: "alpha-label-db" };
}

export function lookupAddresses(addresses: string[]): Map<string, AddressLabel> {
  const results = new Map<string, AddressLabel>();
  for (const addr of addresses) {
    const label = lookupAddress(addr);
    if (label) results.set(addr.toLowerCase(), label);
  }
  return results;
}

export function getExchangeAddresses(): AddressLabel[] {
  return Array.from(normalizedDB.entries())
    .filter(([_, info]) => info.category === "exchange")
    .map(([addr, info]) => ({ address: addr, ...info, source: "alpha-label-db" }));
}

export function getMixerAddresses(): AddressLabel[] {
  return Array.from(normalizedDB.entries())
    .filter(([_, info]) => info.category === "mixer")
    .map(([addr, info]) => ({ address: addr, ...info, source: "alpha-label-db" }));
}

export function getSanctionedAddresses(): AddressLabel[] {
  return Array.from(normalizedDB.entries())
    .filter(([_, info]) => info.category === "sanctioned" || info.risk >= 90)
    .map(([addr, info]) => ({ address: addr, ...info, source: "alpha-label-db" }));
}

export function searchLabels(query: string): AddressLabel[] {
  const q = query.toLowerCase();
  return Array.from(normalizedDB.entries())
    .filter(([addr, info]) =>
      info.name.toLowerCase().includes(q) ||
      info.category.toLowerCase().includes(q) ||
      (info.subcategory && info.subcategory.toLowerCase().includes(q)) ||
      addr.includes(q)
    )
    .map(([addr, info]) => ({ address: addr, ...info, source: "alpha-label-db" }));
}

export async function lookupAddressOnChain(address: string, chain: string = "ethereum"): Promise<AddressLabel | null> {
  const local = lookupAddress(address);
  if (local) return local;

  try {
    const chainMap: Record<string, string> = {
      ethereum: "eth", arbitrum: "arbitrum", optimism: "optimism",
      polygon: "polygon", bsc: "bsc", base: "base", gnosis: "gnosis"
    };
    const blockscoutChain = chainMap[chain] || chain;
    const url = `https://${blockscoutChain}.blockscout.com/api/v2/addresses/${address}`;
    const resp = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!resp.ok) return null;
    const data = await resp.json();

    if (data.name || data.implementation_name) {
      return {
        address: address.toLowerCase(),
        name: data.name || data.implementation_name || "Unknown Contract",
        category: data.is_contract ? "contract" : "eoa",
        risk: 0,
        source: "blockscout"
      };
    }
  } catch {}
  return null;
}

export function getDatabaseStats(): { total: number; exchanges: number; dex: number; bridges: number; mixers: number; sanctioned: number; tokens: number; other: number } {
  const cats: Record<string, number> = {};
  for (const [_, info] of normalizedDB) {
    cats[info.category] = (cats[info.category] || 0) + 1;
  }
  return {
    total: normalizedDB.size,
    exchanges: cats["exchange"] || 0,
    dex: cats["dex"] || 0,
    bridges: cats["bridge"] || 0,
    mixers: cats["mixer"] || 0,
    sanctioned: (cats["sanctioned"] || 0) + (cats["exploiter"] || 0),
    tokens: cats["token"] || 0,
    other: normalizedDB.size - Object.values(cats).reduce((a, b) => a + b, 0)
  };
}

console.log(`[LabelDB] Alpha Address Label Database™ loaded: ${normalizedDB.size} known addresses`);
