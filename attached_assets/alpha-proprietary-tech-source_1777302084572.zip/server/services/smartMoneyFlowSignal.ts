/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Smart-Money Flow Signal™
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws (Title 17 / DMCA / CFAA / DTSA).
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Tracks publicly-known smart-money / institutional wallets on-chain.
 * Aggregates token-level inflows vs outflows over a configurable window.
 * Emits buy/sell/hold signals based on consensus across multiple smart wallets.
 *
 * Patent Pending. Trade Secret Protected.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Smart-Money Flow Signal™');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';

/**
 * Curated set of publicly-known smart-money / institutional Ethereum wallets.
 * Sources: Arkham public attribution, Etherscan public labels, on-chain reporting.
 * NOT confidential — all addresses are publicly published entity attributions.
 */
export const SMART_MONEY_WALLETS: { address: string; entity: string; type: 'mm' | 'fund' | 'whale' | 'oracle' }[] = [
  { address: '0xae2fc483527b8ef99eb5d9b44875f005ba1fae13', entity: 'Jump Trading',            type: 'mm'    },
  { address: '0x9696f59e4d72e237be84ffd425dcad154bf96976', entity: 'Wintermute',              type: 'mm'    },
  { address: '0xcffad3200574698b78f32232aa9d63eabd290703', entity: 'DCP Capital',             type: 'fund'  },
  { address: '0x868dab0b8e21ec0a48b726a1ccf25826c78c6d7f', entity: 'Cumberland (DRW)',        type: 'mm'    },
  { address: '0x6cc5f688a315f3dc28a7781717a9a798a59fda7b', entity: 'OKX Hot Wallet 21',       type: 'mm'    },
  { address: '0x0d0707963952f2fba59dd06f2b425ace40b492fe', entity: 'Gate.io 1',               type: 'mm'    },
  { address: '0xd24400ae8bfebb18ca49be86258a3c749cf46853', entity: 'Gemini 4',                type: 'mm'    },
  { address: '0x7ff9cfad3877f21d41da833e2f775db0569ee3d9', entity: 'Justin Sun (Tron)',       type: 'whale' },
  { address: '0x176f3dab24a159341c0509bb36b833e7fdd0a132', entity: 'Coinbase Custody Cold 1', type: 'fund'  },
  { address: '0x1aaba3147c98e1d29ee2dc3aabad9f56fcab74a2', entity: 'Alameda Residual',        type: 'fund'  },
];

interface TransferRow {
  hash: string;
  from: string;
  to: string;
  asset: string;
  contract: string | null;
  value: number;
  ts: number;
  direction: 'buy' | 'sell';   // buy = smart money received, sell = smart money sent out
  smartWalletEntity: string;
}

interface TokenAggregate {
  asset: string;
  contract: string | null;
  buyers: string[];      // entity names that accumulated
  sellers: string[];     // entity names that distributed
  totalBuyValue: number;
  totalSellValue: number;
  netFlowValue: number;
  uniqueBuyers: number;
  uniqueSellers: number;
}

export interface SmartMoneySignal {
  asset: string;
  contract: string | null;
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  confidence: number;     // 0-100
  consensus: number;      // -1 (all sells) to +1 (all buys)
  buyers: string[];
  sellers: string[];
  netFlowValue: number;
  totalActivity: number;
  reasoning: string[];
}

export interface SmartMoneyReport {
  _proprietaryHeader: string;
  generatedAt: string;
  windowHours: number;
  walletsScanned: number;
  totalTransfers: number;
  signals: SmartMoneySignal[];
}

async function alchemyRpc<T = any>(method: string, params: any[]): Promise<T> {
  const url = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  if (!r.ok) throw new Error(`Alchemy ${method} failed: ${r.status}`);
  const j = await r.json();
  if (j.error) throw new Error(`Alchemy ${method} error: ${j.error.message}`);
  return j.result;
}

async function getCurrentBlock(): Promise<number> {
  const hex: string = await alchemyRpc('eth_blockNumber', []);
  return parseInt(hex, 16);
}

async function getTransfersForWallet(wallet: string, fromBlockHex: string, direction: 'in' | 'out'): Promise<any[]> {
  const params: any = {
    fromBlock: fromBlockHex,
    toBlock: 'latest',
    category: ['erc20'],
    maxCount: '0x32',
    withMetadata: true,
    order: 'desc',
  };
  if (direction === 'in') params.toAddress = wallet;
  else params.fromAddress = wallet;
  try {
    const res: any = await alchemyRpc('alchemy_getAssetTransfers', [params]);
    return res?.transfers || [];
  } catch {
    return [];
  }
}

export async function generateSmartMoneySignals(windowHours = 24): Promise<SmartMoneyReport> {
  if (!ALCHEMY_KEY) throw new Error('ALCHEMY_API_KEY is not set');

  const currentBlock = await getCurrentBlock();
  const blocksBack = Math.ceil((windowHours * 3600) / 12);  // ~12s/block
  const fromBlock = currentBlock - blocksBack;
  const fromBlockHex = `0x${fromBlock.toString(16)}`;

  const allTransfers: TransferRow[] = [];

  for (const w of SMART_MONEY_WALLETS) {
    const wAddr = w.address.toLowerCase();
    try {
      const [ins, outs] = await Promise.all([
        getTransfersForWallet(wAddr, fromBlockHex, 'in'),
        getTransfersForWallet(wAddr, fromBlockHex, 'out'),
      ]);
      for (const t of ins) {
        allTransfers.push({
          hash: t.hash, from: (t.from || '').toLowerCase(), to: wAddr,
          asset: t.asset || 'UNKNOWN', contract: t.rawContract?.address || null,
          value: typeof t.value === 'number' ? t.value : 0,
          ts: t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).getTime() : 0,
          direction: 'buy', smartWalletEntity: w.entity,
        });
      }
      for (const t of outs) {
        allTransfers.push({
          hash: t.hash, from: wAddr, to: (t.to || '').toLowerCase(),
          asset: t.asset || 'UNKNOWN', contract: t.rawContract?.address || null,
          value: typeof t.value === 'number' ? t.value : 0,
          ts: t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).getTime() : 0,
          direction: 'sell', smartWalletEntity: w.entity,
        });
      }
      await new Promise(r => setTimeout(r, 150));
    } catch {
      // continue on error per wallet
    }
  }

  // Aggregate by asset
  const byAsset: Record<string, TokenAggregate> = {};
  for (const t of allTransfers) {
    if (!t.asset || t.asset === 'UNKNOWN' || t.value <= 0) continue;
    const k = (t.contract || t.asset).toLowerCase();
    if (!byAsset[k]) byAsset[k] = {
      asset: t.asset, contract: t.contract,
      buyers: [], sellers: [],
      totalBuyValue: 0, totalSellValue: 0, netFlowValue: 0,
      uniqueBuyers: 0, uniqueSellers: 0,
    };
    if (t.direction === 'buy') {
      byAsset[k].totalBuyValue += t.value;
      if (!byAsset[k].buyers.includes(t.smartWalletEntity)) byAsset[k].buyers.push(t.smartWalletEntity);
    } else {
      byAsset[k].totalSellValue += t.value;
      if (!byAsset[k].sellers.includes(t.smartWalletEntity)) byAsset[k].sellers.push(t.smartWalletEntity);
    }
  }

  // Build signals
  const signals: SmartMoneySignal[] = [];
  for (const agg of Object.values(byAsset)) {
    agg.netFlowValue = agg.totalBuyValue - agg.totalSellValue;
    agg.uniqueBuyers = agg.buyers.length;
    agg.uniqueSellers = agg.sellers.length;
    const totalActivity = agg.uniqueBuyers + agg.uniqueSellers;
    if (totalActivity < 1) continue;
    const consensus = (agg.uniqueBuyers - agg.uniqueSellers) / totalActivity;

    let signal: SmartMoneySignal['signal'] = 'HOLD';
    if (consensus >= 0.66 && agg.uniqueBuyers >= 2) signal = 'STRONG_BUY';
    else if (consensus >= 0.33) signal = 'BUY';
    else if (consensus <= -0.66 && agg.uniqueSellers >= 2) signal = 'STRONG_SELL';
    else if (consensus <= -0.33) signal = 'SELL';

    const confidence = Math.min(100, Math.round(Math.abs(consensus) * 70 + Math.min(30, totalActivity * 5)));

    const reasoning: string[] = [];
    if (agg.uniqueBuyers > 0) reasoning.push(`${agg.uniqueBuyers} smart wallet${agg.uniqueBuyers > 1 ? 's' : ''} accumulating: ${agg.buyers.slice(0, 3).join(', ')}`);
    if (agg.uniqueSellers > 0) reasoning.push(`${agg.uniqueSellers} smart wallet${agg.uniqueSellers > 1 ? 's' : ''} distributing: ${agg.sellers.slice(0, 3).join(', ')}`);
    reasoning.push(`Net flow: ${agg.netFlowValue >= 0 ? '+' : ''}${agg.netFlowValue.toFixed(2)} ${agg.asset} over ${windowHours}h`);

    signals.push({
      asset: agg.asset, contract: agg.contract, signal, confidence,
      consensus: Math.round(consensus * 100) / 100,
      buyers: agg.buyers, sellers: agg.sellers,
      netFlowValue: agg.netFlowValue,
      totalActivity, reasoning,
    });
  }

  signals.sort((a, b) => b.confidence - a.confidence);

  return {
    _proprietaryHeader: proprietaryHeader('Alpha Smart-Money Flow Signal™'),
    generatedAt: new Date().toISOString(),
    windowHours,
    walletsScanned: SMART_MONEY_WALLETS.length,
    totalTransfers: allTransfers.length,
    signals: signals.slice(0, 25),
  };
}

// In-memory cache so the trading terminal can poll cheaply
let cache: { ts: number; report: SmartMoneyReport | null } = { ts: 0, report: null };
let inflight: Promise<SmartMoneyReport> | null = null;
const CACHE_TTL_MS = 5 * 60 * 1000;  // 5 min

export async function getCachedSmartMoneyReport(windowHours = 24): Promise<SmartMoneyReport> {
  if (cache.report && Date.now() - cache.ts < CACHE_TTL_MS) return cache.report;
  // Stampede guard: serve same in-flight promise to all concurrent callers during cache miss.
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const report = await generateSmartMoneySignals(windowHours);
      cache = { ts: Date.now(), report };
      return report;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}
