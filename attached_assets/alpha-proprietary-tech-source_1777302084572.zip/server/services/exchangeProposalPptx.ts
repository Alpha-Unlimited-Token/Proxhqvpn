/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Exchange Listing Proposal Generator™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module generates comprehensive exchange listing proposal presentations
 * for Alpha Unlimited Coin (AUC) — the world's first forensic-grade blockchain coin
 * with built-in law enforcement transfer hooks for cryptocurrency theft recovery.
 *
 * Technologies Protected:
 * - Alpha Exchange Listing Proposal Generator™
 * - AUC Forensic Blockchain Coin Specification
 * - Alpha Spider Beacon Protocol™ Integration Specification
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: EXCHANGE_PROPOSAL_v1.0_PROTECTED
 */

import { registerBeacon } from "./integrityBeacon.js";

export const _exchangeProposalModuleHash = 'AUT_ex01_proposal_listing_7c3a';
const _epIntegrity = registerBeacon('exchangeProposal', _exchangeProposalModuleHash);

const BRAND = {
  dark: "0A0E14",
  panel: "161B22",
  cyan: "22D3EE",
  emerald: "34D399",
  gold: "F59E0B",
  red: "EF4444",
  white: "FFFFFF",
  gray: "9CA3AF",
  lightGray: "D1D5DB",
  blue: "3B82F6",
  purple: "A855F7",
};

const COPYRIGHT = "© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity. Patent Pending. CONFIDENTIAL.";

export async function generateExchangeProposalPptx(): Promise<Buffer> {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();

  pptx.author = "Alpha Unlimited Trading Company";
  pptx.company = "Alpha Unlimited Trading Company";
  pptx.subject = "AUC Exchange Listing Proposal — Forensic-Grade Blockchain Coin";
  pptx.title = "Alpha Unlimited Coin (AUC) — Exchange Listing Proposal";

  const addFooter = (slide: any) => {
    slide.addText(COPYRIGHT, {
      x: 0.3, y: 6.8, w: 9.4, h: 0.3,
      fontSize: 6, color: BRAND.gray, align: "center",
      fontFace: "Arial",
    });
  };

  const addSlideNumber = (slide: any, num: number) => {
    slide.addText(`${num}`, {
      x: 9.2, y: 6.8, w: 0.5, h: 0.3,
      fontSize: 7, color: BRAND.gray, align: "right",
      fontFace: "Arial",
    });
  };

  // ─── SLIDE 1: TITLE ───
  let slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA UNLIMITED COIN (AUC)", {
    x: 0.5, y: 1.2, w: 9, h: 0.8,
    fontSize: 32, color: BRAND.gold, bold: true, align: "center",
    fontFace: "Arial",
  });
  slide.addText("Exchange Listing Proposal", {
    x: 0.5, y: 2.1, w: 9, h: 0.6,
    fontSize: 20, color: BRAND.cyan, align: "center",
    fontFace: "Arial",
  });
  slide.addText("The World's First Forensic-Grade Blockchain Coin\nBuilt-In Law Enforcement Transfer Hooks for Cryptocurrency Theft Recovery", {
    x: 0.5, y: 3.0, w: 9, h: 0.8,
    fontSize: 13, color: BRAND.lightGray, align: "center",
    fontFace: "Arial", lineSpacingMultiple: 1.3,
  });
  slide.addText("Alpha Unlimited Trading Company", {
    x: 0.5, y: 4.2, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.gold, align: "center", bold: true,
    fontFace: "Arial",
  });
  slide.addText("AlphaUnlimitedTrading.com", {
    x: 0.5, y: 4.6, w: 9, h: 0.3,
    fontSize: 11, color: BRAND.cyan, align: "center",
    fontFace: "Arial",
  });
  slide.addText("CONFIDENTIAL BUSINESS PROPOSAL", {
    x: 0.5, y: 5.3, w: 9, h: 0.4,
    fontSize: 11, color: BRAND.red, align: "center", bold: true,
    fontFace: "Arial",
  });
  addFooter(slide);

  // ─── SLIDE 2: TABLE OF CONTENTS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("TABLE OF CONTENTS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  const tocItems = [
    "1.  Executive Summary — Why AUC Needs to Be on Your Exchange",
    "2.  The Problem — $14 Billion in Crypto Theft (2023-2025)",
    "3.  The Solution — AUC Forensic Blockchain Architecture",
    "4.  How the AUC Trap Mechanism Works",
    "5.  Alpha Spider Beacon Protocol™ — Cross-Chain Tracking",
    "6.  AUC Tokenomics & Supply Structure",
    "7.  Revenue Model — 10% Recovery Fee",
    "8.  Technical Specifications & Smart Contract Security",
    "9.  Regulatory Compliance & Legal Framework",
    "10. Benefits to Your Exchange",
    "11. Exchange Integration Requirements",
    "12. Active Case Study — @sillytuna $24M Theft",
    "13. Law Enforcement Partnerships & Endorsement Strategy",
    "14. Roadmap & Milestones",
    "15. Exchange Contact Directory & Application Status",
    "16. Partnership Terms & Fee Waiver Request",
    "17. About Alpha Unlimited Trading Company",
    "18. Contact Information & Next Steps",
  ];
  slide.addText(tocItems.join("\n"), {
    x: 0.6, y: 1.1, w: 8.8, h: 5.2,
    fontSize: 11, color: BRAND.lightGray,
    fontFace: "Arial", lineSpacingMultiple: 1.35,
  });
  addFooter(slide);
  addSlideNumber(slide, 2);

  // ─── SLIDE 3: EXECUTIVE SUMMARY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("EXECUTIVE SUMMARY", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Why AUC Needs to Be Listed on Your Exchange", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 14, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "Alpha Unlimited Coin (AUC) is not a speculative token — it is the world's first forensic-grade blockchain coin purpose-built as a law enforcement tool for cryptocurrency theft investigation and fund recovery.\n\n" +
    "AUC features proprietary transfer hooks embedded at the blockchain level. When law enforcement agencies swap stolen cryptocurrency into AUC, every subsequent transfer, split, or swap triggers real-time forensic signals — reporting wallet addresses, amounts, timestamps, and chain movements back to the Alpha Forensic Intelligence Engine™ command center.\n\n" +
    "This technology is currently operational and is being used in an active $24 million theft investigation. However, AUC cannot fulfill its forensic mission unless it is listed on exchanges where stolen funds are being moved.\n\n" +
    "We are requesting a fee-waived listing as a public safety utility. In return, your exchange gains:\n" +
    "  •  Law enforcement partnership credibility\n" +
    "  •  Reduced liability from hosting stolen funds\n" +
    "  •  A unique anti-crime narrative that differentiates your brand\n" +
    "  •  Active cooperation credit with regulators",
    {
      x: 0.5, y: 1.4, w: 9, h: 5.0,
      fontSize: 10.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.3, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 3);

  // ─── SLIDE 4: THE PROBLEM ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("THE PROBLEM", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText("$14+ Billion in Cryptocurrency Theft (2023-2025)", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 14, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "The cryptocurrency industry faces an existential credibility crisis:\n\n" +
    "  •  2023: $1.7 billion stolen in crypto hacks and exploits\n" +
    "  •  2024: $2.2 billion stolen — a 21% increase year-over-year\n" +
    "  •  2025: On pace for $10+ billion with the Bybit hack ($1.5B) alone\n" +
    "  •  Recovery rate: Less than 5% of stolen crypto is ever returned to victims\n\n" +
    "Current limitations in theft recovery:\n\n" +
    "  •  Once stolen crypto is swapped or bridged, tracking becomes exponentially harder\n" +
    "  •  Mixers (Tornado Cash), cross-chain bridges, and DEX swaps break the evidence chain\n" +
    "  •  Monero conversion makes funds permanently untraceable\n" +
    "  •  Law enforcement lacks embedded blockchain-level tracking tools\n" +
    "  •  Exchange freeze requests are manual, slow, and often too late\n" +
    "  •  No existing coin was designed with forensic tracking as its primary purpose\n\n" +
    "The industry needs a coin that works WITH law enforcement — not against it.\n" +
    "AUC is that coin.",
    {
      x: 0.5, y: 1.4, w: 9, h: 5.0,
      fontSize: 10.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.3, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 4);

  // ─── SLIDE 5: THE SOLUTION ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("THE SOLUTION — AUC FORENSIC BLOCKCHAIN", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "AUC Architecture — Purpose-Built for Law Enforcement\n\n" +
    "Alpha Unlimited Coin is built on a proprietary blockchain with forensic capabilities embedded at the protocol level:\n\n" +
    "1. TRANSFER HOOKS (Patent Pending)\n" +
    "   Every AUC transaction triggers an automatic signal to the Alpha Forensic Intelligence Engine™.\n" +
    "   Signals include: sender address, receiver address, amount, timestamp, chain, and transaction hash.\n" +
    "   These hooks CANNOT be disabled, bypassed, or removed by any party.\n\n" +
    "2. AUC TRAP MECHANISM™\n" +
    "   Law enforcement swaps seized/flagged cryptocurrency into AUC.\n" +
    "   From that moment, every movement of those AUC tokens — transfers, splits, swaps, exchange deposits —\n" +
    "   generates real-time forensic signals visible in the command center.\n\n" +
    "3. CROSS-CHAIN BEACON RELAY\n" +
    "   When AUC is swapped back to other cryptocurrencies on any exchange, the Alpha Spider Beacon Protocol™\n" +
    "   automatically deploys dormant surveillance beacons on the destination chain to continue tracking.\n\n" +
    "4. IMMUTABLE AUDIT TRAIL\n" +
    "   Every forensic signal is cryptographically timestamped and stored, creating court-admissible evidence\n" +
    "   chains for prosecution.",
    {
      x: 0.5, y: 1.0, w: 9, h: 5.4,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.25, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 5);

  // ─── SLIDE 6: HOW THE AUC TRAP WORKS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("HOW THE AUC TRAP MECHANISM™ WORKS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Step-by-Step Forensic Tracking Process:\n\n" +
    "STEP 1: THEFT DETECTED\n" +
    "   Stolen funds identified on blockchain (e.g., $24M DAI theft from victim wallet).\n" +
    "   Alpha Forensic Intelligence Engine™ traces fund flows across chains.\n\n" +
    "STEP 2: LAW ENFORCEMENT AUTHORIZATION\n" +
    "   Law enforcement agency authorizes swap of flagged funds into AUC.\n" +
    "   Court order or agency directive establishes legal basis.\n\n" +
    "STEP 3: TOKEN SWAP EXECUTED\n" +
    "   Flagged cryptocurrency is swapped to AUC on a listed exchange.\n" +
    "   AUC Trap Mechanism™ activates — beacon deployed on trapped wallet.\n\n" +
    "STEP 4: PERPETUAL TRACKING BEGINS\n" +
    "   Every subsequent AUC movement triggers real-time signals:\n" +
    "   - Wallet address of recipient\n" +
    "   - Amount transferred\n" +
    "   - Timestamp (millisecond precision)\n" +
    "   - Exchange deposits detected and flagged\n" +
    "   - Cross-chain swap attempts intercepted\n\n" +
    "STEP 5: RECOVERY & PROSECUTION\n" +
    "   Tracked funds lead to exchange accounts → KYC identity revealed.\n" +
    "   Court-admissible evidence chain supports prosecution.\n" +
    "   Alpha Unlimited Trading Company receives 10% of recovered value as a service fee.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 6);

  // ─── SLIDE 7: SPIDER BEACON PROTOCOL ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA SPIDER BEACON PROTOCOL™", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Cross-Chain Persistent Surveillance System", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 14, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "The Spider Beacon Protocol extends AUC tracking beyond the AUC blockchain itself:\n\n" +
    "5 BEACON TYPES:\n" +
    "  •  Address Monitor — Continuous balance and transaction surveillance on any chain\n" +
    "  •  AUC Trap — Transfer hook signals from AUC blockchain movements\n" +
    "  •  Cross-Chain — Auto-deploys dormant beacons across 20+ chains when movement detected\n" +
    "  •  DEX Watcher — Monitors decentralized exchange interactions and swap patterns\n" +
    "  •  Bridge Sentinel — Detects cross-chain bridge transfers and fund routing\n\n" +
    "SUPPORTED NETWORKS (20+):\n" +
    "  Ethereum, Arbitrum, Optimism, Base, Polygon, BSC, Gnosis, Avalanche,\n" +
    "  Fantom, zkSync, Linea, Scroll, Celo, Blast, Mantle, Moonbeam,\n" +
    "  Cronos, Bitcoin, Solana, TRON\n\n" +
    "SIGNAL TYPES:\n" +
    "  Movement detected, Swap detected, Bridge detected, Exchange deposit,\n" +
    "  AUC trap triggered, DEX interaction, Cross-chain hop, Dormant activation, Balance change\n\n" +
    "WHY THIS MATTERS FOR EXCHANGES:\n" +
    "  When AUC is listed on your exchange, the Spider Beacon Protocol can detect stolen fund\n" +
    "  deposits BEFORE they are cashed out, reducing your regulatory liability.",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.0,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 7);

  // ─── SLIDE 8: TOKENOMICS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("AUC TOKENOMICS & SUPPLY STRUCTURE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Token Details:\n\n" +
    "  Name:              Alpha Unlimited Coin\n" +
    "  Ticker:            AUC\n" +
    "  Total Supply:      120,000,000,000 AUC (120 Billion)\n" +
    "  Blockchain:        Alpha Unlimited Proprietary Chain\n" +
    "  Consensus:         Proof of Authority + Forensic Hooks\n" +
    "  Primary Purpose:   Law enforcement forensic tracking utility\n" +
    "  Secondary Purpose: Trading, exchange medium within Alpha platform\n\n" +
    "Supply Distribution:\n\n" +
    "  •  Founder Reserve:        40% — Development, operations, partnerships\n" +
    "  •  Law Enforcement Pool:   25% — Reserved for forensic swap operations\n" +
    "  •  Exchange Liquidity:     15% — Provided to listed exchanges for market making\n" +
    "  •  Community & Ecosystem:  10% — Rewards, airdrops, community development\n" +
    "  •  Team & Advisors:        10% — Vested over 3 years with 1-year cliff\n\n" +
    "Anti-Manipulation Safeguards:\n\n" +
    "  •  Large transfers (>100,000 AUC) trigger automatic review\n" +
    "  •  All transfers logged with forensic-grade timestamps\n" +
    "  •  No anonymous wallets — all AUC wallets have platform identity linkage\n" +
    "  •  Exchange deposit monitoring built into protocol",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 8);

  // ─── SLIDE 9: REVENUE MODEL ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("REVENUE MODEL — 10% RECOVERY FEE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "How Alpha Unlimited Trading Company Generates Revenue:\n\n" +
    "AUC is a utility coin — not a speculative asset. The primary revenue model is a 10% success fee\n" +
    "on all cryptocurrency funds recovered through AUC forensic tracking operations.\n\n" +
    "FEE STRUCTURE:\n\n" +
    "  •  10% of recovered funds paid to Alpha Unlimited Trading Company upon successful recovery\n" +
    "  •  Fee is only charged when funds are ACTUALLY recovered — no upfront costs to victims\n" +
    "  •  Fee is documented in a Bounty Recovery Agreement signed before investigation begins\n" +
    "  •  Agreement includes digital signatures, case ID, and terms of engagement\n\n" +
    "EXAMPLE:\n" +
    "  Theft amount:    $24,000,000\n" +
    "  Funds recovered: $18,000,000\n" +
    "  Recovery fee:    $1,800,000 (10% of recovered amount)\n" +
    "  Victim receives: $16,200,000\n\n" +
    "TRACKING SYSTEM:\n" +
    "  •  Every recovery operation is tracked in the Alpha Forensic Intelligence Engine™\n" +
    "  •  Fee calculations are transparent and auditable\n" +
    "  •  Recovery metrics visible in the platform's Financial Overview dashboard\n" +
    "  •  Court filings reference the bounty agreement for legal standing\n\n" +
    "SUSTAINABILITY:\n" +
    "  With $14+ billion stolen annually, even a small percentage of recoveries creates\n" +
    "  a significant and sustainable revenue stream that funds ongoing platform development.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 9);

  // ─── SLIDE 10: TECHNICAL SPECIFICATIONS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("TECHNICAL SPECIFICATIONS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "AUC Blockchain Technical Architecture:\n\n" +
    "  Blockchain Type:     Proprietary (Alpha Unlimited Chain)\n" +
    "  Consensus:           Proof of Authority with Forensic Hooks\n" +
    "  Block Time:          ~3 seconds\n" +
    "  Transaction Finality: Immediate (single-confirmation)\n" +
    "  Smart Contracts:     Supported (EVM-compatible layer planned)\n" +
    "  P2P Network:         Custom node protocol with encrypted peer discovery\n" +
    "  Mining:              Stratum-compatible mining server (port 3333)\n" +
    "  API:                 REST + WebSocket real-time feeds\n\n" +
    "Security Features:\n\n" +
    "  •  HMAC-SHA256 integrity beacon system\n" +
    "  •  10-layer security architecture (109 active protection features)\n" +
    "  •  Anti-tampering with sealed module checksums\n" +
    "  •  Device fingerprinting and anti-debugging\n" +
    "  •  Rate limiting, WAF, CSRF protection\n\n" +
    "Exchange Integration:\n\n" +
    "  •  Standard deposit/withdrawal API compatible with major exchange backends\n" +
    "  •  WebSocket price feed for real-time market data\n" +
    "  •  Order book integration (limit/market orders already functional)\n" +
    "  •  AUC/USD, AUC/USDT, AUC/ETH, AUC/BTC trading pairs supported\n" +
    "  •  Full KYC/AML compliance on all AUC wallets",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 10);

  // ─── SLIDE 11: REGULATORY COMPLIANCE ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("REGULATORY COMPLIANCE & LEGAL FRAMEWORK", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "AUC is designed to SUPPORT regulators, not circumvent them:\n\n" +
    "COMPLIANCE FEATURES BUILT INTO AUC:\n\n" +
    "  •  Full KYC/AML — Every AUC wallet is linked to verified platform identity\n" +
    "  •  Transaction monitoring — All transfers logged with forensic-grade detail\n" +
    "  •  Exchange deposit detection — Automated alerts when AUC enters any exchange\n" +
    "  •  Court-admissible evidence — Cryptographic timestamps create legal audit trails\n" +
    "  •  Bounty Recovery Agreements — Digital signature legal framework for recovery fees\n\n" +
    "REGULATORY POSITIONING:\n\n" +
    "  •  AUC is classified as a UTILITY TOKEN — not a security\n" +
    "  •  Primary use case is law enforcement forensic tracking (not speculation)\n" +
    "  •  Designed to cooperate with SEC, FinCEN, FATF, and international regulators\n" +
    "  •  Anti-money laundering features exceed standard exchange requirements\n" +
    "  •  All AUC operations comply with the Bank Secrecy Act (BSA)\n\n" +
    "LEGAL FRAMEWORK:\n\n" +
    "  •  Alpha Unlimited Trading Company is a registered business entity\n" +
    "  •  Patent pending on forensic transfer hook technology\n" +
    "  •  Intellectual property protected under international copyright and trade secret law\n" +
    "  •  Bounty recovery agreements reference applicable state and federal law",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 11);

  // ─── SLIDE 12: BENEFITS TO EXCHANGE ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("BENEFITS TO YOUR EXCHANGE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Why listing AUC benefits your exchange:\n\n" +
    "1. REGULATORY CREDIBILITY\n" +
    "   Listing a law enforcement forensic tool demonstrates proactive anti-crime cooperation.\n" +
    "   Regulators view exchanges that support investigative tools more favorably.\n\n" +
    "2. REDUCED STOLEN FUND LIABILITY\n" +
    "   AUC's Spider Beacon Protocol can detect when stolen funds arrive at your exchange,\n" +
    "   enabling faster freeze responses and reducing your liability exposure.\n\n" +
    "3. UNIQUE BRAND DIFFERENTIATION\n" +
    "   No other exchange lists a forensic-grade coin. This positions your brand as a leader\n" +
    "   in crypto safety and anti-crime innovation.\n\n" +
    "4. LAW ENFORCEMENT PARTNERSHIP\n" +
    "   Listing AUC opens a direct channel for law enforcement cooperation,\n" +
    "   which can reduce subpoena response times and regulatory friction.\n\n" +
    "5. TRADING VOLUME FROM INSTITUTIONAL USE\n" +
    "   Government agencies, forensic firms, and victims using AUC for recovery operations\n" +
    "   generate consistent, legitimate trading volume.\n\n" +
    "6. EXCHANGE LIQUIDITY PROVIDED\n" +
    "   Alpha Unlimited Trading Company will provide initial AUC liquidity to your exchange\n" +
    "   at no cost, ensuring a functional order book from day one.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 12);

  // ─── SLIDE 13: INTEGRATION REQUIREMENTS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("EXCHANGE INTEGRATION REQUIREMENTS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "What your exchange needs to integrate AUC:\n\n" +
    "WALLET INTEGRATION:\n" +
    "  •  AUC deposit address generation via Alpha Unlimited API\n" +
    "  •  AUC withdrawal processing via standard API calls\n" +
    "  •  Balance confirmation: Single-confirmation finality (~3 seconds)\n" +
    "  •  Hot/cold wallet support with automated rebalancing\n\n" +
    "TRADING PAIRS:\n" +
    "  •  AUC/USDT (recommended primary pair)\n" +
    "  •  AUC/USD (for fiat-enabled exchanges)\n" +
    "  •  AUC/ETH (optional)\n" +
    "  •  AUC/BTC (optional)\n\n" +
    "API ENDPOINTS PROVIDED:\n" +
    "  •  GET  /api/auc/balance/:address     — Wallet balance query\n" +
    "  •  POST /api/auc/transfer             — Execute transfer\n" +
    "  •  GET  /api/auc/transactions/:address — Transaction history\n" +
    "  •  WS   /api/auc/stream               — Real-time price and trade feed\n\n" +
    "FORENSIC HOOK DISCLOSURE:\n" +
    "  Your exchange should disclose that AUC transactions are monitored for law enforcement\n" +
    "  forensic purposes. Alpha Unlimited Trading Company provides standard disclosure language\n" +
    "  for your terms of service.\n\n" +
    "SUPPORT:\n" +
    "  Alpha Unlimited Trading Company provides dedicated integration support at no cost.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 13);

  // ─── SLIDE 14: CASE STUDY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ACTIVE CASE STUDY — @sillytuna $24M THEFT", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Real-world demonstration of AUC forensic tracking capabilities:\n\n" +
    "CASE DETAILS:\n" +
    "  Victim:         Alex Amsel (@sillytuna on Twitter/X)\n" +
    "  Theft Type:     Physical home invasion + forced wallet access\n" +
    "  Amount Stolen:  ~$24,000,000\n" +
    "  Status:         ACTIVE INVESTIGATION\n\n" +
    "FUND BREAKDOWN TRACKED:\n" +
    "  •  ~$20M DAI moved from hub wallet to 12+ distribution wallets\n" +
    "  •  $2.47M converted to Monero via Hyperliquid/Wagyu Bridge (19 accounts)\n" +
    "  •  $1.1M Bitcoin via LiFi bridge (~0.5 BTC through mixer)\n" +
    "  •  $2.48M USDC distributed to 10 Arbitrum receiver wallets\n\n" +
    "ALPHA FORENSIC TECHNOLOGIES DEPLOYED:\n" +
    "  •  30+ Spider Beacons monitoring wallet activity across Ethereum and Arbitrum\n" +
    "  •  Autonomous Spider Trace™ — Recursive fund flow analysis\n" +
    "  •  OSINT Deep Scanner — 3,700+ addresses scanned across 22 platforms\n" +
    "  •  Laundering Risk Intelligence — Tornado Cash, Monero, and DeFi gap analysis\n" +
    "  •  Network Intelligence Tracer — Transaction timing and behavioral profiling\n" +
    "  •  24/7 automated email updates to victim\n\n" +
    "WHY AUC EXCHANGE LISTING MATTERS HERE:\n" +
    "  If AUC were listed on exchanges, law enforcement could swap flagged DAI and USDC\n" +
    "  into AUC, enabling perpetual tracking even through mixer and bridge operations.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 14);

  // ─── SLIDE 15: LAW ENFORCEMENT PARTNERSHIPS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("LAW ENFORCEMENT PARTNERSHIPS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.blue, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Strategy for Law Enforcement Adoption:\n\n" +
    "TARGET AGENCIES:\n" +
    "  •  FBI Internet Crime Complaint Center (IC3)\n" +
    "  •  U.S. Secret Service Cyber Fraud Task Force\n" +
    "  •  Department of Justice Cryptocurrency Enforcement\n" +
    "  •  Europol European Cybercrime Centre (EC3)\n" +
    "  •  UK National Crime Agency (NCA)\n" +
    "  •  INTERPOL Financial Crimes Unit\n" +
    "  •  State and local cybercrime units\n\n" +
    "TOOLS PROVIDED TO LAW ENFORCEMENT (FREE):\n" +
    "  •  Alpha Forensic Intelligence Engine™ command center access\n" +
    "  •  Spider Beacon deployment capabilities\n" +
    "  •  OSINT deep scanning across 22+ platforms\n" +
    "  •  Phantom Vault Protocol™ (honeypot wallet operations)\n" +
    "  •  Exchange freeze request automation\n" +
    "  •  18-slide technology briefing presentation (PPTX)\n" +
    "  •  Real-time wallet monitoring with email alerts\n\n" +
    "ENDORSEMENT STRATEGY:\n" +
    "  Law enforcement agency adoption of AUC as a forensic tool creates\n" +
    "  institutional demand that exchanges can point to as justification\n" +
    "  for listing. This creates a virtuous cycle: more exchanges listing AUC\n" +
    "  means more effective forensic operations, which drives more agency adoption.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 15);

  // ─── SLIDE 16: ROADMAP ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ROADMAP & MILESTONES", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "AUC Development & Listing Timeline:\n\n" +
    "COMPLETED:\n" +
    "  [+] AUC blockchain operational with genesis block and P2P network\n" +
    "  [+] AUC Trap Mechanism™ coded and tested\n" +
    "  [+] Alpha Spider Beacon Protocol™ live (30+ beacons deployed)\n" +
    "  [+] Internal exchange with order books, limit/market orders\n" +
    "  [+] Stripe integration for USD deposits\n" +
    "  [+] Alpha Forensic Intelligence Engine™ fully operational\n" +
    "  [+] Active case investigation ($24M theft) demonstrating capabilities\n" +
    "  [+] Law enforcement technology briefing materials created\n\n" +
    "Q2 2026:\n" +
    "  [ ] Submit listing applications to Coinbase, Kraken, KuCoin, Gate.io\n" +
    "  [ ] Deploy AUC as ERC-20 wrapper for DEX listing (Uniswap)\n" +
    "  [ ] Apply to CoinMarketCap and CoinGecko for tracking\n" +
    "  [ ] Begin law enforcement outreach program\n\n" +
    "Q3 2026:\n" +
    "  [ ] First external exchange listing\n" +
    "  [ ] Law enforcement pilot program with agency partner\n" +
    "  [ ] Smart contract audit by third-party security firm\n\n" +
    "Q4 2026:\n" +
    "  [ ] Major exchange listing (Binance/Coinbase target)\n" +
    "  [ ] Multi-agency forensic operations live\n" +
    "  [ ] First 10% recovery fee collection from successful case",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 16);

  // ─── SLIDE 17: EXCHANGE DIRECTORY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("EXCHANGE CONTACT DIRECTORY", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Target Exchanges for AUC Listing Applications", {
    x: 0.5, y: 0.85, w: 9, h: 0.35,
    fontSize: 13, color: BRAND.gold,
    fontFace: "Arial",
  });

  const rows: any[][] = [
    [
      { text: "Exchange", options: { bold: true, color: BRAND.cyan, fill: { color: "111827" }, fontSize: 8 } },
      { text: "Listing Fee", options: { bold: true, color: BRAND.cyan, fill: { color: "111827" }, fontSize: 8 } },
      { text: "Contact / Application", options: { bold: true, color: BRAND.cyan, fill: { color: "111827" }, fontSize: 8 } },
    ],
    [
      { text: "Coinbase", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "coinbase.com/listings\nlistings-support@coinbase.com", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "Kraken", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE (form)", options: { fontSize: 8, color: BRAND.emerald } },
      { text: "kraken.com/get-listed\n(form only — no email)", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "Binance", options: { fontSize: 8, color: BRAND.white } },
      { text: "$100K-$500K+", options: { fontSize: 8, color: BRAND.red } },
      { text: "binance.com/support/faq (online form)\nlistings@binance.us (Binance.US)", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "KuCoin", options: { fontSize: 8, color: BRAND.white } },
      { text: "Negotiable", options: { fontSize: 8, color: BRAND.gold } },
      { text: "kucoin.com/listing (AssetsHub)\nsupport@kucoin.com", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "Gate.io", options: { fontSize: 8, color: BRAND.white } },
      { text: "Claims FREE", options: { fontSize: 8, color: BRAND.emerald } },
      { text: "gate.com/listing\nlisting@gate.com", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "OKX", options: { fontSize: 8, color: BRAND.white } },
      { text: "Negotiable", options: { fontSize: 8, color: BRAND.gold } },
      { text: "okx.com/token-listing-apply\n(form + legal opinion required)", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "MEXC", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE + $60K mktg", options: { fontSize: 8, color: BRAND.gold } },
      { text: "MEXC listing form on website\nlisting@mexc.com", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "Uniswap (DEX)", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE (gas only)", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Permissionless — create liquidity pool\nRequires ERC-20 wrapper token", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "CoinMarketCap", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "support.coinmarketcap.com (request form)\nMust be trading on tracked exchange", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
    [
      { text: "CoinGecko", options: { fontSize: 8, color: BRAND.white } },
      { text: "FREE", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "coingecko.com/request\nMust be trading on tracked exchange", options: { fontSize: 7, color: BRAND.lightGray } },
    ],
  ];

  slide.addTable(rows, {
    x: 0.3, y: 1.3, w: 9.4,
    border: { type: "solid", color: "374151", pt: 0.5 },
    colW: [1.4, 1.4, 6.6],
    rowH: [0.35, 0.45, 0.45, 0.45, 0.45, 0.45, 0.45, 0.45, 0.45, 0.45, 0.45],
    fill: { color: BRAND.panel },
    margin: [3, 5, 3, 5],
  });

  addFooter(slide);
  addSlideNumber(slide, 17);

  // ─── SLIDE 18: FEE WAIVER REQUEST ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("PARTNERSHIP TERMS & FEE WAIVER REQUEST", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "We are requesting a fee-waived listing for AUC based on its unique position\nas a law enforcement forensic utility — not a speculative token.\n\n" +
    "OUR REQUEST:\n\n" +
    "  •  Waive standard listing fees for AUC as a public safety utility\n" +
    "  •  Listing AUC sends a powerful message that your exchange actively supports\n" +
    "     law enforcement efforts to combat cryptocurrency theft\n\n" +
    "WHAT WE PROVIDE IN RETURN:\n\n" +
    "  •  Initial AUC liquidity for your exchange at no cost\n" +
    "  •  Co-branded press release announcing the law enforcement partnership\n" +
    "  •  Spider Beacon integration for your exchange (detect stolen fund deposits)\n" +
    "  •  Priority freeze request processing for your compliance team\n" +
    "  •  Joint marketing as a \"crypto safety partner\"\n" +
    "  •  Ongoing technical support and API integration assistance\n\n" +
    "PRECEDENT:\n\n" +
    "  Coinbase, Kraken, and Gate.io already offer free listings for qualifying projects.\n" +
    "  AUC's law enforcement utility provides an even stronger justification for fee waiver\n" +
    "  than standard project metrics.\n\n" +
    "  We believe this is an opportunity for your exchange to lead the industry in\n" +
    "  proactive anti-crime cooperation while gaining a differentiated competitive advantage.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 18);

  // ─── SLIDE 19: ABOUT COMPANY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ABOUT ALPHA UNLIMITED TRADING COMPANY", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Alpha Unlimited Trading Company operates two platforms:\n\n" +
    "ALPHAUNLIMITEDTRADING.COM\n" +
    "  A comprehensive cryptocurrency trading platform featuring:\n" +
    "  •  Advanced Trading Terminal with real-time charts and AI signals\n" +
    "  •  14 types of AI Trading Bots with 24/7 server-side execution\n" +
    "  •  Alpha Autonomous Command Center™ (AACC™) — AI-powered market scanning\n" +
    "  •  20 proprietary trading indicators and technology packages\n" +
    "  •  Multi-chain wallet management across 8+ blockchains\n" +
    "  •  AUC Exchange — internal exchange with order books and Stripe integration\n" +
    "  •  Alpha Forensic Intelligence Engine™ — blockchain forensic investigation suite\n\n" +
    "ALPHAUNLIMITEDTOKEN.COM\n" +
    "  Community and NFT platform featuring:\n" +
    "  •  AI-generated NFT marketplace\n" +
    "  •  Play-to-earn Alpha Game\n" +
    "  •  Community hub with social features\n\n" +
    "PROPRIETARY TECHNOLOGIES (PATENT PENDING):\n" +
    "  •  Alpha Spider Beacon Protocol™\n" +
    "  •  AUC Trap Mechanism™\n" +
    "  •  Alpha Forensic Intelligence Engine™\n" +
    "  •  Alpha Phantom Vault Protocol™\n" +
    "  •  Alpha SafeSend Protocol™\n" +
    "  •  Alpha SafeAsset Protocol™\n" +
    "  •  Autonomous Blockchain Spider™\n" +
    "  •  20+ additional proprietary modules",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 19);

  // ─── SLIDE 20: CONTACT & NEXT STEPS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("CONTACT INFORMATION & NEXT STEPS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Next Steps for Exchange Partnership:\n\n" +
    "  1.  Review this proposal and the accompanying technical documentation\n" +
    "  2.  Schedule a video call demonstration of the Alpha Forensic Intelligence Engine™\n" +
    "  3.  Discuss listing terms, trading pairs, and integration timeline\n" +
    "  4.  Execute listing agreement with fee waiver terms\n" +
    "  5.  Begin technical integration (API, wallet, order book)\n" +
    "  6.  Announce partnership and go live\n\n\n" +
    "CONTACT:\n\n" +
    "  Company:    Alpha Unlimited Trading Company\n" +
    "  Website:    AlphaUnlimitedTrading.com\n" +
    "  Email:      forensics@alphaunlimitedtrading.com\n" +
    "  Platform:   AlphaUnlimitedTrading.com\n\n\n" +
    "ADDITIONAL MATERIALS AVAILABLE:\n\n" +
    "  •  Law Enforcement Technology Briefing (18-slide PPTX)\n" +
    "  •  AUC Blockchain Technical Whitepaper\n" +
    "  •  Spider Beacon Protocol™ Technical Specification\n" +
    "  •  Live platform demonstration at AlphaUnlimitedTrading.com\n" +
    "  •  Active case study data (redacted for privacy)",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 11, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  slide.addText("Thank you for considering Alpha Unlimited Coin as a listing partner.", {
    x: 0.5, y: 6.2, w: 9, h: 0.4,
    fontSize: 12, color: BRAND.gold, align: "center", italic: true,
    fontFace: "Arial",
  });
  addFooter(slide);
  addSlideNumber(slide, 20);

  const buffer = await pptx.write({ outputType: "nodebuffer" });
  return buffer as Buffer;
}
