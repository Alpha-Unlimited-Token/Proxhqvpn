/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Deep Market Intelligence Engine™ (ADMIE™) is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 */

import { registerBeacon } from "./integrityBeacon.js";

export const _admieSeal = 'AUT_5f77da30a3fe47311a4cb76c';
const _admieIntegrityValid = registerBeacon('technicalAnalysis', _admieSeal);
if (!_admieSeal?.startsWith('AUT_') || !_admieIntegrityValid) {
  throw new Error('ADMIE™ module integrity compromised — unauthorized modification detected');
}

export interface Candle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
}

export type TimeframeTrend = 'strong_buy' | 'buy' | 'neutral' | 'sell' | 'strong_sell';

export interface TimeframeAnalysis {
  trend: TimeframeTrend;
  rsi: number;
  buyVolume: number;
  sellVolume: number;
  volumeBias: 'buying' | 'selling' | 'neutral';
  buyPressurePercent: number;
  priceChange: number;
  candleCount: number;
  consecutiveGreen: number;
  consecutiveRed: number;
}

export interface MarketCapData {
  marketCap: number;
  marketCapRank: 'mega' | 'large' | 'mid' | 'small' | 'micro';
  volume24h: number;
  volumeToMcapRatio: number;
  circulatingSupply: number;
}

export interface TechnicalProfile {
  symbol: string;
  rsi14: number;
  rsi7: number;
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  macdCrossover: 'bullish' | 'bearish' | 'none';
  ema9: number;
  ema21: number;
  ema50: number;
  sma200: number;
  emaCrossover: 'golden_cross' | 'death_cross' | 'none';
  priceVsEma50: number;
  priceVsSma200: number;
  bollingerUpper: number;
  bollingerMiddle: number;
  bollingerLower: number;
  bollingerWidth: number;
  bollingerPosition: number;
  atr14: number;
  atrPercent: number;
  adx14: number;
  plusDI: number;
  minusDI: number;
  trendStrength: 'strong' | 'moderate' | 'weak' | 'no_trend';
  vwap: number;
  priceVsVwap: number;
  obv: number;
  obvTrend: 'rising' | 'falling' | 'flat';
  supportLevel: number;
  resistanceLevel: number;
  priceVsSupport: number;
  priceVsResistance: number;
  volumeProfile: 'above_average' | 'average' | 'below_average';
  volumeRatio: number;
  trendDirection30d: 'strong_bullish' | 'bullish' | 'neutral' | 'bearish' | 'strong_bearish';
  trendConsistency: number;
  consecutiveGreenDays: number;
  consecutiveRedDays: number;
  highsVsLows: number;
  meanReversionSignal: 'oversold_bounce' | 'overbought_reversal' | 'none';
  breakoutSignal: 'bullish_breakout' | 'bearish_breakdown' | 'none';
  momentumScore: number;
  overallScore: number;
  confidence: number;
  recommendation: 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell';
  analysisAge: number;
  timeframes: {
    tf30d: TimeframeAnalysis;
    tf24h: TimeframeAnalysis;
    tf1h: TimeframeAnalysis;
    tf5m: TimeframeAnalysis;
    tf1m: TimeframeAnalysis;
  };
  multiTimeframeTrend: TimeframeTrend;
  multiTimeframeAlignment: number;
  buyVolumePressure: number;
  sellVolumePressure: number;
  overallVolumeBias: 'strong_buying' | 'buying' | 'neutral' | 'selling' | 'strong_selling';
  marketCap: number;
  marketCapRank: 'mega' | 'large' | 'mid' | 'small' | 'micro';
  volume24hUsd: number;
  volumeToMcapRatio: number;
}

const candleCache = new Map<string, { candles: Candle[]; ts: number }>();
const profileCache = new Map<string, { profile: TechnicalProfile; ts: number }>();
const CANDLE_CACHE_TTL = 120000;
const PROFILE_CACHE_TTL = 60000;

function taLog(msg: string) {
  console.log(`[ADMIE] ${msg}`);
}

function safeNum(v: number, fallback: number = 0): number {
  return Number.isFinite(v) ? v : fallback;
}

function preciseRound(v: number): number {
  if (!Number.isFinite(v) || v === 0) return 0;
  const abs = Math.abs(v);
  if (abs < 1e-15) return 0;
  if (abs >= 1) return Math.round(v * 10000) / 10000;
  if (abs >= 0.001) return Math.round(v * 1000000) / 1000000;
  if (abs >= 0.000001) return Math.round(v * 1000000000) / 1000000000;
  if (abs >= 1e-12) return Math.round(v * 1e12) / 1e12;
  return 0;
}

function lastFinite(arr: number[], fallback: number = 0): number {
  for (let i = arr.length - 1; i >= 0; i--) {
    if (Number.isFinite(arr[i])) return arr[i];
  }
  return fallback;
}

export async function fetchCandles(symbol: string, interval: string = '1d', limit: number = 30): Promise<Candle[]> {
  const cacheKey = `${symbol}_${interval}_${limit}`;
  const cached = candleCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CANDLE_CACHE_TTL) return cached.candles;

  try {
    const url = `https://data-api.binance.vision/api/v3/klines?symbol=${symbol.replace('/', '').toUpperCase()}&interval=${interval}&limit=${limit}`;
    const res = await globalThis.fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [];

    const data = await res.json();
    const candles: Candle[] = data.map((k: any[]) => ({
      openTime: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      closeTime: k[6],
    }));

    candleCache.set(cacheKey, { candles, ts: Date.now() });
    return candles;
  } catch {
    return [];
  }
}

function calcEMA(values: number[], period: number): number[] {
  if (values.length < period) return values.map(() => NaN);
  const multiplier = 2 / (period + 1);
  const ema: number[] = [];
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  ema[period - 1] = sum / period;
  for (let i = 0; i < period - 1; i++) ema[i] = NaN;
  for (let i = period; i < values.length; i++) {
    ema[i] = (values[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  return ema;
}

function calcSMA(values: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) { sma.push(NaN); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += values[j];
    sma.push(sum / period);
  }
  return sma;
}

function calcRSI(closes: number[], period: number): number {
  if (closes.length < period + 1) return 50;
  let avgGain = 0, avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) avgGain += change; else avgLoss += Math.abs(change);
  }
  avgGain /= period;
  avgLoss /= period;
  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calcMACD(closes: number[]): { macdLine: number[]; signalLine: number[]; histogram: number[] } {
  const ema12 = calcEMA(closes, 12);
  const ema26 = calcEMA(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const validMacd = macdLine.filter(v => !isNaN(v));
  const signalLine = calcEMA(validMacd, 9);
  const fullSignal: number[] = [];
  let si = 0;
  for (let i = 0; i < macdLine.length; i++) {
    if (isNaN(macdLine[i])) { fullSignal.push(NaN); }
    else { fullSignal.push(si < signalLine.length ? signalLine[si++] : NaN); }
  }
  const histogram = macdLine.map((v, i) => v - fullSignal[i]);
  return { macdLine, signalLine: fullSignal, histogram };
}

function calcBollingerBands(closes: number[], period: number = 20, stdDev: number = 2): { upper: number[]; middle: number[]; lower: number[]; width: number[] } {
  const sma = calcSMA(closes, period);
  const upper: number[] = [];
  const lower: number[] = [];
  const width: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (isNaN(sma[i])) { upper.push(NaN); lower.push(NaN); width.push(NaN); continue; }
    let sumSq = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sumSq += (closes[j] - sma[i]) ** 2;
    }
    const sd = Math.sqrt(sumSq / period);
    upper.push(sma[i] + stdDev * sd);
    lower.push(sma[i] - stdDev * sd);
    width.push(sma[i] > 0 ? ((upper[i] - lower[i]) / sma[i]) * 100 : 0);
  }
  return { upper, middle: sma, lower, width };
}

function calcATR(candles: Candle[], period: number = 14): number[] {
  const tr: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) { tr.push(candles[i].high - candles[i].low); continue; }
    const hl = candles[i].high - candles[i].low;
    const hpc = Math.abs(candles[i].high - candles[i - 1].close);
    const lpc = Math.abs(candles[i].low - candles[i - 1].close);
    tr.push(Math.max(hl, hpc, lpc));
  }
  const atr: number[] = [];
  let sum = 0;
  for (let i = 0; i < period && i < tr.length; i++) sum += tr[i];
  if (tr.length >= period) {
    atr[period - 1] = sum / period;
    for (let i = 0; i < period - 1; i++) atr[i] = NaN;
    for (let i = period; i < tr.length; i++) {
      atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period;
    }
  }
  return atr;
}

function calcADX(candles: Candle[], period: number = 14): { adx: number; plusDI: number; minusDI: number } {
  if (candles.length < period * 2) return { adx: 25, plusDI: 25, minusDI: 25 };

  const plusDM: number[] = [];
  const minusDM: number[] = [];
  const tr: number[] = [];

  for (let i = 1; i < candles.length; i++) {
    const upMove = candles[i].high - candles[i - 1].high;
    const downMove = candles[i - 1].low - candles[i].low;
    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
    const hl = candles[i].high - candles[i].low;
    const hpc = Math.abs(candles[i].high - candles[i - 1].close);
    const lpc = Math.abs(candles[i].low - candles[i - 1].close);
    tr.push(Math.max(hl, hpc, lpc));
  }

  let smoothPlusDM = 0, smoothMinusDM = 0, smoothTR = 0;
  for (let i = 0; i < period; i++) {
    smoothPlusDM += plusDM[i];
    smoothMinusDM += minusDM[i];
    smoothTR += tr[i];
  }

  const dxValues: number[] = [];
  for (let i = period; i < plusDM.length; i++) {
    smoothPlusDM = smoothPlusDM - (smoothPlusDM / period) + plusDM[i];
    smoothMinusDM = smoothMinusDM - (smoothMinusDM / period) + minusDM[i];
    smoothTR = smoothTR - (smoothTR / period) + tr[i];

    const pdi = smoothTR > 0 ? (smoothPlusDM / smoothTR) * 100 : 0;
    const mdi = smoothTR > 0 ? (smoothMinusDM / smoothTR) * 100 : 0;
    const diDiff = Math.abs(pdi - mdi);
    const diSum = pdi + mdi;
    const dx = diSum > 0 ? (diDiff / diSum) * 100 : 0;
    dxValues.push(dx);
  }

  if (dxValues.length === 0) return { adx: 25, plusDI: 25, minusDI: 25 };

  let adx = dxValues.slice(0, period).reduce((s, v) => s + v, 0) / Math.min(period, dxValues.length);
  for (let i = period; i < dxValues.length; i++) {
    adx = (adx * (period - 1) + dxValues[i]) / period;
  }

  const lastPDI = smoothTR > 0 ? (smoothPlusDM / smoothTR) * 100 : 25;
  const lastMDI = smoothTR > 0 ? (smoothMinusDM / smoothTR) * 100 : 25;

  return { adx: Math.round(adx * 100) / 100, plusDI: Math.round(lastPDI * 100) / 100, minusDI: Math.round(lastMDI * 100) / 100 };
}

function calcOBV(candles: Candle[]): { obv: number; trend: 'rising' | 'falling' | 'flat' } {
  if (candles.length < 5) return { obv: 0, trend: 'flat' };
  let obv = 0;
  const obvHistory: number[] = [0];
  for (let i = 1; i < candles.length; i++) {
    if (candles[i].close > candles[i - 1].close) obv += candles[i].volume;
    else if (candles[i].close < candles[i - 1].close) obv -= candles[i].volume;
    obvHistory.push(obv);
  }
  const recent = obvHistory.slice(-5);
  const avgRecent = recent.reduce((s, v) => s + v, 0) / recent.length;
  const older = obvHistory.slice(-10, -5);
  const avgOlder = older.length > 0 ? older.reduce((s, v) => s + v, 0) / older.length : avgRecent;
  const changePercent = avgOlder !== 0 ? ((avgRecent - avgOlder) / Math.abs(avgOlder)) * 100 : 0;
  return { obv, trend: changePercent > 5 ? 'rising' : changePercent < -5 ? 'falling' : 'flat' };
}

function calcVWAP(candles: Candle[]): number {
  let cumVolPrice = 0, cumVol = 0;
  for (const c of candles) {
    const typicalPrice = (c.high + c.low + c.close) / 3;
    cumVolPrice += typicalPrice * c.volume;
    cumVol += c.volume;
  }
  return cumVol > 0 ? cumVolPrice / cumVol : 0;
}

function findSupportResistance(candles: Candle[]): { support: number; resistance: number } {
  if (candles.length < 5) return { support: 0, resistance: Infinity };
  const lows = candles.map(c => c.low).sort((a, b) => a - b);
  const highs = candles.map(c => c.high).sort((a, b) => b - a);
  const support = lows.slice(0, Math.ceil(lows.length * 0.2)).reduce((s, v) => s + v, 0) / Math.ceil(lows.length * 0.2);
  const resistance = highs.slice(0, Math.ceil(highs.length * 0.2)).reduce((s, v) => s + v, 0) / Math.ceil(highs.length * 0.2);
  return { support, resistance };
}

function analyzeTrend30d(candles: Candle[]): {
  direction: 'strong_bullish' | 'bullish' | 'neutral' | 'bearish' | 'strong_bearish';
  consistency: number;
  greenDays: number;
  redDays: number;
  highsVsLows: number;
} {
  if (candles.length < 5) return { direction: 'neutral', consistency: 0, greenDays: 0, redDays: 0, highsVsLows: 0 };

  let greenDays = 0, redDays = 0, higherHighs = 0, lowerLows = 0;
  for (let i = 0; i < candles.length; i++) {
    if (candles[i].close >= candles[i].open) greenDays++; else redDays++;
    if (i > 0) {
      if (candles[i].high > candles[i - 1].high) higherHighs++;
      if (candles[i].low < candles[i - 1].low) lowerLows++;
    }
  }

  let consecutiveGreen = 0, consecutiveRed = 0;
  for (let i = candles.length - 1; i >= 0; i--) {
    if (candles[i].close >= candles[i].open) {
      if (consecutiveRed === 0) consecutiveGreen++;
      else break;
    } else {
      if (consecutiveGreen === 0) consecutiveRed++;
      else break;
    }
  }

  const totalChange = candles.length > 1 ? ((candles[candles.length - 1].close - candles[0].open) / candles[0].open) * 100 : 0;
  const greenRatio = greenDays / candles.length;
  const hhRatio = candles.length > 1 ? higherHighs / (candles.length - 1) : 0;
  const llRatio = candles.length > 1 ? lowerLows / (candles.length - 1) : 0;

  const consistency = Math.abs(greenRatio - 0.5) * 2;

  let direction: 'strong_bullish' | 'bullish' | 'neutral' | 'bearish' | 'strong_bearish';
  if (totalChange > 20 && greenRatio > 0.65) direction = 'strong_bullish';
  else if (totalChange > 5 && greenRatio > 0.55) direction = 'bullish';
  else if (totalChange < -20 && greenRatio < 0.35) direction = 'strong_bearish';
  else if (totalChange < -5 && greenRatio < 0.45) direction = 'bearish';
  else direction = 'neutral';

  return {
    direction,
    consistency,
    greenDays: consecutiveGreen,
    redDays: consecutiveRed,
    highsVsLows: hhRatio - llRatio,
  };
}

function detectMeanReversion(rsi: number, bbPosition: number, priceVsVwap: number): 'oversold_bounce' | 'overbought_reversal' | 'none' {
  if (rsi < 30 && bbPosition < 0.1 && priceVsVwap < -3) return 'oversold_bounce';
  if (rsi > 70 && bbPosition > 0.9 && priceVsVwap > 3) return 'overbought_reversal';
  return 'none';
}

function detectBreakout(
  price: number, resistance: number, support: number,
  volume: number, avgVolume: number,
  bbWidth: number, atrPercent: number
): 'bullish_breakout' | 'bearish_breakdown' | 'none' {
  const volumeSpike = volume > avgVolume * 1.5;
  if (price > resistance && volumeSpike && bbWidth > 3) return 'bullish_breakout';
  if (price < support && volumeSpike && bbWidth > 3) return 'bearish_breakdown';
  return 'none';
}

function calculateMomentumScore(
  rsi14: number, macdHistogram: number, priceVsEma50: number,
  adx: number, plusDI: number, minusDI: number,
  obvTrend: string, volumeRatio: number
): number {
  let score = 0;

  if (rsi14 > 50 && rsi14 < 70) score += 15;
  else if (rsi14 >= 40 && rsi14 <= 50) score += 8;
  else if (rsi14 < 30) score += 12;
  else if (rsi14 > 80) score -= 5;

  if (macdHistogram > 0) score += 10;
  if (macdHistogram > 0.01) score += 5;

  if (priceVsEma50 > 0 && priceVsEma50 < 10) score += 10;
  else if (priceVsEma50 >= 10) score += 5;
  else if (priceVsEma50 < -5) score -= 5;

  if (adx > 25 && plusDI > minusDI) score += 15;
  else if (adx > 25 && plusDI < minusDI) score -= 10;
  else if (adx < 20) score += 2;

  if (obvTrend === 'rising') score += 8;
  else if (obvTrend === 'falling') score -= 5;

  if (volumeRatio > 1.5) score += 7;
  else if (volumeRatio > 1.0) score += 3;

  return Math.max(0, Math.min(100, score + 30));
}

function analyzeTimeframe(candles: Candle[]): TimeframeAnalysis {
  if (candles.length < 3) {
    return {
      trend: 'neutral', rsi: 50, buyVolume: 0, sellVolume: 0,
      volumeBias: 'neutral', buyPressurePercent: 50, priceChange: 0,
      candleCount: candles.length, consecutiveGreen: 0, consecutiveRed: 0,
    };
  }

  const closes = candles.map(c => c.close);
  const rsi = calcRSI(closes, Math.min(14, Math.floor(candles.length / 2)));

  let buyVol = 0, sellVol = 0;
  for (const c of candles) {
    if (c.close >= c.open) {
      const bodyRatio = c.high !== c.low ? (c.close - c.open) / (c.high - c.low) : 0.5;
      buyVol += c.volume * (0.5 + bodyRatio * 0.5);
      sellVol += c.volume * (0.5 - bodyRatio * 0.5);
    } else {
      const bodyRatio = c.high !== c.low ? (c.open - c.close) / (c.high - c.low) : 0.5;
      sellVol += c.volume * (0.5 + bodyRatio * 0.5);
      buyVol += c.volume * (0.5 - bodyRatio * 0.5);
    }
  }
  buyVol = Math.max(0, buyVol);
  sellVol = Math.max(0, sellVol);

  const totalVol = buyVol + sellVol;
  const buyPressure = totalVol > 0 ? (buyVol / totalVol) * 100 : 50;

  let volumeBias: 'buying' | 'selling' | 'neutral';
  if (buyPressure > 58) volumeBias = 'buying';
  else if (buyPressure < 42) volumeBias = 'selling';
  else volumeBias = 'neutral';

  const first = candles[0].open;
  const last = candles[candles.length - 1].close;
  const priceChange = first > 0 ? ((last - first) / first) * 100 : 0;

  let consecutiveGreen = 0, consecutiveRed = 0;
  for (let i = candles.length - 1; i >= 0; i--) {
    if (candles[i].close >= candles[i].open) {
      if (consecutiveRed === 0) consecutiveGreen++;
      else break;
    } else {
      if (consecutiveGreen === 0) consecutiveRed++;
      else break;
    }
  }

  let greenCount = 0;
  for (const c of candles) if (c.close >= c.open) greenCount++;
  const greenRatio = greenCount / candles.length;

  const ema3 = calcEMA(closes, Math.min(3, closes.length));
  const ema8 = calcEMA(closes, Math.min(8, closes.length));
  const lastEma3 = lastFinite(ema3, last);
  const lastEma8 = lastFinite(ema8, last);
  const emaSignal = lastEma3 > lastEma8 ? 1 : lastEma3 < lastEma8 ? -1 : 0;

  let trendScore = 0;
  if (priceChange > 3) trendScore += 2;
  else if (priceChange > 0.5) trendScore += 1;
  else if (priceChange < -3) trendScore -= 2;
  else if (priceChange < -0.5) trendScore -= 1;

  if (rsi > 60) trendScore += 1;
  else if (rsi < 40) trendScore -= 1;

  trendScore += emaSignal;

  if (volumeBias === 'buying') trendScore += 1;
  else if (volumeBias === 'selling') trendScore -= 1;

  if (greenRatio > 0.65) trendScore += 1;
  else if (greenRatio < 0.35) trendScore -= 1;

  let trend: TimeframeTrend;
  if (trendScore >= 4) trend = 'strong_buy';
  else if (trendScore >= 2) trend = 'buy';
  else if (trendScore <= -4) trend = 'strong_sell';
  else if (trendScore <= -2) trend = 'sell';
  else trend = 'neutral';

  return {
    trend, rsi: Math.round(rsi * 100) / 100,
    buyVolume: Math.round(buyVol), sellVolume: Math.round(sellVol),
    volumeBias, buyPressurePercent: Math.round(buyPressure * 100) / 100,
    priceChange: Math.round(priceChange * 100) / 100,
    candleCount: candles.length,
    consecutiveGreen, consecutiveRed,
  };
}

function trendToScore(t: TimeframeTrend): number {
  switch (t) {
    case 'strong_buy': return 100;
    case 'buy': return 75;
    case 'neutral': return 50;
    case 'sell': return 25;
    case 'strong_sell': return 0;
  }
}

function scoreToTrend(s: number): TimeframeTrend {
  if (s >= 80) return 'strong_buy';
  if (s >= 62) return 'buy';
  if (s <= 20) return 'strong_sell';
  if (s <= 38) return 'sell';
  return 'neutral';
}

function computeMultiTimeframeTrend(
  tf30d: TimeframeAnalysis, tf24h: TimeframeAnalysis,
  tf1h: TimeframeAnalysis, tf5m: TimeframeAnalysis, tf1m: TimeframeAnalysis
): { trend: TimeframeTrend; alignment: number } {
  const scores = [
    { score: trendToScore(tf30d.trend), weight: 0.15 },
    { score: trendToScore(tf24h.trend), weight: 0.25 },
    { score: trendToScore(tf1h.trend),  weight: 0.30 },
    { score: trendToScore(tf5m.trend),  weight: 0.20 },
    { score: trendToScore(tf1m.trend),  weight: 0.10 },
  ];

  const weighted = scores.reduce((s, e) => s + e.score * e.weight, 0);
  const trend = scoreToTrend(weighted);

  const allScores = [trendToScore(tf30d.trend), trendToScore(tf24h.trend), trendToScore(tf1h.trend), trendToScore(tf5m.trend), trendToScore(tf1m.trend)];
  const allBuy = allScores.every(s => s >= 62);
  const allSell = allScores.every(s => s <= 38);
  const mean = allScores.reduce((a, b) => a + b, 0) / allScores.length;
  const variance = allScores.reduce((s, v) => s + (v - mean) ** 2, 0) / allScores.length;
  const stdDev = Math.sqrt(variance);
  let alignment = Math.max(0, Math.min(100, 100 - stdDev * 2));
  if (allBuy || allSell) alignment = Math.max(alignment, 90);

  return { trend, alignment: Math.round(alignment) };
}

function computeOverallVolumeBias(
  tf30d: TimeframeAnalysis, tf24h: TimeframeAnalysis,
  tf1h: TimeframeAnalysis, tf5m: TimeframeAnalysis, tf1m: TimeframeAnalysis
): { buyPressure: number; sellPressure: number; bias: 'strong_buying' | 'buying' | 'neutral' | 'selling' | 'strong_selling' } {
  const weightedBuy =
    tf30d.buyPressurePercent * 0.10 +
    tf24h.buyPressurePercent * 0.20 +
    tf1h.buyPressurePercent * 0.30 +
    tf5m.buyPressurePercent * 0.25 +
    tf1m.buyPressurePercent * 0.15;

  const sellPressure = 100 - weightedBuy;

  let bias: 'strong_buying' | 'buying' | 'neutral' | 'selling' | 'strong_selling';
  if (weightedBuy >= 65) bias = 'strong_buying';
  else if (weightedBuy >= 55) bias = 'buying';
  else if (weightedBuy <= 35) bias = 'strong_selling';
  else if (weightedBuy <= 45) bias = 'selling';
  else bias = 'neutral';

  return {
    buyPressure: Math.round(weightedBuy * 100) / 100,
    sellPressure: Math.round(sellPressure * 100) / 100,
    bias,
  };
}

const marketDataCache = new Map<string, { data: MarketCapData; ts: number }>();
const MARKET_DATA_CACHE_TTL = 300000;

async function fetchMarketData(symbol: string): Promise<MarketCapData> {
  const cached = marketDataCache.get(symbol);
  if (cached && Date.now() - cached.ts < MARKET_DATA_CACHE_TTL) return cached.data;

  try {
    const url = `https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${symbol.replace('/', '').toUpperCase()}`;
    const res = await globalThis.fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error('failed');
    const d = await res.json();

    const lastPrice = parseFloat(d.lastPrice) || 0;
    const volume24h = parseFloat(d.quoteVolume) || 0;
    const weightedAvgPrice = parseFloat(d.weightedAvgPrice) || lastPrice;
    const baseVolume = parseFloat(d.volume) || 0;
    const circulatingSupply = baseVolume > 0 ? baseVolume : (lastPrice > 0 ? volume24h / lastPrice : 0);
    const marketCap = weightedAvgPrice * circulatingSupply;

    let marketCapRank: 'mega' | 'large' | 'mid' | 'small' | 'micro';
    if (volume24h > 1_000_000_000) marketCapRank = 'mega';
    else if (volume24h > 100_000_000) marketCapRank = 'large';
    else if (volume24h > 10_000_000) marketCapRank = 'mid';
    else if (volume24h > 1_000_000) marketCapRank = 'small';
    else marketCapRank = 'micro';

    const volumeToMcapRatio = marketCap > 0 ? volume24h / marketCap : 0;

    const data: MarketCapData = {
      marketCap: Math.round(marketCap),
      marketCapRank,
      volume24h: Math.round(volume24h),
      volumeToMcapRatio: Math.round(volumeToMcapRatio * 10000) / 10000,
      circulatingSupply: Math.round(circulatingSupply),
    };

    marketDataCache.set(symbol, { data, ts: Date.now() });
    return data;
  } catch {
    return { marketCap: 0, marketCapRank: 'micro', volume24h: 0, volumeToMcapRatio: 0, circulatingSupply: 0 };
  }
}

function generateRecommendation(overallScore: number, trendDir: string, meanReversion: string, breakout: string): 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell' {
  if (overallScore >= 80 && (trendDir === 'strong_bullish' || breakout === 'bullish_breakout')) return 'strong_buy';
  if (overallScore >= 65 && trendDir !== 'bearish' && trendDir !== 'strong_bearish') return 'buy';
  if (overallScore <= 25 && (trendDir === 'strong_bearish' || breakout === 'bearish_breakdown')) return 'strong_sell';
  if (overallScore <= 40 && trendDir !== 'bullish' && trendDir !== 'strong_bullish') return 'sell';
  return 'hold';
}

export async function analyzeCoin(symbol: string): Promise<TechnicalProfile | null> {
  const cleanSymbol = symbol.replace('/', '').toUpperCase();
  const cacheKey = cleanSymbol;
  const cached = profileCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < PROFILE_CACHE_TTL) return cached.profile;

  const [dailyCandles, hourlyCandles, candles1h, candles5m, candles1m, marketData] = await Promise.all([
    fetchCandles(cleanSymbol, '1d', 35),
    fetchCandles(cleanSymbol, '4h', 50),
    fetchCandles(cleanSymbol, '1h', 60),
    fetchCandles(cleanSymbol, '5m', 60),
    fetchCandles(cleanSymbol, '1m', 60),
    fetchMarketData(cleanSymbol),
  ]);

  if (dailyCandles.length < 14) return null;

  const closes = dailyCandles.map(c => c.close);
  const currentPrice = closes[closes.length - 1];

  const rsi14 = calcRSI(closes, 14);
  const rsi7 = calcRSI(closes, 7);

  const { macdLine, signalLine, histogram } = calcMACD(closes);
  const lastMacd = lastFinite(macdLine, 0);
  const lastSignal = lastFinite(signalLine, 0);
  const lastHistogram = lastFinite(histogram, 0);
  const prevHistogram = histogram.length >= 2 ? safeNum(histogram[histogram.length - 2], 0) : 0;
  let macdCrossover: 'bullish' | 'bearish' | 'none' = 'none';
  if (lastHistogram > 0 && prevHistogram <= 0) macdCrossover = 'bullish';
  else if (lastHistogram < 0 && prevHistogram >= 0) macdCrossover = 'bearish';

  const ema9 = calcEMA(closes, 9);
  const ema21 = calcEMA(closes, 21);
  const ema50 = calcEMA(closes, Math.min(50, closes.length));
  const sma200Arr = closes.length >= 30 ? calcSMA(closes, Math.min(200, closes.length)) : [currentPrice];

  const lastEma9 = lastFinite(ema9, currentPrice);
  const lastEma21 = lastFinite(ema21, currentPrice);
  const lastEma50 = lastFinite(ema50, currentPrice);
  const lastSma200 = lastFinite(sma200Arr, currentPrice);

  let emaCrossover: 'golden_cross' | 'death_cross' | 'none' = 'none';
  if (ema9.length >= 2 && ema21.length >= 2) {
    const prevEma9 = safeNum(ema9[ema9.length - 2], lastEma9);
    const prevEma21 = safeNum(ema21[ema21.length - 2], lastEma21);
    if (lastEma9 > lastEma21 && prevEma9 <= prevEma21) emaCrossover = 'golden_cross';
    else if (lastEma9 < lastEma21 && prevEma9 >= prevEma21) emaCrossover = 'death_cross';
  }

  const priceVsEma50 = lastEma50 > 0 ? safeNum(((currentPrice - lastEma50) / lastEma50) * 100, 0) : 0;
  const priceVsSma200 = lastSma200 > 0 ? safeNum(((currentPrice - lastSma200) / lastSma200) * 100, 0) : 0;

  const bb = calcBollingerBands(closes, Math.min(20, closes.length), 2);
  const bbUpper = lastFinite(bb.upper, currentPrice * 1.02);
  const bbMiddle = lastFinite(bb.middle, currentPrice);
  const bbLower = lastFinite(bb.lower, currentPrice * 0.98);
  const bbWidth = lastFinite(bb.width, 4);
  const bbRange = bbUpper - bbLower;
  const bbPosition = bbRange > 0 ? safeNum((currentPrice - bbLower) / bbRange, 0.5) : 0.5;

  const atrArr = calcATR(dailyCandles, 14);
  const atr14 = lastFinite(atrArr, 0);
  const atrPercent = currentPrice > 0 ? safeNum((atr14 / currentPrice) * 100, 0) : 0;

  const { adx: adx14, plusDI, minusDI } = calcADX(dailyCandles, 14);
  let trendStrength: 'strong' | 'moderate' | 'weak' | 'no_trend';
  if (adx14 > 40) trendStrength = 'strong';
  else if (adx14 > 25) trendStrength = 'moderate';
  else if (adx14 > 15) trendStrength = 'weak';
  else trendStrength = 'no_trend';

  const vwap = calcVWAP(dailyCandles.slice(-10));
  const priceVsVwap = vwap > 0 ? ((currentPrice - vwap) / vwap) * 100 : 0;

  const { obv, trend: obvTrend } = calcOBV(dailyCandles);
  const { support: supportLevel, resistance: resistanceLevel } = findSupportResistance(dailyCandles);
  const priceVsSupport = supportLevel > 0 ? ((currentPrice - supportLevel) / supportLevel) * 100 : 0;
  const priceVsResistance = resistanceLevel > 0 ? ((currentPrice - resistanceLevel) / resistanceLevel) * 100 : 0;

  const volumes = dailyCandles.map(c => c.volume);
  const avgVolume = volumes.reduce((s, v) => s + v, 0) / volumes.length;
  const lastVolume = volumes[volumes.length - 1] || 0;
  const volumeRatio = avgVolume > 0 ? lastVolume / avgVolume : 1;
  let volumeProfile: 'above_average' | 'average' | 'below_average';
  if (volumeRatio > 1.3) volumeProfile = 'above_average';
  else if (volumeRatio < 0.7) volumeProfile = 'below_average';
  else volumeProfile = 'average';

  const trendAnalysis = analyzeTrend30d(dailyCandles);
  const meanReversionSignal = detectMeanReversion(rsi14, bbPosition, priceVsVwap);
  const breakoutSignal = detectBreakout(currentPrice, resistanceLevel, supportLevel, lastVolume, avgVolume, bbWidth, atrPercent);

  const momentumScore = calculateMomentumScore(rsi14, lastHistogram, priceVsEma50, adx14, plusDI, minusDI, obvTrend, volumeRatio);

  const tf30d = analyzeTimeframe(dailyCandles);
  const tf24h = analyzeTimeframe(hourlyCandles.length > 0 ? hourlyCandles.slice(-6) : candles1h.slice(-24));
  const tf1h = analyzeTimeframe(candles1h);
  const tf5m = analyzeTimeframe(candles5m);
  const tf1m = analyzeTimeframe(candles1m);

  const sparseTimeframes = [candles1h, candles5m, candles1m].filter(c => c.length < 5).length;

  let { trend: multiTimeframeTrend, alignment: multiTimeframeAlignment } = computeMultiTimeframeTrend(tf30d, tf24h, tf1h, tf5m, tf1m);
  if (sparseTimeframes >= 2) {
    multiTimeframeAlignment = Math.min(multiTimeframeAlignment, 40);
  } else if (sparseTimeframes === 1) {
    multiTimeframeAlignment = Math.min(multiTimeframeAlignment, 65);
  }
  const volumeBiasData = computeOverallVolumeBias(tf30d, tf24h, tf1h, tf5m, tf1m);

  let overallScore = 0;
  overallScore += momentumScore * 0.20;

  let trendScore = 0;
  if (trendAnalysis.direction === 'strong_bullish') trendScore = 90;
  else if (trendAnalysis.direction === 'bullish') trendScore = 70;
  else if (trendAnalysis.direction === 'neutral') trendScore = 50;
  else if (trendAnalysis.direction === 'bearish') trendScore = 30;
  else trendScore = 10;
  overallScore += trendScore * 0.15;

  let techScore = 50;
  if (macdCrossover === 'bullish') techScore += 15;
  if (macdCrossover === 'bearish') techScore -= 15;
  if (emaCrossover === 'golden_cross') techScore += 20;
  if (emaCrossover === 'death_cross') techScore -= 20;
  if (priceVsEma50 > 0) techScore += 5;
  if (priceVsEma50 < 0) techScore -= 5;
  if (rsi14 < 30) techScore += 10;
  if (rsi14 > 70) techScore -= 10;
  if (breakoutSignal === 'bullish_breakout') techScore += 15;
  if (breakoutSignal === 'bearish_breakdown') techScore -= 15;
  if (meanReversionSignal === 'oversold_bounce') techScore += 10;
  if (meanReversionSignal === 'overbought_reversal') techScore -= 10;
  techScore = Math.max(0, Math.min(100, techScore));
  overallScore += techScore * 0.15;

  let volumeScore = 50;
  if (obvTrend === 'rising') volumeScore += 15;
  if (obvTrend === 'falling') volumeScore -= 15;
  if (volumeRatio > 1.5) volumeScore += 10;
  if (volumeRatio < 0.5) volumeScore -= 10;
  if (volumeBiasData.bias === 'strong_buying') volumeScore += 15;
  else if (volumeBiasData.bias === 'buying') volumeScore += 8;
  else if (volumeBiasData.bias === 'strong_selling') volumeScore -= 15;
  else if (volumeBiasData.bias === 'selling') volumeScore -= 8;
  volumeScore = Math.max(0, Math.min(100, volumeScore));
  overallScore += volumeScore * 0.15;

  const mtfScore = trendToScore(multiTimeframeTrend);
  overallScore += mtfScore * 0.25;

  let marketCapScore = 50;
  if (marketData.marketCapRank === 'mega') marketCapScore = 75;
  else if (marketData.marketCapRank === 'large') marketCapScore = 65;
  else if (marketData.marketCapRank === 'mid') marketCapScore = 55;
  else if (marketData.marketCapRank === 'small') marketCapScore = 40;
  else marketCapScore = 25;
  if (marketData.volumeToMcapRatio > 0.1) marketCapScore += 10;
  else if (marketData.volumeToMcapRatio < 0.01) marketCapScore -= 10;
  marketCapScore = Math.max(0, Math.min(100, marketCapScore));
  overallScore += marketCapScore * 0.10;

  if (multiTimeframeAlignment > 80) {
    if (multiTimeframeTrend === 'strong_buy' || multiTimeframeTrend === 'buy') overallScore += 5;
    else if (multiTimeframeTrend === 'strong_sell' || multiTimeframeTrend === 'sell') overallScore -= 5;
  }

  if (tf1m.trend === 'strong_sell' && tf5m.trend === 'sell' && tf1h.trend !== 'buy') {
    overallScore -= 8;
  }
  if (tf1m.trend === 'strong_buy' && tf5m.trend === 'buy' && tf1h.trend !== 'sell') {
    overallScore += 5;
  }

  overallScore = Math.round(Math.max(0, Math.min(100, overallScore)));

  let confidence = 50;
  if (dailyCandles.length >= 30) confidence += 10;
  else if (dailyCandles.length >= 20) confidence += 5;
  if (candles1h.length >= 40) confidence += 5;
  if (candles5m.length >= 40) confidence += 5;
  if (candles1m.length >= 30) confidence += 3;
  if (adx14 > 25) confidence += 8;
  if (volumeRatio > 1.0) confidence += 3;
  if (trendAnalysis.consistency > 0.3) confidence += 5;
  if (macdCrossover !== 'none') confidence += 3;
  if (emaCrossover !== 'none') confidence += 3;
  if (multiTimeframeAlignment > 70) confidence += 8;
  else if (multiTimeframeAlignment < 30) confidence -= 5;
  if (marketData.volume24h > 10_000_000) confidence += 5;
  confidence = Math.min(95, confidence);

  const recommendation = generateRecommendation(overallScore, trendAnalysis.direction, meanReversionSignal, breakoutSignal);

  const profile: TechnicalProfile = {
    symbol: cleanSymbol,
    rsi14: Math.round(rsi14 * 100) / 100,
    rsi7: Math.round(rsi7 * 100) / 100,
    macdLine: preciseRound(lastMacd),
    macdSignal: preciseRound(lastSignal),
    macdHistogram: preciseRound(lastHistogram),
    macdCrossover,
    ema9: preciseRound(lastEma9),
    ema21: preciseRound(lastEma21),
    ema50: preciseRound(lastEma50),
    sma200: preciseRound(lastSma200),
    emaCrossover,
    priceVsEma50: Math.round(priceVsEma50 * 100) / 100,
    priceVsSma200: Math.round(priceVsSma200 * 100) / 100,
    bollingerUpper: preciseRound(bbUpper),
    bollingerMiddle: preciseRound(bbMiddle),
    bollingerLower: preciseRound(bbLower),
    bollingerWidth: Math.round(bbWidth * 100) / 100,
    bollingerPosition: Math.round(bbPosition * 100) / 100,
    atr14: preciseRound(atr14),
    atrPercent: Math.round(atrPercent * 100) / 100,
    adx14: Math.round(adx14 * 100) / 100,
    plusDI: Math.round(plusDI * 100) / 100,
    minusDI: Math.round(minusDI * 100) / 100,
    trendStrength,
    vwap: preciseRound(vwap),
    priceVsVwap: Math.round(priceVsVwap * 100) / 100,
    obv,
    obvTrend,
    supportLevel: preciseRound(supportLevel),
    resistanceLevel: preciseRound(resistanceLevel),
    priceVsSupport: Math.round(priceVsSupport * 100) / 100,
    priceVsResistance: Math.round(priceVsResistance * 100) / 100,
    volumeProfile,
    volumeRatio: Math.round(volumeRatio * 100) / 100,
    trendDirection30d: trendAnalysis.direction,
    trendConsistency: Math.round(trendAnalysis.consistency * 100) / 100,
    consecutiveGreenDays: trendAnalysis.greenDays,
    consecutiveRedDays: trendAnalysis.redDays,
    highsVsLows: Math.round(trendAnalysis.highsVsLows * 100) / 100,
    meanReversionSignal,
    breakoutSignal,
    momentumScore,
    overallScore,
    confidence,
    recommendation,
    analysisAge: Date.now(),
    timeframes: { tf30d, tf24h, tf1h, tf5m, tf1m },
    multiTimeframeTrend,
    multiTimeframeAlignment,
    buyVolumePressure: volumeBiasData.buyPressure,
    sellVolumePressure: volumeBiasData.sellPressure,
    overallVolumeBias: volumeBiasData.bias,
    marketCap: marketData.marketCap,
    marketCapRank: marketData.marketCapRank,
    volume24hUsd: marketData.volume24h,
    volumeToMcapRatio: marketData.volumeToMcapRatio,
  };

  profileCache.set(cacheKey, { profile, ts: Date.now() });
  return profile;
}

export async function analyzeTopCoins(symbols: string[], maxConcurrent: number = 5): Promise<Map<string, TechnicalProfile>> {
  const results = new Map<string, TechnicalProfile>();

  for (let i = 0; i < symbols.length; i += maxConcurrent) {
    const batch = symbols.slice(i, i + maxConcurrent);
    const batchResults = await Promise.allSettled(
      batch.map(s => analyzeCoin(s))
    );

    for (let j = 0; j < batch.length; j++) {
      const result = batchResults[j];
      if (result.status === 'fulfilled' && result.value) {
        const key = batch[j].replace('/', '').toUpperCase();
        results.set(key, result.value);
      }
    }

    if (i + maxConcurrent < symbols.length) {
      await new Promise(r => setTimeout(r, 200));
    }
  }

  taLog(`Analyzed ${results.size}/${symbols.length} coins with full technical profiles`);
  return results;
}

export function clearCaches() {
  candleCache.clear();
  profileCache.clear();
  marketDataCache.clear();
}
