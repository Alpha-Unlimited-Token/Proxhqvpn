/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha OSINT Spider™ — Open Source Intelligence Blockchain Address Scanner
 * Patent Pending. Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Alpha OSINT Spider™
 * - Social Media Wallet Intelligence Engine™
 * - Multi-Platform Address Correlation System™
 * - Identity Discovery Pipeline™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: OSINT_SPIDER_v1.0_PROTECTED
 */

import { db } from "../db";
import { forensicAlerts, monitoredWallets } from "@shared/schema";
import { eq, and, inArray } from "drizzle-orm";
import { registerBeacon } from "./integrityBeacon.js";

export const _osintSpiderModuleHash = 'AUT_37ee039febf52e841c17b88d';
const _osIntegrityValid = registerBeacon('osintSpider', _osintSpiderModuleHash);
if (!_osintSpiderModuleHash?.startsWith('AUT_') || !_osIntegrityValid) {
  throw new Error('OSINT Spider™ module integrity compromised — unauthorized modification detected');
}

export interface OsintResult {
  address: string;
  platform: string;
  platformIcon: string;
  url: string;
  title: string;
  snippet: string;
  matchType: "verified" | "ens_linked" | "label" | "web_mention";
  verified: boolean;
  discoveredAt: string;
  context: string;
  author?: string;
  datePosted?: string;
}

export interface OsintScanResult {
  scanId: string;
  caseId: string;
  status: "running" | "complete" | "error";
  progress: number;
  totalAddressesScanned: number;
  totalAddresses: number;
  totalHits: number;
  results: OsintResult[];
  platformBreakdown: Record<string, number>;
  startedAt: string;
  completedAt?: string;
  error?: string;
}

const activeScanCache = new Map<string, OsintScanResult>();

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function containsAddress(text: string, address: string): boolean {
  if (!text || !address) return false;
  return text.toLowerCase().includes(address.toLowerCase());
}

async function searchGitHub(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://api.github.com/search/code?q=${encodeURIComponent(address)}&per_page=5`, {
      headers: { 'Accept': 'application/vnd.github.v3+json', 'User-Agent': 'AlphaForensicEngine/1.0' },
    });
    if (!resp.ok) {
      if (resp.status === 403) console.log(`[OSINT] GitHub rate limited`);
      return results;
    }
    const data = await resp.json();
    if (data.items?.length > 0) {
      for (const item of data.items.slice(0, 5)) {
        const repoName = item.repository?.full_name || "";
        const fileName = item.name || "";
        const filePath = item.path || "";
        const htmlUrl = item.html_url || "";
        if (!htmlUrl) continue;
        results.push({
          address,
          platform: "GitHub",
          platformIcon: "github",
          url: htmlUrl,
          title: `${repoName} — ${fileName}`,
          snippet: `Address found in file "${filePath}" in repository ${repoName}. GitHub code search confirmed this file contains the exact address.`,
          matchType: "verified",
          verified: true,
          discoveredAt: new Date().toISOString(),
          context: "code_repository",
          author: item.repository?.owner?.login,
        });
      }
    }
  } catch (e: any) {
    console.log(`[OSINT] GitHub search error for ${address.slice(0, 10)}...: ${e.message}`);
  }
  return results;
}

async function searchReddit(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://www.reddit.com/search.json?q=%22${encodeURIComponent(address)}%22&limit=10&sort=new&type=link`, {
      headers: { 'User-Agent': 'AlphaForensicEngine/1.0' },
    });
    if (!resp.ok) return results;
    const data = await resp.json();
    const posts = data?.data?.children || [];
    for (const post of posts.slice(0, 10)) {
      const d = post.data;
      if (!d) continue;
      const postText = `${d.title || ""} ${d.selftext || ""}`;
      const addrInPost = containsAddress(postText, address);
      if (!addrInPost) continue;
      results.push({
        address,
        platform: "Reddit",
        platformIcon: "reddit",
        url: `https://reddit.com${d.permalink}`,
        title: d.title || "Reddit Post",
        snippet: (d.selftext || "").slice(0, 300) || d.title || "",
        matchType: "verified",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: `r/${d.subreddit}`,
        author: d.author,
        datePosted: d.created_utc ? new Date(d.created_utc * 1000).toISOString() : undefined,
      });
    }
  } catch (e: any) {
    console.log(`[OSINT] Reddit search error for ${address.slice(0, 10)}...: ${e.message}`);
  }
  return results;
}

async function searchBlockchainLabels(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  if (!address.startsWith("0x")) return results;
  try {
    const resp = await fetch(`https://api.debank.com/user/addr/${address}`, {
      headers: { 'User-Agent': 'AlphaForensicEngine/1.0' },
    });
    if (!resp.ok) return results;
    const data = await resp.json();
    if (data?.data?.desc) {
      results.push({
        address,
        platform: "DeBank",
        platformIcon: "debank",
        url: `https://debank.com/profile/${address}`,
        title: `Labeled: ${data.data.desc}`,
        snippet: `DeBank has this address labeled as "${data.data.desc}"${data.data.usd_value ? ` — Current portfolio value: $${Number(data.data.usd_value).toLocaleString()}` : ""}`,
        matchType: "label",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "blockchain_label",
      });
    }
  } catch (e: any) {
    console.log(`[OSINT] DeBank search error: ${e.message}`);
  }
  return results;
}

async function searchEtherscanLabels(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  if (!address.startsWith("0x")) return results;
  try {
    const resp = await fetch(`https://etherscan.io/address/${address}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
    });
    if (!resp.ok) return results;
    const html = await resp.text();
    const labelMatch = html.match(/data-original-title="Public Name Tag[^"]*"[^>]*>([^<]+)</);
    const nameMatch = html.match(/<span[^>]*class="[^"]*hash-tag[^"]*"[^>]*>([^<]+)<\/span>/);
    const foundLabel = labelMatch?.[1]?.trim() || nameMatch?.[1]?.trim();
    if (foundLabel && foundLabel.length > 1 && !foundLabel.startsWith("0x")) {
      results.push({
        address,
        platform: "Etherscan",
        platformIcon: "etherscan",
        url: `https://etherscan.io/address/${address}`,
        title: `Etherscan Public Label: ${foundLabel}`,
        snippet: `Etherscan has publicly tagged this address as "${foundLabel}". This is a verified on-chain identity label.`,
        matchType: "label",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "blockchain_explorer",
      });
    }
  } catch (e: any) {
    console.log(`[OSINT] Etherscan label check error: ${e.message}`);
  }
  return results;
}

async function searchENSReverse(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  if (!address.startsWith("0x")) return results;
  try {
    const resp = await fetch("https://api.thegraph.com/subgraphs/name/ensdomains/ens", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: `{ domains(where: { resolvedAddress: "${address.toLowerCase()}" }) { name labelhash } }`,
      }),
    });
    if (!resp.ok) return results;
    const data = await resp.json();
    const domains = data?.data?.domains || [];
    for (const domain of domains.slice(0, 3)) {
      if (!domain.name) continue;
      results.push({
        address,
        platform: "ENS",
        platformIcon: "ens",
        url: `https://app.ens.domains/name/${domain.name}`,
        title: `ENS Domain: ${domain.name}`,
        snippet: `This wallet resolves to ENS name "${domain.name}". This is a verified on-chain identity link from the ENS protocol. The owner registered this name and pointed it to this address.`,
        matchType: "ens_linked",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "identity_link",
      });
    }
  } catch (e: any) {
    console.log(`[OSINT] ENS reverse lookup error: ${e.message}`);
  }
  return results;
}

async function searchAhmia(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://ahmia.fi/search/?q=${encodeURIComponent(address)}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
    });
    if (!resp.ok) {
      console.log(`[OSINT] Ahmia returned ${resp.status}`);
      return results;
    }
    const html = await resp.text();
    if (!containsAddress(html, address)) return results;

    const resultBlocks = [...html.matchAll(/<li class="result">([\s\S]*?)<\/li>/gi)];
    for (const block of resultBlocks.slice(0, 8)) {
      const blockHtml = block[1] || "";
      const linkMatch = blockHtml.match(/<a[^>]+href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/i);
      const snippetMatch = blockHtml.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
      const url = linkMatch?.[1] || "";
      const title = (linkMatch?.[2] || "").replace(/<[^>]*>/g, "").trim();
      const snippet = (snippetMatch?.[1] || "").replace(/<[^>]*>/g, "").trim();
      if (!url || !title) continue;
      if (!containsAddress(`${title} ${snippet}`, address)) continue;
      const isOnion = url.includes(".onion");
      results.push({
        address,
        platform: isOnion ? "Dark Web (.onion)" : "Ahmia (Tor Index)",
        platformIcon: "tor",
        url: isOnion ? `https://ahmia.fi/search/?q=${encodeURIComponent(address)}` : url,
        title,
        snippet: snippet || title,
        matchType: "web_mention",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: isOnion ? "dark_web_hidden_service" : "tor_indexed",
      });
    }
  } catch (e) {
    console.log(`[OSINT] Ahmia search error: ${(e as Error).message}`);
  }
  return results;
}

async function searchBraveDarkWeb(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://search.brave.com/search?q=%22${encodeURIComponent(address)}%22&source=web`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
      },
    });
    if (!resp.ok) return results;
    const html = await resp.text();
    if (!containsAddress(html, address)) return results;

    const snippets = [...html.matchAll(/<div[^>]*class="snippet[^"]*"[^>]*>([\s\S]*?)<\/div>/gi)];
    const titles = [...html.matchAll(/<a[^>]*class="result-header"[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi)];

    for (let i = 0; i < Math.min(titles.length, 5); i++) {
      const url = titles[i]?.[1] || "";
      const title = (titles[i]?.[2] || "").replace(/<[^>]*>/g, "").trim();
      const snippet = (snippets[i]?.[1] || "").replace(/<[^>]*>/g, "").trim();
      if (!url || !url.startsWith("http") || !title) continue;
      if (!containsAddress(`${title} ${snippet}`, address)) continue;
      results.push({
        address,
        platform: "Brave Search",
        platformIcon: "brave",
        url,
        title,
        snippet: snippet || title,
        matchType: "web_mention",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "privacy_search_engine",
      });
    }
  } catch (e) {
    console.log(`[OSINT] Brave search error: ${(e as Error).message}`);
  }
  return results;
}

async function searchPasteSites(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  const pasteSources = [
    { url: `https://psbdmp.ws/api/v3/search/${encodeURIComponent(address)}`, platform: "Pastebin Dumps", context: "paste_dump" },
    { url: `https://rentry.co/api/raw/search/${encodeURIComponent(address.slice(0, 20))}`, platform: "Rentry", context: "paste_site" },
  ];
  for (const src of pasteSources) {
    try {
      const resp = await fetch(src.url, {
        headers: { 'User-Agent': 'AlphaForensicEngine/1.0' },
      });
      if (!resp.ok) continue;
      const text = await resp.text();
      let data;
      try { data = JSON.parse(text); } catch { continue; }
      if (Array.isArray(data) && data.length > 0) {
        for (const item of data.slice(0, 5)) {
          const pasteText = item.text || item.content || item.title || "";
          const pasteId = item.id || item.key || "";
          if (!containsAddress(pasteText, address) && !containsAddress(JSON.stringify(item), address)) continue;
          results.push({
            address,
            platform: src.platform,
            platformIcon: "paste",
            url: item.url || `https://psbdmp.ws/${pasteId}`,
            title: `Paste dump containing wallet address`,
            snippet: pasteText.slice(0, 300) || `Address ${address.slice(0, 10)}... found in paste dump ${pasteId}`,
            matchType: "web_mention",
            verified: true,
            discoveredAt: new Date().toISOString(),
            context: src.context,
            datePosted: item.time || item.created_at || undefined,
          });
        }
      }
    } catch (e) {
      console.log(`[OSINT] ${src.platform} search error: ${(e as Error).message}`);
    }
  }
  return results;
}

async function searchChainabuse(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://www.chainabuse.com/address/${address}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
    });
    if (!resp.ok) return results;
    const html = await resp.text();
    const hasReports = html.includes("report") && (containsAddress(html, address) || html.includes(address.toLowerCase()));
    if (hasReports && (html.includes("scam") || html.includes("theft") || html.includes("fraud") || html.includes("hack") || html.includes("phish") || html.includes("report"))) {
      const countMatch = html.match(/(\d+)\s*report/i);
      const reportCount = countMatch ? countMatch[1] : "multiple";
      results.push({
        address,
        platform: "Chainabuse",
        platformIcon: "chainabuse",
        url: `https://www.chainabuse.com/address/${address}`,
        title: `Chainabuse: ${reportCount} report(s) filed against this address`,
        snippet: `This address has been reported on Chainabuse.com, a community-driven scam/fraud reporting platform. ${reportCount} report(s) found. Visit the link for details on reported incidents.`,
        matchType: "web_mention",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "fraud_report_platform",
      });
    }
  } catch (e) {
    console.log(`[OSINT] Chainabuse search error: ${(e as Error).message}`);
  }
  return results;
}

async function searchBlockchair(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  if (!address.startsWith("0x")) return results;
  try {
    const resp = await fetch(`https://api.blockchair.com/ethereum/dashboards/address/${address}?limit=0`, {
      headers: { 'User-Agent': 'AlphaForensicEngine/1.0' },
    });
    if (!resp.ok) return results;
    const data = await resp.json();
    const addrData = data?.data?.[address.toLowerCase()];
    if (addrData?.address) {
      const a = addrData.address;
      const balanceEth = Number(a.balance || 0) / 1e18;
      const txCount = a.transaction_count || 0;
      if (txCount > 0 || balanceEth > 0) {
        results.push({
          address,
          platform: "Blockchair",
          platformIcon: "blockchair",
          url: `https://blockchair.com/ethereum/address/${address}`,
          title: `Blockchair: ${txCount} transactions, ${balanceEth.toFixed(4)} ETH balance`,
          snippet: `Blockchair analytics: ${txCount} total transactions. Current balance: ${balanceEth.toFixed(4)} ETH. First seen: ${a.first_seen_receiving || "unknown"}. Last active: ${a.last_seen_sending || a.last_seen_receiving || "unknown"}.`,
          matchType: "verified",
          verified: true,
          discoveredAt: new Date().toISOString(),
          context: "blockchain_analytics",
        });
      }
    }
  } catch (e) {
    console.log(`[OSINT] Blockchair search error: ${(e as Error).message}`);
  }
  return results;
}

async function searchUndergroundForums(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  const queries = [
    { query: `"${address}" site:breachforums.st OR site:breachforums.is OR site:raidforums.com`, platform: "Underground Forums", icon: "darkforum", context: "underground_forum" },
    { query: `"${address}" mixer OR tumbler OR tornado OR wasabi OR "coin join"`, platform: "Mixing Services", icon: "mixer", context: "mixing_service_mention" },
    { query: `"${address}" darknet OR dark-web OR marketplace OR onion`, platform: "Dark Web Mentions", icon: "darkweb", context: "dark_web_reference" },
    { query: `"${address}" exploit OR vulnerability OR zero-day OR phishing`, platform: "Exploit References", icon: "exploit", context: "exploit_reference" },
  ];
  for (const q of queries) {
    try {
      const resp = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q.query)}`, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
      });
      if (!resp.ok) continue;
      const html = await resp.text();
      if (!containsAddress(html, address)) continue;
      const linkMatches = [...html.matchAll(/<a[^>]+class="result__a"[^>]+href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi)];
      const snippetMatches = [...html.matchAll(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi)];
      for (let i = 0; i < Math.min(linkMatches.length, 3); i++) {
        const rawUrl = linkMatches[i]?.[1] || "";
        let url = rawUrl;
        const uddMatch = rawUrl.match(/uddg=([^&]+)/);
        if (uddMatch) url = decodeURIComponent(uddMatch[1]);
        const title = (linkMatches[i]?.[2] || "").replace(/<[^>]*>/g, "").trim();
        const snippet = (snippetMatches[i]?.[1] || "").replace(/<[^>]*>/g, "").trim();
        if (!title || !url || !url.startsWith("http")) continue;
        if (!containsAddress(`${snippet} ${title}`, address)) continue;
        results.push({
          address,
          platform: q.platform,
          platformIcon: q.icon,
          url,
          title,
          snippet: snippet || title,
          matchType: "web_mention",
          verified: true,
          discoveredAt: new Date().toISOString(),
          context: q.context,
        });
      }
      await sleep(1200);
    } catch (e) {
      console.log(`[OSINT] Underground forum search error for ${q.platform}: ${(e as Error).message}`);
    }
  }
  return results;
}

async function searchMempoolSpace(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  if (!address.startsWith("0x")) return results;
  try {
    const resp = await fetch(`https://mempool.space/api/v1/validate-address/${address}`, {
      headers: { 'User-Agent': 'AlphaForensicEngine/1.0' },
    });
    if (!resp.ok) return results;
    const data = await resp.json();
    if (data?.isvalid) {
      results.push({
        address,
        platform: "Mempool.space",
        platformIcon: "mempool",
        url: `https://mempool.space/address/${address}`,
        title: `Mempool.space: Bitcoin address activity`,
        snippet: `Address validated on Mempool.space. Check link for real-time mempool data, transaction history, and UTXO set.`,
        matchType: "verified",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "bitcoin_mempool",
      });
    }
  } catch (e) {
    console.log(`[OSINT] Mempool.space error: ${(e as Error).message}`);
  }
  return results;
}

async function searchGoogleCache(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  try {
    const resp = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(`"${address}" inurl:paste OR inurl:dump OR inurl:leak OR inurl:exposed`)}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
    });
    if (!resp.ok) return results;
    const html = await resp.text();
    if (!containsAddress(html, address)) return results;
    const linkMatches = [...html.matchAll(/<a[^>]+class="result__a"[^>]+href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi)];
    const snippetMatches = [...html.matchAll(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi)];
    for (let i = 0; i < Math.min(linkMatches.length, 3); i++) {
      const rawUrl = linkMatches[i]?.[1] || "";
      let url = rawUrl;
      const uddMatch = rawUrl.match(/uddg=([^&]+)/);
      if (uddMatch) url = decodeURIComponent(uddMatch[1]);
      const title = (linkMatches[i]?.[2] || "").replace(/<[^>]*>/g, "").trim();
      const snippet = (snippetMatches[i]?.[1] || "").replace(/<[^>]*>/g, "").trim();
      if (!title || !url || !url.startsWith("http")) continue;
      if (!containsAddress(`${snippet} ${title}`, address)) continue;
      results.push({
        address,
        platform: "Paste/Leak Sites",
        platformIcon: "leak",
        url,
        title,
        snippet: snippet || title,
        matchType: "web_mention",
        verified: true,
        discoveredAt: new Date().toISOString(),
        context: "data_leak",
      });
    }
  } catch (e) {
    console.log(`[OSINT] Paste/leak search error: ${(e as Error).message}`);
  }
  return results;
}

async function searchDuckDuckGo(address: string): Promise<OsintResult[]> {
  const results: OsintResult[] = [];
  const queries = [
    { query: `"${address}" site:t.me`, platform: "Telegram", icon: "telegram", context: "messaging_platform" },
    { query: `"${address}" site:twitter.com OR site:x.com`, platform: "Twitter/X", icon: "twitter", context: "social_media" },
    { query: `"${address}" site:medium.com`, platform: "Medium", icon: "medium", context: "blog" },
    { query: `"${address}" site:bitcointalk.org`, platform: "BitcoinTalk", icon: "bitcointalk", context: "crypto_forum" },
    { query: `"${address}" crypto hack OR stolen OR theft OR scam`, platform: "Web (Incident Reports)", icon: "news", context: "incident_report" },
    { query: `"${address}" site:mirror.xyz OR site:paragraph.xyz`, platform: "Web3 Blogs", icon: "blog", context: "web3_blog" },
  ];

  for (const q of queries) {
    try {
      const resp = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q.query)}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      });
      if (!resp.ok) continue;
      const html = await resp.text();

      if (!containsAddress(html, address)) continue;

      const linkMatches = [...html.matchAll(/<a[^>]+class="result__a"[^>]+href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi)];
      const snippetMatches = [...html.matchAll(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi)];

      for (let i = 0; i < Math.min(linkMatches.length, 5); i++) {
        const rawUrl = linkMatches[i]?.[1] || "";
        let url = rawUrl;
        const uddMatch = rawUrl.match(/uddg=([^&]+)/);
        if (uddMatch) url = decodeURIComponent(uddMatch[1]);
        const title = (linkMatches[i]?.[2] || "").replace(/<[^>]*>/g, "").trim();
        const snippet = (snippetMatches[i]?.[1] || "").replace(/<[^>]*>/g, "").trim();

        if (!title || !url || !url.startsWith("http")) continue;

        const snippetHasAddr = containsAddress(snippet, address) || containsAddress(title, address);
        if (!snippetHasAddr) continue;

        results.push({
          address,
          platform: q.platform,
          platformIcon: q.icon,
          url,
          title,
          snippet: snippet || title,
          matchType: "web_mention",
          verified: true,
          discoveredAt: new Date().toISOString(),
          context: q.context,
        });
      }
      await sleep(1000);
    } catch (e: any) {
      console.log(`[OSINT] DuckDuckGo search error for ${q.platform}: ${e.message}`);
    }
  }
  return results;
}

export async function runOsintScan(caseId: string, addresses: string[]): Promise<string> {
  const scanId = `osint_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const uniqueAddresses = [...new Set(addresses.map(a => a.trim()).filter(Boolean))];

  const scan: OsintScanResult = {
    scanId,
    caseId,
    status: "running",
    progress: 0,
    totalAddressesScanned: 0,
    totalAddresses: uniqueAddresses.length,
    totalHits: 0,
    results: [],
    platformBreakdown: {},
    startedAt: new Date().toISOString(),
  };

  activeScanCache.set(scanId, scan);

  console.log(`[OSINT Spider] Starting scan for ${uniqueAddresses.length} addresses on case ${caseId}`);

  (async () => {
    try {
      for (let i = 0; i < uniqueAddresses.length; i++) {
        const address = uniqueAddresses[i];
        console.log(`[OSINT Spider] Scanning ${i + 1}/${uniqueAddresses.length}: ${address.slice(0, 10)}...`);

        const addressResults: OsintResult[] = [];

        const [githubResults, redditResults, ensResults, etherscanResults, debankResults, blockchairResults, chainabuseResults] = await Promise.all([
          searchGitHub(address),
          searchReddit(address),
          searchENSReverse(address),
          searchEtherscanLabels(address),
          searchBlockchainLabels(address),
          searchBlockchair(address),
          searchChainabuse(address),
        ]);

        addressResults.push(...githubResults, ...redditResults, ...ensResults, ...etherscanResults, ...debankResults, ...blockchairResults, ...chainabuseResults);

        const [ahmiaResults, braveResults, pasteResults, mempoolResults] = await Promise.all([
          searchAhmia(address),
          searchBraveDarkWeb(address),
          searchPasteSites(address),
          searchMempoolSpace(address),
        ]);

        addressResults.push(...ahmiaResults, ...braveResults, ...pasteResults, ...mempoolResults);

        const dorkResults = await searchDuckDuckGo(address);
        addressResults.push(...dorkResults);

        const undergroundResults = await searchUndergroundForums(address);
        addressResults.push(...undergroundResults);

        const leakResults = await searchGoogleCache(address);
        addressResults.push(...leakResults);

        if (addressResults.length > 0) {
          console.log(`[OSINT Spider] ${address.slice(0, 10)}... → ${addressResults.length} verified hit(s): ${addressResults.map(r => r.platform).join(", ")}`);
        }

        scan.results.push(...addressResults);
        scan.totalHits += addressResults.length;
        scan.totalAddressesScanned = i + 1;
        scan.progress = Math.round(((i + 1) / uniqueAddresses.length) * 100);

        for (const r of addressResults) {
          scan.platformBreakdown[r.platform] = (scan.platformBreakdown[r.platform] || 0) + 1;
        }

        if (addressResults.length > 0) {
          try {
            await db.insert(forensicAlerts).values({
              id: `osint_alert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
              caseId,
              alertType: "osint_hit",
              message: `OSINT Spider™ found ${addressResults.length} verified online mention(s) for ${address.slice(0, 10)}...${address.slice(-6)}`,
              details: { address, hits: addressResults.length, platforms: addressResults.map(r => r.platform), results: addressResults.slice(0, 5) },
              severity: addressResults.some(r => r.matchType === "ens_linked") ? "critical" : addressResults.length >= 3 ? "high" : "medium",
              acknowledged: false,
              createdAt: new Date(),
            });
          } catch (e: any) {
            console.log(`[OSINT Spider] Alert creation error: ${e.message}`);
          }
        }

        if (i < uniqueAddresses.length - 1) {
          await sleep(1500);
        }

        activeScanCache.set(scanId, { ...scan });
      }

      scan.status = "complete";
      scan.completedAt = new Date().toISOString();
      activeScanCache.set(scanId, { ...scan });

      console.log(`[OSINT Spider] Scan complete. ${scan.totalHits} verified hits across ${scan.totalAddressesScanned} addresses.`);

      try {
        await db.insert(forensicAlerts).values({
          id: `osint_complete_${Date.now()}`,
          caseId,
          alertType: "osint_scan_complete",
          message: `OSINT Spider™ scan complete: ${scan.totalHits} verified online mentions found across ${scan.totalAddressesScanned} wallet addresses`,
          details: {
            scanId,
            totalHits: scan.totalHits,
            totalAddresses: scan.totalAddressesScanned,
            platformBreakdown: scan.platformBreakdown,
            topResults: scan.results.slice(0, 10),
          },
          severity: scan.totalHits > 10 ? "high" : scan.totalHits > 0 ? "medium" : "low",
          acknowledged: false,
          createdAt: new Date(),
        });
      } catch (e: any) {
        console.log(`[OSINT Spider] Completion alert error: ${e.message}`);
      }

    } catch (error: any) {
      scan.status = "error";
      scan.error = error.message;
      activeScanCache.set(scanId, { ...scan });
      console.error(`[OSINT Spider] Scan error: ${error.message}`);
    }
  })();

  return scanId;
}

export function getOsintScanStatus(scanId: string): OsintScanResult | null {
  return activeScanCache.get(scanId) || null;
}

export function getAllOsintResults(caseId: string): OsintResult[] {
  const allResults: OsintResult[] = [];
  for (const [_, scan] of activeScanCache) {
    if (scan.caseId === caseId) {
      allResults.push(...scan.results);
    }
  }
  return allResults;
}

export async function getAddressesForCase(caseId: string): Promise<string[]> {
  const walletsData = await db
    .select({ address: monitoredWallets.address })
    .from(monitoredWallets)
    .where(eq(monitoredWallets.caseId, caseId));
  return walletsData.map(w => w.address);
}

export async function searchSingleAddress(address: string): Promise<OsintResult[]> {
  console.log(`[OSINT Spider] Single address scan: ${address.slice(0, 10)}...`);

  const [githubResults, redditResults, ensResults, etherscanResults, debankResults, blockchairResults, chainabuseResults] = await Promise.all([
    searchGitHub(address),
    searchReddit(address),
    searchENSReverse(address),
    searchEtherscanLabels(address),
    searchBlockchainLabels(address),
    searchBlockchair(address),
    searchChainabuse(address),
  ]);

  const [ahmiaResults, braveResults, pasteResults, mempoolResults] = await Promise.all([
    searchAhmia(address),
    searchBraveDarkWeb(address),
    searchPasteSites(address),
    searchMempoolSpace(address),
  ]);

  const dorkResults = await searchDuckDuckGo(address);
  const undergroundResults = await searchUndergroundForums(address);
  const leakResults = await searchGoogleCache(address);

  const all = [
    ...githubResults, ...redditResults, ...ensResults, ...etherscanResults, ...debankResults,
    ...blockchairResults, ...chainabuseResults, ...ahmiaResults, ...braveResults, ...pasteResults,
    ...mempoolResults, ...dorkResults, ...undergroundResults, ...leakResults,
  ];
  console.log(`[OSINT Spider] Single address: ${all.length} verified hits found`);
  return all;
}
