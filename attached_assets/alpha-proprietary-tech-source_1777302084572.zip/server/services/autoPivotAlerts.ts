import { getUncachableSendGridClient } from "./sendgridService.js";
import { amountCorrelationScanner } from "./amountCorrelationScanner.js";

const OWNER_EMAIL = "alphaunlimitedtoken@gmail.com";
const ALERT_FROM_NAME = "Alpha Auto-Pivot Surveillance™";
const CHECK_INTERVAL_MS = 5 * 60 * 1000;
const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const DAU_CONTRACT = "0xAB403962C943e3335903824BB2880A219858C5CC";
const DAU_TARGET = "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3";

interface WatchTarget {
  address: string;
  label: string;
  lastKnownNonce: number;
  lastKnownBalance: number;
  lastKnownDAU: number;
  caseId: string;
}

const watchedTargets: WatchTarget[] = [];
let intervalHandle: ReturnType<typeof setInterval> | null = null;
let isRunning = false;

export function addWatchTarget(address: string, label: string, caseId: string) {
  const exists = watchedTargets.find(t => t.address.toLowerCase() === address.toLowerCase());
  if (!exists) {
    watchedTargets.push({
      address: address.toLowerCase(),
      label,
      lastKnownNonce: -1,
      lastKnownBalance: -1,
      lastKnownDAU: -1,
      caseId,
    });
    console.log(`[AutoPivotAlerts] Added watch target: ${label} (${address.slice(0, 10)}...)`);
  }
}

export function getWatchTargets() {
  return watchedTargets.map(t => ({
    address: t.address,
    label: t.label,
    lastKnownNonce: t.lastKnownNonce,
    lastKnownBalance: t.lastKnownBalance,
  }));
}

async function alchemyCall(method: string, params: any[]) {
  const res = await fetch(`https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  return (await res.json()).result;
}

async function getDAUBalance(address: string): Promise<number> {
  try {
    const result = await alchemyCall("alchemy_getTokenBalances", [address, [DAU_CONTRACT]]);
    const tokenBal = result?.tokenBalances?.[0]?.tokenBalance || "0x0";
    return Number(BigInt(tokenBal)) / 1e18;
  } catch { return -1; }
}

async function getRecentERC20Transfers(fromAddress: string, contractAddress: string, maxCount = 5) {
  const res = await fetch(`https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0", id: 1,
      method: "alchemy_getAssetTransfers",
      params: [{
        fromAddress,
        contractAddresses: [contractAddress],
        category: ["erc20"],
        order: "desc",
        maxCount: `0x${maxCount.toString(16)}`,
        withMetadata: true,
      }],
    }),
  });
  return (await res.json()).result?.transfers || [];
}

async function checkTarget(target: WatchTarget): Promise<string | null> {
  const nonce = parseInt(await alchemyCall("eth_getTransactionCount", [target.address, "latest"]), 16);
  const balRaw = await alchemyCall("eth_getBalance", [target.address, "latest"]);
  const balance = Number(BigInt(balRaw || "0x0")) / 1e18;
  const dauBal = await getDAUBalance(target.address);

  if (target.lastKnownNonce === -1) {
    target.lastKnownNonce = nonce;
    target.lastKnownBalance = balance;
    target.lastKnownDAU = dauBal;
    console.log(`[AutoPivotAlerts] Baseline: ${target.label} — nonce=${nonce}, balance=${balance.toFixed(4)} ETH, DAU=${dauBal.toFixed(4)}`);
    return null;
  }

  const changes: string[] = [];

  if (dauBal >= 0 && target.lastKnownDAU > 0 && dauBal < target.lastKnownDAU) {
    const moved = target.lastKnownDAU - dauBal;
    changes.push(`🚨 DAU BEACON MOVED! ${moved.toFixed(6)} DAU transferred OUT of wallet!`);
    changes.push(`Previous DAU: ${target.lastKnownDAU.toFixed(6)} → Current: ${dauBal.toFixed(6)}`);
    const dauTransfers = await getRecentERC20Transfers(target.address, DAU_CONTRACT, 3);
    for (const t of dauTransfers) {
      const date = t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).toISOString().slice(0, 16) : "unknown";
      changes.push(`  → DAU sent to: ${t.to} at ${date} | TX: https://etherscan.io/tx/${t.hash}`);
      changes.push(`  → NEW WALLET TO MONITOR: ${t.to}`);
    }
  }

  if (nonce > target.lastKnownNonce) {
    const newTxCount = nonce - target.lastKnownNonce;
    changes.push(`${newTxCount} NEW OUTBOUND TRANSACTION(S) detected`);

    const txRes = await fetch(`https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0", id: 1,
        method: "alchemy_getAssetTransfers",
        params: [{
          fromAddress: target.address,
          category: ["external", "erc20"],
          order: "desc",
          maxCount: "0xA",
          withMetadata: true,
        }],
      }),
    });
    const txData = await txRes.json();
    const recent = txData.result?.transfers || [];
    for (const t of recent.slice(0, Math.min(newTxCount, 10))) {
      const date = t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).toISOString().slice(0, 16) : "unknown";
      changes.push(`  → ${date} | ${(t.value || 0).toFixed(4)} ${t.asset || "ETH"} → ${t.to}`);
      changes.push(`    TX: https://etherscan.io/tx/${t.hash}`);

      const onRampCheck = amountCorrelationScanner.isMoneroOnRampAddress(t.to || '');
      if (onRampCheck.isOnRamp) {
        changes.push(`  🚨🚨🚨 MONERO ON-RAMP DETECTED!`);
        changes.push(`  SERVICE: ${onRampCheck.service}`);
        changes.push(`  AMOUNT: ${(t.value || 0).toFixed(6)} ${t.asset || "ETH"} sent to XMR swap service`);
        changes.push(`  KYC REQUIRED: ${onRampCheck.details?.kycRequired ? 'YES — subpoena possible' : 'NO — privacy swap'}`);
        changes.push(`  JURISDICTION: ${onRampCheck.details?.jurisdiction || 'Unknown'}`);
        const correlation = await amountCorrelationScanner.calculateSwapCorrelation(
          t.value || 0, t.asset || 'ETH', 'XMR'
        );
        changes.push(`  ESTIMATED XMR OUTPUT: ${correlation.expectedOutput.min.toFixed(4)} — ${correlation.expectedOutput.max.toFixed(4)} XMR`);
        changes.push(`  WATCH FOR: Monero wallet receiving ${correlation.expectedOutput.min.toFixed(4)}–${correlation.expectedOutput.max.toFixed(4)} XMR within 30 min`);
      }
    }
  }

  if (Math.abs(balance - target.lastKnownBalance) > 0.001) {
    const diff = balance - target.lastKnownBalance;
    const direction = diff > 0 ? "INCREASED" : "DECREASED";
    changes.push(`Balance ${direction}: ${target.lastKnownBalance.toFixed(4)} → ${balance.toFixed(4)} ETH (${diff > 0 ? "+" : ""}${diff.toFixed(4)} ETH / ~$${Math.abs(diff * 2083).toFixed(2)})`);
  }

  target.lastKnownNonce = nonce;
  target.lastKnownBalance = balance;
  target.lastKnownDAU = dauBal;

  if (changes.length > 0) {
    return changes.join("\n");
  }
  return null;
}

async function fireSealWebhooks(target: WatchTarget, changeDetails: string) {
  try {
    const webhooks: Array<{ url: string; label: string }> = (globalThis as any).__SEAL_WEBHOOKS || [];
    if (webhooks.length === 0) return;
    const payload = {
      event: "wallet_activity",
      timestamp: new Date().toISOString(),
      target: { address: target.address, label: target.label, caseId: target.caseId },
      currentBalance: target.lastKnownBalance,
      currentDAU: target.lastKnownDAU,
      nonce: target.lastKnownNonce,
      changes: changeDetails,
      etherscan: `https://etherscan.io/address/${target.address}`,
    };
    for (const wh of webhooks) {
      try {
        await fetch(wh.url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        console.log(`[SEAL Webhook] Delivered to ${wh.label}: ${wh.url}`);
      } catch (err: any) {
        console.error(`[SEAL Webhook] Failed ${wh.url}:`, err.message);
      }
    }
  } catch {}
}

async function sendAlertEmail(target: WatchTarget, changeDetails: string) {
  try {
    const { client: sgClient, fromEmail } = await getUncachableSendGridClient();
    const now = new Date().toISOString();
    const etherscanLink = `https://etherscan.io/address/${target.address}`;

    const htmlBody = `
<!DOCTYPE html>
<html>
<head></head>
<body style="background-color:#0A1628;color:#FFFFFF;font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0">
<div style="max-width:700px;margin:0 auto;padding:24px">
  <div style="background-color:#991B1B;border:2px solid #EF4444;border-radius:12px;padding:20px;margin-bottom:24px;text-align:center">
    <h1 style="color:#FFFFFF;font-size:20px;margin:0 0 6px 0;letter-spacing:2px">⚠️ WALLET ACTIVITY DETECTED</h1>
    <div style="color:#FECACA;font-size:12px">Alpha Auto-Pivot Surveillance Engine™ &bull; ${now}</div>
  </div>
  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">TARGET WALLET</h3>
    <p style="font-size:13px;margin:4px 0;color:#FFFFFF"><strong style="color:#FFFFFF">${target.label}</strong></p>
    <p><span style="font-family:'Courier New',monospace;font-size:12px;color:#FFD700;word-break:break-all;background-color:#1E293B;padding:4px 8px;border-radius:4px">${target.address}</span></p>
    <p style="margin-top:8px"><a href="${etherscanLink}" style="color:#00D4FF;text-decoration:none">View on Etherscan →</a></p>
  </div>
  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">DETECTED CHANGES</h3>
    <div style="font-family:'Courier New',monospace;font-size:12px;color:#FF6B6B;background-color:#1E293B;padding:12px;border-radius:6px;white-space:pre-wrap;line-height:1.6">${changeDetails.replace(/\n/g, "<br/>")}</div>
  </div>
  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">CURRENT STATUS</h3>
    <p style="font-size:12px;color:#FFFFFF">Balance: <strong style="color:#FFD700">${target.lastKnownBalance.toFixed(4)} ETH (~$${(target.lastKnownBalance * 2083).toFixed(2)})</strong></p>
    <p style="font-size:12px;color:#FFFFFF">Total TXs: <strong style="color:#FFFFFF">${target.lastKnownNonce}</strong></p>
    <p style="font-size:12px;color:#FFFFFF">Case ID: ${target.caseId.slice(0, 8)}...</p>
  </div>
  <div style="text-align:center;color:#94A3B8;font-size:11px;margin-top:20px">
    Auto-Pivot Surveillance Engine™ &bull; Monitoring every 5 minutes<br/>
    Alpha Unlimited Trading &bull; Forensic Intelligence Division
  </div>
</div>
</body>
</html>`;

    const textBody = `[AUTO-PIVOT ALERT] Wallet Activity Detected
Target: ${target.label}
Address: ${target.address}
Changes:
${changeDetails}
Current Balance: ${target.lastKnownBalance.toFixed(4)} ETH
Etherscan: ${etherscanLink}
Time: ${now}`;

    await sgClient.send({
      to: OWNER_EMAIL,
      from: { email: fromEmail, name: ALERT_FROM_NAME },
      subject: `[SURVEILLANCE ALERT] Activity on ${target.label} — ${target.address.slice(0, 10)}... — Case ${target.caseId.slice(0, 8)}`,
      content: [
        { type: "text/plain", value: textBody },
        { type: "text/html", value: htmlBody },
      ],
    });

    console.log(`[AutoPivotAlerts] ✓ Alert email sent to ${OWNER_EMAIL} for ${target.label}`);
  } catch (err: any) {
    console.error(`[AutoPivotAlerts] ✗ Failed to send alert:`, err.message);
  }
}

async function runCheck() {
  for (const target of watchedTargets) {
    try {
      const changes = await checkTarget(target);
      if (changes) {
        console.log(`[AutoPivotAlerts] Activity detected on ${target.label}!`);
        await sendAlertEmail(target, changes);
        await fireSealWebhooks(target, changes);
      }
    } catch (err: any) {
      console.error(`[AutoPivotAlerts] Error checking ${target.label}:`, err.message);
    }
  }
}

export function startAutoPivotAlerts() {
  if (isRunning) return;
  isRunning = true;

  addWatchTarget(
    "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3",
    "USDT Endpoint B (stolen funds, 75 TXs, hop-4)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e",
    "DAI Laundering Hub (10M DAI, hop-2)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872",
    "Main Attacker Wallet (hop-1, 490 ETH + 1.97M DAI stolen)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4",
    "DCA Laundering Hub (still active Mar 20)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0x4389070b909ff2a6549f3ca8e42e578e12cf61b6",
    "USDC Endpoint ($2.4M forwarded to cashout)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0x8e04af7f7c76daa9ab429b1340e0327b5b835748",
    "Cashout Primary (receives USDT/USDC/ETH from 0xf576, active Mar 20)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0x8e044d1ecebab9b62323ead86917e5123e795748",
    "Mirror Cashout A ($4.99M+ USDT, $2M USDC in $499K chunks)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  addWatchTarget(
    "0x8e03a03bb063abd8871cc8e508d9f4506d835748",
    "Mirror Cashout B ($3.99M+ USDT, $1.5M USDC in $499K chunks)",
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );

  console.log(`[AutoPivotAlerts] Started. Monitoring ${watchedTargets.length} targets every 5 minutes.`);
  console.log(`[AutoPivotAlerts] Alerts will be emailed to: ${OWNER_EMAIL}`);

  runCheck();

  intervalHandle = setInterval(runCheck, CHECK_INTERVAL_MS);
}

export function stopAutoPivotAlerts() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
  isRunning = false;
  console.log("[AutoPivotAlerts] Stopped.");
}
