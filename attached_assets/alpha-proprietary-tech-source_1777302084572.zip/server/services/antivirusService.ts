/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Antivirus Scanner™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary real-time file scanning and malware detection technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Antivirus Scanner™
 * - Real-Time Threat Detection Engine™
 * - Malware Signature Analysis™
 * - File Integrity Verification System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_36b588913c94963babe2687f
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import path from "path";


export const _avsSeal = 'AUT_36b588913c94963babe2687f';
const _avsIntegrityValid = registerBeacon('antivirusService', _avsSeal);
if (!_avsSeal?.startsWith('AUT_') || !_avsIntegrityValid) {
  throw new Error('[SECURITY] Alpha Antivirus Scanner™ integrity verification failed — module sealed');
}

const execAsync = promisify(exec);

const CLAMSCAN_PATH = "clamscan";
const SCAN_TIMEOUT_MS = 30000;
const MAX_FILE_SIZE = 25 * 1024 * 1024;

interface ScanResult {
  clean: boolean;
  threat?: string;
  scanTime: number;
  fileSize: number;
}

let clamAvailable: boolean | null = null;

async function checkClamAvailable(): Promise<boolean> {
  if (clamAvailable !== null) return clamAvailable;
  try {
    await execAsync(`${CLAMSCAN_PATH} --version`, { timeout: 5000 });
    clamAvailable = true;
    console.log("[Antivirus] ClamAV scanner initialized successfully");
  } catch {
    clamAvailable = false;
    console.warn("[Antivirus] ClamAV not available - using signature-based fallback scanner");
  }
  return clamAvailable;
}

const MALWARE_SIGNATURES = [
  { pattern: Buffer.from("4d5a", "hex"), name: "PE_Executable", offset: 0 },
  { pattern: Buffer.from("7f454c46", "hex"), name: "ELF_Binary", offset: 0 },
  { pattern: Buffer.from("cafebabe", "hex"), name: "Java_Class", offset: 0 },
  { pattern: Buffer.from("504b0304", "hex"), name: "ZIP_Archive", offset: 0 },
  { pattern: Buffer.from("1f8b", "hex"), name: "GZIP_Archive", offset: 0 },
  { pattern: Buffer.from("526172211a07", "hex"), name: "RAR_Archive", offset: 0 },
  { pattern: Buffer.from("25504446", "hex"), name: "PDF_Document", offset: 0 },
];

const SUSPICIOUS_STRINGS = [
  /eval\s*\(/i,
  /document\.write/i,
  /<script[\s>]/i,
  /javascript\s*:/i,
  /vbscript\s*:/i,
  /on(error|load|click)\s*=/i,
  /base64_decode/i,
  /exec\s*\(/i,
  /system\s*\(/i,
  /passthru\s*\(/i,
  /shell_exec/i,
  /\bphp\b.*\beval\b/i,
  /powershell/i,
  /cmd\.exe/i,
];

function fallbackScan(filePath: string): ScanResult {
  const startTime = Date.now();
  const stats = fs.statSync(filePath);
  const buffer = fs.readFileSync(filePath);

  for (const sig of MALWARE_SIGNATURES) {
    if (buffer.length > sig.offset + sig.pattern.length) {
      const slice = buffer.slice(sig.offset, sig.offset + sig.pattern.length);
      if (slice.equals(sig.pattern)) {
        return {
          clean: false,
          threat: `Suspicious.${sig.name}`,
          scanTime: Date.now() - startTime,
          fileSize: stats.size,
        };
      }
    }
  }

  const textContent = buffer.toString("utf8", 0, Math.min(buffer.length, 1024 * 100));
  for (const pattern of SUSPICIOUS_STRINGS) {
    if (pattern.test(textContent)) {
      return {
        clean: false,
        threat: "Suspicious.EmbeddedScript",
        scanTime: Date.now() - startTime,
        fileSize: stats.size,
      };
    }
  }

  return {
    clean: true,
    scanTime: Date.now() - startTime,
    fileSize: stats.size,
  };
}

export async function scanFile(filePath: string): Promise<ScanResult> {
  const startTime = Date.now();

  if (!fs.existsSync(filePath)) {
    return { clean: false, threat: "File.NotFound", scanTime: 0, fileSize: 0 };
  }

  const stats = fs.statSync(filePath);
  if (stats.size > MAX_FILE_SIZE) {
    return { clean: false, threat: "File.TooLarge", scanTime: 0, fileSize: stats.size };
  }

  if (stats.size === 0) {
    return { clean: false, threat: "File.Empty", scanTime: 0, fileSize: 0 };
  }

  const isClamReady = await checkClamAvailable();

  if (isClamReady) {
    try {
      const safePath = filePath.replace(/'/g, "'\\''");
      const { stdout } = await execAsync(
        `${CLAMSCAN_PATH} --no-summary --stdout '${safePath}'`,
        { timeout: SCAN_TIMEOUT_MS }
      );

      return {
        clean: true,
        scanTime: Date.now() - startTime,
        fileSize: stats.size,
      };
    } catch (error: any) {
      if (error.code === 1 && error.stdout) {
        const match = error.stdout.match(/:\s*(.+)\s+FOUND/);
        const threat = match ? match[1].trim() : "Unknown.Malware";
        return {
          clean: false,
          threat,
          scanTime: Date.now() - startTime,
          fileSize: stats.size,
        };
      }

      console.warn("[Antivirus] ClamAV scan failed, falling back to signature scan:", error.message);
      return fallbackScan(filePath);
    }
  }

  return fallbackScan(filePath);
}

export async function scanBuffer(buffer: Buffer, filename: string): Promise<ScanResult> {
  const tempDir = path.join(process.cwd(), "uploads", ".scan-temp");
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }

  const tempPath = path.join(tempDir, `scan-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  try {
    fs.writeFileSync(tempPath, buffer);
    const result = await scanFile(tempPath);
    return result;
  } finally {
    try {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    } catch {}
  }
}

export function getAntivirusStatus(): {
  engine: string;
  available: boolean;
  version: string;
  scanMode: string;
} {
  return {
    engine: clamAvailable ? "ClamAV" : "Signature Scanner",
    available: clamAvailable ?? false,
    version: clamAvailable ? "1.3.x" : "1.0.0",
    scanMode: clamAvailable ? "full" : "fallback",
  };
}

checkClamAvailable();
