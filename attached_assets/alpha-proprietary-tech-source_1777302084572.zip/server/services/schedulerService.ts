/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Autonomous Task Scheduler™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary autonomous task scheduling and monitoring technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Autonomous Task Scheduler™
 * - Subscription Lifecycle Manager™
 * - Price Alert Monitoring Engine™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_fb4c3388a66e265216267d05
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

import { registerBeacon } from "./integrityBeacon.js";
import { storage } from '../storage';
import {
  sendSubscriptionExpiryReminderEmail,
  sendPriceAlertEmail,
} from './agentmailService';

export const _schSeal = 'AUT_fb4c3388a66e265216267d05';
const _schIntegrityValid = registerBeacon('schedulerService', _schSeal);
if (!_schSeal?.startsWith('AUT_') || !_schIntegrityValid) {
  throw new Error('[SECURITY] Alpha Autonomous Task Scheduler™ integrity verification failed — module sealed');
}

const EXPIRY_CHECK_INTERVAL = 60 * 60 * 1000;
const PRICE_ALERT_CHECK_INTERVAL = 5 * 60 * 1000;

async function checkSubscriptionExpiry() {
  try {
    for (const daysLeft of [7, 3, 1]) {
      const expiring = await storage.getExpiringSubscriptions(daysLeft);
      for (const sub of expiring) {
        if (!sub.user?.email) continue;
        const emailType = `expiry_reminder_${daysLeft}d`;
        const refId = `${sub.id}_${daysLeft}d`;
        const alreadySent = await storage.hasRecentEmailNotification(
          sub.userId, emailType, refId, 24
        );
        if (alreadySent) continue;

        try {
          const tierNames: Record<string, string> = {
            free: 'Free', basic: 'Basic', premium: 'Premium',
            platinum: 'Platinum', alpha: 'Alpha'
          };
          const tierName = tierNames[String(sub.tierId)] || String(sub.tierId);
          await sendSubscriptionExpiryReminderEmail(
            sub.user.email,
            sub.user.firstName || sub.user.username || undefined,
            tierName,
            Number(daysLeft)
          );
          await storage.logEmailNotification({
            userId: sub.userId,
            emailType,
            referenceId: refId,
          });
          console.log(`Sent ${daysLeft}-day expiry reminder to ${sub.user.email}`);
        } catch (err: any) {
          console.error(`Failed to send expiry reminder to ${sub.user.email}:`, err.message);
        }
      }
    }
  } catch (err: any) {
    console.error('Subscription expiry check failed:', err.message);
  }
}

async function fetchCurrentPrice(symbol: string): Promise<number | null> {
  try {
    const res = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(symbol.toLowerCase())}&vs_currencies=usd`
    );
    if (!res.ok) return null;
    const data = await res.json() as Record<string, { usd?: number }>;
    const key = Object.keys(data)[0];
    return key ? data[key]?.usd ?? null : null;
  } catch {
    return null;
  }
}

async function checkPriceAlerts() {
  try {
    const activeAlerts = await storage.getActiveWatchlistAlerts();
    if (activeAlerts.length === 0) return;

    const symbolSet = new Set(activeAlerts.map(a => a.symbol));
    const symbols = Array.from(symbolSet);
    const prices: Record<string, number> = {};
    for (const symbol of symbols) {
      const price = await fetchCurrentPrice(symbol);
      if (price !== null) prices[symbol] = price;
    }

    for (const alert of activeAlerts) {
      const currentPrice = prices[alert.symbol];
      if (currentPrice === undefined) continue;

      const targetPrice = Number(alert.targetPrice);
      const triggered =
        (alert.direction === 'above' && currentPrice >= targetPrice) ||
        (alert.direction === 'below' && currentPrice <= targetPrice);

      if (!triggered) continue;
      if (!alert.user?.email) continue;

      const alreadySent = await storage.hasRecentEmailNotification(
        alert.userId, 'price_alert', String(alert.id), 1
      );
      if (alreadySent) continue;

      try {
        await sendPriceAlertEmail(
          alert.user.email,
          alert.user.firstName || alert.user.username || undefined,
          alert.symbol.toUpperCase(),
          currentPrice,
          targetPrice,
          alert.direction as 'above' | 'below'
        );
        await storage.triggerWatchlistAlert(alert.id);
        await storage.logEmailNotification({
          userId: alert.userId,
          emailType: 'price_alert',
          referenceId: String(alert.id),
        });
        console.log(`Price alert triggered for ${alert.symbol} -> ${alert.user.email}`);
      } catch (err: any) {
        console.error(`Failed to send price alert to ${alert.user.email}:`, err.message);
      }
    }
  } catch (err: any) {
    console.error('Price alert check failed:', err.message);
  }
}

let expiryTimer: ReturnType<typeof setInterval> | null = null;
let priceTimer: ReturnType<typeof setInterval> | null = null;

export function startScheduler() {
  console.log('Starting background email scheduler...');

  expiryTimer = setInterval(checkSubscriptionExpiry, EXPIRY_CHECK_INTERVAL);
  priceTimer = setInterval(checkPriceAlerts, PRICE_ALERT_CHECK_INTERVAL);

  setTimeout(checkSubscriptionExpiry, 30_000);
  setTimeout(checkPriceAlerts, 60_000);

  console.log(`Scheduler started: expiry checks every ${EXPIRY_CHECK_INTERVAL / 60000}min, price alerts every ${PRICE_ALERT_CHECK_INTERVAL / 60000}min`);
}

export function stopScheduler() {
  if (expiryTimer) clearInterval(expiryTimer);
  if (priceTimer) clearInterval(priceTimer);
  expiryTimer = null;
  priceTimer = null;
  console.log('Background email scheduler stopped.');
}
