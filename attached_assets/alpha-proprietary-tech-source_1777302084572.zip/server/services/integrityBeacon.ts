/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024 and onwards Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Integrity Beacon System™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 * 
 * This module implements cryptographic integrity verification for all proprietary
 * Alpha Unlimited technologies. Tampering with this file or any protected module
 * will result in immediate application failure.
 */

import crypto from "crypto";
import fs from "fs";
import path from "path";

const _envSalt = process.env.BEACON_SALT || process.env.SESSION_SECRET || "";
const _beaconEngineKey = crypto.createHmac("sha256", "ALPHA_UNLIMITED_PROPRIETARY_2024")
  .update(_envSalt + "BEACON_ENGINE_CORE").digest("hex");
const _validationEpoch = 1704067200000;

function _computeBeaconHash(technologyName: string): string {
  return "AUT_" + crypto.createHmac("sha256", _beaconEngineKey)
    .update(technologyName).digest("hex").substring(0, 24);
}

function _deriveFileChecksum(filePath: string): string {
  try {
    const resolved = path.resolve(filePath);
    if (!fs.existsSync(resolved)) return "";
    const content = fs.readFileSync(resolved, "utf-8");
    const copyrightPresent = content.includes("PROPRIETARY AND CONFIDENTIAL") && 
      (content.includes("Alpha Unlimited Trading Company") || content.includes("Alpha Unlimited Token"));
    const beaconPresent = content.includes("AUT_") && 
      (content.includes("Seal") || content.includes("seal") || 
       content.includes("Calibration") || content.includes("calibration") ||
       content.includes("ModuleHash") || content.includes("moduleHash"));
    if (!copyrightPresent || !beaconPresent) return "";
    return crypto.createHash("sha256").update(content.substring(0, 500)).digest("hex").substring(0, 16);
  } catch {
    return "";
  }
}

const BEACON_REGISTRY: Record<string, { expected: string; label: string; critical: boolean; filePath?: string }> = {
  commandCenter: {
    expected: _computeBeaconHash("Alpha Autonomous Command Center"),
    label: "AACC™",
    critical: true,
    filePath: "server/services/commandCenter.ts"
  },
  botEngine: {
    expected: _computeBeaconHash("Alpha Bot Engine"),
    label: "Bot Engine™",
    critical: true,
    filePath: "server/services/botEngine.ts"
  },
  securityFramework: {
    expected: _computeBeaconHash("Alpha Security Framework"),
    label: "Security Framework™",
    critical: true,
    filePath: "server/middleware/softwareSecurity.ts"
  },
  bridgeFusion: {
    expected: _computeBeaconHash("Bridge Fusion"),
    label: "Bridge Fusion™",
    critical: true,
    filePath: "client/src/lib/standalone/bridge-fusion-engine.ts"
  },
  qmge: {
    expected: _computeBeaconHash("Quantum Market Genome Engine"),
    label: "QMGE™",
    critical: true,
    filePath: "client/src/lib/qmge/engine.ts"
  },
  signalSdk: {
    expected: _computeBeaconHash("Alpha Signal SDK"),
    label: "Signal SDK™",
    critical: true,
    filePath: "client/src/lib/standalone/signal-sdk.ts"
  },
  atfmo: {
    expected: _computeBeaconHash("Alpha Temporal Field Mining Optimizer"),
    label: "ATFMO™",
    critical: true,
    filePath: "personal/alpha-temporal-field-mining-optimizer/atfmo.js"
  },
  anpa: {
    expected: _computeBeaconHash("Alpha Network Pulse Analyzer"),
    label: "ANPA™",
    critical: true,
    filePath: "personal/alpha-network-pulse-analyzer/anpa.js"
  },
  asfg: {
    expected: _computeBeaconHash("Alpha Signal Fusion Guardian"),
    label: "ASFG™",
    critical: true,
    filePath: "personal/alpha-signal-fusion-guardian/asfg.js"
  },
  apce: {
    expected: _computeBeaconHash("Alpha Probability Convergence Engine"),
    label: "APCE™",
    critical: true,
    filePath: "personal/alpha-probability-convergence-engine/apce.js"
  },
  mrp: {
    expected: _computeBeaconHash("Market Reset Probability"),
    label: "MRP™",
    critical: true,
    filePath: "scripts/mrp-algorithm.ts"
  },
  technicalAnalysis: {
    expected: _computeBeaconHash("Alpha Deep Market Intelligence Engine"),
    label: "ADMIE™",
    critical: true,
    filePath: "server/services/technicalAnalysis.ts"
  },
  phantomVault: {
    expected: _computeBeaconHash("Alpha Phantom Vault Protocol"),
    label: "Phantom Vault Protocol™",
    critical: true,
    filePath: "client/src/pages/trading-platform/PhantomVaultService.tsx"
  },
  forensicIntelligenceEngine: {
    expected: _computeBeaconHash("Alpha Forensic Intelligence Engine"),
    label: "Forensic Intelligence Engine™",
    critical: true,
    filePath: "client/src/pages/trading-platform/ForensicCommandCenter.tsx"
  },
  customerVaultOversight: {
    expected: _computeBeaconHash("Alpha Customer Vault Oversight"),
    label: "Customer Vault Oversight™",
    critical: false,
    filePath: "shared/models/forensic.ts"
  },
  walletMonitor: {
    expected: _computeBeaconHash("Alpha Wallet Monitor Service"),
    label: "Wallet Monitor Service™",
    critical: true,
    filePath: "server/services/walletMonitor.ts"
  },
  forensicSpider: {
    expected: _computeBeaconHash("Alpha Forensic Spider Trace"),
    label: "Spider Trace™",
    critical: true,
    filePath: "server/services/forensicSpider.ts"
  },
  osintSpider: {
    expected: _computeBeaconHash("Alpha OSINT Spider"),
    label: "OSINT Spider™",
    critical: false,
    filePath: "server/services/osintSpider.ts"
  },
  txOriginIntel: {
    expected: _computeBeaconHash("Alpha Transaction Origin Intelligence"),
    label: "Transaction Origin Intelligence™",
    critical: true,
    filePath: "server/services/transactionOriginIntel.ts"
  },
  networkIntelTracer: {
    expected: _computeBeaconHash("Alpha Network Intelligence Tracer"),
    label: "Network Intelligence Tracer™",
    critical: true,
    filePath: "server/services/networkIntelTracer.ts"
  },
  spiderBeacon: {
    expected: _computeBeaconHash("Alpha Spider Beacon Protocol"),
    label: "Spider Beacon Protocol™",
    critical: true,
    filePath: "server/services/spiderBeacon.ts"
  },
  privacyProtocolTracker: {
    expected: _computeBeaconHash("Alpha Privacy Protocol Tracker"),
    label: "Privacy Protocol Tracker™",
    critical: false,
    filePath: "server/services/privacyProtocolTracker.ts"
  },
  privacyExploitScanner: {
    expected: _computeBeaconHash("Alpha Privacy Exploit Scanner"),
    label: "Privacy Exploit Scanner™",
    critical: false,
    filePath: "server/services/privacyExploitScanner.ts"
  },
  caseExploitScanner: {
    expected: _computeBeaconHash("Alpha Case Exploit Scanner"),
    label: "Case Exploit Scanner™",
    critical: false,
    filePath: "server/services/caseExploitScanner.ts"
  },
  addressClusterEngine: {
    expected: _computeBeaconHash("Alpha Address Cluster Engine"),
    label: "Address Cluster Engine™",
    critical: true,
    filePath: "server/services/addressClusterEngine.ts"
  },
  addressLabelDatabase: {
    expected: _computeBeaconHash("Alpha Address Label Database"),
    label: "Address Label Database™",
    critical: true,
    filePath: "server/services/addressLabelDatabase.ts"
  },
  crossChainBridgeTracer: {
    expected: _computeBeaconHash("Alpha Cross-Chain Bridge Tracer"),
    label: "Cross-Chain Bridge Tracer™",
    critical: true,
    filePath: "server/services/crossChainBridgeTracer.ts"
  },
  peelChainDetector: {
    expected: _computeBeaconHash("Alpha Peel Chain Detector"),
    label: "Peel Chain Detector™",
    critical: true,
    filePath: "server/services/peelChainDetector.ts"
  },
  riskScoringEngine: {
    expected: _computeBeaconHash("Alpha Risk Scoring Engine"),
    label: "Risk Scoring Engine™",
    critical: true,
    filePath: "server/services/riskScoringEngine.ts"
  },
  minerService: {
    expected: _computeBeaconHash("Alpha Mining Service Engine"),
    label: "Mining Service Engine™",
    critical: true,
    filePath: "server/services/minerService.ts"
  },
  exchangeService: {
    expected: _computeBeaconHash("Alpha Exchange Service"),
    label: "Exchange Service™",
    critical: true,
    filePath: "server/services/exchangeService.ts"
  },
  antivirusService: {
    expected: _computeBeaconHash("Alpha Antivirus Scanner"),
    label: "Antivirus Scanner™",
    critical: false,
    filePath: "server/services/antivirusService.ts"
  },
  agentmailService: {
    expected: _computeBeaconHash("Alpha Forensic Communications Engine"),
    label: "Forensic Communications Engine™",
    critical: true,
    filePath: "server/services/agentmailService.ts"
  },
  sendgridService: {
    expected: _computeBeaconHash("Alpha Secure Email Delivery Engine"),
    label: "Secure Email Delivery Engine™",
    critical: false,
    filePath: "server/services/sendgridService.ts"
  },
  nowPaymentsService: {
    expected: _computeBeaconHash("Alpha Crypto Payment Processing Engine"),
    label: "Crypto Payment Processing Engine™",
    critical: false,
    filePath: "server/services/nowPaymentsService.ts"
  },
  pushNotificationService: {
    expected: _computeBeaconHash("Alpha Real-Time Alert Delivery System"),
    label: "Real-Time Alert Delivery System™",
    critical: false,
    filePath: "server/services/pushNotificationService.ts"
  },
  schedulerService: {
    expected: _computeBeaconHash("Alpha Autonomous Task Scheduler"),
    label: "Autonomous Task Scheduler™",
    critical: false,
    filePath: "server/services/schedulerService.ts"
  },
  hourlyForensicEmail: {
    expected: _computeBeaconHash("Alpha Hourly Forensic Email Engine"),
    label: "Hourly Forensic Email Engine™",
    critical: true,
    filePath: "server/services/hourlyForensicEmail.ts"
  },
  quantumSecurityEngine: {
    expected: _computeBeaconHash("Alpha Quantum Security Engine"),
    label: "Quantum Security Engine™",
    critical: true,
    filePath: "server/services/quantumSecurityEngine.ts"
  },
  quantumShieldProtocol: {
    expected: _computeBeaconHash("Alpha Quantum Shield Protocol"),
    label: "Alpha Quantum Shield Protocol™",
    critical: true,
    filePath: "client/src/pages/trading-platform/QuantumShield.tsx"
  },
  quantumVulnerabilityScanner: {
    expected: _computeBeaconHash("Quantum Vulnerability Scanner"),
    label: "Quantum Vulnerability Scanner™",
    critical: true,
    filePath: "client/src/pages/trading-platform/QuantumScanner.tsx"
  },
  quantumMigrationEngine: {
    expected: _computeBeaconHash("Alpha Quantum Migration Engine"),
    label: "Alpha Quantum Migration Engine™",
    critical: true,
    filePath: "client/src/pages/trading-platform/QuantumMigration.tsx"
  },
  quantumForensicModule: {
    expected: _computeBeaconHash("Quantum Forensic Intelligence Module"),
    label: "Quantum Forensic Intelligence Module™",
    critical: true,
    filePath: "client/src/pages/trading-platform/QuantumForensics.tsx"
  },
  safeSendQuantumWrap: {
    expected: _computeBeaconHash("SafeSend Quantum Wrap"),
    label: "SafeSend Quantum Wrap™",
    critical: true,
    filePath: "client/src/pages/trading-platform/QuantumWrap.tsx"
  },
  biweeklyForensicDigest: {
    expected: _computeBeaconHash("Alpha Bi-Weekly Forensic Digest Engine"),
    label: "Bi-Weekly Forensic Digest Engine™",
    critical: false,
    filePath: "server/services/biweeklyForensicDigest.ts"
  },
  moneroCrossChainEngine: {
    expected: _computeBeaconHash("Alpha Monero Cross-Chain Correlation Engine"),
    label: "Monero Cross-Chain Correlation Engine™",
    critical: false,
    filePath: "server/services/moneroCrossChainEngine.ts"
  }
};

const _beaconValidationResults: Map<string, boolean> = new Map();
let _sealGenerated = false;
const _fileChecksums: Map<string, string> = new Map();

function _validateSingleBeacon(moduleId: string, providedSeal: string): boolean {
  const entry = BEACON_REGISTRY[moduleId];
  if (!entry) return false;
  const valid = providedSeal === entry.expected;
  _beaconValidationResults.set(moduleId, valid);
  return valid;
}

export function registerBeacon(moduleId: string, seal: string): boolean {
  return _validateSingleBeacon(moduleId, seal);
}

function _validateFileIntegrity(): string[] {
  const failures: string[] = [];
  for (const [moduleId, entry] of Object.entries(BEACON_REGISTRY)) {
    if (!entry.filePath) continue;
    const checksum = _deriveFileChecksum(entry.filePath);
    if (checksum) {
      _fileChecksums.set(moduleId, checksum);
    } else {
      failures.push(entry.label);
    }
  }
  return failures;
}

function _generateProprietarySeal(): string {
  const allBeacons = Object.keys(BEACON_REGISTRY)
    .sort()
    .map(k => BEACON_REGISTRY[k].expected)
    .join("|");
  const checksumChain = [..._fileChecksums.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => v)
    .join("");
  return crypto.createHmac("sha256", _beaconEngineKey)
    .update(allBeacons + checksumChain + _validationEpoch).digest("hex");
}

export function validateServerBeacons(): { verified: boolean; seal: string; failures: string[] } {
  const failures: string[] = [];

  const serverModules = ["commandCenter", "botEngine", "securityFramework", "technicalAnalysis"];
  for (const moduleId of serverModules) {
    if (!_beaconValidationResults.get(moduleId)) {
      failures.push(BEACON_REGISTRY[moduleId]?.label || moduleId);
    }
  }

  if (failures.length > 0) {
    return { verified: false, seal: "", failures };
  }

  const fileFailures = _validateFileIntegrity();
  if (fileFailures.length > 0) {
    return { verified: false, seal: "", failures: fileFailures };
  }

  _sealGenerated = true;
  return { verified: true, seal: _generateProprietarySeal(), failures: [] };
}

const _serverValidation = validateServerBeacons;

let _beaconVerified = false;
let _proprietarySeal = "";

export function finalizeBeaconValidation(): void {
  const result = _serverValidation();
  if (!result.verified) {
    console.error(`[FATAL] Proprietary integrity check failed for: ${result.failures.join(", ")}`);
    console.error("[FATAL] Application cannot start. Unauthorized modification detected.");
    process.exit(1);
  }
  _beaconVerified = true;
  _proprietarySeal = result.seal;
}

export function getBeaconStatus(): boolean {
  return _beaconVerified;
}

export function getProprietarySeal(): string {
  return _proprietarySeal;
}

export function getFileChecksumCount(): number {
  return _fileChecksums.size;
}

export const BEACON_ENGINE_VERSION = "2.1.0";
export const COPYRIGHT_HOLDER = "Alpha Unlimited Trading Company";
export const BEACON_REGISTRY_SIZE = Object.keys(BEACON_REGISTRY).length;
