/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Law Enforcement Adoption Proposal Generator™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module generates a professional proposal presentation for law enforcement agencies
 * to adopt Alpha Unlimited Coin (AUC) and the Alpha Forensic Intelligence Engine™
 * as official tools for cryptocurrency theft investigation and fund recovery.
 *
 * Technologies Protected:
 * - Alpha Law Enforcement Adoption Proposal Generator™
 * - Alpha Forensic Intelligence Engine™ Proposal System
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: LE_PROPOSAL_v1.0_PROTECTED
 */

import { registerBeacon } from "./integrityBeacon.js";

export const _leProposalModuleHash = 'AUT_lep01_le_adoption_9f4b';
const _lepIntegrity = registerBeacon('leProposal', _leProposalModuleHash);

const BRAND = {
  dark: "0A0E14",
  panel: "161B22",
  cyan: "22D3EE",
  emerald: "34D399",
  gold: "F59E0B",
  red: "EF4444",
  white: "FFFFFF",
  gray: "9CA3AF",
  lightGray: "D1D5DB",
  blue: "3B82F6",
  navy: "1E3A5F",
};

const COPYRIGHT = "© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity. Patent Pending. CONFIDENTIAL.";

export async function generateLawEnforcementProposalPptx(): Promise<Buffer> {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();

  pptx.author = "Alpha Unlimited Trading Company";
  pptx.company = "Alpha Unlimited Trading Company";
  pptx.subject = "Law Enforcement Adoption Proposal — AUC Forensic Tracking Tool";
  pptx.title = "Alpha Forensic Intelligence Engine™ — Law Enforcement Adoption Proposal";

  const addFooter = (slide: any) => {
    slide.addText(COPYRIGHT, {
      x: 0.3, y: 6.8, w: 9.4, h: 0.3,
      fontSize: 6, color: BRAND.gray, align: "center",
      fontFace: "Arial",
    });
  };

  const addSlideNumber = (slide: any, num: number) => {
    slide.addText(`${num}`, {
      x: 9.2, y: 6.8, w: 0.5, h: 0.3,
      fontSize: 7, color: BRAND.gray, align: "right",
      fontFace: "Arial",
    });
  };

  // ─── SLIDE 1: TITLE ───
  let slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA FORENSIC INTELLIGENCE ENGINE™", {
    x: 0.5, y: 1.0, w: 9, h: 0.8,
    fontSize: 28, color: BRAND.cyan, bold: true, align: "center",
    fontFace: "Arial",
  });
  slide.addText("Law Enforcement Adoption Proposal", {
    x: 0.5, y: 1.9, w: 9, h: 0.6,
    fontSize: 20, color: BRAND.gold, align: "center",
    fontFace: "Arial",
  });
  slide.addText("A Comprehensive Blockchain Forensic Investigation Platform\nfor Cryptocurrency Theft Recovery", {
    x: 0.5, y: 2.7, w: 9, h: 0.7,
    fontSize: 13, color: BRAND.lightGray, align: "center",
    fontFace: "Arial", lineSpacingMultiple: 1.3,
  });
  slide.addText("Featuring: Alpha Unlimited Coin (AUC)\nThe World's First Forensic-Grade Tracking Coin", {
    x: 0.5, y: 3.6, w: 9, h: 0.7,
    fontSize: 12, color: BRAND.emerald, align: "center",
    fontFace: "Arial", lineSpacingMultiple: 1.3,
  });
  slide.addText("Alpha Unlimited Trading Company", {
    x: 0.5, y: 4.7, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.gold, align: "center", bold: true,
    fontFace: "Arial",
  });
  slide.addText("AlphaUnlimitedTrading.com", {
    x: 0.5, y: 5.1, w: 9, h: 0.3,
    fontSize: 11, color: BRAND.cyan, align: "center",
    fontFace: "Arial",
  });
  slide.addText("FOR LAW ENFORCEMENT USE ONLY — CONFIDENTIAL", {
    x: 0.5, y: 5.7, w: 9, h: 0.4,
    fontSize: 11, color: BRAND.red, align: "center", bold: true,
    fontFace: "Arial",
  });
  addFooter(slide);

  // ─── SLIDE 2: TABLE OF CONTENTS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("TABLE OF CONTENTS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  const tocItems = [
    "1.  The Crisis — Cryptocurrency Theft is Exploding",
    "2.  Current Limitations of Law Enforcement Tools",
    "3.  Our Solution — Alpha Forensic Intelligence Engine™",
    "4.  Alpha Unlimited Coin (AUC) — The Forensic Tracking Coin",
    "5.  How the AUC Trap Mechanism™ Works for Investigators",
    "6.  Alpha Spider Beacon Protocol™ — Persistent Surveillance",
    "7.  Complete Forensic Tool Suite Overview",
    "8.  Autonomous Spider Trace™ — Automated Fund Flow Analysis",
    "9.  Alpha Phantom Vault Protocol™ — Honeypot Operations",
    "10. OSINT & Network Intelligence Capabilities",
    "11. Real-Time Monitoring & Automated Alerts",
    "12. Active Case Study — $24M Physical Theft Recovery",
    "13. Court-Admissible Evidence Generation",
    "14. Cost Structure — Zero Upfront, 10% Recovery Fee",
    "15. Implementation: How Your Department Adopts This Tool",
    "16. Security & Privacy Safeguards",
    "17. Frequently Asked Questions",
    "18. Partnership Agreement & Next Steps",
    "19. Contact Information",
  ];
  slide.addText(tocItems.join("\n"), {
    x: 0.6, y: 1.05, w: 8.8, h: 5.4,
    fontSize: 10.5, color: BRAND.lightGray,
    fontFace: "Arial", lineSpacingMultiple: 1.3,
  });
  addFooter(slide);
  addSlideNumber(slide, 2);

  // ─── SLIDE 3: THE CRISIS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("THE CRISIS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Cryptocurrency Theft is Outpacing Law Enforcement Capabilities", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "The scale of cryptocurrency theft has reached crisis levels:\n\n" +
    "BY THE NUMBERS:\n" +
    "  •  2023: $1.7 billion stolen in crypto hacks and scams\n" +
    "  •  2024: $2.2 billion stolen — 21% increase year-over-year\n" +
    "  •  2025: On pace for $10+ billion (Bybit hack alone: $1.5 billion)\n" +
    "  •  Total since 2020: Over $20 billion in verified crypto theft\n" +
    "  •  Recovery rate: Less than 5% of stolen cryptocurrency is returned to victims\n\n" +
    "TYPES OF THEFT INVESTIGATED:\n" +
    "  •  Smart contract exploits (DeFi hacks, bridge exploits)\n" +
    "  •  Physical theft / home invasion with forced wallet access\n" +
    "  •  SIM swap attacks leading to exchange account takeover\n" +
    "  •  Phishing and social engineering targeting high-net-worth holders\n" +
    "  •  Insider theft at exchanges and custody providers\n" +
    "  •  Ransomware payments in cryptocurrency\n\n" +
    "IMPACT ON VICTIMS:\n" +
    "  •  Most victims have no path to recovery\n" +
    "  •  Traditional forensic tools cannot track funds through mixers, bridges, and DEX swaps\n" +
    "  •  By the time freeze requests reach exchanges, funds have already moved\n" +
    "  •  Monero conversion makes funds permanently untraceable with existing tools",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.1,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 3);

  // ─── SLIDE 4: CURRENT LIMITATIONS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("CURRENT LIMITATIONS OF LAW ENFORCEMENT TOOLS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 20, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Existing cryptocurrency investigation tools have critical gaps:\n\n" +
    "CHAINALYSIS / ELLIPTIC / CIPHERTRACE:\n" +
    "  •  Track fund flows between known wallets (useful but limited)\n" +
    "  •  Cannot embed tracking hooks INTO the cryptocurrency itself\n" +
    "  •  Cannot follow funds through mixers or privacy coins\n" +
    "  •  Require manual analysis — no autonomous tracking\n" +
    "  •  Expensive annual licenses ($50,000-$500,000+)\n" +
    "  •  Cannot deploy honeypot wallets or surveillance beacons\n\n" +
    "EXCHANGE COOPERATION:\n" +
    "  •  Freeze requests are manual and slow (days to weeks)\n" +
    "  •  By the time requests are processed, funds have moved\n" +
    "  •  No automated detection of incoming stolen funds\n" +
    "  •  Each exchange requires separate communication\n\n" +
    "WHAT'S MISSING:\n" +
    "  •  A cryptocurrency that tracks ITSELF when it moves\n" +
    "  •  Autonomous cross-chain surveillance that doesn't require manual intervention\n" +
    "  •  Honeypot wallet operations to lure and identify thieves\n" +
    "  •  Real-time automated alerts — not reports generated days later\n" +
    "  •  An investigation platform with ZERO upfront cost to agencies\n\n" +
    "Alpha Forensic Intelligence Engine™ fills every one of these gaps.",
    {
      x: 0.5, y: 1.0, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 4);

  // ─── SLIDE 5: THE SOLUTION ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("OUR SOLUTION", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Alpha Forensic Intelligence Engine™ — A Complete Investigation Platform", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 12, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "Alpha Forensic Intelligence Engine™ is a comprehensive, cloud-based blockchain forensic\ninvestigation platform purpose-built for law enforcement agencies.\n\n" +
    "WHAT IT DOES:\n\n" +
    "  •  Traces stolen cryptocurrency across 20+ blockchain networks in real time\n" +
    "  •  Deploys persistent surveillance beacons on suspect wallets (Spider Beacon Protocol™)\n" +
    "  •  Uses AUC Trap Mechanism™ to embed tracking hooks into seized cryptocurrency\n" +
    "  •  Operates honeypot wallets to identify and profile thieves (Phantom Vault Protocol™)\n" +
    "  •  Generates court-admissible evidence chains with cryptographic timestamps\n" +
    "  •  Sends automated exchange freeze requests\n" +
    "  •  Provides 24/7 automated monitoring with real-time email alerts\n" +
    "  •  Scans 22+ OSINT platforms (surface web, dark web, paste sites, forums)\n" +
    "  •  Analyzes transaction timing, behavioral patterns, and network infrastructure\n\n" +
    "HOW IT'S DIFFERENT:\n\n" +
    "  •  ZERO upfront cost to your department — we earn 10% of recovered funds only\n" +
    "  •  Fully autonomous — the system runs 24/7 without manual intervention\n" +
    "  •  Active tracking, not passive analysis — beacons and traps, not just reports\n" +
    "  •  Already operational with an active $24M theft investigation in progress\n" +
    "  •  Web-based command center — no software installation required",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.2,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 5);

  // ─── SLIDE 6: AUC COIN ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA UNLIMITED COIN (AUC)", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText("The World's First Forensic-Grade Tracking Coin", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 14, color: BRAND.cyan,
    fontFace: "Arial",
  });
  slide.addText(
    "AUC is NOT a speculative cryptocurrency. It is a purpose-built forensic tracking tool\ndesigned specifically for law enforcement use.\n\n" +
    "WHAT MAKES AUC UNIQUE:\n\n" +
    "  BUILT-IN TRANSFER HOOKS (Patent Pending)\n" +
    "  Every single AUC transaction — no matter how small — automatically sends a\n" +
    "  forensic signal to the command center including:\n" +
    "    - Sender wallet address\n" +
    "    - Receiver wallet address\n" +
    "    - Exact amount transferred\n" +
    "    - Millisecond-precision timestamp\n" +
    "    - Transaction hash for audit trail\n\n" +
    "  These hooks are embedded at the blockchain protocol level.\n" +
    "  They CANNOT be disabled, bypassed, or removed — even by us.\n\n" +
    "HOW LAW ENFORCEMENT USES AUC:\n\n" +
    "  1. Investigator identifies wallet holding stolen funds\n" +
    "  2. Court order authorizes swap of flagged tokens into AUC\n" +
    "  3. AUC Trap activates — every movement now generates signals\n" +
    "  4. Thief moves AUC to exchange → KYC identity revealed\n" +
    "  5. Evidence chain supports prosecution and fund recovery\n" +
    "  6. 10% recovery fee paid to Alpha Unlimited upon successful recovery",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.1,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 6);

  // ─── SLIDE 7: AUC TRAP MECHANISM ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("AUC TRAP MECHANISM™ — FOR INVESTIGATORS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Step-by-step operational workflow for law enforcement:\n\n" +
    "PHASE 1: DETECTION & ASSESSMENT\n" +
    "  •  Victim reports cryptocurrency theft to your department\n" +
    "  •  Alpha Forensic Intelligence Engine™ begins automated blockchain scanning\n" +
    "  •  Fund flows traced across all 20+ supported chains\n" +
    "  •  Spider Beacons deployed on identified suspect wallets\n\n" +
    "PHASE 2: AUC TRAP DEPLOYMENT\n" +
    "  •  Investigator identifies wallet(s) holding significant stolen funds\n" +
    "  •  Court order obtained authorizing token swap to AUC\n" +
    "  •  Flagged tokens swapped to AUC on listed exchange\n" +
    "  •  AUC Trap Mechanism™ activates immediately\n" +
    "  •  Original wallet ALSO continues to be monitored\n\n" +
    "PHASE 3: PERPETUAL TRACKING\n" +
    "  •  Every AUC movement generates real-time signal in command center\n" +
    "  •  Splits, transfers, exchange deposits — all tracked automatically\n" +
    "  •  If AUC is swapped back to another coin, Spider Beacons follow\n" +
    "  •  24/7 email alerts sent to assigned investigator\n\n" +
    "PHASE 4: IDENTIFICATION & RECOVERY\n" +
    "  •  AUC deposited at exchange → exchange KYC reveals identity\n" +
    "  •  Automated freeze request sent to exchange compliance team\n" +
    "  •  Court-admissible evidence package generated\n" +
    "  •  Funds recovered and returned to victim (minus 10% recovery fee)",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 7);

  // ─── SLIDE 8: SPIDER BEACON ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA SPIDER BEACON PROTOCOL™", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Persistent Cross-Chain Surveillance for Investigators", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "Spider Beacons are persistent surveillance units that monitor suspect wallets\nacross 20+ blockchain networks simultaneously.\n\n" +
    "BEACON TYPES AVAILABLE:\n\n" +
    "  ADDRESS MONITOR — Watches a specific wallet for any balance change or transaction.\n" +
    "                    Checks every 5 minutes automatically.\n\n" +
    "  CROSS-CHAIN — When deployed, automatically creates dormant beacons on 5+ other\n" +
    "                chains. If the suspect moves funds to a different blockchain, the\n" +
    "                dormant beacon activates and begins tracking.\n\n" +
    "  DEX WATCHER — Monitors decentralized exchange interactions. Detects when a suspect\n" +
    "                swaps tokens on Uniswap, SushiSwap, PancakeSwap, etc.\n\n" +
    "  BRIDGE SENTINEL — Detects when funds move through cross-chain bridges, which\n" +
    "                    criminals commonly use to obscure fund trails.\n\n" +
    "  AUC TRAP — Monitors AUC blockchain transfer hooks (requires AUC exchange listing).\n\n" +
    "SUPPORTED NETWORKS:\n" +
    "  Ethereum, Arbitrum, Optimism, Base, Polygon, BSC, Gnosis, Avalanche,\n" +
    "  Fantom, zkSync, Linea, Scroll, Celo, Blast, Mantle, Moonbeam,\n" +
    "  Cronos, Bitcoin, Solana, TRON\n\n" +
    "SIGNAL SEVERITY LEVELS:\n" +
    "  CRITICAL — Large movement, exchange deposit, or AUC trap triggered\n" +
    "  WARNING  — Moderate activity, contract interaction, or balance change\n" +
    "  INFO     — Minor activity or status update",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.2,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 8);

  // ─── SLIDE 9: TOOL SUITE OVERVIEW ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("COMPLETE FORENSIC TOOL SUITE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });

  const toolRows: any[][] = [
    [
      { text: "Tool", options: { bold: true, color: BRAND.cyan, fill: { color: "111827" }, fontSize: 8.5 } },
      { text: "What It Does", options: { bold: true, color: BRAND.cyan, fill: { color: "111827" }, fontSize: 8.5 } },
    ],
    [
      { text: "Spider Beacon Protocol™", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Persistent wallet surveillance across 20+ chains with auto-expanding beacons", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "AUC Trap Mechanism™", options: { fontSize: 8, color: BRAND.gold, bold: true } },
      { text: "Swap stolen crypto into AUC for perpetual transfer-hook tracking", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Autonomous Spider Trace™", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Recursive fund flow analysis — traces every split, swap, and bridge hop", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Phantom Vault Protocol™", options: { fontSize: 8, color: BRAND.gold, bold: true } },
      { text: "Deploys honeypot wallets to lure and identify thieves", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Exchange Freeze System", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Automated freeze requests sent to exchanges when stolen funds arrive", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "OSINT Deep Scanner", options: { fontSize: 8, color: BRAND.gold, bold: true } },
      { text: "Scans surface web, dark web, paste sites, and forums for wallet mentions", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Network Intelligence Tracer™", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Analyzes transaction timing, behavioral patterns, and device fingerprints", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Laundering Risk Intelligence", options: { fontSize: 8, color: BRAND.gold, bold: true } },
      { text: "Tracks Tornado Cash, Monero on-ramps, and DeFi freeze protocol gaps", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Transaction Origin Intel™", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Profiles funding sources with ENS, labels, and protocol interaction history", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Fund Flow Visualization", options: { fontSize: 8, color: BRAND.gold, bold: true } },
      { text: "Arkham-style interactive graph with zoom, pan, and entity profiling", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
    [
      { text: "Bounty Recovery Agreements", options: { fontSize: 8, color: BRAND.emerald, bold: true } },
      { text: "Digital signature legal framework for recovery fee agreements", options: { fontSize: 8, color: BRAND.lightGray } },
    ],
  ];

  slide.addTable(toolRows, {
    x: 0.3, y: 1.0, w: 9.4,
    border: { type: "solid", color: "374151", pt: 0.5 },
    colW: [2.8, 6.6],
    rowH: [0.35, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4],
    fill: { color: BRAND.panel },
    margin: [3, 5, 3, 5],
  });

  addFooter(slide);
  addSlideNumber(slide, 9);

  // ─── SLIDE 10: SPIDER TRACE ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("AUTONOMOUS SPIDER TRACE™", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Automated Fund Flow Analysis — No Manual Work Required", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "The Autonomous Spider Trace™ recursively follows every dollar of stolen cryptocurrency:\n\n" +
    "HOW IT WORKS:\n" +
    "  1. Start with the victim's wallet address and theft transaction\n" +
    "  2. System automatically traces ALL outgoing transactions\n" +
    "  3. For each receiving wallet, it repeats the process (recursive tracing)\n" +
    "  4. Continues until funds reach exchange deposit addresses, mixers, or dead ends\n" +
    "  5. Creates a complete fund flow map showing every hop\n\n" +
    "WHAT IT DETECTS:\n" +
    "  •  Token splits — when stolen funds are divided among multiple wallets\n" +
    "  •  Chain hops — when funds bridge from Ethereum to Arbitrum, BSC, etc.\n" +
    "  •  DEX swaps — when tokens are exchanged (DAI → ETH → USDC)\n" +
    "  •  Mixer interactions — Tornado Cash, ChipMixer, Wasabi\n" +
    "  •  Exchange deposits — where funds land for potential cashout\n" +
    "  •  Monero on-ramps — Wagyu Bridge, ChangeNOW, FixedFloat, etc.\n\n" +
    "AUTOMATION:\n" +
    "  •  Runs 24/7 without investigator intervention\n" +
    "  •  Automatically detects new transactions and extends the trace\n" +
    "  •  Email alerts when significant movements detected\n" +
    "  •  Visual fund flow graph updated in real time\n" +
    "  •  Currently tracking 10,000+ transaction hashes in active case",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.1,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 10);

  // ─── SLIDE 11: PHANTOM VAULT ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ALPHA PHANTOM VAULT PROTOCOL™", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Honeypot Wallet Operations for Criminal Identification", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 13, color: BRAND.cyan,
    fontFace: "Arial",
  });
  slide.addText(
    "The Phantom Vault Protocol™ creates monitored decoy wallets that appear to contain\nvaluable cryptocurrency, attracting and identifying potential thieves.\n\n" +
    "OPERATIONAL CONCEPT:\n" +
    "  •  Deploy decoy wallets on target blockchains (Ethereum, BSC, Polygon, etc.)\n" +
    "  •  Load with real or apparent token balances (USDC, USDT, ETH)\n" +
    "  •  Monitor 24/7 for any interaction — transfers, approval attempts, contract calls\n" +
    "  •  When a thief interacts, capture wallet address, timing, and behavior patterns\n" +
    "  •  Cross-reference with case databases for suspect identification\n\n" +
    "USE CASES FOR LAW ENFORCEMENT:\n\n" +
    "  STING OPERATIONS\n" +
    "  Deploy phantom wallets in known criminal infrastructure. When thieves attempt\n" +
    "  to drain them, their wallet addresses are captured and traced.\n\n" +
    "  SUSPECT VERIFICATION\n" +
    "  Share a phantom wallet address with a suspected thief. If they interact with it,\n" +
    "  this provides evidence linking them to criminal activity.\n\n" +
    "  REPEAT OFFENDER DETECTION\n" +
    "  Cross-reference phantom vault interactions with known criminal wallets from\n" +
    "  previous cases to identify serial offenders.\n\n" +
    "  All phantom vault operations are logged with court-admissible timestamps.",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.1,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 11);

  // ─── SLIDE 12: OSINT ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("OSINT & NETWORK INTELLIGENCE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.blue, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Open Source Intelligence & Network Analysis Capabilities:\n\n" +
    "OSINT DEEP SCANNER — AUTOMATED PLATFORM SCANNING:\n" +
    "  •  Surface web search engines (Google, DuckDuckGo)\n" +
    "  •  Dark web forums and marketplaces\n" +
    "  •  Paste sites (Pastebin, Rentry, Ghostbin)\n" +
    "  •  Blockchain explorers (Etherscan, Blockscout, Arbiscan)\n" +
    "  •  Social media platforms (Twitter/X mentions)\n" +
    "  •  Telegram groups and channels\n" +
    "  •  Discord servers\n" +
    "  •  Underground forums and OTC trading groups\n" +
    "  •  Domain registration databases (WHOIS)\n" +
    "  •  22+ platforms scanned simultaneously\n\n" +
    "NETWORK INTELLIGENCE TRACER™:\n" +
    "  •  Transaction timing analysis — identifies timezone and activity patterns\n" +
    "  •  Behavioral profiling — gas usage, contract interaction frequency\n" +
    "  •  Ethereum node propagation analysis — potential IP inference\n" +
    "  •  Device fingerprinting indicators\n" +
    "  •  VPN detection signals\n\n" +
    "TRANSACTION ORIGIN INTELLIGENCE™:\n" +
    "  •  Profiles funding sources for every suspect wallet\n" +
    "  •  ENS name resolution, exchange labels, protocol history\n" +
    "  •  Risk scoring (LOW / MEDIUM / HIGH / CRITICAL)",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 12);

  // ─── SLIDE 13: MONITORING & ALERTS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("REAL-TIME MONITORING & AUTOMATED ALERTS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "The system runs 24/7/365 without manual intervention:\n\n" +
    "CONTINUOUS MONITORING:\n" +
    "  •  Spider Beacons check all monitored wallets every 5 minutes\n" +
    "  •  Wallet Monitor Service checks all case wallets every 5 minutes\n" +
    "  •  Token Flow Tracer runs every 3 minutes for new transactions\n" +
    "  •  Real-time price feeds for accurate value calculations\n" +
    "  •  Cross-chain monitoring across 20+ networks simultaneously\n\n" +
    "AUTOMATED ALERTS:\n" +
    "  •  Hourly email updates to assigned investigator\n" +
    "  •  Only sends emails when NEW information is detected\n" +
    "  •  Includes balance changes, new transactions, OSINT findings\n" +
    "  •  Critical alerts (large movements) sent immediately\n" +
    "  •  Alerts include wallet addresses, amounts, and chain details\n\n" +
    "COMMAND CENTER DASHBOARD:\n" +
    "  •  Web-based — accessible from any browser, no software install\n" +
    "  •  Real-time wallet balance display with live crypto prices\n" +
    "  •  Interactive fund flow visualization (zoom, pan, click nodes)\n" +
    "  •  Signal feed showing all beacon activity\n" +
    "  •  Entity profiles with portfolio breakdowns\n" +
    "  •  Export capabilities for reports and evidence packages\n\n" +
    "ACTIVE CASE:\n" +
    "  Currently monitoring 3,700+ wallet addresses with 30+ active beacons,\n" +
    "  10,000+ tracked transactions, sending hourly updates to the victim.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 13);

  // ─── SLIDE 14: CASE STUDY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("ACTIVE CASE STUDY — $24M PHYSICAL THEFT", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Demonstrating real-world capabilities with an active investigation:\n\n" +
    "CASE: @sillytuna (Alex Amsel) — ~$24,000,000 Cryptocurrency Theft\n" +
    "TYPE: Physical home invasion with forced wallet/device access\n" +
    "STATUS: ACTIVE INVESTIGATION — Technologies deployed and tracking\n\n" +
    "FUND FLOWS IDENTIFIED:\n" +
    "  •  ~$20M DAI moved from hub wallet → 12+ distribution wallets on Ethereum\n" +
    "  •  $2.47M converted to Monero via Hyperliquid/Wagyu Bridge (19 accounts)\n" +
    "  •  $1.1M Bitcoin via LiFi bridge (~0.5 BTC through mixer services)\n" +
    "  •  $2.48M USDC distributed to 10 Arbitrum receiver wallets\n\n" +
    "TECHNOLOGIES ACTIVELY DEPLOYED:\n" +
    "  •  30+ Spider Beacons across Ethereum and Arbitrum\n" +
    "  •  Autonomous Spider Trace — 10,000+ transaction hashes tracked\n" +
    "  •  OSINT Scanner — 3,700+ addresses scanned across 22 platforms\n" +
    "  •  Network Intelligence — Behavioral profiling on POI wallets\n" +
    "  •  Transaction Origin Intel — Funding source analysis on all receivers\n" +
    "  •  Laundering Risk — Tornado Cash, Monero, DeFi gap detection\n" +
    "  •  24/7 hourly email updates to victim\n\n" +
    "KEY FINDING:\n" +
    "  Crypto.com exchange wallet identified: 0x658370618bbc885865df66c1061bfe4771fad846\n" +
    "  containing 155,017.66 USDC — directly linked to theft chain.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 14);

  // ─── SLIDE 15: EVIDENCE ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("COURT-ADMISSIBLE EVIDENCE GENERATION", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "All forensic data generated by the platform is designed for court use:\n\n" +
    "EVIDENCE INTEGRITY:\n" +
    "  •  All transactions logged with cryptographic SHA-256 timestamps\n" +
    "  •  Immutable audit trail — data cannot be altered after recording\n" +
    "  •  Chain of custody documented from detection through recovery\n" +
    "  •  HMAC-signed data integrity verification on all forensic modules\n\n" +
    "EXPORTABLE EVIDENCE PACKAGES:\n" +
    "  •  Complete fund flow maps with transaction hashes and block numbers\n" +
    "  •  Wallet interaction timelines with precise timestamps\n" +
    "  •  OSINT findings with source URLs and discovery timestamps\n" +
    "  •  Spider Beacon signal logs showing surveillance coverage\n" +
    "  •  Entity profiles with on-chain behavioral analysis\n" +
    "  •  Laundering risk assessments with specific mixer/bridge identification\n\n" +
    "REPORT GENERATION:\n" +
    "  •  Victim reports — comprehensive case summary for the affected party\n" +
    "  •  Law enforcement reports — technical details formatted for investigators\n" +
    "  •  Exchange freeze requests — formatted for compliance team review\n" +
    "  •  Bounty Recovery Agreements — digital signature legal documents\n" +
    "  •  Technology briefings — 18-slide PPTX for department training\n\n" +
    "All reports can be emailed directly from the platform via encrypted channels.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 15);

  // ─── SLIDE 16: COST STRUCTURE ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("COST STRUCTURE", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText("Zero Upfront Cost — 10% Recovery Fee Model", {
    x: 0.5, y: 0.85, w: 9, h: 0.4,
    fontSize: 14, color: BRAND.gold,
    fontFace: "Arial",
  });
  slide.addText(
    "Unlike traditional forensic tools that charge $50,000-$500,000+ in annual licenses,\nAlpha Forensic Intelligence Engine™ costs your department NOTHING upfront.\n\n" +
    "HOW IT WORKS:\n\n" +
    "  •  Your department gets FULL ACCESS to all forensic tools — no limitations\n" +
    "  •  All technologies listed in this proposal are included at no cost\n" +
    "  •  We only earn money when we help RECOVER stolen cryptocurrency\n" +
    "  •  Recovery fee: 10% of the funds actually recovered and returned to the victim\n" +
    "  •  If nothing is recovered, your department pays nothing\n\n" +
    "FEE DOCUMENTATION:\n" +
    "  •  Bounty Recovery Agreement signed before investigation begins\n" +
    "  •  Agreement includes digital signatures, case ID, and specific terms\n" +
    "  •  Fee only applies to funds returned to victim — not seized funds held in evidence\n" +
    "  •  All fee calculations are transparent and auditable in the platform\n\n" +
    "EXAMPLE:\n" +
    "  Case value:      $24,000,000 stolen\n" +
    "  Funds recovered: $18,000,000\n" +
    "  Recovery fee:    $1,800,000 (10%)\n" +
    "  Victim receives: $16,200,000\n" +
    "  Your department:  $0 cost\n\n" +
    "COMPARISON:\n" +
    "  Chainalysis Reactor: ~$100,000-$500,000/year license\n" +
    "  Alpha Forensic Engine: $0 upfront, 10% of recoveries only",
    {
      x: 0.5, y: 1.35, w: 9, h: 5.2,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 16);

  // ─── SLIDE 17: IMPLEMENTATION ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("HOW YOUR DEPARTMENT ADOPTS THIS TOOL", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.cyan, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Simple, fast implementation — no IT infrastructure required:\n\n" +
    "STEP 1: PARTNERSHIP AGREEMENT (Day 1)\n" +
    "  •  Sign partnership agreement with Alpha Unlimited Trading Company\n" +
    "  •  Define authorized personnel and access levels\n" +
    "  •  Establish communication protocols\n\n" +
    "STEP 2: ACCOUNT SETUP (Day 1-2)\n" +
    "  •  Authorized investigators create accounts at AlphaUnlimitedTrading.com\n" +
    "  •  Admin access granted to Forensic Intelligence Engine™ command center\n" +
    "  •  No software installation — fully web-based platform\n\n" +
    "STEP 3: TRAINING (Day 2-3)\n" +
    "  •  Video call training session (1-2 hours)\n" +
    "  •  Covers: case creation, beacon deployment, evidence export\n" +
    "  •  Technology briefing materials provided (PPTX and documentation)\n\n" +
    "STEP 4: FIRST CASE (Day 3+)\n" +
    "  •  Investigator creates case in command center\n" +
    "  •  Adds victim and suspect wallet addresses\n" +
    "  •  System automatically begins scanning, tracing, and monitoring\n" +
    "  •  Spider Beacons deploy across relevant chains\n" +
    "  •  Automated alerts begin within minutes\n\n" +
    "TOTAL SETUP TIME: 1-3 business days\n" +
    "ONGOING SUPPORT: Unlimited, included at no additional cost",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 10, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 17);

  // ─── SLIDE 18: SECURITY ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("SECURITY & PRIVACY SAFEGUARDS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.red, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Enterprise-grade security protecting investigation data:\n\n" +
    "PLATFORM SECURITY (10-Layer Architecture):\n" +
    "  •  109 active protection features\n" +
    "  •  HMAC-signed data integrity on all forensic modules\n" +
    "  •  Device fingerprinting and anti-debugging protection\n" +
    "  •  Rate limiting, WAF, CSRF protection\n" +
    "  •  Secure HttpOnly session cookies with idle timeouts\n" +
    "  •  IP change detection and automated blocking\n\n" +
    "DATA PRIVACY:\n" +
    "  •  Case data isolated per investigation — no cross-case data leakage\n" +
    "  •  Admin-only access to forensic command center\n" +
    "  •  All communications encrypted in transit (TLS 1.3)\n" +
    "  •  Database encryption at rest (PostgreSQL with encrypted storage)\n" +
    "  •  Audit logs of all investigator actions\n\n" +
    "ACCESS CONTROL:\n" +
    "  •  Multi-factor authentication available\n" +
    "  •  Role-based access (admin, investigator, viewer)\n" +
    "  •  Emergency account freeze (kill switch)\n" +
    "  •  Trusted device management\n" +
    "  •  Login activity monitoring\n\n" +
    "COMPLIANCE:\n" +
    "  •  SOC 2 and ISO 27001 compliance framework\n" +
    "  •  CJIS Security Policy compatible\n" +
    "  •  Data retention policies aligned with law enforcement requirements",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 18);

  // ─── SLIDE 19: FAQ ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("FREQUENTLY ASKED QUESTIONS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.gold, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "Q: Does my department need to purchase cryptocurrency?\n" +
    "A: No. The platform operates using existing blockchain data. AUC Trap operations\n" +
    "   would use court-ordered seized funds, not department budgets.\n\n" +
    "Q: Is this admissible in court?\n" +
    "A: Yes. All data includes cryptographic timestamps, immutable audit trails, and chain\n" +
    "   of custody documentation designed for legal proceedings.\n\n" +
    "Q: What if we don't recover anything?\n" +
    "A: You pay nothing. The 10% fee only applies to funds actually recovered\n" +
    "   and returned to the victim.\n\n" +
    "Q: Do we need special hardware or software?\n" +
    "A: No. The platform is entirely web-based. Any modern browser works.\n" +
    "   No installation, no IT department involvement required.\n\n" +
    "Q: How is this different from Chainalysis?\n" +
    "A: Chainalysis provides passive analysis. We provide ACTIVE tracking with beacons,\n" +
    "   traps, honeypots, and automated alerts. Plus zero upfront cost.\n\n" +
    "Q: Can criminals detect the AUC tracking?\n" +
    "A: The transfer hooks are embedded at the protocol level and are invisible to\n" +
    "   users. There is no way to detect or disable them.\n\n" +
    "Q: What jurisdictions do you cover?\n" +
    "A: The platform monitors 20+ blockchain networks globally. We can support\n" +
    "   investigations in any jurisdiction.",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.5,
      fontSize: 9.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.15, valign: "top",
    }
  );
  addFooter(slide);
  addSlideNumber(slide, 19);

  // ─── SLIDE 20: PARTNERSHIP & NEXT STEPS ───
  slide = pptx.addSlide();
  slide.background = { color: BRAND.dark };
  slide.addText("PARTNERSHIP AGREEMENT & NEXT STEPS", {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, color: BRAND.emerald, bold: true,
    fontFace: "Arial",
  });
  slide.addText(
    "We invite your department to partner with Alpha Unlimited Trading Company.\n\n" +
    "WHAT YOUR DEPARTMENT RECEIVES:\n\n" +
    "  •  Full access to Alpha Forensic Intelligence Engine™ (all tools included)\n" +
    "  •  Spider Beacon Protocol™ deployment capabilities\n" +
    "  •  Phantom Vault Protocol™ for honeypot operations\n" +
    "  •  24/7 automated monitoring and email alerts\n" +
    "  •  OSINT deep scanning across 22+ platforms\n" +
    "  •  Court-admissible evidence generation\n" +
    "  •  Unlimited training and technical support\n" +
    "  •  All of the above at ZERO upfront cost\n\n" +
    "NEXT STEPS:\n\n" +
    "  1.  Schedule a live platform demonstration (video call, 30-60 minutes)\n" +
    "  2.  Review partnership agreement and terms\n" +
    "  3.  Designate authorized investigators for account creation\n" +
    "  4.  Begin first case within 1-3 business days of agreement\n\n\n" +
    "CONTACT:\n\n" +
    "  Company:    Alpha Unlimited Trading Company\n" +
    "  Website:    AlphaUnlimitedTrading.com\n" +
    "  Email:      forensics@alphaunlimitedtrading.com\n" +
    "  Platform:   AlphaUnlimitedTrading.com/forensic-command-center",
    {
      x: 0.5, y: 0.95, w: 9, h: 5.3,
      fontSize: 10.5, color: BRAND.lightGray,
      fontFace: "Arial", lineSpacingMultiple: 1.2, valign: "top",
    }
  );
  slide.addText("Together, we can make cryptocurrency theft recoverable.", {
    x: 0.5, y: 6.3, w: 9, h: 0.35,
    fontSize: 12, color: BRAND.gold, align: "center", italic: true,
    fontFace: "Arial",
  });
  addFooter(slide);
  addSlideNumber(slide, 20);

  const buffer = await pptx.write({ outputType: "nodebuffer" });
  return buffer as Buffer;
}
