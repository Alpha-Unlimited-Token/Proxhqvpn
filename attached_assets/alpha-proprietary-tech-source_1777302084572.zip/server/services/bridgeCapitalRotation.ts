/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Bridge Capital-Rotation Signal™
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws (Title 17 / DMCA / CFAA / DTSA).
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Detects multi-chain capital rotation by tracking ETH inflows / outflows on
 * canonical L2 bridges and major cross-chain bridges. When large net capital
 * leaves Ethereum mainnet for a destination chain, that's an early "rotate-into-X"
 * signal for AI trading bots.
 *
 * Patent Pending. Trade Secret Protected.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Bridge Capital-Rotation Signal™');

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';

/**
 * Canonical L1->L2 bridge contracts on Ethereum mainnet.
 * ETH sent TO these = rotation OUT of mainnet INTO that L2.
 * All addresses are publicly verified on Etherscan.
 */
export const BRIDGE_CONTRACTS: { address: string; name: string; destinationChain: string; type: 'canonical' | 'third_party' }[] = [
  { address: '0x99c9fc46f92e8a1c0dec1b1747d010903e884be1', name: 'Optimism Gateway',     destinationChain: 'Optimism', type: 'canonical'  },
  { address: '0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f', name: 'Arbitrum Inbox',       destinationChain: 'Arbitrum', type: 'canonical'  },
  { address: '0x49048044d57e1c92a77f79988d21fa8faf74e97e', name: 'Base L1 Bridge',       destinationChain: 'Base',     type: 'canonical'  },
  { address: '0x401f6c983ea34274ec46f84d70b31c151321188b', name: 'Polygon PoS Bridge',   destinationChain: 'Polygon',  type: 'canonical'  },
  { address: '0xa0c68c638235ee32657e8f720a23cec1bfc77c77', name: 'Polygon (Plasma)',     destinationChain: 'Polygon',  type: 'canonical'  },
  { address: '0x8731d54e9d02c286767d56ac03e8037c07e01e98', name: 'Stargate (LayerZero)', destinationChain: 'Multi',    type: 'third_party' },
  { address: '0x5c7bcd6e7de5423a257d81b442095a1a6ced35c5', name: 'Across V3 SpokePool',  destinationChain: 'Multi',    type: 'third_party' },
  { address: '0x2796317b0ff8538f253012862c06787adfb8ceb6', name: 'Synapse Bridge',       destinationChain: 'Multi',    type: 'third_party' },
  { address: '0x3ee18b2214aff97000d974cf647e54347de73b0e', name: 'Wormhole Token Bridge',destinationChain: 'Multi',    type: 'third_party' },
];

interface BridgeFlow {
  bridgeAddress: string;
  bridgeName: string;
  destinationChain: string;
  type: 'canonical' | 'third_party';
  ethInflow: number;        // ETH sent TO bridge (rotating out of mainnet)
  ethOutflow: number;       // ETH coming back FROM bridge (rotating in to mainnet)
  netRotationOutOfMainnet: number;
  inflowTxCount: number;
  outflowTxCount: number;
}

export interface RotationSignal {
  destinationChain: string;
  signal: 'STRONG_ROTATE_IN' | 'ROTATE_IN' | 'NEUTRAL' | 'ROTATE_OUT' | 'STRONG_ROTATE_OUT';
  confidence: number;       // 0-100
  netEthFlow: number;       // positive = mainnet→destination, negative = destination→mainnet
  totalEthVolume: number;
  bridgesObserved: number;
  reasoning: string[];
}

export interface BridgeRotationReport {
  _proprietaryHeader: string;
  generatedAt: string;
  windowHours: number;
  bridgesScanned: number;
  totalBridgeVolumeEth: number;
  bridgeFlows: BridgeFlow[];
  rotationSignals: RotationSignal[];
}

async function alchemyRpc<T = any>(method: string, params: any[]): Promise<T> {
  const url = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  if (!r.ok) throw new Error(`Alchemy ${method} failed: ${r.status}`);
  const j = await r.json();
  if (j.error) throw new Error(`Alchemy ${method} error: ${j.error.message}`);
  return j.result;
}

async function getCurrentBlock(): Promise<number> {
  const hex: string = await alchemyRpc('eth_blockNumber', []);
  return parseInt(hex, 16);
}

async function getBridgeTransfers(bridge: string, fromBlockHex: string, direction: 'in' | 'out'): Promise<{ count: number; totalEth: number }> {
  const params: any = {
    fromBlock: fromBlockHex,
    toBlock: 'latest',
    category: ['external'],
    maxCount: '0x3e8',  // 1000
    withMetadata: false,
    excludeZeroValue: true,
    order: 'desc',
  };
  if (direction === 'in') params.toAddress = bridge;
  else params.fromAddress = bridge;
  try {
    const res: any = await alchemyRpc('alchemy_getAssetTransfers', [params]);
    const transfers = res?.transfers || [];
    let totalEth = 0;
    let count = 0;
    for (const t of transfers) {
      if (t.asset !== 'ETH' || typeof t.value !== 'number') continue;
      totalEth += t.value;
      count++;
    }
    return { count, totalEth };
  } catch {
    return { count: 0, totalEth: 0 };
  }
}

export async function generateBridgeRotationSignals(windowHours = 24): Promise<BridgeRotationReport> {
  if (!ALCHEMY_KEY) throw new Error('ALCHEMY_API_KEY is not set');

  const currentBlock = await getCurrentBlock();
  const blocksBack = Math.ceil((windowHours * 3600) / 12);
  const fromBlock = currentBlock - blocksBack;
  const fromBlockHex = `0x${fromBlock.toString(16)}`;

  const flows: BridgeFlow[] = [];

  for (const b of BRIDGE_CONTRACTS) {
    try {
      const [inFlow, outFlow] = await Promise.all([
        getBridgeTransfers(b.address, fromBlockHex, 'in'),
        getBridgeTransfers(b.address, fromBlockHex, 'out'),
      ]);
      flows.push({
        bridgeAddress: b.address,
        bridgeName: b.name,
        destinationChain: b.destinationChain,
        type: b.type,
        ethInflow: inFlow.totalEth,
        ethOutflow: outFlow.totalEth,
        netRotationOutOfMainnet: inFlow.totalEth - outFlow.totalEth,
        inflowTxCount: inFlow.count,
        outflowTxCount: outFlow.count,
      });
      await new Promise(r => setTimeout(r, 200));
    } catch {
      // skip bridge on error
    }
  }

  // Group by destination chain (excluding "Multi" — those need separate emit)
  const byChain: Record<string, { netEth: number; volume: number; bridges: number; bridgeNames: string[] }> = {};
  for (const f of flows) {
    const k = f.destinationChain;
    if (!byChain[k]) byChain[k] = { netEth: 0, volume: 0, bridges: 0, bridgeNames: [] };
    byChain[k].netEth += f.netRotationOutOfMainnet;
    byChain[k].volume += f.ethInflow + f.ethOutflow;
    byChain[k].bridges++;
    byChain[k].bridgeNames.push(f.bridgeName);
  }

  const rotationSignals: RotationSignal[] = [];
  for (const [chain, data] of Object.entries(byChain)) {
    if (data.volume < 10) continue;  // ignore noise
    const intensity = Math.abs(data.netEth) / Math.max(1, data.volume);

    let signal: RotationSignal['signal'] = 'NEUTRAL';
    if (data.netEth > 0 && intensity >= 0.3) signal = data.netEth > 1000 ? 'STRONG_ROTATE_IN' : 'ROTATE_IN';
    else if (data.netEth < 0 && intensity >= 0.3) signal = data.netEth < -1000 ? 'STRONG_ROTATE_OUT' : 'ROTATE_OUT';

    const confidence = Math.min(100, Math.round(intensity * 60 + Math.min(30, Math.log10(Math.max(1, data.volume)) * 8) + Math.min(10, data.bridges * 3)));

    const reasoning: string[] = [
      `Net ETH flow: ${data.netEth >= 0 ? '+' : ''}${data.netEth.toFixed(1)} ETH (mainnet → ${chain})`,
      `Total bridge volume: ${data.volume.toFixed(1)} ETH across ${data.bridges} bridge${data.bridges > 1 ? 's' : ''}`,
      `Bridges observed: ${data.bridgeNames.join(', ')}`,
    ];
    if (signal.includes('ROTATE_IN')) reasoning.push(`Bullish ${chain}: capital is rotating IN — accumulate native and ${chain}-ecosystem assets.`);
    if (signal.includes('ROTATE_OUT')) reasoning.push(`Bearish ${chain}: capital is rotating OUT — reduce ${chain}-ecosystem exposure.`);

    rotationSignals.push({
      destinationChain: chain,
      signal,
      confidence,
      netEthFlow: Math.round(data.netEth * 100) / 100,
      totalEthVolume: Math.round(data.volume * 100) / 100,
      bridgesObserved: data.bridges,
      reasoning,
    });
  }

  rotationSignals.sort((a, b) => Math.abs(b.netEthFlow) - Math.abs(a.netEthFlow));

  const totalBridgeVolumeEth = flows.reduce((s, f) => s + f.ethInflow + f.ethOutflow, 0);

  return {
    _proprietaryHeader: proprietaryHeader('Alpha Bridge Capital-Rotation Signal™'),
    generatedAt: new Date().toISOString(),
    windowHours,
    bridgesScanned: BRIDGE_CONTRACTS.length,
    totalBridgeVolumeEth: Math.round(totalBridgeVolumeEth * 100) / 100,
    bridgeFlows: flows,
    rotationSignals,
  };
}

let cache: { ts: number; report: BridgeRotationReport | null } = { ts: 0, report: null };
let inflight: Promise<BridgeRotationReport> | null = null;
const CACHE_TTL_MS = 5 * 60 * 1000;

export async function getCachedBridgeRotationReport(windowHours = 24): Promise<BridgeRotationReport> {
  if (cache.report && Date.now() - cache.ts < CACHE_TTL_MS) return cache.report;
  // Stampede guard: serve same in-flight promise to all concurrent callers during cache miss.
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const report = await generateBridgeRotationSignals(windowHours);
      cache = { ts: Date.now(), report };
      return report;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}
