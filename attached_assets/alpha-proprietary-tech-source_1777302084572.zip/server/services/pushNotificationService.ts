/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Real-Time Alert Delivery System™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary real-time push notification and alert delivery technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Real-Time Alert Delivery System™
 * - Web Push Notification Engine™
 * - Priority Alert Routing™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_113148197b3ef3d992e4c25f
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import webpush from 'web-push';
import { db } from '../db';
import { pushSubscriptions, notificationPreferences } from '@shared/schema';
import { eq } from 'drizzle-orm';


export const _pnsSeal = 'AUT_113148197b3ef3d992e4c25f';
const _pnsIntegrityValid = registerBeacon('pushNotificationService', _pnsSeal);
if (!_pnsSeal?.startsWith('AUT_') || !_pnsIntegrityValid) {
  throw new Error('[SECURITY] Alpha Real-Time Alert Delivery System™ integrity verification failed — module sealed');
}

const vapidPublicKey = process.env.VAPID_PUBLIC_KEY;
const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;

if (vapidPublicKey && vapidPrivateKey) {
  webpush.setVapidDetails(
    'mailto:support@alphaunlimitedtrading.com',
    vapidPublicKey,
    vapidPrivateKey
  );
}

export type NotificationType = 'trading_signal' | 'price_alert' | 'portfolio_change' | 'security_alert' | 'news';

interface NotificationPayload {
  title: string;
  body: string;
  tag?: string;
  data?: Record<string, any>;
  actions?: { action: string; title: string }[];
  requireInteraction?: boolean;
}

export async function saveSubscription(userId: string, subscription: { endpoint: string; keys: { p256dh: string; auth: string } }) {
  const existing = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.endpoint, subscription.endpoint));
  
  if (existing.length > 0) {
    await db.update(pushSubscriptions)
      .set({ userId, p256dh: subscription.keys.p256dh, auth: subscription.keys.auth })
      .where(eq(pushSubscriptions.endpoint, subscription.endpoint));
    return existing[0];
  }
  
  const [sub] = await db.insert(pushSubscriptions).values({
    userId,
    endpoint: subscription.endpoint,
    p256dh: subscription.keys.p256dh,
    auth: subscription.keys.auth,
  }).returning();
  
  return sub;
}

export async function removeSubscription(endpoint: string) {
  await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
}

export async function getUserPreferences(userId: string) {
  const [prefs] = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, userId));
  
  if (!prefs) {
    const [newPrefs] = await db.insert(notificationPreferences).values({
      userId,
      tradingSignals: true,
      priceAlerts: true,
      portfolioChanges: true,
      securityAlerts: true,
      newsUpdates: false,
    }).returning();
    return newPrefs;
  }
  
  return prefs;
}

export async function updateUserPreferences(userId: string, preferences: Partial<{
  tradingSignals: boolean;
  priceAlerts: boolean;
  portfolioChanges: boolean;
  securityAlerts: boolean;
  newsUpdates: boolean;
}>) {
  const existing = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, userId));
  
  if (existing.length === 0) {
    const [prefs] = await db.insert(notificationPreferences).values({
      userId,
      ...preferences,
    }).returning();
    return prefs;
  }
  
  const [updated] = await db.update(notificationPreferences)
    .set(preferences)
    .where(eq(notificationPreferences.userId, userId))
    .returning();
  
  return updated;
}

async function shouldSendNotification(userId: string, type: NotificationType): Promise<boolean> {
  const prefs = await getUserPreferences(userId);
  
  switch (type) {
    case 'trading_signal':
      return prefs.tradingSignals;
    case 'price_alert':
      return prefs.priceAlerts;
    case 'portfolio_change':
      return prefs.portfolioChanges;
    case 'security_alert':
      return prefs.securityAlerts;
    case 'news':
      return prefs.newsUpdates;
    default:
      return true;
  }
}

export async function sendNotificationToUser(userId: string, type: NotificationType, payload: NotificationPayload) {
  if (!vapidPublicKey || !vapidPrivateKey) {
    console.warn('VAPID keys not configured, skipping push notification');
    return { sent: 0, failed: 0 };
  }
  
  const shouldSend = await shouldSendNotification(userId, type);
  if (!shouldSend) {
    return { sent: 0, failed: 0, skipped: 'disabled by user preferences' };
  }
  
  const subscriptions = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
  
  let sent = 0;
  let failed = 0;
  
  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth,
          },
        },
        JSON.stringify(payload)
      );
      sent++;
    } catch (error: any) {
      failed++;
      if (error.statusCode === 410 || error.statusCode === 404) {
        await removeSubscription(sub.endpoint);
      }
      console.error('Push notification failed:', error.message);
    }
  }
  
  return { sent, failed };
}

export async function sendTradingSignalNotification(userId: string, signal: {
  symbol: string;
  type: 'BUY' | 'SELL';
  strength: number;
  price: number;
  indicator: string;
}) {
  const emoji = signal.type === 'BUY' ? '🟢' : '🔴';
  const strengthText = signal.strength >= 0.8 ? 'STRONG' : signal.strength >= 0.6 ? 'MODERATE' : 'WEAK';
  
  return sendNotificationToUser(userId, 'trading_signal', {
    title: `${emoji} ${signal.type} Signal: ${signal.symbol.replace('USDT', '')}`,
    body: `${strengthText} ${signal.indicator} signal at $${signal.price.toLocaleString()}`,
    tag: `signal-${signal.symbol}-${Date.now()}`,
    data: { symbol: signal.symbol, url: `/trading?symbol=${signal.symbol}` },
    actions: [
      { action: 'view', title: 'View Chart' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
    requireInteraction: signal.strength >= 0.8,
  });
}

export async function sendPriceAlertNotification(userId: string, alert: {
  symbol: string;
  targetPrice: number;
  currentPrice: number;
  direction: 'above' | 'below';
}) {
  const emoji = alert.direction === 'above' ? '📈' : '📉';
  
  return sendNotificationToUser(userId, 'price_alert', {
    title: `${emoji} Price Alert: ${alert.symbol.replace('USDT', '')}`,
    body: `Price is now ${alert.direction} $${alert.targetPrice.toLocaleString()} (currently $${alert.currentPrice.toLocaleString()})`,
    tag: `price-alert-${alert.symbol}`,
    data: { symbol: alert.symbol, url: `/trading?symbol=${alert.symbol}` },
    requireInteraction: true,
  });
}

export async function sendPortfolioChangeNotification(userId: string, change: {
  type: 'profit' | 'loss' | 'trade_executed';
  symbol?: string;
  amount?: number;
  percentChange?: number;
}) {
  let title: string;
  let body: string;
  
  if (change.type === 'trade_executed') {
    title = '✅ Trade Executed';
    body = `Your ${change.symbol} trade has been executed`;
  } else {
    const emoji = change.type === 'profit' ? '💰' : '⚠️';
    title = `${emoji} Portfolio ${change.type === 'profit' ? 'Gain' : 'Loss'}`;
    body = `${change.symbol || 'Portfolio'}: ${change.percentChange! >= 0 ? '+' : ''}${change.percentChange?.toFixed(2)}%`;
  }
  
  return sendNotificationToUser(userId, 'portfolio_change', {
    title,
    body,
    tag: 'portfolio-update',
    data: { url: '/trading' },
  });
}

export async function sendSecurityAlertNotification(userId: string, alert: {
  type: 'login' | 'new_device' | 'api_key_added' | 'suspicious_activity';
  details: string;
}) {
  return sendNotificationToUser(userId, 'security_alert', {
    title: '🔐 Security Alert',
    body: alert.details,
    tag: 'security-alert',
    data: { url: '/security' },
    requireInteraction: true,
  });
}
