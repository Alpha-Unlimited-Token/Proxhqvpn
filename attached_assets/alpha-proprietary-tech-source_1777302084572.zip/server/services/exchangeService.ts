/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Exchange Service™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary cryptocurrency exchange order management and liquidity engine.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Exchange Service™
 * - Order Matching Engine™
 * - Liquidity Management System™
 * - AUC Blockchain Integration™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_47d4b9db6fe0ede531ef4768
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

import { registerBeacon } from "./integrityBeacon.js";
import { db } from "../db";
import { eq, and, desc, asc, sql, lte, gte } from "drizzle-orm";
import {
  exchangeAccounts, exchangeOrders, exchangeTrades,
  exchangeDeposits, exchangeWithdrawals, exchangeStats,
  aucPurchases, AUC_DISCOUNT_PERCENT,
  exchangeReferralCodes, exchangeReferrals, exchangeReferralEarnings,
} from "@shared/schema";

export const _exsSeal = 'AUT_47d4b9db6fe0ede531ef4768';
const _exsIntegrityValid = registerBeacon('exchangeService', _exsSeal);
if (!_exsSeal?.startsWith('AUT_') || !_exsIntegrityValid) {
  throw new Error('[SECURITY] Alpha Exchange Service™ integrity verification failed — module sealed');
}

const TRADING_FEE_RATE = 0.0025; // 0.25%
const WITHDRAWAL_FEE_AUC = 0.5;
const WITHDRAWAL_FEE_USD = 2.00;
const MIN_ORDER_AMOUNT = 0.001;
const INITIAL_AUC_PRICE = 0.00000001;

export class ExchangeService {
  async getOrCreateAccount(userId: string) {
    const existing = await db.select().from(exchangeAccounts).where(eq(exchangeAccounts.userId, userId)).limit(1);
    if (existing.length > 0) return existing[0];

    const [account] = await db.insert(exchangeAccounts).values({
      userId,
      aucBalance: 0,
      usdBalance: 0,
      aucLocked: 0,
      usdLocked: 0,
      totalFeesGenerated: 0,
    }).returning();
    return account;
  }

  async getAccount(userId: string) {
    const accounts = await db.select().from(exchangeAccounts).where(eq(exchangeAccounts.userId, userId)).limit(1);
    return accounts[0] || null;
  }

  async depositUSD(userId: string, amount: number, paymentId?: string) {
    try {
      return await db.transaction(async (tx) => {
        if (paymentId) {
          const existing = await tx.select().from(exchangeDeposits)
            .where(and(eq(exchangeDeposits.paymentId, paymentId), eq(exchangeDeposits.status, "completed")))
            .limit(1);
          if (existing.length > 0) {
            console.log(`[Exchange] Duplicate deposit detected for paymentId ${paymentId}, skipping`);
            return existing[0];
          }
        }

        const existingAccount = await tx.select().from(exchangeAccounts)
          .where(eq(exchangeAccounts.userId, userId)).limit(1).for("update");

        if (existingAccount.length === 0) {
          await tx.insert(exchangeAccounts).values({
            userId, aucBalance: 0, usdBalance: amount, aucLocked: 0, usdLocked: 0, totalFeesGenerated: 0,
          });
        } else {
          await tx.update(exchangeAccounts)
            .set({ usdBalance: sql`${exchangeAccounts.usdBalance} + ${amount}` })
            .where(eq(exchangeAccounts.userId, userId));
        }

        const [deposit] = await tx.insert(exchangeDeposits).values({
          userId, type: "usd", amount, fee: 0, status: "completed", paymentId: paymentId || null,
        }).returning();
        return deposit;
      });
    } catch (err: any) {
      if (err?.code === '23505' && paymentId) {
        console.log(`[Exchange] Unique constraint caught duplicate paymentId ${paymentId}`);
        const existing = await db.select().from(exchangeDeposits)
          .where(eq(exchangeDeposits.paymentId, paymentId)).limit(1);
        return existing[0];
      }
      throw err;
    }
  }

  async depositAUC(userId: string, amount: number, txHash?: string) {
    try {
      return await db.transaction(async (tx) => {
        if (txHash) {
          const existing = await tx.select().from(exchangeDeposits)
            .where(and(eq(exchangeDeposits.txHash, txHash), eq(exchangeDeposits.status, "completed")))
            .limit(1);
          if (existing.length > 0) {
            console.log(`[Exchange] Duplicate AUC deposit detected for txHash ${txHash}, skipping`);
            return existing[0];
          }
        }

        const existingAccount = await tx.select().from(exchangeAccounts)
          .where(eq(exchangeAccounts.userId, userId)).limit(1).for("update");

        if (existingAccount.length === 0) {
          await tx.insert(exchangeAccounts).values({
            userId, aucBalance: amount, usdBalance: 0, aucLocked: 0, usdLocked: 0, totalFeesGenerated: 0,
          });
        } else {
          await tx.update(exchangeAccounts)
            .set({ aucBalance: sql`${exchangeAccounts.aucBalance} + ${amount}` })
            .where(eq(exchangeAccounts.userId, userId));
        }

        const [deposit] = await tx.insert(exchangeDeposits).values({
          userId, type: "auc", amount, fee: 0, status: "completed", txHash: txHash || null,
        }).returning();
        return deposit;
      });
    } catch (err: any) {
      if (err?.code === '23505' && txHash) {
        console.log(`[Exchange] Unique constraint caught duplicate txHash ${txHash}`);
        const existing = await db.select().from(exchangeDeposits)
          .where(eq(exchangeDeposits.txHash, txHash)).limit(1);
        return existing[0];
      }
      throw err;
    }
  }

  async withdrawAUC(userId: string, amount: number, destination: string) {
    const totalCost = amount + WITHDRAWAL_FEE_AUC;

    return await db.transaction(async (tx) => {
      const [account] = await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, userId)).limit(1).for("update");
      if (!account) return { error: "Account not found" };

      const available = (account.aucBalance || 0) - (account.aucLocked || 0);
      if (available < totalCost) {
        return { error: `Insufficient AUC balance. Available: ${available.toFixed(4)}, Required: ${totalCost.toFixed(4)} (includes ${WITHDRAWAL_FEE_AUC} AUC withdrawal fee)` };
      }

      await tx.update(exchangeAccounts)
        .set({
          aucBalance: sql`${exchangeAccounts.aucBalance} - ${totalCost}`,
          totalFeesGenerated: sql`${exchangeAccounts.totalFeesGenerated} + ${WITHDRAWAL_FEE_AUC}`,
        })
        .where(eq(exchangeAccounts.userId, userId));

      const [withdrawal] = await tx.insert(exchangeWithdrawals).values({
        userId, type: "auc", amount, fee: WITHDRAWAL_FEE_AUC, status: "completed", destination,
      }).returning();
      return { withdrawal, fee: WITHDRAWAL_FEE_AUC };
    });
  }

  async withdrawUSD(userId: string, amount: number, destination: string) {
    const totalCost = amount + WITHDRAWAL_FEE_USD;

    return await db.transaction(async (tx) => {
      const [account] = await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, userId)).limit(1).for("update");
      if (!account) return { error: "Account not found" };

      const available = (account.usdBalance || 0) - (account.usdLocked || 0);
      if (available < totalCost) {
        return { error: `Insufficient USD balance. Available: $${available.toFixed(2)}, Required: $${totalCost.toFixed(2)} (includes $${WITHDRAWAL_FEE_USD} withdrawal fee)` };
      }

      await tx.update(exchangeAccounts)
        .set({
          usdBalance: sql`${exchangeAccounts.usdBalance} - ${totalCost}`,
          totalFeesGenerated: sql`${exchangeAccounts.totalFeesGenerated} + ${WITHDRAWAL_FEE_USD}`,
        })
        .where(eq(exchangeAccounts.userId, userId));

      const [withdrawal] = await tx.insert(exchangeWithdrawals).values({
        userId, type: "usd", amount, fee: WITHDRAWAL_FEE_USD, status: "completed", destination,
      }).returning();
      return { withdrawal, fee: WITHDRAWAL_FEE_USD };
    });
  }

  async placeOrder(userId: string, side: "buy" | "sell", orderType: "limit" | "market", amount: number, price?: number) {
    if (amount < MIN_ORDER_AMOUNT) {
      return { error: `Minimum order amount is ${MIN_ORDER_AMOUNT} AUC` };
    }

    if (orderType === "limit" && (!price || price <= 0)) {
      return { error: "Limit orders require a valid price" };
    }

    return await db.transaction(async (tx) => {
      const [account] = await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, userId)).limit(1).for("update");
      if (!account) {
        const [newAccount] = await tx.insert(exchangeAccounts).values({
          userId, aucBalance: 0, usdBalance: 0, aucLocked: 0, usdLocked: 0, totalFeesGenerated: 0,
        }).returning();
        if (!newAccount) throw new Error("Failed to create account");
      }
      const acct = account || (await tx.select().from(exchangeAccounts).where(eq(exchangeAccounts.userId, userId)).limit(1))[0];

      if (side === "sell") {
        const available = (acct.aucBalance || 0) - (acct.aucLocked || 0);
        if (available < amount) {
          return { error: `Insufficient AUC. Available: ${available.toFixed(4)} AUC` };
        }
        await tx.update(exchangeAccounts)
          .set({ aucLocked: sql`${exchangeAccounts.aucLocked} + ${amount}` })
          .where(eq(exchangeAccounts.userId, userId));
      } else {
        const orderPrice = orderType === "market" ? await this.getMarketPrice() : price!;
        const usdNeeded = amount * orderPrice;
        const usdFeeReserve = usdNeeded * TRADING_FEE_RATE;
        const totalUsdLock = usdNeeded + usdFeeReserve;
        const available = (acct.usdBalance || 0) - (acct.usdLocked || 0);
        if (available < totalUsdLock) {
          return { error: `Insufficient USD. Available: $${available.toFixed(2)}, Required: $${totalUsdLock.toFixed(2)} (includes 0.25% fee)` };
        }
        await tx.update(exchangeAccounts)
          .set({ usdLocked: sql`${exchangeAccounts.usdLocked} + ${totalUsdLock}` })
          .where(eq(exchangeAccounts.userId, userId));
      }

      const [order] = await tx.insert(exchangeOrders).values({
        userId,
        side,
        orderType,
        price: orderType === "market" ? null : price!,
        amount,
        filled: 0,
        remaining: amount,
        status: "open",
        fee: 0,
      }).returning();

      const matches = await this.matchOrderInTx(tx, order);
      const updatedOrder = await tx.select().from(exchangeOrders).where(eq(exchangeOrders.id, order.id)).limit(1);

      return { order: updatedOrder[0] || order, trades: matches };
    });
  }

  async matchOrder(order: typeof exchangeOrders.$inferSelect) {
    return await db.transaction(async (tx) => {
      return this.matchOrderInTx(tx, order);
    });
  }

  private async matchOrderInTx(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], order: typeof exchangeOrders.$inferSelect) {
    const trades: any[] = [];
    let remainingAmount = order.remaining;

    const oppositeOrders = await tx.select().from(exchangeOrders).where(
      and(
        eq(exchangeOrders.side, order.side === "buy" ? "sell" : "buy"),
        sql`${exchangeOrders.status} IN ('open', 'partial')`,
        sql`${exchangeOrders.userId} != ${order.userId}`,
        order.orderType === "limit" && order.price
          ? order.side === "buy"
            ? lte(exchangeOrders.price, order.price)
            : gte(exchangeOrders.price, order.price!)
          : undefined
      )
    ).orderBy(
      order.side === "buy" ? asc(exchangeOrders.price) : desc(exchangeOrders.price),
      asc(exchangeOrders.createdAt)
    ).limit(50).for("update");

    const participantUserIds = new Set<string>([order.userId]);
    for (const m of oppositeOrders) {
      if (m.remaining > 0) participantUserIds.add(m.userId);
    }
    const sortedUserIds = [...participantUserIds].sort();
    for (const uid of sortedUserIds) {
      await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, uid)).limit(1).for("update");
    }

    for (const match of oppositeOrders) {
      if (remainingAmount <= 0) break;
      if (!match.price && order.orderType === "market") continue;

      const tradePrice = match.price || order.price || await this.getMarketPrice();

      const buyerId = order.side === "buy" ? order.userId : match.userId;
      const sellerId = order.side === "sell" ? order.userId : match.userId;

      let tradeAmount = Math.min(remainingAmount, match.remaining);

      if (order.side === "buy" && order.orderType === "market") {
        const [buyerAcct] = await tx.select().from(exchangeAccounts)
          .where(eq(exchangeAccounts.userId, buyerId)).limit(1);
        if (buyerAcct) {
          const availableUsd = buyerAcct.usdBalance || 0;
          const maxAffordableAmount = Math.floor((availableUsd / (tradePrice * (1 + TRADING_FEE_RATE))) * 1000) / 1000;
          tradeAmount = Math.min(tradeAmount, maxAffordableAmount);
          if (tradeAmount < MIN_ORDER_AMOUNT) break;
        }
      }

      const tradeValue = tradeAmount * tradePrice;
      const buyerFee = tradeValue * TRADING_FEE_RATE;
      const sellerFee = tradeValue * TRADING_FEE_RATE;

      const buyOrderId = order.side === "buy" ? order.id : match.id;
      const sellOrderId = order.side === "sell" ? order.id : match.id;

      const [trade] = await tx.insert(exchangeTrades).values({
        buyOrderId, sellOrderId, buyerId, sellerId,
        price: tradePrice, amount: tradeAmount,
        buyerFee, sellerFee, totalValue: tradeValue,
      }).returning();

      const buyerUnlockAmount = (order.side === "buy" && order.orderType === "limit" && order.price)
        ? tradeAmount * order.price * (1 + TRADING_FEE_RATE)
        : (order.side === "sell" && match.price)
          ? tradeAmount * match.price * (1 + TRADING_FEE_RATE)
          : tradeValue + buyerFee;

      await tx.update(exchangeAccounts)
        .set({
          aucBalance: sql`${exchangeAccounts.aucBalance} + ${tradeAmount}`,
          usdBalance: sql`${exchangeAccounts.usdBalance} - ${tradeValue} - ${buyerFee}`,
          usdLocked: sql`GREATEST(0, ${exchangeAccounts.usdLocked} - ${buyerUnlockAmount})`,
          totalFeesGenerated: sql`${exchangeAccounts.totalFeesGenerated} + ${buyerFee}`,
        })
        .where(eq(exchangeAccounts.userId, buyerId));

      await tx.update(exchangeAccounts)
        .set({
          usdBalance: sql`${exchangeAccounts.usdBalance} + ${tradeValue} - ${sellerFee}`,
          aucBalance: sql`${exchangeAccounts.aucBalance} - ${tradeAmount}`,
          aucLocked: sql`GREATEST(0, ${exchangeAccounts.aucLocked} - ${tradeAmount})`,
          totalFeesGenerated: sql`${exchangeAccounts.totalFeesGenerated} + ${sellerFee}`,
        })
        .where(eq(exchangeAccounts.userId, sellerId));

      try {
        await this.processReferralEarningInTx(tx, buyerId, trade.id, buyerFee);
        await this.processReferralEarningInTx(tx, sellerId, trade.id, sellerFee);
      } catch (e) {}

      const matchNewRemaining = match.remaining - tradeAmount;
      await tx.update(exchangeOrders)
        .set({
          filled: sql`${exchangeOrders.filled} + ${tradeAmount}`,
          remaining: matchNewRemaining,
          fee: sql`${exchangeOrders.fee} + ${order.side === "buy" ? sellerFee : buyerFee}`,
          status: matchNewRemaining <= 0.0001 ? "filled" : "partial",
          updatedAt: new Date(),
        })
        .where(eq(exchangeOrders.id, match.id));

      remainingAmount -= tradeAmount;
      trades.push(trade);
    }

    const orderNewRemaining = remainingAmount;
    let orderStatus: string;
    if (orderNewRemaining <= 0.0001) {
      orderStatus = "filled";
    } else if (order.orderType === "market") {
      orderStatus = trades.length > 0 ? "filled" : "cancelled";
      if (orderNewRemaining > 0.0001) {
        if (order.side === "sell") {
          await tx.update(exchangeAccounts)
            .set({ aucLocked: sql`GREATEST(0, ${exchangeAccounts.aucLocked} - ${orderNewRemaining})` })
            .where(eq(exchangeAccounts.userId, order.userId));
        } else {
          const refundUsd = orderNewRemaining * (order.price || await this.getMarketPrice());
          const refundFee = refundUsd * TRADING_FEE_RATE;
          await tx.update(exchangeAccounts)
            .set({ usdLocked: sql`GREATEST(0, ${exchangeAccounts.usdLocked} - ${refundUsd} - ${refundFee})` })
            .where(eq(exchangeAccounts.userId, order.userId));
        }
      }
    } else {
      orderStatus = trades.length > 0 ? "partial" : "open";
    }

    const newFees = trades.reduce((sum, t) => sum + (order.side === "buy" ? t.buyerFee : t.sellerFee), 0);
    await tx.update(exchangeOrders)
      .set({
        filled: order.amount - orderNewRemaining,
        remaining: order.orderType === "market" ? 0 : orderNewRemaining,
        fee: sql`${exchangeOrders.fee} + ${newFees}`,
        status: orderStatus,
        updatedAt: new Date(),
      })
      .where(eq(exchangeOrders.id, order.id));

    if (trades.length > 0) {
      await this.updateDailyStats(trades);
    }

    return trades;
  }

  async cancelOrder(userId: string, orderId: number) {
    return await db.transaction(async (tx) => {
      const orders = await tx.select().from(exchangeOrders)
        .where(and(eq(exchangeOrders.id, orderId), eq(exchangeOrders.userId, userId)))
        .limit(1).for("update");

      if (orders.length === 0) return { error: "Order not found" };
      const order = orders[0];
      if (order.status === "filled" || order.status === "cancelled") {
        return { error: `Order already ${order.status}` };
      }

      if (order.side === "sell") {
        await tx.update(exchangeAccounts)
          .set({ aucLocked: sql`GREATEST(0, ${exchangeAccounts.aucLocked} - ${order.remaining})` })
          .where(eq(exchangeAccounts.userId, userId));
      } else {
        const lockedUsd = order.remaining * (order.price || await this.getMarketPrice());
        const lockedFee = lockedUsd * TRADING_FEE_RATE;
        await tx.update(exchangeAccounts)
          .set({ usdLocked: sql`GREATEST(0, ${exchangeAccounts.usdLocked} - ${lockedUsd} - ${lockedFee})` })
          .where(eq(exchangeAccounts.userId, userId));
      }

      await tx.update(exchangeOrders)
        .set({ status: "cancelled", updatedAt: new Date() })
        .where(eq(exchangeOrders.id, orderId));

      return { success: true, message: "Order cancelled" };
    });
  }

  async getOrderBook(limit: number = 20) {
    const bids = await db.select().from(exchangeOrders)
      .where(and(eq(exchangeOrders.side, "buy"), sql`${exchangeOrders.status} IN ('open', 'partial')`, eq(exchangeOrders.orderType, "limit")))
      .orderBy(desc(exchangeOrders.price))
      .limit(limit);

    const asks = await db.select().from(exchangeOrders)
      .where(and(eq(exchangeOrders.side, "sell"), sql`${exchangeOrders.status} IN ('open', 'partial')`, eq(exchangeOrders.orderType, "limit")))
      .orderBy(asc(exchangeOrders.price))
      .limit(limit);

    const bidLevels = this.aggregateLevels(bids);
    const askLevels = this.aggregateLevels(asks);

    return { bids: bidLevels, asks: askLevels, spread: askLevels[0] && bidLevels[0] ? askLevels[0].price - bidLevels[0].price : 0 };
  }

  private aggregateLevels(orders: any[]) {
    const levels = new Map<string, { price: number; amount: number; total: number; orders: number }>();
    for (const o of orders) {
      if (!o.price) continue;
      const price = typeof o.price === 'number' ? o.price : parseFloat(o.price);
      if (isNaN(price) || price <= 0) continue;
      const key = price.toPrecision(6);
      const existing = levels.get(key) || { price, amount: 0, total: 0, orders: 0 };
      existing.amount += o.remaining;
      existing.total += o.remaining * price;
      existing.orders++;
      levels.set(key, existing);
    }
    return Array.from(levels.values());
  }

  async getRecentTrades(limit: number = 50) {
    return db.select().from(exchangeTrades).orderBy(desc(exchangeTrades.createdAt)).limit(limit);
  }

  async getUserOrders(userId: string, status?: string) {
    const conditions = [eq(exchangeOrders.userId, userId)];
    if (status) conditions.push(eq(exchangeOrders.status, status));
    return db.select().from(exchangeOrders).where(and(...conditions)).orderBy(desc(exchangeOrders.createdAt)).limit(100);
  }

  async getUserTrades(userId: string, limit: number = 50) {
    return db.select().from(exchangeTrades)
      .where(sql`${exchangeTrades.buyerId} = ${userId} OR ${exchangeTrades.sellerId} = ${userId}`)
      .orderBy(desc(exchangeTrades.createdAt))
      .limit(limit);
  }

  async getMarketPrice(): Promise<number> {
    const recentTrades = await db.select().from(exchangeTrades).orderBy(desc(exchangeTrades.createdAt)).limit(1);
    if (recentTrades.length > 0) return recentTrades[0].price;

    const bestAsk = await db.select().from(exchangeOrders)
      .where(and(eq(exchangeOrders.side, "sell"), sql`${exchangeOrders.status} IN ('open', 'partial')`, eq(exchangeOrders.orderType, "limit")))
      .orderBy(asc(exchangeOrders.price)).limit(1);

    const bestBid = await db.select().from(exchangeOrders)
      .where(and(eq(exchangeOrders.side, "buy"), sql`${exchangeOrders.status} IN ('open', 'partial')`, eq(exchangeOrders.orderType, "limit")))
      .orderBy(desc(exchangeOrders.price)).limit(1);

    if (bestAsk.length > 0 && bestBid.length > 0) {
      return ((bestAsk[0].price || 0) + (bestBid[0].price || 0)) / 2;
    }
    if (bestAsk.length > 0) return bestAsk[0].price || INITIAL_AUC_PRICE;
    if (bestBid.length > 0) return bestBid[0].price || INITIAL_AUC_PRICE;

    return INITIAL_AUC_PRICE;
  }

  async getMarketStats() {
    const price = await this.getMarketPrice();

    const oneDayAgo = new Date(Date.now() - 86400000);
    const trades24h = await db.select().from(exchangeTrades)
      .where(gte(exchangeTrades.createdAt, oneDayAgo));

    const volume24h = trades24h.reduce((s, t) => s + t.totalValue, 0);
    const tradeCount24h = trades24h.length;
    const fees24h = trades24h.reduce((s, t) => s + t.buyerFee + t.sellerFee, 0);

    let high24h = price, low24h = price, priceChange24h = 0;
    if (trades24h.length > 0) {
      high24h = Math.max(...trades24h.map(t => t.price));
      low24h = Math.min(...trades24h.map(t => t.price));
      const firstPrice = trades24h[trades24h.length - 1].price;
      priceChange24h = firstPrice > 0 ? ((price - firstPrice) / firstPrice) * 100 : 0;
    }

    const allAccounts = await db.select({ total: sql<number>`SUM(${exchangeAccounts.totalFeesGenerated})` }).from(exchangeAccounts);
    const totalFeesAllTime = allAccounts[0]?.total || 0;

    const totalTrades = await db.select({ count: sql<number>`COUNT(*)` }).from(exchangeTrades);
    const totalUsers = await db.select({ count: sql<number>`COUNT(*)` }).from(exchangeAccounts);

    const orderBook = await this.getOrderBook(5);

    return {
      price,
      priceChange24h: parseFloat(priceChange24h.toFixed(2)),
      high24h,
      low24h,
      volume24h: parseFloat(volume24h.toFixed(2)),
      tradeCount24h,
      fees24h: parseFloat(fees24h.toFixed(4)),
      totalFeesAllTime: parseFloat(totalFeesAllTime.toFixed(4)),
      totalTrades: totalTrades[0]?.count || 0,
      totalUsers: totalUsers[0]?.count || 0,
      tradingFeeRate: TRADING_FEE_RATE * 100,
      withdrawalFeeAUC: WITHDRAWAL_FEE_AUC,
      withdrawalFeeUSD: WITHDRAWAL_FEE_USD,
      bestBid: orderBook.bids[0]?.price || 0,
      bestAsk: orderBook.asks[0]?.price || 0,
      spread: orderBook.spread,
      ticker: "AUC",
      pair: "AUC/USD",
    };
  }

  async getPriceHistory(period: string = "1d") {
    const now = Date.now();
    let since: number;
    switch (period) {
      case "1h": since = now - 3600000; break;
      case "4h": since = now - 14400000; break;
      case "1d": since = now - 86400000; break;
      case "1w": since = now - 604800000; break;
      case "1m": since = now - 2592000000; break;
      default: since = now - 86400000;
    }

    const trades = await db.select().from(exchangeTrades)
      .where(gte(exchangeTrades.createdAt, new Date(since)))
      .orderBy(asc(exchangeTrades.createdAt));

    if (trades.length === 0) {
      const price = await this.getMarketPrice();
      return [{ time: now, open: price, high: price, low: price, close: price, volume: 0 }];
    }

    const interval = period === "1h" ? 60000 : period === "4h" ? 300000 : 3600000;
    const candles: any[] = [];
    let currentStart = Math.floor(trades[0].createdAt.getTime() / interval) * interval;

    let bucket: typeof trades = [];
    for (const trade of trades) {
      const tradeTime = trade.createdAt.getTime();
      if (tradeTime >= currentStart + interval) {
        if (bucket.length > 0) {
          candles.push({
            time: currentStart,
            open: bucket[0].price,
            high: Math.max(...bucket.map(t => t.price)),
            low: Math.min(...bucket.map(t => t.price)),
            close: bucket[bucket.length - 1].price,
            volume: bucket.reduce((s, t) => s + t.totalValue, 0),
          });
        }
        currentStart += interval * Math.ceil((tradeTime - currentStart) / interval);
        bucket = [];
      }
      bucket.push(trade);
    }
    if (bucket.length > 0) {
      candles.push({
        time: currentStart,
        open: bucket[0].price,
        high: Math.max(...bucket.map(t => t.price)),
        low: Math.min(...bucket.map(t => t.price)),
        close: bucket[bucket.length - 1].price,
        volume: bucket.reduce((s, t) => s + t.totalValue, 0),
      });
    }

    return candles;
  }

  async getRevenueReport() {
    const allFees = await db.select({
      totalBuyerFees: sql<number>`COALESCE(SUM(${exchangeTrades.buyerFee}), 0)`,
      totalSellerFees: sql<number>`COALESCE(SUM(${exchangeTrades.sellerFee}), 0)`,
      tradeCount: sql<number>`COUNT(*)`,
    }).from(exchangeTrades);

    const withdrawalFees = await db.select({
      totalFees: sql<number>`COALESCE(SUM(${exchangeWithdrawals.fee}), 0)`,
      count: sql<number>`COUNT(*)`,
    }).from(exchangeWithdrawals).where(eq(exchangeWithdrawals.status, "completed"));

    const tradingFees = (allFees[0]?.totalBuyerFees || 0) + (allFees[0]?.totalSellerFees || 0);
    const totalWithdrawalFees = withdrawalFees[0]?.totalFees || 0;

    return {
      tradingFees: parseFloat(tradingFees.toFixed(4)),
      withdrawalFees: parseFloat(totalWithdrawalFees.toFixed(4)),
      totalRevenue: parseFloat((tradingFees + totalWithdrawalFees).toFixed(4)),
      totalTrades: allFees[0]?.tradeCount || 0,
      totalWithdrawals: withdrawalFees[0]?.count || 0,
      feeRate: `${TRADING_FEE_RATE * 100}%`,
    };
  }

  private async updateDailyStats(trades: any[]) {
    const today = new Date().toISOString().split("T")[0];
    try {
      const existing = await db.select().from(exchangeStats).where(eq(exchangeStats.date, today)).limit(1);
      const volume = trades.reduce((s, t) => s + t.totalValue, 0);
      const fees = trades.reduce((s, t) => s + t.buyerFee + t.sellerFee, 0);
      const prices = trades.map((t: any) => t.price);
      const high = Math.max(...prices);
      const low = Math.min(...prices);
      const close = prices[prices.length - 1];

      if (existing.length > 0) {
        await db.update(exchangeStats).set({
          volume24h: (existing[0].volume24h || 0) + volume,
          trades24h: (existing[0].trades24h || 0) + trades.length,
          highPrice: Math.max(existing[0].highPrice || 0, high),
          lowPrice: existing[0].lowPrice ? Math.min(existing[0].lowPrice, low) : low,
          closePrice: close,
          feesCollected: (existing[0].feesCollected || 0) + fees,
        }).where(eq(exchangeStats.date, today));
      } else {
        await db.insert(exchangeStats).values({
          date: today,
          volume24h: volume,
          trades24h: trades.length,
          highPrice: high,
          lowPrice: low,
          openPrice: prices[0],
          closePrice: close,
          feesCollected: fees,
        });
      }
    } catch {}
  }

  async processAucPurchase(userId: string, usdPriceCents: number, purchaseType: string, referenceId: string, metadata?: string) {
    if (usdPriceCents <= 0) throw new Error("Invalid price");
    const aucPrice = await this.getMarketPrice();
    const discountedCents = Math.round(usdPriceCents * (1 - AUC_DISCOUNT_PERCENT / 100));
    const aucAmount = parseFloat((discountedCents / 100 / aucPrice).toFixed(4));

    return await db.transaction(async (tx) => {
      const [account] = await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, userId)).limit(1);
      if (!account) throw new Error("No exchange account found. Please create one first.");

      const available = (account.aucBalance || 0) - (account.aucLocked || 0);
      if (available < aucAmount) {
        throw new Error(`Insufficient AUC balance. Required: ${aucAmount} AUC, Available: ${available.toFixed(4)} AUC`);
      }

      const updated = await tx.update(exchangeAccounts)
        .set({ aucBalance: sql`${exchangeAccounts.aucBalance} - ${aucAmount}` })
        .where(and(eq(exchangeAccounts.userId, userId), gte(sql`${exchangeAccounts.aucBalance} - COALESCE(${exchangeAccounts.aucLocked}, 0)`, aucAmount)))
        .returning();
      if (updated.length === 0) throw new Error("Insufficient AUC balance (concurrent transaction)");

      const [purchase] = await tx.insert(aucPurchases).values({
        userId,
        purchaseType,
        referenceId,
        usdPriceCents,
        discountPercent: AUC_DISCOUNT_PERCENT,
        discountedUsdCents: discountedCents,
        aucPricePerUnit: aucPrice,
        aucAmount,
        status: "completed",
        metadata: metadata || null,
      }).returning();

      return purchase;
    });
  }

  async getAucPurchases(userId: string) {
    return db.select().from(aucPurchases).where(eq(aucPurchases.userId, userId)).orderBy(desc(aucPurchases.createdAt));
  }

  async getAucQuote(usdPriceCents: number) {
    const aucPrice = await this.getMarketPrice();
    const discountedCents = Math.round(usdPriceCents * (1 - AUC_DISCOUNT_PERCENT / 100));
    const aucAmount = parseFloat((discountedCents / 100 / aucPrice).toFixed(4));
    return {
      usdPriceCents,
      discountPercent: AUC_DISCOUNT_PERCENT,
      discountedUsdCents: discountedCents,
      aucPricePerUnit: aucPrice,
      aucRequired: aucAmount,
      savings: usdPriceCents - discountedCents,
    };
  }

  async getKlines(interval: string, limit: number) {
    const intervalMs: Record<string, number> = {
      '1m': 60000, '3m': 180000, '5m': 300000, '15m': 900000, '30m': 1800000,
      '1h': 3600000, '2h': 7200000, '4h': 14400000, '6h': 21600000, '8h': 28800000,
      '12h': 43200000, '1d': 86400000, '3d': 259200000, '1w': 604800000, '1M': 2592000000,
    };
    const bucketSize = intervalMs[interval] || 900000;
    const lookback = bucketSize * Math.max(limit, 100);
    const since = new Date(Date.now() - lookback);

    const trades = await db.select().from(exchangeTrades)
      .where(gte(exchangeTrades.createdAt, since))
      .orderBy(asc(exchangeTrades.createdAt));

    const currentPrice = await this.getMarketPrice();

    if (trades.length === 0) {
      const now = Date.now();
      const candles = [];
      for (let i = limit - 1; i >= 0; i--) {
        const time = Math.floor((now - i * bucketSize) / 1000);
        candles.push({ time, open: currentPrice, high: currentPrice, low: currentPrice, close: currentPrice, volume: 0 });
      }
      return candles;
    }

    const candles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }> = [];
    const firstTradeTime = trades[0].createdAt.getTime();
    let bucketStart = Math.floor(firstTradeTime / bucketSize) * bucketSize;
    const now = Date.now();
    let tradeIdx = 0;
    let lastClose = trades[0].price;

    while (bucketStart <= now) {
      const bucketEnd = bucketStart + bucketSize;
      const bucketTrades: typeof trades = [];
      while (tradeIdx < trades.length && trades[tradeIdx].createdAt.getTime() < bucketEnd) {
        if (trades[tradeIdx].createdAt.getTime() >= bucketStart) {
          bucketTrades.push(trades[tradeIdx]);
        }
        tradeIdx++;
      }

      if (bucketTrades.length > 0) {
        const open = bucketTrades[0].price;
        const close = bucketTrades[bucketTrades.length - 1].price;
        const high = Math.max(...bucketTrades.map(t => t.price));
        const low = Math.min(...bucketTrades.map(t => t.price));
        const volume = bucketTrades.reduce((s, t) => s + t.amount, 0);
        candles.push({ time: Math.floor(bucketStart / 1000), open, high, low, close, volume });
        lastClose = close;
      } else {
        candles.push({ time: Math.floor(bucketStart / 1000), open: lastClose, high: lastClose, low: lastClose, close: lastClose, volume: 0 });
      }
      bucketStart += bucketSize;
    }

    return candles.slice(-limit);
  }

  getFeeRate(volume30d: number): { maker: number; taker: number; tier: string } {
    if (volume30d >= 1000000) return { maker: 0.0005, taker: 0.001, tier: 'VIP 5' };
    if (volume30d >= 500000) return { maker: 0.0008, taker: 0.0012, tier: 'VIP 4' };
    if (volume30d >= 100000) return { maker: 0.001, taker: 0.0015, tier: 'VIP 3' };
    if (volume30d >= 50000) return { maker: 0.0012, taker: 0.0018, tier: 'VIP 2' };
    if (volume30d >= 10000) return { maker: 0.0015, taker: 0.002, tier: 'VIP 1' };
    return { maker: 0.002, taker: 0.0025, tier: 'Standard' };
  }

  async getUserVolume30d(userId: string): Promise<number> {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000);
    const result = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeTrades.totalValue}), 0)`
    }).from(exchangeTrades)
      .where(and(
        sql`(${exchangeTrades.buyerId} = ${userId} OR ${exchangeTrades.sellerId} = ${userId})`,
        gte(exchangeTrades.createdAt, thirtyDaysAgo)
      ));
    return result[0]?.total || 0;
  }

  async getProofOfReserves() {
    const totalAucBalances = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeAccounts.aucBalance}), 0)`
    }).from(exchangeAccounts);

    const totalUsdBalances = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeAccounts.usdBalance}), 0)`
    }).from(exchangeAccounts);

    const totalAucLocked = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeAccounts.aucLocked}), 0)`
    }).from(exchangeAccounts);

    const totalUsdLocked = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeAccounts.usdLocked}), 0)`
    }).from(exchangeAccounts);

    const totalAccounts = await db.select({
      count: sql<number>`COUNT(*)`
    }).from(exchangeAccounts);

    const totalDepositsAuc = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeDeposits.amount}), 0)`
    }).from(exchangeDeposits).where(and(eq(exchangeDeposits.type, 'auc'), eq(exchangeDeposits.status, 'completed')));

    const totalDepositsUsd = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeDeposits.amount}), 0)`
    }).from(exchangeDeposits).where(and(eq(exchangeDeposits.type, 'usd'), eq(exchangeDeposits.status, 'completed')));

    const totalWithdrawalsAuc = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeWithdrawals.amount}), 0)`
    }).from(exchangeWithdrawals).where(and(eq(exchangeWithdrawals.type, 'auc'), eq(exchangeWithdrawals.status, 'completed')));

    const totalWithdrawalsUsd = await db.select({
      total: sql<number>`COALESCE(SUM(${exchangeWithdrawals.amount}), 0)`
    }).from(exchangeWithdrawals).where(and(eq(exchangeWithdrawals.type, 'usd'), eq(exchangeWithdrawals.status, 'completed')));

    const aucReserve = (totalDepositsAuc[0]?.total || 0) - (totalWithdrawalsAuc[0]?.total || 0);
    const usdReserve = (totalDepositsUsd[0]?.total || 0) - (totalWithdrawalsUsd[0]?.total || 0);
    const aucLiability = totalAucBalances[0]?.total || 0;
    const usdLiability = totalUsdBalances[0]?.total || 0;

    return {
      timestamp: new Date().toISOString(),
      accounts: totalAccounts[0]?.count || 0,
      auc: {
        totalDeposits: parseFloat((totalDepositsAuc[0]?.total || 0).toFixed(4)),
        totalWithdrawals: parseFloat((totalWithdrawalsAuc[0]?.total || 0).toFixed(4)),
        reserve: parseFloat(aucReserve.toFixed(4)),
        liability: parseFloat(aucLiability.toFixed(4)),
        locked: parseFloat((totalAucLocked[0]?.total || 0).toFixed(4)),
        ratio: aucLiability > 0 ? parseFloat((aucReserve / aucLiability).toFixed(4)) : 1,
      },
      usd: {
        totalDeposits: parseFloat((totalDepositsUsd[0]?.total || 0).toFixed(2)),
        totalWithdrawals: parseFloat((totalWithdrawalsUsd[0]?.total || 0).toFixed(2)),
        reserve: parseFloat(usdReserve.toFixed(2)),
        liability: parseFloat(usdLiability.toFixed(2)),
        locked: parseFloat((totalUsdLocked[0]?.total || 0).toFixed(2)),
        ratio: usdLiability > 0 ? parseFloat((usdReserve / usdLiability).toFixed(4)) : 1,
      },
      verified: true,
    };
  }

  async getLeaderboard(period: string = '30d') {
    const periodMs = period === '7d' ? 7 * 86400000 : period === '24h' ? 86400000 : 30 * 86400000;
    const since = new Date(Date.now() - periodMs);

    const traders = await db.select({
      userId: exchangeTrades.buyerId,
      volume: sql<number>`COALESCE(SUM(${exchangeTrades.totalValue}), 0)`,
      trades: sql<number>`COUNT(*)`,
      totalFees: sql<number>`COALESCE(SUM(${exchangeTrades.buyerFee}), 0)`,
    }).from(exchangeTrades)
      .where(gte(exchangeTrades.createdAt, since))
      .groupBy(exchangeTrades.buyerId)
      .orderBy(sql`SUM(${exchangeTrades.totalValue}) DESC`)
      .limit(50);

    const sellers = await db.select({
      userId: exchangeTrades.sellerId,
      volume: sql<number>`COALESCE(SUM(${exchangeTrades.totalValue}), 0)`,
      trades: sql<number>`COUNT(*)`,
      totalFees: sql<number>`COALESCE(SUM(${exchangeTrades.sellerFee}), 0)`,
    }).from(exchangeTrades)
      .where(gte(exchangeTrades.createdAt, since))
      .groupBy(exchangeTrades.sellerId)
      .orderBy(sql`SUM(${exchangeTrades.totalValue}) DESC`)
      .limit(50);

    const combined = new Map<string, { volume: number; trades: number; fees: number }>();
    for (const t of traders) {
      combined.set(t.userId, { volume: t.volume, trades: t.trades, fees: t.totalFees });
    }
    for (const s of sellers) {
      const existing = combined.get(s.userId) || { volume: 0, trades: 0, fees: 0 };
      combined.set(s.userId, {
        volume: existing.volume + s.volume,
        trades: existing.trades + s.trades,
        fees: existing.fees + s.totalFees,
      });
    }

    const leaderboard = Array.from(combined.entries())
      .map(([userId, data], idx) => ({
        rank: idx + 1,
        userId: userId.substring(0, 8) + '...',
        volume: parseFloat(data.volume.toFixed(2)),
        trades: data.trades,
        fees: parseFloat(data.fees.toFixed(4)),
      }))
      .sort((a, b) => b.volume - a.volume)
      .slice(0, 25)
      .map((entry, idx) => ({ ...entry, rank: idx + 1 }));

    return { period, leaderboard, updatedAt: new Date().toISOString() };
  }

  async exportTradesCSV(userId: string) {
    const trades = await db.select().from(exchangeTrades)
      .where(sql`${exchangeTrades.buyerId} = ${userId} OR ${exchangeTrades.sellerId} = ${userId}`)
      .orderBy(asc(exchangeTrades.createdAt));

    const headers = 'Date,Type,Price (USD),Amount (AUC),Total Value (USD),Fee (USD),Trade ID\n';
    const rows = trades.map(t => {
      const isBuyer = t.buyerId === userId;
      const type = isBuyer ? 'BUY' : 'SELL';
      const fee = isBuyer ? t.buyerFee : t.sellerFee;
      return `${t.createdAt.toISOString()},${type},${t.price.toFixed(4)},${t.amount.toFixed(4)},${t.totalValue.toFixed(4)},${fee.toFixed(4)},${t.id}`;
    }).join('\n');

    return headers + rows;
  }
  async getOrCreateReferralCode(userId: string) {
    const existing = await db.select().from(exchangeReferralCodes).where(eq(exchangeReferralCodes.userId, userId)).limit(1);
    if (existing.length > 0) return existing[0];

    const code = 'AUC' + userId.replace(/[^a-zA-Z0-9]/g, '').slice(0, 6).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const [created] = await db.insert(exchangeReferralCodes).values({ userId, code }).returning();
    return created;
  }

  async applyReferralCode(userId: string, code: string) {
    const existing = await db.select().from(exchangeReferrals).where(eq(exchangeReferrals.referredId, userId)).limit(1);
    if (existing.length > 0) return { error: 'You have already used a referral code' };

    const refCode = await db.select().from(exchangeReferralCodes).where(eq(exchangeReferralCodes.code, code.toUpperCase())).limit(1);
    if (refCode.length === 0) return { error: 'Invalid referral code' };
    if (refCode[0].userId === userId) return { error: 'You cannot use your own referral code' };

    await db.insert(exchangeReferrals).values({
      referrerId: refCode[0].userId,
      referredId: userId,
      referralCode: code.toUpperCase(),
      feeSharePercent: 20,
    });

    await db.update(exchangeReferralCodes)
      .set({ totalReferrals: sql`${exchangeReferralCodes.totalReferrals} + 1` })
      .where(eq(exchangeReferralCodes.code, code.toUpperCase()));

    return { success: true, referrer: refCode[0].userId };
  }

  async processReferralEarning(traderId: string, tradeId: number, feeAmount: number) {
    await this.processReferralEarningInTx(db, traderId, tradeId, feeAmount);
  }

  private async processReferralEarningInTx(txOrDb: any, traderId: string, tradeId: number, feeAmount: number) {
    const ref = await txOrDb.select().from(exchangeReferrals)
      .where(and(eq(exchangeReferrals.referredId, traderId), eq(exchangeReferrals.status, 'active')))
      .limit(1);
    if (ref.length === 0) return;

    const earning = feeAmount * (ref[0].feeSharePercent / 100);
    if (earning <= 0) return;

    await txOrDb.insert(exchangeReferralEarnings).values({
      referrerId: ref[0].referrerId,
      referredId: traderId,
      tradeId,
      feeAmount,
      earningAmount: earning,
    });

    await txOrDb.update(exchangeReferrals)
      .set({
        totalEarnings: sql`${exchangeReferrals.totalEarnings} + ${earning}`,
        totalTrades: sql`${exchangeReferrals.totalTrades} + 1`,
      })
      .where(eq(exchangeReferrals.id, ref[0].id));

    await txOrDb.update(exchangeReferralCodes)
      .set({ totalEarnings: sql`${exchangeReferralCodes.totalEarnings} + ${earning}` })
      .where(eq(exchangeReferralCodes.userId, ref[0].referrerId));

    await txOrDb.update(exchangeAccounts)
      .set({ usdBalance: sql`${exchangeAccounts.usdBalance} + ${earning}` })
      .where(eq(exchangeAccounts.userId, ref[0].referrerId));
  }

  async getReferralStats(userId: string) {
    const code = await this.getOrCreateReferralCode(userId);
    const referrals = await db.select().from(exchangeReferrals)
      .where(eq(exchangeReferrals.referrerId, userId))
      .orderBy(desc(exchangeReferrals.createdAt));

    const myReferrer = await db.select().from(exchangeReferrals)
      .where(eq(exchangeReferrals.referredId, userId))
      .limit(1);

    const recentEarnings = await db.select().from(exchangeReferralEarnings)
      .where(eq(exchangeReferralEarnings.referrerId, userId))
      .orderBy(desc(exchangeReferralEarnings.createdAt))
      .limit(20);

    return {
      code: code.code,
      totalReferrals: code.totalReferrals,
      totalEarnings: code.totalEarnings,
      feeSharePercent: 20,
      referrals: referrals.map(r => ({
        referredId: r.referredId.slice(0, 4) + '***',
        trades: r.totalTrades,
        earnings: r.totalEarnings,
        joinedAt: r.createdAt,
      })),
      hasReferrer: myReferrer.length > 0,
      recentEarnings: recentEarnings.map(e => ({
        amount: e.earningAmount,
        fromFee: e.feeAmount,
        date: e.createdAt,
      })),
    };
  }
  async seedFounderLiquidity() {
    const FOUNDER_USER_ID = "FOUNDER_LIQUIDITY_PROVIDER";
    const LIQUIDITY_AUC = 10_000_000_000;
    const LIQUIDITY_USD = 100;

    await db.transaction(async (tx) => {
      const existing = await tx.select().from(exchangeAccounts)
        .where(eq(exchangeAccounts.userId, FOUNDER_USER_ID)).limit(1).for("update");

      const openOrders = await tx.select().from(exchangeOrders)
        .where(and(
          eq(exchangeOrders.userId, FOUNDER_USER_ID),
          eq(exchangeOrders.status, "open")
        ));

      if (openOrders.length > 0) {
        console.log(`[Exchange] Founder liquidity already active (${openOrders.length} open orders)`);
        return;
      }

      if (existing.length === 0) {
        await tx.insert(exchangeAccounts).values({
          userId: FOUNDER_USER_ID,
          aucBalance: LIQUIDITY_AUC,
          usdBalance: LIQUIDITY_USD,
          aucLocked: 0,
          usdLocked: 0,
          totalFeesGenerated: 0,
        });
        console.log(`[Exchange] Founder liquidity account created with ${LIQUIDITY_AUC.toLocaleString()} AUC`);
      }

      const basePrice = INITIAL_AUC_PRICE;
      const sellLevels = [
        { price: basePrice, amount: 2_000_000_000 },
        { price: basePrice * 1.1, amount: 1_500_000_000 },
        { price: basePrice * 1.25, amount: 1_000_000_000 },
        { price: basePrice * 1.5, amount: 800_000_000 },
        { price: basePrice * 2, amount: 500_000_000 },
        { price: basePrice * 3, amount: 300_000_000 },
        { price: basePrice * 5, amount: 200_000_000 },
        { price: basePrice * 10, amount: 100_000_000 },
      ];

      const buyLevels = [
        { price: basePrice * 0.9, amount: 1_000_000_000 },
        { price: basePrice * 0.75, amount: 800_000_000 },
        { price: basePrice * 0.5, amount: 500_000_000 },
      ];

      let totalAucLocked = 0;
      let totalUsdLocked = 0;

      for (const level of sellLevels) {
        await tx.insert(exchangeOrders).values({
          userId: FOUNDER_USER_ID,
          side: "sell",
          orderType: "limit",
          price: level.price,
          amount: level.amount,
          filled: 0,
          remaining: level.amount,
          status: "open",
          fee: 0,
        });
        totalAucLocked += level.amount;
      }

      for (const level of buyLevels) {
        const usdNeeded = level.amount * level.price;
        const usdFee = usdNeeded * TRADING_FEE_RATE;
        await tx.insert(exchangeOrders).values({
          userId: FOUNDER_USER_ID,
          side: "buy",
          orderType: "limit",
          price: level.price,
          amount: level.amount,
          filled: 0,
          remaining: level.amount,
          status: "open",
          fee: 0,
        });
        totalUsdLocked += usdNeeded + usdFee;
      }

      const acct = existing.length > 0 ? existing[0] : null;
      const currentAucBalance = acct ? (acct.aucBalance || 0) : LIQUIDITY_AUC;
      const currentUsdBalance = acct ? (acct.usdBalance || 0) : LIQUIDITY_USD;
      const neededAuc = Math.max(0, totalAucLocked - currentAucBalance);
      const neededUsd = Math.max(0, totalUsdLocked - currentUsdBalance);

      if (existing.length > 0) {
        await tx.update(exchangeAccounts)
          .set({
            aucBalance: sql`${exchangeAccounts.aucBalance} + ${neededAuc}`,
            usdBalance: sql`${exchangeAccounts.usdBalance} + ${neededUsd}`,
            aucLocked: totalAucLocked,
            usdLocked: totalUsdLocked,
          })
          .where(eq(exchangeAccounts.userId, FOUNDER_USER_ID));
      } else {
        await tx.update(exchangeAccounts)
          .set({ aucLocked: totalAucLocked, usdLocked: totalUsdLocked })
          .where(eq(exchangeAccounts.userId, FOUNDER_USER_ID));
      }

      console.log(`[Exchange] Founder liquidity seeded: ${sellLevels.length} sell orders + ${buyLevels.length} buy orders`);
      console.log(`[Exchange] Sell liquidity: ${totalAucLocked.toLocaleString()} AUC across ${sellLevels.length} price levels`);
      console.log(`[Exchange] Buy liquidity: $${totalUsdLocked.toFixed(4)} across ${buyLevels.length} price levels`);
    });
  }
}

export const exchangeService = new ExchangeService();
