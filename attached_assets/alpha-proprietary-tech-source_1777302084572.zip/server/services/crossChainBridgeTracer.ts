/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Cross-Chain Bridge Tracer™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary cross-chain bridge transaction tracing and fund flow analysis technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Cross-Chain Bridge Tracer™
 * - Bridge Transaction Correlation Engine™
 * - Multi-Chain Fund Flow Analyzer™
 * - Bridge Exploit Detection System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_8013e524bbc98bd1e53f459f
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import { lookupAddress } from "./addressLabelDatabase.js";


export const _ccbtSeal = 'AUT_8013e524bbc98bd1e53f459f';
const _ccbtIntegrityValid = registerBeacon('crossChainBridgeTracer', _ccbtSeal);
if (!_ccbtSeal?.startsWith('AUT_') || !_ccbtIntegrityValid) {
  throw new Error('[SECURITY] Alpha Cross-Chain Bridge Tracer™ integrity verification failed — module sealed');
}

export interface BridgeTrace {
  sourceChain: string;
  sourceTxHash: string;
  sourceAddress: string;
  bridgeProtocol: string;
  bridgeContract: string;
  destinationChain: string | null;
  destinationAddress: string | null;
  destinationTxHash: string | null;
  amount: string;
  token: string;
  timestamp: string;
  status: "traced" | "pending" | "unknown";
  onwardMovements: OnwardMovement[];
}

export interface OnwardMovement {
  txHash: string;
  from: string;
  to: string;
  toLabel: string | null;
  amount: string;
  chain: string;
  timestamp: string;
}

const BRIDGE_CONTRACTS: Record<string, { name: string; destChains: string[] }> = {
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": { name: "LI.FI Diamond", destChains: ["arbitrum", "optimism", "polygon", "bsc", "base", "gnosis"] },
  "0x3a23f943181408eac424116af7b7790c94cb97a5": { name: "Socket Gateway", destChains: ["arbitrum", "optimism", "polygon", "bsc", "base"] },
  "0x99c9fc46f92e8a1c0dec1b1747d010903e884be1": { name: "Optimism Gateway", destChains: ["optimism"] },
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f": { name: "Arbitrum Delayed Inbox", destChains: ["arbitrum"] },
  "0xa0c68c638235ee32657e8f720a23cec1bfc6c9a8": { name: "Polygon Bridge", destChains: ["polygon"] },
  "0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf": { name: "Polygon ERC20 Bridge", destChains: ["polygon"] },
  "0x3ee18b2214aff97000d974cf647e7c347e8fa585": { name: "Wormhole Token Bridge", destChains: ["arbitrum", "optimism", "polygon", "bsc", "base"] },
  "0x3014ca10b91cb3d0ad85fef7a3cb95bcac9c0f79": { name: "Stargate Router", destChains: ["arbitrum", "optimism", "polygon", "bsc", "base"] },
  "0xe4edb277e41dc89ab076a1f049f4a3efa700bce8": { name: "Across Bridge", destChains: ["arbitrum", "optimism", "polygon", "base"] },
  "0x5427fefa711eff984124bfbb1ab6fbf5e3da1820": { name: "Synapse Bridge", destChains: ["arbitrum", "optimism", "polygon", "bsc"] },
  "0xcb566e3b6934fa77258d68ea18e931fa75e1aaaa": { name: "Multichain Router", destChains: ["arbitrum", "polygon", "bsc"] },
  "0xb8901acb165ed027e32754e0ffe830802919727f": { name: "Hop Protocol ETH Bridge", destChains: ["arbitrum", "optimism", "polygon"] },
};

const CHAIN_URLS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com",
  arbitrum: "https://arbitrum.blockscout.com",
  optimism: "https://optimism.blockscout.com",
  base: "https://base.blockscout.com",
  polygon: "https://polygon.blockscout.com",
  gnosis: "https://gnosis.blockscout.com",
  bsc: "https://bsc.blockscout.com",
};

async function fetchTxsToContract(address: string, contractAddr: string, chain: string = "ethereum"): Promise<any[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/transactions?limit=100`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return (data.items || []).filter((tx: any) =>
      tx.to?.hash?.toLowerCase() === contractAddr.toLowerCase()
    );
  } catch { return []; }
}

async function traceDestinationOnChain(senderAddress: string, destChain: string, timeWindow: { start: number; end: number }): Promise<{ address: string; txHash: string; amount: string } | null> {
  const baseUrl = CHAIN_URLS[destChain];
  if (!baseUrl) return null;

  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${senderAddress}/transactions?limit=20`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    const txs = data.items || [];

    for (const tx of txs) {
      const txTime = new Date(tx.timestamp).getTime();
      if (txTime >= timeWindow.start && txTime <= timeWindow.end) {
        return {
          address: tx.to?.hash || senderAddress,
          txHash: tx.hash,
          amount: tx.value || "0"
        };
      }
    }
  } catch {}
  return null;
}

async function fetchOnwardMovements(address: string, chain: string, afterTimestamp: number, limit: number = 20): Promise<OnwardMovement[]> {
  const baseUrl = CHAIN_URLS[chain];
  if (!baseUrl) return [];

  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/transactions?limit=${limit}`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    const txs = (data.items || []).filter((tx: any) => {
      const txTime = new Date(tx.timestamp).getTime();
      return tx.from?.hash?.toLowerCase() === address.toLowerCase() && txTime >= afterTimestamp;
    });

    return txs.map((tx: any) => {
      const toAddr = tx.to?.hash?.toLowerCase() || "";
      const label = lookupAddress(toAddr);
      return {
        txHash: tx.hash,
        from: address.toLowerCase(),
        to: toAddr,
        toLabel: label ? `${label.name} (${label.category})` : null,
        amount: tx.value || "0",
        chain,
        timestamp: tx.timestamp
      };
    });
  } catch { return []; }
}

export async function detectBridgeTransactions(address: string, chain: string = "ethereum"): Promise<BridgeTrace[]> {
  const results: BridgeTrace[] = [];
  const bridgeContracts = Object.entries(BRIDGE_CONTRACTS);

  for (const [contractAddr, bridgeInfo] of bridgeContracts) {
    const txs = await fetchTxsToContract(address, contractAddr, chain);

    for (const tx of txs) {
      const txTime = new Date(tx.timestamp).getTime();
      const timeWindow = { start: txTime, end: txTime + 3600000 };

      let destResult: { address: string; txHash: string; amount: string } | null = null;
      let destChain: string | null = null;

      for (const dc of bridgeInfo.destChains) {
        destResult = await traceDestinationOnChain(address, dc, timeWindow);
        if (destResult) {
          destChain = dc;
          break;
        }
        await new Promise(r => setTimeout(r, 300));
      }

      let onwardMovements: OnwardMovement[] = [];
      if (destResult && destChain) {
        onwardMovements = await fetchOnwardMovements(destResult.address, destChain, txTime);
      }

      results.push({
        sourceChain: chain,
        sourceTxHash: tx.hash,
        sourceAddress: address.toLowerCase(),
        bridgeProtocol: bridgeInfo.name,
        bridgeContract: contractAddr,
        destinationChain: destChain,
        destinationAddress: destResult?.address || null,
        destinationTxHash: destResult?.txHash || null,
        amount: tx.value || "0",
        token: "ETH",
        timestamp: tx.timestamp,
        status: destResult ? "traced" : "pending",
        onwardMovements
      });
    }

    await new Promise(r => setTimeout(r, 300));
  }

  return results;
}

export async function traceFullBridgePath(address: string, startChain: string = "ethereum", maxDepth: number = 3): Promise<BridgeTrace[]> {
  const allTraces: BridgeTrace[] = [];
  const visited = new Set<string>();

  async function trace(addr: string, chain: string, depth: number) {
    const key = `${chain}:${addr.toLowerCase()}`;
    if (visited.has(key) || depth >= maxDepth) return;
    visited.add(key);

    const bridges = await detectBridgeTransactions(addr, chain);
    allTraces.push(...bridges);

    for (const bridge of bridges) {
      if (bridge.destinationAddress && bridge.destinationChain) {
        await trace(bridge.destinationAddress, bridge.destinationChain, depth + 1);
      }
    }
  }

  await trace(address, startChain, 0);
  return allTraces;
}

export function getBridgeContractList(): { address: string; name: string; destChains: string[] }[] {
  return Object.entries(BRIDGE_CONTRACTS).map(([addr, info]) => ({
    address: addr,
    name: info.name,
    destChains: info.destChains
  }));
}

console.log(`[BridgeTracer] Alpha Cross-Chain Bridge Tracer™ initialized`);
console.log(`[BridgeTracer] Monitoring ${Object.keys(BRIDGE_CONTRACTS).length} bridge contracts across ${Object.keys(CHAIN_URLS).length} chains`);
