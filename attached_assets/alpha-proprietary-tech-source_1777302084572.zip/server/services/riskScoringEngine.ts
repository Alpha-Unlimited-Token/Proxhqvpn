/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Risk Scoring Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary multi-factor blockchain risk assessment and scoring technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Risk Scoring Engine™
 * - Multi-Factor Risk Assessment™
 * - Behavioral Risk Profiling™
 * - Sanctions Compliance Screening™
 * - Mixer Interaction Detector™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_2e11d441ef5cc432311e959a
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import { lookupAddress, getMixerAddresses, getSanctionedAddresses, type AddressLabel } from "./addressLabelDatabase.js";


export const _rseSeal = 'AUT_2e11d441ef5cc432311e959a';
const _rseIntegrityValid = registerBeacon('riskScoringEngine', _rseSeal);
if (!_rseSeal?.startsWith('AUT_') || !_rseIntegrityValid) {
  throw new Error('[SECURITY] Alpha Risk Scoring Engine™ integrity verification failed — module sealed');
}

export interface RiskScore {
  address: string;
  chain: string;
  overallScore: number;
  riskLevel: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "CLEAN";
  breakdown: RiskFactor[];
  timestamp: string;
  transactionsAnalyzed: number;
  counterpartiesChecked: number;
}

export interface RiskFactor {
  factor: string;
  score: number;
  weight: number;
  weightedScore: number;
  details: string;
}

const CHAIN_URLS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com",
  arbitrum: "https://arbitrum.blockscout.com",
  optimism: "https://optimism.blockscout.com",
  base: "https://base.blockscout.com",
  polygon: "https://polygon.blockscout.com",
  gnosis: "https://gnosis.blockscout.com",
  bsc: "https://bsc.blockscout.com",
};

const mixerAddrs = new Set(getMixerAddresses().map(a => a.address));
const sanctionedAddrs = new Set(getSanctionedAddresses().map(a => a.address));

async function fetchTxs(address: string, chain: string, limit: number = 100): Promise<any[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/transactions?limit=${limit}`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.items || [];
  } catch { return []; }
}

async function fetchTokenTransfers(address: string, chain: string, limit: number = 50): Promise<any[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/token-transfers?limit=${limit}`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.items || [];
  } catch { return []; }
}

function scoreMixerProximity(txs: any[], address: string): RiskFactor {
  let directMixer = 0;
  for (const tx of txs) {
    const from = tx.from?.hash?.toLowerCase();
    const to = tx.to?.hash?.toLowerCase();
    if (mixerAddrs.has(from || "") || mixerAddrs.has(to || "")) directMixer++;
  }

  const score = directMixer > 0 ? Math.min(100, 60 + directMixer * 15) : 0;
  return {
    factor: "Mixer Interaction",
    score,
    weight: 0.30,
    weightedScore: score * 0.30,
    details: directMixer > 0
      ? `${directMixer} direct transaction(s) with known mixer contracts (Tornado Cash)`
      : "No mixer interactions detected"
  };
}

function scoreSanctionedProximity(txs: any[]): RiskFactor {
  let directSanctioned = 0;
  const sanctionedNames: string[] = [];
  for (const tx of txs) {
    const from = tx.from?.hash?.toLowerCase();
    const to = tx.to?.hash?.toLowerCase();
    for (const addr of [from, to]) {
      if (addr && sanctionedAddrs.has(addr)) {
        directSanctioned++;
        const label = lookupAddress(addr);
        if (label) sanctionedNames.push(label.name);
      }
    }
  }

  const score = directSanctioned > 0 ? Math.min(100, 70 + directSanctioned * 15) : 0;
  return {
    factor: "Sanctioned Entity Interaction",
    score,
    weight: 0.25,
    weightedScore: score * 0.25,
    details: directSanctioned > 0
      ? `${directSanctioned} transaction(s) with sanctioned/exploiter addresses: ${[...new Set(sanctionedNames)].join(", ")}`
      : "No sanctioned entity interactions detected"
  };
}

function scoreExchangeDepositPattern(txs: any[], address: string): RiskFactor {
  let exchangeDeposits = 0;
  let totalOutgoing = 0;
  const exchanges = new Set<string>();

  for (const tx of txs) {
    const from = tx.from?.hash?.toLowerCase();
    const to = tx.to?.hash?.toLowerCase();
    if (from === address.toLowerCase() && to) {
      totalOutgoing++;
      const label = lookupAddress(to);
      if (label && label.category === "exchange") {
        exchangeDeposits++;
        exchanges.add(label.subcategory || label.name);
      }
    }
  }

  const ratio = totalOutgoing > 0 ? exchangeDeposits / totalOutgoing : 0;
  let score = 0;
  if (ratio > 0.8 && exchangeDeposits > 3) score = 70;
  else if (ratio > 0.5) score = 45;
  else if (exchangeDeposits > 0) score = 15;

  return {
    factor: "Exchange Deposit Pattern",
    score,
    weight: 0.15,
    weightedScore: score * 0.15,
    details: `${exchangeDeposits}/${totalOutgoing} outgoing transactions to exchanges (${[...exchanges].join(", ") || "none"}). ${ratio > 0.5 ? "HIGH deposit concentration — possible cash-out pattern" : "Normal exchange usage"}`
  };
}

function scoreWalletAge(txs: any[]): RiskFactor {
  if (txs.length === 0) {
    return { factor: "Wallet Age & Activity", score: 50, weight: 0.10, weightedScore: 5, details: "No transactions found — cannot assess age" };
  }

  const timestamps = txs.map(tx => new Date(tx.timestamp).getTime()).sort();
  const oldest = timestamps[0];
  const newest = timestamps[timestamps.length - 1];
  const ageDays = (Date.now() - oldest) / (1000 * 60 * 60 * 24);
  const activitySpanDays = (newest - oldest) / (1000 * 60 * 60 * 24);

  let score = 0;
  if (ageDays < 7) score = 60;
  else if (ageDays < 30) score = 40;
  else if (ageDays < 90) score = 20;
  else score = 5;

  if (activitySpanDays < 1 && txs.length > 10) score = Math.max(score, 50);

  return {
    factor: "Wallet Age & Activity",
    score,
    weight: 0.10,
    weightedScore: score * 0.10,
    details: `Wallet age: ${ageDays.toFixed(0)} days | Activity span: ${activitySpanDays.toFixed(1)} days | ${txs.length} transactions. ${ageDays < 30 ? "NEW wallet — higher risk" : "Established wallet"}`
  };
}

function scoreTransactionVelocity(txs: any[], address: string): RiskFactor {
  if (txs.length < 2) {
    return { factor: "Transaction Velocity", score: 0, weight: 0.10, weightedScore: 0, details: "Insufficient transactions for velocity analysis" };
  }

  const outgoing = txs
    .filter(tx => tx.from?.hash?.toLowerCase() === address.toLowerCase())
    .map(tx => new Date(tx.timestamp).getTime())
    .sort();

  if (outgoing.length < 2) {
    return { factor: "Transaction Velocity", score: 0, weight: 0.10, weightedScore: 0, details: "No outgoing transaction pattern" };
  }

  let rapidBursts = 0;
  for (let i = 1; i < outgoing.length; i++) {
    if (outgoing[i] - outgoing[i - 1] < 60000) rapidBursts++;
  }

  const burstRatio = rapidBursts / (outgoing.length - 1);
  let score = 0;
  if (burstRatio > 0.5 && outgoing.length > 5) score = 65;
  else if (burstRatio > 0.2) score = 35;
  else score = 5;

  return {
    factor: "Transaction Velocity",
    score,
    weight: 0.10,
    weightedScore: score * 0.10,
    details: `${rapidBursts} rapid-fire transactions (<60s apart) out of ${outgoing.length} outgoing. ${burstRatio > 0.3 ? "HIGH velocity — possible automated laundering" : "Normal transaction pace"}`
  };
}

export async function scoreAddress(address: string, chain: string = "ethereum"): Promise<RiskScore> {
  const txs = await fetchTxs(address, chain);
  const tokenTransfers = await fetchTokenTransfers(address, chain);

  const allTxs = [...txs, ...tokenTransfers];

  const factors: RiskFactor[] = [
    scoreMixerProximity(allTxs, address),
    scoreSanctionedProximity(allTxs),
    scoreExchangeDepositPattern(txs, address),
    scoreWalletAge(txs),
    scoreTransactionVelocity(txs, address),
  ];

  const counterparties = new Set<string>();
  for (const tx of txs) {
    if (tx.from?.hash) counterparties.add(tx.from.hash.toLowerCase());
    if (tx.to?.hash) counterparties.add(tx.to.hash.toLowerCase());
  }

  const overallScore = Math.round(factors.reduce((sum, f) => sum + f.weightedScore, 0));

  let riskLevel: RiskScore["riskLevel"];
  if (overallScore >= 75) riskLevel = "CRITICAL";
  else if (overallScore >= 50) riskLevel = "HIGH";
  else if (overallScore >= 25) riskLevel = "MEDIUM";
  else if (overallScore >= 10) riskLevel = "LOW";
  else riskLevel = "CLEAN";

  return {
    address: address.toLowerCase(),
    chain,
    overallScore,
    riskLevel,
    breakdown: factors,
    timestamp: new Date().toISOString(),
    transactionsAnalyzed: allTxs.length,
    counterpartiesChecked: counterparties.size
  };
}

export async function batchScoreAddresses(addresses: string[], chain: string = "ethereum"): Promise<RiskScore[]> {
  const results: RiskScore[] = [];
  for (const addr of addresses) {
    const score = await scoreAddress(addr, chain);
    results.push(score);
    await new Promise(r => setTimeout(r, 500));
  }
  return results;
}

console.log("[RiskEngine] Alpha Risk Scoring Engine™ initialized");
console.log("[RiskEngine] Factors: mixer proximity (30%), sanctioned entity (25%), exchange deposit pattern (15%), wallet age (10%), transaction velocity (10%)");
