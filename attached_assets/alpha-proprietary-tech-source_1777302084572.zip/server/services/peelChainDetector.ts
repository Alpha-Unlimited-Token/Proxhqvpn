/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Peel Chain Detector™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary peel chain detection and layered transaction analysis technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Peel Chain Detector™
 * - Layered Transaction Unwinding Engine™
 * - Obfuscation Pattern Recognition™
 * - Micro-Split Tracing Algorithm™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_ff91c1f8e541ca9aee8b3f78
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import { lookupAddress, type AddressLabel } from "./addressLabelDatabase.js";


export const _pcdModuleHash = 'AUT_ff91c1f8e541ca9aee8b3f78';
const _pcdIntegrityValid = registerBeacon('peelChainDetector', _pcdModuleHash);
if (!_pcdModuleHash?.startsWith('AUT_') || !_pcdIntegrityValid) {
  throw new Error('[SECURITY] Alpha Peel Chain Detector™ integrity verification failed — module sealed');
}

export interface PeelChain {
  chainId: string;
  startAddress: string;
  endAddress: string;
  hops: PeelHop[];
  totalPeeled: string;
  totalRemaining: string;
  pattern: "linear" | "fan-out" | "consolidation";
  confidence: number;
  riskIndicators: string[];
  detectedAt: string;
}

export interface PeelHop {
  hopNumber: number;
  from: string;
  fromLabel: string | null;
  to: string;
  toLabel: string | null;
  peeledTo: string | null;
  peeledToLabel: string | null;
  amountForwarded: string;
  amountPeeled: string;
  txHash: string;
  timestamp: string;
  chain: string;
}

const CHAIN_URLS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com",
  arbitrum: "https://arbitrum.blockscout.com",
  optimism: "https://optimism.blockscout.com",
  base: "https://base.blockscout.com",
  polygon: "https://polygon.blockscout.com",
  gnosis: "https://gnosis.blockscout.com",
  bsc: "https://bsc.blockscout.com",
};

async function fetchOutgoingTxs(address: string, chain: string): Promise<any[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/transactions?limit=50`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return (data.items || []).filter((tx: any) =>
      tx.from?.hash?.toLowerCase() === address.toLowerCase()
    );
  } catch { return []; }
}

function weiToEth(wei: string): number {
  return parseInt(wei || "0") / 1e18;
}

export async function detectPeelChain(startAddress: string, chain: string = "ethereum", maxHops: number = 15): Promise<PeelChain | null> {
  const hops: PeelHop[] = [];
  const visited = new Set<string>();
  let currentAddr = startAddress.toLowerCase();
  let hopNum = 0;
  const riskIndicators: string[] = [];
  let totalPeeled = 0;

  while (hopNum < maxHops) {
    if (visited.has(currentAddr)) break;
    visited.add(currentAddr);

    const txs = await fetchOutgoingTxs(currentAddr, chain);
    if (txs.length === 0) break;

    const sortedTxs = txs.sort((a: any, b: any) =>
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    let bestForwardTx: any = null;
    let bestPeelTx: any = null;

    if (sortedTxs.length === 1) {
      bestForwardTx = sortedTxs[0];
    } else if (sortedTxs.length === 2) {
      const val0 = weiToEth(sortedTxs[0].value);
      const val1 = weiToEth(sortedTxs[1].value);
      if (val0 > val1) {
        bestForwardTx = sortedTxs[0];
        bestPeelTx = sortedTxs[1];
      } else {
        bestForwardTx = sortedTxs[1];
        bestPeelTx = sortedTxs[0];
      }
    } else {
      const values = sortedTxs.map((tx: any) => ({ tx, val: weiToEth(tx.value) }));
      values.sort((a: any, b: any) => b.val - a.val);
      bestForwardTx = values[0].tx;
      if (values.length > 1) bestPeelTx = values[1].tx;
    }

    if (!bestForwardTx) break;

    const forwardTo = bestForwardTx.to?.hash?.toLowerCase();
    const forwardLabel = forwardTo ? lookupAddress(forwardTo) : null;
    const peelTo = bestPeelTx?.to?.hash?.toLowerCase() || null;
    const peelLabel = peelTo ? lookupAddress(peelTo) : null;
    const fromLabel = lookupAddress(currentAddr);

    const peelAmount = bestPeelTx ? weiToEth(bestPeelTx.value) : 0;
    totalPeeled += peelAmount;

    hops.push({
      hopNumber: hopNum,
      from: currentAddr,
      fromLabel: fromLabel?.name || null,
      to: forwardTo || "",
      toLabel: forwardLabel?.name || null,
      peeledTo: peelTo,
      peeledToLabel: peelLabel?.name || null,
      amountForwarded: weiToEth(bestForwardTx.value).toFixed(6),
      amountPeeled: peelAmount.toFixed(6),
      txHash: bestForwardTx.hash,
      timestamp: bestForwardTx.timestamp,
      chain
    });

    if (peelLabel && peelLabel.category === "exchange") {
      riskIndicators.push(`Hop ${hopNum}: peeled ${peelAmount.toFixed(4)} ETH to ${peelLabel.name}`);
    }
    if (peelLabel && peelLabel.category === "mixer") {
      riskIndicators.push(`Hop ${hopNum}: peeled to MIXER (${peelLabel.name}) — HIGH RISK`);
    }

    if (forwardLabel && (forwardLabel.category === "exchange" || forwardLabel.category === "mixer")) {
      riskIndicators.push(`Hop ${hopNum}: chain terminates at ${forwardLabel.name} (${forwardLabel.category})`);
      break;
    }

    if (!forwardTo || visited.has(forwardTo)) break;
    currentAddr = forwardTo;
    hopNum++;

    await new Promise(r => setTimeout(r, 400));
  }

  if (hops.length < 2) return null;

  const lastHop = hops[hops.length - 1];
  const remainingAmount = parseFloat(lastHop.amountForwarded);

  let pattern: PeelChain["pattern"] = "linear";
  const uniqueRecipients = new Set(hops.map(h => h.to));
  if (uniqueRecipients.size < hops.length * 0.5) pattern = "consolidation";

  const peelConsistency = hops.filter(h => parseFloat(h.amountPeeled) > 0).length / hops.length;
  const confidence = Math.min(0.95, 0.3 + peelConsistency * 0.4 + (hops.length / maxHops) * 0.25);

  if (hops.length >= 5) riskIndicators.push(`Long peel chain: ${hops.length} hops — suggests deliberate laundering`);
  if (totalPeeled > 0 && remainingAmount > 0) {
    const peelRatio = totalPeeled / (totalPeeled + remainingAmount);
    if (peelRatio < 0.3) riskIndicators.push(`Low peel ratio (${(peelRatio * 100).toFixed(1)}%) — most funds still in chain`);
  }

  return {
    chainId: `peel_${startAddress.slice(2, 10).toLowerCase()}`,
    startAddress: startAddress.toLowerCase(),
    endAddress: lastHop.to,
    hops,
    totalPeeled: totalPeeled.toFixed(6),
    totalRemaining: remainingAmount.toFixed(6),
    pattern,
    confidence,
    riskIndicators,
    detectedAt: new Date().toISOString()
  };
}

export async function scanForPeelChains(addresses: string[], chain: string = "ethereum"): Promise<PeelChain[]> {
  const results: PeelChain[] = [];

  for (const addr of addresses) {
    const peelChain = await detectPeelChain(addr, chain);
    if (peelChain && peelChain.hops.length >= 3) {
      results.push(peelChain);
    }
    await new Promise(r => setTimeout(r, 500));
  }

  return results.sort((a, b) => b.hops.length - a.hops.length);
}

console.log("[PeelDetector] Alpha Peel Chain Detector™ initialized");
console.log("[PeelDetector] Detects sequential fund-splitting patterns across 7 EVM chains");
