/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Mining Service Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary cryptocurrency mining optimization and management technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Mining Service Engine™
 * - Temporal Difficulty Analysis™
 * - Entropy Cascade Mapping™
 * - Network Latency Optimizer™
 * - Hash Rate Optimization Protocol™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_f35abb58f347c252157364ce
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import http from "http";
import net from "net";
import type { MinerStatus, MinerProtocol } from "@shared/models/mining";


export const _msSeal = 'AUT_f35abb58f347c252157364ce';
const _msIntegrityValid = registerBeacon('minerService', _msSeal);
if (!_msSeal?.startsWith('AUT_') || !_msIntegrityValid) {
  throw new Error('[SECURITY] Alpha Mining Service Engine™ integrity verification failed — module sealed');
}

const REQUEST_TIMEOUT = 5000;

function isPrivateOrLocalIP(ip: string): boolean {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some(p => isNaN(p) || p < 0 || p > 255)) return false;
  if (parts[0] === 10) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  if (parts[0] === 192 && parts[1] === 168) return true;
  if (parts[0] === 127) return true;
  if (parts[0] === 169 && parts[1] === 254) return true;
  return false;
}

export function validateMinerIP(ip: string): { valid: boolean; error?: string } {
  if (ip.includes(':')) {
    return { valid: false, error: "IPv6 addresses not supported" };
  }
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some(p => isNaN(p) || p < 0 || p > 255)) {
    return { valid: false, error: "Invalid IP address format" };
  }
  if (parts[0] === 0 || parts[0] === 255) {
    return { valid: false, error: "Reserved IP address" };
  }
  if (parts[0] === 127) {
    return { valid: false, error: "Loopback addresses not allowed" };
  }
  if (ip === '0.0.0.0') {
    return { valid: false, error: "Broadcast address not allowed" };
  }
  if (parts[0] === 169 && parts[1] === 254) {
    return { valid: false, error: "Link-local/cloud metadata addresses not allowed" };
  }
  if (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) {
    return { valid: false, error: "Carrier-grade NAT addresses not allowed" };
  }
  if (!isPrivateOrLocalIP(ip)) {
    return { valid: false, error: "Only private/local network IPs allowed for miner connections" };
  }
  return { valid: true };
}

function httpGet(ip: string, port: number, path: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const req = http.get(
      { hostname: ip, port, path, timeout: REQUEST_TIMEOUT },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            reject(new Error("Invalid JSON response"));
          }
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timeout"));
    });
  });
}

function httpPatch(ip: string, port: number, path: string, body: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        hostname: ip,
        port,
        path,
        method: "PATCH",
        timeout: REQUEST_TIMEOUT,
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(payload),
        },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(data ? JSON.parse(data) : { success: true });
          } catch {
            resolve({ success: true, raw: data });
          }
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timeout"));
    });
    req.write(payload);
    req.end();
  });
}

function httpPost(ip: string, port: number, path: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: ip,
        port,
        path,
        method: "POST",
        timeout: REQUEST_TIMEOUT,
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(data ? JSON.parse(data) : { success: true });
          } catch {
            resolve({ success: true, raw: data });
          }
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timeout"));
    });
    req.end();
  });
}

function cgminerCommand(ip: string, port: number, command: string, parameter?: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const client = new net.Socket();
    client.setTimeout(REQUEST_TIMEOUT);
    let data = "";

    client.connect(port, ip, () => {
      const req: any = { command };
      if (parameter) req.parameter = parameter;
      client.write(JSON.stringify(req));
    });

    client.on("data", (chunk) => {
      data += chunk.toString();
    });

    client.on("end", () => {
      try {
        const cleaned = data.replace(/\0/g, "");
        resolve(JSON.parse(cleaned));
      } catch {
        reject(new Error("Invalid CGMiner response"));
      }
    });

    client.on("error", reject);
    client.on("timeout", () => {
      client.destroy();
      reject(new Error("CGMiner connection timeout"));
    });
  });
}

async function detectBitaxe(ip: string, port: number): Promise<{ detected: boolean; info?: any }> {
  try {
    const info = await httpGet(ip, port, "/api/system/info");
    if (info && (info.ASICModel || info.boardVersion || info.version || info.hashRate !== undefined || info.hashrate !== undefined)) {
      return { detected: true, info };
    }
    return { detected: false };
  } catch {
    return { detected: false };
  }
}

async function detectCGMiner(ip: string, port: number): Promise<{ detected: boolean; info?: any }> {
  try {
    const result = await cgminerCommand(ip, port, "version");
    if (result && (result.VERSION || result.STATUS)) {
      return { detected: true, info: result };
    }
    return { detected: false };
  } catch {
    return { detected: false };
  }
}

function enforceIPValidation(ip: string): void {
  const check = validateMinerIP(ip);
  if (!check.valid) {
    throw new Error(`IP validation failed: ${check.error}`);
  }
}

export async function autoDetectMiner(ip: string): Promise<{ protocol: MinerProtocol; port: number; info: any } | null> {
  enforceIPValidation(ip);

  const bitaxe = await detectBitaxe(ip, 80);
  if (bitaxe.detected) {
    return { protocol: "bitaxe", port: 80, info: bitaxe.info };
  }

  const cgminer = await detectCGMiner(ip, 4028);
  if (cgminer.detected) {
    return { protocol: "cgminer", port: 4028, info: cgminer.info };
  }

  const bitaxeAlt = await detectBitaxe(ip, 8080);
  if (bitaxeAlt.detected) {
    return { protocol: "bitaxe", port: 8080, info: bitaxeAlt.info };
  }

  return null;
}

export async function getBitaxeStatus(ip: string, port: number): Promise<MinerStatus> {
  try {
    const info = await httpGet(ip, port, "/api/system/info");
    return {
      online: true,
      hashrate: info.hashRate ?? info.hashrate ?? 0,
      hashrateUnit: "GH/s",
      temperature: info.temp ?? info.asicTemp ?? 0,
      vrTemp: info.vrTemp ?? 0,
      fanSpeed: info.fanspeed ?? info.fanSpeed ?? 0,
      fanRpm: info.fanrpm ?? info.fanRpm ?? 0,
      power: info.power ?? 0,
      voltage: info.coreVoltage ?? info.voltage ?? 0,
      frequency: info.frequency ?? 0,
      accepted: info.sharesAccepted ?? 0,
      rejected: info.sharesRejected ?? 0,
      difficulty: info.difficulty ?? 0,
      bestDifficulty: info.bestDiff ?? info.bestDifficulty ?? "0",
      uptimeSeconds: info.uptimeSeconds ?? 0,
      poolUrl: info.stratumURL ?? info.stratumUrl ?? "",
      poolUser: info.stratumUser ?? "",
      boardVersion: info.boardVersion ?? "",
      firmwareVersion: info.version ?? info.runningPartition ?? "",
      chipModel: info.ASICModel ?? info.asicModel ?? "",
      blockHeight: info.blockHeight ?? 0,
      networkDifficulty: info.networkDifficulty ?? 0,
      freeHeap: info.freeHeap ?? 0,
      ssid: info.ssid ?? "",
      macAddress: info.macAddr ?? "",
      hostname: info.hostname ?? "",
      sharesPerMinute: info.sharesPerMinute ?? 0,
      bestSessionDifficulty: info.bestSessionDiff ?? "0",
      rawData: info,
    };
  } catch (e: any) {
    return { online: false, error: e.message };
  }
}

export async function getCGMinerStatus(ip: string, port: number): Promise<MinerStatus> {
  try {
    const [summaryRes, devsRes] = await Promise.all([
      cgminerCommand(ip, port, "summary"),
      cgminerCommand(ip, port, "devs"),
    ]);

    const summary = summaryRes?.SUMMARY?.[0] || {};
    const dev = devsRes?.DEVS?.[0] || {};

    return {
      online: true,
      hashrate: summary["GHS av"] != null ? summary["GHS av"] : (summary["MHS av"] != null ? summary["MHS av"] : 0),
      hashrateUnit: summary["GHS av"] != null ? "GH/s" : "MH/s",
      temperature: dev.Temperature ?? summary.Temperature ?? 0,
      fanSpeed: dev["Fan Percent"] ?? 0,
      fanRpm: dev["Fan Speed"] ?? 0,
      power: 0,
      accepted: summary.Accepted ?? 0,
      rejected: summary.Rejected ?? 0,
      difficulty: summary["Difficulty Accepted"] ?? 0,
      bestDifficulty: String(summary["Best Share"] ?? 0),
      uptimeSeconds: summary.Elapsed ?? 0,
      poolUrl: "",
      chipModel: dev.Name ?? "Unknown ASIC",
      firmwareVersion: summaryRes?.VERSION?.[0]?.CGMiner ?? "Unknown",
      rawData: { summary: summaryRes, devs: devsRes },
    };
  } catch (e: any) {
    return { online: false, error: e.message };
  }
}

export async function getMinerStatus(ip: string, port: number, protocol: MinerProtocol): Promise<MinerStatus> {
  enforceIPValidation(ip);
  switch (protocol) {
    case "bitaxe":
      return getBitaxeStatus(ip, port);
    case "cgminer":
      return getCGMinerStatus(ip, port);
    case "vnish":
    case "braiins":
    case "generic_http":
      return getBitaxeStatus(ip, port);
    default:
      return { online: false, error: "Unsupported protocol" };
  }
}

export async function adjustBitaxe(
  ip: string,
  port: number,
  settings: { fanspeed?: number; autofanspeed?: number; frequency?: number; coreVoltage?: number }
): Promise<{ success: boolean; error?: string }> {
  try {
    enforceIPValidation(ip);
    await httpPatch(ip, port, "/api/system", settings);
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e.message };
  }
}

export async function restartMiner(ip: string, port: number, protocol: MinerProtocol): Promise<{ success: boolean; error?: string }> {
  try {
    enforceIPValidation(ip);
    if (protocol === "bitaxe" || protocol === "vnish" || protocol === "braiins" || protocol === "generic_http") {
      await httpPost(ip, port, "/api/system/restart");
    } else if (protocol === "cgminer") {
      await cgminerCommand(ip, port, "restart");
    }
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e.message };
  }
}

export async function identifyMiner(ip: string, port: number, protocol: MinerProtocol): Promise<{ success: boolean; error?: string }> {
  try {
    enforceIPValidation(ip);
    if (protocol === "bitaxe") {
      await httpPost(ip, port, "/api/system/identify");
    }
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e.message };
  }
}

export function computeAutoAdjustSettings(
  signal: string,
  windowScore: number,
  currentStatus: MinerStatus,
  protocol: MinerProtocol
): { action: string; settings?: any; reason: string } | null {
  if (protocol !== "bitaxe") {
    return null;
  }

  if (signal === "MINE" && windowScore >= 75) {
    return {
      action: "boost",
      settings: { autofanspeed: 1 },
      reason: `Strong mining window detected (score: ${windowScore}). Ensuring optimal cooling with auto-fan.`,
    };
  }

  if (signal === "WAIT" && windowScore < 40) {
    return {
      action: "conserve",
      settings: { autofanspeed: 1 },
      reason: `Weak mining window (score: ${windowScore}). Maintaining efficiency mode.`,
    };
  }

  if (currentStatus.temperature && currentStatus.temperature > 75) {
    return {
      action: "thermal_protect",
      settings: { fanspeed: 100, autofanspeed: 0 },
      reason: `High temperature detected (${currentStatus.temperature}°C). Setting fan to maximum.`,
    };
  }

  return null;
}

export async function scanSubnet(baseIp: string, startOctet: number, endOctet: number): Promise<Array<{ ip: string; protocol: MinerProtocol; port: number; info: any }>> {
  const parts = baseIp.split(".");
  if (parts.length !== 4) return [];

  const results: Array<{ ip: string; protocol: MinerProtocol; port: number; info: any }> = [];
  const prefix = parts.slice(0, 3).join(".");

  const scanPromises = [];
  for (let i = startOctet; i <= endOctet; i++) {
    const ip = `${prefix}.${i}`;
    scanPromises.push(
      autoDetectMiner(ip)
        .then((result) => {
          if (result) {
            results.push({ ip, ...result });
          }
        })
        .catch(() => {})
    );
  }

  await Promise.allSettled(scanPromises);
  return results;
}
