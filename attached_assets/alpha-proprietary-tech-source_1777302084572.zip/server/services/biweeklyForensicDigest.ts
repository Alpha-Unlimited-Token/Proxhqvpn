/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Bi-Weekly Forensic Digest Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_6ee39307332d20e21c8f704e
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

import { registerBeacon } from "./integrityBeacon.js";
import { getUncachableSendGridClient } from "./sendgridService.js";

export const _bfdSeal = 'AUT_6ee39307332d20e21c8f704e';
const _bfdIntegrityValid = registerBeacon('biweeklyForensicDigest', _bfdSeal);
if (!_bfdSeal?.startsWith('AUT_') || !_bfdIntegrityValid) {
  throw new Error('[SECURITY] Alpha Bi-Weekly Forensic Digest™ integrity verification failed — module sealed');
}

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

const DAU_V2_ADDRESS = "0x875D639ffE58c39324256be7E388Fc85921c76AB";
const DAU_V1_ADDRESS = "0xAB403962C943e3335903824BB2880A219858C5CC";
const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

const RECIPIENTS = [
  { email: "alphaunlimitedtoken@gmail.com", name: "Alpha Unlimited" },
  { email: "sillytuna@gmail.com", name: "@sillytuna (Alex Amsel)" },
  { email: "tips@securityalliance.org", name: "SEAL 911 Team" },
];

const KNOWN_ATTACKER_WALLETS = [
  "0x8e04af7f7c76daa9ab429b1340e0327b5b835748",
  "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3",
  "0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73",
  "0x83d10e4698efb8a0bd3cafad6c950572905d5ca1",
  "0x46af8e7a2ee01134d1757bc19607781dbd410e6b",
  "0x4d0f03b83650b33138764aaaf3da76861576ff98",
  "0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a",
  "0x1f04378f94313421ed1faaf4f6415de722bea5ea",
];

const WALLET_LABELS: Record<string, string> = {
  "0x8e04af7f7c76daa9ab429b1340e0327b5b835748": "Cashout Primary",
  "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3": "HOP-4 Consolidation",
  "0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73": "OTC/Bridge Service",
  "0x83d10e4698efb8a0bd3cafad6c950572905d5ca1": "Distribution EOA",
  "0x46af8e7a2ee01134d1757bc19607781dbd410e6b": "Circular Mixer",
  "0x4d0f03b83650b33138764aaaf3da76861576ff98": "KYC Bridge Wallet",
  "0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a": "KYC Bridge Wallet 2",
  "0x1f04378f94313421ed1faaf4f6415de722bea5ea": "Large-Value Intermediary",
  "0xa8e1960ab9234f56df6031dde4561a42c15812df": "HOP-1 Relay",
  "0x83d1754dd1315a433461a014da950422905d5ca1": "Address-Sim Relay",
  "0x46af83b6bee9bcfd4d31eed47a8c32adbd410e6b": "Address-Sim Mixer",
  "0x8e04d839f70619505ce7559396664d1b5b835748": "Mule (address-sim)",
  "0x8e041766f4cba3a298e27d1e3f7560f8d1375748": "Address-Sim Pipe",
  "0x83d1920d0b1a354fc1d81165af80a122905d5ca1": "Address-Sim Mule",
  "0xcfbbebc1471f458912b93a3b7468bd080f853230": "Downstream Relay A",
  "0xcfbbf8dc80bb324d2f8634cc73d6e8f6784d3230": "Downstream Relay B",
  "0xcfbb3bc7f46af91fd12368ab07963ef8689d3230": "Downstream Relay C",
  "0x5bbea8a4b36d1c897ac89726594ea1ce04608877": "Mule Pattern A",
  "0xb48522f1b6863f897d4a6dd04ef6a16c69499db1": "Mule Pattern B",
  "0xb485a81b220071e00d3ca4730b1ed569fd6dddb1": "Mule Pattern C",
  "0x2cc8d5e64c008f26db42848057519a06191d6f2f": "Mule Pattern D",
  "0x83d7ed598e805ad63ce27d777d8a77d2585d5ca1": "Address-Sim 85%",
  "0x4d0ffe81540f0755d70ede0d7430ae861576ff98": "Address-Sim 100%",
  "0x0016e313e598de1af2a67d3c869622a69634430c": "Mule Pattern E",
  "0x9a72643e82b7ed8db3d575c02621e91d8d06ba73": "Address-Sim OTC",
  "0x80d71876152b781a9b43ae6307819b1d66c0f90a": "Address-Sim KYC",
};

const ALL_TRACKED = Object.keys(WALLET_LABELS);

interface WalletSnapshot {
  address: string;
  label: string;
  ethBalance: number;
  txCount: number;
}

interface TransactionRecord {
  hash: string;
  from: string;
  to: string;
  value: string;
  blockNumber: number;
  timestamp: number;
  isIncoming: boolean;
  walletLabel: string;
}

interface DAUEvent {
  type: string;
  wallet: string;
  detail: string;
  blockNumber: number;
  txHash: string;
  timestamp: number;
}

interface DigestData {
  periodStart: Date;
  periodEnd: Date;
  walletSnapshots: WalletSnapshot[];
  transactions: TransactionRecord[];
  dauEvents: DAUEvent[];
  totalEthInNetwork: number;
  activeWallets: number;
  dormantWallets: number;
  newWalletsDetected: number;
}

let digestInterval: ReturnType<typeof setInterval> | null = null;
let lastDigestSentAt: Date = new Date();

async function alchemyRpc(method: string, params: any[]): Promise<any> {
  const res = await fetch(ALCHEMY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.result;
}

function fmtAddr(addr: string): string {
  if (!addr || addr.length < 14) return addr;
  return addr.slice(0, 8) + "..." + addr.slice(-6);
}

function fmtEth(wei: string | number): string {
  const eth = typeof wei === "string" ? parseInt(wei, 16) / 1e18 : wei;
  if (eth === 0) return "0 ETH";
  if (eth < 0.001) return eth.toFixed(6) + " ETH";
  if (eth < 1) return eth.toFixed(4) + " ETH";
  return eth.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 4 }) + " ETH";
}

function fmtDate(d: Date): string {
  return d.toLocaleString("en-US", { timeZone: "UTC", month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" }) + " UTC";
}

async function getWalletBalance(address: string): Promise<number> {
  try {
    const hex = await alchemyRpc("eth_getBalance", [address, "latest"]);
    return parseInt(hex, 16) / 1e18;
  } catch {
    return 0;
  }
}

async function getTransactionCount(address: string): Promise<number> {
  try {
    const hex = await alchemyRpc("eth_getTransactionCount", [address, "latest"]);
    return parseInt(hex, 16);
  } catch {
    return 0;
  }
}

async function getRecentTransactions(address: string, fromBlock: string): Promise<any[]> {
  try {
    const transfers = await fetch(ALCHEMY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0", id: 1,
        method: "alchemy_getAssetTransfers",
        params: [{
          fromBlock,
          toBlock: "latest",
          fromAddress: address,
          category: ["external", "erc20"],
          withMetadata: true,
          maxCount: "0x64",
        }]
      }),
    }).then(r => r.json());

    const received = await fetch(ALCHEMY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0", id: 2,
        method: "alchemy_getAssetTransfers",
        params: [{
          fromBlock,
          toBlock: "latest",
          toAddress: address,
          category: ["external", "erc20"],
          withMetadata: true,
          maxCount: "0x64",
        }]
      }),
    }).then(r => r.json());

    const outbound = (transfers.result?.transfers || []).map((t: any) => ({ ...t, isIncoming: false }));
    const inbound = (received.result?.transfers || []).map((t: any) => ({ ...t, isIncoming: true }));
    return [...outbound, ...inbound];
  } catch {
    return [];
  }
}

async function getDAUv2Events(fromBlock: string): Promise<DAUEvent[]> {
  const events: DAUEvent[] = [];
  try {
    const forensicMintTopic = "0x" + "ForensicMint".padEnd(64, "0").slice(0, 64);

    const logs = await alchemyRpc("eth_getLogs", [{
      fromBlock,
      toBlock: "latest",
      address: DAU_V2_ADDRESS,
    }]);

    for (const log of logs || []) {
      const topic0 = log.topics?.[0] || "";

      if (topic0 === "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef") {
        const from = "0x" + (log.topics?.[1] || "").slice(26);
        const to = "0x" + (log.topics?.[2] || "").slice(26);
        const value = parseInt(log.data, 16) / 1e18;
        const isZeroFrom = from === "0x0000000000000000000000000000000000000000";

        events.push({
          type: isZeroFrom ? "MINT" : "TRANSFER",
          wallet: to.toLowerCase(),
          detail: isZeroFrom
            ? `Minted ${value} DAU2 to ${fmtAddr(to)} (${WALLET_LABELS[to.toLowerCase()] || "unknown"})`
            : `Transfer ${value} DAU2: ${fmtAddr(from)} -> ${fmtAddr(to)}`,
          blockNumber: parseInt(log.blockNumber, 16),
          txHash: log.transactionHash,
          timestamp: 0,
        });
      }

      else if (topic0.startsWith("0x")) {
        const walletAddr = log.topics?.[1] ? "0x" + log.topics[1].slice(26) : "";
        events.push({
          type: "FORENSIC_EVENT",
          wallet: walletAddr.toLowerCase(),
          detail: `DAU v2 contract event (topic: ${topic0.slice(0, 10)}...) involving ${fmtAddr(walletAddr)}`,
          blockNumber: parseInt(log.blockNumber, 16),
          txHash: log.transactionHash,
          timestamp: 0,
        });
      }
    }
  } catch (e: any) {
    console.log(`[BiWeeklyDigest] Error fetching DAU events: ${e.message}`);
  }
  return events;
}

async function collectDigestData(since: Date): Promise<DigestData> {
  const now = new Date();
  console.log(`[BiWeeklyDigest] Collecting data from ${since.toISOString()} to ${now.toISOString()}`);

  const currentBlock = await alchemyRpc("eth_blockNumber", []);
  const currentBlockNum = parseInt(currentBlock, 16);

  const secondsSince = Math.floor((now.getTime() - since.getTime()) / 1000);
  const blocksSince = Math.ceil(secondsSince / 12);
  const fromBlockNum = Math.max(currentBlockNum - blocksSince, 0);
  const fromBlock = "0x" + fromBlockNum.toString(16);

  const walletSnapshots: WalletSnapshot[] = [];
  let totalEth = 0;
  let active = 0;
  let dormant = 0;

  for (const addr of ALL_TRACKED) {
    const bal = await getWalletBalance(addr);
    const txCount = await getTransactionCount(addr);
    walletSnapshots.push({
      address: addr,
      label: WALLET_LABELS[addr] || "Unknown",
      ethBalance: bal,
      txCount,
    });
    totalEth += bal;
    if (bal > 0 || txCount > 0) active++;
    else dormant++;
  }

  const allTransactions: TransactionRecord[] = [];
  const seen = new Set<string>();

  for (const addr of ALL_TRACKED) {
    const txs = await getRecentTransactions(addr, fromBlock);
    for (const tx of txs) {
      const key = `${tx.hash}-${tx.isIncoming}`;
      if (seen.has(key)) continue;
      seen.add(key);
      allTransactions.push({
        hash: tx.hash,
        from: tx.from || "",
        to: tx.to || "",
        value: tx.value ? `${tx.value} ${tx.asset || "ETH"}` : "0 ETH",
        blockNumber: parseInt(tx.blockNum, 16) || 0,
        timestamp: tx.metadata?.blockTimestamp ? new Date(tx.metadata.blockTimestamp).getTime() : 0,
        isIncoming: tx.isIncoming,
        walletLabel: WALLET_LABELS[addr] || addr.slice(0, 10),
      });
    }
  }

  allTransactions.sort((a, b) => b.timestamp - a.timestamp);

  const dauEvents = await getDAUv2Events(fromBlock);

  return {
    periodStart: since,
    periodEnd: now,
    walletSnapshots,
    transactions: allTransactions,
    dauEvents,
    totalEthInNetwork: totalEth,
    activeWallets: active,
    dormantWallets: dormant,
    newWalletsDetected: 0,
  };
}

function buildDigestHtml(data: DigestData): string {
  const periodStr = `${fmtDate(data.periodStart)} — ${fmtDate(data.periodEnd)}`;

  const highValueWallets = data.walletSnapshots
    .filter(w => w.ethBalance > 0.01)
    .sort((a, b) => b.ethBalance - a.ethBalance);

  const txRows = data.transactions.slice(0, 50).map(tx => {
    const fromLabel = WALLET_LABELS[tx.from.toLowerCase()] || fmtAddr(tx.from);
    const toLabel = WALLET_LABELS[tx.to.toLowerCase()] || fmtAddr(tx.to);
    const time = tx.timestamp ? new Date(tx.timestamp).toLocaleString("en-US", { timeZone: "UTC", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";
    const dirColor = tx.isIncoming ? "#10b981" : "#ef4444";
    const dirLabel = tx.isIncoming ? "IN" : "OUT";
    return `<tr>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#9ca3af;font-size:11px;">${time}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;"><span style="color:${dirColor};font-weight:bold;font-size:11px;">${dirLabel}</span></td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#e5e7eb;font-size:11px;">${fromLabel}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#e5e7eb;font-size:11px;">${toLabel}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#fbbf24;font-size:11px;text-align:right;">${tx.value}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;"><a href="https://etherscan.io/tx/${tx.hash}" style="color:#3b82f6;font-size:10px;text-decoration:none;">${tx.hash.slice(0, 10)}...</a></td>
    </tr>`;
  }).join("");

  const dauEventRows = data.dauEvents.slice(0, 30).map(ev => {
    const typeColor = ev.type === "MINT" ? "#10b981" : ev.type === "TRANSFER" ? "#f59e0b" : "#6366f1";
    return `<tr>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;"><span style="color:${typeColor};font-weight:bold;font-size:11px;">${ev.type}</span></td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#e5e7eb;font-size:11px;">${ev.detail}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;"><a href="https://etherscan.io/tx/${ev.txHash}" style="color:#3b82f6;font-size:10px;text-decoration:none;">${ev.txHash.slice(0, 10)}...</a></td>
    </tr>`;
  }).join("");

  const walletRows = highValueWallets.map(w => {
    const isKnown = KNOWN_ATTACKER_WALLETS.includes(w.address);
    const labelColor = isKnown ? "#ef4444" : "#f59e0b";
    return `<tr>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:${labelColor};font-size:12px;font-weight:bold;">${w.label}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;"><a href="https://etherscan.io/address/${w.address}" style="color:#3b82f6;font-size:11px;text-decoration:none;">${fmtAddr(w.address)}</a></td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#fbbf24;font-size:12px;text-align:right;font-weight:bold;">${fmtEth(w.ethBalance)}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #1f2937;color:#9ca3af;font-size:11px;text-align:right;">${w.txCount} txs</td>
    </tr>`;
  }).join("");

  const noActivityNote = data.transactions.length === 0 && data.dauEvents.length === 0
    ? `<tr><td colspan="6" style="padding:16px;color:#6b7280;text-align:center;font-style:italic;">No on-chain activity detected during this period. All tracked wallets remain in the same state.</td></tr>`
    : "";

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background-color:#0a0e17;font-family:Arial,Helvetica,sans-serif;color:#e5e7eb;">
<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0a0e17;padding:20px 0;">
<tr><td align="center">
<table width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;">

<tr><td style="background:linear-gradient(135deg,#0e1a2e,#1a2744);padding:24px 32px;border-radius:12px 12px 0 0;border-bottom:3px solid #f59e0b;">
  <table width="100%"><tr>
    <td>
      <span style="font-size:22px;font-weight:bold;color:#f59e0b;">Alpha Unlimited Trading</span><br>
      <span style="font-size:14px;color:#9ca3af;">DAU v2 Dye Pack Protocol — Bi-Weekly Intelligence Digest</span>
    </td>
    <td align="right" style="color:#9ca3af;font-size:12px;">
      Case: ${CASE_ID.slice(0, 8)}...<br>
      <span style="color:#f59e0b;font-weight:bold;">CONFIDENTIAL</span>
    </td>
  </tr></table>
</td></tr>

<tr><td style="background-color:#111827;padding:16px 32px;border-bottom:1px solid #1f2937;">
  <table width="100%"><tr>
    <td style="font-size:13px;color:#9ca3af;">Period: <span style="color:#FFFFFF;">${periodStr}</span></td>
    <td align="right">
      <span style="background:#14532d;color:#86efac;padding:3px 12px;border-radius:12px;font-size:12px;font-weight:bold;">${data.transactions.length} Transactions</span>
      <span style="background:#1e1b4b;color:#a5b4fc;padding:3px 12px;border-radius:12px;font-size:12px;font-weight:bold;margin-left:6px;">${data.dauEvents.length} DAU Events</span>
    </td>
  </tr></table>
</td></tr>

<tr><td style="background-color:#111827;padding:20px 32px;">
  <table width="100%" cellspacing="0" style="margin-bottom:16px;">
    <tr>
      <td style="width:25%;padding:12px;background:#0d1117;border-radius:8px;text-align:center;border:1px solid #1f2937;">
        <div style="font-size:24px;font-weight:bold;color:#f59e0b;">${data.walletSnapshots.length}</div>
        <div style="font-size:11px;color:#9ca3af;">Wallets Tracked</div>
      </td>
      <td style="width:4%;"></td>
      <td style="width:25%;padding:12px;background:#0d1117;border-radius:8px;text-align:center;border:1px solid #1f2937;">
        <div style="font-size:24px;font-weight:bold;color:#ef4444;">${fmtEth(data.totalEthInNetwork)}</div>
        <div style="font-size:11px;color:#9ca3af;">Total ETH in Network</div>
      </td>
      <td style="width:4%;"></td>
      <td style="width:25%;padding:12px;background:#0d1117;border-radius:8px;text-align:center;border:1px solid #1f2937;">
        <div style="font-size:24px;font-weight:bold;color:#10b981;">${data.activeWallets}</div>
        <div style="font-size:11px;color:#9ca3af;">Active Wallets</div>
      </td>
      <td style="width:4%;"></td>
      <td style="width:25%;padding:12px;background:#0d1117;border-radius:8px;text-align:center;border:1px solid #1f2937;">
        <div style="font-size:24px;font-weight:bold;color:#6b7280;">${data.dormantWallets}</div>
        <div style="font-size:11px;color:#9ca3af;">Dormant</div>
      </td>
    </tr>
  </table>
</td></tr>

${walletRows ? `
<tr><td style="background-color:#111827;padding:8px 32px 20px;">
  <div style="font-size:14px;font-weight:bold;color:#f59e0b;margin-bottom:10px;border-bottom:1px solid #1f2937;padding-bottom:8px;">WALLET BALANCES (ETH > 0.01)</div>
  <table width="100%" cellspacing="0" style="border-collapse:collapse;">
    <tr style="background:#0d1117;">
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;font-weight:bold;">Label</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;font-weight:bold;">Address</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;font-weight:bold;text-align:right;">Balance</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;font-weight:bold;text-align:right;">Nonce</td>
    </tr>
    ${walletRows}
  </table>
</td></tr>
` : ""}

${data.transactions.length > 0 ? `
<tr><td style="background-color:#111827;padding:8px 32px 20px;">
  <div style="font-size:14px;font-weight:bold;color:#3b82f6;margin-bottom:10px;border-bottom:1px solid #1f2937;padding-bottom:8px;">TRANSACTION LOG (${data.transactions.length} total${data.transactions.length > 50 ? ", showing top 50" : ""})</div>
  <table width="100%" cellspacing="0" style="border-collapse:collapse;">
    <tr style="background:#0d1117;">
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">Time</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">Dir</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">From</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">To</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;text-align:right;">Value</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">TX</td>
    </tr>
    ${txRows}
  </table>
</td></tr>
` : ""}

${data.dauEvents.length > 0 ? `
<tr><td style="background-color:#111827;padding:8px 32px 20px;">
  <div style="font-size:14px;font-weight:bold;color:#8b5cf6;margin-bottom:10px;border-bottom:1px solid #1f2937;padding-bottom:8px;">DAU v2 CONTRACT EVENTS (${data.dauEvents.length} total)</div>
  <table width="100%" cellspacing="0" style="border-collapse:collapse;">
    <tr style="background:#0d1117;">
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">Type</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">Detail</td>
      <td style="padding:6px 8px;color:#6b7280;font-size:10px;text-transform:uppercase;">TX</td>
    </tr>
    ${dauEventRows}
  </table>
</td></tr>
` : ""}

${noActivityNote ? `
<tr><td style="background-color:#111827;padding:8px 32px 20px;">
  <table width="100%" cellspacing="0" style="border-collapse:collapse;">
    ${noActivityNote}
  </table>
</td></tr>
` : ""}

<tr><td style="background-color:#111827;padding:12px 32px 20px;">
  <div style="background:#0d1117;border:1px solid #1f2937;border-radius:8px;padding:16px;">
    <div style="font-size:12px;font-weight:bold;color:#06b6d4;margin-bottom:8px;">DAU v2 CONTRACT STATUS</div>
    <table width="100%" cellspacing="0">
      <tr>
        <td style="padding:3px 0;color:#9ca3af;font-size:11px;">Contract</td>
        <td style="padding:3px 0;text-align:right;"><a href="https://etherscan.io/address/${DAU_V2_ADDRESS}" style="color:#3b82f6;font-size:11px;text-decoration:none;">${fmtAddr(DAU_V2_ADDRESS)}</a></td>
      </tr>
      <tr>
        <td style="padding:3px 0;color:#9ca3af;font-size:11px;">Soulbound Mode</td>
        <td style="padding:3px 0;text-align:right;color:#10b981;font-size:11px;font-weight:bold;">ENABLED</td>
      </tr>
      <tr>
        <td style="padding:3px 0;color:#9ca3af;font-size:11px;">Self-Propagation</td>
        <td style="padding:3px 0;text-align:right;color:#10b981;font-size:11px;font-weight:bold;">ACTIVE</td>
      </tr>
      <tr>
        <td style="padding:3px 0;color:#9ca3af;font-size:11px;">Wallets Tagged</td>
        <td style="padding:3px 0;text-align:right;color:#f59e0b;font-size:11px;font-weight:bold;">${ALL_TRACKED.length}</td>
      </tr>
    </table>
  </div>
</td></tr>

<tr><td style="background-color:#0a0e17;padding:16px 32px;border-radius:0 0 12px 12px;border-top:1px solid #1f2937;">
  <table width="100%"><tr>
    <td style="color:#4b5563;font-size:10px;">
      Alpha Unlimited Trading — Forensic Intelligence Division<br>
      Case: @sillytuna (Alex Amsel) EIP-7702 Exploit (~$26M)<br>
      This email is auto-generated every Wednesday and Saturday.
    </td>
    <td align="right" style="color:#4b5563;font-size:10px;">
      DAU v1: ${fmtAddr(DAU_V1_ADDRESS)}<br>
      DAU v2: ${fmtAddr(DAU_V2_ADDRESS)}<br>
      <a href="https://etherscan.io/address/${DAU_V2_ADDRESS}" style="color:#3b82f6;font-size:10px;">View on Etherscan</a>
    </td>
  </tr></table>
</td></tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

async function sendDigestEmail(): Promise<void> {
  try {
    const now = new Date();
    console.log(`[BiWeeklyDigest] Collecting forensic data since ${lastDigestSentAt.toISOString()}...`);

    const data = await collectDigestData(lastDigestSentAt);

    const html = buildDigestHtml(data);

    const dayName = now.toLocaleDateString("en-US", { weekday: "long", timeZone: "UTC" });
    const dateStr = now.toLocaleDateString("en-US", { timeZone: "UTC", month: "short", day: "numeric", year: "numeric" });
    const subject = `DAU v2 Dye Pack — ${dayName} Intelligence Digest — ${dateStr} — ${data.transactions.length} txs, ${data.dauEvents.length} events`;

    const { client: sgClient, fromEmail } = await getUncachableSendGridClient();

    for (const recipient of RECIPIENTS) {
      try {
        await sgClient.send({
          to: { email: recipient.email, name: recipient.name },
          from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
          subject,
          html,
          text: `DAU v2 Dye Pack Bi-Weekly Digest\nPeriod: ${fmtDate(data.periodStart)} - ${fmtDate(data.periodEnd)}\nTransactions: ${data.transactions.length}\nDAU Events: ${data.dauEvents.length}\nTotal ETH in network: ${fmtEth(data.totalEthInNetwork)}\nWallets tracked: ${data.walletSnapshots.length}\n\nView contract: https://etherscan.io/address/${DAU_V2_ADDRESS}`,
          trackingSettings: {
            clickTracking: { enable: false, enableText: false },
            openTracking: { enable: false },
          },
        } as any);
        console.log(`[BiWeeklyDigest] Sent to ${recipient.email} (${recipient.name})`);
      } catch (e: any) {
        console.error(`[BiWeeklyDigest] Failed to send to ${recipient.email}: ${e.message}`);
      }
    }

    lastDigestSentAt = now;
    console.log(`[BiWeeklyDigest] Digest complete. Next check in 1 hour.`);
  } catch (e: any) {
    console.error(`[BiWeeklyDigest] Error building digest: ${e.message}`);
  }
}

function isDigestDay(): boolean {
  const now = new Date();
  const utcDay = now.getUTCDay();
  const utcHour = now.getUTCHours();
  return (utcDay === 3 || utcDay === 6) && utcHour >= 14 && utcHour < 15;
}

function getNextDigestDate(): string {
  const now = new Date();
  const utcDay = now.getUTCDay();
  let daysUntilWed = (3 - utcDay + 7) % 7;
  let daysUntilSat = (6 - utcDay + 7) % 7;
  if (daysUntilWed === 0 && now.getUTCHours() >= 15) daysUntilWed = 7;
  if (daysUntilSat === 0 && now.getUTCHours() >= 15) daysUntilSat = 7;
  const nextDays = Math.min(daysUntilWed, daysUntilSat);
  const next = new Date(now);
  next.setUTCDate(next.getUTCDate() + nextDays);
  next.setUTCHours(14, 0, 0, 0);
  return next.toLocaleString("en-US", { timeZone: "UTC", weekday: "long", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) + " UTC";
}

let digestSentToday = false;

async function checkAndSendDigest(): Promise<void> {
  const now = new Date();
  const utcDay = now.getUTCDay();
  const utcHour = now.getUTCHours();

  if ((utcDay === 3 || utcDay === 6) && utcHour >= 14 && utcHour < 15) {
    if (!digestSentToday) {
      console.log(`[BiWeeklyDigest] It's digest day! Sending now...`);
      digestSentToday = true;
      await sendDigestEmail();
    }
  } else {
    digestSentToday = false;
  }
}

export async function startBiWeeklyDigest(): Promise<void> {
  if (digestInterval) return;

  const recipientList = RECIPIENTS.map(r => `${r.email} (${r.name})`).join(", ");
  console.log(`[BiWeeklyDigest] Starting bi-weekly forensic digest scheduler`);
  console.log(`[BiWeeklyDigest] Recipients: ${recipientList}`);
  console.log(`[BiWeeklyDigest] Schedule: Every Wednesday and Saturday at 2:00 PM UTC`);
  console.log(`[BiWeeklyDigest] Next digest: ${getNextDigestDate()}`);
  console.log(`[BiWeeklyDigest] Tracking ${ALL_TRACKED.length} wallets with DAU v2`);

  digestInterval = setInterval(() => {
    checkAndSendDigest().catch(e => console.error(`[BiWeeklyDigest] Check error: ${e.message}`));
  }, 60 * 60 * 1000);

  await checkAndSendDigest();
}

export async function sendDigestNow(): Promise<void> {
  console.log(`[BiWeeklyDigest] Manual digest trigger — sending immediately`);
  await sendDigestEmail();
}

export function stopBiWeeklyDigest(): void {
  if (digestInterval) {
    clearInterval(digestInterval);
    digestInterval = null;
    console.log(`[BiWeeklyDigest] Stopped`);
  }
}
