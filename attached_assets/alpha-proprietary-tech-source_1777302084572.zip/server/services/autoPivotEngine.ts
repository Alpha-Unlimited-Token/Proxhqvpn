/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Auto-Pivot Surveillance Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements the Alpha Auto-Pivot Surveillance Engine™ — a persistent wallet
 * surveillance system that locks onto wallet addresses after DAU token contact,
 * scans all holdings and transaction history, deploys spider beacons to every
 * connected address, and follows funds across swaps, bridges, and chain hops.
 *
 * Technologies Protected:
 * - Alpha Auto-Pivot Surveillance Engine™
 * - Wallet Leech Protocol™ (persistent address-level tracking)
 * - Token Holdings Spider™ (full portfolio enumeration)
 * - Swap Pivot Detection™ (DEX/exchange swap following)
 * - Cross-Chain Hop Tracker™ (bridge departure → destination pickup)
 * - Network Expansion Protocol™ (auto-discover and monitor connected wallets)
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 */

import crypto from "crypto";

const ALCHEMY_CHAINS: Record<string, { http: string; name: string }> = {
  ethereum: { http: 'https://eth-mainnet.g.alchemy.com/v2/', name: 'Ethereum Mainnet' },
  sepolia: { http: 'https://eth-sepolia.g.alchemy.com/v2/', name: 'Sepolia Testnet' },
  polygon: { http: 'https://polygon-mainnet.g.alchemy.com/v2/', name: 'Polygon' },
  arbitrum: { http: 'https://arb-mainnet.g.alchemy.com/v2/', name: 'Arbitrum One' },
  optimism: { http: 'https://opt-mainnet.g.alchemy.com/v2/', name: 'Optimism' },
  base: { http: 'https://base-mainnet.g.alchemy.com/v2/', name: 'Base' },
};

const KNOWN_DEX_ROUTERS: Record<string, string> = {
  '0x7a250d5630b4cf539739df2c5dacb4c659f2488d': 'Uniswap V2 Router',
  '0xe592427a0aece92de3edee1f18e0157c05861564': 'Uniswap V3 Router',
  '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45': 'Uniswap Universal Router',
  '0xef1c6e67703c7bd7107eed8303fbe6ec2554bf6b': 'Uniswap Universal Router V2',
  '0xd9e1ce17f2641f24ae83637ab66a2cca9c378b9f': 'SushiSwap Router',
  '0x1111111254eeb25477b68fb85ed929f73a960582': '1inch V5 Router',
  '0x1111111254fb6c44bac0bed2854e76f90643097d': '1inch V4 Router',
  '0xdef1c0ded9bec7f1a1670819833240f027b25eff': '0x Exchange Proxy',
  '0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad': 'Uniswap Universal Router V3',
  '0x9008d19f58aabd9ed0d60971565aa8510560ab41': 'CoW Protocol Settlement',
  '0x6131b5fae19ea4f9d964eac0408e4408b66337b5': 'KyberSwap Router',
  '0x881d40237659c251811cec9c364ef91dc08d300c': 'MetaMask Swap Router',
};

const KNOWN_BRIDGES: Record<string, { name: string; destinationChains: string[] }> = {
  '0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae': { name: 'LI.FI Diamond', destinationChains: ['arbitrum', 'optimism', 'polygon', 'base', 'bsc', 'avalanche'] },
  '0x2796317b0ff8538f253012862c06787adfb8ceb6': { name: 'Synapse Bridge', destinationChains: ['arbitrum', 'optimism', 'polygon', 'bsc', 'avalanche'] },
  '0x3a23f943181408eac424116af7b7790c94cb97a5': { name: 'Socket Gateway', destinationChains: ['arbitrum', 'optimism', 'polygon', 'base'] },
  '0xb8901acb165ed027e32754e0ffe830802919727f': { name: 'Hop Protocol', destinationChains: ['arbitrum', 'optimism', 'polygon'] },
  '0x99c9fc46f92e8a1c0dec1b1747d010903e884be1': { name: 'Optimism Gateway', destinationChains: ['optimism'] },
  '0x8315177ab297ba92a06054ce80a67ed4dbd7ed3a': { name: 'Arbitrum Gateway', destinationChains: ['arbitrum'] },
  '0x3154cf16ccdb4c6d922629664174b904d80f2c35': { name: 'Base Bridge', destinationChains: ['base'] },
  '0xc30141b657f4216252dc59af2e7cdb9d8792e1b0': { name: 'Socket V2', destinationChains: ['arbitrum', 'optimism', 'polygon', 'base'] },
  '0xe4edb277e41dc89ab076a1f049f4a3efa700bce8': { name: 'Orbiter Finance', destinationChains: ['arbitrum', 'optimism', 'base', 'polygon', 'zksync'] },
  '0x4c69bbaa383ee18993f635d72a8af16de1bdb779': { name: 'Across Bridge V3', destinationChains: ['arbitrum', 'optimism', 'polygon', 'base'] },
};

const KNOWN_EXCHANGES: Record<string, string> = {
  '0x28c6c06298d514db089934071355e5743bf21d60': 'Binance Hot Wallet',
  '0x21a31ee1afc51d94c2efccaa2092ad1028285549': 'Binance Hot Wallet 2',
  '0xdfd5293d8e347dfe59e90efd55b2956a1343963d': 'Binance Hot Wallet 3',
  '0x56eddb7aa87536c09ccc2793473599fd21a8b17f': 'Binance Hot Wallet 4',
  '0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43': 'Coinbase Hot Wallet',
  '0x503828976d22510aad0201ac7ec88293211d23da': 'Coinbase Hot Wallet 2',
  '0x71660c4005ba85c37ccec55d0c4493e66fe775d3': 'Coinbase Hot Wallet 3',
  '0x2910543af39aba0cd09dbb2d50200b3e800a63d2': 'Kraken Hot Wallet',
  '0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0': 'Kraken Hot Wallet 2',
  '0xf89d7b9c864f589bbf53a82105107622b35eaa40': 'Bybit Hot Wallet',
  '0x6cc5f688a315f3dc28a7781717a9a798a59fda7b': 'OKX Hot Wallet',
  '0x236f233dbd32e279a7e0cddf17293996ee23d345': 'OKX Hot Wallet 2',
  '0x0d0707963952f2fba59dd06f2b425ace40b492fe': 'Gate.io Hot Wallet',
  '0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23': 'Gate.io Hot Wallet 2',
  '0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88': 'MEXC Hot Wallet',
  '0xcfcc6fded9eb6e206ef30019f18f1a65b8893015': 'MEXC Hot Wallet 2',
  '0x876eabf441b2ee5b5b0554fd502a8e0600950cfa': 'Bitfinex Hot Wallet',
  '0x742d35cc6634c0532925a3b844bc9e7595f2bd1e': 'Bitfinex Hot Wallet 2',
  '0xeb2629a2734e272bcc07bda959863f316f4bd4cf': 'KuCoin Hot Wallet',
  '0xd89350284c7732163765b23338f2ff27449e0bf5': 'KuCoin Hot Wallet 2',
  '0xd24400ae8bfebb18ca49be86258a3c749cf46853': 'Gemini Hot Wallet',
  '0x6fc82a5fe25a5cdb58bc74600a40a69c065263f8': 'Gemini Hot Wallet 2',
  '0x61189da79177950a7272c88c6058b96d4bcd6be2': 'HTX (Huobi) Hot Wallet',
  '0xe93381fb4c4f14bda253907b18fad305d799cee7': 'HTX (Huobi) Hot Wallet 2',
  '0xfbb1b73c4f0bda4f67dca266ce6ef42f520fbb98': 'Bittrex Hot Wallet',
};

interface SurveillanceTarget {
  address: string;
  caseId: string;
  chain: string;
  reason: string;
  lockedAt: Date;
  lastScanned: Date | null;
  scanCount: number;
  discoveredVia: 'dau_contact' | 'transaction_link' | 'token_approval' | 'contract_interaction' | 'manual';
  parentAddress: string | null;
  depth: number;
  holdings: TokenHolding[];
  recentTransactions: TransactionRecord[];
  connectedAddresses: Set<string>;
  swapHistory: SwapRecord[];
  bridgeHistory: BridgeRecord[];
  exchangeDeposits: ExchangeDepositRecord[];
  riskScore: number;
  tags: string[];
}

interface TokenHolding {
  contractAddress: string;
  symbol: string;
  balance: string;
  chain: string;
  discoveredAt: Date;
}

interface TransactionRecord {
  hash: string;
  from: string;
  to: string;
  value: string;
  asset: string;
  category: 'external' | 'erc20' | 'erc721' | 'erc1155' | 'internal';
  blockNumber: number;
  timestamp: Date;
  direction: 'incoming' | 'outgoing';
}

interface SwapRecord {
  txHash: string;
  dex: string;
  tokenIn: string;
  tokenOut: string;
  amountIn: string;
  amountOut: string;
  timestamp: Date;
  pivotDeployed: boolean;
}

interface BridgeRecord {
  txHash: string;
  bridge: string;
  sourceChain: string;
  destinationChains: string[];
  amount: string;
  token: string;
  timestamp: Date;
  destinationMonitored: boolean;
}

interface ExchangeDepositRecord {
  txHash: string;
  exchange: string;
  amount: string;
  token: string;
  timestamp: Date;
  subpoenaReady: boolean;
  correlationData: {
    depositTime: string;
    depositAmount: string;
    estimatedWithdrawalWindow: string;
  };
}

interface PivotSignal {
  id: string;
  type: 'wallet_locked' | 'holdings_scanned' | 'swap_detected' | 'bridge_detected' | 'exchange_deposit' |
        'new_wallet_discovered' | 'cross_chain_pickup' | 'network_expanded' | 'token_approval_detected' | 'risk_escalation';
  sourceAddress: string;
  targetAddress: string | null;
  caseId: string;
  chain: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp: Date;
  details: Record<string, any>;
}

class AutoPivotEngine {
  private surveillanceNetwork: Map<string, SurveillanceTarget> = new Map();
  private pivotSignals: PivotSignal[] = [];
  private scanInterval: NodeJS.Timeout | null = null;
  private isRunning = false;
  private alchemyKey: string | null = null;
  private networkChain: string = 'ethereum';
  private spiderBeaconCallback: ((signal: any) => void) | null = null;
  private maxDepth = 5;
  private maxNetworkSize = 10000;
  private scanCooldownMs = 60000;
  private maxPivotSignals = 10000;
  private maxPerTargetHistory = 200;

  constructor() {
    this.alchemyKey = process.env.ALCHEMY_API_KEY || null;
    this.networkChain = process.env.ATC_NETWORK || 'ethereum';

    console.log('[AutoPivot] Alpha Auto-Pivot Surveillance Engine™ v1.0 initialized');
    console.log('[AutoPivot] Wallet Leech Protocol™ — ARMED');
    console.log('[AutoPivot] Token Holdings Spider™ — ACTIVE');
    console.log('[AutoPivot] Swap Pivot Detection™ — ACTIVE');
    console.log('[AutoPivot] Cross-Chain Hop Tracker™ — ACTIVE');
    console.log('[AutoPivot] Network Expansion Protocol™ — ACTIVE');
    console.log(`[AutoPivot] Monitoring ${Object.keys(KNOWN_DEX_ROUTERS).length} DEX routers`);
    console.log(`[AutoPivot] Monitoring ${Object.keys(KNOWN_BRIDGES).length} bridge contracts`);
    console.log(`[AutoPivot] Monitoring ${Object.keys(KNOWN_EXCHANGES).length} exchange hot wallets`);
    console.log(`[AutoPivot] Max surveillance depth: ${this.maxDepth} hops`);
    console.log(`[AutoPivot] Max network size: ${this.maxNetworkSize.toLocaleString()} addresses`);
  }

  setSpiderBeaconCallback(cb: (signal: any) => void) {
    this.spiderBeaconCallback = cb;
    console.log('[AutoPivot] Connected to Spider Beacon Protocol™');
  }

  async lockOnWallet(
    address: string,
    caseId: string,
    chain: string,
    reason: string,
    discoveredVia: SurveillanceTarget['discoveredVia'] = 'dau_contact',
    parentAddress: string | null = null,
    depth: number = 0
  ): Promise<SurveillanceTarget | null> {
    const normalized = address.toLowerCase();

    if (this.surveillanceNetwork.has(normalized)) {
      const existing = this.surveillanceNetwork.get(normalized)!;
      if (!existing.tags.includes(reason)) existing.tags.push(reason);
      return existing;
    }

    if (this.surveillanceNetwork.size >= this.maxNetworkSize) {
      console.log(`[AutoPivot] Network at max capacity (${this.maxNetworkSize}). Skipping ${normalized.slice(0, 10)}...`);
      return null;
    }

    if (depth > this.maxDepth) {
      console.log(`[AutoPivot] Max depth (${this.maxDepth}) reached for ${normalized.slice(0, 10)}... from parent ${parentAddress?.slice(0, 10)}...`);
      return null;
    }

    const target: SurveillanceTarget = {
      address: normalized,
      caseId,
      chain,
      reason,
      lockedAt: new Date(),
      lastScanned: null,
      scanCount: 0,
      discoveredVia,
      parentAddress,
      depth,
      holdings: [],
      recentTransactions: [],
      connectedAddresses: new Set(),
      swapHistory: [],
      bridgeHistory: [],
      exchangeDeposits: [],
      riskScore: discoveredVia === 'dau_contact' ? 80 : 50,
      tags: [reason],
    };

    this.surveillanceNetwork.set(normalized, target);

    this.emitPivotSignal({
      type: 'wallet_locked',
      sourceAddress: normalized,
      targetAddress: null,
      caseId,
      chain,
      severity: depth === 0 ? 'critical' : 'warning',
      details: {
        reason,
        discoveredVia,
        parentAddress,
        depth,
        networkSize: this.surveillanceNetwork.size,
      },
    });

    console.log(`[AutoPivot] 🔒 WALLET LOCKED: ${normalized.slice(0, 16)}... | Depth: ${depth} | Via: ${discoveredVia} | Network: ${this.surveillanceNetwork.size}`);

    await this.scanWallet(normalized);

    return target;
  }

  async scanWallet(address: string): Promise<void> {
    const target = this.surveillanceNetwork.get(address.toLowerCase());
    if (!target) return;

    if (!this.alchemyKey) {
      console.log(`[AutoPivot] No Alchemy key — limited scanning for ${address.slice(0, 10)}...`);
      return;
    }

    const now = Date.now();
    if (target.lastScanned && now - target.lastScanned.getTime() < this.scanCooldownMs) {
      return;
    }

    target.scanCount++;
    target.lastScanned = new Date();

    const chain = target.chain === 'sepolia' ? 'sepolia' : target.chain;
    const alchemyConfig = ALCHEMY_CHAINS[chain];
    if (!alchemyConfig) {
      console.log(`[AutoPivot] No Alchemy support for chain: ${chain}`);
      return;
    }

    const baseUrl = alchemyConfig.http + this.alchemyKey;

    try {
      await this.scanTokenHoldings(target, baseUrl);
    } catch (err: any) {
      console.log(`[AutoPivot] Holdings scan error for ${address.slice(0, 10)}...: ${err.message}`);
    }

    try {
      await this.scanTransactionHistory(target, baseUrl);
    } catch (err: any) {
      console.log(`[AutoPivot] TX history scan error for ${address.slice(0, 10)}...: ${err.message}`);
    }

    this.analyzeConnections(target);
    this.trimTargetHistory(target);

    console.log(`[AutoPivot] Scan #${target.scanCount} complete: ${target.address.slice(0, 10)}... | Holdings: ${target.holdings.length} | TXs: ${target.recentTransactions.length} | Connections: ${target.connectedAddresses.size}`);
  }

  private async scanTokenHoldings(target: SurveillanceTarget, baseUrl: string): Promise<void> {
    const response = await fetch(baseUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'alchemy_getTokenBalances',
        params: [target.address],
      }),
    });

    const data = await response.json() as any;

    if (data.result?.tokenBalances) {
      const nonZeroTokens = data.result.tokenBalances.filter(
        (t: any) => t.tokenBalance && t.tokenBalance !== '0x0' && t.tokenBalance !== '0x0000000000000000000000000000000000000000000000000000000000000000'
      );

      target.holdings = [];

      for (const token of nonZeroTokens) {
        const balance = BigInt(token.tokenBalance).toString();

        let symbol = 'UNKNOWN';
        try {
          const metaRes = await fetch(baseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0',
              id: 1,
              method: 'alchemy_getTokenMetadata',
              params: [token.contractAddress],
            }),
          });
          const metaData = await metaRes.json() as any;
          if (metaData.result?.symbol) symbol = metaData.result.symbol;
        } catch {}

        target.holdings.push({
          contractAddress: token.contractAddress,
          symbol,
          balance,
          chain: target.chain,
          discoveredAt: new Date(),
        });
      }

      if (nonZeroTokens.length > 0) {
        this.emitPivotSignal({
          type: 'holdings_scanned',
          sourceAddress: target.address,
          targetAddress: null,
          caseId: target.caseId,
          chain: target.chain,
          severity: 'info',
          details: {
            tokenCount: nonZeroTokens.length,
            tokens: target.holdings.map(h => `${h.symbol}: ${h.balance}`).slice(0, 20),
          },
        });
      }
    }
  }

  private async scanTransactionHistory(target: SurveillanceTarget, baseUrl: string): Promise<void> {
    const categories = ['external', 'erc20', 'erc721', 'erc1155', 'internal'];

    for (const direction of ['from', 'to'] as const) {
      try {
        const response = await fetch(baseUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'alchemy_getAssetTransfers',
            params: [{
              [direction === 'from' ? 'fromAddress' : 'toAddress']: target.address,
              category: categories,
              maxCount: '0x64',
              order: 'desc',
              withMetadata: true,
            }],
          }),
        });

        const data = await response.json() as any;

        if (data.result?.transfers) {
          for (const tx of data.result.transfers) {
            const record: TransactionRecord = {
              hash: tx.hash,
              from: (tx.from || '').toLowerCase(),
              to: (tx.to || '').toLowerCase(),
              value: tx.value?.toString() || '0',
              asset: tx.asset || 'ETH',
              category: tx.category || 'external',
              blockNumber: parseInt(tx.blockNum, 16) || 0,
              timestamp: tx.metadata?.blockTimestamp ? new Date(tx.metadata.blockTimestamp) : new Date(),
              direction: direction === 'from' ? 'outgoing' : 'incoming',
            };

            const exists = target.recentTransactions.some(t => t.hash === record.hash && t.direction === record.direction);
            if (!exists) {
              target.recentTransactions.push(record);
            }

            const counterparty = direction === 'from' ? record.to : record.from;
            if (counterparty && counterparty !== '0x0000000000000000000000000000000000000000') {
              target.connectedAddresses.add(counterparty);

              this.checkForSwap(target, record);
              this.checkForBridge(target, record);
              this.checkForExchangeDeposit(target, record);
            }
          }
        }
      } catch (err: any) {
        console.log(`[AutoPivot] ${direction} TX scan error: ${err.message}`);
      }
    }

    target.recentTransactions.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    if (target.recentTransactions.length > 500) {
      target.recentTransactions = target.recentTransactions.slice(0, 500);
    }
  }

  private checkForSwap(target: SurveillanceTarget, tx: TransactionRecord): void {
    const toAddr = tx.to.toLowerCase();
    const dexName = KNOWN_DEX_ROUTERS[toAddr];
    if (!dexName && tx.direction !== 'outgoing') return;
    if (!dexName) return;

    const existingSwap = target.swapHistory.find(s => s.txHash === tx.hash);
    if (existingSwap) return;

    const swap: SwapRecord = {
      txHash: tx.hash,
      dex: dexName,
      tokenIn: tx.asset || 'ETH',
      tokenOut: 'PENDING_ANALYSIS',
      amountIn: tx.value,
      amountOut: '0',
      timestamp: tx.timestamp,
      pivotDeployed: false,
    };

    target.swapHistory.push(swap);
    target.riskScore = Math.min(100, target.riskScore + 10);

    this.emitPivotSignal({
      type: 'swap_detected',
      sourceAddress: target.address,
      targetAddress: toAddr,
      caseId: target.caseId,
      chain: target.chain,
      severity: 'critical',
      details: {
        dex: dexName,
        tokenIn: swap.tokenIn,
        amountIn: swap.amountIn,
        txHash: tx.hash,
        message: `Swap detected on ${dexName}. Pivoting to track output token.`,
      },
    });

    console.log(`[AutoPivot] 🔄 SWAP DETECTED: ${target.address.slice(0, 10)}... used ${dexName} | ${swap.amountIn} ${swap.tokenIn} | TX: ${tx.hash.slice(0, 16)}...`);
  }

  private checkForBridge(target: SurveillanceTarget, tx: TransactionRecord): void {
    const toAddr = tx.to.toLowerCase();
    const bridge = KNOWN_BRIDGES[toAddr];
    if (!bridge || tx.direction !== 'outgoing') return;

    const existingBridge = target.bridgeHistory.find(b => b.txHash === tx.hash);
    if (existingBridge) return;

    const bridgeRecord: BridgeRecord = {
      txHash: tx.hash,
      bridge: bridge.name,
      sourceChain: target.chain,
      destinationChains: bridge.destinationChains,
      amount: tx.value,
      token: tx.asset || 'ETH',
      timestamp: tx.timestamp,
      destinationMonitored: false,
    };

    target.bridgeHistory.push(bridgeRecord);
    target.riskScore = Math.min(100, target.riskScore + 15);

    this.emitPivotSignal({
      type: 'bridge_detected',
      sourceAddress: target.address,
      targetAddress: toAddr,
      caseId: target.caseId,
      chain: target.chain,
      severity: 'critical',
      details: {
        bridge: bridge.name,
        sourceChain: target.chain,
        destinationChains: bridge.destinationChains,
        amount: tx.value,
        token: tx.asset,
        txHash: tx.hash,
        message: `Bridge departure via ${bridge.name}. Deploying monitors on ${bridge.destinationChains.join(', ')}.`,
      },
    });

    console.log(`[AutoPivot] 🌉 BRIDGE DETECTED: ${target.address.slice(0, 10)}... → ${bridge.name} | ${tx.value} ${tx.asset} | Destinations: ${bridge.destinationChains.join(', ')}`);

    for (const destChain of bridge.destinationChains) {
      this.lockOnWallet(
        target.address,
        target.caseId,
        destChain,
        `Cross-chain pickup from ${target.chain} via ${bridge.name}`,
        'transaction_link',
        target.address,
        target.depth
      ).catch(() => {});
    }

    bridgeRecord.destinationMonitored = true;
  }

  private checkForExchangeDeposit(target: SurveillanceTarget, tx: TransactionRecord): void {
    const toAddr = tx.to.toLowerCase();
    const exchangeName = KNOWN_EXCHANGES[toAddr];
    if (!exchangeName || tx.direction !== 'outgoing') return;

    const existingDeposit = target.exchangeDeposits.find(d => d.txHash === tx.hash);
    if (existingDeposit) return;

    const deposit: ExchangeDepositRecord = {
      txHash: tx.hash,
      exchange: exchangeName,
      amount: tx.value,
      token: tx.asset || 'ETH',
      timestamp: tx.timestamp,
      subpoenaReady: true,
      correlationData: {
        depositTime: tx.timestamp.toISOString(),
        depositAmount: `${tx.value} ${tx.asset || 'ETH'}`,
        estimatedWithdrawalWindow: `${tx.timestamp.toISOString()} to ${new Date(tx.timestamp.getTime() + 3600000).toISOString()}`,
      },
    };

    target.exchangeDeposits.push(deposit);
    target.riskScore = Math.min(100, target.riskScore + 20);

    this.emitPivotSignal({
      type: 'exchange_deposit',
      sourceAddress: target.address,
      targetAddress: toAddr,
      caseId: target.caseId,
      chain: target.chain,
      severity: 'critical',
      details: {
        exchange: exchangeName,
        amount: tx.value,
        token: tx.asset,
        txHash: tx.hash,
        subpoenaReady: true,
        correlationData: deposit.correlationData,
        message: `EXCHANGE DEPOSIT: ${tx.value} ${tx.asset} sent to ${exchangeName}. Subpoena target identified.`,
      },
    });

    console.log(`[AutoPivot] 🏦 EXCHANGE DEPOSIT: ${target.address.slice(0, 10)}... → ${exchangeName} | ${tx.value} ${tx.asset} | SUBPOENA TARGET ✓`);
  }

  private trimTargetHistory(target: SurveillanceTarget): void {
    if (target.recentTransactions.length > this.maxPerTargetHistory) {
      target.recentTransactions = target.recentTransactions.slice(0, this.maxPerTargetHistory);
    }
    if (target.swapHistory.length > this.maxPerTargetHistory) {
      target.swapHistory = target.swapHistory.slice(-this.maxPerTargetHistory);
    }
    if (target.bridgeHistory.length > this.maxPerTargetHistory) {
      target.bridgeHistory = target.bridgeHistory.slice(-this.maxPerTargetHistory);
    }
    if (target.exchangeDeposits.length > this.maxPerTargetHistory) {
      target.exchangeDeposits = target.exchangeDeposits.slice(-this.maxPerTargetHistory);
    }
    if (target.connectedAddresses.size > 5000) {
      const arr = Array.from(target.connectedAddresses);
      target.connectedAddresses = new Set(arr.slice(0, 5000));
    }
  }

  private analyzeConnections(target: SurveillanceTarget): void {
    const newAddresses: string[] = [];
    const connectedArray = Array.from(target.connectedAddresses);

    for (const addr of connectedArray) {
      if (this.surveillanceNetwork.has(addr)) continue;

      const isExchange = !!KNOWN_EXCHANGES[addr];
      const isDex = !!KNOWN_DEX_ROUTERS[addr];
      const isBridge = !!KNOWN_BRIDGES[addr];

      if (isExchange || isDex || isBridge) continue;

      const txCount = target.recentTransactions.filter(
        tx => tx.from === addr || tx.to === addr
      ).length;

      if (txCount >= 2 || target.depth === 0) {
        newAddresses.push(addr);
      }
    }

    if (newAddresses.length > 0 && target.depth < this.maxDepth) {
      const toExpand = newAddresses.slice(0, 50);

      for (const addr of toExpand) {
        this.lockOnWallet(
          addr,
          target.caseId,
          target.chain,
          `Connected to ${target.address.slice(0, 10)}... (${target.recentTransactions.filter(tx => tx.from === addr || tx.to === addr).length} interactions)`,
          'transaction_link',
          target.address,
          target.depth + 1
        ).catch(() => {});
      }

      this.emitPivotSignal({
        type: 'network_expanded',
        sourceAddress: target.address,
        targetAddress: null,
        caseId: target.caseId,
        chain: target.chain,
        severity: 'warning',
        details: {
          newAddressesAdded: toExpand.length,
          totalNetworkSize: this.surveillanceNetwork.size,
          addresses: toExpand.map(a => a.slice(0, 16) + '...'),
        },
      });

      console.log(`[AutoPivot] 🕸️ NETWORK EXPANDED: ${toExpand.length} new addresses added from ${target.address.slice(0, 10)}... | Total network: ${this.surveillanceNetwork.size}`);
    }
  }

  async handleDAUContact(fromAddress: string, toAddress: string, amount: string, txHash: string, caseId: string = 'ON_CHAIN_ATC', chain?: string): Promise<void> {
    const targetChain = chain || this.networkChain;
    console.log(`[AutoPivot] 🎯 DAU CONTACT DETECTED: ${fromAddress.slice(0, 10)}... → ${toAddress.slice(0, 10)}... | ${amount} DAU | Chain: ${targetChain}`);

    await this.lockOnWallet(
      fromAddress,
      caseId,
      targetChain,
      `DAU sender — ${amount} DAU sent to ${toAddress.slice(0, 10)}...`,
      'dau_contact',
      null,
      0
    );

    await this.lockOnWallet(
      toAddress,
      caseId,
      targetChain,
      `DAU receiver — ${amount} DAU received from ${fromAddress.slice(0, 10)}...`,
      'dau_contact',
      fromAddress.toLowerCase(),
      0
    );
  }

  startPeriodicScan(intervalMs: number = 300000): void {
    if (this.isRunning) return;
    this.isRunning = true;

    console.log(`[AutoPivot] Starting periodic surveillance scan (every ${intervalMs / 1000}s)`);

    this.scanInterval = setInterval(async () => {
      const targets = Array.from(this.surveillanceNetwork.values());
      const stale = targets.filter(t => {
        if (!t.lastScanned) return true;
        return Date.now() - t.lastScanned.getTime() > intervalMs;
      }).sort((a, b) => b.riskScore - a.riskScore);

      const batch = stale.slice(0, 10);

      if (batch.length > 0) {
        console.log(`[AutoPivot] Surveillance cycle: scanning ${batch.length}/${targets.length} targets`);
        for (const target of batch) {
          await this.scanWallet(target.address);
        }
      }
    }, intervalMs);
  }

  stopPeriodicScan(): void {
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
    this.isRunning = false;
    console.log('[AutoPivot] Periodic scan stopped');
  }

  private emitPivotSignal(params: Omit<PivotSignal, 'id' | 'timestamp'>): PivotSignal {
    const signal: PivotSignal = {
      ...params,
      id: `PIVOT_${crypto.randomBytes(8).toString('hex').toUpperCase()}`,
      timestamp: new Date(),
    };

    this.pivotSignals.push(signal);
    if (this.pivotSignals.length > this.maxPivotSignals) {
      this.pivotSignals = this.pivotSignals.slice(-this.maxPivotSignals);
    }

    if (this.spiderBeaconCallback) {
      try {
        this.spiderBeaconCallback(signal);
      } catch {}
    }

    return signal;
  }

  getTarget(address: string): SurveillanceTarget | null {
    return this.surveillanceNetwork.get(address.toLowerCase()) || null;
  }

  getNetworkForCase(caseId: string): SurveillanceTarget[] {
    return Array.from(this.surveillanceNetwork.values()).filter(t => t.caseId === caseId);
  }

  getPivotSignals(caseId?: string, limit: number = 100): PivotSignal[] {
    let filtered = caseId ? this.pivotSignals.filter(s => s.caseId === caseId) : [...this.pivotSignals];
    filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return filtered.slice(0, limit);
  }

  getStats() {
    const targets = Array.from(this.surveillanceNetwork.values());
    const highRisk = targets.filter(t => t.riskScore >= 70);
    const depths = targets.map(t => t.depth);
    const maxDepthReached = depths.length > 0 ? Math.max(...depths) : 0;

    const totalSwaps = targets.reduce((sum, t) => sum + t.swapHistory.length, 0);
    const totalBridges = targets.reduce((sum, t) => sum + t.bridgeHistory.length, 0);
    const totalExchangeDeposits = targets.reduce((sum, t) => sum + t.exchangeDeposits.length, 0);
    const totalHoldings = targets.reduce((sum, t) => sum + t.holdings.length, 0);
    const totalConnections = targets.reduce((sum, t) => sum + t.connectedAddresses.size, 0);

    const discoveryBreakdown: Record<string, number> = {};
    for (const t of targets) {
      discoveryBreakdown[t.discoveredVia] = (discoveryBreakdown[t.discoveredVia] || 0) + 1;
    }

    return {
      networkSize: targets.length,
      highRiskTargets: highRisk.length,
      maxDepthReached,
      totalPivotSignals: this.pivotSignals.length,
      totalSwapsDetected: totalSwaps,
      totalBridgesDetected: totalBridges,
      totalExchangeDeposits,
      subpoenaTargets: totalExchangeDeposits,
      totalTokenHoldings: totalHoldings,
      totalConnections,
      discoveryBreakdown,
      isRunning: this.isRunning,
      dexRoutersMonitored: Object.keys(KNOWN_DEX_ROUTERS).length,
      bridgeContractsMonitored: Object.keys(KNOWN_BRIDGES).length,
      exchangeWalletsMonitored: Object.keys(KNOWN_EXCHANGES).length,
      casesMonitored: new Set(targets.map(t => t.caseId)).size,
    };
  }

  getWalletIntelligenceReport(address: string): Record<string, any> | null {
    const target = this.surveillanceNetwork.get(address.toLowerCase());
    if (!target) return null;

    return {
      address: target.address,
      caseId: target.caseId,
      chain: target.chain,
      riskScore: target.riskScore,
      lockedAt: target.lockedAt.toISOString(),
      lastScanned: target.lastScanned?.toISOString() || null,
      scanCount: target.scanCount,
      discoveredVia: target.discoveredVia,
      parentAddress: target.parentAddress,
      depth: target.depth,
      tags: target.tags,
      holdings: target.holdings,
      recentTransactions: target.recentTransactions.slice(0, 50),
      connectedAddresses: Array.from(target.connectedAddresses).slice(0, 100),
      swapHistory: target.swapHistory,
      bridgeHistory: target.bridgeHistory,
      exchangeDeposits: target.exchangeDeposits,
      networkNeighbors: Array.from(target.connectedAddresses)
        .filter(a => this.surveillanceNetwork.has(a))
        .map(a => ({
          address: a,
          riskScore: this.surveillanceNetwork.get(a)!.riskScore,
          depth: this.surveillanceNetwork.get(a)!.depth,
        })),
    };
  }
}

export const autoPivotEngine = new AutoPivotEngine();
export { AutoPivotEngine };
