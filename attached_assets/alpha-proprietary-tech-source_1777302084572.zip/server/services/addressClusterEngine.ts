/**
   * PROPRIETARY AND CONFIDENTIAL
   * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
   * Alpha Address Cluster Engine™ is proprietary technology. Patent Pending.
   * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
   * Protected by international copyright and trade secret laws.
   * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
   *
   * This module implements proprietary blockchain address clustering and entity resolution technology.
   * Part of the Alpha Unlimited Trading™ ecosystem.
   *
   * Technologies Protected:
   * - Address Cluster Engine™
 * - Entity Resolution Algorithm™
 * - Behavioral Pattern Matching™
 * - Cross-Chain Address Linkage System™
   *
   * Patent Pending. Trade Secret Protected. DMCA Protected.
   * Module Hash: AUT_c31d3b58fd7f0549ccbd465e
   * Integrity Beacon: ACTIVE
   * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
   */

  import { registerBeacon } from "./integrityBeacon.js";
import { lookupAddress, type AddressLabel } from "./addressLabelDatabase.js";


export const _aceCalibration = 'AUT_c31d3b58fd7f0549ccbd465e';
const _aceIntegrityValid = registerBeacon('addressClusterEngine', _aceCalibration);
if (!_aceCalibration?.startsWith('AUT_') || !_aceIntegrityValid) {
  throw new Error('[SECURITY] Alpha Address Cluster Engine™ integrity verification failed — module sealed');
}

export interface AddressCluster {
  clusterId: string;
  addresses: string[];
  labels: (AddressLabel | null)[];
  confidence: number;
  heuristic: string;
  entityName?: string;
}

interface BlockscoutTx {
  hash: string;
  from?: { hash: string };
  to?: { hash: string };
  value: string;
  timestamp: string;
}

const CHAIN_URLS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com",
  arbitrum: "https://arbitrum.blockscout.com",
  optimism: "https://optimism.blockscout.com",
  base: "https://base.blockscout.com",
  polygon: "https://polygon.blockscout.com",
  gnosis: "https://gnosis.blockscout.com",
  bsc: "https://bsc.blockscout.com",
};

const clusterCache = new Map<string, AddressCluster>();

async function fetchAddressTransactions(address: string, chain: string = "ethereum", limit: number = 50): Promise<BlockscoutTx[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/transactions?limit=${limit}`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.items || [];
  } catch { return []; }
}

async function fetchInternalTransactions(address: string, chain: string = "ethereum", limit: number = 50): Promise<any[]> {
  const baseUrl = CHAIN_URLS[chain] || CHAIN_URLS.ethereum;
  try {
    const resp = await fetch(`${baseUrl}/api/v2/addresses/${address}/internal-transactions?limit=${limit}`, {
      signal: AbortSignal.timeout(12000)
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.items || [];
  } catch { return []; }
}

export async function clusterByCommonFunding(address: string, chain: string = "ethereum"): Promise<AddressCluster> {
  const cacheKey = `funding:${chain}:${address.toLowerCase()}`;
  if (clusterCache.has(cacheKey)) return clusterCache.get(cacheKey)!;

  const txs = await fetchAddressTransactions(address, chain);
  const internalTxs = await fetchInternalTransactions(address, chain);

  const fundingSources = new Set<string>();
  const fundedSiblings = new Set<string>();
  fundedSiblings.add(address.toLowerCase());

  for (const tx of txs) {
    const from = tx.from?.hash?.toLowerCase();
    const to = tx.to?.hash?.toLowerCase();
    if (to === address.toLowerCase() && from) {
      fundingSources.add(from);
    }
  }

  for (const itx of internalTxs) {
    const from = itx.from?.hash?.toLowerCase();
    const to = itx.to?.hash?.toLowerCase();
    if (to === address.toLowerCase() && from) {
      fundingSources.add(from);
    }
  }

  for (const source of fundingSources) {
    const label = lookupAddress(source);
    if (label && (label.category === "exchange" || label.category === "dex" || label.category === "bridge")) continue;

    try {
      const sourceTxs = await fetchAddressTransactions(source, chain, 100);
      for (const tx of sourceTxs) {
        const from = tx.from?.hash?.toLowerCase();
        const to = tx.to?.hash?.toLowerCase();
        if (from === source && to && to !== address.toLowerCase()) {
          const toLabel = lookupAddress(to);
          if (!toLabel || (toLabel.category !== "exchange" && toLabel.category !== "dex")) {
            fundedSiblings.add(to);
          }
        }
      }
    } catch {}

    await new Promise(r => setTimeout(r, 300));

    if (fundedSiblings.size > 25) break;
  }

  const addresses = Array.from(fundedSiblings).slice(0, 50);
  const labels = addresses.map(a => lookupAddress(a));

  const cluster: AddressCluster = {
    clusterId: `cluster_${address.slice(2, 10).toLowerCase()}`,
    addresses,
    labels,
    confidence: fundingSources.size > 0 ? Math.min(0.85, 0.5 + fundingSources.size * 0.1) : 0.3,
    heuristic: "common-funding-source",
    entityName: labels.find(l => l !== null)?.name
  };

  clusterCache.set(cacheKey, cluster);
  return cluster;
}

export async function clusterByBehavior(address: string, chain: string = "ethereum"): Promise<AddressCluster> {
  const cacheKey = `behavior:${chain}:${address.toLowerCase()}`;
  if (clusterCache.has(cacheKey)) return clusterCache.get(cacheKey)!;

  const txs = await fetchAddressTransactions(address, chain, 100);

  const interacted = new Map<string, number>();
  for (const tx of txs) {
    const from = tx.from?.hash?.toLowerCase();
    const to = tx.to?.hash?.toLowerCase();
    const counterparty = from === address.toLowerCase() ? to : from;
    if (!counterparty) continue;
    const label = lookupAddress(counterparty);
    if (label && (label.category === "exchange" || label.category === "dex" || label.category === "bridge" || label.category === "token")) continue;
    interacted.set(counterparty, (interacted.get(counterparty) || 0) + 1);
  }

  const frequentPeers = Array.from(interacted.entries())
    .filter(([_, count]) => count >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([addr]) => addr);

  const addresses = [address.toLowerCase(), ...frequentPeers];
  const labels = addresses.map(a => lookupAddress(a));

  const cluster: AddressCluster = {
    clusterId: `behav_${address.slice(2, 10).toLowerCase()}`,
    addresses,
    labels,
    confidence: frequentPeers.length > 3 ? 0.7 : frequentPeers.length > 0 ? 0.5 : 0.2,
    heuristic: "behavioral-pattern",
    entityName: labels.find(l => l !== null)?.name
  };

  clusterCache.set(cacheKey, cluster);
  return cluster;
}

export async function clusterByTimingPattern(address: string, chain: string = "ethereum"): Promise<AddressCluster> {
  const cacheKey = `timing:${chain}:${address.toLowerCase()}`;
  if (clusterCache.has(cacheKey)) return clusterCache.get(cacheKey)!;

  const txs = await fetchAddressTransactions(address, chain, 100);

  const outgoing = txs.filter(tx => tx.from?.hash?.toLowerCase() === address.toLowerCase());

  const rapidRecipients = new Set<string>();
  rapidRecipients.add(address.toLowerCase());

  for (let i = 0; i < outgoing.length - 1; i++) {
    const t1 = new Date(outgoing[i].timestamp).getTime();
    const t2 = new Date(outgoing[i + 1].timestamp).getTime();
    if (Math.abs(t1 - t2) < 300000) {
      const to1 = outgoing[i].to?.hash?.toLowerCase();
      const to2 = outgoing[i + 1].to?.hash?.toLowerCase();
      if (to1) rapidRecipients.add(to1);
      if (to2) rapidRecipients.add(to2);
    }
  }

  const addresses = Array.from(rapidRecipients).slice(0, 30);
  const labels = addresses.map(a => lookupAddress(a));

  const cluster: AddressCluster = {
    clusterId: `timing_${address.slice(2, 10).toLowerCase()}`,
    addresses,
    labels,
    confidence: rapidRecipients.size > 5 ? 0.75 : rapidRecipients.size > 2 ? 0.55 : 0.3,
    heuristic: "rapid-timing-pattern",
    entityName: labels.find(l => l !== null)?.name
  };

  clusterCache.set(cacheKey, cluster);
  return cluster;
}

export async function fullClusterAnalysis(address: string, chain: string = "ethereum"): Promise<{
  address: string;
  chain: string;
  clusters: AddressCluster[];
  totalLinkedAddresses: number;
  mergedAddresses: string[];
  knownEntities: AddressLabel[];
}> {
  const [funding, behavior, timing] = await Promise.all([
    clusterByCommonFunding(address, chain),
    clusterByBehavior(address, chain),
    clusterByTimingPattern(address, chain)
  ]);

  const allAddresses = new Set<string>();
  for (const cluster of [funding, behavior, timing]) {
    for (const addr of cluster.addresses) {
      allAddresses.add(addr);
    }
  }

  const merged = Array.from(allAddresses);
  const knownEntities = merged.map(a => lookupAddress(a)).filter((l): l is AddressLabel => l !== null);

  return {
    address: address.toLowerCase(),
    chain,
    clusters: [funding, behavior, timing],
    totalLinkedAddresses: merged.length,
    mergedAddresses: merged,
    knownEntities
  };
}

console.log("[ClusterEngine] Alpha Address Clustering Engine™ initialized");
console.log("[ClusterEngine] Heuristics: common-funding-source, behavioral-pattern, rapid-timing-pattern");
