/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Universal Forensics Engine™ (powered by UCAL)
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws (Title 17 / DMCA / CFAA / DTSA).
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Patent Pending. Trade Secret Protected.
 *
 * Closes the chain-coverage gap that previously limited Multi-Chain Wallet Tracer™,
 * Forensic Spider™, Auto-Pivot Surveillance Engine™ and Amount Correlation Scanner™
 * to EVM-only. This module exposes universal (any-chain) versions of those primitives
 * by routing through the Alpha Universal Chain Adapter Layer™ (UCAL).
 *
 * Supported chains: Ethereum, Polygon, Arbitrum, Optimism, Base, Solana, Bitcoin, Tron, TON.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
import {
  getAdapter,
  detectChainsForAddress,
  probeAddressOnAllChains,
  SUPPORTED_CHAINS,
} from './chain-adapters/index.js';
import type { ChainKey, UnifiedTransfer, AddressProfile, CounterpartyAggregate } from './chain-adapters/types.js';

enforceProprietaryLicense('Alpha Universal Forensics Engine™');

/* =====================================================================================
 * Multi-Chain Wallet Tracer™ — Universal
 * ===================================================================================== */

export interface UniversalWalletTrace {
  address: string;
  chain: ChainKey;
  detectedFromAddress?: ChainKey[];
  profile: AddressProfile;
  recentTransfers: UnifiedTransfer[];
  counterparties: CounterpartyAggregate[];
  generatedAt: string;
  proprietaryHeader: string;
}

export async function traceWalletUniversal(
  address: string,
  chain?: ChainKey,
  opts: { transferLimit?: number; counterpartyLimit?: number } = {}
): Promise<UniversalWalletTrace> {
  let resolvedChain: ChainKey | undefined = chain;
  let detected: ChainKey[] | undefined;
  if (!resolvedChain) {
    detected = detectChainsForAddress(address);
    if (detected.length === 0) throw new Error(`No supported chain matches address shape: ${address}`);
    // For ambiguous (EVM-shaped) addresses, default to Ethereum
    resolvedChain = detected.includes('ethereum') ? 'ethereum' : detected[0];
  }
  const adapter = getAdapter(resolvedChain);
  const [profile, transfers, counterparties] = await Promise.all([
    adapter.getAddressProfile(address),
    adapter.getTransfers(address, { limit: opts.transferLimit ?? 50 }),
    adapter.getCounterparties(address, { limit: opts.counterpartyLimit ?? 25 }),
  ]);
  return {
    address,
    chain: resolvedChain,
    detectedFromAddress: detected,
    profile,
    recentTransfers: transfers,
    counterparties,
    generatedAt: new Date().toISOString(),
    proprietaryHeader: proprietaryHeader('Alpha Universal Forensics Engine™'),
  };
}

/** Probe an address against EVERY chain whose syntax matches and return all hits with activity. */
export async function traceWalletAcrossEcosystem(address: string) {
  const probes = await probeAddressOnAllChains(address);
  return {
    address,
    chainsWithActivity: probes.map(p => p.chain),
    profiles: probes.map(p => p.profile),
    generatedAt: new Date().toISOString(),
    proprietaryHeader: proprietaryHeader('Alpha Universal Forensics Engine™'),
  };
}

/* =====================================================================================
 * Forensic Spider™ — Universal (BFS multi-hop trace)
 * ===================================================================================== */

export interface UniversalSpiderNode {
  address: string;
  chain: ChainKey;
  depth: number;
  nativeBalance: number;
  txCount: number;
  topAsset?: string;
  source?: string; // counterparty path
}

export interface UniversalSpiderEdge {
  from: string;
  to: string;
  asset: string;
  amount: number;
  hash: string;
  blockTime: number;
  direction: 'in' | 'out';
}

export interface UniversalSpiderResult {
  rootAddress: string;
  chain: ChainKey;
  maxDepth: number;
  totalNodes: number;
  totalEdges: number;
  nodes: UniversalSpiderNode[];
  edges: UniversalSpiderEdge[];
  generatedAt: string;
  proprietaryHeader: string;
  notes: string[];
}

export async function runSpiderTraceUniversal(
  rootAddress: string,
  chain?: ChainKey,
  opts: { maxDepth?: number; perHopLimit?: number; sinceTs?: number } = {}
): Promise<UniversalSpiderResult> {
  const maxDepth = Math.min(Math.max(opts.maxDepth ?? 2, 1), 4);
  const perHop = Math.min(opts.perHopLimit ?? 10, 25);

  let resolvedChain: ChainKey | undefined = chain;
  if (!resolvedChain) {
    const cands = detectChainsForAddress(rootAddress);
    if (!cands.length) throw new Error(`No supported chain matches address shape: ${rootAddress}`);
    resolvedChain = cands.includes('ethereum') ? 'ethereum' : cands[0];
  }
  const adapter = getAdapter(resolvedChain);

  const visited = new Set<string>([rootAddress]);
  const nodes: UniversalSpiderNode[] = [];
  const edges: UniversalSpiderEdge[] = [];
  const notes: string[] = [];

  // Seed root profile
  const rootProfile = await adapter.getAddressProfile(rootAddress).catch(() => null);
  nodes.push({
    address: rootAddress,
    chain: resolvedChain,
    depth: 0,
    nativeBalance: rootProfile?.nativeBalance ?? 0,
    txCount: rootProfile?.txCount ?? 0,
    topAsset: rootProfile?.tokens?.[0]?.asset,
  });

  let frontier: { addr: string; depth: number }[] = [{ addr: rootAddress, depth: 0 }];

  while (frontier.length) {
    const next: { addr: string; depth: number }[] = [];
    for (const { addr, depth } of frontier) {
      if (depth >= maxDepth) continue;
      let cps: CounterpartyAggregate[] = [];
      try {
        cps = await adapter.getCounterparties(addr, { limit: perHop });
      } catch (e: any) {
        notes.push(`hop d=${depth} ${addr}: counterparty fetch failed (${e?.message || e})`);
        continue;
      }
      // Get raw transfers once for edges
      let xfers: UnifiedTransfer[] = [];
      try {
        xfers = await adapter.getTransfers(addr, { limit: perHop * 4, sinceTs: opts.sinceTs });
      } catch {}
      const norm = (s: string | null | undefined) => (s ?? '').toLowerCase();
      for (const cp of cps.slice(0, perHop)) {
        const edgeRow = xfers.find(x => norm(x.counterparty) === norm(cp.address));
        if (edgeRow) {
          edges.push({
            from: edgeRow.direction === 'out' ? addr : cp.address,
            to:   edgeRow.direction === 'out' ? cp.address : addr,
            asset: edgeRow.asset,
            amount: edgeRow.amount,
            hash: edgeRow.hash,
            blockTime: edgeRow.blockTime,
            direction: edgeRow.direction,
          });
        }
        if (visited.has(cp.address)) continue;
        visited.add(cp.address);
        nodes.push({
          address: cp.address,
          chain: resolvedChain,
          depth: depth + 1,
          nativeBalance: 0, // hydrated below if depth+1 < maxDepth
          txCount: cp.count,
          source: addr,
        });
        if (depth + 1 < maxDepth) next.push({ addr: cp.address, depth: depth + 1 });
      }
    }
    frontier = next;
  }

  // Hydrate native balances for non-root nodes (in parallel, capped)
  const toHydrate = nodes.filter(n => n.depth > 0).slice(0, 30);
  await Promise.all(toHydrate.map(async (n) => {
    try {
      const p = await adapter.getAddressProfile(n.address);
      n.nativeBalance = p.nativeBalance;
      n.topAsset = p.tokens?.[0]?.asset || n.topAsset;
    } catch {}
  }));

  return {
    rootAddress,
    chain: resolvedChain,
    maxDepth,
    totalNodes: nodes.length,
    totalEdges: edges.length,
    nodes,
    edges,
    generatedAt: new Date().toISOString(),
    proprietaryHeader: proprietaryHeader('Alpha Forensic Spider™ (Universal via UCAL)'),
    notes,
  };
}

/* =====================================================================================
 * Auto-Pivot Surveillance Engine™ — Universal
 * ===================================================================================== */

export interface UniversalPivotResult {
  address: string;
  chain: ChainKey;
  profile: AddressProfile;
  outboundPivots: { counterparty: string; totalSent: number; lastSeen: number }[];
  inboundPivots: { counterparty: string; totalReceived: number; lastSeen: number }[];
  swapEvents: UnifiedTransfer[];
  bridgeEvents: UnifiedTransfer[]; // best-effort heuristic
  generatedAt: string;
  proprietaryHeader: string;
}

const BRIDGE_HINT = /(bridge|relay|portal|wormhole|stargate|hop|across|allbridge)/i;

export async function pivotSurveillanceUniversal(
  address: string,
  chain?: ChainKey,
  opts: { since?: number; limit?: number } = {}
): Promise<UniversalPivotResult> {
  let resolvedChain: ChainKey = chain ?? (detectChainsForAddress(address)[0]);
  if (!resolvedChain) throw new Error(`No supported chain matches address: ${address}`);
  const adapter = getAdapter(resolvedChain);
  const [profile, transfers] = await Promise.all([
    adapter.getAddressProfile(address),
    adapter.getTransfers(address, { limit: opts.limit ?? 100, sinceTs: opts.since }),
  ]);
  const outboundMap = new Map<string, { totalSent: number; lastSeen: number }>();
  const inboundMap = new Map<string, { totalReceived: number; lastSeen: number }>();
  const swaps: UnifiedTransfer[] = [];
  const bridges: UnifiedTransfer[] = [];
  // Detect swaps as same-tx pair (in+out at same hash)
  const byHash = new Map<string, UnifiedTransfer[]>();
  for (const t of transfers) {
    const arr = byHash.get(t.hash) || []; arr.push(t); byHash.set(t.hash, arr);
  }
  for (const [, arr] of byHash) {
    const hasIn = arr.some(x => x.direction === 'in');
    const hasOut = arr.some(x => x.direction === 'out');
    if (hasIn && hasOut) swaps.push(...arr);
  }
  for (const t of transfers) {
    if (t.counterparty && BRIDGE_HINT.test(t.counterparty)) bridges.push(t);
    if (!t.counterparty) continue;
    if (t.direction === 'out') {
      const cur = outboundMap.get(t.counterparty) || { totalSent: 0, lastSeen: 0 };
      cur.totalSent += t.amount; cur.lastSeen = Math.max(cur.lastSeen, t.blockTime);
      outboundMap.set(t.counterparty, cur);
    } else {
      const cur = inboundMap.get(t.counterparty) || { totalReceived: 0, lastSeen: 0 };
      cur.totalReceived += t.amount; cur.lastSeen = Math.max(cur.lastSeen, t.blockTime);
      inboundMap.set(t.counterparty, cur);
    }
  }
  return {
    address,
    chain: resolvedChain,
    profile,
    outboundPivots: [...outboundMap.entries()].map(([counterparty, v]) => ({ counterparty, ...v })).sort((a, b) => b.totalSent - a.totalSent),
    inboundPivots:  [...inboundMap.entries()].map(([counterparty, v]) => ({ counterparty, ...v })).sort((a, b) => b.totalReceived - a.totalReceived),
    swapEvents: swaps,
    bridgeEvents: bridges,
    generatedAt: new Date().toISOString(),
    proprietaryHeader: proprietaryHeader('Alpha Auto-Pivot Surveillance Engine™ (Universal via UCAL)'),
  };
}

/* =====================================================================================
 * Amount Correlation Scanner™ — Universal
 * ===================================================================================== */

export interface UniversalAmountMatch {
  chain: ChainKey;
  address: string;
  hash: string;
  asset: string;
  amount: number;
  blockTime: number;
  deltaFromTarget: number;
  deltaPct: number;
}

/**
 * Search a list of candidate addresses on the given chain for any transfer that
 * matches the target amount within ±tolerancePct (default 0.5%).
 * Useful for tracing on-chain "fingerprints" — same value bridging or hopping.
 */
export async function correlateAmountUniversal(
  candidateAddresses: string[],
  targetAmount: number,
  asset: string,
  chain: ChainKey,
  opts: { tolerancePct?: number; sinceTs?: number; perAddrLimit?: number } = {}
): Promise<{
  target: { amount: number; asset: string; chain: ChainKey };
  tolerancePct: number;
  matches: UniversalAmountMatch[];
  scanned: number;
  generatedAt: string;
  proprietaryHeader: string;
}> {
  const tol = opts.tolerancePct ?? 0.5;
  const adapter = getAdapter(chain);
  const matches: UniversalAmountMatch[] = [];
  const limit = opts.perAddrLimit ?? 100;
  const lo = targetAmount * (1 - tol / 100);
  const hi = targetAmount * (1 + tol / 100);
  for (const addr of candidateAddresses) {
    let xfers: UnifiedTransfer[] = [];
    try { xfers = await adapter.getTransfers(addr, { limit, sinceTs: opts.sinceTs }); } catch { continue; }
    for (const x of xfers) {
      if (asset && x.asset.toUpperCase() !== asset.toUpperCase()) continue;
      if (x.amount >= lo && x.amount <= hi) {
        matches.push({
          chain,
          address: addr,
          hash: x.hash,
          asset: x.asset,
          amount: x.amount,
          blockTime: x.blockTime,
          deltaFromTarget: x.amount - targetAmount,
          deltaPct: ((x.amount - targetAmount) / targetAmount) * 100,
        });
      }
    }
  }
  return {
    target: { amount: targetAmount, asset, chain },
    tolerancePct: tol,
    matches: matches.sort((a, b) => Math.abs(a.deltaPct) - Math.abs(b.deltaPct)),
    scanned: candidateAddresses.length,
    generatedAt: new Date().toISOString(),
    proprietaryHeader: proprietaryHeader('Alpha Amount Correlation Scanner™ (Universal via UCAL)'),
  };
}

/* =====================================================================================
 * Convenience exports
 * ===================================================================================== */

export { SUPPORTED_CHAINS, detectChainsForAddress, probeAddressOnAllChains, getAdapter };
export type { ChainKey, UnifiedTransfer, AddressProfile, CounterpartyAggregate } from './chain-adapters/types.js';
