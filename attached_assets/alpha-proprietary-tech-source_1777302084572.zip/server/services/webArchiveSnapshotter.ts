/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Web Archive Forensic Snapshotter™
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws (Title 17 / DMCA / CFAA / DTSA).
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Purpose: Pulls archived snapshots of project websites/socials from the Wayback Machine
 * (free public CDX API, no key required) and detects rug-pull-indicative changes such as
 * sudden disappearance, social handle deletion, ownership rebrands, or content gaps.
 *
 * Patent Pending. Trade Secret Protected.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Web Archive Forensic Snapshotter™');

interface Snapshot {
  timestamp: string;       // YYYYMMDDhhmmss
  isoDate: string;
  status: number;
  mimeType: string;
  digest: string;
  archiveUrl: string;
  length: number;
}

export interface RugSignal {
  severity: 'low' | 'medium' | 'high' | 'critical';
  signal: string;
  detail: string;
  evidenceUrl?: string;
}

export interface ArchiveForensicReport {
  _proprietaryHeader: string;
  target: string;
  generatedAt: string;
  totalSnapshots: number;
  firstSeen: string | null;
  lastSeen: string | null;
  longestGapDays: number;
  uniqueDigests: number;
  recentSnapshots: Snapshot[];
  oldestSnapshot: Snapshot | null;
  rugSignals: RugSignal[];
  isLikelyRug: boolean;
  rugScore: number;  // 0-100
}

function tsToIso(ts: string): string {
  // 20240115123045 -> 2024-01-15T12:30:45Z
  return `${ts.slice(0,4)}-${ts.slice(4,6)}-${ts.slice(6,8)}T${ts.slice(8,10)}:${ts.slice(10,12)}:${ts.slice(12,14)}Z`;
}

async function fetchCdx(url: string, limit = 1000): Promise<Snapshot[]> {
  const cdx = `https://web.archive.org/cdx/search/cdx?url=${encodeURIComponent(url)}&output=json&limit=${limit}&fl=timestamp,statuscode,mimetype,digest,length&filter=statuscode:200`;
  const r = await fetch(cdx, { headers: { 'user-agent': 'Alpha-Web-Archive-Forensic-Snapshotter/1.0' } });
  if (!r.ok) throw new Error(`Wayback CDX failed: ${r.status}`);
  const rows: any[] = await r.json();
  if (!Array.isArray(rows) || rows.length < 2) return [];
  // first row is header
  return rows.slice(1).map((row: any[]) => {
    const [timestamp, statuscode, mimetype, digest, length] = row;
    return {
      timestamp,
      isoDate: tsToIso(timestamp),
      status: parseInt(statuscode, 10) || 0,
      mimeType: mimetype || 'unknown',
      digest: digest || '',
      length: parseInt(length, 10) || 0,
      archiveUrl: `https://web.archive.org/web/${timestamp}/${url}`,
    };
  });
}

async function checkLiveStatus(url: string): Promise<{ alive: boolean; status: number; reachable: boolean }> {
  const fullUrl = url.startsWith('http') ? url : `https://${url}`;
  try {
    // Use a real browser User-Agent so Cloudflare/Akamai/etc. don't 403/503 us
    // and produce false-positive "DOMAIN_UNREACHABLE" rug signals.
    const r = await fetch(fullUrl, {
      method: 'GET',
      redirect: 'follow',
      signal: AbortSignal.timeout(10000),
      headers: {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.5',
      },
    });
    return { alive: r.status >= 200 && r.status < 400, status: r.status, reachable: true };
  } catch {
    return { alive: false, status: 0, reachable: false };
  }
}

function computeLongestGapDays(snaps: Snapshot[]): number {
  if (snaps.length < 2) return 0;
  const sorted = [...snaps].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  let maxGap = 0;
  for (let i = 1; i < sorted.length; i++) {
    const a = new Date(sorted[i - 1].isoDate).getTime();
    const b = new Date(sorted[i].isoDate).getTime();
    const gap = (b - a) / (1000 * 60 * 60 * 24);
    if (gap > maxGap) maxGap = gap;
  }
  return Math.round(maxGap);
}

export async function snapshotForensicTrace(target: string): Promise<ArchiveForensicReport> {
  // Strip protocol for cleaner CDX matching
  const cleanTarget = target.replace(/^https?:\/\//, '').replace(/\/$/, '');

  const [snapshots, liveStatus] = await Promise.all([
    fetchCdx(cleanTarget),
    checkLiveStatus(cleanTarget),
  ]);

  const rugSignals: RugSignal[] = [];
  let rugScore = 0;

  if (snapshots.length === 0) {
    rugSignals.push({ severity: 'medium', signal: 'NO_ARCHIVE_HISTORY', detail: 'No Wayback snapshots ever recorded — target was never cached or is brand new.' });
    rugScore += 25;
  }

  const sorted = [...snapshots].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  const firstSeen = sorted[0]?.isoDate ?? null;
  const lastSeen = sorted[sorted.length - 1]?.isoDate ?? null;
  const longestGapDays = computeLongestGapDays(sorted);
  const uniqueDigests = new Set(sorted.map(s => s.digest).filter(Boolean)).size;

  if (lastSeen) {
    const daysSinceLast = (Date.now() - new Date(lastSeen).getTime()) / (1000 * 60 * 60 * 24);
    if (daysSinceLast > 90 && !liveStatus.alive) {
      rugSignals.push({ severity: 'critical', signal: 'SITE_OFFLINE_LONG_GAP', detail: `Last archive was ${Math.round(daysSinceLast)} days ago and live site is unreachable (status ${liveStatus.status}). Strong rug indicator.`, evidenceUrl: sorted[sorted.length - 1].archiveUrl });
      rugScore += 50;
    } else if (daysSinceLast > 180 && liveStatus.alive) {
      rugSignals.push({ severity: 'low', signal: 'NO_RECENT_ARCHIVES_BUT_LIVE', detail: `No new snapshots in ${Math.round(daysSinceLast)} days, but site is reachable. Possible neglect.` });
      rugScore += 10;
    }
  }

  if (!liveStatus.alive && liveStatus.reachable) {
    rugSignals.push({ severity: 'high', signal: 'SITE_RETURNS_ERROR', detail: `Live site returns HTTP ${liveStatus.status}. Domain may be parked or removed.` });
    rugScore += 30;
  } else if (!liveStatus.reachable) {
    rugSignals.push({ severity: 'high', signal: 'DOMAIN_UNREACHABLE', detail: 'Live site is completely unreachable (DNS failure, timeout, or domain expired).' });
    rugScore += 35;
  }

  if (longestGapDays > 365 && snapshots.length > 5) {
    rugSignals.push({ severity: 'medium', signal: 'LONG_HISTORICAL_GAP', detail: `Detected ${longestGapDays}-day gap in archive history — possible site takedown or dormancy period.` });
    rugScore += 15;
  }

  if (sorted.length >= 3) {
    const recentDigests = sorted.slice(-3).map(s => s.digest).filter(Boolean);
    const allSame = recentDigests.length === 3 && recentDigests.every(d => d === recentDigests[0]);
    if (allSame) {
      rugSignals.push({ severity: 'low', signal: 'STATIC_RECENT_CONTENT', detail: 'Last 3 snapshots have identical digest — site may be a static/abandoned page.' });
      rugScore += 5;
    }
  }

  const isLikelyRug = rugScore >= 60;

  return {
    _proprietaryHeader: proprietaryHeader('Alpha Web Archive Forensic Snapshotter™'),
    target: cleanTarget,
    generatedAt: new Date().toISOString(),
    totalSnapshots: snapshots.length,
    firstSeen,
    lastSeen,
    longestGapDays,
    uniqueDigests,
    recentSnapshots: sorted.slice(-15).reverse(),
    oldestSnapshot: sorted[0] || null,
    rugSignals,
    isLikelyRug,
    rugScore: Math.min(100, rugScore),
  };
}
