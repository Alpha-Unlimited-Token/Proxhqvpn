/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Forensic Spider Trace™ (Autonomous Spider Trace™) is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements autonomous recursive blockchain address tracing with multi-hop
 * fund flow analysis, exchange detection, mixer identification, and risk scoring. Part of the
 * Alpha Forensic Intelligence Engine™ ecosystem.
 *
 * Technologies Protected:
 * - Autonomous Spider Trace™
 * - Recursive Fund Flow Analysis Engine™
 * - Exchange Deposit Detection Algorithm™
 * - Multi-Hop Address Clustering System™
 * - Risk Scoring Pipeline™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: SPIDER_TRACE_v2.1_PROTECTED
 */

import { db } from "../db";
import { forensicCases, monitoredWallets, forensicAlerts } from "@shared/schema";
import { eq } from "drizzle-orm";
import { traceAddress, traceFundFlow, type AddressProfile, type FundFlowGraph, type FundFlowNode, type FundFlowEdge } from "../blockchain/forensicTracer";
import { registerBeacon } from "./integrityBeacon.js";

export const _spiderTraceModuleHash = 'AUT_cf31c9fac611e7d9fcaf6dde';
const _stIntegrityValid = registerBeacon('forensicSpider', _spiderTraceModuleHash);
if (!_spiderTraceModuleHash?.startsWith('AUT_') || !_stIntegrityValid) {
  throw new Error('Spider Trace™ module integrity compromised — unauthorized modification detected');
}

export interface SpiderTraceResult {
  caseId: string;
  rootAddress: string;
  chain: string;
  status: "running" | "complete" | "error";
  progress: number;
  totalWalletsFound: number;
  totalWalletsTraced: number;
  totalValueMoved: string;
  fundFlow: {
    nodes: SpiderNode[];
    edges: SpiderEdge[];
  };
  riskSummary: {
    criticalWallets: number;
    highRiskWallets: number;
    exchangeDeposits: number;
    bridgeTransfers: number;
    mixerInteractions: number;
    splitPatterns: number;
  };
  walletsAdded: number;
  alertsCreated: number;
  error?: string;
  startedAt: string;
  completedAt?: string;
}

export interface SpiderNode {
  address: string;
  label: string;
  role: string;
  chain: string;
  balance: string;
  balanceUSD: string | null;
  totalIn: string;
  totalOut: string;
  txCount: number;
  depth: number;
  riskLevel: "critical" | "high" | "medium" | "low" | "none";
  riskIndicators: string[];
  firstSeen: string | null;
  lastSeen: string | null;
}

export interface SpiderEdge {
  from: string;
  to: string;
  value: string;
  valueUSD: string | null;
  txHash: string;
  timestamp: string;
  tokenSymbol?: string;
  direction: string;
}

const KNOWN_EXCHANGE_PATTERNS: Record<string, string> = {
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance Hot Wallet 6",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance Hot Wallet 8",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance Hot Wallet 14",
  "0x9696f59e4d72e237be84ffd425dcad154bf96976": "Binance Hot Wallet 15",
  "0x4e9ce36e442e55ecd9025b9a6e0d88485d628a67": "Binance Hot Wallet 16",
  "0x4976a4a02f38326660d17bf34b431dc6e2eb2327": "Binance Hot Wallet 20",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot Wallet",
  "0x2f65e11e4eaf1af0e352c8ddf2705b1281a1f702": "Bybit Hot Wallet 2",
  "0xee5b5b923ffce93a870b3104b7ca09c3db80047a": "Bybit Hot Wallet 3",
  "0x1db92e2eebc8e0c075a02bea49a2935bcd2dfcf4": "Coinbase",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase Pro",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase 10",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase 2",
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase 3",
  "0x3cd751e6b0078be393132286c442345e68ff0aaa": "Coinbase 4",
  "0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511": "Coinbase 5",
  "0xeb2629a2734e272bcc07bda959863f316f4bd4cf": "Coinbase 6",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken",
  "0x0a869d79a7052c7f1b55a8ebabbea3420f0d1e13": "Kraken 2",
  "0xe853c56864a2ebe4576a807d26fdc4a0ada51919": "Kraken 3",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken 4",
  "0xfa52274dd61e1643d2205169732f29114bc240b3": "Kraken 5",
  "0x53d284357ec70ce289d6d64134dfac8e511c8a3d": "Kraken 6",
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": "KuCoin",
  "0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91": "KuCoin 2",
  "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin 3",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX Hot Wallet",
  "0x98ec059dc3adfbdd63429227d09a55459421467f": "OKX Hot Wallet 2",
  "0x6cC5F688a315f3dC28A7781717a9A798a59fDA7b": "OKX Hot Wallet 3",
  "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": "MEXC Hot Wallet",
  "0x0162cd2ba40888b0893b5024afc5a3288f45dbcf": "MEXC Hot Wallet 2",
  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
  "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io 2",
  "0x246a2ecd9626f9eda55eff4a914e9eb2dd07a72b": "Bitget Hot Wallet",
  "0x97b9d2102a9a65a26e1ee82d59e42d1b73b68689": "Bitget Hot Wallet 2",
  "0xd793281b45cebc9f0aa33dfb6690c81e99a2de8e": "HTX (Huobi)",
  "0xab5c66752a9e8167967685f1450532fb96d5d24f": "HTX (Huobi) 2",
  "0x1062a747393198f70f71ec65a582423dba7e5ab3": "Bitfinex",
  "0x742d35cc6634c0532925a3b844bc9e7595f2bd3e": "Bitfinex 2",
  "0xfbb1b73c4f0bda4f67dca266ce6ef42f520fbb98": "Bittrex",
  "0xe03c23519e18d64f144d2800e30e81b0065c48b5": "Bittrex 2",
  "0xeea81c4416d2a8261e7e2385c4b1032a4f9e8945": "Bitstamp",
  "0x9b9fc46f92e8a1c0dec1b1747d010903e884be1": "Bitstamp 2",
  "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640": "Uniswap V3: USDC-ETH Pool",
  "0x5777d92f208679db4b9778590fa3cab3ac9e2168": "Uniswap V3 Router",
  "0x7a250d5630b4cf539739df2c5dacb4c659f2488d": "Uniswap V2 Router",
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": "Uniswap Swap Router 2",
  "0xef1c6e67703c7bd7107eed8303fbe6ec2554bf6b": "Uniswap Universal Router",
  "0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad": "Uniswap Universal Router V2",
  "0x1111111254eeb25477b68fb85ed929f73a960582": "1inch V5 Router",
  "0x11111112542d85b3ef69ae05771c2dccff4faa26": "1inch V3 Router",
  "0x111111125421ca6dc452d289314280a0f8842a65": "1inch V6 Router",
  "0xdef1c0ded9bec7f1a1670819833240f027b25eff": "0x Exchange Proxy",
  "0x881d40237659c251811cec9c364ef91dc08d300c": "MetaMask Swap Router",
  "0x3328f7f4a1d1c57c35df56bbf0c9dcafca309c49": "Banana Gun Router",
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41": "CoW Protocol",
  "0xd9e1ce17f2641f24ae83637ab66a2cca9c378b9f": "SushiSwap Router",
  "0xe592427a0aece92de3edee1f18e0157c05861564": "Uniswap V3 SwapRouter",
  "0x6131b5fae19ea4f9d964eac0408e4408b66337b5": "KyberSwap Aggregator",
  "0x1116898dda4015ed8ddefb84b6e8bc24528af2d8": "Paraswap V5",
};

const KNOWN_BRIDGE_PATTERNS: Record<string, string> = {
  "0x3154cf16ccdb4c6d922629664174b904d80f2c35": "Across Bridge",
  "0xe4edb277e41dc89ab076a1f049f4a3efa700bce8": "Across V2 Bridge",
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": "LI.FI Bridge",
  "0x99c9fc46f92e8a1c0dec1b1747d010903e884be1": "Optimism Bridge",
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f": "Arbitrum Bridge",
  "0x8315177ab297ba92a06054ce80a67ed4dbd7ed3a": "Arbitrum Bridge 2",
  "0x2796317b0ff8538f253012862c06787adfb8ceb6": "Synapse Bridge",
  "0xabea9132b05a70803a4e85094fd0e1800777fbef": "zkSync Bridge",
  "0x3ee18b2214aff97000d974cf647e7c347e8fa585": "Wormhole Bridge",
  "0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf": "Polygon Bridge",
  "0xa0c68c638235ee32657e8f720a23cec1bfc6c4d": "Polygon zkEVM Bridge",
  "0x32400084c286cf3e17e7b677ea9583e60a000324": "zkSync Era Bridge",
  "0xd19d4b5d358258f05d7b411e21a1460d11b0876f": "Linea Bridge",
  "0x051f1d88f0af049f4bfc60011c71ea2ba3fdf600": "Scroll Bridge",
  "0x49048044d57e1c92a77f79988d21fa8faf74e97e": "Base Bridge",
  "0x3a23f943181408eac424116af7b7790c94cb97a5": "Socket Bridge",
  "0xc30141b657f4216252dc59af2e7cdb9d8792e1b0": "Socket Gateway",
  "0x5427fefa711eff984124bfbb1ab6fbf5e3da1820": "Celer cBridge",
  "0x5a3749e7a9b33c8b70e3b71402c6aadb33e22b5c": "Celer cBridge V2",
  "0x23ddd3e3692d1861ed57ede224608875809e127f": "LayerZero Stargate",
  "0x8731d54e9d02c286767d56ac03e8037c07e01e98": "Stargate Router",
  "0xbf22f0f184bccbea268df387a49ff5238dd23e40": "Multichain Bridge",
  "0x765277eebeca2e31912c9946eae1021199b39c61": "Multichain Router",
  "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7": "Hop Protocol",
  "0xb8901acb165ed027e32754e0ffe830802919727f": "Hop Bridge (ETH)",
  "0x3d4cc8602f866d8fb00a0dcfcbb0e93e6ddbc84e": "Hop Bridge (ARB)",
  "0xe22d2bedb3eca35e6397e0c6d62857094aaff940": "Connext Bridge",
  "0x8898b472c54c31894e3b9bb83cea802a5d0e63c6": "Connext Diamond",
  "0x1c479675ad559dc151f6ec7ed3fbf8cee79582b6": "Allbridge",
  "0x0b2402144bb366a632d14b83f244d2e0e21bd39c": "deBridge",
  "0x663dc15d3c1ac63ff12e45ab68fea3f0a883c251": "Squid Router",
};

const KNOWN_MIXER_PATTERNS: Record<string, string> = {
  "0xd90e2f925da726b50c4ed8d0fb90ad053324f31b": "Tornado Cash",
  "0x12d66f87a04a9e220743712ce6d9bb1b5616b8fc": "Tornado Cash 0.1 ETH",
  "0x47ce0c6ed5b0ce3d3a51fdb1c52dc66a7c3c2936": "Tornado Cash 1 ETH",
  "0x910cbd523d972eb0a6f4cae4618ad62622b39dbf": "Tornado Cash 10 ETH",
  "0xa160cdab225685da1d56aa342ad8841c3b53f291": "Tornado Cash 100 ETH",
  "0xd4b88df4d29f5cedd6857912842cff3b20c8cfa3": "Tornado Cash (old)",
  "0xfd8610d20aa15b7b2e3be39b396a1bc3516c7144": "Tornado Cash (BSC 0.1 BNB)",
  "0x84443CFd09A48AF6eF360C6976C5392aC5023a1F": "Tornado Cash (BSC 1 BNB)",
  "0x330bdfade01ee9bf63c209ee33102dd334618e0a": "Tornado Cash (BSC 10 BNB)",
  "0x1e34a77868e19a6647b1f2f47b51ed72dede95dd": "Tornado Cash (BSC 100 BNB)",
  "0x0d5550d52428e7e3175bfc9550207e4ad3859b17": "Railgun Privacy",
  "0xfa7093cdd9ee6932b4eb2c9e1cde7ce00b1fa4b9": "Railgun Relay",
  "0x932777e1729781e390ad5a2578bf44e9eb0971b4": "Aztec Connect",
};

const activeTraces = new Map<string, SpiderTraceResult>();

function classifyAddress(addr: string): { role: string; label: string } {
  const lower = addr.toLowerCase();

  for (const [known, label] of Object.entries(KNOWN_EXCHANGE_PATTERNS)) {
    if (lower === known.toLowerCase()) {
      return { role: "exchange", label };
    }
  }

  for (const [known, label] of Object.entries(KNOWN_BRIDGE_PATTERNS)) {
    if (lower === known.toLowerCase()) {
      return { role: "bridge", label };
    }
  }

  for (const [known, label] of Object.entries(KNOWN_MIXER_PATTERNS)) {
    if (lower === known.toLowerCase()) {
      return { role: "mixer", label };
    }
  }

  return { role: "unknown", label: "" };
}

function classifyByBehavior(profile: AddressProfile): { role: string; riskLevel: "critical" | "high" | "medium" | "low" | "none" } {
  const risks = profile.riskIndicators.map(r => r.type);
  let role = "intermediary";
  let riskLevel: "critical" | "high" | "medium" | "low" | "none" = "low";

  if (risks.includes("drain_pattern")) {
    role = "drainer";
    riskLevel = "critical";
  } else if (risks.includes("mixer_pattern")) {
    role = "mixer";
    riskLevel = "critical";
  } else if (risks.includes("split_pattern")) {
    role = "splitter";
    riskLevel = "high";
  } else if (risks.includes("rapid_movement")) {
    role = "relay";
    riskLevel = "high";
  } else if (risks.includes("exchange_deposit")) {
    role = "exchange_deposit";
    riskLevel = "high";
  } else if (risks.includes("high_volume")) {
    role = "high_volume";
    riskLevel = "medium";
  } else if (risks.includes("new_wallet")) {
    role = "new_wallet";
    riskLevel = "medium";
  } else if (risks.includes("dormant_activation")) {
    role = "reactivated";
    riskLevel = "medium";
  }

  return { role, riskLevel };
}

export async function runSpiderTrace(
  caseId: string,
  rootAddress: string,
  chain: string = "ethereum",
  maxDepth: number = 3,
  maxWallets: number = 50,
): Promise<SpiderTraceResult> {
  const traceKey = `${caseId}-${rootAddress}`;

  const result: SpiderTraceResult = {
    caseId,
    rootAddress,
    chain,
    status: "running",
    progress: 0,
    totalWalletsFound: 0,
    totalWalletsTraced: 0,
    totalValueMoved: "0",
    fundFlow: { nodes: [], edges: [] },
    riskSummary: {
      criticalWallets: 0,
      highRiskWallets: 0,
      exchangeDeposits: 0,
      bridgeTransfers: 0,
      mixerInteractions: 0,
      splitPatterns: 0,
    },
    walletsAdded: 0,
    alertsCreated: 0,
    startedAt: new Date().toISOString(),
  };

  activeTraces.set(traceKey, result);

  try {
    const unlimitedDepth = maxDepth <= 0;
    const unlimitedWallets = maxWallets <= 0;
    const effectiveMaxDepth = unlimitedDepth ? 999999 : maxDepth;
    const effectiveMaxWallets = unlimitedWallets ? 999999 : maxWallets;

    console.log(`[ForensicSpider] Starting automated trace for case ${caseId}`);
    console.log(`[ForensicSpider] Root: ${rootAddress} | Chain: ${chain} | Depth: ${unlimitedDepth ? "UNLIMITED" : maxDepth} | Wallets: ${unlimitedWallets ? "UNLIMITED" : maxWallets}`);

    const visited = new Set<string>();
    const queue: Array<{ address: string; depth: number; parentAddr?: string; parentTxHash?: string; value?: string; timestamp?: string }> = [];
    let totalValueWei = BigInt(0);

    queue.push({ address: rootAddress, depth: 0 });

    while (queue.length > 0 && visited.size < effectiveMaxWallets) {
      const current = queue.shift()!;
      const addrLower = current.address.toLowerCase();

      if (visited.has(addrLower)) continue;
      visited.add(addrLower);

      result.totalWalletsTraced = visited.size;
      const estimatedTotal = unlimitedWallets ? Math.max(visited.size + queue.length, visited.size * 2) : effectiveMaxWallets;
      result.progress = unlimitedWallets
        ? Math.min(99, Math.round((visited.size / Math.max(1, visited.size + queue.length)) * 100))
        : Math.min(95, Math.round((visited.size / Math.max(effectiveMaxWallets, queue.length + visited.size)) * 100));
      activeTraces.set(traceKey, { ...result });

      console.log(`[ForensicSpider] Tracing [${visited.size}${unlimitedWallets ? "" : `/${maxWallets}`}] depth=${current.depth}: ${current.address.slice(0, 10)}...`);

      await new Promise(r => setTimeout(r, 800));

      const profile = await traceAddress(current.address, chain);

      const knownClass = classifyAddress(current.address);
      let role = knownClass.role;
      let label = knownClass.label;
      let riskLevel: "critical" | "high" | "medium" | "low" | "none" = "none";
      let riskIndicatorNames: string[] = [];

      if (profile) {
        const behavior = classifyByBehavior(profile);
        if (role === "unknown") role = behavior.role;
        riskLevel = behavior.riskLevel;
        riskIndicatorNames = profile.riskIndicators.map(r => r.type);

        if (riskLevel === "critical") result.riskSummary.criticalWallets++;
        if (riskLevel === "high") result.riskSummary.highRiskWallets++;
        if (role === "exchange" || role === "exchange_deposit") result.riskSummary.exchangeDeposits++;
        if (role === "bridge") result.riskSummary.bridgeTransfers++;
        if (role === "mixer") result.riskSummary.mixerInteractions++;
        if (riskIndicatorNames.includes("split_pattern")) result.riskSummary.splitPatterns++;
      }

      if (current.depth === 0) {
        role = "victim";
        label = "Victim Wallet";
      }

      const node: SpiderNode = {
        address: current.address,
        label: label || current.address.slice(0, 6) + "..." + current.address.slice(-4),
        role,
        chain,
        balance: profile?.balance || "0",
        balanceUSD: profile?.balanceUSD || null,
        totalIn: profile?.totalReceived || "0",
        totalOut: profile?.totalSent || "0",
        txCount: profile?.transactionCount || 0,
        depth: current.depth,
        riskLevel,
        riskIndicators: riskIndicatorNames,
        firstSeen: profile?.firstSeen || null,
        lastSeen: profile?.lastSeen || null,
      };

      result.fundFlow.nodes.push(node);

      if (current.parentAddr && current.parentTxHash) {
        result.fundFlow.edges.push({
          from: current.parentAddr,
          to: current.address,
          value: current.value || "0",
          valueUSD: null,
          txHash: current.parentTxHash,
          timestamp: current.timestamp || new Date().toISOString(),
          direction: "outgoing",
        });
      }

      try {
        const existingWallets = await db.select().from(monitoredWallets)
          .where(eq(monitoredWallets.caseId, caseId));
        const alreadyMonitored = existingWallets.some(w => w.address.toLowerCase() === addrLower);

        if (!alreadyMonitored) {
          await db.insert(monitoredWallets).values({
            caseId,
            address: current.address,
            chain,
            role: role,
            label: label || `Depth-${current.depth} ${role}`,
            lastKnownBalanceEth: profile ? parseFloat(profile.balance) : null,
            lastKnownBalanceUsd: profile?.balanceUSD ? parseFloat(profile.balanceUSD) : null,
            status: "monitoring",
          });
          result.walletsAdded++;
        }
      } catch {}

      if (profile && riskLevel !== "none" && current.depth > 0) {
        try {
          let severity: "critical" | "high" | "medium" | "low" = "medium";
          if (riskLevel === "critical") severity = "critical";
          else if (riskLevel === "high") severity = "high";

          let alertMsg = `Spider traced ${role} wallet at depth ${current.depth}: ${current.address.slice(0, 10)}...`;
          if (label) alertMsg = `${label}: ${alertMsg}`;
          if (role === "exchange") alertMsg = `EXCHANGE DETECTED: Funds sent to ${label || "exchange"} (${current.address.slice(0, 10)}...)`;
          if (role === "bridge") alertMsg = `BRIDGE DETECTED: Funds bridged via ${label || "bridge"} (${current.address.slice(0, 10)}...)`;
          if (role === "mixer") alertMsg = `MIXER DETECTED: Funds mixed via ${label || "mixer"} (${current.address.slice(0, 10)}...)`;

          await db.insert(forensicAlerts).values({
            caseId,
            alertType: "spider_discovery",
            message: alertMsg,
            details: {
              address: current.address,
              role,
              label,
              depth: current.depth,
              balance: profile.balance,
              riskLevel,
              riskIndicators: riskIndicatorNames,
            },
            severity,
            acknowledged: false,
          });
          result.alertsCreated++;
        } catch {}
      }

      if (current.depth < effectiveMaxDepth && profile && visited.size < effectiveMaxWallets) {
        const outgoing = profile.transactions
          .filter(tx => tx.direction === "outgoing" && tx.to && tx.to !== current.address)
          .filter(tx => {
            const val = parseFloat(tx.value);
            return !isNaN(val) && val > 0.001;
          });

        const uniqueRecipients = new Map<string, { txHash: string; value: string; timestamp: string }>();
        for (const tx of outgoing) {
          const toLower = tx.to.toLowerCase();
          if (!uniqueRecipients.has(toLower) || parseFloat(tx.value) > parseFloat(uniqueRecipients.get(toLower)!.value)) {
            uniqueRecipients.set(toLower, { txHash: tx.hash, value: tx.value, timestamp: tx.timestamp });
          }
        }

        const sortedRecipients = [...uniqueRecipients.entries()]
          .sort((a, b) => parseFloat(b[1].value) - parseFloat(a[1].value))
          .slice(0, 10);

        for (const [recipientAddr, txInfo] of sortedRecipients) {
          if (!visited.has(recipientAddr)) {
            try {
              totalValueWei += BigInt(Math.round(parseFloat(txInfo.value) * 1e18));
            } catch {}
            queue.push({
              address: recipientAddr,
              depth: current.depth + 1,
              parentAddr: current.address,
              parentTxHash: txInfo.txHash,
              value: txInfo.value,
              timestamp: txInfo.timestamp,
            });
          }
        }

        if (profile.connectedAddresses && profile.connectedAddresses.length > 0) {
          const sentTo = profile.connectedAddresses
            .filter(ca => ca.relationship === "sent_to" || ca.relationship === "bidirectional")
            .filter(ca => !visited.has(ca.address.toLowerCase()) && !uniqueRecipients.has(ca.address.toLowerCase()))
            .sort((a, b) => parseFloat(b.totalValue) - parseFloat(a.totalValue))
            .slice(0, 5);

          for (const conn of sentTo) {
            if (!visited.has(conn.address.toLowerCase()) && visited.size + queue.length < effectiveMaxWallets) {
              queue.push({
                address: conn.address,
                depth: current.depth + 1,
                parentAddr: current.address,
                parentTxHash: "connected",
                value: conn.totalValue,
                timestamp: conn.lastInteraction || new Date().toISOString(),
              });
            }
          }
        }
      }

      result.totalWalletsFound = visited.size + queue.length;
    }

    result.totalValueMoved = (Number(totalValueWei) / 1e18).toFixed(6);
    result.status = "complete";
    result.progress = 100;
    result.completedAt = new Date().toISOString();

    try {
      await db.insert(forensicAlerts).values({
        caseId,
        alertType: "spider_complete",
        message: `Automated Spider Trace complete: ${visited.size} wallets traced, ${result.walletsAdded} added to monitoring, ${result.fundFlow.edges.length} fund flows mapped`,
        details: {
          rootAddress,
          walletsTraced: visited.size,
          walletsAdded: result.walletsAdded,
          edgesMapped: result.fundFlow.edges.length,
          riskSummary: result.riskSummary,
          totalValueMoved: result.totalValueMoved,
        },
        severity: result.riskSummary.criticalWallets > 0 ? "critical" : "high",
        acknowledged: false,
      });
    } catch {}

    console.log(`[ForensicSpider] Trace complete for ${rootAddress}`);
    console.log(`[ForensicSpider] Results: ${visited.size} wallets | ${result.fundFlow.edges.length} edges | ${result.walletsAdded} added | ${result.alertsCreated} alerts`);
    console.log(`[ForensicSpider] Risk: ${result.riskSummary.criticalWallets} critical, ${result.riskSummary.highRiskWallets} high, ${result.riskSummary.exchangeDeposits} exchanges, ${result.riskSummary.bridgeTransfers} bridges, ${result.riskSummary.mixerInteractions} mixers`);

  } catch (error: any) {
    result.status = "error";
    result.error = error.message;
    console.error(`[ForensicSpider] Error tracing ${rootAddress}:`, error.message);
  }

  activeTraces.set(traceKey, result);
  return result;
}

export function getActiveTrace(caseId: string, rootAddress: string): SpiderTraceResult | null {
  return activeTraces.get(`${caseId}-${rootAddress}`) || null;
}

export function getAllActiveTraces(): Map<string, SpiderTraceResult> {
  return activeTraces;
}

export function getTraceForCase(caseId: string): SpiderTraceResult | null {
  for (const [key, trace] of activeTraces) {
    if (trace.caseId === caseId) return trace;
  }
  return null;
}
