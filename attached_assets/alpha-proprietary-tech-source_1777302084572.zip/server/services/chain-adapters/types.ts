/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — type definitions.
 */

export type ChainKey =
  | 'ethereum'
  | 'polygon'
  | 'arbitrum'
  | 'optimism'
  | 'base'
  | 'solana'
  | 'bitcoin'
  | 'tron'
  | 'ton'
  | 'xrpl';

export interface UnifiedTransfer {
  hash: string;
  blockTime: number;          // unix seconds
  direction: 'in' | 'out' | 'both';
  counterparty: string | null; // for UTXO chains, may be aggregated/null
  asset: string;               // 'ETH', 'USDC', 'SOL', 'BTC', 'TRX', 'TON', etc.
  contract: string | null;     // contract / mint / null for native
  amount: number;              // human units
  valueUsd?: number;
  raw?: any;
}

export interface TokenHolding {
  asset: string;
  contract: string | null;
  amount: number;
  decimals?: number;
  valueUsd?: number;
}

export interface CounterpartyAggregate {
  address: string;
  count: number;
  inboundValueNative: number;  // received FROM counterparty
  outboundValueNative: number; // sent TO counterparty
  firstSeen: number;
  lastSeen: number;
  entityLabel?: string | null;
}

export interface AddressProfile {
  chain: ChainKey;
  address: string;
  nativeSymbol: string;
  nativeBalance: number;
  txCount: number;
  firstSeen: number | null;
  lastSeen: number | null;
  tokens: TokenHolding[];
  notes?: string[];
}

export interface ChainAdapter {
  /** Canonical chain key (matches ChainKey union). */
  readonly chainKey: ChainKey;
  /** Human display name (e.g. 'Ethereum'). */
  readonly displayName: string;
  /** Native currency ticker (e.g. 'ETH', 'SOL', 'BTC'). */
  readonly nativeSymbol: string;
  /** True if the address syntactically matches this chain. */
  isValidAddress(addr: string): boolean;
  /** Native balance in human units. */
  getNativeBalance(addr: string): Promise<number>;
  /** Address profile (balance + token holdings + first/last activity). */
  getAddressProfile(addr: string): Promise<AddressProfile>;
  /** Recent transfers (newest first). */
  getTransfers(addr: string, opts?: { limit?: number; sinceTs?: number }): Promise<UnifiedTransfer[]>;
  /** Aggregated counterparties from recent activity. */
  getCounterparties(addr: string, opts?: { limit?: number }): Promise<CounterpartyAggregate[]>;
  /** Explorer URL for an address / tx / token. */
  explorerUrl(kind: 'address' | 'tx' | 'token', id: string): string;
}
