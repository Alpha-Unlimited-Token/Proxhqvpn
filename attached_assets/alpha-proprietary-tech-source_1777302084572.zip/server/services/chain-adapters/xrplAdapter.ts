/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — XRP Ledger adapter (xrplcluster.com public JSON-RPC).
 */

import type { ChainAdapter, UnifiedTransfer, AddressProfile, CounterpartyAggregate, TokenHolding } from './types';

const RPC_URLS = ['https://xrplcluster.com/', 'https://s1.ripple.com:51234/', 'https://s2.ripple.com:51234/'];
const XRPSCAN = 'https://api.xrpscan.com/api/v1';
const RIPPLE_EPOCH = 946684800; // 2000-01-01 UTC offset

let rpcIdx = 0;
async function rpc(method: string, params: any): Promise<any> {
  let lastErr: any;
  for (let attempt = 0; attempt < RPC_URLS.length; attempt++) {
    const url = RPC_URLS[(rpcIdx + attempt) % RPC_URLS.length];
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, params: [params] }),
      });
      if (!r.ok) throw new Error(`xrpl ${url}: HTTP ${r.status}`);
      const j: any = await r.json();
      if (j?.result?.status === 'error') throw new Error(j.result.error_message || j.result.error);
      rpcIdx = (rpcIdx + attempt) % RPC_URLS.length;
      return j.result;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr;
}

/** Fetch XRPSCAN account label (best-effort, swallow errors). */
async function fetchLabel(addr: string): Promise<{ name?: string; tags?: string[] } | null> {
  try {
    const r = await fetch(`${XRPSCAN}/account/${addr}`, { headers: { 'User-Agent': 'AlphaUCAL/1.0' } });
    if (!r.ok) return null;
    const j: any = await r.json();
    return { name: j?.accountName?.name || j?.accountName?.desc, tags: j?.accountName?.tags || [] };
  } catch { return null; }
}

function rippleSecondsToUnix(rs: number): number { return rs + RIPPLE_EPOCH; }

function asXrpAmount(amount: any): number | null {
  if (typeof amount === 'string') {
    const n = parseInt(amount, 10);
    if (!Number.isFinite(n)) return null;
    return n / 1e6;
  }
  return null; // IOU (issued-currency) handled separately
}

export const xrplAdapter: ChainAdapter = {
  chainKey: 'xrpl',
  displayName: 'XRP Ledger',
  nativeSymbol: 'XRP',

  isValidAddress(addr: string): boolean {
    return typeof addr === 'string' && /^r[1-9A-HJ-NP-Za-km-z]{24,34}$/.test(addr);
  },

  async getNativeBalance(addr: string): Promise<number> {
    try {
      const r = await rpc('account_info', { account: addr, ledger_index: 'validated' });
      const drops = r?.account_data?.Balance;
      if (!drops) return 0;
      return parseInt(drops, 10) / 1e6;
    } catch { return 0; }
  },

  async getAddressProfile(addr: string): Promise<AddressProfile> {
    let nativeBalance = 0;
    let txCount = 0;
    let firstSeen: number | null = null;
    let lastSeen: number | null = null;
    const notes: string[] = [];

    try {
      const info = await rpc('account_info', { account: addr, ledger_index: 'validated' });
      const drops = info?.account_data?.Balance;
      if (drops) nativeBalance = parseInt(drops, 10) / 1e6;
      txCount = info?.account_data?.Sequence ? Math.max(0, parseInt(info.account_data.Sequence, 10) - 1) : 0;
    } catch (e: any) {
      // Account not found / not activated — leave defaults; don't throw so probeAddressOnAllChains still works
      notes.push(`account_info: ${e?.message || 'unknown error'}`);
    }

    // Pull first / last activity from a single page of account_tx (newest 25).
    try {
      const tx = await rpc('account_tx', { account: addr, limit: 25, forward: false, ledger_index_min: -1, ledger_index_max: -1 });
      const rows: any[] = tx?.transactions || [];
      const dates = rows.map(r => r?.tx?.date).filter((d: any) => typeof d === 'number');
      if (dates.length) {
        lastSeen = rippleSecondsToUnix(Math.max(...dates));
        firstSeen = rippleSecondsToUnix(Math.min(...dates));
      }
    } catch { /* ignore */ }

    // Trust line balances → token holdings
    const tokens: TokenHolding[] = [];
    try {
      const lines = await rpc('account_lines', { account: addr, ledger_index: 'validated' });
      for (const l of (lines?.lines || []).slice(0, 50)) {
        const amt = parseFloat(l.balance);
        if (Number.isFinite(amt) && Math.abs(amt) > 0) {
          tokens.push({ asset: l.currency, contract: l.account, amount: amt });
        }
      }
    } catch { /* ignore */ }

    const lbl = await fetchLabel(addr);
    if (lbl?.name) notes.push(`Label: ${lbl.name}${lbl.tags?.length ? ` (${lbl.tags.join(', ')})` : ''}`);

    return {
      chain: 'xrpl',
      address: addr,
      nativeSymbol: 'XRP',
      nativeBalance,
      txCount,
      firstSeen,
      lastSeen,
      tokens,
      notes,
    };
  },

  async getTransfers(addr: string, opts: { limit?: number; sinceTs?: number } = {}): Promise<UnifiedTransfer[]> {
    const limit = Math.min(opts.limit ?? 200, 1000);
    const sinceRipple = opts.sinceTs ? Math.max(0, opts.sinceTs - RIPPLE_EPOCH) : -Infinity;
    const out: UnifiedTransfer[] = [];
    let marker: any = undefined;
    const maxPages = Math.ceil(limit / 200);
    for (let page = 0; page < maxPages && out.length < limit; page++) {
      let res: any;
      try {
        const params: any = { account: addr, limit: 200, forward: false, ledger_index_min: -1, ledger_index_max: -1 };
        if (marker) params.marker = marker;
        res = await rpc('account_tx', params);
      } catch { break; }
      const rows: any[] = res?.transactions || [];
      if (!rows.length) break;
      for (const r of rows) {
        const tx = r.tx || r.tx_json || {};
        const meta = r.meta || {};
        if (tx.TransactionType !== 'Payment') continue;
        if (meta.TransactionResult !== 'tesSUCCESS') continue;
        const date = tx.date;
        if (typeof date !== 'number') continue;
        if (date < sinceRipple) continue;
        const amtNative = asXrpAmount(tx.Amount);
        const isIou = !amtNative && tx.Amount && typeof tx.Amount === 'object';
        const isOut = tx.Account === addr;
        const isIn = tx.Destination === addr;
        if (!isOut && !isIn) continue;
        out.push({
          hash: tx.hash,
          blockTime: rippleSecondsToUnix(date),
          direction: isOut && isIn ? 'both' : isOut ? 'out' : 'in',
          counterparty: isOut ? (tx.Destination || null) : (tx.Account || null),
          asset: isIou ? (tx.Amount.currency || 'IOU') : 'XRP',
          contract: isIou ? (tx.Amount.issuer || null) : null,
          amount: amtNative ?? (isIou ? parseFloat(tx.Amount.value) : 0),
          raw: { destinationTag: tx.DestinationTag, sourceTag: tx.SourceTag, ledger: r.ledger_index, fee: tx.Fee },
        });
        if (out.length >= limit) break;
      }
      marker = res.marker;
      if (!marker) break;
      // optimization: oldest tx older than sinceTs → stop paging
      const oldest = rows[rows.length - 1]?.tx?.date;
      if (typeof oldest === 'number' && oldest < sinceRipple) break;
    }
    return out;
  },

  async getCounterparties(addr: string, opts: { limit?: number } = {}): Promise<CounterpartyAggregate[]> {
    const limit = opts.limit ?? 100;
    const transfers = await this.getTransfers(addr, { limit: 500 });
    const map = new Map<string, CounterpartyAggregate>();
    for (const t of transfers) {
      const cp = t.counterparty;
      if (!cp) continue;
      let agg = map.get(cp);
      if (!agg) {
        agg = { address: cp, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: t.blockTime, lastSeen: t.blockTime };
        map.set(cp, agg);
      }
      agg.count++;
      if (t.direction === 'in') agg.inboundValueNative += t.amount;
      else if (t.direction === 'out') agg.outboundValueNative += t.amount;
      if (t.blockTime < agg.firstSeen) agg.firstSeen = t.blockTime;
      if (t.blockTime > agg.lastSeen) agg.lastSeen = t.blockTime;
    }
    // Best-effort label enrichment for top-N
    const sorted = [...map.values()].sort((a, b) => (b.inboundValueNative + b.outboundValueNative) - (a.inboundValueNative + a.outboundValueNative)).slice(0, limit);
    await Promise.all(sorted.slice(0, 25).map(async (a) => { const lbl = await fetchLabel(a.address); if (lbl?.name) a.entityLabel = lbl.name; }));
    return sorted;
  },

  explorerUrl(kind: 'address' | 'tx' | 'token', id: string): string {
    if (kind === 'address') return `https://xrpscan.com/account/${id}`;
    if (kind === 'tx') return `https://xrpscan.com/tx/${id}`;
    return `https://xrpscan.com/${id}`;
  },
};
