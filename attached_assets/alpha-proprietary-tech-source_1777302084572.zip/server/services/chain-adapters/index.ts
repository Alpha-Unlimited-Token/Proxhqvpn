/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — registry + auto-router.
 */

import { enforceProprietaryLicense, proprietaryHeader } from '../../../private/security/alpha_proprietary_guard.js';
import type { ChainAdapter, ChainKey } from './types';
import { makeEvmAdapter } from './evmAdapter';
import { solanaAdapter } from './solanaAdapter';
import { bitcoinAdapter } from './bitcoinAdapter';
import { tronAdapter } from './tronAdapter';
import { tonAdapter } from './tonAdapter';
import { xrplAdapter } from './xrplAdapter';

enforceProprietaryLicense('Alpha Universal Chain Adapter Layer™ (UCAL)');

const REGISTRY: Record<ChainKey, ChainAdapter> = {
  ethereum: makeEvmAdapter('ethereum'),
  polygon:  makeEvmAdapter('polygon'),
  arbitrum: makeEvmAdapter('arbitrum'),
  optimism: makeEvmAdapter('optimism'),
  base:     makeEvmAdapter('base'),
  solana:   solanaAdapter,
  bitcoin:  bitcoinAdapter,
  tron:     tronAdapter,
  ton:      tonAdapter,
  xrpl:     xrplAdapter,
};

export const SUPPORTED_CHAINS: ChainKey[] = Object.keys(REGISTRY) as ChainKey[];

export function getAdapter(chain: ChainKey): ChainAdapter {
  const a = REGISTRY[chain];
  if (!a) throw new Error(`UCAL: unsupported chain "${chain}"`);
  return a;
}

/**
 * Detect the most likely chain(s) for an address by syntactic shape.
 * Returns ALL adapters whose isValidAddress() matches; caller can probe each.
 */
export function detectChainsForAddress(addr: string): ChainKey[] {
  return SUPPORTED_CHAINS.filter(c => REGISTRY[c].isValidAddress(addr));
}

/**
 * Run a getAddressProfile() across every chain whose address shape matches,
 * in parallel, returning whichever succeed (live activity ≠ syntactic match).
 */
export async function probeAddressOnAllChains(addr: string) {
  const candidates = detectChainsForAddress(addr);
  const results = await Promise.allSettled(candidates.map(async (c) => ({ chain: c, profile: await REGISTRY[c].getAddressProfile(addr) })));
  return results
    .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled')
    .map(r => r.value)
    // Keep chains where there's any sign of activity (balance > 0 OR txCount > 0 OR tokens > 0 OR lastSeen)
    .filter(r => (r.profile.nativeBalance > 0) || (r.profile.txCount > 0) || (r.profile.tokens?.length > 0) || (r.profile.lastSeen !== null));
}

/** Header banner emitted by every UCAL-aware report output. */
export function ucalHeader(): string {
  return proprietaryHeader('Alpha Universal Chain Adapter Layer™ (UCAL)');
}

export type { ChainAdapter, ChainKey } from './types';
