/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — Solana adapter.
 */

import type { ChainAdapter, UnifiedTransfer, AddressProfile, CounterpartyAggregate, TokenHolding } from './types';

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';
const RPC = `https://solana-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const BASE58_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

async function rpc(method: string, params: any[], retries = 4): Promise<any> {
  let lastErr: any;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const r = await fetch(RPC, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      });
      if (r.status === 429 || r.status >= 500) {
        const wait = 500 * Math.pow(2, attempt);
        await new Promise(res => setTimeout(res, wait));
        lastErr = new Error(`Solana RPC ${method}: HTTP ${r.status}`);
        continue;
      }
      const txt = await r.text();
      if (!txt) {
        lastErr = new Error(`Solana RPC ${method}: empty response (status ${r.status})`);
        await new Promise(res => setTimeout(res, 400 * (attempt + 1)));
        continue;
      }
      let j: any;
      try { j = JSON.parse(txt); } catch { throw new Error(`Solana RPC ${method}: non-JSON response (status ${r.status})`); }
      if (j.error) throw new Error(`Solana RPC ${method}: ${j.error.message || JSON.stringify(j.error)}`);
      return j.result;
    } catch (e) {
      lastErr = e;
      if (attempt < retries) await new Promise(res => setTimeout(res, 400 * (attempt + 1)));
    }
  }
  throw lastErr;
}

export const solanaAdapter: ChainAdapter = {
  chainKey: 'solana',
  displayName: 'Solana',
  nativeSymbol: 'SOL',
  isValidAddress: (a) => BASE58_RE.test(a) && a.length >= 32 && a.length <= 44,
  async getNativeBalance(addr) {
    const r = await rpc('getBalance', [addr]);
    return (r?.value ?? 0) / 1e9;
  },
  async getAddressProfile(addr) {
    const [bal, sigs, ta] = await Promise.all([
      this.getNativeBalance(addr),
      rpc('getSignaturesForAddress', [addr, { limit: 1 }]).catch(() => []),
      rpc('getTokenAccountsByOwner', [addr, { programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA' }, { encoding: 'jsonParsed' }]).catch(() => ({ value: [] })),
    ]);
    const tokens: TokenHolding[] = ((ta?.value as any[]) || []).map((acct: any) => {
      const info = acct?.account?.data?.parsed?.info;
      const ui = info?.tokenAmount?.uiAmount ?? 0;
      return ui > 0 ? {
        asset: info?.mint?.slice(0, 8) ?? 'SPL',
        contract: info?.mint ?? null,
        amount: ui,
        decimals: info?.tokenAmount?.decimals,
      } : null;
    }).filter(Boolean) as TokenHolding[];
    const lastSig = (sigs as any[])[0];
    return {
      chain: 'solana',
      address: addr,
      nativeSymbol: 'SOL',
      nativeBalance: bal,
      txCount: 0,
      firstSeen: null,
      lastSeen: lastSig?.blockTime ?? null,
      tokens: tokens.slice(0, 50),
    };
  },
  async getTransfers(addr, opts = {}) {
    const limit = Math.min(opts.limit ?? 25, 100);
    const sigs: any[] = await rpc('getSignaturesForAddress', [addr, { limit }]).catch(() => []);
    const since = opts.sinceTs ?? 0;
    const filtered = sigs.filter(s => (s.blockTime ?? 0) >= since);
    const out: UnifiedTransfer[] = [];
    // Hydrate up to 25 transactions in parallel batches of 5
    const slice = filtered.slice(0, Math.min(limit, 25));
    for (let i = 0; i < slice.length; i += 5) {
      const chunk = slice.slice(i, i + 5);
      const txs = await Promise.all(chunk.map(s =>
        rpc('getTransaction', [s.signature, { maxSupportedTransactionVersion: 0, encoding: 'jsonParsed' }]).catch(() => null)
      ));
      for (let k = 0; k < txs.length; k++) {
        const tx = txs[k];
        const sig = chunk[k];
        if (!tx?.meta || !tx.transaction) continue;
        const accts = tx.transaction.message.accountKeys.map((a: any) => typeof a === 'string' ? a : a.pubkey);
        const idx = accts.indexOf(addr);
        if (idx === -1) continue;
        const preL = tx.meta.preBalances?.[idx] ?? 0;
        const postL = tx.meta.postBalances?.[idx] ?? 0;
        const deltaSol = (postL - preL) / 1e9;
        if (Math.abs(deltaSol) > 0.000001) {
          // Find counterparty: largest opposite-sign delta
          let cp: string | null = null; let best = 0;
          for (let j = 0; j < accts.length; j++) {
            if (j === idx) continue;
            const d = ((tx.meta.postBalances?.[j] ?? 0) - (tx.meta.preBalances?.[j] ?? 0)) / 1e9;
            if (Math.sign(d) !== Math.sign(deltaSol) && Math.abs(d) > Math.abs(best)) { best = d; cp = accts[j]; }
          }
          out.push({
            hash: sig.signature,
            blockTime: sig.blockTime ?? 0,
            direction: deltaSol > 0 ? 'in' : 'out',
            counterparty: cp,
            asset: 'SOL',
            contract: null,
            amount: Math.abs(deltaSol),
            raw: { slot: sig.slot, fee: tx.meta.fee },
          });
        }
        // SPL token deltas
        const preTok = tx.meta.preTokenBalances || [];
        const postTok = tx.meta.postTokenBalances || [];
        const myPre = preTok.filter((b: any) => b.owner === addr);
        const myPost = postTok.filter((b: any) => b.owner === addr);
        const mints = new Set([...myPre.map((b: any) => b.mint), ...myPost.map((b: any) => b.mint)]);
        for (const mint of mints) {
          const a = (myPre.find((b: any) => b.mint === mint)?.uiTokenAmount?.uiAmount) ?? 0;
          const b = (myPost.find((b: any) => b.mint === mint)?.uiTokenAmount?.uiAmount) ?? 0;
          const d = b - a;
          if (Math.abs(d) > 0) {
            out.push({
              hash: sig.signature,
              blockTime: sig.blockTime ?? 0,
              direction: d > 0 ? 'in' : 'out',
              counterparty: null,
              asset: (mint as string).slice(0, 8),
              contract: mint as string,
              amount: Math.abs(d),
              raw: { slot: sig.slot },
            });
          }
        }
      }
    }
    return out.sort((a, b) => b.blockTime - a.blockTime);
  },
  async getCounterparties(addr, opts = {}) {
    const xfers = await this.getTransfers(addr, { limit: 50 });
    const map = new Map<string, CounterpartyAggregate>();
    for (const x of xfers) {
      if (!x.counterparty) continue;
      const cur = map.get(x.counterparty) || { address: x.counterparty, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: x.blockTime, lastSeen: x.blockTime };
      cur.count++;
      if (x.direction === 'in') cur.inboundValueNative += x.amount; else cur.outboundValueNative += x.amount;
      cur.firstSeen = Math.min(cur.firstSeen, x.blockTime);
      cur.lastSeen  = Math.max(cur.lastSeen,  x.blockTime);
      map.set(x.counterparty, cur);
    }
    return [...map.values()].sort((a, b) => b.count - a.count).slice(0, opts.limit ?? 50);
  },
  explorerUrl(kind, id) {
    if (kind === 'tx') return `https://solscan.io/tx/${id}`;
    if (kind === 'token') return `https://solscan.io/token/${id}`;
    return `https://solscan.io/account/${id}`;
  },
};
