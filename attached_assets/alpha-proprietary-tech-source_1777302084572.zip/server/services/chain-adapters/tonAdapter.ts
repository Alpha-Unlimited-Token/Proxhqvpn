/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — TON adapter (TonAPI public).
 */

import type { ChainAdapter, UnifiedTransfer, AddressProfile, CounterpartyAggregate, TokenHolding } from './types';

const BASE = 'https://tonapi.io/v2';

async function get(path: string): Promise<any> {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`TonAPI ${path}: ${r.status}`);
  return r.json();
}

export const tonAdapter: ChainAdapter = {
  chainKey: 'ton',
  displayName: 'TON',
  nativeSymbol: 'TON',
  isValidAddress: (a) => /^(EQ|UQ|kQ|0Q|-1:|0:)[A-Za-z0-9_\-:]{20,}$/.test(a),
  async getNativeBalance(addr) {
    const j = await get(`/accounts/${addr}`);
    return (j?.balance ?? 0) / 1e9;
  },
  async getAddressProfile(addr) {
    const [a, jettons] = await Promise.all([
      get(`/accounts/${addr}`),
      get(`/accounts/${addr}/jettons`).catch(() => ({ balances: [] })),
    ]);
    const tokens: TokenHolding[] = (jettons?.balances || []).map((b: any) => ({
      asset: b?.jetton?.symbol || 'JETTON',
      contract: b?.jetton?.address || null,
      amount: Number(b?.balance ?? '0') / 10 ** (b?.jetton?.decimals ?? 9),
      decimals: b?.jetton?.decimals,
    }));
    return {
      chain: 'ton',
      address: addr,
      nativeSymbol: 'TON',
      nativeBalance: (a?.balance ?? 0) / 1e9,
      txCount: 0,
      firstSeen: null,
      lastSeen: a?.last_activity ?? null,
      tokens,
    };
  },
  async getTransfers(addr, opts = {}) {
    const limit = Math.min(opts.limit ?? 50, 100);
    const j = await get(`/accounts/${addr}/events?limit=${limit}`);
    const out: UnifiedTransfer[] = [];
    for (const ev of (j?.events || [])) {
      const ts = ev.timestamp || 0;
      for (const act of (ev.actions || [])) {
        if (act.type === 'TonTransfer' && act.TonTransfer) {
          const t = act.TonTransfer;
          const isOut = t.sender?.address === addr;
          out.push({
            hash: ev.event_id,
            blockTime: ts,
            direction: isOut ? 'out' : 'in',
            counterparty: isOut ? t.recipient?.address : t.sender?.address,
            asset: 'TON',
            contract: null,
            amount: (t.amount ?? 0) / 1e9,
            raw: act,
          });
        } else if (act.type === 'JettonTransfer' && act.JettonTransfer) {
          const t = act.JettonTransfer;
          const isOut = t.sender?.address === addr;
          out.push({
            hash: ev.event_id,
            blockTime: ts,
            direction: isOut ? 'out' : 'in',
            counterparty: isOut ? t.recipient?.address : t.sender?.address,
            asset: t.jetton?.symbol || 'JETTON',
            contract: t.jetton?.address || null,
            amount: Number(t.amount ?? 0) / 10 ** (t.jetton?.decimals ?? 9),
            raw: act,
          });
        }
      }
    }
    const since = opts.sinceTs ?? 0;
    return out.filter(x => x.blockTime >= since).sort((a, b) => b.blockTime - a.blockTime).slice(0, limit);
  },
  async getCounterparties(addr, opts = {}) {
    const xfers = await this.getTransfers(addr, { limit: 100 });
    const map = new Map<string, CounterpartyAggregate>();
    for (const x of xfers) {
      if (!x.counterparty) continue;
      const cur = map.get(x.counterparty) || { address: x.counterparty, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: x.blockTime, lastSeen: x.blockTime };
      cur.count++;
      if (x.direction === 'in') cur.inboundValueNative += x.amount; else cur.outboundValueNative += x.amount;
      cur.firstSeen = Math.min(cur.firstSeen, x.blockTime);
      cur.lastSeen  = Math.max(cur.lastSeen,  x.blockTime);
      map.set(x.counterparty, cur);
    }
    return [...map.values()].sort((a, b) => b.count - a.count).slice(0, opts.limit ?? 50);
  },
  explorerUrl(kind, id) {
    if (kind === 'tx') return `https://tonviewer.com/transaction/${id}`;
    if (kind === 'token') return `https://tonviewer.com/${id}`;
    return `https://tonviewer.com/${id}`;
  },
};
