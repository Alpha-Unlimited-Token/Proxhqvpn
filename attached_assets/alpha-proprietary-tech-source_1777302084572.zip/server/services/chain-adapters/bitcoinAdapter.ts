/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — Bitcoin (UTXO) adapter.
 *
 * Bitcoin uses UTXO not account-based, so "counterparty" is best-effort
 * (largest opposite-side input/output). Backed by mempool.space (no key required).
 */

import type { ChainAdapter, UnifiedTransfer, AddressProfile, CounterpartyAggregate } from './types';

const BASE = 'https://mempool.space/api';
// Conservative regex: legacy P2PKH/P2SH (1.../3...), bech32 (bc1...), taproot (bc1p...)
const BTC_RE = /^(bc1[ac-hj-np-z02-9]{8,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/;

async function get(path: string): Promise<any> {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`mempool.space ${path}: ${r.status}`);
  return r.json();
}

export const bitcoinAdapter: ChainAdapter = {
  chainKey: 'bitcoin',
  displayName: 'Bitcoin',
  nativeSymbol: 'BTC',
  isValidAddress: (a) => BTC_RE.test(a),
  async getNativeBalance(addr) {
    const a = await get(`/address/${addr}`);
    const sats = (a?.chain_stats?.funded_txo_sum ?? 0) - (a?.chain_stats?.spent_txo_sum ?? 0);
    return sats / 1e8;
  },
  async getAddressProfile(addr) {
    const a = await get(`/address/${addr}`);
    const sats = (a?.chain_stats?.funded_txo_sum ?? 0) - (a?.chain_stats?.spent_txo_sum ?? 0);
    return {
      chain: 'bitcoin',
      address: addr,
      nativeSymbol: 'BTC',
      nativeBalance: sats / 1e8,
      txCount: (a?.chain_stats?.tx_count ?? 0),
      firstSeen: null,
      lastSeen: null,
      tokens: [],
      notes: ['Bitcoin is UTXO-based; counterparty resolution is best-effort.'],
    };
  },
  async getTransfers(addr, opts = {}) {
    const limit = Math.min(opts.limit ?? 25, 50);
    const txs: any[] = await get(`/address/${addr}/txs`).catch(() => []);
    const since = opts.sinceTs ?? 0;
    const out: UnifiedTransfer[] = [];
    for (const tx of txs.slice(0, limit)) {
      const ts = tx?.status?.block_time ?? 0;
      if (ts < since) continue;
      const myInputSats = (tx.vin || []).filter((v: any) => v?.prevout?.scriptpubkey_address === addr)
        .reduce((s: number, v: any) => s + (v?.prevout?.value ?? 0), 0);
      const myOutputSats = (tx.vout || []).filter((v: any) => v?.scriptpubkey_address === addr)
        .reduce((s: number, v: any) => s + (v?.value ?? 0), 0);
      const deltaSats = myOutputSats - myInputSats;
      if (deltaSats === 0) continue;
      // Counterparty heuristic
      let cp: string | null = null; let bestSats = 0;
      if (deltaSats < 0) {
        // outflow: pick largest non-self output
        for (const o of tx.vout || []) {
          if (o?.scriptpubkey_address && o.scriptpubkey_address !== addr && (o.value ?? 0) > bestSats) {
            bestSats = o.value; cp = o.scriptpubkey_address;
          }
        }
      } else {
        // inflow: pick largest non-self input
        for (const v of tx.vin || []) {
          const a2 = v?.prevout?.scriptpubkey_address;
          const val = v?.prevout?.value ?? 0;
          if (a2 && a2 !== addr && val > bestSats) { bestSats = val; cp = a2; }
        }
      }
      out.push({
        hash: tx.txid,
        blockTime: ts,
        direction: deltaSats > 0 ? 'in' : 'out',
        counterparty: cp,
        asset: 'BTC',
        contract: null,
        amount: Math.abs(deltaSats) / 1e8,
        raw: { fee: tx.fee, size: tx.size },
      });
    }
    return out.sort((a, b) => b.blockTime - a.blockTime);
  },
  async getCounterparties(addr, opts = {}) {
    const xfers = await this.getTransfers(addr, { limit: 50 });
    const map = new Map<string, CounterpartyAggregate>();
    for (const x of xfers) {
      if (!x.counterparty) continue;
      const cur = map.get(x.counterparty) || { address: x.counterparty, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: x.blockTime, lastSeen: x.blockTime };
      cur.count++;
      if (x.direction === 'in') cur.inboundValueNative += x.amount; else cur.outboundValueNative += x.amount;
      cur.firstSeen = Math.min(cur.firstSeen, x.blockTime);
      cur.lastSeen  = Math.max(cur.lastSeen,  x.blockTime);
      map.set(x.counterparty, cur);
    }
    return [...map.values()].sort((a, b) => b.count - a.count).slice(0, opts.limit ?? 50);
  },
  explorerUrl(kind, id) {
    if (kind === 'tx') return `https://mempool.space/tx/${id}`;
    return `https://mempool.space/address/${id}`;
  },
};
