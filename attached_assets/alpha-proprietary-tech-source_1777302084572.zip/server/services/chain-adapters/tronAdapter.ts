/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — Tron adapter (TronGrid public API).
 */

import type { ChainAdapter, UnifiedTransfer, AddressProfile, CounterpartyAggregate, TokenHolding } from './types';

import crypto from 'node:crypto';

const BASE = 'https://api.trongrid.io';

async function get(path: string): Promise<any> {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`TronGrid ${path}: ${r.status}`);
  return r.json();
}

const B58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function base58encode(bytes: Buffer): string {
  let n = BigInt('0x' + bytes.toString('hex'));
  let out = '';
  const fiftyEight = 58n;
  while (n > 0n) { const r = Number(n % fiftyEight); out = B58_ALPHABET[r] + out; n = n / fiftyEight; }
  for (const b of bytes) { if (b === 0) out = '1' + out; else break; }
  return out;
}

/** Convert a Tron 21-byte hex address (e.g. 41…) to base58 (e.g. T…). Idempotent. */
function tronHexToBase58(hex: string | undefined | null): string | null {
  if (!hex) return null;
  if (hex.startsWith('T') && hex.length === 34) return hex;
  const clean = hex.toLowerCase().startsWith('0x') ? hex.slice(2) : hex;
  if (!/^41[0-9a-f]{40}$/i.test(clean)) return null;
  const raw = Buffer.from(clean, 'hex');
  const sha1 = crypto.createHash('sha256').update(raw).digest();
  const sha2 = crypto.createHash('sha256').update(sha1).digest();
  const checksum = sha2.subarray(0, 4);
  return base58encode(Buffer.concat([raw, checksum]));
}

export const tronAdapter: ChainAdapter = {
  chainKey: 'tron',
  displayName: 'Tron',
  nativeSymbol: 'TRX',
  isValidAddress: (a) => /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a),
  async getNativeBalance(addr) {
    const j = await get(`/v1/accounts/${addr}`);
    const sun = j?.data?.[0]?.balance ?? 0;
    return sun / 1e6;
  },
  async getAddressProfile(addr) {
    const j = await get(`/v1/accounts/${addr}`);
    const acc = j?.data?.[0];
    const sun = acc?.balance ?? 0;
    const tokens: TokenHolding[] = (acc?.trc20 || []).flatMap((m: any) => Object.entries(m).map(([contract, amount]) => ({
      asset: 'TRC20',
      contract,
      amount: Number(amount as string) / 1e6, // best-effort; true decimals require contract call
    })));
    return {
      chain: 'tron',
      address: addr,
      nativeSymbol: 'TRX',
      nativeBalance: sun / 1e6,
      txCount: 0,
      firstSeen: acc?.create_time ? Math.floor(acc.create_time / 1000) : null,
      lastSeen: acc?.latest_opration_time ? Math.floor(acc.latest_opration_time / 1000) : null,
      tokens,
      notes: ['TRC20 decimals are best-effort (default 6); query contract for exact value.'],
    };
  },
  async getTransfers(addr, opts = {}) {
    const limit = Math.min(opts.limit ?? 50, 200);
    const [native, trc20] = await Promise.all([
      get(`/v1/accounts/${addr}/transactions?limit=${limit}`).catch(() => ({ data: [] })),
      get(`/v1/accounts/${addr}/transactions/trc20?limit=${limit}`).catch(() => ({ data: [] })),
    ]);
    const out: UnifiedTransfer[] = [];
    for (const t of (native?.data || [])) {
      const c = t.raw_data?.contract?.[0]?.parameter?.value;
      if (!c?.amount || !c?.owner_address) continue;
      const fromB58 = tronHexToBase58(c.owner_address);
      const toB58   = tronHexToBase58(c.to_address);
      const isOut = fromB58 === addr;
      out.push({
        hash: t.txID,
        blockTime: Math.floor((t.block_timestamp || t.raw_data?.timestamp || 0) / 1000),
        direction: isOut ? 'out' : 'in',
        counterparty: isOut ? toB58 : fromB58,
        asset: 'TRX',
        contract: null,
        amount: c.amount / 1e6,
        raw: t,
      });
    }
    for (const t of (trc20?.data || [])) {
      const isOut = t.from === addr;
      out.push({
        hash: t.transaction_id,
        blockTime: Math.floor((t.block_timestamp || 0) / 1000),
        direction: isOut ? 'out' : 'in',
        counterparty: isOut ? t.to : t.from,
        asset: t.token_info?.symbol || 'TRC20',
        contract: t.token_info?.address || null,
        amount: Number(t.value || 0) / 10 ** (t.token_info?.decimals ?? 6),
        raw: t,
      });
    }
    const since = opts.sinceTs ?? 0;
    return out.filter(x => x.blockTime >= since).sort((a, b) => b.blockTime - a.blockTime).slice(0, limit);
  },
  async getCounterparties(addr, opts = {}) {
    const xfers = await this.getTransfers(addr, { limit: 100 });
    const map = new Map<string, CounterpartyAggregate>();
    for (const x of xfers) {
      if (!x.counterparty) continue;
      const cur = map.get(x.counterparty) || { address: x.counterparty, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: x.blockTime, lastSeen: x.blockTime };
      cur.count++;
      if (x.direction === 'in') cur.inboundValueNative += x.amount; else cur.outboundValueNative += x.amount;
      cur.firstSeen = Math.min(cur.firstSeen, x.blockTime);
      cur.lastSeen  = Math.max(cur.lastSeen,  x.blockTime);
      map.set(x.counterparty, cur);
    }
    return [...map.values()].sort((a, b) => b.count - a.count).slice(0, opts.limit ?? 50);
  },
  explorerUrl(kind, id) {
    if (kind === 'tx') return `https://tronscan.org/#/transaction/${id}`;
    if (kind === 'token') return `https://tronscan.org/#/token20/${id}`;
    return `https://tronscan.org/#/address/${id}`;
  },
};
