/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL — Title 17 / DMCA / CFAA / DTSA
 * Alpha Universal Chain Adapter Layer™ (UCAL) — EVM adapter (ETH/POLY/ARB/OP/BASE).
 */

import type { ChainAdapter, ChainKey, UnifiedTransfer, AddressProfile, CounterpartyAggregate, TokenHolding } from './types';

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || '';

const NETWORKS: Record<string, { display: string; alchemy: string; explorer: string; native: string }> = {
  ethereum: { display: 'Ethereum',  alchemy: 'eth-mainnet',     explorer: 'https://etherscan.io',  native: 'ETH'   },
  polygon:  { display: 'Polygon',   alchemy: 'polygon-mainnet', explorer: 'https://polygonscan.com', native: 'MATIC' },
  arbitrum: { display: 'Arbitrum',  alchemy: 'arb-mainnet',     explorer: 'https://arbiscan.io',     native: 'ETH'   },
  optimism: { display: 'Optimism',  alchemy: 'opt-mainnet',     explorer: 'https://optimistic.etherscan.io', native: 'ETH' },
  base:     { display: 'Base',      alchemy: 'base-mainnet',    explorer: 'https://basescan.org',    native: 'ETH'   },
};

function rpcUrl(chain: string): string {
  return `https://${NETWORKS[chain].alchemy}.g.alchemy.com/v2/${ALCHEMY_KEY}`;
}

async function rpcCall(chain: string, method: string, params: any[]): Promise<any> {
  const r = await fetch(rpcUrl(chain), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  const j = await r.json();
  if (j.error) throw new Error(`${chain} RPC ${method}: ${j.error.message || JSON.stringify(j.error)}`);
  return j.result;
}

export function makeEvmAdapter(chain: 'ethereum'|'polygon'|'arbitrum'|'optimism'|'base'): ChainAdapter {
  const meta = NETWORKS[chain];
  return {
    chainKey: chain as ChainKey,
    displayName: meta.display,
    nativeSymbol: meta.native,
    isValidAddress: (a) => /^0x[a-fA-F0-9]{40}$/.test(a),
    async getNativeBalance(addr) {
      const hex = await rpcCall(chain, 'eth_getBalance', [addr, 'latest']);
      return Number(BigInt(hex)) / 1e18;
    },
    async getAddressProfile(addr) {
      const [bal, txCountHex] = await Promise.all([
        this.getNativeBalance(addr),
        rpcCall(chain, 'eth_getTransactionCount', [addr, 'latest']),
      ]);
      let tokens: TokenHolding[] = [];
      try {
        const tb = await rpcCall(chain, 'alchemy_getTokenBalances', [addr]);
        const nonZero = (tb?.tokenBalances || []).filter((t: any) => t.tokenBalance && t.tokenBalance !== '0x' + '0'.repeat(64)).slice(0, 25);
        for (const t of nonZero) {
          try {
            const m = await rpcCall(chain, 'alchemy_getTokenMetadata', [t.contractAddress]);
            const dec = m?.decimals ?? 18;
            tokens.push({
              asset: m?.symbol || 'UNKNOWN',
              contract: t.contractAddress,
              amount: Number(BigInt(t.tokenBalance)) / 10 ** dec,
              decimals: dec,
            });
          } catch {}
        }
      } catch {}
      return {
        chain: chain as ChainKey,
        address: addr,
        nativeSymbol: meta.native,
        nativeBalance: bal,
        txCount: Number(BigInt(txCountHex || '0x0')),
        firstSeen: null,
        lastSeen: null,
        tokens,
      };
    },
    async getTransfers(addr, opts = {}) {
      const limit = Math.min(opts.limit ?? 50, 1000);
      const params = {
        fromBlock: '0x0',
        toBlock: 'latest',
        category: ['external', 'erc20'],
        withMetadata: true,
        excludeZeroValue: false,
        maxCount: '0x' + limit.toString(16),
        order: 'desc',
      };
      const [outRes, inRes] = await Promise.all([
        rpcCall(chain, 'alchemy_getAssetTransfers', [{ ...params, fromAddress: addr }]).catch(() => ({ transfers: [] })),
        rpcCall(chain, 'alchemy_getAssetTransfers', [{ ...params, toAddress: addr }]).catch(() => ({ transfers: [] })),
      ]);
      const norm = (t: any, dir: 'in'|'out'): UnifiedTransfer => ({
        hash: t.hash,
        blockTime: t.metadata?.blockTimestamp ? Math.floor(new Date(t.metadata.blockTimestamp).getTime() / 1000) : 0,
        direction: dir,
        counterparty: dir === 'in' ? t.from : t.to,
        asset: t.asset || meta.native,
        contract: t.rawContract?.address || null,
        amount: Number(t.value || 0),
        raw: t,
      });
      const all = [
        ...(outRes.transfers || []).map((t: any) => norm(t, 'out')),
        ...(inRes.transfers || []).map((t: any) => norm(t, 'in')),
      ];
      const since = opts.sinceTs ?? 0;
      return all.filter(t => t.blockTime >= since).sort((a, b) => b.blockTime - a.blockTime).slice(0, limit);
    },
    async getCounterparties(addr, opts = {}) {
      const xfers = await this.getTransfers(addr, { limit: 200 });
      const map = new Map<string, CounterpartyAggregate>();
      for (const x of xfers) {
        if (!x.counterparty) continue;
        const k = x.counterparty.toLowerCase();
        const cur = map.get(k) || { address: k, count: 0, inboundValueNative: 0, outboundValueNative: 0, firstSeen: x.blockTime, lastSeen: x.blockTime };
        cur.count++;
        if (x.direction === 'in') cur.inboundValueNative += x.amount; else cur.outboundValueNative += x.amount;
        cur.firstSeen = Math.min(cur.firstSeen, x.blockTime || cur.firstSeen);
        cur.lastSeen  = Math.max(cur.lastSeen,  x.blockTime || cur.lastSeen);
        map.set(k, cur);
      }
      return [...map.values()].sort((a, b) => b.count - a.count).slice(0, opts.limit ?? 50);
    },
    explorerUrl(kind, id) {
      const base = meta.explorer;
      if (kind === 'tx') return `${base}/tx/${id}`;
      if (kind === 'token') return `${base}/token/${id}`;
      return `${base}/address/${id}`;
    },
  };
}
