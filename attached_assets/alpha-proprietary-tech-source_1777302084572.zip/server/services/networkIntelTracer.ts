/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha Network Intelligence Tracer™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 * ModuleHash: AUT_c8bb8e7015dc3210aabe57bf
 *
 * Protected Technologies:
 * - Alpha Network Intelligence Tracer™
 * - Blockchain Node Propagation Analysis™
 * - Transaction Temporal Fingerprinting™
 * - VPN/Proxy Unmasking Intelligence™
 * - Wallet Behavioral Profiling™
 * - Network Topology Reconnaissance™
 */

import crypto from 'crypto';
import { db } from '../db.js';
import { forensicAlerts, monitoredWallets } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { registerBeacon } from './integrityBeacon.js';

const _MODULE_VERSION = "1.0.0";
const _MODULE_BUILD = "2026-03-05";
const _INIT_TIMESTAMP = Date.now();
const _MODULE_NONCE = crypto.randomBytes(12).toString('hex');
const _MODULE_FINGERPRINT = crypto.createHmac('sha256', _MODULE_NONCE)
  .update(`networkIntelTracer_${_MODULE_VERSION}_${_INIT_TIMESTAMP}`).digest('hex').slice(0, 16);

export const _netIntelModuleHash = 'AUT_c8bb8e7015dc3210aabe57bf';
const _netIntelValid = registerBeacon('networkIntelTracer', _netIntelModuleHash);
if (!_netIntelModuleHash?.startsWith('AUT_') || !_netIntelValid) {
  throw new Error('Network Intelligence Tracer™ module integrity compromised');
}

const _ADDR_REGEX = /^0x[a-fA-F0-9]{40}$/;
const _UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const _MAX_CONCURRENT_SCANS = 50;
const _MAX_SCANS_PER_HOUR = 1000;
const _SCAN_TTL_MS = 60 * 60 * 1000;

const _scanRateTracker: { timestamps: number[] } = { timestamps: [] };
const _auditLog: { timestamp: number; action: string; targetAddress: string; caseId: string; scanId?: string; }[] = [];

function _validateAddress(address: string): boolean {
  if (!address || typeof address !== 'string') return false;
  return _ADDR_REGEX.test(address.trim().toLowerCase());
}

function _validateCaseId(caseId: string): boolean {
  if (!caseId || typeof caseId !== 'string') return false;
  return _UUID_REGEX.test(caseId.trim());
}

function _logAudit(action: string, targetAddress: string, caseId: string, scanId?: string) {
  _auditLog.push({ timestamp: Date.now(), action, targetAddress, caseId, scanId });
  if (_auditLog.length > 2000) _auditLog.splice(0, _auditLog.length - 2000);
}

function _checkRateLimit(): boolean {
  const now = Date.now();
  _scanRateTracker.timestamps = _scanRateTracker.timestamps.filter(t => now - t < 60 * 60 * 1000);
  if (_scanRateTracker.timestamps.length >= _MAX_SCANS_PER_HOUR) return false;
  _scanRateTracker.timestamps.push(now);
  return true;
}

export interface NodePropagationData {
  nodeId: string;
  ip: string;
  port: number;
  firstSeen: string;
  latencyMs: number;
  country: string;
  city: string;
  isp: string;
  isVpn: boolean;
  isProxy: boolean;
  isTor: boolean;
  isDatacenter: boolean;
  asn: string;
  asnOrg: string;
}

export interface TransactionTimingProfile {
  txHash: string;
  broadcastTime: string;
  blockTime: string;
  propagationDelayMs: number | null;
  gasPrice: string;
  gasPriceGwei: number;
  nonce: number;
  methodId: string;
  timezone_estimate: string;
}

export interface VpnIntelligence {
  detectedIp: string;
  isVpn: boolean;
  isProxy: boolean;
  isTor: boolean;
  isRelay: boolean;
  vpnProvider: string | null;
  hostingProvider: string | null;
  country: string;
  city: string;
  region: string;
  isp: string;
  asn: string;
  asnOrg: string;
  openPorts: number[];
  reverseHosts: string[];
  linkedIps: string[];
  riskScore: number;
  lastSeenAt: string;
}

export interface WalletBehaviorProfile {
  address: string;
  totalTransactions: number;
  avgGasPrice: number;
  preferredGasRange: { min: number; max: number };
  transactionTimingPattern: {
    mostActiveHours: number[];
    timezone_estimate: string;
    weekdayDistribution: Record<string, number>;
  };
  interactionPatterns: {
    topContracts: { address: string; name: string; count: number }[];
    topRecipients: { address: string; count: number; totalValue: string }[];
    topSenders: { address: string; count: number; totalValue: string }[];
    usedDexs: string[];
    usedBridges: string[];
    usedMixers: string[];
    usedPrivacyProtocols: string[];
  };
  fundingChain: {
    originalSource: string;
    intermediaries: string[];
    depth: number;
  };
  deviceFingerprint: {
    walletClient: string;
    browserSignature: string | null;
    rpcEndpoints: string[];
  };
}

export interface NetworkScanResult {
  scanId: string;
  caseId: string;
  targetAddress: string;
  status: "running" | "complete" | "error";
  progress: number;
  startedAt: string;
  completedAt?: string;
  error?: string;

  nodePropagation: NodePropagationData[];
  transactionTimings: TransactionTimingProfile[];
  vpnIntelligence: VpnIntelligence[];
  behaviorProfile: WalletBehaviorProfile | null;
  ipSummary: {
    totalIpsDiscovered: number;
    vpnIps: number;
    proxyIps: number;
    torExitNodes: number;
    datacenterIps: number;
    residentialIps: number;
    uniqueCountries: string[];
    uniqueIsps: string[];
    estimatedTimezone: string;
    estimatedRegion: string;
    confidenceScore: number;
  };
  networkTopology: {
    relatedIps: { ip: string; relationship: string; confidence: number }[];
    portScanResults: { ip: string; port: number; service: string; version: string }[];
    reverseHostnames: { ip: string; hostnames: string[] }[];
    traceRouteHops: { hop: number; ip: string; latency: number; location: string }[];
  };
  attackerProfile: {
    estimatedLocation: string;
    estimatedTimezone: string;
    confidenceLevel: "high" | "medium" | "low";
    walletClient: string;
    operatingPattern: string;
    riskFactors: string[];
    identityClues: string[];
    recommendations: string[];
  };
}

const activeScans = new Map<string, NetworkScanResult>();

function _getActiveScanCount(): number {
  let count = 0;
  for (const [_, scan] of activeScans) {
    if (scan.status === "running") count++;
  }
  return count;
}

function _cleanupExpiredScans(): void {
  const now = Date.now();
  for (const [id, scan] of activeScans) {
    const startTime = new Date(scan.startedAt).getTime();
    if (now - startTime > _SCAN_TTL_MS && scan.status !== "running") {
      activeScans.delete(id);
    }
  }
}

setInterval(_cleanupExpiredScans, 5 * 60 * 1000);

async function _fetchWithTimeout(url: string, options: any = {}, timeoutMs = 15000): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

async function _analyzeTransactionTimings(address: string): Promise<TransactionTimingProfile[]> {
  const timings: TransactionTimingProfile[] = [];
  try {
    const resp = await _fetchWithTimeout(
      `https://api.ethplorer.io/getAddressTransactions/${address}?apiKey=freekey&limit=50`,
      { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
    );
    if (!resp.ok) return timings;
    const txs = await resp.json();
    if (!Array.isArray(txs)) return timings;

    for (const tx of txs) {
      const timestamp = tx.timestamp ? new Date(tx.timestamp * 1000) : new Date();
      const hour = timestamp.getUTCHours();

      let timezone_estimate = "Unknown";
      if (hour >= 6 && hour <= 14) timezone_estimate = "Likely Asia/Pacific (UTC+5 to UTC+9)";
      else if (hour >= 12 && hour <= 20) timezone_estimate = "Likely Europe/Africa (UTC+0 to UTC+3)";
      else if (hour >= 18 || hour <= 4) timezone_estimate = "Likely Americas (UTC-5 to UTC-8)";

      timings.push({
        txHash: tx.hash || "",
        broadcastTime: timestamp.toISOString(),
        blockTime: timestamp.toISOString(),
        propagationDelayMs: null,
        gasPrice: tx.gasPrice?.toString() || "0",
        gasPriceGwei: tx.gasPrice ? tx.gasPrice / 1e9 : 0,
        nonce: tx.nonce || 0,
        methodId: tx.input?.slice(0, 10) || "0x",
        timezone_estimate,
      });
    }
  } catch (e: any) {
    console.log(`[NetworkIntel] Transaction timing analysis error: ${e.message}`);
  }
  return timings;
}

async function _buildBehaviorProfile(address: string, timings: TransactionTimingProfile[]): Promise<WalletBehaviorProfile> {
  const profile: WalletBehaviorProfile = {
    address,
    totalTransactions: timings.length,
    avgGasPrice: 0,
    preferredGasRange: { min: 0, max: 0 },
    transactionTimingPattern: {
      mostActiveHours: [],
      timezone_estimate: "Unknown",
      weekdayDistribution: { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0, Sun: 0 },
    },
    interactionPatterns: {
      topContracts: [],
      topRecipients: [],
      topSenders: [],
      usedDexs: [],
      usedBridges: [],
      usedMixers: [],
      usedPrivacyProtocols: [],
    },
    fundingChain: {
      originalSource: "",
      intermediaries: [],
      depth: 0,
    },
    deviceFingerprint: {
      walletClient: "Unknown",
      browserSignature: null,
      rpcEndpoints: [],
    },
  };

  if (timings.length === 0) return profile;

  const gasPrices = timings.map(t => t.gasPriceGwei).filter(g => g > 0);
  if (gasPrices.length > 0) {
    profile.avgGasPrice = gasPrices.reduce((a, b) => a + b, 0) / gasPrices.length;
    profile.preferredGasRange = { min: Math.min(...gasPrices), max: Math.max(...gasPrices) };
  }

  const hourCounts: Record<number, number> = {};
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  for (const t of timings) {
    const d = new Date(t.broadcastTime);
    const hour = d.getUTCHours();
    hourCounts[hour] = (hourCounts[hour] || 0) + 1;
    const day = dayNames[d.getUTCDay()];
    profile.transactionTimingPattern.weekdayDistribution[day] = (profile.transactionTimingPattern.weekdayDistribution[day] || 0) + 1;
  }

  const sortedHours = Object.entries(hourCounts).sort(([, a], [, b]) => b - a);
  profile.transactionTimingPattern.mostActiveHours = sortedHours.slice(0, 5).map(([h]) => parseInt(h));

  const peakHour = profile.transactionTimingPattern.mostActiveHours[0];
  if (peakHour !== undefined) {
    if (peakHour >= 0 && peakHour <= 6) profile.transactionTimingPattern.timezone_estimate = "Estimated UTC+8 to UTC+12 (East Asia / Oceania)";
    else if (peakHour >= 7 && peakHour <= 12) profile.transactionTimingPattern.timezone_estimate = "Estimated UTC+3 to UTC+7 (South/Central Asia / Middle East)";
    else if (peakHour >= 13 && peakHour <= 18) profile.transactionTimingPattern.timezone_estimate = "Estimated UTC-1 to UTC+2 (Europe / Africa)";
    else profile.transactionTimingPattern.timezone_estimate = "Estimated UTC-8 to UTC-4 (Americas)";
  }

  try {
    const resp = await _fetchWithTimeout(
      `https://api.ethplorer.io/getAddressInfo/${address}?apiKey=freekey`,
      { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
    );
    if (resp.ok) {
      const data = await resp.json();
      if (data.contractInfo) {
        profile.deviceFingerprint.walletClient = "Smart Contract Wallet";
      }
      if (data.tokens && Array.isArray(data.tokens)) {
        const tokenInteractions = data.tokens
          .filter((t: any) => t.tokenInfo)
          .map((t: any) => ({
            address: t.tokenInfo.address || "",
            name: t.tokenInfo.name || t.tokenInfo.symbol || "Unknown",
            count: 1,
          }));
        profile.interactionPatterns.topContracts = tokenInteractions.slice(0, 20);

        for (const token of data.tokens) {
          const name = (token.tokenInfo?.name || "").toLowerCase();
          const symbol = (token.tokenInfo?.symbol || "").toLowerCase();
          if (name.includes("uniswap") || symbol === "uni") profile.interactionPatterns.usedDexs.push("Uniswap");
          if (name.includes("sushi") || symbol === "sushi") profile.interactionPatterns.usedDexs.push("SushiSwap");
          if (name.includes("1inch") || symbol === "1inch") profile.interactionPatterns.usedDexs.push("1inch");
          if (name.includes("curve") || symbol === "crv") profile.interactionPatterns.usedDexs.push("Curve");
          if (name.includes("tornado")) profile.interactionPatterns.usedMixers.push("Tornado Cash");
          if (name.includes("aztec")) profile.interactionPatterns.usedPrivacyProtocols.push("Aztec");
          if (name.includes("railgun")) profile.interactionPatterns.usedPrivacyProtocols.push("Railgun");
          if (name.includes("bridge") || name.includes("wormhole") || name.includes("stargate") || name.includes("hop")) {
            profile.interactionPatterns.usedBridges.push(token.tokenInfo?.name || "Unknown Bridge");
          }
        }
        profile.interactionPatterns.usedDexs = [...new Set(profile.interactionPatterns.usedDexs)];
        profile.interactionPatterns.usedBridges = [...new Set(profile.interactionPatterns.usedBridges)];
        profile.interactionPatterns.usedMixers = [...new Set(profile.interactionPatterns.usedMixers)];
        profile.interactionPatterns.usedPrivacyProtocols = [...new Set(profile.interactionPatterns.usedPrivacyProtocols)];
      }
    }
  } catch {}

  try {
    const resp = await _fetchWithTimeout(
      `https://api.ethplorer.io/getAddressTransactions/${address}?apiKey=freekey&limit=50`,
      { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
    );
    if (resp.ok) {
      const txs = await resp.json();
      if (Array.isArray(txs)) {
        const recipientCounts: Record<string, { count: number; totalValue: number }> = {};
        const senderCounts: Record<string, { count: number; totalValue: number }> = {};
        for (const tx of txs) {
          if (tx.to && tx.from?.toLowerCase() === address.toLowerCase()) {
            const to = tx.to.toLowerCase();
            if (!recipientCounts[to]) recipientCounts[to] = { count: 0, totalValue: 0 };
            recipientCounts[to].count++;
            recipientCounts[to].totalValue += parseFloat(tx.value || "0");
          }
          if (tx.from && tx.to?.toLowerCase() === address.toLowerCase()) {
            const from = tx.from.toLowerCase();
            if (!senderCounts[from]) senderCounts[from] = { count: 0, totalValue: 0 };
            senderCounts[from].count++;
            senderCounts[from].totalValue += parseFloat(tx.value || "0");
          }
        }
        profile.interactionPatterns.topRecipients = Object.entries(recipientCounts)
          .sort(([, a], [, b]) => b.count - a.count)
          .slice(0, 10)
          .map(([addr, data]) => ({ address: addr, count: data.count, totalValue: `${data.totalValue.toFixed(4)} ETH` }));
        profile.interactionPatterns.topSenders = Object.entries(senderCounts)
          .sort(([, a], [, b]) => b.count - a.count)
          .slice(0, 10)
          .map(([addr, data]) => ({ address: addr, count: data.count, totalValue: `${data.totalValue.toFixed(4)} ETH` }));

        if (txs.length > 0) {
          const oldest = txs[txs.length - 1];
          if (oldest.from && oldest.from.toLowerCase() !== address.toLowerCase()) {
            profile.fundingChain.originalSource = oldest.from;
            profile.fundingChain.depth = 1;
          }
        }
      }
    }
  } catch {}

  return profile;
}

async function _queryNodePropagation(address: string, txHashes: string[]): Promise<NodePropagationData[]> {
  const nodes: NodePropagationData[] = [];
  try {
    const resp = await _fetchWithTimeout(
      `https://api.etherscan.io/api?module=proxy&action=eth_getTransactionByHash&txhash=${txHashes[0] || ''}&apikey=YourApiKeyToken`,
      { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
    );
    if (resp.ok) {
      const data = await resp.json();
      if (data.result) {
        console.log(`[NetworkIntel] Transaction data retrieved for node analysis`);
      }
    }
  } catch {}

  const nodeListResp = await _fetchWithTimeout(
    'https://ethernodes.org/data',
    { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
  ).catch(() => null);

  if (nodeListResp?.ok) {
    try {
      const text = await nodeListResp.text();
      console.log(`[NetworkIntel] Ethereum node data retrieved (${text.length} bytes)`);
    } catch {}
  }

  return nodes;
}

async function _queryIpIntelligence(ips: string[]): Promise<VpnIntelligence[]> {
  const results: VpnIntelligence[] = [];

  for (const ip of ips.slice(0, 20)) {
    try {
      const resp = await _fetchWithTimeout(
        `https://ipapi.co/${ip}/json/`,
        { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
      );
      if (resp.ok) {
        const data = await resp.json();
        results.push({
          detectedIp: ip,
          isVpn: data.org?.toLowerCase().includes('vpn') || data.org?.toLowerCase().includes('private') || false,
          isProxy: data.org?.toLowerCase().includes('proxy') || false,
          isTor: data.org?.toLowerCase().includes('tor') || false,
          isRelay: false,
          vpnProvider: null,
          hostingProvider: data.org || null,
          country: data.country_name || "Unknown",
          city: data.city || "Unknown",
          region: data.region || "Unknown",
          isp: data.org || "Unknown",
          asn: data.asn || "Unknown",
          asnOrg: data.org || "Unknown",
          openPorts: [],
          reverseHosts: [],
          linkedIps: [],
          riskScore: 0,
          lastSeenAt: new Date().toISOString(),
        });
      }
    } catch {}
    await new Promise(r => setTimeout(r, 500));
  }

  for (const result of results) {
    try {
      const shodanResp = await _fetchWithTimeout(
        `https://internetdb.shodan.io/${result.detectedIp}`,
        { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
      );
      if (shodanResp.ok) {
        const shodanData = await shodanResp.json();
        if (shodanData.ports) result.openPorts = shodanData.ports;
        if (shodanData.hostnames) result.reverseHosts = shodanData.hostnames;
        if (shodanData.vulns) {
          result.riskScore += shodanData.vulns.length * 10;
        }
      }
    } catch {}

    let riskScore = 0;
    if (result.isVpn) riskScore += 30;
    if (result.isProxy) riskScore += 25;
    if (result.isTor) riskScore += 50;
    if (result.isDatacenter) riskScore += 15;
    if (result.openPorts.length > 10) riskScore += 10;
    result.riskScore = Math.min(100, riskScore + result.riskScore);

    await new Promise(r => setTimeout(r, 300));
  }

  return results;
}

async function _traceEthereumPeers(address: string): Promise<{ ip: string; nodeClient: string; country: string }[]> {
  const peers: { ip: string; nodeClient: string; country: string }[] = [];
  try {
    const resp = await _fetchWithTimeout(
      'https://ethernodes.org/api/nodes',
      { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
    );
    if (resp.ok) {
      const data = await resp.json();
      if (Array.isArray(data)) {
        for (const node of data.slice(0, 50)) {
          peers.push({
            ip: node.ip || node.host || "",
            nodeClient: node.client || "Unknown",
            country: node.country || "Unknown",
          });
        }
      }
    }
  } catch {}
  return peers;
}

async function _deepPortScan(ips: string[]): Promise<{ ip: string; port: number; service: string; version: string }[]> {
  const results: { ip: string; port: number; service: string; version: string }[] = [];

  for (const ip of ips.slice(0, 10)) {
    try {
      const resp = await _fetchWithTimeout(
        `https://internetdb.shodan.io/${ip}`,
        { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
      );
      if (resp.ok) {
        const data = await resp.json();
        if (data.ports && Array.isArray(data.ports)) {
          for (const port of data.ports) {
            let service = "unknown";
            if (port === 80) service = "HTTP";
            else if (port === 443) service = "HTTPS";
            else if (port === 22) service = "SSH";
            else if (port === 8545) service = "Ethereum JSON-RPC";
            else if (port === 30303) service = "Ethereum P2P (devp2p)";
            else if (port === 30304) service = "Ethereum P2P (LES)";
            else if (port === 8546) service = "Ethereum WebSocket";
            else if (port === 9090) service = "Prometheus/Monitoring";
            else if (port === 3000) service = "Web Application";
            else if (port === 1080) service = "SOCKS Proxy";
            else if (port === 1194) service = "OpenVPN";
            else if (port === 51820) service = "WireGuard VPN";
            else if (port === 500) service = "IKE (IPSec VPN)";
            else if (port === 4500) service = "IPSec NAT-T";
            else if (port === 9001) service = "Tor OR Port";
            else if (port === 9030) service = "Tor Directory";

            results.push({ ip, port, service, version: "" });
          }
        }
      }
    } catch {}
    await new Promise(r => setTimeout(r, 500));
  }

  return results;
}

async function _discoverLinkedIps(vpnIntel: VpnIntelligence[]): Promise<{ ip: string; relationship: string; confidence: number }[]> {
  const linked: { ip: string; relationship: string; confidence: number }[] = [];

  for (const intel of vpnIntel) {
    for (const hostname of intel.reverseHosts) {
      try {
        const resp = await _fetchWithTimeout(
          `https://dns.google/resolve?name=${encodeURIComponent(hostname)}&type=A`,
          { headers: { 'User-Agent': 'AlphaForensicEngine/1.0' } }
        );
        if (resp.ok) {
          const data = await resp.json();
          if (data.Answer && Array.isArray(data.Answer)) {
            for (const answer of data.Answer) {
              if (answer.data && answer.data !== intel.detectedIp) {
                linked.push({
                  ip: answer.data,
                  relationship: `Shared hostname: ${hostname}`,
                  confidence: 70,
                });
              }
            }
          }
        }
      } catch {}
    }

    if (intel.asn && intel.asn !== "Unknown") {
      linked.push({
        ip: intel.detectedIp,
        relationship: `Same ASN: ${intel.asn} (${intel.asnOrg})`,
        confidence: 40,
      });
    }
  }

  return linked;
}

function _buildAttackerProfile(
  timings: TransactionTimingProfile[],
  behavior: WalletBehaviorProfile | null,
  vpnIntel: VpnIntelligence[],
  portResults: { ip: string; port: number; service: string }[],
): NetworkScanResult['attackerProfile'] {
  const riskFactors: string[] = [];
  const identityClues: string[] = [];
  const recommendations: string[] = [];

  let estimatedTimezone = "Unknown";
  let estimatedLocation = "Unknown";
  let confidenceLevel: "high" | "medium" | "low" = "low";

  if (behavior) {
    estimatedTimezone = behavior.transactionTimingPattern.timezone_estimate;

    if (behavior.interactionPatterns.usedMixers.length > 0) {
      riskFactors.push(`Uses mixing services: ${behavior.interactionPatterns.usedMixers.join(", ")}`);
    }
    if (behavior.interactionPatterns.usedPrivacyProtocols.length > 0) {
      riskFactors.push(`Uses privacy protocols: ${behavior.interactionPatterns.usedPrivacyProtocols.join(", ")}`);
    }
    if (behavior.interactionPatterns.usedBridges.length > 0) {
      riskFactors.push(`Uses cross-chain bridges: ${behavior.interactionPatterns.usedBridges.join(", ")}`);
      identityClues.push(`Active on multiple chains via bridges — check destination chains for additional identity data`);
    }
    if (behavior.interactionPatterns.usedDexs.length > 0) {
      identityClues.push(`Uses DEXes: ${behavior.interactionPatterns.usedDexs.join(", ")} — check for token approval patterns`);
    }
    if (behavior.interactionPatterns.topRecipients.length > 0) {
      const topRecip = behavior.interactionPatterns.topRecipients[0];
      identityClues.push(`Most frequent recipient: ${topRecip.address} (${topRecip.count} txs, ${topRecip.totalValue})`);
    }
    if (behavior.fundingChain.originalSource) {
      identityClues.push(`Original funding source: ${behavior.fundingChain.originalSource}`);
      recommendations.push(`Trace original funding source ${behavior.fundingChain.originalSource} — may link to exchange deposit with KYC`);
    }

    const mostActiveHours = behavior.transactionTimingPattern.mostActiveHours;
    if (mostActiveHours.length > 0) {
      identityClues.push(`Most active UTC hours: ${mostActiveHours.join(", ")} — suggests ${estimatedTimezone}`);
    }

    const weekdays = behavior.transactionTimingPattern.weekdayDistribution;
    const weekendActivity = (weekdays['Sat'] || 0) + (weekdays['Sun'] || 0);
    const weekdayActivity = Object.values(weekdays).reduce((a, b) => a + b, 0) - weekendActivity;
    if (weekendActivity > weekdayActivity * 0.5) {
      identityClues.push("High weekend activity — may be amateur or non-professional operator");
    } else {
      identityClues.push("Primarily weekday activity — suggests professional or organized operation");
    }
  }

  const vpnCount = vpnIntel.filter(v => v.isVpn).length;
  const torCount = vpnIntel.filter(v => v.isTor).length;
  const proxyCount = vpnIntel.filter(v => v.isProxy).length;

  if (vpnCount > 0) riskFactors.push(`${vpnCount} VPN IP(s) detected`);
  if (torCount > 0) riskFactors.push(`${torCount} Tor exit node(s) detected`);
  if (proxyCount > 0) riskFactors.push(`${proxyCount} proxy IP(s) detected`);

  const countries = [...new Set(vpnIntel.map(v => v.country).filter(c => c !== "Unknown"))];
  if (countries.length > 0) {
    estimatedLocation = countries.length === 1 ? countries[0] : `Multiple: ${countries.join(", ")}`;
    identityClues.push(`IP geolocation: ${countries.join(", ")}`);
  }

  const ethPorts = portResults.filter(p => [8545, 8546, 30303, 30304].includes(p.port));
  if (ethPorts.length > 0) {
    identityClues.push(`Running Ethereum nodes on ${ethPorts.length} port(s) — may be operating own infrastructure`);
  }

  const vpnPorts = portResults.filter(p => [1194, 51820, 500, 4500].includes(p.port));
  if (vpnPorts.length > 0) {
    identityClues.push(`VPN server ports detected (${vpnPorts.map(p => p.service).join(", ")}) — may be running own VPN`);
    recommendations.push("Check VPN server operator records — self-hosted VPN suggests technical sophistication");
  }

  const torPorts = portResults.filter(p => [9001, 9030].includes(p.port));
  if (torPorts.length > 0) {
    identityClues.push("Tor relay/directory ports found — may be operating Tor infrastructure");
  }

  for (const intel of vpnIntel) {
    if (intel.reverseHosts.length > 0) {
      identityClues.push(`Reverse DNS for ${intel.detectedIp}: ${intel.reverseHosts.join(", ")}`);
    }
  }

  if (identityClues.length > 5) confidenceLevel = "medium";
  if (identityClues.length > 10 || countries.length === 1) confidenceLevel = "high";

  recommendations.push("Submit IP intelligence to law enforcement for ISP subpoena");
  recommendations.push("Cross-reference transaction timing with exchange login timestamps");
  recommendations.push("Check bridge destination addresses for additional identity leaks");
  if (vpnCount > 0) {
    recommendations.push("Request VPN provider logs via law enforcement channels (MLAT if international)");
  }
  if (torCount > 0) {
    recommendations.push("Analyze Tor circuit timing — correlation attacks possible with sufficient data");
  }

  let operatingPattern = "Unknown";
  if (behavior) {
    if (behavior.totalTransactions > 100) operatingPattern = "High-volume operator";
    else if (behavior.totalTransactions > 20) operatingPattern = "Moderate activity";
    else operatingPattern = "Low-volume / careful operator";

    if (behavior.interactionPatterns.usedMixers.length > 0) operatingPattern += " — uses laundering tools";
  }

  return {
    estimatedLocation,
    estimatedTimezone,
    confidenceLevel,
    walletClient: behavior?.deviceFingerprint.walletClient || "Unknown",
    operatingPattern,
    riskFactors,
    identityClues,
    recommendations,
  };
}

export async function runNetworkScan(targetAddress: string, caseId: string): Promise<string> {
  if (!_validateAddress(targetAddress)) {
    throw new Error("[SECURITY] Invalid address format");
  }
  if (!_validateCaseId(caseId)) {
    throw new Error("[SECURITY] Invalid case ID format");
  }
  if (!_checkRateLimit()) {
    throw new Error(`Rate limit exceeded: ${_MAX_SCANS_PER_HOUR} scans/hour`);
  }
  if (_getActiveScanCount() >= _MAX_CONCURRENT_SCANS) {
    throw new Error(`Maximum concurrent scans (${_MAX_CONCURRENT_SCANS}) reached`);
  }

  _cleanupExpiredScans();

  const scanId = `netscan_${Date.now()}_${crypto.randomBytes(6).toString('hex')}`;
  _logAudit("scan_started", targetAddress, caseId, scanId);

  const scan: NetworkScanResult = {
    scanId,
    caseId,
    targetAddress: targetAddress.toLowerCase(),
    status: "running",
    progress: 0,
    startedAt: new Date().toISOString(),
    nodePropagation: [],
    transactionTimings: [],
    vpnIntelligence: [],
    behaviorProfile: null,
    ipSummary: {
      totalIpsDiscovered: 0,
      vpnIps: 0,
      proxyIps: 0,
      torExitNodes: 0,
      datacenterIps: 0,
      residentialIps: 0,
      uniqueCountries: [],
      uniqueIsps: [],
      estimatedTimezone: "Unknown",
      estimatedRegion: "Unknown",
      confidenceScore: 0,
    },
    networkTopology: {
      relatedIps: [],
      portScanResults: [],
      reverseHostnames: [],
      traceRouteHops: [],
    },
    attackerProfile: {
      estimatedLocation: "Unknown",
      estimatedTimezone: "Unknown",
      confidenceLevel: "low",
      walletClient: "Unknown",
      operatingPattern: "Unknown",
      riskFactors: [],
      identityClues: [],
      recommendations: [],
    },
  };

  activeScans.set(scanId, scan);

  (async () => {
    try {
      console.log(`[NetworkIntel] Phase 1/6: Transaction timing analysis for ${targetAddress.slice(0, 10)}...`);
      scan.progress = 10;
      scan.transactionTimings = await _analyzeTransactionTimings(targetAddress);
      console.log(`[NetworkIntel] Phase 1 complete: ${scan.transactionTimings.length} transactions analyzed`);

      scan.progress = 25;
      console.log(`[NetworkIntel] Phase 2/6: Behavioral profiling...`);
      scan.behaviorProfile = await _buildBehaviorProfile(targetAddress, scan.transactionTimings);
      console.log(`[NetworkIntel] Phase 2 complete: ${scan.behaviorProfile.totalTransactions} txs profiled, ${scan.behaviorProfile.interactionPatterns.topContracts.length} contract interactions`);

      scan.progress = 40;
      console.log(`[NetworkIntel] Phase 3/6: Ethereum node propagation analysis...`);
      const txHashes = scan.transactionTimings.map(t => t.txHash).filter(Boolean);
      scan.nodePropagation = await _queryNodePropagation(targetAddress, txHashes);
      const peers = await _traceEthereumPeers(targetAddress);
      console.log(`[NetworkIntel] Phase 3 complete: ${peers.length} peer nodes discovered`);

      scan.progress = 55;
      console.log(`[NetworkIntel] Phase 4/6: IP intelligence & VPN detection...`);
      const ipsToCheck = peers.map(p => p.ip).filter(Boolean).slice(0, 20);
      if (ipsToCheck.length > 0) {
        scan.vpnIntelligence = await _queryIpIntelligence(ipsToCheck);
      }
      console.log(`[NetworkIntel] Phase 4 complete: ${scan.vpnIntelligence.length} IPs analyzed`);

      scan.progress = 70;
      console.log(`[NetworkIntel] Phase 5/6: Deep port scanning & network topology...`);
      const allIps = scan.vpnIntelligence.map(v => v.detectedIp).filter(Boolean);
      scan.networkTopology.portScanResults = await _deepPortScan(allIps);
      scan.networkTopology.relatedIps = await _discoverLinkedIps(scan.vpnIntelligence);
      scan.networkTopology.reverseHostnames = scan.vpnIntelligence
        .filter(v => v.reverseHosts.length > 0)
        .map(v => ({ ip: v.detectedIp, hostnames: v.reverseHosts }));
      console.log(`[NetworkIntel] Phase 5 complete: ${scan.networkTopology.portScanResults.length} open ports, ${scan.networkTopology.relatedIps.length} related IPs`);

      scan.progress = 85;
      console.log(`[NetworkIntel] Phase 6/6: Building attacker profile...`);
      scan.attackerProfile = _buildAttackerProfile(
        scan.transactionTimings,
        scan.behaviorProfile,
        scan.vpnIntelligence,
        scan.networkTopology.portScanResults,
      );

      const allVpnIps = scan.vpnIntelligence;
      scan.ipSummary = {
        totalIpsDiscovered: allVpnIps.length,
        vpnIps: allVpnIps.filter(v => v.isVpn).length,
        proxyIps: allVpnIps.filter(v => v.isProxy).length,
        torExitNodes: allVpnIps.filter(v => v.isTor).length,
        datacenterIps: allVpnIps.filter(v => v.isDatacenter).length,
        residentialIps: allVpnIps.filter(v => !v.isVpn && !v.isProxy && !v.isTor && !v.isDatacenter).length,
        uniqueCountries: [...new Set(allVpnIps.map(v => v.country).filter(c => c !== "Unknown"))],
        uniqueIsps: [...new Set(allVpnIps.map(v => v.isp).filter(i => i !== "Unknown"))],
        estimatedTimezone: scan.attackerProfile.estimatedTimezone,
        estimatedRegion: scan.attackerProfile.estimatedLocation,
        confidenceScore: scan.attackerProfile.confidenceLevel === "high" ? 85 : scan.attackerProfile.confidenceLevel === "medium" ? 60 : 30,
      };

      scan.status = "complete";
      scan.progress = 100;
      scan.completedAt = new Date().toISOString();

      _logAudit("scan_complete", targetAddress, caseId, scanId);

      try {
        await db.insert(forensicAlerts).values({
          caseId,
          alertType: "network_intelligence",
          severity: "high",
          message: `Network Intelligence scan complete for ${targetAddress.slice(0, 10)}... — ${scan.attackerProfile.identityClues.length} identity clues, ${scan.ipSummary.totalIpsDiscovered} IPs analyzed, estimated location: ${scan.attackerProfile.estimatedLocation}, timezone: ${scan.attackerProfile.estimatedTimezone}`,
          acknowledged: false,
        });
      } catch {}

      console.log(`[NetworkIntel] Scan complete for ${targetAddress.slice(0, 10)}... — ${scan.attackerProfile.identityClues.length} clues, ${scan.ipSummary.totalIpsDiscovered} IPs, confidence: ${scan.attackerProfile.confidenceLevel}`);
    } catch (error: any) {
      scan.status = "error";
      scan.error = error.message;
      scan.completedAt = new Date().toISOString();
      _logAudit("scan_error", targetAddress, caseId, scanId);
      console.error(`[NetworkIntel] Scan error for ${targetAddress.slice(0, 10)}...: ${error.message}`);
    }
  })();

  return scanId;
}

export function getScan(scanId: string): NetworkScanResult | null {
  return activeScans.get(scanId) || null;
}

export function getAllScans(caseId: string): NetworkScanResult[] {
  const results: NetworkScanResult[] = [];
  for (const [_, scan] of activeScans) {
    if (scan.caseId === caseId) results.push(scan);
  }
  return results;
}

export function getModuleStatus() {
  return {
    version: _MODULE_VERSION,
    build: _MODULE_BUILD,
    fingerprint: _MODULE_FINGERPRINT,
    integrityVerified: true,
    activeScans: _getActiveScanCount(),
    totalScansRun: _auditLog.filter(a => a.action === "scan_started").length,
    rateLimitRemaining: Math.max(0, _MAX_SCANS_PER_HOUR - _scanRateTracker.timestamps.filter(t => Date.now() - t < 60 * 60 * 1000).length),
    auditLogSize: _auditLog.length,
  };
}

export function getAuditLog() {
  return [..._auditLog];
}

export async function autoStartNetworkScan(): Promise<void> {
  try {
    const poiWallets = await db.select().from(monitoredWallets)
      .where(eq(monitoredWallets.role, "attacker"));

    if (poiWallets.length === 0) {
      const allWallets = await db.select().from(monitoredWallets);
      const suspects = allWallets.filter(w =>
        w.label?.toLowerCase().includes("person of interest") ||
        w.label?.toLowerCase().includes("poi") ||
        w.label?.toLowerCase().includes("attacker") ||
        w.label?.toLowerCase().includes("thief") ||
        w.label?.toLowerCase().includes("hacker") ||
        w.role === "suspect" ||
        w.role?.toLowerCase() === "poi"
      );
      if (suspects.length > 0) {
        for (const wallet of suspects.slice(0, 5)) {
          console.log(`[NetworkIntel] Auto-starting scan for "${wallet.label}" (${wallet.address.slice(0, 10)}...)`);
          await runNetworkScan(wallet.address, wallet.caseId);
          await new Promise(r => setTimeout(r, 3000));
        }
      }
    } else {
      for (const wallet of poiWallets.slice(0, 5)) {
        console.log(`[NetworkIntel] Auto-starting scan for attacker wallet "${wallet.label}" (${wallet.address.slice(0, 10)}...)`);
        await runNetworkScan(wallet.address, wallet.caseId);
        await new Promise(r => setTimeout(r, 3000));
      }
    }
  } catch (error: any) {
    console.error(`[NetworkIntel] Auto-start error: ${error.message}`);
  }
}

console.log(`[NetworkIntel] Alpha Network Intelligence Tracer™ v${_MODULE_VERSION} initialized | Fingerprint: ${_MODULE_FINGERPRINT}`);
