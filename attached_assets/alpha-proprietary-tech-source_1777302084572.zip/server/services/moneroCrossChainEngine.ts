/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Monero Cross-Chain Correlation Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * Technologies Protected:
 * - Monero Cross-Chain Correlation Engine™ (bidirectional swap tracking)
 * - XMR Amount Fingerprint Protocol™ (expected output calculation)
 * - Exchange Pool Exit Monitor™ (real-time swap service surveillance)
 * - Historical Backtrace Engine™ (retroactive transaction correlation)
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * Module Seal: AUT_MCCE_FORENSIC_2026
 * Integrity Beacon: ACTIVE
 * Security Layer: 10-LAYER ARCHITECTURE ENFORCED
 */

const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY || ""}`;

const SWAP_SERVICES: Record<string, { name: string; fee: number; type: string; kyc: boolean; jurisdiction: string }> = {
  "0xd37bbe5744d730a1d98d8dc97c42f0ca46ad7146": { name: "THORChain Router", fee: 0.003, type: "DEX", kyc: false, jurisdiction: "Decentralized" },
  "0x3624525075b88b24ecc29ce226b0cec1ffcb6976": { name: "THORChain Asgard", fee: 0.003, type: "DEX", kyc: false, jurisdiction: "Decentralized" },
  "0xc145990e84155416144c532e31f89b840ca8c2ce": { name: "THORChain Vault", fee: 0.003, type: "DEX", kyc: false, jurisdiction: "Decentralized" },
  "0x1facc26559c09aba0cd7d2f6e42f1f9a8e6e36d2": { name: "ChangeNow", fee: 0.005, type: "Instant Swap", kyc: false, jurisdiction: "Seychelles" },
  "0x077d360f11d220e4d5d831430c81c26c9be7c4a4": { name: "ChangeNow Hot", fee: 0.005, type: "Instant Swap", kyc: false, jurisdiction: "Seychelles" },
  "0xbc2b2b19a0c4a51b0c38809847581b0b009eda62": { name: "ChangeNow Pool", fee: 0.005, type: "Instant Swap", kyc: false, jurisdiction: "Seychelles" },
  "0x4e5b2e1dc63f6b91cb6cd759936495434c7e972f": { name: "FixedFloat", fee: 0.01, type: "Instant Swap", kyc: false, jurisdiction: "British Virgin Islands" },
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": { name: "Uniswap/FixedFloat Router", fee: 0.01, type: "DEX Router", kyc: false, jurisdiction: "Decentralized" },
  "0x94f31ac896c9823d81fc2e4e2c1440a18e73c408": { name: "SideShift.ai", fee: 0.015, type: "Instant Swap", kyc: false, jurisdiction: "Unknown" },
  "0x3bb4445d30ac020a84c1b5a8a2c6248c36b0c40f": { name: "SideShift.ai Pool", fee: 0.015, type: "Instant Swap", kyc: false, jurisdiction: "Unknown" },
  "0xf1da173228fcf015786b9b1c29d0c4f7e6c1439f": { name: "eXch", fee: 0.005, type: "Instant Swap", kyc: false, jurisdiction: "Unknown" },
  "0x28c6c06298d514db089934071355e5743bf21d60": { name: "Binance Hot Wallet 14", fee: 0.001, type: "CEX", kyc: true, jurisdiction: "Cayman Islands / Global" },
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": { name: "Binance Hot Wallet 15", fee: 0.001, type: "CEX", kyc: true, jurisdiction: "Cayman Islands / Global" },
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": { name: "Binance Hot Wallet 16", fee: 0.001, type: "CEX", kyc: true, jurisdiction: "Cayman Islands / Global" },
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": { name: "Kraken Hot", fee: 0.002, type: "CEX", kyc: true, jurisdiction: "USA" },
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": { name: "Kraken 4", fee: 0.002, type: "CEX", kyc: true, jurisdiction: "USA" },
  "0xeb2629a2734e272bcc07bda959863f316f4bd4cf": { name: "KuCoin Hot", fee: 0.002, type: "CEX", kyc: true, jurisdiction: "Seychelles" },
  "0x1ae3739b22351e1e38a88d1268b40fffec18866b": { name: "TradeOgre", fee: 0.02, type: "CEX", kyc: false, jurisdiction: "Unknown" },
};

type WalletType = "direct_attacker" | "shared_service" | "intermediary";

const ATTACKER_WALLETS: Record<string, { label: string; type: WalletType }> = {
  "0x8e04af7f7c76daa9ab429b1340e0327b5b835748": { label: "Cashout Primary (1,634 ETH)", type: "direct_attacker" },
  "0xa8e1960ab9234f56df6031dde4561a42c15812df": { label: "HOP-1 Relay", type: "direct_attacker" },
  "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3": { label: "HOP-4 Consolidation (USDT)", type: "direct_attacker" },
  "0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73": { label: "OTC/Bridge Service", type: "shared_service" },
  "0x83d1754dd1315a433461a014da950422905d5ca1": { label: "Address-Sim Relay", type: "direct_attacker" },
  "0x46af83b6bee9bcfd4d31eed47a8c32adbd410e6b": { label: "Address-Sim Mixer", type: "direct_attacker" },
  "0x46af8e7a2ee01134d1757bc19607781dbd410e6b": { label: "Circular Mixer", type: "direct_attacker" },
  "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872": { label: "Main Attacker (hop-1, 490 ETH)", type: "direct_attacker" },
  "0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e": { label: "DAI Laundering Hub", type: "direct_attacker" },
  "0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4": { label: "DCA Laundering Hub", type: "direct_attacker" },
  "0x4389070b909ff2a6549f3ca8e42e578e12cf61b6": { label: "USDC Endpoint", type: "direct_attacker" },
  "0x8e044d1ecebab9b62323ead86917e5123e795748": { label: "Mirror Cashout A", type: "direct_attacker" },
  "0x8e03a03bb063abd8871cc8e508d9f4506d835748": { label: "Mirror Cashout B", type: "direct_attacker" },
  "0x4d0f03b83650b33138764aaaf3da76861576ff98": { label: "KYC Bridge Wallet", type: "intermediary" },
  "0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a": { label: "KYC Bridge Wallet 2", type: "intermediary" },
  "0x1f04378f94313421ed1faaf4f6415de722bea5ea": { label: "Large-Value Intermediary", type: "intermediary" },
  "0x5bbea8a4b36d1c897ac89726594ea1ce04608877": { label: "Mule Pattern A", type: "direct_attacker" },
  "0xb48522f1b6863f897d4a6dd04ef6a16c69499db1": { label: "Mule Pattern B", type: "direct_attacker" },
  "0xb485a81b220071e00d3ca4730b1ed569fd6dddb1": { label: "Mule Pattern C", type: "direct_attacker" },
  "0x2cc8d5e64c008f26db42848057519a06191d6f2f": { label: "Mule Pattern D", type: "direct_attacker" },
  "0x0016e313e598de1af2a67d3c869622a69634430c": { label: "Mule Pattern E", type: "direct_attacker" },
  "0x9a72643e82b7ed8db3d575c02621e91d8d06ba73": { label: "Address-Sim OTC", type: "intermediary" },
  "0x80d71876152b781a9b43ae6307819b1d66c0f90a": { label: "Address-Sim KYC", type: "intermediary" },
  "0x83d7ed598e805ad63ce27d777d8a77d2585d5ca1": { label: "Address-Sim 85%", type: "direct_attacker" },
  "0x4d0ffe81540f0755d70ede0d7430ae861576ff98": { label: "Address-Sim 100%", type: "direct_attacker" },
  "0x83d10e4698efb8a0bd3cafad6c950572905d5ca1": { label: "Distribution EOA", type: "direct_attacker" },
};

const VALID_ASSETS = new Set(["ETH", "WETH", "USDT", "USDC", "DAI"]);

const CASE_STOLEN_AMOUNT_USD = 26_000_000;
const VICTIM_WALLET = "0x6fe0fab2164d8e0d03ad6a628e2af78624060322";

const HIGH_VOLUME_WALLETS = new Set([
  "0x8e04af7f7c76daa9ab429b1340e0327b5b835748",
]);

interface CorrelationHit {
  wallet: string;
  walletLabel: string;
  walletType: WalletType;
  service: string;
  serviceAddr: string;
  serviceFee: number;
  serviceType: string;
  serviceKYC: boolean;
  serviceJurisdiction: string;
  txHash: string;
  time: string;
  blockNum: string;
  asset: string;
  amount: number;
  usdValue: number;
  expectedXMR: number;
  xmrMin: number;
  xmrMax: number;
  confidence: number;
  unitFingerprint18: string;
}

let correlationCache: CorrelationHit[] = [];
let lastFullScanTime: Date | null = null;
let scanInterval: ReturnType<typeof setInterval> | null = null;

async function alchemyRPC(method: string, params: any[]): Promise<any> {
  const r = await fetch(ALCHEMY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  const d = await r.json() as any;
  return d.result;
}

async function getOutboundTransfers(addr: string, fromBlock?: string): Promise<any[]> {
  const params: any = {
    fromAddress: addr,
    category: ["external", "erc20"],
    withMetadata: true,
    maxCount: "0x3e8",
  };
  if (fromBlock) params.fromBlock = fromBlock;
  const result = await alchemyRPC("alchemy_getAssetTransfers", [params]);
  return result?.transfers || [];
}

function getETHPrice(date: Date): number {
  const ts = date.getTime();
  if (ts < new Date("2023-06-01").getTime()) return 1800;
  if (ts < new Date("2024-01-01").getTime()) return 2300;
  if (ts < new Date("2024-06-01").getTime()) return 3200;
  if (ts < new Date("2024-09-01").getTime()) return 3500;
  if (ts < new Date("2025-01-01").getTime()) return 3500;
  if (ts < new Date("2025-06-01").getTime()) return 2700;
  return 2500;
}

function getXMRPrice(date: Date): number {
  const ts = date.getTime();
  if (ts < new Date("2023-06-01").getTime()) return 150;
  if (ts < new Date("2024-01-01").getTime()) return 170;
  if (ts < new Date("2024-06-01").getTime()) return 160;
  if (ts < new Date("2024-09-01").getTime()) return 175;
  if (ts < new Date("2025-01-01").getTime()) return 175;
  return 180;
}

function calculateCorrelation(
  amount: number,
  asset: string,
  txDate: Date,
  serviceFee: number,
): { usdValue: number; expectedXMR: number; xmrMin: number; xmrMax: number } {
  const ethPrice = getETHPrice(txDate);
  const xmrPrice = getXMRPrice(txDate);

  let usdValue: number;
  if (asset === "ETH" || asset === "WETH") {
    usdValue = amount * ethPrice;
  } else {
    usdValue = amount;
  }

  const expectedXMR = (usdValue / xmrPrice) * (1 - serviceFee);
  const xmrMin = expectedXMR * 0.97;
  const xmrMax = expectedXMR * 1.03;

  return { usdValue, expectedXMR, xmrMin, xmrMax };
}

async function scanWalletForExchangeDeposits(
  addr: string,
  label: string,
  walletType: WalletType,
  fromBlock?: string,
): Promise<CorrelationHit[]> {
  const hits: CorrelationHit[] = [];
  const txs = await getOutboundTransfers(addr, fromBlock);

  for (const tx of txs) {
    const toAddr = tx.to?.toLowerCase();
    if (!toAddr) continue;

    const service = SWAP_SERVICES[toAddr];
    if (!service) continue;

    const value = parseFloat(tx.value) || 0;
    if (value === 0) continue;

    const asset = tx.asset || "ETH";
    if (!VALID_ASSETS.has(asset)) continue;

    const txDate = tx.metadata?.blockTimestamp ? new Date(tx.metadata.blockTimestamp) : new Date();
    const corr = calculateCorrelation(value, asset, txDate, service.fee);

    if (corr.usdValue < 100) continue;

    const confidence = corr.usdValue > 100000 ? 95 : corr.usdValue > 10000 ? 90 : corr.usdValue > 1000 ? 85 : 80;

    hits.push({
      wallet: addr,
      walletLabel: label,
      walletType,
      service: service.name,
      serviceAddr: toAddr,
      serviceFee: service.fee,
      serviceType: service.type,
      serviceKYC: service.kyc,
      serviceJurisdiction: service.jurisdiction,
      txHash: tx.hash,
      time: txDate.toISOString(),
      blockNum: tx.blockNum || "",
      asset,
      amount: value,
      usdValue: corr.usdValue,
      expectedXMR: corr.expectedXMR,
      xmrMin: corr.xmrMin,
      xmrMax: corr.xmrMax,
      confidence,
      unitFingerprint18: BigInt(Math.round(value * 1e18)).toString(),
    });
  }

  return hits;
}

const SHARED_SERVICE_ADDRS = new Set(
  Object.entries(ATTACKER_WALLETS)
    .filter(([, w]) => w.type === "shared_service")
    .map(([addr]) => addr),
);

const DIRECT_ATTACKER_ADDRS = new Set(
  Object.entries(ATTACKER_WALLETS)
    .filter(([, w]) => w.type !== "shared_service")
    .map(([addr]) => addr),
);

interface InboundDeposit {
  fromAddr: string;
  fromLabel: string;
  txHash: string;
  amount: number;
  asset: string;
  time: Date;
  blockNum: string;
}

async function getInboundFromAttackers(serviceAddr: string): Promise<InboundDeposit[]> {
  const params: any = {
    toAddress: serviceAddr,
    category: ["external", "erc20"],
    withMetadata: true,
    maxCount: "0x3e8",
  };
  const result = await alchemyRPC("alchemy_getAssetTransfers", [params]);
  const transfers = result?.transfers || [];
  const deposits: InboundDeposit[] = [];

  for (const tx of transfers) {
    const fromAddr = tx.from?.toLowerCase();
    if (!fromAddr || !DIRECT_ATTACKER_ADDRS.has(fromAddr)) continue;

    const value = parseFloat(tx.value) || 0;
    if (value === 0) continue;

    const asset = tx.asset || "ETH";
    if (!VALID_ASSETS.has(asset)) continue;

    const walletInfo = ATTACKER_WALLETS[fromAddr];
    deposits.push({
      fromAddr,
      fromLabel: walletInfo?.label || fromAddr,
      txHash: tx.hash,
      amount: value,
      asset,
      time: tx.metadata?.blockTimestamp ? new Date(tx.metadata.blockTimestamp) : new Date(),
      blockNum: tx.blockNum || "",
    });
  }

  return deposits;
}

function correlateOTCOutbound(
  inboundDeposits: InboundDeposit[],
  outboundHits: CorrelationHit[],
): CorrelationHit[] {
  const matched: CorrelationHit[] = [];
  const usedOutbound = new Set<string>();

  const sortedInbound = [...inboundDeposits].sort((a, b) => a.time.getTime() - b.time.getTime());

  for (const deposit of sortedInbound) {
    const depositTime = deposit.time.getTime();
    const amountLow = deposit.amount * 0.90;
    const amountHigh = deposit.amount * 1.10;

    let bestMatch: CorrelationHit | null = null;
    let bestTimeDiff = Infinity;

    for (const out of outboundHits) {
      if (usedOutbound.has(out.txHash)) continue;

      const outTime = new Date(out.time).getTime();
      if (outTime < depositTime) continue;

      const timeDiffMs = outTime - depositTime;
      if (timeDiffMs > 48 * 60 * 60 * 1000) continue;

      if (out.asset !== deposit.asset) continue;

      if (out.amount >= amountLow && out.amount <= amountHigh) {
        if (timeDiffMs < bestTimeDiff) {
          bestTimeDiff = timeDiffMs;
          bestMatch = out;
        }
      }
    }

    if (bestMatch) {
      usedOutbound.add(bestMatch.txHash);
      matched.push({
        ...bestMatch,
        walletLabel: `OTC Pass-through ← ${deposit.fromLabel}`,
        walletType: "shared_service",
        confidence: bestTimeDiff < 3600000 ? 92 : bestTimeDiff < 14400000 ? 85 : 78,
      });
    }
  }

  return matched;
}

async function fullBacktrace(): Promise<CorrelationHit[]> {
  const directCount = Object.values(ATTACKER_WALLETS).filter(w => w.type !== "shared_service").length;
  const serviceCount = Object.values(ATTACKER_WALLETS).filter(w => w.type === "shared_service").length;
  console.log(`[MoneroCorrelation] Starting full backtrace: ${directCount} direct wallets, ${serviceCount} shared service wallets...`);

  const allHits: CorrelationHit[] = [];

  for (const [addr, wallet] of Object.entries(ATTACKER_WALLETS)) {
    if (wallet.type === "shared_service") continue;
    try {
      const hits = await scanWalletForExchangeDeposits(addr, wallet.label, wallet.type);
      if (hits.length > 0) {
        allHits.push(...hits);
        const usd = hits.reduce((s, h) => s + h.usdValue, 0);
        console.log(`[MoneroCorrelation] ${wallet.label}: ${hits.length} direct exchange deposits ($${usd.toLocaleString()})`);
      }
    } catch (e: any) {
      console.error(`[MoneroCorrelation] Error scanning ${wallet.label}: ${e.message}`);
    }
    await new Promise((r) => setTimeout(r, 250));
  }

  const directTotal = allHits.reduce((s, h) => s + h.usdValue, 0);
  console.log(`[MoneroCorrelation] Direct attacker → exchange deposits: ${allHits.length} txs, $${directTotal.toLocaleString()}`);

  for (const [serviceAddr, wallet] of Object.entries(ATTACKER_WALLETS)) {
    if (wallet.type !== "shared_service") continue;
    try {
      console.log(`[MoneroCorrelation] Analyzing shared service: ${wallet.label} (${serviceAddr.slice(0, 10)}...)`);
      console.log(`[MoneroCorrelation]   Step 1: Finding inbound deposits from attacker wallets...`);
      const inbound = await getInboundFromAttackers(serviceAddr);
      const inboundUSD = inbound.reduce((s, d) => {
        const ethP = getETHPrice(d.time);
        return s + (d.asset === "ETH" || d.asset === "WETH" ? d.amount * ethP : d.amount);
      }, 0);
      console.log(`[MoneroCorrelation]   Found ${inbound.length} inbound from attackers ($${inboundUSD.toLocaleString()})`);

      if (inbound.length === 0) continue;

      console.log(`[MoneroCorrelation]   Step 2: Scanning outbound to exchanges...`);
      const outbound = await scanWalletForExchangeDeposits(serviceAddr, wallet.label, wallet.type);
      console.log(`[MoneroCorrelation]   Found ${outbound.length} total outbound to exchanges (gross volume, includes other customers)`);

      console.log(`[MoneroCorrelation]   Step 3: Correlating inbound attacker deposits with outbound exchange deposits...`);
      const correlated = correlateOTCOutbound(inbound, outbound);
      const correlatedUSD = correlated.reduce((s, h) => s + h.usdValue, 0);
      console.log(`[MoneroCorrelation]   Matched ${correlated.length}/${inbound.length} attacker deposits through OTC → exchange ($${correlatedUSD.toLocaleString()})`);
      console.log(`[MoneroCorrelation]   Filtered out ${outbound.length - correlated.length} unrelated OTC customer transactions`);

      allHits.push(...correlated);
    } catch (e: any) {
      console.error(`[MoneroCorrelation] Error analyzing service ${wallet.label}: ${e.message}`);
    }
    await new Promise((r) => setTimeout(r, 500));
  }

  allHits.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
  correlationCache = allHits;
  lastFullScanTime = new Date();

  const totalUSD = allHits.reduce((s, h) => s + h.usdValue, 0);
  const directHits = allHits.filter(h => h.walletType !== "shared_service");
  const otcHits = allHits.filter(h => h.walletType === "shared_service");
  const directUSD = directHits.reduce((s, h) => s + h.usdValue, 0);
  const otcUSD = otcHits.reduce((s, h) => s + h.usdValue, 0);

  console.log(`[MoneroCorrelation] ═══ BACKTRACE COMPLETE ═══`);
  console.log(`[MoneroCorrelation] Known stolen amount: ~$${CASE_STOLEN_AMOUNT_USD.toLocaleString()}`);
  console.log(`[MoneroCorrelation] Exchange deposit routes found: ${allHits.length} txs`);
  console.log(`[MoneroCorrelation]   Direct attacker → exchange: ${directHits.length} txs ($${directUSD.toLocaleString()})`);
  console.log(`[MoneroCorrelation]   OTC pass-through (correlated): ${otcHits.length} txs ($${otcUSD.toLocaleString()})`);
  if (totalUSD > CASE_STOLEN_AMOUNT_USD * 1.5) {
    console.log(`[MoneroCorrelation]   ⚠ Gross volume ($${totalUSD.toLocaleString()}) > stolen amount — attacker wallets process other funds too`);
    console.log(`[MoneroCorrelation]   ⚠ Use route/exchange data for intelligence, not as total loss figure`);
  }

  return allHits;
}

async function incrementalScan(): Promise<CorrelationHit[]> {
  const currentBlock = parseInt(await alchemyRPC("eth_blockNumber", []), 16);
  const fromBlock = "0x" + (currentBlock - 7200).toString(16);

  const newHits: CorrelationHit[] = [];

  for (const [addr, wallet] of Object.entries(ATTACKER_WALLETS)) {
    if (wallet.type === "shared_service") continue;
    try {
      const hits = await scanWalletForExchangeDeposits(addr, wallet.label, wallet.type, fromBlock);
      for (const hit of hits) {
        const isDuplicate = correlationCache.some((c) => c.txHash === hit.txHash);
        if (!isDuplicate) {
          newHits.push(hit);
          correlationCache.push(hit);
          console.log(
            `[MoneroCorrelation] NEW DEPOSIT: ${hit.walletLabel} → ${hit.service} | ${hit.amount.toFixed(4)} ${hit.asset} ($${hit.usdValue.toLocaleString()}) | Expected XMR: ${hit.expectedXMR.toFixed(4)}`,
          );
        }
      }
    } catch {
    }
    await new Promise((r) => setTimeout(r, 100));
  }

  if (newHits.length > 0) {
    console.log(`[MoneroCorrelation] Incremental scan found ${newHits.length} new deposits`);
  }

  return newHits;
}

export function getCorrelationResults(): {
  hits: CorrelationHit[];
  lastScan: string | null;
  caseStolenAmountUSD: number;
  grossVolumeUSD: number;
  grossVolumeTxs: number;
  directAttackerUSD: number;
  directAttackerTxs: number;
  otcCorrelatedUSD: number;
  otcCorrelatedTxs: number;
  volumeExceedsStolenAmount: boolean;
  volumeWarning: string | null;
  byService: Record<string, { count: number; usd: number }>;
  byWallet: Record<string, { count: number; usd: number }>;
} {
  const byService: Record<string, { count: number; usd: number }> = {};
  const byWallet: Record<string, { count: number; usd: number }> = {};

  for (const h of correlationCache) {
    if (!byService[h.service]) byService[h.service] = { count: 0, usd: 0 };
    byService[h.service].count++;
    byService[h.service].usd += h.usdValue;

    if (!byWallet[h.walletLabel]) byWallet[h.walletLabel] = { count: 0, usd: 0 };
    byWallet[h.walletLabel].count++;
    byWallet[h.walletLabel].usd += h.usdValue;
  }

  const directHits = correlationCache.filter(h => h.walletType !== "shared_service");
  const otcHits = correlationCache.filter(h => h.walletType === "shared_service");
  const grossUSD = correlationCache.reduce((s, h) => s + h.usdValue, 0);
  const exceedsStolenAmount = grossUSD > CASE_STOLEN_AMOUNT_USD * 1.5;

  let volumeWarning: string | null = null;
  if (exceedsStolenAmount) {
    volumeWarning = `IMPORTANT: Gross correlated volume ($${Math.round(grossUSD).toLocaleString()}) exceeds known stolen amount ($${CASE_STOLEN_AMOUNT_USD.toLocaleString()}). ` +
      `This is because some attacker-linked wallets (e.g., Cashout Primary with 33K+ nonce) also process funds unrelated to this case. ` +
      `The actual stolen amount is ~$${CASE_STOLEN_AMOUNT_USD.toLocaleString()}. Use the transaction list for exchange routing intelligence, not as a total loss figure.`;
  }

  return {
    hits: correlationCache,
    lastScan: lastFullScanTime?.toISOString() || null,
    caseStolenAmountUSD: CASE_STOLEN_AMOUNT_USD,
    grossVolumeUSD: grossUSD,
    grossVolumeTxs: correlationCache.length,
    directAttackerUSD: directHits.reduce((s, h) => s + h.usdValue, 0),
    directAttackerTxs: directHits.length,
    otcCorrelatedUSD: otcHits.reduce((s, h) => s + h.usdValue, 0),
    otcCorrelatedTxs: otcHits.length,
    volumeExceedsStolenAmount: exceedsStolenAmount,
    volumeWarning,
    byService,
    byWallet,
  };
}

export function getRecentHits(hours: number = 24): CorrelationHit[] {
  const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
  return correlationCache.filter((h) => new Date(h.time) > cutoff);
}

export function getHighConfidenceHits(minConfidence: number = 90): CorrelationHit[] {
  return correlationCache.filter((h) => h.confidence >= minConfidence);
}

export function getXMRSearchKeys(): Array<{
  expectedXMR: number;
  xmrMin: number;
  xmrMax: number;
  sourceAsset: string;
  sourceAmount: number;
  sourceUSD: number;
  sourceTime: string;
  sourceTxHash: string;
  sourceWallet: string;
  walletType: string;
  targetService: string;
}> {
  return correlationCache.map((h) => ({
    expectedXMR: h.expectedXMR,
    xmrMin: h.xmrMin,
    xmrMax: h.xmrMax,
    sourceAsset: h.asset,
    sourceAmount: h.amount,
    sourceUSD: h.usdValue,
    sourceTime: h.time,
    sourceTxHash: h.txHash,
    sourceWallet: h.walletLabel,
    walletType: h.walletType,
    targetService: h.service,
  }));
}

export async function startMoneroCrossChainEngine(): Promise<void> {
  const directCount = Object.values(ATTACKER_WALLETS).filter(w => w.type !== "shared_service").length;
  const serviceCount = Object.values(ATTACKER_WALLETS).filter(w => w.type === "shared_service").length;
  console.log(`[MoneroCorrelation] Monero Cross-Chain Correlation Engine™ initializing...`);
  console.log(`[MoneroCorrelation] Direct attacker wallets: ${directCount} | Shared service wallets: ${serviceCount}`);
  console.log(`[MoneroCorrelation] Tracking ${Object.keys(SWAP_SERVICES).length} swap/exchange services`);
  console.log(`[MoneroCorrelation] OTC filtering: ON — only counting funds correlated with attacker inflows`);

  await fullBacktrace();

  const results = getCorrelationResults();
  console.log(`[MoneroCorrelation] Engine active — ${results.grossVolumeTxs} exchange routes cached (stolen ~$${CASE_STOLEN_AMOUNT_USD.toLocaleString()})`);

  scanInterval = setInterval(async () => {
    try {
      await incrementalScan();
    } catch (e: any) {
      console.error(`[MoneroCorrelation] Incremental scan error: ${e.message}`);
    }
  }, 5 * 60 * 1000);

  console.log(`[MoneroCorrelation] Real-time monitoring active (scan every 5 minutes)`);
}

export function stopMoneroCrossChainEngine(): void {
  if (scanInterval) {
    clearInterval(scanInterval);
    scanInterval = null;
    console.log(`[MoneroCorrelation] Engine stopped`);
  }
}
