/**
 * Alpha Unlimited Token (ALPHAU) - Security Service
 * Layer 3: Activity Monitoring and Anomaly Detection
 * Copyright (c) 2024-present Alpha Unlimited Token. All Rights Reserved.
 * 
 * PROPRIETARY AND CONFIDENTIAL - TRADE SECRET
 * This source code is protected under international copyright law.
 * Unauthorized copying, modification, distribution, reverse engineering,
 * or use of this code is strictly prohibited and will be prosecuted.
 * 
 * This security service, including all anomaly detection algorithms,
 * brute force protection, and monitoring systems are exclusive trade
 * secrets of Alpha Unlimited Token.
 */

import { db } from "../db";
import { 
  securityLogs, 
  securityAlerts,
  type InsertSecurityLog, 
  type InsertSecurityAlert,
  type SecurityEventType,
  type AlertType,
  type SeverityLevel,
  ALERT_TYPES,
  SEVERITY_LEVELS
} from "@shared/schema";
import { desc, eq, and, gt } from "drizzle-orm";

const FAILED_LOGIN_THRESHOLD = 5;
const FAILED_LOGIN_WINDOW_MS = 15 * 60 * 1000;
const RAPID_REQUEST_THRESHOLD = 100;
const RAPID_REQUEST_WINDOW_MS = 60 * 1000;

export async function logSecurityEvent(
  eventType: SecurityEventType,
  options: {
    userId?: string | null;
    ipAddress?: string | null;
    userAgent?: string | null;
    success?: boolean;
    details?: string;
  } = {}
): Promise<void> {
  try {
    const logEntry: InsertSecurityLog = {
      eventType,
      userId: options.userId ?? null,
      ipAddress: options.ipAddress ?? null,
      userAgent: options.userAgent ?? null,
      success: options.success ?? true,
      details: options.details ?? null,
    };

    await db.insert(securityLogs).values(logEntry);

    if (eventType === "login_failed" && options.ipAddress) {
      await checkBruteForceAttempt(options.ipAddress, options.userId);
    }
  } catch (error) {
    console.error("Failed to log security event:", error);
  }
}

export async function createSecurityAlert(
  alertType: AlertType,
  options: {
    userId?: string | null;
    severity?: SeverityLevel;
    message: string;
    metadata?: Record<string, any>;
  }
): Promise<void> {
  try {
    const alert: InsertSecurityAlert = {
      alertType,
      userId: options.userId ?? null,
      severity: options.severity ?? SEVERITY_LEVELS.MEDIUM,
      message: options.message,
      metadata: options.metadata ?? null,
    };

    await db.insert(securityAlerts).values(alert);
    console.log(`Security alert created: ${alertType} - ${options.message}`);
  } catch (error) {
    console.error("Failed to create security alert:", error);
  }
}

async function checkBruteForceAttempt(ipAddress: string, userId?: string | null): Promise<void> {
  const recentFailedLogins = await getRecentFailedLogins(ipAddress, FAILED_LOGIN_WINDOW_MS);
  
  if (recentFailedLogins.length >= FAILED_LOGIN_THRESHOLD) {
    await createSecurityAlert(ALERT_TYPES.BRUTE_FORCE_ATTEMPT, {
      userId,
      severity: SEVERITY_LEVELS.HIGH,
      message: `Multiple failed login attempts detected from IP ${ipAddress}`,
      metadata: {
        ipAddress,
        failedAttempts: recentFailedLogins.length,
        windowMinutes: FAILED_LOGIN_WINDOW_MS / 60000,
      },
    });
  }
}

export async function getSecurityLogs(userId: string, limit: number = 20) {
  return db
    .select()
    .from(securityLogs)
    .where(eq(securityLogs.userId, userId))
    .orderBy(desc(securityLogs.createdAt))
    .limit(limit);
}

export async function getSecurityAlerts(userId: string, limit: number = 10) {
  return db
    .select()
    .from(securityAlerts)
    .where(eq(securityAlerts.userId, userId))
    .orderBy(desc(securityAlerts.createdAt))
    .limit(limit);
}

export async function getUnacknowledgedAlerts(userId: string) {
  return db
    .select()
    .from(securityAlerts)
    .where(
      and(
        eq(securityAlerts.userId, userId),
        eq(securityAlerts.acknowledged, false)
      )
    )
    .orderBy(desc(securityAlerts.createdAt));
}

export async function acknowledgeAlert(alertId: string, userId: string): Promise<boolean> {
  try {
    const result = await db
      .update(securityAlerts)
      .set({ acknowledged: true })
      .where(
        and(
          eq(securityAlerts.id, alertId),
          eq(securityAlerts.userId, userId)
        )
      );
    return true;
  } catch (error) {
    console.error("Failed to acknowledge alert:", error);
    return false;
  }
}

export async function getRecentFailedLogins(ipAddress: string, windowMs: number = 15 * 60 * 1000) {
  const cutoff = new Date(Date.now() - windowMs);
  const logs = await db
    .select()
    .from(securityLogs)
    .where(eq(securityLogs.ipAddress, ipAddress));

  return logs.filter(
    (log) =>
      log.eventType === "login_failed" &&
      log.createdAt &&
      log.createdAt > cutoff
  );
}

export async function getRecentLoginActivity(userId: string, limit: number = 5) {
  const logs = await db
    .select()
    .from(securityLogs)
    .where(eq(securityLogs.userId, userId))
    .orderBy(desc(securityLogs.createdAt))
    .limit(limit * 2);

  return logs.filter(
    (log) => log.eventType === "login_success" || log.eventType === "logout"
  ).slice(0, limit);
}

export async function getSecuritySummary(userId: string) {
  const [logs, alerts, recentLogins] = await Promise.all([
    getSecurityLogs(userId, 50),
    getUnacknowledgedAlerts(userId),
    getRecentLoginActivity(userId, 5),
  ]);

  const failedLoginCount = logs.filter(l => l.eventType === "login_failed").length;
  const successfulLoginCount = logs.filter(l => l.eventType === "login_success").length;
  const lastLogin = recentLogins.find(l => l.eventType === "login_success");

  return {
    totalEvents: logs.length,
    failedLogins: failedLoginCount,
    successfulLogins: successfulLoginCount,
    unacknowledgedAlerts: alerts.length,
    alertsSeverity: alerts.reduce((acc, alert) => {
      acc[alert.severity] = (acc[alert.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    lastLogin: lastLogin?.createdAt,
    lastLoginIp: lastLogin?.ipAddress,
    recentActivity: recentLogins,
  };
}
