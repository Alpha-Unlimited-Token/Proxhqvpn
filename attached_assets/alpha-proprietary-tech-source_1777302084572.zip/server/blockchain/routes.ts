import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { getBlockchain, AlphaBlockchain } from './chain.js';
import { createWallet, signData, deriveAddress } from './wallet.js';
import { generateTransactionId } from './block.js';
import { COIN_NAME, COIN_TICKER, BURN_ADDRESS, calculateTransactionFee } from './consensus.js';
import { getP2PNetwork } from './p2p.js';
import { getStratumServer } from './stratum.js';
import { getFounderWallet, getFounderDisclosure, getVestingSchedule } from './founder.js';
import { isAuthenticated } from '../replit_integrations/auth/replitAuth.js';
import type { Transaction } from './block.js';
import {
  getSpider, getSpiderIntelligence, getNonceHotspots,
  getDifficultyPrediction, getOptimalMiningWindow,
  getEntropyAnalysis, getTemplateOptimization,
} from './spider.js';
import {
  traceAddress, traceTransaction, traceFundFlow,
  getSupportedChains, detectChainFromInput,
} from './forensicTracer.js';

const router = Router();

const WALLET_ENCRYPTION_ALGO = 'aes-256-gcm';

function getWalletStoreKey(): Buffer {
  const key = process.env.ENCRYPTION_KEY || process.env.SESSION_SECRET;
  if (!key || key.length < 32) {
    throw new Error('ENCRYPTION_KEY or SESSION_SECRET required for wallet encryption');
  }
  return crypto.createHash('sha256').update(key).digest();
}

function encryptKey(plaintext: string): string {
  const key = getWalletStoreKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(WALLET_ENCRYPTION_ALGO, key, iv);
  let encrypted = cipher.update(plaintext, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

function decryptKey(ciphertext: string): string {
  const key = getWalletStoreKey();
  const [ivHex, authTagHex, encrypted] = ciphertext.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const decipher = crypto.createDecipheriv(WALLET_ENCRYPTION_ALGO, key, iv, { authTagLength: 16 });
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

interface EncryptedWalletEntry {
  address: string;
  publicKey: string;
  encryptedPrivateKey: string;
}

const walletStore = new Map<string, EncryptedWalletEntry>();

function storeWallet(address: string, publicKey: string, privateKey: string): void {
  walletStore.set(address, {
    address,
    publicKey,
    encryptedPrivateKey: encryptKey(privateKey),
  });
}

function getWalletPrivateKey(address: string): string | null {
  const entry = walletStore.get(address);
  if (!entry) return null;
  return decryptKey(entry.encryptedPrivateKey);
}

function getWalletPublicKey(address: string): string | null {
  const entry = walletStore.get(address);
  if (!entry) return null;
  return entry.publicKey;
}

function ensureFounderWalletRegistered() {
  const fw = getFounderWallet();
  if (!walletStore.has(fw.address)) {
    storeWallet(fw.address, fw.publicKey, fw.privateKey);
  }
}
ensureFounderWalletRegistered();

function isValidAddress(address: string): boolean {
  if (!address || typeof address !== 'string') return false;
  if (!address.startsWith('ALPHA_')) return false;
  if (address.length < 10 || address.length > 50) return false;
  if (!/^ALPHA_[A-Z0-9]+$/.test(address)) return false;
  return true;
}

router.get('/stats', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  res.json(blockchain.getChainStats());
});

router.get('/blocks', (req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const count = Math.min(parseInt(req.query.count as string) || 20, 100);
  const blocks = blockchain.getRecentBlocks(count);
  res.json(blocks.map(b => ({
    index: b.index,
    hash: b.hash,
    previousHash: b.header.previousHash,
    timestamp: b.header.timestamp,
    difficulty: b.header.difficulty,
    nonce: b.header.nonce,
    merkleRoot: b.header.merkleRoot,
    transactionCount: b.transactions.length,
    size: b.size,
  })));
});

router.get('/block/:identifier', (req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const id = req.params.identifier;
  const block = /^\d+$/.test(id)
    ? blockchain.getBlockByIndex(parseInt(id))
    : blockchain.getBlockByHash(id);

  if (!block) {
    return res.status(404).json({ error: 'Block not found' });
  }
  res.json(block);
});

router.get('/transaction/:txId', (req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const result = blockchain.getTransactionById(req.params.txId);
  if (!result) {
    return res.status(404).json({ error: 'Transaction not found' });
  }
  res.json(result);
});

router.get('/address/:address', (req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const address = req.params.address;
  const balance = blockchain.getBalance(address);
  const transactions = blockchain.getAddressTransactions(address);
  res.json({
    address,
    balance,
    ticker: COIN_TICKER,
    transactionCount: transactions.length,
    transactions: transactions.slice(-50),
  });
});

router.get('/mempool', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  res.json({
    size: blockchain.mempool.length,
    transactions: blockchain.mempool.slice(0, 50),
  });
});

router.post('/wallet/create', isAuthenticated, (_req: Request, res: Response) => {
  const wallet = createWallet();
  storeWallet(wallet.address, wallet.publicKey, wallet.privateKey);
  res.json({
    address: wallet.address,
    publicKey: wallet.publicKey,
    warning: 'Your wallet has been created on this node. The private key is stored securely on the server and is never exposed.',
  });
});

router.post('/mine', isAuthenticated, async (req: Request, res: Response) => {
  const { minerAddress } = req.body;
  if (!minerAddress) {
    return res.status(400).json({ error: 'minerAddress is required' });
  }

  if (!isValidAddress(minerAddress)) {
    return res.status(400).json({ error: 'Invalid miner address format' });
  }

  const blockchain = getBlockchain();

  try {
    const result = await blockchain.mineBlockAsync(minerAddress);

    if ('error' in result) {
      return res.status(400).json(result);
    }

    const p2p = getP2PNetwork();
    if (p2p) p2p.broadcastBlock(result);

    res.json({
      message: `Block #${result.index} mined successfully`,
      block: {
        index: result.index,
        hash: result.hash,
        previousHash: result.header.previousHash,
        timestamp: result.header.timestamp,
        difficulty: result.header.difficulty,
        nonce: result.header.nonce,
        transactionCount: result.transactions.length,
      },
      reward: result.transactions[0].outputs[0].amount,
      ticker: COIN_TICKER,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Mining failed' });
  }
});

router.post('/transaction', isAuthenticated, (req: Request, res: Response) => {
  const { fromAddress, toAddress, amount } = req.body;

  if (!fromAddress || !toAddress || !amount) {
    return res.status(400).json({ error: 'fromAddress, toAddress, and amount are required' });
  }

  if (!isValidAddress(fromAddress) || !isValidAddress(toAddress)) {
    return res.status(400).json({ error: 'Invalid address format' });
  }

  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }

  const blockchain = getBlockchain();
  const privateKey = getWalletPrivateKey(fromAddress);
  const publicKey = getWalletPublicKey(fromAddress);

  if (!privateKey || !publicKey) {
    return res.status(403).json({ error: 'Wallet not found on this node. Only wallets created on this node can send transactions.' });
  }

  const fee = calculateTransactionFee(parsedAmount);
  const balance = blockchain.getBalance(fromAddress);
  if (balance < parsedAmount + fee) {
    return res.status(400).json({
      error: `Insufficient balance. Have ${balance} ${COIN_TICKER}, need ${parsedAmount + fee} ${COIN_TICKER}`,
    });
  }

  const txData: Omit<Transaction, 'id'> = {
    type: 'transfer',
    timestamp: Date.now(),
    inputs: [{ txId: 'balance', outputIndex: 0, address: fromAddress }],
    outputs: [
      { address: toAddress, amount: parsedAmount },
      { address: fromAddress, amount: parseFloat((balance - parsedAmount - fee).toFixed(8)) },
    ],
  };

  const txId = generateTransactionId(txData);

  const txForSigning: Transaction = { ...txData, id: txId } as Transaction;
  const sigPayload = AlphaBlockchain.getSigningPayload(txForSigning);
  const signature = signData(privateKey, sigPayload);

  if (!signature) {
    return res.status(500).json({ error: 'Failed to sign transaction' });
  }

  const transaction: Transaction = {
    ...txData,
    id: txId,
    signature,
    publicKey,
  };

  const result = blockchain.addTransactionToMempool(transaction);
  if (typeof result === 'object' && 'error' in result) {
    return res.status(400).json(result);
  }

  const p2p = getP2PNetwork();
  if (p2p) p2p.broadcastTransaction(transaction);

  res.json({
    message: 'Transaction added to mempool',
    transaction: {
      id: transaction.id,
      from: fromAddress,
      to: toAddress,
      amount: parsedAmount,
      fee,
      timestamp: transaction.timestamp,
    },
    ticker: COIN_TICKER,
  });
});

router.get('/validate', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const isValid = blockchain.isChainValid();
  res.json({
    valid: isValid,
    chainHeight: blockchain.getChainHeight(),
    totalBlocks: blockchain.chain.length,
  });
});

router.get('/supply', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const stats = blockchain.getChainStats();
  const totalBurned = blockchain.getTotalBurned();
  res.json({
    coinName: COIN_NAME,
    ticker: COIN_TICKER,
    totalSupply: stats.totalSupply,
    maxSupply: stats.maxSupply,
    circulatingSupply: parseFloat((stats.totalSupply - totalBurned).toFixed(8)),
    totalBurned,
    burnAddress: BURN_ADDRESS,
    percentMined: parseFloat(((stats.totalSupply / stats.maxSupply) * 100).toFixed(6)),
    percentBurned: parseFloat(((totalBurned / stats.totalSupply) * 100).toFixed(6)) || 0,
  });
});

router.post('/burn', isAuthenticated, (req: Request, res: Response) => {
  const { fromAddress, amount } = req.body;

  if (!fromAddress || !amount) {
    return res.status(400).json({ error: 'fromAddress and amount are required' });
  }

  if (!isValidAddress(fromAddress)) {
    return res.status(400).json({ error: 'Invalid address format' });
  }

  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }

  const blockchain = getBlockchain();
  const privateKey = getWalletPrivateKey(fromAddress);
  const publicKey = getWalletPublicKey(fromAddress);

  if (!privateKey || !publicKey) {
    return res.status(403).json({ error: 'Wallet not found on this node. Only wallets created on this node can burn tokens.' });
  }

  const fee = calculateTransactionFee(parsedAmount);
  const balance = blockchain.getBalance(fromAddress);
  if (balance < parsedAmount + fee) {
    return res.status(400).json({
      error: `Insufficient balance. Have ${balance} ${COIN_TICKER}, need ${parsedAmount + fee} ${COIN_TICKER}`,
    });
  }

  if (fromAddress === blockchain.founderAddress) {
    const spendable = blockchain.getSpendableBalance(fromAddress);
    if (parsedAmount + fee > spendable) {
      return res.status(400).json({
        error: `Vesting restriction: Only ${spendable.toLocaleString()} ${COIN_TICKER} unlocked and available to burn.`,
      });
    }
  }

  const txData: Omit<Transaction, 'id'> = {
    type: 'transfer',
    timestamp: Date.now(),
    inputs: [{ txId: 'balance', outputIndex: 0, address: fromAddress }],
    outputs: [
      { address: BURN_ADDRESS, amount: parsedAmount },
      { address: fromAddress, amount: parseFloat((balance - parsedAmount - fee).toFixed(8)) },
    ],
  };

  const txId = generateTransactionId(txData);
  const txForSigning: Transaction = { ...txData, id: txId } as Transaction;
  const sigPayload = AlphaBlockchain.getSigningPayload(txForSigning);
  const signature = signData(privateKey, sigPayload);

  if (!signature) {
    return res.status(500).json({ error: 'Failed to sign burn transaction' });
  }

  const transaction: Transaction = {
    ...txData,
    id: txId,
    signature,
    publicKey,
  };

  const result = blockchain.addTransactionToMempool(transaction);
  if (typeof result === 'object' && 'error' in result) {
    return res.status(400).json(result);
  }

  const p2p = getP2PNetwork();
  if (p2p) p2p.broadcastTransaction(transaction);

  res.json({
    message: `${parsedAmount} ${COIN_TICKER} burn transaction submitted`,
    transaction: {
      id: transaction.id,
      from: fromAddress,
      to: BURN_ADDRESS,
      amount: parsedAmount,
      fee,
      timestamp: transaction.timestamp,
      type: 'burn',
    },
    burnAddress: BURN_ADDRESS,
    note: 'Coins sent to the burn address are permanently destroyed and removed from circulation.',
    ticker: COIN_TICKER,
  });
});

router.get('/burn/stats', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const totalBurned = blockchain.getTotalBurned();
  const stats = blockchain.getChainStats();
  const burnTxs = blockchain.getAddressTransactions(BURN_ADDRESS);

  res.json({
    burnAddress: BURN_ADDRESS,
    totalBurned,
    ticker: COIN_TICKER,
    burnTransactions: burnTxs.length,
    percentOfSupply: parseFloat(((totalBurned / stats.totalSupply) * 100).toFixed(6)) || 0,
    circulatingSupply: parseFloat((stats.totalSupply - totalBurned).toFixed(8)),
    recentBurns: burnTxs.slice(-20).reverse().map(bt => ({
      txId: bt.transaction.id,
      amount: bt.transaction.outputs.find(o => o.address === BURN_ADDRESS)?.amount || 0,
      from: bt.transaction.inputs[0]?.address,
      blockIndex: bt.blockIndex,
      timestamp: bt.transaction.timestamp,
    })),
  });
});

router.get('/network', (_req: Request, res: Response) => {
  const p2p = getP2PNetwork();
  if (!p2p) {
    return res.json({
      status: 'offline',
      nodeId: null,
      peerCount: 0,
      peers: [],
      message: 'P2P network not initialized',
    });
  }
  res.json(p2p.getNetworkStats());
});

router.post('/network/connect', isAuthenticated, (req: Request, res: Response) => {
  const { address } = req.body;
  if (!address) return res.status(400).json({ error: 'address is required (wss://host:port/ws/p2p)' });
  const p2p = getP2PNetwork();
  if (!p2p) return res.status(503).json({ error: 'P2P network not available' });
  p2p.connectToPeer(address);
  res.json({ message: `Connecting to ${address}...` });
});

router.get('/network/peers', (_req: Request, res: Response) => {
  const p2p = getP2PNetwork();
  res.json({ peers: p2p ? p2p.getPeers() : [], count: p2p ? p2p.getPeerCount() : 0 });
});

router.get('/explorer/search', (req: Request, res: Response) => {
  const { q } = req.query;
  if (!q || typeof q !== 'string') return res.status(400).json({ error: 'Query parameter q is required' });
  const blockchain = getBlockchain();
  const query = q.trim();

  if (/^\d+$/.test(query)) {
    const block = blockchain.getBlockByIndex(parseInt(query));
    if (block) return res.json({ type: 'block', data: block });
  }

  if (query.startsWith('ALPHA_')) {
    const balance = blockchain.getBalance(query);
    const txs = blockchain.getAddressTransactions(query);
    return res.json({ type: 'address', data: { address: query, balance, transactionCount: txs.length, transactions: txs.slice(0, 50) } });
  }

  const block = blockchain.getBlockByHash(query);
  if (block) return res.json({ type: 'block', data: block });

  const tx = blockchain.getTransactionById(query);
  if (tx) return res.json({ type: 'transaction', data: tx });

  res.json({ type: 'not_found', data: null, message: 'No results found' });
});

router.get('/explorer/latest', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const blocks = blockchain.getRecentBlocks(20);
  const recentTxs: any[] = [];
  for (const block of blocks.slice(0, 5)) {
    for (const tx of block.transactions) {
      recentTxs.push({ ...tx, blockIndex: block.index, blockHash: block.hash });
    }
  }
  res.json({
    blocks: blocks.map(b => ({
      index: b.index,
      hash: b.hash,
      timestamp: b.header.timestamp,
      difficulty: b.header.difficulty,
      nonce: b.header.nonce,
      txCount: b.transactions.length,
      size: b.size,
    })),
    transactions: recentTxs.slice(0, 20),
  });
});

router.get('/mining/pool', (_req: Request, res: Response) => {
  const stratum = getStratumServer();
  if (!stratum) {
    return res.json({
      status: 'offline',
      message: 'Stratum mining server not running',
      connectedMiners: 0,
    });
  }
  res.json({ status: 'online', ...stratum.getStats() });
});

router.get('/explorer/richlist', (_req: Request, res: Response) => {
  const blockchain = getBlockchain();
  const allBalances = blockchain.getAllBalances();
  const founderAddr = blockchain.founderAddress;
  const entries = Array.from(allBalances.entries())
    .filter(([addr]) => addr !== 'COINBASE' && addr !== 'ALPHA_GENESIS_000000000000000000000000000000')
    .map(([address, balance]) => {
      let label: string | undefined;
      if (address === founderAddr) label = 'Founder (Pre-mine)';
      else if (address === BURN_ADDRESS) label = 'Burn Address (Destroyed)';
      return { address, balance, label };
    })
    .sort((a, b) => b.balance - a.balance)
    .slice(0, 100);
  const stats = blockchain.getChainStats();
  res.json({ richlist: entries, totalAddresses: allBalances.size, totalSupply: stats.totalSupply });
});

router.get('/founder', (_req: Request, res: Response) => {
  const disclosure = getFounderDisclosure();
  res.json(disclosure);
});

router.get('/founder/vesting', (_req: Request, res: Response) => {
  const vesting = getVestingSchedule();
  res.json(vesting);
});

router.post('/airdrop', isAuthenticated, (req: Request, res: Response) => {
  const { amountPerHolder, minBalance } = req.body;

  if (!amountPerHolder) {
    return res.status(400).json({ error: 'amountPerHolder is required' });
  }

  const parsedAmount = parseFloat(amountPerHolder);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'amountPerHolder must be a positive number' });
  }

  const minBal = parseFloat(minBalance || '0');

  const blockchain = getBlockchain();
  const founderAddr = blockchain.founderAddress;

  const founderPrivateKey = getWalletPrivateKey(founderAddr);
  const founderPublicKey = getWalletPublicKey(founderAddr);

  if (!founderPrivateKey || !founderPublicKey) {
    return res.status(500).json({ error: 'Founder wallet not available on this node' });
  }

  const allBalances = blockchain.getAllBalances();
  const eligibleHolders = Array.from(allBalances.entries())
    .filter(([addr, bal]) =>
      addr !== founderAddr &&
      addr !== BURN_ADDRESS &&
      addr !== 'COINBASE' &&
      addr !== 'ALPHA_GENESIS_000000000000000000000000000000' &&
      bal >= minBal
    )
    .map(([address]) => address);

  if (eligibleHolders.length === 0) {
    return res.status(400).json({ error: 'No eligible holders found for airdrop', minBalance: minBal });
  }

  const totalNeeded = parsedAmount * eligibleHolders.length;
  const spendable = blockchain.getSpendableBalance(founderAddr);

  if (totalNeeded > spendable) {
    return res.status(400).json({
      error: `Insufficient unlocked funds. Need ${totalNeeded.toLocaleString()} ${COIN_TICKER} for ${eligibleHolders.length} holders, but only ${spendable.toLocaleString()} ${COIN_TICKER} available.`,
    });
  }

  const results: { address: string; amount: number; txId: string }[] = [];
  const errors: { address: string; error: string }[] = [];
  let aborted = false;

  for (const holderAddr of eligibleHolders) {
    const currentSpendable = blockchain.getSpendableBalance(founderAddr);
    const feePerTx = calculateTransactionFee(parsedAmount);
    if (currentSpendable < parsedAmount + feePerTx) {
      aborted = true;
      errors.push({ address: holderAddr, error: 'Insufficient remaining balance - airdrop stopped early' });
      break;
    }

    const tx = blockchain.createTransaction(
      founderAddr,
      holderAddr,
      parsedAmount,
      founderPrivateKey,
      founderPublicKey
    );

    if ('error' in tx) {
      errors.push({ address: holderAddr, error: tx.error });
    } else {
      results.push({ address: holderAddr, amount: parsedAmount, txId: tx.id });
      const p2p = getP2PNetwork();
      if (p2p) p2p.broadcastTransaction(tx);
    }
  }

  res.json({
    message: aborted
      ? `Airdrop partially completed: ${results.length} of ${eligibleHolders.length} transactions created (stopped due to insufficient funds)`
      : `Airdrop submitted: ${results.length} transactions created`,
    amountPerHolder: parsedAmount,
    totalDistributed: parsedAmount * results.length,
    eligibleHolders: eligibleHolders.length,
    successful: results.length,
    failed: errors.length,
    aborted,
    ticker: COIN_TICKER,
    transactions: results,
    errors: errors.length > 0 ? errors : undefined,
    note: 'Airdrop transactions are in the mempool and will be included in the next mined block.',
  });
});

router.get('/airdrop/preview', (req: Request, res: Response) => {
  const amountPerHolder = parseFloat(req.query.amount as string || '0');
  const minBal = parseFloat(req.query.minBalance as string || '0');

  const blockchain = getBlockchain();
  const founderAddr = blockchain.founderAddress;
  const allBalances = blockchain.getAllBalances();

  const eligibleHolders = Array.from(allBalances.entries())
    .filter(([addr, bal]) =>
      addr !== founderAddr &&
      addr !== BURN_ADDRESS &&
      addr !== 'COINBASE' &&
      addr !== 'ALPHA_GENESIS_000000000000000000000000000000' &&
      bal >= minBal
    )
    .map(([address, balance]) => ({ address, balance }));

  const totalNeeded = amountPerHolder * eligibleHolders.length;
  const spendable = blockchain.getSpendableBalance(founderAddr);

  res.json({
    eligibleHolders: eligibleHolders.length,
    holders: eligibleHolders,
    amountPerHolder,
    totalNeeded,
    founderSpendable: spendable,
    canAfford: totalNeeded <= spendable,
    ticker: COIN_TICKER,
  });
});

router.get('/spider/status', (_req: Request, res: Response) => {
  const spider = getSpider();
  if (!spider) {
    return res.json({ status: 'offline', blocksAnalyzed: 0, totalBlocks: 0, crawlProgress: 0 });
  }
  res.json(spider.getStatus());
});

router.get('/spider/intelligence', (_req: Request, res: Response) => {
  const intelligence = getSpiderIntelligence();
  if (!intelligence) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json(intelligence);
});

router.get('/spider/nonce-map', (_req: Request, res: Response) => {
  const intelligence = getSpiderIntelligence();
  if (!intelligence) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json({
    buckets: intelligence.nonceBuckets,
    hotspots: intelligence.nonceHotspots,
    preferredRanges: intelligence.preferredNonceRanges,
    totalBlocks: intelligence.blocksAnalyzed,
  });
});

router.get('/spider/difficulty-prediction', (_req: Request, res: Response) => {
  const prediction = getDifficultyPrediction();
  if (!prediction) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json(prediction);
});

router.get('/spider/mining-window', (_req: Request, res: Response) => {
  const window = getOptimalMiningWindow();
  if (!window) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json(window);
});

router.get('/spider/entropy', (_req: Request, res: Response) => {
  const entropy = getEntropyAnalysis();
  if (!entropy) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json(entropy);
});

router.get('/spider/template', (_req: Request, res: Response) => {
  const template = getTemplateOptimization();
  if (!template) {
    return res.status(503).json({ error: 'Spider not initialized' });
  }
  res.json(template);
});

router.get('/forensic/chains', (_req: Request, res: Response) => {
  res.json({ chains: getSupportedChains() });
});

router.get('/forensic/detect', (req: Request, res: Response) => {
  const input = req.query.input as string;
  if (!input) return res.status(400).json({ error: 'Input required' });
  const result = detectChainFromInput(input.trim());
  res.json({ detected: result });
});

router.get('/forensic/trace/address/:address', async (req: Request, res: Response) => {
  const { address } = req.params;
  const chain = req.query.chain as string | undefined;
  if (!address) return res.status(400).json({ error: 'Address required' });

  try {
    const profile = await traceAddress(address, chain);
    if (!profile) {
      return res.status(404).json({ error: 'Address not found or unsupported chain' });
    }
    res.json(profile);
  } catch (err: any) {
    console.error('[ForensicTracer] Route error:', err.message);
    res.status(500).json({ error: 'Trace failed', message: err.message });
  }
});

router.get('/forensic/trace/transaction/:hash', async (req: Request, res: Response) => {
  const { hash } = req.params;
  const chain = req.query.chain as string | undefined;
  if (!hash) return res.status(400).json({ error: 'Transaction hash required' });

  try {
    const detail = await traceTransaction(hash, chain);
    if (!detail) {
      return res.status(404).json({ error: 'Transaction not found' });
    }
    res.json(detail);
  } catch (err: any) {
    console.error('[ForensicTracer] Tx route error:', err.message);
    res.status(500).json({ error: 'Trace failed', message: err.message });
  }
});

router.post('/forensic/trace/flow', async (req: Request, res: Response) => {
  const { address, chain, depth, direction } = req.body;
  if (!address || !chain) return res.status(400).json({ error: 'Address and chain required' });

  const maxDepth = Math.min(depth || 2, 3);
  const flowDir = direction === 'backward' ? 'backward' : 'forward';

  try {
    const graph = await traceFundFlow(address, chain, maxDepth, flowDir);
    res.json(graph);
  } catch (err: any) {
    console.error('[ForensicTracer] Flow trace error:', err.message);
    res.status(500).json({ error: 'Flow trace failed', message: err.message });
  }
});

export default router;
