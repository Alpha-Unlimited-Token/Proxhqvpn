import WebSocket, { WebSocketServer } from 'ws';
import { type Server } from 'http';
import { AlphaBlockchain, getBlockchain } from './chain.js';
import type { Block, Transaction } from './block.js';
import { COIN_NAME, COIN_TICKER } from './consensus.js';

export interface P2PMessage {
  type: string;
  data: any;
  nodeId: string;
  timestamp: number;
}

export interface PeerInfo {
  nodeId: string;
  address: string;
  port: number;
  version: string;
  chainHeight: number;
  connectedAt: number;
  lastSeen: number;
  latency: number;
}

const P2P_VERSION = '1.0.0';
const HEARTBEAT_INTERVAL = 30000;
const PEER_TIMEOUT = 90000;
const MAX_PEERS = 50;

const RATE_LIMIT_WINDOW_MS = 10000;
const RATE_LIMIT_MAX_MESSAGES = 100;

interface RateLimitEntry {
  count: number;
  windowStart: number;
}

const MAX_KNOWN_BLOCKS = 10000;
const MAX_KNOWN_TXS = 50000;

export class P2PNetwork {
  private wss: WebSocketServer | null = null;
  private peers: Map<string, { ws: WebSocket; info: PeerInfo }> = new Map();
  private nodeId: string;
  private port: number;
  private seedNodes: string[];
  private blockchain: AlphaBlockchain;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private eventHandlers: Map<string, Function[]> = new Map();
  private knownBlocks: Set<string> = new Set();
  private knownTxs: Set<string> = new Set();
  private isSyncing: boolean = false;
  private rateLimits: Map<string, RateLimitEntry> = new Map();
  private startTime: number = Date.now();

  constructor(port: number = 6001, seedNodes: string[] = []) {
    this.nodeId = `node_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}`;
    this.port = port;
    this.seedNodes = seedNodes;
    this.blockchain = getBlockchain();

    for (const block of this.blockchain.chain) {
      this.knownBlocks.add(block.hash);
    }
  }

  private checkRateLimit(peerId: string): boolean {
    const now = Date.now();
    const entry = this.rateLimits.get(peerId);

    if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
      this.rateLimits.set(peerId, { count: 1, windowStart: now });
      return true;
    }

    entry.count++;
    if (entry.count > RATE_LIMIT_MAX_MESSAGES) {
      return false;
    }
    return true;
  }

  start(_server?: Server): void {
    this.wss = new WebSocketServer({ port: this.port });

    this.wss.on('connection', (ws: WebSocket, req) => {
      this.handleNewConnection(ws, req.socket.remoteAddress || 'unknown');
    });

    this.startHeartbeat();
    this.connectToSeeds();

    console.log(`[${COIN_NAME}] P2P network started | Node: ${this.nodeId} | Port: ${this.port}`);
  }

  stop(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    Array.from(this.peers.values()).forEach(peer => peer.ws.close());
    this.peers.clear();
    if (this.wss) this.wss.close();
    console.log(`[${COIN_NAME}] P2P network stopped`);
  }

  private handleNewConnection(ws: WebSocket, remoteAddress: string): void {
    if (this.peers.size >= MAX_PEERS) {
      ws.close(1013, 'Max peers reached');
      return;
    }

    const tempId = `pending_${Date.now()}`;

    ws.on('message', (data: Buffer) => {
      try {
        const message: P2PMessage = JSON.parse(data.toString());

        if (!this.checkRateLimit(message.nodeId || tempId)) {
          console.log(`[${COIN_NAME}] P2P: Rate limited peer ${message.nodeId || tempId}`);
          return;
        }

        this.handleMessage(ws, message, remoteAddress);
      } catch (err) {
        console.error(`[${COIN_NAME}] P2P invalid message from ${remoteAddress}`);
      }
    });

    ws.on('close', () => {
      const entries = Array.from(this.peers.entries());
      for (const [peerId, peer] of entries) {
        if (peer.ws === ws) {
          this.peers.delete(peerId);
          this.rateLimits.delete(peerId);
          this.emit('peer:disconnect', peerId);
          console.log(`[${COIN_NAME}] Peer disconnected: ${peerId}`);
          break;
        }
      }
    });

    ws.on('error', (err) => {
      console.error(`[${COIN_NAME}] P2P peer error: ${err.message}`);
    });

    this.sendMessage(ws, {
      type: 'HELLO',
      data: {
        nodeId: this.nodeId,
        version: P2P_VERSION,
        chainHeight: this.blockchain.getChainHeight(),
        ticker: COIN_TICKER,
        port: this.port,
        genesisHash: this.blockchain.genesisHash,
      },
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  private handleMessage(ws: WebSocket, message: P2PMessage, remoteAddress: string): void {
    if (message.nodeId === this.nodeId) return;

    switch (message.type) {
      case 'HELLO':
        this.handleHello(ws, message, remoteAddress);
        break;
      case 'HELLO_ACK':
        this.handleHelloAck(ws, message, remoteAddress);
        break;
      case 'GET_PEERS':
        this.handleGetPeers(ws);
        break;
      case 'PEERS':
        this.handlePeersResponse(message);
        break;
      case 'NEW_BLOCK':
        this.handleNewBlock(message);
        break;
      case 'NEW_TX':
        this.handleNewTransaction(message);
        break;
      case 'GET_CHAIN':
        this.handleGetChain(ws, message);
        break;
      case 'CHAIN_RESPONSE':
        this.handleChainResponse(message);
        break;
      case 'GET_BLOCKS':
        this.handleGetBlocks(ws, message);
        break;
      case 'BLOCKS_RESPONSE':
        this.handleBlocksResponse(message);
        break;
      case 'PING':
        this.sendMessage(ws, { type: 'PONG', data: { timestamp: message.timestamp }, nodeId: this.nodeId, timestamp: Date.now() });
        break;
      case 'PONG':
        this.handlePong(message);
        break;
    }
  }

  private handleHello(ws: WebSocket, message: P2PMessage, remoteAddress: string): void {
    const { nodeId, version, chainHeight, port, genesisHash } = message.data;

    if (genesisHash && genesisHash !== this.blockchain.genesisHash) {
      console.log(`[${COIN_NAME}] P2P: Rejected peer ${nodeId} - genesis hash mismatch`);
      ws.close(1008, 'Genesis hash mismatch');
      return;
    }

    if (this.peers.has(nodeId)) {
      ws.close(1000, 'Already connected');
      return;
    }

    const peerInfo: PeerInfo = {
      nodeId,
      address: remoteAddress,
      port: port || this.port,
      version,
      chainHeight,
      connectedAt: Date.now(),
      lastSeen: Date.now(),
      latency: 0,
    };

    this.peers.set(nodeId, { ws, info: peerInfo });
    this.emit('peer:connect', peerInfo);
    console.log(`[${COIN_NAME}] Peer connected: ${nodeId} (height: ${chainHeight})`);

    this.sendMessage(ws, {
      type: 'HELLO_ACK',
      data: {
        nodeId: this.nodeId,
        version: P2P_VERSION,
        chainHeight: this.blockchain.getChainHeight(),
        ticker: COIN_TICKER,
        port: this.port,
        genesisHash: this.blockchain.genesisHash,
      },
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });

    if (chainHeight > this.blockchain.getChainHeight()) {
      this.requestChainSync(ws, nodeId);
    }
  }

  private handleHelloAck(ws: WebSocket, message: P2PMessage, remoteAddress: string): void {
    const { nodeId, version, chainHeight, port, genesisHash } = message.data;

    if (genesisHash && genesisHash !== this.blockchain.genesisHash) {
      console.log(`[${COIN_NAME}] P2P: Rejected peer ${nodeId} - genesis hash mismatch`);
      ws.close(1008, 'Genesis hash mismatch');
      return;
    }

    if (!this.peers.has(nodeId)) {
      const peerInfo: PeerInfo = {
        nodeId,
        address: remoteAddress,
        port: port || this.port,
        version,
        chainHeight,
        connectedAt: Date.now(),
        lastSeen: Date.now(),
        latency: 0,
      };

      this.peers.set(nodeId, { ws, info: peerInfo });
      this.emit('peer:connect', peerInfo);
      console.log(`[${COIN_NAME}] Peer confirmed: ${nodeId} (height: ${chainHeight})`);
    }

    if (chainHeight > this.blockchain.getChainHeight()) {
      this.requestChainSync(ws, nodeId);
    }
  }

  private handleGetPeers(ws: WebSocket): void {
    const peerList = Array.from(this.peers.values()).map(p => ({
      address: p.info.address,
      port: p.info.port,
      nodeId: p.info.nodeId,
    }));
    this.sendMessage(ws, { type: 'PEERS', data: peerList, nodeId: this.nodeId, timestamp: Date.now() });
  }

  private handlePeersResponse(message: P2PMessage): void {
    const peers = message.data as { address: string; port: number; nodeId: string }[];
    for (const peer of peers) {
      if (peer.nodeId !== this.nodeId && !this.peers.has(peer.nodeId) && this.peers.size < MAX_PEERS) {
        const protocol = process.env.NODE_ENV === 'production' ? 'wss' : 'ws';
        this.connectToPeer(`${protocol}://${peer.address}:${peer.port}/ws/p2p`);
      }
    }
  }

  private handleNewBlock(message: P2PMessage): void {
    const block: Block = message.data;

    if (this.knownBlocks.has(block.hash)) return;
    this.knownBlocks.add(block.hash);

    const currentHeight = this.blockchain.getChainHeight();
    const latestBlock = this.blockchain.getLatestBlock();

    if (block.index === currentHeight + 1 && block.header.previousHash === latestBlock.hash) {
      if (this.blockchain.validateBlock(block, latestBlock)) {
        this.blockchain.chain.push(block);
        this.blockchain.processBlockTransactions(block);

        const minedTxIds = new Set(block.transactions.map(tx => tx.id));
        this.blockchain.mempool = this.blockchain.mempool.filter(tx => !minedTxIds.has(tx.id));

        console.log(`[${COIN_NAME}] P2P: Accepted block #${block.index} from ${message.nodeId}`);
        this.emit('block:received', block);

        this.broadcast({ type: 'NEW_BLOCK', data: block, nodeId: this.nodeId, timestamp: Date.now() }, message.nodeId);
      }
    } else if (block.index > currentHeight + 1) {
      const peer = this.peers.get(message.nodeId);
      if (peer) {
        this.requestChainSync(peer.ws, message.nodeId);
      }
    }
  }

  private handleNewTransaction(message: P2PMessage): void {
    const tx: Transaction = message.data;

    if (this.knownTxs.has(tx.id)) return;
    this.knownTxs.add(tx.id);

    const result = this.blockchain.addTransactionToMempool(tx);
    if (result === true) {
      console.log(`[${COIN_NAME}] P2P: Accepted tx ${tx.id.substring(0, 12)}... from ${message.nodeId}`);
      this.broadcast({ type: 'NEW_TX', data: tx, nodeId: this.nodeId, timestamp: Date.now() }, message.nodeId);
    }
  }

  private handleGetChain(ws: WebSocket, message: P2PMessage): void {
    const fromHeight = message.data?.fromHeight || 0;
    const blocks = this.blockchain.chain.slice(fromHeight);

    this.sendMessage(ws, {
      type: 'CHAIN_RESPONSE',
      data: { blocks, totalHeight: this.blockchain.getChainHeight() },
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  private handleChainResponse(message: P2PMessage): void {
    const { blocks, totalHeight } = message.data;

    if (!blocks || !Array.isArray(blocks) || blocks.length === 0) {
      this.isSyncing = false;
      return;
    }

    if (totalHeight <= this.blockchain.getChainHeight()) {
      this.isSyncing = false;
      return;
    }

    if (blocks[0]?.hash !== this.blockchain.genesisHash) {
      console.log(`[${COIN_NAME}] P2P: Chain sync rejected - genesis hash mismatch from peer`);
      this.isSyncing = false;
      return;
    }

    const tempChain: Block[] = [...blocks];
    let isValid = true;
    for (let i = 1; i < tempChain.length; i++) {
      if (!this.blockchain.validateBlock(tempChain[i], tempChain[i - 1])) {
        isValid = false;
        break;
      }
    }

    if (isValid && tempChain.length > this.blockchain.chain.length) {
      console.log(`[${COIN_NAME}] P2P: Chain sync - replacing chain (${this.blockchain.getChainHeight()} -> ${tempChain.length - 1})`);

      this.blockchain.chain = tempChain;
      this.blockchain.balances.clear();
      for (const block of tempChain) {
        this.blockchain.processBlockTransactions(block);
        this.knownBlocks.add(block.hash);
      }

      this.emit('chain:synced', { height: this.blockchain.getChainHeight() });
    }

    this.isSyncing = false;
  }

  private handleGetBlocks(ws: WebSocket, message: P2PMessage): void {
    const { fromIndex, count } = message.data;
    const blocks = this.blockchain.chain.slice(fromIndex, fromIndex + (count || 100));
    this.sendMessage(ws, {
      type: 'BLOCKS_RESPONSE',
      data: blocks,
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  private handleBlocksResponse(message: P2PMessage): void {
    const blocks: Block[] = message.data;
    if (!blocks || blocks.length === 0) return;

    for (const block of blocks) {
      if (this.knownBlocks.has(block.hash)) continue;
      const latestBlock = this.blockchain.getLatestBlock();
      if (block.index === this.blockchain.getChainHeight() + 1 && this.blockchain.validateBlock(block, latestBlock)) {
        this.blockchain.chain.push(block);
        this.blockchain.processBlockTransactions(block);
        this.knownBlocks.add(block.hash);
      }
    }
  }

  private handlePong(message: P2PMessage): void {
    const peer = this.peers.get(message.nodeId);
    if (peer) {
      peer.info.lastSeen = Date.now();
      peer.info.latency = Date.now() - (message.data?.timestamp || Date.now());
    }
  }

  private requestChainSync(ws: WebSocket, peerId: string): void {
    if (this.isSyncing) return;
    this.isSyncing = true;
    console.log(`[${COIN_NAME}] P2P: Requesting chain sync from ${peerId}`);
    this.sendMessage(ws, {
      type: 'GET_CHAIN',
      data: { fromHeight: 0 },
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  connectToPeer(address: string): void {
    try {
      const ws = new WebSocket(address);

      ws.on('open', () => {
        this.handleNewConnection(ws, address);
      });

      ws.on('error', (err) => {
        console.log(`[${COIN_NAME}] P2P: Failed to connect to ${address}: ${err.message}`);
      });
    } catch (err) {
      console.log(`[${COIN_NAME}] P2P: Connection error: ${address}`);
    }
  }

  private connectToSeeds(): void {
    for (const seed of this.seedNodes) {
      if (!seed) continue;
      this.connectToPeer(seed);
    }
  }

  broadcast(message: P2PMessage, excludeNodeId?: string): void {
    const entries = Array.from(this.peers.entries());
    for (const [peerId, peer] of entries) {
      if (peerId === excludeNodeId) continue;
      if (peer.ws.readyState === WebSocket.OPEN) {
        this.sendMessage(peer.ws, message);
      }
    }
  }

  private pruneKnownSets(): void {
    if (this.knownBlocks.size > MAX_KNOWN_BLOCKS) {
      const excess = this.knownBlocks.size - MAX_KNOWN_BLOCKS;
      const iter = this.knownBlocks.values();
      for (let i = 0; i < excess; i++) {
        this.knownBlocks.delete(iter.next().value as string);
      }
    }
    if (this.knownTxs.size > MAX_KNOWN_TXS) {
      const excess = this.knownTxs.size - MAX_KNOWN_TXS;
      const iter = this.knownTxs.values();
      for (let i = 0; i < excess; i++) {
        this.knownTxs.delete(iter.next().value as string);
      }
    }
  }

  broadcastBlock(block: Block): void {
    this.knownBlocks.add(block.hash);
    this.pruneKnownSets();
    this.broadcast({
      type: 'NEW_BLOCK',
      data: block,
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  broadcastTransaction(tx: Transaction): void {
    this.knownTxs.add(tx.id);
    this.pruneKnownSets();
    this.broadcast({
      type: 'NEW_TX',
      data: tx,
      nodeId: this.nodeId,
      timestamp: Date.now(),
    });
  }

  private sendMessage(ws: WebSocket, message: P2PMessage): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  private startHeartbeat(): void {
    this.heartbeatTimer = setInterval(() => {
      const now = Date.now();
      const entries = Array.from(this.peers.entries());
      for (const [peerId, peer] of entries) {
        if (now - peer.info.lastSeen > PEER_TIMEOUT) {
          console.log(`[${COIN_NAME}] P2P: Peer timeout: ${peerId}`);
          peer.ws.close();
          this.peers.delete(peerId);
          this.rateLimits.delete(peerId);
          continue;
        }
        this.sendMessage(peer.ws, { type: 'PING', data: {}, nodeId: this.nodeId, timestamp: Date.now() });
      }

      if (this.peers.size < 3 && this.seedNodes.length > 0) {
        this.connectToSeeds();
      }
    }, HEARTBEAT_INTERVAL);
  }

  on(event: string, handler: Function): void {
    if (!this.eventHandlers.has(event)) this.eventHandlers.set(event, []);
    this.eventHandlers.get(event)!.push(handler);
  }

  private emit(event: string, data?: any): void {
    const handlers = this.eventHandlers.get(event) || [];
    for (const handler of handlers) {
      try { handler(data); } catch (err) { console.error(`[${COIN_NAME}] P2P event error:`, err); }
    }
  }

  getNodeId(): string { return this.nodeId; }
  getPeerCount(): number { return this.peers.size; }
  getPeers(): PeerInfo[] { return Array.from(this.peers.values()).map(p => p.info); }
  isSyncingChain(): boolean { return this.isSyncing; }

  getNetworkStats() {
    return {
      status: 'online',
      nodeId: this.nodeId,
      version: P2P_VERSION,
      peerCount: this.peers.size,
      maxPeers: MAX_PEERS,
      chainHeight: this.blockchain.getChainHeight(),
      isSyncing: this.isSyncing,
      peers: this.getPeers(),
      knownBlocks: this.knownBlocks.size,
      knownTransactions: this.knownTxs.size,
      seedNodes: this.seedNodes,
      uptime: Date.now() - this.startTime,
    };
  }
}

let p2pInstance: P2PNetwork | null = null;

export function getP2PNetwork(): P2PNetwork | null {
  return p2pInstance;
}

export function initP2PNetwork(port?: number, seedNodes?: string[], server?: Server): P2PNetwork {
  if (!p2pInstance) {
    const seeds = seedNodes || (process.env.AUC_SEED_NODES ? process.env.AUC_SEED_NODES.split(',') : []);
    p2pInstance = new P2PNetwork(port || 6001, seeds);
    p2pInstance.start(server);
  }
  return p2pInstance;
}
