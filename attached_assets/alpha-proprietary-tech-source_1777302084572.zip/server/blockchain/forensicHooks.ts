/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved Worldwide in Perpetuity.
 * Alpha AUC Forensic Transfer Hook Engine™ is proprietary technology. Patent Pending.
 * Unauthorized copying, modification, distribution, reverse engineering, or use is strictly prohibited.
 * Protected by international copyright and trade secret laws.
 * CONTAINS TRADE SECRETS - DO NOT DISTRIBUTE
 *
 * This module implements blockchain-level forensic transfer hooks embedded directly
 * into the AUC blockchain protocol. Every AUC transaction is evaluated for forensic
 * relevance and fires real-time signals to the Alpha Spider Beacon Protocol™.
 *
 * Transfer hooks CANNOT be disabled, bypassed, or removed by any party.
 * They are hardcoded at the protocol level.
 *
 * Technologies Protected:
 * - Alpha AUC Forensic Transfer Hook Engine™
 * - AUC Trap Mechanism™ Protocol-Level Integration
 * - Forensic Signal Relay System™
 *
 * Patent Pending. Trade Secret Protected. DMCA Protected.
 * ALPHA_INTEGRITY_SEAL: AUC_FORENSIC_HOOKS_v1.0_PROTECTED
 */

import { registerBeacon } from "../services/integrityBeacon.js";

export const _forensicHooksModuleHash = 'AUT_fh01_forensic_hooks_a7c2';
const _fhIntegrity = registerBeacon('forensicHooks', _forensicHooksModuleHash);

export interface ForensicTransferRecord {
  txId: string;
  blockIndex: number;
  timestamp: number;
  fromAddress: string;
  toAddress: string;
  amount: number;
  fee: number;
  forensicFlags: string[];
  signalsFired: number;
  isTrapped: boolean;
  isWatched: boolean;
  isLargeTransfer: boolean;
}

export interface WatchedAddress {
  address: string;
  caseId: string | null;
  reason: string;
  addedAt: Date;
  alertLevel: 'info' | 'warning' | 'critical';
  totalTransfers: number;
  totalVolume: number;
  lastActivity: Date | null;
  metadata: Record<string, any>;
}

export interface ForensicSignalLog {
  id: string;
  timestamp: Date;
  txId: string;
  blockIndex: number;
  type: 'trap_triggered' | 'watched_transfer' | 'large_transfer' | 'flagged_movement' | 'new_address_detected' | 'transfer';
  severity: 'info' | 'warning' | 'critical';
  fromAddress: string;
  toAddress: string;
  amount: number;
  details: string;
  caseId: string | null;
}

const LARGE_TRANSFER_THRESHOLD = 100000;
const CRITICAL_TRANSFER_THRESHOLD = 1000000;

class ForensicHookEngine {
  private watchedAddresses: Map<string, WatchedAddress> = new Map();
  private transferLog: ForensicTransferRecord[] = [];
  private signalLog: ForensicSignalLog[] = [];
  private signalCounter = 0;
  private spiderBeaconRef: any = null;

  constructor() {
    console.log('[ForensicHooks] Alpha AUC Forensic Transfer Hook Engine™ initialized');
    console.log('[ForensicHooks] Protocol-level transfer hooks ACTIVE — cannot be disabled');
  }

  setSpiderBeaconService(sbs: any) {
    this.spiderBeaconRef = sbs;
    console.log('[ForensicHooks] Connected to Alpha Spider Beacon Protocol™');
  }

  addWatchedAddress(
    address: string,
    caseId: string | null,
    reason: string,
    alertLevel: 'info' | 'warning' | 'critical' = 'warning',
    metadata: Record<string, any> = {}
  ): WatchedAddress {
    const normalized = address.toLowerCase();
    const existing = this.watchedAddresses.get(normalized);
    if (existing) {
      existing.reason = reason;
      existing.alertLevel = alertLevel;
      existing.caseId = caseId || existing.caseId;
      existing.metadata = { ...existing.metadata, ...metadata };
      return existing;
    }

    const watched: WatchedAddress = {
      address: normalized,
      caseId,
      reason,
      addedAt: new Date(),
      alertLevel,
      totalTransfers: 0,
      totalVolume: 0,
      lastActivity: null,
      metadata,
    };
    this.watchedAddresses.set(normalized, watched);
    console.log(`[ForensicHooks] Address added to watch list: ${normalized.slice(0, 16)}... (${reason})`);
    return watched;
  }

  removeWatchedAddress(address: string): boolean {
    return this.watchedAddresses.delete(address.toLowerCase());
  }

  getWatchedAddresses(): WatchedAddress[] {
    return Array.from(this.watchedAddresses.values());
  }

  isWatched(address: string): boolean {
    return this.watchedAddresses.has(address.toLowerCase());
  }

  getTransferLog(address?: string, limit = 100): ForensicTransferRecord[] {
    let records = address
      ? this.transferLog.filter(r => r.fromAddress === address.toLowerCase() || r.toAddress === address.toLowerCase())
      : [...this.transferLog];
    records.sort((a, b) => b.timestamp - a.timestamp);
    return records.slice(0, limit);
  }

  getSignalLog(caseId?: string, limit = 200): ForensicSignalLog[] {
    let filtered = caseId
      ? this.signalLog.filter(s => s.caseId === caseId)
      : [...this.signalLog];
    filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return filtered.slice(0, limit);
  }

  getStats() {
    const watched = Array.from(this.watchedAddresses.values());
    const criticalWatched = watched.filter(w => w.alertLevel === 'critical');
    const trappedSignals = this.signalLog.filter(s => s.type === 'trap_triggered');
    const last24h = new Date(Date.now() - 86400000);
    const recentSignals = this.signalLog.filter(s => s.timestamp >= last24h);

    return {
      totalWatchedAddresses: watched.length,
      criticalAddresses: criticalWatched.length,
      totalTransfersLogged: this.transferLog.length,
      totalSignalsFired: this.signalLog.length,
      trapTriggeredCount: trappedSignals.length,
      signals24h: recentSignals.length,
      largeTransfers: this.transferLog.filter(r => r.isLargeTransfer).length,
      casesLinked: new Set(watched.filter(w => w.caseId).map(w => w.caseId)).size,
    };
  }

  processTransferHook(
    txId: string,
    blockIndex: number,
    timestamp: number,
    fromAddress: string,
    toAddress: string,
    amount: number,
    fee: number
  ): ForensicTransferRecord {
    const fromLower = fromAddress.toLowerCase();
    const toLower = toAddress.toLowerCase();
    const flags: string[] = [];
    let signalsFired = 0;

    const isFromWatched = this.watchedAddresses.has(fromLower);
    const isToWatched = this.watchedAddresses.has(toLower);
    const isLarge = amount >= LARGE_TRANSFER_THRESHOLD;
    const isCritical = amount >= CRITICAL_TRANSFER_THRESHOLD;

    let isTrapped = false;
    if (this.spiderBeaconRef) {
      const trapSignals = this.spiderBeaconRef.checkAucBlockchainTransfers(fromLower, toLower, amount);
      if (trapSignals.length > 0) {
        isTrapped = true;
        signalsFired += trapSignals.length;
        flags.push('AUC_TRAP_TRIGGERED');

        for (const ts of trapSignals) {
          if (ts.txHash === null) {
            ts.txHash = txId;
          }
        }
      }
    }

    if (isFromWatched) {
      const watched = this.watchedAddresses.get(fromLower)!;
      watched.totalTransfers++;
      watched.totalVolume += amount;
      watched.lastActivity = new Date(timestamp);
      flags.push('WATCHED_SENDER');

      const signal = this.createSignal({
        txId, blockIndex,
        type: 'watched_transfer',
        severity: watched.alertLevel,
        fromAddress: fromLower,
        toAddress: toLower,
        amount,
        details: `Watched address ${fromLower.slice(0, 16)}... sent ${amount.toLocaleString()} AUC to ${toLower.slice(0, 16)}... (${watched.reason})`,
        caseId: watched.caseId,
      });
      signalsFired++;

      if (!this.watchedAddresses.has(toLower)) {
        this.addWatchedAddress(toLower, watched.caseId, `Received ${amount.toLocaleString()} AUC from watched address ${fromLower.slice(0, 16)}...`, 'warning', {
          sourceAddress: fromLower,
          autoDetected: true,
          detectedTxId: txId,
        });
        this.createSignal({
          txId, blockIndex,
          type: 'new_address_detected',
          severity: 'warning',
          fromAddress: fromLower,
          toAddress: toLower,
          amount,
          details: `NEW ADDRESS AUTO-WATCHED: ${toLower.slice(0, 16)}... received ${amount.toLocaleString()} AUC from forensically tracked wallet`,
          caseId: watched.caseId,
        });
        signalsFired++;
        flags.push('AUTO_WATCH_DEPLOYED');
      }
    }

    if (isToWatched) {
      const watched = this.watchedAddresses.get(toLower)!;
      watched.totalTransfers++;
      watched.totalVolume += amount;
      watched.lastActivity = new Date(timestamp);
      flags.push('WATCHED_RECEIVER');

      this.createSignal({
        txId, blockIndex,
        type: 'watched_transfer',
        severity: watched.alertLevel,
        fromAddress: fromLower,
        toAddress: toLower,
        amount,
        details: `Watched address ${toLower.slice(0, 16)}... received ${amount.toLocaleString()} AUC from ${fromLower.slice(0, 16)}... (${watched.reason})`,
        caseId: watched.caseId,
      });
      signalsFired++;
    }

    if (isLarge) {
      flags.push(isCritical ? 'CRITICAL_LARGE_TRANSFER' : 'LARGE_TRANSFER');
      this.createSignal({
        txId, blockIndex,
        type: 'large_transfer',
        severity: isCritical ? 'critical' : 'warning',
        fromAddress: fromLower,
        toAddress: toLower,
        amount,
        details: `${isCritical ? 'CRITICAL' : 'Large'} AUC transfer: ${amount.toLocaleString()} AUC from ${fromLower.slice(0, 16)}... to ${toLower.slice(0, 16)}...`,
        caseId: null,
      });
      signalsFired++;
    }

    if (!isTrapped && !isFromWatched && !isToWatched && !isLarge) {
      flags.push('TRANSFER_LOGGED');
      this.createSignal({
        txId, blockIndex,
        type: 'transfer',
        severity: 'info',
        fromAddress: fromLower,
        toAddress: toLower,
        amount,
        details: `AUC transfer: ${amount.toLocaleString()} AUC from ${fromLower.slice(0, 16)}... to ${toLower.slice(0, 16)}...`,
        caseId: null,
      });
      signalsFired++;
    }

    const record: ForensicTransferRecord = {
      txId,
      blockIndex,
      timestamp,
      fromAddress: fromLower,
      toAddress: toLower,
      amount,
      fee,
      forensicFlags: flags,
      signalsFired,
      isTrapped,
      isWatched: isFromWatched || isToWatched,
      isLargeTransfer: isLarge,
    };

    this.transferLog.push(record);

    if (this.transferLog.length > 50000) {
      this.transferLog = this.transferLog.slice(-40000);
    }

    console.log(`[ForensicHooks] TX ${txId.slice(0, 12)}... | ${amount.toLocaleString()} AUC | Flags: [${flags.join(', ')}] | Signals: ${signalsFired}`);

    return record;
  }

  private createSignal(params: Omit<ForensicSignalLog, 'id' | 'timestamp'>): ForensicSignalLog {
    this.signalCounter++;
    const signal: ForensicSignalLog = {
      ...params,
      id: `fh_signal_${Date.now()}_${this.signalCounter}`,
      timestamp: new Date(),
    };
    this.signalLog.push(signal);

    if (this.signalLog.length > 10000) {
      this.signalLog = this.signalLog.slice(-8000);
    }

    const icon = params.severity === 'critical' ? '🚨' : params.severity === 'warning' ? '⚠️' : 'ℹ️';
    console.log(`[ForensicHooks] ${icon} ${params.type.toUpperCase()}: ${params.details.slice(0, 120)}`);

    return signal;
  }

  executeTrapSwap(
    caseId: string,
    targetAucAddress: string,
    amount: number,
    originalToken: string,
    originalChain: string,
    originalAddress: string
  ): { success: boolean; message: string; watchedAddress?: WatchedAddress } {
    const normalized = targetAucAddress.toLowerCase();

    this.addWatchedAddress(normalized, caseId, `AUC Trap target — ${amount.toLocaleString()} ${originalToken} swapped from ${originalChain}`, 'critical', {
      trapType: 'token_swap',
      originalToken,
      originalChain,
      originalAddress: originalAddress.toLowerCase(),
      amountSwapped: amount,
      swapTimestamp: Date.now(),
    });

    if (this.spiderBeaconRef) {
      this.spiderBeaconRef.deployAucTrap(
        caseId, originalToken, originalChain, originalAddress, normalized, amount.toString()
      );
    }

    this.createSignal({
      txId: `trap_deploy_${Date.now()}`,
      blockIndex: -1,
      type: 'trap_triggered',
      severity: 'critical',
      fromAddress: originalAddress.toLowerCase(),
      toAddress: normalized,
      amount,
      details: `AUC TRAP DEPLOYED: ${amount.toLocaleString()} ${originalToken} from ${originalChain} swapped to AUC. Wallet ${normalized.slice(0, 16)}... now under perpetual forensic surveillance. Transfer hooks ACTIVE.`,
      caseId,
    });

    console.log(`[ForensicHooks] 🎯 AUC TRAP DEPLOYED on ${normalized.slice(0, 16)}... | Case: ${caseId.slice(0, 8)}... | ${amount.toLocaleString()} ${originalToken} trapped`);

    return {
      success: true,
      message: `AUC Trap deployed. All transfers involving ${normalized.slice(0, 16)}... will fire forensic signals. Transfer hooks are embedded at the protocol level and CANNOT be disabled.`,
      watchedAddress: this.watchedAddresses.get(normalized),
    };
  }
}

let hookEngineInstance: ForensicHookEngine | null = null;

export function getForensicHookEngine(): ForensicHookEngine {
  if (!hookEngineInstance) {
    hookEngineInstance = new ForensicHookEngine();
  }
  return hookEngineInstance;
}
