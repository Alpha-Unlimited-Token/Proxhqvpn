import net from 'net';
import crypto from 'crypto';
import { getBlockchain, AlphaBlockchain } from './chain.js';
import { getP2PNetwork } from './p2p.js';
import {
  calculateBlockHash, calculateMerkleRoot, createCoinbaseTransaction,
  type Block, type BlockHeader,
} from './block.js';
import {
  calculateBlockReward, meetsTarget, calculateTransactionFee, COIN_NAME, COIN_TICKER,
  difficultyToTarget, targetToHex,
} from './consensus.js';
import { getPreferredNonceRanges } from './spider.js';

interface StratumClient {
  id: string;
  socket: net.Socket;
  minerAddress: string;
  workerName: string;
  authorized: boolean;
  subscribed: boolean;
  difficulty: number;
  sharesAccepted: number;
  sharesRejected: number;
  hashrate: number;
  connectedAt: number;
  lastShareTime: number;
  extraNonce: string;
}

interface MiningJob {
  id: string;
  blockHeight: number;
  previousHash: string;
  coinbaseTx: any;
  merkleRoot: string;
  difficulty: number;
  timestamp: number;
  transactions: any[];
  reward: number;
  spiderNonceHint?: { start: number; end: number };
}

const STRATUM_PORT = 3333;
const SHARE_DIFFICULTY_DIVISOR = 2;
const JOB_REFRESH_INTERVAL = 30000;

export class StratumServer {
  private server: net.Server;
  private clients: Map<string, StratumClient> = new Map();
  private currentJob: MiningJob | null = null;
  private jobCounter: number = 0;
  private extraNonceCounter: number = 0;
  private blockchain: AlphaBlockchain;
  private jobTimer: NodeJS.Timeout | null = null;
  private poolStats = {
    totalShares: 0,
    totalBlocks: 0,
    startTime: Date.now(),
    lastBlockTime: 0,
  };

  constructor(private port: number = STRATUM_PORT) {
    this.blockchain = getBlockchain();
    this.server = net.createServer((socket) => this.handleConnection(socket));
  }

  start(): void {
    this.server.listen(this.port, '0.0.0.0', () => {
      console.log(`[${COIN_NAME}] Stratum mining server started on port ${this.port}`);
      this.createNewJob();
      this.startJobRefresh();
    });

    this.server.on('error', (err: any) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`[${COIN_NAME}] Stratum port ${this.port} in use, trying ${this.port + 1}`);
        this.port++;
        setTimeout(() => this.start(), 1000);
      }
    });
  }

  stop(): void {
    if (this.jobTimer) clearInterval(this.jobTimer);
    Array.from(this.clients.values()).forEach(c => c.socket.destroy());
    this.clients.clear();
    this.server.close();
    console.log(`[${COIN_NAME}] Stratum server stopped`);
  }

  private handleConnection(socket: net.Socket): void {
    const clientId = `miner_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
    const extraNonce = (++this.extraNonceCounter).toString(16).padStart(8, '0');

    const client: StratumClient = {
      id: clientId,
      socket,
      minerAddress: '',
      workerName: '',
      authorized: false,
      subscribed: false,
      difficulty: 1,
      sharesAccepted: 0,
      sharesRejected: 0,
      hashrate: 0,
      connectedAt: Date.now(),
      lastShareTime: Date.now(),
      extraNonce,
    };

    this.clients.set(clientId, client);
    console.log(`[${COIN_NAME}] Stratum: Miner connected ${clientId} (${socket.remoteAddress})`);

    let buffer = '';
    socket.on('data', (data) => {
      buffer += data.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.trim()) {
          try {
            const request = JSON.parse(line.trim());
            this.handleRequest(client, request);
          } catch (err) {
            console.error(`[${COIN_NAME}] Stratum: Invalid JSON from ${clientId}`);
          }
        }
      }
    });

    socket.on('close', () => {
      this.clients.delete(clientId);
      console.log(`[${COIN_NAME}] Stratum: Miner disconnected ${clientId}`);
    });

    socket.on('error', () => {
      this.clients.delete(clientId);
    });
  }

  private handleRequest(client: StratumClient, request: any): void {
    const { id, method, params } = request;

    switch (method) {
      case 'mining.subscribe':
        this.handleSubscribe(client, id, params);
        break;
      case 'mining.authorize':
        this.handleAuthorize(client, id, params);
        break;
      case 'mining.submit':
        this.handleSubmit(client, id, params);
        break;
      case 'mining.get_transactions':
        this.sendResponse(client, id, []);
        break;
      default:
        this.sendError(client, id, 20, 'Unknown method');
    }
  }

  private handleSubscribe(client: StratumClient, id: number, _params: any[]): void {
    client.subscribed = true;

    this.sendResponse(client, id, [
      [['mining.set_difficulty', client.id], ['mining.notify', client.id]],
      client.extraNonce,
      4,
    ]);

    this.sendDifficulty(client);

    if (this.currentJob) {
      this.sendJob(client, this.currentJob);
    }
  }

  private handleAuthorize(client: StratumClient, id: number, params: any[]): void {
    const [workerName] = params || [];
    client.workerName = workerName || 'default';

    if (workerName && workerName.includes('.')) {
      client.minerAddress = workerName.split('.')[0];
    } else {
      client.minerAddress = workerName || '';
    }

    if (!client.minerAddress.startsWith('ALPHA_')) {
      client.minerAddress = 'ALPHA_POOL_' + crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 30);
    }

    client.authorized = true;
    this.sendResponse(client, id, true);
    console.log(`[${COIN_NAME}] Stratum: Miner authorized ${client.id} as ${client.workerName} -> ${client.minerAddress}`);

    this.updateJobForMiner(client);
  }

  private updateJobForMiner(client: StratumClient): void {
    if (!this.currentJob || !client.authorized) return;

    const height = this.blockchain.getChainHeight() + 1;
    const difficulty = this.blockchain.getCurrentDifficulty();
    const pendingTxs = this.blockchain.mempool.slice(0, 499);
    const totalFees = this.calculateMempoolFees(pendingTxs);
    const reward = calculateBlockReward(height) + totalFees;

    const coinbaseTx = createCoinbaseTransaction(client.minerAddress, reward, height);
    const allTxs = [coinbaseTx, ...pendingTxs];
    const merkleRoot = calculateMerkleRoot(allTxs);

    const clientJob: MiningJob = {
      id: this.currentJob.id,
      blockHeight: height,
      previousHash: this.blockchain.getLatestBlock().hash,
      coinbaseTx,
      merkleRoot,
      difficulty,
      timestamp: Date.now(),
      transactions: pendingTxs,
      reward,
    };

    this.sendJob(client, clientJob);
  }

  private calculateMempoolFees(transactions: any[]): number {
    let totalFees = 0;
    for (const tx of transactions) {
      if (tx.type === 'coinbase') continue;
      const senderAddr = tx.inputs?.[0]?.address;
      const recipientOutputs = tx.outputs?.filter((o: any) => o.address !== senderAddr) || [];
      const txAmount = recipientOutputs.reduce((s: number, o: any) => s + o.amount, 0);
      totalFees += calculateTransactionFee(txAmount);
    }
    return parseFloat(totalFees.toFixed(8));
  }

  private handleSubmit(client: StratumClient, id: number, params: any[]): void {
    if (!client.authorized) {
      this.sendError(client, id, 24, 'Unauthorized');
      return;
    }

    if (!this.currentJob) {
      this.sendError(client, id, 21, 'No job available');
      return;
    }

    const [, jobId, , ntime, nonce] = params || [];

    if (jobId !== this.currentJob.id) {
      client.sharesRejected++;
      this.sendError(client, id, 21, 'Job not found (stale)');
      return;
    }

    const submittedNonce = parseInt(nonce, 16);
    const submittedTime = parseInt(ntime, 16) || this.currentJob.timestamp;

    const height = this.currentJob.blockHeight;
    const difficulty = this.currentJob.difficulty;
    const pendingTxs = this.currentJob.transactions;
    const totalFees = this.calculateMempoolFees(pendingTxs);
    const reward = calculateBlockReward(height) + totalFees;

    const coinbaseTx = createCoinbaseTransaction(client.minerAddress, reward, height);
    const allTxs = [coinbaseTx, ...pendingTxs];
    const merkleRoot = calculateMerkleRoot(allTxs);

    const header: BlockHeader = {
      version: 1,
      previousHash: this.currentJob.previousHash,
      merkleRoot,
      timestamp: submittedTime,
      difficulty,
      nonce: submittedNonce,
    };

    const hash = calculateBlockHash(header);
    const shareDiff = Math.max(1, difficulty / SHARE_DIFFICULTY_DIVISOR);

    if (!meetsTarget(hash, shareDiff)) {
      client.sharesRejected++;
      this.sendError(client, id, 23, 'Low difficulty share');
      return;
    }

    client.sharesAccepted++;
    client.lastShareTime = Date.now();
    this.poolStats.totalShares++;
    this.sendResponse(client, id, true);

    if (meetsTarget(hash, difficulty)) {
      console.log(`[${COIN_NAME}] Stratum: BLOCK FOUND by ${client.workerName}! Hash: ${hash.substring(0, 16)}... Nonce: ${submittedNonce}`);

      const block: Block = {
        index: height,
        header,
        hash,
        transactions: allTxs,
        size: JSON.stringify(allTxs).length,
      };

      const latestBlock = this.blockchain.getLatestBlock();
      if (this.blockchain.validateBlock(block, latestBlock)) {
        this.blockchain.chain.push(block);
        this.blockchain.processBlockTransactions(block);

        const minedTxIds = new Set(block.transactions.map((tx: any) => tx.id));
        this.blockchain.mempool = this.blockchain.mempool.filter(tx => !minedTxIds.has(tx.id));

        this.poolStats.totalBlocks++;
        this.poolStats.lastBlockTime = Date.now();

        const p2p = getP2PNetwork();
        if (p2p) p2p.broadcastBlock(block);

        console.log(`[${COIN_NAME}] Stratum: Block #${block.index} accepted! Reward: ${reward} ${COIN_TICKER} -> ${client.minerAddress}`);

        this.createNewJob();
        this.broadcastJobToAll();
      }
    }
  }

  private createNewJob(): void {
    const height = this.blockchain.getChainHeight() + 1;
    const difficulty = this.blockchain.getCurrentDifficulty();
    const previousBlock = this.blockchain.getLatestBlock();
    const pendingTxs = this.blockchain.mempool.slice(0, 499);
    const totalFees = this.calculateMempoolFees(pendingTxs);
    const reward = calculateBlockReward(height) + totalFees;

    const poolAddress = Array.from(this.clients.values()).find(c => c.authorized)?.minerAddress ||
      'ALPHA_POOL_DEFAULT_000000000000000000000000000000';

    const coinbaseTx = createCoinbaseTransaction(poolAddress, reward, height);
    const allTxs = [coinbaseTx, ...pendingTxs];
    const merkleRoot = calculateMerkleRoot(allTxs);

    let spiderNonceHint: { start: number; end: number } | null = null;
    try {
      const ranges = getPreferredNonceRanges();
      if (ranges.length > 0) {
        spiderNonceHint = { start: ranges[0].start, end: ranges[0].end };
      }
    } catch {}

    this.currentJob = {
      id: (++this.jobCounter).toString(16).padStart(8, '0'),
      blockHeight: height,
      previousHash: previousBlock.hash,
      coinbaseTx,
      merkleRoot,
      difficulty,
      timestamp: Date.now(),
      transactions: pendingTxs,
      reward,
      ...(spiderNonceHint ? { spiderNonceHint } : {}),
    };
  }

  private broadcastJobToAll(): void {
    if (!this.currentJob) return;
    Array.from(this.clients.values()).forEach(client => {
      if (client.subscribed && client.authorized) {
        this.updateJobForMiner(client);
      } else if (client.subscribed) {
        this.sendJob(client, this.currentJob!);
      }
    });
  }

  private sendJob(client: StratumClient, job: MiningJob): void {
    const targetHex = targetToHex(difficultyToTarget(job.difficulty));
    const notification = {
      id: null,
      method: 'mining.notify',
      params: [
        job.id,
        job.previousHash,
        '',
        '',
        [],
        '00000001',
        targetHex.substring(0, 8),
        Math.floor(job.timestamp / 1000).toString(16),
        true,
      ],
    };
    this.send(client, notification);
  }

  private sendDifficulty(client: StratumClient): void {
    this.send(client, { id: null, method: 'mining.set_difficulty', params: [client.difficulty] });
  }

  private sendResponse(client: StratumClient, id: number, result: any): void {
    this.send(client, { id, result, error: null });
  }

  private sendError(client: StratumClient, id: number, code: number, message: string): void {
    this.send(client, { id, result: null, error: [code, message, null] });
  }

  private send(client: StratumClient, data: any): void {
    try {
      client.socket.write(JSON.stringify(data) + '\n');
    } catch {}
  }

  private startJobRefresh(): void {
    this.jobTimer = setInterval(() => {
      this.createNewJob();
      this.broadcastJobToAll();
    }, JOB_REFRESH_INTERVAL);
  }

  getStats() {
    const miners = Array.from(this.clients.values()).map(c => ({
      id: c.id,
      worker: c.workerName,
      address: c.minerAddress,
      authorized: c.authorized,
      sharesAccepted: c.sharesAccepted,
      sharesRejected: c.sharesRejected,
      connectedAt: c.connectedAt,
      lastShare: c.lastShareTime,
    }));

    return {
      port: this.port,
      connectedMiners: this.clients.size,
      authorizedMiners: miners.filter(m => m.authorized).length,
      totalShares: this.poolStats.totalShares,
      totalBlocks: this.poolStats.totalBlocks,
      lastBlockTime: this.poolStats.lastBlockTime,
      uptime: Date.now() - this.poolStats.startTime,
      currentJob: this.currentJob ? {
        id: this.currentJob.id,
        height: this.currentJob.blockHeight,
        difficulty: this.currentJob.difficulty,
        pendingTxs: this.currentJob.transactions.length,
        reward: this.currentJob.reward,
      } : null,
      miners,
    };
  }
}

let stratumInstance: StratumServer | null = null;

export function getStratumServer(): StratumServer | null {
  return stratumInstance;
}

export function initStratumServer(port?: number): StratumServer {
  if (!stratumInstance) {
    stratumInstance = new StratumServer(port || STRATUM_PORT);
    stratumInstance.start();
  }
  return stratumInstance;
}
