import { getBlockchain, type AlphaBlockchain } from './chain.js';
import type { Block } from './block.js';
import {
  DIFFICULTY_ADJUSTMENT_INTERVAL, BLOCK_TIME_TARGET_MS,
  COIN_NAME,
} from './consensus.js';

interface NonceHotspot {
  rangeStart: number;
  rangeEnd: number;
  frequency: number;
  probability: number;
  lastSeenBlock: number;
}

interface DifficultyPrediction {
  currentDifficulty: number;
  predictedNextDifficulty: number;
  adjustmentFactor: number;
  blocksUntilAdjustment: number;
  epochProgress: number;
  trend: 'increasing' | 'decreasing' | 'stable';
  confidence: number;
  estimatedTimeToAdjustment: number;
}

interface MiningWindow {
  optimal: boolean;
  score: number;
  avgBlockInterval: number;
  recentBlockInterval: number;
  intervalDeviation: number;
  networkHashTrend: 'rising' | 'falling' | 'stable';
  recommendation: string;
  windowStart: number;
  windowDuration: number;
}

interface EntropyAnalysis {
  currentEntropy: number;
  avgEntropy: number;
  entropyTrend: 'increasing' | 'decreasing' | 'stable';
  bitDistribution: number[];
  hexDigitFrequency: number[];
  leadingZeroTrend: number[];
  shannonScore: number;
  patternStrength: number;
}

interface TemplateOptimization {
  avgTxPerBlock: number;
  avgBlockSize: number;
  optimalTxCount: number;
  merkleDepthDistribution: number[];
  recommendedVersion: number;
  timestampStrategy: string;
}

interface SpiderIntelligence {
  status: 'idle' | 'crawling' | 'analyzing' | 'ready';
  blocksAnalyzed: number;
  totalBlocks: number;
  crawlProgress: number;
  lastCrawlTime: number;
  crawlDuration: number;
  nonceHotspots: NonceHotspot[];
  difficultyPrediction: DifficultyPrediction;
  miningWindow: MiningWindow;
  entropyAnalysis: EntropyAnalysis;
  templateOptimization: TemplateOptimization;
  intelligenceFeed: IntelligenceEntry[];
  nonceBuckets: number[];
  preferredNonceRanges: { start: number; end: number; weight: number }[];
}

interface IntelligenceEntry {
  id: string;
  timestamp: number;
  type: 'pattern' | 'prediction' | 'anomaly' | 'optimization' | 'discovery';
  severity: 'info' | 'notable' | 'significant' | 'critical';
  title: string;
  description: string;
}

const NONCE_BUCKETS = 64;
const NONCE_MAX = 4294967295;
const BUCKET_SIZE = Math.floor(NONCE_MAX / NONCE_BUCKETS);
const CRAWL_INTERVAL = 15000;

let spiderInstance: BlockchainSpider | null = null;

export class BlockchainSpider {
  private blockchain: AlphaBlockchain;
  private intelligence: SpiderIntelligence;
  private crawlTimer: NodeJS.Timeout | null = null;
  private lastAnalyzedHeight: number = -1;

  constructor(blockchain: AlphaBlockchain) {
    this.blockchain = blockchain;
    this.intelligence = this.createEmptyIntelligence();
  }

  private createEmptyIntelligence(): SpiderIntelligence {
    return {
      status: 'idle',
      blocksAnalyzed: 0,
      totalBlocks: 0,
      crawlProgress: 0,
      lastCrawlTime: 0,
      crawlDuration: 0,
      nonceHotspots: [],
      difficultyPrediction: {
        currentDifficulty: 0,
        predictedNextDifficulty: 0,
        adjustmentFactor: 1,
        blocksUntilAdjustment: 0,
        epochProgress: 0,
        trend: 'stable',
        confidence: 0,
        estimatedTimeToAdjustment: 0,
      },
      miningWindow: {
        optimal: false,
        score: 50,
        avgBlockInterval: 0,
        recentBlockInterval: 0,
        intervalDeviation: 0,
        networkHashTrend: 'stable',
        recommendation: 'Analyzing blockchain...',
        windowStart: Date.now(),
        windowDuration: 0,
      },
      entropyAnalysis: {
        currentEntropy: 0,
        avgEntropy: 0,
        entropyTrend: 'stable',
        bitDistribution: new Array(256).fill(0),
        hexDigitFrequency: new Array(16).fill(0),
        leadingZeroTrend: [],
        shannonScore: 0,
        patternStrength: 0,
      },
      templateOptimization: {
        avgTxPerBlock: 0,
        avgBlockSize: 0,
        optimalTxCount: 1,
        merkleDepthDistribution: [],
        recommendedVersion: 1,
        timestampStrategy: 'network_adjusted',
      },
      intelligenceFeed: [],
      nonceBuckets: new Array(NONCE_BUCKETS).fill(0),
      preferredNonceRanges: [],
    };
  }

  start(): void {
    console.log(`[BlockchainSpider] Autonomous Blockchain Spider™ initialized`);
    this.performCrawl();
    this.crawlTimer = setInterval(() => this.performCrawl(), CRAWL_INTERVAL);
  }

  stop(): void {
    if (this.crawlTimer) {
      clearInterval(this.crawlTimer);
      this.crawlTimer = null;
    }
  }

  private performCrawl(): void {
    const startTime = Date.now();
    const chain = this.blockchain.chain;
    const chainHeight = chain.length;

    if (chainHeight <= 1 || chainHeight === this.lastAnalyzedHeight) {
      return;
    }

    this.intelligence.status = 'crawling';
    this.intelligence.totalBlocks = chainHeight;

    this.intelligence.status = 'analyzing';

    this.analyzeNonceDistribution(chain);
    this.predictDifficulty(chain);
    this.analyzeMiningWindows(chain);
    this.analyzeEntropy(chain);
    this.analyzeTemplates(chain);
    this.generateIntelligenceFeed(chain);
    this.computePreferredNonceRanges();

    this.intelligence.status = 'ready';
    this.intelligence.blocksAnalyzed = chainHeight;
    this.intelligence.crawlProgress = 100;
    this.intelligence.lastCrawlTime = Date.now();
    this.intelligence.crawlDuration = Date.now() - startTime;
    this.lastAnalyzedHeight = chainHeight;
  }

  private analyzeNonceDistribution(chain: Block[]): void {
    const buckets = new Array(NONCE_BUCKETS).fill(0);
    const totalBlocks = chain.length;

    for (const block of chain) {
      const nonce = block.header.nonce;
      if (nonce >= 0 && nonce <= NONCE_MAX) {
        const bucket = Math.min(Math.floor(nonce / BUCKET_SIZE), NONCE_BUCKETS - 1);
        buckets[bucket]++;
      }
    }

    this.intelligence.nonceBuckets = buckets;

    const avgPerBucket = totalBlocks / NONCE_BUCKETS;
    const hotspots: NonceHotspot[] = [];

    for (let i = 0; i < NONCE_BUCKETS; i++) {
      if (buckets[i] > 0) {
        const freq = buckets[i];
        const probability = freq / totalBlocks;

        hotspots.push({
          rangeStart: i * BUCKET_SIZE,
          rangeEnd: (i + 1) * BUCKET_SIZE - 1,
          frequency: freq,
          probability,
          lastSeenBlock: this.findLastBlockInBucket(chain, i),
        });
      }
    }

    hotspots.sort((a, b) => b.frequency - a.frequency);
    this.intelligence.nonceHotspots = hotspots.slice(0, 20);
  }

  private findLastBlockInBucket(chain: Block[], bucket: number): number {
    for (let i = chain.length - 1; i >= 0; i--) {
      const nonce = chain[i].header.nonce;
      const b = Math.min(Math.floor(nonce / BUCKET_SIZE), NONCE_BUCKETS - 1);
      if (b === bucket) return chain[i].index;
    }
    return 0;
  }

  private predictDifficulty(chain: Block[]): void {
    if (chain.length < 2) return;

    const latestBlock = chain[chain.length - 1];
    const currentDifficulty = latestBlock.header.difficulty;
    const height = chain.length - 1;

    const blocksIntoEpoch = height % DIFFICULTY_ADJUSTMENT_INTERVAL;
    const blocksUntilAdjustment = DIFFICULTY_ADJUSTMENT_INTERVAL - blocksIntoEpoch;
    const epochProgress = (blocksIntoEpoch / DIFFICULTY_ADJUSTMENT_INTERVAL) * 100;

    let predictedDifficulty = currentDifficulty;
    let adjustmentFactor = 1;
    let confidence = 30;

    if (chain.length >= 3) {
      const recentCount = Math.min(chain.length - 1, blocksIntoEpoch || DIFFICULTY_ADJUSTMENT_INTERVAL);
      const recentBlocks = chain.slice(-recentCount - 1);

      if (recentBlocks.length >= 2) {
        const timeSpan = recentBlocks[recentBlocks.length - 1].header.timestamp - recentBlocks[0].header.timestamp;
        const expectedTime = BLOCK_TIME_TARGET_MS * recentBlocks.length;

        if (timeSpan > 0) {
          const projectedFactor = expectedTime / timeSpan;
          adjustmentFactor = Math.max(0.25, Math.min(4, projectedFactor));
          predictedDifficulty = currentDifficulty * adjustmentFactor;

          confidence = Math.min(95, 30 + epochProgress * 0.65);
        }
      }
    }

    let trend: 'increasing' | 'decreasing' | 'stable' = 'stable';
    if (adjustmentFactor > 1.05) trend = 'increasing';
    else if (adjustmentFactor < 0.95) trend = 'decreasing';

    const avgBlockTime = chain.length > 1
      ? (chain[chain.length - 1].header.timestamp - chain[0].header.timestamp) / (chain.length - 1)
      : BLOCK_TIME_TARGET_MS;

    this.intelligence.difficultyPrediction = {
      currentDifficulty,
      predictedNextDifficulty: parseFloat(predictedDifficulty.toFixed(4)),
      adjustmentFactor: parseFloat(adjustmentFactor.toFixed(4)),
      blocksUntilAdjustment,
      epochProgress: parseFloat((epochProgress / 100).toFixed(4)),
      trend,
      confidence: parseFloat(confidence.toFixed(1)),
      estimatedTimeToAdjustment: blocksUntilAdjustment * avgBlockTime,
    };
  }

  private analyzeMiningWindows(chain: Block[]): void {
    if (chain.length < 3) {
      this.intelligence.miningWindow = {
        optimal: true,
        score: 75,
        avgBlockInterval: 0,
        recentBlockInterval: 0,
        intervalDeviation: 0,
        networkHashTrend: 'stable',
        recommendation: 'Insufficient chain history — mining recommended at default intensity',
        windowStart: Date.now(),
        windowDuration: BLOCK_TIME_TARGET_MS * 10,
      };
      return;
    }

    const intervals: number[] = [];
    for (let i = 1; i < chain.length; i++) {
      intervals.push(chain[i].header.timestamp - chain[i - 1].header.timestamp);
    }

    const avgInterval = intervals.reduce((s, v) => s + v, 0) / intervals.length;
    const recentIntervals = intervals.slice(-10);
    const recentAvg = recentIntervals.reduce((s, v) => s + v, 0) / recentIntervals.length;

    const variance = intervals.reduce((s, v) => s + Math.pow(v - avgInterval, 2), 0) / intervals.length;
    const stdDev = Math.sqrt(variance);
    const deviation = (stdDev / avgInterval) * 100;

    let hashTrend: 'rising' | 'falling' | 'stable' = 'stable';
    if (recentAvg < avgInterval * 0.85) hashTrend = 'rising';
    else if (recentAvg > avgInterval * 1.15) hashTrend = 'falling';

    let score = 50;
    if (hashTrend === 'falling') score += 25;
    if (recentAvg > BLOCK_TIME_TARGET_MS) score += 15;
    if (deviation > 30) score += 10;

    const optimal = score >= 70;
    let recommendation = '';
    if (optimal) {
      recommendation = 'Mining window is favorable — network hash rate appears to be dipping. Increase mining intensity for higher probability of block discovery.';
    } else if (hashTrend === 'rising') {
      recommendation = 'Network hash rate is rising — competition increasing. Maintain current intensity and wait for more favorable conditions.';
    } else {
      recommendation = 'Neutral mining conditions. Spider continues monitoring for optimal windows.';
    }

    this.intelligence.miningWindow = {
      optimal,
      score: Math.min(100, score),
      avgBlockInterval: Math.round(avgInterval),
      recentBlockInterval: Math.round(recentAvg),
      intervalDeviation: parseFloat(deviation.toFixed(1)),
      networkHashTrend: hashTrend,
      recommendation,
      windowStart: Date.now(),
      windowDuration: BLOCK_TIME_TARGET_MS * 6,
    };
  }

  private analyzeEntropy(chain: Block[]): void {
    if (chain.length < 2) return;

    const hexCounts = new Array(16).fill(0);
    const leadingZeros: number[] = [];
    const perBlockOnesRatio: number[] = [];

    for (const block of chain) {
      const hash = block.hash;

      let lz = 0;
      for (const c of hash) {
        if (c === '0') lz++;
        else break;
      }
      leadingZeros.push(lz);

      let ones = 0;
      let totalBitsInBlock = 0;
      for (const char of hash) {
        const val = parseInt(char, 16);
        if (!isNaN(val)) {
          hexCounts[val]++;
          for (let bit = 3; bit >= 0; bit--) {
            if ((val >> bit) & 1) ones++;
            totalBitsInBlock++;
          }
        }
      }
      perBlockOnesRatio.push(totalBitsInBlock > 0 ? ones / totalBitsInBlock : 0.5);
    }

    const totalHexChars = chain.length * 64;
    const hexProbs = hexCounts.map(c => c / totalHexChars);
    let shannonEntropy = 0;
    for (const p of hexProbs) {
      if (p > 0) shannonEntropy -= p * Math.log2(p);
    }

    const maxEntropy = Math.log2(16);
    const shannonScore = (shannonEntropy / maxEntropy) * 100;

    const recentEntropy = this.computeRecentEntropy(chain.slice(-10));
    let trend: 'increasing' | 'decreasing' | 'stable' = 'stable';
    if (recentEntropy > shannonScore * 1.02) trend = 'increasing';
    else if (recentEntropy < shannonScore * 0.98) trend = 'decreasing';

    const expectedFreq = totalHexChars / 16;
    const chiSquare = hexCounts.reduce((s, c) => s + Math.pow(c - expectedFreq, 2) / expectedFreq, 0);
    const patternStrength = Math.max(0, Math.min(100, (chiSquare / 16) * 10));

    this.intelligence.entropyAnalysis = {
      currentEntropy: parseFloat(recentEntropy.toFixed(2)),
      avgEntropy: parseFloat(shannonScore.toFixed(2)),
      entropyTrend: trend,
      bitDistribution: perBlockOnesRatio.slice(-64).map(r => parseFloat(r.toFixed(4))),
      hexDigitFrequency: hexCounts,
      leadingZeroTrend: leadingZeros.slice(-50),
      shannonScore: parseFloat(shannonScore.toFixed(2)),
      patternStrength: parseFloat(patternStrength.toFixed(2)),
    };
  }

  private computeRecentEntropy(blocks: Block[]): number {
    if (blocks.length === 0) return 0;
    const hexCounts = new Array(16).fill(0);
    let total = 0;
    for (const block of blocks) {
      for (const c of block.hash) {
        const v = parseInt(c, 16);
        if (!isNaN(v)) { hexCounts[v]++; total++; }
      }
    }
    if (total === 0) return 0;
    const probs = hexCounts.map(c => c / total);
    let entropy = 0;
    for (const p of probs) {
      if (p > 0) entropy -= p * Math.log2(p);
    }
    return (entropy / Math.log2(16)) * 100;
  }

  private analyzeTemplates(chain: Block[]): void {
    if (chain.length < 2) return;

    let totalTx = 0;
    let totalSize = 0;
    const merkleDepths: number[] = [];

    for (const block of chain) {
      const txCount = block.transactions.length;
      totalTx += txCount;
      totalSize += block.size;
      const depth = txCount > 0 ? Math.ceil(Math.log2(txCount + 1)) : 0;
      merkleDepths.push(depth);
    }

    const avgTx = totalTx / chain.length;
    const avgSize = totalSize / chain.length;
    const depthDist = new Array(8).fill(0);
    for (const d of merkleDepths) {
      if (d < 8) depthDist[d]++;
    }

    this.intelligence.templateOptimization = {
      avgTxPerBlock: parseFloat(avgTx.toFixed(1)),
      avgBlockSize: Math.round(avgSize),
      optimalTxCount: Math.max(1, Math.round(avgTx * 0.8)),
      merkleDepthDistribution: depthDist,
      recommendedVersion: 1,
      timestampStrategy: avgTx > 10 ? 'fee_weighted' : 'network_adjusted',
    };
  }

  private generateIntelligenceFeed(chain: Block[]): void {
    const feed: IntelligenceEntry[] = [];
    const now = Date.now();

    const topBucket = this.intelligence.nonceHotspots[0];
    if (topBucket) {
      feed.push({
        id: `nonce_hotspot_${now}`,
        timestamp: now,
        type: 'pattern',
        severity: 'notable',
        title: 'Nonce Hotspot Identified',
        description: `Nonce range ${topBucket.rangeStart.toLocaleString()}-${topBucket.rangeEnd.toLocaleString()} has ${(topBucket.probability * 100).toFixed(1)}% of winning nonces (${topBucket.frequency} blocks). Search this range first for statistical advantage.`,
      });
    }

    const dp = this.intelligence.difficultyPrediction;
    if (dp.confidence > 50) {
      const changePercent = ((dp.predictedNextDifficulty - dp.currentDifficulty) / dp.currentDifficulty * 100).toFixed(1);
      feed.push({
        id: `difficulty_pred_${now}`,
        timestamp: now,
        type: 'prediction',
        severity: dp.trend !== 'stable' ? 'significant' : 'info',
        title: `Difficulty ${dp.trend === 'increasing' ? 'Increase' : dp.trend === 'decreasing' ? 'Decrease' : 'Stable'} Predicted`,
        description: `Next difficulty adjustment estimated at ${dp.predictedNextDifficulty.toFixed(4)} (${changePercent}% change). ${dp.blocksUntilAdjustment} blocks remaining in epoch (${(dp.epochProgress * 100).toFixed(0)}% complete). Confidence: ${dp.confidence.toFixed(0)}%.`,
      });
    }

    const mw = this.intelligence.miningWindow;
    feed.push({
      id: `mining_window_${now}`,
      timestamp: now,
      type: 'optimization',
      severity: mw.optimal ? 'significant' : 'info',
      title: mw.optimal ? 'Favorable Mining Window Detected' : 'Mining Window Analysis',
      description: mw.recommendation,
    });

    const ea = this.intelligence.entropyAnalysis;
    if (ea.patternStrength > 20) {
      feed.push({
        id: `entropy_pattern_${now}`,
        timestamp: now,
        type: 'discovery',
        severity: ea.patternStrength > 50 ? 'significant' : 'notable',
        title: 'Entropy Pattern Deviation',
        description: `Hash entropy analysis shows ${ea.patternStrength.toFixed(1)}% pattern deviation from uniform distribution. ${ea.entropyTrend === 'decreasing' ? 'Decreasing entropy may indicate exploitable bias.' : 'Monitoring for actionable patterns.'}`,
      });
    }

    if (chain.length > 5) {
      const recentNonces = chain.slice(-5).map(b => b.header.nonce);
      const avgNonce = recentNonces.reduce((s, n) => s + n, 0) / recentNonces.length;
      const recentBucket = Math.min(Math.floor(avgNonce / BUCKET_SIZE), NONCE_BUCKETS - 1);
      feed.push({
        id: `recent_nonce_${now}`,
        timestamp: now,
        type: 'pattern',
        severity: 'info',
        title: 'Recent Nonce Cluster',
        description: `Last ${recentNonces.length} blocks clustered in nonce bucket #${recentBucket} (range ${(recentBucket * BUCKET_SIZE).toLocaleString()}-${((recentBucket + 1) * BUCKET_SIZE - 1).toLocaleString()}). Average recent nonce: ${Math.round(avgNonce).toLocaleString()}.`,
      });
    }

    this.intelligence.intelligenceFeed = feed;
  }

  private computePreferredNonceRanges(): void {
    const hotspots = this.intelligence.nonceHotspots;
    if (hotspots.length === 0) return;

    const totalFreq = hotspots.reduce((s, h) => s + h.frequency, 0);
    const ranges = hotspots.slice(0, 8).map(h => ({
      start: h.rangeStart,
      end: h.rangeEnd,
      weight: parseFloat((h.frequency / totalFreq).toFixed(4)),
    }));

    this.intelligence.preferredNonceRanges = ranges;
  }

  getIntelligence(): SpiderIntelligence {
    return { ...this.intelligence };
  }

  getNonceHotspots(): NonceHotspot[] {
    return [...this.intelligence.nonceHotspots];
  }

  getDifficultyPrediction(): DifficultyPrediction {
    return { ...this.intelligence.difficultyPrediction };
  }

  getOptimalMiningWindow(): MiningWindow {
    return { ...this.intelligence.miningWindow };
  }

  getEntropyAnalysis(): EntropyAnalysis {
    return { ...this.intelligence.entropyAnalysis };
  }

  getTemplateOptimization(): TemplateOptimization {
    return { ...this.intelligence.templateOptimization };
  }

  getPreferredNonceRanges(): { start: number; end: number; weight: number }[] {
    return [...this.intelligence.preferredNonceRanges];
  }

  getStatus(): {
    status: string;
    blocksAnalyzed: number;
    totalBlocks: number;
    crawlProgress: number;
    lastCrawlTime: number;
    crawlDuration: number;
    intelligenceEntries: number;
    nonceHotspotsFound: number;
    preferredRanges: number;
  } {
    return {
      status: this.intelligence.status,
      blocksAnalyzed: this.intelligence.blocksAnalyzed,
      totalBlocks: this.intelligence.totalBlocks,
      crawlProgress: this.intelligence.crawlProgress,
      lastCrawlTime: this.intelligence.lastCrawlTime,
      crawlDuration: this.intelligence.crawlDuration,
      intelligenceEntries: this.intelligence.intelligenceFeed.length,
      nonceHotspotsFound: this.intelligence.nonceHotspots.length,
      preferredRanges: this.intelligence.preferredNonceRanges.length,
    };
  }
}

export function initializeSpider(blockchain?: AlphaBlockchain): BlockchainSpider {
  const chain = blockchain || getBlockchain();
  const spider = new BlockchainSpider(chain);
  spiderInstance = spider;
  spider.start();
  return spider;
}

export function getSpider(): BlockchainSpider | null {
  return spiderInstance;
}

export function getSpiderIntelligence(): SpiderIntelligence | null {
  return spiderInstance?.getIntelligence() || null;
}

export function getNonceHotspots(): NonceHotspot[] {
  return spiderInstance?.getNonceHotspots() || [];
}

export function getDifficultyPrediction(): DifficultyPrediction | null {
  return spiderInstance?.getDifficultyPrediction() || null;
}

export function getOptimalMiningWindow(): MiningWindow | null {
  return spiderInstance?.getOptimalMiningWindow() || null;
}

export function getEntropyAnalysis(): EntropyAnalysis | null {
  return spiderInstance?.getEntropyAnalysis() || null;
}

export function getTemplateOptimization(): TemplateOptimization | null {
  return spiderInstance?.getTemplateOptimization() || null;
}

export function getPreferredNonceRanges(): { start: number; end: number; weight: number }[] {
  return spiderInstance?.getPreferredNonceRanges() || [];
}
