import crypto from 'crypto';
import { getBlockchain } from './chain.js';
import { COIN_TICKER } from './consensus.js';
import { createSafeSendTransaction } from './safeSend.js';

export type AssetType = 'REAL_ESTATE' | 'COMMODITY' | 'SECURITY' | 'ART' | 'IP' | 'VEHICLE' | 'PRECIOUS_METAL' | 'COLLECTIBLE';

export type VerificationStatus = 'unverified' | 'pending_review' | 'verified' | 'rejected';

export type ValuationMethod = 'appraisal' | 'market' | 'formula';

export type PayoutSchedule = 'monthly' | 'quarterly' | 'annually';

export type AssetStatus = 'active' | 'frozen' | 'delisted';

export interface AssetDocument {
  hash: string;
  name: string;
  uploadedAt: number;
  uploadedBy: string;
}

export interface AssetValuation {
  value: number;
  currency: string;
  method: ValuationMethod;
  valuedAt: number;
  valuedBy: string;
}

export interface ComplianceConfig {
  requiresKYC: boolean;
  requiresAccreditation: boolean;
  holdingPeriodDays: number;
  geographicRestrictions: string[];
  whitelistOnly: boolean;
  whitelistedAddresses: string[];
}

export interface SecondaryMarketRules {
  minTradeShares: number;
  maxTradeShares: number;
  rightOfFirstRefusal: boolean;
  lockUpPeriodDays: number;
}

export interface YieldConfig {
  enabled: boolean;
  annualRatePercent: number;
  payoutSchedule: PayoutSchedule;
  lastPayoutAt: number;
  totalDistributed: number;
}

export interface ShareHolder {
  address: string;
  shares: number;
  acquiredAt: number;
  lockedUntil: number;
}

export interface TokenizedAsset {
  assetId: string;
  name: string;
  description: string;
  assetType: AssetType;
  creatorAddress: string;
  createdAt: number;
  status: AssetStatus;

  totalShares: number;
  holders: Map<string, ShareHolder>;

  documents: AssetDocument[];
  verificationStatus: VerificationStatus;
  auditorAddress?: string;
  verifiedAt?: number;

  compliance: ComplianceConfig;
  secondaryMarketRules: SecondaryMarketRules;
  yieldConfig: YieldConfig;

  valuationHistory: AssetValuation[];
  currentValuation?: AssetValuation;
}

export interface AssetTransferRecord {
  transferId: string;
  assetId: string;
  fromAddress: string;
  toAddress: string;
  shares: number;
  safeSendTxId: string;
  timestamp: number;
}

const tokenizedAssets = new Map<string, TokenizedAsset>();
const transferRecords: AssetTransferRecord[] = [];

function generateAssetId(): string {
  return 'SA_' + crypto.randomBytes(16).toString('hex').toUpperCase();
}

function generateTransferId(): string {
  return 'SAT_' + crypto.randomBytes(12).toString('hex').toUpperCase();
}

function getDefaultCompliance(assetType: AssetType): ComplianceConfig {
  const base: ComplianceConfig = {
    requiresKYC: false,
    requiresAccreditation: false,
    holdingPeriodDays: 0,
    geographicRestrictions: [],
    whitelistOnly: false,
    whitelistedAddresses: [],
  };

  switch (assetType) {
    case 'SECURITY':
      base.requiresKYC = true;
      base.requiresAccreditation = true;
      base.holdingPeriodDays = 365;
      break;
    case 'REAL_ESTATE':
      base.requiresKYC = true;
      base.holdingPeriodDays = 90;
      break;
    case 'PRECIOUS_METAL':
    case 'COMMODITY':
      base.requiresKYC = true;
      break;
    default:
      break;
  }

  return base;
}

function getDefaultSecondaryMarketRules(totalShares: number): SecondaryMarketRules {
  return {
    minTradeShares: 1,
    maxTradeShares: Math.floor(totalShares * 0.1),
    rightOfFirstRefusal: false,
    lockUpPeriodDays: 0,
  };
}

export function createTokenizedAsset(params: {
  name: string;
  description: string;
  assetType: AssetType;
  creatorAddress: string;
  totalShares: number;
  initialValuation?: number;
  valuationMethod?: ValuationMethod;
  compliance?: Partial<ComplianceConfig>;
  secondaryMarketRules?: Partial<SecondaryMarketRules>;
  yieldConfig?: Partial<YieldConfig>;
  documents?: { hash: string; name: string }[];
}): TokenizedAsset | { error: string } {
  if (!params.name || params.name.trim().length === 0) {
    return { error: 'Asset name is required' };
  }
  if (!params.creatorAddress || !params.creatorAddress.startsWith('ALPHA_')) {
    return { error: 'Valid ALPHA_ creator address is required' };
  }
  if (!params.totalShares || params.totalShares < 1 || params.totalShares > 1000000000) {
    return { error: 'Total shares must be between 1 and 1,000,000,000' };
  }

  const validAssetTypes: AssetType[] = ['REAL_ESTATE', 'COMMODITY', 'SECURITY', 'ART', 'IP', 'VEHICLE', 'PRECIOUS_METAL', 'COLLECTIBLE'];
  if (!validAssetTypes.includes(params.assetType)) {
    return { error: `Invalid asset type. Must be one of: ${validAssetTypes.join(', ')}` };
  }

  const now = Date.now();
  const assetId = generateAssetId();

  const defaultCompliance = getDefaultCompliance(params.assetType);
  const compliance: ComplianceConfig = {
    ...defaultCompliance,
    ...(params.compliance || {}),
  };

  const defaultMarketRules = getDefaultSecondaryMarketRules(params.totalShares);
  const secondaryMarketRules: SecondaryMarketRules = {
    ...defaultMarketRules,
    ...(params.secondaryMarketRules || {}),
  };

  const yieldConfig: YieldConfig = {
    enabled: false,
    annualRatePercent: 0,
    payoutSchedule: 'quarterly',
    lastPayoutAt: now,
    totalDistributed: 0,
    ...(params.yieldConfig || {}),
  };

  const documents: AssetDocument[] = (params.documents || []).map(d => ({
    hash: d.hash,
    name: d.name,
    uploadedAt: now,
    uploadedBy: params.creatorAddress,
  }));

  const holders = new Map<string, ShareHolder>();
  holders.set(params.creatorAddress, {
    address: params.creatorAddress,
    shares: params.totalShares,
    acquiredAt: now,
    lockedUntil: 0,
  });

  const valuationHistory: AssetValuation[] = [];
  let currentValuation: AssetValuation | undefined;

  if (params.initialValuation && params.initialValuation > 0) {
    const valuation: AssetValuation = {
      value: params.initialValuation,
      currency: COIN_TICKER,
      method: params.valuationMethod || 'appraisal',
      valuedAt: now,
      valuedBy: params.creatorAddress,
    };
    valuationHistory.push(valuation);
    currentValuation = valuation;
  }

  const asset: TokenizedAsset = {
    assetId,
    name: params.name.trim(),
    description: (params.description || '').trim(),
    assetType: params.assetType,
    creatorAddress: params.creatorAddress,
    createdAt: now,
    status: 'active',
    totalShares: params.totalShares,
    holders,
    documents,
    verificationStatus: 'unverified',
    compliance,
    secondaryMarketRules,
    yieldConfig,
    valuationHistory,
    currentValuation,
  };

  tokenizedAssets.set(assetId, asset);

  console.log(`[SafeAsset] Asset tokenized: ${asset.name} (${assetId}) | Type: ${asset.assetType} | Shares: ${asset.totalShares} | Creator: ${params.creatorAddress.substring(0, 20)}...`);

  return asset;
}

export function getAsset(assetId: string): TokenizedAsset | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }
  return asset;
}

export function getAllAssets(filters?: { assetType?: AssetType; status?: AssetStatus }): TokenizedAsset[] {
  let assets = Array.from(tokenizedAssets.values());

  if (filters?.assetType) {
    assets = assets.filter(a => a.assetType === filters.assetType);
  }
  if (filters?.status) {
    assets = assets.filter(a => a.status === filters.status);
  }

  return assets.sort((a, b) => b.createdAt - a.createdAt);
}

export function transferShares(params: {
  assetId: string;
  fromAddress: string;
  toAddress: string;
  shares: number;
  timeLockSeconds?: number;
}): AssetTransferRecord | { error: string } {
  const asset = tokenizedAssets.get(params.assetId);
  if (!asset) {
    return { error: `Asset ${params.assetId} not found` };
  }

  if (asset.status !== 'active') {
    return { error: `Asset is ${asset.status}. Transfers are not allowed.` };
  }

  if (!params.fromAddress || !params.fromAddress.startsWith('ALPHA_')) {
    return { error: 'Valid ALPHA_ sender address is required' };
  }
  if (!params.toAddress || !params.toAddress.startsWith('ALPHA_')) {
    return { error: 'Valid ALPHA_ recipient address is required' };
  }
  if (params.fromAddress === params.toAddress) {
    return { error: 'Cannot transfer shares to the same address' };
  }
  if (params.shares <= 0 || !Number.isInteger(params.shares)) {
    return { error: 'Shares must be a positive integer' };
  }

  const senderHolder = asset.holders.get(params.fromAddress);
  if (!senderHolder) {
    return { error: 'Sender does not hold any shares of this asset' };
  }
  if (senderHolder.shares < params.shares) {
    return { error: `Insufficient shares. Have ${senderHolder.shares}, need ${params.shares}` };
  }

  const now = Date.now();

  if (senderHolder.lockedUntil > now) {
    const daysLeft = Math.ceil((senderHolder.lockedUntil - now) / (24 * 60 * 60 * 1000));
    return { error: `Shares are locked for ${daysLeft} more days` };
  }

  if (asset.secondaryMarketRules.lockUpPeriodDays > 0) {
    const lockUpEnd = senderHolder.acquiredAt + (asset.secondaryMarketRules.lockUpPeriodDays * 24 * 60 * 60 * 1000);
    if (now < lockUpEnd) {
      const daysLeft = Math.ceil((lockUpEnd - now) / (24 * 60 * 60 * 1000));
      return { error: `Lock-up period active. ${daysLeft} days remaining.` };
    }
  }

  if (params.shares < asset.secondaryMarketRules.minTradeShares) {
    return { error: `Minimum trade size is ${asset.secondaryMarketRules.minTradeShares} shares` };
  }
  if (params.shares > asset.secondaryMarketRules.maxTradeShares) {
    return { error: `Maximum trade size is ${asset.secondaryMarketRules.maxTradeShares} shares` };
  }

  if (asset.compliance.whitelistOnly) {
    if (!asset.compliance.whitelistedAddresses.includes(params.toAddress)) {
      return { error: 'Recipient address is not whitelisted for this asset' };
    }
  }

  let safeSendTxId = 'DIRECT_TRANSFER';

  if (asset.currentValuation) {
    const sharePrice = asset.currentValuation.value / asset.totalShares;
    const transferValue = sharePrice * params.shares;

    if (transferValue > 0) {
      const safeSendResult = createSafeSendTransaction(
        params.fromAddress,
        params.toAddress,
        transferValue,
        params.timeLockSeconds
      );

      if ('error' in safeSendResult) {
        safeSendTxId = 'SAFESEND_UNAVAILABLE';
      } else {
        safeSendTxId = safeSendResult.id;
      }
    }
  }

  senderHolder.shares -= params.shares;
  if (senderHolder.shares === 0) {
    asset.holders.delete(params.fromAddress);
  }

  const existingRecipient = asset.holders.get(params.toAddress);
  if (existingRecipient) {
    existingRecipient.shares += params.shares;
  } else {
    const holdingPeriodMs = asset.compliance.holdingPeriodDays * 24 * 60 * 60 * 1000;
    asset.holders.set(params.toAddress, {
      address: params.toAddress,
      shares: params.shares,
      acquiredAt: now,
      lockedUntil: holdingPeriodMs > 0 ? now + holdingPeriodMs : 0,
    });
  }

  const transferId = generateTransferId();
  const record: AssetTransferRecord = {
    transferId,
    assetId: params.assetId,
    fromAddress: params.fromAddress,
    toAddress: params.toAddress,
    shares: params.shares,
    safeSendTxId,
    timestamp: now,
  };

  transferRecords.push(record);

  console.log(`[SafeAsset] Transfer: ${params.shares} shares of ${asset.name} (${params.assetId}) from ${params.fromAddress.substring(0, 20)}... to ${params.toAddress.substring(0, 20)}...`);

  return record;
}

export function getAssetHolders(assetId: string): { address: string; shares: number; percentage: number; acquiredAt: number; lockedUntil: number }[] | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  return Array.from(asset.holders.values()).map(h => ({
    address: h.address,
    shares: h.shares,
    percentage: parseFloat(((h.shares / asset.totalShares) * 100).toFixed(4)),
    acquiredAt: h.acquiredAt,
    lockedUntil: h.lockedUntil,
  })).sort((a, b) => b.shares - a.shares);
}

export function distributeYield(assetId: string, distributorAddress: string): {
  assetId: string;
  totalDistributed: number;
  distributions: { address: string; shares: number; amount: number }[];
} | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (asset.status !== 'active') {
    return { error: `Asset is ${asset.status}. Yield distribution not allowed.` };
  }

  if (!asset.yieldConfig.enabled) {
    return { error: 'Yield distribution is not enabled for this asset' };
  }

  if (distributorAddress !== asset.creatorAddress) {
    return { error: 'Only the asset creator can distribute yield' };
  }

  if (!asset.currentValuation) {
    return { error: 'Asset must have a valuation before yield can be distributed' };
  }

  const now = Date.now();
  const scheduleMs = getPayoutIntervalMs(asset.yieldConfig.payoutSchedule);
  const timeSinceLastPayout = now - asset.yieldConfig.lastPayoutAt;

  if (timeSinceLastPayout < scheduleMs * 0.9) {
    const nextPayoutDate = new Date(asset.yieldConfig.lastPayoutAt + scheduleMs);
    return { error: `Next payout is not due until ${nextPayoutDate.toISOString()}` };
  }

  const periodsPerYear = getPeriodsPerYear(asset.yieldConfig.payoutSchedule);
  const periodRate = asset.yieldConfig.annualRatePercent / 100 / periodsPerYear;
  const totalYieldPool = asset.currentValuation.value * periodRate;

  const blockchain = getBlockchain();
  const distributorBalance = blockchain.getBalance(distributorAddress);

  if (distributorBalance < totalYieldPool) {
    return { error: `Insufficient balance to distribute yield. Need ${totalYieldPool} ${COIN_TICKER}, have ${distributorBalance} ${COIN_TICKER}` };
  }

  const distributions: { address: string; shares: number; amount: number }[] = [];
  let totalDistributedAmount = 0;

  const holderEntries = Array.from(asset.holders.entries());
  for (const [address, holder] of holderEntries) {
    if (address === distributorAddress) continue;

    const sharePercentage = holder.shares / asset.totalShares;
    const payoutAmount = parseFloat((totalYieldPool * sharePercentage).toFixed(8));

    if (payoutAmount > 0) {
      const currentBalance = blockchain.getBalance(address);
      blockchain.balances.set(address, parseFloat((currentBalance + payoutAmount).toFixed(8)));
      totalDistributedAmount += payoutAmount;

      distributions.push({
        address,
        shares: holder.shares,
        amount: payoutAmount,
      });
    }
  }

  const currentDistributorBalance = blockchain.getBalance(distributorAddress);
  blockchain.balances.set(distributorAddress, parseFloat((currentDistributorBalance - totalDistributedAmount).toFixed(8)));

  asset.yieldConfig.lastPayoutAt = now;
  asset.yieldConfig.totalDistributed += totalDistributedAmount;

  console.log(`[SafeAsset] Yield distributed for ${asset.name} (${assetId}): ${totalDistributedAmount} ${COIN_TICKER} to ${distributions.length} holders`);

  return {
    assetId,
    totalDistributed: parseFloat(totalDistributedAmount.toFixed(8)),
    distributions,
  };
}

export function updateAssetValuation(
  assetId: string,
  value: number,
  method: ValuationMethod,
  valuedBy: string
): AssetValuation | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (value <= 0) {
    return { error: 'Valuation must be positive' };
  }

  const valuation: AssetValuation = {
    value,
    currency: COIN_TICKER,
    method,
    valuedAt: Date.now(),
    valuedBy,
  };

  asset.valuationHistory.push(valuation);
  asset.currentValuation = valuation;

  return valuation;
}

export function verifyAsset(
  assetId: string,
  auditorAddress: string,
  status: 'verified' | 'rejected'
): TokenizedAsset | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (!auditorAddress || !auditorAddress.startsWith('ALPHA_')) {
    return { error: 'Valid ALPHA_ auditor address is required' };
  }

  asset.verificationStatus = status;
  asset.auditorAddress = auditorAddress;
  asset.verifiedAt = Date.now();

  console.log(`[SafeAsset] Asset ${asset.name} (${assetId}) verification: ${status} by ${auditorAddress.substring(0, 20)}...`);

  return asset;
}

export function addDocument(
  assetId: string,
  uploaderAddress: string,
  documentHash: string,
  documentName: string
): AssetDocument | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (!documentHash || !documentName) {
    return { error: 'Document hash and name are required' };
  }

  const existing = asset.documents.find(d => d.hash === documentHash);
  if (existing) {
    return { error: 'Document with this hash already exists' };
  }

  const doc: AssetDocument = {
    hash: documentHash,
    name: documentName,
    uploadedAt: Date.now(),
    uploadedBy: uploaderAddress,
  };

  asset.documents.push(doc);
  return doc;
}

export function updateAssetStatus(
  assetId: string,
  status: AssetStatus,
  requesterAddress: string
): TokenizedAsset | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (requesterAddress !== asset.creatorAddress) {
    return { error: 'Only the asset creator can update the status' };
  }

  asset.status = status;
  console.log(`[SafeAsset] Asset ${asset.name} (${assetId}) status updated to: ${status}`);
  return asset;
}

export function updateComplianceConfig(
  assetId: string,
  requesterAddress: string,
  updates: Partial<ComplianceConfig>
): ComplianceConfig | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (requesterAddress !== asset.creatorAddress) {
    return { error: 'Only the asset creator can update compliance configuration' };
  }

  Object.assign(asset.compliance, updates);
  return asset.compliance;
}

export function updateSecondaryMarketRules(
  assetId: string,
  requesterAddress: string,
  updates: Partial<SecondaryMarketRules>
): SecondaryMarketRules | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }

  if (requesterAddress !== asset.creatorAddress) {
    return { error: 'Only the asset creator can update secondary market rules' };
  }

  Object.assign(asset.secondaryMarketRules, updates);
  return asset.secondaryMarketRules;
}

export function getSafeAssetStats() {
  const assets = Array.from(tokenizedAssets.values());
  const totalAssets = assets.length;
  const activeAssets = assets.filter(a => a.status === 'active').length;
  const verifiedAssets = assets.filter(a => a.verificationStatus === 'verified').length;

  let totalValuation = 0;
  let totalShares = 0;
  let totalHolders = new Set<string>();

  const assetsByType: Record<string, number> = {};

  for (const asset of assets) {
    if (asset.currentValuation) {
      totalValuation += asset.currentValuation.value;
    }
    totalShares += asset.totalShares;
    const holderKeys = Array.from(asset.holders.keys());
    for (const address of holderKeys) {
      totalHolders.add(address);
    }
    assetsByType[asset.assetType] = (assetsByType[asset.assetType] || 0) + 1;
  }

  let totalYieldDistributed = 0;
  for (const asset of assets) {
    totalYieldDistributed += asset.yieldConfig.totalDistributed;
  }

  return {
    totalAssets,
    activeAssets,
    verifiedAssets,
    totalValuation: parseFloat(totalValuation.toFixed(8)),
    totalShares,
    uniqueHolders: totalHolders.size,
    totalTransfers: transferRecords.length,
    totalYieldDistributed: parseFloat(totalYieldDistributed.toFixed(8)),
    assetsByType,
    ticker: COIN_TICKER,
  };
}

export function getAssetTransfers(assetId: string): AssetTransferRecord[] {
  return transferRecords
    .filter(r => r.assetId === assetId)
    .sort((a, b) => b.timestamp - a.timestamp);
}

function serializeAsset(asset: TokenizedAsset): any {
  return {
    ...asset,
    holders: Array.from(asset.holders.values()),
  };
}

export function getSerializedAsset(assetId: string): any | { error: string } {
  const asset = tokenizedAssets.get(assetId);
  if (!asset) {
    return { error: `Asset ${assetId} not found` };
  }
  return serializeAsset(asset);
}

export function getAllSerializedAssets(filters?: { assetType?: AssetType; status?: AssetStatus }): any[] {
  return getAllAssets(filters).map(serializeAsset);
}

function getPayoutIntervalMs(schedule: PayoutSchedule): number {
  switch (schedule) {
    case 'monthly': return 30 * 24 * 60 * 60 * 1000;
    case 'quarterly': return 90 * 24 * 60 * 60 * 1000;
    case 'annually': return 365 * 24 * 60 * 60 * 1000;
  }
}

function getPeriodsPerYear(schedule: PayoutSchedule): number {
  switch (schedule) {
    case 'monthly': return 12;
    case 'quarterly': return 4;
    case 'annually': return 1;
  }
}
