import crypto from 'crypto';
import { getBlockchain } from './chain.js';
import { COIN_TICKER } from './consensus.js';

const VAULT_ADDRESS = 'ALPHA_SAFESEND_VAULT_000000000000000000';
const INSURANCE_RATE = 0.001;
const MIN_STAKE_PERCENT = 0.05;
const MIN_INVESTIGATION_DAYS = 7;
const MAX_INVESTIGATION_DAYS = 30;
const JURY_STAKE_AMOUNT = 100;
const JURY_REWARD_MULTIPLIER = 1.1;
const MAX_PAYOUT_PERCENT_OF_VAULT = 0.1;
const HMAC_SECRET = crypto.randomBytes(64).toString('hex');
const INTEGRITY_CHECK_INTERVAL_MS = 60000;

export type ClaimStatus = 'pending' | 'investigating' | 'jury_vote' | 'approved' | 'denied' | 'paid' | 'fraudulent';
export type IntegrityStatus = 'active' | 'triggered' | 'expired' | 'resolved';

export interface InsuranceClaim {
  id: string;
  claimantAddress: string;
  transactionHash: string;
  destinationAddress: string;
  claimedAmount: number;
  stakeAmount: number;
  status: ClaimStatus;
  filedAt: number;
  investigationDeadline: number;
  verificationResults: VerificationResult[];
  juryVotes: JuryVote[];
  reputationScore: number;
  maxPayout: number;
  payoutAmount: number;
  validatorId: string | null;
  resolvedAt: number | null;
  denialReason: string | null;
}

export interface VerificationResult {
  layer: number;
  name: string;
  passed: boolean;
  details: string;
  checkedAt: number;
}

export interface JuryVote {
  jurorAddress: string;
  vote: 'approve' | 'deny';
  stakeAmount: number;
  reason: string;
  votedAt: number;
  rewarded: boolean;
}

export interface IntegrityValidator {
  id: string;
  claimId: string;
  taggedFundsHash: string;
  originAddress: string;
  destinationAddress: string;
  amount: number;
  status: IntegrityStatus;
  createdAt: number;
  threads: ValidationThread[];
  triggered: boolean;
  triggeredAt: number | null;
  triggerReason: string | null;
  auditTrail: AuditEntry[];
}

export interface ValidationThread {
  fromAddress: string;
  toAddress: string;
  amount: number;
  transactionHash: string;
  threadNumber: number;
  timestamp: number;
  portionValidated: number;
}

export interface AuditEntry {
  timestamp: number;
  event: string;
  details: string;
  addresses: string[];
}

export interface VaultStats {
  vaultAddress: string;
  totalBalance: number;
  totalDeposits: number;
  totalPayouts: number;
  totalClaims: number;
  activeClaims: number;
  approvedClaims: number;
  deniedClaims: number;
  fraudulentClaims: number;
  activeValidators: number;
  triggeredValidators: number;
  ticker: string;
}

interface WalletRelationship {
  address: string;
  interactionCount: number;
  sharedSources: string[];
  circularFlowDetected: boolean;
}

interface TamperEvent {
  timestamp: number;
  affectedAddress: string;
  validatorId: string;
  burnedAmount: number;
  details: string;
  forensicDossierId: string | null;
}

export type ForensicTrigger = 'tamper_detected' | 'circular_flow' | 'connected_wallet' | 'manual_fraud_flag' | 'post_payout_recovery';
export type ForensicSeverity = 'critical' | 'high' | 'medium' | 'low';

export interface WalletFingerprint {
  address: string;
  firstSeen: number;
  lastSeen: number;
  totalTransactionCount: number;
  totalSent: number;
  totalReceived: number;
  currentBalance: number;
  associatedAliases: string[];
  fundingSources: string[];
  fundingDestinations: string[];
  averageTransactionSize: number;
  largestTransaction: { amount: number; hash: string; timestamp: number } | null;
  transactionVelocity: number;
}

export interface ForensicTransaction {
  hash: string;
  fromAddress: string;
  toAddress: string;
  amount: number;
  timestamp: number;
  blockIndex: number | null;
  direction: 'inbound' | 'outbound';
  counterpartyAddress: string;
}

export interface ConnectedWalletProfile {
  address: string;
  relationship: 'direct_transfer' | 'shared_funding_source' | 'circular_flow' | 'common_destination';
  interactionCount: number;
  totalFlowAmount: number;
  firstInteraction: number;
  lastInteraction: number;
  currentBalance: number;
  suspicionScore: number;
}

export interface ForensicDossier {
  id: string;
  createdAt: number;
  updatedAt: number;
  trigger: ForensicTrigger;
  severity: ForensicSeverity;
  status: 'active' | 'under_review' | 'referred_to_legal' | 'resolved';
  primaryAddress: string;
  claimId: string | null;
  validatorId: string | null;
  walletFingerprint: WalletFingerprint;
  transactionHistory: ForensicTransaction[];
  connectedWallets: ConnectedWalletProfile[];
  fundFlowMap: { fromAddress: string; toAddress: string; amount: number; hash: string; timestamp: number; depth: number }[];
  evidenceChain: { timestamp: number; type: string; description: string; data: Record<string, any> }[];
  fraudIndicators: { indicator: string; confidence: number; details: string }[];
  totalFundsInvolved: number;
  burnedAmount: number;
  frozenAmount: number;
  chainInvalidated: boolean;
  legalReferralReady: boolean;
  adminNotes: string[];
  notificationsSent: { timestamp: number; channel: string; recipient: string; summary: string }[];
}

class InsuranceVaultService {
  private vaultBalance: number = 0;
  private totalDeposits: number = 0;
  private totalPayouts: number = 0;
  private claims: Map<string, InsuranceClaim> = new Map();
  private validators: Map<string, IntegrityValidator> = new Map();
  private addressInteractions: Map<string, Set<string>> = new Map();
  private claimHistory: Map<string, string[]> = new Map();
  private integrityHmacs: Map<string, string> = new Map();
  private tamperEvents: TamperEvent[] = [];
  private invalidatedAddresses: Set<string> = new Set();
  private integrityCheckTimer: ReturnType<typeof setInterval> | null = null;
  private forensicDossiers: Map<string, ForensicDossier> = new Map();
  private adminAlerts: { id: string; timestamp: number; severity: ForensicSeverity; title: string; summary: string; dossierId: string; acknowledged: boolean }[] = [];

  constructor() {
    console.log(`[InsuranceVault] Initialized at ${VAULT_ADDRESS}`);
    this.startPeriodicIntegrityCheck();
  }

  private computeValidatorHmac(validator: IntegrityValidator): string {
    const payload = JSON.stringify({
      id: validator.id,
      claimId: validator.claimId,
      taggedFundsHash: validator.taggedFundsHash,
      originAddress: validator.originAddress,
      destinationAddress: validator.destinationAddress,
      amount: validator.amount,
      createdAt: validator.createdAt,
    });
    return crypto.createHmac('sha256', HMAC_SECRET).update(payload).digest('hex');
  }

  private verifyValidatorIntegrity(validatorId: string): boolean {
    const validator = this.validators.get(validatorId);
    if (!validator) return false;
    const storedHmac = this.integrityHmacs.get(validatorId);
    if (!storedHmac) return false;
    const currentHmac = this.computeValidatorHmac(validator);
    return crypto.timingSafeEqual(Buffer.from(storedHmac, 'hex'), Buffer.from(currentHmac, 'hex'));
  }

  private startPeriodicIntegrityCheck(): void {
    this.integrityCheckTimer = setInterval(() => {
      this.runFullIntegrityVerification();
    }, INTEGRITY_CHECK_INTERVAL_MS);
  }

  private runFullIntegrityVerification(): void {
    for (const [validatorId, validator] of Array.from(this.validators.entries())) {
      if (validator.status === 'resolved' || validator.status === 'expired') continue;
      if (!this.verifyValidatorIntegrity(validatorId)) {
        console.log(`[ACIP] TAMPER DETECTED on validator ${validatorId.substring(0, 16)}... — initiating self-destruct`);
        this.selfDestructOnTamper(validatorId);
      }
    }
  }

  selfDestructOnTamper(validatorId: string): TamperEvent | { error: string } {
    const validator = this.validators.get(validatorId);
    if (!validator) {
      return { error: 'Validator not found' };
    }

    const claim = this.claims.get(validator.claimId);
    const affectedAddress = validator.destinationAddress;

    const blockchain = getBlockchain();
    const addressBalance = blockchain.getBalance(affectedAddress);

    if (addressBalance > 0) {
      const burnAddress = 'ALPHA_BURN_000000000000000000000000000000000';
      const currentBurn = blockchain.balances.get(burnAddress) || 0;
      blockchain.balances.set(burnAddress, parseFloat((currentBurn + addressBalance).toFixed(8)));
      blockchain.balances.set(affectedAddress, 0);
      console.log(`[ACIP] FUNDS BURNED: ${addressBalance} ${COIN_TICKER} from ${affectedAddress.substring(0, 16)}... sent to burn address`);
    }

    if (claim) {
      claim.status = 'fraudulent';
      claim.resolvedAt = Date.now();
      claim.denialReason = `TAMPER DETECTED: Protocol integrity compromised. Funds invalidated and chain state purged for address ${affectedAddress.substring(0, 16)}...`;
    }

    this.invalidatedAddresses.add(affectedAddress);

    validator.status = 'triggered';
    validator.triggered = true;
    validator.triggeredAt = Date.now();
    validator.triggerReason = `INTEGRITY VIOLATION: HMAC mismatch detected. Self-destruct protocol executed.`;
    validator.auditTrail.push({
      timestamp: Date.now(),
      event: 'TAMPER_SELF_DESTRUCT',
      details: `Tamper detected on validator ${validatorId}. Burned ${addressBalance} ${COIN_TICKER}. Address ${affectedAddress} invalidated.`,
      addresses: [affectedAddress],
    });

    const dossier = this.buildForensicDossier(affectedAddress, 'tamper_detected', 'critical', claim?.id || null, validatorId);
    dossier.burnedAmount = addressBalance;
    dossier.chainInvalidated = true;
    dossier.legalReferralReady = true;
    dossier.evidenceChain.push({
      timestamp: Date.now(),
      type: 'TAMPER_SELF_DESTRUCT',
      description: `HMAC integrity violation detected. Protocol self-destruct executed. ${addressBalance} ${COIN_TICKER} burned. Address permanently invalidated.`,
      data: { validatorId, burnedAmount: addressBalance, hmacExpected: this.integrityHmacs.get(validatorId) || 'N/A', affectedAddress },
    });
    dossier.fraudIndicators.push(
      { indicator: 'Protocol Tampering Attempt', confidence: 100, details: 'HMAC signature mismatch on integrity validator — deliberate modification detected' },
      { indicator: 'Chain State Invalidation', confidence: 100, details: `Address ${affectedAddress} permanently blocked from all AUC operations` },
    );

    this.forensicDossiers.set(dossier.id, dossier);
    this.emitAdminAlert('critical', `TAMPER SELF-DESTRUCT: ${addressBalance} ${COIN_TICKER} burned`, `Integrity violation on validator ${validatorId.substring(0, 16)}... Address ${affectedAddress.substring(0, 20)}... invalidated. Forensic dossier compiled with full wallet history, transaction map, and connected wallets.`, dossier.id);

    const tamperEvent: TamperEvent = {
      timestamp: Date.now(),
      affectedAddress,
      validatorId,
      burnedAmount: addressBalance,
      details: `HMAC integrity check failed. Validator code was modified. All funds burned and address chain state invalidated.`,
      forensicDossierId: dossier.id,
    };
    this.tamperEvents.push(tamperEvent);

    console.log(`[ACIP] Self-destruct complete for validator ${validatorId.substring(0, 16)}... | Address ${affectedAddress.substring(0, 16)}... invalidated | ${addressBalance} ${COIN_TICKER} burned | Dossier: ${dossier.id}`);

    return tamperEvent;
  }

  getTamperEvents(): TamperEvent[] {
    return [...this.tamperEvents];
  }

  isAddressInvalidated(address: string): boolean {
    return this.invalidatedAddresses.has(address);
  }

  calculateInsuranceFee(amount: number): number {
    return parseFloat((amount * INSURANCE_RATE).toFixed(8));
  }

  depositToVault(amount: number, fromTxId: string): void {
    this.vaultBalance = parseFloat((this.vaultBalance + amount).toFixed(8));
    this.totalDeposits = parseFloat((this.totalDeposits + amount).toFixed(8));
    console.log(`[InsuranceVault] Deposit: ${amount} ${COIN_TICKER} from tx ${fromTxId.substring(0, 16)}... | Vault balance: ${this.vaultBalance}`);
  }

  getVaultBalance(): number {
    return this.vaultBalance;
  }

  getVaultAddress(): string {
    return VAULT_ADDRESS;
  }

  fileClaim(
    claimantAddress: string,
    transactionHash: string,
    destinationAddress: string,
    claimedAmount: number,
    stakeAmount: number
  ): InsuranceClaim | { error: string } {
    const minStake = parseFloat((claimedAmount * MIN_STAKE_PERCENT).toFixed(8));
    if (stakeAmount < minStake) {
      return { error: `Minimum stake is 5% of claimed amount (${minStake} ${COIN_TICKER}). You provided ${stakeAmount} ${COIN_TICKER}.` };
    }

    if (claimedAmount <= 0) {
      return { error: 'Claimed amount must be positive' };
    }

    const maxPayout = this.calculateMaxPayout(claimantAddress);
    if (claimedAmount > maxPayout) {
      return { error: `Claim exceeds maximum payout of ${maxPayout} ${COIN_TICKER} based on vault balance and your history.` };
    }

    const existingClaims = Array.from(this.claims.values()).filter(
      c => c.claimantAddress === claimantAddress && ['pending', 'investigating', 'jury_vote'].includes(c.status)
    );
    if (existingClaims.length >= 3) {
      return { error: 'Maximum 3 active claims per address.' };
    }

    const claimId = this.generateClaimId(claimantAddress, transactionHash);
    const now = Date.now();

    const claim: InsuranceClaim = {
      id: claimId,
      claimantAddress,
      transactionHash,
      destinationAddress,
      claimedAmount,
      stakeAmount,
      status: 'pending',
      filedAt: now,
      investigationDeadline: now + (MIN_INVESTIGATION_DAYS * 24 * 60 * 60 * 1000),
      verificationResults: [],
      juryVotes: [],
      reputationScore: this.calculateReputationScore(claimantAddress),
      maxPayout,
      payoutAmount: 0,
      validatorId: null,
      resolvedAt: null,
      denialReason: null,
    };

    this.claims.set(claimId, claim);

    const history = this.claimHistory.get(claimantAddress) || [];
    history.push(claimId);
    this.claimHistory.set(claimantAddress, history);

    const verificationResults = this.runVerification(claim);
    claim.verificationResults = verificationResults;

    const allPassed = verificationResults.every(v => v.passed);
    const criticalFailed = verificationResults.filter(v => !v.passed && [1, 2].includes(v.layer));

    if (criticalFailed.length > 0) {
      claim.status = 'denied';
      claim.resolvedAt = Date.now();
      claim.denialReason = `Critical verification failed: ${criticalFailed.map(v => v.name).join(', ')}`;
    } else {
      claim.status = 'investigating';
      const validator = this.initValidator(claim);
      claim.validatorId = validator.id;
    }

    return claim;
  }

  private runVerification(claim: InsuranceClaim): VerificationResult[] {
    const results: VerificationResult[] = [];
    const now = Date.now();

    results.push(this.verifyOnChainProof(claim, now));
    results.push(this.verifyWalletRelationship(claim, now));
    results.push(this.verifyTimeLockEscrow(claim, now));
    results.push(this.verifyStakeToClaim(claim, now));
    results.push(this.verifyCommunityJury(claim, now));
    results.push(this.verifyReputation(claim, now));
    results.push(this.verifyPayoutCaps(claim, now));

    return results;
  }

  private verifyOnChainProof(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const blockchain = getBlockchain();
    const txResult = blockchain.getTransactionById(claim.transactionHash);

    if (!txResult) {
      const mempoolTx = blockchain.mempool.find(t => t.id === claim.transactionHash);
      if (mempoolTx) {
        const fromInput = mempoolTx.inputs.find(i => i.address === claim.claimantAddress);
        return {
          layer: 1,
          name: 'On-Chain Proof',
          passed: !!fromInput,
          details: fromInput
            ? `Transaction ${claim.transactionHash.substring(0, 16)}... found in mempool from claimant's wallet`
            : `Transaction found in mempool but claimant is not the sender`,
          checkedAt: timestamp,
        };
      }
      return {
        layer: 1,
        name: 'On-Chain Proof',
        passed: false,
        details: `Transaction ${claim.transactionHash.substring(0, 16)}... not found on chain or in mempool`,
        checkedAt: timestamp,
      };
    }

    const tx = txResult.transaction;
    const fromInput = tx.inputs.find(i => i.address === claim.claimantAddress);
    const toOutput = tx.outputs.find(o => o.address === claim.destinationAddress);

    return {
      layer: 1,
      name: 'On-Chain Proof',
      passed: !!fromInput && !!toOutput,
      details: fromInput && toOutput
        ? `Verified: tx ${claim.transactionHash.substring(0, 16)}... sent ${toOutput.amount} ${COIN_TICKER} from ${claim.claimantAddress.substring(0, 16)}... to ${claim.destinationAddress.substring(0, 16)}... in block #${txResult.blockIndex}`
        : `Transaction exists but does not match claim details (sender/recipient mismatch)`,
      checkedAt: timestamp,
    };
  }

  private verifyWalletRelationship(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const relationship = this.analyzeWalletRelationship(claim.claimantAddress, claim.destinationAddress);

    if (relationship.circularFlowDetected) {
      return {
        layer: 2,
        name: 'Wallet Relationship Graph',
        passed: false,
        details: `CIRCULAR FLOW DETECTED between ${claim.claimantAddress.substring(0, 16)}... and ${claim.destinationAddress.substring(0, 16)}... Shared sources: ${relationship.sharedSources.length}. Auto-denied.`,
        checkedAt: timestamp,
      };
    }

    const suspicious = relationship.interactionCount > 5 || relationship.sharedSources.length > 2;

    return {
      layer: 2,
      name: 'Wallet Relationship Graph',
      passed: !suspicious,
      details: suspicious
        ? `Suspicious relationship: ${relationship.interactionCount} prior interactions, ${relationship.sharedSources.length} shared funding sources`
        : `No suspicious relationship detected. ${relationship.interactionCount} prior interactions.`,
      checkedAt: timestamp,
    };
  }

  private verifyTimeLockEscrow(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const daysRemaining = Math.ceil((claim.investigationDeadline - timestamp) / (24 * 60 * 60 * 1000));

    return {
      layer: 3,
      name: 'Time-Lock Escrow',
      passed: true,
      details: `Investigation window active. ${daysRemaining} days remaining before payout eligibility. Window: ${MIN_INVESTIGATION_DAYS}-${MAX_INVESTIGATION_DAYS} days.`,
      checkedAt: timestamp,
    };
  }

  private verifyStakeToClaim(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const requiredStake = parseFloat((claim.claimedAmount * MIN_STAKE_PERCENT).toFixed(8));
    const passed = claim.stakeAmount >= requiredStake;

    return {
      layer: 4,
      name: 'Stake-to-Claim',
      passed,
      details: passed
        ? `Claimant staked ${claim.stakeAmount} ${COIN_TICKER} (required: ${requiredStake} ${COIN_TICKER}). Stake will be returned if claim is legitimate, forfeited if fraudulent.`
        : `Insufficient stake: ${claim.stakeAmount} ${COIN_TICKER} < required ${requiredStake} ${COIN_TICKER}`,
      checkedAt: timestamp,
    };
  }

  private verifyCommunityJury(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const totalVotes = claim.juryVotes.length;
    const approveVotes = claim.juryVotes.filter(v => v.vote === 'approve').length;
    const denyVotes = claim.juryVotes.filter(v => v.vote === 'deny').length;

    if (totalVotes < 3) {
      return {
        layer: 5,
        name: 'Community Jury (DAO)',
        passed: true,
        details: `Jury voting in progress. ${totalVotes}/3 minimum votes received. Jurors stake ${JURY_STAKE_AMOUNT} ${COIN_TICKER} per vote.`,
        checkedAt: timestamp,
      };
    }

    const passed = approveVotes > denyVotes;
    return {
      layer: 5,
      name: 'Community Jury (DAO)',
      passed,
      details: `Jury voted: ${approveVotes} approve, ${denyVotes} deny. ${passed ? 'Claim approved by community.' : 'Claim denied by community.'}`,
      checkedAt: timestamp,
    };
  }

  private verifyReputation(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const score = claim.reputationScore;
    const passed = score >= 30;

    return {
      layer: 6,
      name: 'Reputation Scoring',
      passed,
      details: `Reputation score: ${score}/100. ${passed ? 'Meets minimum threshold (30).' : 'Below minimum threshold (30). Higher account age, transaction count, and clean claim history improve score.'}`,
      checkedAt: timestamp,
    };
  }

  private verifyPayoutCaps(claim: InsuranceClaim, timestamp: number): VerificationResult {
    const maxPayout = this.calculateMaxPayout(claim.claimantAddress);
    const passed = claim.claimedAmount <= maxPayout;

    return {
      layer: 7,
      name: 'Maximum Payout Caps',
      passed,
      details: passed
        ? `Claimed ${claim.claimedAmount} ${COIN_TICKER} within maximum payout cap of ${maxPayout} ${COIN_TICKER} (${(MAX_PAYOUT_PERCENT_OF_VAULT * 100).toFixed(0)}% of vault balance).`
        : `Claimed ${claim.claimedAmount} ${COIN_TICKER} exceeds maximum payout cap of ${maxPayout} ${COIN_TICKER}.`,
      checkedAt: timestamp,
    };
  }

  private analyzeWalletRelationship(address1: string, address2: string): WalletRelationship {
    const blockchain = getBlockchain();
    const txs1 = blockchain.getAddressTransactions(address1);
    const txs2 = blockchain.getAddressTransactions(address2);

    let interactionCount = 0;
    const sources1 = new Set<string>();
    const sources2 = new Set<string>();

    for (const { transaction } of txs1) {
      for (const input of transaction.inputs) {
        if (input.address !== address1 && input.address !== 'COINBASE') {
          sources1.add(input.address);
        }
      }
      for (const output of transaction.outputs) {
        if (output.address === address2) {
          interactionCount++;
        }
      }
    }

    for (const { transaction } of txs2) {
      for (const input of transaction.inputs) {
        if (input.address !== address2 && input.address !== 'COINBASE') {
          sources2.add(input.address);
        }
      }
      for (const output of transaction.outputs) {
        if (output.address === address1) {
          interactionCount++;
        }
      }
    }

    const sharedSources = Array.from(sources1).filter(s => sources2.has(s));

    const circularFlowDetected = this.detectCircularFlow(address1, address2);

    return {
      address: address2,
      interactionCount,
      sharedSources,
      circularFlowDetected,
    };
  }

  private detectCircularFlow(origin: string, destination: string, maxDepth: number = 10): boolean {
    const blockchain = getBlockchain();
    const visited = new Set<string>();
    const queue: { address: string; depth: number }[] = [{ address: destination, depth: 0 }];

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (current.depth >= maxDepth) continue;
      if (visited.has(current.address)) continue;
      visited.add(current.address);

      const txs = blockchain.getAddressTransactions(current.address);
      for (const { transaction } of txs) {
        for (const output of transaction.outputs) {
          if (output.address === origin && output.address !== current.address) {
            return true;
          }
          if (!visited.has(output.address) && output.address !== current.address) {
            queue.push({ address: output.address, depth: current.depth + 1 });
          }
        }
      }
    }

    return false;
  }

  private calculateReputationScore(address: string): number {
    const blockchain = getBlockchain();
    let score = 0;

    const txs = blockchain.getAddressTransactions(address);
    const txCount = txs.length;

    if (txCount >= 50) score += 25;
    else if (txCount >= 20) score += 20;
    else if (txCount >= 10) score += 15;
    else if (txCount >= 5) score += 10;
    else score += 5;

    if (txs.length > 0) {
      const firstTx = txs[0].transaction.timestamp;
      const ageMs = Date.now() - firstTx;
      const ageDays = ageMs / (24 * 60 * 60 * 1000);

      if (ageDays >= 365) score += 25;
      else if (ageDays >= 180) score += 20;
      else if (ageDays >= 90) score += 15;
      else if (ageDays >= 30) score += 10;
      else score += 5;
    }

    const balance = blockchain.getBalance(address);
    if (balance >= 10000) score += 20;
    else if (balance >= 1000) score += 15;
    else if (balance >= 100) score += 10;
    else score += 5;

    const previousClaims = this.claimHistory.get(address) || [];
    const fraudulentCount = previousClaims.filter(cid => {
      const c = this.claims.get(cid);
      return c && c.status === 'fraudulent';
    }).length;
    const deniedCount = previousClaims.filter(cid => {
      const c = this.claims.get(cid);
      return c && c.status === 'denied';
    }).length;
    const approvedCount = previousClaims.filter(cid => {
      const c = this.claims.get(cid);
      return c && (c.status === 'approved' || c.status === 'paid');
    }).length;

    if (fraudulentCount > 0) score -= (fraudulentCount * 30);
    if (deniedCount > 0) score -= (deniedCount * 10);
    if (approvedCount > 0) score += (approvedCount * 5);

    if (previousClaims.length === 0) score += 10;

    return Math.max(0, Math.min(100, score));
  }

  private calculateMaxPayout(address: string): number {
    const vaultCap = parseFloat((this.vaultBalance * MAX_PAYOUT_PERCENT_OF_VAULT).toFixed(8));

    const previousClaims = this.claimHistory.get(address) || [];
    const previousPayouts = previousClaims.reduce((sum, cid) => {
      const c = this.claims.get(cid);
      return sum + (c ? c.payoutAmount : 0);
    }, 0);

    const historyMultiplier = previousPayouts > 0 ? Math.max(0.5, 1 - (previousPayouts / this.vaultBalance)) : 1;

    return parseFloat((vaultCap * historyMultiplier).toFixed(8));
  }

  submitJuryVote(
    claimId: string,
    jurorAddress: string,
    vote: 'approve' | 'deny',
    reason: string
  ): JuryVote | { error: string } {
    const claim = this.claims.get(claimId);
    if (!claim) {
      return { error: 'Claim not found' };
    }

    if (!['investigating', 'jury_vote'].includes(claim.status)) {
      return { error: `Claim is not accepting votes. Current status: ${claim.status}` };
    }

    if (jurorAddress === claim.claimantAddress || jurorAddress === claim.destinationAddress) {
      return { error: 'Involved parties cannot vote on their own claims' };
    }

    const existingVote = claim.juryVotes.find(v => v.jurorAddress === jurorAddress);
    if (existingVote) {
      return { error: 'You have already voted on this claim' };
    }

    const juryVote: JuryVote = {
      jurorAddress,
      vote,
      stakeAmount: JURY_STAKE_AMOUNT,
      reason,
      votedAt: Date.now(),
      rewarded: false,
    };

    claim.juryVotes.push(juryVote);

    if (claim.juryVotes.length >= 3) {
      claim.status = 'jury_vote';
      this.evaluateJuryResult(claim);
    }

    return juryVote;
  }

  private evaluateJuryResult(claim: InsuranceClaim): void {
    const approveVotes = claim.juryVotes.filter(v => v.vote === 'approve').length;
    const denyVotes = claim.juryVotes.filter(v => v.vote === 'deny').length;

    if (claim.juryVotes.length < 3) return;

    const majorityVote = approveVotes > denyVotes ? 'approve' : 'deny';

    for (const vote of claim.juryVotes) {
      if (vote.vote === majorityVote) {
        vote.rewarded = true;
      }
    }

    claim.verificationResults = this.runVerification(claim);

    const failedLayers = claim.verificationResults.filter(v => !v.passed);
    if (failedLayers.length === 0 && majorityVote === 'approve') {
      claim.status = 'approved';
      claim.payoutAmount = Math.min(claim.claimedAmount, claim.maxPayout);
      claim.resolvedAt = Date.now();
    } else if (majorityVote === 'deny') {
      claim.status = 'denied';
      claim.resolvedAt = Date.now();
      claim.denialReason = `Community jury denied. Failed layers: ${failedLayers.map(v => v.name).join(', ') || 'None'}`;
    }
  }

  processClaimPayout(claimId: string): { success: boolean; amount: number } | { error: string } {
    const claim = this.claims.get(claimId);
    if (!claim) {
      return { error: 'Claim not found' };
    }

    if (claim.status !== 'approved') {
      return { error: `Claim must be approved before payout. Current status: ${claim.status}` };
    }

    if (claim.payoutAmount > this.vaultBalance) {
      return { error: `Insufficient vault balance. Payout: ${claim.payoutAmount}, Vault: ${this.vaultBalance}` };
    }

    this.vaultBalance = parseFloat((this.vaultBalance - claim.payoutAmount).toFixed(8));
    this.totalPayouts = parseFloat((this.totalPayouts + claim.payoutAmount).toFixed(8));
    claim.status = 'paid';
    claim.resolvedAt = Date.now();

    console.log(`[InsuranceVault] Payout: ${claim.payoutAmount} ${COIN_TICKER} to ${claim.claimantAddress.substring(0, 16)}... for claim ${claimId.substring(0, 16)}...`);

    return { success: true, amount: claim.payoutAmount };
  }

  markClaimFraudulent(claimId: string, reason: string): InsuranceClaim | { error: string } {
    const claim = this.claims.get(claimId);
    if (!claim) {
      return { error: 'Claim not found' };
    }

    claim.status = 'fraudulent';
    claim.resolvedAt = Date.now();
    claim.denialReason = `Fraudulent: ${reason}`;

    this.vaultBalance = parseFloat((this.vaultBalance + claim.stakeAmount).toFixed(8));

    if (claim.validatorId) {
      const validator = this.validators.get(claim.validatorId);
      if (validator) {
        validator.status = 'resolved';
        validator.auditTrail.push({
          timestamp: Date.now(),
          event: 'CLAIM_FRAUDULENT',
          details: reason,
          addresses: [claim.claimantAddress],
        });
      }
    }

    const trigger: ForensicTrigger = reason.includes('CIRCULAR FLOW') ? 'circular_flow'
      : reason.includes('CONNECTED WALLET') ? 'connected_wallet'
      : 'manual_fraud_flag';
    const severity: ForensicSeverity = claim.claimedAmount > 10000 ? 'critical' : claim.claimedAmount > 1000 ? 'high' : 'medium';

    const dossier = this.buildForensicDossier(claim.claimantAddress, trigger, severity, claimId, claim.validatorId);
    dossier.totalFundsInvolved = claim.claimedAmount;
    dossier.frozenAmount = claim.stakeAmount;
    dossier.evidenceChain.push({
      timestamp: Date.now(),
      type: 'FRAUD_DETECTION',
      description: `Claim ${claimId} flagged as fraudulent. Reason: ${reason}`,
      data: {
        claimId,
        claimantAddress: claim.claimantAddress,
        destinationAddress: claim.destinationAddress,
        claimedAmount: claim.claimedAmount,
        stakeForfeited: claim.stakeAmount,
        transactionHash: claim.transactionHash,
        verificationResults: claim.verificationResults,
      },
    });

    const destDossier = this.buildForensicDossier(claim.destinationAddress, trigger, severity, claimId, claim.validatorId);
    destDossier.totalFundsInvolved = claim.claimedAmount;
    destDossier.evidenceChain.push({
      timestamp: Date.now(),
      type: 'CONNECTED_FRAUD_SUBJECT',
      description: `Destination address in fraudulent claim. Received funds from ${claim.claimantAddress.substring(0, 20)}...`,
      data: { claimId, originAddress: claim.claimantAddress, amount: claim.claimedAmount },
    });
    this.forensicDossiers.set(destDossier.id, destDossier);

    if (claim.validatorId) {
      const validator = this.validators.get(claim.validatorId);
      if (validator && validator.threads.length > 0) {
        for (const thread of validator.threads) {
          if (thread.toAddress !== claim.claimantAddress && thread.toAddress !== claim.destinationAddress) {
            dossier.evidenceChain.push({
              timestamp: Date.now(),
              type: 'FUND_FLOW_INTERMEDIARY',
              description: `Intermediary wallet detected in fund flow path: ${thread.toAddress.substring(0, 20)}...`,
              data: { intermediaryAddress: thread.toAddress, amount: thread.amount, threadNumber: thread.threadNumber, fromAddress: thread.fromAddress },
            });
          }
        }
      }
    }

    this.forensicDossiers.set(dossier.id, dossier);
    this.emitAdminAlert(severity, `FRAUD DETECTED: ${claim.claimedAmount} ${COIN_TICKER} claim`, `${reason}. Claimant: ${claim.claimantAddress.substring(0, 20)}... Destination: ${claim.destinationAddress.substring(0, 20)}... Stake forfeited: ${claim.stakeAmount} ${COIN_TICKER}. Full forensic dossier compiled.`, dossier.id);

    return claim;
  }

  getClaim(claimId: string): InsuranceClaim | undefined {
    return this.claims.get(claimId);
  }

  getAllClaims(): InsuranceClaim[] {
    return Array.from(this.claims.values()).sort((a, b) => b.filedAt - a.filedAt);
  }

  getClaimsByAddress(address: string): InsuranceClaim[] {
    return Array.from(this.claims.values())
      .filter(c => c.claimantAddress === address)
      .sort((a, b) => b.filedAt - a.filedAt);
  }

  private initValidator(claim: InsuranceClaim): IntegrityValidator {
    const validatorId = this.generateValidatorId(claim);
    const taggedFundsHash = this.generateFundsTag(claim.transactionHash, claim.claimantAddress, claim.claimedAmount);

    const validator: IntegrityValidator = {
      id: validatorId,
      claimId: claim.id,
      taggedFundsHash,
      originAddress: claim.claimantAddress,
      destinationAddress: claim.destinationAddress,
      amount: claim.claimedAmount,
      status: 'active',
      createdAt: Date.now(),
      threads: [],
      triggered: false,
      triggeredAt: null,
      triggerReason: null,
      auditTrail: [{
        timestamp: Date.now(),
        event: 'CV_INITIALIZED',
        details: `Integrity check initialized for ${claim.claimedAmount} ${COIN_TICKER} from tx ${claim.transactionHash.substring(0, 16)}...`,
        addresses: [claim.claimantAddress, claim.destinationAddress],
      }],
    };

    this.validators.set(validatorId, validator);

    const hmac = this.computeValidatorHmac(validator);
    this.integrityHmacs.set(validatorId, hmac);

    this.trackInteraction(claim.claimantAddress, claim.destinationAddress);

    this.runConsensusCheck(validator);

    return validator;
  }

  private runConsensusCheck(validator: IntegrityValidator): void {
    const blockchain = getBlockchain();
    const visited = new Set<string>();
    const claimantConnections = this.getConnectedAddresses(validator.originAddress);

    const queue: { address: string; depth: number; portion: number }[] = [
      { address: validator.destinationAddress, depth: 0, portion: 1.0 },
    ];

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (current.depth >= 20) continue;
      if (visited.has(current.address)) continue;
      visited.add(current.address);

      const txs = blockchain.getAddressTransactions(current.address);

      for (const { transaction } of txs) {
        if (transaction.timestamp < validator.createdAt - (30 * 24 * 60 * 60 * 1000)) continue;

        const fromThis = transaction.inputs.some(i => i.address === current.address);
        if (!fromThis) continue;

        for (const output of transaction.outputs) {
          if (output.address === current.address) continue;

          const thread: ValidationThread = {
            fromAddress: current.address,
            toAddress: output.address,
            amount: output.amount,
            transactionHash: transaction.id,
            threadNumber: current.depth + 1,
            timestamp: transaction.timestamp,
            portionValidated: current.portion * (output.amount / validator.amount),
          };

          validator.threads.push(thread);

          validator.auditTrail.push({
            timestamp: Date.now(),
            event: 'THREAD_VERIFIED',
            details: `Validation thread #${thread.threadNumber}: ${output.amount} ${COIN_TICKER} verified ${current.address.substring(0, 12)}... → ${output.address.substring(0, 12)}...`,
            addresses: [current.address, output.address],
          });

          if (output.address === validator.originAddress) {
            validator.triggered = true;
            validator.triggeredAt = Date.now();
            validator.status = 'triggered';
            validator.triggerReason = `CIRCULAR FLOW: Validated funds returned to claimant after ${thread.threadNumber} threads. Path: ${validator.threads.map(h => h.toAddress.substring(0, 8)).join(' → ')}`;
            validator.auditTrail.push({
              timestamp: Date.now(),
              event: 'CV_ALERT',
              details: validator.triggerReason,
              addresses: [validator.originAddress, validator.destinationAddress],
            });
            return;
          }

          if (claimantConnections.has(output.address)) {
            validator.triggered = true;
            validator.triggeredAt = Date.now();
            validator.status = 'triggered';
            validator.triggerReason = `CONNECTED WALLET: Validated funds flowed to ${output.address.substring(0, 16)}... which has interacted with claimant. Thread #${thread.threadNumber}.`;
            validator.auditTrail.push({
              timestamp: Date.now(),
              event: 'CV_ALERT',
              details: validator.triggerReason,
              addresses: [output.address, validator.originAddress],
            });
            return;
          }

          if (current.depth + 1 < 20) {
            queue.push({
              address: output.address,
              depth: current.depth + 1,
              portion: thread.portionValidated,
            });
          }
        }
      }
    }
  }

  runIntegrityAudit(): { triggered: IntegrityValidator[]; active: IntegrityValidator[] } {
    const triggered: IntegrityValidator[] = [];
    const active: IntegrityValidator[] = [];

    for (const validator of Array.from(this.validators.values())) {
      if (validator.status === 'active') {
        this.runConsensusCheck(validator);

        if (validator.triggered) {
          triggered.push(validator);
          const claim = this.claims.get(validator.claimId);
          if (claim && ['investigating', 'jury_vote', 'approved'].includes(claim.status)) {
            this.markClaimFraudulent(claim.id, validator.triggerReason || 'Integrity check alert triggered');
          }
        } else {
          active.push(validator);
        }
      } else if (validator.status === 'triggered') {
        triggered.push(validator);
      }
    }

    return { triggered, active };
  }

  getValidator(validatorId: string): IntegrityValidator | undefined {
    return this.validators.get(validatorId);
  }

  getAllValidators(): IntegrityValidator[] {
    return Array.from(this.validators.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  getActiveValidators(): IntegrityValidator[] {
    return Array.from(this.validators.values())
      .filter(b => b.status === 'active')
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  private getConnectedAddresses(address: string): Set<string> {
    const connections = new Set<string>();
    const directConnections = this.addressInteractions.get(address);
    if (directConnections) {
      for (const addr of Array.from(directConnections)) {
        connections.add(addr);
      }
    }

    const blockchain = getBlockchain();
    const txs = blockchain.getAddressTransactions(address);
    for (const { transaction } of txs) {
      for (const input of transaction.inputs) {
        if (input.address !== address && input.address !== 'COINBASE') {
          connections.add(input.address);
        }
      }
      for (const output of transaction.outputs) {
        if (output.address !== address) {
          connections.add(output.address);
        }
      }
    }

    return connections;
  }

  private trackInteraction(address1: string, address2: string): void {
    if (!this.addressInteractions.has(address1)) {
      this.addressInteractions.set(address1, new Set());
    }
    if (!this.addressInteractions.has(address2)) {
      this.addressInteractions.set(address2, new Set());
    }
    this.addressInteractions.get(address1)!.add(address2);
    this.addressInteractions.get(address2)!.add(address1);
  }

  private generateClaimId(claimantAddress: string, txHash: string): string {
    const data = `claim:${claimantAddress}:${txHash}:${Date.now()}:${Math.random()}`;
    return `CLAIM_${crypto.createHash('sha256').update(data).digest('hex').substring(0, 32).toUpperCase()}`;
  }

  private generateValidatorId(claim: InsuranceClaim): string {
    const data = `validator:${claim.id}:${claim.transactionHash}:${Date.now()}`;
    return `CV_${crypto.createHash('sha256').update(data).digest('hex').substring(0, 32).toUpperCase()}`;
  }

  private generateFundsTag(txHash: string, address: string, amount: number): string {
    const data = `tag:${txHash}:${address}:${amount}:${Date.now()}`;
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  private buildForensicDossier(targetAddress: string, trigger: ForensicTrigger, severity: ForensicSeverity, claimId: string | null, validatorId: string | null): ForensicDossier {
    const existing = Array.from(this.forensicDossiers.values()).find(d => d.primaryAddress === targetAddress && d.status === 'active');
    if (existing) {
      existing.updatedAt = Date.now();
      return existing;
    }

    const dossierId = `FD_${crypto.createHash('sha256').update(`forensic:${targetAddress}:${Date.now()}:${Math.random()}`).digest('hex').substring(0, 32).toUpperCase()}`;
    const now = Date.now();

    const walletFingerprint = this.buildWalletFingerprint(targetAddress);
    const transactionHistory = this.buildTransactionHistory(targetAddress);
    const connectedWallets = this.buildConnectedWalletProfiles(targetAddress);
    const fundFlowMap = this.buildFundFlowMap(targetAddress);
    const fraudIndicators = this.analyzeForFraudIndicators(targetAddress, walletFingerprint, connectedWallets, transactionHistory);

    const dossier: ForensicDossier = {
      id: dossierId,
      createdAt: now,
      updatedAt: now,
      trigger,
      severity,
      status: 'active',
      primaryAddress: targetAddress,
      claimId,
      validatorId,
      walletFingerprint,
      transactionHistory,
      connectedWallets,
      fundFlowMap,
      evidenceChain: [{
        timestamp: now,
        type: 'DOSSIER_CREATED',
        description: `Forensic dossier initiated for address ${targetAddress}. Trigger: ${trigger}. ${transactionHistory.length} transactions analyzed. ${connectedWallets.length} connected wallets profiled.`,
        data: { trigger, severity, totalTransactions: transactionHistory.length, connectedWalletCount: connectedWallets.length },
      }],
      fraudIndicators,
      totalFundsInvolved: 0,
      burnedAmount: 0,
      frozenAmount: 0,
      chainInvalidated: this.invalidatedAddresses.has(targetAddress),
      legalReferralReady: severity === 'critical',
      adminNotes: [],
      notificationsSent: [],
    };

    console.log(`[ACIP Forensics] Dossier ${dossierId.substring(0, 16)}... compiled for ${targetAddress.substring(0, 20)}... | ${transactionHistory.length} txs | ${connectedWallets.length} connected wallets | ${fraudIndicators.length} indicators`);

    return dossier;
  }

  private buildWalletFingerprint(address: string): WalletFingerprint {
    const blockchain = getBlockchain();
    const txs = blockchain.getAddressTransactions(address);
    const balance = blockchain.getBalance(address);

    let firstSeen = Infinity;
    let lastSeen = 0;
    let totalSent = 0;
    let totalReceived = 0;
    const fundingSources = new Set<string>();
    const fundingDestinations = new Set<string>();
    let largestTx: { amount: number; hash: string; timestamp: number } | null = null;
    const allAmounts: number[] = [];

    for (const { transaction } of txs) {
      if (transaction.timestamp < firstSeen) firstSeen = transaction.timestamp;
      if (transaction.timestamp > lastSeen) lastSeen = transaction.timestamp;

      const isOutbound = transaction.inputs.some(i => i.address === address);
      const isInbound = transaction.outputs.some(o => o.address === address);

      if (isOutbound) {
        for (const output of transaction.outputs) {
          if (output.address !== address) {
            totalSent += output.amount;
            fundingDestinations.add(output.address);
            allAmounts.push(output.amount);
            if (!largestTx || output.amount > largestTx.amount) {
              largestTx = { amount: output.amount, hash: transaction.id, timestamp: transaction.timestamp };
            }
          }
        }
      }
      if (isInbound) {
        for (const output of transaction.outputs) {
          if (output.address === address) {
            totalReceived += output.amount;
            allAmounts.push(output.amount);
            if (!largestTx || output.amount > largestTx.amount) {
              largestTx = { amount: output.amount, hash: transaction.id, timestamp: transaction.timestamp };
            }
          }
        }
        for (const input of transaction.inputs) {
          if (input.address !== address && input.address !== 'COINBASE') {
            fundingSources.add(input.address);
          }
        }
      }
    }

    const aliases = this.lookupAliasesForAddress(address);
    const avgAmount = allAmounts.length > 0 ? allAmounts.reduce((a, b) => a + b, 0) / allAmounts.length : 0;
    const timeSpanDays = firstSeen < Infinity && lastSeen > 0 ? Math.max(1, (lastSeen - firstSeen) / (24 * 60 * 60 * 1000)) : 1;
    const velocity = txs.length / timeSpanDays;

    return {
      address,
      firstSeen: firstSeen === Infinity ? 0 : firstSeen,
      lastSeen,
      totalTransactionCount: txs.length,
      totalSent: parseFloat(totalSent.toFixed(8)),
      totalReceived: parseFloat(totalReceived.toFixed(8)),
      currentBalance: balance,
      associatedAliases: aliases,
      fundingSources: Array.from(fundingSources),
      fundingDestinations: Array.from(fundingDestinations),
      averageTransactionSize: parseFloat(avgAmount.toFixed(8)),
      largestTransaction: largestTx,
      transactionVelocity: parseFloat(velocity.toFixed(4)),
    };
  }

  private buildTransactionHistory(address: string): ForensicTransaction[] {
    const blockchain = getBlockchain();
    const txs = blockchain.getAddressTransactions(address);
    const history: ForensicTransaction[] = [];

    for (const { transaction, blockIndex } of txs) {
      const isOutbound = transaction.inputs.some(i => i.address === address);

      if (isOutbound) {
        for (const output of transaction.outputs) {
          if (output.address !== address) {
            history.push({
              hash: transaction.id,
              fromAddress: address,
              toAddress: output.address,
              amount: output.amount,
              timestamp: transaction.timestamp,
              blockIndex,
              direction: 'outbound',
              counterpartyAddress: output.address,
            });
          }
        }
      } else {
        for (const output of transaction.outputs) {
          if (output.address === address) {
            const senderAddress = transaction.inputs[0]?.address || 'COINBASE';
            history.push({
              hash: transaction.id,
              fromAddress: senderAddress,
              toAddress: address,
              amount: output.amount,
              timestamp: transaction.timestamp,
              blockIndex,
              direction: 'inbound',
              counterpartyAddress: senderAddress,
            });
          }
        }
      }
    }

    return history.sort((a, b) => b.timestamp - a.timestamp);
  }

  private buildConnectedWalletProfiles(address: string): ConnectedWalletProfile[] {
    const blockchain = getBlockchain();
    const txs = blockchain.getAddressTransactions(address);
    const walletMap = new Map<string, { interactions: number; totalFlow: number; firstTime: number; lastTime: number; relationships: Set<string> }>();

    for (const { transaction } of txs) {
      const isOutbound = transaction.inputs.some(i => i.address === address);

      if (isOutbound) {
        for (const output of transaction.outputs) {
          if (output.address !== address) {
            const existing = walletMap.get(output.address) || { interactions: 0, totalFlow: 0, firstTime: Infinity, lastTime: 0, relationships: new Set() };
            existing.interactions++;
            existing.totalFlow += output.amount;
            if (transaction.timestamp < existing.firstTime) existing.firstTime = transaction.timestamp;
            if (transaction.timestamp > existing.lastTime) existing.lastTime = transaction.timestamp;
            existing.relationships.add('direct_transfer');
            walletMap.set(output.address, existing);
          }
        }
      } else {
        for (const input of transaction.inputs) {
          if (input.address !== address && input.address !== 'COINBASE') {
            const existing = walletMap.get(input.address) || { interactions: 0, totalFlow: 0, firstTime: Infinity, lastTime: 0, relationships: new Set() };
            existing.interactions++;
            for (const output of transaction.outputs) {
              if (output.address === address) existing.totalFlow += output.amount;
            }
            if (transaction.timestamp < existing.firstTime) existing.firstTime = transaction.timestamp;
            if (transaction.timestamp > existing.lastTime) existing.lastTime = transaction.timestamp;
            existing.relationships.add('direct_transfer');
            walletMap.set(input.address, existing);
          }
        }
      }
    }

    const fundingSources = new Set<string>();
    for (const { transaction } of txs) {
      for (const input of transaction.inputs) {
        if (input.address !== address && input.address !== 'COINBASE') {
          fundingSources.add(input.address);
        }
      }
    }

    for (const source of Array.from(fundingSources)) {
      const sourceTxs = blockchain.getAddressTransactions(source);
      for (const { transaction } of sourceTxs) {
        for (const output of transaction.outputs) {
          if (output.address !== address && output.address !== source) {
            const existing = walletMap.get(output.address);
            if (existing) {
              existing.relationships.add('shared_funding_source');
            }
          }
        }
      }
    }

    const profiles: ConnectedWalletProfile[] = [];
    for (const [addr, data] of Array.from(walletMap.entries())) {
      const balance = blockchain.getBalance(addr);
      let suspicionScore = 0;

      if (data.interactions > 5) suspicionScore += 20;
      if (data.relationships.has('shared_funding_source')) suspicionScore += 30;
      if (data.relationships.has('circular_flow')) suspicionScore += 50;
      if (data.totalFlow > 10000) suspicionScore += 15;

      const addrTxs = blockchain.getAddressTransactions(addr);
      const addrIsOutbound = addrTxs.some(({ transaction }) =>
        transaction.inputs.some(i => i.address === addr) &&
        transaction.outputs.some(o => o.address === address)
      );
      const addrIsInbound = addrTxs.some(({ transaction }) =>
        transaction.inputs.some(i => i.address === address) &&
        transaction.outputs.some(o => o.address === addr)
      );
      if (addrIsOutbound && addrIsInbound) {
        suspicionScore += 40;
        data.relationships.add('circular_flow');
      }

      const primaryRelationship = data.relationships.has('circular_flow') ? 'circular_flow' as const
        : data.relationships.has('shared_funding_source') ? 'shared_funding_source' as const
        : data.relationships.has('common_destination') ? 'common_destination' as const
        : 'direct_transfer' as const;

      profiles.push({
        address: addr,
        relationship: primaryRelationship,
        interactionCount: data.interactions,
        totalFlowAmount: parseFloat(data.totalFlow.toFixed(8)),
        firstInteraction: data.firstTime === Infinity ? 0 : data.firstTime,
        lastInteraction: data.lastTime,
        currentBalance: balance,
        suspicionScore: Math.min(100, suspicionScore),
      });
    }

    return profiles.sort((a, b) => b.suspicionScore - a.suspicionScore);
  }

  private buildFundFlowMap(address: string, maxDepth: number = 10): { fromAddress: string; toAddress: string; amount: number; hash: string; timestamp: number; depth: number }[] {
    const blockchain = getBlockchain();
    const flowMap: { fromAddress: string; toAddress: string; amount: number; hash: string; timestamp: number; depth: number }[] = [];
    const visited = new Set<string>();

    const queue: { addr: string; depth: number }[] = [{ addr: address, depth: 0 }];

    while (queue.length > 0) {
      const { addr, depth } = queue.shift()!;
      if (depth >= maxDepth || visited.has(addr)) continue;
      visited.add(addr);

      const txs = blockchain.getAddressTransactions(addr);
      for (const { transaction } of txs) {
        const isOutbound = transaction.inputs.some(i => i.address === addr);
        if (!isOutbound) continue;

        for (const output of transaction.outputs) {
          if (output.address !== addr) {
            flowMap.push({
              fromAddress: addr,
              toAddress: output.address,
              amount: output.amount,
              hash: transaction.id,
              timestamp: transaction.timestamp,
              depth: depth + 1,
            });

            if (depth + 1 < maxDepth && !visited.has(output.address)) {
              queue.push({ addr: output.address, depth: depth + 1 });
            }
          }
        }
      }
    }

    return flowMap.sort((a, b) => a.depth - b.depth || b.timestamp - a.timestamp);
  }

  private analyzeForFraudIndicators(address: string, fingerprint: WalletFingerprint, connectedWallets: ConnectedWalletProfile[], txHistory: ForensicTransaction[]): { indicator: string; confidence: number; details: string }[] {
    const indicators: { indicator: string; confidence: number; details: string }[] = [];

    if (fingerprint.transactionVelocity > 10) {
      indicators.push({ indicator: 'High Transaction Velocity', confidence: 70, details: `${fingerprint.transactionVelocity.toFixed(1)} transactions per day — abnormally high activity suggests automated or laundering behavior` });
    }

    const circularWallets = connectedWallets.filter(w => w.relationship === 'circular_flow');
    if (circularWallets.length > 0) {
      indicators.push({ indicator: 'Circular Fund Flow Detected', confidence: 90, details: `${circularWallets.length} wallet(s) show bidirectional fund flow: ${circularWallets.map(w => w.address.substring(0, 16) + '...').join(', ')}` });
    }

    const sharedFunding = connectedWallets.filter(w => w.relationship === 'shared_funding_source');
    if (sharedFunding.length > 2) {
      indicators.push({ indicator: 'Shared Funding Sources', confidence: 75, details: `${sharedFunding.length} wallets share common funding origin — suggests same entity controlling multiple wallets` });
    }

    const recentTxs = txHistory.filter(t => t.timestamp > Date.now() - (24 * 60 * 60 * 1000));
    if (recentTxs.length > 20) {
      indicators.push({ indicator: 'Burst Activity', confidence: 65, details: `${recentTxs.length} transactions in last 24 hours — potential rapid fund dispersal` });
    }

    if (fingerprint.currentBalance === 0 && fingerprint.totalReceived > 0) {
      indicators.push({ indicator: 'Empty Wallet — Funds Drained', confidence: 60, details: `Wallet received ${fingerprint.totalReceived} ${COIN_TICKER} total but current balance is 0 — funds have been fully withdrawn` });
    }

    const claimsForAddress = Array.from(this.claims.values()).filter(c => c.claimantAddress === address);
    const fraudulentClaims = claimsForAddress.filter(c => c.status === 'fraudulent');
    if (fraudulentClaims.length > 0) {
      indicators.push({ indicator: 'Prior Fraudulent Claims', confidence: 95, details: `${fraudulentClaims.length} previous fraudulent claim(s) from this address` });
    }

    if (this.invalidatedAddresses.has(address)) {
      indicators.push({ indicator: 'Address Previously Invalidated', confidence: 100, details: 'This address has been permanently invalidated by a prior tamper self-destruct event' });
    }

    const smallTxCount = txHistory.filter(t => t.amount < 1).length;
    if (smallTxCount > txHistory.length * 0.7 && txHistory.length > 10) {
      indicators.push({ indicator: 'Micro-Transaction Pattern', confidence: 55, details: `${smallTxCount}/${txHistory.length} transactions are under 1 ${COIN_TICKER} — potential structuring to avoid detection` });
    }

    return indicators.sort((a, b) => b.confidence - a.confidence);
  }

  private lookupAliasesForAddress(address: string): string[] {
    try {
      const { reverseLookup } = require('./safeSend.js');
      const result = reverseLookup(address);
      if (result && !('error' in result)) {
        return [result.alias];
      }
    } catch {}
    return [];
  }

  private emitAdminAlert(severity: ForensicSeverity, title: string, summary: string, dossierId: string): void {
    const alertId = `ALERT_${crypto.createHash('sha256').update(`alert:${dossierId}:${Date.now()}`).digest('hex').substring(0, 16).toUpperCase()}`;
    this.adminAlerts.push({
      id: alertId,
      timestamp: Date.now(),
      severity,
      title,
      summary,
      dossierId,
      acknowledged: false,
    });
    console.log(`[ACIP ALERT] ${severity.toUpperCase()}: ${title}`);
  }

  getForensicDossier(dossierId: string): ForensicDossier | undefined {
    return this.forensicDossiers.get(dossierId);
  }

  getAllForensicDossiers(): ForensicDossier[] {
    return Array.from(this.forensicDossiers.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  getDossiersByAddress(address: string): ForensicDossier[] {
    return Array.from(this.forensicDossiers.values())
      .filter(d => d.primaryAddress === address)
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  getDossiersBySeverity(severity: ForensicSeverity): ForensicDossier[] {
    return Array.from(this.forensicDossiers.values())
      .filter(d => d.severity === severity)
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  updateDossierStatus(dossierId: string, status: 'active' | 'under_review' | 'referred_to_legal' | 'resolved'): ForensicDossier | { error: string } {
    const dossier = this.forensicDossiers.get(dossierId);
    if (!dossier) return { error: 'Dossier not found' };
    dossier.status = status;
    dossier.updatedAt = Date.now();
    if (status === 'referred_to_legal') dossier.legalReferralReady = true;
    return dossier;
  }

  addDossierNote(dossierId: string, note: string): ForensicDossier | { error: string } {
    const dossier = this.forensicDossiers.get(dossierId);
    if (!dossier) return { error: 'Dossier not found' };
    dossier.adminNotes.push(`[${new Date().toISOString()}] ${note}`);
    dossier.updatedAt = Date.now();
    return dossier;
  }

  getAdminAlerts(unacknowledgedOnly: boolean = false): typeof this.adminAlerts {
    const alerts = unacknowledgedOnly ? this.adminAlerts.filter(a => !a.acknowledged) : this.adminAlerts;
    return [...alerts].sort((a, b) => b.timestamp - a.timestamp);
  }

  acknowledgeAlert(alertId: string): { success: boolean } {
    const alert = this.adminAlerts.find(a => a.id === alertId);
    if (!alert) return { success: false };
    alert.acknowledged = true;
    return { success: true };
  }

  getForensicStats(): { totalDossiers: number; activeDossiers: number; criticalDossiers: number; legalReferrals: number; unacknowledgedAlerts: number; totalBurned: number; invalidatedAddresses: number } {
    const dossiers = Array.from(this.forensicDossiers.values());
    return {
      totalDossiers: dossiers.length,
      activeDossiers: dossiers.filter(d => d.status === 'active').length,
      criticalDossiers: dossiers.filter(d => d.severity === 'critical').length,
      legalReferrals: dossiers.filter(d => d.status === 'referred_to_legal').length,
      unacknowledgedAlerts: this.adminAlerts.filter(a => !a.acknowledged).length,
      totalBurned: this.tamperEvents.reduce((sum, e) => sum + e.burnedAmount, 0),
      invalidatedAddresses: this.invalidatedAddresses.size,
    };
  }

  getVaultStats(): VaultStats {
    const allClaims = Array.from(this.claims.values());
    const allValidators = Array.from(this.validators.values());

    return {
      vaultAddress: VAULT_ADDRESS,
      totalBalance: this.vaultBalance,
      totalDeposits: this.totalDeposits,
      totalPayouts: this.totalPayouts,
      totalClaims: allClaims.length,
      activeClaims: allClaims.filter(c => ['pending', 'investigating', 'jury_vote'].includes(c.status)).length,
      approvedClaims: allClaims.filter(c => c.status === 'approved' || c.status === 'paid').length,
      deniedClaims: allClaims.filter(c => c.status === 'denied').length,
      fraudulentClaims: allClaims.filter(c => c.status === 'fraudulent').length,
      activeValidators: allValidators.filter(b => b.status === 'active').length,
      triggeredValidators: allValidators.filter(b => b.status === 'triggered').length,
      ticker: COIN_TICKER,
    };
  }
}

let vaultInstance: InsuranceVaultService | null = null;

export function getInsuranceVault(): InsuranceVaultService {
  if (!vaultInstance) {
    vaultInstance = new InsuranceVaultService();
  }
  return vaultInstance;
}
