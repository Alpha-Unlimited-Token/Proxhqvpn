import {
  Block, BlockHeader, Transaction,
  calculateBlockHash, calculateMerkleRoot, createGenesisBlock,
  createCoinbaseTransaction, generateTransactionId,
} from './block.js';
import { verifySignature, signData } from './wallet.js';
import {
  calculateBlockReward, calculateDifficulty, meetsTarget, calculateTransactionFee,
  DIFFICULTY_ADJUSTMENT_INTERVAL, MAX_TRANSACTIONS_PER_BLOCK,
  COIN_NAME, COIN_TICKER, FOUNDER_ALLOCATION, BURN_ADDRESS, MAX_SUPPLY,
  INITIAL_DIFFICULTY,
} from './consensus.js';
import { getFounderAddress, getVestingSchedule } from './founder.js';
import { getForensicHookEngine } from './forensicHooks.js';

const MAX_BLOCK_TIMESTAMP_DRIFT_MS = 2 * 60 * 60 * 1000;

export class AlphaBlockchain {
  public chain: Block[] = [];
  public mempool: Transaction[] = [];
  public balances: Map<string, number> = new Map();
  public founderAddress: string;
  public genesisHash: string;
  private miningLock: boolean = false;

  constructor() {
    this.founderAddress = getFounderAddress();
    const genesis = createGenesisBlock(this.founderAddress, FOUNDER_ALLOCATION);
    this.chain.push(genesis);
    this.genesisHash = genesis.hash;
    this.processBlockTransactions(genesis);
    console.log(`[${COIN_NAME}] Blockchain initialized with genesis block`);
    console.log(`[${COIN_NAME}] Ticker: ${COIN_TICKER} | Genesis hash: ${genesis.hash.substring(0, 16)}...`);
    console.log(`[${COIN_NAME}] Founder wallet: ${this.founderAddress} | Pre-mine: ${FOUNDER_ALLOCATION.toLocaleString()} ${COIN_TICKER}`);
  }

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1];
  }

  getBlockByIndex(index: number): Block | undefined {
    return this.chain[index];
  }

  getBlockByHash(hash: string): Block | undefined {
    return this.chain.find(b => b.hash === hash);
  }

  getChainHeight(): number {
    return this.chain.length - 1;
  }

  getCurrentDifficulty(): number {
    const latest = this.getLatestBlock();
    const height = this.getChainHeight();

    if (height % DIFFICULTY_ADJUSTMENT_INTERVAL === 0 && height > 0) {
      const recentBlocks = this.chain.slice(-DIFFICULTY_ADJUSTMENT_INTERVAL).map(b => ({
        timestamp: b.header.timestamp,
      }));
      return calculateDifficulty(latest.header.difficulty, recentBlocks, height);
    }

    return latest.header.difficulty;
  }

  getBalance(address: string): number {
    return this.balances.get(address) || 0;
  }

  getAllBalances(): Map<string, number> {
    return new Map(this.balances);
  }

  getTransactionById(txId: string): { transaction: Transaction; blockIndex: number } | undefined {
    for (const block of this.chain) {
      const tx = block.transactions.find(t => t.id === txId);
      if (tx) return { transaction: tx, blockIndex: block.index };
    }
    return undefined;
  }

  getAddressTransactions(address: string): { transaction: Transaction; blockIndex: number }[] {
    const results: { transaction: Transaction; blockIndex: number }[] = [];
    for (const block of this.chain) {
      for (const tx of block.transactions) {
        const isInvolved = tx.inputs.some(i => i.address === address) ||
                           tx.outputs.some(o => o.address === address);
        if (isInvolved) {
          results.push({ transaction: tx, blockIndex: block.index });
        }
      }
    }
    return results;
  }

  getTotalBurned(): number {
    return this.getBalance(BURN_ADDRESS);
  }

  getSpendableBalance(address: string): number {
    const balance = this.getBalance(address);
    if (address === this.founderAddress) {
      const vesting = getVestingSchedule();
      const lockedAmount = vesting.totalLocked;
      return Math.max(0, balance - lockedAmount);
    }
    return balance;
  }

  createTransaction(
    fromAddress: string,
    toAddress: string,
    amount: number,
    privateKey: string,
    publicKey: string
  ): Transaction | { error: string } {
    if (amount <= 0) return { error: 'Amount must be positive' };

    const balance = this.getBalance(fromAddress);
    const fee = calculateTransactionFee(amount);
    const totalNeeded = amount + fee;

    if (fromAddress === this.founderAddress) {
      const spendable = this.getSpendableBalance(fromAddress);
      if (totalNeeded > spendable) {
        const vesting = getVestingSchedule();
        return { error: `Vesting restriction: Only ${spendable.toLocaleString()} ${COIN_TICKER} unlocked. ${vesting.totalLocked.toLocaleString()} ${COIN_TICKER} still locked until vesting schedule releases them.` };
      }
    }

    if (balance < totalNeeded) {
      return { error: `Insufficient balance. Have ${balance} ${COIN_TICKER}, need ${totalNeeded} ${COIN_TICKER} (${amount} + ${fee} fee)` };
    }

    const txData: Omit<Transaction, 'id'> = {
      type: 'transfer',
      timestamp: Date.now(),
      inputs: [{
        txId: 'balance',
        outputIndex: 0,
        address: fromAddress,
      }],
      outputs: [
        { address: toAddress, amount },
        { address: fromAddress, amount: parseFloat((balance - totalNeeded).toFixed(8)) },
      ],
    };

    const txId = generateTransactionId(txData);

    const txForSigning: Transaction = { ...txData, id: txId } as Transaction;
    const sigPayload = AlphaBlockchain.getSigningPayload(txForSigning);

    const signature = signData(privateKey, sigPayload);

    if (!signature) {
      return { error: 'Failed to sign transaction' };
    }

    const transaction: Transaction = {
      ...txData,
      id: txId,
      signature,
      publicKey,
    };

    this.mempool.push(transaction);
    return transaction;
  }

  static getSigningPayload(tx: Transaction): string {
    return JSON.stringify({
      id: tx.id,
      type: tx.type,
      timestamp: tx.timestamp,
      inputs: tx.inputs,
      outputs: tx.outputs,
    });
  }

  addTransactionToMempool(tx: Transaction): boolean | { error: string } {
    if (tx.type === 'coinbase') return { error: 'Cannot add coinbase to mempool' };

    if (this.mempool.find(t => t.id === tx.id)) {
      return { error: 'Transaction already in mempool' };
    }

    if (!tx.signature || !tx.publicKey) {
      return { error: 'Transaction must be signed (signature and publicKey required)' };
    }

    const sigPayload = AlphaBlockchain.getSigningPayload(tx);
    const isValid = verifySignature(tx.publicKey, sigPayload, tx.signature);
    if (!isValid) {
      return { error: 'Invalid transaction signature' };
    }

    const fromAddress = tx.inputs[0]?.address;
    if (fromAddress) {
      const pendingSpent = this.mempool
        .filter(m => m.inputs.some(i => i.address === fromAddress))
        .reduce((s, m) => {
          const recipientOutputs = m.outputs.filter(o => o.address !== fromAddress);
          const amount = recipientOutputs.reduce((ts, o) => ts + o.amount, 0);
          return s + amount + calculateTransactionFee(amount);
        }, 0);

      const recipientOutputs = tx.outputs.filter(o => o.address !== fromAddress);
      const txAmount = recipientOutputs.reduce((s, o) => s + o.amount, 0);
      const txFee = calculateTransactionFee(txAmount);
      const balance = this.getBalance(fromAddress);

      if (txAmount + txFee + pendingSpent > balance) {
        return { error: 'Insufficient balance for transaction (including pending spends)' };
      }
    }

    this.mempool.push(tx);
    return true;
  }

  mineBlock(minerAddress: string): Block | { error: string } {
    if (this.miningLock) {
      return { error: 'Mining already in progress' };
    }
    this.miningLock = true;

    try {
      return this._mineBlockSync(minerAddress);
    } finally {
      this.miningLock = false;
    }
  }

  private _mineBlockSync(minerAddress: string): Block | { error: string } {
    const height = this.getChainHeight() + 1;
    const difficulty = this.getCurrentDifficulty();
    const previousBlock = this.getLatestBlock();

    const pendingTxs = this.mempool.slice(0, MAX_TRANSACTIONS_PER_BLOCK - 1);
    const totalFees = this.calculateMempoolFees(pendingTxs);
    const reward = calculateBlockReward(height) + totalFees;

    const coinbaseTx = createCoinbaseTransaction(minerAddress, reward, height);

    const blockTransactions = [coinbaseTx, ...pendingTxs];

    const merkleRoot = calculateMerkleRoot(blockTransactions);

    const header: BlockHeader = {
      version: 1,
      previousHash: previousBlock.hash,
      merkleRoot,
      timestamp: Date.now(),
      difficulty,
      nonce: 0,
    };

    const startTime = Date.now();
    let hash = '';
    let attempts = 0;

    while (true) {
      hash = calculateBlockHash(header);
      attempts++;

      if (meetsTarget(hash, difficulty)) {
        break;
      }

      header.nonce++;

      if (header.nonce > 0xFFFFFFFF) {
        header.nonce = 0;
        header.timestamp = Date.now();
      }

      if (attempts % 100000 === 0) {
        header.timestamp = Date.now();
      }
    }

    const miningTime = Date.now() - startTime;

    const block: Block = {
      index: height,
      header,
      hash,
      transactions: blockTransactions,
      size: JSON.stringify(blockTransactions).length,
    };

    if (!this.validateBlock(block, previousBlock)) {
      return { error: 'Block validation failed after mining' };
    }

    this.chain.push(block);
    this.processBlockTransactions(block);

    const minedTxIds = new Set(blockTransactions.filter(tx => tx.type !== 'coinbase').map(tx => tx.id));
    this.mempool = this.mempool.filter(tx => !minedTxIds.has(tx.id));

    console.log(`[${COIN_NAME}] Block #${height} mined | Hash: ${hash.substring(0, 16)}... | Nonce: ${header.nonce} | ${attempts} attempts | ${miningTime}ms | ${blockTransactions.length} txs | Reward: ${reward} ${COIN_TICKER}`);

    return block;
  }

  async mineBlockAsync(minerAddress: string): Promise<Block | { error: string }> {
    if (this.miningLock) {
      return { error: 'Mining already in progress' };
    }
    this.miningLock = true;

    try {
      return await this._mineBlockAsyncInternal(minerAddress);
    } finally {
      this.miningLock = false;
    }
  }

  private async _mineBlockAsyncInternal(minerAddress: string): Promise<Block | { error: string }> {
    const height = this.getChainHeight() + 1;
    const difficulty = this.getCurrentDifficulty();
    const previousBlock = this.getLatestBlock();

    const pendingTxs = this.mempool.slice(0, MAX_TRANSACTIONS_PER_BLOCK - 1);
    const totalFees = this.calculateMempoolFees(pendingTxs);
    const reward = calculateBlockReward(height) + totalFees;

    const coinbaseTx = createCoinbaseTransaction(minerAddress, reward, height);
    const blockTransactions = [coinbaseTx, ...pendingTxs];
    const merkleRoot = calculateMerkleRoot(blockTransactions);

    const header: BlockHeader = {
      version: 1,
      previousHash: previousBlock.hash,
      merkleRoot,
      timestamp: Date.now(),
      difficulty,
      nonce: 0,
    };

    const startTime = Date.now();
    let hash = '';
    let attempts = 0;
    const BATCH_SIZE = 10000;

    const mineChunk = (): Promise<void> => {
      return new Promise((resolve) => {
        for (let i = 0; i < BATCH_SIZE; i++) {
          hash = calculateBlockHash(header);
          attempts++;

          if (meetsTarget(hash, difficulty)) {
            return resolve();
          }

          header.nonce++;
          if (header.nonce > 0xFFFFFFFF) {
            header.nonce = 0;
            header.timestamp = Date.now();
          }
        }

        header.timestamp = Date.now();
        setImmediate(() => mineChunk().then(resolve));
      });
    };

    await mineChunk();

    const miningTime = Date.now() - startTime;

    const block: Block = {
      index: height,
      header,
      hash,
      transactions: blockTransactions,
      size: JSON.stringify(blockTransactions).length,
    };

    if (!this.validateBlock(block, previousBlock)) {
      return { error: 'Block validation failed after mining' };
    }

    this.chain.push(block);
    this.processBlockTransactions(block);

    const minedTxIds = new Set(blockTransactions.filter(tx => tx.type !== 'coinbase').map(tx => tx.id));
    this.mempool = this.mempool.filter(tx => !minedTxIds.has(tx.id));

    console.log(`[${COIN_NAME}] Block #${height} mined (async) | Hash: ${hash.substring(0, 16)}... | Nonce: ${header.nonce} | ${attempts} attempts | ${miningTime}ms | ${blockTransactions.length} txs | Reward: ${reward} ${COIN_TICKER}`);

    return block;
  }

  private calculateMempoolFees(transactions: Transaction[]): number {
    let totalFees = 0;
    for (const tx of transactions) {
      if (tx.type === 'coinbase') continue;
      const recipientOutputs = tx.outputs.filter(o => o.address !== tx.inputs[0]?.address);
      const txAmount = recipientOutputs.reduce((s, o) => s + o.amount, 0);
      totalFees += calculateTransactionFee(txAmount);
    }
    return parseFloat(totalFees.toFixed(8));
  }

  processBlockTransactions(block: Block): void {
    for (const tx of block.transactions) {
      if (tx.type === 'coinbase') {
        for (const output of tx.outputs) {
          const current = this.balances.get(output.address) || 0;
          this.balances.set(output.address, parseFloat((current + output.amount).toFixed(8)));
        }
      } else {
        const senderAddress = tx.inputs[0]?.address;
        if (senderAddress) {
          const changeOutput = tx.outputs.find(o => o.address === senderAddress);
          const changeAmount = changeOutput ? changeOutput.amount : 0;
          this.balances.set(senderAddress, parseFloat(changeAmount.toFixed(8)));
        }
        for (const output of tx.outputs) {
          if (output.address === tx.inputs[0]?.address) continue;
          const current = this.balances.get(output.address) || 0;
          this.balances.set(output.address, parseFloat((current + output.amount).toFixed(8)));
        }

        try {
          const fromAddr = tx.inputs[0]?.address || '';
          const recipientOutputs = tx.outputs.filter(o => o.address !== fromAddr);
          for (const output of recipientOutputs) {
            const fee = calculateTransactionFee(output.amount);
            getForensicHookEngine().processTransferHook(
              tx.id, block.index, tx.timestamp,
              fromAddr, output.address, output.amount, fee
            );
          }
        } catch (hookErr) {
          // Forensic hooks are non-blocking — never prevent transaction processing
        }
      }
    }
  }

  validateBlock(block: Block, previousBlock: Block): boolean {
    if (block.index !== previousBlock.index + 1) return false;
    if (block.header.previousHash !== previousBlock.hash) return false;

    const calculatedHash = calculateBlockHash(block.header);
    if (calculatedHash !== block.hash) return false;

    if (!meetsTarget(block.hash, block.header.difficulty)) return false;

    const calculatedMerkle = calculateMerkleRoot(block.transactions);
    if (calculatedMerkle !== block.header.merkleRoot) return false;

    if (block.transactions.length === 0) return false;
    if (block.transactions[0].type !== 'coinbase') return false;

    const now = Date.now();
    if (block.header.timestamp > now + MAX_BLOCK_TIMESTAMP_DRIFT_MS) return false;
    if (block.header.timestamp < previousBlock.header.timestamp - MAX_BLOCK_TIMESTAMP_DRIFT_MS) return false;

    return true;
  }

  isChainValid(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      if (!this.validateBlock(this.chain[i], this.chain[i - 1])) {
        return false;
      }
    }
    return true;
  }

  getChainStats() {
    const height = this.getChainHeight();
    const totalTransactions = this.chain.reduce((s, b) => s + b.transactions.length, 0);
    const totalSupply = Array.from(this.balances.values()).reduce((s, v) => s + v, 0);
    const latestBlock = this.getLatestBlock();
    const uniqueAddresses = this.balances.size;

    let totalMiningTime = 0;
    for (let i = 1; i < this.chain.length; i++) {
      totalMiningTime += this.chain[i].header.timestamp - this.chain[i - 1].header.timestamp;
    }
    const avgBlockTime = height > 0 ? totalMiningTime / height : 0;

    return {
      coinName: COIN_NAME,
      ticker: COIN_TICKER,
      chainHeight: height,
      totalBlocks: this.chain.length,
      totalTransactions,
      totalSupply: parseFloat(totalSupply.toFixed(8)),
      maxSupply: MAX_SUPPLY,
      currentDifficulty: parseFloat(this.getCurrentDifficulty().toFixed(4)),
      currentTarget: getDifficultyTarget(this.getCurrentDifficulty()),
      currentReward: calculateBlockReward(height + 1),
      mempoolSize: this.mempool.length,
      uniqueAddresses,
      averageBlockTime: Math.round(avgBlockTime),
      latestBlockHash: latestBlock.hash,
      latestBlockTime: latestBlock.header.timestamp,
      genesisHash: this.chain[0].hash,
      isValid: this.isChainValid(),
      founderAddress: this.founderAddress,
      founderBalance: this.getBalance(this.founderAddress),
      founderAllocation: FOUNDER_ALLOCATION,
      burnAddress: BURN_ADDRESS,
      totalBurned: this.getTotalBurned(),
      circulatingSupply: parseFloat((totalSupply - this.getTotalBurned()).toFixed(8)),
    };
  }

  getRecentBlocks(count: number = 10): Block[] {
    return this.chain.slice(-count).reverse();
  }
}

import { getDifficultyTarget } from './consensus.js';

let blockchainInstance: AlphaBlockchain | null = null;

export function getBlockchain(): AlphaBlockchain {
  if (!blockchainInstance) {
    blockchainInstance = new AlphaBlockchain();
    const bc = blockchainInstance;
    import('./spider.js').then(({ initializeSpider }) => {
      initializeSpider(bc!);
      console.log(`[${COIN_NAME}] Autonomous Blockchain Spider™ activated`);
    }).catch(err => {
      console.error(`[${COIN_NAME}] Spider initialization failed:`, err);
    });
  }
  return blockchainInstance;
}
