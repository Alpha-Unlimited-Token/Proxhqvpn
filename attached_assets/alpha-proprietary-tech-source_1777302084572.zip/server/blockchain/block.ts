import crypto from 'crypto';
import { INITIAL_DIFFICULTY } from './consensus.js';

export interface BlockHeader {
  version: number;
  previousHash: string;
  merkleRoot: string;
  timestamp: number;
  difficulty: number;
  nonce: number;
}

export interface Block {
  index: number;
  header: BlockHeader;
  hash: string;
  transactions: Transaction[];
  size: number;
}

export interface Transaction {
  id: string;
  type: 'coinbase' | 'transfer';
  timestamp: number;
  inputs: TxInput[];
  outputs: TxOutput[];
  signature?: string;
  publicKey?: string;
}

export interface TxInput {
  txId: string;
  outputIndex: number;
  address: string;
}

export interface TxOutput {
  address: string;
  amount: number;
}

export function calculateHash(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

export function doubleHash(data: string): string {
  const first = crypto.createHash('sha256').update(data).digest();
  return crypto.createHash('sha256').update(first).digest('hex');
}

export function calculateBlockHash(header: BlockHeader): string {
  const headerString = `${header.version}${header.previousHash}${header.merkleRoot}${header.timestamp}${header.difficulty}${header.nonce}`;
  return doubleHash(headerString);
}

export function calculateMerkleRoot(transactions: Transaction[]): string {
  if (transactions.length === 0) return calculateHash('');

  let hashes = transactions.map(tx => calculateHash(tx.id));

  while (hashes.length > 1) {
    const newHashes: string[] = [];
    for (let i = 0; i < hashes.length; i += 2) {
      const left = hashes[i];
      const right = i + 1 < hashes.length ? hashes[i + 1] : left;
      newHashes.push(doubleHash(left + right));
    }
    hashes = newHashes;
  }

  return hashes[0];
}

export function generateTransactionId(tx: Omit<Transaction, 'id'>): string {
  const data = JSON.stringify({
    type: tx.type,
    timestamp: tx.timestamp,
    inputs: tx.inputs,
    outputs: tx.outputs,
  });
  return calculateHash(data);
}

export function createCoinbaseTransaction(minerAddress: string, reward: number, blockIndex: number): Transaction {
  const txData: Omit<Transaction, 'id'> = {
    type: 'coinbase',
    timestamp: Date.now(),
    inputs: [{
      txId: '0'.repeat(64),
      outputIndex: blockIndex,
      address: 'COINBASE',
    }],
    outputs: [{
      address: minerAddress,
      amount: reward,
    }],
  };

  return {
    ...txData,
    id: generateTransactionId(txData),
  };
}

const GENESIS_TIMESTAMP = 1740787200000;

export function createGenesisBlock(founderAddress?: string, founderAllocation?: number): Block {
  const coinbaseData: Omit<Transaction, 'id'> = {
    type: 'coinbase',
    timestamp: GENESIS_TIMESTAMP,
    inputs: [{
      txId: '0'.repeat(64),
      outputIndex: 0,
      address: 'COINBASE',
    }],
    outputs: [{
      address: 'ALPHA_GENESIS_000000000000000000000000000000',
      amount: 50,
    }],
  };
  const coinbaseTx: Transaction = {
    ...coinbaseData,
    id: generateTransactionId(coinbaseData),
  };

  const transactions: Transaction[] = [coinbaseTx];

  if (founderAddress && founderAllocation && founderAllocation > 0) {
    const premineData: Omit<Transaction, 'id'> = {
      type: 'coinbase',
      timestamp: GENESIS_TIMESTAMP,
      inputs: [{
        txId: '0'.repeat(64),
        outputIndex: -1,
        address: 'FOUNDER_PREMINE',
      }],
      outputs: [{
        address: founderAddress,
        amount: founderAllocation,
      }],
    };
    const premineTx: Transaction = {
      ...premineData,
      id: generateTransactionId(premineData),
    };
    transactions.push(premineTx);
  }

  const merkleRoot = calculateMerkleRoot(transactions);

  const header: BlockHeader = {
    version: 1,
    previousHash: '0'.repeat(64),
    merkleRoot,
    timestamp: GENESIS_TIMESTAMP,
    difficulty: INITIAL_DIFFICULTY,
    nonce: 0,
  };

  const hash = calculateBlockHash(header);

  return {
    index: 0,
    header,
    hash,
    transactions,
    size: JSON.stringify(transactions).length,
  };
}
