import crypto from 'crypto';
import { calculateHash } from './block.js';

export interface AlphaWallet {
  address: string;
  publicKey: string;
  privateKey: string;
  createdAt: number;
}

const ADDRESS_PREFIX = 'ALPHA';
const ADDRESS_VERSION = '01';

export function generateKeyPair(): { publicKey: string; privateKey: string } {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
    namedCurve: 'secp256k1',
    publicKeyEncoding: { type: 'spki', format: 'der' },
    privateKeyEncoding: { type: 'pkcs8', format: 'der' },
  });
  return {
    publicKey: publicKey.toString('hex'),
    privateKey: privateKey.toString('hex'),
  };
}

export function deriveAddress(publicKey: string): string {
  const sha256Hash = calculateHash(publicKey);
  const ripemd = crypto.createHash('ripemd160').update(Buffer.from(sha256Hash, 'hex')).digest('hex');
  const versionedPayload = ADDRESS_VERSION + ripemd;
  const checksum = calculateHash(calculateHash(versionedPayload)).substring(0, 8);
  const rawAddress = versionedPayload + checksum;
  return `${ADDRESS_PREFIX}_${rawAddress.substring(0, 40).toUpperCase()}`;
}

export function createWallet(): AlphaWallet {
  const { publicKey, privateKey } = generateKeyPair();
  const address = deriveAddress(publicKey);

  return {
    address,
    publicKey,
    privateKey,
    createdAt: Date.now(),
  };
}

export function signData(privateKeyHex: string, data: string): string {
  try {
    const privateKeyDer = Buffer.from(privateKeyHex, 'hex');
    const privateKeyObj = crypto.createPrivateKey({
      key: privateKeyDer,
      format: 'der',
      type: 'pkcs8',
    });
    const sign = crypto.createSign('SHA256');
    sign.update(data);
    sign.end();
    return sign.sign(privateKeyObj).toString('hex');
  } catch {
    return '';
  }
}

export function verifySignature(publicKeyHex: string, data: string, signature: string): boolean {
  try {
    const publicKeyDer = Buffer.from(publicKeyHex, 'hex');
    const publicKeyObj = crypto.createPublicKey({
      key: publicKeyDer,
      format: 'der',
      type: 'spki',
    });
    const verify = crypto.createVerify('SHA256');
    verify.update(data);
    verify.end();
    return verify.verify(publicKeyObj, Buffer.from(signature, 'hex'));
  } catch {
    return false;
  }
}
