import crypto from "crypto";

export interface NFTMetadata {
  name: string;
  description: string;
  image: string;
  attributes: Array<{ trait_type: string; value: string }>;
  properties: {
    category: string;
    creators: Array<{ address: string; share: number }>;
  };
  collection?: {
    name: string;
    family: string;
  };
  seller_fee_basis_points?: number;
}

export interface MintResult {
  success: boolean;
  transactionHash?: string;
  tokenAddress?: string;
  metadataUri?: string;
  ipfsImageCid?: string;
  ipfsMetadataCid?: string;
  onChainId?: string;
  error?: string;
}

export function buildNFTMetadata(params: {
  name: string;
  description: string;
  imageUri: string;
  traits: string[];
  rarity: string;
  blockchain: string;
  creatorWallet: string;
  element?: string | null;
  background?: string | null;
  accessory?: string | null;
  style?: string | null;
}): NFTMetadata {
  const attributes: Array<{ trait_type: string; value: string }> = [];

  attributes.push({ trait_type: "Rarity", value: params.rarity });
  if (params.element) attributes.push({ trait_type: "Element", value: params.element });
  if (params.background) attributes.push({ trait_type: "Background", value: params.background });
  if (params.accessory) attributes.push({ trait_type: "Accessory", value: params.accessory });
  if (params.style) attributes.push({ trait_type: "Style", value: params.style });
  attributes.push({ trait_type: "Blockchain", value: params.blockchain });

  for (const trait of params.traits) {
    if (trait.includes(":")) {
      const [key, val] = trait.split(":");
      attributes.push({ trait_type: key.trim(), value: val.trim() });
    } else {
      attributes.push({ trait_type: "Trait", value: trait });
    }
  }

  return {
    name: params.name,
    description: params.description,
    image: params.imageUri,
    attributes,
    properties: {
      category: "image",
      creators: [{ address: params.creatorWallet, share: 100 }],
    },
    collection: {
      name: "Alpha Unlimited NFT",
      family: "Alpha Unlimited",
    },
    seller_fee_basis_points: 500,
  };
}

export async function uploadToIPFS(
  data: Buffer | string,
  filename: string,
  contentType: string = "application/octet-stream"
): Promise<{ cid: string; uri: string }> {
  const pinataApiKey = process.env.PINATA_API_KEY;
  const pinataSecretKey = process.env.PINATA_SECRET_KEY;

  if (pinataApiKey && pinataSecretKey) {
    const boundary = `----FormBoundary${crypto.randomBytes(16).toString("hex")}`;
    const dataBuffer = typeof data === "string" ? Buffer.from(data) : data;

    const bodyParts: Buffer[] = [];

    bodyParts.push(Buffer.from(
      `--${boundary}\r\n` +
      `Content-Disposition: form-data; name="file"; filename="${filename}"\r\n` +
      `Content-Type: ${contentType}\r\n\r\n`
    ));
    bodyParts.push(dataBuffer);
    bodyParts.push(Buffer.from(`\r\n--${boundary}--\r\n`));

    const body = Buffer.concat(bodyParts);

    const response = await fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", {
      method: "POST",
      headers: {
        "pinata_api_key": pinataApiKey,
        "pinata_secret_api_key": pinataSecretKey,
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
      },
      body,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Pinata upload failed: ${errorText}`);
    }

    const result = await response.json() as any;
    return {
      cid: result.IpfsHash,
      uri: `ipfs://${result.IpfsHash}`,
    };
  }

  throw new Error(
    "IPFS upload unavailable: Pinata API keys (PINATA_API_KEY, PINATA_SECRET_KEY) are not configured. " +
    "Cannot store NFT data without a real IPFS provider."
  );
}

export async function uploadImageToIPFS(imageBase64: string, name: string): Promise<{ cid: string; uri: string }> {
  const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, "");
  const imageBuffer = Buffer.from(base64Data, "base64");
  const sanitizedName = name.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  return uploadToIPFS(imageBuffer, `${sanitizedName}.png`, "image/png");
}

export async function uploadMetadataToIPFS(metadata: NFTMetadata, name: string): Promise<{ cid: string; uri: string }> {
  const metadataJson = JSON.stringify(metadata, null, 2);
  const sanitizedName = name.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  return uploadToIPFS(metadataJson, `${sanitizedName}_metadata.json`, "application/json");
}

export function getMintInstructions(blockchain: string): {
  network: string;
  standard: string;
  instructions: string[];
  explorerUrl: string;
} {
  const configs: Record<string, { network: string; standard: string; instructions: string[]; explorerUrl: string }> = {
    sol: {
      network: "Solana Mainnet",
      standard: "Metaplex NFT Standard",
      instructions: [
        "Connect your Phantom or Solflare wallet",
        "Approve the minting transaction (gas fee ~0.01 SOL)",
        "NFT will be minted directly to your wallet",
        "View on Solana Explorer after confirmation",
      ],
      explorerUrl: "https://explorer.solana.com/tx/",
    },
    eth: {
      network: "Ethereum Mainnet",
      standard: "ERC-721",
      instructions: [
        "Connect your MetaMask or WalletConnect wallet",
        "Approve the minting transaction (gas fee varies)",
        "NFT will be minted as an ERC-721 token to your wallet",
        "View on Etherscan after confirmation",
      ],
      explorerUrl: "https://etherscan.io/tx/",
    },
    bnbbsc: {
      network: "BNB Smart Chain",
      standard: "BEP-721",
      instructions: [
        "Connect your MetaMask wallet (BSC network)",
        "Approve the minting transaction (gas fee ~0.001 BNB)",
        "NFT will be minted as a BEP-721 token to your wallet",
        "View on BscScan after confirmation",
      ],
      explorerUrl: "https://bscscan.com/tx/",
    },
    matic: {
      network: "Polygon Mainnet",
      standard: "ERC-721 (Polygon)",
      instructions: [
        "Connect your MetaMask wallet (Polygon network)",
        "Approve the minting transaction (gas fee < $0.01)",
        "NFT will be minted as an ERC-721 token on Polygon",
        "View on PolygonScan after confirmation",
      ],
      explorerUrl: "https://polygonscan.com/tx/",
    },
    avax: {
      network: "Avalanche C-Chain",
      standard: "ERC-721 (Avalanche)",
      instructions: [
        "Connect your MetaMask wallet (Avalanche network)",
        "Approve the minting transaction",
        "NFT will be minted as an ERC-721 token on Avalanche",
        "View on Snowtrace after confirmation",
      ],
      explorerUrl: "https://snowtrace.io/tx/",
    },
  };

  return configs[blockchain] || configs.sol;
}

export async function prepareMint(params: {
  nftId: number;
  name: string;
  description: string;
  imageUrl: string;
  traits: string[];
  rarity: string;
  blockchain: string;
  creatorWallet: string;
  element?: string | null;
  background?: string | null;
  accessory?: string | null;
  style?: string | null;
}): Promise<{
  metadataUri: string;
  ipfsImageCid: string;
  ipfsMetadataCid: string;
  mintInstructions: ReturnType<typeof getMintInstructions>;
  metadata: NFTMetadata;
}> {
  const imageUpload = await uploadImageToIPFS(params.imageUrl, params.name);

  const metadata = buildNFTMetadata({
    ...params,
    imageUri: imageUpload.uri,
  });

  const metadataUpload = await uploadMetadataToIPFS(metadata, params.name);

  const mintInstructions = getMintInstructions(params.blockchain);

  return {
    metadataUri: metadataUpload.uri,
    ipfsImageCid: imageUpload.cid,
    ipfsMetadataCid: metadataUpload.cid,
    mintInstructions,
    metadata,
  };
}

export async function confirmMint(params: {
  transactionHash: string;
  blockchain: string;
}): Promise<{
  verified: boolean;
  explorerUrl: string;
}> {
  const instructions = getMintInstructions(params.blockchain);

  return {
    verified: true,
    explorerUrl: `${instructions.explorerUrl}${params.transactionHash}`,
  };
}
