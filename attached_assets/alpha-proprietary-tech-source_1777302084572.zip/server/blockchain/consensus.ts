export const COIN_NAME = 'Alpha Unlimited Coin';
export const COIN_TICKER = 'AUC';
export const COIN_SYMBOL = 'α';

export const INITIAL_BLOCK_REWARD = 50;
export const HALVING_INTERVAL = 210000;
export const MAX_SUPPLY = 1000000000000;
export const BLOCK_TIME_TARGET_MS = 600000;
export const DIFFICULTY_ADJUSTMENT_INTERVAL = 2016;
export const INITIAL_DIFFICULTY = 4;
export const MIN_DIFFICULTY = 1;
export const MAX_DIFFICULTY_BITS = 256;

export const MAX_TRANSACTIONS_PER_BLOCK = 500;
export const TRANSACTION_FEE_RATE = 0.001;
export const MIN_TRANSACTION_FEE = 0.0001;

export const BURN_ADDRESS = 'ALPHA_BURN_000000000000000000000000000000000';

export const FOUNDER_ALLOCATION_PERCENT = 12;
export const FOUNDER_ALLOCATION = Math.floor(MAX_SUPPLY * FOUNDER_ALLOCATION_PERCENT / 100);
export const VESTING_YEARS = 5;
export const VESTING_TRANCHES = VESTING_YEARS;
export const VESTING_TRANCHE_AMOUNT = FOUNDER_ALLOCATION / VESTING_TRANCHES;
export const VESTING_START_DATE = new Date('2026-03-01T00:00:00Z').getTime();
export const VESTING_INTERVAL_MS = 365.25 * 24 * 60 * 60 * 1000;

const MAX_TARGET = (BigInt(1) << BigInt(256)) - BigInt(1);

export function difficultyToTarget(difficulty: number): bigint {
  if (difficulty <= 0) return MAX_TARGET;
  const scaledDifficulty = BigInt(Math.floor(difficulty * 1000));
  const target = MAX_TARGET / scaledDifficulty * BigInt(1000);
  if (target > MAX_TARGET) return MAX_TARGET;
  if (target < BigInt(1)) return BigInt(1);
  return target;
}

export function targetToHex(target: bigint): string {
  let hex = target.toString(16);
  return hex.padStart(64, '0');
}

export function hashToBigInt(hash: string): bigint {
  return BigInt('0x' + hash);
}

export function meetsTarget(hash: string, difficulty: number): boolean {
  const target = difficultyToTarget(difficulty);
  const hashValue = hashToBigInt(hash);
  return hashValue <= target;
}

export function getDifficultyTarget(difficulty: number): string {
  return targetToHex(difficultyToTarget(difficulty));
}

export function calculateBlockReward(blockHeight: number): number {
  const halvings = Math.floor(blockHeight / HALVING_INTERVAL);
  if (halvings >= 64) return 0;
  const reward = INITIAL_BLOCK_REWARD / Math.pow(2, halvings);
  return parseFloat(reward.toFixed(8));
}

export function calculateDifficulty(
  currentDifficulty: number,
  lastBlocks: { timestamp: number }[],
  blockHeight: number = 0
): number {
  if (lastBlocks.length < DIFFICULTY_ADJUSTMENT_INTERVAL) {
    return currentDifficulty;
  }

  const recentBlocks = lastBlocks.slice(-DIFFICULTY_ADJUSTMENT_INTERVAL);
  const timeSpan = recentBlocks[recentBlocks.length - 1].timestamp - recentBlocks[0].timestamp;
  const expectedTime = BLOCK_TIME_TARGET_MS * DIFFICULTY_ADJUSTMENT_INTERVAL;

  let adjustmentFactor = expectedTime / timeSpan;

  if (adjustmentFactor > 4) adjustmentFactor = 4;
  if (adjustmentFactor < 0.25) adjustmentFactor = 0.25;

  let newDifficulty = currentDifficulty * adjustmentFactor;

  newDifficulty = parseFloat(newDifficulty.toFixed(4));

  if (newDifficulty < MIN_DIFFICULTY) newDifficulty = MIN_DIFFICULTY;

  return newDifficulty;
}

export function calculateTotalSupply(currentHeight: number): number {
  let total = 0;
  let reward = INITIAL_BLOCK_REWARD;
  let height = 0;

  while (height < currentHeight && reward > 0) {
    const blocksInEra = Math.min(HALVING_INTERVAL, currentHeight - height);
    total += reward * blocksInEra;
    height += blocksInEra;
    reward /= 2;
    if (reward < 0.00000001) break;
  }

  return Math.min(total, MAX_SUPPLY);
}

export function calculateTransactionFee(amount: number): number {
  return Math.max(amount * TRANSACTION_FEE_RATE, MIN_TRANSACTION_FEE);
}

export function getEstimatedHashrate(difficulty: number, blockTimeMs: number): number {
  if (blockTimeMs <= 0) return 0;
  const target = difficultyToTarget(difficulty);
  const hashSpace = MAX_TARGET / target;
  return Number(hashSpace / BigInt(Math.ceil(blockTimeMs / 1000)));
}
