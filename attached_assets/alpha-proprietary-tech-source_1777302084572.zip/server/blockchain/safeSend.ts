import crypto from 'crypto';
import { getBlockchain } from './chain.js';
import { COIN_TICKER } from './consensus.js';

export type SafeSendStatus = 'pending' | 'finalized' | 'cancelled';

export interface SafeSendTransaction {
  id: string;
  fromAddress: string;
  toAddress: string;
  amount: number;
  fee: number;
  timeLockSeconds: number;
  createdAt: number;
  expiresAt: number;
  status: SafeSendStatus;
  cancelledAt?: number;
  finalizedAt?: number;
  blockchainTxId?: string;
}

export interface RegistryEntry {
  alias: string;
  address: string;
  registeredAt: number;
  owner: string;
}

export interface InheritanceConfig {
  ownerAddress: string;
  beneficiaries: { address: string; percentage: number }[];
  inactivityMonths: number;
  lastActivityAt: number;
  lastCheckInAt: number;
  isActive: boolean;
  configuredAt: number;
}

const MIN_TIMELOCK_SECONDS = 300;
const MAX_TIMELOCK_SECONDS = 86400;
const DEFAULT_TIMELOCK_SECONDS = 3600;
const ESCROW_ADDRESS = 'ALPHA_SAFESEND_ESCROW_00000000000000000';

const safeSendTransactions = new Map<string, SafeSendTransaction>();
const addressRegistry = new Map<string, RegistryEntry>();
const reverseRegistry = new Map<string, string>();
const inheritanceConfigs = new Map<string, InheritanceConfig>();

function generateSafeSendId(): string {
  return 'SS_' + crypto.randomBytes(16).toString('hex').toUpperCase();
}

function escrowFunds(fromAddress: string, amount: number, fee: number, insuranceFee: number): boolean {
  const blockchain = getBlockchain();
  const balance = blockchain.getBalance(fromAddress);
  const total = amount + fee + insuranceFee;
  if (balance < total) return false;
  blockchain.balances.set(fromAddress, parseFloat((balance - total).toFixed(8)));
  const escrowBal = blockchain.balances.get(ESCROW_ADDRESS) || 0;
  blockchain.balances.set(ESCROW_ADDRESS, parseFloat((escrowBal + amount + fee).toFixed(8)));
  return true;
}

function releaseEscrowToSender(fromAddress: string, amount: number, fee: number): void {
  const blockchain = getBlockchain();
  const escrowBal = blockchain.balances.get(ESCROW_ADDRESS) || 0;
  blockchain.balances.set(ESCROW_ADDRESS, parseFloat((escrowBal - amount - fee).toFixed(8)));
  const senderBal = blockchain.balances.get(fromAddress) || 0;
  blockchain.balances.set(fromAddress, parseFloat((senderBal + amount + fee).toFixed(8)));
}

function releaseEscrowToRecipient(toAddress: string, amount: number, fee: number): void {
  const blockchain = getBlockchain();
  const escrowBal = blockchain.balances.get(ESCROW_ADDRESS) || 0;
  blockchain.balances.set(ESCROW_ADDRESS, parseFloat((escrowBal - amount - fee).toFixed(8)));
  const recipientBal = blockchain.balances.get(toAddress) || 0;
  blockchain.balances.set(toAddress, parseFloat((recipientBal + amount).toFixed(8)));
}

export function createSafeSendTransaction(
  fromAddress: string,
  toAddress: string,
  amount: number,
  timeLockSeconds?: number
): SafeSendTransaction | { error: string } {
  if (!fromAddress || !toAddress) {
    return { error: 'fromAddress and toAddress are required' };
  }
  if (amount <= 0) {
    return { error: 'Amount must be positive' };
  }
  if (fromAddress === toAddress) {
    return { error: 'Cannot send to the same address' };
  }

  const lockTime = timeLockSeconds ?? DEFAULT_TIMELOCK_SECONDS;
  if (lockTime < MIN_TIMELOCK_SECONDS || lockTime > MAX_TIMELOCK_SECONDS) {
    return { error: `Time lock must be between ${MIN_TIMELOCK_SECONDS}s (5 min) and ${MAX_TIMELOCK_SECONDS}s (24 hrs)` };
  }

  const resolvedTo = resolveAddress(toAddress);
  if ('error' in resolvedTo) {
    return resolvedTo;
  }

  const blockchain = getBlockchain();
  const balance = blockchain.getBalance(fromAddress);
  const fee = amount * 0.001;
  const insuranceFee = amount * 0.001;
  const totalNeeded = amount + fee + insuranceFee;

  if (balance < totalNeeded) {
    return { error: `Insufficient balance. Have ${balance} ${COIN_TICKER}, need ${totalNeeded} ${COIN_TICKER} (${amount} + ${fee} fee + ${insuranceFee} insurance)` };
  }

  const escrowed = escrowFunds(fromAddress, amount, fee, insuranceFee);
  if (!escrowed) {
    return { error: 'Failed to escrow funds' };
  }

  const now = Date.now();
  const id = generateSafeSendId();

  const tx: SafeSendTransaction = {
    id,
    fromAddress,
    toAddress: resolvedTo.address,
    amount,
    fee,
    timeLockSeconds: lockTime,
    createdAt: now,
    expiresAt: now + lockTime * 1000,
    status: 'pending',
  };

  safeSendTransactions.set(id, tx);
  updateActivity(fromAddress);

  return tx;
}

export function cancelSafeSendTransaction(txId: string, senderAddress: string): SafeSendTransaction | { error: string } {
  const tx = safeSendTransactions.get(txId);
  if (!tx) {
    return { error: 'SafeSend transaction not found' };
  }
  if (tx.fromAddress !== senderAddress) {
    return { error: 'Only the sender can cancel this transaction' };
  }
  if (tx.status !== 'pending') {
    return { error: `Transaction is already ${tx.status}` };
  }
  if (Date.now() >= tx.expiresAt) {
    return { error: 'Time lock has expired. Transaction can no longer be cancelled.' };
  }

  releaseEscrowToSender(tx.fromAddress, tx.amount, tx.fee);

  tx.status = 'cancelled';
  tx.cancelledAt = Date.now();
  return tx;
}

export function finalizeSafeSendTransaction(txId: string): SafeSendTransaction | { error: string } {
  const tx = safeSendTransactions.get(txId);
  if (!tx) {
    return { error: 'SafeSend transaction not found' };
  }
  if (tx.status !== 'pending') {
    return { error: `Transaction is already ${tx.status}` };
  }
  if (Date.now() < tx.expiresAt) {
    return { error: 'Time lock has not expired yet. Cannot finalize.' };
  }

  releaseEscrowToRecipient(tx.toAddress, tx.amount, tx.fee);

  tx.status = 'finalized';
  tx.finalizedAt = Date.now();
  return tx;
}

export function getSafeSendTransaction(txId: string): SafeSendTransaction | { error: string } {
  const tx = safeSendTransactions.get(txId);
  if (!tx) {
    return { error: 'SafeSend transaction not found' };
  }

  if (tx.status === 'pending' && Date.now() >= tx.expiresAt) {
    releaseEscrowToRecipient(tx.toAddress, tx.amount, tx.fee);
    tx.status = 'finalized';
    tx.finalizedAt = tx.expiresAt;
  }

  return tx;
}

export function getPendingSafeSendTransactions(address?: string): SafeSendTransaction[] {
  const now = Date.now();
  const results: SafeSendTransaction[] = [];

  const allTxs = Array.from(safeSendTransactions.values());
  for (const tx of allTxs) {
    if (tx.status === 'pending' && now >= tx.expiresAt) {
      releaseEscrowToRecipient(tx.toAddress, tx.amount, tx.fee);
      tx.status = 'finalized';
      tx.finalizedAt = tx.expiresAt;
    }

    if (address) {
      if (tx.fromAddress === address || tx.toAddress === address) {
        results.push(tx);
      }
    } else {
      if (tx.status === 'pending') {
        results.push(tx);
      }
    }
  }

  return results.sort((a, b) => b.createdAt - a.createdAt);
}

function resolveAddress(addressOrAlias: string): { address: string } | { error: string } {
  if (addressOrAlias.startsWith('@') && addressOrAlias.endsWith('.auc')) {
    const entry = addressRegistry.get(addressOrAlias.toLowerCase());
    if (!entry) {
      return { error: `Alias ${addressOrAlias} not found in registry` };
    }
    return { address: entry.address };
  }
  if (addressOrAlias.startsWith('ALPHA_')) {
    return { address: addressOrAlias };
  }
  return { error: 'Invalid address or alias format' };
}

export function registerAlias(
  alias: string,
  address: string,
  ownerAddress: string
): RegistryEntry | { error: string } {
  if (!alias || !address) {
    return { error: 'alias and address are required' };
  }

  let normalizedAlias = alias.toLowerCase().trim();
  if (!normalizedAlias.startsWith('@')) {
    normalizedAlias = '@' + normalizedAlias;
  }
  if (!normalizedAlias.endsWith('.auc')) {
    normalizedAlias = normalizedAlias + '.auc';
  }

  const namepart = normalizedAlias.slice(1, -4);
  if (namepart.length < 3 || namepart.length > 32) {
    return { error: 'Alias name must be between 3 and 32 characters' };
  }
  if (!/^[a-z0-9_-]+$/.test(namepart)) {
    return { error: 'Alias name can only contain lowercase letters, numbers, hyphens, and underscores' };
  }

  if (addressRegistry.has(normalizedAlias)) {
    return { error: `Alias ${normalizedAlias} is already registered` };
  }

  if (!address.startsWith('ALPHA_')) {
    return { error: 'Address must be a valid ALPHA_ wallet address' };
  }

  const entry: RegistryEntry = {
    alias: normalizedAlias,
    address,
    registeredAt: Date.now(),
    owner: ownerAddress || address,
  };

  addressRegistry.set(normalizedAlias, entry);
  reverseRegistry.set(address, normalizedAlias);
  updateActivity(ownerAddress);

  return entry;
}

export function lookupAlias(alias: string): RegistryEntry | { error: string } {
  let normalizedAlias = alias.toLowerCase().trim();
  if (!normalizedAlias.startsWith('@')) {
    normalizedAlias = '@' + normalizedAlias;
  }
  if (!normalizedAlias.endsWith('.auc')) {
    normalizedAlias = normalizedAlias + '.auc';
  }

  const entry = addressRegistry.get(normalizedAlias);
  if (!entry) {
    return { error: `Alias ${normalizedAlias} not found` };
  }
  return entry;
}

export function reverseLookup(address: string): { alias: string; entry: RegistryEntry } | { error: string } {
  const alias = reverseRegistry.get(address);
  if (!alias) {
    return { error: `No alias registered for address ${address}` };
  }
  const entry = addressRegistry.get(alias);
  if (!entry) {
    return { error: `Registry inconsistency for address ${address}` };
  }
  return { alias, entry };
}

export function transferAlias(
  alias: string,
  newAddress: string,
  currentOwner: string
): RegistryEntry | { error: string } {
  let normalizedAlias = alias.toLowerCase().trim();
  if (!normalizedAlias.startsWith('@')) {
    normalizedAlias = '@' + normalizedAlias;
  }
  if (!normalizedAlias.endsWith('.auc')) {
    normalizedAlias = normalizedAlias + '.auc';
  }

  const entry = addressRegistry.get(normalizedAlias);
  if (!entry) {
    return { error: `Alias ${normalizedAlias} not found` };
  }
  if (entry.owner !== currentOwner) {
    return { error: 'Only the owner can transfer this alias' };
  }
  if (!newAddress.startsWith('ALPHA_')) {
    return { error: 'New address must be a valid ALPHA_ wallet address' };
  }

  reverseRegistry.delete(entry.address);
  entry.address = newAddress;
  entry.owner = newAddress;
  reverseRegistry.set(newAddress, normalizedAlias);

  return entry;
}

function updateActivity(address: string): void {
  const config = inheritanceConfigs.get(address);
  if (config) {
    config.lastActivityAt = Date.now();
  }
}

export function configureInheritance(
  ownerAddress: string,
  beneficiaries: { address: string; percentage: number }[],
  inactivityMonths: number
): InheritanceConfig | { error: string } {
  if (!ownerAddress || !ownerAddress.startsWith('ALPHA_')) {
    return { error: 'Valid ALPHA_ owner address is required' };
  }
  if (!beneficiaries || beneficiaries.length === 0) {
    return { error: 'At least one beneficiary is required' };
  }
  if (inactivityMonths < 6 || inactivityMonths > 24) {
    return { error: 'Inactivity period must be between 6 and 24 months' };
  }

  const totalPercentage = beneficiaries.reduce((sum, b) => sum + b.percentage, 0);
  if (Math.abs(totalPercentage - 100) > 0.01) {
    return { error: `Beneficiary percentages must sum to 100%. Current sum: ${totalPercentage}%` };
  }

  for (const b of beneficiaries) {
    if (!b.address || !b.address.startsWith('ALPHA_')) {
      return { error: `Invalid beneficiary address: ${b.address}` };
    }
    if (b.percentage <= 0 || b.percentage > 100) {
      return { error: `Invalid percentage for ${b.address}: ${b.percentage}` };
    }
    if (b.address === ownerAddress) {
      return { error: 'Owner cannot be a beneficiary' };
    }
  }

  const now = Date.now();
  const config: InheritanceConfig = {
    ownerAddress,
    beneficiaries,
    inactivityMonths,
    lastActivityAt: now,
    lastCheckInAt: now,
    isActive: true,
    configuredAt: now,
  };

  inheritanceConfigs.set(ownerAddress, config);
  return config;
}

export function checkInInheritance(ownerAddress: string): InheritanceConfig | { error: string } {
  const config = inheritanceConfigs.get(ownerAddress);
  if (!config) {
    return { error: 'No inheritance configuration found for this address' };
  }
  if (!config.isActive) {
    return { error: 'Inheritance protocol has been deactivated' };
  }

  const now = Date.now();
  config.lastCheckInAt = now;
  config.lastActivityAt = now;

  return config;
}

export function getInheritanceStatus(address: string): {
  config: InheritanceConfig;
  daysUntilTrigger: number;
  isTriggered: boolean;
  triggerDate: number;
} | { error: string } {
  const config = inheritanceConfigs.get(address);
  if (!config) {
    return { error: 'No inheritance configuration found for this address' };
  }

  const now = Date.now();
  const inactivityMs = config.inactivityMonths * 30 * 24 * 60 * 60 * 1000;
  const triggerDate = config.lastActivityAt + inactivityMs;
  const isTriggered = now >= triggerDate;
  const daysUntilTrigger = isTriggered ? 0 : Math.ceil((triggerDate - now) / (24 * 60 * 60 * 1000));

  return {
    config,
    daysUntilTrigger,
    isTriggered,
    triggerDate,
  };
}

export function deactivateInheritance(ownerAddress: string): InheritanceConfig | { error: string } {
  const config = inheritanceConfigs.get(ownerAddress);
  if (!config) {
    return { error: 'No inheritance configuration found for this address' };
  }
  config.isActive = false;
  return config;
}

export function getSafeSendStats() {
  let totalTransactions = 0;
  let pendingCount = 0;
  let finalizedCount = 0;
  let cancelledCount = 0;
  let totalVolume = 0;
  let totalFees = 0;

  const allTxs = Array.from(safeSendTransactions.values());
  for (const tx of allTxs) {
    totalTransactions++;
    totalVolume += tx.amount;
    totalFees += tx.fee;
    if (tx.status === 'pending') {
      if (Date.now() >= tx.expiresAt) {
        releaseEscrowToRecipient(tx.toAddress, tx.amount, tx.fee);
        tx.status = 'finalized';
        tx.finalizedAt = tx.expiresAt;
        finalizedCount++;
      } else {
        pendingCount++;
      }
    } else if (tx.status === 'finalized') {
      finalizedCount++;
    } else {
      cancelledCount++;
    }
  }

  return {
    totalTransactions,
    pendingCount,
    finalizedCount,
    cancelledCount,
    totalVolume,
    totalFees,
    registeredAliases: addressRegistry.size,
    inheritanceConfigs: inheritanceConfigs.size,
    activeInheritanceConfigs: Array.from(inheritanceConfigs.values()).filter(c => c.isActive).length,
    ticker: COIN_TICKER,
    timeLockRange: {
      minSeconds: MIN_TIMELOCK_SECONDS,
      maxSeconds: MAX_TIMELOCK_SECONDS,
      defaultSeconds: DEFAULT_TIMELOCK_SECONDS,
    },
    insuranceFeeRate: 0.001,
  };
}

export function getAllRegistryEntries(): RegistryEntry[] {
  return Array.from(addressRegistry.values()).sort((a, b) => b.registeredAt - a.registeredAt);
}

export function getAllInheritanceConfigs(): InheritanceConfig[] {
  return Array.from(inheritanceConfigs.values());
}
