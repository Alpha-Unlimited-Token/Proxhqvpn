import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { createWallet, type AlphaWallet } from './wallet.js';
import {
  FOUNDER_ALLOCATION, FOUNDER_ALLOCATION_PERCENT,
  VESTING_TRANCHES, VESTING_TRANCHE_AMOUNT,
  VESTING_START_DATE, VESTING_INTERVAL_MS, VESTING_YEARS,
  MAX_SUPPLY, COIN_TICKER,
} from './consensus.js';

const FOUNDER_WALLET_PATH = path.join(process.cwd(), 'data', 'founder-wallet.json');
const ENCRYPTION_ALGO = 'aes-256-gcm';

function getWalletEncryptionKey(): Buffer {
  const key = process.env.ENCRYPTION_KEY || process.env.SESSION_SECRET;
  if (!key || key.length < 32) {
    throw new Error('ENCRYPTION_KEY or SESSION_SECRET must be at least 32 characters for wallet encryption');
  }
  return crypto.createHash('sha256').update(key).digest();
}

function encryptPrivateKey(plaintext: string): string {
  const key = getWalletEncryptionKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGO, key, iv);
  let encrypted = cipher.update(plaintext, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

function decryptPrivateKey(ciphertext: string): string {
  const key = getWalletEncryptionKey();
  const [ivHex, authTagHex, encrypted] = ciphertext.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const decipher = crypto.createDecipheriv(ENCRYPTION_ALGO, key, iv, { authTagLength: 16 });
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

interface FounderWalletData {
  address: string;
  publicKey: string;
  privateKey: string;
  createdAt: number;
}

interface EncryptedWalletFile {
  address: string;
  publicKey: string;
  encryptedPrivateKey: string;
  createdAt: number;
  encrypted: true;
}

let founderWallet: FounderWalletData | null = null;

export function getFounderWallet(): FounderWalletData {
  if (founderWallet) return founderWallet;

  const dataDir = path.dirname(FOUNDER_WALLET_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(FOUNDER_WALLET_PATH)) {
    const stat = fs.statSync(FOUNDER_WALLET_PATH);
    if ((stat.mode & 0o077) !== 0) {
      fs.chmodSync(FOUNDER_WALLET_PATH, 0o600);
    }

    const raw = fs.readFileSync(FOUNDER_WALLET_PATH, 'utf-8');
    const parsed = JSON.parse(raw);

    if (parsed.encrypted && parsed.encryptedPrivateKey) {
      founderWallet = {
        address: parsed.address,
        publicKey: parsed.publicKey,
        privateKey: decryptPrivateKey(parsed.encryptedPrivateKey),
        createdAt: parsed.createdAt,
      };
    } else if (parsed.privateKey) {
      founderWallet = {
        address: parsed.address,
        publicKey: parsed.publicKey,
        privateKey: parsed.privateKey,
        createdAt: parsed.createdAt,
      };
      const encryptedFile: EncryptedWalletFile = {
        address: parsed.address,
        publicKey: parsed.publicKey,
        encryptedPrivateKey: encryptPrivateKey(parsed.privateKey),
        createdAt: parsed.createdAt,
        encrypted: true,
      };
      fs.writeFileSync(FOUNDER_WALLET_PATH, JSON.stringify(encryptedFile, null, 2), { mode: 0o600 });
      fs.chmodSync(FOUNDER_WALLET_PATH, 0o600);
      console.log(`[Founder] Migrated wallet to encrypted format`);
    }

    console.log(`[Founder] Loaded founder wallet: ${founderWallet!.address}`);
    return founderWallet!;
  }

  const wallet = createWallet();
  founderWallet = {
    address: wallet.address,
    publicKey: wallet.publicKey,
    privateKey: wallet.privateKey,
    createdAt: wallet.createdAt,
  };

  const encryptedFile: EncryptedWalletFile = {
    address: founderWallet.address,
    publicKey: founderWallet.publicKey,
    encryptedPrivateKey: encryptPrivateKey(founderWallet.privateKey),
    createdAt: founderWallet.createdAt,
    encrypted: true,
  };

  fs.writeFileSync(FOUNDER_WALLET_PATH, JSON.stringify(encryptedFile, null, 2), { mode: 0o600 });
  fs.chmodSync(FOUNDER_WALLET_PATH, 0o600);
  console.log(`[Founder] Created new founder wallet: ${founderWallet.address}`);
  console.log(`[Founder] Wallet saved to ${FOUNDER_WALLET_PATH} (encrypted)`);

  return founderWallet;
}

export function getFounderAddress(): string {
  return getFounderWallet().address;
}

export function getVestingSchedule(): {
  totalAllocation: number;
  vestingYears: number;
  tranches: { year: number; amount: number; unlockDate: string; unlocked: boolean }[];
  totalUnlocked: number;
  totalLocked: number;
  percentUnlocked: number;
} {
  const now = Date.now();
  const tranches = [];
  let totalUnlocked = 0;

  for (let i = 0; i < VESTING_TRANCHES; i++) {
    const unlockTime = VESTING_START_DATE + (i * VESTING_INTERVAL_MS);
    const unlocked = now >= unlockTime;
    if (unlocked) totalUnlocked += VESTING_TRANCHE_AMOUNT;

    tranches.push({
      year: i + 1,
      amount: VESTING_TRANCHE_AMOUNT,
      unlockDate: new Date(unlockTime).toISOString(),
      unlocked,
    });
  }

  return {
    totalAllocation: FOUNDER_ALLOCATION,
    vestingYears: VESTING_YEARS,
    tranches,
    totalUnlocked,
    totalLocked: FOUNDER_ALLOCATION - totalUnlocked,
    percentUnlocked: parseFloat(((totalUnlocked / FOUNDER_ALLOCATION) * 100).toFixed(2)),
  };
}

export function getFounderDisclosure() {
  const wallet = getFounderWallet();
  const vesting = getVestingSchedule();

  return {
    founderAllocation: {
      percentage: FOUNDER_ALLOCATION_PERCENT,
      amount: FOUNDER_ALLOCATION,
      ticker: COIN_TICKER,
      maxSupply: MAX_SUPPLY,
    },
    founderAddress: wallet.address,
    vesting,
    transparency: {
      note: 'The founder allocation is fully disclosed and subject to a vesting schedule. The founder wallet address is public and can be verified on the blockchain explorer.',
      vestingSummary: `${FOUNDER_ALLOCATION.toLocaleString()} ${COIN_TICKER} (${FOUNDER_ALLOCATION_PERCENT}% of max supply) vesting over ${VESTING_YEARS} years with ${VESTING_TRANCHE_AMOUNT.toLocaleString()} ${COIN_TICKER} unlocking each year.`,
    },
  };
}
