import { Router, Request, Response } from 'express';
import { isAuthenticated } from '../replit_integrations/auth/replitAuth.js';
import {
  createSafeSendTransaction,
  cancelSafeSendTransaction,
  getSafeSendTransaction,
  getPendingSafeSendTransactions,
  registerAlias,
  lookupAlias,
  reverseLookup,
  transferAlias,
  getAllRegistryEntries,
  configureInheritance,
  checkInInheritance,
  getInheritanceStatus,
  deactivateInheritance,
  getAllInheritanceConfigs,
  getSafeSendStats,
} from './safeSend.js';
import { getInsuranceVault } from './insuranceVault.js';
import {
  createTokenizedAsset,
  getAsset,
  getAllAssets,
  getSerializedAsset,
  getAllSerializedAssets,
  transferShares,
  distributeYield,
  getAssetHolders,
  getAssetTransfers,
  updateAssetValuation,
  verifyAsset,
  addDocument,
  updateAssetStatus,
  updateComplianceConfig,
  updateSecondaryMarketRules,
  getSafeAssetStats,
} from './safeAsset.js';

const router = Router();

router.get('/stats', (_req: Request, res: Response) => {
  const safeSendStats = getSafeSendStats();
  const vault = getInsuranceVault();
  const vaultStats = vault.getVaultStats();
  const assetStats = getSafeAssetStats();
  res.json({
    protocol: 'Alpha SafeSend Protocol™',
    safeSend: safeSendStats,
    vault: vaultStats,
    safeAsset: assetStats,
  });
});

router.post('/transaction', isAuthenticated, (req: Request, res: Response) => {
  const { fromAddress, toAddress, amount, timeLockSeconds } = req.body;
  if (!fromAddress || !toAddress || !amount) {
    return res.status(400).json({ error: 'fromAddress, toAddress, and amount are required' });
  }
  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }
  const result = createSafeSendTransaction(
    fromAddress,
    toAddress,
    parsedAmount,
    timeLockSeconds ? parseInt(timeLockSeconds) : undefined
  );
  if ('error' in result) {
    return res.status(400).json(result);
  }
  const vault = getInsuranceVault();
  const insuranceFee = vault.calculateInsuranceFee(parsedAmount);
  vault.depositToVault(insuranceFee, result.id);
  res.json({
    message: 'SafeSend transaction created with time-lock protection',
    transaction: result,
    insuranceFee,
    note: `Transaction is pending for ${result.timeLockSeconds}s. You can cancel before the time-lock expires.`,
  });
});

router.post('/cancel/:txId', isAuthenticated, (req: Request, res: Response) => {
  const { txId } = req.params;
  const { senderAddress } = req.body;
  if (!senderAddress) {
    return res.status(400).json({ error: 'senderAddress is required' });
  }
  const result = cancelSafeSendTransaction(txId, senderAddress);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'SafeSend transaction cancelled successfully. Funds returned to sender.',
    transaction: result,
  });
});

router.get('/pending', (req: Request, res: Response) => {
  const address = req.query.address as string | undefined;
  const transactions = getPendingSafeSendTransactions(address);
  res.json({ transactions, count: transactions.length });
});

router.get('/status/:txId', (req: Request, res: Response) => {
  const result = getSafeSendTransaction(req.params.txId);
  if ('error' in result) {
    return res.status(404).json(result);
  }
  const now = Date.now();
  const timeRemaining = result.status === 'pending' ? Math.max(0, result.expiresAt - now) : 0;
  res.json({
    transaction: result,
    timeRemainingMs: timeRemaining,
    timeRemainingSeconds: Math.ceil(timeRemaining / 1000),
    canCancel: result.status === 'pending' && now < result.expiresAt,
  });
});

router.post('/registry/register', isAuthenticated, (req: Request, res: Response) => {
  const { alias, address, ownerAddress } = req.body;
  if (!alias || !address) {
    return res.status(400).json({ error: 'alias and address are required' });
  }
  const result = registerAlias(alias, address, ownerAddress || address);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: `Alias ${result.alias} registered successfully`,
    entry: result,
  });
});

router.get('/registry/lookup/:alias', (req: Request, res: Response) => {
  const result = lookupAlias(req.params.alias);
  if ('error' in result) {
    return res.status(404).json(result);
  }
  res.json(result);
});

router.get('/registry/reverse/:address', (req: Request, res: Response) => {
  const result = reverseLookup(req.params.address);
  if ('error' in result) {
    return res.status(404).json(result);
  }
  res.json(result);
});

router.post('/registry/transfer', isAuthenticated, (req: Request, res: Response) => {
  const { alias, newAddress, currentOwner } = req.body;
  if (!alias || !newAddress || !currentOwner) {
    return res.status(400).json({ error: 'alias, newAddress, and currentOwner are required' });
  }
  const result = transferAlias(alias, newAddress, currentOwner);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: `Alias ${result.alias} transferred to ${newAddress}`,
    entry: result,
  });
});

router.get('/registry/all', (req: Request, res: Response) => {
  const entries = getAllRegistryEntries();
  res.json({ entries, count: entries.length });
});

router.post('/inheritance/configure', isAuthenticated, (req: Request, res: Response) => {
  const { ownerAddress, beneficiaries, inactivityMonths } = req.body;
  if (!ownerAddress || !beneficiaries || !inactivityMonths) {
    return res.status(400).json({ error: 'ownerAddress, beneficiaries, and inactivityMonths are required' });
  }
  const result = configureInheritance(ownerAddress, beneficiaries, parseInt(inactivityMonths));
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'Inheritance protocol configured successfully',
    config: result,
    note: `Dead man\'s switch set to ${inactivityMonths} months of inactivity. Check in regularly to keep it active.`,
  });
});

router.post('/inheritance/checkin', isAuthenticated, (req: Request, res: Response) => {
  const { ownerAddress } = req.body;
  if (!ownerAddress) {
    return res.status(400).json({ error: 'ownerAddress is required' });
  }
  const result = checkInInheritance(ownerAddress);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'Inheritance check-in recorded. Timer reset.',
    config: result,
  });
});

router.get('/inheritance/status/:address', (req: Request, res: Response) => {
  const result = getInheritanceStatus(req.params.address);
  if ('error' in result) {
    return res.status(404).json(result);
  }
  res.json(result);
});

router.post('/inheritance/deactivate', isAuthenticated, (req: Request, res: Response) => {
  const { ownerAddress } = req.body;
  if (!ownerAddress) {
    return res.status(400).json({ error: 'ownerAddress is required' });
  }
  const result = deactivateInheritance(ownerAddress);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'Inheritance protocol deactivated',
    config: result,
  });
});

router.get('/vault/stats', (_req: Request, res: Response) => {
  const vault = getInsuranceVault();
  res.json(vault.getVaultStats());
});

router.post('/vault/claim', isAuthenticated, (req: Request, res: Response) => {
  const { claimantAddress, transactionHash, destinationAddress, claimedAmount, stakeAmount } = req.body;
  if (!claimantAddress || !transactionHash || !destinationAddress || !claimedAmount || !stakeAmount) {
    return res.status(400).json({ error: 'claimantAddress, transactionHash, destinationAddress, claimedAmount, and stakeAmount are required' });
  }
  const parsedAmount = parseFloat(claimedAmount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'claimedAmount must be a positive number' });
  }
  const parsedStake = parseFloat(stakeAmount);
  if (isNaN(parsedStake) || parsedStake <= 0) {
    return res.status(400).json({ error: 'stakeAmount must be a positive number' });
  }
  const vault = getInsuranceVault();
  const result = vault.fileClaim(claimantAddress, transactionHash, destinationAddress, parsedAmount, parsedStake);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'Insurance claim filed. 7-layer anti-fraud verification in progress.',
    claim: result,
    note: 'Your stake of 5% has been locked. Investigation period begins now.',
  });
});

router.get('/vault/claims', (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const address = req.query.address as string | undefined;
  const claims = address ? vault.getClaimsByAddress(address) : vault.getAllClaims();
  res.json({ claims, count: claims.length });
});

router.get('/vault/claim/:claimId', (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const claim = vault.getClaim(req.params.claimId);
  if (!claim) {
    return res.status(404).json({ error: 'Claim not found' });
  }
  res.json(claim);
});

router.post('/vault/vote/:claimId', isAuthenticated, (req: Request, res: Response) => {
  const { claimId } = req.params;
  const { jurorAddress, vote, reason } = req.body;
  if (!jurorAddress || !vote) {
    return res.status(400).json({ error: 'jurorAddress and vote (approve/deny) are required' });
  }
  if (vote !== 'approve' && vote !== 'deny') {
    return res.status(400).json({ error: 'vote must be "approve" or "deny"' });
  }
  const vault = getInsuranceVault();
  const result = vault.voteOnClaim(claimId, jurorAddress, vote, reason || '');
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: `Vote recorded: ${vote}`,
    claim: result,
    note: 'Your jury stake has been locked. You will earn rewards if your vote matches the final outcome.',
  });
});

router.get('/vault/validators', (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const validators = vault.getAllValidators();
  const status = req.query.status as string | undefined;
  const filtered = status ? validators.filter(v => v.status === status) : validators;
  res.json({ validators: filtered, count: filtered.length });
});

router.get('/vault/validator/:validatorId', (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const validator = vault.getValidator(req.params.validatorId);
  if (!validator) {
    return res.status(404).json({ error: 'Validator not found' });
  }
  res.json(validator);
});

router.post('/vault/integrity-audit', isAuthenticated, (_req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const result = vault.runIntegrityAudit();
  res.json({
    message: 'Chain integrity audit complete',
    triggered: result.triggered.length,
    active: result.active.length,
    alerts: result.triggered.map(v => ({
      id: v.id,
      claimId: v.claimId,
      threadCount: v.threads?.length || 0,
      status: v.status,
    })),
  });
});

router.post('/asset/create', isAuthenticated, (req: Request, res: Response) => {
  const { name, assetType, description, totalShares, creatorAddress, initialValuation, valuationMethod, complianceOverrides, secondaryMarketRules, yieldConfig, documents } = req.body;
  if (!name || !assetType || !totalShares || !creatorAddress) {
    return res.status(400).json({ error: 'name, assetType, totalShares, and creatorAddress are required' });
  }
  const result = createTokenizedAsset({
    name,
    assetType,
    description: description || '',
    totalShares: parseInt(totalShares),
    creatorAddress,
    initialValuation: initialValuation ? parseFloat(initialValuation) : undefined,
    valuationMethod,
    complianceOverrides,
    secondaryMarketRules,
    yieldConfig,
    documents,
  });
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: `Asset "${name}" tokenized successfully with ${totalShares} shares`,
    asset: result,
  });
});

router.get('/asset/stats', (_req: Request, res: Response) => {
  res.json(getSafeAssetStats());
});

router.get('/asset/:assetId', (req: Request, res: Response) => {
  const result = getSerializedAsset(req.params.assetId);
  if (result && 'error' in result) {
    return res.status(404).json(result);
  }
  res.json(result);
});

router.get('/assets', (req: Request, res: Response) => {
  const assetType = req.query.assetType as string | undefined;
  const status = req.query.status as string | undefined;
  const filters: any = {};
  if (assetType) filters.assetType = assetType;
  if (status) filters.status = status;
  const assets = getAllSerializedAssets(Object.keys(filters).length > 0 ? filters : undefined);
  res.json({ assets, count: assets.length });
});

router.post('/asset/:assetId/transfer', isAuthenticated, (req: Request, res: Response) => {
  const { assetId } = req.params;
  const { fromAddress, toAddress, shares } = req.body;
  if (!fromAddress || !toAddress || !shares) {
    return res.status(400).json({ error: 'fromAddress, toAddress, and shares are required' });
  }
  const result = transferShares({
    assetId,
    fromAddress,
    toAddress,
    shares: parseInt(shares),
  });
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: `${shares} shares of ${assetId} transferred successfully`,
    transfer: result,
  });
});

router.post('/asset/:assetId/distribute', isAuthenticated, (req: Request, res: Response) => {
  const { assetId } = req.params;
  const { distributorAddress } = req.body;
  if (!distributorAddress) {
    return res.status(400).json({ error: 'distributorAddress is required' });
  }
  const result = distributeYield(assetId, distributorAddress);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({
    message: 'Yield distributed to all holders',
    distribution: result,
  });
});

router.get('/asset/:assetId/holders', (req: Request, res: Response) => {
  const result = getAssetHolders(req.params.assetId);
  if ('error' in result) {
    return res.status(404).json(result);
  }
  res.json({ holders: result, count: result.length });
});

router.get('/asset/:assetId/transfers', (req: Request, res: Response) => {
  const transfers = getAssetTransfers(req.params.assetId);
  res.json({ transfers, count: transfers.length });
});

router.post('/asset/:assetId/valuate', isAuthenticated, (req: Request, res: Response) => {
  const { assetId } = req.params;
  const { value, method, appraiserAddress } = req.body;
  if (!value || !method || !appraiserAddress) {
    return res.status(400).json({ error: 'value, method, and appraiserAddress are required' });
  }
  const result = updateAssetValuation(assetId, parseFloat(value), method, appraiserAddress);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({ message: 'Valuation updated', asset: result });
});

router.post('/asset/:assetId/verify', isAuthenticated, (req: Request, res: Response) => {
  const { assetId } = req.params;
  const { auditorAddress, status } = req.body;
  if (!auditorAddress || !status) {
    return res.status(400).json({ error: 'auditorAddress and status are required' });
  }
  if (status !== 'verified' && status !== 'rejected') {
    return res.status(400).json({ error: 'status must be "verified" or "rejected"' });
  }
  const result = verifyAsset(assetId, auditorAddress, status);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({ message: `Asset verification: ${status}`, asset: result });
});

router.post('/asset/:assetId/document', isAuthenticated, (req: Request, res: Response) => {
  const { assetId } = req.params;
  const { name, documentHash, uploaderAddress } = req.body;
  if (!name || !documentHash || !uploaderAddress) {
    return res.status(400).json({ error: 'name, documentHash, and uploaderAddress are required' });
  }
  const result = addDocument(assetId, uploaderAddress, documentHash, name);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({ message: 'Document added', document: result });
});

router.get('/forensics/stats', isAuthenticated, (_req: Request, res: Response) => {
  const vault = getInsuranceVault();
  res.json(vault.getForensicStats());
});

router.get('/forensics/dossiers', isAuthenticated, (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const severity = req.query.severity as string | undefined;
  const dossiers = severity ? vault.getDossiersBySeverity(severity as any) : vault.getAllForensicDossiers();
  res.json({ dossiers, count: dossiers.length });
});

router.get('/forensics/dossier/:dossierId', isAuthenticated, (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const dossier = vault.getForensicDossier(req.params.dossierId);
  if (!dossier) {
    return res.status(404).json({ error: 'Dossier not found' });
  }
  res.json(dossier);
});

router.get('/forensics/dossiers/address/:address', isAuthenticated, (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const dossiers = vault.getDossiersByAddress(req.params.address);
  res.json({ dossiers, count: dossiers.length });
});

router.post('/forensics/dossier/:dossierId/status', isAuthenticated, (req: Request, res: Response) => {
  const { status } = req.body;
  if (!status || !['active', 'under_review', 'referred_to_legal', 'resolved'].includes(status)) {
    return res.status(400).json({ error: 'Valid status required: active, under_review, referred_to_legal, resolved' });
  }
  const vault = getInsuranceVault();
  const result = vault.updateDossierStatus(req.params.dossierId, status);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({ message: `Dossier status updated to ${status}`, dossier: result });
});

router.post('/forensics/dossier/:dossierId/note', isAuthenticated, (req: Request, res: Response) => {
  const { note } = req.body;
  if (!note) {
    return res.status(400).json({ error: 'Note text is required' });
  }
  const vault = getInsuranceVault();
  const result = vault.addDossierNote(req.params.dossierId, note);
  if ('error' in result) {
    return res.status(400).json(result);
  }
  res.json({ message: 'Note added', dossier: result });
});

router.get('/forensics/alerts', isAuthenticated, (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const unacknowledgedOnly = req.query.unacknowledged === 'true';
  const alerts = vault.getAdminAlerts(unacknowledgedOnly);
  res.json({ alerts, count: alerts.length });
});

router.post('/forensics/alerts/:alertId/acknowledge', isAuthenticated, (req: Request, res: Response) => {
  const vault = getInsuranceVault();
  const result = vault.acknowledgeAlert(req.params.alertId);
  res.json(result);
});

export default router;
