interface ChainConfig {
  name: string;
  symbol: string;
  explorer: string;
  apiBase: string;
  addressPattern: RegExp;
  txPattern: RegExp;
}

const CHAINS: Record<string, ChainConfig> = {
  ethereum: {
    name: 'Ethereum',
    symbol: 'ETH',
    explorer: 'https://etherscan.io',
    apiBase: 'https://api.blockchair.com/ethereum',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  bitcoin: {
    name: 'Bitcoin',
    symbol: 'BTC',
    explorer: 'https://blockchain.info',
    apiBase: 'https://api.blockchair.com/bitcoin',
    addressPattern: /^(1|3|bc1)[a-zA-HJ-NP-Z0-9]{25,62}$/,
    txPattern: /^[a-fA-F0-9]{64}$/,
  },
  bsc: {
    name: 'BNB Smart Chain',
    symbol: 'BNB',
    explorer: 'https://bscscan.com',
    apiBase: 'https://api.blockchair.com/binance-smart-chain',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  polygon: {
    name: 'Polygon',
    symbol: 'MATIC',
    explorer: 'https://polygonscan.com',
    apiBase: 'https://api.blockchair.com/polygon',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  solana: {
    name: 'Solana',
    symbol: 'SOL',
    explorer: 'https://explorer.solana.com',
    apiBase: 'https://api.blockchair.com/solana',
    addressPattern: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/,
    txPattern: /^[1-9A-HJ-NP-Za-km-z]{64,88}$/,
  },
  tron: {
    name: 'TRON',
    symbol: 'TRX',
    explorer: 'https://tronscan.org',
    apiBase: 'https://api.blockchair.com/tron',
    addressPattern: /^T[a-zA-HJ-NP-Z0-9]{33}$/,
    txPattern: /^[a-fA-F0-9]{64}$/,
  },
  arbitrum: {
    name: 'Arbitrum',
    symbol: 'ETH',
    explorer: 'https://arbiscan.io',
    apiBase: 'https://api.blockchair.com/arbitrum',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  optimism: {
    name: 'Optimism',
    symbol: 'ETH',
    explorer: 'https://optimistic.etherscan.io',
    apiBase: 'https://api.blockchair.com/optimism',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  base: {
    name: 'Base',
    symbol: 'ETH',
    explorer: 'https://basescan.org',
    apiBase: 'https://api.blockchair.com/base',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  avalanche: {
    name: 'Avalanche C-Chain',
    symbol: 'AVAX',
    explorer: 'https://snowtrace.io',
    apiBase: 'https://api.blockchair.com/avalanche',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  fantom: {
    name: 'Fantom',
    symbol: 'FTM',
    explorer: 'https://ftmscan.com',
    apiBase: 'https://api.blockchair.com/fantom',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  cronos: {
    name: 'Cronos',
    symbol: 'CRO',
    explorer: 'https://cronoscan.com',
    apiBase: 'https://api.blockchair.com/cronos',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  gnosis: {
    name: 'Gnosis Chain',
    symbol: 'xDAI',
    explorer: 'https://gnosisscan.io',
    apiBase: 'https://api.blockchair.com/gnosis',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  linea: {
    name: 'Linea',
    symbol: 'ETH',
    explorer: 'https://lineascan.build',
    apiBase: 'https://api.blockchair.com/linea',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  scroll: {
    name: 'Scroll',
    symbol: 'ETH',
    explorer: 'https://scrollscan.com',
    apiBase: 'https://api.blockchair.com/scroll',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  zksync: {
    name: 'zkSync Era',
    symbol: 'ETH',
    explorer: 'https://explorer.zksync.io',
    apiBase: 'https://api.blockchair.com/zksync',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  blast: {
    name: 'Blast',
    symbol: 'ETH',
    explorer: 'https://blastscan.io',
    apiBase: 'https://api.blockchair.com/blast',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  mantle: {
    name: 'Mantle',
    symbol: 'MNT',
    explorer: 'https://mantlescan.xyz',
    apiBase: 'https://api.blockchair.com/mantle',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  celo: {
    name: 'Celo',
    symbol: 'CELO',
    explorer: 'https://celoscan.io',
    apiBase: 'https://api.blockchair.com/celo',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
  moonbeam: {
    name: 'Moonbeam',
    symbol: 'GLMR',
    explorer: 'https://moonscan.io',
    apiBase: 'https://api.blockchair.com/moonbeam',
    addressPattern: /^0x[a-fA-F0-9]{40}$/,
    txPattern: /^0x[a-fA-F0-9]{64}$/,
  },
};

export interface TracedTransaction {
  hash: string;
  blockNumber: number | null;
  timestamp: string;
  from: string;
  to: string;
  value: string;
  valueUSD: string | null;
  fee: string;
  direction: 'incoming' | 'outgoing' | 'self';
  tokenTransfer: boolean;
  tokenSymbol?: string;
  tokenAmount?: string;
  confirmed: boolean;
}

export interface AddressProfile {
  address: string;
  chain: string;
  chainName: string;
  balance: string;
  balanceUSD: string | null;
  totalReceived: string;
  totalSent: string;
  transactionCount: number;
  firstSeen: string | null;
  lastSeen: string | null;
  transactions: TracedTransaction[];
  riskIndicators: RiskIndicator[];
  connectedAddresses: ConnectedAddress[];
}

export interface RiskIndicator {
  type: 'high_volume' | 'rapid_movement' | 'mixer_pattern' | 'new_wallet' | 'drain_pattern' | 'exchange_deposit' | 'split_pattern' | 'dormant_activation';
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
}

export interface ConnectedAddress {
  address: string;
  relationship: 'sent_to' | 'received_from' | 'bidirectional';
  totalValue: string;
  transactionCount: number;
  firstInteraction: string | null;
  lastInteraction: string | null;
}

export interface TransactionDetail {
  hash: string;
  chain: string;
  chainName: string;
  blockNumber: number | null;
  blockHash: string | null;
  timestamp: string;
  from: string;
  to: string;
  value: string;
  valueUSD: string | null;
  fee: string;
  feeUSD: string | null;
  gasUsed: string | null;
  gasPrice: string | null;
  nonce: number | null;
  confirmed: boolean;
  confirmations: number;
  inputData: string | null;
  internalTransactions: Array<{
    from: string;
    to: string;
    value: string;
  }>;
}

export interface FundFlowNode {
  address: string;
  label: string;
  totalIn: string;
  totalOut: string;
  depth: number;
}

export interface FundFlowEdge {
  from: string;
  to: string;
  value: string;
  txHash: string;
  timestamp: string;
}

export interface FundFlowGraph {
  nodes: FundFlowNode[];
  edges: FundFlowEdge[];
  rootAddress: string;
  chain: string;
  depth: number;
}

function detectChain(input: string): string | null {
  if (input.startsWith('T') && CHAINS.tron.addressPattern.test(input)) return 'tron';
  if (input.startsWith('bc1') || input.startsWith('1') || input.startsWith('3')) {
    if (CHAINS.bitcoin.addressPattern.test(input) || CHAINS.bitcoin.txPattern.test(input)) return 'bitcoin';
  }
  if (input.startsWith('0x')) {
    return 'ethereum';
  }
  if (CHAINS.solana.addressPattern.test(input)) return 'solana';
  return null;
}

export function getSupportedChains() {
  return Object.entries(CHAINS).map(([id, config]) => ({
    id,
    name: config.name,
    symbol: config.symbol,
    explorer: config.explorer,
  }));
}

export function detectChainFromInput(input: string): { chain: string; type: 'address' | 'transaction' } | null {
  const trimmed = input.trim();
  const chain = detectChain(trimmed);
  if (!chain) return null;

  const config = CHAINS[chain];
  if (config.txPattern.test(trimmed)) {
    if (config.addressPattern.test(trimmed)) {
      return { chain, type: trimmed.length > 50 ? 'transaction' : 'address' };
    }
    return { chain, type: 'transaction' };
  }
  if (config.addressPattern.test(trimmed)) {
    return { chain, type: 'address' };
  }
  return null;
}

async function fetchWithTimeout(url: string, timeout = 15000): Promise<any> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const resp = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'AlphaForensicEngine/1.0',
        'Accept': 'application/json',
      },
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${resp.statusText}`);
    return await resp.json();
  } finally {
    clearTimeout(timer);
  }
}

async function traceAddressBlockchair(address: string, chain: string): Promise<AddressProfile | null> {
  const config = CHAINS[chain];
  if (!config) return null;

  try {
    const data = await fetchWithTimeout(
      `${config.apiBase}/dashboards/address/${address}?limit=50&offset=0`
    );

    if (!data?.data?.[address]) return null;
    const addrData = data.data[address];
    const addrInfo = addrData.address;

    const isEVMChain = ['ethereum', 'bsc', 'polygon', 'arbitrum', 'optimism', 'base', 'avalanche', 'fantom', 'cronos', 'gnosis', 'linea', 'scroll', 'zksync', 'blast', 'mantle', 'celo', 'moonbeam'].includes(chain);
    const isBitcoin = chain === 'bitcoin';

    let balance = '0';
    let totalReceived = '0';
    let totalSent = '0';
    let txCount = 0;
    let firstSeen: string | null = null;
    let lastSeen: string | null = null;
    let balanceUSD: string | null = null;

    if (isEVMChain) {
      const balWei = BigInt(addrInfo.balance || '0');
      balance = (Number(balWei) / 1e18).toFixed(6);
      totalReceived = (Number(BigInt(addrInfo.received || '0')) / 1e18).toFixed(6);
      totalSent = (Number(BigInt(addrInfo.spent || '0')) / 1e18).toFixed(6);
      txCount = addrInfo.transaction_count || 0;
      firstSeen = addrInfo.first_seen_receiving || null;
      lastSeen = addrInfo.last_seen_receiving || null;
      balanceUSD = addrInfo.balance_usd ? String(addrInfo.balance_usd) : null;
    } else if (isBitcoin) {
      balance = (Number(addrInfo.balance || 0) / 1e8).toFixed(8);
      totalReceived = (Number(addrInfo.received || 0) / 1e8).toFixed(8);
      totalSent = (Number(addrInfo.spent || 0) / 1e8).toFixed(8);
      txCount = addrInfo.transaction_count || 0;
      firstSeen = addrInfo.first_seen_receiving || null;
      lastSeen = addrInfo.last_seen_receiving || null;
      balanceUSD = addrInfo.balance_usd ? String(addrInfo.balance_usd) : null;
    } else {
      balance = String(addrInfo.balance || '0');
      txCount = addrInfo.transaction_count || 0;
      firstSeen = addrInfo.first_seen_receiving || null;
      lastSeen = addrInfo.last_seen_receiving || null;
      balanceUSD = addrInfo.balance_usd ? String(addrInfo.balance_usd) : null;
    }

    const transactions: TracedTransaction[] = [];
    const txHashes: string[] = addrData.transactions || [];

    if (txHashes.length > 0 && isEVMChain) {
      try {
        const txBatch = txHashes.slice(0, 20);
        const txData = await fetchWithTimeout(
          `${config.apiBase}/dashboards/transactions/${txBatch.join(',')}`
        );
        if (txData?.data) {
          for (const [hash, txInfo] of Object.entries(txData.data as Record<string, any>)) {
            const tx = txInfo.transaction;
            if (!tx) continue;
            const fromAddr = (tx.sender || '').toLowerCase();
            const toAddr = (tx.recipient || '').toLowerCase();
            const addrLower = address.toLowerCase();
            const direction = fromAddr === addrLower && toAddr === addrLower ? 'self'
              : fromAddr === addrLower ? 'outgoing' : 'incoming';
            transactions.push({
              hash,
              blockNumber: tx.block_id || null,
              timestamp: tx.time || '',
              from: tx.sender || '',
              to: tx.recipient || '',
              value: (Number(BigInt(tx.value || '0')) / 1e18).toFixed(6),
              valueUSD: tx.value_usd ? String(tx.value_usd) : null,
              fee: tx.fee ? (Number(BigInt(tx.fee)) / 1e18).toFixed(8) : '0',
              direction,
              tokenTransfer: tx.internal_value ? true : false,
              confirmed: true,
            });
          }
        }
      } catch (e) {
        console.log('[ForensicTracer] Could not fetch tx details:', (e as Error).message);
      }
    } else if (txHashes.length > 0 && isBitcoin) {
      try {
        const txBatch = txHashes.slice(0, 10);
        const txData = await fetchWithTimeout(
          `${config.apiBase}/dashboards/transactions/${txBatch.join(',')}`
        );
        if (txData?.data) {
          for (const [hash, txInfo] of Object.entries(txData.data as Record<string, any>)) {
            const tx = (txInfo as any).transaction;
            if (!tx) continue;
            const isInput = tx.input_total_usd > 0;
            transactions.push({
              hash,
              blockNumber: tx.block_id || null,
              timestamp: tx.time || '',
              from: 'Multiple Inputs',
              to: 'Multiple Outputs',
              value: ((tx.output_total || 0) / 1e8).toFixed(8),
              valueUSD: tx.output_total_usd ? String(tx.output_total_usd) : null,
              fee: ((tx.fee || 0) / 1e8).toFixed(8),
              direction: isInput ? 'outgoing' : 'incoming',
              tokenTransfer: false,
              confirmed: tx.block_id > 0,
            });
          }
        }
      } catch (e) {
        console.log('[ForensicTracer] Could not fetch BTC tx details:', (e as Error).message);
      }
    }

    const connectedAddresses: ConnectedAddress[] = [];
    const addressMap = new Map<string, { sent: number; received: number; count: number; first: string | null; last: string | null }>();
    for (const tx of transactions) {
      const counterparty = tx.direction === 'outgoing' ? tx.to : tx.from;
      if (!counterparty || counterparty === address || counterparty === 'Multiple Inputs' || counterparty === 'Multiple Outputs') continue;
      const existing = addressMap.get(counterparty) || { sent: 0, received: 0, count: 0, first: null, last: null };
      existing.count++;
      if (tx.direction === 'outgoing') existing.sent += parseFloat(tx.value);
      else existing.received += parseFloat(tx.value);
      if (!existing.first || tx.timestamp < existing.first) existing.first = tx.timestamp;
      if (!existing.last || tx.timestamp > existing.last) existing.last = tx.timestamp;
      addressMap.set(counterparty, existing);
    }
    for (const [addr, info] of addressMap) {
      connectedAddresses.push({
        address: addr,
        relationship: info.sent > 0 && info.received > 0 ? 'bidirectional'
          : info.sent > 0 ? 'sent_to' : 'received_from',
        totalValue: (info.sent + info.received).toFixed(6),
        transactionCount: info.count,
        firstInteraction: info.first,
        lastInteraction: info.last,
      });
    }
    connectedAddresses.sort((a, b) => parseFloat(b.totalValue) - parseFloat(a.totalValue));

    const riskIndicators = analyzeRisks(address, {
      balance: parseFloat(balance),
      txCount,
      firstSeen,
      lastSeen,
      transactions,
      totalReceived: parseFloat(totalReceived),
      totalSent: parseFloat(totalSent),
    });

    return {
      address,
      chain,
      chainName: config.name,
      balance,
      balanceUSD,
      totalReceived,
      totalSent,
      transactionCount: txCount,
      firstSeen,
      lastSeen,
      transactions: transactions.sort((a, b) => b.timestamp.localeCompare(a.timestamp)),
      riskIndicators,
      connectedAddresses: connectedAddresses.slice(0, 50),
    };
  } catch (err) {
    console.error(`[ForensicTracer] Blockchair trace failed for ${chain}/${address}:`, (err as Error).message);
    return null;
  }
}

async function traceAddressEtherscanFallback(address: string): Promise<AddressProfile | null> {
  try {
    const addrResp = await fetchWithTimeout(
      `https://eth.blockscout.com/api/v2/addresses/${address}`
    );
    const txResp = await fetchWithTimeout(
      `https://eth.blockscout.com/api/v2/addresses/${address}/transactions`
    );

    let balance = '0';
    try {
      balance = (Number(BigInt(addrResp?.coin_balance || '0')) / 1e18).toFixed(6);
    } catch {
      balance = '0';
    }

    const transactions: TracedTransaction[] = [];
    const txList = txResp?.items || [];
    if (Array.isArray(txList)) {
      for (const tx of txList) {
        const fromAddr = (tx.from?.hash || '').toLowerCase();
        const toAddr = (tx.to?.hash || '').toLowerCase();
        const addrLower = address.toLowerCase();
        const direction = fromAddr === addrLower && toAddr === addrLower ? 'self'
          : fromAddr === addrLower ? 'outgoing' : 'incoming';
        let value = '0';
        try { value = (Number(BigInt(tx.value || '0')) / 1e18).toFixed(6); } catch { value = '0'; }
        let fee = '0';
        try { fee = (Number(BigInt(tx.fee?.value || '0')) / 1e18).toFixed(8); } catch { fee = '0'; }
        transactions.push({
          hash: tx.hash,
          blockNumber: tx.block_number || tx.block || null,
          timestamp: tx.timestamp || '',
          from: tx.from?.hash || '',
          to: tx.to?.hash || 'Contract Creation',
          value,
          valueUSD: null,
          fee,
          direction,
          tokenTransfer: tx.token_transfers_overflow || false,
          confirmed: tx.status === 'ok',
        });
      }
    }

    let totalReceived = 0, totalSent = 0;
    for (const tx of transactions) {
      if (tx.direction === 'incoming') totalReceived += parseFloat(tx.value);
      else if (tx.direction === 'outgoing') totalSent += parseFloat(tx.value);
    }

    const connectedAddresses: ConnectedAddress[] = [];
    const addressMap = new Map<string, { sent: number; received: number; count: number; first: string | null; last: string | null }>();
    for (const tx of transactions) {
      const counterparty = tx.direction === 'outgoing' ? tx.to : tx.from;
      if (!counterparty || counterparty.toLowerCase() === address.toLowerCase()) continue;
      const existing = addressMap.get(counterparty) || { sent: 0, received: 0, count: 0, first: null, last: null };
      existing.count++;
      if (tx.direction === 'outgoing') existing.sent += parseFloat(tx.value);
      else existing.received += parseFloat(tx.value);
      if (!existing.first || tx.timestamp < existing.first) existing.first = tx.timestamp;
      if (!existing.last || tx.timestamp > existing.last) existing.last = tx.timestamp;
      addressMap.set(counterparty, existing);
    }
    for (const [addr, info] of addressMap) {
      connectedAddresses.push({
        address: addr,
        relationship: info.sent > 0 && info.received > 0 ? 'bidirectional'
          : info.sent > 0 ? 'sent_to' : 'received_from',
        totalValue: (info.sent + info.received).toFixed(6),
        transactionCount: info.count,
        firstInteraction: info.first,
        lastInteraction: info.last,
      });
    }
    connectedAddresses.sort((a, b) => parseFloat(b.totalValue) - parseFloat(a.totalValue));

    const riskIndicators = analyzeRisks(address, {
      balance: parseFloat(balance),
      txCount: transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      totalReceived,
      totalSent,
    });

    return {
      address,
      chain: 'ethereum',
      chainName: 'Ethereum',
      balance,
      balanceUSD: null,
      totalReceived: totalReceived.toFixed(6),
      totalSent: totalSent.toFixed(6),
      transactionCount: transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      riskIndicators,
      connectedAddresses: connectedAddresses.slice(0, 50),
    };
  } catch (err) {
    console.error('[ForensicTracer] Etherscan fallback failed:', (err as Error).message);
    return null;
  }
}

async function traceAddressBitcoinFallback(address: string): Promise<AddressProfile | null> {
  try {
    const data = await fetchWithTimeout(
      `https://blockchain.info/rawaddr/${address}?limit=50`
    );
    if (!data) return null;

    const balance = (data.final_balance / 1e8).toFixed(8);
    const totalReceived = (data.total_received / 1e8).toFixed(8);
    const totalSent = (data.total_sent / 1e8).toFixed(8);

    const transactions: TracedTransaction[] = [];
    for (const tx of (data.txs || []).slice(0, 50)) {
      let inputValue = 0, outputValue = 0;
      let isInput = false, isOutput = false;
      const fromAddresses: string[] = [];
      const toAddresses: string[] = [];

      for (const inp of tx.inputs || []) {
        if (inp.prev_out?.addr === address) {
          isInput = true;
          inputValue += inp.prev_out.value || 0;
        }
        if (inp.prev_out?.addr) fromAddresses.push(inp.prev_out.addr);
      }
      for (const out of tx.out || []) {
        if (out.addr === address) {
          isOutput = true;
          outputValue += out.value || 0;
        }
        if (out.addr) toAddresses.push(out.addr);
      }

      const direction = isInput && isOutput ? 'self' : isInput ? 'outgoing' : 'incoming';
      const value = direction === 'outgoing' ? inputValue : outputValue;

      transactions.push({
        hash: tx.hash,
        blockNumber: tx.block_height || null,
        timestamp: tx.time ? new Date(tx.time * 1000).toISOString() : '',
        from: fromAddresses[0] || 'Coinbase',
        to: toAddresses[0] || 'Unknown',
        value: (value / 1e8).toFixed(8),
        valueUSD: null,
        fee: ((tx.fee || 0) / 1e8).toFixed(8),
        direction,
        tokenTransfer: false,
        confirmed: !!tx.block_height,
      });
    }

    const connectedAddresses: ConnectedAddress[] = [];
    const addressMap = new Map<string, { sent: number; received: number; count: number; first: string | null; last: string | null }>();
    for (const tx of transactions) {
      const counterparty = tx.direction === 'outgoing' ? tx.to : tx.from;
      if (!counterparty || counterparty === address || counterparty === 'Coinbase' || counterparty === 'Unknown') continue;
      const existing = addressMap.get(counterparty) || { sent: 0, received: 0, count: 0, first: null, last: null };
      existing.count++;
      if (tx.direction === 'outgoing') existing.sent += parseFloat(tx.value);
      else existing.received += parseFloat(tx.value);
      if (!existing.first || tx.timestamp < existing.first) existing.first = tx.timestamp;
      if (!existing.last || tx.timestamp > existing.last) existing.last = tx.timestamp;
      addressMap.set(counterparty, existing);
    }
    for (const [addr, info] of addressMap) {
      connectedAddresses.push({
        address: addr,
        relationship: info.sent > 0 && info.received > 0 ? 'bidirectional'
          : info.sent > 0 ? 'sent_to' : 'received_from',
        totalValue: (info.sent + info.received).toFixed(8),
        transactionCount: info.count,
        firstInteraction: info.first,
        lastInteraction: info.last,
      });
    }
    connectedAddresses.sort((a, b) => parseFloat(b.totalValue) - parseFloat(a.totalValue));

    const riskIndicators = analyzeRisks(address, {
      balance: parseFloat(balance),
      txCount: data.n_tx || transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      totalReceived: parseFloat(totalReceived),
      totalSent: parseFloat(totalSent),
    });

    return {
      address,
      chain: 'bitcoin',
      chainName: 'Bitcoin',
      balance,
      balanceUSD: null,
      totalReceived,
      totalSent,
      transactionCount: data.n_tx || transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      riskIndicators,
      connectedAddresses: connectedAddresses.slice(0, 50),
    };
  } catch (err) {
    console.error('[ForensicTracer] Bitcoin fallback failed:', (err as Error).message);
    return null;
  }
}

async function traceAddressBlockscoutFallback(address: string, chain: string, apiBase: string): Promise<AddressProfile | null> {
  try {
    const chainConfig = CHAINS[chain];
    const addrResp = await fetchWithTimeout(`${apiBase}/addresses/${address}`);
    const txResp = await fetchWithTimeout(`${apiBase}/addresses/${address}/transactions`);

    let balance = '0';
    try {
      const decimals = ['ethereum', 'arbitrum', 'optimism', 'base', 'linea', 'scroll', 'zksync', 'blast', 'gnosis', 'mantle', 'moonbeam', 'polygon', 'bsc', 'avalanche', 'fantom', 'cronos', 'celo'].includes(chain) ? 1e18 : 1e18;
      balance = (Number(BigInt(addrResp?.coin_balance || '0')) / decimals).toFixed(6);
    } catch {
      balance = '0';
    }

    const transactions: TracedTransaction[] = [];
    const txList = txResp?.items || [];
    if (Array.isArray(txList)) {
      for (const tx of txList) {
        const fromAddr = (tx.from?.hash || '').toLowerCase();
        const toAddr = (tx.to?.hash || '').toLowerCase();
        const addrLower = address.toLowerCase();
        const direction = fromAddr === addrLower && toAddr === addrLower ? 'self'
          : fromAddr === addrLower ? 'outgoing' : 'incoming';
        let value = '0';
        try { value = (Number(BigInt(tx.value || '0')) / 1e18).toFixed(6); } catch { value = '0'; }
        let fee = '0';
        try { fee = (Number(BigInt(tx.fee?.value || '0')) / 1e18).toFixed(8); } catch { fee = '0'; }
        transactions.push({
          hash: tx.hash,
          blockNumber: tx.block_number || tx.block || null,
          timestamp: tx.timestamp || '',
          from: tx.from?.hash || '',
          to: tx.to?.hash || 'Contract Creation',
          value,
          valueUSD: null,
          fee,
          direction,
          tokenTransfer: tx.token_transfers_overflow || false,
          confirmed: tx.status === 'ok',
        });
      }
    }

    let totalReceived = 0, totalSent = 0;
    for (const tx of transactions) {
      if (tx.direction === 'incoming') totalReceived += parseFloat(tx.value);
      else if (tx.direction === 'outgoing') totalSent += parseFloat(tx.value);
    }

    const connectedAddresses: ConnectedAddress[] = [];
    const addressMap = new Map<string, { sent: number; received: number; count: number; first: string | null; last: string | null }>();
    for (const tx of transactions) {
      const counterparty = tx.direction === 'outgoing' ? tx.to : tx.from;
      if (!counterparty || counterparty.toLowerCase() === address.toLowerCase()) continue;
      const existing = addressMap.get(counterparty) || { sent: 0, received: 0, count: 0, first: null, last: null };
      existing.count++;
      if (tx.direction === 'outgoing') existing.sent += parseFloat(tx.value);
      else existing.received += parseFloat(tx.value);
      if (!existing.first || tx.timestamp < existing.first) existing.first = tx.timestamp;
      if (!existing.last || tx.timestamp > existing.last) existing.last = tx.timestamp;
      addressMap.set(counterparty, existing);
    }
    for (const [addr, info] of addressMap) {
      connectedAddresses.push({
        address: addr,
        relationship: info.sent > 0 && info.received > 0 ? 'bidirectional'
          : info.sent > 0 ? 'sent_to' : 'received_from',
        totalValue: (info.sent + info.received).toFixed(6),
        transactionCount: info.count,
        firstInteraction: info.first,
        lastInteraction: info.last,
      });
    }
    connectedAddresses.sort((a, b) => parseFloat(b.totalValue) - parseFloat(a.totalValue));

    const riskIndicators = analyzeRisks(address, {
      balance: parseFloat(balance),
      txCount: transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      totalReceived,
      totalSent,
    });

    return {
      address,
      chain,
      chainName: chainConfig?.name || chain,
      balance,
      balanceUSD: null,
      totalReceived: totalReceived.toFixed(6),
      totalSent: totalSent.toFixed(6),
      transactionCount: transactions.length,
      firstSeen: transactions.length > 0 ? transactions[transactions.length - 1].timestamp : null,
      lastSeen: transactions.length > 0 ? transactions[0].timestamp : null,
      transactions,
      riskIndicators,
      connectedAddresses: connectedAddresses.slice(0, 50),
    };
  } catch (err) {
    console.error(`[ForensicTracer] Blockscout ${chain} fallback failed:`, (err as Error).message);
    return null;
  }
}

function analyzeRisks(address: string, data: {
  balance: number;
  txCount: number;
  firstSeen: string | null;
  lastSeen: string | null;
  transactions: TracedTransaction[];
  totalReceived: number;
  totalSent: number;
}): RiskIndicator[] {
  const risks: RiskIndicator[] = [];

  if (data.totalReceived > 1000) {
    risks.push({
      type: 'high_volume',
      severity: data.totalReceived > 10000 ? 'critical' : 'high',
      description: `High volume address: ${data.totalReceived.toFixed(4)} total received`,
    });
  }

  if (data.balance < data.totalReceived * 0.01 && data.totalReceived > 10) {
    risks.push({
      type: 'drain_pattern',
      severity: 'critical',
      description: `Wallet drained: ${((1 - data.balance / data.totalReceived) * 100).toFixed(1)}% of received funds moved out`,
    });
  }

  if (data.firstSeen) {
    const walletAge = Date.now() - new Date(data.firstSeen).getTime();
    const dayAge = walletAge / (1000 * 60 * 60 * 24);
    if (dayAge < 7 && data.txCount > 10) {
      risks.push({
        type: 'new_wallet',
        severity: 'high',
        description: `New wallet with high activity: ${data.txCount} txs in ${dayAge.toFixed(1)} days`,
      });
    }
  }

  const recentTxs = data.transactions.slice(0, 10);
  if (recentTxs.length >= 3) {
    const outgoing = recentTxs.filter(tx => tx.direction === 'outgoing');
    if (outgoing.length >= 3) {
      const timestamps = outgoing.map(tx => new Date(tx.timestamp).getTime()).filter(t => t > 0);
      if (timestamps.length >= 3) {
        const gaps = [];
        for (let i = 0; i < timestamps.length - 1; i++) {
          gaps.push(Math.abs(timestamps[i] - timestamps[i + 1]));
        }
        const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
        if (avgGap < 5 * 60 * 1000) {
          risks.push({
            type: 'rapid_movement',
            severity: 'critical',
            description: `Rapid fund movement detected: ${outgoing.length} outgoing txs within minutes`,
          });
        }
      }
    }
  }

  const uniqueRecipients = new Set(
    data.transactions
      .filter(tx => tx.direction === 'outgoing')
      .map(tx => tx.to)
  );
  if (uniqueRecipients.size >= 5 && uniqueRecipients.size > data.transactions.length * 0.7) {
    risks.push({
      type: 'split_pattern',
      severity: 'high',
      description: `Fund splitting detected: ${uniqueRecipients.size} unique recipients from ${data.transactions.filter(t => t.direction === 'outgoing').length} outgoing txs`,
    });
  }

  if (data.firstSeen && data.lastSeen) {
    const lastActivity = Date.now() - new Date(data.lastSeen).getTime();
    const walletAge = new Date(data.lastSeen).getTime() - new Date(data.firstSeen).getTime();
    const dormantPeriod = walletAge - lastActivity;
    if (dormantPeriod > 180 * 24 * 60 * 60 * 1000 && lastActivity < 7 * 24 * 60 * 60 * 1000) {
      risks.push({
        type: 'dormant_activation',
        severity: 'medium',
        description: 'Previously dormant wallet recently reactivated',
      });
    }
  }

  return risks;
}

export async function traceAddress(address: string, chain?: string): Promise<AddressProfile | null> {
  const detectedChain = chain || detectChain(address);
  if (!detectedChain) return null;

  console.log(`[ForensicTracer] Tracing ${detectedChain} address: ${address.slice(0, 10)}...`);

  let result = await traceAddressBlockchair(address, detectedChain);

  if (result && result.transactions.length === 0 && result.transactionCount > 0 && detectedChain === 'ethereum') {
    console.log('[ForensicTracer] Blockchair returned no tx details, enriching with Etherscan...');
    const ethResult = await traceAddressEtherscanFallback(address);
    if (ethResult && ethResult.transactions.length > 0) {
      result.transactions = ethResult.transactions;
      result.connectedAddresses = ethResult.connectedAddresses;
      if (ethResult.totalReceived !== '0') result.totalReceived = ethResult.totalReceived;
      if (ethResult.totalSent !== '0') result.totalSent = ethResult.totalSent;
      result.riskIndicators = analyzeRisks(address, {
        balance: parseFloat(result.balance),
        txCount: result.transactionCount,
        firstSeen: result.firstSeen,
        lastSeen: result.lastSeen,
        transactions: result.transactions,
        totalReceived: parseFloat(result.totalReceived),
        totalSent: parseFloat(result.totalSent),
      });
    }
  }

  if (!result && detectedChain === 'ethereum') {
    console.log('[ForensicTracer] Blockchair failed, trying Etherscan fallback...');
    result = await traceAddressEtherscanFallback(address);
  }

  const blockscoutFallbackChains: Record<string, string> = {
    arbitrum: 'https://arbitrum.blockscout.com/api/v2',
    optimism: 'https://optimism.blockscout.com/api/v2',
    base: 'https://base.blockscout.com/api/v2',
    gnosis: 'https://gnosis.blockscout.com/api/v2',
    polygon: 'https://polygon.blockscout.com/api/v2',
    zksync: 'https://zksync.blockscout.com/api/v2',
    linea: 'https://linea.blockscout.com/api/v2',
    scroll: 'https://scroll.blockscout.com/api/v2',
    celo: 'https://celo.blockscout.com/api/v2',
    mantle: 'https://explorer.mantle.xyz/api/v2',
    blast: 'https://blast.blockscout.com/api/v2',
    moonbeam: 'https://moonbeam.blockscout.com/api/v2',
    bsc: 'https://bsc.blockscout.com/api/v2',
    avalanche: 'https://avalanche.blockscout.com/api/v2',
    fantom: 'https://fantom.blockscout.com/api/v2',
    cronos: 'https://cronos.blockscout.com/api/v2',
  };

  if (result && result.transactions.length === 0 && result.transactionCount > 0 && blockscoutFallbackChains[detectedChain]) {
    console.log(`[ForensicTracer] Blockchair returned no tx details for ${detectedChain}, enriching with Blockscout...`);
    const bsResult = await traceAddressBlockscoutFallback(address, detectedChain, blockscoutFallbackChains[detectedChain]);
    if (bsResult && bsResult.transactions.length > 0) {
      result.transactions = bsResult.transactions;
      result.connectedAddresses = bsResult.connectedAddresses;
      if (bsResult.totalReceived !== '0') result.totalReceived = bsResult.totalReceived;
      if (bsResult.totalSent !== '0') result.totalSent = bsResult.totalSent;
      result.riskIndicators = analyzeRisks(address, {
        balance: parseFloat(result.balance),
        txCount: result.transactionCount,
        firstSeen: result.firstSeen,
        lastSeen: result.lastSeen,
        transactions: result.transactions,
        totalReceived: parseFloat(result.totalReceived),
        totalSent: parseFloat(result.totalSent),
      });
    }
  }

  if (!result && blockscoutFallbackChains[detectedChain]) {
    console.log(`[ForensicTracer] Blockchair failed for ${detectedChain}, trying Blockscout fallback...`);
    result = await traceAddressBlockscoutFallback(address, detectedChain, blockscoutFallbackChains[detectedChain]);
  }

  if (result && result.transactions.length === 0 && result.transactionCount > 0 && detectedChain === 'bitcoin') {
    console.log('[ForensicTracer] Blockchair returned no BTC tx details, enriching with Blockchain.info...');
    const btcResult = await traceAddressBitcoinFallback(address);
    if (btcResult && btcResult.transactions.length > 0) {
      result.transactions = btcResult.transactions;
      result.connectedAddresses = btcResult.connectedAddresses;
      result.riskIndicators = analyzeRisks(address, {
        balance: parseFloat(result.balance),
        txCount: result.transactionCount,
        firstSeen: result.firstSeen,
        lastSeen: result.lastSeen,
        transactions: result.transactions,
        totalReceived: parseFloat(result.totalReceived),
        totalSent: parseFloat(result.totalSent),
      });
    }
  }

  if (!result && detectedChain === 'bitcoin') {
    console.log('[ForensicTracer] Blockchair failed, trying Blockchain.info fallback...');
    result = await traceAddressBitcoinFallback(address);
  }

  return result;
}

export async function traceTransaction(txHash: string, chain?: string): Promise<TransactionDetail | null> {
  const detectedChain = chain || detectChain(txHash) || 'ethereum';
  const config = CHAINS[detectedChain];
  if (!config) return null;

  console.log(`[ForensicTracer] Tracing ${detectedChain} tx: ${txHash.slice(0, 10)}...`);

  try {
    const data = await fetchWithTimeout(
      `${config.apiBase}/dashboards/transaction/${txHash}`
    );

    if (!data?.data?.[txHash]) {
      return traceTransactionBlockscoutFallback(txHash, detectedChain);
    }

    const tx = data.data[txHash].transaction;
    const isEVM = ['ethereum', 'bsc', 'polygon', 'arbitrum', 'optimism', 'base', 'avalanche', 'fantom', 'cronos', 'gnosis', 'linea', 'scroll', 'zksync', 'blast', 'mantle', 'celo', 'moonbeam'].includes(detectedChain);

    return {
      hash: txHash,
      chain: detectedChain,
      chainName: config.name,
      blockNumber: tx.block_id || null,
      blockHash: null,
      timestamp: tx.time || '',
      from: tx.sender || tx.input_address || '',
      to: tx.recipient || tx.output_address || '',
      value: isEVM
        ? (Number(BigInt(tx.value || '0')) / 1e18).toFixed(6)
        : detectedChain === 'bitcoin'
          ? ((tx.output_total || 0) / 1e8).toFixed(8)
          : String(tx.value || '0'),
      valueUSD: tx.value_usd ? String(tx.value_usd) : tx.output_total_usd ? String(tx.output_total_usd) : null,
      fee: isEVM
        ? (Number(BigInt(tx.fee || '0')) / 1e18).toFixed(8)
        : detectedChain === 'bitcoin'
          ? ((tx.fee || 0) / 1e8).toFixed(8)
          : String(tx.fee || '0'),
      feeUSD: tx.fee_usd ? String(tx.fee_usd) : null,
      gasUsed: tx.gas_used ? String(tx.gas_used) : null,
      gasPrice: tx.gas_price ? String(tx.gas_price) : null,
      nonce: tx.nonce ?? null,
      confirmed: tx.block_id > 0,
      confirmations: 0,
      inputData: tx.input_hex || null,
      internalTransactions: (data.data[txHash].calls || []).map((c: any) => ({
        from: c.sender || '',
        to: c.recipient || '',
        value: isEVM ? (Number(BigInt(c.value || '0')) / 1e18).toFixed(6) : String(c.value || '0'),
      })),
    };
  } catch (err) {
    console.error(`[ForensicTracer] Transaction trace failed:`, (err as Error).message);
    return traceTransactionBlockscoutFallback(txHash, detectedChain);
  }
}

const TX_BLOCKSCOUT_ENDPOINTS: Record<string, string> = {
  ethereum: 'https://eth.blockscout.com/api/v2',
  arbitrum: 'https://arbitrum.blockscout.com/api/v2',
  optimism: 'https://optimism.blockscout.com/api/v2',
  base: 'https://base.blockscout.com/api/v2',
  polygon: 'https://polygon.blockscout.com/api/v2',
  bsc: 'https://bsc.blockscout.com/api/v2',
  gnosis: 'https://gnosis.blockscout.com/api/v2',
  avalanche: 'https://avalanche.blockscout.com/api/v2',
  fantom: 'https://fantom.blockscout.com/api/v2',
  zksync: 'https://zksync.blockscout.com/api/v2',
  linea: 'https://linea.blockscout.com/api/v2',
  scroll: 'https://scroll.blockscout.com/api/v2',
  celo: 'https://celo.blockscout.com/api/v2',
  blast: 'https://blast.blockscout.com/api/v2',
  mantle: 'https://explorer.mantle.xyz/api/v2',
  moonbeam: 'https://moonbeam.blockscout.com/api/v2',
  cronos: 'https://cronos.blockscout.com/api/v2',
};

async function traceTransactionBlockscoutFallback(txHash: string, chain: string): Promise<TransactionDetail | null> {
  const apiBase = TX_BLOCKSCOUT_ENDPOINTS[chain];
  if (!apiBase) return null;

  try {
    const data = await fetchWithTimeout(`${apiBase}/transactions/${txHash}`);
    if (!data?.hash) return null;

    const chainConfig = CHAINS[chain];
    let value = '0';
    try { value = (Number(BigInt(data.value || '0')) / 1e18).toFixed(6); } catch { value = '0'; }
    let fee = '0';
    try { fee = (Number(BigInt(data.fee?.value || '0')) / 1e18).toFixed(8); } catch { fee = '0'; }

    return {
      hash: txHash,
      chain,
      chainName: chainConfig?.name || chain,
      blockNumber: data.block_number || data.block || null,
      blockHash: null,
      timestamp: data.timestamp || '',
      from: data.from?.hash || '',
      to: data.to?.hash || 'Contract Creation',
      value,
      valueUSD: null,
      fee,
      feeUSD: null,
      gasUsed: data.gas_used ? String(data.gas_used) : null,
      gasPrice: data.gas_price ? String(data.gas_price) : null,
      nonce: data.nonce ?? null,
      confirmed: data.status === 'ok',
      confirmations: data.confirmations || 0,
      inputData: data.raw_input || null,
      internalTransactions: [],
    };
  } catch (err) {
    console.error(`[ForensicTracer] Blockscout ${chain} tx fallback failed:`, (err as Error).message);
    return null;
  }
}

export async function traceFundFlow(address: string, chain: string, maxDepth: number = 2, direction: 'forward' | 'backward' = 'forward'): Promise<FundFlowGraph> {
  const nodes: FundFlowNode[] = [];
  const edges: FundFlowEdge[] = [];
  const visited = new Set<string>();

  async function crawl(addr: string, depth: number) {
    if (depth > maxDepth || visited.has(addr.toLowerCase())) return;
    visited.add(addr.toLowerCase());

    const profile = await traceAddress(addr, chain);
    if (!profile) return;

    nodes.push({
      address: addr,
      label: addr.slice(0, 6) + '...' + addr.slice(-4),
      totalIn: profile.totalReceived,
      totalOut: profile.totalSent,
      depth,
    });

    const relevantTxs = profile.transactions.filter(tx =>
      direction === 'forward' ? tx.direction === 'outgoing' : tx.direction === 'incoming'
    ).slice(0, 5);

    for (const tx of relevantTxs) {
      const nextAddr = direction === 'forward' ? tx.to : tx.from;
      if (!nextAddr || nextAddr === addr || nextAddr === 'Multiple Inputs' || nextAddr === 'Multiple Outputs' || nextAddr === 'Contract Creation') continue;

      edges.push({
        from: direction === 'forward' ? addr : nextAddr,
        to: direction === 'forward' ? nextAddr : addr,
        value: tx.value,
        txHash: tx.hash,
        timestamp: tx.timestamp,
      });

      if (depth < maxDepth) {
        await crawl(nextAddr, depth + 1);
      } else if (!visited.has(nextAddr.toLowerCase())) {
        nodes.push({
          address: nextAddr,
          label: nextAddr.slice(0, 6) + '...' + nextAddr.slice(-4),
          totalIn: '0',
          totalOut: '0',
          depth: depth + 1,
        });
      }
    }
  }

  await crawl(address, 0);

  return {
    nodes,
    edges,
    rootAddress: address,
    chain,
    depth: maxDepth,
  };
}
