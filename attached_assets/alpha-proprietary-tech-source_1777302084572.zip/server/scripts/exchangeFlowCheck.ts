/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_EXCHANGE_FLOW_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_ExchangeFlow_Calibration_PROTECTED
 */
import { db } from "../db.js";
import { monitoredWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const BE = "https://eth.blockscout.com/api/v2";
const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

const KNOWN_EXCHANGES: Record<string, string> = {
  "0x46340b20830761efd32832a74d7169b29feb9758": "Crypto.com Hot Wallet 2",
  "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com Main Hot Wallet",
  "0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com Hot Wallet 3",
  "0x72a53cdbbcc1b9efa39c834a540550e23463aacb": "Crypto.com Exchange",
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance",
  "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance 8",
  "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance 7",
  "0xa7efae728d2936e78bda97dc267687568dd593f3": "OKX",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX 2",
  "0x98ec059dc3adfbdd63429227d09cb015b78fc709": "OKX 3",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase 1",
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase 2",
  "0x3cd751e6b0078be393132286c442345e5dc49699": "Coinbase 4",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase 10",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase 3",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken",
  "0x53d284357ec70ce289d6d64134dfac8e511c8a3d": "Kraken 4",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken 6",
  "0xae2d4617c862309a3d75a0ffb358c7a5009c673f": "Kraken 10",
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": "KuCoin",
  "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin 2",
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io",
  "0xd793281b45ceebfc1b3bac8f16a003e8ba03c2dd": "Gate.io 2",
  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io 3",
  "0x1681195c176239ac5e72d9aebacf5b2492e0c4ee": "Bitfinex",
  "0x876eabf441b2ee5b5b0554fd502a8e0600950cfa": "Bitfinex 4",
  "0x742d35cc6634c0532925a3b844bc9e7595f2bd3e": "Bitfinex 2",
  "0xbf3aeb96e164ae67e763d9e050ff124e7c3fdd28": "Bitget",
  "0x5bdf85216ec1e38d6458c870992a69e38e03f7ef": "Bitget Hot",
  "0x2faf487a4414fe77e2327f0bf4ae2a264a776ad2": "FTX (defunct)",
  "0xc098b2a3aa256d2140208c3de6543aaef5cd3a94": "FTX 2",
  "0xab5c66752a9e8167967685f1450532fb96d5d24f": "Huobi",
  "0x18709e89bd403f470088abdacebe86cc60dda12e": "Huobi 2",
  "0x6748f50f686bfbca6fe8ad62b22228b87f31ff2b": "Huobi 3",
  "0xeee27662c2b8eba3cd936a23f039f3189633e4c8": "Bybit",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit 2",
  "0xe93381fb4c4f14bda253907b18fad305d799cee7": "Huobi 7",
};

async function api(url: string): Promise<any> {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function main() {
  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
  
  // Get important wallets only
  const important = wallets.filter(w => {
    const role = (w.role || "").toLowerCase();
    return role !== "token_recipient" && !role.includes("victim");
  });
  
  // Add key addresses
  const toCheck: Array<{addr: string; label: string}> = [
    {addr: "0x658370618BBc885865df66c1061BfE4771FaD846", label: "Crypto.com Suspect Wallet"},
    {addr: "0xf70da97812cb96acdf810712aa562db8dfa3dbef", label: "POI / GFF ($4.35M)"},
    {addr: "0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb", label: "Source Wallet (EIP-7702)"},
    {addr: "0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7", label: "Gas Funder"},
    {addr: "0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872", label: "Laundering Hub"},
    {addr: "0x423d2b61952d56358db8b313ec7404a9582d4865", label: "Original Funder"},
    {addr: "0xd8cFAaceB9719d7c5c68c0AD876E619C180770c6", label: "Hub DAI Dispersal 7"},
  ];
  
  const seen = new Set<string>();
  for (const x of toCheck) seen.add(x.addr.toLowerCase());
  
  for (const w of important) {
    const lo = w.address.toLowerCase();
    if (!seen.has(lo) && lo.startsWith("0x") && lo.length === 42 && (w.chain || "ethereum").toLowerCase() !== "arbitrum") {
      seen.add(lo);
      toCheck.push({addr: w.address, label: `${w.label || ""} [${w.role || ""}]`});
    }
  }

  console.log(`\n═══ EXCHANGE FLOW CHECK — ${new Date().toISOString()} ═══`);
  console.log(`Checking ${toCheck.length} wallets for transfers TO/FROM known exchanges...\n`);

  const exchangeFlows: Array<{wallet: string; walletLabel: string; direction: string; exchange: string; amount: string; token: string; timestamp: string; txHash: string}> = [];
  
  let checked = 0;
  for (const {addr, label} of toCheck) {
    checked++;
    if (checked % 10 === 0) console.log(`  Progress: ${checked}/${toCheck.length}...`);
    
    const data = await api(`${BE}/addresses/${addr.toLowerCase()}/token-transfers`);
    await sleep(150);
    
    if (!data?.items) continue;
    
    for (const tt of data.items) {
      const from = (tt.from?.hash || "").toLowerCase();
      const to = (tt.to?.hash || "").toLowerCase();
      const fromName = tt.from?.name || "";
      const toName = tt.to?.name || "";
      const sym = tt.token?.symbol || "???";
      const dec = parseInt(tt.token?.decimals || "18");
      const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
      
      // Check if counterparty is a known exchange
      let exchangeName = "";
      let direction = "";
      
      if (KNOWN_EXCHANGES[to]) {
        exchangeName = KNOWN_EXCHANGES[to];
        direction = "DEPOSIT TO";
      } else if (KNOWN_EXCHANGES[from]) {
        exchangeName = KNOWN_EXCHANGES[from];
        direction = "WITHDRAWAL FROM";
      } else if (toName && (toName.toLowerCase().includes("binance") || toName.toLowerCase().includes("coinbase") || 
                 toName.toLowerCase().includes("kraken") || toName.toLowerCase().includes("crypto.com") ||
                 toName.toLowerCase().includes("okx") || toName.toLowerCase().includes("huobi") ||
                 toName.toLowerCase().includes("bybit") || toName.toLowerCase().includes("kucoin") ||
                 toName.toLowerCase().includes("gate.io") || toName.toLowerCase().includes("bitfinex") ||
                 toName.toLowerCase().includes("bitget") || toName.toLowerCase().includes("mexc"))) {
        exchangeName = toName;
        direction = "DEPOSIT TO";
      } else if (fromName && (fromName.toLowerCase().includes("binance") || fromName.toLowerCase().includes("coinbase") || 
                 fromName.toLowerCase().includes("kraken") || fromName.toLowerCase().includes("crypto.com") ||
                 fromName.toLowerCase().includes("okx") || fromName.toLowerCase().includes("huobi") ||
                 fromName.toLowerCase().includes("bybit") || fromName.toLowerCase().includes("kucoin") ||
                 fromName.toLowerCase().includes("gate.io") || fromName.toLowerCase().includes("bitfinex") ||
                 fromName.toLowerCase().includes("bitget") || fromName.toLowerCase().includes("mexc"))) {
        exchangeName = fromName;
        direction = "WITHDRAWAL FROM";
      }
      
      if (exchangeName) {
        exchangeFlows.push({
          wallet: addr,
          walletLabel: label,
          direction,
          exchange: exchangeName,
          amount: amt.toFixed(6),
          token: sym,
          timestamp: tt.timestamp || "",
          txHash: tt.transaction_hash || tt.hash || "",
        });
      }
    }
  }
  
  // Also check ETH transactions for the key wallets
  const keyAddrs = toCheck.slice(0, 7);
  for (const {addr, label} of keyAddrs) {
    const data = await api(`${BE}/addresses/${addr.toLowerCase()}/transactions`);
    await sleep(150);
    if (!data?.items) continue;
    
    for (const tx of data.items) {
      const from = (tx.from?.hash || "").toLowerCase();
      const to = (tx.to?.hash || "").toLowerCase();
      const fromName = tx.from?.name || "";
      const toName = tx.to?.name || "";
      const val = parseInt(tx.value || "0") / 1e18;
      if (val === 0) continue;
      
      let exchangeName = "";
      let direction = "";
      
      if (KNOWN_EXCHANGES[to]) { exchangeName = KNOWN_EXCHANGES[to]; direction = "ETH DEPOSIT TO"; }
      else if (KNOWN_EXCHANGES[from]) { exchangeName = KNOWN_EXCHANGES[from]; direction = "ETH WITHDRAWAL FROM"; }
      else if (toName && /binance|coinbase|kraken|crypto\.com|okx|huobi|bybit|kucoin/i.test(toName)) {
        exchangeName = toName; direction = "ETH DEPOSIT TO";
      } else if (fromName && /binance|coinbase|kraken|crypto\.com|okx|huobi|bybit|kucoin/i.test(fromName)) {
        exchangeName = fromName; direction = "ETH WITHDRAWAL FROM";
      }
      
      if (exchangeName) {
        exchangeFlows.push({
          wallet: addr, walletLabel: label, direction, exchange: exchangeName,
          amount: val.toFixed(8), token: "ETH", timestamp: tx.timestamp || "", txHash: tx.hash || "",
        });
      }
    }
  }
  
  console.log(`\n═══ RESULTS ═══\n`);
  
  if (exchangeFlows.length === 0) {
    console.log("No direct exchange deposits or withdrawals found in the recent transfers.");
    console.log("This means the attacker is NOT currently moving funds through major exchanges");
    console.log("(or is using deposit addresses we haven't identified yet).");
  } else {
    // Sort by timestamp
    exchangeFlows.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    console.log(`Found ${exchangeFlows.length} exchange-related transactions:\n`);
    
    const deposits = exchangeFlows.filter(f => f.direction.includes("DEPOSIT"));
    const withdrawals = exchangeFlows.filter(f => f.direction.includes("WITHDRAWAL"));
    
    if (deposits.length > 0) {
      console.log(`\n★★★ DEPOSITS TO EXCHANGES (${deposits.length}) — POTENTIAL CASH-OUT ★★★\n`);
      for (const f of deposits) {
        console.log(`  ${f.timestamp}`);
        console.log(`  ${f.direction} ${f.exchange}`);
        console.log(`  Amount: ${f.amount} ${f.token}`);
        console.log(`  From Wallet: ${f.wallet} (${f.walletLabel})`);
        console.log(`  TX: ${f.txHash}`);
        console.log("");
      }
    }
    
    if (withdrawals.length > 0) {
      console.log(`\n  WITHDRAWALS FROM EXCHANGES (${withdrawals.length}):\n`);
      for (const f of withdrawals) {
        console.log(`  ${f.timestamp}`);
        console.log(`  ${f.direction} ${f.exchange}`);
        console.log(`  Amount: ${f.amount} ${f.token}`);
        console.log(`  To Wallet: ${f.wallet} (${f.walletLabel})`);
        console.log(`  TX: ${f.txHash}`);
        console.log("");
      }
    }
  }
  
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
