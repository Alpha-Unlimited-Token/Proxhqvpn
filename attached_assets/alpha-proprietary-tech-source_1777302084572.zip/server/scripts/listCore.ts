/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_LIST_CORE_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_ListCore_Calibration_PROTECTED
 */
import { db } from "../db.js";
import { monitoredWallets } from "../../shared/models/forensic.js";
import { eq } from "drizzle-orm";
async function main() {
  const w = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"));
  const core = w.filter(ww => ww.role !== "token_recipient");
  for (const ww of core) {
    console.log(`${ww.address}|${ww.role}|${(ww.label||"").slice(0,80)}|${ww.chain}`);
  }
  process.exit(0);
}
main();
