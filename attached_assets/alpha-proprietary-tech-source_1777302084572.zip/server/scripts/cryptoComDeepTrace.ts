import { db } from "../db.js";
import { sql } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function fetchEtherscanTxs(address: string) {
  const url = `https://eth.blockscout.com/api/v2/addresses/${address.toLowerCase()}/transactions`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch { return []; }
}

async function fetchTokenTransfers(address: string) {
  const url = `https://eth.blockscout.com/api/v2/addresses/${address.toLowerCase()}/token-transfers`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch { return []; }
}

async function main() {
  console.log("╔══════════════════════════════════════════════════════════════════╗");
  console.log("║   CRYPTO.COM WALLET DEEP TRACE — KYC IDENTITY INVESTIGATION   ║");
  console.log("╚══════════════════════════════════════════════════════════════════╝\n");

  // Two Crypto.com interactions found in our data:
  // 1. 0x46340b20830761efd32832a74d7169b29feb9758 (Crypto.com Hot Wallet 2) -> sent ETH to case wallet
  // 2. 0x3cd751e6b0078be393132286c442345e5dc49699 -> sent 130.58 USDT (funded from Crypto.com)
  
  const cryptoComHotWallets = [
    "0x6262998ced04146fa42253a5c0af90ca02dfd2a3",  // Crypto.com Main
    "0x46340b20830761efd32832a74d7169b29feb9758",  // Crypto.com 2 (confirmed in our case)
    "0xcffad3200574698b78f32232aa9d63eabd290703",  // Crypto.com 3
    "0x72a53cdbbcc1b9efa39c834a540550e23463aacb",  // Crypto.com Exchange
  ];

  // The key wallets that interacted with Crypto.com
  const suspectWallets = [
    { addr: "0x3cd751e6b0078be393132286c442345e5dc49699", note: "Sent 130.58 USDT to case wallet 0x2151..., funded by Crypto.com" },
    { addr: "0x658370618bbc885865df66c1061bfe4771fad846", note: "Received 0.0226 ETH from Crypto.com Hot Wallet 2, holds 155K USDC" },
  ];

  console.log("═══════════════════════════════════════════════════════════════════");
  console.log("CRYPTO.COM HOT WALLET ADDRESSES (KNOWN)");
  console.log("═══════════════════════════════════════════════════════════════════\n");
  for (const hw of cryptoComHotWallets) {
    console.log(`  ${hw}`);
  }

  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("SUSPECT WALLETS LINKED TO CRYPTO.COM IN THIS CASE");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  for (const sw of suspectWallets) {
    console.log(`\n${"─".repeat(65)}`);
    console.log(`WALLET: ${sw.addr}`);
    console.log(`NOTE: ${sw.note}`);
    console.log(`${"─".repeat(65)}\n`);

    // Get all on-chain transactions
    console.log("  Fetching on-chain ETH transactions...");
    const txs = await fetchEtherscanTxs(sw.addr);
    console.log(`  Found ${txs.length} ETH transactions\n`);

    const funders = new Set<string>();
    const recipients = new Set<string>();

    if (txs.length > 0) {
      console.log("  INCOMING TRANSACTIONS (funding sources):");
      for (const tx of txs) {
        if (tx.to?.hash?.toLowerCase() === sw.addr.toLowerCase()) {
          const from = tx.from?.hash || "?";
          const val = tx.value ? (parseInt(tx.value) / 1e18).toFixed(6) : "0";
          const time = tx.timestamp || tx.block?.timestamp || "?";
          const fromLabel = tx.from?.name || tx.from?.ens_domain_name || "";
          console.log(`    [${time}] FROM: ${from} ${fromLabel ? `(${fromLabel})` : ""} | ${val} ETH | TX: ${tx.hash}`);
          funders.add(from.toLowerCase());
        }
      }
      console.log("");
      console.log("  OUTGOING TRANSACTIONS (where funds went):");
      for (const tx of txs) {
        if (tx.from?.hash?.toLowerCase() === sw.addr.toLowerCase()) {
          const to = tx.to?.hash || "?";
          const val = tx.value ? (parseInt(tx.value) / 1e18).toFixed(6) : "0";
          const time = tx.timestamp || tx.block?.timestamp || "?";
          const toLabel = tx.to?.name || tx.to?.ens_domain_name || "";
          console.log(`    [${time}] TO: ${to} ${toLabel ? `(${toLabel})` : ""} | ${val} ETH | TX: ${tx.hash}`);
          recipients.add(to.toLowerCase());
        }
      }
    }

    console.log("\n  Fetching token transfers...");
    const tokens = await fetchTokenTransfers(sw.addr);
    console.log(`  Found ${tokens.length} token transfers\n`);

    if (tokens.length > 0) {
      console.log("  TOKEN TRANSFERS:");
      for (const tt of tokens) {
        const from = tt.from?.hash || "?";
        const to = tt.to?.hash || "?";
        const symbol = tt.token?.symbol || "?";
        const decimals = parseInt(tt.token?.decimals || "18");
        const amount = tt.total?.value ? (parseInt(tt.total.value) / Math.pow(10, decimals)).toFixed(4) : "?";
        const time = tt.timestamp || "?";
        const dir = to.toLowerCase() === sw.addr.toLowerCase() ? "IN" : "OUT";
        const fromLabel = tt.from?.name || tt.from?.ens_domain_name || "";
        const toLabel = tt.to?.name || tt.to?.ens_domain_name || "";
        console.log(`    [${time}] ${dir}: ${amount} ${symbol} | From: ${from} ${fromLabel ? `(${fromLabel})` : ""} -> To: ${to} ${toLabel ? `(${toLabel})` : ""}`);
        if (dir === "IN") funders.add(from.toLowerCase());
        else recipients.add(to.toLowerCase());
      }
    }

    // Check if any funders are Crypto.com hot wallets
    console.log("\n  CRYPTO.COM CONNECTION CHECK:");
    for (const f of funders) {
      if (cryptoComHotWallets.map(h => h.toLowerCase()).includes(f)) {
        console.log(`    ⚠️  DIRECTLY FUNDED BY CRYPTO.COM: ${f}`);
      }
    }

    console.log("\n  ALL UNIQUE FUNDING SOURCES:");
    for (const f of funders) {
      const isCryptoCom = cryptoComHotWallets.map(h => h.toLowerCase()).includes(f);
      console.log(`    ${isCryptoCom ? "⚠️ [CRYPTO.COM]" : "   "} ${f}`);
    }

    console.log("\n  ALL UNIQUE RECIPIENTS:");
    for (const r of recipients) {
      console.log(`    ${r}`);
    }

    await new Promise(r => setTimeout(r, 1000));
  }

  // Now trace 0x3cd751e6b0078be393132286c442345e5dc49699 deeper — where did IT get funded from?
  console.log("\n\n═══════════════════════════════════════════════════════════════════");
  console.log("DEEP TRACE: 0x3cd751e6...49699 — TRACING FUNDING CHAIN BACK");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const deepAddr = "0x3cd751e6b0078be393132286c442345e5dc49699";
  console.log("Fetching all transactions for funding source wallet...");
  const deepTxs = await fetchEtherscanTxs(deepAddr);
  const deepTokens = await fetchTokenTransfers(deepAddr);
  
  console.log(`Found ${deepTxs.length} ETH txs, ${deepTokens.length} token transfers\n`);

  const deepFunders = new Map<string, { ethAmount: number; tokenAmounts: Map<string, number>; firstSeen: string; label: string }>();

  for (const tx of deepTxs) {
    if (tx.to?.hash?.toLowerCase() === deepAddr.toLowerCase()) {
      const from = tx.from?.hash?.toLowerCase() || "";
      const val = tx.value ? parseInt(tx.value) / 1e18 : 0;
      const label = tx.from?.name || tx.from?.ens_domain_name || "";
      if (!deepFunders.has(from)) deepFunders.set(from, { ethAmount: 0, tokenAmounts: new Map(), firstSeen: "", label: "" });
      const entry = deepFunders.get(from)!;
      entry.ethAmount += val;
      if (!entry.firstSeen || (tx.timestamp && tx.timestamp < entry.firstSeen)) entry.firstSeen = tx.timestamp || "";
      if (label) entry.label = label;
    }
  }

  for (const tt of deepTokens) {
    if (tt.to?.hash?.toLowerCase() === deepAddr.toLowerCase()) {
      const from = tt.from?.hash?.toLowerCase() || "";
      const symbol = tt.token?.symbol || "?";
      const decimals = parseInt(tt.token?.decimals || "18");
      const amount = tt.total?.value ? parseInt(tt.total.value) / Math.pow(10, decimals) : 0;
      const label = tt.from?.name || tt.from?.ens_domain_name || "";
      if (!deepFunders.has(from)) deepFunders.set(from, { ethAmount: 0, tokenAmounts: new Map(), firstSeen: "", label: "" });
      const entry = deepFunders.get(from)!;
      entry.tokenAmounts.set(symbol, (entry.tokenAmounts.get(symbol) || 0) + amount);
      if (label) entry.label = label;
    }
  }

  console.log("WALLETS THAT FUNDED 0x3cd751e6...49699:");
  for (const [addr, data] of [...deepFunders.entries()].sort((a, b) => b[1].ethAmount - a[1].ethAmount)) {
    const isCryptoCom = cryptoComHotWallets.map(h => h.toLowerCase()).includes(addr);
    const tokenStr = [...data.tokenAmounts.entries()].map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ");
    console.log(`  ${isCryptoCom ? "⚠️ [CRYPTO.COM]" : "   "} ${addr} ${data.label ? `(${data.label})` : ""}`);
    console.log(`     ETH: ${data.ethAmount.toFixed(6)} | Tokens: ${tokenStr || "none"} | First: ${data.firstSeen}`);
  }

  // Now same for 0x658370618bbc885865df66c1061bfe4771fad846
  console.log("\n\n═══════════════════════════════════════════════════════════════════");
  console.log("DEEP TRACE: 0x65837061...d846 — TRACING FUNDING CHAIN BACK");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const deepAddr2 = "0x658370618bbc885865df66c1061bfe4771fad846";
  const deepTxs2 = await fetchEtherscanTxs(deepAddr2);
  const deepTokens2 = await fetchTokenTransfers(deepAddr2);
  
  console.log(`Found ${deepTxs2.length} ETH txs, ${deepTokens2.length} token transfers\n`);

  const deepFunders2 = new Map<string, { ethAmount: number; tokenAmounts: Map<string, number>; firstSeen: string; label: string }>();

  for (const tx of deepTxs2) {
    if (tx.to?.hash?.toLowerCase() === deepAddr2.toLowerCase()) {
      const from = tx.from?.hash?.toLowerCase() || "";
      const val = tx.value ? parseInt(tx.value) / 1e18 : 0;
      const label = tx.from?.name || tx.from?.ens_domain_name || "";
      if (!deepFunders2.has(from)) deepFunders2.set(from, { ethAmount: 0, tokenAmounts: new Map(), firstSeen: "", label: "" });
      const entry = deepFunders2.get(from)!;
      entry.ethAmount += val;
      if (!entry.firstSeen || (tx.timestamp && tx.timestamp < entry.firstSeen)) entry.firstSeen = tx.timestamp || "";
      if (label) entry.label = label;
    }
  }

  for (const tt of deepTokens2) {
    if (tt.to?.hash?.toLowerCase() === deepAddr2.toLowerCase()) {
      const from = tt.from?.hash?.toLowerCase() || "";
      const symbol = tt.token?.symbol || "?";
      const decimals = parseInt(tt.token?.decimals || "18");
      const amount = tt.total?.value ? parseInt(tt.total.value) / Math.pow(10, decimals) : 0;
      const label = tt.from?.name || tt.from?.ens_domain_name || "";
      if (!deepFunders2.has(from)) deepFunders2.set(from, { ethAmount: 0, tokenAmounts: new Map(), firstSeen: "", label: "" });
      const entry = deepFunders2.get(from)!;
      entry.tokenAmounts.set(symbol, (entry.tokenAmounts.get(symbol) || 0) + amount);
      if (label) entry.label = label;
    }
  }

  console.log("WALLETS THAT FUNDED 0x65837061...d846:");
  for (const [addr, data] of [...deepFunders2.entries()].sort((a, b) => b[1].ethAmount - a[1].ethAmount)) {
    const isCryptoCom = cryptoComHotWallets.map(h => h.toLowerCase()).includes(addr);
    const tokenStr = [...data.tokenAmounts.entries()].map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ");
    console.log(`  ${isCryptoCom ? "⚠️ [CRYPTO.COM]" : "   "} ${addr} ${data.label ? `(${data.label})` : ""}`);
    console.log(`     ETH: ${data.ethAmount.toFixed(6)} | Tokens: ${tokenStr || "none"} | First: ${data.firstSeen}`);
  }

  console.log("\n\n═══════════════════════════════════════════════════════════════════");
  console.log("SUMMARY — CRYPTO.COM KYC TRAIL");
  console.log("═══════════════════════════════════════════════════════════════════\n");
  console.log("Crypto.com requires full KYC verification:");
  console.log("  - Government-issued photo ID");
  console.log("  - Selfie verification");
  console.log("  - Proof of address");
  console.log("  - Source of funds declaration");
  console.log("");
  console.log("The following wallets received withdrawals FROM Crypto.com,");
  console.log("meaning the Crypto.com account holder's identity is on file:");
  console.log("  Wallet 1: 0x658370618bbc885865df66c1061bfe4771fad846");
  console.log("    → Received 0.0226 ETH from Crypto.com Hot Wallet 2");
  console.log("    → Now holds 155,017.66 USDC from CoW Swap");
  console.log("  Wallet 2: 0x3cd751e6b0078be393132286c442345e5dc49699");
  console.log("    → Sent 130.58 USDT to case wallet (check funding sources above)");
  console.log("");
  console.log("Law enforcement can subpoena Crypto.com for the KYC records");
  console.log("associated with these withdrawal transactions.");

  process.exit(0);
}
main();
