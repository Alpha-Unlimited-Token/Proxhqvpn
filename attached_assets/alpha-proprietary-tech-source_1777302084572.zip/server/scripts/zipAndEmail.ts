import * as fs from "fs";
import * as path from "path";
import archiver from "archiver";

const dir = path.resolve("private/forensic-exports");
const files = fs.readdirSync(dir).filter(f => f.endsWith(".txt") || f.endsWith(".json") || f.endsWith(".csv"));

const totalSize = files.reduce((s, f) => s + fs.statSync(path.join(dir, f)).size, 0);
const MAX_ZIP_SIZE = 20 * 1024 * 1024;
const needsSplit = totalSize > MAX_ZIP_SIZE;

async function createZip(zipPath: string, fileList: string[]): Promise<number> {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });
    output.on("close", () => resolve(archive.pointer()));
    archive.on("error", reject);
    archive.pipe(output);
    for (const f of fileList) {
      archive.file(path.join(dir, f), { name: f });
    }
    archive.finalize();
  });
}

async function main() {
  console.log(`Total files: ${files.length} | Total size: ${(totalSize / 1024).toFixed(0)} KB`);
  console.log(`Files: ${files.join(", ")}`);

  const zipDir = path.resolve("private");
  const zipPaths: string[] = [];

  if (!needsSplit) {
    const zipPath = path.join(zipDir, "Sillytuna-Deep-Fund-Trace-File1.zip");
    const size = await createZip(zipPath, files);
    console.log(`Created: ${zipPath} (${(size / 1024).toFixed(0)} KB)`);
    zipPaths.push(zipPath);
  } else {
    const half = Math.ceil(files.length / 2);
    const zip1 = path.join(zipDir, "Sillytuna-Deep-Fund-Trace-File1.zip");
    const zip2 = path.join(zipDir, "Sillytuna-Deep-Fund-Trace-File2.zip");
    const s1 = await createZip(zip1, files.slice(0, half));
    const s2 = await createZip(zip2, files.slice(half));
    console.log(`Created: File1.zip (${(s1 / 1024).toFixed(0)} KB), File2.zip (${(s2 / 1024).toFixed(0)} KB)`);
    zipPaths.push(zip1, zip2);
  }

  const sgKey = process.env.SENDGRID_API_KEY;
  if (!sgKey) { console.error("No SENDGRID_API_KEY"); process.exit(1); }

  for (let i = 0; i < zipPaths.length; i++) {
    const zipData = fs.readFileSync(zipPaths[i]);
    const b64 = zipData.toString("base64");
    const fileName = path.basename(zipPaths[i]);
    const fileLabel = zipPaths.length > 1 ? ` (File ${i + 1} of ${zipPaths.length})` : "";

    const emailBody = {
      personalizations: [{ to: [{ email: "sillytuna@gmail.com", name: "@sillytuna" }] }],
      from: { email: "forensics@alphaunlimitedtrading.com", name: "Alpha Unlimited Trading — Forensic Intelligence" },
      subject: `Deep Fund Flow Trace — @sillytuna Case${fileLabel}`,
      content: [{
        type: "text/plain",
        value: `Dear @sillytuna,\n\nAttached is the comprehensive deep fund flow trace${fileLabel} for your case.\n\nThis package contains:\n- COMPLETE-FUND-FLOW-REPORT.txt — Full wallet-by-wallet fund flow analysis\n- ALL-TRANSACTIONS.json/csv — Every single transaction from all monitored wallets\n- ALL-WALLET-PROFILES.json/csv — Every wallet discovered with balances and tokens\n- REMAINING-WALLETS.json/csv — Extended wallet profiles and transaction data\n- REMAINING-TRANSACTIONS.json/csv — Additional transaction records\n- FUND-FLOW-GRAPH.json — Graph data showing fund flow between wallets\n- EXCHANGE-DEPOSITS.json — Exchange deposit tracking\n\nThis trace followed stolen funds from wallet to wallet, through DEX swaps (CoW Swap, Uniswap, LI.FI), across bridges (Arbitrum), and into exchanges — tracking every hop to the final destination.\n\nOur live monitoring system is running 24/7 and will send you hourly updates with any new movements or changes detected.\n\nDo not share this information publicly — it is for you and law enforcement only.\n\nAlpha Unlimited Trading\nForensic Intelligence Division\n${new Date().toISOString()}`
      }],
      attachments: [{ content: b64, filename: fileName, type: "application/zip", disposition: "attachment" }]
    };

    const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: { "Authorization": `Bearer ${sgKey}`, "Content-Type": "application/json" },
      body: JSON.stringify(emailBody)
    });

    if (res.ok || res.status === 202) {
      console.log(`Email ${i + 1}/${zipPaths.length} sent successfully to sillytuna@gmail.com (${fileName})`);
    } else {
      const err = await res.text();
      console.error(`Email ${i + 1} failed (${res.status}): ${err}`);
    }
  }

  console.log("Done!");
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
