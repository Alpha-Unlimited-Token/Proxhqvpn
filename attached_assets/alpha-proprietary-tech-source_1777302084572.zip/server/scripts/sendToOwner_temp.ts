import { getUncachableSendGridClient } from "./server/services/sendgridService.js";

async function main() {
  const { client: sgClient, fromEmail } = await getUncachableSendGridClient();
  
  // Re-run the same intel gathering
  const TARGET_WALLET = "0x9a7226C3F2c4663af5786bdCa118Ce1d8d06bA73";
  const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
  const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
  const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
  const NOW = new Date().toISOString();

  async function alchemyRpc(method: string, params: any[]): Promise<any> {
    const res = await fetch(ALCHEMY_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
    return (await res.json()).result;
  }
  async function alchemyApi(method: string, params: Record<string, any>): Promise<any> {
    const res = await fetch(ALCHEMY_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
    return (await res.json()).result;
  }

  const ethHex = await alchemyRpc("eth_getBalance", [TARGET_WALLET, "latest"]);
  const ethBalance = (Number(BigInt(ethHex)) / 1e18).toFixed(6);
  const ethUsd = (parseFloat(ethBalance) * 2083).toFixed(2);
  const txHex = await alchemyRpc("eth_getTransactionCount", [TARGET_WALLET, "latest"]);
  const txCount = parseInt(txHex, 16);
  const code = await alchemyRpc("eth_getCode", [TARGET_WALLET, "latest"]);
  const isContract = code !== "0x" && code !== "0x0";

  const inResult = await alchemyApi("alchemy_getAssetTransfers", { toAddress: TARGET_WALLET, category: ["external","erc20"], maxCount: "0x14", order: "desc", withMetadata: true });
  const inbound = inResult?.transfers || [];
  const outResult = await alchemyApi("alchemy_getAssetTransfers", { fromAddress: TARGET_WALLET, category: ["external","erc20"], maxCount: "0x14", order: "desc", withMetadata: true });
  const outbound = outResult?.transfers || [];

  const knownAddresses: Record<string, string> = {
    "0x8e04af7f7c76daa9ab429b1340e0327b5b835748": "Cashout Primary (Attacker)",
    "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3": "HOP-4 (Attacker Consolidation)",
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet 14",
    "0x6fe0fab2164d8e0d03ad6a628e2af78624060322": "VICTIM (sillytuna/Alex Amsel)",
  };
  function labelAddr(addr: string): string { const l = addr.toLowerCase(); for (const [k,v] of Object.entries(knownAddresses)) if (l===k.toLowerCase()) return v; return ""; }
  function shortenAddr(addr: string): string { return addr.slice(0,10)+"..."+addr.slice(-6); }
  function formatEth(v: any): string { return parseFloat(String(v)).toFixed(4); }

  let totalEthFromAttacker = 0;
  for (const t of inbound) { if (t.from.toLowerCase() === "0x8e04af7f7c76daa9ab429b1340e0327b5b835748" && t.asset === "ETH") totalEthFromAttacker += parseFloat(String(t.value)||"0"); }
  const outboundToBinance = outbound.filter((t:any) => t.to?.toLowerCase() === "0x28c6c06298d514db089934071355e5743bf21d60");

  const inboundRows = inbound.slice(0,15).map((t:any) => { const label = labelAddr(t.from); const lh = label ? ` <span style="color:#EF4444;font-size:10px">[${label}]</span>` : ""; const ts = t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).toISOString().slice(0,19) : "—"; return `<tr><td style="font-size:10px">${ts}</td><td class="mono">${shortenAddr(t.from)}${lh}</td><td class="val">${formatEth(t.value)}</td><td>${t.asset||"ETH"}</td><td class="mono" style="font-size:10px"><a href="https://etherscan.io/tx/${t.hash}" style="color:#00D4FF">${t.hash.slice(0,14)}...</a></td></tr>`; }).join("");
  const outboundRows = outbound.slice(0,15).map((t:any) => { const label = labelAddr(t.to||""); const lh = label ? ` <span style="color:#EF4444;font-size:10px">[${label}]</span>` : ""; const ts = t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp).toISOString().slice(0,19) : "—"; return `<tr><td style="font-size:10px">${ts}</td><td class="mono">${shortenAddr(t.to||"")}${lh}</td><td class="val">${formatEth(t.value)}</td><td>${t.asset||"ETH"}</td><td class="mono" style="font-size:10px"><a href="https://etherscan.io/tx/${t.hash}" style="color:#00D4FF">${t.hash.slice(0,14)}...</a></td></tr>`; }).join("");

  const htmlBody = `<!DOCTYPE html>
<html><head><style>
body{background:#0A1628;color:#E2E8F0;font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0}
.c{max-width:900px;margin:0 auto;padding:24px}
.hdr{background:linear-gradient(135deg,#7F1D1D,#450A0A);border:2px solid #EF4444;border-radius:12px;padding:28px;margin-bottom:24px;text-align:center}
.hdr h1{color:#FFF;font-size:22px;margin:0 0 8px;letter-spacing:2px}
.hdr h2{color:#FCA5A5;font-size:14px;margin:0 0 6px;font-weight:normal}
.hdr .sub{color:#94A3B8;font-size:11px}
.s{background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px}
.s h3{color:#00D4FF;font-size:15px;margin:0 0 12px;border-bottom:1px solid #1E3A5F;padding-bottom:8px}
.crit{background:#7F1D1D44;border:2px solid #EF4444;border-radius:8px;padding:20px;margin-bottom:16px}
.crit h3{color:#FF6B6B;font-size:16px;margin:0 0 12px;border-bottom:1px solid #EF444466;padding-bottom:8px}
.alert{background:#78350F44;border:2px solid #F59E0B;border-radius:8px;padding:20px;margin-bottom:16px}
.alert h3{color:#FBBF24;font-size:16px;margin:0 0 12px;border-bottom:1px solid #F59E0B66;padding-bottom:8px}
.ok{background:#14532D44;border:2px solid #22C55E;border-radius:8px;padding:20px;margin-bottom:16px}
.ok h3{color:#22C55E;font-size:16px;margin:0 0 12px}
.mono{font-family:monospace;font-size:12px;word-break:break-all;color:#FFD700}
.val{color:#FFD700;font-weight:bold}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:left;padding:8px 6px;border-bottom:2px solid #00D4FF;color:#00D4FF;font-size:11px}
td{color:#E2E8F0;padding:5px 6px;border-bottom:1px solid #1E3A5F}
.flow{text-align:center;font-size:16px;padding:16px;margin:12px 0;background:#0D1117;border:2px solid #FFD700;border-radius:8px}
.flow span{color:#FFD700}
.ft{text-align:center;color:#64748B;font-size:11px;margin-top:24px;padding-top:16px;border-top:1px solid #1E3A5F}
a{color:#00D4FF;text-decoration:none}
</style></head>
<body><div class="c">
<div class="hdr">
<h1>🚨 URGENT — OTC WALLET INTELLIGENCE REPORT</h1>
<h2>1,300 ETH (~$2.7M) Movement Detected — Funds In Motion</h2>
<div class="sub">Case ${CASE_ID} | @sillytuna / Alex Amsel EIP-7702 Exploit (~$26M) | Generated ${NOW}</div>
</div>
<div class="crit">
<h3>🔴 TRIGGER EVENT — 1,300 ETH OUTBOUND FROM ATTACKER</h3>
<p>Alpha Auto-Pivot Surveillance Engine™ detected <strong style="color:#FFD700">1,300.0000 ETH (~$2,707,900)</strong> transferred from the primary cashout wallet to the OTC intermediary wallet.</p>
<div class="flow">
<span>0x8e04...5748</span> (Cashout Primary)<br>↓ 1,300 ETH<br>
<span>0x9a72...ba73</span> (OTC/Bridge Intermediary)<br>↓ likely next destination<br>
<span>0x28c6...1d60</span> (Binance Hot Wallet 14)
</div>
<p style="color:#FCA5A5;font-size:13px"><strong>THIS WALLET IS THE CRITICAL CHOKEPOINT.</strong> Identifying the OTC operator reveals the attacker. All stolen funds pass through this address before reaching exchanges.</p>
</div>
<div class="s">
<h3>📊 WALLET PROFILE — 0x9a7226C3</h3>
<table>
<tr><td style="width:200px">Full Address</td><td class="mono">${TARGET_WALLET}</td></tr>
<tr><td>Etherscan</td><td><a href="https://etherscan.io/address/${TARGET_WALLET}">View on Etherscan ↗</a></td></tr>
<tr><td>Type</td><td>${isContract ? "⚠️ Smart Contract" : "EOA (Externally Owned Account)"}</td></tr>
<tr><td>ETH Balance</td><td class="val">${ethBalance} ETH (~$${ethUsd})</td></tr>
<tr><td>Total Transactions</td><td class="val">${txCount.toLocaleString()}</td></tr>
<tr><td>ETH from Attacker (visible)</td><td class="val">${formatEth(totalEthFromAttacker)} ETH</td></tr>
<tr><td>Transfers to Binance</td><td class="val">${outboundToBinance.length}</td></tr>
<tr><td>Role in Attack Chain</td><td style="color:#EF4444;font-weight:bold">OTC / Bridge Intermediary — Laundering Layer</td></tr>
</table>
</div>
<div class="s">
<h3>📥 RECENT INBOUND TRANSFERS (Last ${inbound.length})</h3>
<table><tr><th>Time</th><th>From</th><th>Amount</th><th>Asset</th><th>TX Hash</th></tr>${inboundRows}</table>
</div>
<div class="s">
<h3>📤 RECENT OUTBOUND TRANSFERS (Last ${outbound.length})</h3>
<table><tr><th>Time</th><th>To</th><th>Amount</th><th>Asset</th><th>TX Hash</th></tr>${outboundRows}</table>
</div>
<div class="alert">
<h3>⚠️ KNOWN CONNECTIONS</h3>
<table><tr><th>Address</th><th>Role</th><th>Relationship</th></tr>
<tr><td class="mono">0x8e04...5748</td><td style="color:#EF4444">Cashout Primary</td><td>Sends consolidated stolen ETH to this wallet</td></tr>
<tr><td class="mono">0xf576...59f3</td><td style="color:#EF4444">HOP-4</td><td>Attacker consolidation — feeds into 0x8e04</td></tr>
<tr><td class="mono">0x28c6...1d60</td><td style="color:#F59E0B">Binance Hot Wallet 14</td><td>Receives deposits FROM this wallet — KYC subpoena target</td></tr>
<tr><td class="mono">0x6fe0...0322</td><td style="color:#86EFAC">VICTIM</td><td>Original source of stolen ~$26M</td></tr>
</table></div>
<div class="s">
<h3>🔍 ASSESSMENT & RECOMMENDED ACTIONS</h3>
<ol style="font-size:13px;line-height:1.8">
<li><strong style="color:#FFD700">IDENTIFY THE OTC OPERATOR</strong> — This wallet functions as a professional OTC or bridging service. The operator likely has direct contact with the attacker or KYC/AML records.</li>
<li><strong style="color:#FFD700">BINANCE KYC SUBPOENA</strong> — Request KYC identity records for accounts receiving deposits from 0x9a7226C3.</li>
<li><strong style="color:#FFD700">FREEZE REQUEST</strong> — If any funds remain on Binance from this deposit path, submit emergency freeze immediately.</li>
<li><strong style="color:#FFD700">ON-CHAIN GRAPH EXPANSION</strong> — Analyze all counterparties to identify other clients or additional attacker wallets.</li>
</ol></div>
<div class="flow">
<strong>COMPLETE ATTACK CHAIN</strong><br><br>
<span>Victim (0x6fe0)</span> → CoW Protocol → <span>HOP-4 (0xf576)</span> → <span>Cashout (0x8e04)</span><br>↓ 1,300 ETH (just detected)<br>
<span style="color:#EF4444;font-size:18px">⬤ OTC SERVICE (0x9a72) ← YOU ARE HERE</span><br>↓<br>
<span>Binance Hot Wallet 14 (0x28c6)</span>
</div>
<div class="ok">
<h3>✅ SURVEILLANCE STATUS</h3>
<p>Alpha Auto-Pivot Surveillance Engine™ actively monitoring all 8 attacker-linked wallets every 5 minutes. DAU forensic beacons deployed in 2 attacker wallets. Email alerts trigger automatically on any movement.</p>
</div>
<div class="ft">Alpha Unlimited Trading — Forensic Intelligence Division<br>Auto-Pivot Surveillance Engine™ • Monitoring 24/7<br>Case ${CASE_ID}<br>Contact: alphaunlimitedtoken@gmail.com</div>
</div></body></html>`;

  const textBody = `URGENT — OTC WALLET INTELLIGENCE REPORT\nCase ${CASE_ID} | @sillytuna EIP-7702 Exploit (~$26M)\nGenerated: ${NOW}\n\nTRIGGER: 1,300 ETH (~$2.7M) moved from Cashout Primary (0x8e04) to OTC intermediary (0x9a72)\n\nWALLET: ${TARGET_WALLET}\nEtherscan: https://etherscan.io/address/${TARGET_WALLET}\nType: ${isContract ? "Smart Contract" : "EOA"}\nBalance: ${ethBalance} ETH (~$${ethUsd})\nTotal TXs: ${txCount}\nETH from Attacker: ${formatEth(totalEthFromAttacker)} ETH\nTransfers to Binance: ${outboundToBinance.length}\n\nATTACK CHAIN:\nVictim (0x6fe0) → CoW Protocol → HOP-4 (0xf576) → Cashout (0x8e04) → OTC (0x9a72) → Binance (0x28c6)\n\nAlpha Unlimited Trading — Forensic Intelligence Division`;

  await sgClient.send({
    to: "alphaunlimitedtoken@gmail.com",
    from: { email: fromEmail, name: "Alpha Unlimited — Forensic Intelligence" },
    subject: "[URGENT] OTC Wallet Intel — 1,300 ETH Movement — 0x9a7226C3 Full Report — Case ${CASE_ID.slice(0,8)}",
    content: [
      { type: "text/plain", value: textBody },
      { type: "text/html", value: htmlBody },
    ],
  });
  console.log("✅ Email SENT to alphaunlimitedtoken@gmail.com");
}
main().catch(err => { console.error("FATAL:", err); process.exit(1); });
