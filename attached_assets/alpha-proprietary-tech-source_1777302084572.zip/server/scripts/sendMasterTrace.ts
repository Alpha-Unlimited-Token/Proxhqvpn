/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SEND_MASTER_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_SendMaster_Calibration_PROTECTED
 *
 * Sends the complete FXUSD-anchored master trace to sillytuna via SendGrid.
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const TO = "sillytuna@gmail.com";
const LE_URL = "https://alphaunlimitedtrading.com/law-enforcement-tech";

async function main() {
  console.log("[SendMaster] Preparing master FXUSD-anchored trace...");

  const files = [
    { src: "forensic_master_fxusd_trace.txt", dst: "[MASTER] All Findings Traced Through FXUSD Source (64 wallets 1435 TXs).txt" },
    { src: "forensic_fxusd_source_chain_trace.txt", dst: "[FXUSD-CHAIN] FXUSD Source to Crypto.com Evidence Chain.txt" },
    { src: "forensic_crypto_com_chain_trace.txt", dst: "[ORIGINAL-TRACE] Crypto.com Full Chain Trace (3678 TXs).txt" },
  ];

  for (const f of files) {
    if (!fs.existsSync(path.resolve(f.src))) {
      console.error(`Missing: ${f.src}`);
      process.exit(1);
    }
  }

  const tmp = `/tmp/master_trace_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-FXUSD-Master-Evidence");
  fs.mkdirSync(zipDir, { recursive: true });

  for (const f of files) {
    fs.copyFileSync(path.resolve(f.src), path.join(zipDir, f.dst));
  }

  const zipPath = path.join(tmp, "master.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-FXUSD-Master-Evidence/"`, { timeout: 15000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`[SendMaster] ZIP: ${zipKb} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();
  console.log(`[SendMaster] Sending from ${fromEmail} to ${TO}...`);

  const body = `Dear @sillytuna,

URGENT — Complete FXUSD-anchored master evidence compilation attached.

We have recompiled ALL of our findings through the FXUSD SOURCE address
(0xD14F4B36E1D1D98c218db782c49149876042BC56) — the address known to your
tracking team — so everything now flows from that verified starting point.
This means your team and law enforcement can use this data directly.

THIS ZIP CONTAINS 3 FILES:

FILE 1: [MASTER] All Findings Traced Through FXUSD Source
  • 64 wallets traced with 1,435 on-chain transactions
  • USDC/USDT blacklist check on 55 addresses (NONE frozen yet)
  • Complete wallet directory: POI, Source, Gas Funder, Laundering Hub,
    Original Funder, 10 Split Wallets, 10 Arbitrum Receivers, 2 DAI Recipients,
    30 Fund Destinations, CoW Swap, Relay Proxy, Crypto.com Suspect
  • Full FXUSD anchor chain with critical TX hashes
  • Theft breakdown: ~$20M DAI, ~$2.47M Monero, ~$1.1M BTC, ~$2.48M Arb USDC, ~$155K FXUSD
  • Law enforcement subpoena guidance for Crypto.com

FILE 2: [FXUSD-CHAIN] FXUSD Source to Crypto.com Evidence Chain
  • Detailed trace from FXUSD SOURCE through relay proxy to Crypto.com wallet
  • Complete token transfer histories for all addresses in the chain
  • KYC proof transaction analysis
  • Law enforcement subpoena template with specific data requests

FILE 3: [ORIGINAL-TRACE] Crypto.com Full Chain Trace (3,678 TXs)
  • The original trace we ran that first identified the Crypto.com connection
  • 22 wallets, 3,678 transactions
  • Kept for reference and cross-verification

CRITICAL FINDING — BLACKLIST STATUS:
  ⚠ NONE of the 55 checked addresses have been frozen by Circle (USDC) or
  Tether (USDT). The suspect can still freely move USDC/USDT.
  RECOMMENDATION: Request Circle and Tether to blacklist the suspect wallet
  (0x658370618BBc885865df66c1061BfE4771FaD846) immediately.

KEY ADDRESSES:
  POI ($4.35M):      0xf70da97812cb96acdf810712aa562db8dfa3dbef
  Source (EIP-7702): 0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb
  Gas Funder:        0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7
  Laundering Hub:    0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872
  Original Funder:   0x423d2b61952d56358db8b313ec7404a9582d4865
  FXUSD SOURCE:      0xD14F4B36E1D1D98c218db782c49149876042BC56
  Crypto.com:        0x658370618BBc885865df66c1061BfE4771FaD846

GOING FORWARD: All future case updates will be anchored through the FXUSD SOURCE.
No re-tracing needed — everything flows from the verified starting point.

LAW ENFORCEMENT RESOURCES:
  Technology briefing, PPTX downloads, and additional evidence at:
  ${LE_URL}

All TX hashes are on Ethereum/Arbitrum mainnet — verify at etherscan.io or blockscout.com.

CONFIDENTIAL — For the victim and law enforcement only.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
© 2024-2026 All Rights Reserved`;

  await client.send({
    to: TO,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: "URGENT — Crypto.com Findings: Master FXUSD-Anchored Evidence (64 Wallets, 1435 TXs, Blacklist Status)",
    text: body,
    attachments: [{
      content: zipBuf.toString("base64"),
      filename: `Sillytuna-FXUSD-Master-Evidence-${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[SendMaster] ✓ Email sent to ${TO}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "report_sent",
    severity: "critical",
    message: `Master FXUSD-anchored evidence ZIP sent to ${TO} from ${fromEmail} (${zipKb} KB) — 64 wallets, 1435 TXs, 55 blacklist checks, 3 files`,
    walletAddress: "system",
    details: {
      recipientEmail: TO,
      fromAddress: fromEmail,
      zipSizeKb: zipKb,
      files: files.map(f => f.dst),
      walletsTraced: 64,
      transactionsTraced: 1435,
      blacklistChecks: 55,
      frozenAddresses: 0,
      lawEnforcementUrl: LE_URL,
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("[SendMaster] Done. Alert logged.");
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
