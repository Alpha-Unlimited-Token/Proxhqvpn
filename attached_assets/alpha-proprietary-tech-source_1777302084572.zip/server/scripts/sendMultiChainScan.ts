/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_MULTICHAIN_SCAN_SEND_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_MultiChainScan_Calibration_PROTECTED
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

const RECIPIENTS = [
  { email: "sillytuna@gmail.com", name: "sillytuna" },
  { email: "tips@securityalliance.org", name: "SEAL 911" },
];

async function main() {
  console.log("[MultiChainScan] Preparing multi-chain scan report for delivery...");

  const reportPath = path.resolve("forensic_multichain_scan_report.txt");
  const dataPath = path.resolve("forensic_scan_data.jsonl");

  if (!fs.existsSync(reportPath)) {
    console.error("Report file not found:", reportPath);
    process.exit(1);
  }

  const reportSize = (fs.statSync(reportPath).size / 1024).toFixed(1);
  console.log(`  ✓ Report: ${reportSize} KB`);

  const dataExists = fs.existsSync(dataPath);
  if (dataExists) {
    const dataSize = (fs.statSync(dataPath).size / 1024).toFixed(1);
    console.log(`  ✓ Raw data: ${dataSize} KB`);
  }

  const tmp = `/tmp/multichain_send_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-MultiChain-Scan-Report");
  fs.mkdirSync(zipDir, { recursive: true });

  fs.copyFileSync(reportPath, path.join(zipDir, "[7] Multi-Chain Scan Report — 66 Wallets × 9 Chains — 21878 Records.txt"));

  if (dataExists) {
    fs.copyFileSync(dataPath, path.join(zipDir, "raw_scan_data.jsonl"));
  }

  const prevReports = [
    { src: "forensic_master_fxusd_trace.txt", name: "[1] Master FXUSD-Anchored Evidence — 64 Wallets 1435 TXs.txt" },
    { src: "forensic_full_exchange_sweep.txt", name: "[6] Complete Exchange Sweep — 66 Wallets vs 60+ KYC Exchanges.txt" },
  ];
  for (const f of prevReports) {
    if (fs.existsSync(path.resolve(f.src))) {
      fs.copyFileSync(path.resolve(f.src), path.join(zipDir, f.name));
      console.log(`  ✓ Including: ${f.name}`);
    }
  }

  const zipPath = path.join(tmp, "multichain_scan.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-MultiChain-Scan-Report/"`, { timeout: 30000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`[MultiChainScan] ZIP: ${zipKb} KB`);

  if (zipBuf.length > 25 * 1024 * 1024) {
    console.error("ZIP exceeds 25MB SendGrid limit");
    process.exit(1);
  }

  const { client, fromEmail } = await getUncachableSendGridClient();

  const subject = `@sillytuna Theft — Multi-Chain Blockchain Scan: 66 Wallets × 9 Chains — 21,878 Records Collected`;

  const emailBody = `Dear Recipient,

NEW FORENSIC INTELLIGENCE: Complete multi-chain blockchain scan results.

══════════════════════════════════════════════════════════════════
SCAN COVERAGE: 66 Wallets × 9 Chains = 594 Wallet-Chain Pairs
TOTAL RECORDS: 21,878 token transfer records collected
══════════════════════════════════════════════════════════════════

CHAINS SCANNED:
  Ethereum (9,162 records) | Arbitrum (2,863) | Optimism (3,285)
  Base (3,355) | Polygon (2,348) | Gnosis (617)
  zkSync (14) | Scroll (234) | Linea (scanned, minimal activity)

KEY FINDINGS:

1. POI WALLET (0xf70da978...) — ACTIVE ON 8 CHAINS
   The primary suspect wallet has 1,000+ records on Ethereum, Arbitrum,
   Optimism, Base, Polygon, Gnosis, zkSync, and Scroll. This indicates
   sophisticated cross-chain laundering operations.

2. LAUNDERING HUB (0xb98e8eef...) — ~$20M DAI DISTRIBUTED
   Multiple $7.9M DAI transfers to intermediary wallets on Ethereum.
   Hub distributed stolen DAI across multiple addresses for layering.

3. GAS FUNDER (0xb01fed2f...) — ACTIVE ON 7 CHAINS
   Funded laundering operations across Ethereum, Arbitrum, Optimism,
   Base, Polygon, Gnosis, and Scroll. This wallet enabled all cross-chain
   movement of stolen funds.

4. RELAY PROXY ERC1967 (0x6818809e...) — AUTOMATED LAUNDERING
   Active on 6 chains with 1,000+ Ethereum records. An upgradeable
   proxy contract used as an automated laundering relay.

5. CRYPTO.COM SUSPECT (0x65837061...) — ACTIVE ON 3 CHAINS
   Active on Ethereum, Base, and Polygon. Previously identified as
   recipient of $155K+ USDC via FXUSD trace. Still unfrozen.

6. 518 TRANSFERS EXCEEDING $10,000 — Detailed in attached report
   Largest: $11.9M USDC single transfer from victim secondary wallet.

IMMEDIATE ACTION REQUIRED:
  • Exchange freeze requests for POI wallet deposits across all 8 chains
  • Crypto.com compliance contact for the $155K USDC (still unfrozen)
  • Cross-chain bridge operators (Across, LiFi, Arbitrum Bridge) for records
  • Law enforcement subpoenas for Binance (primary cash-out destination)

ATTACHED:
  • [7] Multi-Chain Scan Report — Full analysis with 100+ largest transfers
  • [6] Complete Exchange Sweep — 66 wallets vs 60+ KYC exchanges
  • Raw scan data (JSONL) — 21,878 machine-readable records for analysis

All transaction hashes are independently verifiable on-chain.

This is report #8 in our ongoing investigation.

Best regards,
Alpha Unlimited Trading — Forensic Intelligence Engine™
`;

  for (const recipient of RECIPIENTS) {
    console.log(`\n[MultiChainScan] Sending to ${recipient.name} (${recipient.email})...`);

    const msg = {
      to: recipient.email,
      from: fromEmail,
      subject,
      text: emailBody,
      attachments: [
        {
          content: zipBuf.toString("base64"),
          filename: "Sillytuna-MultiChain-Scan-Report.zip",
          type: "application/zip",
          disposition: "attachment" as const,
        },
      ],
    };

    try {
      const [response] = await client.send(msg);
      console.log(`  ✓ Sent to ${recipient.name}: HTTP ${response.statusCode}`);

      await db.insert(forensicAlerts).values({
        caseId: CASE_ID,
        alertType: "multi_chain_scan_sent",
        severity: "high",
        title: `Multi-Chain Scan Report sent to ${recipient.name}`,
        description: `66 wallets × 9 chains scan report (21,878 records) sent to ${recipient.email}`,
        sourceChain: "multi-chain",
        metadata: {
          recipient: recipient.email,
          zipSizeKb: zipKb,
          totalRecords: 21878,
          chainsScanned: 9,
          walletsScanned: 66,
        },
      });
    } catch (err: any) {
      console.error(`  ✗ Failed to send to ${recipient.name}:`, err?.response?.body || err.message);
    }
  }

  console.log("\n[MultiChainScan] ✓ All emails sent successfully.");

  fs.rmSync(tmp, { recursive: true, force: true });
}

main().catch((e) => {
  console.error("[MultiChainScan] Fatal:", e);
  process.exit(1);
});
