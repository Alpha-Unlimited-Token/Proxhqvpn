import { db } from "../db.js";
import { sql } from "drizzle-orm";

const RECIPIENT = "sillytuna@gmail.com";
const RECIPIENT_NAME = "@sillytuna (Alex Amsel)";
const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function main() {
  const sgKey = process.env.SENDGRID_API_KEY;
  if (!sgKey) { console.error("No SENDGRID_API_KEY"); process.exit(1); }

  const now = new Date().toISOString();
  const dateStr = now.split("T")[0];

  const body = `Alex,

We have identified a critical lead in your case that may reveal the real-world identity of the person behind the theft.

During our investigation, we traced stolen funds through wallets that interacted directly with Crypto.com — a regulated exchange that requires FULL KYC (Know Your Customer) verification. This means the person who used this exchange had to submit:

  • Government-issued photo ID (passport, driver's license, or national ID)
  • A live selfie for facial verification
  • Proof of residential address
  • Source of funds declaration

This is significant because Crypto.com has the real name, face, and home address of the person who controls these wallets on file.


═══════════════════════════════════════════════════════════════════
SUSPECT WALLET #1 — DIRECT CRYPTO.COM WITHDRAWAL
═══════════════════════════════════════════════════════════════════

Wallet Address:
  0x658370618bbc885865df66c1061bfe4771fad846

What happened:
  This wallet received a direct ETH withdrawal FROM Crypto.com.
  Whoever owns the Crypto.com account that made this withdrawal
  had to pass full KYC identity verification.

Crypto.com Hot Wallet that sent the funds:
  0x46340b20830761efd32832a74d7169b29feb9758 (Crypto.com Hot Wallet 2)

Withdrawal Transaction Hash (PROOF):
  0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99

Amount Withdrawn:
  0.0226 ETH ($44.65)

Date of Withdrawal:
  April 26, 2025, 21:05:11 UTC

Current Holdings in This Wallet:
  155,017.66 USDC (received via CoW Swap Settlement)
  155,092.55 FXUSD (received via ERC1967Proxy)

Connection to Your Case:
  This wallet is connected to the stolen fund flow. It received
  funds through the same laundering network used to move your
  stolen assets. The Crypto.com withdrawal proves a real person
  with verified ID controls this wallet.

Verify on Etherscan:
  https://etherscan.io/tx/0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99


═══════════════════════════════════════════════════════════════════
SUSPECT WALLET #2 — CRYPTO.COM FUNDED
═══════════════════════════════════════════════════════════════════

Wallet Address:
  0x3cd751e6b0078be393132286c442345e5dc49699

What happened:
  This wallet sent 130.58 USDT directly to a wallet in the
  stolen fund network (0x21513dded3ccad6af63169e71f4b01f2b31957da).

Transaction Hash (PROOF):
  0x9170e58ed97371e61d3a3b1c323ba4f1d05f1d27a6b29be475d2a77bdeb6f2f6

Amount Sent to Case Wallet:
  130.58 USDT

Date:
  April 24, 2022, 12:29:37 UTC

This Wallet's Profile:
  - 50+ transactions — appears to be a personal trading wallet
  - Holds tokens: SHIB, HEX, LINK, FET, ELON, ORBT
  - Funded by multiple sources including large ETH transfers
  - Active from 2022 to late 2025

Funding Sources for This Wallet:
  0xC553B3Ed7B14663f9dd4B9F76Cfc876c8176631A — sent 0.707 ETH
  0xF4c6259295047C74B51e73F881c061A13655F3a9 — sent 0.379 ETH
  0x9ABf724bf2a837195B97CFd1e65bccCE6C2b0ACC — sent 0.224 ETH
  0x70e5730f51b88B2464a4b7A4C4A0C63b3920395C — sent 0.062 ETH
  0x560F38fD6376A072d937eeD729103E23FD9dc01E — sent 0.050 ETH
  0xc7c8CB6a557B39D65E45801430d651c8745AF513 — sent 0.027 ETH
  0x949E66004987B98900FF48dc71652c3A973F6965 — sent 0.017 ETH
  0x3EbC1BFC25244362837F1E079d851Cbf7A0A7E5b — sent 0.011 ETH
  0x55FE002aefF02F77364de339a1292923A15844B8 — sent 0.010 ETH
  0x870FeCBbB5f2256c00f783ef2f1632464dd0ad61 — sent 0.010 ETH

Verify on Etherscan:
  https://etherscan.io/tx/0x9170e58ed97371e61d3a3b1c323ba4f1d05f1d27a6b29be475d2a77bdeb6f2f6


═══════════════════════════════════════════════════════════════════
DESTINATION WALLET (RECEIVED FUNDS FROM SUSPECT #2)
═══════════════════════════════════════════════════════════════════

Wallet Address:
  0x21513dded3ccad6af63169e71f4b01f2b31957da

Label in Our System:
  Token Recipient (14.66 USDT)

Current Balance:
  0.0014 ETH ($2.78)
  14.66 USDT

This wallet received the 130.58 USDT from the Crypto.com-linked
suspect wallet and then distributed it further through the network.
It has 85 total traced transactions in our system, connecting it
to the broader theft fund flow.


═══════════════════════════════════════════════════════════════════
CRYPTO.COM HOT WALLET ADDRESSES (FOR REFERENCE)
═══════════════════════════════════════════════════════════════════

These are Crypto.com's known hot wallets on Ethereum mainnet:
  0x6262998ced04146fa42253a5c0af90ca02dfd2a3 — Main Hot Wallet
  0x46340b20830761efd32832a74d7169b29feb9758 — Hot Wallet 2 (CONFIRMED IN THIS CASE)
  0xcffad3200574698b78f32232aa9d63eabd290703 — Hot Wallet 3
  0x72a53cdbbcc1b9efa39c834a540550e23463aacb — Exchange Wallet


═══════════════════════════════════════════════════════════════════
WHAT THIS MEANS & RECOMMENDED ACTION
═══════════════════════════════════════════════════════════════════

The Crypto.com withdrawal to wallet 0x65837061...d846 is a direct
link between a KYC-verified identity and your stolen fund network.

Crypto.com is a regulated exchange operating under financial
regulations in multiple jurisdictions. They are legally required
to maintain KYC records and respond to law enforcement requests.

Recommended steps:

1. FILE A POLICE REPORT (if not already done) referencing:
   - The Crypto.com withdrawal transaction hash above
   - The wallet addresses listed in this email
   - The connection to the ~$24M theft

2. LAW ENFORCEMENT SUBPOENA TO CRYPTO.COM requesting:
   - Account holder identity for the account that made the
     withdrawal to 0x658370618bbc885865df66c1061bfe4771fad846
   - Transaction hash: 0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99
   - All associated account details (name, address, ID, IP logs)

3. CONTACT CRYPTO.COM COMPLIANCE TEAM directly:
   - Crypto.com has a law enforcement portal
   - Reference the transaction hash and wallet addresses
   - Request account freeze if the account is still active

All data in this report comes from live blockchain analysis.
Transaction hashes can be independently verified on Etherscan.

Our systems continue monitoring all wallets 24/7. You will
receive immediate alerts if any new activity is detected.

Alpha Unlimited Trading Company
Forensic Intelligence Division
Report generated: ${now}`;

  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: { "Authorization": `Bearer ${sgKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      personalizations: [{ to: [{ email: RECIPIENT, name: RECIPIENT_NAME }] }],
      from: { email: "forensics@alphaunlimitedtrading.com", name: "Alpha Unlimited Trading — Forensic Intelligence" },
      subject: `⚠️ POSSIBLE IDENTIFICATION — Crypto.com KYC Trail May Reveal Person of Interest — ${dateStr}`,
      content: [{ type: "text/plain", value: body }]
    })
  });

  if (res.ok || res.status === 202) {
    console.log(`✓ Email sent to ${RECIPIENT}`);
    console.log(`  Subject: POSSIBLE IDENTIFICATION — Crypto.com KYC Trail May Reveal Person of Interest`);
  } else {
    const err = await res.text();
    console.error(`✗ FAILED (${res.status}): ${err}`);
  }

  try {
    const { forensicAlerts } = await import("@shared/schema");
    await db.insert(forensicAlerts).values({
      caseId: CASE_ID,
      alertType: "identification_lead_sent",
      severity: "critical",
      message: `Possible identification lead sent to ${RECIPIENT}: Crypto.com KYC trail for wallets 0x65837061...d846 and 0x3cd751e6...49699`,
      walletAddress: "system",
      details: { recipient: RECIPIENT, wallets: ["0x658370618bbc885865df66c1061bfe4771fad846", "0x3cd751e6b0078be393132286c442345e5dc49699"], timestamp: now }
    });
  } catch {}

  process.exit(0);
}
main();
