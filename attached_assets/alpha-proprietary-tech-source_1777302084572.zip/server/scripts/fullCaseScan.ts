/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_FULL_CASE_SCAN_v3.0
 * ALPHA_INTEGRITY_SEAL: AUT_FullCaseScan_Calibration_PROTECTED
 *
 * Complete case scan:
 * 1. Deep scan 62 core wallets across ALL chains (every TX, every token)
 * 2. Fast check 22K+ recipients for new activity
 * 3. Build comprehensive report with everything
 */

import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { monitoredWallets, forensicAlerts } from "../../shared/models/forensic.js";
import { eq, sql, ne } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const CHAINS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
};

// Known exchange hot wallet addresses for identification
const KNOWN_EXCHANGES: Record<string, string> = {
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance Hot Wallet 2",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance Hot Wallet 3",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance Hot Wallet 4",
  "0x9696f59e4d72e237be84ffd425dcad154bf96976": "Binance Hot Wallet 5",
  "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance Hot Wallet 8",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase 1",
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase 2",
  "0x3cd751e6b0078be393132286c442345e68ff0aaa": "Coinbase 3",
  "0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511": "Coinbase 5",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
  "0x236f233dbb0dd3e0d4b5b4b91440f54c21b8d034": "Crypto.com Hot Wallet 1",
  "0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com Hot Wallet 2",
  "0x46340b20830761efd32832a74d7169b29feb9758": "Crypto.com Hot Wallet 3",
  "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Kraken",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken 4",
  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io 1",
  "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io 2",
};

async function fetchJSON(url: string): Promise<any> {
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/3.0" }, timeout: 15000 } as any);
      if (r.status === 429) { await sleep(3000); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(1000); }
  }
  return null;
}

function fmtVal(val: string, dec = 18): string {
  const n = parseFloat(val) / Math.pow(10, dec);
  if (isNaN(n) || n === 0) return "0";
  if (n >= 1e9) return (n/1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n/1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n/1e3).toFixed(2) + "K";
  return n.toFixed(4);
}

interface TX {
  hash: string; from: string; to: string; value: string; timestamp: string;
  block: number; chain: string; type: "token" | "native";
  tokenSymbol?: string; tokenDecimals?: number; tokenAddress?: string; method?: string;
}

async function getAllTokenTransfers(api: string, addr: string, chain: string): Promise<TX[]> {
  const results: TX[] = [];
  let next = "";
  let pages = 0;
  while (pages < 100) {
    const url = `${api}/addresses/${addr}/token-transfers${next ? "?" + next : ""}`;
    const data = await fetchJSON(url);
    await sleep(350);
    if (!data?.items?.length) break;
    for (const tt of data.items) {
      results.push({
        hash: tt.transaction_hash || tt.tx_hash || "",
        from: (tt.from?.hash || "").toLowerCase(),
        to: (tt.to?.hash || "").toLowerCase(),
        value: tt.total?.value || "0",
        timestamp: tt.timestamp || "",
        block: tt.block_number || 0,
        chain, type: "token",
        tokenSymbol: tt.token?.symbol || "???",
        tokenDecimals: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
        tokenAddress: (tt.token?.address || "").toLowerCase(),
      });
    }
    if (!data.next_page_params) break;
    next = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  return results;
}

async function getAllNativeTxs(api: string, addr: string, chain: string): Promise<TX[]> {
  const results: TX[] = [];
  let next = "";
  let pages = 0;
  while (pages < 100) {
    const url = `${api}/addresses/${addr}/transactions${next ? "?" + next : ""}`;
    const data = await fetchJSON(url);
    await sleep(350);
    if (!data?.items?.length) break;
    for (const tx of data.items) {
      results.push({
        hash: tx.hash,
        from: (tx.from?.hash || "").toLowerCase(),
        to: (tx.to?.hash || "").toLowerCase(),
        value: tx.value || "0",
        timestamp: tx.timestamp || "",
        block: tx.block || 0,
        chain, type: "native",
        method: tx.method || "",
      });
    }
    if (!data.next_page_params) break;
    next = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  return results;
}

async function checkExists(api: string, addr: string): Promise<{ txCount: number; tokenCount: number } | null> {
  const data = await fetchJSON(`${api}/addresses/${addr}`);
  if (!data) return null;
  return { txCount: parseInt(data.transactions_count || "0"), tokenCount: parseInt(data.token_transfers_count || "0") };
}

async function main() {
  const phase = process.argv[2] || "core";
  
  if (phase === "core") {
    // ══════════════════════════════════════════════════════
    // PHASE: DEEP SCAN CORE WALLETS ACROSS ALL CHAINS
    // ══════════════════════════════════════════════════════
    console.log("═══ DEEP SCANNING CORE CASE WALLETS ACROSS ALL CHAINS ═══\n");
    
    // Get core wallets (status = monitoring, NOT token_recipient)
    const coreWallets = await db.select().from(monitoredWallets).where(
      eq(monitoredWallets.caseId, CASE_ID)
    );
    const core = coreWallets.filter(w => w.role !== "token_recipient");
    const allAddrs = [...new Set(core.map(w => w.address.toLowerCase()))];
    
    // Add known key addresses
    const keyAddrs = [
      "0xd14f4b36e1d1d98c218db782c49149876042bc56",
      "0x6818809eefce719e480a7526d76bd3e561526b46",
      "0x658370618bbc885865df66c1061bfe4771fad846",
      "0xf70da97812cb96acdf810712aa562db8dfa3dbef",
      "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb",
      "0xb01fed2f701695992a4f7ffdb53f3af099e140d7",
      "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872",
      "0x423d2b61952d56358db8b313ec7404a9582d4865",
      "0x6fe0fab2164d8e0d03ad6a628e2af78624060322",
      "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41",
    ];
    for (const a of keyAddrs) allAddrs.push(a);
    const uniqueAddrs = [...new Set(allAddrs)];
    
    console.log(`Core wallets: ${uniqueAddrs.length}`);
    
    // Build label map
    const labelMap = new Map<string, string>();
    for (const w of core) { if (w.label) labelMap.set(w.address.toLowerCase(), w.label); }
    const knownLabels: Record<string, string> = {
      "0x6fe0fab2164d8e0d03ad6a628e2af78624060322": "VICTIM PRIMARY",
      "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41": "VICTIM SECONDARY",
      "0xf70da97812cb96acdf810712aa562db8dfa3dbef": "POI ($4.35M)",
      "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872": "LAUNDERING HUB ($20M)",
      "0xd14f4b36e1d1d98c218db782c49149876042bc56": "FXUSD SOURCE",
      "0x658370618bbc885865df66c1061bfe4771fad846": "CRYPTO.COM SUSPECT",
      "0x423d2b61952d56358db8b313ec7404a9582d4865": "ORIGINAL FUNDER",
      "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb": "SOURCE EIP-7702",
      "0xb01fed2f701695992a4f7ffdb53f3af099e140d7": "GAS FUNDER",
      "0x6818809eefce719e480a7526d76bd3e561526b46": "RELAY PROXY",
    };
    for (const [a, l] of Object.entries(knownLabels)) labelMap.set(a, l);
    
    const allTxs: TX[] = [];
    const chainsActive = new Map<string, string[]>(); // chain -> addrs with activity
    
    for (const [chain, api] of Object.entries(CHAINS)) {
      console.log(`\n[${chain}] Checking ${uniqueAddrs.length} core wallets...`);
      let activeCount = 0;
      const activeAddrs: string[] = [];
      
      for (let i = 0; i < uniqueAddrs.length; i++) {
        const addr = uniqueAddrs[i];
        process.stdout.write(`\r  ${i+1}/${uniqueAddrs.length} ${addr.slice(0,12)}...`);
        
        const exists = await checkExists(api, addr);
        await sleep(200);
        
        if (exists && (exists.txCount > 0 || exists.tokenCount > 0)) {
          activeCount++;
          activeAddrs.push(addr);
          const label = labelMap.get(addr) || "";
          console.log(`\n  ✦ ACTIVE on ${chain}: ${addr.slice(0,14)}...${label ? " ["+label+"]" : ""} (${exists.txCount} tx, ${exists.tokenCount} tokens)`);
          
          // Deep scan
          const tokens = await getAllTokenTransfers(api, addr, chain);
          const native = await getAllNativeTxs(api, addr, chain);
          allTxs.push(...tokens, ...native);
          console.log(`    → ${tokens.length} token transfers, ${native.length} native txs`);
        }
      }
      
      if (activeAddrs.length > 0) {
        chainsActive.set(chain, activeAddrs);
      }
      console.log(`\n  ${chain}: ${activeCount} active wallets`);
    }
    
    // Deduplicate
    const uniqueTxs = new Map<string, TX>();
    for (const t of allTxs) {
      const key = `${t.hash}-${t.from}-${t.to}-${t.tokenSymbol||"N"}-${t.chain}`;
      if (!uniqueTxs.has(key)) uniqueTxs.set(key, t);
    }
    const txList = [...uniqueTxs.values()].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    // New activity since last scan
    const lastScan = new Date("2026-03-08T02:00:00Z");
    const newTxs = txList.filter(t => new Date(t.timestamp) > lastScan);
    
    // Discover new addresses not in our DB
    const allCaseAddrs = new Set(coreWallets.map(w => w.address.toLowerCase()));
    const discoveredAddrs = new Set<string>();
    for (const t of txList) {
      if (t.from && !allCaseAddrs.has(t.from)) discoveredAddrs.add(t.from);
      if (t.to && !allCaseAddrs.has(t.to)) discoveredAddrs.add(t.to);
    }
    
    // Exchange interactions
    const exchangeHits: Array<{ chain: string; exchange: string; hash: string; from: string; to: string; timestamp: string; value: string; tokenSymbol?: string }> = [];
    for (const t of txList) {
      const exFrom = KNOWN_EXCHANGES[t.from];
      const exTo = KNOWN_EXCHANGES[t.to];
      if (exFrom || exTo) {
        exchangeHits.push({
          chain: t.chain,
          exchange: exFrom || exTo || "",
          hash: t.hash,
          from: t.from,
          to: t.to,
          timestamp: t.timestamp,
          value: t.value,
          tokenSymbol: t.tokenSymbol,
        });
      }
    }
    
    // Token summary
    const tokenSummary = new Map<string, { count: number; totalVal: number; chains: Set<string>; senders: Set<string>; receivers: Set<string> }>();
    for (const t of txList.filter(t => t.type === "token")) {
      if (!tokenSummary.has(t.tokenSymbol!)) tokenSummary.set(t.tokenSymbol!, { count: 0, totalVal: 0, chains: new Set(), senders: new Set(), receivers: new Set() });
      const s = tokenSummary.get(t.tokenSymbol!)!;
      s.count++;
      s.totalVal += parseFloat(t.value) / Math.pow(10, t.tokenDecimals || 18);
      s.chains.add(t.chain);
      s.senders.add(t.from);
      s.receivers.add(t.to);
    }
    
    // ═══ BUILD REPORT ═══
    let rpt = "";
    rpt += "═".repeat(90) + "\n";
    rpt += "  ALPHA FORENSIC INTELLIGENCE ENGINE™\n";
    rpt += "  COMPREHENSIVE MULTI-CHAIN SCAN — ALL CORE WALLETS, ALL CHAINS, ALL TOKENS\n";
    rpt += "  Case: @sillytuna (Alex Amsel) ~$24M Physical Theft\n";
    rpt += `  Generated: ${new Date().toISOString()}\n`;
    rpt += `  Case ID: ${CASE_ID}\n`;
    rpt += "═".repeat(90) + "\n\n";
    
    rpt += "SCAN SUMMARY\n" + "─".repeat(70) + "\n";
    rpt += `  Core Wallets Scanned: ${uniqueAddrs.length}\n`;
    rpt += `  Chains Scanned: ${Object.keys(CHAINS).join(", ")} (${Object.keys(CHAINS).length} chains)\n`;
    rpt += `  Chains With Activity: ${[...chainsActive.keys()].join(", ")}\n`;
    rpt += `  Total Unique Transactions: ${txList.length}\n`;
    rpt += `  Token Transfers: ${txList.filter(t=>t.type==="token").length}\n`;
    rpt += `  Native TXs: ${txList.filter(t=>t.type==="native").length}\n`;
    rpt += `  Unique Tokens: ${tokenSummary.size}\n`;
    rpt += `  Exchange Interactions Found: ${exchangeHits.length}\n`;
    rpt += `  New Activity Since Last Scan: ${newTxs.length}\n`;
    rpt += `  Wallet DB (including recipients): ${coreWallets.length}\n\n`;
    
    // Active wallets by chain
    rpt += "ACTIVE WALLETS BY CHAIN\n" + "─".repeat(70) + "\n";
    for (const [chain, addrs] of chainsActive) {
      rpt += `  ${chain}: ${addrs.length} wallets\n`;
      for (const a of addrs) {
        rpt += `    ${a}${labelMap.has(a) ? " [" + labelMap.get(a) + "]" : ""}\n`;
      }
    }
    rpt += "\n";
    
    // NEW ACTIVITY
    rpt += "═".repeat(90) + "\n";
    rpt += `  NEW ACTIVITY SINCE LAST SCAN (${newTxs.length} transactions)\n`;
    rpt += "═".repeat(90) + "\n\n";
    for (const t of newTxs) {
      const fl = labelMap.get(t.from) ? ` [${labelMap.get(t.from)}]` : (KNOWN_EXCHANGES[t.from] ? ` [${KNOWN_EXCHANGES[t.from]}]` : "");
      const tl = labelMap.get(t.to) ? ` [${labelMap.get(t.to)}]` : (KNOWN_EXCHANGES[t.to] ? ` [${KNOWN_EXCHANGES[t.to]}]` : "");
      if (t.type === "token") {
        rpt += `  [${t.chain.toUpperCase()}] ${t.timestamp} | ${t.tokenSymbol}\n`;
        rpt += `    TX: ${t.hash}\n`;
        rpt += `    FROM: ${t.from}${fl}\n`;
        rpt += `    TO:   ${t.to}${tl}\n`;
        rpt += `    VALUE: ${fmtVal(t.value, t.tokenDecimals||18)} ${t.tokenSymbol}\n\n`;
      } else {
        rpt += `  [${t.chain.toUpperCase()}] ${t.timestamp} | NATIVE\n`;
        rpt += `    TX: ${t.hash}\n`;
        rpt += `    FROM: ${t.from}${fl}\n`;
        rpt += `    TO:   ${t.to}${tl}\n`;
        rpt += `    VALUE: ${fmtVal(t.value)} ETH${t.method ? " | " + t.method : ""}\n\n`;
      }
    }
    
    // EXCHANGE INTERACTIONS
    rpt += "═".repeat(90) + "\n";
    rpt += `  EXCHANGE INTERACTIONS (${exchangeHits.length} found)\n`;
    rpt += "═".repeat(90) + "\n\n";
    for (const e of exchangeHits.sort((a,b) => a.timestamp.localeCompare(b.timestamp))) {
      rpt += `  [${e.chain.toUpperCase()}] ${e.timestamp} | ${e.exchange}\n`;
      rpt += `    TX: ${e.hash}\n`;
      rpt += `    ${e.from}${labelMap.has(e.from) ? " ["+labelMap.get(e.from)+"]" : ""}\n`;
      rpt += `    → ${e.to}${labelMap.has(e.to) ? " ["+labelMap.get(e.to)+"]" : ""}\n`;
      if (e.tokenSymbol) rpt += `    Token: ${e.tokenSymbol}\n`;
      rpt += "\n";
    }
    
    // TOKEN SUMMARY
    rpt += "═".repeat(90) + "\n";
    rpt += "  ALL TOKENS TRACED — COMPLETE SUMMARY\n";
    rpt += "═".repeat(90) + "\n\n";
    for (const [sym, info] of [...tokenSummary.entries()].sort((a,b) => b[1].totalVal - a[1].totalVal)) {
      const valStr = info.totalVal >= 1e9 ? (info.totalVal/1e9).toFixed(2)+"B" :
                     info.totalVal >= 1e6 ? (info.totalVal/1e6).toFixed(2)+"M" :
                     info.totalVal >= 1e3 ? (info.totalVal/1e3).toFixed(2)+"K" : info.totalVal.toFixed(4);
      rpt += `  ${sym.padEnd(15)} ${valStr.padStart(15)} | ${info.count} transfers | ${[...info.chains].join(",")} | ${info.senders.size} senders → ${info.receivers.size} receivers\n`;
    }
    
    // PER-WALLET BREAKDOWN
    rpt += "\n" + "═".repeat(90) + "\n";
    rpt += "  PER-WALLET ACTIVITY BREAKDOWN\n";
    rpt += "═".repeat(90) + "\n\n";
    
    const walletTxs = new Map<string, TX[]>();
    for (const t of txList) {
      // Group by the wallet that was being scanned
      for (const addr of uniqueAddrs) {
        if (t.from === addr || t.to === addr) {
          if (!walletTxs.has(addr)) walletTxs.set(addr, []);
          walletTxs.get(addr)!.push(t);
        }
      }
    }
    
    for (const [addr, txs] of [...walletTxs.entries()].sort((a,b) => b[1].length - a[1].length)) {
      const label = labelMap.get(addr) || "";
      const chains = [...new Set(txs.map(t => t.chain))];
      const tokens = txs.filter(t => t.type === "token");
      const native = txs.filter(t => t.type === "native");
      const timestamps = txs.map(t => t.timestamp).filter(Boolean).sort();
      
      rpt += `  ${addr}${label ? " ["+label+"]" : ""}\n`;
      rpt += `    Chains: ${chains.join(", ")} | ${native.length} native + ${tokens.length} token = ${txs.length} total\n`;
      if (timestamps.length > 0) rpt += `    Active: ${timestamps[0]?.split("T")[0]} → ${timestamps[timestamps.length-1]?.split("T")[0]}\n`;
      
      // Token breakdown
      const tMap = new Map<string, number>();
      for (const t of tokens) tMap.set(t.tokenSymbol!, (tMap.get(t.tokenSymbol!) || 0) + 1);
      if (tMap.size > 0) rpt += `    Tokens: ${[...tMap.entries()].map(([s,c]) => `${s}(${c})`).join(", ")}\n`;
      
      // Key destinations
      const dests = new Set<string>();
      for (const t of txs) { if (t.from === addr && t.to) dests.add(t.to); }
      rpt += `    → Sent to ${dests.size} addresses\n\n`;
    }
    
    // COMPLETE TX LOG
    rpt += "═".repeat(90) + "\n";
    rpt += `  COMPLETE TRANSACTION LOG (${txList.length} records, chronological)\n`;
    rpt += "═".repeat(90) + "\n\n";
    
    for (const t of txList) {
      const fl = labelMap.get(t.from) || KNOWN_EXCHANGES[t.from] || "";
      const tl = labelMap.get(t.to) || KNOWN_EXCHANGES[t.to] || "";
      if (t.type === "token") {
        rpt += `[${t.chain.toUpperCase().padEnd(10)}] ${t.timestamp} | ${t.hash}\n`;
        rpt += `  ${t.from}${fl?" ["+fl+"]":""} → ${t.to}${tl?" ["+tl+"]":""} | ${fmtVal(t.value, t.tokenDecimals||18)} ${t.tokenSymbol}\n`;
      } else {
        rpt += `[${t.chain.toUpperCase().padEnd(10)}] ${t.timestamp} | ${t.hash}\n`;
        rpt += `  ${t.from}${fl?" ["+fl+"]":""} → ${t.to}${tl?" ["+tl+"]":""} | ${fmtVal(t.value)} ETH${t.method?" | "+t.method:""}\n`;
      }
    }
    
    rpt += "\n" + "═".repeat(90) + "\n";
    rpt += "  END OF COMPREHENSIVE MULTI-CHAIN SCAN REPORT\n";
    rpt += `  Total Wallets in Case DB: ${coreWallets.length} (${core.length} core + ${coreWallets.length - core.length} recipients)\n`;
    rpt += "  Alpha Unlimited Trading Company — Forensic Intelligence Division\n";
    rpt += "  © 2024-2026 All Rights Reserved. PROPRIETARY AND CONFIDENTIAL\n";
    rpt += "═".repeat(90) + "\n";
    
    const outFile = "forensic_complete_multichain_scan.txt";
    fs.writeFileSync(outFile, rpt);
    const sizeKb = (fs.statSync(outFile).size / 1024).toFixed(1);
    
    console.log(`\n\n${"═".repeat(60)}`);
    console.log(`SCAN COMPLETE`);
    console.log(`Report: ${outFile} (${sizeKb} KB)`);
    console.log(`Total TXs: ${txList.length}`);
    console.log(`New Activity: ${newTxs.length}`);
    console.log(`Exchange Hits: ${exchangeHits.length}`);
    console.log(`Tokens: ${tokenSummary.size}`);
    console.log(`Chains active: ${[...chainsActive.keys()].join(", ")}`);
    
    // Save metadata for email script
    fs.writeFileSync("/tmp/scan_meta.json", JSON.stringify({
      totalTxs: txList.length,
      newActivity: newTxs.length,
      exchangeHits: exchangeHits.length,
      tokens: tokenSummary.size,
      chains: [...chainsActive.keys()],
      reportFile: outFile,
      sizeKb,
    }));
  }
  
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
