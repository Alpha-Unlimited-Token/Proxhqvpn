/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_TURBO_SCAN_v2.0
 * ALPHA_INTEGRITY_SEAL: AUT_TurboScan_Calibration_PROTECTED
 *
 * High-speed parallel scanner: checks ALL wallets for activity across chains
 * Uses concurrent requests with rate limiting
 */

import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { monitoredWallets } from "../../shared/models/forensic.js";
import { eq } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const PROGRESS_FILE = "/tmp/turbo_progress.json";
const ACTIVE_FILE = "/tmp/turbo_active.jsonl";
const CONCURRENCY = 15; // parallel requests
const DELAY_BETWEEN_BATCHES = 200;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const CHAINS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
};

async function checkAddress(api: string, addr: string): Promise<{ txCount: number; tokenCount: number } | null> {
  try {
    const r = await fetch(`${api}/addresses/${addr}`, {
      headers: { "User-Agent": "AlphaForensic/3.0" },
      timeout: 8000
    } as any);
    if (!r.ok) return null;
    const data = await r.json() as any;
    return {
      txCount: parseInt(data.transactions_count || "0"),
      tokenCount: parseInt(data.token_transfers_count || "0")
    };
  } catch {
    return null;
  }
}

async function getTokenTransfersFull(api: string, addr: string, chain: string): Promise<any[]> {
  const results: any[] = [];
  let nextParams = "";
  let pages = 0;
  while (pages < 50) {
    try {
      const url = `${api}/addresses/${addr}/token-transfers${nextParams ? "?" + nextParams : ""}`;
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/3.0" }, timeout: 12000 } as any);
      if (!r.ok) break;
      const data = await r.json() as any;
      if (!data?.items?.length) break;
      for (const tt of data.items) {
        results.push({
          hash: tt.transaction_hash || tt.tx_hash || "",
          from: (tt.from?.hash || "").toLowerCase(),
          to: (tt.to?.hash || "").toLowerCase(),
          value: tt.total?.value || "0",
          timestamp: tt.timestamp || "",
          block: tt.block_number || 0,
          tokenAddress: (tt.token?.address || "").toLowerCase(),
          tokenSymbol: tt.token?.symbol || "???",
          tokenDecimals: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
          chain,
        });
      }
      if (!data.next_page_params) break;
      nextParams = new URLSearchParams(data.next_page_params as any).toString();
      pages++;
      await sleep(300);
    } catch { break; }
  }
  return results;
}

async function getNativeTxsFull(api: string, addr: string, chain: string): Promise<any[]> {
  const results: any[] = [];
  let nextParams = "";
  let pages = 0;
  while (pages < 50) {
    try {
      const url = `${api}/addresses/${addr}/transactions${nextParams ? "?" + nextParams : ""}`;
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/3.0" }, timeout: 12000 } as any);
      if (!r.ok) break;
      const data = await r.json() as any;
      if (!data?.items?.length) break;
      for (const tx of data.items) {
        results.push({
          hash: tx.hash,
          from: (tx.from?.hash || "").toLowerCase(),
          to: (tx.to?.hash || "").toLowerCase(),
          value: tx.value || "0",
          timestamp: tx.timestamp || "",
          block: tx.block || 0,
          method: tx.method || "",
          chain,
        });
      }
      if (!data.next_page_params) break;
      nextParams = new URLSearchParams(data.next_page_params as any).toString();
      pages++;
      await sleep(300);
    } catch { break; }
  }
  return results;
}

async function processBatch(addrs: string[], api: string, chain: string): Promise<Array<{ addr: string; txCount: number; tokenCount: number }>> {
  const results: Array<{ addr: string; txCount: number; tokenCount: number }> = [];
  
  // Process in concurrent chunks
  for (let i = 0; i < addrs.length; i += CONCURRENCY) {
    const chunk = addrs.slice(i, i + CONCURRENCY);
    const promises = chunk.map(async addr => {
      const r = await checkAddress(api, addr);
      return { addr, ...r };
    });
    const chunkResults = await Promise.all(promises);
    for (const cr of chunkResults) {
      if (cr.txCount !== undefined && cr.txCount !== null) {
        results.push({ addr: cr.addr, txCount: cr.txCount!, tokenCount: cr.tokenCount! });
      }
    }
    await sleep(DELAY_BETWEEN_BATCHES);
  }
  return results;
}

async function main() {
  const arg = process.argv[2] || "phase1";
  
  if (arg === "phase1") {
    // PHASE 1: Quick scan all wallets to find which ones have activity
    console.log("═══ PHASE 1: QUICK ACTIVITY CHECK ═══\n");
    
    const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
    const allAddrs = [...new Set(wallets.map(w => w.address.toLowerCase()))];
    console.log(`Total unique addresses: ${allAddrs.length}`);
    
    // Load progress
    let progress: { done: Record<string, string[]>; active: Record<string, Array<{ addr: string; txCount: number; tokenCount: number }>> } = { done: {}, active: {} };
    if (fs.existsSync(PROGRESS_FILE)) {
      progress = JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
    }
    
    for (const [chain, api] of Object.entries(CHAINS)) {
      if (progress.done[chain]?.length === allAddrs.length) {
        console.log(`\n[${chain}] Already done — ${progress.active[chain]?.length || 0} active wallets found`);
        continue;
      }
      
      const alreadyDone = new Set(progress.done[chain] || []);
      const remaining = allAddrs.filter(a => !alreadyDone.has(a));
      
      if (remaining.length === 0) {
        console.log(`\n[${chain}] All scanned`);
        continue;
      }
      
      console.log(`\n[${chain}] Scanning ${remaining.length} addresses (${alreadyDone.size} already done)...`);
      
      const batchSize = 500;
      if (!progress.active[chain]) progress.active[chain] = [];
      if (!progress.done[chain]) progress.done[chain] = [];
      
      for (let b = 0; b < remaining.length; b += batchSize) {
        const batch = remaining.slice(b, b + batchSize);
        process.stdout.write(`\r  ${b + batch.length}/${remaining.length} checked...`);
        
        const results = await processBatch(batch, api, chain);
        
        for (const r of results) {
          progress.done[chain].push(r.addr);
          if (r.txCount > 0 || r.tokenCount > 0) {
            progress.active[chain].push(r);
          }
        }
        
        // Save progress every batch
        fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress));
      }
      
      console.log(`\n  ✓ ${chain}: ${progress.active[chain].length} active wallets found out of ${allAddrs.length}`);
    }
    
    // Summary
    console.log("\n═══ PHASE 1 COMPLETE ═══");
    let totalActive = 0;
    for (const [chain, active] of Object.entries(progress.active)) {
      console.log(`  ${chain}: ${active.length} active wallets`);
      totalActive += active.length;
    }
    console.log(`  TOTAL ACTIVE: ${totalActive} wallet-chain pairs\n`);
    console.log("Run with 'phase2' to deep-scan all active wallets");
    
  } else if (arg === "phase2") {
    // PHASE 2: Deep scan all active wallets
    console.log("═══ PHASE 2: DEEP SCAN ACTIVE WALLETS ═══\n");
    
    if (!fs.existsSync(PROGRESS_FILE)) {
      console.error("Run phase1 first!");
      process.exit(1);
    }
    
    const progress = JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
    const phase2Progress: { done: Set<string> } = { done: new Set() };
    const PHASE2_FILE = "/tmp/turbo_phase2.json";
    if (fs.existsSync(PHASE2_FILE)) {
      const p2 = JSON.parse(fs.readFileSync(PHASE2_FILE, "utf-8"));
      phase2Progress.done = new Set(p2.done || []);
    }
    
    // Load labels
    const dbWallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
    const labelMap = new Map<string, string>();
    for (const w of dbWallets) {
      if (w.label) labelMap.set(w.address.toLowerCase(), w.label);
    }
    
    let totalProcessed = 0;
    let totalTokenTxs = 0;
    let totalNativeTxs = 0;
    
    for (const [chain, activeList] of Object.entries(progress.active as Record<string, Array<{ addr: string; txCount: number; tokenCount: number }>>)) {
      const api = CHAINS[chain];
      if (!api) continue;
      
      const toScan = activeList.filter(a => !phase2Progress.done.has(`${a.addr}:${chain}`));
      if (toScan.length === 0) {
        console.log(`[${chain}] All ${activeList.length} active wallets already deep-scanned`);
        continue;
      }
      
      console.log(`[${chain}] Deep scanning ${toScan.length} active wallets...`);
      
      for (let i = 0; i < toScan.length; i++) {
        const { addr, txCount, tokenCount } = toScan[i];
        process.stdout.write(`\r  [${i + 1}/${toScan.length}] ${addr.slice(0, 14)}... (${txCount} tx, ${tokenCount} tokens)`);
        
        // Get full token transfers
        if (tokenCount > 0) {
          const tokens = await getTokenTransfersFull(api, addr, chain);
          totalTokenTxs += tokens.length;
          for (const t of tokens) {
            fs.appendFileSync(ACTIVE_FILE, JSON.stringify({ ...t, type: "token", wallet: addr }) + "\n");
          }
        }
        
        // Get full native txs
        if (txCount > 0) {
          const native = await getNativeTxsFull(api, addr, chain);
          totalNativeTxs += native.length;
          for (const t of native) {
            fs.appendFileSync(ACTIVE_FILE, JSON.stringify({ ...t, type: "native", wallet: addr }) + "\n");
          }
        }
        
        phase2Progress.done.add(`${addr}:${chain}`);
        totalProcessed++;
        
        // Save progress every 10 wallets
        if (totalProcessed % 10 === 0) {
          fs.writeFileSync(PHASE2_FILE, JSON.stringify({ done: [...phase2Progress.done] }));
        }
      }
      
      fs.writeFileSync(PHASE2_FILE, JSON.stringify({ done: [...phase2Progress.done] }));
      console.log(`\n  ✓ ${chain} done: ${totalTokenTxs} token transfers, ${totalNativeTxs} native txs so far`);
    }
    
    console.log("\n═══ PHASE 2 COMPLETE ═══");
    console.log(`  Wallets deep-scanned: ${totalProcessed}`);
    console.log(`  Token transfers collected: ${totalTokenTxs}`);
    console.log(`  Native TXs collected: ${totalNativeTxs}`);
    console.log("\nRun with 'report' to build the final report");
    
  } else if (arg === "report") {
    // PHASE 3: Build comprehensive report
    console.log("═══ BUILDING COMPREHENSIVE REPORT ═══\n");
    
    if (!fs.existsSync(ACTIVE_FILE)) {
      console.error("Run phase1 and phase2 first!");
      process.exit(1);
    }
    
    const lines = fs.readFileSync(ACTIVE_FILE, "utf-8").trim().split("\n").filter(Boolean);
    console.log(`Loading ${lines.length} transaction records...`);
    
    const dbWallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
    const labelMap = new Map<string, string>();
    for (const w of dbWallets) {
      if (w.label) labelMap.set(w.address.toLowerCase(), w.label);
    }
    
    // Add known labels
    const knownLabels: Record<string, string> = {
      "0x6fe0fab2164d8e0d03ad6a628e2af78624060322": "VICTIM PRIMARY",
      "0xf70da97812cb96acdf810712aa562db8dfa3dbef": "POI ($4.35M)",
      "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872": "LAUNDERING HUB ($20M)",
      "0xd14f4b36e1d1d98c218db782c49149876042bc56": "FXUSD SOURCE",
      "0x658370618bbc885865df66c1061bfe4771fad846": "CRYPTO.COM SUSPECT",
      "0x423d2b61952d56358db8b313ec7404a9582d4865": "ORIGINAL FUNDER",
      "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb": "SOURCE EIP-7702",
      "0xb01fed2f701695992a4f7ffdb53f3af099e140d7": "GAS FUNDER",
      "0x6818809eefce719e480a7526d76bd3e561526b46": "RELAY PROXY",
    };
    for (const [a, l] of Object.entries(knownLabels)) labelMap.set(a, l);
    
    // Parse all records
    const allRecords = lines.map(l => JSON.parse(l));
    
    // Deduplicate
    const unique = new Map<string, any>();
    for (const r of allRecords) {
      const key = `${r.hash}-${r.from}-${r.to}-${r.tokenSymbol || "NATIVE"}-${r.chain}`;
      if (!unique.has(key)) unique.set(key, r);
    }
    const records = [...unique.values()].sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    console.log(`${records.length} unique records after dedup`);
    
    // Get progress for chain info
    const progress = JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
    
    // Build report (will save to file, too large for stdout)
    let report = "";
    report += "═".repeat(90) + "\n";
    report += "  ALPHA FORENSIC INTELLIGENCE ENGINE\n";
    report += "  COMPREHENSIVE MULTI-CHAIN DEEP SCAN — ALL 22,000+ WALLETS\n";
    report += "  Case: @sillytuna (Alex Amsel) ~$24M Theft\n";
    report += `  Generated: ${new Date().toISOString()}\n`;
    report += `  Case ID: ${CASE_ID}\n`;
    report += "═".repeat(90) + "\n\n";
    
    // Summary stats
    const tokenRecords = records.filter((r: any) => r.type === "token");
    const nativeRecords = records.filter((r: any) => r.type === "native");
    const chains = [...new Set(records.map((r: any) => r.chain))];
    
    report += "SCAN SUMMARY\n" + "─".repeat(60) + "\n";
    report += `  Total Wallets in Case DB: ${dbWallets.length}\n`;
    for (const [chain, active] of Object.entries(progress.active || {})) {
      report += `  ${chain}: ${(active as any[]).length} wallets with activity\n`;
    }
    report += `  Chains With Activity: ${chains.join(", ")}\n`;
    report += `  Total Unique Transactions: ${records.length}\n`;
    report += `  Token Transfers: ${tokenRecords.length}\n`;
    report += `  Native TXs: ${nativeRecords.length}\n\n`;
    
    // New activity
    const lastScan = new Date("2026-03-08T02:00:00Z");
    const newRecords = records.filter((r: any) => new Date(r.timestamp) > lastScan);
    report += "═".repeat(90) + "\n";
    report += `  NEW ACTIVITY SINCE LAST SCAN (${newRecords.length} transactions)\n`;
    report += "═".repeat(90) + "\n\n";
    for (const r of newRecords) {
      const fromLabel = labelMap.get(r.from) ? ` [${labelMap.get(r.from)}]` : "";
      const toLabel = labelMap.get(r.to) ? ` [${labelMap.get(r.to)}]` : "";
      if (r.type === "token") {
        const val = parseFloat(r.value) / Math.pow(10, r.tokenDecimals || 18);
        const valStr = val >= 1e6 ? (val/1e6).toFixed(2)+"M" : val >= 1e3 ? (val/1e3).toFixed(2)+"K" : val.toFixed(4);
        report += `  [${r.chain.toUpperCase()}] ${r.timestamp} | ${r.tokenSymbol}\n`;
        report += `    ${r.from}${fromLabel} → ${r.to}${toLabel}\n`;
        report += `    ${valStr} ${r.tokenSymbol} | TX: ${r.hash}\n\n`;
      } else {
        const val = parseFloat(r.value) / 1e18;
        report += `  [${r.chain.toUpperCase()}] ${r.timestamp} | NATIVE\n`;
        report += `    ${r.from}${fromLabel} → ${r.to}${toLabel}\n`;
        report += `    ${val.toFixed(6)} ETH | TX: ${r.hash}\n\n`;
      }
    }
    
    // Token summary
    const tokenSummary = new Map<string, { count: number; totalVal: number; chains: Set<string> }>();
    for (const r of tokenRecords) {
      if (!tokenSummary.has(r.tokenSymbol)) tokenSummary.set(r.tokenSymbol, { count: 0, totalVal: 0, chains: new Set() });
      const s = tokenSummary.get(r.tokenSymbol)!;
      s.count++;
      s.totalVal += parseFloat(r.value) / Math.pow(10, r.tokenDecimals || 18);
      s.chains.add(r.chain);
    }
    
    report += "═".repeat(90) + "\n";
    report += "  ALL TOKENS TRACED\n";
    report += "═".repeat(90) + "\n\n";
    for (const [sym, info] of [...tokenSummary.entries()].sort((a, b) => b[1].totalVal - a[1].totalVal)) {
      const valStr = info.totalVal >= 1e6 ? (info.totalVal/1e6).toFixed(2)+"M" : info.totalVal >= 1e3 ? (info.totalVal/1e3).toFixed(2)+"K" : info.totalVal.toFixed(4);
      report += `  ${sym.padEnd(15)} ${valStr.padStart(15)} | ${info.count} transfers | ${[...info.chains].join(",")}\n`;
    }
    
    // Full transaction log
    report += "\n" + "═".repeat(90) + "\n";
    report += `  COMPLETE TRANSACTION LOG (${records.length} records)\n`;
    report += "═".repeat(90) + "\n\n";
    for (const r of records) {
      const fromLabel = labelMap.get(r.from) ? `[${labelMap.get(r.from)}]` : "";
      const toLabel = labelMap.get(r.to) ? `[${labelMap.get(r.to)}]` : "";
      if (r.type === "token") {
        const val = parseFloat(r.value) / Math.pow(10, r.tokenDecimals || 18);
        const valStr = val >= 1e6 ? (val/1e6).toFixed(2)+"M" : val >= 1e3 ? (val/1e3).toFixed(2)+"K" : val.toFixed(4);
        report += `[${(r.chain||"").toUpperCase().padEnd(10)}] ${r.timestamp} | ${r.hash}\n`;
        report += `  ${r.from}${fromLabel} → ${r.to}${toLabel} | ${valStr} ${r.tokenSymbol}\n`;
      } else {
        const val = parseFloat(r.value) / 1e18;
        report += `[${(r.chain||"").toUpperCase().padEnd(10)}] ${r.timestamp} | ${r.hash}\n`;
        report += `  ${r.from}${fromLabel} → ${r.to}${toLabel} | ${val.toFixed(6)} ETH${r.method ? " | " + r.method : ""}\n`;
      }
    }
    
    report += "\n" + "═".repeat(90) + "\n";
    report += "  END OF COMPREHENSIVE MULTI-CHAIN REPORT\n";
    report += "  Alpha Unlimited Trading Company — Forensic Intelligence Division\n";
    report += "  © 2024-2026 All Rights Reserved. PROPRIETARY AND CONFIDENTIAL\n";
    report += "═".repeat(90) + "\n";
    
    const outFile = "forensic_complete_multichain_scan.txt";
    fs.writeFileSync(outFile, report);
    const sizeKb = (fs.statSync(outFile).size / 1024).toFixed(1);
    console.log(`\nReport saved: ${outFile} (${sizeKb} KB)`);
    console.log(`Total records: ${records.length}`);
    console.log(`New activity: ${newRecords.length}`);
    console.log(`Tokens traced: ${tokenSummary.size}`);
  }
  
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
