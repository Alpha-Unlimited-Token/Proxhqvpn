/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_RECENT_CRYPTO_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_RecentCrypto_Calibration_PROTECTED
 */

const BE = "https://eth.blockscout.com/api/v2";
const WALLET = "0x658370618bbc885865df66c1061bfe4771fad846";

async function api(url: string) {
  const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
  if (!r.ok) return null;
  return await r.json();
}

async function main() {
  console.log(`\n═══ CRYPTO.COM SUSPECT WALLET — COMPLETE ACTIVITY ═══`);
  console.log(`Wallet: ${WALLET}`);
  console.log(`Checked: ${new Date().toISOString()}\n`);

  const txs = await api(`${BE}/addresses/${WALLET}/transactions`);
  if (txs?.items) {
    console.log(`═══ ETH TRANSACTIONS (${txs.items.length} most recent) ═══\n`);
    for (const tx of txs.items) {
      const from = tx.from?.hash || "";
      const to = tx.to?.hash || "";
      const fromName = tx.from?.name || "";
      const toName = tx.to?.name || "";
      const val = parseInt(tx.value || "0") / 1e18;
      const dir = from.toLowerCase() === WALLET ? "OUT →" : "IN  ←";
      const counterparty = from.toLowerCase() === WALLET ? `${to} ${toName}` : `${from} ${fromName}`;
      console.log(`  ${tx.timestamp}  ${dir}  ${val.toFixed(6)} ETH`);
      console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
      console.log(`    TX: ${tx.hash}`);
      console.log("");
    }
  }

  const tokens = await api(`${BE}/addresses/${WALLET}/token-transfers`);
  if (tokens?.items) {
    console.log(`\n═══ TOKEN TRANSFERS (${tokens.items.length} most recent) ═══\n`);
    for (const tt of tokens.items) {
      const from = tt.from?.hash || "";
      const to = tt.to?.hash || "";
      const fromName = tt.from?.name || "";
      const toName = tt.to?.name || "";
      const sym = tt.token?.symbol || "???";
      const dec = parseInt(tt.token?.decimals || "18");
      const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
      const dir = from.toLowerCase() === WALLET ? "OUT →" : "IN  ←";
      const counterparty = from.toLowerCase() === WALLET ? `${to} ${toName}` : `${from} ${fromName}`;
      console.log(`  ${tt.timestamp}  ${dir}  ${amt.toFixed(6)} ${sym}`);
      console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
      console.log(`    TX: ${tt.transaction_hash || ""}`);
      console.log("");
    }
  }

  const bal = await api(`${BE}/addresses/${WALLET}`);
  if (bal) {
    const ethBal = parseInt(bal.coin_balance || "0") / 1e18;
    console.log(`\n═══ CURRENT BALANCE ═══`);
    console.log(`  ETH: ${ethBal.toFixed(8)}`);
  }

  const tBal = await api(`${BE}/addresses/${WALLET}/tokens?type=ERC-20`);
  if (tBal?.items) {
    console.log(`\n═══ TOKEN HOLDINGS ═══\n`);
    for (const t of tBal.items) {
      const dec = parseInt(t.token?.decimals || "18");
      const val = parseFloat(t.value || "0") / Math.pow(10, dec);
      if (val > 0.000001) {
        console.log(`  ${t.token?.symbol}: ${val.toFixed(6)} (${t.token?.name})`);
      }
    }
    if (tBal.items.filter((t: any) => parseFloat(t.value || "0") > 0).length === 0) {
      console.log("  No token holdings.");
    }
  }
}
main().catch(e => { console.error(e); process.exit(1); });
