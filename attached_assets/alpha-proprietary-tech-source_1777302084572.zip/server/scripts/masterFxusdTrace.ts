/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Alpha Forensic Master FXUSD-Anchored Trace™
 * AUT_FORENSIC_MASTER_FXUSD_TRACE_v4.0
 * ALPHA_INTEGRITY_SEAL: AUT_MasterFXUSD_Calibration_PROTECTED
 *
 * Streams report to disk as it runs. Single-page token transfer per wallet.
 * Batch RPC blacklist checks. Covers all 64+ important wallets.
 */

import * as fs from "fs";
import { db } from "../db.js";
import { monitoredWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const BE = "https://eth.blockscout.com/api/v2";
const BA = "https://arbitrum.blockscout.com/api/v2";
const RPC = "https://ethereum-rpc.publicnode.com";
const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const OUT = "forensic_master_fxusd_trace.txt";

const FS = "0xD14F4B36E1D1D98c218db782c49149876042BC56";
const RP = "0x6818809EefCe719E480a7526D76bD3e561526b46";
const RL = "0xEC15c20015e72748F03065ed80c41cb882E3fB66";
const CC = "0x658370618BBc885865df66c1061BfE4771FaD846";
const CH = "0x46340b20830761efd32832A74d7169B29FEB9758";
const V1 = "0x6fe0fab2164d8e0d03ad6a628e2af78624060322";
const V2 = "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41";
const UC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
const UT = "0xdAC17F958D2ee523a2206206994597C13D831ec7";

const KL: Record<string, string> = {
  [FS.toLowerCase()]: "FXUSD SOURCE",
  [RP.toLowerCase()]: "Relay Proxy (ZK)",
  [RL.toLowerCase()]: "Relayer",
  [CC.toLowerCase()]: "CRYPTO.COM SUSPECT (KYC)",
  [CH.toLowerCase()]: "CRYPTO.COM HOT 2",
  [V1.toLowerCase()]: "VICTIM",
  [V2.toLowerCase()]: "VICTIM 2",
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41": "CoW Swap",
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": "LiFi Bridge",
  "0x3154cf16ccdb4c6d922629664174b904d80f2c35": "Optimism Bridge",
};

const fxAddrs = [FS, RP, CC, V1, V2].map(a => a.toLowerCase());
let fd: number;
let totalTx = 0;

function w(s: string) { fs.writeSync(fd, s + "\n"); }
function wp(s: string) { fs.writeSync(fd, s + "\n"); console.log(s); }
function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function api(url: string): Promise<any> {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

async function bl(addr: string, contract: string, sel: string): Promise<boolean | null> {
  try {
    const p = addr.replace("0x", "").toLowerCase();
    const r = await fetch(RPC, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: contract, data: `0x${sel}000000000000000000000000${p}` }, "latest"], id: 1 }),
      signal: AbortSignal.timeout(6000),
    });
    const d = await r.json();
    if (!d?.result || d.result === "0x") return null;
    return parseInt(d.result, 16) === 1;
  } catch { return null; }
}

function lbl(addr: string, m: Map<string, any>): string {
  const lo = (addr || "").toLowerCase();
  if (KL[lo]) return KL[lo];
  const d = m.get(lo);
  return d ? `${d.label || ""} [${d.role || ""}]` : "";
}

async function main() {
  fd = fs.openSync(OUT, "w");

  wp("═".repeat(80));
  wp("  ALPHA FORENSIC INTELLIGENCE ENGINE™");
  wp("  MASTER FXUSD-ANCHORED EVIDENCE COMPILATION");
  wp("  Case: @sillytuna (Alex Amsel) — ~$24M Crypto Theft");
  wp("  Case ID: " + CASE);
  wp(`  Generated: ${new Date().toISOString()}`);
  wp("  Anchor: FXUSD SOURCE " + FS);
  wp("  Data: Ethereum & Arbitrum mainnet via Blockscout API");
  wp("═".repeat(80));
  w("");
  w("ALL findings anchored through FXUSD SOURCE — confirmed by victim's team.");
  w("Every TX hash independently verifiable on Etherscan/Blockscout.\n");

  console.log("Loading wallets...");
  const all = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
  const dm = new Map<string, any>();
  for (const x of all) dm.set(x.address.toLowerCase(), x);

  const imp = all.filter(x => {
    const r = (x.role || "").toLowerCase();
    return r !== "token_recipient" && !r.includes("victim");
  });

  const seen = new Set<string>();
  const tl: Array<{ a: string; l: string; r: string; c: string }> = [];
  const add = (a: string, l: string, r: string, c: string) => {
    const lo = a.toLowerCase();
    if (seen.has(lo) || !lo.startsWith("0x") || lo.length !== 42) return;
    seen.add(lo);
    tl.push({ a, l, r, c });
  };

  add(FS, "FXUSD SOURCE (Known Tracking Address)", "anchor", "ethereum");
  add(RP, "Relay Proxy (ERC1967)", "relay", "ethereum");
  add(CC, "Crypto.com Suspect (KYC on file)", "suspect", "ethereum");
  add(RL, "Relayer", "relayer", "ethereum");
  for (const x of imp) add(x.address, x.label || "", x.role || "", x.chain || "ethereum");

  wp(`Tracing ${tl.length} wallets (of ${all.length} total)\n`);

  // === SECTION 1: DIRECTORY ===
  w("═".repeat(80));
  w("SECTION 1: WALLET DIRECTORY");
  w("═".repeat(80) + "\n");
  const gr: Record<string, typeof tl> = {};
  for (const x of tl) { const k = x.r || "Other"; if (!gr[k]) gr[k] = []; gr[k].push(x); }
  for (const [role, ws] of Object.entries(gr).sort()) {
    w(`  ${role.toUpperCase()} (${ws.length}):`);
    for (const x of ws) w(`    ${x.a} — ${x.l} [${x.c}]`);
    w("");
  }

  // === SECTION 2: BLACKLIST ===
  w("═".repeat(80));
  w("SECTION 2: USDC / USDT BLACKLIST CHECK");
  w("═".repeat(80) + "\n");

  const blList = [
    { a: V1, l: "Victim" }, { a: V2, l: "Victim 2" },
    ...tl.filter(x => x.c !== "arbitrum").map(x => ({ a: x.a, l: x.l || x.r }))
  ];
  const blDone = new Set<string>();
  let frozenN = 0;

  for (const { a, l } of blList) {
    if (blDone.has(a.toLowerCase())) continue;
    blDone.add(a.toLowerCase());
    const uf = await bl(a, UC, "fe575a87");
    const tf = await bl(a, UT, "e47d6060");
    const us = uf === true ? "⛔ FROZEN" : "Not frozen";
    const ts = tf === true ? "⛔ FROZEN" : "Not frozen";
    if (uf || tf) frozenN++;
    const tag = (uf || tf) ? " ★★★ FROZEN ★★★" : "";
    w(`  ${a} | USDC: ${us} | USDT: ${ts}${tag}`);
    w(`    ${l}`);
  }
  w(`\n  FROZEN: ${frozenN} of ${blDone.size}`);
  if (frozenN === 0) {
    w("  ⚠ NO addresses frozen. Circle/Tether have NOT acted.");
    w("  RECOMMENDATION: Request USDC/USDT blacklist for suspect addresses.\n");
  }

  // === SECTION 3: FXUSD CHAIN ===
  w("\n" + "═".repeat(80));
  w("SECTION 3: FXUSD ANCHOR CHAIN");
  w("═".repeat(80) + "\n");
  w("FLOW: FXUSD SOURCE → 155,247.80 FXUSD → Relay Proxy → 155,092.55 FXUSD → Crypto.com Wallet");
  w("      Crypto.com → 155,092.55 FXUSD → 155,017.66 USDC via CoW Swap (72 seconds)");
  w("      KYC: Crypto.com Hot Wallet 2 → 0.0226 ETH → Suspect\n");
  w("CRITICAL TXS:");
  w("  Relay:     0x6b0782939444bee11b3722eba8d3a749c32fe82b42e02db7dab852f818c6a484");
  w("  CoW Swap:  0x5875ca456fef552da782c3ce2d76ac65d66dbfe6a987f4f1ecfbd8436d321c57");
  w("  KYC:       0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99");
  w("  Bridge:    0x1e11fe6e576b0bed12c5312f524ca8e41f34d0b4dda66fcf42e484c636dc7a5e\n");

  // === SECTION 4: TRACES ===
  w("═".repeat(80));
  w("SECTION 4: ON-CHAIN TRACES — ALL WALLETS");
  w("═".repeat(80) + "\n");

  let wn = 0;
  for (const x of tl) {
    wn++;
    const lo = x.a.toLowerCase();
    const isArb = x.c === "arbitrum";
    const base = isArb ? BA : BE;

    console.log(`  [${wn}/${tl.length}] ${x.a.substring(0, 14)}... (${x.l || x.r})`);
    w("─".repeat(80));
    w(`#${wn}: ${x.a} | ${x.l || "N/A"} | ${x.r || "N/A"} | ${x.c}`);

    // Single page of token transfers only
    const data = await api(`${base}/addresses/${lo}/token-transfers`);
    await sleep(150);
    const items = data?.items || [];
    totalTx += items.length;

    if (items.length === 0) { w("  No transfers.\n"); continue; }
    items.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    w(`  Transfers: ${items.length}\n`);

    let n = 0;
    for (const tt of items) {
      n++;
      const from = (tt.from?.hash || "").toLowerCase();
      const to = (tt.to?.hash || "").toLowerCase();
      const sym = tt.token?.symbol || "???";
      const dec = parseInt(tt.token?.decimals || "18");
      const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
      const dir = from === lo ? "OUT" : "IN";
      const conn = fxAddrs.some(a => from === a || to === a);
      const tag = conn ? " ◄◄◄ FXUSD" : "";
      const fl = lbl(from, dm);
      const tll = lbl(to, dm);

      w(`  ${String(n).padStart(3, "0")} ${tt.timestamp} ${dir} ${amt.toFixed(6)} ${sym}${tag}`);
      w(`    ${tt.transaction_hash || tt.hash}`);
      w(`    F: ${from} ${fl ? `(${fl})` : ""}`);
      w(`    T: ${to} ${tll ? `(${tll})` : ""}`);
    }
    w("");
  }

  // === SECTION 5: SUMMARY ===
  w("\n" + "═".repeat(80));
  w("SECTION 5: THEFT BREAKDOWN & LAW ENFORCEMENT");
  w("═".repeat(80) + "\n");
  w("TOTAL: ~$24,000,000 USD\n");
  w("Ch 1 — DAI (~$20M): Victim → Hub → 12+ dispersal wallets");
  w("Ch 2 — Monero (~$2.47M): 19 Hyperliquid → Wagyu → Monero (UNRECOVERABLE)");
  w("Ch 3 — BTC (~$1.1M): ETH → LiFi Bridge → mixer");
  w("Ch 4 — Arb USDC (~$2.48M): 10 Arbitrum receivers");
  w("Ch 5 — FXUSD (~$155K): FXUSD SOURCE → Relay → Crypto.com → USDC\n");
  w("SUBPOENA: Crypto.com (Foris DAX MT Ltd.) Malta/Singapore");
  w("  compliance@crypto.com | TX: 0x358a4d8c...\n");
  w("KEY WALLETS:");
  w(`  POI ($4.35M):      0xf70da97812cb96acdf810712aa562db8dfa3dbef`);
  w(`  Source (EIP-7702): 0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb`);
  w(`  Gas Funder:        0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7`);
  w(`  Laundering Hub:    0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872`);
  w(`  Original Funder:   0x423d2b61952d56358db8b313ec7404a9582d4865`);
  w(`  FXUSD SOURCE:      ${FS}`);
  w(`  Crypto.com:        ${CC}\n`);
  w(`STATS: ${wn} wallets | ${totalTx} TXs | ${blDone.size} blacklist checks | ${frozenN} frozen`);
  w(`Generated: ${new Date().toISOString()}`);
  w(`LE Page: https://alphaunlimitedtrading.com/law-enforcement-tech\n`);
  w("Alpha Forensic Intelligence Engine™ — © 2024-2026 Alpha Unlimited Trading Company");

  fs.closeSync(fd);
  const lines = fs.readFileSync(OUT, "utf-8").split("\n").length;
  console.log(`\n✓ ${OUT} | ${lines} lines | ${wn} wallets | ${totalTx} TXs`);
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
