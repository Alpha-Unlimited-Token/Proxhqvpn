import { db } from "../db.js";
import { sql } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function main() {
  const w = await db.execute(sql`SELECT count(*)::int as c FROM monitored_wallets WHERE case_id = ${CASE_ID}`);
  const a = await db.execute(sql`SELECT count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID}`);
  const t = await db.execute(sql`SELECT count(*)::int as c FROM traced_transactions WHERE case_id = ${CASE_ID}`);
  console.log("Wallets:", (w as any).rows?.[0]?.c ?? (w as any)[0]?.c ?? JSON.stringify(w));
  console.log("Alerts:", (a as any).rows?.[0]?.c ?? (a as any)[0]?.c ?? JSON.stringify(a));
  console.log("Traced Txs:", (t as any).rows?.[0]?.c ?? (t as any)[0]?.c ?? JSON.stringify(t));

  const recent = await db.execute(sql`SELECT alert_type, severity, substring(message from 1 for 150) as msg FROM forensic_alerts WHERE case_id = ${CASE_ID} ORDER BY created_at DESC LIMIT 12`);
  const recentRows = (recent as any).rows || recent;
  console.log("\n=== 12 MOST RECENT ALERTS ===");
  for (const r of recentRows) console.log(`  [${r.severity}] ${r.alert_type}: ${r.msg}`);

  const newW = await db.execute(sql`SELECT label, chain FROM monitored_wallets WHERE case_id = ${CASE_ID} ORDER BY created_at DESC LIMIT 8`);
  const newWRows = (newW as any).rows || newW;
  console.log("\n=== 8 NEWEST WALLETS (auto-discovered) ===");
  for (const nw of newWRows) console.log(`  ${nw.label} (${nw.chain})`);

  const tornadoAlerts = await db.execute(sql`SELECT count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID} AND alert_type = 'tornado_cash_interaction'`);
  const moneroAlerts = await db.execute(sql`SELECT count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID} AND alert_type = 'monero_conversion'`);
  const unfreezeAlerts = await db.execute(sql`SELECT count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID} AND alert_type = 'unfreezable_token_movement'`);
  const tr = (tornadoAlerts as any).rows?.[0]?.c ?? (tornadoAlerts as any)[0]?.c ?? 0;
  const mr = (moneroAlerts as any).rows?.[0]?.c ?? (moneroAlerts as any)[0]?.c ?? 0;
  const ur = (unfreezeAlerts as any).rows?.[0]?.c ?? (unfreezeAlerts as any)[0]?.c ?? 0;
  console.log("\n=== LAUNDERING RISK ALERTS ===");
  console.log("Tornado Cash interactions:", tr);
  console.log("Monero conversions:", mr);
  console.log("Unfreezable token movements:", ur);

  process.exit(0);
}
main();
