import { getBlockchain } from "../blockchain/chain.js";
import { createWallet } from "../blockchain/wallet.js";
import { spiderBeaconService } from "../services/spiderBeacon.js";
import { getForensicHookEngine } from "../blockchain/forensicHooks.js";
import { getFounderWallet } from "../blockchain/founder.js";

const CASE_ID = "TEST-ATC-BEACON-001";

async function main() {
  console.log("═══════════════════════════════════════════════════════════════");
  console.log("  ALPHA TRACKING COIN™ — FULL SYSTEM TEST");
  console.log("  Testing: Beacons, Transfers, Forensic Hooks, Self-Destruct");
  console.log("═══════════════════════════════════════════════════════════════\n");

  const blockchain = getBlockchain();
  const hookEngine = getForensicHookEngine();
  hookEngine.setSpiderBeaconService(spiderBeaconService);

  console.log("[STEP 1] Creating test wallets...\n");

  const walletA = createWallet();
  const walletB = createWallet();
  const walletC = createWallet();

  console.log(`  Wallet A (Your wallet):     ${walletA.address}`);
  console.log(`  Wallet B (Intermediary):     ${walletB.address}`);
  console.log(`  Wallet C (Final receiver):   ${walletC.address}`);
  console.log(`  Founder wallet:              ${blockchain.founderAddress}`);
  console.log(`  Founder balance:             ${blockchain.getBalance(blockchain.founderAddress).toLocaleString()} AUC\n`);

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 2] Deploying Spider Beacons on all 3 wallets...\n");

  const beaconA = await spiderBeaconService.deployBeacon(
    CASE_ID, walletA.address, 'auc', 'auc_trap',
    { label: 'Wallet A — primary target', testMode: true }
  );
  console.log(`  ✓ Beacon deployed on Wallet A: ${beaconA.id} (type: ${beaconA.type})`);

  const beaconB = await spiderBeaconService.deployBeacon(
    CASE_ID, walletB.address, 'auc', 'address_monitor',
    { label: 'Wallet B — intermediary', testMode: true }
  );
  console.log(`  ✓ Beacon deployed on Wallet B: ${beaconB.id} (type: ${beaconB.type})`);

  const beaconC = await spiderBeaconService.deployBeacon(
    CASE_ID, walletC.address, 'auc', 'address_monitor',
    { label: 'Wallet C — final receiver', testMode: true }
  );
  console.log(`  ✓ Beacon deployed on Wallet C: ${beaconC.id} (type: ${beaconC.type})`);

  hookEngine.addWatchedAddress(walletA.address, CASE_ID, 'ATC Test — Wallet A', 'critical');
  hookEngine.addWatchedAddress(walletB.address, CASE_ID, 'ATC Test — Wallet B', 'warning');
  hookEngine.addWatchedAddress(walletC.address, CASE_ID, 'ATC Test — Wallet C', 'warning');
  console.log(`  ✓ All 3 wallets added to ForensicHookEngine watch list\n`);

  const aucTrap = await spiderBeaconService.deployAucTrap(
    CASE_ID, 'ETH', 'ethereum', '0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb',
    walletA.address, '50000'
  );
  console.log(`  ✓ AUC Trap deployed: ${aucTrap.id} (monitoring ${walletA.address.slice(0, 20)}...)\n`);

  let stats = spiderBeaconService.getStats();
  console.log(`  Beacons active: ${stats.activeBeacons} | Signals so far: ${stats.totalSignals}`);
  console.log(`  Token standards covered: ${stats.tokenStandardsCovered?.join(', ') || 'N/A'}\n`);

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 3] Funding Wallet A from Founder (simulating ATC airdrop)...\n");

  const founderWallet = getFounderWallet();
  const fundTx = blockchain.createTransaction(
    blockchain.founderAddress, walletA.address, 100000,
    founderWallet.privateKey, founderWallet.publicKey
  );

  if ('error' in fundTx) {
    console.error(`  ✗ Funding failed: ${fundTx.error}`);
    return;
  }

  console.log(`  ✓ Created funding TX: ${fundTx.id.slice(0, 24)}...`);
  console.log(`    From: Founder → Wallet A | Amount: 100,000 AUC`);

  const mineResult1 = blockchain.mineBlock(blockchain.founderAddress);
  if ('error' in mineResult1) {
    console.error(`  ✗ Mining failed: ${mineResult1.error}`);
    return;
  }
  console.log(`  ✓ Block mined: #${mineResult1.index} (${mineResult1.transactions.length} txs)`);
  console.log(`  ✓ Wallet A balance: ${blockchain.getBalance(walletA.address).toLocaleString()} AUC\n`);

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 4] Transfer: Wallet A → Wallet B (50,000 AUC)...\n");

  const txAB = blockchain.createTransaction(
    walletA.address, walletB.address, 50000,
    walletA.privateKey, walletA.publicKey
  );

  if ('error' in txAB) {
    console.error(`  ✗ Transfer A→B failed: ${txAB.error}`);
    return;
  }

  console.log(`  ✓ Created TX: ${txAB.id.slice(0, 24)}...`);
  console.log(`    From: Wallet A → Wallet B | Amount: 50,000 AUC`);

  const mineResult2 = blockchain.mineBlock(blockchain.founderAddress);
  if ('error' in mineResult2) {
    console.error(`  ✗ Mining failed: ${mineResult2.error}`);
    return;
  }
  console.log(`  ✓ Block mined: #${mineResult2.index}`);
  console.log(`  ✓ Wallet A balance: ${blockchain.getBalance(walletA.address).toLocaleString()} AUC`);
  console.log(`  ✓ Wallet B balance: ${blockchain.getBalance(walletB.address).toLocaleString()} AUC\n`);

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 5] Transfer: Wallet B → Wallet C (25,000 AUC)...\n");

  const txBC = blockchain.createTransaction(
    walletB.address, walletC.address, 25000,
    walletB.privateKey, walletB.publicKey
  );

  if ('error' in txBC) {
    console.error(`  ✗ Transfer B→C failed: ${txBC.error}`);
    return;
  }

  console.log(`  ✓ Created TX: ${txBC.id.slice(0, 24)}...`);
  console.log(`    From: Wallet B → Wallet C | Amount: 25,000 AUC`);

  const mineResult3 = blockchain.mineBlock(blockchain.founderAddress);
  if ('error' in mineResult3) {
    console.error(`  ✗ Mining failed: ${mineResult3.error}`);
    return;
  }
  console.log(`  ✓ Block mined: #${mineResult3.index}`);
  console.log(`  ✓ Wallet A balance: ${blockchain.getBalance(walletA.address).toLocaleString()} AUC`);
  console.log(`  ✓ Wallet B balance: ${blockchain.getBalance(walletB.address).toLocaleString()} AUC`);
  console.log(`  ✓ Wallet C balance: ${blockchain.getBalance(walletC.address).toLocaleString()} AUC\n`);

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 6] Transfer: Wallet C → Wallet A (10,000 AUC — circular test)...\n");

  const txCA = blockchain.createTransaction(
    walletC.address, walletA.address, 10000,
    walletC.privateKey, walletC.publicKey
  );

  if ('error' in txCA) {
    console.error(`  ✗ Transfer C→A failed: ${txCA.error}`);
    return;
  }

  console.log(`  ✓ Created TX: ${txCA.id.slice(0, 24)}...`);
  console.log(`    From: Wallet C → Wallet A | Amount: 10,000 AUC`);

  const mineResult4 = blockchain.mineBlock(blockchain.founderAddress);
  if ('error' in mineResult4) {
    console.error(`  ✗ Mining failed: ${mineResult4.error}`);
    return;
  }
  console.log(`  ✓ Block mined: #${mineResult4.index}`);
  console.log(`  ✓ Wallet A balance: ${blockchain.getBalance(walletA.address).toLocaleString()} AUC`);
  console.log(`  ✓ Wallet B balance: ${blockchain.getBalance(walletB.address).toLocaleString()} AUC`);
  console.log(`  ✓ Wallet C balance: ${blockchain.getBalance(walletC.address).toLocaleString()} AUC\n`);

  console.log("══════════════════════════════════════════════════════════════");
  console.log("[STEP 7] VERIFICATION — Checking all beacon signals...\n");

  const allSignals = spiderBeaconService.getSignals(CASE_ID, 500);
  console.log(`  Total signals fired for test case: ${allSignals.length}\n`);

  const signalTypes: Record<string, number> = {};
  for (const sig of allSignals) {
    signalTypes[sig.signalType] = (signalTypes[sig.signalType] || 0) + 1;
  }

  console.log("  Signal breakdown:");
  for (const [type, count] of Object.entries(signalTypes)) {
    const icon = type.includes('trap') ? '🎯' : type.includes('critical') ? '🚨' : type.includes('exchange') ? '🏦' : '📡';
    console.log(`    ${icon} ${type}: ${count}`);
  }
  console.log();

  const hookSignals = hookEngine.getSignalLog(CASE_ID, 500);
  console.log(`  ForensicHookEngine signals for case: ${hookSignals.length}`);

  const hookTypes: Record<string, number> = {};
  for (const sig of hookSignals) {
    hookTypes[sig.type] = (hookTypes[sig.type] || 0) + 1;
  }
  console.log("  Hook signal breakdown:");
  for (const [type, count] of Object.entries(hookTypes)) {
    console.log(`    🔗 ${type}: ${count}`);
  }
  console.log();

  const watchedAddrs = hookEngine.getWatchedAddresses();
  console.log(`  Watched addresses (including auto-detected): ${watchedAddrs.length}`);
  for (const w of watchedAddrs) {
    if (w.caseId === CASE_ID) {
      console.log(`    • ${w.address.slice(0, 20)}... | Alert: ${w.alertLevel} | Transfers: ${w.totalTransfers} | Volume: ${w.totalVolume.toLocaleString()} AUC | ${w.reason.slice(0, 60)}`);
    }
  }
  console.log();

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 8] Testing Behavioral Profile...\n");

  const profileA = spiderBeaconService.getBehavioralProfile(walletA.address);
  if (profileA) {
    console.log(`  Wallet A Behavioral Profile:`);
    console.log(`    Total TX count: ${profileA.totalTxCount}`);
    console.log(`    Peer wallets discovered: ${profileA.peerWallets.size}`);
    console.log(`    Active hours (UTC): [${profileA.activeHoursUTC.slice(-5).join(', ')}]`);
    console.log(`    Inferred timezone: ${profileA.inferredTimezone || 'Not enough data'}`);
    console.log(`    First seen: ${profileA.firstSeen.toISOString()}`);
    console.log(`    Last seen: ${profileA.lastSeen.toISOString()}`);
  } else {
    console.log(`  ⚠ No behavioral profile for Wallet A`);
  }
  console.log();

  console.log("──────────────────────────────────────────────────────────────");
  console.log("[STEP 9] Testing Self-Destruct with Evidence Archival...\n");

  console.log(`  Destroying Beacon C (${beaconC.id})...`);
  const archiveC = await spiderBeaconService.selfDestructBeacon(beaconC.id, 'test_single_destruct');

  if (archiveC) {
    console.log(`  ✓ Self-destruct successful!`);
    console.log(`    Archive ID:       ${archiveC.archiveId}`);
    console.log(`    Evidence Hash:    ${archiveC.evidenceHash.slice(0, 32)}...`);
    console.log(`    Signals archived: ${archiveC.totalSignals}`);
    console.log(`    Deployed at:      ${archiveC.deployedAt.toISOString()}`);
    console.log(`    Destructed at:    ${archiveC.destructedAt.toISOString()}`);
  } else {
    console.log(`  ✗ Self-destruct failed`);
  }
  console.log();

  console.log("  Now destroying ALL remaining beacons for the test case...");
  const allArchives = await spiderBeaconService.selfDestructAllForCase(CASE_ID, 'test_case_closure');
  console.log(`  ✓ ${allArchives.length} beacon(s) destroyed`);

  for (const arch of allArchives) {
    console.log(`    • ${arch.archiveId} | ${arch.targetAddress.slice(0, 20)}... | ${arch.totalSignals} signals | Hash: ${arch.evidenceHash.slice(0, 16)}...`);
  }
  console.log();

  const allEvidenceArchives = spiderBeaconService.getAllEvidenceArchives(CASE_ID);
  console.log(`  Total evidence archives stored: ${allEvidenceArchives.length}`);

  const retrievedArchive = allEvidenceArchives[0];
  if (retrievedArchive) {
    console.log(`  Verified retrieval: ${retrievedArchive.archiveId} ✓`);
    console.log(`  Evidence hash verifiable: ${retrievedArchive.evidenceHash.slice(0, 32)}... ✓`);
  }
  console.log();

  console.log("══════════════════════════════════════════════════════════════");
  console.log("[STEP 10] FINAL SYSTEM STATUS\n");

  stats = spiderBeaconService.getStats();
  console.log(`  Beacons total:           ${stats.totalBeacons}`);
  console.log(`  Beacons active:          ${stats.activeBeacons}`);
  console.log(`  Beacons dormant:         ${stats.dormantBeacons}`);
  console.log(`  Beacons self-destructed: ${stats.selfDestructedBeacons || 0}`);
  console.log(`  Total signals:           ${stats.totalSignals}`);
  console.log(`  AUC traps active:        ${stats.aucTrapsActive}`);
  console.log(`  Behavioral profiles:     ${stats.behavioralProfiles}`);
  console.log(`  Evidence archives:       ${stats.evidenceArchives}`);
  console.log(`  Dedup cache size:        ${stats.deduplicationCacheSize}`);
  console.log(`  Bridge contracts:        ${stats.bridgeContractsTracked}`);
  console.log(`  Exchange addresses:      ${stats.exchangeAddressesTracked}`);
  console.log(`  Token standards:         ${stats.tokenStandardsCovered?.join(', ') || 'N/A'}`);
  console.log();

  const hookStats = hookEngine.getStats();
  console.log(`  ForensicHookEngine stats:`);
  console.log(`    Watched addresses:     ${hookStats.totalWatchedAddresses}`);
  console.log(`    Critical addresses:    ${hookStats.criticalAddresses}`);
  console.log(`    Total transfers:       ${hookStats.totalTransfersLogged}`);
  console.log(`    Total signals fired:   ${hookStats.totalSignalsFired}`);
  console.log(`    Trap triggers:         ${hookStats.trapTriggeredCount}`);
  console.log(`    Cases linked:          ${hookStats.casesLinked}`);
  console.log();

  console.log("══════════════════════════════════════════════════════════════");
  console.log("  TEST SUMMARY");
  console.log("══════════════════════════════════════════════════════════════");

  const tests = [
    { name: "Wallet creation", pass: !!(walletA.address && walletB.address && walletC.address) },
    { name: "Beacon deployment (3 beacons)", pass: !!(beaconA.id && beaconB.id && beaconC.id) },
    { name: "AUC Trap deployment", pass: !!(aucTrap.id) },
    { name: "ForensicHook watch list", pass: watchedAddrs.filter(w => w.caseId === CASE_ID).length >= 3 },
    { name: "Founder → Wallet A (funding)", pass: blockchain.getBalance(walletA.address) > 0 },
    { name: "Wallet A → Wallet B (transfer)", pass: blockchain.getBalance(walletB.address) > 0 },
    { name: "Wallet B → Wallet C (transfer)", pass: blockchain.getBalance(walletC.address) > 0 },
    { name: "Wallet C → Wallet A (circular)", pass: blockchain.getBalance(walletA.address) > 50000 },
    { name: "Spider Beacon signals fired", pass: allSignals.length > 0 },
    { name: "ForensicHook signals fired", pass: hookSignals.length > 0 },
    { name: "AUC trap triggered", pass: allSignals.some(s => s.signalType === 'auc_trap_triggered') },
    { name: "All pre-registered addresses tracked", pass: watchedAddrs.filter(w => w.caseId === CASE_ID).length >= 3 },
    { name: "Watched transfer detection", pass: hookSignals.some(s => s.type === 'watched_transfer') },
    { name: "Behavioral profile created", pass: !!profileA },
    { name: "Self-destruct (single)", pass: !!archiveC },
    { name: "Self-destruct (case-wide)", pass: allArchives.length > 0 },
    { name: "Evidence hash generated", pass: !!archiveC?.evidenceHash },
    { name: "Evidence archive retrievable", pass: allEvidenceArchives.length > 0 },
  ];

  let passed = 0;
  let failed = 0;
  for (const test of tests) {
    const icon = test.pass ? '✅' : '❌';
    console.log(`  ${icon} ${test.name}`);
    if (test.pass) passed++;
    else failed++;
  }

  console.log();
  console.log(`  RESULT: ${passed}/${tests.length} PASSED | ${failed} FAILED`);
  console.log();

  if (failed === 0) {
    console.log("  🎉 ALL TESTS PASSED — Alpha Tracking Coin™ system fully operational!");
  } else {
    console.log("  ⚠ Some tests failed. Review output above for details.");
  }

  console.log("\n══════════════════════════════════════════════════════════════\n");
}


main().catch((err) => {
  console.error("[ATC Test] Fatal error:", err);
  process.exit(1);
});
