/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_DEEP_SCAN_v2.0
 * ALPHA_INTEGRITY_SEAL: AUT_DeepScan_Calibration_PROTECTED
 */

import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { forensicWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const ETH_API = "https://eth.blockscout.com/api/v2";
const ARB_API = "https://arbitrum.blockscout.com/api/v2";
const DELAY = 350;

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

interface TxRecord {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: string;
  block: number;
  method?: string;
  type: string; // "eth_tx" | "token_transfer"
  token?: string;
  tokenSymbol?: string;
  tokenDecimals?: number;
  chain: string;
  wallet: string;
}

async function fetchJSON(url: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/2.0" } });
      if (r.status === 429) { await sleep(2000); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(1000); }
  }
  return null;
}

async function getAllTxs(api: string, addr: string, chain: string): Promise<TxRecord[]> {
  const records: TxRecord[] = [];
  const laddr = addr.toLowerCase();
  
  // Get normal transactions (paginate)
  let nextParams = "";
  let pages = 0;
  while (pages < 20) {
    const url = `${api}/addresses/${laddr}/transactions${nextParams ? "?" + nextParams : ""}`;
    const data = await fetchJSON(url);
    await sleep(DELAY);
    if (!data?.items?.length) break;
    
    for (const tx of data.items) {
      records.push({
        hash: tx.hash,
        from: (tx.from?.hash || "").toLowerCase(),
        to: (tx.to?.hash || "").toLowerCase(),
        value: tx.value || "0",
        timestamp: tx.timestamp || "",
        block: tx.block || 0,
        method: tx.method || "",
        type: "eth_tx",
        chain,
        wallet: laddr
      });
    }
    
    if (!data.next_page_params) break;
    nextParams = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  
  // Get token transfers (paginate)
  nextParams = "";
  pages = 0;
  while (pages < 20) {
    const url = `${api}/addresses/${laddr}/token-transfers${nextParams ? "?" + nextParams : ""}`;
    const data = await fetchJSON(url);
    await sleep(DELAY);
    if (!data?.items?.length) break;
    
    for (const tt of data.items) {
      records.push({
        hash: tt.transaction_hash || tt.tx_hash || "",
        from: (tt.from?.hash || "").toLowerCase(),
        to: (tt.to?.hash || "").toLowerCase(),
        value: tt.total?.value || "0",
        timestamp: tt.timestamp || "",
        block: tt.block_number || 0,
        type: "token_transfer",
        token: tt.token?.address || "",
        tokenSymbol: tt.token?.symbol || "???",
        tokenDecimals: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
        chain,
        wallet: laddr
      });
    }
    
    if (!data.next_page_params) break;
    nextParams = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  
  return records;
}

function formatValue(val: string, decimals: number = 18): string {
  if (!val || val === "0") return "0";
  const str = val.padStart(decimals + 1, "0");
  const whole = str.slice(0, str.length - decimals) || "0";
  const frac = str.slice(str.length - decimals, str.length - decimals + 4);
  const n = parseFloat(whole + "." + frac);
  if (n >= 1000000) return (n / 1000000).toFixed(2) + "M";
  if (n >= 1000) return (n / 1000).toFixed(2) + "K";
  return n.toFixed(4);
}

async function main() {
  console.log("[DeepScan] Loading all case wallets...");
  
  const wallets = await db.select().from(forensicWallets).where(eq(forensicWallets.caseId, CASE_ID));
  console.log(`[DeepScan] ${wallets.length} wallets in database\n`);
  
  // Also add known wallets that might not be in DB
  const knownAddrs = new Set(wallets.map(w => w.address.toLowerCase()));
  const extraWallets = [
    "0x6fe0fab2164d8e0d03ad6a628e2af78624060322", // victim
    "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41", // victim secondary  
    "0xf70da97812cb96acdf810712aa562db8dfa3dbef", // POI
    "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb", // Source EIP-7702
    "0xb01fed2f701695992a4f7ffdb53f3af099e140d7", // Gas funder
    "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872", // Laundering hub
    "0x423d2b61952d56358db8b313ec7404a9582d4865", // Original funder
    "0xd14f4b36e1d1d98c218db782c49149876042bc56", // FXUSD Source
    "0x6818809eefce719e480a7526d76bd3e561526b46", // Relay proxy
    "0x658370618bbc885865df66c1061bfe4771fad846", // Crypto.com suspect
  ];
  for (const a of extraWallets) {
    knownAddrs.add(a.toLowerCase());
  }
  
  const allAddresses = [...knownAddrs];
  console.log(`[DeepScan] Total unique addresses to scan: ${allAddresses.length}`);
  
  const allRecords: TxRecord[] = [];
  const newWallets = new Set<string>();
  const walletSummaries: { addr: string; chain: string; txCount: number; tokenCount: number; latestTx: string }[] = [];
  
  // Determine which wallets to scan on which chain
  // Check DB for chain info
  const arbWallets = new Set<string>();
  for (const w of wallets) {
    const d = w.details as any;
    if (d?.chain === "arbitrum" || w.label?.toLowerCase().includes("arb")) {
      arbWallets.add(w.address.toLowerCase());
    }
  }
  
  // Scan Ethereum for all wallets
  console.log("\n═══ SCANNING ETHEREUM ═══");
  let scanned = 0;
  for (const addr of allAddresses) {
    if (arbWallets.has(addr)) continue; // skip arb-only wallets on eth
    scanned++;
    process.stdout.write(`\r  Scanning ${scanned}/${allAddresses.length - arbWallets.size}: ${addr.slice(0, 10)}...`);
    
    const records = await getAllTxs(ETH_API, addr, "ethereum");
    allRecords.push(...records);
    
    if (records.length > 0) {
      const latest = records.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
      walletSummaries.push({
        addr,
        chain: "ethereum",
        txCount: records.filter(r => r.type === "eth_tx").length,
        tokenCount: records.filter(r => r.type === "token_transfer").length,
        latestTx: latest.timestamp
      });
    }
    
    // Discover new wallets
    for (const r of records) {
      if (r.from && !knownAddrs.has(r.from)) newWallets.add(r.from);
      if (r.to && !knownAddrs.has(r.to)) newWallets.add(r.to);
    }
  }
  
  // Scan Arbitrum for all wallets (many cross-chain)
  console.log("\n\n═══ SCANNING ARBITRUM ═══");
  scanned = 0;
  for (const addr of allAddresses) {
    scanned++;
    process.stdout.write(`\r  Scanning ${scanned}/${allAddresses.length}: ${addr.slice(0, 10)}...`);
    
    const records = await getAllTxs(ARB_API, addr, "arbitrum");
    allRecords.push(...records);
    
    if (records.length > 0) {
      const latest = records.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
      walletSummaries.push({
        addr,
        chain: "arbitrum",
        txCount: records.filter(r => r.type === "eth_tx").length,
        tokenCount: records.filter(r => r.type === "token_transfer").length,
        latestTx: latest.timestamp
      });
    }
    
    for (const r of records) {
      if (r.from && !knownAddrs.has(r.from)) newWallets.add(r.from);
      if (r.to && !knownAddrs.has(r.to)) newWallets.add(r.to);
    }
  }
  
  console.log("\n\n[DeepScan] Scan complete. Building report...");
  
  // Deduplicate by tx hash
  const uniqueTxs = new Map<string, TxRecord>();
  for (const r of allRecords) {
    const key = `${r.hash}-${r.from}-${r.to}-${r.tokenSymbol || "ETH"}-${r.chain}`;
    if (!uniqueTxs.has(key)) uniqueTxs.set(key, r);
  }
  
  const allUnique = [...uniqueTxs.values()].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  
  // Find activity since our last scan (March 8, 2026 ~02:00 UTC)
  const lastScan = new Date("2026-03-08T02:00:00Z");
  const newActivity = allUnique.filter(r => new Date(r.timestamp) > lastScan);
  
  // Token summary
  const tokenFlows = new Map<string, { symbol: string; totalValue: number; txCount: number; from: Set<string>; to: Set<string> }>();
  for (const r of allUnique) {
    if (r.type === "token_transfer" && r.tokenSymbol) {
      const key = r.tokenSymbol;
      if (!tokenFlows.has(key)) tokenFlows.set(key, { symbol: key, totalValue: 0, txCount: 0, from: new Set(), to: new Set() });
      const flow = tokenFlows.get(key)!;
      flow.txCount++;
      const dec = r.tokenDecimals || 18;
      const val = parseFloat(r.value) / Math.pow(10, dec);
      if (!isNaN(val)) flow.totalValue += val;
      flow.from.add(r.from);
      flow.to.add(r.to);
    }
  }
  
  // Build the report
  let report = "";
  report += "═".repeat(80) + "\n";
  report += "  ALPHA FORENSIC INTELLIGENCE ENGINE — COMPLETE DEEP SCAN REPORT\n";
  report += "  Case: @sillytuna (Alex Amsel) ~$24M Theft\n";
  report += `  Generated: ${new Date().toISOString()}\n`;
  report += `  Case ID: ${CASE_ID}\n`;
  report += "═".repeat(80) + "\n\n";
  
  report += `SCAN SUMMARY\n`;
  report += `${"─".repeat(60)}\n`;
  report += `  Wallets Scanned: ${allAddresses.length}\n`;
  report += `  Chains: Ethereum, Arbitrum\n`;
  report += `  Total Unique Transactions: ${allUnique.length}\n`;
  report += `  Token Transfer Events: ${allUnique.filter(r => r.type === "token_transfer").length}\n`;
  report += `  ETH/Native Transactions: ${allUnique.filter(r => r.type === "eth_tx").length}\n`;
  report += `  Unique Tokens Moved: ${tokenFlows.size}\n`;
  report += `  New Wallets Discovered: ${newWallets.size}\n`;
  report += `  New Activity Since Last Scan: ${newActivity.length} transactions\n\n`;
  
  // Section: New Activity
  report += "═".repeat(80) + "\n";
  report += "  NEW ACTIVITY SINCE LAST SCAN (after 2026-03-08 02:00 UTC)\n";
  report += "═".repeat(80) + "\n\n";
  
  if (newActivity.length === 0) {
    report += "  No new transactions detected.\n\n";
  } else {
    for (const tx of newActivity) {
      const valStr = tx.type === "token_transfer" 
        ? formatValue(tx.value, tx.tokenDecimals || 18) + " " + (tx.tokenSymbol || "???")
        : formatValue(tx.value) + " ETH";
      report += `  [${tx.chain.toUpperCase()}] ${tx.timestamp}\n`;
      report += `    TX: ${tx.hash}\n`;
      report += `    FROM: ${tx.from}\n`;
      report += `    TO:   ${tx.to}\n`;
      report += `    VALUE: ${valStr}\n`;
      if (tx.method) report += `    METHOD: ${tx.method}\n`;
      report += "\n";
    }
  }
  
  // Section: Token Flow Summary
  report += "═".repeat(80) + "\n";
  report += "  TOKEN FLOW SUMMARY — ALL TOKENS TRACED\n";
  report += "═".repeat(80) + "\n\n";
  
  const sortedTokens = [...tokenFlows.entries()].sort((a, b) => b[1].totalValue - a[1].totalValue);
  for (const [sym, flow] of sortedTokens) {
    const valStr = flow.totalValue >= 1000000 ? (flow.totalValue / 1000000).toFixed(2) + "M" :
                   flow.totalValue >= 1000 ? (flow.totalValue / 1000).toFixed(2) + "K" :
                   flow.totalValue.toFixed(4);
    report += `  ${sym}: ${valStr} across ${flow.txCount} transfers\n`;
    report += `    Senders: ${flow.from.size} unique | Recipients: ${flow.to.size} unique\n\n`;
  }
  
  // Section: Per-Wallet Activity
  report += "═".repeat(80) + "\n";
  report += "  PER-WALLET ACTIVITY BREAKDOWN\n";
  report += "═".repeat(80) + "\n\n";
  
  const walletMap = new Map<string, TxRecord[]>();
  for (const r of allUnique) {
    const key = r.wallet;
    if (!walletMap.has(key)) walletMap.set(key, []);
    walletMap.get(key)!.push(r);
  }
  
  // Find DB labels
  const labelMap = new Map<string, string>();
  for (const w of wallets) {
    labelMap.set(w.address.toLowerCase(), w.label || "");
  }
  labelMap.set("0x6fe0fab2164d8e0d03ad6a628e2af78624060322", "VICTIM PRIMARY");
  labelMap.set("0xf70da97812cb96acdf810712aa562db8dfa3dbef", "POI ($4.35M)");
  labelMap.set("0xb98e8eefba0f7476b85cd9716cb5b38a935aa872", "LAUNDERING HUB ($20M)");
  labelMap.set("0xd14f4b36e1d1d98c218db782c49149876042bc56", "FXUSD SOURCE");
  labelMap.set("0x658370618bbc885865df66c1061bfe4771fad846", "CRYPTO.COM SUSPECT");
  labelMap.set("0x423d2b61952d56358db8b313ec7404a9582d4865", "ORIGINAL FUNDER");
  
  for (const [addr, txs] of [...walletMap.entries()].sort((a, b) => b[1].length - a[1].length)) {
    const label = labelMap.get(addr) || "";
    const ethTxs = txs.filter(t => t.type === "eth_tx");
    const tokenTxs = txs.filter(t => t.type === "token_transfer");
    const latest = txs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
    const chains = [...new Set(txs.map(t => t.chain))];
    
    report += `  ${addr}${label ? " [" + label + "]" : ""}\n`;
    report += `    Chains: ${chains.join(", ")} | ETH TXs: ${ethTxs.length} | Token Transfers: ${tokenTxs.length}\n`;
    report += `    Latest Activity: ${latest.timestamp}\n`;
    
    // Token breakdown for this wallet
    const wTokens = new Map<string, number>();
    for (const t of tokenTxs) {
      const sym = t.tokenSymbol || "???";
      wTokens.set(sym, (wTokens.get(sym) || 0) + 1);
    }
    if (wTokens.size > 0) {
      report += `    Tokens: ${[...wTokens.entries()].map(([s, c]) => `${s}(${c})`).join(", ")}\n`;
    }
    
    // Show destinations
    const destinations = new Set<string>();
    const sources = new Set<string>();
    for (const t of txs) {
      if (t.from === addr) destinations.add(t.to);
      if (t.to === addr) sources.add(t.from);
    }
    if (destinations.size > 0 && destinations.size <= 30) {
      report += `    Sent to (${destinations.size}): ${[...destinations].join(", ")}\n`;
    } else if (destinations.size > 30) {
      report += `    Sent to: ${destinations.size} unique addresses\n`;
    }
    if (sources.size > 0 && sources.size <= 30) {
      report += `    Received from (${sources.size}): ${[...sources].join(", ")}\n`;
    } else if (sources.size > 30) {
      report += `    Received from: ${sources.size} unique addresses\n`;
    }
    report += "\n";
  }
  
  // Section: Complete Transaction Log
  report += "═".repeat(80) + "\n";
  report += "  COMPLETE TRANSACTION LOG — ALL CHAINS\n";
  report += `  (${allUnique.length} transactions, chronological)\n`;
  report += "═".repeat(80) + "\n\n";
  
  for (const tx of allUnique) {
    const valStr = tx.type === "token_transfer"
      ? formatValue(tx.value, tx.tokenDecimals || 18) + " " + (tx.tokenSymbol || "???")
      : formatValue(tx.value) + " ETH";
    report += `[${tx.chain.toUpperCase().padEnd(8)}] ${tx.timestamp} | ${tx.hash}\n`;
    report += `  ${tx.from} → ${tx.to} | ${valStr}${tx.method ? " | " + tx.method : ""}\n`;
  }
  
  // Section: Newly discovered wallets
  report += "\n" + "═".repeat(80) + "\n";
  report += "  NEWLY DISCOVERED WALLETS (not in original case DB)\n";
  report += `  (${newWallets.size} addresses)\n`;
  report += "═".repeat(80) + "\n\n";
  
  // Filter out known contracts, routers, etc - just list them all
  const newArr = [...newWallets].sort();
  for (const w of newArr) {
    report += `  ${w}\n`;
  }
  
  report += "\n" + "═".repeat(80) + "\n";
  report += "  END OF DEEP SCAN REPORT\n";
  report += `  Alpha Unlimited Trading Company — Forensic Intelligence Division\n`;
  report += `  © 2024-2026 All Rights Reserved.\n`;
  report += "═".repeat(80) + "\n";
  
  const outFile = "forensic_deep_scan_complete.txt";
  fs.writeFileSync(outFile, report);
  const sizeKb = (fs.statSync(outFile).size / 1024).toFixed(1);
  console.log(`\n[DeepScan] Report saved: ${outFile} (${sizeKb} KB)`);
  console.log(`[DeepScan] Total unique TXs: ${allUnique.length}`);
  console.log(`[DeepScan] New activity since last scan: ${newActivity.length}`);
  console.log(`[DeepScan] Tokens traced: ${tokenFlows.size}`);
  console.log(`[DeepScan] New wallets discovered: ${newWallets.size}`);
  
  // Write summary to stdout for next step
  const summary = {
    totalTxs: allUnique.length,
    newActivity: newActivity.length,
    tokensTraced: tokenFlows.size,
    newWallets: newWallets.size,
    walletsScanned: allAddresses.length,
    reportFile: outFile,
    reportSizeKb: sizeKb
  };
  fs.writeFileSync("/tmp/deepScanSummary.json", JSON.stringify(summary));
  
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
