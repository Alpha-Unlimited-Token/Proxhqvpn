/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_CHECK_ROLES_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_CheckRoles_Calibration_PROTECTED
 */
import { db } from "../db.js";
import { monitoredWallets } from "../../shared/models/forensic.js";
import { eq, sql } from "drizzle-orm";

async function main() {
  const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
  const result = await db.execute(sql`
    SELECT role, count(*) as cnt 
    FROM monitored_wallets 
    WHERE case_id = ${CASE_ID} 
    GROUP BY role 
    ORDER BY cnt DESC
  `);
  console.log("WALLET ROLES:");
  for (const r of result.rows) {
    console.log(`  ${r.role || "(null)"}: ${r.cnt}`);
  }
  
  // Also check chain distribution
  const chains = await db.execute(sql`
    SELECT chain, count(*) as cnt 
    FROM monitored_wallets 
    WHERE case_id = ${CASE_ID} 
    GROUP BY chain 
    ORDER BY cnt DESC
  `);
  console.log("\nCHAINS:");
  for (const r of chains.rows) {
    console.log(`  ${r.chain}: ${r.cnt}`);
  }
  
  // Status distribution
  const statuses = await db.execute(sql`
    SELECT status, count(*) as cnt 
    FROM monitored_wallets 
    WHERE case_id = ${CASE_ID} 
    GROUP BY status 
    ORDER BY cnt DESC
  `);
  console.log("\nSTATUS:");
  for (const r of statuses.rows) {
    console.log(`  ${r.status}: ${r.cnt}`);
  }
  
  // Sample some addresses to understand them
  const samples = await db.execute(sql`
    SELECT address, role, label, chain 
    FROM monitored_wallets 
    WHERE case_id = ${CASE_ID} 
    ORDER BY created_at DESC 
    LIMIT 20
  `);
  console.log("\nRECENT 20 WALLETS:");
  for (const r of samples.rows) {
    console.log(`  ${r.address} | ${r.role} | ${r.label} | ${r.chain}`);
  }
  
  process.exit(0);
}
main();
