/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SCAN_ALL_v4.0
 * ALPHA_INTEGRITY_SEAL: AUT_ScanAll_Calibration_PROTECTED
 *
 * Fixed scanner: directly fetches TXs, no existence check needed
 * Saves progress, resumes between runs
 */
import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { monitoredWallets } from "../../shared/models/forensic.js";
import { eq } from "drizzle-orm";

const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const PROG = "/tmp/scanall_progress.json";
const DATA = "/tmp/scanall_data.jsonl";
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const CHAINS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
};

async function fetchJ(url: string): Promise<any> {
  for (let i = 0; i < 2; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AF/4" }, timeout: 10000 } as any);
      if (r.status === 429) { await sleep(2000); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(500); }
  }
  return null;
}

async function getFirstPageTokens(api: string, addr: string, chain: string): Promise<any[]> {
  const d = await fetchJ(`${api}/addresses/${addr}/token-transfers`);
  if (!d?.items?.length) return [];
  return d.items.map((tt: any) => ({
    h: tt.transaction_hash || tt.tx_hash || "",
    f: (tt.from?.hash || "").toLowerCase(),
    t: (tt.to?.hash || "").toLowerCase(),
    v: tt.total?.value || "0",
    ts: tt.timestamp || "",
    sym: tt.token?.symbol || "?",
    dec: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
    ta: (tt.token?.address || "").toLowerCase(),
    c: chain, tp: "tok"
  }));
}

async function getFirstPageTxs(api: string, addr: string, chain: string): Promise<any[]> {
  const d = await fetchJ(`${api}/addresses/${addr}/transactions`);
  if (!d?.items?.length) return [];
  return d.items.map((tx: any) => ({
    h: tx.hash,
    f: (tx.from?.hash || "").toLowerCase(),
    t: (tx.to?.hash || "").toLowerCase(),
    v: tx.value || "0",
    ts: tx.timestamp || "",
    m: tx.method || "",
    c: chain, tp: "nat"
  }));
}

// For deep scan — get ALL pages
async function getAllTokens(api: string, addr: string, chain: string): Promise<any[]> {
  const all: any[] = [];
  let next = "";
  let pg = 0;
  while (pg < 100) {
    const url = `${api}/addresses/${addr}/token-transfers${next ? "?" + next : ""}`;
    const d = await fetchJ(url);
    await sleep(300);
    if (!d?.items?.length) break;
    for (const tt of d.items) {
      all.push({
        h: tt.transaction_hash || tt.tx_hash || "",
        f: (tt.from?.hash || "").toLowerCase(),
        t: (tt.to?.hash || "").toLowerCase(),
        v: tt.total?.value || "0",
        ts: tt.timestamp || "",
        sym: tt.token?.symbol || "?",
        dec: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
        ta: (tt.token?.address || "").toLowerCase(),
        c: chain, tp: "tok"
      });
    }
    if (!d.next_page_params) break;
    next = new URLSearchParams(d.next_page_params as any).toString();
    pg++;
  }
  return all;
}

async function getAllTxs(api: string, addr: string, chain: string): Promise<any[]> {
  const all: any[] = [];
  let next = "";
  let pg = 0;
  while (pg < 100) {
    const url = `${api}/addresses/${addr}/transactions${next ? "?" + next : ""}`;
    const d = await fetchJ(url);
    await sleep(300);
    if (!d?.items?.length) break;
    for (const tx of d.items) {
      all.push({
        h: tx.hash,
        f: (tx.from?.hash || "").toLowerCase(),
        t: (tx.to?.hash || "").toLowerCase(),
        v: tx.value || "0",
        ts: tx.timestamp || "",
        m: tx.method || "",
        c: chain, tp: "nat"
      });
    }
    if (!d.next_page_params) break;
    next = new URLSearchParams(d.next_page_params as any).toString();
    pg++;
  }
  return all;
}

async function main() {
  const mode = process.argv[2] || "scan";
  
  if (mode === "scan") {
    console.log("═══ SCANNING ALL CASE WALLETS ═══\n");
    
    // Get core wallets (not token_recipient)
    const allW = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
    const core = allW.filter(w => w.role !== "token_recipient");
    const recipients = allW.filter(w => w.role === "token_recipient");
    
    // Build unique list of core addresses
    const coreAddrs = [...new Set(core.map(w => w.address.toLowerCase()))];
    
    // Add key addresses
    const keyAddrs = [
      "0xd14f4b36e1d1d98c218db782c49149876042bc56", "0x6818809eefce719e480a7526d76bd3e561526b46",
      "0x658370618bbc885865df66c1061bfe4771fad846", "0xf70da97812cb96acdf810712aa562db8dfa3dbef",
      "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb", "0xb01fed2f701695992a4f7ffdb53f3af099e140d7",
      "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872", "0x423d2b61952d56358db8b313ec7404a9582d4865",
      "0x6fe0fab2164d8e0d03ad6a628e2af78624060322", "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41",
    ];
    for (const a of keyAddrs) { if (!coreAddrs.includes(a)) coreAddrs.push(a); }
    
    console.log(`Core wallets: ${coreAddrs.length}`);
    console.log(`Token recipients in DB: ${recipients.length}`);
    console.log(`Total wallets in DB: ${allW.length}\n`);
    
    // Load progress
    let prog: { done: string[] } = { done: [] };
    if (fs.existsSync(PROG)) prog = JSON.parse(fs.readFileSync(PROG, "utf-8"));
    const doneSet = new Set(prog.done);
    
    // STEP 1: Deep scan all core wallets across ALL chains  
    console.log("── STEP 1: Deep scan core wallets on ALL chains ──");
    let totalTxs = 0;
    
    for (const addr of coreAddrs) {
      for (const [chain, api] of Object.entries(CHAINS)) {
        const key = `${addr}:${chain}:deep`;
        if (doneSet.has(key)) continue;
        
        process.stdout.write(`\r  ${chain.padEnd(10)} ${addr.slice(0,14)}...`);
        
        const tokens = await getAllTokens(api, addr, chain);
        await sleep(200);
        const txs = await getAllTxs(api, addr, chain);
        await sleep(200);
        
        if (tokens.length > 0 || txs.length > 0) {
          console.log(`\n  ✦ ${addr.slice(0,14)}... on ${chain}: ${tokens.length} token + ${txs.length} native`);
          for (const t of [...tokens, ...txs]) {
            fs.appendFileSync(DATA, JSON.stringify(t) + "\n");
          }
          totalTxs += tokens.length + txs.length;
        }
        
        doneSet.add(key);
        prog.done.push(key);
        fs.writeFileSync(PROG, JSON.stringify(prog));
      }
    }
    
    // STEP 2: Quick check recipients on Ethereum (first page only - just looking for activity)
    console.log("\n\n── STEP 2: Quick scan recipients on Ethereum ──");
    const recipAddrs = [...new Set(recipients.map(w => w.address.toLowerCase()))];
    console.log(`${recipAddrs.length} recipient addresses to check`);
    
    let recipChecked = 0;
    let recipActive = 0;
    
    for (const addr of recipAddrs) {
      const key = `${addr}:ethereum:quick`;
      if (doneSet.has(key)) { recipChecked++; continue; }
      
      recipChecked++;
      if (recipChecked % 100 === 0) process.stdout.write(`\r  ${recipChecked}/${recipAddrs.length} checked (${recipActive} active)...`);
      
      const tokens = await getFirstPageTokens(CHAINS.ethereum, addr, "ethereum");
      await sleep(200);
      
      if (tokens.length > 0) {
        recipActive++;
        // Check if any recent activity (after theft date March 4 2026)
        const afterTheft = tokens.filter(t => t.ts > "2026-03-04");
        if (afterTheft.length > 0) {
          console.log(`\n  ✦ RECIPIENT ACTIVE POST-THEFT: ${addr.slice(0,14)}... (${afterTheft.length} txs after theft)`);
        }
        for (const t of tokens) {
          fs.appendFileSync(DATA, JSON.stringify(t) + "\n");
        }
        totalTxs += tokens.length;
        
        // Also get native txs for active recipients
        const txs = await getFirstPageTxs(CHAINS.ethereum, addr, "ethereum");
        await sleep(200);
        for (const t of txs) {
          fs.appendFileSync(DATA, JSON.stringify(t) + "\n");
        }
        totalTxs += txs.length;
      }
      
      doneSet.add(key);
      prog.done.push(key);
      
      // Save every 50
      if (recipChecked % 50 === 0) fs.writeFileSync(PROG, JSON.stringify(prog));
    }
    
    fs.writeFileSync(PROG, JSON.stringify(prog));
    
    console.log(`\n\nScan batch complete.`);
    console.log(`Total records this batch: ${totalTxs}`);
    console.log(`Recipients checked: ${recipChecked}/${recipAddrs.length}`);
    console.log(`Active recipients: ${recipActive}`);
    console.log(`Progress saved. Run again to continue.`);
    
    // Count total records
    if (fs.existsSync(DATA)) {
      const lineCount = fs.readFileSync(DATA, "utf-8").trim().split("\n").filter(Boolean).length;
      console.log(`Total accumulated records: ${lineCount}`);
    }
    
  } else if (mode === "report") {
    console.log("═══ BUILDING COMPREHENSIVE REPORT ═══\n");
    // Build report from collected data
    if (!fs.existsSync(DATA)) { console.error("No data. Run 'scan' first."); process.exit(1); }
    
    const allW = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
    const labelMap = new Map<string, string>();
    for (const w of allW) { if (w.label) labelMap.set(w.address.toLowerCase(), w.label.slice(0, 60)); }
    const kl: Record<string, string> = {
      "0x6fe0fab2164d8e0d03ad6a628e2af78624060322": "VICTIM",
      "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41": "VICTIM-2",
      "0xf70da97812cb96acdf810712aa562db8dfa3dbef": "POI-$4.35M",
      "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872": "LAUNDER-HUB-$20M",
      "0xd14f4b36e1d1d98c218db782c49149876042bc56": "FXUSD-SOURCE",
      "0x658370618bbc885865df66c1061bfe4771fad846": "CRYPTO.COM-SUSPECT",
      "0x423d2b61952d56358db8b313ec7404a9582d4865": "ORIGINAL-FUNDER",
      "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb": "SOURCE-EIP7702",
      "0xb01fed2f701695992a4f7ffdb53f3af099e140d7": "GAS-FUNDER",
      "0x6818809eefce719e480a7526d76bd3e561526b46": "RELAY-PROXY",
    };
    for (const [a, l] of Object.entries(kl)) labelMap.set(a, l);
    
    const EXCHANGES: Record<string, string> = {
      "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
      "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance-2",
      "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance-3",
      "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance-4",
      "0x9696f59e4d72e237be84ffd425dcad154bf96976": "Binance-5",
      "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance-8",
      "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase-1",
      "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase-2",
      "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
      "0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com-2",
      "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Kraken",
      "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    };
    
    const lines = fs.readFileSync(DATA, "utf-8").trim().split("\n").filter(Boolean);
    console.log(`Loading ${lines.length} records...`);
    
    const uniqueMap = new Map<string, any>();
    for (const l of lines) {
      const r = JSON.parse(l);
      const k = `${r.h}-${r.f}-${r.t}-${r.sym||"N"}-${r.c}`;
      if (!uniqueMap.has(k)) uniqueMap.set(k, r);
    }
    
    const records = [...uniqueMap.values()].sort((a, b) => (a.ts || "").localeCompare(b.ts || ""));
    console.log(`${records.length} unique records`);
    
    const lastScan = new Date("2026-03-08T02:00:00Z");
    const newRecs = records.filter(r => new Date(r.ts) > lastScan);
    const chains = [...new Set(records.map(r => r.c))];
    const tokenRecs = records.filter(r => r.tp === "tok");
    const nativeRecs = records.filter(r => r.tp === "nat");
    
    // Exchange hits
    const exHits = records.filter(r => EXCHANGES[r.f] || EXCHANGES[r.t]);
    
    // Token summary
    const tSums = new Map<string, { n: number; v: number; ch: Set<string> }>();
    for (const r of tokenRecs) {
      if (!tSums.has(r.sym)) tSums.set(r.sym, { n: 0, v: 0, ch: new Set() });
      const s = tSums.get(r.sym)!;
      s.n++;
      s.v += parseFloat(r.v) / Math.pow(10, r.dec || 18);
      s.ch.add(r.c);
    }
    
    function fv(v: string, d = 18) {
      const n = parseFloat(v) / Math.pow(10, d);
      if (isNaN(n) || n === 0) return "0";
      if (n >= 1e9) return (n/1e9).toFixed(2)+"B";
      if (n >= 1e6) return (n/1e6).toFixed(2)+"M";
      if (n >= 1e3) return (n/1e3).toFixed(2)+"K";
      return n.toFixed(4);
    }
    function lbl(a: string) { return labelMap.get(a) || EXCHANGES[a] || ""; }
    
    let rpt = "";
    rpt += "═".repeat(90) + "\n";
    rpt += "  ALPHA FORENSIC INTELLIGENCE ENGINE™ — COMPLETE MULTI-CHAIN SCAN\n";
    rpt += "  Case: @sillytuna (Alex Amsel) ~$24M Physical Theft\n";
    rpt += `  Generated: ${new Date().toISOString()}\n`;
    rpt += `  Case ID: ${CASE}\n`;
    rpt += `  Wallets in DB: ${allW.length}\n`;
    rpt += "═".repeat(90) + "\n\n";
    
    rpt += "SCAN SUMMARY\n" + "─".repeat(70) + "\n";
    rpt += `  Chains Scanned: ${Object.keys(CHAINS).join(", ")}\n`;
    rpt += `  Chains With Activity: ${chains.join(", ")}\n`;
    rpt += `  Total Unique Records: ${records.length}\n`;
    rpt += `  Token Transfers: ${tokenRecs.length}\n`;
    rpt += `  Native TXs: ${nativeRecs.length}\n`;
    rpt += `  Unique Tokens: ${tSums.size}\n`;
    rpt += `  Exchange Interactions: ${exHits.length}\n`;
    rpt += `  New Activity Since Last Scan: ${newRecs.length}\n\n`;
    
    // NEW ACTIVITY
    rpt += "═".repeat(90) + "\n";
    rpt += `  NEW ACTIVITY (${newRecs.length} transactions since 2026-03-08T02:00Z)\n`;
    rpt += "═".repeat(90) + "\n\n";
    for (const r of newRecs) {
      const fl = lbl(r.f); const tl = lbl(r.t);
      if (r.tp === "tok") {
        rpt += `  [${(r.c||"").toUpperCase()}] ${r.ts} | ${r.sym}\n`;
        rpt += `    ${r.f}${fl?" ["+fl+"]":""} → ${r.t}${tl?" ["+tl+"]":""}\n`;
        rpt += `    ${fv(r.v, r.dec||18)} ${r.sym} | TX: ${r.h}\n\n`;
      } else {
        rpt += `  [${(r.c||"").toUpperCase()}] ${r.ts} | NATIVE\n`;
        rpt += `    ${r.f}${fl?" ["+fl+"]":""} → ${r.t}${tl?" ["+tl+"]":""}\n`;
        rpt += `    ${fv(r.v)} ETH | TX: ${r.h}\n\n`;
      }
    }
    
    // EXCHANGE
    rpt += "═".repeat(90) + "\n";
    rpt += `  EXCHANGE INTERACTIONS (${exHits.length})\n`;
    rpt += "═".repeat(90) + "\n\n";
    for (const r of exHits) {
      const ex = EXCHANGES[r.f] || EXCHANGES[r.t];
      rpt += `  [${(r.c||"").toUpperCase()}] ${r.ts} | ${ex}\n`;
      rpt += `    ${r.f}${lbl(r.f)?" ["+lbl(r.f)+"]":""} → ${r.t}${lbl(r.t)?" ["+lbl(r.t)+"]":""}\n`;
      if (r.sym) rpt += `    ${fv(r.v, r.dec||18)} ${r.sym} | TX: ${r.h}\n`;
      else rpt += `    ${fv(r.v)} ETH | TX: ${r.h}\n`;
      rpt += "\n";
    }
    
    // TOKENS
    rpt += "═".repeat(90) + "\n";
    rpt += "  ALL TOKENS TRACED\n";
    rpt += "═".repeat(90) + "\n\n";
    for (const [sym, info] of [...tSums.entries()].sort((a,b) => b[1].v - a[1].v)) {
      const vs = info.v >= 1e6 ? (info.v/1e6).toFixed(2)+"M" : info.v >= 1e3 ? (info.v/1e3).toFixed(2)+"K" : info.v.toFixed(4);
      rpt += `  ${sym.padEnd(15)} ${vs.padStart(15)} | ${info.n} transfers | ${[...info.ch].join(",")}\n`;
    }
    
    // FULL LOG
    rpt += "\n" + "═".repeat(90) + "\n";
    rpt += `  FULL TRANSACTION LOG (${records.length} records)\n`;
    rpt += "═".repeat(90) + "\n\n";
    for (const r of records) {
      const fl = lbl(r.f); const tl = lbl(r.t);
      rpt += `[${(r.c||"").toUpperCase().padEnd(10)}] ${r.ts} | ${r.h}\n`;
      if (r.tp === "tok") {
        rpt += `  ${r.f}${fl?" ["+fl+"]":""} → ${r.t}${tl?" ["+tl+"]":""} | ${fv(r.v, r.dec||18)} ${r.sym}\n`;
      } else {
        rpt += `  ${r.f}${fl?" ["+fl+"]":""} → ${r.t}${tl?" ["+tl+"]":""} | ${fv(r.v)} ETH${r.m?" | "+r.m:""}\n`;
      }
    }
    
    rpt += "\n" + "═".repeat(90) + "\n";
    rpt += "  END OF REPORT\n";
    rpt += "  © 2024-2026 Alpha Unlimited Trading Company. PROPRIETARY AND CONFIDENTIAL\n";
    rpt += "═".repeat(90) + "\n";
    
    const outFile = "forensic_complete_multichain_scan.txt";
    fs.writeFileSync(outFile, rpt);
    const sizeKb = (fs.statSync(outFile).size / 1024).toFixed(1);
    console.log(`\nReport: ${outFile} (${sizeKb} KB)`);
    console.log(`Records: ${records.length} | New: ${newRecs.length} | Exchanges: ${exHits.length} | Tokens: ${tSums.size}`);
  }
  
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
