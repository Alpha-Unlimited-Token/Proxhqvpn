/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Alpha Forensic FXUSD Source Chain Trace™
 * AUT_FORENSIC_FXUSD_TRACE_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_FXUSD_Calibration_PROTECTED
 *
 * Traces the complete FXUSD SOURCE chain from the known FXUSD Source address
 * through the relay proxy to the Crypto.com-linked wallet, pulling ALL
 * on-chain data from Blockscout for law enforcement evidence.
 */

import * as fs from "fs";

const BLOCKSCOUT_ETH = "https://eth.blockscout.com/api/v2";

const FXUSD_SOURCE = "0xD14F4B36E1D1D98c218db782c49149876042BC56";
const RELAY_PROXY = "0x6818809EefCe719E480a7526D76bD3e561526b46";
const RELAYER = "0xEC15c20015e72748F03065ed80c41cb882E3fB66";
const CRYPTO_COM_WALLET = "0x658370618BBc885865df66c1061BfE4771FaD846";
const CRYPTO_COM_HOT_WALLET_2 = "0x46340b20830761efd32832A74d7169B29FEB9758";
const COW_SWAP = "0x9008D19f58AAbD9eD0D60971565AA8510560ab41";
const OPTIMISM_BRIDGE = "0x3154Cf16ccdb4C6d922629664174b904d80F2C35";

const LABELS: Record<string, string> = {
  [FXUSD_SOURCE.toLowerCase()]: "FXUSD SOURCE (Known Address)",
  [RELAY_PROXY.toLowerCase()]: "Relay Proxy (ERC1967Proxy / ZK Proof Relay)",
  [RELAYER.toLowerCase()]: "Relayer (calls relay() function)",
  [CRYPTO_COM_WALLET.toLowerCase()]: "CRYPTO.COM SUSPECT WALLET (KYC on file)",
  [CRYPTO_COM_HOT_WALLET_2.toLowerCase()]: "CRYPTO.COM HOT WALLET 2 (Exchange-controlled)",
  [COW_SWAP.toLowerCase()]: "CoW Swap Settlement (GPv2Settlement / DEX)",
  [OPTIMISM_BRIDGE.toLowerCase()]: "Optimism Bridge (L1ChugSplashProxy)",
  "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com Main Hot Wallet",
  "0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com Hot Wallet 3",
  "0x72a53cdbbcc1b9efa39c834a540550e23463aacb": "Crypto.com Exchange",
};

interface TxRecord {
  txHash: string;
  timestamp: string;
  blockNumber: number;
  fromAddress: string;
  toAddress: string;
  amount: string;
  token: string;
  method: string;
  type: string;
}

async function apiFetch(url: string): Promise<any> {
  try {
    const r = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(20000),
    });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

function getLabel(addr: string): string {
  return LABELS[addr.toLowerCase()] || addr;
}

async function getAllTokenTransfers(address: string): Promise<any[]> {
  const addr = address.toLowerCase();
  const all: any[] = [];
  let nextParams: any = null;
  let page = 0;
  do {
    let url = `${BLOCKSCOUT_ETH}/addresses/${addr}/token-transfers`;
    if (nextParams) {
      url += `?${new URLSearchParams(nextParams).toString()}`;
    }
    const data = await apiFetch(url);
    await new Promise((r) => setTimeout(r, 250));
    if (!data?.items) break;
    all.push(...data.items);
    nextParams = data.next_page_params || null;
    page++;
  } while (nextParams && page < 20);
  return all;
}

async function getAllEthTransactions(address: string): Promise<any[]> {
  const addr = address.toLowerCase();
  const all: any[] = [];
  let nextParams: any = null;
  let page = 0;
  do {
    let url = `${BLOCKSCOUT_ETH}/addresses/${addr}/transactions`;
    if (nextParams) {
      url += `?${new URLSearchParams(nextParams).toString()}`;
    }
    const data = await apiFetch(url);
    await new Promise((r) => setTimeout(r, 250));
    if (!data?.items) break;
    all.push(...data.items);
    nextParams = data.next_page_params || null;
    page++;
  } while (nextParams && page < 20);
  return all;
}

async function getTxTokenTransfers(txHash: string): Promise<any[]> {
  const data = await apiFetch(`${BLOCKSCOUT_ETH}/transactions/${txHash}/token-transfers`);
  return data?.items || [];
}

async function main() {
  const report: string[] = [];
  const log = (s: string) => {
    report.push(s);
    console.log(s);
  };

  log("═══════════════════════════════════════════════════════════════════════════════");
  log("  ALPHA FORENSIC INTELLIGENCE ENGINE™");
  log("  FXUSD SOURCE → CRYPTO.COM WALLET COMPLETE EVIDENCE CHAIN");
  log("  Case: @sillytuna (Alex Amsel) — ~$24M Crypto Theft");
  log("  Case ID: 306db48a-36e2-42c1-9d7c-3b49d5bfdb49");
  log(`  Generated: ${new Date().toISOString()}`);
  log("  Data Source: Ethereum Blockchain via Blockscout API");
  log("  All transaction hashes independently verifiable on Etherscan/Blockscout");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  log("KEY ADDRESSES IN THIS EVIDENCE CHAIN:");
  log("──────────────────────────────────────────────────────────────────────────────");
  log(`  FXUSD SOURCE:           ${FXUSD_SOURCE}`);
  log(`                          Known address (confirmed by victim's tracking team)`);
  log(`  RELAY PROXY:            ${RELAY_PROXY}`);
  log(`                          ERC1967Proxy — ZK proof relay contract`);
  log(`  RELAYER:                ${RELAYER}`);
  log(`                          Entity executing relay() calls on the proxy`);
  log(`  CRYPTO.COM WALLET:      ${CRYPTO_COM_WALLET}`);
  log(`                          Suspect wallet — received funds, KYC identity on file`);
  log(`  CRYPTO.COM HOT WALLET:  ${CRYPTO_COM_HOT_WALLET_2}`);
  log(`                          Exchange-controlled hot wallet (proves KYC link)`);
  log(`  COW SWAP:               ${COW_SWAP}`);
  log(`                          GPv2Settlement — DEX used for FXUSD→USDC swap`);
  log(`  OPTIMISM BRIDGE:        ${OPTIMISM_BRIDGE}`);
  log(`                          L1ChugSplashProxy — used to bridge ETH to Optimism`);
  log("──────────────────────────────────────────────────────────────────────────────\n");

  log("MONEY FLOW SUMMARY:");
  log("──────────────────────────────────────────────────────────────────────────────");
  log("  FXUSD SOURCE (known) → deposits 155,247.80 FXUSD into Relay Proxy");
  log("  Relay Proxy → sends 155,092.55 FXUSD to Crypto.com Wallet (via ZK relay)");
  log("  Relay Proxy → sends 155.25 FXUSD fee to Relayer");
  log("  Crypto.com Wallet → swaps 155,092.55 FXUSD for 155,017.66 USDC via CoW Swap");
  log("  Crypto.com Hot Wallet 2 → sends 0.0226 ETH to Crypto.com Wallet (gas funding)");
  log("  Crypto.com Wallet → bridges 0.01 ETH to Optimism");
  log("  TOTAL VALUE: ~$155,017 USDC + ETH");
  log("──────────────────────────────────────────────────────────────────────────────\n\n");

  // ============== SECTION 1: FXUSD SOURCE COMPLETE HISTORY ==============
  log("═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 1: FXUSD SOURCE — COMPLETE TOKEN TRANSFER HISTORY");
  log(`Address: ${FXUSD_SOURCE}`);
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  console.log("  Fetching FXUSD SOURCE token transfers...");
  const fxusdSourceTransfers = await getAllTokenTransfers(FXUSD_SOURCE);
  console.log(`  Found ${fxusdSourceTransfers.length} token transfers\n`);
  
  log(`Total token transfers found: ${fxusdSourceTransfers.length}\n`);

  const fxusdSourceParsed: TxRecord[] = [];
  for (const tt of fxusdSourceTransfers) {
    const from = (tt.from?.hash || "").toLowerCase();
    const to = (tt.to?.hash || "").toLowerCase();
    const sym = tt.token?.symbol || "???";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
    fxusdSourceParsed.push({
      txHash: tt.transaction_hash || tt.hash || "",
      timestamp: tt.timestamp || "",
      blockNumber: parseInt(tt.block_number || "0"),
      fromAddress: from,
      toAddress: to,
      amount: amt.toFixed(6),
      token: sym,
      method: "",
      type: from === FXUSD_SOURCE.toLowerCase() ? "OUTGOING" : "INCOMING",
    });
  }

  fxusdSourceParsed.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  let txNum = 0;
  for (const tx of fxusdSourceParsed) {
    txNum++;
    const fromLbl = getLabel(tx.fromAddress);
    const toLbl = getLabel(tx.toAddress);
    const isCritical = tx.toAddress === CRYPTO_COM_WALLET.toLowerCase() || 
                       tx.toAddress === RELAY_PROXY.toLowerCase() ||
                       tx.fromAddress === RELAY_PROXY.toLowerCase();
    const marker = isCritical ? " ◄◄◄ CASE RELEVANT" : "";

    log(`TX #${String(txNum).padStart(4, "0")} | ${tx.timestamp} | ${tx.type}`);
    log(`  Hash:   ${tx.txHash}`);
    log(`  Amount: ${tx.amount} ${tx.token}${marker}`);
    log(`  FROM:   ${tx.fromAddress}`);
    log(`          (${fromLbl})`);
    log(`  TO:     ${tx.toAddress}`);
    log(`          (${toLbl})`);
    log(`  ──────────────────────────────────────────────────────`);
  }

  // ============== SECTION 2: RELAY PROXY COMPLETE HISTORY ==============
  log("\n\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 2: RELAY PROXY — COMPLETE TRANSACTION HISTORY");
  log(`Address: ${RELAY_PROXY} (ERC1967Proxy)`);
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  console.log("  Fetching Relay Proxy token transfers...");
  const relayTransfers = await getAllTokenTransfers(RELAY_PROXY);
  console.log(`  Found ${relayTransfers.length} token transfers`);

  console.log("  Fetching Relay Proxy ETH transactions...");
  const relayEthTxs = await getAllEthTransactions(RELAY_PROXY);
  console.log(`  Found ${relayEthTxs.length} ETH transactions\n`);

  log(`Token transfers: ${relayTransfers.length}`);
  log(`ETH transactions: ${relayEthTxs.length}\n`);

  const relayParsed: TxRecord[] = [];
  const seenHashes = new Set<string>();

  for (const tt of relayTransfers) {
    const from = (tt.from?.hash || "").toLowerCase();
    const to = (tt.to?.hash || "").toLowerCase();
    const sym = tt.token?.symbol || "???";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
    const key = (tt.transaction_hash || tt.hash || "") + sym + from + to;
    if (seenHashes.has(key)) continue;
    seenHashes.add(key);
    relayParsed.push({
      txHash: tt.transaction_hash || tt.hash || "",
      timestamp: tt.timestamp || "",
      blockNumber: parseInt(tt.block_number || "0"),
      fromAddress: from,
      toAddress: to,
      amount: amt.toFixed(6),
      token: sym,
      method: "",
      type: from === RELAY_PROXY.toLowerCase() ? "OUTGOING" : "INCOMING",
    });
  }

  for (const tx of relayEthTxs) {
    const from = (tx.from?.hash || "").toLowerCase();
    const to = (tx.to?.hash || "").toLowerCase();
    const val = tx.value ? parseInt(tx.value) / 1e18 : 0;
    if (val === 0) continue;
    const key = tx.hash + "ETH" + from + to;
    if (seenHashes.has(key)) continue;
    seenHashes.add(key);
    relayParsed.push({
      txHash: tx.hash || "",
      timestamp: tx.timestamp || "",
      blockNumber: parseInt(tx.block || tx.block_number || "0"),
      fromAddress: from,
      toAddress: to,
      amount: val.toFixed(8),
      token: "ETH",
      method: tx.method || "",
      type: from === RELAY_PROXY.toLowerCase() ? "OUTGOING" : "INCOMING",
    });
  }

  relayParsed.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  txNum = 0;
  for (const tx of relayParsed) {
    txNum++;
    const fromLbl = getLabel(tx.fromAddress);
    const toLbl = getLabel(tx.toAddress);
    const isCritical = tx.toAddress === CRYPTO_COM_WALLET.toLowerCase() ||
                       tx.fromAddress === FXUSD_SOURCE.toLowerCase() ||
                       tx.fromAddress === CRYPTO_COM_WALLET.toLowerCase();
    const marker = isCritical ? " ◄◄◄ CASE RELEVANT" : "";

    log(`TX #${String(txNum).padStart(4, "0")} | ${tx.timestamp} | ${tx.type}`);
    log(`  Hash:   ${tx.txHash}`);
    log(`  Amount: ${tx.amount} ${tx.token}${marker}`);
    log(`  FROM:   ${tx.fromAddress}`);
    log(`          (${fromLbl})`);
    log(`  TO:     ${tx.toAddress}`);
    log(`          (${toLbl})`);
    if (tx.method) log(`  Method: ${tx.method}`);
    log(`  ──────────────────────────────────────────────────────`);
  }

  // ============== SECTION 3: CRYPTO.COM WALLET COMPLETE HISTORY ==============
  log("\n\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 3: CRYPTO.COM SUSPECT WALLET — COMPLETE TRANSACTION HISTORY");
  log(`Address: ${CRYPTO_COM_WALLET}`);
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  console.log("  Fetching Crypto.com Wallet token transfers...");
  const ccTransfers = await getAllTokenTransfers(CRYPTO_COM_WALLET);
  console.log(`  Found ${ccTransfers.length} token transfers`);

  console.log("  Fetching Crypto.com Wallet ETH transactions...");
  const ccEthTxs = await getAllEthTransactions(CRYPTO_COM_WALLET);
  console.log(`  Found ${ccEthTxs.length} ETH transactions\n`);

  log(`Token transfers: ${ccTransfers.length}`);
  log(`ETH transactions: ${ccEthTxs.length}\n`);

  const ccParsed: TxRecord[] = [];
  const ccSeen = new Set<string>();

  for (const tt of ccTransfers) {
    const from = (tt.from?.hash || "").toLowerCase();
    const to = (tt.to?.hash || "").toLowerCase();
    const sym = tt.token?.symbol || "???";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
    const key = (tt.transaction_hash || tt.hash || "") + sym + from + to;
    if (ccSeen.has(key)) continue;
    ccSeen.add(key);
    ccParsed.push({
      txHash: tt.transaction_hash || tt.hash || "",
      timestamp: tt.timestamp || "",
      blockNumber: parseInt(tt.block_number || "0"),
      fromAddress: from,
      toAddress: to,
      amount: amt.toFixed(6),
      token: sym,
      method: "",
      type: from === CRYPTO_COM_WALLET.toLowerCase() ? "OUTGOING" : "INCOMING",
    });
  }

  for (const tx of ccEthTxs) {
    const from = (tx.from?.hash || "").toLowerCase();
    const to = (tx.to?.hash || "").toLowerCase();
    const val = tx.value ? parseInt(tx.value) / 1e18 : 0;
    const key = tx.hash + "ETH" + from + to;
    if (ccSeen.has(key)) continue;
    ccSeen.add(key);
    ccParsed.push({
      txHash: tx.hash || "",
      timestamp: tx.timestamp || "",
      blockNumber: parseInt(tx.block || tx.block_number || "0"),
      fromAddress: from,
      toAddress: to,
      amount: val.toFixed(8),
      token: "ETH",
      method: tx.method || "",
      type: from === CRYPTO_COM_WALLET.toLowerCase() ? "OUTGOING" : "INCOMING",
    });
  }

  ccParsed.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  txNum = 0;
  for (const tx of ccParsed) {
    txNum++;
    const fromLbl = getLabel(tx.fromAddress);
    const toLbl = getLabel(tx.toAddress);
    const isCryptoComHot = tx.fromAddress === CRYPTO_COM_HOT_WALLET_2.toLowerCase();
    const marker = isCryptoComHot ? " ★★★ FROM CRYPTO.COM EXCHANGE (KYC IDENTITY ON FILE) ★★★" : "";

    log(`TX #${String(txNum).padStart(4, "0")} | ${tx.timestamp} | ${tx.type}`);
    log(`  Hash:   ${tx.txHash}`);
    log(`  Amount: ${tx.amount} ${tx.token}${marker}`);
    log(`  FROM:   ${tx.fromAddress}`);
    log(`          (${fromLbl})`);
    log(`  TO:     ${tx.toAddress}`);
    log(`          (${toLbl})`);
    if (tx.method) log(`  Method: ${tx.method}`);
    log(`  ──────────────────────────────────────────────────────`);
  }

  // ============== SECTION 4: THE CRITICAL RELAY TRANSACTION BREAKDOWN ==============
  log("\n\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 4: CRITICAL RELAY TRANSACTION — DETAILED BREAKDOWN");
  log("TX: 0x6b0782939444bee11b3722eba8d3a749c32fe82b42e02db7dab852f818c6a484");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  console.log("  Fetching critical relay TX token transfers...");
  const criticalTxTransfers = await getTxTokenTransfers("0x6b0782939444bee11b3722eba8d3a749c32fe82b42e02db7dab852f818c6a484");
  console.log(`  Found ${criticalTxTransfers.length} internal token transfers\n`);

  log("This single transaction is the critical link in the evidence chain.");
  log("It shows the FXUSD SOURCE depositing into the relay, which then");
  log("forwarded funds directly to the Crypto.com-linked wallet.\n");
  log("Method called: relay()");
  log("Caller: " + RELAYER);
  log("Contract: " + RELAY_PROXY + " (ERC1967Proxy)\n");
  log("Internal token movements within this transaction:\n");

  for (const tt of criticalTxTransfers) {
    const from = (tt.from?.hash || "").toLowerCase();
    const to = (tt.to?.hash || "").toLowerCase();
    const sym = tt.token?.symbol || "???";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);

    log(`  ${amt.toFixed(6)} ${sym}`);
    log(`    FROM: ${tt.from?.hash} (${getLabel(from)})`);
    log(`    TO:   ${tt.to?.hash} (${getLabel(to)})`);
    log("");
  }

  // ============== SECTION 5: COW SWAP TRANSACTION BREAKDOWN ==============
  log("\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 5: COW SWAP TRANSACTION — FXUSD → USDC CONVERSION");
  log("TX: 0x5875ca456fef552da782c3ce2d76ac65d66dbfe6a987f4f1ecfbd8436d321c57");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  console.log("  Fetching CoW Swap TX token transfers...");
  const cowSwapTransfers = await getTxTokenTransfers("0x5875ca456fef552da782c3ce2d76ac65d66dbfe6a987f4f1ecfbd8436d321c57");
  console.log(`  Found ${cowSwapTransfers.length} internal token transfers\n`);

  log("This transaction shows the Crypto.com wallet swapping FXUSD for USDC:");
  log("The suspect wallet converted the received FXUSD tokens into USDC stablecoins.\n");

  for (const tt of cowSwapTransfers) {
    const from = (tt.from?.hash || "").toLowerCase();
    const to = (tt.to?.hash || "").toLowerCase();
    const sym = tt.token?.symbol || "???";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);

    log(`  ${amt.toFixed(6)} ${sym}`);
    log(`    FROM: ${tt.from?.hash} (${getLabel(from)})`);
    log(`    TO:   ${tt.to?.hash} (${getLabel(to)})`);
    log("");
  }

  // ============== SECTION 6: CRYPTO.COM HOT WALLET PROOF ==============
  log("\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 6: CRYPTO.COM KYC PROOF — HOT WALLET WITHDRAWAL");
  log("TX: 0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  log("This transaction PROVES the suspect wallet has a Crypto.com account with KYC:");
  log("");
  log("  0.02256150 ETH");
  log(`    FROM: ${CRYPTO_COM_HOT_WALLET_2}`);
  log(`          (Crypto.com Hot Wallet 2 — Exchange-controlled address)`);
  log(`    TO:   ${CRYPTO_COM_WALLET}`);
  log(`          (Crypto.com Suspect Wallet)`);
  log("");
  log("  Timestamp: 2025-04-26T21:05:11.000000Z");
  log("  Block: Ethereum mainnet");
  log("");
  log("  SIGNIFICANCE: Crypto.com hot wallets are exchange-controlled addresses.");
  log("  A withdrawal FROM a Crypto.com hot wallet TO the suspect wallet means:");
  log("    1. The suspect wallet owner has a Crypto.com account");
  log("    2. They withdrew 0.0226 ETH from their Crypto.com account to this wallet");
  log("    3. Crypto.com requires full KYC to create an account and withdraw");
  log("    4. Crypto.com has the account holder's real identity on record\n");

  // ============== SECTION 7: CHRONOLOGICAL EVENT TIMELINE ==============
  log("\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 7: CHRONOLOGICAL EVENT TIMELINE");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  log("EVENT 1 — 2025-04-26T21:05:11Z");
  log("  Crypto.com Hot Wallet 2 sends 0.0226 ETH to suspect wallet");
  log("  → This proves suspect has a KYC-verified Crypto.com account");
  log(`  TX: 0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99\n`);

  log("EVENT 2 — 2025-04-30T01:06:35Z");
  log("  Suspect wallet bridges 0.01 ETH to Optimism via L1ChugSplashProxy");
  log(`  TX: 0x1e11fe6e576b0bed12c5312f524ca8e41f34d0b4dda66fcf42e484c636dc7a5e\n`);

  log("EVENT 3 — 2026-03-07T01:11:11Z");
  log("  FXUSD SOURCE deposits 155,247.80 FXUSD into Relay Proxy");
  log("  Relay Proxy sends 155,092.55 FXUSD to suspect wallet");
  log("  Relay Proxy sends 155.25 FXUSD fee to relayer");
  log(`  TX: 0x6b0782939444bee11b3722eba8d3a749c32fe82b42e02db7dab852f818c6a484\n`);

  log("EVENT 4 — 2026-03-07T01:12:23Z (72 seconds later)");
  log("  Suspect wallet swaps 155,092.55 FXUSD → 155,017.66 USDC via CoW Swap");
  log("  → Immediate conversion of FXUSD to stablecoins");
  log(`  TX: 0x5875ca456fef552da782c3ce2d76ac65d66dbfe6a987f4f1ecfbd8436d321c57\n`);

  // ============== SECTION 8: LAW ENFORCEMENT SUBPOENA GUIDANCE ==============
  log("\n═══════════════════════════════════════════════════════════════════════════════");
  log("SECTION 8: LAW ENFORCEMENT SUBPOENA GUIDANCE");
  log("═══════════════════════════════════════════════════════════════════════════════\n");

  log("SUBPOENA TARGET: Crypto.com (Foris DAX MT Ltd.)");
  log("  Legal Entity: Foris DAX MT Ltd.");
  log("  Jurisdiction: Malta / Singapore");
  log("  Compliance: support@crypto.com / compliance@crypto.com\n");

  log("EVIDENCE ESTABLISHING CRYPTO.COM ACCOUNT LINK:");
  log(`  1. Suspect Wallet: ${CRYPTO_COM_WALLET}`);
  log(`  2. Received withdrawal FROM Crypto.com Hot Wallet 2: ${CRYPTO_COM_HOT_WALLET_2}`);
  log("  3. TX Hash: 0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99");
  log("  4. Amount: 0.02256150 ETH");
  log("  5. Date: April 26, 2025, 21:05:11 UTC");
  log("  6. This withdrawal is ONLY possible from a KYC-verified Crypto.com account\n");

  log("INFORMATION TO REQUEST FROM CRYPTO.COM:");
  log("  a) Full legal name and date of birth of account holder");
  log("  b) Government-issued ID submitted for KYC verification");
  log("  c) Selfie / liveness check images");
  log("  d) Proof of address documentation");
  log("  e) Source of funds declaration");
  log("  f) All email addresses and phone numbers on the account");
  log("  g) IP addresses and geolocation of all login sessions");
  log("  h) Device information (fingerprints, user agents)");
  log("  i) Complete transaction history (all deposits, withdrawals, trades)");
  log("  j) ALL cryptocurrency withdrawal addresses linked to the account");
  log("  k) Fiat bank account / payment method details");
  log("  l) Any linked or referred accounts");
  log("  m) Account creation date and last login date");
  log("  n) Any internal fraud flags or suspicious activity reports (SARs)\n");

  log("CHAIN OF EVIDENCE (FXUSD Source → Crypto.com Wallet):");
  log("  Step 1: FXUSD SOURCE (known) → deposits FXUSD into Relay Proxy");
  log("  Step 2: Relay Proxy → sends FXUSD to Suspect Wallet (via ZK proof relay)");
  log("  Step 3: Suspect Wallet → immediately swaps FXUSD → USDC via CoW Swap");
  log("  Step 4: Suspect Wallet ← previously received ETH from Crypto.com Hot Wallet");
  log("  Step 5: Crypto.com has KYC identity of account that withdrew to this wallet\n");

  log("VERIFICATION:");
  log("  All transaction hashes in this report are on the Ethereum mainnet blockchain.");
  log("  They can be independently verified by entering any TX hash at:");
  log("    - https://etherscan.io/tx/<TX_HASH>");
  log("    - https://eth.blockscout.com/tx/<TX_HASH>");
  log("  The blockchain is immutable — these records cannot be altered or deleted.\n");

  log(`Report generated: ${new Date().toISOString()}`);
  log("Alpha Forensic Intelligence Engine™ — Alpha Unlimited Trading Company");

  const outputPath = "forensic_fxusd_source_chain_trace.txt";
  fs.writeFileSync(outputPath, report.join("\n"), "utf-8");
  console.log(`\n✓ Report saved to: ${outputPath}`);
  console.log(`  Total lines: ${report.length}`);

  process.exit(0);
}

main().catch((e) => {
  console.error("Fatal error:", e);
  process.exit(1);
});
