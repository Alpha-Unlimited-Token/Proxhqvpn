/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_ORIG_FUNDER_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_OrigFunder_Calibration_PROTECTED
 */

const BE = "https://eth.blockscout.com/api/v2";
const WALLET = "0x423d2b61952d56358db8b313ec7404a9582d4865";

async function api(url: string) {
  const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
  if (!r.ok) return null;
  return await r.json();
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function main() {
  console.log(`\n═══ ORIGINAL FUNDER WALLET — DEEP TRACE ═══`);
  console.log(`Wallet: ${WALLET}`);
  console.log(`Checked: ${new Date().toISOString()}\n`);

  // Address info
  const info = await api(`${BE}/addresses/${WALLET}`);
  if (info) {
    const ethBal = parseInt(info.coin_balance || "0") / 1e18;
    console.log(`═══ WALLET INFO ═══`);
    console.log(`  Name/Label: ${info.name || "NONE"}`);
    console.log(`  Is Contract: ${info.is_contract || false}`);
    console.log(`  Is Verified: ${info.is_verified || false}`);
    console.log(`  Creator: ${info.creator_address_hash || "N/A"}`);
    console.log(`  Creation TX: ${info.creation_tx_hash || "N/A"}`);
    console.log(`  ETH Balance: ${ethBal.toFixed(8)}`);
    console.log(`  TX Count: ${info.transactions_count || "?"}`);
    console.log(`  Token Transfer Count: ${info.token_transfers_count || "?"}`);
    console.log(`  ENS Name: ${info.ens_domain_name || "NONE"}`);
    console.log(`  Implementation Name: ${info.implementation_name || "N/A"}`);
    if (info.has_custom_methods_read) console.log("  Has custom read methods");
    if (info.has_custom_methods_write) console.log("  Has custom write methods");
    console.log("");
  }

  // ALL ETH transactions — paginate to get everything
  console.log(`═══ ALL ETH TRANSACTIONS ═══\n`);
  let page: string | null = null;
  let allTxs: any[] = [];
  let pageCount = 0;
  
  while (true) {
    const url = page ? `${BE}/addresses/${WALLET}/transactions?${page}` : `${BE}/addresses/${WALLET}/transactions`;
    const txs = await api(url);
    await sleep(200);
    if (!txs?.items || txs.items.length === 0) break;
    allTxs.push(...txs.items);
    pageCount++;
    if (!txs.next_page_params) break;
    const p = txs.next_page_params;
    page = Object.entries(p).map(([k,v]) => `${k}=${v}`).join("&");
    if (pageCount > 20) break; // safety
  }

  // Sort oldest first
  allTxs.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  
  console.log(`  Total ETH transactions: ${allTxs.length}\n`);

  // Show first 5 (earliest) and last 5 (most recent)
  console.log(`  ── EARLIEST TRANSACTIONS (first funding sources) ──\n`);
  for (const tx of allTxs.slice(0, Math.min(15, allTxs.length))) {
    const from = tx.from?.hash || "";
    const to = tx.to?.hash || "";
    const fromName = tx.from?.name || "";
    const toName = tx.to?.name || "";
    const val = parseInt(tx.value || "0") / 1e18;
    const dir = from.toLowerCase() === WALLET.toLowerCase() ? "OUT →" : "IN  ←";
    const counterparty = from.toLowerCase() === WALLET.toLowerCase() ? `${to} ${toName}` : `${from} ${fromName}`;
    const method = tx.method || "";
    console.log(`  ${tx.timestamp}  ${dir}  ${val.toFixed(8)} ETH  ${method}`);
    console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
    console.log(`    TX: ${tx.hash}`);
    console.log("");
  }

  if (allTxs.length > 15) {
    console.log(`  ... ${allTxs.length - 30} more transactions ...\n`);
    console.log(`  ── MOST RECENT TRANSACTIONS ──\n`);
    for (const tx of allTxs.slice(-15)) {
      const from = tx.from?.hash || "";
      const to = tx.to?.hash || "";
      const fromName = tx.from?.name || "";
      const toName = tx.to?.name || "";
      const val = parseInt(tx.value || "0") / 1e18;
      const dir = from.toLowerCase() === WALLET.toLowerCase() ? "OUT →" : "IN  ←";
      const counterparty = from.toLowerCase() === WALLET.toLowerCase() ? `${to} ${toName}` : `${from} ${fromName}`;
      const method = tx.method || "";
      console.log(`  ${tx.timestamp}  ${dir}  ${val.toFixed(8)} ETH  ${method}`);
      console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
      console.log(`    TX: ${tx.hash}`);
      console.log("");
    }
  }

  // ALL token transfers
  console.log(`\n═══ ALL TOKEN TRANSFERS ═══\n`);
  let tPage: string | null = null;
  let allTokens: any[] = [];
  pageCount = 0;
  
  while (true) {
    const url = tPage ? `${BE}/addresses/${WALLET}/token-transfers?${tPage}` : `${BE}/addresses/${WALLET}/token-transfers`;
    const tts = await api(url);
    await sleep(200);
    if (!tts?.items || tts.items.length === 0) break;
    allTokens.push(...tts.items);
    pageCount++;
    if (!tts.next_page_params) break;
    const p = tts.next_page_params;
    tPage = Object.entries(p).map(([k,v]) => `${k}=${v}`).join("&");
    if (pageCount > 20) break;
  }

  allTokens.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  
  console.log(`  Total token transfers: ${allTokens.length}\n`);

  for (const tt of allTokens) {
    const from = tt.from?.hash || "";
    const to = tt.to?.hash || "";
    const fromName = tt.from?.name || "";
    const toName = tt.to?.name || "";
    const sym = tt.token?.symbol || "???";
    const tokenName = tt.token?.name || "";
    const dec = parseInt(tt.token?.decimals || "18");
    const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
    const dir = from.toLowerCase() === WALLET.toLowerCase() ? "OUT →" : "IN  ←";
    const counterparty = from.toLowerCase() === WALLET.toLowerCase() ? `${to} ${toName}` : `${from} ${fromName}`;
    console.log(`  ${tt.timestamp}  ${dir}  ${amt.toFixed(6)} ${sym} (${tokenName})`);
    console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
    console.log(`    TX: ${tt.transaction_hash || ""}`);
    console.log("");
  }

  // Current token holdings
  const tBal = await api(`${BE}/addresses/${WALLET}/tokens?type=ERC-20`);
  if (tBal?.items) {
    console.log(`\n═══ CURRENT TOKEN HOLDINGS ═══\n`);
    let hasTokens = false;
    for (const t of tBal.items) {
      const dec = parseInt(t.token?.decimals || "18");
      const val = parseFloat(t.value || "0") / Math.pow(10, dec);
      if (val > 0.000001) {
        hasTokens = true;
        console.log(`  ${t.token?.symbol}: ${val.toFixed(6)} (${t.token?.name})`);
      }
    }
    if (!hasTokens) console.log("  No tokens remaining.");
  }

  // Now trace the FIRST funder — who sent the very first ETH to this wallet?
  if (allTxs.length > 0) {
    const firstTx = allTxs[0];
    const firstFrom = firstTx.from?.hash || "";
    if (firstFrom.toLowerCase() !== WALLET.toLowerCase()) {
      console.log(`\n═══ TRACING FIRST FUNDER ═══`);
      console.log(`  First funder: ${firstFrom}`);
      console.log(`  First TX: ${firstTx.hash}`);
      console.log(`  Date: ${firstTx.timestamp}`);
      
      const funderInfo = await api(`${BE}/addresses/${firstFrom.toLowerCase()}`);
      await sleep(200);
      if (funderInfo) {
        console.log(`  Funder Name/Label: ${funderInfo.name || "NONE"}`);
        console.log(`  Is Contract: ${funderInfo.is_contract || false}`);
        console.log(`  ENS: ${funderInfo.ens_domain_name || "NONE"}`);
        console.log(`  TX Count: ${funderInfo.transactions_count || "?"}`);
        console.log(`  Token Transfer Count: ${funderInfo.token_transfers_count || "?"}`);
      }

      // Check if the first funder received from an exchange
      const funderTxs = await api(`${BE}/addresses/${firstFrom.toLowerCase()}/transactions`);
      await sleep(200);
      if (funderTxs?.items) {
        // Sort oldest first
        const sorted = funderTxs.items.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        console.log(`\n  ── First Funder's earliest transactions ──\n`);
        for (const tx of sorted.slice(0, 10)) {
          const from = tx.from?.hash || "";
          const to = tx.to?.hash || "";
          const fromName = tx.from?.name || "";
          const toName = tx.to?.name || "";
          const val = parseInt(tx.value || "0") / 1e18;
          const dir = from.toLowerCase() === firstFrom.toLowerCase() ? "OUT →" : "IN  ←";
          const counterparty = from.toLowerCase() === firstFrom.toLowerCase() ? `${to} ${toName}` : `${from} ${fromName}`;
          console.log(`  ${tx.timestamp}  ${dir}  ${val.toFixed(8)} ETH`);
          console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
          console.log(`    TX: ${tx.hash}`);
          console.log("");
        }
      }
    }
  }

  // Check internal transactions (for contract interactions)
  const internal = await api(`${BE}/addresses/${WALLET}/internal-transactions`);
  if (internal?.items && internal.items.length > 0) {
    console.log(`\n═══ INTERNAL TRANSACTIONS ═══\n`);
    for (const itx of internal.items.slice(0, 20)) {
      const from = itx.from?.hash || "";
      const to = itx.to?.hash || "";
      const val = parseInt(itx.value || "0") / 1e18;
      const dir = from.toLowerCase() === WALLET.toLowerCase() ? "OUT →" : "IN  ←";
      console.log(`  ${itx.timestamp}  ${dir}  ${val.toFixed(8)} ETH  Type: ${itx.type || "?"}`);
      console.log(`    ${dir === "OUT →" ? "To" : "From"}: ${from.toLowerCase() === WALLET.toLowerCase() ? to : from}`);
      console.log(`    TX: ${itx.transaction_hash || ""}`);
      console.log("");
    }
  }
}
main().catch(e => { console.error(e); process.exit(1); });
