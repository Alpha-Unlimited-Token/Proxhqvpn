/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_BATCH_SCAN_ALL_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_BatchScanAll_Calibration_PROTECTED
 *
 * Batch scanner: processes ALL case wallets in chunks, saves progress
 * Run multiple times to complete full scan
 */

import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { monitoredWallets } from "../../shared/models/forensic.js";
import { eq } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const PROGRESS_FILE = "/tmp/scan_progress.json";
const RESULTS_FILE = "/tmp/scan_results.jsonl"; // append-only results
const BATCH_SIZE = 80; // wallets per run
const DELAY = 300;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

const APIS: Record<string, string[]> = {
  ethereum: [
    "https://eth.blockscout.com/api/v2",
    "https://api.etherscan.io/api"
  ],
  arbitrum: [
    "https://arbitrum.blockscout.com/api/v2",
    "https://api.arbiscan.io/api"
  ],
  optimism: ["https://optimism.blockscout.com/api/v2"],
  base: ["https://base.blockscout.com/api/v2"],
  polygon: ["https://polygon.blockscout.com/api/v2"],
};

async function fetchJSON(url: string): Promise<any> {
  for (let i = 0; i < 2; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/3.0" }, timeout: 12000 } as any);
      if (r.status === 429) { await sleep(2000); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(800); }
  }
  return null;
}

interface WalletResult {
  address: string;
  chain: string;
  ethTxCount: number;
  tokenTxCount: number;
  latestTimestamp: string;
  tokenSymbols: string[];
  destinations: string[];
  sources: string[];
  scannedAt: string;
}

async function scanWalletOnChain(addr: string, chain: string, api: string): Promise<WalletResult | null> {
  const laddr = addr.toLowerCase();
  
  // Check if address exists
  const addrData = await fetchJSON(`${api}/addresses/${laddr}`);
  await sleep(DELAY);
  if (!addrData) return null;
  
  const txCount = parseInt(addrData.transactions_count || "0");
  const tokenTxCount = parseInt(addrData.token_transfers_count || "0");
  
  if (txCount === 0 && tokenTxCount === 0) return null;
  
  const result: WalletResult = {
    address: laddr,
    chain,
    ethTxCount: txCount,
    tokenTxCount: tokenTxCount,
    latestTimestamp: "",
    tokenSymbols: [],
    destinations: [],
    sources: [],
    scannedAt: new Date().toISOString()
  };
  
  // Get recent transactions (just first page for speed)
  if (txCount > 0) {
    const txData = await fetchJSON(`${api}/addresses/${laddr}/transactions`);
    await sleep(DELAY);
    if (txData?.items) {
      const dests = new Set<string>();
      const srcs = new Set<string>();
      for (const tx of txData.items) {
        const from = (tx.from?.hash || "").toLowerCase();
        const to = (tx.to?.hash || "").toLowerCase();
        if (from === laddr && to) dests.add(to);
        if (to === laddr && from) srcs.add(from);
        if (tx.timestamp && (!result.latestTimestamp || tx.timestamp > result.latestTimestamp)) {
          result.latestTimestamp = tx.timestamp;
        }
      }
      result.destinations = [...dests];
      result.sources = [...srcs];
    }
  }
  
  // Get token transfers (just first page)
  if (tokenTxCount > 0) {
    const ttData = await fetchJSON(`${api}/addresses/${laddr}/token-transfers`);
    await sleep(DELAY);
    if (ttData?.items) {
      const symbols = new Set<string>();
      const dests = new Set(result.destinations);
      const srcs = new Set(result.sources);
      for (const tt of ttData.items) {
        if (tt.token?.symbol) symbols.add(tt.token.symbol);
        const from = (tt.from?.hash || "").toLowerCase();
        const to = (tt.to?.hash || "").toLowerCase();
        if (from === laddr && to) dests.add(to);
        if (to === laddr && from) srcs.add(from);
        if (tt.timestamp && (!result.latestTimestamp || tt.timestamp > result.latestTimestamp)) {
          result.latestTimestamp = tt.timestamp;
        }
      }
      result.tokenSymbols = [...symbols];
      result.destinations = [...dests];
      result.sources = [...srcs];
    }
  }
  
  return result;
}

async function main() {
  // Load all wallets from DB
  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const allAddrs = [...new Set(wallets.map(w => w.address.toLowerCase()))];
  console.log(`[BatchScan] ${allAddrs.length} unique addresses in case DB`);
  
  // Load progress
  let progress: { scannedKeys: string[]; batchNumber: number } = { scannedKeys: [], batchNumber: 0 };
  if (fs.existsSync(PROGRESS_FILE)) {
    progress = JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
    console.log(`[BatchScan] Resuming — ${progress.scannedKeys.length} wallet-chain pairs already done (batch #${progress.batchNumber})`);
  }
  
  const scannedSet = new Set(progress.scannedKeys);
  
  // Build queue of unscanned wallet-chain pairs
  // Primary chains to check: ethereum & arbitrum for ALL wallets
  // Then check optimism, base, polygon for wallets that show bridge activity
  const queue: Array<{ addr: string; chain: string }> = [];
  
  for (const addr of allAddrs) {
    for (const chain of ["ethereum", "arbitrum"]) {
      const key = `${addr}:${chain}`;
      if (!scannedSet.has(key)) {
        queue.push({ addr, chain });
      }
    }
  }
  
  console.log(`[BatchScan] ${queue.length} wallet-chain pairs remaining to scan`);
  console.log(`[BatchScan] Processing batch of ${BATCH_SIZE}...\n`);
  
  const batch = queue.slice(0, BATCH_SIZE);
  let done = 0;
  let found = 0;
  
  for (const { addr, chain } of batch) {
    done++;
    const api = APIS[chain][0]; // use blockscout primary
    process.stdout.write(`\r  [${done}/${batch.length}] ${chain.padEnd(10)} ${addr.slice(0, 14)}...`);
    
    const result = await scanWalletOnChain(addr, chain, api);
    const key = `${addr}:${chain}`;
    scannedSet.add(key);
    progress.scannedKeys.push(key);
    
    if (result && (result.ethTxCount > 0 || result.tokenTxCount > 0)) {
      found++;
      // Append to results file
      fs.appendFileSync(RESULTS_FILE, JSON.stringify(result) + "\n");
      
      // If this wallet has activity, also queue it for other chains
      for (const otherChain of ["optimism", "base", "polygon"]) {
        const otherKey = `${addr}:${otherChain}`;
        if (!scannedSet.has(otherKey)) {
          // Quick check
          const otherApi = APIS[otherChain][0];
          const otherResult = await scanWalletOnChain(addr, otherChain, otherApi);
          scannedSet.add(otherKey);
          progress.scannedKeys.push(otherKey);
          if (otherResult) {
            found++;
            fs.appendFileSync(RESULTS_FILE, JSON.stringify(otherResult) + "\n");
            console.log(`\n  ✦ CROSS-CHAIN: ${addr.slice(0, 14)}... active on ${otherChain}! (${otherResult.ethTxCount} txs, ${otherResult.tokenTxCount} token transfers)`);
          }
        }
      }
    }
  }
  
  progress.batchNumber++;
  fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress));
  
  const remaining = queue.length - batch.length;
  const totalDone = progress.scannedKeys.length;
  const totalPairs = allAddrs.length * 2; // eth + arb minimum
  const pct = ((totalDone / totalPairs) * 100).toFixed(1);
  
  console.log(`\n\n[BatchScan] Batch #${progress.batchNumber} complete`);
  console.log(`  Scanned this batch: ${done}`);
  console.log(`  Active wallets found: ${found}`);
  console.log(`  Total scanned so far: ${totalDone} / ~${totalPairs} (${pct}%)`);
  console.log(`  Remaining: ~${remaining} wallet-chain pairs`);
  
  // Count total results
  if (fs.existsSync(RESULTS_FILE)) {
    const lines = fs.readFileSync(RESULTS_FILE, "utf-8").trim().split("\n").filter(Boolean);
    console.log(`  Total active wallets found: ${lines.length}`);
  }
  
  if (remaining > 0) {
    console.log(`\n  Run again to continue scanning...`);
  } else {
    console.log(`\n  ✅ ALL WALLETS SCANNED!`);
  }
  
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
