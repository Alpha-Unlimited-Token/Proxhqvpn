/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SWEEP_PART_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_SweepPart_Calibration_PROTECTED
 */

import * as fs from "fs";
import { db } from "../db.js";
import { monitoredWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const BE = "https://eth.blockscout.com/api/v2";
const ARB = "https://arbitrum.blockscout.com/api/v2";
const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const PART = parseInt(process.argv[2] || "1"); // 1 or 2

const EX: Record<string, string> = {
  "0x46340b20830761efd32832a74d7169b29feb9758": "Crypto.com","0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com","0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com","0x72a53cdbbcc1b9efa39c834a540550e23463aacb": "Crypto.com","0x7758e507850da48cd47df1fb5f875c23e3340c50": "Crypto.com",
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance","0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance","0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance","0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance","0xf977814e90da44bfa03b6295a0616a897441acec": "Binance","0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance","0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": "Binance","0xd551234ae421e3bcba99a0da6d736074f22192ff": "Binance","0x564286362092d8e7936f0549571a803b203aaced": "Binance","0x4e9ce36e442e55ecd9025b9a6e0d88485d628a67": "Binance","0x8894e0a0c962cb723c1ef8a1b6fcd0d2b756f896": "Binance",
  "0xa7efae728d2936e78bda97dc267687568dd593f3": "OKX","0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX","0x98ec059dc3adfbdd63429227d09cb015b78fc709": "OKX","0x236f9f97e0e62388479bf9e5ba4889e46b0273c3": "OKX",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase","0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase","0x3cd751e6b0078be393132286c442345e5dc49699": "Coinbase","0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase","0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase","0xf6874c88757721a02f47592140905c4e66a36945": "Coinbase",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken","0x53d284357ec70ce289d6d64134dfac8e511c8a3d": "Kraken","0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken","0xae2d4617c862309a3d75a0ffb358c7a5009c673f": "Kraken",
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": "KuCoin","0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin","0xf3f094484ec6901ffc9681bcb808b96bafd0b8a8": "KuCoin",
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io","0xd793281b45ceebfc1b3bac8f16a003e8ba03c2dd": "Gate.io","0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
  "0x1681195c176239ac5e72d9aebacf5b2492e0c4ee": "Bitfinex","0x876eabf441b2ee5b5b0554fd502a8e0600950cfa": "Bitfinex","0x742d35cc6634c0532925a3b844bc9e7595f2bd3e": "Bitfinex",
  "0xbf3aeb96e164ae67e763d9e050ff124e7c3fdd28": "Bitget","0x5bdf85216ec1e38d6458c870992a69e38e03f7ef": "Bitget",
  "0x2faf487a4414fe77e2327f0bf4ae2a264a776ad2": "FTX","0xc098b2a3aa256d2140208c3de6543aaef5cd3a94": "FTX",
  "0xab5c66752a9e8167967685f1450532fb96d5d24f": "Huobi/HTX","0x18709e89bd403f470088abdacebe86cc60dda12e": "Huobi/HTX","0x6748f50f686bfbca6fe8ad62b22228b87f31ff2b": "Huobi/HTX","0xe93381fb4c4f14bda253907b18fad305d799cee7": "Huobi/HTX",
  "0xeee27662c2b8eba3cd936a23f039f3189633e4c8": "Bybit","0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
  "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": "MEXC","0x0211f3cedbef3143223d3acf0e589747933e8527": "MEXC",
  "0xd24400ae8bfebb18ca49be86258a3c749cf46853": "Gemini","0x6fc82a5fe25a5cdb58bc74600a40a69c065263f8": "Gemini","0x07ee55aa48bb72dcc6e9d78256648910de513015": "Gemini",
  "0x00bdb5699745f5b860228c8f939abf1b9ae374ed": "Bitstamp","0x1522900b6dafac587d499a862861c0869be6e428": "Bitstamp",
  "0x5e032243d507c743b061ef27c9169ae83fc6d5f1": "Upbit",
  "0xfbb1b73c4f0bda4f67dca266ce6ef42f520fbb98": "Bittrex",
  "0x32be343b94f860124dc4fee278fdcbd38c102d88": "Poloniex",
  "0x077d360f11d220e4d5d831430c81c26c9be7c4a4": "ChangeNOW",
  "0x4e5b2e1dc63f6b91cb6cd759936495434c7e972f": "FixedFloat",
};

function exName(n: string): string | null {
  if (!n) return null;
  const lo = n.toLowerCase();
  for (const p of ["binance","coinbase","kraken","crypto.com","okx","huobi","htx","bybit","kucoin","gate.io","bitfinex","bitget","mexc","gemini","bitstamp","upbit","bittrex","poloniex","changenow","fixedfloat","ftx","nexo","celsius","revolut","luno"]) {
    if (lo.includes(p)) return n;
  }
  return null;
}

async function api(url: string): Promise<any> {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

interface Hit { wallet: string; label: string; role: string; dir: string; exchange: string; amount: string; token: string; ts: string; tx: string; chain: string; }

async function main() {
  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
  const important = wallets.filter(w => (w.role || "").toLowerCase() !== "token_recipient");

  const extra = [
    { address: "0x658370618BBc885865df66c1061BfE4771FaD846", label: "Crypto.com Suspect", role: "suspect", chain: "ethereum" },
    { address: "0xD14F4B36E1D1D98c218db782c49149876042BC56", label: "FXUSD Source", role: "source", chain: "ethereum" },
    { address: "0x6818809EefCe719E480a7526D76bD3e561526b46", label: "Relay Proxy", role: "relay", chain: "ethereum" },
    { address: "0xEC15c20015e72748F03065ed80c41cb882E3fB66", label: "Relayer", role: "relayer", chain: "ethereum" },
  ];

  const seen = new Set<string>();
  const all: Array<{address: string; label: string; role: string; chain: string}> = [];
  for (const w of extra) { seen.add(w.address.toLowerCase()); all.push(w); }
  for (const w of important) {
    const lo = w.address.toLowerCase();
    if (!seen.has(lo) && lo.startsWith("0x") && lo.length === 42) { seen.add(lo); all.push({ address: w.address, label: w.label || "", role: w.role || "", chain: w.chain || "ethereum" }); }
  }

  const mid = Math.ceil(all.length / 2);
  const chunk = PART === 1 ? all.slice(0, mid) : all.slice(mid);
  console.log(`Part ${PART}: checking wallets ${PART === 1 ? 1 : mid+1}-${PART === 1 ? mid : all.length} of ${all.length}`);

  const hits: Hit[] = [];
  let c = 0;
  for (const w of chunk) {
    c++;
    const base = (w.chain || "ethereum").toLowerCase() === "arbitrum" ? ARB : BE;
    const lo = w.address.toLowerCase();
    const ch = (w.chain || "ethereum").toLowerCase() === "arbitrum" ? "arbitrum" : "ethereum";

    const tt = await api(`${base}/addresses/${lo}/token-transfers`);
    await new Promise(r => setTimeout(r, 180));
    if (tt?.items) for (const t of tt.items) {
      const from = (t.from?.hash || "").toLowerCase(), to = (t.to?.hash || "").toLowerCase();
      const ex = EX[to] || EX[from] || exName(t.to?.name) || exName(t.from?.name);
      if (!ex) continue;
      const dir = (EX[to] || exName(t.to?.name)) ? "DEPOSIT" : "FROM";
      const dec = parseInt(t.token?.decimals || "18");
      const amt = parseFloat(t.total?.value || "0") / Math.pow(10, dec);
      hits.push({ wallet: w.address, label: w.label, role: w.role, dir, exchange: ex, amount: amt.toFixed(6), token: t.token?.symbol || "?", ts: t.timestamp || "", tx: t.transaction_hash || "", chain: ch });
    }

    const txs = await api(`${base}/addresses/${lo}/transactions`);
    await new Promise(r => setTimeout(r, 180));
    if (txs?.items) for (const t of txs.items) {
      const from = (t.from?.hash || "").toLowerCase(), to = (t.to?.hash || "").toLowerCase();
      const ex = EX[to] || EX[from] || exName(t.to?.name) || exName(t.from?.name);
      if (!ex) continue;
      const dir = (EX[to] || exName(t.to?.name)) ? "ETH_DEPOSIT" : "ETH_FROM";
      const val = parseInt(t.value || "0") / 1e18;
      hits.push({ wallet: w.address, label: w.label, role: w.role, dir, exchange: ex, amount: val.toFixed(8), token: "ETH", ts: t.timestamp || "", tx: t.hash || "", chain: ch });
    }

    if (c % 5 === 0) console.log(`  ${c}/${chunk.length}...`);
  }

  // Dedup
  const dm = new Map<string, Hit>();
  for (const h of hits) { const k = `${h.tx}-${h.wallet}-${h.dir}-${h.token}`; if (!dm.has(k)) dm.set(k, h); }
  const deduped = [...dm.values()];

  // Save to JSON
  const outFile = `/tmp/sweep_part${PART}.json`;
  fs.writeFileSync(outFile, JSON.stringify(deduped, null, 2));
  console.log(`\nPart ${PART}: ${c} wallets checked, ${deduped.length} exchange hits → ${outFile}`);

  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
