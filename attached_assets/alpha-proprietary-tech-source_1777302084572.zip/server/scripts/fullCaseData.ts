import { db } from "../db.js";
import { sql } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function main() {
  const w = await db.execute(sql`SELECT count(*)::int as c FROM monitored_wallets WHERE case_id = ${CASE_ID}`);
  const t = await db.execute(sql`SELECT count(*)::int as c FROM traced_transactions WHERE case_id = ${CASE_ID}`);
  const a = await db.execute(sql`SELECT count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID}`);
  
  const roles = await db.execute(sql`SELECT role, count(*)::int as c FROM monitored_wallets WHERE case_id = ${CASE_ID} GROUP BY role ORDER BY c DESC`);
  const chains = await db.execute(sql`SELECT chain, count(*)::int as c FROM monitored_wallets WHERE case_id = ${CASE_ID} GROUP BY chain ORDER BY c DESC`);
  
  const topByUsd = await db.execute(sql`SELECT address, label, role, chain, last_known_balance_eth, last_known_balance_usd, last_known_tokens FROM monitored_wallets WHERE case_id = ${CASE_ID} AND last_known_balance_usd > 0 ORDER BY last_known_balance_usd DESC LIMIT 30`);
  
  const txTypes = await db.execute(sql`SELECT tx_type, count(*)::int as c, sum(CAST(COALESCE(amount_usd,'0') AS numeric))::text as tusd FROM traced_transactions WHERE case_id = ${CASE_ID} GROUP BY tx_type ORDER BY c DESC`);
  
  const tokenFlows = await db.execute(sql`SELECT token_symbol, count(*)::int as c, sum(CAST(COALESCE(amount_usd,'0') AS numeric))::text as tusd FROM traced_transactions WHERE case_id = ${CASE_ID} AND token_symbol IS NOT NULL GROUP BY token_symbol ORDER BY sum(CAST(COALESCE(amount_usd,'0') AS numeric)) DESC LIMIT 20`);
  
  const exchanges = await db.execute(sql`SELECT exchange_name, count(*)::int as c, sum(CAST(COALESCE(amount_usd,'0') AS numeric))::text as tusd FROM traced_transactions WHERE case_id = ${CASE_ID} AND exchange_name IS NOT NULL GROUP BY exchange_name ORDER BY c DESC`);

  const launderAlerts = await db.execute(sql`SELECT alert_type, count(*)::int as c FROM forensic_alerts WHERE case_id = ${CASE_ID} AND alert_type IN ('tornado_cash_interaction','monero_conversion','unfreezable_token_movement') GROUP BY alert_type`);

  const wRows = (w as any).rows || w;
  const tRows = (t as any).rows || t;
  const aRows = (a as any).rows || a;
  console.log("=== CASE TOTALS ===");
  console.log("Wallets:", wRows[0]?.c);
  console.log("Traced Txs:", tRows[0]?.c);
  console.log("Alerts:", aRows[0]?.c);
  
  console.log("\n=== WALLET ROLES ===");
  for (const r of ((roles as any).rows || roles)) console.log(`  ${r.role}: ${r.c}`);
  
  console.log("\n=== CHAINS ===");
  for (const c of ((chains as any).rows || chains)) console.log(`  ${c.chain}: ${c.c}`);
  
  console.log("\n=== TOP 30 WALLETS BY USD VALUE ===");
  for (const w of ((topByUsd as any).rows || topByUsd)) {
    const tokens = w.last_known_tokens ? Object.entries(w.last_known_tokens as Record<string, number>).filter(([,v]) => v > 0.01).map(([s,v]) => `${(v as number).toFixed(2)} ${s}`).join(', ') : '';
    console.log(`  $${parseFloat(w.last_known_balance_usd || '0').toFixed(2)} | ${w.address} | ${w.label || w.role} (${w.chain}) | ETH: ${parseFloat(w.last_known_balance_eth || '0').toFixed(6)} | Tokens: ${tokens || 'none'}`);
  }
  
  console.log("\n=== TX TYPES ===");
  for (const t of ((txTypes as any).rows || txTypes)) console.log(`  ${t.tx_type}: ${t.c} txs ($${parseFloat(t.tusd || '0').toFixed(2)})`);
  
  console.log("\n=== TOKEN FLOWS ===");
  for (const t of ((tokenFlows as any).rows || tokenFlows)) console.log(`  ${t.token_symbol}: ${t.c} flows ($${parseFloat(t.tusd || '0').toFixed(2)})`);
  
  console.log("\n=== EXCHANGE INTERACTIONS ===");
  for (const e of ((exchanges as any).rows || exchanges)) console.log(`  ${e.exchange_name}: ${e.c} txs ($${parseFloat(e.tusd || '0').toFixed(2)})`);

  console.log("\n=== LAUNDERING ALERTS ===");
  for (const la of ((launderAlerts as any).rows || launderAlerts)) console.log(`  ${la.alert_type}: ${la.c}`);

  process.exit(0);
}
main();
