/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_BLACKLIST_CHECK_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_Blacklist_Calibration_PROTECTED
 */
import { db } from "../db.js";
import { monitoredWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const RPC = "https://ethereum-rpc.publicnode.com";
const USDC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
const USDT = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function check(addr: string, contract: string, sel: string): Promise<boolean | null> {
  try {
    const p = addr.replace("0x","").toLowerCase();
    const r = await fetch(RPC, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({jsonrpc:"2.0",method:"eth_call",params:[{to:contract,data:`0x${sel}000000000000000000000000${p}`},"latest"],id:1}),
      signal: AbortSignal.timeout(8000),
    });
    const d = await r.json();
    if (!d?.result || d.result === "0x") return null;
    return parseInt(d.result, 16) === 1;
  } catch { return null; }
}

async function main() {
  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
  
  // Get unique Ethereum addresses
  const ethAddrs = new Map<string, string>();
  
  // Key addresses first
  const keys = [
    ["0x658370618BBc885865df66c1061BfE4771FaD846", "Crypto.com Suspect Wallet"],
    ["0xD14F4B36E1D1D98c218db782c49149876042BC56", "FXUSD Source"],
    ["0x6818809EefCe719E480a7526D76bD3e561526b46", "Relay Proxy"],
    ["0xEC15c20015e72748F03065ed80c41cb882E3fB66", "Relayer"],
    ["0x46340b20830761efd32832A74d7169B29FEB9758", "Crypto.com Hot Wallet 2"],
    ["0x6fe0fab2164d8e0d03ad6a628e2af78624060322", "Victim Wallet"],
    ["0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41", "Victim Wallet 2"],
    ["0xf70da97812cb96acdf810712aa562db8dfa3dbef", "POI / GFF ($4.35M)"],
    ["0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb", "Source Wallet (EIP-7702)"],
    ["0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7", "Gas Funder"],
    ["0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872", "Laundering Hub"],
    ["0x423d2b61952d56358db8b313ec7404a9582d4865", "Original Funder"],
  ];
  
  for (const [a, l] of keys) ethAddrs.set(a.toLowerCase(), l);
  
  // All non-victim, non-token_recipient Ethereum wallets
  for (const w of wallets) {
    const role = (w.role || "").toLowerCase();
    const chain = (w.chain || "").toLowerCase();
    if (chain === "arbitrum") continue;
    if (role === "token_recipient") continue;
    const lo = w.address.toLowerCase();
    if (!ethAddrs.has(lo)) ethAddrs.set(lo, `${w.label || ""} [${w.role || ""}]`);
  }

  console.log(`\n═══ USDC/USDT BLACKLIST CHECK — ${new Date().toISOString()} ═══`);
  console.log(`Checking ${ethAddrs.size} Ethereum addresses...\n`);

  let frozen = 0;
  let checked = 0;
  
  for (const [addr, label] of ethAddrs) {
    checked++;
    const usdcF = await check(addr, USDC, "fe575a87");
    const usdtF = await check(addr, USDT, "e47d6060");
    
    const usdcSt = usdcF === true ? "⛔ FROZEN" : "✓ Not frozen";
    const usdtSt = usdtF === true ? "⛔ FROZEN" : "✓ Not frozen";
    
    if (usdcF || usdtF) {
      frozen++;
      console.log(`★★★ FROZEN ★★★ ${addr}`);
      console.log(`  ${label}`);
      console.log(`  USDC: ${usdcSt}  |  USDT: ${usdtSt}\n`);
    } else {
      console.log(`  ${addr} | USDC: ${usdcSt} | USDT: ${usdtSt} | ${label}`);
    }
  }
  
  console.log(`\n═══ RESULTS ═══`);
  console.log(`Checked: ${checked} addresses`);
  console.log(`Frozen:  ${frozen}`);
  if (frozen === 0) {
    console.log(`\n⚠ NONE of the ${checked} addresses have been blacklisted.`);
    console.log(`Circle (USDC) and Tether (USDT) have NOT taken any freeze action.`);
    console.log(`The attacker can still freely move USDC and USDT tokens.`);
  } else {
    console.log(`\n★ ${frozen} address(es) have been frozen!`);
  }
  
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
