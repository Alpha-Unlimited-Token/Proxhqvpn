/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * Sends the RAVEDAO_DUMP — Alpha Proceeds Forward-Trace Engine™ report.
 * INTERNAL OWNER USE ONLY — sole recipient: alphaunlimitedtoken@gmail.com.
 * NOT for SillyTuna or SEAL distribution.
 *
 * White text forced inline (Gmail mobile strips <style> blocks).
 */

import fs from 'node:fs';
import path from 'node:path';
import { getUncachableSendGridClient } from '../services/sendgridService.js';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('RAVEDAO_DUMP Forward-Trace Email Sender');

const RECIPIENT = { email: 'alphaunlimitedtoken@gmail.com', name: 'Alpha Unlimited (Owner — Internal Only)' };

const ATTACHMENTS = [
  { path: 'contracts/atc/ravedao_forward_trace.html', filename: 'RAVEDAO-Forward-Trace.html', type: 'text/html' },
  { path: 'contracts/atc/ravedao_forward_trace.json', filename: 'RAVEDAO-Forward-Trace.json', type: 'application/json' },
  { path: 'contracts/atc/ravedao_forward_trace.ts', filename: 'RAVEDAO-Forward-Trace-Source.ts', type: 'text/plain' },
];

const NOW = new Date().toISOString();

const C = {
  bg: '#0A0A0A', panel: '#111111', panel2: '#1E293B', border: '#1E3A5F',
  text: '#FFFFFF', gold: '#FFD700', cyan: '#00D4FF', red: '#FF4444', orange: '#F59E0B', green: '#10B981',
};

function loadAttachments() {
  const out: any[] = [];
  for (const a of ATTACHMENTS) {
    const full = path.resolve(a.path);
    if (!fs.existsSync(full)) { console.log(`  [skip] ${a.path} not found`); continue; }
    const data = fs.readFileSync(full);
    const sizeMb = data.length / 1024 / 1024;
    if (sizeMb > 25) { console.log(`  [skip] ${a.path} too large (${sizeMb.toFixed(1)}MB)`); continue; }
    out.push({ content: data.toString('base64'), filename: a.filename, type: a.type, disposition: 'attachment' });
    console.log(`  [attach] ${a.filename} (${sizeMb.toFixed(2)}MB)`);
  }
  return out;
}

interface FwdTrace {
  proprietary: any;
  case: any;
  technology: string;
  runMeta: any;
  aggregate: {
    byCategory: Record<string, { totalUsd: number; uniqueEndpoints: number }>;
    grandTotalUsd: number;
    uniqueTerminalsTotal: number;
    totalEdges: number;
    topEndpoints: { address: string; label: string | null; category: string; totalUsd: number; dumperHits: number }[];
  };
  traces: { dumpRank: number; dumper: string; tokensSold: number; totalProceedsUsd: number; totalHopsExplored: number; edges: any[] }[];
}

function loadData(): FwdTrace {
  return JSON.parse(fs.readFileSync(path.resolve('contracts/atc/ravedao_forward_trace.json'), 'utf-8'));
}

function fmtUsd(n: number): string {
  if (Math.abs(n) >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (Math.abs(n) >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

function buildHtml(): string {
  const d = loadData();
  const { aggregate, traces, runMeta } = d;

  const sec = (titleColor: string, title: string, body: string, bg = C.panel, border = C.border) =>
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${bg};border:1px solid ${border};border-radius:8px;margin-bottom:16px;"><tr><td style="padding:20px;">
      <div style="color:${titleColor};font-size:15px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;border-bottom:1px solid ${border};padding-bottom:8px;margin-bottom:14px;">${title}</div>
      ${body}
    </td></tr></table>`;
  const li = (html: string) =>
    `<div style="color:${C.text};font-size:13px;font-family:Segoe UI,Arial,sans-serif;margin:6px 0;padding-left:16px;line-height:1.55;">• ${html}</div>`;
  const stat = (val: string, label: string, color = C.gold) =>
    `<td align="center" valign="middle" style="background:${C.panel2};border:1px solid #334155;border-radius:6px;padding:14px 8px;width:25%;">
      <div style="color:${color};font-size:20px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;">${val}</div>
      <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;margin-top:4px;">${label}</div>
    </td>`;

  const endpointRows = aggregate.topEndpoints.slice(0, 18).map((e, i) => `
    <tr>
      <td style="padding:8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:12px;width:30px;">#${i + 1}</td>
      <td style="padding:8px;border-bottom:1px solid ${C.border};color:${C.gold};font-family:Consolas,monospace;font-size:11px;">${e.address}</td>
      <td style="padding:8px;border-bottom:1px solid ${C.border};color:${C.cyan};font-family:Segoe UI,Arial,sans-serif;font-size:11px;">${e.label || '<unlabeled EOA>'}</td>
      <td style="padding:8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:11px;">${e.category}</td>
      <td align="right" style="padding:8px;border-bottom:1px solid ${C.border};color:${C.green};font-family:Segoe UI,Arial,sans-serif;font-size:13px;font-weight:bold;">${fmtUsd(e.totalUsd)}</td>
      <td align="right" style="padding:8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:11px;">${e.dumperHits}</td>
    </tr>`).join('');

  const dumperRows = [...traces]
    .sort((a, b) => b.totalProceedsUsd - a.totalProceedsUsd)
    .slice(0, 12).map(t => `
    <tr>
      <td style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:12px;">#${t.dumpRank}</td>
      <td style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.gold};font-family:Consolas,monospace;font-size:11px;">${t.dumper}</td>
      <td align="right" style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:12px;">${(t.tokensSold || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
      <td align="right" style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.green};font-family:Segoe UI,Arial,sans-serif;font-size:12px;font-weight:bold;">${fmtUsd(t.totalProceedsUsd || 0)}</td>
      <td align="right" style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:11px;">${t.totalHopsExplored}</td>
      <td align="right" style="padding:7px 8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:11px;">${(t.edges || []).length}</td>
    </tr>`).join('');

  const catRows = Object.entries(aggregate.byCategory)
    .sort((a, b) => b[1].totalUsd - a[1].totalUsd)
    .map(([cat, v]) => `
    <tr>
      <td style="padding:8px;border-bottom:1px solid ${C.border};color:${C.cyan};font-family:Segoe UI,Arial,sans-serif;font-size:12px;font-weight:bold;text-transform:uppercase;">${cat.replace(/_/g, ' ')}</td>
      <td align="right" style="padding:8px;border-bottom:1px solid ${C.border};color:${C.green};font-family:Segoe UI,Arial,sans-serif;font-size:13px;font-weight:bold;">${fmtUsd(v.totalUsd)}</td>
      <td align="right" style="padding:8px;border-bottom:1px solid ${C.border};color:${C.text};font-family:Segoe UI,Arial,sans-serif;font-size:12px;">${v.uniqueEndpoints}</td>
    </tr>`).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="background:${C.bg};margin:0;padding:0;font-family:Segoe UI,Arial,sans-serif;color:${C.text};">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};"><tr><td align="center" style="padding:24px;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="880" style="max-width:880px;width:100%;">

  <tr><td style="background:linear-gradient(135deg,#064E3B 0%,#022c22 100%);background-color:#064E3B;border:2px solid ${C.green};border-radius:12px;padding:28px;text-align:center;">
    <div style="color:${C.green};font-size:24px;font-weight:bold;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:8px;">💰 RAVEDAO_DUMP — PROCEEDS FORWARD-TRACE</div>
    <div style="color:#A7F3D0;font-size:14px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:6px;">Alpha Proceeds Forward-Trace Engine™ · Where the dump money went</div>
    <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;">Token: 0x17205fab260a7a6383a81452cE6315A39370Db97 (RaveDAO / RAVE) · Generated ${NOW}</div>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td style="background:#1a0000;border:2px dashed ${C.red};border-radius:8px;padding:14px;text-align:center;">
    <div style="color:${C.red};font-size:12px;font-weight:bold;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;">⚠ INTERNAL USE ONLY — DO NOT FORWARD TO SILLYTUNA OR SEAL TEAM ⚠</div>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td>${sec(C.green, '🎯 Headline — Total Dump Proceeds Traced', `
    <table role="presentation" cellpadding="0" cellspacing="6" border="0" width="100%"><tr>
      ${stat(fmtUsd(aggregate.grandTotalUsd), 'Total proceeds traced', C.green)}
      ${stat(`${aggregate.uniqueTerminalsTotal}`, 'Unique terminal endpoints', C.green)}
      ${stat(`${traces.length}`, 'Dumpers traced', C.green)}
      ${stat(`${aggregate.totalEdges}`, 'Hop edges recorded', C.cyan)}
    </tr></table>
    <div style="color:${C.text};font-size:13px;font-family:Segoe UI,Arial,sans-serif;margin-top:14px;line-height:1.55;">
      The Alpha Proceeds Forward-Trace Engine™ followed every dollar leaving each top dumper's wallet, classified each terminal address (CEX deposit / bridge / mixer / swap service / DEX router / resting EOA), and aggregated by category. Result: <b style="color:${C.green};">${fmtUsd(aggregate.grandTotalUsd)}</b> across <b style="color:${C.green};">${aggregate.uniqueTerminalsTotal}</b> distinct end-of-trace addresses.
    </div>
  `, '#064E3B22', C.green)}</td></tr>

  <tr><td>${sec(C.cyan, '📊 Proceeds by Endpoint Category', `
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};border-radius:6px;">
      <tr style="background:${C.panel2};">
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:12px;font-weight:bold;">Category</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:12px;font-weight:bold;">USD Total</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:12px;font-weight:bold;">Endpoints</td>
      </tr>
      ${catRows}
    </table>
    <div style="color:${C.text};font-size:12px;font-family:Segoe UI,Arial,sans-serif;margin-top:10px;line-height:1.55;">
      <b style="color:${C.orange};">Note:</b> All ${aggregate.uniqueTerminalsTotal} terminals classified as <b style="color:${C.green};">RESTING_EOA</b> — proceeds parked in unlabeled externally-owned accounts within the 96h trace window. None hit a known CEX / bridge / mixer / swap-service address at hop 1. <b style="color:${C.cyan};">This is the operational handoff layer</b> — every recovery action should subpoena Etherscan for the funding history of these 18 wallets to obtain the next-hop CEX deposits.
    </div>
  `)}</td></tr>

  <tr><td>${sec(C.cyan, '🎯 Top 18 Terminal Endpoints (Where The Money Rests)', `
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};border-radius:6px;">
      <tr style="background:${C.panel2};">
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">#</td>
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Address</td>
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Label</td>
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Category</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">USD</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Hits</td>
      </tr>
      ${endpointRows}
    </table>
  `)}</td></tr>

  <tr><td>${sec(C.cyan, '👤 Per-Dumper Proceeds (Top 12 by USD)', `
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};border-radius:6px;">
      <tr style="background:${C.panel2};">
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Rank</td>
        <td style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Dumper Address</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">RAVE Sold</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">USD Out</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Nodes</td>
        <td align="right" style="padding:10px;color:${C.gold};font-family:Segoe UI,Arial,sans-serif;font-size:11px;font-weight:bold;">Edges</td>
      </tr>
      ${dumperRows}
    </table>
  `)}</td></tr>

  <tr><td>${sec(C.cyan, '🔧 Methodology — Alpha Proceeds Forward-Trace Engine™', `
    ${li(`<b style="color:${C.gold};">Inputs:</b> 20 top dumpers from RAVEDAO_DUMP analysis (sorted by RAVE volume).`)}
    ${li(`<b style="color:${C.gold};">BFS sweep:</b> ${runMeta.maxHops}-hop forward trace from each dumper, top ${runMeta.maxBranchesPerHop} branches per hop, ${runMeta.windowHours}h window.`)}
    ${li(`<b style="color:${C.gold};">Per-hop classification:</b> CEX deposit / bridge / mixer / swap service / DEX router / resting EOA / contract-other (using Alpha Address Label Database™ + on-chain code lookup).`)}
    ${li(`<b style="color:${C.gold};">USD valuation:</b> Per-asset spot pricing (ETH / WETH / stablecoins / WBTC / blue-chip ERC-20s) applied to every outbound edge.`)}
    ${li(`<b style="color:${C.gold};">Aggregation:</b> Per-(destination,asset) edge folding to suppress double-counting; per-category and per-endpoint totals.`)}
    ${li(`<b style="color:${C.gold};">Terminal early-stop:</b> BFS halts at known terminals AND any unrecognised contract (DEX routers / swap pools) to avoid leakage into unrelated downstream traffic.`)}
  `)}</td></tr>

  <tr><td>${sec(C.green, '🎯 Recommended Next Action', `
    ${li(`<b style="color:${C.text};">Subpoena-prep package:</b> The 18 terminal addresses above are the <b style="color:${C.green};">handoff custodians</b> — request KYC funding history from Etherscan for each.`)}
    ${li(`<b style="color:${C.text};">Cross-reference with Ringleader Profile:</b> Compare these 18 against the prime ringleader (0x1ab4973a…8f8f23) and secondary (0x0d070796…0b492fe) — overlapping addresses confirm the same operator cluster.`)}
    ${li(`<b style="color:${C.text};">Run hop-2 expansion on the top-5 endpoints:</b> $2.08M / $618K / $396K / $385K / $300K — those resting wallets almost certainly route to Binance HW14/15/16 / Coinbase 10 / Gate.io on the next hop.`)}
    ${li(`<b style="color:${C.text};">Schedule re-run:</b> Re-run the Forward-Trace Engine in 72h with a wider window — proceeds tend to consolidate to CEX deposits within 5-10 days post-dump.`)}
  `, '#064E3B22', C.green)}</td></tr>

  <tr><td>${sec(C.cyan, '📎 Attachments', `
    ${li(`<b style="color:${C.text};">RAVEDAO-Forward-Trace.html</b> — Interactive viewer with all per-dumper trace edges, terminal classifications and USD totals`)}
    ${li(`<b style="color:${C.text};">RAVEDAO-Forward-Trace.json</b> — Complete machine-readable dataset (every node, every edge, every terminal)`)}
    ${li(`<b style="color:${C.text};">RAVEDAO-Forward-Trace-Source.ts</b> — Source code of the Forward-Trace Engine (for reproducibility)`)}
  `)}</td></tr>

  <tr><td style="text-align:center;padding-top:12px;">
    <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;line-height:1.6;">
      © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.<br>
      PROPRIETARY AND CONFIDENTIAL · Title 17 · DMCA · CFAA · DTSA<br>
      Generated by Alpha Proceeds Forward-Trace Engine™ · Alpha Address Label Database™ · Alpha Forensic Intelligence Engine™ · Alpha Proprietary Software Guard™
    </div>
  </td></tr>

</table>
</td></tr></table>
</body></html>`;
}

function buildText(): string {
  const d = loadData();
  const { aggregate, traces } = d;
  const top = aggregate.topEndpoints.slice(0, 18);
  return `RAVEDAO_DUMP — PROCEEDS FORWARD-TRACE (INTERNAL OWNER COPY ONLY)
Token: 0x17205fab260a7a6383a81452cE6315A39370Db97 (RaveDAO / RAVE)
Generated: ${NOW}

⚠ DO NOT FORWARD TO SILLYTUNA OR SEAL TEAM — INTERNAL USE ONLY ⚠

HEADLINE — TOTAL DUMP PROCEEDS TRACED
=====================================
Total proceeds traced:    ${fmtUsd(aggregate.grandTotalUsd)}
Unique terminal endpoints: ${aggregate.uniqueTerminalsTotal}
Dumpers traced:           ${traces.length}
Hop edges recorded:       ${aggregate.totalEdges}

PROCEEDS BY ENDPOINT CATEGORY
=============================
${Object.entries(aggregate.byCategory)
  .sort((a, b) => b[1].totalUsd - a[1].totalUsd)
  .map(([cat, v]) => `  ${cat.padEnd(20)} ${fmtUsd(v.totalUsd).padStart(10)}  (${v.uniqueEndpoints} endpoints)`)
  .join('\n')}

TOP 18 TERMINAL ENDPOINTS (WHERE THE MONEY RESTS)
=================================================
${top.map((e, i) => `  #${(i + 1).toString().padStart(2)}  ${e.address}  ${(e.label || '<unlabeled EOA>').padEnd(24)} ${e.category.padEnd(12)} ${fmtUsd(e.totalUsd).padStart(10)}  hits=${e.dumperHits}`).join('\n')}

RECOMMENDED NEXT ACTIONS
========================
1. Subpoena-prep: request KYC funding history for the 18 terminal addresses above.
2. Cross-reference with Ringleader Profile (prime: 0x1ab4973a…8f8f23, secondary: 0x0d070796…0b492fe).
3. Run hop-2 expansion on the top-5 endpoints (highest USD totals).
4. Schedule a re-run in 72h with a wider window — proceeds consolidate to CEX deposits within 5-10 days.

ATTACHMENTS
===========
- RAVEDAO-Forward-Trace.html        (interactive viewer)
- RAVEDAO-Forward-Trace.json        (complete dataset)
- RAVEDAO-Forward-Trace-Source.ts   (source code)

---
© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
PROPRIETARY AND CONFIDENTIAL · Title 17 · DMCA · CFAA · DTSA
`;
}

async function main() {
  console.log('=== RAVEDAO_DUMP — PROCEEDS FORWARD-TRACE EMAIL ===');
  console.log(`Recipient: ${RECIPIENT.email}  (NOT SillyTuna · NOT SEAL)`);
  console.log('Loading attachments:');
  const attachments = loadAttachments();

  const { client, fromEmail } = await getUncachableSendGridClient();
  const html = buildHtml();
  const text = buildText();
  const subject = '💰 RAVEDAO_DUMP — Proceeds Forward-Trace Report (Internal Owner Copy · Where The Dump Money Went)';

  console.log(`\n→ Sending to ${RECIPIENT.name} <${RECIPIENT.email}> ...`);
  try {
    await client.send({
      to: { email: RECIPIENT.email, name: RECIPIENT.name },
      from: { email: fromEmail, name: 'Alpha Unlimited — Forensic Intelligence (Internal)' },
      subject,
      content: [
        { type: 'text/plain', value: text },
        { type: 'text/html', value: html },
      ],
      attachments,
    });
    console.log(`  ✅ SENT to ${RECIPIENT.email}`);
  } catch (e: any) {
    console.log(`  ❌ FAILED: ${e?.message || e}`);
    if (e?.response?.body) console.log(`     ${JSON.stringify(e.response.body).slice(0, 500)}`);
    process.exit(1);
  }
  console.log('\n=== Done ===');
}

main().catch(e => { console.error(e); process.exit(1); });
