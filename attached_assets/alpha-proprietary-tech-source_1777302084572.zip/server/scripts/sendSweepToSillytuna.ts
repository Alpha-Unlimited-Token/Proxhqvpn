/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SEND_SWEEP_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_SendSweep_Calibration_PROTECTED
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const TO = "sillytuna@gmail.com";

async function main() {
  console.log("[SendSweep] Preparing complete exchange sweep report...");

  const tmp = `/tmp/sweep_send_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-Complete-Exchange-Sweep");
  fs.mkdirSync(zipDir, { recursive: true });

  fs.copyFileSync(
    path.resolve("forensic_full_exchange_sweep.txt"),
    path.join(zipDir, "COMPLETE Exchange Sweep — All 66 Wallets vs 60+ KYC Exchanges.txt")
  );
  fs.copyFileSync(
    path.resolve("forensic_live_activity_alert.txt"),
    path.join(zipDir, "LIVE Activity Alert — 211 New Transactions Detected.txt")
  );

  const zipPath = path.join(tmp, "sweep.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-Complete-Exchange-Sweep/"`, { timeout: 15000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`[SendSweep] ZIP: ${zipKb} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();

  const emailBody = `Dear @sillytuna,

Complete exchange sweep results attached — we checked EVERY wallet in the case
(all 66 wallets) against 60+ known KYC exchange addresses.

══════════════════════════════════════════════════════════════════
RESULTS: 5 KYC EXCHANGES IDENTIFIED — 35 INTERACTIONS
══════════════════════════════════════════════════════════════════

1. BINANCE — 29 interactions (25 deposits, 4 withdrawals) — 5 wallets
   ★ PRIMARY EXCHANGE USED BY THE ATTACKER
   Subpoena: law-enforcement@binance.com
   Connected wallets:
     • 0x7f72c73dc7d3badb2000edb1e11135eaae33cc2c (Destination, 0.0187 ETH via Gas Funder)
     • 0x48916d83049adc30c49105493c700e4945434ec1 (Destination, 0.0103 ETH via Gas Funder)
     • 0x0bed139e66c6b80e193627e144544e57d53f629c (Destination, via Original Funder)
     • 0x9f3ca7a2ef8e55f665cde43c0c5b4f8672aedda5 (Destination, via Gas Funder)
     • 0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41 (Victim Secondary)

2. CRYPTO.COM — 2 interactions (0 deposits, 2 withdrawals) — 2 wallets
   ★ KYC PROOF — Exchange funded suspect wallet
   Subpoena: compliance@crypto.com (Foris DAX MT Ltd.)
   Connected wallets:
     • 0x658370618BBc885865df66c1061BfE4771FaD846 (Suspect — $155K USDC)
     • 0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41 (Victim Secondary)

3. COINBASE — 2 interactions (0 deposits, 2 withdrawals) — 2 wallets
   Subpoena: law-enforcement@coinbase.com
   Connected wallets:
     • 0x0439e60f02a8900a951603950d8d4527f400c3f1 (Destination)
     • 0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41 (Victim Secondary)

4. FTX — 1 interaction (0 deposits, 1 withdrawal) — 1 wallet
   ★ KYC RECORDS IN BANKRUPTCY ESTATE
   Contact: Kroll (FTX claims administrator)
   Connected wallet:
     • 0x423d2b61952d56358db8b313ec7404a9582d4865 (Original Funder)

5. GATE.IO — 1 interaction (0 deposits, 1 withdrawal) — 1 wallet
   Subpoena: support@gate.io
   Connected wallet:
     • 0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f (Destination)

══════════════════════════════════════════════════════════════════
KEY FINDINGS
══════════════════════════════════════════════════════════════════

• BINANCE IS THE PRIMARY EXCHANGE — 25 deposits from attacker wallets.
  The attacker has been depositing USDC, USDT, NEWT, OPEN, KITE, and FRAX.
  This is likely the main cash-out channel.

• 5 different attacker wallets are connected to Binance, meaning
  the attacker may have multiple Binance accounts or is using
  a single account with multiple deposit addresses.

• The Victim's Secondary wallet also interacted with Binance, Crypto.com,
  and Coinbase — these may be the victim's own exchange accounts,
  but law enforcement should verify.

• No interactions found with: Kraken, KuCoin, Bitfinex, Bitget, Bybit,
  MEXC, Gemini, Bitstamp, Upbit, Bittrex, Poloniex, ChangeNOW, FixedFloat,
  Huobi/HTX, or any other tracked exchange.

══════════════════════════════════════════════════════════════════
SUBPOENA PRIORITY ORDER
══════════════════════════════════════════════════════════════════

1. BINANCE (HIGHEST) — 25 deposits, 5 wallets, main cash-out
2. CRYPTO.COM — KYC'd suspect wallet with $155K USDC
3. COINBASE — 2 withdrawals to attacker destination
4. FTX ESTATE — Original Funder identity records
5. GATE.IO — 1 withdrawal to destination wallet

Full report with every TX hash attached.

CONFIDENTIAL — For the victim and law enforcement only.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com`;

  await client.send({
    to: TO,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: "Complete Exchange Sweep: 5 KYC Exchanges Found — Binance (25 deposits), Crypto.com, Coinbase, FTX, Gate.io",
    text: emailBody,
    attachments: [{
      content: zipBuf.toString("base64"),
      filename: `Sillytuna-Complete-Exchange-Sweep-${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[SendSweep] ✓ Email sent to ${TO}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "report_sent",
    severity: "critical",
    message: `Complete exchange sweep sent to ${TO}: 66 wallets checked, 5 KYC exchanges found (Binance 29, Crypto.com 2, Coinbase 2, FTX 1, Gate.io 1), 35 total interactions`,
    walletAddress: "system",
    details: {
      recipientEmail: TO,
      fromAddress: fromEmail,
      zipSizeKb: zipKb,
      walletsChecked: 66,
      exchangeInteractions: 35,
      exchanges: { "Binance": 29, "Crypto.com": 2, "Coinbase": 2, "FTX": 1, "Gate.io": 1 },
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("[SendSweep] Done.");
  process.exit(0);
}
main().catch(e => { console.error("FATAL:", e); process.exit(1); });
