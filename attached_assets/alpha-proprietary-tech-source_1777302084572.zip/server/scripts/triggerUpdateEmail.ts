import { db } from "../db.js";
import { sql } from "drizzle-orm";

async function main() {
  console.log("Triggering immediate hourly update with new analytics data...");
  
  const resp = await fetch("http://localhost:5000/api/forensic/hourly-email/trigger", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Cookie": "connect.sid=admin" },
    credentials: "include"
  });
  
  if (resp.ok) {
    const data = await resp.json();
    console.log("Trigger response:", JSON.stringify(data));
  } else {
    console.log("Status:", resp.status, "- Need to trigger directly...");
    const { triggerImmediateUpdate } = await import("../services/hourlyForensicEmail.js");
    await triggerImmediateUpdate();
    console.log("Triggered directly via module import");
  }
  
  setTimeout(() => process.exit(0), 5000);
}
main().catch(e => { console.error(e); process.exit(1); });
