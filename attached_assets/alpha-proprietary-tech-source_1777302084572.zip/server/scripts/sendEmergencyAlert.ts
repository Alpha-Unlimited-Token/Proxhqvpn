/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_EMERGENCY_ALERT_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_EmergencyAlert_Calibration_PROTECTED
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";

const RECIPIENTS = [
  { email: "tips@securityalliance.org", name: "SEAL 911" },
  { email: "sillytuna@gmail.com", name: "sillytuna" },
];

async function main() {
  console.log("[EmergencyAlert] Sending emergency live activity alert...");

  const reportPath = path.resolve("forensic_emergency_live_alert.txt");
  if (!fs.existsSync(reportPath)) {
    console.error("Report not found");
    process.exit(1);
  }

  const reportText = fs.readFileSync(reportPath, "utf-8");
  const reportSize = (Buffer.byteLength(reportText) / 1024).toFixed(1);
  console.log(`  Report: ${reportSize} KB`);

  const tmp = `/tmp/emergency_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-Emergency-Live-Alert");
  fs.mkdirSync(zipDir, { recursive: true });

  fs.copyFileSync(reportPath, path.join(zipDir, "[8] EMERGENCY Live Activity Alert — POI Active NOW.txt"));

  const prevReports = [
    "forensic_multichain_scan_report.txt",
    "forensic_master_fxusd_trace.txt",
    "forensic_full_exchange_sweep.txt",
  ];
  for (const f of prevReports) {
    if (fs.existsSync(path.resolve(f))) {
      fs.copyFileSync(path.resolve(f), path.join(zipDir, f));
    }
  }

  const zipPath = path.join(tmp, "emergency.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-Emergency-Live-Alert/"`, { timeout: 15000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`  ZIP: ${zipKb} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();

  const subject = "EMERGENCY: @sillytuna Theft — POI Wallet ACTIVELY Moving Funds NOW — Relay Protocol Cross-Chain — Report #8";

  const emailBody = [
    "EMERGENCY ALERT — POI WALLET IS ACTIVELY MOVING FUNDS RIGHT NOW",
    "",
    "Case: @sillytuna (Alex Amsel) — Physical/Twitter Theft (~$24M)",
    "",
    "The Person of Interest wallet (0xf70da97812cb96acdf810712aa562db8dfa3dbef) is",
    "currently executing rapid-fire transactions across MULTIPLE chains simultaneously.",
    "",
    "ACTIVE ON: Ethereum, Arbitrum, Optimism, Polygon, Base — ALL within the last hour.",
    "",
    "INFRASTRUCTURE IDENTIFIED:",
    "The POI is using RELAY PROTOCOL (relay.link) for cross-chain movement:",
    "  - RelayRouter — 0xF5042e6ffaC5a625d4e7848e0b01373d8eb9e222",
    "  - RelayRouterV3 — 0xb92fe925DC43a0ecDE6C8b1a2709c170ec4fff4f",
    "  - RelayDepository — 0x4cD00E387622c35BdDB9b4c962c136462338Bc31",
    "",
    "KEY FLOWS DETECTED:",
    "  - $65,623 received from RelayDepository to POI wallet (USDC + USDT0)",
    "  - $9,381 routed through RelayRouter (cross-chain swaps)",
    "  - $7,963 sent to unidentified EOA 0xf677c5fb60Cf...",
    "  - $3,810 accumulated via RelayRouterV3",
    "  - Multiple $100-$2,000 transfers to 17 new destination wallets",
    "",
    "TOKENS BEING MOVED: USDC, USDT, USDT0 (Stargate), USDe",
    "",
    "RECOMMENDED IMMEDIATE ACTIONS:",
    "1. Contact Relay Protocol — block POI address, obtain records",
    "2. Exchange freeze — POI active on 5+ chains, potential deposits",
    "3. Circle/Tether — request blacklist of POI address",
    "4. Trace wallet 0xf677c5fb60Cf... — received $7,963 USDC",
    "",
    "Full detailed report with every transaction hash attached.",
    "This is report #8 in our ongoing investigation.",
    "",
    "— Alpha Unlimited Trading, Forensic Intelligence Engine™",
  ].join("\n");

  for (const recipient of RECIPIENTS) {
    console.log(`\n  Sending to ${recipient.name} (${recipient.email})...`);
    try {
      const [response] = await client.send({
        to: recipient.email,
        from: fromEmail,
        subject,
        text: emailBody,
        attachments: [{
          content: zipBuf.toString("base64"),
          filename: "Sillytuna-Emergency-Live-Alert.zip",
          type: "application/zip",
          disposition: "attachment" as const,
        }],
      });
      console.log(`  ✓ Sent to ${recipient.name}: HTTP ${response.statusCode}`);
    } catch (err: any) {
      console.error(`  ✗ Failed:`, err?.response?.body || err.message);
    }
  }

  console.log("\n[EmergencyAlert] ✓ All emergency alerts sent.");
  fs.rmSync(tmp, { recursive: true, force: true });
}

main().catch(e => { console.error(e); process.exit(1); });
