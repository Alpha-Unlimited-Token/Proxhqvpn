/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_SEAL_UPDATE_v2.0
 * ALPHA_INTEGRITY_SEAL: AUT_SealUpdate_Calibration_PROTECTED
 */

import { db } from "../db.js";
import { eq, desc, asc } from "drizzle-orm";
import { forensicCases, monitoredWallets, forensicAlerts, tracedTransactions, freezeRequests } from "@shared/schema";
import { getUncachableSendGridClient } from "../services/sendgridService.js";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENTS = [
  { email: "tips@securityalliance.org", name: "SEAL 911" },
  { email: "sillytuna@gmail.com", name: "sillytuna (Alex Amsel)" },
];

const STABLECOIN_SYMBOLS = ["USDC", "USDT", "DAI", "USDE", "PYUSD", "MUSD", "sDAI", "LUSD", "BUSD", "TUSD", "FXUSD"];

function computeWalletValue(w: any): number {
  let val = w.lastKnownBalanceUsd || 0;
  const tokens = (w.lastKnownTokens || {}) as Record<string, number>;
  for (const [sym, amount] of Object.entries(tokens)) {
    if (STABLECOIN_SYMBOLS.includes(sym)) val += amount;
  }
  return val;
}

function fmtUsd(n: number): string {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtAddr(addr: string): string {
  if (!addr || addr.length < 14) return addr || "unknown";
  return addr.slice(0, 10) + "..." + addr.slice(-6);
}

function fmtDate(d: any): string {
  if (!d) return "N/A";
  return new Date(d).toLocaleString("en-US", { timeZone: "UTC", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) + " UTC";
}

async function main() {
  console.log("[SealUpdate] Generating comprehensive SEAL 911 update...\n");

  const caseData = (await db.select().from(forensicCases).where(eq(forensicCases.id, CASE_ID)).limit(1))[0];
  if (!caseData) { console.error("Case not found"); process.exit(1); }

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const alerts = await db.select().from(forensicAlerts).where(eq(forensicAlerts.caseId, CASE_ID)).orderBy(asc(forensicAlerts.createdAt));
  const txs = await db.select().from(tracedTransactions).where(eq(tracedTransactions.caseId, CASE_ID)).orderBy(asc(tracedTransactions.timestamp));
  const freezeReqs = await db.select().from(freezeRequests).where(eq(freezeRequests.caseId, CASE_ID));

  console.log(`  Case: ${caseData.caseName}`);
  console.log(`  Wallets: ${wallets.length}, Alerts: ${alerts.length}, Traced Txs: ${txs.length}, Freeze Reqs: ${freezeReqs.length}`);

  const autoDiscRoles = ["token_recipient", "token_sender"];
  const coreWallets = wallets.filter(w => !autoDiscRoles.includes(w.role || ""));
  const discoveredWallets = wallets.filter(w => autoDiscRoles.includes(w.role || ""));
  const victimWallets = coreWallets.filter(w => (w.role || "").toLowerCase().includes("victim"));
  const poiWallets = coreWallets.filter(w => ["poi", "attacker"].some(r => (w.role || "").toLowerCase().includes(r)) || (w.label || "").toLowerCase().includes("person of interest"));

  let coreHoldings = 0;
  for (const w of coreWallets) coreHoldings += computeWalletValue(w);
  let discoveredHoldings = 0;
  for (const w of discoveredWallets) discoveredHoldings += computeWalletValue(w);

  const totalStolen = (caseData.totalStolenUsd as number) || 0;
  const totalRecovered = (caseData.totalRecoveredUsd as number) || 0;

  const exchangeMap = new Map<string, { deposits: number; withdrawals: number; txCount: number; chains: Set<string> }>();
  for (const tx of txs) {
    if (!tx.exchangeName) continue;
    if (!exchangeMap.has(tx.exchangeName)) {
      exchangeMap.set(tx.exchangeName, { deposits: 0, withdrawals: 0, txCount: 0, chains: new Set() });
    }
    const ex = exchangeMap.get(tx.exchangeName)!;
    ex.txCount++;
    ex.chains.add(tx.chain || "ethereum");
    const usd = parseFloat(tx.amountUsd || "0");
    if (tx.direction === "outbound") ex.deposits += usd;
    else ex.withdrawals += usd;
  }

  let exchangeDepositsTotal = 0;
  for (const [, data] of exchangeMap) exchangeDepositsTotal += data.deposits;

  const chainMap = new Map<string, { txCount: number; totalUsd: number; wallets: Set<string> }>();
  for (const tx of txs) {
    const chain = tx.chain || "ethereum";
    if (!chainMap.has(chain)) chainMap.set(chain, { txCount: 0, totalUsd: 0, wallets: new Set() });
    const c = chainMap.get(chain)!;
    c.txCount++;
    c.totalUsd += parseFloat(tx.amountUsd || "0");
    if (tx.fromAddress) c.wallets.add(tx.fromAddress.toLowerCase());
    if (tx.toAddress) c.wallets.add(tx.toAddress.toLowerCase());
  }

  const tornadoAlerts = alerts.filter(a => a.alertType === "tornado_cash_interaction");
  const moneroAlerts = alerts.filter(a => a.alertType === "monero_conversion");
  const unfreezeAlerts = alerts.filter(a => a.alertType === "unfreezable_token_movement");
  const exchangeDepositAlerts = alerts.filter(a => a.alertType === "token_exchange_deposit" || a.alertType === "native_exchange_deposit");
  const returnAlerts = alerts.filter(a => a.alertType === "token_returned_to_victim" || a.alertType === "native_returned_to_victim");

  const significantTxs = txs
    .filter(tx => parseFloat(tx.amountUsd || "0") > 100)
    .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  const topHops = new Map<string, { totalSentUsd: number; totalReceivedUsd: number; label: string; chains: Set<string>; sentTo: Set<string>; receivedFrom: Set<string> }>();
  for (const tx of txs) {
    const from = (tx.fromAddress || "").toLowerCase();
    const to = (tx.toAddress || "").toLowerCase();
    const usd = parseFloat(tx.amountUsd || "0");

    if (from) {
      if (!topHops.has(from)) topHops.set(from, { totalSentUsd: 0, totalReceivedUsd: 0, label: tx.fromLabel || "", chains: new Set(), sentTo: new Set(), receivedFrom: new Set() });
      const h = topHops.get(from)!;
      h.totalSentUsd += usd;
      h.chains.add(tx.chain || "ethereum");
      if (to) h.sentTo.add(to);
      if (tx.fromLabel && !h.label) h.label = tx.fromLabel;
    }
    if (to) {
      if (!topHops.has(to)) topHops.set(to, { totalSentUsd: 0, totalReceivedUsd: 0, label: tx.toLabel || "", chains: new Set(), sentTo: new Set(), receivedFrom: new Set() });
      const h = topHops.get(to)!;
      h.totalReceivedUsd += usd;
      h.chains.add(tx.chain || "ethereum");
      if (from) h.receivedFrom.add(from);
      if (tx.toLabel && !h.label) h.label = tx.toLabel;
    }
  }

  const sortedHops = Array.from(topHops.entries())
    .map(([addr, data]) => ({ addr, ...data, totalVolume: data.totalSentUsd + data.totalReceivedUsd }))
    .sort((a, b) => b.totalVolume - a.totalVolume)
    .slice(0, 30);

  const now = new Date();
  const reportDate = now.toLocaleDateString("en-US", { timeZone: "UTC", year: "numeric", month: "long", day: "numeric" });

  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background-color:#0a0e17;font-family:Arial,Helvetica,sans-serif;color:#e5e7eb;">
<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0a0e17;padding:20px 0;">
<tr><td align="center">
<table width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;">

<!-- Header -->
<tr><td style="background:linear-gradient(135deg,#0e1a2e,#1a2744);padding:28px 32px;border-radius:12px 12px 0 0;border-bottom:3px solid #ef4444;">
  <table width="100%"><tr>
    <td>
      <h1 style="margin:0;font-size:22px;color:#06b6d4;">Alpha Unlimited Trading</h1>
      <p style="margin:4px 0 0;color:#9ca3af;font-size:13px;">Forensic Intelligence Engine™ — Comprehensive Case Update</p>
    </td>
    <td align="right">
      <span style="background:#7f1d1d;color:#fca5a5;padding:4px 14px;border-radius:20px;font-size:12px;font-weight:bold;">ACTIVE CASE</span>
    </td>
  </tr></table>
</td></tr>

<!-- Case Overview -->
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#e5e7eb;font-size:16px;margin:0 0 16px;">Case: ${caseData.caseName}</h2>
  <table width="100%" cellpadding="4" cellspacing="0" style="font-size:13px;">
    <tr><td style="color:#9ca3af;width:200px;">Victim</td><td style="color:#e5e7eb;">${caseData.victimHandle || "N/A"} (Alex Amsel)</td></tr>
    <tr><td style="color:#9ca3af;">Victim Wallet</td><td style="color:#93c5fd;font-family:monospace;font-size:12px;">${caseData.victimAddress || "N/A"}</td></tr>
    <tr><td style="color:#9ca3af;">Crime Type</td><td style="color:#e5e7eb;">Physical + Twitter account theft</td></tr>
    <tr><td style="color:#9ca3af;">Investigation Since</td><td style="color:#e5e7eb;">${fmtDate(caseData.createdAt)}</td></tr>
    <tr><td style="color:#9ca3af;">Report Date</td><td style="color:#e5e7eb;">${reportDate}</td></tr>
    <tr><td style="color:#9ca3af;">Chains Involved</td><td style="color:#e5e7eb;">${caseData.chains || "ethereum"}</td></tr>
  </table>
</td></tr>

<!-- Executive Fund Flow -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#ef4444;font-size:18px;margin:0 0 4px;">Where Is the Money Now?</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 20px;">Complete breakdown of stolen fund movements from theft to present</p>

  <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
    <tr><td style="background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:16px;text-align:center;">
      <div style="color:#9ca3af;font-size:11px;text-transform:uppercase;letter-spacing:1px;">Total Stolen (Estimated)</div>
      <div style="color:#ef4444;font-size:32px;font-weight:bold;margin:4px 0;">${fmtUsd(totalStolen)}</div>
    </td></tr>
  </table>

  <table width="100%" cellpadding="6" cellspacing="6">
    <tr>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:10px;text-transform:uppercase;">Core Wallets (${coreWallets.length})</div>
        <div style="color:#f97316;font-size:22px;font-weight:bold;">${fmtUsd(coreHoldings)}</div>
        <div style="color:#6b7280;font-size:10px;">Attacker-controlled addresses</div>
      </td>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:10px;text-transform:uppercase;">Recipient Wallets (${discoveredWallets.length})</div>
        <div style="color:#eab308;font-size:22px;font-weight:bold;">${fmtUsd(discoveredHoldings)}</div>
        <div style="color:#6b7280;font-size:10px;">Funds forwarded from core wallets</div>
      </td>
    </tr>
    <tr>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:10px;text-transform:uppercase;">Exchange Deposits</div>
        <div style="color:#a78bfa;font-size:22px;font-weight:bold;">${fmtUsd(exchangeDepositsTotal)}</div>
        <div style="color:#6b7280;font-size:10px;">Sent to centralized exchanges</div>
      </td>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:10px;text-transform:uppercase;">Recovered</div>
        <div style="color:#10b981;font-size:22px;font-weight:bold;">${fmtUsd(totalRecovered)}</div>
        <div style="color:#6b7280;font-size:10px;">Frozen or returned</div>
      </td>
    </tr>
  </table>

  <table width="100%" cellpadding="4" cellspacing="0" style="font-size:13px;margin-top:16px;border-top:1px solid #1e3a5f;padding-top:12px;">
    <tr><td style="color:#9ca3af;">Total wallets under surveillance</td><td align="right" style="color:#06b6d4;font-weight:bold;">${wallets.length}</td></tr>
    <tr><td style="color:#9ca3af;">Traced transactions</td><td align="right" style="color:#e5e7eb;">${txs.length.toLocaleString()}</td></tr>
    <tr><td style="color:#9ca3af;">Forensic alerts generated</td><td align="right" style="color:#e5e7eb;">${alerts.length.toLocaleString()}</td></tr>
  </table>
</td></tr>

<!-- Money Trail: Step-by-Step -->
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 4px;">Complete Money Trail — Theft to Present</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 20px;">Every significant fund movement (>${"$"}100) in chronological order</p>

  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:12px;">
    <tr style="border-bottom:2px solid #1e3a5f;">
      <th align="left" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">Date</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">From</th>
      <th align="center" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">→</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">To</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">Amount</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;font-weight:bold;">Chain</th>
    </tr>
    ${significantTxs.slice(0, 100).map((tx, i) => {
      const usd = parseFloat(tx.amountUsd || "0");
      const isExchange = !!tx.exchangeName;
      const isVictimReturn = tx.txType === "return_to_victim";
      const rowBg = i % 2 === 0 ? "#0d1420" : "#111827";
      const amtColor = isVictimReturn ? "#10b981" : (isExchange ? "#a78bfa" : (usd > 10000 ? "#ef4444" : usd > 1000 ? "#f97316" : "#e5e7eb"));
      const fromLabel = tx.fromLabel || fmtAddr(tx.fromAddress || "");
      const toLabel = tx.toLabel || (tx.exchangeName ? `${tx.exchangeName}` : fmtAddr(tx.toAddress || ""));
      return `<tr style="background:${rowBg};border-bottom:1px solid #1a2744;">
        <td style="padding:6px 4px;color:#9ca3af;white-space:nowrap;">${tx.timestamp ? new Date(tx.timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}</td>
        <td style="padding:6px 4px;color:#93c5fd;font-family:monospace;" title="${tx.fromAddress || ""}">${fromLabel.length > 28 ? fromLabel.slice(0, 28) + "..." : fromLabel}</td>
        <td align="center" style="padding:6px 2px;color:#6b7280;">→</td>
        <td style="padding:6px 4px;color:${isExchange ? "#a78bfa" : isVictimReturn ? "#10b981" : "#93c5fd"};font-family:monospace;" title="${tx.toAddress || ""}">${isExchange ? "🏦 " : ""}${toLabel.length > 28 ? toLabel.slice(0, 28) + "..." : toLabel}</td>
        <td align="right" style="padding:6px 4px;color:${amtColor};font-weight:bold;white-space:nowrap;">${fmtUsd(usd)}${tx.tokenSymbol ? ` <span style="color:#6b7280;font-weight:normal;">${tx.tokenSymbol}</span>` : ""}</td>
        <td style="padding:6px 4px;color:#6b7280;">${tx.chain || "eth"}</td>
      </tr>`;
    }).join("")}
    ${significantTxs.length > 100 ? `<tr><td colspan="6" style="padding:10px 4px;color:#9ca3af;font-size:12px;">... and ${significantTxs.length - 100} more significant transactions (full data in forensic database)</td></tr>` : ""}
  </table>
</td></tr>

<!-- Top Addresses by Volume -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 4px;">Key Addresses by Transaction Volume</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 16px;">Top addresses involved in the money flow — highest volume first</p>

  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:12px;">
    <tr style="border-bottom:2px solid #1e3a5f;">
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Address</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Label</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Sent</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Received</th>
      <th align="center" style="padding:8px 4px;color:#9ca3af;">Chains</th>
      <th align="center" style="padding:8px 4px;color:#9ca3af;">Connections</th>
    </tr>
    ${sortedHops.map((h, i) => {
      const rowBg = i % 2 === 0 ? "#0d1420" : "#111827";
      return `<tr style="background:${rowBg};border-bottom:1px solid #1a2744;">
        <td style="padding:6px 4px;color:#93c5fd;font-family:monospace;">${fmtAddr(h.addr)}</td>
        <td style="padding:6px 4px;color:#e5e7eb;">${h.label || "—"}</td>
        <td align="right" style="padding:6px 4px;color:#ef4444;">${fmtUsd(h.totalSentUsd)}</td>
        <td align="right" style="padding:6px 4px;color:#10b981;">${fmtUsd(h.totalReceivedUsd)}</td>
        <td align="center" style="padding:6px 4px;color:#9ca3af;">${Array.from(h.chains).join(", ")}</td>
        <td align="center" style="padding:6px 4px;color:#9ca3af;">${h.sentTo.size + h.receivedFrom.size}</td>
      </tr>`;
    }).join("")}
  </table>
</td></tr>

<!-- Exchange Activity -->
${exchangeMap.size > 0 ? `
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#a78bfa;font-size:16px;margin:0 0 4px;">🏦 Exchange Activity</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 16px;">Where stolen funds have been deposited for potential liquidation</p>

  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;">
    <tr style="border-bottom:2px solid #1e3a5f;">
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Exchange</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Deposits</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Withdrawals</th>
      <th align="center" style="padding:8px 4px;color:#9ca3af;">Transactions</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Chains</th>
    </tr>
    ${Array.from(exchangeMap.entries()).sort(([, a], [, b]) => b.deposits - a.deposits).map(([name, data]) =>
      `<tr style="border-bottom:1px solid #1a2744;">
        <td style="padding:8px 4px;color:#e5e7eb;font-weight:bold;">${name}</td>
        <td align="right" style="padding:8px 4px;color:#ef4444;font-weight:bold;">${fmtUsd(data.deposits)}</td>
        <td align="right" style="padding:8px 4px;color:#10b981;">${fmtUsd(data.withdrawals)}</td>
        <td align="center" style="padding:8px 4px;color:#9ca3af;">${data.txCount}</td>
        <td style="padding:8px 4px;color:#9ca3af;">${Array.from(data.chains).join(", ")}</td>
      </tr>`
    ).join("")}
  </table>
</td></tr>` : ""}

<!-- Chain Analysis -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 4px;">⛓️ Multi-Chain Activity Breakdown</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 16px;">Transaction activity across all blockchains involved in the theft</p>

  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;">
    <tr style="border-bottom:2px solid #1e3a5f;">
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Chain</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Transactions</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Volume</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Unique Addresses</th>
    </tr>
    ${Array.from(chainMap.entries()).sort(([, a], [, b]) => b.totalUsd - a.totalUsd).map(([chain, data]) =>
      `<tr style="border-bottom:1px solid #1a2744;">
        <td style="padding:8px 4px;color:#e5e7eb;font-weight:bold;text-transform:capitalize;">${chain}</td>
        <td align="right" style="padding:8px 4px;color:#9ca3af;">${data.txCount.toLocaleString()}</td>
        <td align="right" style="padding:8px 4px;color:#fbbf24;font-weight:bold;">${fmtUsd(data.totalUsd)}</td>
        <td align="right" style="padding:8px 4px;color:#9ca3af;">${data.wallets.size}</td>
      </tr>`
    ).join("")}
  </table>
</td></tr>

<!-- Laundering Risk -->
${(tornadoAlerts.length > 0 || moneroAlerts.length > 0 || unfreezeAlerts.length > 0) ? `
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#ef4444;font-size:16px;margin:0 0 4px;">🧹 Laundering Activity Detected</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 16px;">Known laundering techniques used by the attacker</p>

  <table width="100%" cellpadding="8" cellspacing="0" style="font-size:13px;">
    ${tornadoAlerts.length > 0 ? `<tr><td style="background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:14px;">
      <div style="color:#ef4444;font-weight:bold;font-size:14px;">Tornado Cash Interactions: ${tornadoAlerts.length}</div>
      <div style="color:#d1d5db;font-size:12px;margin-top:6px;">DAI and other unfreezable tokens sent through Tornado Cash mixing contracts. These funds are extremely difficult to trace or recover.</div>
      ${tornadoAlerts.slice(0, 5).map(a => `<div style="color:#fca5a5;font-size:11px;margin-top:4px;border-top:1px solid #7f1d1d;padding-top:4px;">${a.message}</div>`).join("")}
      ${tornadoAlerts.length > 5 ? `<div style="color:#9ca3af;font-size:11px;margin-top:4px;">... and ${tornadoAlerts.length - 5} more Tornado Cash alerts</div>` : ""}
    </td></tr><tr><td style="height:8px;"></td></tr>` : ""}

    ${moneroAlerts.length > 0 ? `<tr><td style="background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:14px;">
      <div style="color:#ef4444;font-weight:bold;font-size:14px;">Monero Conversion Attempts: ${moneroAlerts.length}</div>
      <div style="color:#d1d5db;font-size:12px;margin-top:6px;">Funds sent to known Monero on-ramp services (Wagyu Bridge, ChangeNOW, FixedFloat, etc.). Estimated ~$2.47M converted to Monero — likely unrecoverable.</div>
      ${moneroAlerts.slice(0, 5).map(a => `<div style="color:#fca5a5;font-size:11px;margin-top:4px;border-top:1px solid #7f1d1d;padding-top:4px;">${a.message}</div>`).join("")}
      ${moneroAlerts.length > 5 ? `<div style="color:#9ca3af;font-size:11px;margin-top:4px;">... and ${moneroAlerts.length - 5} more Monero alerts</div>` : ""}
    </td></tr><tr><td style="height:8px;"></td></tr>` : ""}

    ${unfreezeAlerts.length > 0 ? `<tr><td style="background:#1a0a0a;border:1px solid #713f12;border-radius:8px;padding:14px;">
      <div style="color:#eab308;font-weight:bold;font-size:14px;">Unfreezable Token Movements: ${unfreezeAlerts.length}</div>
      <div style="color:#d1d5db;font-size:12px;margin-top:6px;">DAI, WETH, LUSD and other tokens that cannot be frozen or blacklisted by any central authority were moved to unknown addresses.</div>
      ${unfreezeAlerts.slice(0, 5).map(a => `<div style="color:#fde047;font-size:11px;margin-top:4px;border-top:1px solid #713f12;padding-top:4px;">${a.message}</div>`).join("")}
      ${unfreezeAlerts.length > 5 ? `<div style="color:#9ca3af;font-size:11px;margin-top:4px;">... and ${unfreezeAlerts.length - 5} more alerts</div>` : ""}
    </td></tr>` : ""}
  </table>
</td></tr>` : ""}

<!-- POI Wallets -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#f97316;font-size:16px;margin:0 0 4px;">Person(s) of Interest — Wallet Details</h2>
  <p style="color:#6b7280;font-size:12px;margin:0 0 16px;">${poiWallets.length} attacker-controlled wallet(s)</p>

  ${poiWallets.map(w => {
    const val = computeWalletValue(w);
    const tokenStr = w.lastKnownTokens && typeof w.lastKnownTokens === "object"
      ? Object.entries(w.lastKnownTokens as Record<string, number>)
          .filter(([, v]) => v > 0.001)
          .sort(([, a], [, b]) => b - a)
          .map(([s, v]) => `${v.toFixed(4)} ${s}`)
          .join(", ")
      : "";
    return `<div style="background:#111827;border:1px solid #7c2d12;border-radius:8px;padding:14px;margin-bottom:10px;">
      <div style="color:#93c5fd;font-family:monospace;font-size:13px;word-break:break-all;">${w.address}</div>
      <div style="color:#f97316;font-size:13px;font-weight:bold;margin-top:4px;">${w.label || w.role || "POI"}</div>
      <table width="100%" cellpadding="2" style="font-size:12px;margin-top:8px;">
        <tr><td style="color:#9ca3af;width:120px;">Chain</td><td style="color:#e5e7eb;">${w.chain}</td></tr>
        <tr><td style="color:#9ca3af;">Balance</td><td style="color:#fbbf24;font-weight:bold;">${fmtUsd(val)}</td></tr>
        ${tokenStr ? `<tr><td style="color:#9ca3af;">Tokens</td><td style="color:#d1d5db;">${tokenStr}</td></tr>` : ""}
        <tr><td style="color:#9ca3af;">Last Activity</td><td style="color:#e5e7eb;">${fmtDate(w.lastActivity)}</td></tr>
        <tr><td style="color:#9ca3af;">Status</td><td style="color:#e5e7eb;">${w.status}</td></tr>
      </table>
    </div>`;
  }).join("")}
</td></tr>

<!-- Freeze Requests -->
${freezeReqs.length > 0 ? `
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#c084fc;font-size:16px;margin:0 0 16px;">🧊 Exchange Freeze Requests (${freezeReqs.length})</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;">
    <tr style="border-bottom:2px solid #1e3a5f;">
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Exchange</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Status</th>
      <th align="right" style="padding:8px 4px;color:#9ca3af;">Est. Value</th>
      <th align="left" style="padding:8px 4px;color:#9ca3af;">Filed</th>
    </tr>
    ${freezeReqs.map(f => {
      const statusColor = f.status === "frozen" || f.status === "acknowledged" ? "#10b981" : f.status === "rejected" ? "#ef4444" : "#eab308";
      return `<tr style="border-bottom:1px solid #1a2744;">
        <td style="padding:8px 4px;color:#e5e7eb;font-weight:bold;">${f.exchangeName}</td>
        <td style="padding:8px 4px;"><span style="color:${statusColor};font-weight:bold;text-transform:uppercase;">${f.status || "pending"}</span></td>
        <td align="right" style="padding:8px 4px;color:#fbbf24;">${fmtUsd((f.estimatedValueUsd as number) || 0)}</td>
        <td style="padding:8px 4px;color:#9ca3af;">${fmtDate(f.createdAt)}</td>
      </tr>`;
    }).join("")}
  </table>
</td></tr>` : ""}

<!-- Surveillance Status -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 16px;">📡 Active Surveillance Status</h2>
  <table width="100%" cellpadding="6" cellspacing="0" style="font-size:13px;">
    <tr><td style="color:#9ca3af;">Core wallets (directly linked to theft)</td><td align="right" style="color:#e5e7eb;font-weight:bold;">${coreWallets.length}</td></tr>
    <tr><td style="color:#9ca3af;">Auto-discovered recipient wallets</td><td align="right" style="color:#e5e7eb;font-weight:bold;">${discoveredWallets.length}</td></tr>
    <tr><td style="color:#9ca3af;">Total under 24/7 surveillance</td><td align="right" style="color:#06b6d4;font-weight:bold;">${wallets.length}</td></tr>
    <tr><td style="color:#9ca3af;">Monitoring frequency</td><td align="right" style="color:#10b981;">Real-time (core wallets every 15s)</td></tr>
    <tr><td style="color:#9ca3af;">Token flow tracing</td><td align="right" style="color:#10b981;">Active</td></tr>
    <tr><td style="color:#9ca3af;">Hourly victim email updates</td><td align="right" style="color:#10b981;">Active</td></tr>
    <tr><td style="color:#9ca3af;">Exchange deposit detection</td><td align="right" style="color:#10b981;">Active</td></tr>
    <tr><td style="color:#9ca3af;">Tornado Cash monitoring</td><td align="right" style="color:#10b981;">Active</td></tr>
    <tr><td style="color:#9ca3af;">Monero on-ramp detection</td><td align="right" style="color:#10b981;">Active</td></tr>
  </table>
</td></tr>

<!-- Footer -->
<tr><td style="background:#0e1a2e;padding:24px 32px;border-radius:0 0 12px 12px;border-top:2px solid #1e3a5f;">
  <p style="color:#9ca3af;font-size:13px;margin:0 0 12px;">
    This report contains the complete fund flow history from the initial theft through all subsequent transfers, splits, exchange deposits, laundering attempts, and current wallet balances. Our systems continue to monitor all ${wallets.length} wallets 24/7.
  </p>
  <p style="color:#9ca3af;font-size:13px;margin:0 0 16px;">
    Any new fund movements, exchange deposits, or suspicious activity will trigger immediate alerts.
  </p>
  <div style="text-align:center;color:#6b7280;font-size:11px;border-top:1px solid #1e3a5f;padding-top:16px;">
    CONFIDENTIAL — For SEAL 911 team, victim, and law enforcement use only<br>
    Alpha Unlimited Trading Company — Forensic Intelligence Division<br>
    forensics@alphaunlimitedtrading.com<br>
    ${now.toISOString()}<br>
    © 2024-2026 All Rights Reserved
  </div>
</td></tr>

</table>
</td></tr></table>
</body></html>`;

  const plainText = `ALPHA UNLIMITED TRADING — FORENSIC INTELLIGENCE ENGINE
COMPREHENSIVE CASE UPDATE — ${reportDate}
${"=".repeat(72)}

Case: ${caseData.caseName}
Victim: ${caseData.victimHandle} (Alex Amsel)
Victim Wallet: ${caseData.victimAddress}
Crime: Physical + Twitter account theft
Investigation Since: ${fmtDate(caseData.createdAt)}

${"=".repeat(72)}
WHERE IS THE MONEY NOW?
${"=".repeat(72)}

Total Stolen (Estimated):     ${fmtUsd(totalStolen)}
Core Wallet Holdings:          ${fmtUsd(coreHoldings)} (${coreWallets.length} wallets)
Recipient Wallet Holdings:     ${fmtUsd(discoveredHoldings)} (${discoveredWallets.length} auto-discovered)
Exchange Deposits:             ${fmtUsd(exchangeDepositsTotal)}
Recovered:                     ${fmtUsd(totalRecovered)}
Total Wallets Monitored:       ${wallets.length}
Traced Transactions:           ${txs.length.toLocaleString()}

${"=".repeat(72)}
COMPLETE MONEY TRAIL (transactions > $100)
${"=".repeat(72)}

${significantTxs.slice(0, 100).map(tx => {
    const usd = parseFloat(tx.amountUsd || "0");
    const from = tx.fromLabel || fmtAddr(tx.fromAddress || "");
    const to = tx.toLabel || (tx.exchangeName || fmtAddr(tx.toAddress || ""));
    return `[${tx.timestamp ? new Date(tx.timestamp).toISOString().split("T")[0] : "N/A"}] ${from} → ${to} | ${fmtUsd(usd)} ${tx.tokenSymbol || ""} | ${tx.chain || "eth"}`;
  }).join("\n")}
${significantTxs.length > 100 ? `... and ${significantTxs.length - 100} more transactions` : ""}

${"=".repeat(72)}
KEY ADDRESSES BY VOLUME
${"=".repeat(72)}

${sortedHops.slice(0, 20).map(h => `${fmtAddr(h.addr)} | ${h.label || "Unknown"} | Sent: ${fmtUsd(h.totalSentUsd)} | Received: ${fmtUsd(h.totalReceivedUsd)} | Chains: ${Array.from(h.chains).join(",")}`).join("\n")}

${"=".repeat(72)}
EXCHANGE ACTIVITY
${"=".repeat(72)}

${Array.from(exchangeMap.entries()).sort(([, a], [, b]) => b.deposits - a.deposits).map(([name, data]) => `${name}: Deposited ${fmtUsd(data.deposits)} | Withdrawn ${fmtUsd(data.withdrawals)} | ${data.txCount} txs | Chains: ${Array.from(data.chains).join(",")}`).join("\n")}

${"=".repeat(72)}
LAUNDERING ACTIVITY
${"=".repeat(72)}

Tornado Cash interactions: ${tornadoAlerts.length}
Monero conversion attempts: ${moneroAlerts.length}
Unfreezable token movements: ${unfreezeAlerts.length}

${"=".repeat(72)}
POI WALLETS
${"=".repeat(72)}

${poiWallets.map(w => `${w.address} (${w.chain})\n  ${w.label || w.role} | Balance: ${fmtUsd(computeWalletValue(w))} | Last: ${fmtDate(w.lastActivity)}`).join("\n\n")}

${"=".repeat(72)}
ACTIVE SURVEILLANCE: ${wallets.length} wallets monitored in real-time (core wallets every 15s, event-driven updates)

CONFIDENTIAL — For SEAL 911, victim, and law enforcement only.
Alpha Unlimited Trading — Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
${now.toISOString()}
`;

  const subject = `Case Update: @sillytuna ~$24M Theft — Complete Fund Flow Report — ${reportDate}`;

  const { client, fromEmail } = await getUncachableSendGridClient();

  for (const recipient of RECIPIENTS) {
    console.log(`\n  Sending to ${recipient.name} (${recipient.email})...`);
    try {
      const [response] = await client.send({
        to: recipient.email,
        from: { email: fromEmail, name: "Alpha Unlimited Trading — Forensic Intelligence" },
        subject,
        text: plainText,
        html: html,
      });
      console.log(`  ✓ Sent to ${recipient.name}: HTTP ${response.statusCode}`);
    } catch (err: any) {
      console.error(`  ✗ Failed:`, err?.response?.body || err.message);
    }
  }

  try {
    await db.insert(forensicAlerts).values({
      caseId: CASE_ID,
      alertType: "report_sent",
      severity: "info",
      message: `Comprehensive SEAL 911 case update sent to ${RECIPIENTS.map(r => r.email).join(", ")} with complete fund flow trail (${txs.length} txs, ${wallets.length} wallets)`,
      walletAddress: "system",
      details: {
        recipients: RECIPIENTS.map(r => r.email),
        tracedTransactions: txs.length,
        walletsMonitored: wallets.length,
        significantTxs: significantTxs.length,
        exchangeDeposits: exchangeDepositsTotal,
        sentAt: now.toISOString()
      }
    });
  } catch {}

  console.log("\n[SealUpdate] ✓ All updates sent. Alert logged.");
  process.exit(0);
}

main().catch(e => { console.error("[SealUpdate] FATAL:", e); process.exit(1); });
