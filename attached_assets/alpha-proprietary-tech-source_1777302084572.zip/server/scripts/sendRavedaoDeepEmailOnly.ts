/* © 2024-2026 Alpha Unlimited Trading Company. Email-only sender for the deep
 * forward-trace bundle. Reads pre-generated JSON+HTML and emails OWNER ONLY. */
import * as fs from 'fs';
import * as path from 'path';
import { getUncachableSendGridClient } from '../services/sendgridService.js';

const OUT_JSON = 'contracts/atc/ravedao_deep_forward_trace.json';
const OUT_HTML = 'contracts/atc/ravedao_deep_forward_trace.html';
const RECIPIENT = { email: 'alphaunlimitedtoken@gmail.com', name: 'Alpha Unlimited Token (Owner)' };

const fmtUsd = (n: number) =>
  Math.abs(n) >= 1e9 ? `$${(n / 1e9).toFixed(2)}B`
  : Math.abs(n) >= 1e6 ? `$${(n / 1e6).toFixed(2)}M`
  : Math.abs(n) >= 1e3 ? `$${(n / 1e3).toFixed(1)}K`
  : `$${n.toFixed(2)}`;
const esc = (s: any) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function buildSummaryHtml(meta: any, agg: any): string {
  const verdictRows = Object.entries(agg.whereIsItNow as Record<string, any>).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd).map(([v, info]: any) =>
    `<tr><td style="padding:6px 10px;color:#fff;font-size:12px;border-bottom:1px solid #334155;">${esc(v)}</td><td align="right" style="padding:6px 10px;color:#FFD700;font-family:Consolas,monospace;font-size:12px;border-bottom:1px solid #334155;">${fmtUsd(info.totalUsd)}</td><td align="right" style="padding:6px 10px;color:#22C55E;font-family:Consolas,monospace;font-size:12px;border-bottom:1px solid #334155;">${info.currentRestingUsd ? fmtUsd(info.currentRestingUsd) : '—'}</td><td align="right" style="padding:6px 10px;color:#fff;font-size:12px;border-bottom:1px solid #334155;">${info.count}</td></tr>`).join('');
  const topRows = (agg.topTerminals as any[]).slice(0, 15).map(e =>
    `<tr><td style="padding:5px 8px;color:#fff;font-size:11px;border-bottom:1px solid #334155;">${esc(e.label || '<unlabeled EOA>')}</td><td style="padding:5px 8px;color:#FFD700;font-size:9px;font-family:Consolas,monospace;border-bottom:1px solid #334155;">${esc(e.address)}</td><td style="padding:5px 8px;color:#86EFAC;font-size:10px;border-bottom:1px solid #334155;">${esc(e.whereIsItNow)}</td><td align="right" style="padding:5px 8px;color:#FFD700;font-family:Consolas,monospace;font-size:11px;border-bottom:1px solid #334155;">${fmtUsd(e.usd)}</td><td align="right" style="padding:5px 8px;color:#22C55E;font-family:Consolas,monospace;font-size:11px;border-bottom:1px solid #334155;">${e.currentBalanceUsd != null ? fmtUsd(e.currentBalanceUsd) : '—'}</td></tr>`).join('');
  return `<!DOCTYPE html><html><body style="background:#0A1628;color:#E2E8F0;font-family:Segoe UI,Arial,sans-serif;margin:0;padding:0;">
<div style="max-width:900px;margin:0 auto;padding:22px;">
  <div style="background:linear-gradient(135deg,#1E3A5F 0%,#0D2137 100%);border:2px solid #FFD700;border-radius:12px;padding:22px;margin-bottom:18px;text-align:center;">
    <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:1.2px;">RAVEDAO_DUMP — DEEP FORWARD-TRACE</div>
    <div style="color:#FFD700;font-size:13px;margin-top:6px;">${meta.maxHops}-hop BFS · ${meta.maxBranchesPerHop} branches/hop · ${meta.windowHours}h window</div>
    <div style="color:#94A3B8;font-size:11px;margin-top:4px;">Generated ${esc(meta.generated)} · INTERNAL OWNER COPY</div>
  </div>
  <div style="background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:18px;margin-bottom:14px;">
    <div style="color:#00D4FF;font-size:14px;font-weight:bold;margin-bottom:12px;">EXECUTIVE METRICS</div>
    <div style="display:inline-block;background:#1E293B;border:1px solid #334155;border-radius:6px;padding:10px 14px;margin:4px 6px 4px 0;"><b style="color:#FFD700;font-size:16px;">${fmtUsd(agg.grandTotalUsd)}</b><span style="color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px;">Total proceeds traced</span></div>
    <div style="display:inline-block;background:#1E293B;border:1px solid #334155;border-radius:6px;padding:10px 14px;margin:4px 6px 4px 0;"><b style="color:#22C55E;font-size:16px;">${fmtUsd(agg.currentRestingUsd)}</b><span style="color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px;">Still resting (USD now, capped)</span></div>
    <div style="display:inline-block;background:#1E293B;border:1px solid #334155;border-radius:6px;padding:10px 14px;margin:4px 6px 4px 0;"><b style="color:#FFD700;font-size:16px;">${agg.uniqueTerminals}</b><span style="color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px;">Unique terminals</span></div>
    <div style="display:inline-block;background:#1E293B;border:1px solid #334155;border-radius:6px;padding:10px 14px;margin:4px 6px 4px 0;"><b style="color:#FFD700;font-size:16px;">${agg.dumpersTraced}</b><span style="color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px;">Dumpers traced</span></div>
    <div style="display:inline-block;background:#1E293B;border:1px solid #334155;border-radius:6px;padding:10px 14px;margin:4px 6px 4px 0;"><b style="color:#FFD700;font-size:16px;">${agg.totalEdges}</b><span style="color:#94A3B8;font-size:10px;display:block;text-transform:uppercase;letter-spacing:1px;">Total edges</span></div>
  </div>
  <div style="background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:18px;margin-bottom:14px;">
    <div style="color:#00D4FF;font-size:14px;font-weight:bold;margin-bottom:12px;">WHERE IS THE MONEY NOW</div>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1E293B;border-radius:6px;">
      <tr><th align="left" style="background:#0F172A;color:#00D4FF;font-size:12px;padding:8px 10px;">Verdict</th><th align="right" style="background:#0F172A;color:#00D4FF;font-size:12px;padding:8px 10px;">USD routed</th><th align="right" style="background:#0F172A;color:#00D4FF;font-size:12px;padding:8px 10px;">USD now (capped)</th><th align="right" style="background:#0F172A;color:#00D4FF;font-size:12px;padding:8px 10px;">Endpoints</th></tr>
      ${verdictRows}
    </table>
    <div style="color:#94A3B8;font-size:10px;margin-top:8px;font-style:italic;">"USD now" capped at traced inflow per address (excess balance presumed unrelated funds, e.g. unlabeled CEX hot wallet).</div>
  </div>
  <div style="background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:18px;margin-bottom:14px;">
    <div style="color:#00D4FF;font-size:14px;font-weight:bold;margin-bottom:12px;">TOP 15 TERMINALS</div>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1E293B;border-radius:6px;">
      <tr><th align="left" style="background:#0F172A;color:#00D4FF;font-size:11px;padding:6px 8px;">Service / EOA</th><th align="left" style="background:#0F172A;color:#00D4FF;font-size:11px;padding:6px 8px;">Address</th><th align="left" style="background:#0F172A;color:#00D4FF;font-size:11px;padding:6px 8px;">Verdict</th><th align="right" style="background:#0F172A;color:#00D4FF;font-size:11px;padding:6px 8px;">USD in</th><th align="right" style="background:#0F172A;color:#00D4FF;font-size:11px;padding:6px 8px;">USD now</th></tr>
      ${topRows}
    </table>
  </div>
  <div style="font-size:11px;color:#94A3B8;text-align:center;padding:12px;border-top:1px solid #1E3A5F;">Full per-dumper detail in attached HTML report. Raw flow data in attached JSON.<br>© 2024-2026 Alpha Unlimited Trading Company · Alpha Proceeds Forward-Trace Engine™ (Deep Mode) · INTERNAL OWNER USE ONLY</div>
</div></body></html>`;
}

async function main() {
  const data = JSON.parse(fs.readFileSync(OUT_JSON, 'utf-8'));
  const summaryHtml = buildSummaryHtml(data.runMeta, data.aggregate);
  const stamp = new Date().toISOString().slice(0, 10);
  const attachments: any[] = [];
  for (const [p, type] of [[OUT_HTML, 'text/html'], [OUT_JSON, 'application/json']] as const) {
    const buf = fs.readFileSync(p);
    if (buf.length > 14 * 1024 * 1024) continue;
    attachments.push({ content: buf.toString('base64'), filename: path.basename(p), type, disposition: 'attachment' });
    console.log(`  attached ${path.basename(p)} (${(buf.length / 1024).toFixed(1)} KB)`);
  }
  const { client, fromEmail } = await getUncachableSendGridClient();
  const subject = `[INTERNAL · OWNER ONLY] RAVEDAO_DUMP — Deep Forward-Trace (${data.runMeta.maxHops} hops · ${fmtUsd(data.aggregate.grandTotalUsd)} traced · ${fmtUsd(data.aggregate.currentRestingUsd)} still resting now) — ${stamp}`;
  console.log(`→ Sending to ${RECIPIENT.email} …`);
  await client.send({
    to: { email: RECIPIENT.email, name: RECIPIENT.name },
    from: { email: fromEmail, name: 'Alpha Unlimited — Forensic Intelligence (Internal)' },
    subject,
    content: [
      { type: 'text/plain', value: `RAVEDAO_DUMP deep forward-trace complete.\nProceeds traced: ${fmtUsd(data.aggregate.grandTotalUsd)}\nCurrently resting (verified live balance, capped at traced inflow): ${fmtUsd(data.aggregate.currentRestingUsd)}\nUnique terminals: ${data.aggregate.uniqueTerminals}\nGenerated ${data.runMeta.generated}\n\nINTERNAL OWNER COPY ONLY.` },
      { type: 'text/html', value: summaryHtml },
    ],
    attachments,
  });
  console.log(`✅ SENT to ${RECIPIENT.email}`);
}
main().catch(e => { console.error(e); process.exit(1); });
