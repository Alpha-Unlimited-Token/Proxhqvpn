import { db } from "../db.js";
import { eq } from "drizzle-orm";
import { monitoredWallets } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const BLOCKSCOUT: Record<string, string> = { ethereum: "https://eth.blockscout.com/api/v2", arbitrum: "https://arbitrum.blockscout.com/api/v2" };

async function apiFetch(url: string): Promise<any> {
  try { const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(10000) }); if (!r.ok) return null; return await r.json(); } catch { return null; }
}

async function main() {
  const startTime = Date.now();
  const dir = path.resolve("private/forensic-exports");

  const existingProfiles = JSON.parse(fs.readFileSync(path.join(dir, "ALL-WALLET-PROFILES.json"), "utf-8"));
  const alreadyTraced = new Set(existingProfiles.map((p: any) => p.addr || p.address));
  console.log(`Already traced: ${alreadyTraced.size} wallets`);

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const remaining = wallets.filter(w => !alreadyTraced.has(w.address.toLowerCase()));
  console.log(`Remaining to trace: ${remaining.length}\n`);

  const results: any[] = [];
  for (let i = 0; i < remaining.length; i++) {
    if (Date.now() - startTime > 90000) { console.log(`TIME LIMIT at ${i + 1}/${remaining.length}`); break; }
    const w = remaining[i];
    const chain = w.chain || "ethereum";
    const base = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
    const addr = w.address.toLowerCase();

    const info = await apiFetch(`${base}/addresses/${addr}`);
    await new Promise(r => setTimeout(r, 80));
    const balance = info ? parseInt(info.coin_balance || "0") / 1e18 : 0;
    const isCont = info?.is_contract || false;

    let tokens: Record<string, number> = {};
    const td = await apiFetch(`${base}/addresses/${addr}/token-balances`);
    await new Promise(r => setTimeout(r, 80));
    if (Array.isArray(td)) for (const t of td) { const s = t.token?.symbol || "?"; const v = parseFloat(t.value || "0") / Math.pow(10, parseInt(t.token?.decimals || "18")); if (v > 0.001) tokens[s] = v; }

    const txs: any[] = [];
    const nd = await apiFetch(`${base}/addresses/${addr}/transactions?filter=from`);
    await new Promise(r => setTimeout(r, 80));
    if (nd?.items) for (const t of nd.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.hash, from: addr, to, ethVal: parseFloat(t.value || "0") / 1e18, timestamp: t.timestamp || "", type: "normal", chain, method: t.method || "" }); }

    const tt = await apiFetch(`${base}/addresses/${addr}/token-transfers?filter=from`);
    await new Promise(r => setTimeout(r, 80));
    if (tt?.items) for (const t of tt.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.transaction_hash || "", from: addr, to, ethVal: 0, timestamp: t.timestamp || "", type: "token", tokenSym: t.token?.symbol || "?", tokenAmt: parseFloat(t.total?.value || "0") / Math.pow(10, parseInt(t.token?.decimals || "18")), chain }); }

    const it = await apiFetch(`${base}/addresses/${addr}/internal-transactions?filter=from`);
    await new Promise(r => setTimeout(r, 80));
    if (it?.items) for (const t of it.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.transaction_hash || "", from: addr, to, ethVal: parseFloat(t.value || "0") / 1e18, timestamp: t.timestamp || "", type: "internal", chain }); }

    console.log(`${i + 1}/${remaining.length}: ${(w.label || addr).slice(0, 35)} | ${txs.length} txs | ${balance.toFixed(4)} ETH | ${Object.keys(tokens).length} tok`);
    results.push({ addr, chain, label: w.label || "", role: w.role || "", balance, tokens, isContract: isCont, txs, txCount: txs.length });
  }

  fs.writeFileSync(path.join(dir, "REMAINING-WALLETS.json"), JSON.stringify(results, null, 2));
  const allTxs = results.flatMap(r => r.txs.map((t: any) => ({ ...t, srcLabel: r.label, srcRole: r.role })));
  fs.writeFileSync(path.join(dir, "REMAINING-TRANSACTIONS.json"), JSON.stringify(allTxs, null, 2));

  const csv = ["Address,Chain,Label,Role,BalanceETH,IsContract,TxCount,Tokens"];
  for (const r of results) csv.push([r.addr, r.chain, `"${r.label}"`, `"${r.role}"`, r.balance.toFixed(8), r.isContract, r.txCount, `"${Object.entries(r.tokens).map(([s, v]) => `${s}:${v}`).join("; ")}"`].join(","));
  fs.writeFileSync(path.join(dir, "REMAINING-WALLETS.csv"), csv.join("\n"));

  const txCsv = ["Source,SourceLabel,SourceRole,Destination,Type,ETH,TokenSymbol,TokenAmount,TxHash,Timestamp,Chain"];
  for (const t of allTxs) txCsv.push([t.from, `"${t.srcLabel}"`, `"${t.srcRole}"`, t.to, t.type, t.ethVal?.toFixed(8) || "0", t.tokenSym || "", t.tokenAmt?.toFixed(8) || "", t.hash, t.timestamp, t.chain].join(","));
  fs.writeFileSync(path.join(dir, "REMAINING-TRANSACTIONS.csv"), txCsv.join("\n"));

  console.log(`\nDone: ${results.length} wallets, ${allTxs.length} transactions`);
  for (const f of fs.readdirSync(dir)) console.log(`  ${f} — ${(fs.statSync(path.join(dir, f)).size / 1024).toFixed(1)} KB`);
  process.exit(0);
}
main().catch(e => { console.error("FATAL:", e); process.exit(1); });
