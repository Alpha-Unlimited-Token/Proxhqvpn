/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * Sends the FULL RAVEDAO_DUMP forensic report — INTERNAL OWNER USE ONLY.
 * Sole recipient: alphaunlimitedtoken@gmail.com
 * Strictly NOT for SillyTuna or SEAL distribution.
 *
 * v2: Body text forced WHITE inline + Ringleader Profile included in email body.
 */

import fs from 'node:fs';
import path from 'node:path';
import { getUncachableSendGridClient } from '../services/sendgridService.js';

const RECIPIENT = { email: 'alphaunlimitedtoken@gmail.com', name: 'Alpha Unlimited (Owner — Internal Only)' };

const ATTACHMENTS = [
  { path: 'contracts/atc/ravedao_dump_analysis.html', filename: 'RAVEDAO-Dump-Forensic-Report.html', type: 'text/html' },
  { path: 'contracts/atc/ravedao_dump_analysis.json', filename: 'RAVEDAO-Dump-Full-Data.json', type: 'application/json' },
  { path: 'contracts/atc/ravedao_dump_analysis.ts', filename: 'RAVEDAO-Dump-Analysis-Source.ts', type: 'text/plain' },
];

const NOW = new Date().toISOString();

const C = {
  bg: '#0A0A0A', panel: '#111111', panel2: '#1E293B', border: '#1E3A5F',
  text: '#FFFFFF', gold: '#FFD700', cyan: '#00D4FF', red: '#FF4444', orange: '#F59E0B',
};

function loadAttachments() {
  const out: any[] = [];
  for (const a of ATTACHMENTS) {
    const full = path.resolve(a.path);
    if (!fs.existsSync(full)) { console.log(`  [skip] ${a.path} not found`); continue; }
    const data = fs.readFileSync(full);
    const sizeMb = data.length / 1024 / 1024;
    if (sizeMb > 25) { console.log(`  [skip] ${a.path} too large (${sizeMb.toFixed(1)}MB)`); continue; }
    out.push({ content: data.toString('base64'), filename: a.filename, type: a.type, disposition: 'attachment' });
    console.log(`  [attach] ${a.filename} (${sizeMb.toFixed(2)}MB)`);
  }
  return out;
}

function loadRingleaderData() {
  const r = JSON.parse(fs.readFileSync(path.resolve('contracts/atc/ravedao_dump_analysis.json'), 'utf-8'));
  const devs = r.devCohort.earliestHolders;
  const dumpers = r.dumpers;
  const links = r.crossRef.fundingLinks;
  const overlap = r.crossRef.directOverlap.map((a: string) => a.toLowerCase());
  const devFundOut = new Map<string, Set<string>>();
  for (const l of links.filter((l: any) => l.direction === 'dev→dumper')) {
    const dev = l.dev.toLowerCase();
    if (!devFundOut.has(dev)) devFundOut.set(dev, new Set());
    devFundOut.get(dev)!.add(l.dumper.toLowerCase());
  }
  const topFunders = [...devFundOut.entries()]
    .map(([dev, dumperSetFunded]) => {
      const devRec = devs.find((d: any) => d.address.toLowerCase() === dev);
      const dumperRec = dumpers.find((d: any) => d.address.toLowerCase() === dev);
      return {
        address: dev,
        tokensReceivedAsDev: devRec?.tokensReceived || 0,
        dumpedThemselves: !!dumperRec,
        dumpedAmount: dumperRec?.tokensSold || 0,
        dumpRank: dumperRec ? dumpers.indexOf(dumperRec) + 1 : null,
        verdict: dumperRec?.verification?.verdict || 'NOT_DUMPED',
        walletAgeDays: dumperRec?.victimDistinction?.walletAgeDays || null,
        kycChokepoints: dumperRec?.backTrace?.kycChokepoints || [],
        dumpersFunded: dumperSetFunded.size,
        totalTopDumpers: dumpers.length,
      };
    })
    .sort((a, b) => b.dumpersFunded - a.dumpersFunded);
  return { topFunders, overlap, totalLinks: links.length };
}

function buildHtml(): string {
  const { topFunders, overlap, totalLinks } = loadRingleaderData();

  const sec = (titleColor: string, title: string, body: string, bg = C.panel, border = C.border) =>
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${bg};border:1px solid ${border};border-radius:8px;margin-bottom:16px;"><tr><td style="padding:20px;">
      <div style="color:${titleColor};font-size:15px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;border-bottom:1px solid ${border};padding-bottom:8px;margin-bottom:14px;">${title}</div>
      ${body}
    </td></tr></table>`;
  const li = (html: string) =>
    `<div style="color:${C.text};font-size:13px;font-family:Segoe UI,Arial,sans-serif;margin:6px 0;padding-left:16px;line-height:1.55;">• ${html}</div>`;
  const addr = (a: string) =>
    `<span style="font-family:Consolas,monospace;font-size:11px;color:${C.gold};background:${C.panel2};padding:3px 7px;border-radius:4px;">${a}</span>`;
  const stat = (val: string, label: string, color = C.gold) =>
    `<td align="center" valign="middle" style="background:${C.panel2};border:1px solid #334155;border-radius:6px;padding:14px 8px;width:25%;">
      <div style="color:${color};font-size:20px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;">${val}</div>
      <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;margin-top:4px;">${label}</div>
    </td>`;

  // Ringleader cards (top 4)
  const ringleaderCards = topFunders.slice(0, 4).map((p, idx) => {
    const ringColor = idx === 0 ? C.red : (p.dumpersFunded >= 5 ? C.orange : C.gold);
    const ringLabel = idx === 0 ? '👑 PRIME RINGLEADER'
                                : p.dumpersFunded >= 5 ? '🥈 SECONDARY RINGLEADER'
                                : '🔗 SUPPORTING DEV-FUNDER';
    const exchanges = [...new Set(p.kycChokepoints.map((k: any) => k.exchange))].slice(0, 5).join(', ') || '—';
    return `
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border:2px solid ${ringColor};border-radius:8px;margin-bottom:14px;"><tr><td style="padding:14px;">
        <div style="color:${ringColor};font-size:13px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;letter-spacing:1px;margin-bottom:8px;">${ringLabel}</div>
        <div style="color:${C.gold};font-family:Consolas,monospace;font-size:11px;background:${C.bg};padding:5px 9px;border-radius:4px;display:inline-block;margin-bottom:10px;">${p.address}</div>
        <table role="presentation" cellpadding="0" cellspacing="6" border="0" width="100%">
          <tr>
            ${stat(`${p.dumpersFunded}/${p.totalTopDumpers}`, 'Top dumpers funded', ringColor)}
            ${stat(p.tokensReceivedAsDev.toLocaleString(undefined, { maximumFractionDigits: 0 }), 'RAVE received as dev')}
            ${stat(p.dumpedThemselves ? `#${p.dumpRank}` : '—', p.dumpedThemselves ? `Dumped ${p.dumpedAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })} RAVE` : 'Did not dump directly', p.dumpedThemselves ? C.red : C.text)}
            ${stat(`${p.kycChokepoints.length}`, 'KYC chokepoints', C.cyan)}
          </tr>
        </table>
        <div style="color:${C.text};font-size:12px;font-family:Segoe UI,Arial,sans-serif;margin-top:10px;line-height:1.55;">
          <b style="color:${C.gold};">Wallet age:</b> ${p.walletAgeDays !== null ? `${p.walletAgeDays} days` : 'n/a'}  ·  <b style="color:${C.gold};">Verdict:</b> ${p.verdict}
        </div>
        <div style="color:${C.text};font-size:12px;font-family:Segoe UI,Arial,sans-serif;margin-top:6px;line-height:1.55;">
          <b style="color:${C.cyan};">CEX/KYC chokepoints:</b> ${exchanges}
        </div>
      </td></tr></table>`;
  }).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="background:${C.bg};margin:0;padding:0;font-family:Segoe UI,Arial,sans-serif;color:${C.text};">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};"><tr><td align="center" style="padding:24px;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="880" style="max-width:880px;width:100%;">

  <tr><td style="background:linear-gradient(135deg,#7F1D1D 0%,#1a0000 100%);background-color:#7F1D1D;border:2px solid ${C.red};border-radius:12px;padding:28px;text-align:center;">
    <div style="color:${C.red};font-size:24px;font-weight:bold;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:8px;">🚨 RAVEDAO_DUMP — FULL FORENSIC REPORT</div>
    <div style="color:#FCA5A5;font-size:14px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:6px;">Internal owner copy · Coordinated rug-pull confirmed</div>
    <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;">Token: 0x17205fab260a7a6383a81452cE6315A39370Db97 (RaveDAO / RAVE) · Generated ${NOW}</div>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td style="background:#1a0000;border:2px dashed ${C.red};border-radius:8px;padding:14px;text-align:center;">
    <div style="color:${C.red};font-size:12px;font-weight:bold;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;">⚠ INTERNAL USE ONLY — DO NOT FORWARD TO SILLYTUNA OR SEAL TEAM ⚠</div>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td>${sec(C.red, '🚨 Headline Finding — Coordinated Rug-Pull Confirmed', `
    ${li(`<b style="color:${C.text};">${overlap.length} dev/early-holder wallets directly appear in the top dumper list</b> (devs dumped their own bags)`)}
    ${li(`<b style="color:${C.text};">${totalLinks} funding-flow links</b> between the dev cohort and the dump cohort — clear collusion pattern`)}
    ${li(`<b style="color:${C.text};">20 top dumpers</b> moved <b style="color:${C.text};">991,337 RAVE</b> through 2 liquidity pools in the last 72 hours`)}
    ${li(`<b style="color:${C.text};">12 CONFIRMED_PERPETRATOR + 8 DOWNSTREAM_MULE</b> · zero co-victims · zero exchanges`)}
    ${li(`<b style="color:${C.text};">${topFunders.length} dev wallets</b> directly funded one or more of the top 20 dumpers`)}
  `, '#7F1D1D22', C.red)}</td></tr>

  <tr><td>${sec(C.red, '👑 RINGLEADER PROFILE — Dev Wallets Driving the Dump', `
    <div style="color:${C.text};font-size:13px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:12px;line-height:1.55;">
      Computed by <b style="color:${C.gold};">Alpha Dev-Dumper Collusion Detector™</b> — ranked by number of top-20 dumpers each dev wallet directly funded.
    </div>
    <table role="presentation" cellpadding="0" cellspacing="6" border="0" width="100%" style="margin-bottom:12px;"><tr>
      ${stat(`${topFunders.length}`, 'Devs that funded dumpers', C.red)}
      ${stat(`${overlap.length}`, 'Devs in top dumper list', C.red)}
      ${stat(`${topFunders[0]?.dumpersFunded || 0}`, 'Top funder reach (of 20)', C.red)}
      ${stat(`${totalLinks}`, 'Total dev↔dumper links', C.red)}
    </tr></table>
    ${ringleaderCards}
    <div style="background:${C.bg};border:1px dashed ${C.red};border-radius:8px;padding:14px;margin-top:14px;">
      <div style="color:${C.red};font-size:13px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;margin-bottom:6px;">⚠ INTERPRETATION</div>
      <div style="color:${C.text};font-size:12px;font-family:Segoe UI,Arial,sans-serif;line-height:1.6;">
        The dump is not organic — it is driven by a small, tightly-coordinated group of dev/early-holder wallets.
        One ringleader funded ${topFunders[0]?.dumpersFunded || 0} of the top 20 dumpers and dumped its own bag.
        A second hub funded ${topFunders[1]?.dumpersFunded || 0} of the top 20 and also dumped — its 700+ counterparty profile suggests it is being used as a slush pool to launder rug activity inside otherwise legitimate-looking exchange-style traffic.
        All ringleader funding back-traces converge on a small, identifiable cluster of CEX deposit accounts (Binance HW14/15/16, Coinbase 10, Gate.io) — the operational chokepoint for any recovery action.
      </div>
    </div>
  `, '#7F1D1D11', C.red)}</td></tr>

  <tr><td>${sec(C.cyan, '📊 Verification Results', `
    <table role="presentation" cellpadding="0" cellspacing="6" border="0" width="100%"><tr>
      ${stat('20', 'Top dumpers analyzed', C.red)}
      ${stat('991,337', 'RAVE dumped (top 20)', C.red)}
      ${stat('12', 'CONFIRMED_PERPETRATOR')}
      ${stat('8', 'DOWNSTREAM_MULE')}
    </tr><tr>
      ${stat('2', 'Liquidity pools detected')}
      ${stat('30', 'Dev cohort size')}
      ${stat(`${overlap.length}`, 'Devs that dumped directly', C.red)}
      ${stat(`${totalLinks}`, 'Dev↔Dumper funding links', C.red)}
    </tr></table>
  `)}</td></tr>

  <tr><td>${sec(C.cyan, '🔧 Pipeline Stages Run (Full SillyTuna-Grade Treatment)', `
    ${li(`<b style="color:${C.gold};">Stage 1 — Token Dump Detection Engine™:</b> Scanned all RAVE transfers in the 72h window, identified 2 active liquidity pools.`)}
    ${li(`<b style="color:${C.gold};">Stage 2 — Top-Dumper Ranking:</b> Aggregated all transfers TO pools by sender, ranked by RAVE volume.`)}
    ${li(`<b style="color:${C.gold};">Stage 3 — Dev Wallet Identification:</b> Pulled the earliest 200 RAVE transfers, extracted top 30 earliest holders.`)}
    ${li(`<b style="color:${C.gold};">Stage 4 — Alpha KYC Chokepoint Mapper™:</b> Per-dumper 2-hop back-trace to CEX/KYC funding sources.`)}
    ${li(`<b style="color:${C.gold};">Stage 5 — Alpha Post-Trace Activity Surveillance™:</b> Per-dumper forward-activity overlay for the 72h window.`)}
    ${li(`<b style="color:${C.gold};">Stage 6 — Alpha 4-Axis Attacker Verification Protocol™:</b> Per-dumper test for attacker vs. exchange.`)}
    ${li(`<b style="color:${C.gold};">Stage 7 — Alpha Perpetrator-vs-Victim Distinction Engine™:</b> Per-dumper test for perpetrator vs. co-victim.`)}
    ${li(`<b style="color:${C.gold};">Stage 8 — Alpha Dev-Dumper Collusion Detector™:</b> Cross-referenced dev cohort against dumper cohort for direct overlap and funding links.`)}
  `)}</td></tr>

  <tr><td>${sec(C.cyan, '📎 Attachments (Full Report)', `
    ${li(`<b style="color:${C.text};">RAVEDAO-Dump-Forensic-Report.html</b> — Interactive viewer with embedded Ringleader Profile section + all 20 dumper profiles, KYC chokepoints, dev cohort, and collusion links`)}
    ${li(`<b style="color:${C.text};">RAVEDAO-Dump-Full-Data.json</b> — Complete machine-readable dataset (every dumper, every back-trace hop, every flag, every link)`)}
    ${li(`<b style="color:${C.text};">RAVEDAO-Dump-Analysis-Source.ts</b> — Source code of the master analysis script (for reproducibility / re-runs)`)}
  `)}</td></tr>

  <tr><td style="text-align:center;padding-top:12px;">
    <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;line-height:1.6;">
      © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.<br>
      PROPRIETARY AND CONFIDENTIAL · Title 17 · DMCA · CFAA · DTSA<br>
      Generated by Alpha Forensic Intelligence Engine™ · Token Dump Detection Engine™ · Alpha KYC Chokepoint Mapper™ · Alpha Post-Trace Activity Surveillance™ · Alpha 4-Axis Attacker Verification Protocol™ · Alpha Perpetrator-vs-Victim Distinction Engine™ · Alpha Dev-Dumper Collusion Detector™ · Alpha Proprietary Software Guard™
    </div>
  </td></tr>

</table>
</td></tr></table>
</body></html>`;
}

function buildText(): string {
  const { topFunders, overlap, totalLinks } = loadRingleaderData();
  const top = topFunders.slice(0, 4);
  return `RAVEDAO_DUMP — FULL FORENSIC REPORT (INTERNAL OWNER COPY ONLY)
Token: 0x17205fab260a7a6383a81452cE6315A39370Db97 (RaveDAO / RAVE)
Generated: ${NOW}

⚠ DO NOT FORWARD TO SILLYTUNA OR SEAL TEAM — INTERNAL USE ONLY ⚠

HEADLINE FINDING — COORDINATED RUG-PULL CONFIRMED
==================================================
- ${overlap.length} dev/early-holder wallets directly appear in the top dumper list
- ${totalLinks} funding-flow links between the dev cohort and the dump cohort
- 20 top dumpers moved 991,337 RAVE through 2 liquidity pools in the last 72 hours
- 12 CONFIRMED_PERPETRATOR + 8 DOWNSTREAM_MULE
- ${topFunders.length} dev wallets directly funded one or more of the top 20 dumpers

RINGLEADER PROFILE — DEV WALLETS DRIVING THE DUMP
==================================================
${top.map((p, i) => {
  const exchanges = [...new Set(p.kycChokepoints.map((k: any) => k.exchange))].slice(0, 5).join(', ') || '—';
  return `${i === 0 ? '👑 PRIME RINGLEADER' : p.dumpersFunded >= 5 ? '🥈 SECONDARY RINGLEADER' : '🔗 SUPPORTING DEV-FUNDER'}
  Address:                 ${p.address}
  Top dumpers funded:      ${p.dumpersFunded}/${p.totalTopDumpers}
  RAVE received as dev:    ${p.tokensReceivedAsDev.toLocaleString(undefined, { maximumFractionDigits: 0 })}
  Dumped themselves:       ${p.dumpedThemselves ? `YES — Rank #${p.dumpRank}, ${p.dumpedAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })} RAVE` : 'No (funder only)'}
  Wallet age:              ${p.walletAgeDays !== null ? `${p.walletAgeDays} days` : 'n/a'}
  Verdict:                 ${p.verdict}
  KYC chokepoints:         ${p.kycChokepoints.length} (${exchanges})
`;
}).join('\n')}

INTERPRETATION
==============
The dump is not organic — it is driven by a small, tightly-coordinated group of
dev/early-holder wallets. One ringleader funded ${top[0]?.dumpersFunded || 0} of the top 20
dumpers and dumped its own bag. All ringleader funding back-traces converge on
a small, identifiable cluster of CEX deposit accounts (Binance HW14/15/16,
Coinbase 10, Gate.io) — the operational chokepoint for any recovery action.

VERIFICATION RESULTS
====================
Top dumpers analyzed:       20
RAVE dumped (top 20):       991,337
CONFIRMED_PERPETRATOR:      12
DOWNSTREAM_MULE:            8
Liquidity pools detected:   2
Dev cohort size:            30
Devs that dumped directly:  ${overlap.length}
Dev↔Dumper funding links:   ${totalLinks}

PIPELINE STAGES RUN
===================
1. Token Dump Detection Engine™
2. Top-Dumper Ranking
3. Dev Wallet Identification
4. Alpha KYC Chokepoint Mapper™ (per-dumper 2-hop back-trace)
5. Alpha Post-Trace Activity Surveillance™ (per-dumper 72h activity overlay)
6. Alpha 4-Axis Attacker Verification Protocol™
7. Alpha Perpetrator-vs-Victim Distinction Engine™
8. Alpha Dev-Dumper Collusion Detector™

ATTACHMENTS
===========
- RAVEDAO-Dump-Forensic-Report.html  (interactive viewer w/ Ringleader section)
- RAVEDAO-Dump-Full-Data.json        (complete dataset)
- RAVEDAO-Dump-Analysis-Source.ts    (source code)

---
© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
PROPRIETARY AND CONFIDENTIAL · Title 17 · DMCA · CFAA · DTSA
`;
}

async function main() {
  console.log('=== RAVEDAO_DUMP — INTERNAL OWNER REPORT (v2: white text + ringleaders) ===');
  console.log(`Recipient: ${RECIPIENT.email}  (NOT SillyTuna · NOT SEAL)`);
  console.log('Loading attachments:');
  const attachments = loadAttachments();

  const { client, fromEmail } = await getUncachableSendGridClient();
  const html = buildHtml();
  const text = buildText();
  const subject = '🚨 RAVEDAO_DUMP — Full Forensic Report w/ Ringleader Profile (Internal Owner Copy · Coordinated Rug-Pull Confirmed) [v2]';

  console.log(`\n→ Sending to ${RECIPIENT.name} <${RECIPIENT.email}> ...`);
  try {
    await client.send({
      to: { email: RECIPIENT.email, name: RECIPIENT.name },
      from: { email: fromEmail, name: 'Alpha Unlimited — Forensic Intelligence (Internal)' },
      subject,
      content: [
        { type: 'text/plain', value: text },
        { type: 'text/html', value: html },
      ],
      attachments,
    });
    console.log(`  ✅ SENT to ${RECIPIENT.email}`);
  } catch (e: any) {
    console.log(`  ❌ FAILED: ${e?.message || e}`);
    if (e?.response?.body) console.log(`     ${JSON.stringify(e.response.body).slice(0, 500)}`);
    process.exit(1);
  }
  console.log('\n=== Done ===');
}

main().catch(e => { console.error(e); process.exit(1); });
