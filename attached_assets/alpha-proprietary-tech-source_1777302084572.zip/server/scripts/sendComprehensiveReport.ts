import { db } from "../db.js";
import { sql, eq, desc } from "drizzle-orm";
import { monitoredWallets, tracedTransactions, forensicAlerts, forensicCases } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENT = "sillytuna@gmail.com";
const RECIPIENT_NAME = "@sillytuna (Alex Amsel)";

async function sendEmail(sgKey: string, subject: string, bodyText: string, attachments: { content: string; filename: string; type: string }[]) {
  const email = {
    personalizations: [{ to: [{ email: RECIPIENT, name: RECIPIENT_NAME }] }],
    from: { email: "forensics@alphaunlimitedtrading.com", name: "Alpha Unlimited Trading — Forensic Intelligence" },
    subject,
    content: [{ type: "text/plain", value: bodyText }],
    attachments: attachments.map(a => ({ ...a, disposition: "attachment" }))
  };
  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: { "Authorization": `Bearer ${sgKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(email)
  });
  if (res.ok || res.status === 202) {
    console.log(`  ✓ Sent: ${subject}`);
    return true;
  } else {
    const err = await res.text();
    console.error(`  ✗ FAILED (${res.status}): ${subject} — ${err}`);
    return false;
  }
}

async function main() {
  console.log("Building comprehensive forensic report for sillytuna...");
  console.log("Report will be split into multiple emails for reliability.\n");

  const [caseData] = await db.select().from(forensicCases).where(eq(forensicCases.id, CASE_ID));
  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const allTxs = await db.select().from(tracedTransactions).where(eq(tracedTransactions.caseId, CASE_ID)).orderBy(desc(tracedTransactions.timestamp));
  const alerts = await db.select().from(forensicAlerts).where(eq(forensicAlerts.caseId, CASE_ID)).orderBy(desc(forensicAlerts.createdAt));

  console.log(`Data loaded: ${wallets.length} wallets, ${allTxs.length} txs, ${alerts.length} alerts`);

  const sgKey = process.env.SENDGRID_API_KEY;
  if (!sgKey) { console.error("No SENDGRID_API_KEY"); process.exit(1); }

  const now = new Date().toISOString();
  const dateStr = now.split("T")[0];
  const sortedWallets = [...wallets].sort((a, b) => (b.lastKnownBalanceUsd || 0) - (a.lastKnownBalanceUsd || 0));

  const tornadoAlerts = alerts.filter(a => a.alertType === "tornado_cash_interaction");
  const moneroAlerts = alerts.filter(a => a.alertType === "monero_conversion");
  const unfreezeAlerts = alerts.filter(a => a.alertType === "unfreezable_token_movement");

  let sent = 0;
  let failed = 0;
  const totalEmails = 4;

  console.log(`\nSending Email 1/${totalEmails}: Executive Summary & Fund Flow Analysis...`);
  {
    const lines: string[] = [];
    lines.push("╔══════════════════════════════════════════════════════════════════════════╗");
    lines.push("║   ALPHA UNLIMITED TRADING — FORENSIC INTELLIGENCE DIVISION             ║");
    lines.push("║   COMPREHENSIVE FORENSIC INVESTIGATION REPORT                          ║");
    lines.push("║   Email 1 of 4: Executive Summary & Fund Flow Analysis                 ║");
    lines.push("╚══════════════════════════════════════════════════════════════════════════╝");
    lines.push("");
    lines.push(`Case: ${caseData?.caseName || "@sillytuna ~$24M Theft"}`);
    lines.push(`Victim: Alex Amsel (@sillytuna)`);
    lines.push(`Report Generated: ${now}`);
    lines.push(`Case ID: ${CASE_ID}`);
    lines.push(`Status: ACTIVE — 24/7 Monitoring`);
    lines.push("");
    lines.push("This comprehensive report is split across 4 emails:");
    lines.push("  Email 1 (this one): Executive Summary, Fund Flow Analysis, Exchange & Counterparty Data");
    lines.push("  Email 2: Complete Wallet List — all monitored wallets with balances & tokens");
    lines.push("  Email 3: Complete Transaction History — every traced transaction (CSV)");
    lines.push("  Email 4: All Alerts — Tornado Cash, Critical Alerts, Returned Funds");
    lines.push("");

    lines.push("═".repeat(76));
    lines.push("EXECUTIVE SUMMARY");
    lines.push("═".repeat(76));
    lines.push("");
    lines.push(`Total Wallets Under Surveillance: ${wallets.length}`);
    lines.push(`Total Transactions Traced: ${allTxs.length}`);
    lines.push(`Total Forensic Alerts Generated: ${alerts.length}`);
    lines.push(`Estimated Total Stolen: ~$${((caseData?.totalStolenUsd || 24000000) / 1000000).toFixed(0)}M`);
    lines.push("");

    const roleMap = new Map<string, number>();
    for (const w of wallets) roleMap.set(w.role || "unknown", (roleMap.get(w.role || "unknown") || 0) + 1);
    const chainMap = new Map<string, number>();
    for (const w of wallets) chainMap.set(w.chain, (chainMap.get(w.chain) || 0) + 1);

    lines.push("Wallet Breakdown by Role:");
    for (const [role, count] of [...roleMap.entries()].sort((a, b) => b[1] - a[1])) {
      lines.push(`  ${role}: ${count}`);
    }
    lines.push("");
    lines.push("Wallet Breakdown by Chain:");
    for (const [chain, count] of [...chainMap.entries()].sort((a, b) => b[1] - a[1])) {
      lines.push(`  ${chain}: ${count}`);
    }
    lines.push("");
    lines.push("Laundering Detection:");
    lines.push(`  Tornado Cash interactions detected: ${tornadoAlerts.length}`);
    lines.push(`  Monero on-ramp conversions: ${moneroAlerts.length}`);
    lines.push(`  Unfreezable token movements: ${unfreezeAlerts.length}`);
    lines.push("");

    lines.push("═".repeat(76));
    lines.push("FUND FLOW ANALYSIS — WHERE THE MONEY WENT");
    lines.push("═".repeat(76));
    lines.push("");

    const txByType = new Map<string, { count: number; totalUsd: number }>();
    for (const tx of allTxs) {
      const t = tx.txType || "unknown";
      if (!txByType.has(t)) txByType.set(t, { count: 0, totalUsd: 0 });
      const entry = txByType.get(t)!;
      entry.count++;
      entry.totalUsd += parseFloat(tx.amountUsd || "0");
    }
    lines.push("Transaction Types:");
    for (const [type, data] of [...txByType.entries()].sort((a, b) => b[1].totalUsd - a[1].totalUsd)) {
      lines.push(`  ${type}: ${data.count} transactions ($${data.totalUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`);
    }
    lines.push("");

    const tokenMap = new Map<string, { count: number; totalUsd: number; totalAmount: number }>();
    for (const tx of allTxs) {
      const sym = tx.tokenSymbol || "ETH";
      if (!tokenMap.has(sym)) tokenMap.set(sym, { count: 0, totalUsd: 0, totalAmount: 0 });
      const entry = tokenMap.get(sym)!;
      entry.count++;
      entry.totalUsd += parseFloat(tx.amountUsd || "0");
      entry.totalAmount += parseFloat(tx.amount || "0");
    }
    lines.push("Token Flow Summary (by USD volume):");
    for (const [token, data] of [...tokenMap.entries()].sort((a, b) => b[1].totalUsd - a[1].totalUsd).slice(0, 50)) {
      lines.push(`  ${token}: ${data.count} transfers | ${data.totalAmount.toLocaleString()} ${token} | $${data.totalUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
    }
    lines.push("");

    lines.push("═".repeat(76));
    lines.push("EXCHANGE INTERACTIONS — CASH OUT POINTS");
    lines.push("═".repeat(76));
    lines.push("");
    const exchangeMap = new Map<string, { count: number; totalUsd: number; deposits: number; withdrawals: number }>();
    for (const tx of allTxs) {
      if (!tx.exchangeName) continue;
      if (!exchangeMap.has(tx.exchangeName)) exchangeMap.set(tx.exchangeName, { count: 0, totalUsd: 0, deposits: 0, withdrawals: 0 });
      const ex = exchangeMap.get(tx.exchangeName)!;
      ex.count++;
      const usd = parseFloat(tx.amountUsd || "0");
      ex.totalUsd += usd;
      if (tx.direction === "outbound") ex.deposits += usd;
      else ex.withdrawals += usd;
    }
    if (exchangeMap.size > 0) {
      for (const [name, data] of [...exchangeMap.entries()].sort((a, b) => b[1].totalUsd - a[1].totalUsd)) {
        lines.push(`${name}:`);
        lines.push(`  Total Volume: $${data.totalUsd.toFixed(2)} (${data.count} transactions)`);
        lines.push(`  Deposits: $${data.deposits.toFixed(2)} | Withdrawals: $${data.withdrawals.toFixed(2)}`);
        lines.push("");
      }
    } else {
      lines.push("No direct exchange interactions detected in traced transactions.");
      lines.push("");
    }

    lines.push("═".repeat(76));
    lines.push("TOP 50 COUNTERPARTIES BY VOLUME");
    lines.push("═".repeat(76));
    lines.push("");
    const cpMap = new Map<string, { label: string; inCount: number; outCount: number; inUsd: number; outUsd: number }>();
    for (const tx of allTxs) {
      for (const [addr, label, dir] of [
        [tx.fromAddress, tx.fromLabel, "out"],
        [tx.toAddress, tx.toLabel, "in"]
      ] as [string | null, string | null, string][]) {
        if (!addr) continue;
        const key = addr.toLowerCase();
        if (!cpMap.has(key)) cpMap.set(key, { label: label || "", inCount: 0, outCount: 0, inUsd: 0, outUsd: 0 });
        const cp = cpMap.get(key)!;
        if (label && !cp.label) cp.label = label;
        const usd = parseFloat(tx.amountUsd || "0");
        if (dir === "in") { cp.inCount++; cp.inUsd += usd; }
        else { cp.outCount++; cp.outUsd += usd; }
      }
    }
    const topCps = [...cpMap.entries()].sort((a, b) => (b[1].inUsd + b[1].outUsd) - (a[1].inUsd + a[1].outUsd)).slice(0, 50);
    for (const [addr, data] of topCps) {
      const total = data.inUsd + data.outUsd;
      const totalTxs = data.inCount + data.outCount;
      lines.push(`${addr}`);
      lines.push(`  Label: ${data.label || "Unknown"}`);
      lines.push(`  Total Volume: $${total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${totalTxs} txs)`);
      lines.push(`  Inflows: $${data.inUsd.toFixed(2)} (${data.inCount} txs) | Outflows: $${data.outUsd.toFixed(2)} (${data.outCount} txs)`);
      lines.push("");
    }

    lines.push("═".repeat(76));
    lines.push("MONITORING STATUS");
    lines.push("═".repeat(76));
    lines.push("");
    lines.push(`Active 24/7 Monitoring: YES`);
    lines.push(`Wallet Balance Checks: Every 5 minutes`);
    lines.push(`Token Flow Tracing: Every 3 minutes`);
    lines.push(`OSINT Deep Scanning: Continuous across 22+ platforms`);
    lines.push(`Hourly Email Updates: Active (sillytuna@gmail.com)`);
    lines.push(`Tornado Cash Detection: Active (17 contracts monitored)`);
    lines.push(`Monero On-Ramp Detection: Active (11 addresses monitored)`);
    lines.push(`Unfreezable Token Tracking: Active (11 tokens classified)`);
    lines.push("");
    lines.push("Alpha Unlimited Trading Company — Forensic Intelligence Division");
    lines.push(`Report generated: ${now}`);

    const reportText = lines.join("\n");
    const ok = await sendEmail(sgKey, 
      `FORENSIC REPORT 1/4 — Executive Summary & Fund Flow Analysis — ${dateStr}`,
      reportText,
      [{
        content: Buffer.from(reportText).toString("base64"),
        filename: `sillytuna_executive_summary_${dateStr}.txt`,
        type: "text/plain"
      }]
    );
    if (ok) sent++; else failed++;
  }

  await new Promise(r => setTimeout(r, 2000));

  console.log(`\nSending Email 2/${totalEmails}: Complete Wallet List (${wallets.length} wallets)...`);
  {
    const walletLines: string[] = [];
    walletLines.push("╔══════════════════════════════════════════════════════════════════════════╗");
    walletLines.push("║   FORENSIC REPORT — Email 2 of 4                                       ║");
    walletLines.push(`║   ALL ${wallets.length} MONITORED WALLETS — COMPLETE LIST                          ║`);
    walletLines.push("╚══════════════════════════════════════════════════════════════════════════╝");
    walletLines.push("");
    walletLines.push(`Report date: ${now}`);
    walletLines.push(`Case: ${caseData?.caseName || "@sillytuna ~$24M Theft"}`);
    walletLines.push("");
    walletLines.push("Attached: Full wallet list as text report + CSV spreadsheet");
    walletLines.push("The CSV can be opened in Excel/Google Sheets for sorting and filtering.");
    walletLines.push("");

    walletLines.push("═".repeat(76));
    walletLines.push(`ALL ${wallets.length} MONITORED WALLETS`);
    walletLines.push("═".repeat(76));
    walletLines.push("");

    for (const w of sortedWallets) {
      const tokens = w.lastKnownTokens && typeof w.lastKnownTokens === "object"
        ? Object.entries(w.lastKnownTokens as Record<string, number>)
            .filter(([, v]) => v > 0.001)
            .sort(([, a], [, b]) => b - a)
            .map(([s, v]) => `${(v as number) >= 1000 ? `${((v as number)/1000).toFixed(1)}K` : (v as number).toFixed(4)} ${s}`)
            .join(", ")
        : "";
      walletLines.push(`${w.address} (${w.chain})`);
      walletLines.push(`  Label: ${w.label || "-"} | Role: ${w.role || "-"} | Status: ${w.status}`);
      walletLines.push(`  Balance: ${(w.lastKnownBalanceEth || 0).toFixed(6)} ${w.chain === "bitcoin" ? "BTC" : "ETH"} ($${(w.lastKnownBalanceUsd || 0).toFixed(2)})`);
      if (tokens) walletLines.push(`  Tokens: ${tokens}`);
      if (w.lastActivity) walletLines.push(`  Last Activity: ${w.lastActivity}`);
      walletLines.push("");
    }

    const walletCsvRows = ["Address,Chain,Label,Role,Status,Balance_Native,Balance_USD,Tokens,Last_Activity"];
    for (const w of sortedWallets) {
      const tokens = w.lastKnownTokens && typeof w.lastKnownTokens === "object"
        ? Object.entries(w.lastKnownTokens as Record<string, number>)
            .filter(([, v]) => v > 0.001)
            .map(([s, v]) => `${(v as number).toFixed(4)} ${s}`)
            .join("; ")
        : "";
      const escapedLabel = (w.label || "").replace(/"/g, '""');
      const escapedTokens = tokens.replace(/"/g, '""');
      walletCsvRows.push(`"${w.address}","${w.chain}","${escapedLabel}","${w.role || ""}","${w.status}",${(w.lastKnownBalanceEth || 0).toFixed(6)},${(w.lastKnownBalanceUsd || 0).toFixed(2)},"${escapedTokens}","${w.lastActivity || ""}"`);
    }
    const walletCsv = walletCsvRows.join("\n");

    const walletReport = walletLines.join("\n");
    const ok = await sendEmail(sgKey,
      `FORENSIC REPORT 2/4 — All ${wallets.length} Monitored Wallets — ${dateStr}`,
      `Alex,\n\nAttached is the complete list of all ${wallets.length} wallets under surveillance in your case.\n\nTwo formats attached:\n1. Text report — readable wallet-by-wallet breakdown\n2. CSV spreadsheet — for Excel/Google Sheets analysis\n\nEach wallet includes: address, chain, label, role, current ETH/BTC balance, USD value, token holdings, and last activity time.\n\nAlpha Unlimited Trading — Forensic Intelligence Division`,
      [
        {
          content: Buffer.from(walletReport).toString("base64"),
          filename: `sillytuna_${wallets.length}_wallets_report_${dateStr}.txt`,
          type: "text/plain"
        },
        {
          content: Buffer.from(walletCsv).toString("base64"),
          filename: `sillytuna_${wallets.length}_wallets_${dateStr}.csv`,
          type: "text/csv"
        }
      ]
    );
    if (ok) sent++; else failed++;
  }

  await new Promise(r => setTimeout(r, 2000));

  console.log(`\nSending Email 3/${totalEmails}: Complete Transaction History (${allTxs.length} transactions)...`);
  {
    const txCsvRows = ["TX_Hash,Chain,Timestamp,From_Address,From_Label,To_Address,To_Label,Direction,TX_Type,Token,Amount,Amount_USD,Exchange"];
    for (const tx of allTxs) {
      const escapedFromLabel = (tx.fromLabel || "").replace(/"/g, '""');
      const escapedToLabel = (tx.toLabel || "").replace(/"/g, '""');
      txCsvRows.push(`"${tx.txHash || ""}","${tx.chain || ""}","${tx.timestamp || ""}","${tx.fromAddress || ""}","${escapedFromLabel}","${tx.toAddress || ""}","${escapedToLabel}","${tx.direction || ""}","${tx.txType || ""}","${tx.tokenSymbol || "ETH"}","${tx.amount || "0"}","${tx.amountUsd || "0"}","${tx.exchangeName || ""}"`);
    }
    const txCsv = txCsvRows.join("\n");
    const txCsvSize = Buffer.byteLength(txCsv);
    console.log(`  Transaction CSV: ${txCsvRows.length} rows, ${(txCsvSize / 1024 / 1024).toFixed(2)} MB`);

    const MAX_CHUNK = 4 * 1024 * 1024;
    if (txCsvSize > MAX_CHUNK) {
      const header = txCsvRows[0];
      const dataRows = txCsvRows.slice(1);
      const chunkSize = Math.ceil(dataRows.length / Math.ceil(txCsvSize / MAX_CHUNK));
      const chunks: string[][] = [];
      for (let i = 0; i < dataRows.length; i += chunkSize) {
        chunks.push(dataRows.slice(i, i + chunkSize));
      }
      console.log(`  Splitting into ${chunks.length} parts (${chunkSize} rows each)...`);

      for (let i = 0; i < chunks.length; i++) {
        const partCsv = [header, ...chunks[i]].join("\n");
        const partLabel = `Part ${i + 1}/${chunks.length}`;
        const startRow = i * chunkSize + 1;
        const endRow = Math.min((i + 1) * chunkSize, dataRows.length);

        const ok = await sendEmail(sgKey,
          `FORENSIC REPORT 3/4 — Traced Transactions ${partLabel} (rows ${startRow}-${endRow} of ${dataRows.length}) — ${dateStr}`,
          `Alex,\n\nAttached is ${partLabel} of the complete traced transaction history.\n\nThis file contains rows ${startRow} to ${endRow} of ${dataRows.length} total traced transactions.\n\nOpen in Excel/Google Sheets — columns include: TX Hash, Chain, Timestamp, From/To addresses with labels, Direction, Type, Token, Amount, USD Value, and Exchange name.\n\nAlpha Unlimited Trading — Forensic Intelligence Division`,
          [{
            content: Buffer.from(partCsv).toString("base64"),
            filename: `sillytuna_transactions_part${i + 1}of${chunks.length}_${dateStr}.csv`,
            type: "text/csv"
          }]
        );
        if (ok) sent++; else failed++;
        if (i < chunks.length - 1) await new Promise(r => setTimeout(r, 2000));
      }
    } else {
      const ok = await sendEmail(sgKey,
        `FORENSIC REPORT 3/4 — All ${allTxs.length} Traced Transactions — ${dateStr}`,
        `Alex,\n\nAttached is the complete traced transaction history — ${allTxs.length} transactions showing the full money trail.\n\nOpen in Excel/Google Sheets — columns include: TX Hash, Chain, Timestamp, From/To addresses with labels, Direction, Type, Token, Amount, USD Value, and Exchange name.\n\nAlpha Unlimited Trading — Forensic Intelligence Division`,
        [{
          content: Buffer.from(txCsv).toString("base64"),
          filename: `sillytuna_${allTxs.length}_traced_transactions_${dateStr}.csv`,
          type: "text/csv"
        }]
      );
      if (ok) sent++; else failed++;
    }
  }

  await new Promise(r => setTimeout(r, 2000));

  console.log(`\nSending Email 4/${totalEmails}: All Alerts — Tornado Cash, Critical, Returned Funds...`);
  {
    const alertLines: string[] = [];
    alertLines.push("╔══════════════════════════════════════════════════════════════════════════╗");
    alertLines.push("║   FORENSIC REPORT — Email 4 of 4                                       ║");
    alertLines.push("║   COMPLETE ALERT HISTORY & LAUNDERING DETECTION                        ║");
    alertLines.push("╚══════════════════════════════════════════════════════════════════════════╝");
    alertLines.push("");
    alertLines.push(`Report date: ${now}`);
    alertLines.push(`Total alerts: ${alerts.length}`);
    alertLines.push("");

    if (tornadoAlerts.length > 0) {
      alertLines.push("═".repeat(76));
      alertLines.push(`TORNADO CASH INTERACTIONS (${tornadoAlerts.length} DETECTED)`);
      alertLines.push("═".repeat(76));
      alertLines.push("");
      for (const a of tornadoAlerts) {
        alertLines.push(`[${a.createdAt}] ${a.message}`);
        if (a.walletAddress && a.walletAddress !== "system") alertLines.push(`  Wallet: ${a.walletAddress}`);
        const d = a.details as Record<string, any> | null;
        if (d?.txHash) alertLines.push(`  TX: ${d.txHash}`);
        if (d?.contractAddress) alertLines.push(`  Contract: ${d.contractAddress}`);
        if (d?.pool) alertLines.push(`  Pool: ${d.pool}`);
        alertLines.push("");
      }
    }

    if (moneroAlerts.length > 0) {
      alertLines.push("═".repeat(76));
      alertLines.push(`MONERO ON-RAMP CONVERSIONS (${moneroAlerts.length} DETECTED)`);
      alertLines.push("═".repeat(76));
      alertLines.push("");
      for (const a of moneroAlerts) {
        alertLines.push(`[${a.createdAt}] ${a.message}`);
        if (a.walletAddress && a.walletAddress !== "system") alertLines.push(`  Wallet: ${a.walletAddress}`);
        alertLines.push("");
      }
    }

    if (unfreezeAlerts.length > 0) {
      alertLines.push("═".repeat(76));
      alertLines.push(`UNFREEZABLE TOKEN MOVEMENTS (${unfreezeAlerts.length} DETECTED)`);
      alertLines.push("═".repeat(76));
      alertLines.push("");
      for (const a of unfreezeAlerts) {
        alertLines.push(`[${a.createdAt}] ${a.message}`);
        if (a.walletAddress && a.walletAddress !== "system") alertLines.push(`  Wallet: ${a.walletAddress}`);
        alertLines.push("");
      }
    }

    const returnAlerts = alerts.filter(a => a.alertType === "return_to_victim" || a.alertType === "token_returned_to_victim");
    if (returnAlerts.length > 0) {
      alertLines.push("═".repeat(76));
      alertLines.push(`FUNDS RETURNED TO VICTIM (${returnAlerts.length})`);
      alertLines.push("═".repeat(76));
      alertLines.push("");
      for (const a of returnAlerts) {
        alertLines.push(`[${a.createdAt}] ${a.message}`);
        const d = a.details as Record<string, any> | null;
        if (d?.txHash) alertLines.push(`  TX: ${d.txHash}`);
        if (d?.amount) alertLines.push(`  Amount: ${d.amount}`);
        alertLines.push("");
      }
    }

    const criticalAlerts = alerts.filter(a => a.severity === "critical");
    if (criticalAlerts.length > 0) {
      alertLines.push("═".repeat(76));
      alertLines.push(`CRITICAL SEVERITY ALERTS (${criticalAlerts.length})`);
      alertLines.push("═".repeat(76));
      alertLines.push("");
      for (const a of criticalAlerts) {
        alertLines.push(`[${a.createdAt}] [${a.alertType}] ${a.message}`);
        if (a.walletAddress && a.walletAddress !== "system") alertLines.push(`  Wallet: ${a.walletAddress}`);
        alertLines.push("");
      }
    }

    const alertCsvRows = ["Timestamp,Alert_Type,Severity,Message,Wallet_Address"];
    for (const a of alerts) {
      const escapedMsg = (a.message || "").replace(/"/g, '""');
      alertCsvRows.push(`"${a.createdAt}","${a.alertType}","${a.severity}","${escapedMsg}","${a.walletAddress || ""}"`);
    }
    const alertCsv = alertCsvRows.join("\n");
    const alertReport = alertLines.join("\n");

    const alertCsvSize = Buffer.byteLength(alertCsv);
    console.log(`  Alert report: ${alertLines.length} lines, Alert CSV: ${alertCsvRows.length} rows (${(alertCsvSize / 1024 / 1024).toFixed(2)} MB)`);

    if (alertCsvSize > 5 * 1024 * 1024) {
      const ok1 = await sendEmail(sgKey,
        `FORENSIC REPORT 4/4a — Alert Analysis (Tornado Cash, Monero, Critical) — ${dateStr}`,
        alertReport,
        [{
          content: Buffer.from(alertReport).toString("base64"),
          filename: `sillytuna_alert_analysis_${dateStr}.txt`,
          type: "text/plain"
        }]
      );
      if (ok1) sent++; else failed++;
      await new Promise(r => setTimeout(r, 2000));

      const header = alertCsvRows[0];
      const dataRows = alertCsvRows.slice(1);
      const half = Math.ceil(dataRows.length / 2);
      for (let i = 0; i < 2; i++) {
        const chunk = dataRows.slice(i * half, (i + 1) * half);
        const partCsv = [header, ...chunk].join("\n");
        const ok = await sendEmail(sgKey,
          `FORENSIC REPORT 4/4b — All Alerts CSV Part ${i + 1}/2 — ${dateStr}`,
          `Part ${i + 1}/2 of the complete alerts CSV (${chunk.length} of ${dataRows.length} alerts).`,
          [{
            content: Buffer.from(partCsv).toString("base64"),
            filename: `sillytuna_alerts_part${i + 1}of2_${dateStr}.csv`,
            type: "text/csv"
          }]
        );
        if (ok) sent++; else failed++;
        if (i === 0) await new Promise(r => setTimeout(r, 2000));
      }
    } else {
      const ok = await sendEmail(sgKey,
        `FORENSIC REPORT 4/4 — All ${alerts.length} Alerts (Tornado Cash, Monero, Critical) — ${dateStr}`,
        alertReport,
        [
          {
            content: Buffer.from(alertReport).toString("base64"),
            filename: `sillytuna_alert_analysis_${dateStr}.txt`,
            type: "text/plain"
          },
          {
            content: Buffer.from(alertCsv).toString("base64"),
            filename: `sillytuna_${alerts.length}_alerts_${dateStr}.csv`,
            type: "text/csv"
          }
        ]
      );
      if (ok) sent++; else failed++;
    }
  }

  console.log(`\n${"═".repeat(50)}`);
  console.log(`REPORT DELIVERY COMPLETE`);
  console.log(`Sent: ${sent} emails | Failed: ${failed}`);
  console.log(`Recipient: ${RECIPIENT}`);
  console.log(`${"═".repeat(50)}`);

  try {
    await db.insert(forensicAlerts).values({
      caseId: CASE_ID,
      alertType: "comprehensive_report_sent",
      severity: "info",
      message: `Multi-part forensic report sent to ${RECIPIENT}: ${wallets.length} wallets, ${allTxs.length} traced txs, ${alerts.length} alerts across ${sent} emails`,
      walletAddress: "system",
      details: { recipient: RECIPIENT, walletCount: wallets.length, txCount: allTxs.length, alertCount: alerts.length, emailsSent: sent, timestamp: now }
    });
  } catch {}

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
