import { getUncachableSendGridClient } from "../services/sendgridService.js";

async function main() {
  const { client: sgClient, fromEmail } = await getUncachableSendGridClient();

  const sealApiKey = process.env.SEAL_API_KEY || "";
  const domain = process.env.REPLIT_DOMAINS?.split(",")[0] || "";
  const baseUrl = "https://" + domain;
  const now = new Date().toISOString();

  const sealHtml = `<!DOCTYPE html>
<html><head><style>
body{background:#0A1628;color:#E2E8F0;font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0}
.container{max-width:880px;margin:0 auto;padding:28px}
.hdr{background:linear-gradient(135deg,#1E3A5F 0%,#0D2137 100%);border:2px solid #00D4FF;border-radius:12px;padding:30px;margin-bottom:28px;text-align:center}
.hdr h1{color:#FFF;font-size:24px;margin:0 0 8px;letter-spacing:2px}
.hdr h2{color:#86EFAC;font-size:15px;margin:0 0 6px;font-weight:normal}
.hdr .sub{color:#94A3B8;font-size:11px}
.sec{background:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:22px;margin-bottom:18px}
.sec h3{color:#00D4FF;font-size:15px;margin:0 0 14px;border-bottom:1px solid #1E3A5F;padding-bottom:8px}
.sec h4{color:#FFD700;font-size:13px;margin:16px 0 8px}
.addr{font-family:'Courier New',monospace;font-size:11px;color:#FFD700;word-break:break-all;background:#1E293B;padding:4px 8px;border-radius:4px;display:inline-block}
.code{font-family:'Courier New',monospace;font-size:11px;color:#22C55E;background:#0F172A;padding:14px 18px;border-radius:6px;border:1px solid #1E3A5F;white-space:pre-wrap;line-height:1.6;margin:8px 0}
.alert{background:#14532D22;border:1px solid #22C55E;border-radius:8px;padding:18px;margin-bottom:18px}
.alert h3{color:#22C55E;border-bottom-color:#22C55E33}
.warn{background:#7F1D1D22;border:1px solid #EF4444;border-radius:8px;padding:18px;margin-bottom:18px}
.warn h3{color:#EF4444;border-bottom-color:#EF444433}
.pitch{background:#1E293B;border:2px solid #FFD700;border-radius:8px;padding:22px;margin-bottom:18px}
.pitch h3{color:#FFD700;font-size:16px;margin:0 0 14px;border-bottom:1px solid #FFD70044;padding-bottom:8px}
.endpoint{background:#1E293B;border-radius:6px;padding:10px 14px;margin:6px 0}
.method{background:#22C55E;color:#000;font-size:10px;font-weight:bold;padding:2px 8px;border-radius:3px;font-family:monospace;display:inline-block;margin-right:8px}
.method-post{background:#F59E0B}
.method-del{background:#EF4444;color:#FFF}
.path{font-family:monospace;font-size:12px;color:#E2E8F0}
.desc{font-size:11px;color:#94A3B8;display:block;margin-top:4px}
p{font-size:13px;line-height:1.7;margin:8px 0}
ul{padding-left:20px}
li{font-size:12px;margin:5px 0;line-height:1.6}
.ft{text-align:center;color:#64748B;font-size:10px;margin-top:24px;padding-top:16px;border-top:1px solid #1E3A5F}
a{color:#00D4FF;text-decoration:none}
.key-box{background:#14532D;border:2px solid #22C55E;border-radius:8px;padding:18px;text-align:center;margin:14px 0}
.key-box .label{color:#86EFAC;font-size:11px;margin-bottom:6px}
.key-box .key{font-family:'Courier New',monospace;font-size:15px;color:#FFF;letter-spacing:1px}
table{width:100%;border-collapse:collapse}
th{background:#1E293B;color:#00D4FF;font-size:10px;padding:8px;text-align:left;border:1px solid #1E3A5F}
td{padding:8px;font-size:11px;border:1px solid #1E3A5F;color:#E2E8F0}
.btn{display:inline-block;background:linear-gradient(135deg,#22C55E,#16A34A);color:#FFF;padding:12px 24px;border-radius:8px;font-size:13px;font-weight:bold;text-decoration:none;margin:6px 4px;letter-spacing:0.5px}
.btn-blue{background:linear-gradient(135deg,#0EA5E9,#0284C7)}
.btn-amber{background:linear-gradient(135deg,#F59E0B,#D97706);color:#000}
</style></head><body><div class="container">

<div class="hdr">
<h1>SEAL TEAM — DAU BEACON INTELLIGENCE BRIEFING</h1>
<h2>API Access, Download Tools, and DAU Forensic Tracking Platform</h2>
<div class="sub">Alpha Unlimited Trading — Forensic Intelligence Division | From: alphaunlimitedtoken@gmail.com | ${now}</div>
</div>

<div class="alert">
<h3>EXECUTIVE SUMMARY</h3>
<p>We are providing your team with <strong>full API access</strong> to monitor the <strong>DAU (Digital Asset Unit)</strong> — a specialized ERC-20 forensic tracking coin that we deployed directly into a confirmed attacker wallet connected to the @sillytuna / Alex Amsel EIP-7702 exploit (~$26M stolen). This email contains your API key, connection instructions, download links, and an overview of what DAU is, how it works, and why it can be a valuable tool for SEAL investigations going forward.</p>
</div>

<div class="pitch">
<h3>WHAT IS DAU? — THE DIGITAL ASSET UNIT</h3>
<p>The <strong>DAU (Digital Asset Unit)</strong> is a forensic tracking coin built by Alpha Unlimited specifically for blockchain security and criminal investigation. It is an ERC-20 token deployed on Ethereum Mainnet.</p>
<p>Here is what it does in simple terms:</p>
<ul>
<li><strong>It's a tracking beacon disguised as a regular token.</strong> We can send DAU to any wallet address on Ethereum. Once it arrives, it acts as a persistent marker — sitting in the target's token list, recording every interaction on-chain permanently.</li>
<li><strong>We sent it directly into the attacker's wallet.</strong> We airdropped 13.793624 DAU to a confirmed hop-4 endpoint wallet (<span class="addr">0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3</span>) that has processed over $13 million in stolen funds. The attacker did not request it — it simply appeared among their token holdings.</li>
<li><strong>It enables real-time surveillance from the inside.</strong> Because DAU is on the Ethereum blockchain, we can monitor the target wallet 24/7. Our systems check for activity every 5 minutes. If the attacker moves ETH, stablecoins, or any other asset — we see it immediately, including where it went and how much.</li>
<li><strong>If they move the DAU itself, we follow it.</strong> If the attacker transfers the DAU token to another wallet — intentionally or accidentally — we instantly know the new wallet address, giving us the next hop in their laundering chain. The beacon follows the money.</li>
<li><strong>It's difficult to remove without leaving evidence.</strong> To get rid of the DAU, the attacker would have to interact with our smart contract on-chain, which creates another permanent breadcrumb. If they ignore it, it sits there silently while we monitor everything else happening in the wallet.</li>
</ul>
</div>

<div class="sec">
<h3>WHY SEAL SHOULD USE DAU FOR FUTURE INVESTIGATIONS</h3>
<p>The DAU coin was built specifically for organizations like SEAL. Here is why it matters:</p>
<ul>
<li><strong>Instant deployment to any wallet.</strong> We can send DAU to any Ethereum address within minutes. No cooperation from the target needed. No court order to get in — it's a standard ERC-20 transfer on a public blockchain.</li>
<li><strong>Persistent tracking that can't be turned off.</strong> Unlike off-chain monitoring tools that depend on API rate limits or third-party services, DAU lives on the blockchain itself. As long as Ethereum exists, the tracking record exists.</li>
<li><strong>Automated 24/7 surveillance.</strong> Once DAU is in a target wallet, our Auto-Pivot Surveillance Engine monitors it around the clock. Any movement triggers instant alerts — email, webhook push, or API query.</li>
<li><strong>Follow-the-money automation.</strong> If funds move from a DAU-tagged wallet to a new address, the system can automatically begin monitoring the new address too. The surveillance net expands with the money trail.</li>
<li><strong>Chain of custody documentation.</strong> Every transfer is recorded on Ethereum with immutable timestamps, transaction hashes, and block numbers — ready for use as evidence in legal proceedings.</li>
<li><strong>Works alongside your existing tools.</strong> DAU doesn't replace your investigation workflow — it adds a layer of persistent on-chain surveillance that runs independently. The API we provide lets your systems pull data whenever you need it.</li>
<li><strong>Scalable to any number of cases.</strong> We can deploy DAU to multiple wallets across multiple investigations simultaneously. Each deployment gets its own surveillance feed accessible via the same API.</li>
</ul>
<p style="color:#FFD700;font-weight:bold;margin-top:14px">We believe DAU can become a standard tool in SEAL's toolkit for tracking stolen funds across the Ethereum ecosystem. We are offering this capability to your team and are ready to deploy DAU on any future case where it would be useful.</p>
</div>

<div class="warn">
<h3>CURRENT CASE: WHAT WE FOUND</h3>
<p>The target wallet (<span class="addr">0xf576...59f3</span>) has been under our surveillance since the DAU deployment. Key findings:</p>
<ul>
<li><strong>75 outbound transactions</strong>, 100+ inbound transfers — the wallet is actively used for laundering</li>
<li><strong>$13M+ total outflow</strong> in USDT, USDC, and ETH sent to 3 automated cashout wallets</li>
<li>All 3 cashout wallets share the prefix <code style="color:#FFD700">0x8e0</code> — same attacker, automated splitting script</li>
<li>Cashout wallets use <strong>mirror-pair pattern</strong>: $499K chunks of USDT alternating between two addresses</li>
<li>Primary cashout wallet holds <strong>2,065 ETH</strong> — still active as of March 20, 2026</li>
<li>Primary funding source: <span class="addr">0xddbda8094c5523d64db7104925b594834d2a6dc9</span></li>
</ul>
<p>We are monitoring <strong>8 wallets total</strong> across the attack chain, from the initial attacker wallet all the way to the final cashout endpoints. Full details available via the API.</p>
</div>

<div class="sec">
<h3>DAU DEPLOYMENT DETAILS</h3>
<table>
<tr><th>Field</th><th>Value</th></tr>
<tr><td>DAU Contract</td><td><span class="addr">0xAB403962C943e3335903824BB2880A219858C5CC</span></td></tr>
<tr><td>Network</td><td>Ethereum Mainnet</td></tr>
<tr><td>Target Wallet</td><td><span class="addr">0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3</span></td></tr>
<tr><td>DAU Balance</td><td><strong style="color:#22C55E">13.793624 DAU — CONFIRMED PRESENT</strong></td></tr>
<tr><td>Deployment TX</td><td><a href="https://etherscan.io/tx/0x8d4bdfc8b498b677ae4b6bf44d3f0e1f467afcbe206f7801f231461dec2699b9">View on Etherscan</a></td></tr>
<tr><td>Token Page</td><td><a href="https://etherscan.io/token/0xAB403962C943e3335903824BB2880A219858C5CC">View Token on Etherscan</a></td></tr>
</table>
</div>

<div class="alert">
<h3>YOUR API ACCESS</h3>
<p>We've built a dedicated REST API for your team. No login required — just use the API key below. All data is pulled live from Ethereum Mainnet in real-time.</p>

<div class="key-box">
<div class="label">YOUR SEAL API KEY</div>
<div class="key">${sealApiKey}</div>
</div>

<h4>Base URL:</h4>
<p><span class="addr">${baseUrl}</span></p>

<h4>Authentication — 3 Ways:</h4>
<div class="code">// Header (recommended):
X-SEAL-API-KEY: ${sealApiKey}

// Bearer token:
Authorization: Bearer ${sealApiKey}

// Query parameter:
?apiKey=${sealApiKey}</div>
</div>

<div class="sec">
<h3>API ENDPOINTS</h3>

<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/docs</span><span class="desc">Full API documentation (no auth needed)</span></div>
<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/status</span><span class="desc">Live DAU beacon check — is the token still in the wallet? ETH balance, TX count, surveillance status</span></div>
<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/transfers?direction=both&amp;limit=50</span><span class="desc">All transfers in/out of target wallet with TX hashes and Etherscan links</span></div>
<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/tokens</span><span class="desc">All token holdings in the target wallet with metadata</span></div>
<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/network</span><span class="desc">Full surveillance network — all 8 monitored wallets and the complete attack chain</span></div>
<div class="endpoint"><span class="method method-post">POST</span><span class="path">/api/seal/dau/webhook</span><span class="desc">Register a webhook for push alerts. Body: {"url": "https://...", "label": "SEAL"}</span></div>
<div class="endpoint"><span class="method">GET</span><span class="path">/api/seal/dau/webhooks</span><span class="desc">List your registered webhooks</span></div>
<div class="endpoint"><span class="method method-del">DEL</span><span class="path">/api/seal/dau/webhook</span><span class="desc">Remove a webhook</span></div>
</div>

<div class="sec">
<h3>DOWNLOAD DATA FILES</h3>
<p>Click the buttons below to download the latest intelligence data directly. These links pull <strong>live data from the blockchain</strong> at the moment you click — always up to date.</p>

<p style="text-align:center;margin:20px 0">
<a href="${baseUrl}/api/seal/dau/download/full-report?apiKey=${sealApiKey}" class="btn">Download Full JSON Report</a>
<a href="${baseUrl}/api/seal/dau/download/transfers-csv?apiKey=${sealApiKey}" class="btn btn-blue">Download All Transfers (CSV)</a>
<a href="${baseUrl}/api/seal/dau/download/transfers-csv?direction=outbound&apiKey=${sealApiKey}" class="btn btn-amber">Download Outbound Only (CSV)</a>
</p>

<p style="font-size:11px;color:#94A3B8;text-align:center">Full JSON report includes: DAU status, wallet balances, all token holdings, complete transfer history, attack chain map, and surveillance network data.<br/>CSV files can be opened in Excel, Google Sheets, or any analysis tool.</p>
</div>

<div class="sec">
<h3>QUICK START — TRY IT NOW</h3>
<p>Copy and paste these commands into your terminal to verify the API is working:</p>

<h4>1. Check if DAU is still in the wallet:</h4>
<div class="code">curl -s -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  "${baseUrl}/api/seal/dau/status" | python3 -m json.tool</div>

<h4>2. View the full attack chain and all monitored wallets:</h4>
<div class="code">curl -s -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  "${baseUrl}/api/seal/dau/network" | python3 -m json.tool</div>

<h4>3. Get recent outbound transfers (where money went):</h4>
<div class="code">curl -s -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  "${baseUrl}/api/seal/dau/transfers?direction=outbound&amp;limit=20" | python3 -m json.tool</div>

<h4>4. Download full report as a file:</h4>
<div class="code">curl -s -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  "${baseUrl}/api/seal/dau/download/full-report" -o seal_dau_report.json</div>

<h4>5. Download transfers as CSV:</h4>
<div class="code">curl -s -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  "${baseUrl}/api/seal/dau/download/transfers-csv" -o transfers.csv</div>

<h4>6. Register a webhook to receive push alerts:</h4>
<div class="code">curl -s -X POST -H "X-SEAL-API-KEY: ${sealApiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{"url": "https://your-server.com/webhook", "label": "SEAL Monitor"}' \\
  "${baseUrl}/api/seal/dau/webhook"</div>
</div>

<div class="sec">
<h3>CONTACT</h3>
<p>This API and DAU deployment is provided by <strong>Alpha Unlimited Trading — Forensic Intelligence Division</strong>.</p>
<p>We are ready to deploy DAU on any future case where persistent on-chain surveillance would be valuable to SEAL's mission. If your team needs DAU tracking on additional wallets or investigations, reach out and we can have a beacon deployed within minutes.</p>
<p>Email: <a href="mailto:alphaunlimitedtoken@gmail.com">alphaunlimitedtoken@gmail.com</a></p>
<p>Phone: +1 (419) 376-6224</p>
<p>Current Case ID: 306db48a-36e2-42c1-9d7c-3b49d5bfdb49</p>
</div>

<div class="ft">
CONFIDENTIAL — For authorized SEAL Team members only<br/>
Alpha Unlimited Trading | Forensic Intelligence Division<br/>
alphaunlimitedtoken@gmail.com | ${now}
</div>
</div></body></html>`;

  const sealText = `SEAL TEAM — DAU BEACON INTELLIGENCE BRIEFING
API Access, Download Tools, and DAU Forensic Tracking Platform
${"=".repeat(65)}
From: alphaunlimitedtoken@gmail.com
Generated: ${now}

EXECUTIVE SUMMARY:
We are providing your team with full API access to monitor the DAU (Digital Asset Unit) — a specialized ERC-20 forensic tracking coin deployed directly into a confirmed attacker wallet connected to the @sillytuna EIP-7702 exploit (~$26M stolen).

WHAT IS DAU?
The DAU (Digital Asset Unit) is a forensic tracking coin built by Alpha Unlimited for blockchain security and criminal investigation.

- It's a tracking beacon disguised as a regular token. We send it to any wallet, and once there, it acts as a persistent marker.
- We airdropped 13.793624 DAU to attacker wallet 0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3 (~$13M+ in stolen funds passed through it).
- It enables real-time surveillance from inside the wallet. Our systems check every 5 minutes, 24/7.
- If they move the DAU, we follow it to the new wallet instantly.
- It's difficult to remove without leaving more on-chain evidence.

WHY SEAL SHOULD USE DAU FOR FUTURE INVESTIGATIONS:
- Instant deployment to any Ethereum wallet within minutes
- Persistent tracking on-chain that can't be turned off
- Automated 24/7 surveillance with email/webhook alerts
- Follow-the-money automation — surveillance net expands with the trail
- Chain of custody documentation ready for legal proceedings
- Works alongside your existing tools via REST API
- Scalable to any number of simultaneous cases

We believe DAU can become a standard tool in SEAL's toolkit for tracking stolen funds. We are offering this capability and are ready to deploy on any future case.

${"=".repeat(65)}
YOUR API ACCESS
${"=".repeat(65)}

API KEY: ${sealApiKey}
BASE URL: ${baseUrl}

AUTH: X-SEAL-API-KEY header, Authorization: Bearer, or ?apiKey= query param

ENDPOINTS:
  GET  /api/seal/dau/docs                    — API docs (no auth)
  GET  /api/seal/dau/status                  — Live DAU beacon status
  GET  /api/seal/dau/transfers               — All transfers (?direction=&limit=)
  GET  /api/seal/dau/tokens                  — All token holdings
  GET  /api/seal/dau/network                 — Full attack chain + surveillance network
  POST /api/seal/dau/webhook                 — Register push webhook
  GET  /api/seal/dau/webhooks                — List webhooks
  DEL  /api/seal/dau/webhook                 — Remove webhook
  GET  /api/seal/dau/download/full-report    — Download complete JSON report
  GET  /api/seal/dau/download/transfers-csv  — Download transfers as CSV

DOWNLOAD LINKS (click or paste in browser):
  Full JSON Report: ${baseUrl}/api/seal/dau/download/full-report?apiKey=${sealApiKey}
  All Transfers CSV: ${baseUrl}/api/seal/dau/download/transfers-csv?apiKey=${sealApiKey}
  Outbound Only CSV: ${baseUrl}/api/seal/dau/download/transfers-csv?direction=outbound&apiKey=${sealApiKey}

QUICK TEST:
  curl -H "X-SEAL-API-KEY: ${sealApiKey}" "${baseUrl}/api/seal/dau/status"

CURRENT CASE FINDINGS:
- Target wallet: 0xf576...59f3 | 75 TXs | $13M+ outflow
- 3 cashout wallets (prefix 0x8e0) using automated $499K mirror splits
- Primary cashout holds 2,065 ETH — active Mar 20
- 8 wallets monitored 24/7

DAU CONTRACT: 0xAB403962C943e3335903824BB2880A219858C5CC
DEPLOY TX: https://etherscan.io/tx/0x8d4bdfc8b498b677ae4b6bf44d3f0e1f467afcbe206f7801f231461dec2699b9

CONTACT:
Alpha Unlimited Trading — Forensic Intelligence Division
Email: alphaunlimitedtoken@gmail.com
Phone: +1 (419) 376-6224
Case ID: 306db48a-36e2-42c1-9d7c-3b49d5bfdb49

Ready to deploy DAU on any future case. Reach out anytime.

CONFIDENTIAL — Alpha Unlimited Trading | Forensic Intelligence Division`;

  console.log("Sending SEAL team DAU briefing with API access and download links...");
  await sgClient.send({
    to: "tips@securityalliance.org",
    from: { email: fromEmail, name: "Alpha Unlimited — Forensic Intelligence" },
    subject: "SEAL API Access: DAU Forensic Tracking Coin — Live Monitoring, Data Downloads, Webhook Alerts — Case 306db48a",
    content: [
      { type: "text/plain", value: sealText },
      { type: "text/html", value: sealHtml },
    ],
  });
  console.log("SENT to tips@securityalliance.org");
}

main().catch((e) => {
  console.error("ERROR:", e.message);
  process.exit(1);
});
