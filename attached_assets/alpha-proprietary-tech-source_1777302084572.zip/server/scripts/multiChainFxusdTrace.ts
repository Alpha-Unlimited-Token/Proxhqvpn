/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_MULTICHAIN_FXUSD_TRACE_v3.0
 * ALPHA_INTEGRITY_SEAL: AUT_MultiChainTrace_Calibration_PROTECTED
 * 
 * Multi-chain FXUSD deep tracer — follows every token hop across every blockchain
 */

import * as fs from "fs";
import fetch from "node-fetch";
import { db } from "../db.js";
import { monitoredWallets, forensicAlerts } from "../../shared/models/forensic.js";
import { eq } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const DELAY = 400;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// All blockscout-compatible chain APIs
const CHAINS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  avalanche: "https://avax.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
};

// Known case wallets (seed wallets)
const SEED_WALLETS = [
  { addr: "0xd14f4b36e1d1d98c218db782c49149876042bc56", label: "FXUSD SOURCE", chain: "ethereum" },
  { addr: "0x6818809eefce719e480a7526d76bd3e561526b46", label: "RELAY PROXY", chain: "ethereum" },
  { addr: "0x658370618bbc885865df66c1061bfe4771fad846", label: "CRYPTO.COM SUSPECT", chain: "ethereum" },
  { addr: "0xf70da97812cb96acdf810712aa562db8dfa3dbef", label: "POI ($4.35M)", chain: "ethereum" },
  { addr: "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb", label: "SOURCE EIP-7702", chain: "ethereum" },
  { addr: "0xb01fed2f701695992a4f7ffdb53f3af099e140d7", label: "GAS FUNDER", chain: "ethereum" },
  { addr: "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872", label: "LAUNDERING HUB ($20M)", chain: "ethereum" },
  { addr: "0x423d2b61952d56358db8b313ec7404a9582d4865", label: "ORIGINAL FUNDER", chain: "ethereum" },
  { addr: "0x6fe0fab2164d8e0d03ad6a628e2af78624060322", label: "VICTIM PRIMARY", chain: "ethereum" },
  { addr: "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41", label: "VICTIM SECONDARY", chain: "ethereum" },
];

interface TokenTransfer {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: string;
  block: number;
  tokenAddress: string;
  tokenSymbol: string;
  tokenDecimals: number;
  chain: string;
  wallet: string;
}

interface NativeTx {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: string;
  block: number;
  method: string;
  chain: string;
  wallet: string;
}

async function fetchJSON(url: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AlphaForensic/3.0" }, timeout: 15000 } as any);
      if (r.status === 429) { await sleep(3000); continue; }
      if (r.status === 404) return null;
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(1500); }
  }
  return null;
}

async function getTokenTransfers(api: string, addr: string, chain: string): Promise<TokenTransfer[]> {
  const results: TokenTransfer[] = [];
  const laddr = addr.toLowerCase();
  let nextParams = "";
  let pages = 0;

  while (pages < 30) {
    const url = `${api}/addresses/${laddr}/token-transfers${nextParams ? "?" + nextParams : ""}`;
    const data = await fetchJSON(url);
    await sleep(DELAY);
    if (!data?.items?.length) break;

    for (const tt of data.items) {
      results.push({
        hash: tt.transaction_hash || tt.tx_hash || "",
        from: (tt.from?.hash || "").toLowerCase(),
        to: (tt.to?.hash || "").toLowerCase(),
        value: tt.total?.value || "0",
        timestamp: tt.timestamp || "",
        block: tt.block_number || 0,
        tokenAddress: (tt.token?.address || "").toLowerCase(),
        tokenSymbol: tt.token?.symbol || "???",
        tokenDecimals: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
        chain,
        wallet: laddr
      });
    }

    if (!data.next_page_params) break;
    nextParams = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  return results;
}

async function getNativeTxs(api: string, addr: string, chain: string): Promise<NativeTx[]> {
  const results: NativeTx[] = [];
  const laddr = addr.toLowerCase();
  let nextParams = "";
  let pages = 0;

  while (pages < 30) {
    const url = `${api}/addresses/${laddr}/transactions${nextParams ? "?" + nextParams : ""}`;
    const data = await fetchJSON(url);
    await sleep(DELAY);
    if (!data?.items?.length) break;

    for (const tx of data.items) {
      results.push({
        hash: tx.hash,
        from: (tx.from?.hash || "").toLowerCase(),
        to: (tx.to?.hash || "").toLowerCase(),
        value: tx.value || "0",
        timestamp: tx.timestamp || "",
        block: tx.block || 0,
        method: tx.method || "",
        chain,
        wallet: laddr
      });
    }

    if (!data.next_page_params) break;
    nextParams = new URLSearchParams(data.next_page_params as any).toString();
    pages++;
  }
  return results;
}

async function checkAddressOnChain(api: string, addr: string): Promise<boolean> {
  const data = await fetchJSON(`${api}/addresses/${addr.toLowerCase()}`);
  await sleep(DELAY);
  if (!data) return false;
  const txCount = parseInt(data.transactions_count || "0");
  return txCount > 0;
}

function formatVal(val: string, dec: number = 18): string {
  if (!val || val === "0") return "0";
  const n = parseFloat(val) / Math.pow(10, dec);
  if (isNaN(n) || n === 0) return "0";
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(2) + "K";
  if (n >= 1) return n.toFixed(4);
  return n.toFixed(8);
}

async function main() {
  console.log("═".repeat(70));
  console.log("  MULTI-CHAIN FXUSD DEEP TRACER");
  console.log("  Scanning: " + Object.keys(CHAINS).join(", "));
  console.log("═".repeat(70));

  // Load DB wallets too
  const dbWallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  console.log(`[DB] ${dbWallets.length} wallets in database`);

  // Build seed set
  const labelMap = new Map<string, string>();
  const scannedOnChain = new Set<string>(); // "addr:chain" => already scanned
  const allAddrs = new Set<string>();

  for (const s of SEED_WALLETS) {
    allAddrs.add(s.addr.toLowerCase());
    labelMap.set(s.addr.toLowerCase(), s.label);
  }
  for (const w of dbWallets) {
    allAddrs.add(w.address.toLowerCase());
    if (w.label) labelMap.set(w.address.toLowerCase(), w.label);
  }

  console.log(`[Init] ${allAddrs.size} unique seed addresses`);

  const allTokenTransfers: TokenTransfer[] = [];
  const allNativeTxs: NativeTx[] = [];
  const discoveredAddrs = new Set<string>();
  const chainsUsed = new Set<string>();

  // Queue: [addr, chain] pairs to scan
  const queue: Array<{ addr: string; chain: string; depth: number }> = [];

  // Start: scan all seed wallets on Ethereum
  for (const addr of allAddrs) {
    queue.push({ addr, chain: "ethereum", depth: 0 });
  }
  // Also scan known Arbitrum activity
  for (const addr of allAddrs) {
    queue.push({ addr, chain: "arbitrum", depth: 0 });
  }

  let processed = 0;
  const MAX_DEPTH = 3; // follow hops up to 3 levels deep for new wallets
  const MAX_SCANS = 500; // safety limit

  while (queue.length > 0 && processed < MAX_SCANS) {
    const { addr, chain, depth } = queue.shift()!;
    const key = `${addr}:${chain}`;
    if (scannedOnChain.has(key)) continue;
    scannedOnChain.add(key);

    const api = CHAINS[chain];
    if (!api) continue;

    processed++;
    process.stdout.write(`\r[${processed}] ${chain.padEnd(10)} ${addr.slice(0, 12)}... (depth ${depth}, queue ${queue.length})    `);

    // Get token transfers
    const tokens = await getTokenTransfers(api, addr, chain);
    allTokenTransfers.push(...tokens);

    // Get native transactions
    const native = await getNativeTxs(api, addr, chain);
    allNativeTxs.push(...native);

    if (tokens.length > 0 || native.length > 0) {
      chainsUsed.add(chain);
    }

    // Discover new addresses from this wallet's activity
    const newAddrsHere = new Set<string>();
    for (const t of tokens) {
      if (t.from && t.from !== "0x0000000000000000000000000000000000000000") newAddrsHere.add(t.from);
      if (t.to && t.to !== "0x0000000000000000000000000000000000000000") newAddrsHere.add(t.to);
    }
    for (const t of native) {
      if (t.from) newAddrsHere.add(t.from);
      if (t.to) newAddrsHere.add(t.to);
    }

    // For depth 0 (our seed wallets), check if they exist on OTHER chains
    if (depth === 0) {
      for (const otherChain of Object.keys(CHAINS)) {
        if (otherChain === chain) continue;
        const otherKey = `${addr}:${otherChain}`;
        if (scannedOnChain.has(otherKey)) continue;
        // Check if address has activity on this chain
        const exists = await checkAddressOnChain(CHAINS[otherChain], addr);
        if (exists) {
          console.log(`\n  ✦ CROSS-CHAIN: ${addr.slice(0, 12)}... found on ${otherChain}!`);
          queue.push({ addr, chain: otherChain, depth: 0 });
        }
      }
    }

    // For new discovered addresses, add them to scan on same chain (up to MAX_DEPTH)
    if (depth < MAX_DEPTH) {
      for (const newAddr of newAddrsHere) {
        if (!allAddrs.has(newAddr) && !discoveredAddrs.has(newAddr)) {
          discoveredAddrs.add(newAddr);
          // Only follow if they interacted with a known case wallet
          queue.push({ addr: newAddr, chain, depth: depth + 1 });
        }
      }
    }
  }

  console.log(`\n\n[Scan Complete] ${processed} wallet-chain pairs scanned`);
  console.log(`[Chains with activity] ${[...chainsUsed].join(", ")}`);
  console.log(`[Token transfers] ${allTokenTransfers.length}`);
  console.log(`[Native TXs] ${allNativeTxs.length}`);
  console.log(`[Discovered addresses] ${discoveredAddrs.size}`);

  // Deduplicate
  const uniqueTokens = new Map<string, TokenTransfer>();
  for (const t of allTokenTransfers) {
    const key = `${t.hash}-${t.from}-${t.to}-${t.tokenSymbol}-${t.chain}`;
    if (!uniqueTokens.has(key)) uniqueTokens.set(key, t);
  }
  const uniqueNative = new Map<string, NativeTx>();
  for (const t of allNativeTxs) {
    const key = `${t.hash}-${t.from}-${t.to}-${t.chain}`;
    if (!uniqueNative.has(key)) uniqueNative.set(key, t);
  }

  const tokenList = [...uniqueTokens.values()].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  const nativeList = [...uniqueNative.values()].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  // New activity since last scan
  const lastScan = new Date("2026-03-08T02:00:00Z");
  const newTokenActivity = tokenList.filter(t => new Date(t.timestamp) > lastScan);
  const newNativeActivity = nativeList.filter(t => new Date(t.timestamp) > lastScan);

  // Token summary
  const tokenSummary = new Map<string, { count: number; totalVal: number; chains: Set<string>; senders: Set<string>; receivers: Set<string> }>();
  for (const t of tokenList) {
    if (!tokenSummary.has(t.tokenSymbol)) {
      tokenSummary.set(t.tokenSymbol, { count: 0, totalVal: 0, chains: new Set(), senders: new Set(), receivers: new Set() });
    }
    const s = tokenSummary.get(t.tokenSymbol)!;
    s.count++;
    s.totalVal += parseFloat(t.value) / Math.pow(10, t.tokenDecimals);
    s.chains.add(t.chain);
    s.senders.add(t.from);
    s.receivers.add(t.to);
  }

  // Build FXUSD-specific trace
  const fxusdTransfers = tokenList.filter(t => 
    t.tokenSymbol.toUpperCase().includes("FXUSD") || 
    t.tokenSymbol.toUpperCase().includes("FX") ||
    t.tokenAddress === "0x085780639cc2cacd35e5e36dc9a3e5f09f4a845c" // known FXUSD contract
  );

  // ═══════════ BUILD REPORT ═══════════
  let report = "";
  report += "═".repeat(90) + "\n";
  report += "  ALPHA FORENSIC INTELLIGENCE ENGINE — MULTI-CHAIN DEEP SCAN REPORT\n";
  report += "  Case: @sillytuna (Alex Amsel) ~$24M Theft\n";
  report += `  Generated: ${new Date().toISOString()}\n`;
  report += `  Case ID: ${CASE_ID}\n`;
  report += "═".repeat(90) + "\n\n";

  report += "SCAN PARAMETERS\n" + "─".repeat(60) + "\n";
  report += `  Chains Scanned: ${Object.keys(CHAINS).join(", ")}\n`;
  report += `  Chains With Activity: ${[...chainsUsed].join(", ")}\n`;
  report += `  Seed Wallets: ${allAddrs.size}\n`;
  report += `  Wallet-Chain Pairs Scanned: ${processed}\n`;
  report += `  Max Hop Depth: ${MAX_DEPTH}\n`;
  report += `  Unique Token Transfers: ${tokenList.length}\n`;
  report += `  Unique Native TXs: ${nativeList.length}\n`;
  report += `  Total Unique Transactions: ${tokenList.length + nativeList.length}\n`;
  report += `  New Addresses Discovered: ${discoveredAddrs.size}\n`;
  report += `  New Token Activity Since Last Scan: ${newTokenActivity.length}\n`;
  report += `  New Native Activity Since Last Scan: ${newNativeActivity.length}\n\n`;

  // ═══ NEW ACTIVITY ALERT ═══
  report += "═".repeat(90) + "\n";
  report += "  🚨 NEW ACTIVITY SINCE LAST SCAN (after 2026-03-08 02:00 UTC)\n";
  report += "═".repeat(90) + "\n\n";

  const allNew = [
    ...newTokenActivity.map(t => ({ ...t, txType: "TOKEN" as const })),
    ...newNativeActivity.map(t => ({ ...t, txType: "NATIVE" as const }))
  ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  if (allNew.length === 0) {
    report += "  No new transactions detected since last scan.\n\n";
  } else {
    report += `  ${allNew.length} new transactions detected!\n\n`;
    for (const tx of allNew) {
      if (tx.txType === "TOKEN") {
        const t = tx as TokenTransfer & { txType: string };
        report += `  [${t.chain.toUpperCase()}] ${t.timestamp} — ${t.tokenSymbol}\n`;
        report += `    TX: ${t.hash}\n`;
        report += `    FROM: ${t.from}${labelMap.has(t.from) ? " [" + labelMap.get(t.from) + "]" : ""}\n`;
        report += `    TO:   ${t.to}${labelMap.has(t.to) ? " [" + labelMap.get(t.to) + "]" : ""}\n`;
        report += `    VALUE: ${formatVal(t.value, t.tokenDecimals)} ${t.tokenSymbol}\n\n`;
      } else {
        const t = tx as NativeTx & { txType: string };
        report += `  [${t.chain.toUpperCase()}] ${t.timestamp} — NATIVE\n`;
        report += `    TX: ${t.hash}\n`;
        report += `    FROM: ${t.from}${labelMap.has(t.from) ? " [" + labelMap.get(t.from) + "]" : ""}\n`;
        report += `    TO:   ${t.to}${labelMap.has(t.to) ? " [" + labelMap.get(t.to) + "]" : ""}\n`;
        report += `    VALUE: ${formatVal(t.value)} ETH\n`;
        if ((t as NativeTx).method) report += `    METHOD: ${(t as NativeTx).method}\n`;
        report += "\n";
      }
    }
  }

  // ═══ FXUSD SPECIFIC TRACE ═══
  report += "═".repeat(90) + "\n";
  report += "  FXUSD TOKEN — COMPLETE TRACE ACROSS ALL CHAINS\n";
  report += "═".repeat(90) + "\n\n";

  if (fxusdTransfers.length === 0) {
    report += "  No FXUSD transfers found in scanned wallets.\n\n";
  } else {
    report += `  ${fxusdTransfers.length} FXUSD transfers traced\n\n`;
    for (const t of fxusdTransfers) {
      report += `  [${t.chain.toUpperCase()}] ${t.timestamp}\n`;
      report += `    TX: ${t.hash}\n`;
      report += `    FROM: ${t.from}${labelMap.has(t.from) ? " [" + labelMap.get(t.from) + "]" : ""}\n`;
      report += `    TO:   ${t.to}${labelMap.has(t.to) ? " [" + labelMap.get(t.to) + "]" : ""}\n`;
      report += `    VALUE: ${formatVal(t.value, t.tokenDecimals)} ${t.tokenSymbol}\n`;
      report += `    TOKEN CONTRACT: ${t.tokenAddress}\n\n`;
    }
  }

  // ═══ ALL TOKENS SUMMARY ═══
  report += "═".repeat(90) + "\n";
  report += "  ALL TOKENS TRACED — COMPLETE SUMMARY\n";
  report += "═".repeat(90) + "\n\n";

  const sortedTokenSummary = [...tokenSummary.entries()].sort((a, b) => b[1].totalVal - a[1].totalVal);
  for (const [sym, info] of sortedTokenSummary) {
    const valStr = info.totalVal >= 1e9 ? (info.totalVal / 1e9).toFixed(2) + "B" :
                   info.totalVal >= 1e6 ? (info.totalVal / 1e6).toFixed(2) + "M" :
                   info.totalVal >= 1e3 ? (info.totalVal / 1e3).toFixed(2) + "K" :
                   info.totalVal.toFixed(4);
    report += `  ${sym.padEnd(15)} ${valStr.padStart(15)} | ${info.count} transfers | Chains: ${[...info.chains].join(",")} | ${info.senders.size} senders → ${info.receivers.size} receivers\n`;
  }
  report += "\n";

  // ═══ PER-WALLET BREAKDOWN ═══
  report += "═".repeat(90) + "\n";
  report += "  PER-WALLET ACTIVITY — ALL CHAINS\n";
  report += "═".repeat(90) + "\n\n";

  // Group by wallet
  const walletActivity = new Map<string, { tokens: TokenTransfer[]; native: NativeTx[]; chains: Set<string> }>();
  for (const t of tokenList) {
    if (!walletActivity.has(t.wallet)) walletActivity.set(t.wallet, { tokens: [], native: [], chains: new Set() });
    walletActivity.get(t.wallet)!.tokens.push(t);
    walletActivity.get(t.wallet)!.chains.add(t.chain);
  }
  for (const t of nativeList) {
    if (!walletActivity.has(t.wallet)) walletActivity.set(t.wallet, { tokens: [], native: [], chains: new Set() });
    walletActivity.get(t.wallet)!.native.push(t);
    walletActivity.get(t.wallet)!.chains.add(t.chain);
  }

  const sortedWallets = [...walletActivity.entries()].sort((a, b) => (b[1].tokens.length + b[1].native.length) - (a[1].tokens.length + a[1].native.length));

  for (const [addr, data] of sortedWallets) {
    const label = labelMap.get(addr) || "";
    const total = data.tokens.length + data.native.length;
    const allTxTimestamps = [...data.tokens.map(t => t.timestamp), ...data.native.map(t => t.timestamp)].filter(Boolean).sort();
    const latest = allTxTimestamps[allTxTimestamps.length - 1] || "unknown";
    const earliest = allTxTimestamps[0] || "unknown";

    report += `  ${addr}${label ? " [" + label + "]" : ""}\n`;
    report += `    Chains: ${[...data.chains].join(", ")} | Total: ${total} (${data.native.length} native + ${data.tokens.length} token)\n`;
    report += `    Active: ${earliest.split("T")[0]} → ${latest.split("T")[0]}\n`;

    // Token breakdown
    const wTokens = new Map<string, { count: number; totalVal: number }>();
    for (const t of data.tokens) {
      if (!wTokens.has(t.tokenSymbol)) wTokens.set(t.tokenSymbol, { count: 0, totalVal: 0 });
      const w = wTokens.get(t.tokenSymbol)!;
      w.count++;
      w.totalVal += parseFloat(t.value) / Math.pow(10, t.tokenDecimals);
    }
    if (wTokens.size > 0) {
      const tokenParts = [...wTokens.entries()].map(([s, v]) => {
        const val = v.totalVal >= 1e6 ? (v.totalVal / 1e6).toFixed(1) + "M" : v.totalVal >= 1e3 ? (v.totalVal / 1e3).toFixed(1) + "K" : v.totalVal.toFixed(2);
        return `${s}: ${val} (${v.count} txs)`;
      });
      report += `    Tokens: ${tokenParts.join(" | ")}\n`;
    }

    // Destinations
    const dests = new Set<string>();
    const srcs = new Set<string>();
    for (const t of [...data.tokens, ...data.native]) {
      if (t.from === addr && t.to) dests.add(t.to);
      if (t.to === addr && t.from) srcs.add(t.from);
    }
    if (dests.size > 0) report += `    → Sent to ${dests.size} addresses\n`;
    if (srcs.size > 0) report += `    ← Received from ${srcs.size} addresses\n`;
    report += "\n";
  }

  // ═══ COMPLETE TOKEN TRANSFER LOG ═══
  report += "═".repeat(90) + "\n";
  report += `  COMPLETE TOKEN TRANSFER LOG (${tokenList.length} transfers, chronological)\n`;
  report += "═".repeat(90) + "\n\n";

  for (const t of tokenList) {
    const fromLabel = labelMap.has(t.from) ? ` [${labelMap.get(t.from)}]` : "";
    const toLabel = labelMap.has(t.to) ? ` [${labelMap.get(t.to)}]` : "";
    report += `[${t.chain.toUpperCase().padEnd(10)}] ${t.timestamp} | ${t.hash}\n`;
    report += `  ${t.from}${fromLabel} → ${t.to}${toLabel}\n`;
    report += `  ${formatVal(t.value, t.tokenDecimals)} ${t.tokenSymbol} (${t.tokenAddress})\n\n`;
  }

  // ═══ COMPLETE NATIVE TX LOG ═══
  report += "═".repeat(90) + "\n";
  report += `  COMPLETE NATIVE TRANSACTION LOG (${nativeList.length} transactions, chronological)\n`;
  report += "═".repeat(90) + "\n\n";

  for (const t of nativeList) {
    const fromLabel = labelMap.has(t.from) ? ` [${labelMap.get(t.from)}]` : "";
    const toLabel = labelMap.has(t.to) ? ` [${labelMap.get(t.to)}]` : "";
    report += `[${t.chain.toUpperCase().padEnd(10)}] ${t.timestamp} | ${t.hash}\n`;
    report += `  ${t.from}${fromLabel} → ${t.to}${toLabel}\n`;
    report += `  ${formatVal(t.value)} ETH${t.method ? " | " + t.method : ""}\n\n`;
  }

  // ═══ NEWLY DISCOVERED ADDRESSES ═══
  report += "═".repeat(90) + "\n";
  report += `  NEWLY DISCOVERED ADDRESSES (${discoveredAddrs.size})\n`;
  report += "═".repeat(90) + "\n\n";

  for (const addr of [...discoveredAddrs].sort()) {
    report += `  ${addr}\n`;
  }

  report += "\n" + "═".repeat(90) + "\n";
  report += "  END OF MULTI-CHAIN DEEP SCAN REPORT\n";
  report += "  Alpha Unlimited Trading Company — Forensic Intelligence Division\n";
  report += "  © 2024-2026 All Rights Reserved. PROPRIETARY AND CONFIDENTIAL\n";
  report += "═".repeat(90) + "\n";

  const outFile = "forensic_multichain_deep_scan.txt";
  fs.writeFileSync(outFile, report);
  const sizeKb = (fs.statSync(outFile).size / 1024).toFixed(1);
  console.log(`\n[Report] ${outFile} — ${sizeKb} KB`);
  console.log(`[Report] ${tokenList.length} token transfers + ${nativeList.length} native TXs = ${tokenList.length + nativeList.length} total`);
  console.log(`[Report] ${[...chainsUsed].join(", ")} chains with activity`);
  console.log(`[Report] New activity: ${allNew.length} transactions since last scan`);
  console.log(`[Report] ${discoveredAddrs.size} new addresses discovered`);

  // Save summary for next script
  fs.writeFileSync("/tmp/multichain_summary.json", JSON.stringify({
    totalTokenTransfers: tokenList.length,
    totalNativeTxs: nativeList.length,
    newActivityCount: allNew.length,
    chainsWithActivity: [...chainsUsed],
    discoveredAddresses: discoveredAddrs.size,
    reportFile: outFile,
    reportSizeKb: sizeKb
  }));

  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
