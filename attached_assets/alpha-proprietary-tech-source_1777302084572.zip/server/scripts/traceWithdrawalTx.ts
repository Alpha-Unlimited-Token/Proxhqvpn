import { db } from "../db.js";
import { sql } from "drizzle-orm";

const SMOKING_GUN_WALLET = "0x658370618bbc885865df66c1061bfe4771fad846";
const WITHDRAWAL_TX = "0x358a4d8cb1101fd3260d119c60ad2169bb9fb070344c6da2c76d3c87203e0e99";
const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function fetchJson(url: string) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.json();
  } catch { return null; }
}

async function main() {
  console.log("╔══════════════════════════════════════════════════════════════════╗");
  console.log("║  DEEP TRACE: WITHDRAWAL TX & SMOKING GUN WALLET               ║");
  console.log("╚══════════════════════════════════════════════════════════════════╝\n");

  // 1. Get the withdrawal transaction details
  console.log("═══════════════════════════════════════════════════════════════════");
  console.log("STEP 1: WITHDRAWAL TRANSACTION DETAILS");
  console.log("═══════════════════════════════════════════════════════════════════\n");
  
  const txData = await fetchJson(`https://eth.blockscout.com/api/v2/transactions/${WITHDRAWAL_TX}`);
  if (txData) {
    console.log(`TX Hash: ${txData.hash}`);
    console.log(`Block: ${txData.block_number}`);
    console.log(`Timestamp: ${txData.timestamp}`);
    console.log(`From: ${txData.from?.hash} ${txData.from?.name ? `(${txData.from.name})` : ''}`);
    console.log(`To: ${txData.to?.hash} ${txData.to?.name ? `(${txData.to.name})` : ''}`);
    console.log(`Value: ${txData.value ? (parseInt(txData.value) / 1e18).toFixed(8) : '0'} ETH`);
    console.log(`Gas Used: ${txData.gas_used}`);
    console.log(`Gas Price: ${txData.gas_price ? (parseInt(txData.gas_price) / 1e9).toFixed(2) : '?'} Gwei`);
    console.log(`Fee: ${txData.fee?.value ? (parseInt(txData.fee.value) / 1e18).toFixed(8) : '?'} ETH`);
    console.log(`Status: ${txData.status}`);
    console.log(`Nonce: ${txData.nonce}`);
    console.log(`Method: ${txData.method || txData.decoded_input?.method_call || 'transfer'}`);
  } else {
    console.log("Could not fetch TX details from Blockscout");
  }

  await new Promise(r => setTimeout(r, 500));

  // 2. All transactions for the smoking gun wallet
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 2: ALL TRANSACTIONS FOR SMOKING GUN WALLET");
  console.log(`         ${SMOKING_GUN_WALLET}`);
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const allTxs = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${SMOKING_GUN_WALLET}/transactions`);
  const txItems = allTxs?.items || [];
  console.log(`Total ETH transactions: ${txItems.length}\n`);

  const connectedAddresses = new Map<string, { label: string; ethIn: number; ethOut: number; txCount: number; firstSeen: string; lastSeen: string }>();

  for (const tx of txItems) {
    const from = tx.from?.hash?.toLowerCase() || "";
    const to = tx.to?.hash?.toLowerCase() || "";
    const val = tx.value ? parseInt(tx.value) / 1e18 : 0;
    const time = tx.timestamp || "";
    const walletLower = SMOKING_GUN_WALLET.toLowerCase();

    if (from === walletLower && to) {
      const label = tx.to?.name || tx.to?.ens_domain_name || "";
      if (!connectedAddresses.has(to)) connectedAddresses.set(to, { label, ethIn: 0, ethOut: 0, txCount: 0, firstSeen: time, lastSeen: time });
      const e = connectedAddresses.get(to)!;
      e.ethOut += val;
      e.txCount++;
      if (label) e.label = label;
      if (time < e.firstSeen) e.firstSeen = time;
      if (time > e.lastSeen) e.lastSeen = time;
      console.log(`  [${time}] SENT ${val.toFixed(8)} ETH to ${to} ${label ? `(${label})` : ''} | TX: ${tx.hash}`);
    }
    if (to === walletLower && from) {
      const label = tx.from?.name || tx.from?.ens_domain_name || "";
      if (!connectedAddresses.has(from)) connectedAddresses.set(from, { label, ethIn: 0, ethOut: 0, txCount: 0, firstSeen: time, lastSeen: time });
      const e = connectedAddresses.get(from)!;
      e.ethIn += val;
      e.txCount++;
      if (label) e.label = label;
      if (time < e.firstSeen) e.firstSeen = time;
      if (time > e.lastSeen) e.lastSeen = time;
      console.log(`  [${time}] RECEIVED ${val.toFixed(8)} ETH from ${from} ${label ? `(${label})` : ''} | TX: ${tx.hash}`);
    }
  }

  await new Promise(r => setTimeout(r, 500));

  // 3. All token transfers
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 3: ALL TOKEN TRANSFERS FOR SMOKING GUN WALLET");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const tokenTxs = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${SMOKING_GUN_WALLET}/token-transfers`);
  const tokenItems = tokenTxs?.items || [];
  console.log(`Total token transfers: ${tokenItems.length}\n`);

  for (const tt of tokenItems) {
    const from = tt.from?.hash?.toLowerCase() || "";
    const to = tt.to?.hash?.toLowerCase() || "";
    const symbol = tt.token?.symbol || "?";
    const decimals = parseInt(tt.token?.decimals || "18");
    const amount = tt.total?.value ? parseInt(tt.total.value) / Math.pow(10, decimals) : 0;
    const time = tt.timestamp || "";
    const walletLower = SMOKING_GUN_WALLET.toLowerCase();
    const dir = to === walletLower ? "IN" : "OUT";

    const otherAddr = dir === "IN" ? from : to;
    const otherLabel = dir === "IN" ? (tt.from?.name || tt.from?.ens_domain_name || "") : (tt.to?.name || tt.to?.ens_domain_name || "");

    if (otherAddr && otherAddr !== walletLower) {
      if (!connectedAddresses.has(otherAddr)) connectedAddresses.set(otherAddr, { label: otherLabel, ethIn: 0, ethOut: 0, txCount: 0, firstSeen: time, lastSeen: time });
      const e = connectedAddresses.get(otherAddr)!;
      e.txCount++;
      if (otherLabel) e.label = otherLabel;
      if (time && (!e.firstSeen || time < e.firstSeen)) e.firstSeen = time;
      if (time && time > e.lastSeen) e.lastSeen = time;
    }

    console.log(`  [${time}] ${dir}: ${amount.toFixed(4)} ${symbol} | From: ${from} ${tt.from?.name ? `(${tt.from.name})` : ''} -> To: ${to} ${tt.to?.name ? `(${tt.to.name})` : ''}`);
  }

  await new Promise(r => setTimeout(r, 500));

  // 4. Internal transactions (contract calls)
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 4: INTERNAL TRANSACTIONS (CONTRACT INTERACTIONS)");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const internalTxs = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${SMOKING_GUN_WALLET}/internal-transactions`);
  const internalItems = internalTxs?.items || [];
  console.log(`Total internal transactions: ${internalItems.length}\n`);

  for (const itx of internalItems) {
    const from = itx.from?.hash || "?";
    const to = itx.to?.hash || "?";
    const val = itx.value ? (parseInt(itx.value) / 1e18).toFixed(8) : "0";
    const fromLabel = itx.from?.name || "";
    const toLabel = itx.to?.name || "";
    console.log(`  ${from} ${fromLabel ? `(${fromLabel})` : ''} -> ${to} ${toLabel ? `(${toLabel})` : ''} | ${val} ETH | Type: ${itx.type || '?'}`);
  }

  // 5. Wallet balance and tokens
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 5: CURRENT WALLET STATE");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  const addrInfo = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${SMOKING_GUN_WALLET}`);
  if (addrInfo) {
    console.log(`Address: ${addrInfo.hash}`);
    console.log(`ETH Balance: ${addrInfo.coin_balance ? (parseInt(addrInfo.coin_balance) / 1e18).toFixed(8) : '0'} ETH`);
    console.log(`Is Contract: ${addrInfo.is_contract}`);
    console.log(`Is Verified: ${addrInfo.is_verified}`);
    console.log(`TX Count: ${addrInfo.transactions_count}`);
    console.log(`Token Transfers: ${addrInfo.token_transfers_count}`);
    console.log(`ENS: ${addrInfo.ens_domain_name || 'none'}`);
    console.log(`Name Tag: ${addrInfo.name || 'none'}`);
    if (addrInfo.creator_address_hash) console.log(`Created by: ${addrInfo.creator_address_hash}`);
  }

  await new Promise(r => setTimeout(r, 500));

  const tokenList = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${SMOKING_GUN_WALLET}/tokens`);
  const tokens = tokenList?.items || [];
  console.log(`\nToken Holdings (${tokens.length} tokens):`);
  for (const t of tokens) {
    const decimals = parseInt(t.token?.decimals || "18");
    const balance = t.value ? parseInt(t.value) / Math.pow(10, decimals) : 0;
    const symbol = t.token?.symbol || "?";
    const name = t.token?.name || "?";
    if (balance > 0.001) {
      console.log(`  ${balance.toFixed(4)} ${symbol} (${name})`);
    }
  }

  // 6. Now trace each connected address one level deeper
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 6: ALL CONNECTED ADDRESSES SUMMARY");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  console.log(`Found ${connectedAddresses.size} unique addresses connected to the smoking gun wallet:\n`);
  for (const [addr, data] of [...connectedAddresses.entries()].sort((a, b) => b[1].txCount - a[1].txCount)) {
    console.log(`  ${addr} ${data.label ? `(${data.label})` : ''}`);
    console.log(`    Transactions: ${data.txCount} | ETH In: ${data.ethIn.toFixed(6)} | ETH Out: ${data.ethOut.toFixed(6)}`);
    console.log(`    First: ${data.firstSeen} | Last: ${data.lastSeen}`);
  }

  // 7. Deep trace each connected address for labels/ENS/contracts
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 7: IDENTIFYING CONNECTED ADDRESSES");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  for (const [addr] of [...connectedAddresses.entries()]) {
    const info = await fetchJson(`https://eth.blockscout.com/api/v2/addresses/${addr}`);
    if (info) {
      const label = info.name || info.ens_domain_name || "";
      const isContract = info.is_contract;
      const txCount = info.transactions_count || 0;
      const balance = info.coin_balance ? (parseInt(info.coin_balance) / 1e18).toFixed(6) : "0";
      console.log(`  ${addr}`);
      if (label) console.log(`    IDENTIFIED: ${label}`);
      if (info.ens_domain_name) console.log(`    ENS: ${info.ens_domain_name}`);
      console.log(`    Contract: ${isContract} | TX Count: ${txCount} | Balance: ${balance} ETH`);
      if (info.creator_address_hash) console.log(`    Created by: ${info.creator_address_hash}`);
      console.log("");
    }
    await new Promise(r => setTimeout(r, 300));
  }

  // 8. Check if any connected addresses are in our case
  console.log("\n═══════════════════════════════════════════════════════════════════");
  console.log("STEP 8: CROSS-REFERENCE WITH CASE WALLETS");
  console.log("═══════════════════════════════════════════════════════════════════\n");

  for (const [addr, data] of connectedAddresses.entries()) {
    const match = await db.execute(sql`
      SELECT address, label, role, chain, last_known_balance_usd 
      FROM monitored_wallets 
      WHERE LOWER(address) = ${addr} AND case_id = ${CASE_ID}
    `);
    const rows = (match as any).rows || match;
    if (rows.length > 0) {
      const w = rows[0];
      console.log(`  MATCH: ${addr}`);
      console.log(`    Case Label: ${w.label}`);
      console.log(`    Role: ${w.role}`);
      console.log(`    Balance: $${w.last_known_balance_usd}`);
      console.log("");
    }
  }

  process.exit(0);
}
main();
