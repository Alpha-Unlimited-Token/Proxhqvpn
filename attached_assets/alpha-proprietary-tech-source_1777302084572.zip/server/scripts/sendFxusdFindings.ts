/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_FXUSD_SEND_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_FXUSD_Send_Calibration_PROTECTED
 *
 * Sends both chain trace reports to sillytuna as a ZIP file via SendGrid.
 * File 1: Original Crypto.com Chain Trace (the trace we used)
 * File 2: FXUSD Source Evidence Chain (traced through FXUSD source)
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENT_EMAIL = "sillytuna@gmail.com";
const LAW_ENFORCEMENT_URL = "https://alphaunlimitedtrading.com/law-enforcement-tech";

async function main() {
  console.log("[SendFXUSD] Preparing urgent Crypto.com findings for sillytuna...");

  const cryptoComTrace = path.resolve("forensic_crypto_com_chain_trace.txt");
  const fxusdTrace = path.resolve("forensic_fxusd_source_chain_trace.txt");

  if (!fs.existsSync(cryptoComTrace)) {
    console.error("[SendFXUSD] Missing: forensic_crypto_com_chain_trace.txt");
    process.exit(1);
  }
  if (!fs.existsSync(fxusdTrace)) {
    console.error("[SendFXUSD] Missing: forensic_fxusd_source_chain_trace.txt");
    process.exit(1);
  }

  const tmpDir = `/tmp/fxusd_findings_${Date.now()}`;
  const zipDir = path.join(tmpDir, "Urgent-CryptoCom-Findings");
  fs.mkdirSync(zipDir, { recursive: true });

  fs.copyFileSync(
    cryptoComTrace,
    path.join(zipDir, "[ORIGINAL-TRACE-USED] Crypto.com Full Chain Trace (3678 TXs).txt")
  );

  fs.copyFileSync(
    fxusdTrace,
    path.join(zipDir, "[TRACED-VIA-FXUSD-SOURCE] FXUSD Source to Crypto.com Evidence Chain.txt")
  );

  const zipPath = path.join(tmpDir, "Urgent-CryptoCom-Findings.zip");
  execSync(`cd "${tmpDir}" && zip -9 -r "${zipPath}" "Urgent-CryptoCom-Findings/"`, { timeout: 15000 });

  const zipBuffer = fs.readFileSync(zipPath);
  const zipBase64 = zipBuffer.toString("base64");
  const zipSizeKb = (zipBuffer.length / 1024).toFixed(1);
  console.log(`[SendFXUSD] ZIP created: ${zipSizeKb} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();
  console.log(`[SendFXUSD] Sending from ${fromEmail} to ${RECIPIENT_EMAIL}...`);

  const emailBody = `Dear @sillytuna,

URGENT — We have identified CRITICAL evidence linking stolen funds to a Crypto.com KYC-verified account.

This ZIP contains two forensic evidence chain trace files:

FILE 1: [ORIGINAL-TRACE-USED] Crypto.com Full Chain Trace (3678 TXs).txt
  This is the ORIGINAL trace we ran — 3,678 real on-chain transactions across 22 wallets.
  It traces from the victim wallet through all intermediary addresses to the Crypto.com wallet.
  This was our initial investigation trace that identified the Crypto.com connection.

FILE 2: [TRACED-VIA-FXUSD-SOURCE] FXUSD Source to Crypto.com Evidence Chain.txt
  This traces the FXUSD SOURCE address (0xD14F4B36E1D1D98c218db782c49149876042BC56)
  — the address known to your tracking team — through the relay proxy to the
  Crypto.com suspect wallet. All data pulled fresh from the Ethereum blockchain.
  This is the FXUSD-anchored evidence chain for law enforcement subpoena use.

KEY FINDINGS:
  • FXUSD SOURCE deposited 155,247.80 FXUSD into relay proxy (ERC1967Proxy)
  • Relay forwarded 155,092.55 FXUSD to Crypto.com Wallet (0x658370618BBc885865df66c1061BfE4771FaD846)
  • 72 seconds later: suspect swapped 155,092.55 FXUSD → 155,017.66 USDC via CoW Swap
  • KYC PROOF: Crypto.com Hot Wallet 2 (0x46340b20...) sent 0.0226 ETH to suspect wallet
  • This proves the suspect has a KYC-verified Crypto.com account — identity is on file

SUBPOENA TARGET: Crypto.com (Foris DAX MT Ltd.) — Malta/Singapore
  The suspect wallet received a direct withdrawal from a Crypto.com hot wallet.
  This is ONLY possible from a verified account. Crypto.com has the real identity.

GOING FORWARD: All future traces for your case will be anchored through the FXUSD SOURCE
address so everything flows from a verified starting point — no need to re-trace.

LAW ENFORCEMENT RESOURCES:
  Full technology briefing and additional downloads available at:
  ${LAW_ENFORCEMENT_URL}

All transaction hashes in these reports are on the Ethereum mainnet blockchain and can be
independently verified at https://etherscan.io or https://eth.blockscout.com.

This report is CONFIDENTIAL — for the victim and law enforcement only.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
© 2024-2026 All Rights Reserved`;

  await client.send({
    to: RECIPIENT_EMAIL,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: "URGENT — Crypto.com Findings: FXUSD Source Chain & KYC-Verified Suspect Wallet",
    text: emailBody,
    attachments: [{
      content: zipBase64,
      filename: `Urgent-CryptoCom-Findings-${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[SendFXUSD] ✓ Email sent to ${RECIPIENT_EMAIL} from ${fromEmail}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "report_sent",
    severity: "critical",
    message: `URGENT Crypto.com findings ZIP sent to ${RECIPIENT_EMAIL} from ${fromEmail} (${zipSizeKb} KB) — FXUSD Source Chain + Original Trace`,
    walletAddress: "system",
    details: {
      recipientEmail: RECIPIENT_EMAIL,
      fromAddress: fromEmail,
      zipSizeKb,
      files: [
        "[ORIGINAL-TRACE-USED] Crypto.com Full Chain Trace (3678 TXs).txt",
        "[TRACED-VIA-FXUSD-SOURCE] FXUSD Source to Crypto.com Evidence Chain.txt"
      ],
      lawEnforcementUrl: LAW_ENFORCEMENT_URL,
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmpDir, { recursive: true, force: true });
  console.log("[SendFXUSD] Done. Alert logged. Temp files cleaned.");
  process.exit(0);
}

main().catch(e => { console.error("[SendFXUSD] FATAL:", e); process.exit(1); });
