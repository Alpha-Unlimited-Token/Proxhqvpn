import { getUncachableSendGridClient } from "../services/sendgridService.js";

const NOW = new Date().toISOString();
const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function main() {
  const { client: sgClient, fromEmail } = await getUncachableSendGridClient();

  const htmlBody = `
<!DOCTYPE html>
<html>
<head></head>
<body style="background-color:#0A1628;color:#FFFFFF;font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0">
<div style="max-width:780px;margin:0 auto;padding:24px">

  <div style="background-color:#991B1B;border:2px solid #EF4444;border-radius:12px;padding:24px;margin-bottom:24px;text-align:center">
    <h1 style="color:#FFFFFF;font-size:22px;margin:0 0 6px 0;letter-spacing:2px">CONSOLIDATED INTELLIGENCE REPORT</h1>
    <div style="color:#FECACA;font-size:13px">Alpha Auto-Pivot Surveillance Engine&trade; &bull; Last 6 Wallet Activity Alerts</div>
    <div style="color:#FECACA;font-size:12px;margin-top:4px">Generated: ${NOW}</div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">CASE SUMMARY</h3>
    <table style="width:100%;border-collapse:collapse">
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0;width:140px">Victim:</td><td style="color:#FFFFFF;font-size:12px;padding:4px 0">@sillytuna (Alex Amsel)</td></tr>
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0">Victim Address:</td><td style="font-family:'Courier New',monospace;font-size:11px;color:#FFD700;padding:4px 0">0x6fe0fab2164d8e0d03ad6a628e2af78624060322</td></tr>
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0">Case ID:</td><td style="font-family:'Courier New',monospace;font-size:11px;color:#FFFFFF;padding:4px 0">${CASE_ID}</td></tr>
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0">Exploit Type:</td><td style="color:#FF6B6B;font-size:12px;padding:4px 0">EIP-7702 Delegate Exploit (~$26M)</td></tr>
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0">DAU Beacon:</td><td style="font-family:'Courier New',monospace;font-size:11px;color:#FFD700;padding:4px 0">0xAB403962C943e3335903824BB2880A219858C5CC</td></tr>
      <tr><td style="color:#94A3B8;font-size:12px;padding:4px 0">Reporting Period:</td><td style="color:#FFFFFF;font-size:12px;padding:4px 0">April 9-11, 2026</td></tr>
    </table>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">MONITORED WALLETS</h3>
    <table style="width:100%;border-collapse:collapse">
      <tr style="border-bottom:1px solid #1E3A5F">
        <td style="color:#94A3B8;font-size:11px;padding:8px 4px;font-weight:bold">WALLET</td>
        <td style="color:#94A3B8;font-size:11px;padding:8px 4px;font-weight:bold">ADDRESS</td>
        <td style="color:#94A3B8;font-size:11px;padding:8px 4px;font-weight:bold">BALANCE</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout Primary</td>
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x8e04af7f...5748</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px;font-weight:bold">2,613.45 ETH</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">HOP-4 Consolidation</td>
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0xf576a9d0...59f3</td>
        <td style="color:#FF6B6B;font-size:11px;padding:6px 4px">0.0000 ETH</td>
      </tr>
      <tr>
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">OTC/Bridge Service</td>
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x9a7226c3...ba73</td>
        <td style="color:#FF6B6B;font-size:11px;padding:6px 4px">0.0000 ETH (transit only)</td>
      </tr>
    </table>
  </div>

  <div style="background-color:#0D1117;border:1px solid #EF4444;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#EF4444;font-size:14px;margin:0 0 16px 0;border-bottom:1px solid #EF4444;padding-bottom:8px">LAST 6 SIGNIFICANT WALLET MOVEMENTS (Chronological)</h3>

    <div style="background-color:#1E293B;border-left:3px solid #EF4444;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#EF4444;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #1 &mdash; Apr 9, 07:26 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">HOP-4 (0xf576) forwarded <span style="color:#FFD700;font-weight:bold">191,444.54 USDT</span> to Cashout Primary (0x8e04)</div>
      <div style="color:#94A3B8;font-size:11px">Source: 0xb5d5f113...f6a1 &rarr; HOP-4 &rarr; Cashout. Funds originated from external DeFi position liquidation.</div>
    </div>

    <div style="background-color:#1E293B;border-left:3px solid #FF8C00;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#FF8C00;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #2 &mdash; Apr 9, 13:44 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">Cashout sent <span style="color:#FFD700;font-weight:bold">17.86 USDT</span> to 0x80d71876...f90a</div>
      <div style="color:#94A3B8;font-size:11px">Small test transfer. Sibling address 0x80d7ef92 later sent 1,097.35 USDT directly to <span style="color:#00FF88;font-weight:bold">Binance Hot Wallet 14 (KYC)</span>.</div>
    </div>

    <div style="background-color:#1E293B;border-left:3px solid #EF4444;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#EF4444;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #3 &mdash; Apr 10, 03:14 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">Cashout sent <span style="color:#FFD700;font-weight:bold">1,300 ETH (~$2.7M)</span> to OTC wallet (0x9a72)</div>
      <div style="color:#94A3B8;font-size:11px">OTC wallet forwarded the full 1,300 ETH to <span style="color:#00FF88;font-weight:bold">Binance Hot Wallet 14 (0x28c6...1d60)</span> within 9 minutes at 03:22 UTC. <span style="color:#00FF88;font-weight:bold">KYC CONFIRMED</span>.</div>
    </div>

    <div style="background-color:#1E293B;border-left:3px solid #FF8C00;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#FF8C00;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #4 &mdash; Apr 10, 06:14-06:24 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">Cashout sent <span style="color:#FFD700;font-weight:bold">501,300 USDS</span> to 0x1f04378f...a5ea</div>
      <div style="color:#94A3B8;font-size:11px">Two transfers: 100 USDS + 501,200 USDS. Recipient forwarded as 2x 1,000 ETH + 100 USDS to 0xcfbb...3230. Intermediary wallet with 81 TXs &mdash; historically moves 600 ETH chunks.</div>
    </div>

    <div style="background-color:#1E293B;border-left:3px solid #EF4444;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#EF4444;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #5 &mdash; Apr 10, 10:08-10:12 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">Cashout sent <span style="color:#FFD700;font-weight:bold">2,300.81 USDC</span> to 0x4d0f03b8...ff98</div>
      <div style="color:#94A3B8;font-size:11px">Two transfers: 2,267.91 + 32.90 USDC. Recipient forwarded 2,300.80 USDC to 0xee7ae85f (DeFi contract). Same recipient previously sent 2,209.15 USDT directly to <span style="color:#00FF88;font-weight:bold">Binance Hot Wallet 14 (KYC)</span> on Mar 27.</div>
    </div>

    <div style="background-color:#1E293B;border-left:3px solid #FF0000;padding:12px;margin-bottom:12px;border-radius:4px">
      <div style="color:#FF0000;font-size:11px;font-weight:bold;margin-bottom:4px">ALERT #6 (LATEST) &mdash; Apr 11, 01:36 UTC</div>
      <div style="color:#FFFFFF;font-size:12px;margin-bottom:4px">Cashout sent <span style="color:#FFD700;font-weight:bold">394.64 USDC</span> to 0x83d10e46...5ca1</div>
      <div style="color:#94A3B8;font-size:11px">Recipient is an EOA with only 2 inbound transfers &mdash; both from the attacker (total: $4,402.32 USDC). Forwards to 0x57c6fd46, 0x46af8e7a, 0xfc96452d, 0x2cc8d5e6. Within 4 minutes, a related contract (0x83d1754d, 241 TXs) forwarded 400 USDC to 0xe938...bcd1.</div>
      <div style="color:#FFFFFF;font-size:12px;margin-top:6px"><strong style="color:#FFFFFF">Key finding:</strong> 0x46af8e7a (4,280 TXs) is a <span style="color:#FF6B6B">circular intermediary</span> &mdash; sends funds BACK to the Cashout wallet. Recent: 148 USDT, 2.51 ETH, 1,900 USDC, 2,000 USDC all returned to 0x8e04 on Apr 10.</div>
    </div>
  </div>

  <div style="background-color:#0D1117;border:2px solid #00FF88;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00FF88;font-size:14px;margin:0 0 16px 0;border-bottom:1px solid #00FF88;padding-bottom:8px">KYC EXCHANGE ENDPOINTS CONFIRMED</h3>
    <div style="color:#FFFFFF;font-size:12px;margin-bottom:8px">All paths below terminate at verified KYC-required exchange deposit wallets:</div>

    <table style="width:100%;border-collapse:collapse">
      <tr style="border-bottom:1px solid #1E3A5F">
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">PATH</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">AMOUNT</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">DESTINATION</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; OTC (0x9a72)</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">1,300 ETH</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Apr 10)</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; OTC (0x9a72)</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">1,600 ETH</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Apr 7)</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; OTC (0x9a72)</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">1,500 ETH</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Apr 2)</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; OTC (0x9a72)</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">6,500,000 USDT</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Apr 1)</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; 0x4d0f03b8</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">2,209 USDT</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Mar 27)</td>
      </tr>
      <tr>
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Cashout &rarr; 0x80d7ef92</td>
        <td style="color:#FFD700;font-size:11px;padding:6px 4px;font-weight:bold">1,097 USDT</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px">Binance HW14 (Apr 6)</td>
      </tr>
    </table>

    <div style="color:#FFFFFF;font-size:12px;margin-top:12px;padding:10px;background-color:#1E293B;border-radius:6px">
      <strong style="color:#00FF88">Total confirmed to Binance HW14 (Apr 1-10 alone):</strong><br/>
      <span style="color:#FFD700;font-size:14px;font-weight:bold">4,400 ETH (~$9.17M) + 6,503,306 USDT + 1,500,000 USDT + 499,762 DAI</span><br/>
      <span style="color:#94A3B8;font-size:11px">Binance Hot Wallet 14: 0x28c6c06298d514db089934071355e5743bf21d60</span>
    </div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">LATEST TRANSACTION TRACE (Apr 11 Alert)</h3>
    <div style="color:#FFFFFF;font-size:12px;line-height:1.8">
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#EF4444;font-weight:bold">1.</span> <span style="color:#FFFFFF">Cashout (0x8e04) sends 394.64 USDC</span> <span style="color:#94A3B8">&rarr;</span> <span style="color:#FFD700;font-family:'Courier New',monospace;font-size:11px">0x83d10e4698efb8a0bd3cafad6c950572905d5ca1</span>
      </div>
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#EF4444;font-weight:bold">2.</span> <span style="color:#FFFFFF">0x83d10e46 is an EOA that has received <span style="color:#FFD700">$4,402.32</span> total from attacker (2 transfers: Feb 4 + Apr 11)</span>
      </div>
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#EF4444;font-weight:bold">3.</span> <span style="color:#FFFFFF">0x83d10e46 distributes to:</span>
        <div style="margin-left:20px;color:#94A3B8;font-size:11px">
          &bull; 0x57c6fd46 &mdash; 1,500 USDC<br/>
          &bull; 0x46af8e7a &mdash; 5,900 USDC (circular intermediary, 4,280 TXs)<br/>
          &bull; 0xfc96452d &mdash; 4,019 USDC<br/>
          &bull; 0x2cc8d5e6 &mdash; 819 USDC<br/>
          &bull; 0x5fb998b8 &mdash; 580 USDC
        </div>
      </div>
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#EF4444;font-weight:bold">4.</span> <span style="color:#FFFFFF">Within 4 minutes, related contract 0x83d1754d (241 TXs) forwarded 400 USDC to 0xe938...bcd1</span>
      </div>
      <div style="padding:6px 0">
        <span style="color:#EF4444;font-weight:bold">5.</span> <span style="color:#FF6B6B;font-weight:bold">KEY:</span> <span style="color:#FFFFFF">0x46af8e7a is a <span style="color:#FF6B6B">circular mixer</span> &mdash; on Apr 10 alone it returned 148 USDT, 2.51 ETH, 1,900 USDC, and 2,000 USDC back to the Cashout wallet</span>
      </div>
    </div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">OTC WALLET PIPELINE &mdash; COMPLETE FLOW TO BINANCE</h3>
    <div style="color:#FFFFFF;font-size:12px;line-height:2">
      <div style="color:#94A3B8;font-size:11px;margin-bottom:8px">Most recent OTC &rarr; Binance transfers (all to KYC Hot Wallet 14):</div>
      <table style="width:100%;border-collapse:collapse">
        <tr style="border-bottom:1px solid #1E3A5F">
          <td style="color:#94A3B8;font-size:11px;padding:4px">DATE</td>
          <td style="color:#94A3B8;font-size:11px;padding:4px">AMOUNT</td>
          <td style="color:#94A3B8;font-size:11px;padding:4px">ASSET</td>
        </tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Apr 10, 03:22</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,300</td><td style="color:#FFFFFF;font-size:11px;padding:4px">ETH</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Apr 7, 06:23</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,600</td><td style="color:#FFFFFF;font-size:11px;padding:4px">ETH</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Apr 2, 10:22</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,500.01</td><td style="color:#FFFFFF;font-size:11px;padding:4px">ETH</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Apr 1, 10:13</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">500,000</td><td style="color:#FFFFFF;font-size:11px;padding:4px">USDT</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Apr 1, 09:00</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">6,000,000</td><td style="color:#FFFFFF;font-size:11px;padding:4px">USDT</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Mar 31, 07:22</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,500</td><td style="color:#FFFFFF;font-size:11px;padding:4px">ETH</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Mar 31, 04:22</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,500,000</td><td style="color:#FFFFFF;font-size:11px;padding:4px">USDT</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Mar 31, 02:30</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">499,761.57</td><td style="color:#FFFFFF;font-size:11px;padding:4px">DAI</td></tr>
        <tr style="border-bottom:1px solid #1A2332"><td style="color:#FFFFFF;font-size:11px;padding:4px">Mar 30, 07:42</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">1,400,000</td><td style="color:#FFFFFF;font-size:11px;padding:4px">USDT</td></tr>
        <tr><td style="color:#FFFFFF;font-size:11px;padding:4px">Mar 26, 08:30</td><td style="color:#FFD700;font-size:11px;padding:4px;font-weight:bold">2,000</td><td style="color:#FFFFFF;font-size:11px;padding:4px">ETH</td></tr>
      </table>
    </div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">NEWLY IDENTIFIED WALLETS</h3>
    <table style="width:100%;border-collapse:collapse">
      <tr style="border-bottom:1px solid #1E3A5F">
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">ADDRESS</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">ROLE</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px;font-weight:bold">NOTES</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x83d10e46...5ca1</td>
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Distribution EOA</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">Only 2 inbound (both from attacker), distributes to 5 downstream wallets</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x46af8e7a...0e6b</td>
        <td style="color:#FF6B6B;font-size:11px;padding:6px 4px;font-weight:bold">Circular Mixer</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">4,280 TXs. Receives from distribution, sends back to Cashout. Bidirectional flow.</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x4d0f03b8...ff98</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px;font-weight:bold">KYC Bridge</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">Sent 2,209 USDT to Binance HW14 directly + feeds 0xee7ae85f DeFi contract</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x80d7ef92...f90a</td>
        <td style="color:#00FF88;font-size:11px;padding:6px 4px;font-weight:bold">KYC Bridge</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">Sent 1,097 USDT to Binance HW14 directly on Apr 6</td>
      </tr>
      <tr style="border-bottom:1px solid #1A2332">
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x1f04378f...a5ea</td>
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Large-Value Intermediary</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">81 TXs. Received 501K USDS, forwards in 600-1000 ETH chunks</td>
      </tr>
      <tr>
        <td style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700;padding:6px 4px">0x83d1754d...5ca1</td>
        <td style="color:#FFFFFF;font-size:11px;padding:6px 4px">Smart Contract Splitter</td>
        <td style="color:#94A3B8;font-size:11px;padding:6px 4px">241 TXs. Automated contract that splits and forwards USDC</td>
      </tr>
    </table>
  </div>

  <div style="background-color:#0D1117;border:2px solid #FFD700;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#FFD700;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #FFD700;padding-bottom:8px">ACTIONABLE INTELLIGENCE</h3>
    <div style="color:#FFFFFF;font-size:12px;line-height:1.8">
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#FFD700;font-weight:bold">1.</span> <span style="color:#FFFFFF"><strong style="color:#FFFFFF">Binance Subpoena Target:</strong> The attacker is actively depositing through Binance Hot Wallet 14 (<span style="font-family:'Courier New',monospace;font-size:10px;color:#FFD700">0x28c6c06298d514db089934071355e5743bf21d60</span>). Over $17M in assets moved through this single endpoint in the last 10 days. Binance KYC records for the depositing accounts would identify the attacker.</span>
      </div>
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#FFD700;font-weight:bold">2.</span> <span style="color:#FFFFFF"><strong style="color:#FFFFFF">Active Cashout:</strong> The Cashout wallet still holds <span style="color:#00FF88;font-weight:bold">2,613.45 ETH (~$5.4M)</span> and is actively dispersing funds. Funds are moving NOW.</span>
      </div>
      <div style="padding:6px 0;border-bottom:1px dashed #1E3A5F">
        <span style="color:#FFD700;font-weight:bold">3.</span> <span style="color:#FFFFFF"><strong style="color:#FFFFFF">Circular Mixing Pattern:</strong> 0x46af8e7a operates as a circular mixer with 4,280 TXs &mdash; likely an automated layering mechanism to obscure the trail. Both directions connect to the attacker&rsquo;s cashout.</span>
      </div>
      <div style="padding:6px 0">
        <span style="color:#FFD700;font-weight:bold">4.</span> <span style="color:#FFFFFF"><strong style="color:#FFFFFF">DAU Beacon Active:</strong> Our ERC-20 tracking token (0xAB40...C5CC) remains deployed at the attack origin. Any interaction with the DAU token triggers an immediate alert.</span>
      </div>
    </div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">FULL ATTACK CHAIN DIAGRAM</h3>
    <div style="font-family:'Courier New',monospace;font-size:11px;color:#FFFFFF;background-color:#1E293B;padding:16px;border-radius:6px;white-space:pre;line-height:1.8;overflow-x:auto">Victim (0x6fe0) &mdash;EIP-7702&mdash;&gt; CoW Protocol
                                    |
                              HOP-4 (0xf576)
                                    |
                          Cashout Primary (0x8e04)
                           /    |    |    \\
                          /     |    |     \\
            OTC (0x9a72)   0x4d0f  0x80d7  0x83d10e (distribution)
                 |           |       |       |     \\
                 v           v       v       v      v
          <span style="color:#00FF88">BINANCE HW14</span>  <span style="color:#00FF88">BINANCE</span>  <span style="color:#00FF88">BINANCE</span>  0x46af   0x57c6
          <span style="color:#00FF88">(0x28c6)</span>     <span style="color:#00FF88">HW14</span>    <span style="color:#00FF88">HW14</span>   (mixer)  (unknown)
           <span style="color:#00FF88">KYC &check;</span>      <span style="color:#00FF88">KYC &check;</span>   <span style="color:#00FF88">KYC &check;</span>    |
                                            v
                                     Cashout (circular)</div>
  </div>

  <div style="background-color:#0D1117;border:1px solid #1E3A5F;border-radius:8px;padding:20px;margin-bottom:16px">
    <h3 style="color:#00D4FF;font-size:14px;margin:0 0 12px 0;border-bottom:1px solid #1E3A5F;padding-bottom:8px">ETHERSCAN LINKS</h3>
    <div style="color:#FFFFFF;font-size:12px;line-height:2">
      <div><span style="color:#94A3B8">Cashout Primary:</span> <a href="https://etherscan.io/address/0x8e04af7f7c76daa9ab429b1340e0327b5b835748" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0x8e04...5748</a></div>
      <div><span style="color:#94A3B8">OTC/Bridge:</span> <a href="https://etherscan.io/address/0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0x9a72...ba73</a></div>
      <div><span style="color:#94A3B8">Binance HW14 (KYC):</span> <a href="https://etherscan.io/address/0x28c6c06298d514db089934071355e5743bf21d60" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0x28c6...1d60</a></div>
      <div><span style="color:#94A3B8">Latest Destination:</span> <a href="https://etherscan.io/address/0x83d10e4698efb8a0bd3cafad6c950572905d5ca1" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0x83d1...5ca1</a></div>
      <div><span style="color:#94A3B8">Circular Mixer:</span> <a href="https://etherscan.io/address/0x46af8e7a2ee01134d1757bc19607781dbd410e6b" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0x46af...0e6b</a></div>
      <div><span style="color:#94A3B8">HOP-4:</span> <a href="https://etherscan.io/address/0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0xf576...59f3</a></div>
      <div><span style="color:#94A3B8">DAU Beacon:</span> <a href="https://etherscan.io/address/0xAB403962C943e3335903824BB2880A219858C5CC" style="color:#00D4FF;text-decoration:none">etherscan.io/address/0xAB40...C5CC</a></div>
    </div>
  </div>

  <div style="text-align:center;color:#94A3B8;font-size:11px;margin-top:24px;padding-top:16px;border-top:1px solid #1E3A5F">
    Alpha Auto-Pivot Surveillance Engine&trade; &bull; Forensic Intelligence Division<br/>
    Alpha Unlimited Trading &bull; <a href="https://alphaunlimitedtrading.com" style="color:#00D4FF;text-decoration:none">alphaunlimitedtrading.com</a><br/>
    <span style="color:#64748B;font-size:10px">Monitoring active &bull; Alerts every 5 minutes &bull; SEAL API endpoint available</span>
  </div>

</div>
</body>
</html>`;

  const textBody = `CONSOLIDATED INTELLIGENCE REPORT - Alpha Auto-Pivot Surveillance Engine
Case: @sillytuna (Alex Amsel) EIP-7702 Exploit (~$26M)
Case ID: ${CASE_ID}
Report Period: April 9-11, 2026

LAST 6 WALLET MOVEMENTS:
1. Apr 9, 07:26 - HOP-4 forwarded 191,444.54 USDT to Cashout
2. Apr 9, 13:44 - Cashout sent 17.86 USDT to 0x80d7 (sibling sent 1,097 USDT to Binance KYC)
3. Apr 10, 03:14 - Cashout sent 1,300 ETH to OTC -> Binance HW14 (KYC) within 9 min
4. Apr 10, 06:14-06:24 - Cashout sent 501,300 USDS to 0x1f04 (forwarded as ETH chunks)
5. Apr 10, 10:08-10:12 - Cashout sent 2,300.81 USDC to 0x4d0f (prev sent 2,209 USDT to Binance KYC)
6. Apr 11, 01:36 - Cashout sent 394.64 USDC to 0x83d1 (distribution EOA -> circular mixer 0x46af)

KYC ENDPOINTS: All paths terminate at Binance Hot Wallet 14 (0x28c6c062...1d60)
Total to Binance HW14 (Apr 1-10): ~4,400 ETH + 8M USDT + 500K DAI

Cashout wallet still holds 2,613.45 ETH (~$5.4M). Funds actively moving.

Links:
- Cashout: https://etherscan.io/address/0x8e04af7f7c76daa9ab429b1340e0327b5b835748
- OTC: https://etherscan.io/address/0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73
- Binance HW14: https://etherscan.io/address/0x28c6c06298d514db089934071355e5743bf21d60

Alpha Unlimited Trading - Forensic Intelligence Division`;

  const recipients = [
    { email: "sillytuna@gmail.com", name: "Alex Amsel (@sillytuna)" },
    { email: "tips@securityalliance.org", name: "SEAL Team" },
    { email: "alphaunlimitedtoken@gmail.com", name: "Alpha Unlimited (Internal)" },
  ];

  for (const recipient of recipients) {
    try {
      const msg = {
        to: { email: recipient.email, name: recipient.name },
        from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
        subject: `[CONSOLIDATED INTEL] @sillytuna Case — Last 6 Wallet Movements + KYC Endpoints Traced — ${NOW.slice(0, 10)}`,
        html: htmlBody,
        text: textBody,
      };
      await sgClient.send(msg);
      console.log(`Sent to ${recipient.email}`);
    } catch (err: any) {
      console.error(`Failed to send to ${recipient.email}:`, err?.response?.body || err.message);
    }
  }

  console.log("\nDone — consolidated intelligence report sent to all 3 recipients.");
}

main().catch(console.error);
