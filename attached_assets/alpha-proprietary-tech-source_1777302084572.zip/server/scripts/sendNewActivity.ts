/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SEND_ACTIVITY_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_SendActivity_Calibration_PROTECTED
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const TO = "sillytuna@gmail.com";

async function main() {
  console.log("[SendActivity] Preparing live activity alert for sillytuna...");

  const activityReport = fs.readFileSync("/tmp/activity_report.txt", "utf-8");

  const report = `════════════════════════════════════════════════════════════════════════════════
  ALPHA FORENSIC INTELLIGENCE ENGINE™
  ⚠ LIVE ACTIVITY ALERT — ATTACKER WALLETS ARE ACTIVE ⚠
  Case: @sillytuna (Alex Amsel) — ~$24M Crypto Theft
  Case ID: ${CASE_ID}
  Generated: ${new Date().toISOString()}
  Anchor: FXUSD SOURCE 0xD14F4B36E1D1D98c218db782c49149876042BC56
════════════════════════════════════════════════════════════════════════════════

ALERT: 211 new transactions detected across 7 attacker wallets in last 48 hours.
The attacker's infrastructure is ACTIVELY OPERATING.


══════════════════════════════════════════════════════════════════
WALLET STATUS SUMMARY (Last 48 Hours)
══════════════════════════════════════════════════════════════════

  ⚠ ACTIVE — Crypto.com Suspect Wallet ($155K USDC)
    0x658370618BBc885865df66c1061BfE4771FaD846
    Status: $155,017 USDC still sitting unfrozen — has NOT moved out yet
    Activity: FXUSD→USDC swap on March 7 (already documented)
    URGENT: This USDC can be moved at any moment

  ⚠ ACTIVE — FXUSD Source
    0xD14F4B36E1D1D98c218db782c49149876042BC56
    Activity: Multiple FXUSD movements in last 48h:
      • Received 499,916 FXUSD on March 7
      • Sent out: 155K FXUSD (→ suspect wallet chain), 99K FXUSD, 11K FXUSD, smaller amounts
      • Still actively processing FXUSD

  ⚠ ACTIVE — Relay Proxy (ERC1967Proxy)
    0x6818809EefCe719E480a7526D76bD3e561526b46
    Activity: 30+ relay transactions in last 48h
      • Relaying FXUSD in and out
      • Receiving small ETH amounts for gas
      • Infrastructure is fully operational

  ⚠ ACTIVE — POI / GFF ($4.35M)
    0xf70da97812cb96acdf810712aa562db8dfa3dbef
    Activity: 94 token transfer events in last 48h
      • Most recent: March 8, 2:05 AM UTC — TX to AdminUpgradableProxy
      • WHOEVER CONTROLS THIS WALLET IS ACTIVE RIGHT NOW
      • TX: 0x076587c7b65fd3e2ba294b75d90797a9e198a53dc06fabb1f1086632fe447382

  ⚠ ACTIVE — Laundering Hub ($20M DAI)
    0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872
    Activity: Received incoming transaction March 7

  ⚠ ACTIVE — Hub DAI Dispersal
    0xd8cFAaceB9719d7c5c68c0AD876E619C180770c6
    Activity: Sent transaction to Laundering Hub on March 7

  ⚠ ACTIVE — Victim Wallet
    0x6fe0fab2164d8e0d03ad6a628e2af78624060322
    Activity: 2 incoming 0-value ETH TXs on March 7
      • These may be token approvals or contract interactions
      • Could be the attacker probing the victim's wallet

  ✓ NO ACTIVITY — Source Wallet (EIP-7702)
    0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb

  ✓ NO ACTIVITY — Gas Funder
    0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7

  ✓ NO ACTIVITY — Original Funder
    0x423d2b61952d56358db8b313ec7404a9582d4865

  ✓ NO ACTIVITY — Binance Depositor (Destination)
    0x7f72c73dc7d3badb2000edb1e11135eaae33cc2c


══════════════════════════════════════════════════════════════════
CRITICAL OBSERVATIONS
══════════════════════════════════════════════════════════════════

1. THE ATTACKER IS ONLINE RIGHT NOW
   The POI wallet ($4.35M) made a transaction just hours ago.
   The FXUSD Source and Relay Proxy have been busy all day.

2. $155K USDC STILL UNFROZEN
   The Crypto.com suspect wallet's USDC has not moved — but it could
   at any moment. Circle needs to blacklist this address NOW.

3. FXUSD SOURCE IS PROCESSING MORE FUNDS
   Received ~500K FXUSD on March 7 and has been distributing it.
   This suggests ongoing laundering activity, not just a one-time event.

4. RELAY INFRASTRUCTURE IS LIVE
   30+ relay transactions show the attacker's relay proxy system is
   fully operational and processing transactions continuously.

5. VICTIM WALLET RECEIVED PROBES
   Two 0-value transactions to the victim wallet could indicate
   the attacker is checking if the victim has any remaining assets
   or testing contract interactions.


══════════════════════════════════════════════════════════════════
IMMEDIATE RECOMMENDATIONS
══════════════════════════════════════════════════════════════════

1. CONTACT CIRCLE NOW — Request emergency blacklisting of:
   0x658370618BBc885865df66c1061BfE4771FaD846 ($155K USDC at risk)
   compliance@circle.com

2. CONTACT BINANCE NOW — Request account freeze for wallets depositing funds:
   0x7f72c73dc7d3badb2000edb1e11135eaae33cc2c
   0x48916d83049adc30c49105493c700e4945434ec1
   law-enforcement@binance.com

3. MONITOR POI WALLET — Active right now, may be preparing to move more funds
   0xf70da97812cb96acdf810712aa562db8dfa3dbef

4. FXUSD SOURCE — Contact f(x) Protocol team if possible to freeze/flag
   0xD14F4B36E1D1D98c218db782c49149876042BC56


══════════════════════════════════════════════════════════════════
FULL RAW ACTIVITY LOG (Last 48 Hours)
══════════════════════════════════════════════════════════════════

${activityReport}


═══════════════════════════════════════════════════════════════════
All TX hashes independently verifiable on etherscan.io / blockscout.com
Previous reports (Master FXUSD Evidence, Exchange Flows, Original Funder)
remain current. All anchored through FXUSD SOURCE.

CONFIDENTIAL — For the victim and law enforcement only.
Alpha Unlimited Trading Company — Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
© 2024-2026 All Rights Reserved
═══════════════════════════════════════════════════════════════════
`;

  const reportPath = path.resolve("forensic_live_activity_alert.txt");
  fs.writeFileSync(reportPath, report);
  console.log(`[SendActivity] Report: ${report.split("\n").length} lines`);

  const tmp = `/tmp/activity_alert_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-Live-Activity-Alert");
  fs.mkdirSync(zipDir, { recursive: true });
  fs.copyFileSync(reportPath, path.join(zipDir, "LIVE ACTIVITY ALERT — 211 New Transactions Detected.txt"));

  const zipPath = path.join(tmp, "alert.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-Live-Activity-Alert/"`, { timeout: 15000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`[SendActivity] ZIP: ${zipKb} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();
  console.log(`[SendActivity] Sending from ${fromEmail} to ${TO}...`);

  const emailBody = `Dear @sillytuna,

⚠ LIVE ACTIVITY ALERT — The attacker's wallets are ACTIVELY OPERATING.

We detected 211 new transactions across 7 attacker wallets in the last 48 hours.

KEY ALERTS:

1. THE ATTACKER IS ONLINE RIGHT NOW
   The POI wallet ($4.35M) made a transaction just hours ago (March 8, 2:05 AM UTC).
   The FXUSD Source and Relay Proxy have been processing transactions all day.

2. $155K USDC STILL UNFROZEN — HAS NOT MOVED YET
   The Crypto.com suspect wallet still holds $155,017 USDC.
   Circle (USDC) has NOT blacklisted this address.
   It can be moved at any moment — Circle needs to freeze it NOW.
   Contact: compliance@circle.com
   Address to freeze: 0x658370618BBc885865df66c1061BfE4771FaD846

3. FXUSD SOURCE PROCESSING MORE FUNDS
   Received ~500K FXUSD on March 7 and distributed multiple amounts.
   This is ongoing laundering activity, not a one-time event.

4. RELAY PROXY INFRASTRUCTURE IS LIVE
   30+ relay transactions in 48 hours — the system is fully operational.

5. VICTIM WALLET RECEIVED PROBES
   Two 0-value transactions sent to the victim wallet — the attacker may
   be checking for remaining assets.

ACTIVE WALLETS:
  • POI ($4.35M): 0xf70da97812cb96acdf810712aa562db8dfa3dbef — 94 new transfers
  • FXUSD Source: 0xD14F4B36E1D1D98c218db782c49149876042BC56 — moving FXUSD
  • Relay Proxy: 0x6818809EefCe719E480a7526D76bD3e561526b46 — 30+ relays
  • Crypto.com: 0x658370618BBc885865df66c1061BfE4771FaD846 — $155K USDC unfrozen
  • Laundering Hub: 0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872
  • Hub DAI: 0xd8cFAaceB9719d7c5c68c0AD876E619C180770c6
  • Victim: 0x6fe0fab2164d8e0d03ad6a628e2af78624060322 — received probes

INACTIVE:
  • Source Wallet, Gas Funder, Original Funder, Binance Depositor — no new activity

Full activity log with all TX hashes attached.

CONFIDENTIAL — For the victim and law enforcement only.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com`;

  await client.send({
    to: TO,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: "⚠ LIVE ALERT: Attacker Wallets Active NOW — 211 New TXs, $155K USDC Still Unfrozen, POI Moving Funds",
    text: emailBody,
    attachments: [{
      content: zipBuf.toString("base64"),
      filename: `Sillytuna-Live-Activity-Alert-${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[SendActivity] ✓ Email sent to ${TO}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "live_activity_alert",
    severity: "critical",
    message: `Live activity alert sent to ${TO}: 211 new TXs across 7 wallets, POI active hours ago, $155K USDC unfrozen, relay infrastructure operational`,
    walletAddress: "system",
    details: {
      recipientEmail: TO,
      fromAddress: fromEmail,
      zipSizeKb: zipKb,
      newTransactions: 211,
      activeWallets: 7,
      inactiveWallets: 4,
      usdcAtRisk: 155017.66,
      poiLastActive: "2026-03-08T02:05:23.000000Z",
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("[SendActivity] Done. Alert logged.");
  process.exit(0);
}
main().catch(e => { console.error("FATAL:", e); process.exit(1); });
