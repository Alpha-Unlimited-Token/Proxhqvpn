import { scanCaseWallets, scanTCEventLogs } from '../services/caseExploitScanner.js';

const CASE_ID = '306db48a-36e2-42c1-9d7c-3b49d5bfdb49';

async function run() {
  console.log('========================================');
  console.log('  CASE WALLET EXPLOIT SCAN — @sillytuna');
  console.log('========================================\n');

  console.log('[1/2] Running Case Wallet Scan against Blockscout API...\n');
  const walletResult = await scanCaseWallets(CASE_ID);

  console.log('\n=== CASE WALLET SCAN RESULTS ===');
  console.log('Case:', walletResult.caseName);
  console.log('Scan ID:', walletResult.scanId);
  console.log('Wallets Scanned:', walletResult.walletsScanned);
  console.log('Wallets with Findings:', walletResult.walletsWithFindings);
  console.log('TC Interactions:', walletResult.totalTornadoInteractions);
  console.log('Exchange Interactions:', walletResult.totalExchangeInteractions);
  console.log('Relayer Interactions:', walletResult.totalRelayerInteractions);
  console.log('Risk Assessment:', walletResult.overallRiskAssessment);
  console.log('Duration:', (walletResult.scanDuration / 1000).toFixed(1) + 's');

  if (walletResult.keyFindings.length > 0) {
    console.log('\n--- KEY FINDINGS ---');
    for (const f of walletResult.keyFindings) console.log('  >', f);
  }

  if (walletResult.priorityActions.length > 0) {
    console.log('\n--- PRIORITY ACTIONS ---');
    for (const a of walletResult.priorityActions) console.log('  *', a);
  }

  const walletsWithData = walletResult.walletResults.filter(r =>
    r.tornadoCashInteractions.found || r.exchangeInteractions.found ||
    r.relayerInteractions.found || r.scanStatus !== 'scanned'
  );

  if (walletsWithData.length > 0) {
    console.log('\n--- WALLETS WITH FINDINGS (' + walletsWithData.length + ') ---');
    for (const w of walletsWithData) {
      console.log('\n  [' + w.scanStatus.toUpperCase() + '] ' + w.address);
      console.log('  Label: ' + w.label + ' | Role: ' + w.role + ' | Risk: ' + w.privacyRiskScore + '%');
      if (w.tornadoCashInteractions.deposits.length > 0) {
        console.log('  TC Deposits: ' + w.tornadoCashInteractions.deposits.length);
        for (const d of w.tornadoCashInteractions.deposits) console.log('    Deposit -> Pool: ' + d.pool + ' | Amount: ' + d.amount + ' | Tx: ' + d.txHash?.slice(0,20) + '...');
      }
      if (w.tornadoCashInteractions.withdrawals.length > 0) {
        console.log('  TC Withdrawals: ' + w.tornadoCashInteractions.withdrawals.length);
        for (const wd of w.tornadoCashInteractions.withdrawals) console.log('    Withdrawal <- Pool: ' + wd.pool + ' | Amount: ' + wd.amount + ' | Tx: ' + wd.txHash?.slice(0,20) + '...');
      }
      if (w.exchangeInteractions.exchanges.length > 0) {
        console.log('  Exchange Interactions: ' + w.exchangeInteractions.exchanges.length);
        for (const e of w.exchangeInteractions.exchanges.slice(0, 10)) {
          console.log('    ' + e.name + ' | ' + e.direction.replace(/_/g,' ') + ' | ' + e.amount + ' | Tx: ' + (e.txHash?.slice(0,20) || '?') + '...');
        }
      }
      for (const f of w.exploitableFindings) console.log('  FINDING: ' + f);
      for (const a of w.investigatorActions) console.log('  ACTION: ' + a);
    }
  }

  console.log('\n\n========================================');
  console.log('[2/2] Running TC Event Log Exploit Scan...\n');

  const tcResult = await scanTCEventLogs(CASE_ID);

  console.log('\n=== TC EVENT LOG EXPLOIT RESULTS ===');
  console.log('Case:', tcResult.caseName);
  console.log('Scan ID:', tcResult.scanId);
  console.log('Pools Scanned:', tcResult.poolsScanned);
  console.log('Deposits Analyzed:', tcResult.totalDepositsAnalyzed);
  console.log('Withdrawals Analyzed:', tcResult.totalWithdrawalsAnalyzed);
  console.log('Matched Withdrawals:', tcResult.matchedWithdrawals);
  console.log('Matched Wallets:', tcResult.matchedWallets.join(', ') || 'None');
  console.log('Duration:', (tcResult.scanDuration / 1000).toFixed(1) + 's');

  if (tcResult.exploitFindings.length > 0) {
    console.log('\n--- EXPLOIT FINDINGS ---');
    for (const f of tcResult.exploitFindings) console.log('  >', f);
  }

  if (tcResult.investigatorActions.length > 0) {
    console.log('\n--- INVESTIGATOR ACTIONS ---');
    for (const a of tcResult.investigatorActions) console.log('  *', a);
  }

  if (tcResult.relayerIntelligence.length > 0) {
    console.log('\n--- RELAYER INTELLIGENCE ---');
    for (const r of tcResult.relayerIntelligence) {
      console.log('  Relayer: ' + r.address + ' | Withdrawals: ' + r.withdrawalCount + ' | Pools: ' + r.poolsUsed.join(', '));
    }
  }

  for (const p of tcResult.poolResults.filter(pr => pr.matchedWalletWithdrawals > 0)) {
    console.log('\n--- MATCHED POOL: ' + p.pool + ' ---');
    for (const w of p.recentWithdrawals.filter(wd => wd.matchedCaseWallet)) {
      console.log('  MATCH: Recipient=' + w.recipientAddress + ' Label=' + w.walletLabel);
      console.log('  Nullifier: ' + w.nullifierHash);
      console.log('  Relayer: ' + w.relayerAddress);
      console.log('  Fee: ' + w.fee + ' ETH | Block: ' + w.blockNumber);
    }
  }

  console.log('\n========================================');
  console.log('  SCAN COMPLETE');
  console.log('========================================');
  process.exit(0);
}

run().catch(e => { console.error('FATAL:', e.message, e.stack); process.exit(1); });
