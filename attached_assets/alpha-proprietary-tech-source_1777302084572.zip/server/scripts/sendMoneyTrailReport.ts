import { getUncachableSendGridClient } from "../services/sendgridService.js";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENTS = [
  { email: "sillytuna@gmail.com", name: "sillytuna (Alex Amsel)" },
  { email: "tips@securityalliance.org", name: "SEAL 911" },
];

async function main() {
  console.log("[MoneyTrailReport] Compiling complete fund retrace from victim wallet...\n");

  const now = new Date().toISOString();

  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
<style>
  body { background: #0A1628; color: #E2E8F0; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
  .container { max-width: 800px; margin: 0 auto; padding: 24px; }
  .header { background: linear-gradient(135deg, #7F1D1D 0%, #991B1B 100%); border: 2px solid #EF4444; border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center; }
  .header h1 { color: #FFFFFF; font-size: 22px; margin: 0 0 6px 0; letter-spacing: 3px; }
  .header h2 { color: #FCA5A5; font-size: 15px; margin: 0 0 8px 0; font-weight: normal; }
  .header .subtitle { color: #FECACA; font-size: 12px; }
  .section { background: #0D1117; border: 1px solid #1E3A5F; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
  .section h3 { color: #00D4FF; font-size: 15px; margin: 0 0 12px 0; border-bottom: 1px solid #1E3A5F; padding-bottom: 8px; }
  .critical { background: #7F1D1D44; border: 2px solid #EF4444; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
  .critical h3 { color: #FF6B6B; font-size: 16px; margin: 0 0 12px 0; border-bottom: 1px solid #EF444466; padding-bottom: 8px; }
  .target { background: #14532D44; border: 2px solid #22C55E; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
  .target h3 { color: #22C55E; font-size: 16px; margin: 0 0 12px 0; border-bottom: 1px solid #22C55E66; padding-bottom: 8px; }
  .warning { background: #78350F33; border: 1px solid #F59E0B66; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
  .warning h3 { color: #F59E0B; border-bottom-color: #F59E0B44; }
  .addr { font-family: 'Courier New', monospace; font-size: 11px; color: #FFD700; word-break: break-all; background: #1E293B; padding: 3px 8px; border-radius: 4px; display: inline-block; margin: 2px 0; }
  .addr-red { font-family: 'Courier New', monospace; font-size: 11px; color: #EF4444; word-break: break-all; background: #1E293B; padding: 3px 8px; border-radius: 4px; display: inline-block; margin: 2px 0; }
  .addr-green { font-family: 'Courier New', monospace; font-size: 11px; color: #22C55E; word-break: break-all; background: #1E293B; padding: 3px 8px; border-radius: 4px; display: inline-block; margin: 2px 0; }
  .flow-table { width: 100%; border-collapse: collapse; margin: 12px 0; }
  .flow-table th { background: #1E293B; color: #00D4FF; font-size: 11px; padding: 8px; text-align: left; border: 1px solid #1E3A5F; }
  .flow-table td { font-size: 11px; padding: 8px; border: 1px solid #1E3A5F; vertical-align: top; }
  .flow-table tr:nth-child(even) { background: #0D111766; }
  .amount { color: #FFD700; font-weight: bold; }
  .amount-big { color: #EF4444; font-weight: bold; font-size: 13px; }
  .status-active { color: #22C55E; font-weight: bold; }
  .status-empty { color: #64748B; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; margin: 2px; }
  .tag-danger { background: #7F1D1D; color: #FCA5A5; border: 1px solid #EF4444; }
  .tag-active { background: #14532D; color: #86EFAC; border: 1px solid #22C55E; }
  .tag-empty { background: #1E293B; color: #64748B; border: 1px solid #334155; }
  .tag-contract { background: #1E3A5F; color: #93C5FD; border: 1px solid #3B82F6; }
  .highlight { background: #22C55E22; border: 2px solid #22C55E; border-radius: 8px; padding: 16px; margin: 16px 0; }
  .divider { border: 0; border-top: 1px solid #1E3A5F; margin: 20px 0; }
  .footer { text-align: center; color: #64748B; font-size: 11px; margin-top: 24px; padding-top: 16px; border-top: 1px solid #1E3A5F; }
  ul { margin: 8px 0; padding-left: 20px; }
  li { margin: 4px 0; font-size: 12px; }
  p { font-size: 13px; line-height: 1.6; margin: 8px 0; }
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <h1>COMPLETE FUND RETRACE REPORT</h1>
    <h2>Victim Wallet &rarr; All Downstream Destinations</h2>
    <div class="subtitle">Case ${CASE_ID} &bull; Victim: @sillytuna (Alex Amsel) &bull; ${now}</div>
  </div>

  <div class="section">
    <h3>METHODOLOGY</h3>
    <p>Starting from the victim wallet, we traced <strong>every outbound transfer</strong> triggered by the EIP-7702 exploit on March 4, 2026. We then followed each recipient wallet to map where the stolen funds moved next, checking each wallet for current balance, transaction count, token holdings, and whether it is a personal wallet (EOA) or smart contract.</p>
    <p><strong>Victim Wallet:</strong> <span class="addr">0x6fe0fab2164d8e0d03ad6a628e2af78624060322</span></p>
  </div>

  <div class="critical">
    <h3>HOP 1 &mdash; DIRECT THEFT FROM VICTIM (March 4, 2026)</h3>
    <p>The attacker drained ~$26M from the victim wallet to <strong>8 unique addresses</strong> across 30 transactions:</p>

    <table class="flow-table">
      <tr>
        <th>Wallet</th>
        <th>Assets Stolen</th>
        <th>Type</th>
        <th>Current Status</th>
      </tr>
      <tr>
        <td><span class="addr-red">0xb98e8eefba0f7476b85cd9716cb5b38a935aa872</span></td>
        <td>
          <span class="amount-big">490.6 ETH</span> (~$1.02M)<br/>
          <span class="amount-big">1,969,345 DAI</span> (~$1.97M)<br/>
          Total: ~$2.99M
        </td>
        <td><span class="tag tag-danger">EOA</span></td>
        <td><span class="status-empty">EMPTIED</span> &mdash; 31 TXs, moved everything downstream</td>
      </tr>
      <tr>
        <td><span class="addr-red">0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb</span></td>
        <td>
          <span class="amount-big">19,529,502 aEthUSDC</span><br/>
          (~$19.5M in Aave USDC deposits)
        </td>
        <td><span class="tag tag-contract">CONTRACT</span></td>
        <td>0.56 ETH remaining, 16 outbound TXs</td>
      </tr>
      <tr>
        <td><span class="addr-red">0x74de5d4fcbf63e00296fd95d33236b9794016631</span></td>
        <td>
          <span class="amount">1,070,050 aEthUSDC</span> + <span class="amount">407.26 WETH</span>
        </td>
        <td><span class="tag tag-contract">CONTRACT</span></td>
        <td><span class="status-empty">EMPTIED</span></td>
      </tr>
      <tr>
        <td><span class="addr-red">0xb98e32331c96b896541bf17727519f790a77a872</span></td>
        <td><span class="amount">1,969,345 DAI</span></td>
        <td><span class="tag tag-danger">EOA</span></td>
        <td><span class="status-empty">EMPTIED</span> &mdash; 0 outbound TXs (funds pulled by contract)</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xb986765a00798135255677066ead4433a3d3a872</span></td>
        <td><span class="amount">549,889 DAI</span></td>
        <td><span class="tag tag-danger">EOA</span></td>
        <td><span class="status-empty">EMPTIED</span> &mdash; 1 TX</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xb98424e784cf63872b76c3920d3eedc93c7b0872</span></td>
        <td><span class="amount">2.28 ETH</span></td>
        <td><span class="tag tag-danger">EOA</span></td>
        <td><span class="status-empty">EMPTIED</span></td>
      </tr>
      <tr style="background: #14532D33;">
        <td><span class="addr-green">0xe3478b0bb1a5084567c319096437924948be1964</span></td>
        <td><span class="amount">0.0002 ETH</span> (gas funding TX)</td>
        <td><span class="tag tag-active">EOA</span></td>
        <td>
          <span class="status-active">ACTIVE &mdash; 210.17 ETH (~$437,784)</span><br/>
          89 tokens | 279 TXs | Last active: March 20, 2026
        </td>
      </tr>
      <tr>
        <td><span class="addr-red">0x0d5ce2862d3ef390323eec916f1840d7ac6059bb</span></td>
        <td>Small ERC-20 transfer</td>
        <td><span class="tag tag-danger">EOA</span></td>
        <td><span class="status-empty">EMPTIED</span></td>
      </tr>
    </table>
  </div>

  <div class="section">
    <h3>HOP 2 &mdash; MAIN ATTACKER SPLITTING PATTERN (March 4-5, 2026)</h3>
    <p>The main attacker wallet <span class="addr-red">0xb98e...a872</span> used a <strong>systematic splitting strategy</strong>:</p>

    <h4 style="color: #F59E0B; margin-top: 16px;">DAI Laundering (millions split across hubs):</h4>
    <table class="flow-table">
      <tr><th>Laundering Hub</th><th>DAI Received</th><th>Pattern</th></tr>
      <tr>
        <td><span class="addr-red">0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e</span></td>
        <td><span class="amount">~10M DAI</span> (across 7 TXs)</td>
        <td>Split further to 19 sub-wallets</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xd0c277aa22512262e4dbe524a1341e6b7618dd3e</span></td>
        <td><span class="amount">~8.5M DAI</span></td>
        <td>Mirror split pattern</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xd0c254e18f41ccbc3a1ed62f3c153b6d24c9dd3e</span></td>
        <td><span class="amount">~5.5M DAI</span></td>
        <td>Mirror split pattern</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4</span></td>
        <td><span class="amount">~10M DAI</span></td>
        <td>Split to 8+ wallets; <span class="status-active">STILL ACTIVE March 20</span></td>
      </tr>
      <tr>
        <td><span class="addr-red">0xdcadf21e8fe83b51d08b14d2575ca9b1973ec9c4</span></td>
        <td><span class="amount">~8M DAI</span></td>
        <td>Mirror split pattern</td>
      </tr>
      <tr>
        <td><span class="addr-red">0xdca900cf72d3233a5ecb7ee29615cfb0dc68c9c4</span></td>
        <td><span class="amount">~8M DAI</span></td>
        <td>Mirror split pattern</td>
      </tr>
    </table>

    <h4 style="color: #F59E0B; margin-top: 16px;">ETH Splitting (50 ETH chunks / ~$104K each):</h4>
    <table class="flow-table">
      <tr><th>ETH Hop-2 Wallet</th><th>Amount</th><th>Status</th></tr>
      <tr>
        <td><span class="addr">0x7aebc630f301f15baddf160103dc3bd8f9baf043</span></td>
        <td><span class="amount">150 ETH</span> (~$312K)</td>
        <td><span class="status-empty">Emptied</span></td>
      </tr>
      <tr>
        <td><span class="addr">0x487663784c77ba56e32d9fe60485d93c4c319385</span></td>
        <td><span class="amount">2.33 ETH</span></td>
        <td>Split further</td>
      </tr>
      <tr>
        <td><span class="addr">0x48788914a48b9a49616a1b03a5b8a2783c319385</span></td>
        <td><span class="amount">13.98 ETH</span> (6 × 2.33 ETH)</td>
        <td>Split further</td>
      </tr>
      <tr>
        <td><span class="addr">0x48763950cb0b86a12a0cb485d2e82f27037b9385</span></td>
        <td><span class="amount">9.32 ETH</span> (4 × 2.33 ETH)</td>
        <td>Split further</td>
      </tr>
      <tr>
        <td><span class="addr">0x6105ddc22166a1cf1b947b8928eebd2983557237</span></td>
        <td><span class="amount">500 ETH</span> (~$1.04M) via contract</td>
        <td>Emptied through contract</td>
      </tr>
      <tr>
        <td><span class="addr">0x610e10ed49f57591abe16d919b6d15aaf4557237</span></td>
        <td><span class="amount">50 ETH</span></td>
        <td>0.15 ETH remaining, 4 tokens</td>
      </tr>
      <tr>
        <td><span class="addr">0x9b9fd485e94c73af3bc8b9a630c4de7203bc96cb</span></td>
        <td><span class="amount">50 ETH</span></td>
        <td>0.15 ETH remaining, 6 tokens</td>
      </tr>
    </table>
  </div>

  <div class="warning">
    <h3>HOP 3 &mdash; DAI FURTHER DISPERSAL (March 5-20, 2026)</h3>
    <p>The DAI laundering hubs each split funds to <strong>pairs of wallets</strong> in a mirror pattern (same amount sent to two wallets simultaneously). Key downstream wallets:</p>
    <ul>
      <li><span class="addr">0x17d4e5555c0c13ea8c22a5ddbaa3315cf343231d</span> &mdash; ~4.7M DAI received</li>
      <li><span class="addr">0x17d4684ee21ff2acfdca9aafab385c7f3e5e231d</span> &mdash; ~4.7M DAI (mirror)</li>
      <li><span class="addr">0x9da60764cc6e218dabe6e5c89587a9d251a36e20</span> &mdash; ~1.3M DAI</li>
      <li><span class="addr">0x9da64c229438e1741fef63f4867588a63de86e20</span> &mdash; ~1.3M DAI (mirror)</li>
      <li><span class="addr">0xa9bf8ed5a085a13a4ceaad092d0c2e8fb36de304</span> &mdash; ~950K DAI</li>
      <li><span class="addr">0xa9bf8cde52177ba92544e6ec091797a090dee304</span> &mdash; ~950K DAI (mirror)</li>
      <li><span class="addr">0xbaf21e87ea8257146935569eee71a55bb2add941</span> &mdash; ~900K DAI</li>
      <li><span class="addr">0xbaf20dc17ad61d9fa2ab60cf0d9ca4d2a9cdd941</span> &mdash; ~900K DAI (mirror)</li>
      <li><span class="addr">0x65ca96af03f0db3466eb4e12219ad4d030bb8a54</span> &mdash; ~1.5M DAI</li>
      <li><span class="addr">0x65cadde676f635e111446fe499565d109a638a54</span> &mdash; ~1.5M DAI (mirror)</li>
      <li><span class="addr">0xc0dc42bdea3b981ba49b12a561b5bf1b25f524d0</span> &mdash; ~650K DAI</li>
      <li><span class="addr">0xc0dc70deb82da13095a21bc8424970543ea124d0</span> &mdash; ~650K DAI (mirror)</li>
    </ul>
    <p style="color: #F59E0B; font-weight: bold;">PATTERN: Attacker consistently sends identical amounts to paired wallets with similar address prefixes &mdash; automated laundering script.</p>

    <p style="margin-top: 16px;"><strong>Newest activity (March 20, 2026):</strong></p>
    <ul>
      <li><span class="addr">0x54c26910e22e3367ada60c5bec55414348d6c01a</span> &mdash; 999,926 DAI received from DCA hub</li>
      <li><span class="addr">0x54c23a224ba32fdc594974c7b0db0a0d6437c01a</span> &mdash; 999,926 DAI (mirror) &mdash; note spoofed token name "DА1" (Cyrillic A)</li>
    </ul>
    <p style="color: #EF4444;">The laundering is <strong>still active as of 2 days ago</strong>. Funds are still being moved.</p>
  </div>

  <div class="target">
    <h3>&#x1F3AF; PRIMARY TARGET &mdash; ATTACKER'S OPERATIONAL WALLET</h3>
    <p style="font-size: 14px;">This wallet is the <strong>most critical wallet</strong> in the entire investigation:</p>

    <div style="background: #0D1117; border-radius: 8px; padding: 16px; margin: 12px 0;">
      <p style="text-align: center; margin: 0 0 12px 0;">
        <span class="addr-green" style="font-size: 13px;">0xe3478b0bb1a5084567c319096437924948be1964</span>
      </p>
      <table class="flow-table">
        <tr><td style="width: 160px; color: #94A3B8;">Current Balance</td><td><span class="amount-big">210.17 ETH (~$437,784)</span></td></tr>
        <tr><td style="color: #94A3B8;">Token Holdings</td><td>89 different tokens</td></tr>
        <tr><td style="color: #94A3B8;">Total Transactions</td><td>279 outbound</td></tr>
        <tr><td style="color: #94A3B8;">Last Active</td><td><span class="status-active">March 20, 2026 (2 days ago)</span></td></tr>
        <tr><td style="color: #94A3B8;">Wallet Type</td><td>EOA (externally owned &mdash; personal wallet, not a contract)</td></tr>
        <tr><td style="color: #94A3B8;">Connection to Victim</td><td>Sent 0.0002 ETH TO victim wallet (gas funding for exploit execution)</td></tr>
      </table>
    </div>

    <p><strong>Why this wallet matters:</strong></p>
    <ul>
      <li>It funded the victim&rsquo;s wallet with gas for the EIP-7702 exploit &mdash; making it the <strong>attack orchestrator</strong></li>
      <li>It is the only first-hop wallet that is still <strong>actively funded and operational</strong></li>
      <li>Recent activity shows active laundering: sending <strong>5 ETH chunks</strong> to fresh wallets and <strong>~$24,585 USDC</strong> batches to paired addresses</li>
      <li>Uses the same <strong>mirror-pair splitting pattern</strong> as the DAI laundering hubs &mdash; same attacker</li>
    </ul>

    <p style="margin-top: 12px;"><strong>Recent Transactions from this wallet (March 17-20, 2026):</strong></p>
    <table class="flow-table">
      <tr><th>Date</th><th>Amount</th><th>Destination</th></tr>
      <tr><td>Mar 20</td><td>5.00 ETH</td><td><span class="addr">0xb01caea8c6c47bbf4f4b4c5080ca642043359c2e</span></td></tr>
      <tr><td>Mar 19</td><td>5.00 ETH</td><td><span class="addr">0xc066ac5d385419b1a8c43a0e146fa439837a8b8c</span></td></tr>
      <tr><td>Mar 19</td><td>5.00 ETH</td><td><span class="addr">0xb42f812a44c22cc6b861478900401ee759ebead6</span></td></tr>
      <tr><td>Mar 17</td><td>24,584.71 USDC</td><td><span class="addr">0xfcaa4999cae2db88d6dea36db22b1fd065b0d118</span></td></tr>
      <tr><td>Mar 17</td><td>24,584.71 U5DC</td><td><span class="addr">0xfcaa2be464290efcc3c4e16a01e7842a26a8d118</span> (mirror pair)</td></tr>
      <tr><td>Mar 17</td><td>49.00 ETH</td><td><span class="addr">0x1f01e0aef2ce0ff439097bc9190156c0e2b6f1f0</span></td></tr>
      <tr><td>Mar 17</td><td>49.00 ETH</td><td><span class="addr">0x1f01e29ca045b2e791c48c328ff379b07fc1f1f0</span> (mirror pair)</td></tr>
    </table>
    <p style="color: #22C55E; font-weight: bold; font-size: 13px; margin-top: 12px;">This wallet is currently being monitored by our on-chain surveillance system.</p>
  </div>

  <div class="section">
    <h3>SUMMARY OF FUND FLOW</h3>
    <table class="flow-table">
      <tr><th>Asset</th><th>Stolen Amount</th><th>Current Location</th></tr>
      <tr>
        <td>aEthUSDC (Aave)</td>
        <td><span class="amount">~$20.6M</span></td>
        <td>Unwrapped &rarr; converted &rarr; dispersed through DAI splitting network</td>
      </tr>
      <tr>
        <td>DAI</td>
        <td><span class="amount">~$3.07M</span></td>
        <td>Split across 30+ wallets in mirror pairs; still being moved (last: Mar 20)</td>
      </tr>
      <tr>
        <td>ETH</td>
        <td><span class="amount">~490 ETH (~$1.02M)</span></td>
        <td>Split into 50 ETH chunks across 10+ wallets; most emptied to further hops</td>
      </tr>
      <tr>
        <td>WETH</td>
        <td><span class="amount">407 WETH (~$848K)</span></td>
        <td>Sent to contract, unwrapped and moved</td>
      </tr>
    </table>
  </div>

  <div class="section">
    <h3>KEY OBSERVATIONS</h3>
    <ul>
      <li><strong>Automated Script:</strong> The attacker uses automated splitting software &mdash; identical amounts sent to mirror-pair wallets with similar address prefixes (e.g., 0xd0c2...dd3e / 0xd0c2...d3e, 0xfcaa...d118 / 0xfcaa...d118). This is not manual laundering.</li>
      <li><strong>Spoofed Token Names:</strong> Some transfers use visually identical but different Unicode characters (e.g., "U5DC" instead of "USDC", "DА1" with Cyrillic A instead of "DAI") &mdash; possible evasion technique against automated monitoring.</li>
      <li><strong>Still Active:</strong> The laundering operation is <strong>ongoing</strong>. The most recent fund movements were March 20, 2026 &mdash; just 2 days before this report.</li>
      <li><strong>Operational Wallet Identified:</strong> <span class="addr-green">0xe347...1964</span> is the attacker&rsquo;s personal operational wallet with $437K in ETH, actively managing the laundering process.</li>
      <li><strong>Known Laundering Paths (from prior reports):</strong>
        <ul>
          <li>~$20M &rarr; DAI conversion &rarr; 12+ dispersal wallets</li>
          <li>~$2.47M &rarr; Hyperliquid/Wagyu &rarr; Monero (19 accounts)</li>
          <li>~$1.1M &rarr; Bitcoin via LiFi Bridge</li>
          <li>~$2.48M &rarr; Arbitrum USDC (10 receivers)</li>
        </ul>
      </li>
    </ul>
  </div>

  <div class="section">
    <h3>COMPLETE WALLET INDEX</h3>
    <p style="font-size: 11px; color: #94A3B8;">All unique wallets directly involved in the fund flow, organized by hop level:</p>
    <p style="font-size: 11px;"><strong style="color: #EF4444;">Hop 1 (Direct theft):</strong> 0xb98e8eefba0f7476b85cd9716cb5b38a935aa872, 0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb, 0x74de5d4fcbf63e00296fd95d33236b9794016631, 0xb98e32331c96b896541bf17727519f790a77a872, 0xb986765a00798135255677066ead4433a3d3a872, 0xb98424e784cf63872b76c3920d3eedc93c7b0872, 0xe3478b0bb1a5084567c319096437924948be1964, 0x0d5ce2862d3ef390323eec916f1840d7ac6059bb</p>
    <p style="font-size: 11px;"><strong style="color: #F59E0B;">Hop 2 (DAI hubs):</strong> 0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e, 0xd0c277aa22512262e4dbe524a1341e6b7618dd3e, 0xd0c254e18f41ccbc3a1ed62f3c153b6d24c9dd3e, 0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4, 0xdcadf21e8fe83b51d08b14d2575ca9b1973ec9c4, 0xdca900cf72d3233a5ecb7ee29615cfb0dc68c9c4</p>
    <p style="font-size: 11px;"><strong style="color: #F59E0B;">Hop 2 (ETH splits):</strong> 0x7aebc630f301f15baddf160103dc3bd8f9baf043, 0x487663784c77ba56e32d9fe60485d93c4c319385, 0x48788914a48b9a49616a1b03a5b8a2783c319385, 0x48763950cb0b86a12a0cb485d2e82f27037b9385, 0x6105ddc22166a1cf1b947b8928eebd2983557237, 0x610e10ed49f57591abe16d919b6d15aaf4557237, 0x9b9fd485e94c73af3bc8b9a630c4de7203bc96cb</p>
    <p style="font-size: 11px;"><strong style="color: #00D4FF;">Hop 3 (DAI dispersal):</strong> 0x17d4e5555c0c13ea8c22a5ddbaa3315cf343231d, 0x17d4684ee21ff2acfdca9aafab385c7f3e5e231d, 0x9da60764cc6e218dabe6e5c89587a9d251a36e20, 0x9da64c229438e1741fef63f4867588a63de86e20, 0xa9bf8ed5a085a13a4ceaad092d0c2e8fb36de304, 0xa9bf8cde52177ba92544e6ec091797a090dee304, 0xbaf21e87ea8257146935569eee71a55bb2add941, 0xbaf20dc17ad61d9fa2ab60cf0d9ca4d2a9cdd941, 0x65ca96af03f0db3466eb4e12219ad4d030bb8a54, 0x65cadde676f635e111446fe499565d109a638a54, 0xc0dc42bdea3b981ba49b12a561b5bf1b25f524d0, 0xc0dc70deb82da13095a21bc8424970543ea124d0, 0x54c26910e22e3367ada60c5bec55414348d6c01a, 0x54c23a224ba32fdc594974c7b0db0a0d6437c01a</p>
    <p style="font-size: 11px;"><strong style="color: #22C55E;">Active laundering (Mar 17-20):</strong> 0xb01caea8c6c47bbf4f4b4c5080ca642043359c2e, 0xc066ac5d385419b1a8c43a0e146fa439837a8b8c, 0xb42f812a44c22cc6b861478900401ee759ebead6, 0xfcaa4999cae2db88d6dea36db22b1fd065b0d118, 0xfcaa2be464290efcc3c4e16a01e7842a26a8d118, 0x1f01e0aef2ce0ff439097bc9190156c0e2b6f1f0, 0x1f01e29ca045b2e791c48c328ff379b07fc1f1f0</p>
  </div>

  <div class="footer">
    CONFIDENTIAL &mdash; For @sillytuna, SEAL 911, and law enforcement use only<br>
    Alpha Unlimited Trading &bull; Forensic Intelligence Division<br>
    Generated: ${now}
  </div>

</div>
</body>
</html>
`;

  const textBody = `COMPLETE FUND RETRACE REPORT
Case: ${CASE_ID} | Victim: @sillytuna (Alex Amsel)
Generated: ${now}

═══════════════════════════════════════════════════════════════
METHODOLOGY
═══════════════════════════════════════════════════════════════
Starting from victim wallet 0x6fe0fab2164d8e0d03ad6a628e2af78624060322, we traced every outbound transfer triggered by the EIP-7702 exploit on March 4, 2026. We followed each recipient wallet to map where the stolen funds moved next.

═══════════════════════════════════════════════════════════════
HOP 1 — DIRECT THEFT FROM VICTIM (March 4, 2026)
8 unique addresses received ~$26M across 30 transactions
═══════════════════════════════════════════════════════════════

1. 0xb98e8eefba0f7476b85cd9716cb5b38a935aa872
   Received: 490.6 ETH + 1,969,345 DAI (~$2.99M) | EMPTIED | 31 TXs

2. 0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb [CONTRACT]
   Received: 19,529,502 aEthUSDC (~$19.5M) | 0.56 ETH remaining

3. 0x74de5d4fcbf63e00296fd95d33236b9794016631 [CONTRACT]
   Received: 1,070,050 aEthUSDC + 407 WETH | EMPTIED

4. 0xb98e32331c96b896541bf17727519f790a77a872
   Received: 1,969,345 DAI | EMPTIED

5. 0xb986765a00798135255677066ead4433a3d3a872
   Received: 549,889 DAI | EMPTIED

6. 0xb98424e784cf63872b76c3920d3eedc93c7b0872
   Received: 2.28 ETH | EMPTIED

7. ★★★ 0xe3478b0bb1a5084567c319096437924948be1964 [OPERATIONAL WALLET]
   Received: 0.0002 ETH (gas funder) | CURRENT: 210.17 ETH (~$437K)
   89 tokens | 279 TXs | STILL ACTIVE (last: March 20, 2026)

8. 0x0d5ce2862d3ef390323eec916f1840d7ac6059bb
   Small ERC-20 | EMPTIED

═══════════════════════════════════════════════════════════════
HOP 2 — SPLITTING PATTERN
═══════════════════════════════════════════════════════════════

DAI Laundering Hubs (receiving millions):
- 0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e → ~10M DAI → 19 sub-wallets
- 0xd0c277aa22512262e4dbe524a1341e6b7618dd3e → ~8.5M DAI
- 0xd0c254e18f41ccbc3a1ed62f3c153b6d24c9dd3e → ~5.5M DAI
- 0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4 → ~10M DAI (STILL ACTIVE Mar 20)
- 0xdcadf21e8fe83b51d08b14d2575ca9b1973ec9c4 → ~8M DAI
- 0xdca900cf72d3233a5ecb7ee29615cfb0dc68c9c4 → ~8M DAI

ETH Splits (50 ETH / ~$104K chunks):
- Multiple wallets starting 0x4876..., 0x4878..., 0x610..., 0x9b9...
- Most emptied to further downstream hops

═══════════════════════════════════════════════════════════════
PRIMARY TARGET — ATTACKER'S OPERATIONAL WALLET
═══════════════════════════════════════════════════════════════

0xe3478b0bb1a5084567c319096437924948be1964

- Current Balance: 210.17 ETH (~$437,784)
- Token Holdings: 89 different tokens
- Transactions: 279 outbound
- Last Active: March 20, 2026 (2 days ago)
- Type: EOA (personal wallet)
- Connection: Sent gas to victim wallet for exploit execution
- Activity: Sending 5 ETH chunks and ~$24.5K USDC batches in mirror pairs
- This is the attacker's working wallet, still actively managing laundering

═══════════════════════════════════════════════════════════════
KEY OBSERVATIONS
═══════════════════════════════════════════════════════════════

1. AUTOMATED SCRIPT: Mirror-pair wallets with identical amounts and similar prefixes
2. SPOOFED TOKENS: Uses Unicode lookalikes ("U5DC" for USDC, Cyrillic "DА1" for DAI)
3. STILL ACTIVE: Laundering ongoing as of March 20, 2026
4. KNOWN PATHS: ~$20M→DAI, ~$2.47M→Monero, ~$1.1M→Bitcoin, ~$2.48M→Arbitrum USDC

CONFIDENTIAL — For @sillytuna, SEAL 911, and law enforcement only
Alpha Unlimited Trading | Forensic Intelligence Division | ${now}
`;

  const { client: sgClient, fromEmail } = await getUncachableSendGridClient();

  for (const recipient of RECIPIENTS) {
    console.log(`[MoneyTrailReport] Sending to ${recipient.email}...`);

    const msg = {
      to: recipient.email,
      from: { email: fromEmail, name: "Alpha Unlimited Forensics" },
      subject: `[FORENSIC] Complete Fund Retrace — @sillytuna ~$26M EIP-7702 — Attacker Operational Wallet Identified ($437K Active) — Case ${CASE_ID.slice(0, 8)}`,
      content: [
        { type: "text/plain", value: textBody },
        { type: "text/html", value: htmlBody },
      ],
    };

    await sgClient.send(msg);

    console.log(`[MoneyTrailReport] ✓ Sent to ${recipient.email}`);
  }

  console.log("\n[MoneyTrailReport] Done. Report sent to all recipients.");
}

main().catch((err) => {
  console.error("[MoneyTrailReport] FATAL:", err);
  process.exit(1);
});
