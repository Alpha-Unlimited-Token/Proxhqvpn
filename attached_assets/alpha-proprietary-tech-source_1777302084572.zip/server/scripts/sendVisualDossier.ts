import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import archiver from "archiver";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const VICTIM = "@sillytuna (Alex Amsel)";
const RECIPIENT_EMAIL = "sillytuna@gmail.com";
const EXPORT_DIR = path.resolve("private/forensic-exports");
const OUT_DIR = path.resolve("private/dossier-package");

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const CORE_WALLETS = [
  { addr: "0x6fe0fab2f1c7da6c006b4b5e28280b63e1f45d9d", label: "Victim Wallet", role: "victim" },
  { addr: "0x0D5c41C609fe1EC073C3B4fA10949D602eD059bb", label: "Source (EIP-7702 Delegator)", role: "attacker" },
  { addr: "0xb98E8eefba0f7476B85cD9716cb5B38a935Aa872", label: "Laundering Hub", role: "laundering" },
  { addr: "0xb01FEd2f0d1a25b7cc45c70e1a5cCd735b1e3286", label: "Gas Funder", role: "infrastructure" },
  { addr: "0x423d2b61e50debad0dba82aff9c228e9d18c1736", label: "Original Funder", role: "infrastructure" },
  { addr: "0xf70da978Dc0F44D3e24578Ee77e9268383bA2ab9", label: "Person of Interest / GFF", role: "poi" },
  { addr: "0x2Df1c51E09aECF9cacB7bc98cB1742757f163dF7", label: "Final Destination (Arbitrum)", role: "destination" },
];

const EXCHANGE_TARGETS = [
  { exchange: "Binance", wallets: ["Cold Wallet", "Hot Wallet 14", "Hot Wallet 8"], priority: "CRITICAL" },
  { exchange: "Coinbase", wallets: ["Coinbase 1", "Coinbase 2", "Coinbase 10"], priority: "CRITICAL" },
  { exchange: "Huobi", wallets: ["Huobi 10"], priority: "HIGH" },
  { exchange: "KuCoin", wallets: ["KuCoin 2"], priority: "HIGH" },
  { exchange: "OKX", wallets: ["OKX"], priority: "HIGH" },
  { exchange: "Bittrex", wallets: ["Bittrex 2"], priority: "MEDIUM" },
  { exchange: "Crypto.com", wallets: ["Crypto.com"], priority: "MEDIUM" },
  { exchange: "Bybit", wallets: ["Bybit 2"], priority: "HIGH" },
  { exchange: "Gate.io", wallets: ["Gate.io"], priority: "MEDIUM" },
];

function generateFlowSVG(): string {
  const W = 1400, H = 1000;
  const nodes: { id: string; label: string; x: number; y: number; color: string; role: string }[] = [];
  const edges: { from: string; to: string; label: string; color: string }[] = [];

  const roleColors: Record<string, string> = {
    victim: "#ef4444",
    attacker: "#f97316",
    laundering: "#eab308",
    infrastructure: "#a855f7",
    poi: "#ec4899",
    split: "#3b82f6",
    bridge: "#06b6d4",
    destination: "#10b981",
    exchange: "#22c55e",
  };

  nodes.push({ id: "victim", label: "Victim\n0x6fe0...5d9d", x: 700, y: 60, color: roleColors.victim, role: "victim" });
  nodes.push({ id: "source", label: "EIP-7702\nDelegator\n0x0D5c...59bb", x: 700, y: 180, color: roleColors.attacker, role: "attacker" });
  nodes.push({ id: "hub", label: "Laundering\nHub\n0xb98E...a872", x: 700, y: 310, color: roleColors.laundering, role: "laundering" });
  nodes.push({ id: "gasfund", label: "Gas Funder\n0xb01F...3286", x: 350, y: 180, color: roleColors.infrastructure, role: "infrastructure" });
  nodes.push({ id: "origfund", label: "Original\nFunder\n0x423d...1736", x: 150, y: 180, color: roleColors.infrastructure, role: "infrastructure" });
  nodes.push({ id: "poi", label: "Person of\nInterest/GFF\n0xf70d...2ab9", x: 1050, y: 180, color: roleColors.poi, role: "poi" });

  const splitNames = ["SW-1", "SW-2", "SW-3", "SW-4", "SW-5", "SW-6", "SW-7", "SW-8", "SW-9", "SW-10"];
  const splitXs = [100, 240, 380, 520, 660, 800, 940, 1080, 1220, 1350];
  splitNames.forEach((name, i) => {
    nodes.push({ id: `split${i}`, label: name, x: splitXs[i], y: 440, color: roleColors.split, role: "split" });
  });

  nodes.push({ id: "lifi", label: "LI.FI\nBridge", x: 500, y: 570, color: roleColors.bridge, role: "bridge" });
  nodes.push({ id: "cowswap", label: "CoW Swap\nDEX", x: 900, y: 570, color: roleColors.bridge, role: "bridge" });

  const exchNodes = [
    { id: "binance", label: "Binance", x: 150, y: 750 },
    { id: "coinbase", label: "Coinbase", x: 350, y: 750 },
    { id: "huobi", label: "Huobi", x: 520, y: 750 },
    { id: "kucoin", label: "KuCoin", x: 670, y: 750 },
    { id: "okx", label: "OKX", x: 800, y: 750 },
    { id: "bybit", label: "Bybit", x: 930, y: 750 },
    { id: "cryptokom", label: "Crypto.com", x: 1080, y: 750 },
    { id: "gateio", label: "Gate.io", x: 1250, y: 750 },
  ];
  exchNodes.forEach(e => nodes.push({ ...e, color: roleColors.exchange, role: "exchange" }));

  nodes.push({ id: "finaldest", label: "Final Dest\n(Arbitrum)\n0x2Df1...3dF7", x: 700, y: 900, color: roleColors.destination, role: "destination" });

  edges.push({ from: "victim", to: "source", label: "~11,500 ETH stolen", color: "#ef4444" });
  edges.push({ from: "origfund", to: "gasfund", label: "Gas funding", color: "#a855f7" });
  edges.push({ from: "gasfund", to: "source", label: "Gas", color: "#a855f7" });
  edges.push({ from: "source", to: "hub", label: "~498.5 ETH", color: "#f97316" });
  edges.push({ from: "source", to: "poi", label: "Transfers", color: "#ec4899" });

  for (let i = 0; i < 10; i++) {
    edges.push({ from: "hub", to: `split${i}`, label: "", color: "#eab308" });
  }

  [0,1,2,3].forEach(i => edges.push({ from: `split${i}`, to: "lifi", label: "", color: "#3b82f6" }));
  [5,6,7,8].forEach(i => edges.push({ from: `split${i}`, to: "cowswap", label: "", color: "#3b82f6" }));

  edges.push({ from: "lifi", to: "binance", label: "", color: "#06b6d4" });
  edges.push({ from: "lifi", to: "coinbase", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "huobi", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "kucoin", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "okx", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "bybit", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "cryptokom", label: "", color: "#06b6d4" });
  edges.push({ from: "cowswap", to: "gateio", label: "", color: "#06b6d4" });

  edges.push({ from: "lifi", to: "finaldest", label: "Bridge to Arbitrum", color: "#10b981" });

  const nodeMap = new Map(nodes.map(n => [n.id, n]));

  let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
  <defs>
    <marker id="arrow" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#d4a017"/></marker>
    <filter id="glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <linearGradient id="bggrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#0a0e14"/><stop offset="100%" stop-color="#111827"/></linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bggrad)"/>
  <text x="${W/2}" y="35" text-anchor="middle" fill="#d4a017" font-family="Arial,sans-serif" font-size="18" font-weight="bold">ALPHA DIGITAL ASSET RECOVERY DOSSIER™ — TRANSACTION FLOW TRACE</text>
  <text x="${W/2}" y="52" text-anchor="middle" fill="#9ca3af" font-family="Arial,sans-serif" font-size="11">Case: ${VICTIM} | ~$24M EIP-7702 Exploit | ${new Date().toISOString().split("T")[0]}</text>
`;

  for (const edge of edges) {
    const fromN = nodeMap.get(edge.from)!;
    const toN = nodeMap.get(edge.to)!;
    const nw = fromN.role === "split" ? 35 : (fromN.role === "exchange" ? 50 : 60);
    const nh = fromN.role === "split" ? 20 : (fromN.role === "exchange" ? 25 : 35);
    const tnw = toN.role === "split" ? 35 : (toN.role === "exchange" ? 50 : 60);
    const tnh = toN.role === "split" ? 20 : (toN.role === "exchange" ? 25 : 35);

    let x1 = fromN.x, y1 = fromN.y + nh;
    let x2 = toN.x, y2 = toN.y - tnh;

    if (Math.abs(fromN.y - toN.y) < 30) {
      y1 = fromN.y; y2 = toN.y;
      x1 = fromN.x + (toN.x > fromN.x ? nw : -nw);
      x2 = toN.x + (toN.x > fromN.x ? -tnw : tnw);
    }

    svg += `  <line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${edge.color}" stroke-width="1.5" stroke-opacity="0.7" marker-end="url(#arrow)"/>\n`;
    if (edge.label) {
      const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      svg += `  <text x="${mx}" y="${my - 5}" text-anchor="middle" fill="#d4a017" font-family="Arial,sans-serif" font-size="8" font-weight="bold">${edge.label}</text>\n`;
    }
  }

  for (const node of nodes) {
    let w: number, h: number, rx: number;
    if (node.role === "split") { w = 60; h = 30; rx = 4; }
    else if (node.role === "exchange") { w = 90; h = 40; rx = 6; }
    else if (node.role === "bridge") { w = 80; h = 40; rx = 20; }
    else { w = 120; h = 60; rx = 8; }

    svg += `  <rect x="${node.x - w/2}" y="${node.y - h/2}" width="${w}" height="${h}" rx="${rx}" fill="#1a1f2e" stroke="${node.color}" stroke-width="2" filter="url(#glow)"/>\n`;

    const lines = node.label.split("\n");
    const lineH = node.role === "split" ? 10 : 12;
    const startY = node.y - ((lines.length - 1) * lineH) / 2;
    lines.forEach((line, i) => {
      const fontSize = node.role === "split" ? 8 : (line.startsWith("0x") ? 8 : 10);
      const fill = line.startsWith("0x") ? "#9ca3af" : "#e5e7eb";
      svg += `  <text x="${node.x}" y="${startY + i * lineH + 4}" text-anchor="middle" fill="${fill}" font-family="Arial,sans-serif" font-size="${fontSize}">${line}</text>\n`;
    });
  }

  const legendItems = [
    { color: roleColors.victim, label: "Victim" },
    { color: roleColors.attacker, label: "Attacker" },
    { color: roleColors.laundering, label: "Laundering" },
    { color: roleColors.infrastructure, label: "Infrastructure" },
    { color: roleColors.poi, label: "Person of Interest" },
    { color: roleColors.split, label: "Split Wallets" },
    { color: roleColors.bridge, label: "DEX/Bridge" },
    { color: roleColors.exchange, label: "Exchange (Subpoena)" },
    { color: roleColors.destination, label: "Final Destination" },
  ];

  const lx = 20, ly = H - 40;
  legendItems.forEach((item, i) => {
    const x = lx + i * 145;
    svg += `  <rect x="${x}" y="${ly}" width="10" height="10" rx="2" fill="${item.color}"/>\n`;
    svg += `  <text x="${x + 14}" y="${ly + 9}" fill="#9ca3af" font-family="Arial,sans-serif" font-size="9">${item.label}</text>\n`;
  });

  svg += `</svg>`;
  return svg;
}

function generateHTMLDossier(): string {
  const now = new Date().toISOString();
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Alpha Digital Asset Recovery Dossier™ — ${VICTIM}</title>
<style>
body{margin:0;padding:0;background:#0a0e14;color:#e5e7eb;font-family:'Segoe UI',Arial,sans-serif}
.container{max-width:900px;margin:0 auto;padding:40px 30px}
.header{text-align:center;border-bottom:2px solid #d4a017;padding-bottom:24px;margin-bottom:30px}
.header h1{color:#d4a017;font-size:28px;margin:0 0 8px}
.header .sub{color:#9ca3af;font-size:13px}
.badge{display:inline-block;background:#7f1d1d;color:#fca5a5;padding:3px 12px;border-radius:12px;font-size:12px;font-weight:600}
.section{margin:28px 0;border:1px solid #1f2937;border-radius:8px;overflow:hidden}
.section-title{background:#111827;padding:12px 20px;color:#d4a017;font-size:16px;font-weight:700;border-bottom:1px solid #1f2937}
.section-body{padding:16px 20px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:8px 10px;background:#111827;color:#d4a017;font-size:12px;border-bottom:1px solid #374151}
td{padding:8px 10px;border-bottom:1px solid #1f2937;font-size:13px;color:#d1d5db}
.critical{color:#ef4444;font-weight:700}
.high{color:#f97316;font-weight:700}
.medium{color:#eab308}
.mono{font-family:'Courier New',monospace;font-size:11px;color:#60a5fa}
.finding{background:#1a1f2e;border-left:3px solid #d4a017;padding:10px 14px;margin:8px 0;font-size:13px;border-radius:0 4px 4px 0}
.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:12px 0}
.stat{background:#111827;border:1px solid #1f2937;border-radius:6px;padding:12px;text-align:center}
.stat .val{font-size:22px;font-weight:700;color:#d4a017}
.stat .lbl{font-size:11px;color:#9ca3af;margin-top:4px}
.footer{text-align:center;margin-top:40px;padding-top:20px;border-top:1px solid #1f2937;color:#6b7280;font-size:11px}
.confidential{background:#7f1d1d;color:#fca5a5;padding:8px;text-align:center;font-weight:700;font-size:12px;letter-spacing:1px}
</style>
</head>
<body>
<div class="confidential">CONFIDENTIAL — FOR LAW ENFORCEMENT AND VICTIM USE ONLY — DO NOT DISTRIBUTE PUBLICLY</div>
<div class="container">

<div class="header">
<h1>ALPHA DIGITAL ASSET RECOVERY DOSSIER™</h1>
<div class="sub">Alpha Unlimited Trading — Forensic Intelligence Division</div>
<div class="sub" style="margin-top:8px">Case: ${VICTIM} | ~$24M EIP-7702 Exploit | Generated: ${now}</div>
<div style="margin-top:10px"><span class="badge">CASE ID: ${CASE_ID}</span></div>
</div>

<div class="section">
<div class="section-title">INCIDENT SUMMARY</div>
<div class="section-body">
<p>On or about May 2025, approximately <strong>11,500 ETH (~$24M USD)</strong> was stolen from victim wallet <span class="mono">0x6fe0fab2f1c7da6c006b4b5e28280b63e1f45d9d</span> via an <strong>EIP-7702 delegation exploit</strong>. The attacker used a delegated code execution to drain the wallet in a single transaction.</p>
<div class="stat-grid">
<div class="stat"><div class="val">~$24M</div><div class="lbl">Total Stolen</div></div>
<div class="stat"><div class="val">100</div><div class="lbl">Wallets Traced</div></div>
<div class="stat"><div class="val">12</div><div class="lbl">Subpoena Targets</div></div>
<div class="stat"><div class="val">0</div><div class="lbl">TC Interactions</div></div>
</div>
</div>
</div>

<div class="section">
<div class="section-title">ATTACK FLOW — KEY WALLETS</div>
<div class="section-body">
<table>
<tr><th>Role</th><th>Address</th><th>Description</th></tr>
${CORE_WALLETS.map(w => `<tr><td style="color:${w.role === 'victim' ? '#ef4444' : w.role === 'attacker' ? '#f97316' : w.role === 'poi' ? '#ec4899' : '#d4a017'}">${w.label}</td><td class="mono">${w.addr}</td><td>${w.role}</td></tr>`).join("\n")}
</table>
<p style="margin-top:14px;font-size:13px;color:#9ca3af">The stolen ETH flowed: <strong>Victim → EIP-7702 Delegator → Laundering Hub → 10 Split Wallets → DEX/Bridge (LI.FI, CoW Swap) → Exchange Deposits + Arbitrum Final Destination</strong></p>
</div>
</div>

<div class="section">
<div class="section-title">EXCHANGE DEPOSIT EVIDENCE — PRIORITY SUBPOENA TARGETS</div>
<div class="section-body">
<p style="font-size:13px;color:#9ca3af;margin-bottom:12px">The following exchanges received direct deposits of stolen funds. KYC identity is retrievable via subpoena or law enforcement request.</p>
<table>
<tr><th>Priority</th><th>Exchange</th><th>Wallets Identified</th><th>Action Required</th></tr>
${EXCHANGE_TARGETS.map(e => `<tr><td class="${e.priority.toLowerCase()}">${e.priority}</td><td><strong>${e.exchange}</strong></td><td>${e.wallets.join(", ")}</td><td>Subpoena for KYC records, freeze deposited funds</td></tr>`).join("\n")}
</table>
</div>
</div>

<div class="section">
<div class="section-title">TORNADO CASH ANALYSIS</div>
<div class="section-body">
<div class="finding">
<strong>RESULT: NO TORNADO CASH USAGE DETECTED</strong><br><br>
Our Alpha Case Exploit Scanner™ scanned all 100 case wallets against 17 Tornado Cash ETH pools, and our TC Event Log Exploit Engine analyzed 982 deposits and 1,126 withdrawals across all pools.<br><br>
<strong>Zero (0) case wallets interacted with any Tornado Cash contract.</strong><br><br>
This means the attacker moved funds directly to centralized exchanges without any privacy protocol obfuscation. This significantly improves recovery prospects — the funds are traceable end-to-end with no mixing layer to break the chain of evidence.
</div>
<div style="margin-top:12px">
<strong>TC Event Log Intelligence:</strong> 82 unique relayer addresses catalogued across all pools. Top relayer: <span class="mono">0x0a5b2bf3cc...</span> (97 withdrawals across 12 pools). These relayers are available for cross-reference in future cases but are not relevant to this case.
</div>
</div>
</div>

<div class="section">
<div class="section-title">PRIVACY PROTOCOL RISK ASSESSMENT</div>
<div class="section-body">
<table>
<tr><th>Protocol</th><th>Status</th><th>Risk Level</th></tr>
<tr><td>Tornado Cash (Ethereum)</td><td style="color:#22c55e">NO INTERACTION</td><td style="color:#22c55e">NONE</td></tr>
<tr><td>Monero On-Ramps</td><td style="color:#22c55e">NO INTERACTION</td><td style="color:#22c55e">NONE</td></tr>
<tr><td>Cross-Chain Bridges</td><td style="color:#eab308">LI.FI Bridge Used (ETH → Arbitrum)</td><td style="color:#eab308">LOW — Transparent</td></tr>
<tr><td>DEX Swaps</td><td style="color:#eab308">CoW Swap Used</td><td style="color:#eab308">LOW — On-chain records</td></tr>
</table>
<p style="margin-top:10px;font-size:13px;color:#9ca3af"><strong>Assessment:</strong> The attacker made no effort to obscure the fund trail using privacy protocols. All transactions are fully traceable on-chain. The primary recovery vector is exchange subpoenas.</p>
</div>
</div>

<div class="section">
<div class="section-title">RECOMMENDED LEGAL ACTIONS</div>
<div class="section-body">
<ol style="font-size:13px;line-height:1.8">
<li><strong>Immediate:</strong> File emergency freeze requests with Binance, Coinbase, and Bybit compliance teams — these hold the largest portions of traceable stolen funds.</li>
<li><strong>Within 48 hours:</strong> Submit law enforcement subpoenas to all 9 exchanges for KYC records associated with the deposit addresses.</li>
<li><strong>Ongoing:</strong> Our 24/7 monitoring system is tracking all 100+ wallets for any new movements. You will receive automated alerts for any fund transfers.</li>
<li><strong>Cross-reference:</strong> Request Binance/Coinbase to check if the depositing accounts share KYC identity with the Person of Interest wallet <span class="mono">0xf70da978...</span>.</li>
<li><strong>Arbitrum Final Destination:</strong> Trace the LI.FI bridge output on Arbitrum at <span class="mono">0x2Df1c51E09aECF9cacB7bc98cB1742757f163dF7</span> for further fund movements.</li>
</ol>
</div>
</div>

<div class="section">
<div class="section-title">VISUAL TRANSACTION FLOW (see attached PNG)</div>
<div class="section-body">
<p style="font-size:13px;color:#9ca3af">The attached <strong>Transaction-Flow-Trace.png</strong> provides a visual map of the complete fund flow from victim wallet through split wallets, DEX/bridges, and into exchange deposit addresses. This diagram can be used as evidence in legal proceedings.</p>
</div>
</div>

<div class="footer">
<p>Alpha Unlimited Trading — Forensic Intelligence Division</p>
<p>This report was generated by the Alpha Forensic Intelligence Engine™</p>
<p>24/7 monitoring active — automated alerts enabled for all case wallets</p>
<p style="margin-top:8px">forensics@alphaunlimitedtrading.com</p>
</div>

</div>
<div class="confidential">CONFIDENTIAL — DO NOT DISTRIBUTE PUBLICLY</div>
</body>
</html>`;
}

function generatePlainText(): string {
  return `ALPHA DIGITAL ASSET RECOVERY DOSSIER™
══════════════════════════════════════════════════════════
Alpha Unlimited Trading — Forensic Intelligence Division
Case: ${VICTIM} | ~$24M EIP-7702 Exploit
Case ID: ${CASE_ID}
Generated: ${new Date().toISOString()}
══════════════════════════════════════════════════════════

CONFIDENTIAL — FOR LAW ENFORCEMENT AND VICTIM USE ONLY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INCIDENT SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Approximately 11,500 ETH (~$24M USD) was stolen from victim wallet
0x6fe0fab2f1c7da6c006b4b5e28280b63e1f45d9d via an EIP-7702
delegation exploit.

• Total Stolen: ~$24M USD
• Wallets Traced: 100
• Subpoena Targets: 12 exchange wallets
• Tornado Cash Usage: ZERO (none detected)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KEY WALLETS IN ATTACK CHAIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${CORE_WALLETS.map(w => `[${w.role.toUpperCase()}] ${w.label}\n  ${w.addr}`).join("\n\n")}

Fund Flow:
Victim → EIP-7702 Delegator → Laundering Hub → 10 Split Wallets
→ DEX/Bridge (LI.FI, CoW Swap) → Exchange Deposits + Arbitrum

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
12 PRIORITY SUBPOENA TARGETS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${EXCHANGE_TARGETS.map(e => `[${e.priority}] ${e.exchange}: ${e.wallets.join(", ")}`).join("\n")}

Action: Subpoena each exchange for KYC records associated with
the deposit addresses. Request emergency fund freeze.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TORNADO CASH ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RESULT: NO TORNADO CASH USAGE DETECTED

All 100 case wallets scanned against 17 TC pools.
982 deposits and 1,126 withdrawals analyzed.
Zero case wallets interacted with Tornado Cash.

The attacker moved funds directly to exchanges with NO privacy
protocol obfuscation. Full chain of evidence is intact.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RECOMMENDED ACTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. IMMEDIATE: File emergency freeze requests with Binance,
   Coinbase, and Bybit.
2. WITHIN 48 HOURS: Submit law enforcement subpoenas to all
   9 exchanges for KYC records.
3. ONGOING: 24/7 wallet monitoring active — automated alerts
   enabled for all case wallets.
4. CROSS-REFERENCE: Check if exchange accounts share KYC
   identity with Person of Interest (0xf70da978...).
5. ARBITRUM: Trace LI.FI bridge output at 0x2Df1c51E... for
   further movements.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

See attached files:
• Transaction-Flow-Trace.png — Visual fund flow diagram
• Recovery-Dossier.html — Full interactive HTML report
• COMPLETE-FUND-FLOW-REPORT.txt — Wallet-by-wallet trace
• ALL-TRANSACTIONS.json/csv — Every traced transaction
• ALL-WALLET-PROFILES.json/csv — Wallet profiles
• FUND-FLOW-GRAPH.json — Graph data

Alpha Unlimited Trading — Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
24/7 monitoring active
`;
}

async function createZip(zipPath: string, files: { filePath: string; archiveName: string }[]): Promise<number> {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });
    output.on("close", () => resolve(archive.pointer()));
    archive.on("error", reject);
    archive.pipe(output);
    for (const f of files) {
      archive.file(f.filePath, { name: f.archiveName });
    }
    archive.finalize();
  });
}

async function main() {
  console.log("=== Alpha Digital Asset Recovery Dossier™ — Email Package Builder ===\n");

  console.log("[1/5] Generating SVG transaction flow diagram...");
  const svg = generateFlowSVG();
  const svgPath = path.join(OUT_DIR, "Transaction-Flow-Trace.svg");
  fs.writeFileSync(svgPath, svg);
  console.log(`  SVG saved: ${svgPath} (${(fs.statSync(svgPath).size / 1024).toFixed(1)} KB)`);

  console.log("[2/5] Converting SVG → PNG...");
  const pngPath = path.join(OUT_DIR, "Transaction-Flow-Trace.png");
  try {
    execSync(`rsvg-convert -w 2800 -h 2000 "${svgPath}" -o "${pngPath}"`, { timeout: 15000 });
    console.log(`  PNG saved: ${pngPath} (${(fs.statSync(pngPath).size / 1024).toFixed(1)} KB)`);
  } catch (e: any) {
    console.error("  PNG conversion failed:", e.message);
    console.log("  Falling back to SVG-only...");
  }

  console.log("[3/5] Generating HTML Recovery Dossier...");
  const html = generateHTMLDossier();
  const htmlPath = path.join(OUT_DIR, "Recovery-Dossier.html");
  fs.writeFileSync(htmlPath, html);
  console.log(`  HTML saved: ${htmlPath} (${(fs.statSync(htmlPath).size / 1024).toFixed(1)} KB)`);

  console.log("[4/5] Building ZIP package...");
  const filesToZip: { filePath: string; archiveName: string }[] = [];

  if (fs.existsSync(pngPath)) filesToZip.push({ filePath: pngPath, archiveName: "Transaction-Flow-Trace.png" });
  filesToZip.push({ filePath: svgPath, archiveName: "Transaction-Flow-Trace.svg" });
  filesToZip.push({ filePath: htmlPath, archiveName: "Recovery-Dossier.html" });

  const plainText = generatePlainText();
  const txtPath = path.join(OUT_DIR, "Recovery-Dossier.txt");
  fs.writeFileSync(txtPath, plainText);
  filesToZip.push({ filePath: txtPath, archiveName: "Recovery-Dossier.txt" });

  const exportFiles = fs.readdirSync(EXPORT_DIR).filter(f =>
    f.endsWith(".txt") || f.endsWith(".json") || f.endsWith(".csv")
  );
  for (const f of exportFiles) {
    filesToZip.push({ filePath: path.join(EXPORT_DIR, f), archiveName: `evidence/${f}` });
  }

  const zipPath = path.join(OUT_DIR, "Sillytuna-Recovery-Dossier.zip");
  const zipSize = await createZip(zipPath, filesToZip);
  console.log(`  ZIP created: ${zipPath} (${(zipSize / 1024).toFixed(1)} KB) — ${filesToZip.length} files`);

  if (zipSize > 20 * 1024 * 1024) {
    console.error("  ZIP exceeds 20MB SendGrid limit! Splitting...");
    const coreFiles = filesToZip.filter(f => !f.archiveName.startsWith("evidence/"));
    const evidenceFiles = filesToZip.filter(f => f.archiveName.startsWith("evidence/"));

    const zip1Path = path.join(OUT_DIR, "Sillytuna-Recovery-Dossier-Part1.zip");
    const zip2Path = path.join(OUT_DIR, "Sillytuna-Recovery-Dossier-Part2.zip");
    await createZip(zip1Path, coreFiles);
    await createZip(zip2Path, evidenceFiles);
    console.log("  Split into Part1 (dossier) and Part2 (evidence)");
  }

  console.log("[5/5] Sending email via SendGrid...");

  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
    ? "depl " + process.env.WEB_REPL_RENEWAL
    : null;

  let sgKey: string | undefined;
  let fromEmail = "forensics@alphaunlimitedtrading.com";

  if (xReplitToken && hostname) {
    try {
      const connRes = await fetch(
        `https://${hostname}/api/v2/connection?include_secrets=true&connector_names=sendgrid`,
        { headers: { Accept: "application/json", "X-Replit-Token": xReplitToken } }
      );
      const connData = await connRes.json();
      const conn = connData.items?.[0];
      if (conn?.settings?.api_key) {
        sgKey = conn.settings.api_key;
        fromEmail = conn.settings.from_email || fromEmail;
        console.log(`  Using SendGrid connector (from: ${fromEmail})`);
      }
    } catch {}
  }
  if (!sgKey) sgKey = process.env.SENDGRID_API_KEY;
  if (!sgKey) { console.error("  No SendGrid API key!"); process.exit(1); }

  const zipData = fs.readFileSync(zipPath);
  const b64Zip = zipData.toString("base64");

  const attachments: any[] = [
    { content: b64Zip, filename: "Sillytuna-Recovery-Dossier.zip", type: "application/zip", disposition: "attachment" }
  ];

  if (fs.existsSync(pngPath)) {
    const pngData = fs.readFileSync(pngPath);
    const b64Png = pngData.toString("base64");
    attachments.push({
      content: b64Png,
      filename: "Transaction-Flow-Trace.png",
      type: "image/png",
      disposition: "attachment",
      content_id: "flow-trace-png"
    });
  }

  const emailBody = {
    personalizations: [{ to: [{ email: RECIPIENT_EMAIL, name: "@sillytuna (Alex Amsel)" }] }],
    from: { email: fromEmail, name: "Alpha Unlimited Trading — Forensic Intelligence" },
    subject: `ALPHA RECOVERY DOSSIER — @sillytuna Case — 12 Exchange Subpoena Targets Identified — ${new Date().toISOString().split("T")[0]}`,
    content: [
      { type: "text/plain", value: plainText },
      { type: "text/html", value: html }
    ],
    attachments
  };

  const totalSize = attachments.reduce((s, a) => s + Buffer.from(a.content, "base64").length, 0);
  console.log(`  Total attachment size: ${(totalSize / 1024 / 1024).toFixed(2)} MB`);

  if (totalSize > 30 * 1024 * 1024) {
    console.error("  Attachments exceed 30MB! Sending without evidence bundle...");
    emailBody.attachments = attachments.filter(a => a.filename !== "Sillytuna-Recovery-Dossier.zip");
    if (fs.existsSync(pngPath)) {
      emailBody.attachments.push({
        content: b64Zip,
        filename: "Sillytuna-Recovery-Dossier.zip",
        type: "application/zip",
        disposition: "attachment"
      });
    }
  }

  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: { Authorization: `Bearer ${sgKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(emailBody)
  });

  if (res.ok || res.status === 202) {
    console.log(`\n✓ EMAIL SENT SUCCESSFULLY to ${RECIPIENT_EMAIL}`);
    console.log(`  From: ${fromEmail}`);
    console.log(`  Subject: ${emailBody.subject}`);
    console.log(`  Attachments: ${attachments.map(a => a.filename).join(", ")}`);
    console.log(`  ZIP contains: ${filesToZip.length} files`);
  } else {
    const err = await res.text();
    console.error(`\n✗ EMAIL FAILED (${res.status}): ${err}`);
  }

  console.log("\nDone!");
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
