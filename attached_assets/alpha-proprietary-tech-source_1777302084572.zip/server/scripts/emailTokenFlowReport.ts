import { db } from "../db.js";
import { eq, desc } from "drizzle-orm";
import { monitoredWallets, forensicAlerts } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const VICTIM = "0x6fe0fab216e0f4d70b4a2f9de57420b57e2ef4f3";
const RECIPIENT_EMAIL = "sillytuna@gmail.com";
const RECIPIENT_NAME = "@sillytuna";
const BASE = "https://eth.blockscout.com/api/v2";

const EXCHANGES: Record<string, string> = {
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io",
  "0x28c6c06298d514db089934071d89d3dece0c3b2d": "Binance 14",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 15",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 36",
  "0x503828976d22510aad0339f13e7b8b8f3b5f1e1c": "Coinbase",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase 3",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
};

async function apiFetch(url: string) {
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(12000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

async function main() {
  console.log("=== GENERATING & SENDING TOKEN FLOW REPORT ===\n");

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const tokenRecipients = wallets.filter(w => w.role === "token_recipient");

  const alerts = await db.select().from(forensicAlerts)
    .where(eq(forensicAlerts.caseId, CASE_ID))
    .orderBy(desc(forensicAlerts.createdAt));

  const tokenAlerts = alerts.filter(a =>
    a.alertType === "token_change" ||
    a.alertType === "token_exchange_deposit" ||
    a.alertType === "token_returned_to_victim"
  );

  const keyWallets = wallets.filter(w =>
    w.label?.includes("Person of Interest") || w.role === "POI" || w.role === "poi" ||
    w.label?.includes("Fund Destination") || w.label?.includes("Source")
  ).slice(0, 10);

  console.log(`Key wallets to scan: ${keyWallets.length}`);
  console.log(`Existing token recipients: ${tokenRecipients.length}`);
  console.log(`Token-related alerts: ${tokenAlerts.length}\n`);

  interface Flow {
    time: string; from: string; to: string; fromLabel: string; toLabel: string;
    token: string; amount: number; txHash: string; chain: string;
    isReturn: boolean; isExchange: boolean; exchName: string;
  }
  const allFlows: Flow[] = [];

  for (const w of keyWallets) {
    const addr = w.address.toLowerCase();
    const chain = w.chain || "ethereum";
    const apiBase = chain === "arbitrum" ? "https://arbitrum.blockscout.com/api/v2" : BASE;

    console.log(`Scanning ${(w.label || addr).slice(0, 50)}...`);
    const data = await apiFetch(`${apiBase}/addresses/${addr}/token-transfers`);
    await new Promise(r => setTimeout(r, 200));
    if (!data?.items) continue;

    for (const tx of data.items) {
      const from = (tx.from?.hash || "").toLowerCase();
      const to = (tx.to?.hash || "").toLowerCase();
      const sym = tx.token?.symbol || "?";
      const dec = parseInt(tx.token?.decimals || "18");
      const amt = parseFloat(tx.total?.value || "0") / Math.pow(10, dec);
      if (amt < 0.001) continue;
      const isOut = from === addr;
      const dest = isOut ? to : from;

      allFlows.push({
        time: tx.timestamp || "",
        from, to,
        fromLabel: isOut ? (w.label || addr.slice(0, 14)) : (EXCHANGES[from] || from.slice(0, 14)),
        toLabel: isOut ? (EXCHANGES[to] || to.slice(0, 14)) : (w.label || addr.slice(0, 14)),
        token: sym, amount: amt,
        txHash: tx.transaction_hash || "",
        chain,
        isReturn: to === VICTIM.toLowerCase(),
        isExchange: isOut && !!EXCHANGES[to],
        exchName: EXCHANGES[to] || ""
      });
    }
    console.log(`  ${data.items.length} transfers`);
  }

  allFlows.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
  const uniqueTokens = [...new Set(allFlows.map(f => f.token))];
  const returns = allFlows.filter(f => f.isReturn);
  const exchanges = allFlows.filter(f => f.isExchange);
  const outgoing = allFlows.filter(f => keyWallets.some(w => w.address.toLowerCase() === f.from));

  const lines: string[] = [];
  lines.push("=".repeat(72));
  lines.push("COMPREHENSIVE TOKEN FLOW TRACE REPORT");
  lines.push("Alpha Unlimited Trading — Forensic Intelligence Division");
  lines.push(`Case: @sillytuna ~$26M Theft`);
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push("=".repeat(72));
  lines.push("");
  lines.push("This report traces ALL token transfers from the Person of Interest (POI)");
  lines.push("and fund destination wallets. When the attacker used stolen ETH to purchase");
  lines.push("tokens, we track where those tokens were sent, if they were converted, and");
  lines.push("if any were deposited to exchanges for liquidation.");
  lines.push("");

  lines.push("-".repeat(72));
  lines.push("SUMMARY");
  lines.push("-".repeat(72));
  lines.push(`Total token transfers scanned: ${allFlows.length}`);
  lines.push(`Outgoing transfers from attacker wallets: ${outgoing.length}`);
  lines.push(`Unique tokens moved: ${uniqueTokens.length} (${uniqueTokens.join(", ")})`);
  lines.push(`Returns to victim wallet: ${returns.length}`);
  lines.push(`Exchange deposits (potential liquidation): ${exchanges.length}`);
  lines.push(`New recipient wallets discovered & under surveillance: ${tokenRecipients.length}`);
  lines.push(`Total wallets monitored: ${wallets.length}`);
  lines.push("");

  if (returns.length > 0) {
    lines.push("=".repeat(72));
    lines.push("*** TOKENS RETURNED TO VICTIM ***");
    lines.push("=".repeat(72));
    for (const r of returns) {
      lines.push(`${r.time} | ${r.amount.toFixed(6)} ${r.token} from ${r.fromLabel}`);
      lines.push(`  Tx: https://etherscan.io/tx/${r.txHash}`);
    }
    lines.push("");
  } else {
    lines.push("*** NO TOKEN RETURNS TO VICTIM DETECTED YET ***");
    lines.push("We are continuously monitoring for any returns. You will be notified immediately.");
    lines.push("");
  }

  if (exchanges.length > 0) {
    lines.push("-".repeat(72));
    lines.push("EXCHANGE DEPOSITS (Possible Liquidation Points)");
    lines.push("-".repeat(72));
    for (const e of exchanges) {
      lines.push(`${e.time} | ${e.amount.toFixed(6)} ${e.token} → ${e.exchName}`);
      lines.push(`  From: ${e.fromLabel}`);
      lines.push(`  Tx: https://etherscan.io/tx/${e.txHash}`);
    }
    lines.push("");
  }

  lines.push("-".repeat(72));
  lines.push("TOKEN TRANSFER DETAILS BY TOKEN");
  lines.push("-".repeat(72));
  for (const token of uniqueTokens) {
    const tf = allFlows.filter(f => f.token === token);
    const totalMoved = tf.reduce((s, f) => s + f.amount, 0);
    const returnAmt = tf.filter(f => f.isReturn).reduce((s, f) => s + f.amount, 0);
    lines.push(`${token}: ${tf.length} transfers | Total moved: ${totalMoved.toFixed(4)} | Returned: ${returnAmt.toFixed(4)}`);
  }
  lines.push("");

  lines.push("-".repeat(72));
  lines.push("POI TOKEN HOLDINGS (Current)");
  lines.push("-".repeat(72));
  const poi = wallets.find(w => w.label?.includes("Person of Interest"));
  if (poi && poi.lastKnownTokens) {
    const tokens = poi.lastKnownTokens as Record<string, number>;
    for (const [sym, val] of Object.entries(tokens)) {
      if (val > 0.01) lines.push(`  ${val.toFixed(4)} ${sym}`);
    }
  }
  lines.push(`  Native balance: ${poi?.lastKnownBalanceEth?.toFixed?.(6) || "0"} ETH`);
  lines.push("");

  if (tokenRecipients.length > 0) {
    lines.push("-".repeat(72));
    lines.push(`DISCOVERED TOKEN RECIPIENT WALLETS (${tokenRecipients.length})`);
    lines.push("-".repeat(72));
    lines.push("These wallets received tokens from attacker-controlled wallets.");
    lines.push("All are now under 24/7 surveillance.");
    lines.push("");
    for (const tw of tokenRecipients) {
      const tStr = tw.lastKnownTokens && typeof tw.lastKnownTokens === "object"
        ? Object.entries(tw.lastKnownTokens as Record<string, number>)
            .filter(([, v]) => v > 0.01)
            .map(([s, v]) => `${v.toFixed(2)} ${s}`)
            .join(", ")
        : "";
      lines.push(`${tw.address} (${tw.chain})`);
      lines.push(`  ${tw.label || "Token Recipient"}`);
      if (tStr) lines.push(`  Current tokens: ${tStr}`);
      lines.push(`  ETH: ${(typeof tw.lastKnownBalanceEth === 'number' ? tw.lastKnownBalanceEth : parseFloat(String(tw.lastKnownBalanceEth || "0"))).toFixed(6)}`);
      lines.push("");
    }
  }

  lines.push("-".repeat(72));
  lines.push("ALL OUTGOING TOKEN TRANSFERS (CHRONOLOGICAL)");
  lines.push("-".repeat(72));
  for (const f of outgoing) {
    const flag = f.isReturn ? " *** RETURNED TO VICTIM ***" : f.isExchange ? ` → ${f.exchName}` : "";
    lines.push(`${f.time} | ${f.fromLabel.slice(0, 30)} → ${f.toLabel.slice(0, 30)} | ${f.amount.toFixed(6)} ${f.token}${flag}`);
  }
  lines.push("");

  lines.push("-".repeat(72));
  lines.push("ONGOING MONITORING");
  lines.push("-".repeat(72));
  lines.push(`We are tracking ${wallets.length} wallets 24/7 including:`);
  lines.push(`  - All original attacker/POI wallets`);
  lines.push(`  - All fund destination wallets`);
  lines.push(`  - ${tokenRecipients.length} newly discovered token recipient wallets`);
  lines.push(`  - Your victim wallet (for returns)`);
  lines.push("");
  lines.push("In real-time (core wallets every 15s) we check for:");
  lines.push("  - Balance changes (ETH and all tokens)");
  lines.push("  - New outgoing token transfers");
  lines.push("  - Token conversions and swaps");
  lines.push("  - Exchange deposits (liquidation attempts)");
  lines.push("  - Any funds returned to your wallet");
  lines.push("");
  lines.push("You will receive hourly email updates with any new activity.");
  lines.push("Critical events (fund returns, large movements) trigger immediate alerts.");
  lines.push("");
  lines.push("Alpha Unlimited Trading Company");
  lines.push("Forensic Intelligence Division");
  lines.push(new Date().toISOString());
  lines.push("=".repeat(72));

  const reportBody = lines.join("\n");

  const dir = "private/forensic-exports";
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "TOKEN-FLOW-EMAIL-REPORT.txt"), reportBody);
  console.log(`\nReport saved: ${reportBody.length} chars`);

  const sgKey = process.env.SENDGRID_API_KEY;
  if (!sgKey) {
    console.log("No SENDGRID_API_KEY — cannot send email");
    process.exit(1);
  }

  const subject = `TOKEN FLOW TRACE REPORT — ${allFlows.length} transfers traced, ${tokenRecipients.length} new wallets discovered — ${new Date().toISOString().split("T")[0]}`;

  const emailBody = {
    personalizations: [{ to: [{ email: RECIPIENT_EMAIL, name: RECIPIENT_NAME }] }],
    from: { email: "forensics@alphaunlimitedtrading.com", name: "Alpha Unlimited Trading — Forensic Intelligence" },
    subject,
    content: [{ type: "text/plain", value: reportBody }]
  };

  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: { "Authorization": `Bearer ${sgKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(emailBody)
  });

  if (res.ok || res.status === 202) {
    console.log(`\nEmail sent to ${RECIPIENT_EMAIL}!`);

    await db.insert(forensicAlerts).values({
      caseId: CASE_ID,
      alertType: "token_flow_report_sent",
      severity: "info",
      message: `Token flow trace report emailed to ${RECIPIENT_EMAIL}: ${allFlows.length} transfers, ${uniqueTokens.length} tokens, ${tokenRecipients.length} recipient wallets, ${returns.length} returns`,
      walletAddress: "system",
      details: { recipient: RECIPIENT_EMAIL, transfers: allFlows.length, tokens: uniqueTokens.length, recipients: tokenRecipients.length, returns: returns.length }
    });
  } else {
    const err = await res.text();
    console.error(`Send failed (${res.status}): ${err}`);
  }

  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
