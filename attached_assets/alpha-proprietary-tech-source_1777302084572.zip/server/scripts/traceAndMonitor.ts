import { db } from "../db.js";
import { eq, and } from "drizzle-orm";
import { monitoredWallets, forensicAlerts, forensicCases } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const VICTIM_WALLET = "0x6fe0fab2164d8e0d03ad6a628e2af78624060322";

const BLOCKSCOUT: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
};

async function getOutgoingTxs(address: string, chain: string): Promise<any[]> {
  const api = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  try {
    const res = await fetch(`${api}/addresses/${address.toLowerCase()}/transactions?filter=from`, {
      headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) { console.log(`  [API ${res.status}] ${address.slice(0,10)}`); return []; }
    const data = await res.json();
    return data.items || [];
  } catch (e: any) {
    console.log(`  [Error] ${address.slice(0,10)}: ${e.message}`);
    return [];
  }
}

async function getOutgoingTokenTransfers(address: string, chain: string): Promise<any[]> {
  const api = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  try {
    const res = await fetch(`${api}/addresses/${address.toLowerCase()}/token-transfers?filter=from`, {
      headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch {
    return [];
  }
}

async function getInternalTxs(address: string, chain: string): Promise<any[]> {
  const api = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  try {
    const res = await fetch(`${api}/addresses/${address.toLowerCase()}/internal-transactions?filter=from`, {
      headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch {
    return [];
  }
}

async function main() {
  console.log("=".repeat(72));
  console.log("ALPHA FORENSIC INTELLIGENCE ENGINE™ — DEEP FUND TRACING");
  console.log(`Case: @sillytuna $24M Theft`);
  console.log(`Victim: ${VICTIM_WALLET}`);
  console.log(`Data Source: Blockscout API (Ethereum + Arbitrum)`);
  console.log(`Timestamp: ${new Date().toISOString()}`);
  console.log("=".repeat(72));
  console.log("");

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const knownAddresses = new Set(wallets.map(w => w.address.toLowerCase()));

  const traceTargets = wallets.filter(w => {
    const r = (w.role || "").toLowerCase();
    return r.includes("poi") || r.includes("split") || r.includes("source") || r.includes("laundering") ||
      r.includes("gas funder") || r.includes("original funder") || r.includes("dai recipient") ||
      r.includes("arb receiver") || r.includes("final destination");
  });

  console.log(`Tracing outgoing transactions from ${traceTargets.length} wallets via Blockscout...`);
  console.log("");

  type DestInfo = { sources: Set<string>; chain: string; totalEthWei: bigint; tokens: Map<string, number>; txCount: number; firstSeen: string; lastSeen: string };
  const destMap = new Map<string, DestInfo>();

  function addDest(dest: string, source: string, chain: string, weiStr: string, tokenSym: string | null, tokenVal: number, timestamp: string) {
    const key = dest.toLowerCase();
    if (key === source.toLowerCase()) return;
    if (!destMap.has(key)) {
      destMap.set(key, { sources: new Set(), chain, totalEthWei: 0n, tokens: new Map(), txCount: 0, firstSeen: "", lastSeen: "" });
    }
    const e = destMap.get(key)!;
    e.sources.add(source.slice(0, 10));
    try { e.totalEthWei += BigInt(weiStr || "0"); } catch {}
    e.txCount++;
    if (!e.firstSeen || timestamp < e.firstSeen) e.firstSeen = timestamp;
    if (!e.lastSeen || timestamp > e.lastSeen) e.lastSeen = timestamp;
    if (tokenSym && tokenVal > 0) e.tokens.set(tokenSym, (e.tokens.get(tokenSym) || 0) + tokenVal);
  }

  for (const w of traceTargets) {
    const chain = w.chain || "ethereum";
    console.log(`--- ${w.label || w.role} (${w.address.slice(0, 14)}...) [${chain}] ---`);

    const normalTxs = await getOutgoingTxs(w.address, chain);
    await new Promise(r => setTimeout(r, 300));
    const tokenTxs = await getOutgoingTokenTransfers(w.address, chain);
    await new Promise(r => setTimeout(r, 300));
    const internalTxs = await getInternalTxs(w.address, chain);
    await new Promise(r => setTimeout(r, 300));

    console.log(`  Normal: ${normalTxs.length} | Tokens: ${tokenTxs.length} | Internal: ${internalTxs.length}`);

    for (const tx of normalTxs) {
      const to = tx.to?.hash || tx.to;
      if (!to) continue;
      addDest(to, w.address, chain, tx.value || "0", null, 0, tx.timestamp || tx.block?.timestamp || "");
    }

    for (const tx of tokenTxs) {
      const to = tx.to?.hash || tx.to;
      if (!to) continue;
      const decimals = parseInt(tx.token?.decimals || "18");
      const rawVal = tx.total?.value || tx.value || "0";
      const val = parseFloat(rawVal) / Math.pow(10, decimals);
      const sym = tx.token?.symbol || "?";
      addDest(to, w.address, chain, "0", sym, val, tx.timestamp || "");
    }

    for (const tx of internalTxs) {
      const to = tx.to?.hash || tx.to;
      if (!to) continue;
      addDest(to, w.address, chain, tx.value || "0", null, 0, tx.timestamp || "");
    }
  }

  const sorted = [...destMap.entries()]
    .map(([addr, info]) => ({ addr, ...info, ethVal: Number(info.totalEthWei) / 1e18, isKnown: knownAddresses.has(addr), isVictim: addr === VICTIM_WALLET.toLowerCase() }))
    .filter(d => d.ethVal > 0.0001 || d.tokens.size > 0)
    .sort((a, b) => b.ethVal - a.ethVal || b.txCount - a.txCount);

  console.log("");
  console.log("=".repeat(72));
  console.log(`FUND DESTINATIONS — ${sorted.length} significant addresses received stolen funds`);
  console.log("=".repeat(72));
  console.log("");

  for (const d of sorted) {
    const tag = d.isVictim ? " *** VICTIM WALLET ***" : d.isKnown ? " (already monitored)" : " [NEW — UNKNOWN DESTINATION]";
    console.log(`  ${d.addr}${tag}`);
    console.log(`    Chain: ${d.chain} | Txs: ${d.txCount} | Sources: ${[...d.sources].join(", ")}`);
    if (d.ethVal > 0) console.log(`    ETH: ${d.ethVal.toFixed(6)}`);
    if (d.tokens.size > 0) console.log(`    Tokens: ${[...d.tokens.entries()].map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ")}`);
    if (d.firstSeen) console.log(`    Period: ${d.firstSeen.split("T")[0]} → ${d.lastSeen.split("T")[0]}`);
    console.log("");
  }

  // Check for returns
  console.log("=".repeat(72));
  console.log("CHECKING FOR FUNDS RETURNED TO VICTIM...");
  console.log("=".repeat(72));
  console.log("");

  let returnFound = false;
  try {
    const res = await fetch(`${BLOCKSCOUT.ethereum}/addresses/${VICTIM_WALLET.toLowerCase()}/transactions?filter=to`, {
      headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(15000)
    });
    if (res.ok) {
      const data = await res.json();
      const allTracked = new Set([...knownAddresses, ...destMap.keys()]);
      for (const tx of (data.items || [])) {
        const sender = (tx.from?.hash || "").toLowerCase();
        if (allTracked.has(sender)) {
          const ethVal = tx.value ? parseFloat(tx.value) / 1e18 : 0;
          if (ethVal > 0.0001) {
            console.log(`  *** RETURN DETECTED ***`);
            console.log(`  From: ${sender} | Amount: ${ethVal.toFixed(6)} ETH | Tx: ${tx.hash}`);
            console.log(`  Date: ${tx.timestamp || "?"}`);
            console.log("");
            returnFound = true;
          }
        }
      }
    }
  } catch {}

  try {
    const res2 = await fetch(`${BLOCKSCOUT.ethereum}/addresses/${VICTIM_WALLET.toLowerCase()}/token-transfers?filter=to`, {
      headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(15000)
    });
    if (res2.ok) {
      const data2 = await res2.json();
      const allTracked = new Set([...knownAddresses, ...destMap.keys()]);
      for (const tt of (data2.items || [])) {
        const sender = (tt.from?.hash || "").toLowerCase();
        if (allTracked.has(sender)) {
          const decimals = parseInt(tt.token?.decimals || "18");
          const val = tt.total?.value ? parseFloat(tt.total.value) / Math.pow(10, decimals) : 0;
          if (val > 0.01) {
            console.log(`  *** TOKEN RETURN DETECTED ***`);
            console.log(`  From: ${sender} | Amount: ${val.toFixed(2)} ${tt.token?.symbol || "?"} | Tx: ${tt.transaction_hash}`);
            returnFound = true;
          }
        }
      }
    }
  } catch {}

  if (!returnFound) {
    console.log("  No funds have been returned to the victim wallet yet.");
    console.log("");
  }

  // Add new destinations
  const newDests = sorted.filter(d => !d.isKnown && !d.isVictim);
  let addedCount = 0;
  if (newDests.length > 0) {
    console.log(`Adding ${Math.min(newDests.length, 30)} new destinations to active monitoring...`);
    for (const d of newDests.slice(0, 30)) {
      const exists = await db.select().from(monitoredWallets).where(
        and(eq(monitoredWallets.caseId, CASE_ID), eq(monitoredWallets.address, d.addr))
      ).limit(1);
      if (exists.length === 0) {
        const tokenDesc = d.tokens.size > 0 ? [...d.tokens.entries()].map(([s, v]) => `${v.toFixed(0)} ${s}`).join("/") : "";
        const ethDesc = d.ethVal > 0 ? `${d.ethVal.toFixed(4)} ETH` : "";
        await db.insert(monitoredWallets).values({
          caseId: CASE_ID,
          address: d.addr,
          chain: d.chain,
          role: "Destination",
          label: `Fund Destination (${[ethDesc, tokenDesc].filter(Boolean).join(" + ")} via ${[...d.sources].join(",")})`,
          status: "monitoring",
          addedBy: "deep-trace",
        });
        addedCount++;
        console.log(`  + ${d.addr} [${d.chain}]`);
      }
    }
    console.log(`  ${addedCount} new wallets now under active surveillance.`);
  }

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "deep_trace_complete",
    severity: "high",
    message: `Deep fund trace via Blockscout: ${sorted.length} destinations from ${traceTargets.length} wallets. ${addedCount} new wallets added to surveillance. Returns: ${returnFound ? "YES" : "NONE"}`,
    walletAddress: "system",
    details: { totalDestinations: sorted.length, newAdded: addedCount, returnDetected: returnFound, tracedAt: new Date().toISOString() }
  });

  console.log("");
  console.log("=".repeat(72));
  console.log("DEEP TRACE COMPLETE");
  console.log(`Total destinations: ${sorted.length}`);
  console.log(`New wallets added: ${addedCount}`);
  console.log(`Returns to victim: ${returnFound ? "YES" : "NONE"}`);
  console.log("Live monitoring active — you'll be alerted immediately on any returns.");
  console.log("=".repeat(72));
  process.exit(0);
}

main().catch(e => { console.error("[Trace] FATAL:", e); process.exit(1); });
