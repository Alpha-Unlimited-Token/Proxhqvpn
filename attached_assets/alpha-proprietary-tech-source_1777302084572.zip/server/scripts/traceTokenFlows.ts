import { db } from "../db.js";
import { eq, sql } from "drizzle-orm";
import { monitoredWallets, forensicAlerts } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const VICTIM = "0x6fe0fab216e0f4d70b4a2f9de57420b57e2ef4f3";
const BLOCKSCOUT: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2"
};

const KNOWN_EXCHANGES: Record<string, string> = {
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io 1",
  "0x28c6c06298d514db089934071d89d3dece0c3b2d": "Binance 14",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 15",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 36",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance 16",
  "0x9696f59e4d72e237be84ffd425dcad154bf96976": "Binance US",
  "0x503828976d22510aad0339f13e7b8b8f3b5f1e1c": "Coinbase",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase 3",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase 10",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken 4",
  "0xae2d4617c862309a3d75a0ffb358c7a5009c673f": "Kraken 10",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
  "0x98c3d3183c4b8a650614ad179a1a98be0a8d6b8e": "OKX 2",
  "0x3cd751e6b0078be393132286c442345e5dc49699": "Crypto.com",
  "0x46340b20830761efd32832a74d7169b29feb9758": "Crypto.com 2",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
  "0xa7efae728d2936e78bda97dc267687568dd593f3": "OKX 3"
};

const KNOWN_PROTOCOLS: Set<string> = new Set([
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41",
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae",
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f",
  "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
  "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
  "0x6b175474e89094c44da98b954eedeac495271d0f",
  "0xdac17f958d2ee523a2206206994597c13d831ec7",
  "0x7a250d5630b4cf539739df2c5dacb4c659f2488d",
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45",
  "0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad",
  "0x000000000022d473030f116ddee9f6b43ac78ba3"
]);

async function apiFetch(url: string): Promise<any> {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

interface TokenFlow {
  fromAddr: string;
  fromLabel: string;
  toAddr: string;
  toLabel: string;
  tokenSymbol: string;
  tokenName: string;
  amount: number;
  usdValue: number;
  txHash: string;
  timestamp: string;
  chain: string;
  blockNumber: number;
  isReturnToVictim: boolean;
  isExchangeDeposit: boolean;
  exchangeName: string;
}

interface DiscoveredWallet {
  address: string;
  chain: string;
  discoveredVia: string;
  tokens: Record<string, number>;
  ethBalance: number;
  firstSeen: string;
  role: string;
}

async function traceTokenTransfers(address: string, chain: string, label: string): Promise<{ flows: TokenFlow[], newAddresses: Set<string> }> {
  const base = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  const addr = address.toLowerCase();
  const flows: TokenFlow[] = [];
  const newAddresses = new Set<string>();

  let nextParams: any = null;
  let page = 0;
  const MAX_PAGES = 5;

  do {
    let url = `${base}/addresses/${addr}/token-transfers`;
    if (nextParams) {
      const qs = new URLSearchParams(nextParams).toString();
      url += `?${qs}`;
    }
    const data = await apiFetch(url);
    await new Promise(r => setTimeout(r, 150));
    if (!data?.items) break;

    for (const tx of data.items) {
      const from = (tx.from?.hash || "").toLowerCase();
      const to = (tx.to?.hash || "").toLowerCase();
      const symbol = tx.token?.symbol || "???";
      const name = tx.token?.name || symbol;
      const decimals = parseInt(tx.token?.decimals || "18");
      const amount = parseFloat(tx.total?.value || "0") / Math.pow(10, decimals);

      if (amount < 0.001) continue;

      const isOutgoing = from === addr;
      const isIncoming = to === addr;

      const destAddr = isOutgoing ? to : from;
      const isVictimReturn = destAddr === VICTIM.toLowerCase() || to === VICTIM.toLowerCase();
      const isExchange = !!KNOWN_EXCHANGES[destAddr];
      const exchangeName = KNOWN_EXCHANGES[destAddr] || "";

      if (isOutgoing && destAddr && !KNOWN_PROTOCOLS.has(destAddr)) {
        newAddresses.add(destAddr);
      }

      flows.push({
        fromAddr: from,
        fromLabel: isOutgoing ? label : (KNOWN_EXCHANGES[from] || from.slice(0, 14)),
        toAddr: to,
        toLabel: isOutgoing ? (KNOWN_EXCHANGES[to] || to.slice(0, 14)) : label,
        tokenSymbol: symbol,
        tokenName: name,
        amount,
        usdValue: 0,
        txHash: tx.transaction_hash || tx.hash || "",
        timestamp: tx.timestamp || "",
        chain,
        blockNumber: parseInt(tx.block_number || tx.block || "0"),
        isReturnToVictim: isVictimReturn,
        isExchangeDeposit: isExchange && isOutgoing,
        exchangeName
      });
    }

    nextParams = data.next_page_params || null;
    page++;
  } while (nextParams && page < MAX_PAGES);

  return { flows, newAddresses };
}

async function getWalletTokens(address: string, chain: string): Promise<Record<string, number>> {
  const base = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  const addr = address.toLowerCase();
  const tokens: Record<string, number> = {};
  const data = await apiFetch(`${base}/addresses/${addr}/token-balances`);
  await new Promise(r => setTimeout(r, 100));
  if (Array.isArray(data)) {
    for (const t of data) {
      const sym = t.token?.symbol || "?";
      const dec = parseInt(t.token?.decimals || "18");
      const val = parseFloat(t.value || "0") / Math.pow(10, dec);
      if (val > 0.001) tokens[sym] = val;
    }
  }
  return tokens;
}

async function getWalletBalance(address: string, chain: string): Promise<number> {
  const base = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  const addr = address.toLowerCase();
  const data = await apiFetch(`${base}/addresses/${addr}`);
  await new Promise(r => setTimeout(r, 100));
  if (data?.coin_balance) return parseInt(data.coin_balance) / 1e18;
  return 0;
}

async function main() {
  const startTime = Date.now();
  const dir = path.resolve("private/forensic-exports");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  console.log("=== COMPREHENSIVE TOKEN FLOW TRACER ===");
  console.log("Case: @sillytuna ~$26M Theft");
  console.log("Tracing ALL token movements from POI and destination wallets\n");

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  console.log(`Loaded ${wallets.length} monitored wallets\n`);

  const allPriority = wallets.filter(w =>
    w.label?.includes("Person of Interest") ||
    w.role === "poi" ||
    w.label?.includes("Fund Destination") ||
    w.role?.includes("destination") ||
    w.label?.includes("Source") ||
    w.label?.includes("Laundering") ||
    w.label?.includes("Split")
  );
  const batch = parseInt(process.env.TRACE_BATCH || "0");
  const BATCH_SIZE = 8;
  const priorityWallets = allPriority.slice(batch * BATCH_SIZE, (batch + 1) * BATCH_SIZE);
  console.log(`Batch ${batch}: Tracing wallets ${batch * BATCH_SIZE + 1}-${batch * BATCH_SIZE + priorityWallets.length} of ${allPriority.length}\n`);

  const allFlows: TokenFlow[] = [];
  const allDiscovered = new Map<string, DiscoveredWallet>();
  const existingAddresses = new Set(wallets.map(w => w.address.toLowerCase()));
  let walletsTraced = 0;

  for (const w of priorityWallets) {
    if (Date.now() - startTime > 95000) {
      console.log(`\nTIME LIMIT — traced ${walletsTraced}/${priorityWallets.length} wallets`);
      break;
    }

    const chain = w.chain || "ethereum";
    console.log(`[${walletsTraced + 1}/${priorityWallets.length}] ${(w.label || w.address).slice(0, 50)} (${chain})`);

    const { flows, newAddresses } = await traceTokenTransfers(w.address, chain, w.label || w.address.slice(0, 14));

    const outgoing = flows.filter(f => f.fromAddr === w.address.toLowerCase());
    const returns = flows.filter(f => f.isReturnToVictim);
    const exchanges = flows.filter(f => f.isExchangeDeposit);

    console.log(`  → ${flows.length} token transfers (${outgoing.length} outgoing, ${returns.length} victim returns, ${exchanges.length} exchange deposits)`);
    if (returns.length > 0) {
      for (const r of returns) {
        console.log(`  *** VICTIM RETURN: ${r.amount.toFixed(4)} ${r.tokenSymbol} ***`);
      }
    }
    if (exchanges.length > 0) {
      for (const e of exchanges) {
        console.log(`  → EXCHANGE: ${e.amount.toFixed(4)} ${e.tokenSymbol} → ${e.exchangeName}`);
      }
    }

    allFlows.push(...flows);

    for (const newAddr of newAddresses) {
      if (!existingAddresses.has(newAddr) && !allDiscovered.has(newAddr)) {
        const tokens = await getWalletTokens(newAddr, chain);
        const eth = await getWalletBalance(newAddr, chain);
        if (Object.keys(tokens).length > 0 || eth > 0.01) {
          allDiscovered.set(newAddr, {
            address: newAddr,
            chain,
            discoveredVia: `Token transfer from ${w.label || w.address.slice(0, 14)}`,
            tokens,
            ethBalance: eth,
            firstSeen: flows.find(f => f.toAddr === newAddr)?.timestamp || "",
            role: KNOWN_EXCHANGES[newAddr] ? "exchange" : "token_recipient"
          });
          console.log(`  NEW: ${newAddr.slice(0, 14)} | ${eth.toFixed(4)} ETH | ${Object.keys(tokens).length} tokens`);
        }
      }
    }

    walletsTraced++;
  }

  const uniqueTokens = new Set(allFlows.map(f => f.tokenSymbol));
  const victimReturns = allFlows.filter(f => f.isReturnToVictim);
  const exchangeDeposits = allFlows.filter(f => f.isExchangeDeposit);

  const report: string[] = [];
  report.push("=" .repeat(80));
  report.push("COMPREHENSIVE TOKEN FLOW TRACE — @sillytuna Case");
  report.push(`Generated: ${new Date().toISOString()}`);
  report.push(`Wallets Traced: ${walletsTraced} | Total Token Transfers: ${allFlows.length}`);
  report.push(`Unique Tokens: ${uniqueTokens.size} | New Wallets Discovered: ${allDiscovered.size}`);
  report.push(`Victim Returns: ${victimReturns.length} | Exchange Deposits: ${exchangeDeposits.length}`);
  report.push("=" .repeat(80));
  report.push("");

  if (victimReturns.length > 0) {
    report.push("*** TOKEN RETURNS TO VICTIM ***");
    report.push("-".repeat(80));
    for (const r of victimReturns) {
      report.push(`${r.timestamp} | ${r.amount.toFixed(6)} ${r.tokenSymbol} from ${r.fromLabel}`);
      report.push(`  Tx: ${r.txHash}`);
    }
    report.push("");
  }

  if (exchangeDeposits.length > 0) {
    report.push("*** EXCHANGE DEPOSITS (POTENTIAL LIQUIDATION) ***");
    report.push("-".repeat(80));
    for (const e of exchangeDeposits) {
      report.push(`${e.timestamp} | ${e.amount.toFixed(6)} ${e.tokenSymbol} → ${e.exchangeName}`);
      report.push(`  From: ${e.fromLabel} | Tx: ${e.txHash}`);
    }
    report.push("");
  }

  report.push("TOKEN FLOW SUMMARY BY TOKEN");
  report.push("-".repeat(80));
  for (const token of uniqueTokens) {
    const tokenFlows = allFlows.filter(f => f.tokenSymbol === token);
    const totalOut = tokenFlows.filter(f => !f.isReturnToVictim).reduce((s, f) => s + f.amount, 0);
    const totalReturn = tokenFlows.filter(f => f.isReturnToVictim).reduce((s, f) => s + f.amount, 0);
    report.push(`${token}: ${tokenFlows.length} transfers | Total moved: ${totalOut.toFixed(4)} | Returned to victim: ${totalReturn.toFixed(4)}`);
  }
  report.push("");

  report.push("ALL TOKEN TRANSFERS (CHRONOLOGICAL)");
  report.push("-".repeat(80));
  const sorted = [...allFlows].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  for (const f of sorted) {
    const flag = f.isReturnToVictim ? " *** RETURN ***" : f.isExchangeDeposit ? ` → ${f.exchangeName}` : "";
    report.push(`${f.timestamp} | ${f.fromLabel.slice(0, 20)} → ${f.toLabel.slice(0, 20)} | ${f.amount.toFixed(6)} ${f.tokenSymbol} | ${f.chain}${flag}`);
  }
  report.push("");

  if (allDiscovered.size > 0) {
    report.push("NEWLY DISCOVERED WALLETS");
    report.push("-".repeat(80));
    for (const [addr, w] of allDiscovered) {
      report.push(`${addr} (${w.chain}) — ${w.role}`);
      report.push(`  Discovered via: ${w.discoveredVia}`);
      report.push(`  Balance: ${w.ethBalance.toFixed(6)} ETH`);
      report.push(`  Tokens: ${Object.entries(w.tokens).map(([s, v]) => `${v.toFixed(4)} ${s}`).join(", ")}`);
      report.push(`  First seen: ${w.firstSeen}`);
      report.push("");
    }
  }

  const reportPath = path.join(dir, "TOKEN-FLOW-TRACE.txt");
  fs.writeFileSync(reportPath, report.join("\n"));

  const flowsCsv = ["Timestamp,Chain,From,FromLabel,To,ToLabel,Token,Amount,TxHash,IsReturn,IsExchange,ExchangeName"];
  for (const f of sorted) {
    flowsCsv.push([f.timestamp, f.chain, f.fromAddr, `"${f.fromLabel}"`, f.toAddr, `"${f.toLabel}"`, f.tokenSymbol, f.amount.toFixed(8), f.txHash, f.isReturnToVictim, f.isExchangeDeposit, `"${f.exchangeName}"`].join(","));
  }
  fs.writeFileSync(path.join(dir, "TOKEN-TRANSFERS.csv"), flowsCsv.join("\n"));

  const discoveredJson = Array.from(allDiscovered.values());
  fs.writeFileSync(path.join(dir, "TOKEN-RECIPIENT-WALLETS.json"), JSON.stringify(discoveredJson, null, 2));

  let addedCount = 0;
  for (const [addr, w] of allDiscovered) {
    if (w.role === "exchange") continue;
    try {
      const existing = await db.select().from(monitoredWallets)
        .where(eq(monitoredWallets.address, addr))
        .limit(1);
      if (existing.length === 0) {
        const tokenStr = Object.entries(w.tokens).map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ").slice(0, 80);
        await db.insert(monitoredWallets).values({
          caseId: CASE_ID,
          address: addr,
          chain: w.chain,
          label: `Token Recipient (${tokenStr || w.discoveredVia.slice(0, 40)})`,
          role: "token_recipient",
          status: "active",
          lastKnownBalanceEth: w.ethBalance.toString(),
          lastKnownTokens: w.tokens,
          alertConfig: { balanceChange: true, largeTransfer: true, newTokens: true }
        });
        addedCount++;
      }
    } catch (e: any) {
      console.log(`  Could not add ${addr.slice(0, 14)}: ${e.message}`);
    }
  }

  if (victimReturns.length > 0 || exchangeDeposits.length > 0) {
    try {
      await db.insert(forensicAlerts).values({
        caseId: CASE_ID,
        alertType: "token_flow_trace_complete",
        severity: victimReturns.length > 0 ? "critical" : "high",
        message: `Token flow trace complete: ${allFlows.length} transfers across ${uniqueTokens.size} tokens. ${victimReturns.length} returns to victim. ${exchangeDeposits.length} exchange deposits. ${allDiscovered.size} new wallets discovered (${addedCount} added to monitoring).`,
        walletAddress: "system",
        details: {
          totalTransfers: allFlows.length,
          uniqueTokens: uniqueTokens.size,
          victimReturns: victimReturns.length,
          exchangeDeposits: exchangeDeposits.length,
          newWallets: allDiscovered.size,
          addedToMonitoring: addedCount
        }
      });
    } catch {}
  }

  console.log(`\n=== TRACE COMPLETE ===`);
  console.log(`Wallets traced: ${walletsTraced}`);
  console.log(`Total token transfers: ${allFlows.length}`);
  console.log(`Unique tokens: ${uniqueTokens.size}`);
  console.log(`Victim returns: ${victimReturns.length}`);
  console.log(`Exchange deposits: ${exchangeDeposits.length}`);
  console.log(`New wallets discovered: ${allDiscovered.size}`);
  console.log(`Added to monitoring: ${addedCount}`);
  console.log(`\nFiles written:`);
  for (const f of ["TOKEN-FLOW-TRACE.txt", "TOKEN-TRANSFERS.csv", "TOKEN-RECIPIENT-WALLETS.json"]) {
    const fp = path.join(dir, f);
    if (fs.existsSync(fp)) console.log(`  ${f} — ${(fs.statSync(fp).size / 1024).toFixed(1)} KB`);
  }

  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
