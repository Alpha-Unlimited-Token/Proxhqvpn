/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_SWEEP2_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_Sweep2_Calibration_PROTECTED
 */

import * as fs from "fs";
import { db } from "../db.js";
import { monitoredWallets } from "@shared/schema";
import { eq } from "drizzle-orm";

const BE = "https://eth.blockscout.com/api/v2";
const ARB = "https://arbitrum.blockscout.com/api/v2";
const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

const KNOWN_EXCHANGES: Record<string, string> = {
  "0x46340b20830761efd32832a74d7169b29feb9758": "Crypto.com Hot Wallet 2",
  "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com Main",
  "0xcffad3200574698b78f32232aa9d63eabd290703": "Crypto.com Hot 3",
  "0x72a53cdbbcc1b9efa39c834a540550e23463aacb": "Crypto.com Exchange",
  "0x7758e507850da48cd47df1fb5f875c23e3340c50": "Crypto.com",
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 2",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 3",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance 4",
  "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance 8",
  "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance 7",
  "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": "Binance 1",
  "0xd551234ae421e3bcba99a0da6d736074f22192ff": "Binance 6",
  "0x564286362092d8e7936f0549571a803b203aaced": "Binance 5",
  "0x4e9ce36e442e55ecd9025b9a6e0d88485d628a67": "Binance 15",
  "0x8894e0a0c962cb723c1ef8a1b6fcd0d2b756f896": "Binance 16",
  "0xa7efae728d2936e78bda97dc267687568dd593f3": "OKX",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX 2",
  "0x98ec059dc3adfbdd63429227d09cb015b78fc709": "OKX 3",
  "0x236f9f97e0e62388479bf9e5ba4889e46b0273c3": "OKX 4",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase 1",
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase 2",
  "0x3cd751e6b0078be393132286c442345e5dc49699": "Coinbase 4",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase 10",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase 3",
  "0xf6874c88757721a02f47592140905c4e66a36945": "Coinbase 8",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken",
  "0x53d284357ec70ce289d6d64134dfac8e511c8a3d": "Kraken 4",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken 6",
  "0xae2d4617c862309a3d75a0ffb358c7a5009c673f": "Kraken 10",
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": "KuCoin",
  "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin 2",
  "0xf3f094484ec6901ffc9681bcb808b96bafd0b8a8": "KuCoin 3",
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io",
  "0xd793281b45ceebfc1b3bac8f16a003e8ba03c2dd": "Gate.io 2",
  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io 3",
  "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io 4",
  "0x1681195c176239ac5e72d9aebacf5b2492e0c4ee": "Bitfinex",
  "0x876eabf441b2ee5b5b0554fd502a8e0600950cfa": "Bitfinex 4",
  "0x742d35cc6634c0532925a3b844bc9e7595f2bd3e": "Bitfinex 2",
  "0xbf3aeb96e164ae67e763d9e050ff124e7c3fdd28": "Bitget",
  "0x5bdf85216ec1e38d6458c870992a69e38e03f7ef": "Bitget Hot",
  "0x2faf487a4414fe77e2327f0bf4ae2a264a776ad2": "FTX",
  "0xc098b2a3aa256d2140208c3de6543aaef5cd3a94": "FTX 2",
  "0xab5c66752a9e8167967685f1450532fb96d5d24f": "Huobi",
  "0x18709e89bd403f470088abdacebe86cc60dda12e": "Huobi 2",
  "0x6748f50f686bfbca6fe8ad62b22228b87f31ff2b": "Huobi 3",
  "0xe93381fb4c4f14bda253907b18fad305d799cee7": "Huobi 7",
  "0xeee27662c2b8eba3cd936a23f039f3189633e4c8": "Bybit",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit 2",
  "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": "MEXC",
  "0x0211f3cedbef3143223d3acf0e589747933e8527": "MEXC 2",
  "0xd24400ae8bfebb18ca49be86258a3c749cf46853": "Gemini",
  "0x6fc82a5fe25a5cdb58bc74600a40a69c065263f8": "Gemini 2",
  "0x07ee55aa48bb72dcc6e9d78256648910de513015": "Gemini 3",
  "0x00bdb5699745f5b860228c8f939abf1b9ae374ed": "Bitstamp",
  "0x1522900b6dafac587d499a862861c0869be6e428": "Bitstamp 2",
  "0x5e032243d507c743b061ef27c9169ae83fc6d5f1": "Upbit",
  "0xfbb1b73c4f0bda4f67dca266ce6ef42f520fbb98": "Bittrex",
  "0x32be343b94f860124dc4fee278fdcbd38c102d88": "Poloniex",
  "0x077d360f11d220e4d5d831430c81c26c9be7c4a4": "ChangeNOW",
  "0x4e5b2e1dc63f6b91cb6cd759936495434c7e972f": "FixedFloat",
};

function exchangeFromName(name: string): string | null {
  if (!name) return null;
  const lo = name.toLowerCase();
  for (const p of ["binance","coinbase","kraken","crypto.com","okx","huobi","htx","bybit",
    "kucoin","gate.io","bitfinex","bitget","mexc","gemini","bitstamp","upbit","bittrex",
    "poloniex","changenow","fixedfloat","ftx","nexo","celsius","revolut","robinhood"]) {
    if (lo.includes(p)) return name;
  }
  return null;
}

async function api(url: string): Promise<any> {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(10000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

interface Hit { wallet: string; label: string; role: string; dir: string; exchange: string; amount: string; token: string; ts: string; tx: string; chain: string; }

async function check(addr: string, label: string, role: string, chain: string): Promise<Hit[]> {
  const hits: Hit[] = [];
  const base = chain === "arbitrum" ? ARB : BE;
  const lo = addr.toLowerCase();

  // Token transfers — 1 page only (50 most recent)
  const tt = await api(`${base}/addresses/${lo}/token-transfers`);
  await sleep(100);
  if (tt?.items) {
    for (const t of tt.items) {
      const from = (t.from?.hash || "").toLowerCase();
      const to = (t.to?.hash || "").toLowerCase();
      let ex = KNOWN_EXCHANGES[to] || KNOWN_EXCHANGES[from] || exchangeFromName(t.to?.name) || exchangeFromName(t.from?.name) || "";
      if (!ex) continue;
      const dir = (KNOWN_EXCHANGES[to] || exchangeFromName(t.to?.name)) ? "DEPOSIT TO" : "FROM";
      const dec = parseInt(t.token?.decimals || "18");
      const amt = parseFloat(t.total?.value || "0") / Math.pow(10, dec);
      hits.push({ wallet: addr, label, role, dir, exchange: KNOWN_EXCHANGES[to] || KNOWN_EXCHANGES[from] || t.to?.name || t.from?.name || ex, amount: amt.toFixed(6), token: t.token?.symbol || "?", ts: t.timestamp || "", tx: t.transaction_hash || "", chain });
    }
  }

  // ETH txs — 1 page
  const txs = await api(`${base}/addresses/${lo}/transactions`);
  await sleep(100);
  if (txs?.items) {
    for (const t of txs.items) {
      const from = (t.from?.hash || "").toLowerCase();
      const to = (t.to?.hash || "").toLowerCase();
      let ex = KNOWN_EXCHANGES[to] || KNOWN_EXCHANGES[from] || exchangeFromName(t.to?.name) || exchangeFromName(t.from?.name) || "";
      if (!ex) continue;
      const dir = (KNOWN_EXCHANGES[to] || exchangeFromName(t.to?.name)) ? "ETH TO" : "ETH FROM";
      const val = parseInt(t.value || "0") / 1e18;
      hits.push({ wallet: addr, label, role, dir, exchange: KNOWN_EXCHANGES[to] || KNOWN_EXCHANGES[from] || t.to?.name || t.from?.name || ex, amount: val.toFixed(8), token: "ETH", ts: t.timestamp || "", tx: t.hash || "", chain });
    }
  }

  return hits;
}

async function main() {
  console.log(`\n═══ FULL EXCHANGE SWEEP — ${new Date().toISOString()} ═══\n`);

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE));
  const important = wallets.filter(w => (w.role || "").toLowerCase() !== "token_recipient");

  const extra = [
    { address: "0x658370618BBc885865df66c1061BfE4771FaD846", label: "Crypto.com Suspect", role: "suspect", chain: "ethereum" },
    { address: "0xD14F4B36E1D1D98c218db782c49149876042BC56", label: "FXUSD Source", role: "source", chain: "ethereum" },
    { address: "0x6818809EefCe719E480a7526D76bD3e561526b46", label: "Relay Proxy", role: "relay", chain: "ethereum" },
    { address: "0xEC15c20015e72748F03065ed80c41cb882E3fB66", label: "Relayer", role: "relayer", chain: "ethereum" },
  ];

  const seen = new Set<string>();
  const all: Array<{address: string; label: string; role: string; chain: string}> = [];
  for (const w of extra) { seen.add(w.address.toLowerCase()); all.push(w); }
  for (const w of important) {
    const lo = w.address.toLowerCase();
    if (!seen.has(lo) && lo.startsWith("0x") && lo.length === 42) {
      seen.add(lo);
      all.push({ address: w.address, label: w.label || "", role: w.role || "", chain: w.chain || "ethereum" });
    }
  }

  console.log(`Wallets to check: ${all.length}\n`);

  // Process in batches of 3 concurrently
  const allHits: Hit[] = [];
  let checked = 0;

  for (let i = 0; i < all.length; i += 3) {
    const batch = all.slice(i, i + 3);
    const results = await Promise.all(batch.map(w => {
      const ch = (w.chain || "ethereum").toLowerCase() === "arbitrum" ? "arbitrum" : "ethereum";
      return check(w.address, w.label, w.role, ch);
    }));
    for (let j = 0; j < results.length; j++) {
      checked++;
      if (results[j].length > 0) {
        allHits.push(...results[j]);
        console.log(`  ★ ${batch[j].address.slice(0,10)}... (${batch[j].label || batch[j].role}) — ${results[j].length} hits`);
      }
    }
    if (checked % 12 === 0) console.log(`  Progress: ${checked}/${all.length}...`);
  }

  // Dedup
  const dm = new Map<string, Hit>();
  for (const h of allHits) { const k = `${h.tx}-${h.wallet}-${h.dir}-${h.token}`; if (!dm.has(k)) dm.set(k, h); }
  const hits = [...dm.values()].sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime());

  // Group by exchange
  const exMap = new Map<string, Hit[]>();
  for (const h of hits) {
    const n = h.exchange.split(" ")[0]; // normalize
    if (!exMap.has(h.exchange)) exMap.set(h.exchange, []);
    exMap.get(h.exchange)!.push(h);
  }

  // Build report
  let report = `════════════════════════════════════════════════════════════════════════════════
  ALPHA FORENSIC INTELLIGENCE ENGINE™
  COMPLETE KYC EXCHANGE SWEEP — EVERY WALLET CHECKED
  Case: @sillytuna (Alex Amsel) — ~$24M Crypto Theft
  Case ID: ${CASE}
  Generated: ${new Date().toISOString()}
  Anchor: FXUSD SOURCE 0xD14F4B36E1D1D98c218db782c49149876042BC56
════════════════════════════════════════════════════════════════════════════════

Wallets Checked: ${all.length}
Known Exchange Addresses Tracked: ${Object.keys(KNOWN_EXCHANGES).length}
Total Exchange Interactions Found: ${hits.length}
Unique Exchanges: ${exMap.size}

══════════════════════════════════════════════════════════════════
EXCHANGE SUMMARY
══════════════════════════════════════════════════════════════════\n\n`;

  for (const [ex, h] of [...exMap.entries()].sort((a, b) => b[1].length - a[1].length)) {
    const dep = h.filter(x => x.dir.includes("TO")).length;
    const wth = h.filter(x => x.dir.includes("FROM")).length;
    const wallets = new Set(h.map(x => x.wallet.toLowerCase())).size;
    report += `  ${ex}: ${h.length} total (${dep} deposits, ${wth} withdrawals) — ${wallets} wallet(s)\n`;
  }

  for (const [ex, exHits] of [...exMap.entries()].sort((a, b) => b[1].length - a[1].length)) {
    report += `\n══════════════════════════════════════════════════════════════════\n${ex.toUpperCase()} — ${exHits.length} INTERACTIONS\n══════════════════════════════════════════════════════════════════\n\n`;

    for (const h of exHits) {
      report += `  ${h.ts}  ${h.dir} ${h.exchange}\n`;
      report += `  Amount: ${h.amount} ${h.token} | Chain: ${h.chain}\n`;
      report += `  Wallet: ${h.wallet} (${h.label} [${h.role}])\n`;
      report += `  TX: ${h.tx}\n\n`;
    }

    const uw = new Map<string, string>();
    for (const h of exHits) uw.set(h.wallet.toLowerCase(), `${h.label} [${h.role}]`);
    report += `  Subpoena addresses:\n`;
    for (const [a, l] of uw) report += `    ${a} — ${l}\n`;
    report += "\n";
  }

  report += `\n═══════════════════════════════════════════════════════════════════
CONFIDENTIAL — For the victim and law enforcement only.
Alpha Unlimited Trading Company — Forensic Intelligence Division
© 2024-2026 All Rights Reserved
═══════════════════════════════════════════════════════════════════\n`;

  fs.writeFileSync("forensic_full_exchange_sweep.txt", report);
  console.log(`\n═══ FINAL RESULTS ═══`);
  console.log(`Checked: ${checked} wallets`);
  console.log(`Exchange hits: ${hits.length}`);
  console.log(`Exchanges found: ${exMap.size}`);
  console.log(`Report saved: forensic_full_exchange_sweep.txt (${report.split("\n").length} lines)`);

  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
