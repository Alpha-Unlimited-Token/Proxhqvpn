/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_CHECK_EMAILS_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_CheckEmails_Calibration_PROTECTED
 */
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";
import { eq } from "drizzle-orm";

async function main() {
  const CASE = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
  const alerts = await db.select().from(forensicAlerts).where(eq(forensicAlerts.caseId, CASE));
  const sent = alerts.filter(a => a.alertType === "report_sent" || a.alertType === "live_activity_alert").sort((x, y) => new Date(x.createdAt!).getTime() - new Date(y.createdAt!).getTime());

  console.log(`TOTAL EMAILS SENT ON THIS CASE: ${sent.length}\n`);
  for (let i = 0; i < sent.length; i++) {
    const a = sent[i];
    const d = a.details as any;
    console.log(`EMAIL #${i + 1}`);
    console.log(`  Date: ${a.createdAt}`);
    console.log(`  To: ${d?.recipientEmail || "?"}`);
    console.log(`  Summary: ${a.message}`);
    if (d?.zipSizeKb) console.log(`  ZIP: ${d.zipSizeKb} KB`);
    if (d?.subject) console.log(`  Subject: ${d.subject}`);
    console.log("");
  }
  process.exit(0);
}
main();
