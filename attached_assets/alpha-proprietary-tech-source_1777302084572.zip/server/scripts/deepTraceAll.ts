import { db } from "../db.js";
import { eq } from "drizzle-orm";
import { monitoredWallets } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const DELAY_MS = 100;
const BLOCKSCOUT: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
};

const KNOWN: Record<string, string> = {
  "0x28c6c06298d514db089934071d89d3dece0c3b2d": "Binance 14", "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 6",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 16", "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance 8",
  "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": "Binance 1", "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance 7",
  "0x47ac0fb4f2d84898e4d9e7b4dab3c24507a6d503": "Binance US", "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase 1",
  "0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740": "Coinbase 2", "0x3cd751e6b0078be393132286c442345e68ff0aaa": "Coinbase 4",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase 10", "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase 3",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken 4", "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken 7",
  "0xfa52274dd61e1643d2205169732f29114bc240b3": "Kraken 13", "0xae2d4617c862309a3d75a0ffb358c7a5009c673f": "Kraken 10",
  "0x0a869d79a7052c7f1b55a8ebabbea3420f0d1e13": "KuCoin 1", "0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91": "KuCoin 2",
  "0x1db92e2eebc8e0c075a02bea49a2935bcd2dfcf4": "KuCoin Hot", "0xeb2629a2734e272bcc07bda959863f316f4bd4cf": "OKX 2",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX 4", "0x98ec059dc3adfbdd63429227d1e02668e91b0755": "OKX 8",
  "0xa7efae728d2936e78bda97dc267687568dd593f3": "OKX 3", "0x46340b20830761efd32832a74d7169b29feb9758": "Bybit",
  "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit 2", "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io 1",
  "0xd793281b49445e1d78c5c28c85ad50e44c249b27": "Gate.io 2", "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io 3",
  "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": "MEXC 1", "0x3cc936b795a188f0e246cbb2d74c5bd190aecf18": "MEXC 2",
  "0xe93381fb4c4f14bda253907b18fad305d799cee7": "Huobi 10", "0x18709e89bd403f470088abdacebe86cc60dda12e": "Huobi 34",
  "0x0211f3cedbef3143223d3acf0e589747933e8527": "Bitfinex 3", "0x876eabf441b2ee5b5b0554fd502a8e0600950cfa": "Bitfinex 4",
  "0x61189da79177950a7272c88c6058b96d4bcd6be2": "Gemini 4", "0x6fc82a5fe25a5cdb58bc74600a40a69c065263f8": "Gemini Hot",
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41": "CoW Swap", "0x1111111254eeb25477b68fb85ed929f73a960582": "1inch v5",
  "0xdef1c0ded9bec7f1a1670819833240f027b25eff": "0x Proxy", "0xe592427a0aece92de3edee1f18e0157c05861564": "Uniswap V3",
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": "Uniswap Router", "0x7a250d5630b4cf539739df2c5dacb4c659f2488d": "Uniswap V2",
  "0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad": "Uniswap Router2", "0xd9e1ce17f2641f24ae83637ab66a2cca9c378b9f": "SushiSwap",
  "0x881d40237659c251811cec9c364ef91dc08d300c": "MetaMask Swap", "0x216b4b4ba9f3e719726886d34a177484278bfcae": "LI.FI",
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": "LI.FI Proxy", "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f": "Arbitrum Bridge",
  "0x99c9fc46f92e8a1c0dec1b1747d010903e884be1": "Optimism Bridge", "0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf": "Polygon Bridge",
  "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7": "Bridge2 Pool", "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": "WETH",
  "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": "USDC", "0x6b175474e89094c44da98b954eedeac495271d0f": "DAI",
  "0xdac17f958d2ee523a2206206994597c13d831ec7": "USDT", "0x0000000000000000000000000000000000000000": "Null",
};

function isProtocol(label: string): boolean {
  const l = label.toLowerCase();
  return l.includes("swap") || l.includes("router") || l.includes("proxy") || l.includes("bridge") || l.includes("weth") || l.includes("usdc") || l.includes("dai") || l.includes("usdt") || l.includes("null") || l.includes("1inch") || l.includes("0x ") || l.includes("li.fi") || l.includes("sushi") || l.includes("metamask") || l.includes("uniswap") || l.includes("diamond");
}
function isExchange(label: string): boolean {
  const l = label.toLowerCase();
  return (l.includes("binance") || l.includes("coinbase") || l.includes("kraken") || l.includes("kucoin") || l.includes("okx") || l.includes("bybit") || l.includes("gate.io") || l.includes("mexc") || l.includes("huobi") || l.includes("bitfinex") || l.includes("gemini"));
}

interface Tx { hash: string; from: string; to: string; ethVal: number; timestamp: string; type: string; tokenSym?: string; tokenAmt?: number; chain: string; method?: string; }
interface Node { addr: string; chain: string; label: string; role: string; depth: number; parent: string; balance: number; tokens: Record<string,number>; isContract: boolean; txs: Tx[]; }

const nodes = new Map<string, Node>();
const seen = new Set<string>();
let apiCalls = 0;

async function api(url: string): Promise<any> {
  for (let i = 0; i < 2; i++) {
    try {
      apiCalls++;
      const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(10000) });
      if (r.status === 429) { await new Promise(r => setTimeout(r, 2000)); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await new Promise(r => setTimeout(r, 500)); }
  }
  return null;
}

async function scan(address: string, chain: string, depth: number, maxDepth: number, parent: string, label: string, role: string): Promise<void> {
  const key = `${address.toLowerCase()}_${chain}`;
  if (seen.has(key) || depth > maxDepth) return;
  seen.add(key);
  const addr = address.toLowerCase();

  const kl = KNOWN[addr] || "";
  if (kl && depth > 0) {
    nodes.set(key, { addr, chain, label: kl, role: isExchange(kl) ? "Exchange" : "Protocol", depth, parent, balance: 0, tokens: {}, isContract: !isExchange(kl), txs: [] });
    if (isExchange(kl)) process.stdout.write(`${"  ".repeat(depth)}*** ${kl} ***\n`);
    else process.stdout.write(`${"  ".repeat(depth)}${kl} (protocol)\n`);
    return;
  }
  if (depth === 0 && kl && isProtocol(kl)) {
    nodes.set(key, { addr, chain, label: kl, role: "Protocol", depth, parent, balance: 0, tokens: {}, isContract: true, txs: [] });
    process.stdout.write(`[D0] ${kl} — protocol, skip\n`);
    return;
  }

  const base = BLOCKSCOUT[chain] || BLOCKSCOUT.ethereum;
  const info = await api(`${base}/addresses/${addr}`);
  await new Promise(r => setTimeout(r, DELAY_MS));
  const balance = info ? parseInt(info.coin_balance || "0") / 1e18 : 0;
  const isCont = info?.is_contract || false;

  let tokens: Record<string, number> = {};
  if (!isCont || depth === 0) {
    const td = await api(`${base}/addresses/${addr}/token-balances`);
    await new Promise(r => setTimeout(r, DELAY_MS));
    if (Array.isArray(td)) for (const t of td) { const s = t.token?.symbol || "?"; const v = parseFloat(t.value || "0") / Math.pow(10, parseInt(t.token?.decimals || "18")); if (v > 0.001) tokens[s] = v; }
  }

  const txs: Tx[] = [];
  const nd = await api(`${base}/addresses/${addr}/transactions?filter=from`);
  await new Promise(r => setTimeout(r, DELAY_MS));
  if (nd?.items) for (const t of nd.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.hash || "", from: addr, to, ethVal: parseFloat(t.value || "0") / 1e18, timestamp: t.timestamp || "", type: "normal", chain, method: t.method || "" }); }

  const td2 = await api(`${base}/addresses/${addr}/token-transfers?filter=from`);
  await new Promise(r => setTimeout(r, DELAY_MS));
  if (td2?.items) for (const t of td2.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.transaction_hash || "", from: addr, to, ethVal: 0, timestamp: t.timestamp || "", type: "token", tokenSym: t.token?.symbol || "?", tokenAmt: parseFloat(t.total?.value || "0") / Math.pow(10, parseInt(t.token?.decimals || "18")), chain }); }

  const id = await api(`${base}/addresses/${addr}/internal-transactions?filter=from`);
  await new Promise(r => setTimeout(r, DELAY_MS));
  if (id?.items) for (const t of id.items) { const to = (t.to?.hash || "").toLowerCase(); if (to && to !== addr) txs.push({ hash: t.transaction_hash || "", from: addr, to, ethVal: parseFloat(t.value || "0") / 1e18, timestamp: t.timestamp || "", type: "internal", chain }); }

  process.stdout.write(`${"  ".repeat(depth)}[D${depth}] ${(label || addr).slice(0, 30)} | ${txs.length} txs | ${balance.toFixed(4)} ETH | ${Object.keys(tokens).length} tok${isCont ? " [C]" : ""}\n`);
  nodes.set(key, { addr, chain, label: kl || label, role, depth, parent, balance, tokens, isContract: isCont, txs });

  if (isCont && depth >= 1) return;

  const dests = new Map<string, number>();
  for (const tx of txs) { dests.set(tx.to, (dests.get(tx.to) || 0) + tx.ethVal + (tx.tokenAmt || 0) * 0.0001); }
  const top = [...dests.entries()].filter(([a]) => a !== "0x0000000000000000000000000000000000000000").sort((a, b) => b[1] - a[1]).slice(0, depth === 0 ? 8 : 4);
  for (const [d] of top) await scan(d, chain, depth + 1, maxDepth, addr, KNOWN[d] || "", "Destination");
}

async function main() {
  const startTime = Date.now();
  console.log("ALPHA FORENSIC INTELLIGENCE ENGINE™ — COMPREHENSIVE DEEP TRACE");
  console.log(`Started: ${new Date().toISOString()}\n`);

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  console.log(`Tracing ${wallets.length} wallets...\n`);

  for (let i = 0; i < wallets.length; i++) {
    if (Date.now() - startTime > 85000) { console.log(`TIME LIMIT at wallet ${i+1}/${wallets.length} — saving results`); break; }
    const w = wallets[i];
    const r = (w.role || "").toLowerCase();
    const isPriority = r.includes("poi") || r.includes("source") || r.includes("laundering");
    const maxD = isPriority ? 2 : 1;
    console.log(`\n${isPriority ? "===" : "---"} ${i+1}/${wallets.length}: ${w.label || w.address.slice(0,14)} [${w.role}] (depth ${maxD}) ${isPriority ? "===" : "---"}`);
    await scan(w.address, w.chain || "ethereum", 0, maxD, "", w.label || "", w.role || "");
  }

  console.log(`\nTRACE DONE | ${nodes.size} wallets | ${apiCalls} API calls | ${((Date.now() - startTime) / 1000).toFixed(0)}s`);

  const dir = path.resolve("private/forensic-exports");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const lines: string[] = [];
  lines.push("=".repeat(80));
  lines.push("ALPHA UNLIMITED TRADING — FORENSIC INTELLIGENCE ENGINE™");
  lines.push("COMPREHENSIVE FUND FLOW ANALYSIS — @sillytuna ~$26M Theft");
  lines.push(`Generated: ${new Date().toISOString()} | Wallets: ${nodes.size} | API Calls: ${apiCalls}`);
  lines.push("=".repeat(80));
  lines.push("");

  const exchanges = [...nodes.values()].filter(n => n.role === "Exchange");
  const protocols = [...nodes.values()].filter(n => n.role === "Protocol");
  const withBal = [...nodes.values()].filter(n => n.balance > 0.001 || Object.keys(n.tokens).length > 0);

  lines.push("EXECUTIVE SUMMARY");
  lines.push("-".repeat(80));
  lines.push(`Total addresses discovered: ${nodes.size}`);
  lines.push(`Exchanges receiving funds: ${exchanges.length} — ${exchanges.map(e => e.label).join(", ")}`);
  lines.push(`Protocols/DEX used: ${protocols.length} — ${protocols.map(p => p.label).join(", ")}`);
  lines.push(`Wallets still holding funds: ${withBal.length}`);
  lines.push("");

  if (exchanges.length > 0) {
    lines.push("EXCHANGE DEPOSIT DETAILS");
    lines.push("-".repeat(80));
    for (const ex of exchanges) {
      const deps = [...nodes.values()].flatMap(n => n.txs.filter(tx => tx.to === ex.addr));
      const ethSum = deps.filter(t => t.type !== "token").reduce((s, t) => s + t.ethVal, 0);
      const toks: Record<string, number> = {};
      for (const t of deps) if (t.type === "token" && t.tokenSym && t.tokenAmt) toks[t.tokenSym] = (toks[t.tokenSym] || 0) + t.tokenAmt;
      const tokStr = Object.entries(toks).map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ");
      lines.push(`${ex.label} (${ex.addr})`);
      lines.push(`  ${deps.length} deposits | ${ethSum.toFixed(6)} ETH${tokStr ? " + " + tokStr : ""}`);
      for (const d of deps) {
        const src = [...nodes.values()].find(n => n.addr === d.from);
        lines.push(`  • ${d.timestamp} | From: ${d.from}${src?.label ? " [" + src.label + "]" : ""} | ${d.type === "token" ? `${d.tokenAmt?.toFixed(4)} ${d.tokenSym}` : `${d.ethVal.toFixed(6)} ETH`} | Tx: ${d.hash}`);
      }
      lines.push("");
    }
  }

  if (protocols.length > 0) {
    lines.push("DEX / BRIDGE / PROTOCOL INTERACTIONS");
    lines.push("-".repeat(80));
    for (const p of protocols) {
      const uses = [...nodes.values()].flatMap(n => n.txs.filter(tx => tx.to === p.addr));
      if (uses.length === 0) continue;
      lines.push(`${p.label} — ${uses.length} interactions`);
      for (const u of uses.slice(0, 20)) lines.push(`  • ${u.timestamp} | From: ${u.from} | ${u.type === "token" ? `${u.tokenAmt?.toFixed(4)} ${u.tokenSym}` : `${u.ethVal.toFixed(6)} ETH`} | Tx: ${u.hash}`);
      if (uses.length > 20) lines.push(`  ... and ${uses.length - 20} more`);
      lines.push("");
    }
  }

  lines.push("WALLETS WITH REMAINING FUNDS");
  lines.push("-".repeat(80));
  for (const w of withBal.sort((a, b) => b.balance - a.balance)) {
    const tokStr = Object.entries(w.tokens).map(([s, v]) => `${v.toFixed(4)} ${s}`).join(", ");
    lines.push(`${w.addr} (${w.chain}) — ${w.balance.toFixed(6)} ETH${tokStr ? " + " + tokStr : ""} [${w.label || w.role}] D${w.depth}`);
  }
  lines.push("");

  lines.push("COMPLETE WALLET-BY-WALLET FUND FLOW");
  lines.push("=".repeat(80));
  for (const n of [...nodes.values()].sort((a, b) => a.depth - b.depth || b.txs.length - a.txs.length)) {
    if (n.txs.length === 0 && n.balance < 0.001 && Object.keys(n.tokens).length === 0) continue;
    lines.push("");
    lines.push(`${"─".repeat(70)}`);
    lines.push(`${n.addr} [${n.label || "Unknown"}] (${n.chain}) D${n.depth}`);
    lines.push(`Role: ${n.role} | Balance: ${n.balance.toFixed(6)} ETH | Contract: ${n.isContract}`);
    if (n.parent) lines.push(`Parent: ${n.parent}`);
    if (Object.keys(n.tokens).length > 0) lines.push(`Tokens: ${Object.entries(n.tokens).map(([s, v]) => `${v.toFixed(4)} ${s}`).join(", ")}`);
    if (n.txs.length > 0) {
      const byDest = new Map<string, Tx[]>();
      for (const tx of n.txs) { if (!byDest.has(tx.to)) byDest.set(tx.to, []); byDest.get(tx.to)!.push(tx); }
      for (const [dest, txs] of [...byDest.entries()].sort((a, b) => b[1].length - a[1].length)) {
        const dl = KNOWN[dest] || nodes.get(`${dest}_${n.chain}`)?.label || "";
        const ethS = txs.filter(t => t.type !== "token").reduce((s, t) => s + t.ethVal, 0);
        const toks: Record<string, number> = {};
        for (const t of txs) if (t.type === "token" && t.tokenSym && t.tokenAmt) toks[t.tokenSym] = (toks[t.tokenSym] || 0) + t.tokenAmt;
        const tokStr = Object.entries(toks).map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ");
        lines.push(`  → ${dest}${dl ? " [" + dl + "]" : ""} | ${txs.length} tx | ${ethS.toFixed(6)} ETH${tokStr ? " + " + tokStr : ""}`);
        for (const tx of txs) lines.push(`    • ${tx.timestamp} | ${tx.type === "token" ? `${tx.tokenAmt?.toFixed(4)} ${tx.tokenSym}` : `${tx.ethVal.toFixed(6)} ETH`} | ${tx.hash}${tx.method ? " | " + tx.method : ""}`);
      }
    }
  }

  lines.push("\n" + "=".repeat(80));
  lines.push("END — Alpha Unlimited Trading Forensic Intelligence Division");
  lines.push(new Date().toISOString());

  const report = lines.join("\n");
  fs.writeFileSync(path.join(dir, "COMPLETE-FUND-FLOW-REPORT.txt"), report);

  const allTxs = [...nodes.values()].flatMap(n => n.txs.map(t => ({ ...t, srcLabel: n.label, srcRole: n.role, srcDepth: n.depth, destLabel: KNOWN[t.to] || nodes.get(`${t.to}_${t.chain}`)?.label || "" })));
  allTxs.sort((a, b) => (a.timestamp || "").localeCompare(b.timestamp || ""));
  fs.writeFileSync(path.join(dir, "ALL-TRANSACTIONS.json"), JSON.stringify(allTxs, null, 2));

  const csv = ["Source,SourceLabel,SourceRole,Depth,Destination,DestLabel,Type,ETH,TokenSymbol,TokenAmount,TxHash,Timestamp,Chain,Method"];
  for (const t of allTxs) csv.push([t.from, `"${t.srcLabel}"`, `"${t.srcRole}"`, t.srcDepth, t.to, `"${t.destLabel}"`, t.type, t.ethVal.toFixed(8), t.tokenSym || "", t.tokenAmt?.toFixed(8) || "", t.hash, t.timestamp, t.chain, `"${t.method || ""}"`].join(","));
  fs.writeFileSync(path.join(dir, "ALL-TRANSACTIONS.csv"), csv.join("\n"));

  const profiles = [...nodes.values()].map(n => ({ ...n, txCount: n.txs.length, txs: undefined }));
  fs.writeFileSync(path.join(dir, "ALL-WALLET-PROFILES.json"), JSON.stringify(profiles, null, 2));

  const wCsv = ["Address,Chain,Label,Role,Depth,Parent,BalanceETH,IsContract,TxCount,Tokens"];
  for (const p of profiles) wCsv.push([p.addr, p.chain, `"${p.label}"`, `"${p.role}"`, p.depth, p.parent, p.balance.toFixed(8), p.isContract, p.txCount, `"${Object.entries(p.tokens).map(([s, v]) => `${s}:${v.toFixed(4)}`).join("; ")}"`].join(","));
  fs.writeFileSync(path.join(dir, "ALL-WALLET-PROFILES.csv"), wCsv.join("\n"));

  const edges = [...nodes.values()].flatMap(n => {
    const d = new Map<string, { eth: number; toks: Record<string, number>; cnt: number }>();
    for (const t of n.txs) { if (!d.has(t.to)) d.set(t.to, { eth: 0, toks: {}, cnt: 0 }); const x = d.get(t.to)!; x.eth += t.ethVal; x.cnt++; if (t.type === "token" && t.tokenSym && t.tokenAmt) x.toks[t.tokenSym] = (x.toks[t.tokenSym] || 0) + t.tokenAmt; }
    return [...d.entries()].filter(([, v]) => v.eth > 0.0001 || Object.keys(v.toks).length > 0).map(([to, v]) => ({ from: n.addr, fromLabel: n.label, to, toLabel: KNOWN[to] || nodes.get(`${to}_${n.chain}`)?.label || "", chain: n.chain, ...v }));
  });
  fs.writeFileSync(path.join(dir, "FUND-FLOW-GRAPH.json"), JSON.stringify(edges, null, 2));

  const exReport = exchanges.map(ex => {
    const deps = [...nodes.values()].flatMap(n => n.txs.filter(t => t.to === ex.addr));
    return { exchange: ex.label, address: ex.addr, deposits: deps.length, ethTotal: deps.filter(t => t.type !== "token").reduce((s, t) => s + t.ethVal, 0), transactions: deps };
  });
  fs.writeFileSync(path.join(dir, "EXCHANGE-DEPOSITS.json"), JSON.stringify(exReport, null, 2));

  console.log(`\nFiles written to private/forensic-exports/:`);
  for (const f of fs.readdirSync(dir)) console.log(`  ${f} — ${(fs.statSync(path.join(dir, f)).size / 1024).toFixed(1)} KB`);

  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
