/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Comprehensive RAVEDAO_DUMP forensic run — emails OWNER ONLY (alphaunlimitedtoken@gmail.com).
 * NEVER to SillyTuna · NEVER to SEAL · INTERNAL CASE.
 */
import * as fs from 'fs';
import * as path from 'path';
import { getUncachableSendGridClient } from '../services/sendgridService.js';
import {
  runComprehensiveCaseForensics,
  renderComprehensiveHtml,
  type CaseForensicsInput,
} from '../services/comprehensiveCaseForensics.js';

const RAVE_TOKEN = '0x17205fab260a7a6383a81452ce6315a39370db97';

const PROJECT_URLS = [
  `https://etherscan.io/token/${RAVE_TOKEN}`,
  `https://dexscreener.com/ethereum/${RAVE_TOKEN}`,
];

const INTEL_FILES = [
  'contracts/atc/ravedao_dump_analysis.json',
  'contracts/atc/ravedao_forward_trace.json',
];

const CASE_SUMMARY = `
RAVEDAO_DUMP — coordinated dev-cohort dump of RAVE token (${RAVE_TOKEN}).
19 confirmed dumpers (excluding burn address), $5.03M proceeds traced through 82 unique
terminal endpoints via Alpha Proceeds Forward-Trace Engine™ (BFS, USD reconciliation
gap $0.00). This package re-runs the multi-chain wallet tracer on all 19 dumpers,
performs web-archive forensics on the project's public surfaces, and bundles the full
dump-analysis + forward-trace JSON datasets.
`.trim();

const RECIPIENT = { email: 'alphaunlimitedtoken@gmail.com', name: 'Alpha Unlimited Token (Owner)' };

function loadDumpers(): Array<{ address: string; label: string; type: string }> {
  const j = JSON.parse(fs.readFileSync('contracts/atc/ravedao_dump_analysis.json', 'utf-8'));
  const dumpers = (j.dumpers || []).filter(
    (d: any) => d.address && d.address !== '0x0000000000000000000000000000000000000000'
  );
  return dumpers.map((d: any) => ({
    address: d.address,
    label: `Dumped ${(d.tokensSold || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })} RAVE in ${d.txs} tx${d.isContract ? ' (CONTRACT)' : ''}`,
    type: d.isContract ? 'contract_dumper' : 'eoa_dumper',
  }));
}

function loadAttachments(reportHtml: string, reportJson: string) {
  const out: Array<{ content: string; filename: string; type: string; disposition: 'attachment' }> = [];
  out.push({
    content: Buffer.from(reportHtml).toString('base64'),
    filename: `RAVEDAO-Comprehensive-Forensic-Report-${new Date().toISOString().slice(0,10)}.html`,
    type: 'text/html',
    disposition: 'attachment',
  });
  out.push({
    content: Buffer.from(reportJson).toString('base64'),
    filename: `RAVEDAO-Comprehensive-Forensic-Report-${new Date().toISOString().slice(0,10)}.json`,
    type: 'application/json',
    disposition: 'attachment',
  });
  for (const f of INTEL_FILES) {
    const abs = path.resolve(process.cwd(), f);
    if (!fs.existsSync(abs)) { console.log(`  skip (missing): ${f}`); continue; }
    const buf = fs.readFileSync(abs);
    if (buf.length > 14 * 1024 * 1024) { console.log(`  skip (too large): ${f}`); continue; }
    out.push({
      content: buf.toString('base64'),
      filename: path.basename(abs),
      type: 'application/json',
      disposition: 'attachment',
    });
    console.log(`  attached: ${f} (${(buf.length/1024).toFixed(1)} KB)`);
  }
  return out;
}

async function main() {
  console.log('=== RAVEDAO_DUMP — Comprehensive Forensic Run (INTERNAL OWNER ONLY) ===');
  const dumpers = loadDumpers();
  console.log(`Dumpers: ${dumpers.length} · URLs: ${PROJECT_URLS.length}`);

  const input: CaseForensicsInput = {
    caseId: 'RAVEDAO_DUMP',
    caseName: 'RAVE Coordinated Dev-Cohort Dump ($5.03M traced)',
    wallets: dumpers,
    projectUrls: PROJECT_URLS,
    chains: ['eth', 'polygon', 'arbitrum', 'optimism', 'base'],
    existingIntelFiles: INTEL_FILES,
    caseSummary: CASE_SUMMARY,
  };

  console.log('Running multi-chain trace + web-archive snapshot…');
  const t0 = Date.now();
  const report = await runComprehensiveCaseForensics(input);
  console.log(`Done in ${((Date.now() - t0)/1000).toFixed(1)}s.`);
  const natStr = Object.entries(report.aggregate.nativeBalanceTotals).map(([s,a]) => `${(a as number).toLocaleString(undefined,{maximumFractionDigits:2})} ${s}`).join(' · ');
  console.log(`  walletsScanned=${report.aggregate.walletsScanned}  natives=[${natStr}]  totalTx=${report.aggregate.totalTx}`);
  console.log(`  archiveTargets=${report.aggregate.archiveTargetsScanned}  flagged=${Object.keys(report.aggregate.flaggedEntityHits).length}`);

  const reportJson = JSON.stringify(report, null, 2);
  const stamp = new Date().toISOString().slice(0,10);
  const outDir = 'private/forensic-reports';
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, `ravedao-comprehensive-${stamp}.json`), reportJson);

  const html = renderComprehensiveHtml(report, 'owner-internal');
  const attachments = loadAttachments(html, reportJson);

  const { client, fromEmail } = await getUncachableSendGridClient();
  const subject = `[INTERNAL · OWNER ONLY] RAVEDAO_DUMP Comprehensive Forensic Re-Scan — ${report.aggregate.walletsScanned} dumpers across 5 chains — ${stamp}`;

  console.log(`→ Sending to ${RECIPIENT.name} <${RECIPIENT.email}> (${attachments.length} attachments)…`);
  try {
    await client.send({
      to: { email: RECIPIENT.email, name: RECIPIENT.name },
      from: { email: fromEmail, name: 'Alpha Unlimited — Forensic Intelligence (Internal)' },
      subject,
      content: [
        { type: 'text/plain', value: `RAVEDAO_DUMP comprehensive forensic re-scan. INTERNAL OWNER COPY ONLY.\nGenerated ${report.generatedAt}` },
        { type: 'text/html', value: html },
      ],
      attachments,
    });
    console.log(`  ✅ SENT to ${RECIPIENT.email}`);
  } catch (e: any) {
    console.log(`  ❌ FAILED: ${e?.message || e}`);
    if (e?.response?.body) console.log(`     ${JSON.stringify(e.response.body).slice(0, 500)}`);
    process.exit(1);
  }
  console.log('\n=== Done ===');
}

main().catch(e => { console.error(e); process.exit(1); });
