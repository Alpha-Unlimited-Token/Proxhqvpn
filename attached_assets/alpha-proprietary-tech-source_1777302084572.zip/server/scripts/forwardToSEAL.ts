/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_FORWARD_SEAL_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_ForwardSEAL_Calibration_PROTECTED
 */

import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import { db } from "../db.js";
import { forensicAlerts } from "@shared/schema";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const TO = "tips@securityalliance.org";
const SUBJECT = "SEAL 911 — @sillytuna (Alex Amsel) ~$24M Theft — Full Forensic Evidence Package (64 Wallets, 5 KYC Exchanges, Binance Primary Cash-Out)";

async function main() {
  console.log("[ForwardSEAL] Building complete evidence package for SEAL...");

  // Collect all report files
  const files = [
    { src: "forensic_master_fxusd_trace.txt", name: "[1] Master FXUSD-Anchored Evidence — 64 Wallets 1435 TXs.txt" },
    { src: "forensic_fxusd_source_chain_trace.txt", name: "[2] FXUSD Source to Crypto.com Evidence Chain.txt" },
    { src: "forensic_crypto_com_chain_trace.txt", name: "[3] Crypto.com Full Chain Trace — 3678 TXs.txt" },
    { src: "forensic_intelligence_update.txt", name: "[4] Intelligence Update — Exchange Flows Blacklist Original Funder.txt" },
    { src: "forensic_live_activity_alert.txt", name: "[5] Live Activity Alert — 211 New Transactions Detected.txt" },
    { src: "forensic_full_exchange_sweep.txt", name: "[6] Complete Exchange Sweep — 66 Wallets vs 60+ KYC Exchanges.txt" },
  ];

  const available: typeof files = [];
  for (const f of files) {
    if (fs.existsSync(path.resolve(f.src))) {
      available.push(f);
      const size = (fs.statSync(path.resolve(f.src)).size / 1024).toFixed(1);
      console.log(`  ✓ ${f.name} (${size} KB)`);
    } else {
      console.log(`  ✗ MISSING: ${f.src}`);
    }
  }

  // Create ZIP with all files
  const tmp = `/tmp/seal_forward_${Date.now()}`;
  const zipDir = path.join(tmp, "Sillytuna-Complete-Forensic-Package");
  fs.mkdirSync(zipDir, { recursive: true });

  for (const f of available) {
    fs.copyFileSync(path.resolve(f.src), path.join(zipDir, f.name));
  }

  const zipPath = path.join(tmp, "evidence.zip");
  execSync(`cd "${tmp}" && zip -9 -r "${zipPath}" "Sillytuna-Complete-Forensic-Package/"`, { timeout: 30000 });

  const zipBuf = fs.readFileSync(zipPath);
  const zipKb = (zipBuf.length / 1024).toFixed(1);
  console.log(`\n[ForwardSEAL] ZIP: ${zipKb} KB (${available.length} files)`);

  const { client, fromEmail } = await getUncachableSendGridClient();
  console.log(`[ForwardSEAL] Sending from ${fromEmail} to ${TO}...`);
  console.log(`[ForwardSEAL] Subject: ${SUBJECT}`);

  const emailBody = `To the SEAL 911 Team,

We are forwarding a complete forensic evidence package on behalf of the victim
@sillytuna (Alex Amsel), who suffered an approximate $24M cryptocurrency theft
involving physical coercion and subsequent on-chain laundering.

This package contains ALL findings from our forensic investigation, compiled
by the Alpha Forensic Intelligence Engine. Every TX hash is independently
verifiable on Ethereum and Arbitrum mainnet.

══════════════════════════════════════════════════════════════════
CASE SUMMARY
══════════════════════════════════════════════════════════════════

Victim: @sillytuna (Alex Amsel)
Estimated Loss: ~$24M
Victim Wallet: 0x6fe0fab2164d8e0d03ad6a628e2af78624060322
Case ID: 306db48a-36e2-42c1-9d7c-3b49d5bfdb49

Theft Breakdown:
  ~$20M DAI — Hub → 12+ wallets via Laundering Hub
  ~$2.47M — Hyperliquid/Wagyu → Monero (19 accounts)
  ~$1.1M BTC — via LiFi (~0.5 BTC mixer)
  ~$2.48M USDC — Arbitrum (10 receivers)
  ~$155K FXUSD — → Crypto.com wallet → USDC (still unfrozen)

══════════════════════════════════════════════════════════════════
KEY WALLETS
══════════════════════════════════════════════════════════════════

  POI ($4.35M):           0xf70da97812cb96acdf810712aa562db8dfa3dbef
  Source (EIP-7702):      0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb
  Gas Funder:             0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7
  Laundering Hub ($20M):  0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872
  Original Funder:        0x423d2b61952d56358db8b313ec7404a9582d4865
  FXUSD SOURCE:           0xD14F4B36E1D1D98c218db782c49149876042BC56
  Relay Proxy:            0x6818809EefCe719E480a7526D76bD3e561526b46
  Crypto.com Suspect:     0x658370618BBc885865df66c1061BfE4771FaD846

══════════════════════════════════════════════════════════════════
CRITICAL FINDINGS
══════════════════════════════════════════════════════════════════

1. CRYPTO.COM KYC WALLET IDENTIFIED
   0x658370618BBc885865df66c1061BfE4771FaD846
   • Funded by Crypto.com Hot Wallet 2 (TX: 0x358a4d8c...)
   • Currently holds $155,017 USDC — NOT FROZEN
   • Received stolen FXUSD on March 7, 2026 and swapped to USDC via CoW Swap
   • Subpoena target: Foris DAX MT Ltd. (compliance@crypto.com)

2. 5 KYC EXCHANGES CONNECTED — 35 INTERACTIONS
   • Binance: 29 interactions (25 deposits, 4 withdrawals) — 5 wallets — PRIMARY CASH-OUT
   • Crypto.com: 2 interactions — KYC proof
   • Coinbase: 2 interactions — withdrawals to attacker destinations
   • FTX: 1 withdrawal to Original Funder (KYC records in Kroll/bankruptcy estate)
   • Gate.io: 1 withdrawal

3. BLACKLIST STATUS
   56 addresses checked — NONE frozen by Circle (USDC) or Tether (USDT)
   The attacker can still freely move all USDC and USDT

4. ATTACKER IS ACTIVE NOW
   211 new transactions across 7 wallets in the last 48 hours
   POI wallet made a transaction hours ago
   FXUSD Source received ~500K FXUSD and is actively distributing
   Relay proxy infrastructure fully operational (30+ relays)

5. ORIGINAL FUNDER TRACED
   0x423d2b61... — Airdrop farmer pattern (March–July 2022)
   FTX withdrawal in May 2022 (KYC records available via Kroll)
   First funded by 0xaa364c1A... (experienced DeFi user)

══════════════════════════════════════════════════════════════════
FXUSD ANCHOR CHAIN (verified by victim's tracking team)
══════════════════════════════════════════════════════════════════

FXUSD SOURCE (0xD14F4B36...)
  ↓ 155,092 FXUSD via relay() call
Relay Proxy (0x6818809E...) — ERC1967Proxy, ZK proof relay
  ↓ 155,092 FXUSD
Crypto.com Suspect (0x65837061...)
  ↓ CoW Swap (GPv2Settlement)
155,017 USDC — sitting in suspect wallet NOW

══════════════════════════════════════════════════════════════════
ATTACHED FILES (${available.length} reports in ZIP)
══════════════════════════════════════════════════════════════════

${available.map((f, i) => `  ${i+1}. ${f.name}`).join("\n")}

Total: 64 wallets traced, 1,435+ transactions, 5 KYC exchanges,
35 exchange interactions, 56 blacklist checks, 211 recent TXs

══════════════════════════════════════════════════════════════════
SUBPOENA TARGETS (Priority Order)
══════════════════════════════════════════════════════════════════

1. Binance — law-enforcement@binance.com
   5 wallets with 25 deposits (primary cash-out)

2. Crypto.com — compliance@crypto.com
   Foris DAX MT Ltd. (Malta/Singapore)
   KYC'd wallet holding $155K USDC

3. Circle — compliance@circle.com
   Emergency blacklist request for 0x658370618BBc...

4. Coinbase — law-enforcement@coinbase.com
   2 withdrawals to attacker destinations

5. FTX Estate — Kroll
   KYC records for Original Funder withdrawal (May 2022)

6. Gate.io — support@gate.io
   1 withdrawal to destination wallet

══════════════════════════════════════════════════════════════════

The victim (@sillytuna) has been copied on all of these findings.
All TX hashes are independently verifiable on etherscan.io and blockscout.com.

We are available for any follow-up questions or additional analysis.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
https://alphaunlimitedtrading.com/law-enforcement-tech

CONFIDENTIAL — For authorized security researchers and law enforcement only.
© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
`;

  await client.send({
    to: TO,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: SUBJECT,
    text: emailBody,
    attachments: [{
      content: zipBuf.toString("base64"),
      filename: `Sillytuna-Complete-Forensic-Package-${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[ForwardSEAL] ✓ Email sent to ${TO}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "report_sent",
    severity: "critical",
    message: `Complete forensic evidence package forwarded to SEAL 911 (${TO}) — ${available.length} reports, ${zipKb} KB ZIP`,
    walletAddress: "system",
    details: {
      recipientEmail: TO,
      fromAddress: fromEmail,
      subject: SUBJECT,
      zipSizeKb: zipKb,
      filesIncluded: available.map(f => f.name),
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("[ForwardSEAL] Done. Alert logged.");
  process.exit(0);
}
main().catch(e => { console.error("FATAL:", e); process.exit(1); });
