import { db } from "../db.js";
import { eq, desc } from "drizzle-orm";
import {
  forensicCases, monitoredWallets, forensicAlerts,
  freezeRequests, bountyAgreements, recoveryEvents, tracedTransactions
} from "@shared/schema";
import { getUncachableSendGridClient } from "../services/sendgridService.js";
import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENT_EMAIL = "sillytuna@gmail.com";
const RECIPIENT_NAME = "sillytuna";
const STABLECOIN_SYMBOLS = ["USDC", "USDT", "DAI", "USDE", "PYUSD", "MUSD", "sDAI", "LUSD", "BUSD", "TUSD", "FXUSD"];

function computeWalletValue(w: typeof monitoredWallets.$inferSelect): number {
  let val = w.lastKnownBalanceUsd || 0;
  const tokens = (w.lastKnownTokens || {}) as Record<string, number>;
  for (const [sym, amount] of Object.entries(tokens)) {
    if (STABLECOIN_SYMBOLS.includes(sym)) val += amount;
  }
  return val;
}

function fmtUsd(n: number): string {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtAddr(addr: string): string {
  if (!addr || addr.length < 14) return addr;
  return addr.slice(0, 8) + "..." + addr.slice(-6);
}

async function main() {
  console.log("[SendReport] Starting comprehensive forensic report generation...");

  const caseData = (await db.select().from(forensicCases).where(eq(forensicCases.id, CASE_ID)).limit(1))[0];
  if (!caseData) { console.error("Case not found"); process.exit(1); }
  console.log(`[SendReport] Case: ${caseData.caseName}`);

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  const alerts = await db.select().from(forensicAlerts).where(eq(forensicAlerts.caseId, CASE_ID)).orderBy(desc(forensicAlerts.createdAt));
  const freezeReqs = await db.select().from(freezeRequests).where(eq(freezeRequests.caseId, CASE_ID));
  const agreements = await db.select().from(bountyAgreements).where(eq(bountyAgreements.caseId, CASE_ID));

  let allTxs: any[] = [];
  try {
    allTxs = await db.select().from(tracedTransactions).where(eq(tracedTransactions.caseId, CASE_ID)).orderBy(desc(tracedTransactions.timestamp)).limit(10000);
  } catch {}

  console.log(`[SendReport] DB data: ${wallets.length} wallets, ${alerts.length} alerts, ${freezeReqs.length} freeze reqs, ${agreements.length} agreements, ${allTxs.length} traced txs`);

  const autoDiscoveredRoles = ["token_recipient", "token_sender"];
  const coreWallets = wallets.filter(w => !autoDiscoveredRoles.includes(w.role || ""));
  const discoveredWallets = wallets.filter(w => autoDiscoveredRoles.includes(w.role || ""));

  const victimWallets = coreWallets.filter(w => (w.role || "").toLowerCase().includes("victim"));
  const poiWallets = coreWallets.filter(w => ["poi", "attacker"].some(r => (w.role || "").toLowerCase().includes(r)) || (w.label || "").toLowerCase().includes("person of interest"));
  const otherCoreWallets = coreWallets.filter(w => !victimWallets.includes(w) && !poiWallets.includes(w));
  const sortedAlerts = [...alerts].sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());

  let coreHoldings = 0;
  for (const w of coreWallets) coreHoldings += computeWalletValue(w);
  let discoveredHoldings = 0;
  for (const w of discoveredWallets) discoveredHoldings += computeWalletValue(w);

  const exchangeMap = new Map<string, { deposits: number; withdrawals: number; txCount: number }>();
  for (const tx of allTxs) {
    if (!tx.exchangeName) continue;
    if (!exchangeMap.has(tx.exchangeName)) {
      exchangeMap.set(tx.exchangeName, { deposits: 0, withdrawals: 0, txCount: 0 });
    }
    const ex = exchangeMap.get(tx.exchangeName)!;
    ex.txCount++;
    const usd = parseFloat(tx.amountUsd || "0");
    if (tx.direction === "outbound") ex.deposits += usd;
    else ex.withdrawals += usd;
  }

  let exchangeDepositsTotal = 0;
  for (const [, data] of exchangeMap) exchangeDepositsTotal += data.deposits;

  const totalStolen = (caseData.totalStolenUsd as number) || 0;
  const totalRecovered = (caseData.totalRecoveredUsd as number) || 0;

  const tmpDir = `/tmp/forensic_report_${Date.now()}`;
  const safeName = (caseData.caseName || "case").replace(/[^a-zA-Z0-9_-]/g, "_");
  const reportDir = path.join(tmpDir, safeName);
  fs.mkdirSync(reportDir, { recursive: true });

  const n: string[] = [];
  n.push("╔" + "═".repeat(70) + "╗");
  n.push("║  ALPHA UNLIMITED TRADING COMPANY                                    ║");
  n.push("║  FORENSIC INTELLIGENCE ENGINE™ — COMPREHENSIVE INVESTIGATION REPORT ║");
  n.push("╚" + "═".repeat(70) + "╝");
  n.push("");
  n.push(`  Case:       ${caseData.caseName}`);
  n.push(`  Case ID:    ${caseData.id}`);
  n.push(`  Generated:  ${new Date().toISOString()}`);
  n.push(`  Status:     ${(caseData.status || "active").toUpperCase()}`);
  n.push("");
  n.push("═".repeat(72));
  n.push("  1. EXECUTIVE SUMMARY");
  n.push("═".repeat(72));
  n.push("");
  n.push(`  Victim:              ${caseData.victimHandle || "N/A"}`);
  n.push(`  Victim Wallet:       ${caseData.victimAddress || "N/A"}`);
  n.push(`  Investigation Start: ${caseData.createdAt}`);
  n.push(`  Chains Involved:     ${caseData.chains || "ethereum"}`);
  n.push("");
  n.push("  ┌─────────────────────────────────────────────────────┐");
  n.push(`  │  TOTAL STOLEN (Estimated):      ${fmtUsd(totalStolen).padStart(18)}  │`);
  n.push(`  │  TOTAL RECOVERED:               ${fmtUsd(totalRecovered).padStart(18)}  │`);
  n.push("  ├─────────────────────────────────────────────────────┤");
  n.push(`  │  Core Wallet Holdings:           ${fmtUsd(coreHoldings).padStart(18)}  │`);
  n.push(`  │    (${coreWallets.length} wallets directly linked to theft)           │`);
  n.push(`  │  Recipient Wallet Holdings:      ${fmtUsd(discoveredHoldings).padStart(18)}  │`);
  n.push(`  │    (${discoveredWallets.length} wallets receiving funds from core)      │`);
  n.push(`  │  Deposited to Exchanges:         ${fmtUsd(exchangeDepositsTotal).padStart(18)}  │`);
  n.push("  ├─────────────────────────────────────────────────────┤");
  n.push(`  │  Wallets Monitored:              ${String(wallets.length).padStart(18)}  │`);
  n.push(`  │  Forensic Alerts:                ${String(alerts.length).padStart(18)}  │`);
  n.push(`  │  Freeze Requests Filed:          ${String(freezeReqs.length).padStart(18)}  │`);
  n.push(`  │  Traced Transactions:            ${String(allTxs.length).padStart(18)}  │`);
  n.push("  └─────────────────────────────────────────────────────┘");
  n.push("");

  n.push("═".repeat(72));
  n.push("  2. WHERE IS THE MONEY NOW? — FUND FLOW BREAKDOWN");
  n.push("═".repeat(72));
  n.push("");
  n.push("  This section explains where the stolen funds have moved:");
  n.push("");
  n.push(`  STOLEN: ${fmtUsd(totalStolen)}`);
  n.push("    │");
  n.push("    ├── Core wallets (attacker-controlled):");
  n.push(`    │     ${coreWallets.length} wallets holding ${fmtUsd(coreHoldings)}`);
  n.push("    │");
  n.push("    ├── Forwarded to recipient wallets:");
  n.push(`    │     ${discoveredWallets.length} wallets holding ${fmtUsd(discoveredHoldings)}`);
  n.push("    │     (These are wallets that received transfers from core wallets.");
  n.push("    │      Our system automatically discovered and started tracking them.)");
  n.push("    │");
  if (exchangeMap.size > 0) {
    n.push("    ├── Deposited to exchanges:");
    for (const [name, data] of Array.from(exchangeMap.entries()).sort(([, a], [, b]) => b.deposits - a.deposits)) {
      n.push(`    │     ${name}: ${fmtUsd(data.deposits)} deposited (${data.txCount} transactions)`);
    }
    n.push("    │");
  }
  n.push(`    └── Recovered: ${fmtUsd(totalRecovered)}`);
  n.push("");

  n.push("═".repeat(72));
  n.push("  3. PERSON OF INTEREST / ATTACKER WALLETS");
  n.push("═".repeat(72));
  n.push("");
  if (poiWallets.length > 0) {
    for (const w of poiWallets) {
      const val = computeWalletValue(w);
      n.push(`  ┌── ${w.address}`);
      n.push(`  │   Chain: ${w.chain} | Role: ${w.role || "N/A"}`);
      n.push(`  │   Label: ${w.label || "N/A"}`);
      n.push(`  │   Balance: ${(w.lastKnownBalanceEth || 0).toFixed(6)} native (${fmtUsd(val)})`);
      if (w.lastKnownTokens && typeof w.lastKnownTokens === "object") {
        const tokens = Object.entries(w.lastKnownTokens as Record<string, number>).filter(([, v]) => v > 0.001);
        if (tokens.length > 0) {
          n.push(`  │   Tokens: ${tokens.map(([s, v]) => `${v.toFixed(4)} ${s}`).join(", ")}`);
        }
      }
      n.push(`  │   First Seen: ${w.firstSeen || "N/A"}`);
      n.push(`  │   Last Activity: ${w.lastActivity || "N/A"}`);
      n.push(`  └── Status: ${w.status}`);
      n.push("");
    }
  } else {
    n.push("  No POI wallets identified yet.");
    n.push("");
  }

  n.push("═".repeat(72));
  n.push("  4. VICTIM WALLETS");
  n.push("═".repeat(72));
  n.push("");
  if (victimWallets.length > 0) {
    for (const w of victimWallets) {
      n.push(`  ${w.address} — ${w.chain}`);
      n.push(`    ${w.label || "Victim"} — ${fmtUsd(w.lastKnownBalanceUsd || 0)}`);
      n.push("");
    }
  } else {
    n.push("  No victim wallets recorded.");
    n.push("");
  }

  n.push("═".repeat(72));
  n.push("  5. OTHER CORE WALLETS (Intermediary / Relay / Split)");
  n.push("═".repeat(72));
  n.push("");
  if (otherCoreWallets.length > 0) {
    for (const w of otherCoreWallets) {
      const val = computeWalletValue(w);
      n.push(`  ${w.address}`);
      n.push(`    Chain: ${w.chain} | Role: ${w.role || "N/A"} | Label: ${w.label || "N/A"}`);
      n.push(`    Balance: ${(w.lastKnownBalanceEth || 0).toFixed(6)} native (${fmtUsd(val)}) | Status: ${w.status}`);
      if (w.lastKnownTokens && typeof w.lastKnownTokens === "object") {
        const tokens = Object.entries(w.lastKnownTokens as Record<string, number>).filter(([, v]) => v > 0.001);
        if (tokens.length > 0) n.push(`    Tokens: ${tokens.map(([s, v]) => `${v.toFixed(4)} ${s}`).join(", ")}`);
      }
      n.push("");
    }
  } else {
    n.push("  No additional core wallets.");
    n.push("");
  }

  if (discoveredWallets.length > 0) {
    n.push("═".repeat(72));
    n.push(`  6. DISCOVERED RECIPIENT WALLETS (${discoveredWallets.length} auto-tracked)`);
    n.push("═".repeat(72));
    n.push("");
    n.push("  These wallets were automatically discovered when core wallets sent");
    n.push("  funds to them. They are being continuously monitored for further");
    n.push("  movement, exchange deposits, or return of funds.");
    n.push("");

    const significantDiscovered = discoveredWallets
      .map(w => ({ wallet: w, value: computeWalletValue(w) }))
      .sort((a, b) => b.value - a.value);

    const withBalance = significantDiscovered.filter(d => d.value > 0.01);
    const withoutBalance = significantDiscovered.filter(d => d.value <= 0.01);

    if (withBalance.length > 0) {
      n.push(`  --- Holding Funds (${withBalance.length} wallets, ${fmtUsd(withBalance.reduce((s, d) => s + d.value, 0))}) ---`);
      n.push("");
      for (const { wallet: w, value } of withBalance.slice(0, 50)) {
        n.push(`  ${w.address} (${w.chain})`);
        n.push(`    ${w.label || "Token Recipient"} — ${fmtUsd(value)}`);
        if (w.lastKnownTokens && typeof w.lastKnownTokens === "object") {
          const tokens = Object.entries(w.lastKnownTokens as Record<string, number>).filter(([, v]) => v > 0.001);
          if (tokens.length > 0) n.push(`    Tokens: ${tokens.map(([s, v]) => `${v.toFixed(2)} ${s}`).join(", ")}`);
        }
        n.push("");
      }
      if (withBalance.length > 50) {
        n.push(`  ... and ${withBalance.length - 50} more wallets holding funds`);
        n.push("");
      }
    }

    if (withoutBalance.length > 0) {
      n.push(`  --- Empty / Drained (${withoutBalance.length} wallets) ---`);
      n.push(`  These wallets received funds but have since moved them elsewhere.`);
      n.push(`  (Full list in WALLETS.csv attachment)`);
      n.push("");
    }
  }

  n.push("═".repeat(72));
  n.push("  7. COMPLETE ALERT TIMELINE");
  n.push("═".repeat(72));
  n.push("");
  const criticalAlerts = sortedAlerts.filter(a => a.severity === "critical");
  const highAlerts = sortedAlerts.filter(a => a.severity === "high");
  const otherAlerts = sortedAlerts.filter(a => !["critical", "high"].includes(a.severity || ""));

  if (criticalAlerts.length > 0) {
    n.push(`  --- CRITICAL ALERTS (${criticalAlerts.length}) ---`);
    for (const a of criticalAlerts) {
      n.push(`  [${new Date(a.createdAt!).toISOString()}] ${a.alertType}: ${a.message}`);
      if (a.walletAddress && a.walletAddress !== "system") n.push(`    Wallet: ${a.walletAddress}`);
    }
    n.push("");
  }

  if (highAlerts.length > 0) {
    n.push(`  --- HIGH PRIORITY (${highAlerts.length}) ---`);
    for (const a of highAlerts.slice(0, 100)) {
      n.push(`  [${new Date(a.createdAt!).toISOString()}] ${a.alertType}: ${a.message}`);
    }
    if (highAlerts.length > 100) n.push(`  ... and ${highAlerts.length - 100} more`);
    n.push("");
  }

  if (otherAlerts.length > 0) {
    n.push(`  --- OTHER ALERTS (${otherAlerts.length}) ---`);
    for (const a of otherAlerts.slice(0, 200)) {
      n.push(`  [${new Date(a.createdAt!).toISOString()}] [${(a.severity || "info").toUpperCase()}] ${a.alertType}: ${a.message}`);
    }
    if (otherAlerts.length > 200) n.push(`  ... and ${otherAlerts.length - 200} more`);
    n.push("");
  }

  n.push("═".repeat(72));
  n.push("  8. EXCHANGE FREEZE REQUESTS");
  n.push("═".repeat(72));
  n.push("");
  if (freezeReqs.length > 0) {
    for (const fr of freezeReqs) {
      n.push(`  Exchange: ${fr.exchangeName}`);
      n.push(`  Wallet: ${fr.walletAddress}`);
      n.push(`  Chain: ${fr.chain} | Status: ${fr.status}`);
      n.push(`  Estimated Value: ${fmtUsd((fr.estimatedValueUsd as number) || 0)}`);
      n.push(`  Filed: ${fr.createdAt}`);
      n.push("");
    }
  } else {
    n.push("  No formal exchange freeze requests have been filed yet.");
    n.push("  Freeze requests will be filed as attacker funds are located on exchanges.");
    n.push("");
  }

  n.push("═".repeat(72));
  n.push("  9. TECHNOLOGIES DEPLOYED");
  n.push("═".repeat(72));
  n.push("");
  n.push("  Active technologies monitoring this case:");
  n.push("  [x] Alpha Forensic Intelligence Engine™");
  n.push("  [x] Autonomous Spider Trace™ — Recursive fund flow mapping");
  n.push("  [x] Alpha Transaction Origin Intelligence™");
  n.push("  [x] Alpha Spider Beacon Protocol™ — Cross-chain surveillance");
  n.push("  [x] Wallet Monitor Service — Real-time balance tracking (core wallets every 15s)");
  n.push("  [x] Token Flow Tracer — Auto-discovery of recipient wallets");
  n.push("  [x] Exchange Deposit Detection — Identifies liquidation attempts");
  n.push("  [x] Laundering Risk Intelligence — Tornado Cash, Monero, DeFi gap analysis");
  n.push("  [x] Alpha Phantom Vault Protocol™ — Honeypot decoy wallets");
  n.push("  [x] Cross-Case Intelligence Engine");
  n.push("");

  n.push("═".repeat(72));
  n.push("  10. RECOMMENDATIONS & NEXT STEPS");
  n.push("═".repeat(72));
  n.push("");
  n.push("  1. PRESERVE all evidence — do NOT interact with attacker wallets");
  n.push("  2. FILE a police report with local law enforcement immediately");
  n.push("  3. FORWARD this report to law enforcement as supporting evidence");
  n.push("  4. CONTACT exchanges where attacker funds are located to request freezes");
  n.push("  5. DO NOT contact the attacker directly — this could compromise the investigation");
  n.push("  6. SIGN the Recovery Bounty Agreement to formalize the investigation");
  n.push("");
  n.push("═".repeat(72));
  n.push("  CONFIDENTIAL — FOR VICTIM AND LAW ENFORCEMENT USE ONLY");
  n.push("  Alpha Unlimited Trading Company | Forensic Intelligence Division");
  n.push(`  Report Date: ${new Date().toISOString()}`);
  n.push("  © 2024-2026 All Rights Reserved");
  n.push("═".repeat(72));

  fs.writeFileSync(path.join(reportDir, "INVESTIGATION-NARRATIVE.txt"), n.join("\n"));
  console.log("[SendReport] INVESTIGATION-NARRATIVE.txt written");

  const csv: string[] = ["Address,Chain,Role,Label,Status,Balance_Native,Balance_USD,Stablecoin_Value,Total_Value,First_Seen,Last_Activity"];
  for (const w of wallets) {
    const stableVal = computeWalletValue(w) - (w.lastKnownBalanceUsd || 0);
    const totalVal = computeWalletValue(w);
    csv.push(`"${w.address}","${w.chain}","${w.role || ""}","${(w.label || "").replace(/"/g, '""')}","${w.status}","${w.lastKnownBalanceEth || 0}","${w.lastKnownBalanceUsd || 0}","${stableVal.toFixed(2)}","${totalVal.toFixed(2)}","${w.firstSeen || ""}","${w.lastActivity || ""}"`);
  }
  fs.writeFileSync(path.join(reportDir, "WALLETS.csv"), csv.join("\n"));

  const aCsv: string[] = ["Timestamp,Severity,Type,Message,Wallet_Address"];
  for (const a of sortedAlerts) {
    aCsv.push(`"${new Date(a.createdAt!).toISOString()}","${a.severity || "info"}","${a.alertType || ""}","${(a.message || "").replace(/"/g, '""')}","${a.walletAddress || ""}"`);
  }
  fs.writeFileSync(path.join(reportDir, "ALERTS.csv"), aCsv.join("\n"));

  if (agreements.length > 0) {
    fs.writeFileSync(path.join(reportDir, "BOUNTY-AGREEMENT.txt"), agreements[0].agreementText);
  }

  if (freezeReqs.length > 0) {
    fs.writeFileSync(path.join(reportDir, "FREEZE-REQUESTS.json"), JSON.stringify(freezeReqs, null, 2));
  }

  const fundFlow = {
    summary: {
      totalStolen: fmtUsd(totalStolen),
      totalRecovered: fmtUsd(totalRecovered),
      coreWalletHoldings: { count: coreWallets.length, value: fmtUsd(coreHoldings) },
      discoveredWalletHoldings: { count: discoveredWallets.length, value: fmtUsd(discoveredHoldings) },
      exchangeDeposits: fmtUsd(exchangeDepositsTotal),
      allWalletsUnderSurveillance: wallets.length,
    },
    exchanges: Object.fromEntries(exchangeMap),
    coreWallets: coreWallets.map(w => ({
      address: w.address, chain: w.chain, role: w.role, label: w.label,
      status: w.status, balanceEth: w.lastKnownBalanceEth, totalValueUsd: computeWalletValue(w),
      tokens: w.lastKnownTokens, firstSeen: w.firstSeen, lastActivity: w.lastActivity
    })),
    discoveredWallets: discoveredWallets
      .map(w => ({
        address: w.address, chain: w.chain, role: w.role, label: w.label,
        totalValueUsd: computeWalletValue(w),
        tokens: w.lastKnownTokens, lastActivity: w.lastActivity
      }))
      .sort((a, b) => b.totalValueUsd - a.totalValueUsd)
  };
  fs.writeFileSync(path.join(reportDir, "FUND-FLOW.json"), JSON.stringify(fundFlow, null, 2));

  console.log("[SendReport] All files written to disk. Creating ZIP...");

  const zipPath = `${tmpDir}/Forensic_Report_${safeName}_${new Date().toISOString().split("T")[0]}.zip`;
  execSync(`cd "${tmpDir}" && zip -9 -r "${zipPath}" "${safeName}/"`, { timeout: 15000 });

  const zipBuffer = fs.readFileSync(zipPath);
  const zipBase64 = zipBuffer.toString("base64");
  console.log(`[SendReport] ZIP created: ${(zipBuffer.length / 1024).toFixed(1)} KB`);

  const { client, fromEmail } = await getUncachableSendGridClient();
  console.log(`[SendReport] Sending from ${fromEmail} to ${RECIPIENT_EMAIL}...`);

  const htmlEmail = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background-color:#0a0e17;font-family:Arial,Helvetica,sans-serif;color:#e5e7eb;">
<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0a0e17;padding:20px 0;">
<tr><td align="center">
<table width="640" cellpadding="0" cellspacing="0" style="max-width:640px;width:100%;">

<!-- Header -->
<tr><td style="background:linear-gradient(135deg,#0e1a2e,#1a2744);padding:28px 32px;border-radius:12px 12px 0 0;border-bottom:2px solid #06b6d4;">
  <h1 style="margin:0;font-size:24px;color:#06b6d4;">Alpha Unlimited Trading</h1>
  <p style="margin:4px 0 0;color:#9ca3af;font-size:14px;">Forensic Intelligence Engine™ — Comprehensive Investigation Report</p>
</td></tr>

<!-- Case Info -->
<tr><td style="background-color:#111827;padding:20px 32px;">
  <table width="100%" style="font-size:14px;">
    <tr><td style="color:#9ca3af;width:140px;">Case</td><td style="color:#e5e7eb;font-weight:bold;">${caseData.caseName}</td></tr>
    <tr><td style="color:#9ca3af;">Status</td><td><span style="background:#065f46;color:#10b981;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:bold;">${(caseData.status || "ACTIVE").toUpperCase()}</span></td></tr>
    <tr><td style="color:#9ca3af;">Investigation Since</td><td style="color:#e5e7eb;">${new Date(caseData.createdAt!).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</td></tr>
    <tr><td style="color:#9ca3af;">Victim</td><td style="color:#e5e7eb;">${caseData.victimHandle || "N/A"}</td></tr>
    <tr><td style="color:#9ca3af;">Report Generated</td><td style="color:#e5e7eb;">${new Date().toLocaleString("en-US", { timeZone: "UTC", year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })} UTC</td></tr>
  </table>
</td></tr>

<!-- Fund Flow Summary -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:18px;margin:0 0 20px 0;">Where Is the Money Now?</h2>

  <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
    <tr><td style="background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:16px;text-align:center;">
      <div style="color:#9ca3af;font-size:12px;text-transform:uppercase;letter-spacing:1px;">Total Stolen (Estimated)</div>
      <div style="color:#ef4444;font-size:28px;font-weight:bold;margin:4px 0;">${fmtUsd(totalStolen)}</div>
    </td></tr>
  </table>

  <table width="100%" cellpadding="8" cellspacing="8">
    <tr>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:11px;text-transform:uppercase;">Core Wallets (${coreWallets.length})</div>
        <div style="color:#f97316;font-size:20px;font-weight:bold;">${fmtUsd(coreHoldings)}</div>
        <div style="color:#6b7280;font-size:11px;">Attacker-controlled</div>
      </td>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:11px;text-transform:uppercase;">Recipient Wallets (${discoveredWallets.length})</div>
        <div style="color:#eab308;font-size:20px;font-weight:bold;">${fmtUsd(discoveredHoldings)}</div>
        <div style="color:#6b7280;font-size:11px;">Auto-discovered destinations</div>
      </td>
    </tr>
    <tr>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:11px;text-transform:uppercase;">Exchange Deposits</div>
        <div style="color:#a78bfa;font-size:20px;font-weight:bold;">${fmtUsd(exchangeDepositsTotal)}</div>
        <div style="color:#6b7280;font-size:11px;">Potential liquidation</div>
      </td>
      <td width="50%" style="background:#111827;border:1px solid #1e3a5f;border-radius:8px;padding:14px;text-align:center;">
        <div style="color:#9ca3af;font-size:11px;text-transform:uppercase;">Recovered</div>
        <div style="color:#10b981;font-size:20px;font-weight:bold;">${fmtUsd(totalRecovered)}</div>
        <div style="color:#6b7280;font-size:11px;">Returned or frozen</div>
      </td>
    </tr>
  </table>
</td></tr>

<!-- What's in the ZIP -->
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 16px 0;">📎 Attached Report Package</h2>
  <p style="color:#9ca3af;font-size:13px;margin:0 0 16px 0;">The attached ZIP file contains the complete investigation package:</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;">
    <tr><td style="padding:8px 0;border-bottom:1px solid #1a2744;">
      <span style="color:#06b6d4;font-weight:bold;">INVESTIGATION-NARRATIVE.txt</span><br>
      <span style="color:#9ca3af;">Complete report with executive summary, fund flow breakdown, wallet inventory, alert timeline, and recommendations</span>
    </td></tr>
    <tr><td style="padding:8px 0;border-bottom:1px solid #1a2744;">
      <span style="color:#06b6d4;font-weight:bold;">FUND-FLOW.json</span><br>
      <span style="color:#9ca3af;">Machine-readable fund flow data: core wallets, discovered recipients, exchange deposits, and value breakdowns</span>
    </td></tr>
    <tr><td style="padding:8px 0;border-bottom:1px solid #1a2744;">
      <span style="color:#06b6d4;font-weight:bold;">WALLETS.csv</span><br>
      <span style="color:#9ca3af;">${wallets.length} wallet addresses with balances, roles, and activity timestamps (spreadsheet-ready)</span>
    </td></tr>
    <tr><td style="padding:8px 0;border-bottom:1px solid #1a2744;">
      <span style="color:#06b6d4;font-weight:bold;">ALERTS.csv</span><br>
      <span style="color:#9ca3af;">${alerts.length} forensic alerts in chronological order</span>
    </td></tr>
    ${agreements.length > 0 ? `<tr><td style="padding:8px 0;border-bottom:1px solid #1a2744;">
      <span style="color:#06b6d4;font-weight:bold;">BOUNTY-AGREEMENT.txt</span><br>
      <span style="color:#9ca3af;">Recovery bounty agreement terms</span>
    </td></tr>` : ""}
    ${freezeReqs.length > 0 ? `<tr><td style="padding:8px 0;">
      <span style="color:#06b6d4;font-weight:bold;">FREEZE-REQUESTS.json</span><br>
      <span style="color:#9ca3af;">${freezeReqs.length} exchange freeze request records</span>
    </td></tr>` : ""}
  </table>
</td></tr>

<!-- Surveillance Stats -->
<tr><td style="background-color:#0d1420;padding:24px 32px;">
  <h2 style="color:#06b6d4;font-size:16px;margin:0 0 16px 0;">📡 Active Surveillance</h2>
  <table width="100%" cellpadding="6" cellspacing="0" style="font-size:13px;">
    <tr><td style="color:#9ca3af;">Total wallets monitored</td><td align="right" style="color:#06b6d4;font-weight:bold;">${wallets.length}</td></tr>
    <tr><td style="color:#9ca3af;">Traced transactions</td><td align="right" style="color:#e5e7eb;">${allTxs.length.toLocaleString()}</td></tr>
    <tr><td style="color:#9ca3af;">Monitoring frequency</td><td align="right" style="color:#10b981;">Real-time (core wallets every 15s)</td></tr>
    <tr><td style="color:#9ca3af;">Hourly email updates</td><td align="right" style="color:#10b981;">Active</td></tr>
  </table>
</td></tr>

<!-- Next Steps -->
<tr><td style="background-color:#111827;padding:24px 32px;">
  <h2 style="color:#fbbf24;font-size:16px;margin:0 0 16px 0;">⚡ Important Next Steps</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;">
    <tr><td style="padding:8px 0;color:#e5e7eb;">1. <strong>Preserve</strong> all evidence — do NOT interact with attacker wallets</td></tr>
    <tr><td style="padding:8px 0;color:#e5e7eb;">2. <strong>File</strong> a police report with local law enforcement immediately</td></tr>
    <tr><td style="padding:8px 0;color:#e5e7eb;">3. <strong>Forward</strong> this report to law enforcement as supporting evidence</td></tr>
    <tr><td style="padding:8px 0;color:#e5e7eb;">4. <strong>Contact</strong> exchanges where attacker funds are located for freezes</td></tr>
    <tr><td style="padding:8px 0;color:#ef4444;">5. Do <strong>NOT</strong> contact the attacker directly</td></tr>
  </table>
</td></tr>

<!-- Footer -->
<tr><td style="background:#0e1a2e;padding:20px 32px;border-radius:0 0 12px 12px;border-top:1px solid #1e3a5f;text-align:center;">
  <div style="color:#6b7280;font-size:11px;">
    CONFIDENTIAL — For victim and law enforcement use only<br>
    Alpha Unlimited Trading Company — Forensic Intelligence Division<br>
    forensics@alphaunlimitedtrading.com<br>
    © 2024-2026 All Rights Reserved
  </div>
</td></tr>

</table>
</td></tr></table>
</body></html>`;

  const plainEmail = `Dear ${RECIPIENT_NAME},

This is a comprehensive forensic investigation report from Alpha Unlimited Trading.

CASE: ${caseData.caseName}
STATUS: ${(caseData.status || "ACTIVE").toUpperCase()}
INVESTIGATION SINCE: ${new Date(caseData.createdAt!).toLocaleDateString()}

WHERE IS THE MONEY NOW?
━━━━━━━━━━━━━━━━━━━━━
Total Stolen:              ${fmtUsd(totalStolen)}
Core Wallet Holdings:      ${fmtUsd(coreHoldings)} (${coreWallets.length} wallets)
Recipient Wallet Holdings: ${fmtUsd(discoveredHoldings)} (${discoveredWallets.length} auto-discovered)
Exchange Deposits:         ${fmtUsd(exchangeDepositsTotal)}
Recovered:                 ${fmtUsd(totalRecovered)}
Total Wallets Monitored:   ${wallets.length}

ATTACHED FILES:
• INVESTIGATION-NARRATIVE.txt — Full report with fund flow breakdown
• FUND-FLOW.json — Machine-readable fund flow data
• WALLETS.csv — ${wallets.length} wallet addresses (spreadsheet-ready)
• ALERTS.csv — ${alerts.length} forensic alerts
${agreements.length > 0 ? "• BOUNTY-AGREEMENT.txt — Recovery agreement terms\n" : ""}${freezeReqs.length > 0 ? `• FREEZE-REQUESTS.json — ${freezeReqs.length} freeze requests\n` : ""}
NEXT STEPS:
1. Preserve all evidence — do NOT interact with attacker wallets
2. File a police report with local law enforcement
3. Forward this report to law enforcement
4. Do NOT contact the attacker directly

CONFIDENTIAL — For victim and law enforcement use only.

Alpha Unlimited Trading Company
Forensic Intelligence Division
forensics@alphaunlimitedtrading.com
`;

  await client.send({
    to: RECIPIENT_EMAIL,
    from: { email: fromEmail, name: "Alpha Forensic Intelligence" },
    subject: `Forensic Investigation Report — ${caseData.caseName} [CONFIDENTIAL]`,
    text: plainEmail,
    html: htmlEmail,
    attachments: [{
      content: zipBase64,
      filename: `Forensic_Report_${safeName}_${new Date().toISOString().split("T")[0]}.zip`,
      type: "application/zip",
      disposition: "attachment"
    }]
  });

  console.log(`[SendReport] Report sent successfully to ${RECIPIENT_EMAIL} from ${fromEmail}`);

  await db.insert(forensicAlerts).values({
    caseId: CASE_ID,
    alertType: "report_sent",
    severity: "info",
    message: `Comprehensive HTML forensic report sent to ${RECIPIENT_EMAIL} from ${fromEmail} (${(zipBuffer.length / 1024).toFixed(1)} KB)`,
    walletAddress: "system",
    details: {
      recipientEmail: RECIPIENT_EMAIL,
      recipientName: RECIPIENT_NAME,
      fromAddress: fromEmail,
      zipSizeKb: (zipBuffer.length / 1024).toFixed(1),
      walletsIncluded: wallets.length,
      alertsIncluded: alerts.length,
      discoveredWallets: discoveredWallets.length,
      fundFlowIncluded: true,
      sentAt: new Date().toISOString()
    }
  });

  fs.rmSync(tmpDir, { recursive: true, force: true });

  console.log("[SendReport] Done. Alert logged. Temp files cleaned up.");
  process.exit(0);
}

main().catch(e => { console.error("[SendReport] FATAL:", e); process.exit(1); });
