import { db } from "../db.js";
import { sql, eq, desc } from "drizzle-orm";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

async function main() {
  console.log("=== CRYPTO.COM WALLET INVESTIGATION ===\n");

  const cryptoComTxs = await db.execute(sql`
    SELECT * FROM traced_transactions 
    WHERE case_id = ${CASE_ID} 
    AND (exchange_name ILIKE '%crypto.com%' OR to_label ILIKE '%crypto.com%' OR from_label ILIKE '%crypto.com%')
    ORDER BY timestamp DESC
  `);
  const rows = (cryptoComTxs as any).rows || cryptoComTxs;
  console.log(`Found ${rows.length} Crypto.com transactions:\n`);
  
  const addresses = new Set<string>();
  for (const tx of rows) {
    console.log(`TX: ${tx.tx_hash}`);
    console.log(`  Chain: ${tx.chain} | Time: ${tx.timestamp}`);
    console.log(`  From: ${tx.from_address} (${tx.from_label || 'unknown'})`);
    console.log(`  To:   ${tx.to_address} (${tx.to_label || 'unknown'})`);
    console.log(`  Amount: ${tx.amount} ${tx.token_symbol || 'ETH'} ($${tx.amount_usd || '?'})`);
    console.log(`  Direction: ${tx.direction} | Type: ${tx.tx_type}`);
    console.log(`  Exchange: ${tx.exchange_name}`);
    console.log("");
    if (tx.from_address) addresses.add(tx.from_address.toLowerCase());
    if (tx.to_address) addresses.add(tx.to_address.toLowerCase());
  }

  console.log("\n=== WALLETS INVOLVED WITH CRYPTO.COM ===\n");
  for (const addr of addresses) {
    const walletRows = await db.execute(sql`
      SELECT * FROM monitored_wallets 
      WHERE LOWER(address) = ${addr} AND case_id = ${CASE_ID}
    `);
    const wallets = (walletRows as any).rows || walletRows;
    if (wallets.length > 0) {
      const w = wallets[0];
      console.log(`Wallet: ${w.address}`);
      console.log(`  Label: ${w.label}`);
      console.log(`  Role: ${w.role}`);
      console.log(`  Chain: ${w.chain}`);
      console.log(`  Balance: ${w.last_known_balance_eth} ETH ($${w.last_known_balance_usd})`);
      console.log(`  Tokens: ${JSON.stringify(w.last_known_tokens)}`);
      console.log(`  Status: ${w.status}`);
      console.log(`  Last Activity: ${w.last_activity}`);
      console.log("");
    }
  }

  console.log("\n=== ALL TRANSACTIONS FOR CRYPTO.COM-LINKED WALLETS ===\n");
  for (const addr of addresses) {
    const allTxsForAddr = await db.execute(sql`
      SELECT * FROM traced_transactions 
      WHERE case_id = ${CASE_ID} 
      AND (LOWER(from_address) = ${addr} OR LOWER(to_address) = ${addr})
      ORDER BY timestamp DESC
    `);
    const txRows = (allTxsForAddr as any).rows || allTxsForAddr;
    if (txRows.length > 0) {
      console.log(`--- ${addr} (${txRows.length} total transactions) ---`);
      for (const tx of txRows) {
        const dir = tx.from_address?.toLowerCase() === addr ? "SENT" : "RECEIVED";
        const other = dir === "SENT" ? `${tx.to_address} (${tx.to_label || '?'})` : `${tx.from_address} (${tx.from_label || '?'})`;
        console.log(`  [${tx.timestamp}] ${dir} ${tx.amount} ${tx.token_symbol || 'ETH'} ($${tx.amount_usd || '?'}) ${dir === 'SENT' ? 'to' : 'from'} ${other} | TX: ${tx.tx_hash}`);
      }
      console.log("");
    }
  }

  console.log("\n=== CHECKING KNOWN CRYPTO.COM HOT WALLETS ===\n");
  const knownCryptoComWallets = [
    { addr: "0x6262998ced04146fa42253a5c0af90ca02dfd2a3", label: "Crypto.com Hot Wallet" },
    { addr: "0x46340b20830761efd32832a74d7169b29feb9758", label: "Crypto.com Hot Wallet 2" },
    { addr: "0xcffad3200574698b78f32232aa9d63eabd290703", label: "Crypto.com" },
    { addr: "0x72a53cdbbcc1b9efa39c834a540550e23463aacb", label: "Crypto.com Exchange" },
  ];
  
  for (const cw of knownCryptoComWallets) {
    const hits = await db.execute(sql`
      SELECT * FROM traced_transactions 
      WHERE case_id = ${CASE_ID} 
      AND (LOWER(from_address) = ${cw.addr.toLowerCase()} OR LOWER(to_address) = ${cw.addr.toLowerCase()})
      ORDER BY timestamp DESC
    `);
    const hitRows = (hits as any).rows || hits;
    if (hitRows.length > 0) {
      console.log(`${cw.label} (${cw.addr}): ${hitRows.length} transactions`);
      for (const tx of hitRows) {
        console.log(`  [${tx.timestamp}] ${tx.from_address} -> ${tx.to_address} | ${tx.amount} ${tx.token_symbol || 'ETH'} ($${tx.amount_usd})`);
      }
      console.log("");
    }
  }

  console.log("\n=== CHECKING ALERTS RELATED TO CRYPTO.COM ===\n");
  const cryptoAlerts = await db.execute(sql`
    SELECT * FROM forensic_alerts 
    WHERE case_id = ${CASE_ID} 
    AND (message ILIKE '%crypto.com%' OR message ILIKE '%cryptocom%')
    ORDER BY created_at DESC
  `);
  const alertRows = (cryptoAlerts as any).rows || cryptoAlerts;
  console.log(`Found ${alertRows.length} Crypto.com-related alerts:`);
  for (const a of alertRows) {
    console.log(`  [${a.created_at}] [${a.alert_type}] ${a.message}`);
    if (a.wallet_address) console.log(`    Wallet: ${a.wallet_address}`);
  }

  process.exit(0);
}
main();
