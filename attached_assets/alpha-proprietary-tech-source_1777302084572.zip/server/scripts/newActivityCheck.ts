/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_NEW_ACTIVITY_v1.0
 * ALPHA_INTEGRITY_SEAL: AUT_NewActivity_Calibration_PROTECTED
 */

const BE = "https://eth.blockscout.com/api/v2";
const ARB = "https://arbitrum.blockscout.com/api/v2";

const WALLETS = [
  { addr: "0x658370618bbc885865df66c1061bfe4771fad846", label: "Crypto.com Suspect ($155K USDC)", chain: "eth" },
  { addr: "0xD14F4B36E1D1D98c218db782c49149876042BC56", label: "FXUSD Source", chain: "eth" },
  { addr: "0x6818809EefCe719E480a7526D76bD3e561526b46", label: "Relay Proxy", chain: "eth" },
  { addr: "0xf70da97812cb96acdf810712aa562db8dfa3dbef", label: "POI / GFF ($4.35M)", chain: "eth" },
  { addr: "0x0D5c41C609Fe1Ec073C3b4Fa10949d602Ed059Bb", label: "Source Wallet (EIP-7702)", chain: "eth" },
  { addr: "0xb01FEd2f701695992A4F7ffdB53f3aF099e140d7", label: "Gas Funder", chain: "eth" },
  { addr: "0xb98E8eeFBa0f7476B85Cd9716Cb5b38a935AA872", label: "Laundering Hub ($20M DAI)", chain: "eth" },
  { addr: "0x423d2b61952d56358db8b313ec7404a9582d4865", label: "Original Funder", chain: "eth" },
  { addr: "0xd8cFAaceB9719d7c5c68c0AD876E619C180770c6", label: "Hub DAI Dispersal", chain: "eth" },
  { addr: "0x6fe0fab2164d8e0d03ad6a628e2af78624060322", label: "Victim Wallet", chain: "eth" },
  { addr: "0x7f72c73dc7d3badb2000edb1e11135eaae33cc2c", label: "Binance Depositor (Destination)", chain: "eth" },
];

async function api(url: string) {
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

// Only show transactions from last 48 hours
const CUTOFF = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();

async function main() {
  console.log(`\n═══ NEW ACTIVITY CHECK — ${new Date().toISOString()} ═══`);
  console.log(`Looking for activity since: ${CUTOFF}\n`);

  let totalNew = 0;

  for (const w of WALLETS) {
    const base = w.chain === "arb" ? ARB : BE;
    const addr = w.addr.toLowerCase();

    // Check ETH txs
    const txs = await api(`${base}/addresses/${addr}/transactions`);
    await sleep(150);
    
    const newTxs: any[] = [];
    if (txs?.items) {
      for (const tx of txs.items) {
        if (tx.timestamp && tx.timestamp > CUTOFF) {
          newTxs.push(tx);
        }
      }
    }

    // Check token transfers
    const tokens = await api(`${base}/addresses/${addr}/token-transfers`);
    await sleep(150);
    
    const newTokens: any[] = [];
    if (tokens?.items) {
      for (const tt of tokens.items) {
        if (tt.timestamp && tt.timestamp > CUTOFF) {
          newTokens.push(tt);
        }
      }
    }

    if (newTxs.length === 0 && newTokens.length === 0) {
      console.log(`  ✓ ${w.label} — No new activity`);
      continue;
    }

    totalNew += newTxs.length + newTokens.length;
    console.log(`\n  ★★★ ${w.label} — NEW ACTIVITY DETECTED ★★★`);
    console.log(`  Wallet: ${w.addr}\n`);

    for (const tx of newTxs) {
      const from = tx.from?.hash || "";
      const to = tx.to?.hash || "";
      const fromName = tx.from?.name || "";
      const toName = tx.to?.name || "";
      const val = parseInt(tx.value || "0") / 1e18;
      const dir = from.toLowerCase() === addr ? "OUT →" : "IN  ←";
      const counterparty = from.toLowerCase() === addr ? `${to} ${toName}` : `${from} ${fromName}`;
      console.log(`    ${tx.timestamp}  ${dir}  ${val.toFixed(8)} ETH`);
      console.log(`      ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
      console.log(`      TX: ${tx.hash}`);
      console.log("");
    }

    for (const tt of newTokens) {
      const from = tt.from?.hash || "";
      const to = tt.to?.hash || "";
      const fromName = tt.from?.name || "";
      const toName = tt.to?.name || "";
      const sym = tt.token?.symbol || "???";
      const dec = parseInt(tt.token?.decimals || "18");
      const amt = parseFloat(tt.total?.value || "0") / Math.pow(10, dec);
      const dir = from.toLowerCase() === addr ? "OUT →" : "IN  ←";
      const counterparty = from.toLowerCase() === addr ? `${to} ${toName}` : `${from} ${fromName}`;
      console.log(`    ${tt.timestamp}  ${dir}  ${amt.toFixed(6)} ${sym}`);
      console.log(`      ${dir === "OUT →" ? "To" : "From"}: ${counterparty}`);
      console.log(`      TX: ${tt.transaction_hash || ""}`);
      console.log("");
    }
  }

  console.log(`\n═══ SUMMARY ═══`);
  console.log(`Wallets checked: ${WALLETS.length}`);
  console.log(`New transactions (last 48h): ${totalNew}`);
  if (totalNew === 0) {
    console.log(`\nNo new activity detected across any monitored wallets in the last 48 hours.`);
  }
}
main().catch(e => { console.error(e); process.exit(1); });
