/*
 * Copyright (c) 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * Comprehensive SillyTuna case forensic run — emails: SillyTuna + Owner + SEAL Team.
 */
import * as fs from 'fs';
import * as path from 'path';
import { getUncachableSendGridClient } from '../services/sendgridService.js';
import {
  runComprehensiveCaseForensics,
  renderComprehensiveHtml,
  type CaseForensicsInput,
} from '../services/comprehensiveCaseForensics.js';

const ATTACKER_WALLETS: Array<{ address: string; label: string; type: string }> = [
  { address: '0x8e04af7f7c76daa9ab429b1340e0327b5b835748', label: 'Cashout Primary (1,634 ETH)', type: 'direct_attacker' },
  { address: '0xa8e1960ab9234f56df6031dde4561a42c15812df', label: 'HOP-1 Relay', type: 'direct_attacker' },
  { address: '0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3', label: 'HOP-4 Consolidation (USDT)', type: 'direct_attacker' },
  { address: '0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73', label: 'OTC/Bridge Service', type: 'shared_service' },
  { address: '0x83d1754dd1315a433461a014da950422905d5ca1', label: 'Address-Sim Relay', type: 'direct_attacker' },
  { address: '0x46af83b6bee9bcfd4d31eed47a8c32adbd410e6b', label: 'Address-Sim Mixer', type: 'direct_attacker' },
  { address: '0x46af8e7a2ee01134d1757bc19607781dbd410e6b', label: 'Circular Mixer', type: 'direct_attacker' },
  { address: '0xb98e8eefba0f7476b85cd9716cb5b38a935aa872', label: 'Main Attacker (hop-1, 490 ETH)', type: 'direct_attacker' },
  { address: '0xd0c2c387a7f10cd1fbb1078facc834ec43c9dd3e', label: 'DAI Laundering Hub', type: 'direct_attacker' },
  { address: '0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4', label: 'DCA Laundering Hub', type: 'direct_attacker' },
  { address: '0x4389070b909ff2a6549f3ca8e42e578e12cf61b6', label: 'USDC Endpoint', type: 'direct_attacker' },
  { address: '0x8e044d1ecebab9b62323ead86917e5123e795748', label: 'Mirror Cashout A', type: 'direct_attacker' },
  { address: '0x8e03a03bb063abd8871cc8e508d9f4506d835748', label: 'Mirror Cashout B', type: 'direct_attacker' },
  { address: '0x4d0f03b83650b33138764aaaf3da76861576ff98', label: 'KYC Bridge Wallet', type: 'intermediary' },
  { address: '0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a', label: 'KYC Bridge Wallet 2', type: 'intermediary' },
  { address: '0x1f04378f94313421ed1faaf4f6415de722bea5ea', label: 'Large-Value Intermediary', type: 'intermediary' },
  { address: '0x5bbea8a4b36d1c897ac89726594ea1ce04608877', label: 'Mule Pattern A', type: 'direct_attacker' },
  { address: '0xb48522f1b6863f897d4a6dd04ef6a16c69499db1', label: 'Mule Pattern B', type: 'direct_attacker' },
  { address: '0xb485a81b220071e00d3ca4730b1ed569fd6dddb1', label: 'Mule Pattern C', type: 'direct_attacker' },
  { address: '0x2cc8d5e64c008f26db42848057519a06191d6f2f', label: 'Mule Pattern D', type: 'direct_attacker' },
  { address: '0x0016e313e598de1af2a67d3c869622a69634430c', label: 'Mule Pattern E', type: 'direct_attacker' },
  { address: '0x9a72643e82b7ed8db3d575c02621e91d8d06ba73', label: 'Address-Sim OTC', type: 'intermediary' },
  { address: '0x80d71876152b781a9b43ae6307819b1d66c0f90a', label: 'Address-Sim KYC', type: 'intermediary' },
  { address: '0x83d7ed598e805ad63ce27d777d8a77d2585d5ca1', label: 'Address-Sim 85%', type: 'direct_attacker' },
  { address: '0x4d0ffe81540f0755d70ede0d7430ae861576ff98', label: 'Address-Sim 100%', type: 'direct_attacker' },
  { address: '0x83d10e4698efb8a0bd3cafad6c950572905d5ca1', label: 'Distribution EOA', type: 'direct_attacker' },
];

const PROJECT_URLS = [
  'https://x.com/sillytuna',
  'https://sillytuna.com',
];

const INTEL_FILES = [
  'contracts/atc/DAUv2_full_trace_results.json',
  'SillyTuna_Forensic/sillytuna_forensic_report.html',
];

const CASE_SUMMARY = `
EIP-7702 delegation-vector exploit (~$26M USD aggregate loss). Victim wallet:
0x6fe0fab2164d8e0d03ad6a628e2af78624060322. Stolen funds traced through 26 attacker
wallets including primary cashout (1,634 ETH), HOP-1/4 relays, DAI/DCA laundering hubs,
and 5 mule patterns. DAU v2 "Dye Pack Protocol"™ beacon deployed; Monero on-ramp
detection layer + cross-chain amount correlation engine active. This package contains
a fresh multi-chain re-scan of all 26 wallets, web-archive forensics of related
project surfaces, and a summary of all on-disk intel.
`.trim();

const RECIPIENTS = [
  { email: 'sillytuna@gmail.com',           name: 'SillyTuna',                       audience: 'sillytuna' as const },
  { email: 'alphaunlimitedtoken@gmail.com', name: 'Alpha Unlimited Token (Owner)',   audience: 'owner-internal' as const },
  { email: 'tips@securityalliance.org',     name: 'SEAL Team',                       audience: 'sealteam' as const },
];

function loadAttachments(reportHtml: string, reportJson: string) {
  const out: Array<{ content: string; filename: string; type: string; disposition: 'attachment' }> = [];
  out.push({
    content: Buffer.from(reportHtml).toString('base64'),
    filename: `SillyTuna-Comprehensive-Forensic-Report-${new Date().toISOString().slice(0,10)}.html`,
    type: 'text/html',
    disposition: 'attachment',
  });
  out.push({
    content: Buffer.from(reportJson).toString('base64'),
    filename: `SillyTuna-Comprehensive-Forensic-Report-${new Date().toISOString().slice(0,10)}.json`,
    type: 'application/json',
    disposition: 'attachment',
  });
  for (const f of INTEL_FILES) {
    const abs = path.resolve(process.cwd(), f);
    if (!fs.existsSync(abs)) { console.log(`  skip (missing): ${f}`); continue; }
    const buf = fs.readFileSync(abs);
    if (buf.length > 14 * 1024 * 1024) { console.log(`  skip (too large): ${f}`); continue; }
    out.push({
      content: buf.toString('base64'),
      filename: path.basename(abs),
      type: f.endsWith('.json') ? 'application/json' : f.endsWith('.html') ? 'text/html' : 'application/octet-stream',
      disposition: 'attachment',
    });
    console.log(`  attached: ${f} (${(buf.length/1024).toFixed(1)} KB)`);
  }
  return out;
}

async function main() {
  console.log('=== SillyTuna — Comprehensive Forensic Run ===');
  console.log(`Wallets: ${ATTACKER_WALLETS.length} · URLs: ${PROJECT_URLS.length}`);

  const input: CaseForensicsInput = {
    caseId: '306db48a',
    caseName: 'SillyTuna EIP-7702 Exploit (~$26M)',
    wallets: ATTACKER_WALLETS,
    projectUrls: PROJECT_URLS,
    chains: ['eth', 'polygon', 'arbitrum', 'optimism', 'base'],
    existingIntelFiles: INTEL_FILES,
    caseSummary: CASE_SUMMARY,
  };

  console.log('Running multi-chain trace + web-archive snapshot…');
  const t0 = Date.now();
  const report = await runComprehensiveCaseForensics(input);
  console.log(`Done in ${((Date.now() - t0)/1000).toFixed(1)}s.`);
  const natStr = Object.entries(report.aggregate.nativeBalanceTotals).map(([s,a]) => `${(a as number).toLocaleString(undefined,{maximumFractionDigits:2})} ${s}`).join(' · ');
  console.log(`  walletsScanned=${report.aggregate.walletsScanned}  natives=[${natStr}]  totalTx=${report.aggregate.totalTx}`);
  console.log(`  archiveTargets=${report.aggregate.archiveTargetsScanned}  flagged=${Object.keys(report.aggregate.flaggedEntityHits).length}`);

  const reportJson = JSON.stringify(report, null, 2);
  const stamp = new Date().toISOString().slice(0,10);
  const outDir = 'private/forensic-reports';
  fs.mkdirSync(outDir, { recursive: true });
  const compJsonPath = path.join(outDir, `sillytuna-comprehensive-${stamp}.json`);
  fs.writeFileSync(compJsonPath, reportJson);
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(compJsonPath, { title: 'SillyTuna — Comprehensive Multi-Chain Re-Scan', caseId: '306db48a', chain: 'multi-chain', direction: 'bidirectional' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  const { client, fromEmail } = await getUncachableSendGridClient();

  for (const r of RECIPIENTS) {
    const html = renderComprehensiveHtml(report, r.audience);
    const subj = r.audience === 'sealteam'
      ? `[Case 306db48a] SillyTuna — Comprehensive Forensic Update (${report.aggregate.walletsScanned} wallets · multi-chain re-scan · ${stamp})`
      : r.audience === 'sillytuna'
      ? `Case Update — Comprehensive Forensic Re-Scan Complete (${report.aggregate.walletsScanned} wallets across 5 chains · ${stamp})`
      : `[INTERNAL] SillyTuna Comprehensive Forensic Report — Owner Copy — ${stamp}`;
    const attachments = loadAttachments(html, reportJson);
    console.log(`→ Sending to ${r.name} <${r.email}> (${attachments.length} attachments)…`);
    try {
      await client.send({
        to: { email: r.email, name: r.name },
        from: { email: fromEmail, name: 'Alpha Unlimited — Forensic Intelligence' },
        subject: subj,
        content: [
          { type: 'text/plain', value: `Comprehensive forensic re-scan attached. See HTML report for details.\n\nGenerated ${report.generatedAt}` },
          { type: 'text/html', value: html },
        ],
        attachments,
      });
      console.log(`  ✅ SENT to ${r.email}`);
    } catch (e: any) {
      console.log(`  ❌ FAILED: ${e?.message || e}`);
      if (e?.response?.body) console.log(`     ${JSON.stringify(e.response.body).slice(0, 500)}`);
    }
  }

  console.log('\n=== Done ===');
}

main().catch(e => { console.error(e); process.exit(1); });
