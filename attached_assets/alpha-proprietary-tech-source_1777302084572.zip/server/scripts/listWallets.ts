import { db } from "../db.js";
import { eq } from "drizzle-orm";
import { monitoredWallets, forensicCases } from "@shared/schema";

async function main() {
  const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
  const caseData = (await db.select().from(forensicCases).where(eq(forensicCases.id, CASE_ID)).limit(1))[0];
  console.log("Victim Address:", caseData.victimAddress);
  console.log("Victim Handle:", caseData.victimHandle);
  console.log("");

  const wallets = await db.select().from(monitoredWallets).where(eq(monitoredWallets.caseId, CASE_ID));
  for (const w of wallets) {
    console.log(`${w.role} | ${w.label} | ${w.address} | ${w.chain} | $${w.lastKnownBalanceUsd || 0}`);
  }
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
