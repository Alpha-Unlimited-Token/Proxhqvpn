import { getUncachableSendGridClient } from "../services/sendgridService.js";

const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";
const RECIPIENTS = [
  { email: "sillytuna@gmail.com", name: "sillytuna (Alex Amsel)" },
  { email: "tips@securityalliance.org", name: "SEAL 911" },
];

async function main() {
  console.log("[SpamPoisoningAlert] Compiling address poisoning & spam token intelligence...\n");

  const now = new Date().toISOString();

  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
<style>
  body { background: #0A1628; color: #E2E8F0; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
  .container { max-width: 700px; margin: 0 auto; padding: 24px; }
  .header { background: linear-gradient(135deg, #0D1117 0%, #152238 100%); border: 1px solid #00D4FF33; border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center; }
  .header h1 { color: #00D4FF; font-size: 20px; margin: 0 0 4px 0; letter-spacing: 2px; }
  .header h2 { color: #FFD700; font-size: 14px; margin: 0 0 8px 0; font-weight: normal; }
  .header .subtitle { color: #94A3B8; font-size: 12px; }
  .section { background: #0D1117; border: 1px solid #1E3A5F; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
  .section h3 { color: #00D4FF; font-size: 15px; margin: 0 0 12px 0; border-bottom: 1px solid #1E3A5F; padding-bottom: 8px; }
  .alert-box { background: #7F1D1D33; border: 1px solid #EF444466; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
  .alert-box h3 { color: #EF4444; border-bottom-color: #EF444444; }
  .warning-box { background: #78350F33; border: 1px solid #F59E0B66; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
  .warning-box h3 { color: #F59E0B; border-bottom-color: #F59E0B44; }
  .info-box { background: #0C4A6E33; border: 1px solid #00D4FF44; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
  .info-box h3 { color: #00D4FF; border-bottom-color: #00D4FF44; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th { background: #152238; color: #00D4FF; padding: 8px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
  td { padding: 8px; border-bottom: 1px solid #1E3A5F; color: #CBD5E1; font-family: 'Courier New', monospace; font-size: 11px; }
  tr:hover td { background: #15223844; }
  .addr { color: #F59E0B; word-break: break-all; }
  .danger { color: #EF4444; font-weight: bold; }
  .success { color: #10B981; }
  .muted { color: #64748B; }
  .hash { color: #818CF8; word-break: break-all; font-size: 10px; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; text-transform: uppercase; }
  .tag-danger { background: #7F1D1D; color: #FCA5A5; }
  .tag-warning { background: #78350F; color: #FCD34D; }
  .tag-spam { background: #312E81; color: #A5B4FC; }
  .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 12px 0; }
  .summary-card { background: #152238; border-radius: 8px; padding: 12px; text-align: center; }
  .summary-card .value { font-size: 24px; font-weight: bold; color: #00D4FF; }
  .summary-card .label { font-size: 11px; color: #64748B; margin-top: 4px; }
  .footer { text-align: center; padding: 20px; color: #475569; font-size: 11px; border-top: 1px solid #1E3A5F; margin-top: 24px; }
  .key-finding { background: #0F172A; border-left: 3px solid #00D4FF; padding: 12px 16px; margin: 8px 0; border-radius: 0 6px 6px 0; }
  .key-finding strong { color: #00D4FF; }
  ul { padding-left: 20px; }
  li { margin-bottom: 6px; color: #94A3B8; font-size: 13px; }
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <h1>ALPHA FORENSIC INTELLIGENCE ENGINE&trade;</h1>
    <h2>ADDRESS POISONING &amp; SPAM TOKEN INTELLIGENCE REPORT</h2>
    <div class="subtitle">
      Case: @sillytuna (Alex Amsel) &mdash; ~$24M EIP-7702 Exploit<br/>
      Case ID: ${CASE_ID}<br/>
      Generated: ${now}<br/>
      Classification: <span class="tag tag-danger">ACTIVE THREAT</span>
    </div>
  </div>

  <div class="alert-box">
    <h3>&#9888; EXECUTIVE SUMMARY</h3>
    <p style="color: #FCA5A5; font-size: 13px; margin: 0 0 12px 0;">
      Since our investigation opened on <strong>March 5, 2026</strong>, the victim wallet has been subjected to
      ongoing <strong>address poisoning attacks</strong> and <strong>spam token airdrops</strong>. These are secondary
      attacks designed to trick the victim into sending funds to lookalike addresses controlled by the attacker.
    </p>
    <div class="summary-grid">
      <div class="summary-card">
        <div class="value" style="color: #EF4444;">0 ETH</div>
        <div class="label">Funds Recovered</div>
      </div>
      <div class="summary-card">
        <div class="value" style="color: #F59E0B;">12</div>
        <div class="label">Malicious Interactions</div>
      </div>
      <div class="summary-card">
        <div class="value" style="color: #EF4444;">7</div>
        <div class="label">Poisoning Addresses</div>
      </div>
      <div class="summary-card">
        <div class="value" style="color: #818CF8;">4</div>
        <div class="label">Spam Token Airdrops</div>
      </div>
    </div>
    <p style="color: #94A3B8; font-size: 12px; margin: 12px 0 0 0;">
      <strong style="color: #EF4444;">Current wallet balance: 0.000045 ETH (~$0.10)</strong> &mdash;
      No legitimate funds have been returned to the victim.
    </p>
  </div>

  <div class="section">
    <h3>SECTION 1: ADDRESS POISONING ATTACKS</h3>
    <p style="color: #94A3B8; font-size: 12px; margin-bottom: 16px;">
      Address poisoning is a social engineering attack where the attacker sends 0-value transactions from addresses
      that share the same prefix/suffix as wallets the victim regularly interacts with. The goal is for the victim to
      accidentally copy the fake address from their transaction history and send real funds to it.
    </p>

    <div class="key-finding">
      <strong>Pattern Identified:</strong> All 7 poisoning addresses share the prefix <code style="color: #F59E0B;">0xb98...</code>
      and suffix <code style="color: #F59E0B;">...a872</code> (or similar variants <code style="color: #F59E0B;">...3872</code>,
      <code style="color: #F59E0B;">...0872</code>). These are vanity-generated addresses crafted to be visually confusable.
    </div>

    <table>
      <thead>
        <tr><th>Date (UTC)</th><th>Poisoning Address</th><th>Value</th><th>Tx Hash</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Mar 15, 06:37</td>
          <td class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</td>
          <td>0 ETH</td>
          <td class="hash">0x2353156a70bd...d343b7</td>
        </tr>
        <tr>
          <td>Mar 15, 06:35</td>
          <td class="addr">0xb98e83d55cb5100789bbaad6380201ed2b96a872</td>
          <td>0 ETH</td>
          <td class="hash">0xb3a52ccac825...fe7db</td>
        </tr>
        <tr>
          <td>Mar 7, 03:38</td>
          <td class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</td>
          <td>0 ETH</td>
          <td class="hash">0xa6a9ba9e10b5...2fd7ba</td>
        </tr>
        <tr>
          <td>Mar 7, 03:21</td>
          <td class="addr">0xb986765a00798135255677066ead4433a3d3a872</td>
          <td>0 ETH</td>
          <td class="hash">0xc5de46b6512a...1182c</td>
        </tr>
      </tbody>
    </table>

    <p style="color: #94A3B8; font-size: 12px; margin-top: 12px;">
      <strong style="color: #F59E0B;">Pre-investigation poisoning addresses</strong> (before March 5) that are part of the same campaign:
    </p>
    <table>
      <thead>
        <tr><th>Date (UTC)</th><th>Poisoning Address</th><th>Value</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Mar 4, 19:15</td>
          <td class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</td>
          <td>0 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 19:12</td>
          <td class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</td>
          <td>0 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 19:11</td>
          <td class="addr">0xb98473857e3aa19006e64a4102e4949ee95c0872</td>
          <td>0 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 18:58</td>
          <td class="addr">0xb98e43afac373d2bad03f13752ce82944237a872</td>
          <td>0 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 18:12</td>
          <td class="addr">0xb98e8eefba0f7476b85cd9716cb5b38a935aa872</td>
          <td>2.332546 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 18:05</td>
          <td class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</td>
          <td>0 ETH</td>
        </tr>
        <tr>
          <td>Mar 4, 18:04</td>
          <td class="addr">0xb9866c85b56b027548dcd0a7d58923f9c7af3872</td>
          <td>0 ETH</td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="warning-box">
    <h3>&#9888; ALL 7 POISONING ADDRESSES (DO NOT INTERACT)</h3>
    <p style="color: #FCD34D; font-size: 12px; margin-bottom: 12px;">
      These addresses are malicious. Do NOT copy or send any funds to them.
    </p>
    <ol style="padding-left: 20px;">
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb98e55091ad6c662c67f5f1fc4fb379c9477a872</code> <span class="tag tag-danger">MOST ACTIVE — 4 txs</span></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb98e83d55cb5100789bbaad6380201ed2b96a872</code></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb986765a00798135255677066ead4433a3d3a872</code></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb98e43afac373d2bad03f13752ce82944237a872</code></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb98e8eefba0f7476b85cd9716cb5b38a935aa872</code> <span class="tag tag-warning">SENT 2.33 ETH BAIT</span></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb9866c85b56b027548dcd0a7d58923f9c7af3872</code></li>
      <li style="color: #FCD34D; font-size: 12px; margin-bottom: 4px;"><code class="addr">0xb98473857e3aa19006e64a4102e4949ee95c0872</code></li>
    </ol>
  </div>

  <div class="section">
    <h3>SECTION 2: SPAM TOKEN AIRDROPS (SINCE INVESTIGATION)</h3>
    <p style="color: #94A3B8; font-size: 12px; margin-bottom: 16px;">
      Scam tokens airdropped to the victim wallet. These are worthless tokens designed to lure the victim
      into interacting with malicious smart contracts (approval phishing). <strong style="color: #EF4444;">Do NOT
      interact with, approve, or attempt to sell any of these tokens.</strong>
    </p>

    <table>
      <thead>
        <tr><th>Date (UTC)</th><th>Token</th><th>Contract Address</th><th>Amount</th><th>Tx Hash</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Mar 17, 20:45</td>
          <td><span class="tag tag-spam">SCAM</span> Good Dog (DOG)</td>
          <td class="addr" style="font-size: 10px;">0x108a908a51fe79f84584d2da02c38ca588bc442d</td>
          <td>1.0</td>
          <td class="hash">0x53113d3435ce...0df5f</td>
        </tr>
        <tr>
          <td>Mar 11, 04:45</td>
          <td><span class="tag tag-spam">SCAM</span> Royal Dog (DOG)</td>
          <td class="addr" style="font-size: 10px;">0x00e2b6d170740c15bf9fb01d0b6e77c0d4510e32</td>
          <td>1.0</td>
          <td class="hash">0x0488db2781de...1e80b</td>
        </tr>
        <tr>
          <td>Mar 7, 06:14</td>
          <td><span class="tag tag-spam">SCAM</span> Trump Wars (WAR)</td>
          <td class="addr" style="font-size: 10px;">0x4921bb864de2e557939b074be20ff4b98723b86b</td>
          <td>1.0</td>
          <td class="hash">0xbca809705453...2606f5</td>
        </tr>
        <tr>
          <td>Mar 5, 06:36</td>
          <td><span class="tag tag-spam">SCAM</span> Little Dog (DOG)</td>
          <td class="addr" style="font-size: 10px;">0x37dabad8ac496148596196fe9adeb54ee3111c78</td>
          <td>1.0</td>
          <td class="hash">0x406c985530c2...dc4ea</td>
        </tr>
      </tbody>
    </table>

    <div class="key-finding" style="margin-top: 16px;">
      <strong>Key Pattern:</strong> In every case, the token contract address is the same as the sender address.
      This means the scam token creator deployed the contract and immediately airdropped tokens from it &mdash;
      a hallmark of approval-phishing scam tokens.
    </div>
  </div>

  <div class="section">
    <h3>SECTION 3: OTHER NON-RECOVERY INCOMING ACTIVITY</h3>
    <p style="color: #94A3B8; font-size: 12px; margin-bottom: 12px;">
      Additional incoming transactions that are NOT fund recoveries:
    </p>
    <table>
      <thead>
        <tr><th>Date (UTC)</th><th>From</th><th>Value</th><th>Assessment</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Mar 5 (x4)</td>
          <td class="addr">0x495f1862c4fb6dbbbda39d88c568bf5f8f2809a0</td>
          <td>0 ETH each</td>
          <td><span class="tag tag-warning">CONTRACT INTERACTION / SPAM</span></td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="info-box">
    <h3>SECTION 4: RECOVERY STATUS &amp; RECOMMENDATIONS</h3>
    <ul>
      <li><strong style="color: #EF4444;">Recovery Status: $0.00 recovered since investigation opened (March 5, 2026)</strong></li>
      <li>Current wallet balance: <strong>0.000045 ETH (~$0.10)</strong></li>
      <li>The address poisoning campaign is <strong style="color: #EF4444;">still active</strong> (most recent: March 15, 2026)</li>
      <li>The attacker or affiliated parties are actively targeting the victim post-exploit</li>
    </ul>

    <p style="color: #00D4FF; font-size: 13px; font-weight: bold; margin-top: 16px;">Recommendations:</p>
    <ul>
      <li><strong>DO NOT</strong> copy any address from recent transaction history &mdash; use only saved/verified addresses</li>
      <li><strong>DO NOT</strong> interact with, approve, or attempt to sell any airdropped tokens (Good Dog, Royal Dog, Trump Wars, Little Dog)</li>
      <li>Consider migrating to a new wallet if any future fund recovery is expected</li>
      <li>The 7 poisoning addresses have been flagged in our monitoring systems</li>
      <li>All 4 spam token contracts have been catalogued for cross-case intelligence</li>
    </ul>
  </div>

  <div class="footer">
    <p style="color: #00D4FF; font-weight: bold; margin-bottom: 4px;">ALPHA FORENSIC INTELLIGENCE ENGINE&trade;</p>
    <p>Autonomous Spider Trace&trade; | Cross-Chain Surveillance | Address Poisoning Detection</p>
    <p style="margin-top: 8px;">Alpha Unlimited Trading Company &mdash; Forensic Intelligence Division</p>
    <p>forensics@alphaunlimitedtrading.com</p>
    <p style="margin-top: 8px; color: #334155; font-size: 10px;">
      This report contains confidential investigative material. Distribution is restricted to authorized parties only.
    </p>
  </div>

</div>
</body>
</html>`;

  const textBody = `
ALPHA FORENSIC INTELLIGENCE ENGINE™
ADDRESS POISONING & SPAM TOKEN INTELLIGENCE REPORT
Case: @sillytuna (Alex Amsel) — ~$24M EIP-7702 Exploit
Case ID: ${CASE_ID}
Generated: ${now}

═══════════════════════════════════════════════════════════════
EXECUTIVE SUMMARY
═══════════════════════════════════════════════════════════════

Since the investigation opened on March 5, 2026, the victim wallet
(0x6fe0fab2164d8e0d03ad6a628e2af78624060322) has been subjected to:

• 7 unique address poisoning addresses sending 0-value transactions
• 4 spam token airdrops (scam tokens)
• 0 ETH recovered
• Current balance: 0.000045 ETH (~$0.10)

NO FUNDS HAVE BEEN RECOVERED OR RETURNED TO THE VICTIM.

═══════════════════════════════════════════════════════════════
ADDRESS POISONING ATTACKS (7 addresses, all 0xb98...a872 pattern)
═══════════════════════════════════════════════════════════════

1. 0xb98e55091ad6c662c67f5f1fc4fb379c9477a872 (MOST ACTIVE — 4 txs)
2. 0xb98e83d55cb5100789bbaad6380201ed2b96a872
3. 0xb986765a00798135255677066ead4433a3d3a872
4. 0xb98e43afac373d2bad03f13752ce82944237a872
5. 0xb98e8eefba0f7476b85cd9716cb5b38a935aa872 (sent 2.33 ETH bait)
6. 0xb9866c85b56b027548dcd0a7d58923f9c7af3872
7. 0xb98473857e3aa19006e64a4102e4949ee95c0872

═══════════════════════════════════════════════════════════════
SPAM TOKEN AIRDROPS (Since March 5)
═══════════════════════════════════════════════════════════════

Mar 17 — "Good Dog" (DOG) — Contract: 0x108a908a51fe79f84584d2da02c38ca588bc442d
Mar 11 — "Royal Dog" (DOG) — Contract: 0x00e2b6d170740c15bf9fb01d0b6e77c0d4510e32
Mar 7  — "Trump Wars" (WAR) — Contract: 0x4921bb864de2e557939b074be20ff4b98723b86b
Mar 5  — "Little Dog" (DOG) — Contract: 0x37dabad8ac496148596196fe9adeb54ee3111c78

DO NOT interact with these tokens.

═══════════════════════════════════════════════════════════════
RECOVERY STATUS: $0.00 recovered since investigation opened.
═══════════════════════════════════════════════════════════════

Alpha Forensic Intelligence Engine™
forensics@alphaunlimitedtrading.com
`;

  const { client: sgClient, fromEmail } = await getUncachableSendGridClient();
  if (!sgClient) {
    console.error("[SpamPoisoningAlert] SendGrid client not available");
    process.exit(1);
  }

  for (const recipient of RECIPIENTS) {
    try {
      const msg = {
        to: { email: recipient.email, name: recipient.name },
        from: { email: fromEmail, name: "Alpha Forensic Intelligence Engine" },
        subject: `[FORENSIC ALERT] Address Poisoning & Spam Token Activity — @sillytuna Victim Wallet — Case ${CASE_ID.slice(0, 8)}`,
        html: htmlBody,
        text: textBody,
      };

      await sgClient.send(msg);
      console.log(`[SpamPoisoningAlert] ✓ Sent to ${recipient.name} (${recipient.email})`);
    } catch (err: any) {
      console.error(`[SpamPoisoningAlert] ✗ Failed to send to ${recipient.email}:`, err?.response?.body || err.message);
    }
  }

  console.log("\n[SpamPoisoningAlert] Done.");
}

main().catch(console.error);
