/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * AUT_FORENSIC_LEAN_SCAN_v6.0
 * ALPHA_INTEGRITY_SEAL: AUT_LeanScan_Calibration_PROTECTED
 *
 * NO WALLETS SKIPPED. Every single wallet scanned on every chain.
 * Protocol contracts included — they are part of the evidence chain.
 */
import * as fs from "fs";
import fetch from "node-fetch";

const DELAY = 300;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
const PROG = "/home/runner/workspace/forensic_scan_progress.json";
const DATA = "/home/runner/workspace/forensic_scan_data.jsonl";
const MAX_PAGES = 10; // 500 most recent TXs per wallet per chain per type

const CHAINS: Record<string, string> = {
  ethereum: "https://eth.blockscout.com/api/v2",
  arbitrum: "https://arbitrum.blockscout.com/api/v2",
  optimism: "https://optimism.blockscout.com/api/v2",
  base: "https://base.blockscout.com/api/v2",
  polygon: "https://polygon.blockscout.com/api/v2",
  gnosis: "https://gnosis.blockscout.com/api/v2",
  zksync: "https://zksync.blockscout.com/api/v2",
  linea: "https://linea.blockscout.com/api/v2",
  scroll: "https://scroll.blockscout.com/api/v2",
};

// ALL case wallets — NO EXCEPTIONS, NO SKIPS
const ALL_WALLETS = [
  // Victim
  "0x6fe0fab2164d8e0d03ad6a628e2af78624060322",
  "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41",
  // POI / Source / Gas / Laundering
  "0xf70da97812cb96acdf810712aa562db8dfa3dbef",
  "0x0d5c41c609fe1ec073c3b4fa10949d602ed059bb",
  "0xb01fed2f701695992a4f7ffdb53f3af099e140d7",
  "0xb98e8eefba0f7476b85cd9716cb5b38a935aa872",
  "0x423d2b61952d56358db8b313ec7404a9582d4865",
  // FXUSD chain
  "0xd14f4b36e1d1d98c218db782c49149876042bc56",
  "0x6818809eefce719e480a7526d76bd3e561526b46",
  "0x658370618bbc885865df66c1061bfe4771fad846",
  // Protocol contracts — NOT SKIPPED, they are evidence
  "0x9008d19f58aabd9ed0d60971565aa8510560ab41", // CoW Swap (how FXUSD→USDC swap happened)
  "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae", // LiFi Diamond (BTC bridge)
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f", // Arbitrum Bridge Inbox
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45", // Uniswap Router
  // Split wallets
  "0xc600d76b5bfe058d6e52d2c08ceba6c85774f9b6",
  "0xbcd263db9c9ed9215bcb07897f9da582129dd7da",
  "0xea7fc58e112fb3607d8a7694e1f71c6894c72d3c",
  "0xacd1f4e274d1a4bb686a41549a90253cf152dd6d",
  "0xe205e85068704ecf1c3c55b76bcb466ff0798526",
  "0x9b9fd485e94c73af3bc8b9a630c4de7203bc96cb",
  "0x610e10ed49f57591abe16d919b6d15aaf4557237",
  "0xa5cc3e44ed97f8c94df27822c85303a3bd4e8134",
  "0x7aebc630f301f15baddf160103dc3bd8f9baf043",
  "0x487663784c77ba56e32d9fe60485d93c4c319385",
  // DAI Recipients + Dispersal
  "0xdca900cf72d3233a5ecb7ee29615cfb0dc68c9c4",
  "0xd0c277aa22512262e4dbe524a1341e6b7618dd3e",
  "0xd8cfaaceb9719d7c5c68c0ad876e619c180770c6",
  // Arbitrum Receivers
  "0x15fc13d28224a0e8b440a65557792f1b8cdc4608",
  "0xf928775403246fb69c8fb5823e596be66552d5b9",
  "0x68598fafd41bbff18a201fa428ccebf74ff0aebe",
  "0x8632263ede29a102be6d207afeccd4de4897f451",
  "0x06b00470552cd0d99e805a6b07654e0b5e76697f",
  "0x1c25d41f7d449eba3a66689a9e15f86b6b684e32",
  "0xe4388fd9734ad2228cbfaf4fbcb2ab1795cf3748",
  "0x9e7328fcf68b6306f9d2e5957f9a902f46ae6eba",
  "0x02bb54d4bb15f65fcce931a1ae5e57e01ccc2dd3",
  "0x1a0d0ba123fec0862d8c26e355539f100b146faf",
  // All Destinations — every single one
  "0xcb63da64aa0b893a17f11c95e8273508cdcafb52",
  "0x9fb98796b25519a0a26565907e5ecdb643176d2f",
  "0x4da074883357616000f485b84a5e0338acec8071",
  "0x7fd43f5e673489106e9f15cb3729dcf9c339f08a",
  "0x0bed139e66c6b80e193627e144544e57d53f629c",
  "0x7f72c73dc7d3badb2000edb1e11135eaae33cc2c",
  "0x85bbab5353ba3ac87d654b6a6806b9a315afbc52",
  "0xec63b8a34a47992a846694c7ea711863a2c83643",
  "0x9a7710e1735cf8ebd9f204b1683862cec4086b58",
  "0x1415c9a672747fa626f712b844442c4f08d69fe9",
  "0xdca9f78a5740bd19d4652f877b7a10a6ad3ec9c4",
  "0x9f3ca7a2ef8e55f665cde43c0c5b4f8672aedda5",
  "0x48916d83049adc30c49105493c700e4945434ec1",
  "0x31d47468a731a96d7e0f1232c39b7da4b95c144e",
  "0x1eadcba908532ddd49c40b22e52827d695e36939",
  "0x41f03af13cb6cec919e5838a53ae79eadf291b87",
  "0x3a453cf90b0d66f64849ca1531bd0e68e038bd07",
  "0x735adbbe72226bd52e818e7181953f42e3b0ff21",
  "0x2df7cffe95d906182e532b8db911a83987bc403c",
  "0xff05a324f89b4a3ebed1790734d131e4b61030b6",
  "0xa5f565650890fba1824ee0f21ebbbf660a179934",
  "0xf5042e6ffac5a625d4e7848e0b01373d8eb9e222",
  "0x4cd00e387622c35bddb9b4c962c136462338bc31",
  "0x18dd3c14e34c1bc379f7538068c59160d9f68e25",
  "0x01960338516245ce09268d30b5aa4cd49a420c8c",
  "0x0439e60f02a8900a951603950d8d4527f400c3f1",
  "0x00e7a1181a32d03bb17f34f2903fd86a4370027b",
  // Bridge / Final
  "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7",
  // First funder of Original Funder
  "0xaa364c1a66a7e3a4dd39e9b4080e69e3aaf4060c",
];

async function fetchJ(url: string): Promise<any> {
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "AF/6" }, timeout: 12000 } as any);
      if (r.status === 429) { await sleep(3000); continue; }
      if (!r.ok) return null;
      return await r.json();
    } catch { await sleep(1000); }
  }
  return null;
}

async function scanWallet(addr: string, chain: string, api: string): Promise<number> {
  let count = 0;

  // Token transfers
  let next = "";
  let pg = 0;
  while (pg < MAX_PAGES) {
    const url = `${api}/addresses/${addr}/token-transfers${next ? "?" + next : ""}`;
    const d = await fetchJ(url);
    await sleep(DELAY);
    if (!d?.items?.length) break;
    for (const tt of d.items) {
      fs.appendFileSync(DATA, JSON.stringify({
        h: tt.transaction_hash || tt.tx_hash || "",
        f: (tt.from?.hash || "").toLowerCase(),
        t: (tt.to?.hash || "").toLowerCase(),
        v: tt.total?.value || "0",
        ts: tt.timestamp || "",
        sym: tt.token?.symbol || "?",
        dec: tt.token?.decimals ? parseInt(tt.token.decimals) : 18,
        ta: (tt.token?.address || "").toLowerCase(),
        c: chain, tp: "tok"
      }) + "\n");
      count++;
    }
    if (!d.next_page_params) break;
    next = new URLSearchParams(d.next_page_params as any).toString();
    pg++;
  }

  // Native txs
  next = ""; pg = 0;
  while (pg < MAX_PAGES) {
    const url = `${api}/addresses/${addr}/transactions${next ? "?" + next : ""}`;
    const d = await fetchJ(url);
    await sleep(DELAY);
    if (!d?.items?.length) break;
    for (const tx of d.items) {
      fs.appendFileSync(DATA, JSON.stringify({
        h: tx.hash,
        f: (tx.from?.hash || "").toLowerCase(),
        t: (tx.to?.hash || "").toLowerCase(),
        v: tx.value || "0",
        ts: tx.timestamp || "",
        m: tx.method || "",
        c: chain, tp: "nat"
      }) + "\n");
      count++;
    }
    if (!d.next_page_params) break;
    next = new URLSearchParams(d.next_page_params as any).toString();
    pg++;
  }

  return count;
}

async function main() {
  console.log("═══ COMPLETE SCAN — NO WALLETS SKIPPED ═══\n");

  const uniqueAddrs = [...new Set(ALL_WALLETS.map(a => a.toLowerCase()))];
  const totalPairs = uniqueAddrs.length * Object.keys(CHAINS).length;
  console.log(`Wallets: ${uniqueAddrs.length} (ZERO skipped)`);
  console.log(`Chains: ${Object.keys(CHAINS).length}`);
  console.log(`Total pairs: ${totalPairs}\n`);

  // Load progress
  let prog: string[] = [];
  if (fs.existsSync(PROG)) prog = JSON.parse(fs.readFileSync(PROG, "utf-8"));
  const doneSet = new Set(prog);
  console.log(`Already done: ${doneSet.size}/${totalPairs}\n`);

  let scanned = doneSet.size;
  let totalNew = 0;

  for (const addr of uniqueAddrs) {
    for (const [chain, api] of Object.entries(CHAINS)) {
      const key = `${addr}:${chain}`;
      if (doneSet.has(key)) continue;

      scanned++;
      process.stdout.write(`\r  [${scanned}/${totalPairs}] ${chain.padEnd(10)} ${addr.slice(0,14)}...    `);

      const count = await scanWallet(addr, chain, api);

      if (count > 0) {
        console.log(`\n  ✦ ${addr.slice(0,14)}... on ${chain}: ${count} records`);
        totalNew += count;
      }

      doneSet.add(key);
      prog.push(key);
      fs.writeFileSync(PROG, JSON.stringify(prog));
    }
  }

  let totalLines = 0;
  if (fs.existsSync(DATA)) {
    // Count lines without loading entire file into memory
    const fd = fs.openSync(DATA, "r");
    const buf = Buffer.alloc(65536);
    let bytesRead;
    while ((bytesRead = fs.readSync(fd, buf)) > 0) {
      for (let i = 0; i < bytesRead; i++) if (buf[i] === 10) totalLines++;
    }
    fs.closeSync(fd);
  }

  console.log(`\n\n${"═".repeat(60)}`);
  console.log(`Done: ${scanned}/${totalPairs}`);
  console.log(`New records this run: ${totalNew}`);
  console.log(`Total records: ${totalLines}`);
  if (scanned >= totalPairs) console.log("\n✅ ALL WALLETS SCANNED ACROSS ALL CHAINS — NOTHING SKIPPED!");
  else console.log(`\nRun again to continue (${totalPairs - scanned} remaining)`);

  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e); process.exit(1); });
