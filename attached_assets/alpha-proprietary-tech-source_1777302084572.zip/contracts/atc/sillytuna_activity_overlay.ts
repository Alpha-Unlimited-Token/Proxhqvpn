/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * SillyTuna Activity Overlay — Forward Activity Trace
 *
 * Loads the existing back-trace mapping from
 *   contracts/atc/sillytuna_backtrace_mapping.json
 * and overlays per-wallet activity since the case began:
 *   - All inbound + outbound transfers since SINCE_CASE_START
 *   - Large transfer flagging (>= LARGE_TX_USD)
 *   - "New since last trace" detection (after SINCE_LAST_TRACE)
 *   - Counterparty labelling against Address Label Database™
 *
 * Re-writes:
 *   - contracts/atc/sillytuna_backtrace_mapping.json   (augmented in place)
 *   - contracts/atc/sillytuna_backtrace_mapping.html   (regenerated viewer)
 */

import fs from 'node:fs';
import path from 'node:path';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';
import { enforceProprietaryLicense } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Post-Trace Activity Surveillance™');

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) { console.error('[Activity] FATAL: ALCHEMY_API_KEY not set'); process.exit(1); }
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const SINCE_CASE_START = new Date('2026-01-01T00:00:00Z');
const SINCE_LAST_TRACE = new Date('2026-04-13T00:00:00Z');
const LARGE_TX_USD = 10_000;
const RATE_LIMIT_MS = 150;
const MAX_TXS_PER_WALLET = 200;

const PRICES: Record<string, number> = {
  ETH: 2080, WETH: 2080,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1, FRAX: 1, TUSD: 1, USDP: 1,
  WBTC: 67000, BTC: 67000,
  UNI: 8.5, LINK: 14, MATIC: 0.6, AAVE: 90, MKR: 1400, SHIB: 0.000018,
};

interface Transfer {
  hash: string;
  blockNum: number;
  timestamp: string | null;
  from: string;
  to: string;
  asset: string;
  value: number;
  valueUsd: number;
  category: string;
  direction: 'IN' | 'OUT';
  counterparty: string;
  counterpartyLabel: string | null;
  counterpartyCategory: string | null;
  isLarge: boolean;
  isPostLastTrace: boolean;
}

interface ActivitySummary {
  windowStart: string;
  generatedAt: string;
  totalTxs: number;
  totalInboundTxs: number;
  totalOutboundTxs: number;
  totalInboundUsd: number;
  totalOutboundUsd: number;
  largeTxCount: number;
  newSinceLastTraceCount: number;
  largeTransfers: Transfer[];
  newSinceLastTrace: Transfer[];
  counterpartyExchangeHits: { exchange: string; direction: string; count: number; totalUsd: number }[];
  lastActivityTs: string | null;
  isStillActive: boolean;
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function getTransfers(address: string, direction: 'from' | 'to', maxCount = MAX_TXS_PER_WALLET): Promise<any[]> {
  const params: any = {
    fromBlock: '0x0',
    toBlock: 'latest',
    category: ['external', 'erc20'],
    maxCount: `0x${maxCount.toString(16)}`,
    order: 'desc',
    withMetadata: true,
  };
  if (direction === 'from') params.fromAddress = address;
  else params.toAddress = address;

  try {
    const resp = await fetch(ALCHEMY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'alchemy_getAssetTransfers', params: [params] }),
      signal: AbortSignal.timeout(30000),
    });
    if (!resp.ok) return [];
    const data: any = await resp.json();
    if (data.error) { console.log(`[Activity] Alchemy error: ${data.error.message}`); return []; }
    return data?.result?.transfers || [];
  } catch (e) {
    console.log(`[Activity] fetch err ${address.slice(0, 10)}: ${(e as Error).message}`);
    return [];
  }
}

function priceUsd(asset: string, value: number): number {
  const p = PRICES[asset?.toUpperCase()] ?? 0;
  return value * p;
}

async function activityForWallet(address: string): Promise<ActivitySummary> {
  const addrLower = address.toLowerCase();
  const [outRaw, inRaw] = await Promise.all([
    getTransfers(addrLower, 'from'),
    getTransfers(addrLower, 'to'),
  ]);

  const all: Transfer[] = [];
  const exchangeMap = new Map<string, { direction: string; count: number; totalUsd: number }>();

  for (const direction of ['IN', 'OUT'] as const) {
    const raw = direction === 'IN' ? inRaw : outRaw;
    for (const t of raw) {
      const tsRaw = t?.metadata?.blockTimestamp;
      const ts = tsRaw ? new Date(tsRaw) : null;
      if (!ts || ts < SINCE_CASE_START) continue;

      const counterparty = (direction === 'IN' ? t.from : t.to || '').toLowerCase();
      if (!counterparty) continue;
      const lbl = lookupAddress(counterparty);
      const value = typeof t.value === 'number' ? t.value : 0;
      const asset = (t.asset || 'ETH').toUpperCase();
      const valueUsd = priceUsd(asset, value);

      const transfer: Transfer = {
        hash: t.hash,
        blockNum: parseInt(t.blockNum, 16),
        timestamp: ts.toISOString(),
        from: (t.from || '').toLowerCase(),
        to: (t.to || '').toLowerCase(),
        asset,
        value,
        valueUsd,
        category: t.category,
        direction,
        counterparty,
        counterpartyLabel: lbl?.name || null,
        counterpartyCategory: lbl?.category || null,
        isLarge: valueUsd >= LARGE_TX_USD,
        isPostLastTrace: ts >= SINCE_LAST_TRACE,
      };
      all.push(transfer);

      if (lbl?.category === 'exchange') {
        const k = `${lbl.name}|${direction}`;
        if (!exchangeMap.has(k)) exchangeMap.set(k, { direction, count: 0, totalUsd: 0 });
        const e = exchangeMap.get(k)!;
        e.count++;
        e.totalUsd += valueUsd;
      }
    }
  }

  all.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
  const inboundTx = all.filter(t => t.direction === 'IN');
  const outboundTx = all.filter(t => t.direction === 'OUT');
  const large = all.filter(t => t.isLarge).sort((a, b) => b.valueUsd - a.valueUsd);
  const newSince = all.filter(t => t.isPostLastTrace);

  const cpex = Array.from(exchangeMap.entries()).map(([k, v]) => {
    const [exchange, dir] = k.split('|');
    return { exchange, direction: dir, count: v.count, totalUsd: v.totalUsd };
  }).sort((a, b) => b.totalUsd - a.totalUsd);

  const lastTs = all[0]?.timestamp || null;

  return {
    windowStart: SINCE_CASE_START.toISOString(),
    generatedAt: new Date().toISOString(),
    totalTxs: all.length,
    totalInboundTxs: inboundTx.length,
    totalOutboundTxs: outboundTx.length,
    totalInboundUsd: inboundTx.reduce((s, t) => s + t.valueUsd, 0),
    totalOutboundUsd: outboundTx.reduce((s, t) => s + t.valueUsd, 0),
    largeTxCount: large.length,
    newSinceLastTraceCount: newSince.length,
    largeTransfers: large.slice(0, 50),
    newSinceLastTrace: newSince.slice(0, 50),
    counterpartyExchangeHits: cpex,
    lastActivityTs: lastTs,
    isStillActive: lastTs ? new Date(lastTs) >= SINCE_LAST_TRACE : false,
  };
}

function fmtUsd(n: number): string {
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

function buildMergedHtml(merged: any): string {
  const reports = merged.reports;
  const totalKyc = reports.reduce((s: number, r: any) => s + (r.kycChokepoints?.length || 0), 0);
  const exposed = reports.filter((r: any) => r.riskAssessment === 'KYC_EXPOSED').length;
  const partial = reports.filter((r: any) => r.riskAssessment === 'PARTIAL_KYC').length;
  const obfusc = reports.filter((r: any) => r.riskAssessment === 'OBFUSCATED').length;

  const stillActive = reports.filter((r: any) => r.recentActivity?.isStillActive).length;
  const totalNewTxs = reports.reduce((s: number, r: any) => s + (r.recentActivity?.newSinceLastTraceCount || 0), 0);
  const totalLargeTxs = reports.reduce((s: number, r: any) => s + (r.recentActivity?.largeTxCount || 0), 0);
  const totalInUsd = reports.reduce((s: number, r: any) => s + (r.recentActivity?.totalInboundUsd || 0), 0);
  const totalOutUsd = reports.reduce((s: number, r: any) => s + (r.recentActivity?.totalOutboundUsd || 0), 0);

  // Aggregate KYC exchange hits (from back-trace)
  const exchangeHits = new Map<string, number>();
  for (const r of reports) for (const k of (r.kycChokepoints || [])) {
    exchangeHits.set(k.exchange, (exchangeHits.get(k.exchange) || 0) + 1);
  }
  const exchangeRows = Array.from(exchangeHits.entries()).sort((a, b) => b[1] - a[1])
    .map(([ex, n]) => `<tr><td style="padding:8px;color:#d4a017;font-weight:bold;">${ex}</td><td style="padding:8px;text-align:right;color:#4ade80;">${n}</td></tr>`).join('');

  // Aggregate counterparty exchange hits across recent activity
  const recentExch = new Map<string, { in: number; out: number; usd: number }>();
  for (const r of reports) for (const c of (r.recentActivity?.counterpartyExchangeHits || [])) {
    if (!recentExch.has(c.exchange)) recentExch.set(c.exchange, { in: 0, out: 0, usd: 0 });
    const e = recentExch.get(c.exchange)!;
    if (c.direction === 'IN') e.in += c.count; else e.out += c.count;
    e.usd += c.totalUsd;
  }
  const recentExchRows = Array.from(recentExch.entries()).sort((a, b) => b[1].usd - a[1].usd)
    .map(([ex, v]) => `<tr><td style="padding:8px;color:#d4a017;font-weight:bold;">${ex}</td><td style="padding:8px;text-align:right;color:#4ade80;">${v.in}</td><td style="padding:8px;text-align:right;color:#ff8800;">${v.out}</td><td style="padding:8px;text-align:right;color:#fff;">${fmtUsd(v.usd)}</td></tr>`).join('');

  const reportCards = reports.map((r: any) => {
    const riskColor = r.riskAssessment === 'KYC_EXPOSED' ? '#4ade80'
      : r.riskAssessment === 'PARTIAL_KYC' ? '#ffcc00'
      : r.riskAssessment === 'OBFUSCATED' ? '#ff8800' : '#888';
    const act = r.recentActivity;
    const activeBadge = act?.isStillActive ? `<span style="background:#ff222244;color:#ff4444;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:bold;margin-left:6px;">⚡ STILL ACTIVE</span>` : '';

    const kycRows = (r.kycChokepoints || []).slice(0, 50).map((k: any) => `
      <tr>
        <td style="padding:6px;color:#d4a017;font-family:monospace;font-size:12px;">${k.exchange}</td>
        <td style="padding:6px;color:#888;font-family:monospace;font-size:11px;">hop ${k.hopLevel}</td>
        <td style="padding:6px;color:#ccc;font-family:monospace;font-size:11px;">${k.hopAddress.slice(0, 10)}...${k.hopAddress.slice(-6)}</td>
        <td style="padding:6px;text-align:right;color:#4ade80;font-family:monospace;">${(k.amount || 0).toFixed(4)} ${k.asset}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${k.txHash}" style="color:#4488ff;">${k.txHash.slice(0, 14)}...</a></td>
      </tr>`).join('');

    const largeRows = (act?.largeTransfers || []).map((t: Transfer) => {
      const dirColor = t.direction === 'IN' ? '#4ade80' : '#ff8800';
      return `<tr>
        <td style="padding:6px;font-size:11px;color:#888;">${t.timestamp?.slice(0, 10)}</td>
        <td style="padding:6px;color:${dirColor};font-weight:bold;font-size:11px;">${t.direction === 'IN' ? '⬇ IN' : '⬆ OUT'}</td>
        <td style="padding:6px;text-align:right;font-family:monospace;color:#fff;font-weight:bold;">${fmtUsd(t.valueUsd)}</td>
        <td style="padding:6px;text-align:right;font-family:monospace;font-size:11px;color:#ccc;">${t.value.toFixed(2)} ${t.asset}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;color:${t.counterpartyLabel ? '#d4a017' : '#888'};">${t.counterpartyLabel || t.counterparty.slice(0, 14) + '...' + t.counterparty.slice(-4)}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${t.hash}" style="color:#4488ff;">${t.hash.slice(0, 12)}...</a></td>
      </tr>`;
    }).join('');

    const newTxRows = (act?.newSinceLastTrace || []).map((t: Transfer) => {
      const dirColor = t.direction === 'IN' ? '#4ade80' : '#ff8800';
      return `<tr>
        <td style="padding:6px;font-size:11px;color:#ff4444;">${t.timestamp?.slice(0, 10)}</td>
        <td style="padding:6px;color:${dirColor};font-weight:bold;font-size:11px;">${t.direction === 'IN' ? '⬇ IN' : '⬆ OUT'}</td>
        <td style="padding:6px;text-align:right;font-family:monospace;color:#fff;">${fmtUsd(t.valueUsd)}</td>
        <td style="padding:6px;text-align:right;font-family:monospace;font-size:11px;color:#ccc;">${t.value.toFixed(2)} ${t.asset}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;color:${t.counterpartyLabel ? '#d4a017' : '#888'};">${t.counterpartyLabel || t.counterparty.slice(0, 14) + '...' + t.counterparty.slice(-4)}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${t.hash}" style="color:#4488ff;">${t.hash.slice(0, 12)}...</a></td>
      </tr>`;
    }).join('');

    const sourceRows = (r.backTraceNodes || []).flatMap((n: any) => (n.topSources || []).slice(0, 5).map((s: any) => `
      <tr>
        <td style="padding:4px;color:#888;font-size:11px;">hop ${n.hop}</td>
        <td style="padding:4px;font-family:monospace;font-size:11px;color:#ccc;">${n.address.slice(0, 10)}...${n.address.slice(-4)}</td>
        <td style="padding:4px;color:#666;">←</td>
        <td style="padding:4px;font-family:monospace;font-size:11px;color:${s.label ? '#d4a017' : '#999'};">${s.address.slice(0, 10)}...${s.address.slice(-4)}</td>
        <td style="padding:4px;font-size:11px;color:${s.label ? '#4ade80' : '#666'};">${s.label || '(unknown wallet)'}</td>
        <td style="padding:4px;text-align:right;font-family:monospace;font-size:11px;color:#4ade80;">${s.valueEth.toFixed(3)} ETH</td>
      </tr>`)).join('');

    return `
    <div style="background:#111;border-left:4px solid ${riskColor};padding:16px;margin:16px 0;border-radius:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
        <div style="font-family:monospace;font-size:13px;color:#fff;font-weight:bold;">${r.address}</div>
        <div>
          <span style="background:${riskColor}22;color:${riskColor};padding:4px 12px;border-radius:12px;font-size:11px;font-weight:bold;">${r.riskAssessment.replace('_', ' ')}</span>
          ${activeBadge}
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin:12px 0;">
        <div style="background:#0a0a0a;padding:10px;border-radius:4px;text-align:center;"><div style="font-size:18px;color:#4ade80;font-weight:bold;">${fmtUsd(act?.totalInboundUsd || 0)}</div><div style="font-size:10px;color:#888;">IN since ${act?.windowStart?.slice(0, 10) || '—'}</div><div style="font-size:10px;color:#666;">${act?.totalInboundTxs || 0} txs</div></div>
        <div style="background:#0a0a0a;padding:10px;border-radius:4px;text-align:center;"><div style="font-size:18px;color:#ff8800;font-weight:bold;">${fmtUsd(act?.totalOutboundUsd || 0)}</div><div style="font-size:10px;color:#888;">OUT since case start</div><div style="font-size:10px;color:#666;">${act?.totalOutboundTxs || 0} txs</div></div>
        <div style="background:#0a0a0a;padding:10px;border-radius:4px;text-align:center;"><div style="font-size:18px;color:#fff;font-weight:bold;">${act?.largeTxCount || 0}</div><div style="font-size:10px;color:#888;">Large txs (≥$10K)</div></div>
        <div style="background:#0a0a0a;padding:10px;border-radius:4px;text-align:center;"><div style="font-size:18px;color:${(act?.newSinceLastTraceCount || 0) > 0 ? '#ff4444' : '#666'};font-weight:bold;">${act?.newSinceLastTraceCount || 0}</div><div style="font-size:10px;color:#888;">NEW since last trace</div><div style="font-size:10px;color:#666;">${act?.lastActivityTs?.slice(0, 10) || 'no activity'}</div></div>
        <div style="background:#0a0a0a;padding:10px;border-radius:4px;text-align:center;"><div style="font-size:18px;color:#d4a017;font-weight:bold;">${r.kycChokepoints?.length || 0}</div><div style="font-size:10px;color:#888;">KYC chokepoints</div></div>
      </div>

      ${(act?.newSinceLastTrace || []).length > 0 ? `
      <details style="margin-top:10px;" open>
        <summary style="color:#ff4444;font-weight:bold;cursor:pointer;font-size:13px;">⚡ NEW ACTIVITY since last trace (${act.newSinceLastTraceCount}) — ${act?.lastActivityTs?.slice(0, 10)}</summary>
        <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">
          <tr style="background:#1a0000;"><th style="padding:6px;text-align:left;color:#ff4444;font-size:11px;">DATE</th><th style="padding:6px;text-align:left;color:#ff4444;font-size:11px;">DIR</th><th style="padding:6px;text-align:right;color:#ff4444;font-size:11px;">USD</th><th style="padding:6px;text-align:right;color:#ff4444;font-size:11px;">AMOUNT</th><th style="padding:6px;text-align:left;color:#ff4444;font-size:11px;">COUNTERPARTY</th><th style="padding:6px;text-align:left;color:#ff4444;font-size:11px;">TX</th></tr>
          ${newTxRows}
        </table>
      </details>` : ''}

      ${(act?.largeTransfers || []).length > 0 ? `
      <details style="margin-top:8px;">
        <summary style="color:#fff;font-weight:bold;cursor:pointer;font-size:13px;">💰 LARGE TRANSFERS since case start (${act.largeTxCount})</summary>
        <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">
          <tr style="background:#1a1a1a;"><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">DATE</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">DIR</th><th style="padding:6px;text-align:right;color:#d4a017;font-size:11px;">USD</th><th style="padding:6px;text-align:right;color:#d4a017;font-size:11px;">AMOUNT</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">COUNTERPARTY</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">TX</th></tr>
          ${largeRows}
        </table>
      </details>` : ''}

      ${(r.kycChokepoints || []).length > 0 ? `
      <details style="margin-top:8px;">
        <summary style="color:#4ade80;font-weight:bold;cursor:pointer;font-size:13px;">🔑 KYC CHOKEPOINTS — back-trace funding origins (${r.kycChokepoints.length})</summary>
        <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">
          <tr style="background:#1a1a1a;"><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">EXCHANGE</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">HOP</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">FUNDED ADDRESS</th><th style="padding:6px;text-align:right;color:#d4a017;font-size:11px;">AMOUNT</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">TX</th></tr>
          ${kycRows}
        </table>
      </details>` : ''}

      <details style="margin-top:8px;">
        <summary style="color:#888;cursor:pointer;font-size:12px;">📊 Top funding sources (back-trace, all hops)</summary>
        <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">${sourceRows}</table>
      </details>
    </div>`;
  }).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>SillyTuna Full Mapping — Back-Trace + Forward Activity</title><style>
body{background:#0a0a0a;color:#fff;font-family:'Segoe UI',Arial,sans-serif;padding:20px;max-width:1400px;margin:0 auto;line-height:1.6;}
::-webkit-scrollbar{width:8px;}::-webkit-scrollbar-track{background:#111;}::-webkit-scrollbar-thumb{background:#333;border-radius:4px;}
table{border-collapse:collapse;}
</style></head><body>
<div style="text-align:center;border-bottom:2px solid #d4a017;padding-bottom:20px;margin-bottom:30px;">
<div style="font-size:11px;color:#d4a017;letter-spacing:4px;">ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY AND CONFIDENTIAL</div>
<h1 style="margin:10px 0;font-size:28px;">SillyTuna Full Wallet Mapping</h1>
<div style="color:#888;font-size:14px;">Back-Trace + Forward Activity Overlay + KYC Chokepoint Mapping</div>
<div style="color:#666;font-size:12px;margin-top:8px;">Case: ${merged.caseId} | Victim: ${merged.victim}<br>Back-trace generated: ${merged.generatedAt} | Activity overlay: ${new Date().toISOString()}</div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:24px;">
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #d4a017;"><div style="font-size:28px;color:#d4a017;font-weight:bold;">${reports.length}</div><div style="color:#888;font-size:12px;">Wallets Tracked</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff4444;"><div style="font-size:28px;color:#ff4444;font-weight:bold;">${stillActive}</div><div style="color:#888;font-size:12px;">Still Active (post-trace)</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff4444;"><div style="font-size:28px;color:#ff4444;font-weight:bold;">${totalNewTxs}</div><div style="color:#888;font-size:12px;">New Txs Since 04-13</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #fff;"><div style="font-size:28px;color:#fff;font-weight:bold;">${totalLargeTxs}</div><div style="color:#888;font-size:12px;">Large Txs (≥$10K)</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:28px;color:#4ade80;font-weight:bold;">${fmtUsd(totalInUsd)}</div><div style="color:#888;font-size:12px;">Total IN since case start</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff8800;"><div style="font-size:28px;color:#ff8800;font-weight:bold;">${fmtUsd(totalOutUsd)}</div><div style="color:#888;font-size:12px;">Total OUT since case start</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:28px;color:#4ade80;font-weight:bold;">${totalKyc}</div><div style="color:#888;font-size:12px;">KYC Chokepoints</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:28px;color:#4ade80;font-weight:bold;">${exposed}</div><div style="color:#888;font-size:12px;">KYC_EXPOSED</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ffcc00;"><div style="font-size:28px;color:#ffcc00;font-weight:bold;">${partial}</div><div style="color:#888;font-size:12px;">PARTIAL_KYC</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff8800;"><div style="font-size:28px;color:#ff8800;font-weight:bold;">${obfusc}</div><div style="color:#888;font-size:12px;">OBFUSCATED</div></div>
</div>

${recentExch.size > 0 ? `
<h2 style="color:#ff4444;margin-top:30px;border-bottom:1px solid #ff4444;padding-bottom:8px;">⚡ RECENT EXCHANGE INTERACTIONS (since case start)</h2>
<p style="color:#ccc;">Exchanges that the attacker wallets interacted with since the SillyTuna case began. OUT = attacker depositing to exchange (cash-out attempt), IN = exchange paying attacker.</p>
<table style="width:80%;background:#111;border-radius:6px;">
<tr style="background:#1a1a1a;"><th style="padding:10px;text-align:left;color:#d4a017;">EXCHANGE</th><th style="padding:10px;text-align:right;color:#4ade80;">⬇ INBOUND TXS</th><th style="padding:10px;text-align:right;color:#ff8800;">⬆ OUTBOUND TXS</th><th style="padding:10px;text-align:right;color:#fff;">TOTAL USD</th></tr>
${recentExchRows}
</table>` : ''}

${exchangeHits.size > 0 ? `
<h2 style="color:#4ade80;margin-top:30px;border-bottom:1px solid #4ade80;padding-bottom:8px;">🎯 KYC EXCHANGE FUNDING SOURCES (back-trace origins)</h2>
<p style="color:#ccc;">Exchanges that originally funded the attacker wallets — subpoena targets for identity reveal.</p>
<table style="width:60%;background:#111;border-radius:6px;">
<tr style="background:#1a1a1a;"><th style="padding:10px;text-align:left;color:#d4a017;">EXCHANGE</th><th style="padding:10px;text-align:right;color:#d4a017;">FUNDING TXS</th></tr>
${exchangeRows}
</table>` : ''}

<h2 style="color:#d4a017;margin-top:30px;border-bottom:1px solid #d4a017;padding-bottom:8px;">PER-WALLET FULL MAPPING (Back-Trace + Forward Activity)</h2>
${reportCards}

<div style="margin-top:40px;padding:20px;background:#111;border-radius:8px;border:1px solid #333;color:#888;font-size:12px;">
<strong style="color:#d4a017;">Methodology:</strong> Back-trace performed via Alpha Transaction Origin Intelligence™ (2 hops, ~80 known CEX/bridge/mixer labels). Forward activity overlay queries all inbound + outbound transfers since ${SINCE_CASE_START.toISOString().slice(0, 10)} via Alchemy alchemy_getAssetTransfers, with USD valuation against live token prices, large-tx flag at ≥$${LARGE_TX_USD.toLocaleString()}, and "new since last trace" flag at ${SINCE_LAST_TRACE.toISOString().slice(0, 10)}. ⚡ STILL ACTIVE indicates a wallet has moved funds AFTER the original DAU v2 trace was completed.
</div>
</body></html>`;
}

async function main() {
  console.log('[Activity] === SillyTuna Activity Overlay ===\n');

  const jsonPath = path.resolve('contracts/atc/sillytuna_backtrace_mapping.json');
  if (!fs.existsSync(jsonPath)) { console.error(`[Activity] FATAL: ${jsonPath} not found — run sillytuna_full_backtrace.ts first`); process.exit(1); }
  const merged: any = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
  console.log(`[Activity] Loaded back-trace JSON: ${merged.reports.length} wallets`);
  console.log(`[Activity] Window: since ${SINCE_CASE_START.toISOString().slice(0, 10)} | New-since-last-trace cutoff: ${SINCE_LAST_TRACE.toISOString().slice(0, 10)}\n`);

  for (let i = 0; i < merged.reports.length; i++) {
    const r = merged.reports[i];
    console.log(`[Activity] [${i + 1}/${merged.reports.length}] ${r.address}`);
    try {
      const act = await activityForWallet(r.address);
      r.recentActivity = act;
      console.log(`           ${act.totalTxs} txs | IN ${fmtUsd(act.totalInboundUsd)} | OUT ${fmtUsd(act.totalOutboundUsd)} | large=${act.largeTxCount} | new=${act.newSinceLastTraceCount} | active=${act.isStillActive}`);
    } catch (e) {
      console.log(`[Activity] ERROR: ${(e as Error).message}`);
    }
    await sleep(RATE_LIMIT_MS);
  }

  // Persist merged JSON (back-trace + activity)
  merged.activityOverlayMeta = {
    overlayGeneratedAt: new Date().toISOString(),
    sinceCaseStart: SINCE_CASE_START.toISOString(),
    sinceLastTrace: SINCE_LAST_TRACE.toISOString(),
    largeTxThresholdUsd: LARGE_TX_USD,
  };
  fs.writeFileSync(jsonPath, JSON.stringify(merged, null, 2));
  console.log(`\n[Activity] ✅ Updated ${jsonPath}`);
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(jsonPath, { title: 'SillyTuna — Activity Overlay (Recent)', caseId: merged.caseId || 'SILLYTUNA', chain: 'polygon', direction: 'forward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  // Regenerate HTML
  const htmlPath = path.resolve('contracts/atc/sillytuna_backtrace_mapping.html');
  fs.writeFileSync(htmlPath, buildMergedHtml(merged));
  console.log(`[Activity] ✅ Wrote ${htmlPath}`);

  // Final summary
  const stillActive = merged.reports.filter((r: any) => r.recentActivity?.isStillActive).length;
  const totalNew = merged.reports.reduce((s: number, r: any) => s + (r.recentActivity?.newSinceLastTraceCount || 0), 0);
  const totalLarge = merged.reports.reduce((s: number, r: any) => s + (r.recentActivity?.largeTxCount || 0), 0);
  const totalIn = merged.reports.reduce((s: number, r: any) => s + (r.recentActivity?.totalInboundUsd || 0), 0);
  const totalOut = merged.reports.reduce((s: number, r: any) => s + (r.recentActivity?.totalOutboundUsd || 0), 0);

  console.log('\n=== ACTIVITY OVERLAY SUMMARY ===');
  console.log(`Wallets analyzed:        ${merged.reports.length}`);
  console.log(`Still active post-trace: ${stillActive}`);
  console.log(`New txs since 04-13:     ${totalNew}`);
  console.log(`Large txs (≥$10K):       ${totalLarge}`);
  console.log(`Total IN since case:     ${fmtUsd(totalIn)}`);
  console.log(`Total OUT since case:    ${fmtUsd(totalOut)}`);
}

main().catch(e => { console.error(e); process.exit(1); });
