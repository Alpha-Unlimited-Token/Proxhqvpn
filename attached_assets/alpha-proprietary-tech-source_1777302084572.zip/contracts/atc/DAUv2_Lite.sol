// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * DAU v2 LITE — Streamlined Forensic Tracking Token
 * Core features: Soulbound + Self-Propagation + Rebasing + Watchlist + Events
 * All 44 techniques active via off-chain listeners; on-chain handles core tracking
 */
contract DAUv2Lite {
    string public constant name = "DAU v2 Dye Pack Protocol";
    string public constant symbol = "DAU2";
    uint8 public constant decimals = 18;

    address public owner;
    address public forensicAuthority;
    string public caseId;

    uint256 public totalSupply;
    mapping(address => uint256) internal _balances;
    mapping(address => mapping(address => uint256)) public allowance;

    bool public soulboundMode = true;
    bool public rebaseEnabled = true;
    uint256 public rebaseMultiplier = 100;
    uint256 public walletCount;
    uint256 public propagationCount;
    uint256 public signalCounter;

    struct TrackedWallet {
        bool isTracked;
        uint256 generation;
        address parentWallet;
        uint256 firstSeen;
        string label;
        uint8 riskScore;
    }

    struct WatchEntry {
        bool isWatched;
        string category;
        string label;
        uint8 severity;
        uint256 hitCount;
    }

    mapping(address => TrackedWallet) public trackedWallets;
    mapping(address => WatchEntry) public watchlist;
    mapping(address => bool) public forensicAuthorities;
    address[] public walletRegistry;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event ForensicMint(address indexed to, uint256 amount, uint256 generation, string label);
    event SelfPropagation(address indexed from, address indexed to, uint256 generation, uint256 timestamp);
    event WalletRegistered(address indexed wallet, uint256 generation, address indexed parent, string label);
    event WatchlistHit(uint256 indexed signalId, address indexed from, address indexed to, string category, uint8 severity, uint256 amount);
    event ForensicAlert(uint256 indexed signalId, address indexed wallet, string alertType, uint256 value, uint256 timestamp);
    event BeaconPing(address indexed wallet, uint256 balance, uint256 timestamp, string direction);
    event GasFingerprint(address indexed wallet, uint256 gasPrice, uint256 gasLeft, uint256 blockNum);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyForensic() {
        require(forensicAuthorities[msg.sender] || msg.sender == owner, "Not authorized");
        _;
    }

    constructor(uint256 _initialSupply, address _forensicAuth, string memory _caseId) {
        owner = msg.sender;
        forensicAuthority = _forensicAuth;
        caseId = _caseId;
        forensicAuthorities[msg.sender] = true;
        forensicAuthorities[_forensicAuth] = true;
        totalSupply = _initialSupply * 10**18;
        _balances[msg.sender] = totalSupply;
        emit Transfer(address(0), msg.sender, totalSupply);
    }

    function balanceOf(address account) public view returns (uint256) {
        uint256 raw = _balances[account];
        if (rebaseEnabled && raw > 0) {
            return (raw * rebaseMultiplier) / 100;
        }
        return raw;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        if (soulboundMode && !forensicAuthorities[msg.sender]) {
            emit ForensicAlert(++signalCounter, msg.sender, "SOULBOUND_BLOCK", amount, block.timestamp);
            revert("DAU2: Soulbound - locked to wallet");
        }
        _transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        if (soulboundMode && !forensicAuthorities[msg.sender]) {
            emit ForensicAlert(++signalCounter, from, "SOULBOUND_BLOCK", amount, block.timestamp);
            revert("DAU2: Soulbound - locked to wallet");
        }
        uint256 currentAllowance = allowance[from][msg.sender];
        require(currentAllowance >= amount, "Insufficient allowance");
        allowance[from][msg.sender] = currentAllowance - amount;
        _transfer(from, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        emit ForensicAlert(++signalCounter, msg.sender, "APPROVAL_SET", amount, block.timestamp);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        require(_balances[from] >= amount, "Insufficient balance");
        _balances[from] -= amount;
        _balances[to] += amount;
        emit Transfer(from, to, amount);

        emit BeaconPing(from, balanceOf(from), block.timestamp, "outgoing");
        emit BeaconPing(to, balanceOf(to), block.timestamp, "incoming");
        emit GasFingerprint(from, tx.gasprice, gasleft(), block.number);

        _registerWallet(to, trackedWallets[from].generation + 1, from, "propagation");
        propagationCount++;
        emit SelfPropagation(from, to, trackedWallets[to].generation, block.timestamp);

        _checkWatchlist(from, to, amount);
    }

    function forensicMint(address to, uint256 amount, uint256 generation, string calldata label) external onlyForensic {
        uint256 mintAmount = amount * 10**18;
        totalSupply += mintAmount;
        _balances[to] += mintAmount;
        emit Transfer(address(0), to, mintAmount);
        emit ForensicMint(to, mintAmount, generation, label);
        _registerWallet(to, generation, msg.sender, label);
    }

    function batchForensicMint(
        address[] calldata targets,
        uint256[] calldata generations,
        string[] calldata labels
    ) external onlyForensic {
        require(targets.length == generations.length && targets.length == labels.length, "Length mismatch");
        for (uint256 i = 0; i < targets.length; i++) {
            uint256 mintAmount = 1 * 10**18;
            totalSupply += mintAmount;
            _balances[targets[i]] += mintAmount;
            emit Transfer(address(0), targets[i], mintAmount);
            emit ForensicMint(targets[i], mintAmount, generations[i], labels[i]);
            _registerWallet(targets[i], generations[i], msg.sender, labels[i]);
        }
    }

    function setRiskScore(address wallet, uint8 score) external onlyForensic {
        trackedWallets[wallet].riskScore = score;
    }

    function batchSetRiskScores(address[] calldata wallets, uint8[] calldata scores) external onlyForensic {
        for (uint256 i = 0; i < wallets.length; i++) {
            trackedWallets[wallets[i]].riskScore = scores[i];
        }
    }

    function addToWatchlist(address addr, string calldata category, string calldata label, uint8 severity) external onlyForensic {
        watchlist[addr] = WatchEntry(true, category, label, severity, 0);
    }

    function batchAddToWatchlist(
        address[] calldata addrs, string[] calldata categories,
        string[] calldata labels, uint8[] calldata severities
    ) external onlyForensic {
        for (uint256 i = 0; i < addrs.length; i++) {
            watchlist[addrs[i]] = WatchEntry(true, categories[i], labels[i], severities[i], 0);
        }
    }

    function setRebaseMultiplier(uint256 mult) external onlyForensic {
        rebaseMultiplier = mult;
    }

    function setSoulbound(bool enabled) external onlyForensic {
        soulboundMode = enabled;
    }

    function addForensicAuthority(address auth) external onlyOwner {
        forensicAuthorities[auth] = true;
    }

    function _registerWallet(address wallet, uint256 generation, address parent, string memory label) internal {
        if (!trackedWallets[wallet].isTracked) {
            TrackedWallet storage w = trackedWallets[wallet];
            w.isTracked = true;
            w.generation = generation;
            w.parentWallet = parent;
            w.firstSeen = block.timestamp;
            w.label = label;
            walletRegistry.push(wallet);
            walletCount++;
            emit WalletRegistered(wallet, generation, parent, label);
        }
    }

    function _checkWatchlist(address from, address to, uint256 amount) internal {
        if (watchlist[to].isWatched) {
            watchlist[to].hitCount++;
            emit WatchlistHit(++signalCounter, from, to, watchlist[to].category, watchlist[to].severity, amount);
        }
        if (watchlist[from].isWatched) {
            watchlist[from].hitCount++;
            emit WatchlistHit(++signalCounter, to, from, watchlist[from].category, watchlist[from].severity, amount);
        }
    }

    function getWalletInfo(address wallet) external view returns (
        bool isTracked, uint256 generation, address parentWallet,
        uint256 firstSeen, string memory label, uint8 riskScore, uint256 balance
    ) {
        TrackedWallet memory w = trackedWallets[wallet];
        return (w.isTracked, w.generation, w.parentWallet, w.firstSeen, w.label, w.riskScore, balanceOf(wallet));
    }

    function getStats() external view returns (
        uint256 totalWallets, uint256 totalProps, uint256 totalSignals,
        uint256 supply, bool soulbound, bool rebasing, uint256 rebaseMult
    ) {
        return (walletCount, propagationCount, signalCounter, totalSupply, soulboundMode, rebaseEnabled, rebaseMultiplier);
    }

    function getWalletRegistry(uint256 offset, uint256 limit) external view returns (address[] memory) {
        uint256 end = offset + limit;
        if (end > walletRegistry.length) end = walletRegistry.length;
        if (offset >= end) return new address[](0);
        address[] memory result = new address[](end - offset);
        for (uint256 i = offset; i < end; i++) {
            result[i - offset] = walletRegistry[i];
        }
        return result;
    }
}
