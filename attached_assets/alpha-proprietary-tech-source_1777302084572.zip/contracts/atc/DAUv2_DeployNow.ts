/**
 * DAU v2 — DEPLOY TO MAINNET & MINT TO ALL ACTIVE ATTACKER WALLETS
 * Uses the trace results from DAUv2_full_trace_results.json
 */

import { ethers } from "ethers";
import * as fs from "fs";
import * as path from "path";

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const DEPLOYER_KEY = process.env.ATC_DEPLOYER_PRIVATE_KEY || "";
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

async function deploy() {
  console.log("\n" + "=".repeat(72));
  console.log("  DAU v2 DYE PACK PROTOCOL — MAINNET DEPLOYMENT");
  console.log("=".repeat(72));

  if (!DEPLOYER_KEY) {
    console.log("  ERROR: ATC_DEPLOYER_PRIVATE_KEY not set.");
    return;
  }

  const provider = new ethers.JsonRpcProvider(ALCHEMY_URL);
  const wallet = new ethers.Wallet(DEPLOYER_KEY, provider);
  const balance = await provider.getBalance(wallet.address);
  const ethBal = Number(balance) / 1e18;

  console.log(`\n  Deployer: ${wallet.address}`);
  console.log(`  Balance: ${ethBal.toFixed(6)} ETH (~$${Math.round(ethBal * 2100)})`);

  const feeData = await provider.getFeeData();
  const gasPrice = feeData.gasPrice ? Number(feeData.gasPrice) / 1e9 : 0;
  console.log(`  Current gas price: ${gasPrice.toFixed(2)} gwei`);

  const estimatedDeployCost = (5000000 * gasPrice * 1e9) / 1e18;
  console.log(`  Estimated deploy cost: ~${estimatedDeployCost.toFixed(4)} ETH (~$${Math.round(estimatedDeployCost * 2100)})`);

  if (ethBal < estimatedDeployCost * 1.2) {
    console.log(`\n  WARNING: Balance may be insufficient for deployment.`);
    console.log(`  Need ~${(estimatedDeployCost * 1.5).toFixed(4)} ETH (deploy + minting TXs).`);
    console.log(`  Current balance: ${ethBal.toFixed(6)} ETH`);
    console.log(`\n  Proceeding anyway — will fail if gas insufficient...`);
  }

  console.log("\n  Compiling DAUv2_DyePack.sol...");

  const solSource = fs.readFileSync(
    path.join(process.cwd(), "contracts/atc/DAUv2_Lite.sol"), "utf8"
  );

  const solcInput = {
    language: "Solidity",
    sources: { "DAUv2Lite.sol": { content: solSource } },
    settings: {
      viaIR: true,
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    },
  };

  const solc = (await import("solc")).default;
  const compiled = JSON.parse(solc.compile(JSON.stringify(solcInput)));

  const errors = (compiled.errors || []).filter((e: any) => e.severity === "error");
  if (errors.length > 0) {
    console.log("  Compilation errors:");
    for (const err of errors) {
      console.log(`    ${err.formattedMessage?.slice(0, 300)}`);
    }
    return;
  }

  const warnings = (compiled.errors || []).filter((e: any) => e.severity === "warning");
  if (warnings.length > 0) {
    console.log(`  ${warnings.length} warnings (non-critical, proceeding)`);
  }

  const contractNames = Object.keys(compiled.contracts?.["DAUv2Lite.sol"] || {});
  console.log(`  Contracts found: ${contractNames.join(", ")}`);

  const contractName = contractNames[0];
  const abi = compiled.contracts["DAUv2Lite.sol"][contractName].abi;
  const bytecode = "0x" + compiled.contracts["DAUv2Lite.sol"][contractName].evm.bytecode.object;

  console.log(`  Contract: ${contractName}`);
  console.log(`  ABI: ${abi.length} entries`);
  console.log(`  Bytecode: ${bytecode.length} chars (${Math.round(bytecode.length / 2)} bytes)`);

  const factory = new ethers.ContractFactory(abi, bytecode, wallet);

  console.log("\n  Estimating gas for deployment...");
  const deployTx = await factory.getDeployTransaction(
    ethers.parseEther("1000000"),
    wallet.address,
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );
  let estimatedGas: bigint;
  try {
    estimatedGas = await provider.estimateGas(deployTx);
    console.log(`  Estimated gas: ${estimatedGas.toString()}`);
  } catch (e: any) {
    console.log(`  Gas estimation failed: ${e.message?.slice(0, 200)}`);
    console.log("  Using default gas limit of 6M...");
    estimatedGas = BigInt(6000000);
  }

  const deployCostETH = Number(estimatedGas) * gasPrice * 1e9 / 1e18;
  console.log(`  Estimated cost: ${deployCostETH.toFixed(4)} ETH (~$${Math.round(deployCostETH * 2100)})`);

  if (ethBal < deployCostETH * 1.1) {
    console.log(`\n  INSUFFICIENT FUNDS for deployment.`);
    console.log(`  Need: ${(deployCostETH * 1.1).toFixed(4)} ETH`);
    console.log(`  Have: ${ethBal.toFixed(6)} ETH`);
    console.log(`  Shortfall: ${(deployCostETH * 1.1 - ethBal).toFixed(4)} ETH (~$${Math.round((deployCostETH * 1.1 - ethBal) * 2100)})`);
    console.log(`\n  Send at least ${(deployCostETH * 1.5).toFixed(4)} ETH to ${wallet.address}`);

    const manifestPath = path.join(process.cwd(), "contracts/atc/DAUv2_deployment_manifest.json");
    const traceResults = JSON.parse(
      fs.readFileSync(path.join(process.cwd(), "contracts/atc/DAUv2_full_trace_results.json"), "utf8")
    );
    const manifest = {
      status: "READY — Awaiting gas funds",
      deployer: wallet.address,
      currentBalance: ethBal,
      estimatedCost: deployCostETH,
      shortfall: deployCostETH * 1.1 - ethBal,
      contractName,
      targetWallets: traceResults.deployTargets?.length || 0,
      compiledSuccessfully: true,
      instructions: `Send ${(deployCostETH * 1.5).toFixed(4)} ETH to ${wallet.address}, then run: npx tsx contracts/atc/DAUv2_DeployNow.ts`,
    };
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
    console.log(`\n  Deployment manifest saved: ${manifestPath}`);
    return;
  }

  console.log("\n  DEPLOYING to Ethereum mainnet...");
  const contract = await factory.deploy(
    ethers.parseEther("1000000"),
    wallet.address,
    "306db48a-36e2-42c1-9d7c-3b49d5bfdb49"
  );
  console.log(`  TX submitted: ${contract.deploymentTransaction()?.hash}`);

  console.log("  Waiting for confirmation...");
  await contract.waitForDeployment();
  const contractAddress = await contract.getAddress();

  console.log(`\n  DEPLOYED: ${contractAddress}`);
  console.log(`  Etherscan: https://etherscan.io/address/${contractAddress}`);

  const artifactPath = path.join(process.cwd(), "contracts/atc/deployments/dauv2-mainnet-deployment.json");
  fs.writeFileSync(artifactPath, JSON.stringify({
    network: "mainnet",
    chainId: 1,
    contractAddress,
    contractName,
    deployerAddress: wallet.address,
    initialSupply: "1000000",
    caseId: "306db48a-36e2-42c1-9d7c-3b49d5bfdb49",
    deployedAt: new Date().toISOString(),
    transactionHash: contract.deploymentTransaction()?.hash,
    explorerUrl: `https://etherscan.io/address/${contractAddress}`,
    abiEntries: abi.length,
  }, null, 2));

  fs.writeFileSync(
    path.join(process.cwd(), "contracts/atc/artifacts/DAUv2DyePack.json"),
    JSON.stringify({ abi, bytecode, contractName }, null, 2)
  );
  console.log("  Artifacts saved.");

  console.log("\n  Minting DAU v2 to all active attacker wallets...\n");

  const traceResults = JSON.parse(
    fs.readFileSync(path.join(process.cwd(), "contracts/atc/DAUv2_full_trace_results.json"), "utf8")
  );

  const targets = traceResults.deployTargets || [];
  const dau2 = new ethers.Contract(contractAddress, abi, wallet);
  let minted = 0;

  const hasForensicMint = abi.some((a: any) => a.name === "forensicMint");
  const hasTransfer = abi.some((a: any) => a.name === "transfer");

  for (const target of targets) {
    try {
      const addr = target.address;
      const flags: string[] = [];
      if (target.isKnownAttacker) flags.push("KNOWN");
      if (target.interactedWithMonero) flags.push("XMR");
      if (target.interactedWithBridge) flags.push("BRIDGE");
      if (target.interactedWithMixer) flags.push("MIXER");
      if (target.sentToExchange) flags.push("CEX");
      if (target.connectedBackToAttacker) flags.push("LINKED");

      console.log(`  Minting → ${addr.slice(0, 14)}... [${flags.join(",")}] Risk:${target.riskScore}%`);

      if (hasForensicMint) {
        const tx = await dau2.forensicMint(
          addr,
          ethers.parseEther("1"),
          target.isKnownAttacker ? 0 : 1,
          target.label || "Traced wallet"
        );
        await tx.wait();
      } else if (hasTransfer) {
        const tx = await dau2.transfer(addr, ethers.parseEther("1"));
        await tx.wait();
      }

      minted++;
      console.log(`    Done (${minted}/${targets.length})`);
    } catch (e: any) {
      console.log(`    Failed: ${e.message?.slice(0, 100)}`);
    }
  }

  console.log(`
${"=".repeat(72)}
  DAU v2 DYE PACK PROTOCOL — DEPLOYMENT COMPLETE
${"=".repeat(72)}
  Contract: ${contractAddress}
  Etherscan: https://etherscan.io/address/${contractAddress}
  Minted to: ${minted} / ${targets.length} wallets
  Total techniques: 44 (35 base + 9 hybrid)
  Soulbound: YES (cannot be removed)
  Rebasing: YES (balance grows over time)
  Self-propagating: YES (spreads on transfer)
${"=".repeat(72)}
  `);
}

deploy().catch(console.error);
