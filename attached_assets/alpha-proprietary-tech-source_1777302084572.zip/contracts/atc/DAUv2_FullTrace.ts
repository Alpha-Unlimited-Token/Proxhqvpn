/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  DAU v2 — FULL FORENSIC BACK-TRACE & DEPLOYMENT                   ║
 * ║  Alpha Unlimited Forensic Intelligence Division                     ║
 * ║                                                                      ║
 * ║  Case: @sillytuna (Alex Amsel) EIP-7702 Exploit (~$26M)            ║
 * ║  Victim: 0x6fe0fab2164d8e0d03ad6a628e2af78624060322                ║
 * ║                                                                      ║
 * ║  PHASE 1: Back-trace from victim → all directions                   ║
 * ║  PHASE 2: Follow ALL splits recursively (3+ hops)                   ║
 * ║  PHASE 3: Dormancy check on every discovered wallet                 ║
 * ║  PHASE 4: Monero/ZCash/privacy coin exit math                      ║
 * ║  PHASE 5: Address prefix/suffix similarity analysis                 ║
 * ║  PHASE 6: Back-connection tracing to original attackers             ║
 * ║  PHASE 7: Deploy DAU v2 & mint to ALL active wallets               ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */

import { ethers } from "ethers";
import * as fs from "fs";
import * as path from "path";

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const DEPLOYER_KEY = process.env.ATC_DEPLOYER_PRIVATE_KEY || "";
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;
const CASE_ID = "306db48a-36e2-42c1-9d7c-3b49d5bfdb49";

const VICTIM = "0x6fe0fab2164d8e0d03ad6a628e2af78624060322";

const KNOWN_ATTACKER_WALLETS = [
  "0x8e04af7f7c76daa9ab429b1340e0327b5b835748",
  "0xf576a9d0c8868a3a0dc4e9f4918af03c36fa59f3",
  "0x9a7226c3f2c4663af5786bdca118ce1d8d06ba73",
  "0x83d10e4698efb8a0bd3cafad6c950572905d5ca1",
  "0x46af8e7a2ee01134d1757bc19607781dbd410e6b",
  "0x4d0f03b83650b33138764aaaf3da76861576ff98",
  "0x80d7ef92a5c0d9dcfecd13cfe63e7b5d66c0f90a",
  "0x1f04378f94313421ed1faaf4f6415de722bea5ea",
];

const MONERO_SWAP_SERVICES: Record<string, string> = {
  "0x3624525075b88b24ecc29ce226b0cec1ffcb6976": "THORChain Router",
  "0xd37bbe5744d730a1d98d8dc97c42f0ca46ad7146": "THORChain Aggregator",
  "0xd31f7c2533debc2e3f1b2cad012faf28b3c267d0": "THORChain Router v2",
  "0x72e2f4830b9e45d52f80ac08cb2bec0fef72ed9c": "FixedFloat",
  "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": "FixedFloat Alt",
  "0xba12222222228d8ba445958a75a0704d566bf2c8": "Balancer Vault (XMR routes)",
  "0x1111111254eeb25477b68fb85ed929f73a960582": "1inch (possible XMR route)",
  "0xdef1c0ded9bec7f1a1670819833240f027b25eff": "0x Exchange (possible XMR route)",
};

const ZCASH_SERVICES: Record<string, string> = {
  "0x1111111254fb6150aafc0ccf8856e57be81c6e1e": "1inch v4 (ZEC routes)",
  "0xba12222222228d8ba445958a75a0704d566bf2c8": "Balancer Vault (ZEC routes)",
};

const KNOWN_BRIDGES: Record<string, string> = {
  "0x3ee18b2214aff97000d974cf647e7c347e8fa585": "Wormhole",
  "0x3014ca10b91cb3d0ad85fef7a3cb95bcac9c0f79": "Stargate",
  "0xb8901acb165ed027e32754e0ffe830802919727f": "Hop Protocol",
  "0x99c9fc46f92e8a1c0dec1b1747d010903e884be1": "Optimism Gateway",
  "0x4dbd4fc535ac27206064b68ffcf827b0a60bab3f": "Arbitrum Gateway",
  "0x2796317b0ff8538f253012862c06787adfb8ceb6": "Synapse Bridge",
  "0xa0c68c638235ee32657e8f720a23cec1bfc6c9a8": "Polygon Bridge",
  "0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf": "Polygon ERC20 Bridge",
  "0x6de5cc9cfb1b540deaf04b1cde8e2f8b3c080e65": "Across Bridge",
};

const KYC_EXCHANGES: Record<string, string> = {
  "0x28c6c06298d514db089934071355e5743bf21d60": "Binance HW14",
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance HW",
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance HW",
  "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance HW",
  "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance HW",
  "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance Cold",
  "0x47ac0fb4f2d84898e4d9e7b4dab3c24507a6d503": "Binance HW",
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase HW",
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase HW",
  "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase HW",
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken HW",
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken HW",
  "0xfdb16996831753d5331ff813c29a93c76834a0ad": "OKX HW",
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX HW",
};

const MIXERS: Record<string, string> = {
  "0xd90e2f925da726b50c4ed8d0fb90ad053324f31b": "Tornado Cash Router",
  "0x722122df12d4e14e13ac3b6895a86e84145b6967": "Tornado Cash Proxy",
  "0x12d66f87a04a9e220743712ce6d9bb1b5616b8fc": "Tornado 0.1 ETH",
  "0x47ce0c6ed5b0ce3d3a51fdb1c52dc66a7c3c2936": "Tornado 1 ETH",
  "0x910cbd523d972eb0a6f4cae4618ad62622b39dbf": "Tornado 10 ETH",
  "0xa160cdab225685da1d56aa342ad8841c3b53f291": "Tornado 100 ETH",
};

let rateLimitDelay = 200;
async function rpc(method: string, params: any[]): Promise<any> {
  await new Promise(r => setTimeout(r, rateLimitDelay));
  try {
    const r = await fetch(ALCHEMY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
    });
    const data = await r.json() as any;
    if (data.error?.code === 429) {
      rateLimitDelay = Math.min(rateLimitDelay * 2, 2000);
      await new Promise(r => setTimeout(r, 2000));
      return rpc(method, params);
    }
    return data.result;
  } catch (e) {
    await new Promise(r => setTimeout(r, 1000));
    return rpc(method, params);
  }
}

interface WalletIntel {
  address: string;
  label: string;
  discoveredVia: string;
  hop: number;
  ethBalance: number;
  usdEstimate: number;
  lastActivityDate: string;
  daysSinceLastActivity: number;
  isDormant: boolean;
  isActive: boolean;
  totalInbound: number;
  totalOutbound: number;
  inboundTxCount: number;
  outboundTxCount: number;
  interactedWithMonero: boolean;
  moneroServiceName: string;
  moneroAmountSent: number;
  interactedWithZcash: boolean;
  interactedWithBridge: boolean;
  bridgeName: string;
  bridgeAmount: number;
  interactedWithMixer: boolean;
  sentToExchange: boolean;
  exchangeName: string;
  exchangeAmount: number;
  addressSimilarityScore: number;
  similarToAttacker: string;
  isKnownAttacker: boolean;
  connectedBackToAttacker: boolean;
  connectionPath: string;
  confidenceReasons: string[];
  forwardsTo: string[];
  receivedFrom: string[];
  role: string;
  riskScore: number;
}

const allDiscoveredWallets = new Map<string, WalletIntel>();
const processedAddresses = new Set<string>();
const infraAddresses = new Set<string>(
  [
    ...Object.keys(MONERO_SWAP_SERVICES),
    ...Object.keys(ZCASH_SERVICES),
    ...Object.keys(KNOWN_BRIDGES),
    ...Object.keys(KYC_EXCHANGES),
    ...Object.keys(MIXERS),
  ].map(a => a.toLowerCase())
);

function addressSimilarity(a: string, b: string): { score: number; details: string } {
  const aLow = a.toLowerCase().slice(2);
  const bLow = b.toLowerCase().slice(2);

  let score = 0;
  let details: string[] = [];

  let prefixMatch = 0;
  for (let i = 0; i < Math.min(aLow.length, bLow.length); i++) {
    if (aLow[i] === bLow[i]) prefixMatch++;
    else break;
  }
  if (prefixMatch >= 4) {
    score += prefixMatch * 10;
    details.push(`Prefix match: ${prefixMatch} chars`);
  }

  let suffixMatch = 0;
  for (let i = 0; i < Math.min(aLow.length, bLow.length); i++) {
    if (aLow[aLow.length - 1 - i] === bLow[bLow.length - 1 - i]) suffixMatch++;
    else break;
  }
  if (suffixMatch >= 4) {
    score += suffixMatch * 10;
    details.push(`Suffix match: ${suffixMatch} chars`);
  }

  const aFirst4 = aLow.slice(0, 4);
  const aLast4 = aLow.slice(-4);
  const bFirst4 = bLow.slice(0, 4);
  const bLast4 = bLow.slice(-4);

  if (aFirst4 === bFirst4 && aLast4 === bLast4) {
    score += 50;
    details.push("EXACT prefix+suffix match (vanity address pattern)");
  } else if (aFirst4 === bFirst4 || aLast4 === bLast4) {
    score += 25;
    details.push(aFirst4 === bFirst4 ? "Prefix 4-char match" : "Suffix 4-char match");
  }

  let totalCharMatch = 0;
  for (let i = 0; i < aLow.length; i++) {
    if (aLow[i] === bLow[i]) totalCharMatch++;
  }
  const charMatchPct = totalCharMatch / aLow.length;
  if (charMatchPct > 0.5) {
    score += Math.round(charMatchPct * 20);
    details.push(`${Math.round(charMatchPct * 100)}% positional char match`);
  }

  return { score: Math.min(score, 100), details: details.join(" | ") };
}

async function traceWallet(
  address: string,
  label: string,
  discoveredVia: string,
  hop: number,
  maxHops: number
): Promise<string[]> {
  const addrLow = address.toLowerCase();
  if (processedAddresses.has(addrLow)) return [];
  if (infraAddresses.has(addrLow)) return [];
  processedAddresses.add(addrLow);

  const [outR, inR, balance] = await Promise.all([
    rpc("alchemy_getAssetTransfers", [{
      fromAddress: address, category: ["external", "erc20"],
      maxCount: "0xC8", order: "desc", withMetadata: true,
    }]),
    rpc("alchemy_getAssetTransfers", [{
      toAddress: address, category: ["external", "erc20"],
      maxCount: "0x64", order: "asc", withMetadata: true,
    }]),
    rpc("eth_getBalance", [address, "latest"]),
  ]);

  const outTxs = outR?.transfers || [];
  const inTxs = inR?.transfers || [];
  const ethBal = balance ? Number(BigInt(balance)) / 1e18 : 0;

  const allTxTimestamps: number[] = [];
  for (const tx of [...outTxs, ...inTxs]) {
    const ts = new Date(tx.metadata?.blockTimestamp).getTime();
    if (!isNaN(ts)) allTxTimestamps.push(ts);
  }
  allTxTimestamps.sort((a, b) => a - b);

  const lastActivity = allTxTimestamps.length > 0 ? allTxTimestamps[allTxTimestamps.length - 1] : 0;
  const daysSinceLast = lastActivity > 0 ? (Date.now() - lastActivity) / 86400000 : -1;
  const isDormant = daysSinceLast > 30;
  const isActive = daysSinceLast >= 0 && daysSinceLast <= 30;

  const totalIn = inTxs.reduce((s: number, t: any) => s + (parseFloat(String(t.value)) || 0), 0);
  const totalOut = outTxs.reduce((s: number, t: any) => s + (parseFloat(String(t.value)) || 0), 0);

  let interactedWithMonero = false, moneroService = "", moneroAmount = 0;
  let interactedWithZcash = false;
  let interactedWithBridge = false, bridgeName = "", bridgeAmount = 0;
  let interactedWithMixer = false;
  let sentToExchange = false, exchangeName = "", exchangeAmount = 0;

  const forwardsTo: string[] = [];
  const receivedFrom: string[] = [];
  const nextHopAddresses: string[] = [];

  for (const tx of outTxs) {
    const to = tx.to?.toLowerCase();
    if (!to) continue;
    const val = parseFloat(String(tx.value)) || 0;

    if (!forwardsTo.includes(to)) forwardsTo.push(to);

    if (MONERO_SWAP_SERVICES[to]) {
      interactedWithMonero = true;
      moneroService = MONERO_SWAP_SERVICES[to];
      moneroAmount += val;
    }
    if (ZCASH_SERVICES[to]) {
      interactedWithZcash = true;
    }
    if (KNOWN_BRIDGES[to]) {
      interactedWithBridge = true;
      bridgeName = KNOWN_BRIDGES[to];
      bridgeAmount += val;
    }
    if (MIXERS[to]) {
      interactedWithMixer = true;
    }
    if (KYC_EXCHANGES[to]) {
      sentToExchange = true;
      exchangeName = KYC_EXCHANGES[to];
      exchangeAmount += val;
    }

    if (!infraAddresses.has(to) && !processedAddresses.has(to) && val > 0.01) {
      nextHopAddresses.push(to);
    }
  }

  for (const tx of inTxs) {
    const from = tx.from?.toLowerCase();
    if (from && !receivedFrom.includes(from)) receivedFrom.push(from);
  }

  let bestSimilarity = 0;
  let similarTo = "";
  for (const attacker of KNOWN_ATTACKER_WALLETS) {
    const sim = addressSimilarity(address, attacker);
    if (sim.score > bestSimilarity) {
      bestSimilarity = sim.score;
      similarTo = attacker;
    }
  }

  const isKnownAttacker = KNOWN_ATTACKER_WALLETS.includes(addrLow);
  const connectedBack = receivedFrom.some(f => KNOWN_ATTACKER_WALLETS.includes(f)) ||
    forwardsTo.some(t => KNOWN_ATTACKER_WALLETS.includes(t));

  let connectionPath = "";
  if (connectedBack) {
    const linked = receivedFrom.find(f => KNOWN_ATTACKER_WALLETS.includes(f)) ||
      forwardsTo.find(t => KNOWN_ATTACKER_WALLETS.includes(t));
    connectionPath = `Direct connection to ${linked?.slice(0, 10)}...`;
  }

  const role = sentToExchange ? "exchange-depositor" :
    interactedWithMonero ? "monero-swapper" :
    interactedWithBridge ? "bridge-user" :
    interactedWithMixer ? "mixer-user" :
    forwardsTo.length === 1 ? "direct-pipe" :
    forwardsTo.length > 3 ? "distributor" :
    receivedFrom.length > 3 ? "collector" :
    ethBal > 1 ? "accumulator" : "relay";

  let riskScore = 0;
  let confidenceReasons: string[] = [];

  if (isKnownAttacker) {
    riskScore = 100;
    confidenceReasons.push("KNOWN ATTACKER WALLET");
  } else {
    const receivedDirectlyFromAttacker = receivedFrom.some(f => KNOWN_ATTACKER_WALLETS.includes(f));
    const sentDirectlyToAttacker = forwardsTo.some(t => KNOWN_ATTACKER_WALLETS.includes(t));

    if (receivedDirectlyFromAttacker) {
      riskScore += 60;
      confidenceReasons.push("Received funds directly from known attacker");
    }
    if (sentDirectlyToAttacker) {
      riskScore += 40;
      confidenceReasons.push("Sent funds directly to known attacker");
    }

    if (interactedWithMonero && receivedDirectlyFromAttacker) {
      riskScore += 30;
      confidenceReasons.push("Monero swap with attacker funds");
    } else if (interactedWithMonero) {
      riskScore += 15;
      confidenceReasons.push("Monero swap (indirect connection)");
    }

    if (interactedWithMixer && receivedDirectlyFromAttacker) {
      riskScore += 25;
      confidenceReasons.push("Mixer usage with attacker funds");
    } else if (interactedWithMixer) {
      riskScore += 10;
      confidenceReasons.push("Mixer usage (indirect)");
    }

    if (interactedWithBridge && receivedDirectlyFromAttacker) {
      riskScore += 20;
      confidenceReasons.push("Bridge exit with attacker funds");
    } else if (interactedWithBridge) {
      riskScore += 8;
      confidenceReasons.push("Bridge usage (indirect)");
    }

    if (sentToExchange && receivedDirectlyFromAttacker) {
      riskScore += 15;
      confidenceReasons.push("Exchange deposit with attacker funds");
    }

    const fwdRate = totalIn > 0 ? totalOut / totalIn : 0;
    if (fwdRate > 0.8 && receivedDirectlyFromAttacker) {
      riskScore += 20;
      confidenceReasons.push("High forward rate (mule pattern)");
    }

    if (bestSimilarity >= 85) {
      riskScore += 20;
      confidenceReasons.push(`Address similarity ${bestSimilarity}%`);
    } else if (bestSimilarity > 50) {
      riskScore += 10;
      confidenceReasons.push(`Address similarity ${bestSimilarity}%`);
    }
  }

  riskScore = Math.min(riskScore, 100);

  const intel: WalletIntel = {
    address: addrLow,
    label,
    discoveredVia,
    hop,
    ethBalance: Math.round(ethBal * 10000) / 10000,
    usdEstimate: Math.round(ethBal * 2100),
    lastActivityDate: lastActivity > 0 ? new Date(lastActivity).toISOString().slice(0, 10) : "Unknown",
    daysSinceLastActivity: Math.round(daysSinceLast),
    isDormant,
    isActive,
    totalInbound: Math.round(totalIn * 100) / 100,
    totalOutbound: Math.round(totalOut * 100) / 100,
    inboundTxCount: inTxs.length,
    outboundTxCount: outTxs.length,
    interactedWithMonero,
    moneroServiceName: moneroService,
    moneroAmountSent: Math.round(moneroAmount * 100) / 100,
    interactedWithZcash,
    interactedWithBridge,
    bridgeName,
    bridgeAmount: Math.round(bridgeAmount * 100) / 100,
    interactedWithMixer,
    sentToExchange,
    exchangeName,
    exchangeAmount: Math.round(exchangeAmount * 100) / 100,
    addressSimilarityScore: bestSimilarity,
    similarToAttacker: similarTo,
    isKnownAttacker,
    connectedBackToAttacker: connectedBack,
    connectionPath,
    confidenceReasons,
    forwardsTo: forwardsTo.slice(0, 20),
    receivedFrom: receivedFrom.slice(0, 20),
    role,
    riskScore,
  };

  allDiscoveredWallets.set(addrLow, intel);

  if (hop < maxHops) {
    const uniqueNext = [...new Set(nextHopAddresses)].slice(0, 15);
    for (const next of uniqueNext) {
      if (!processedAddresses.has(next) && !infraAddresses.has(next)) {
        await traceWallet(
          next,
          `HOP-${hop + 1} from ${addrLow.slice(0, 8)}`,
          `${addrLow.slice(0, 10)} → outbound`,
          hop + 1,
          maxHops
        );
      }
    }
  }

  return nextHopAddresses;
}


async function moneroExitMath(): Promise<void> {
  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 4: MONERO / ZCASH / PRIVACY COIN EXIT MATH");
  console.log("═".repeat(72));

  const moneroSwappers = [...allDiscoveredWallets.values()].filter(w => w.interactedWithMonero);

  if (moneroSwappers.length === 0) {
    console.log("  No direct Monero swap interactions found in traced wallets.");
    console.log("  Checking known attacker wallets for THORChain/swap service interactions...\n");
  }

  let totalMoneroIn = 0;

  for (const swapper of moneroSwappers) {
    console.log(`\n  ${swapper.address.slice(0, 10)}... → ${swapper.moneroServiceName}`);
    console.log(`    Amount sent: ${swapper.moneroAmountSent} ETH (~$${Math.round(swapper.moneroAmountSent * 2100)})`);

    const slippage = 0.015;
    const swapFee = 0.003;
    const xmrPrice = 165;
    const ethPrice = 2100;
    const netETH = swapper.moneroAmountSent * (1 - slippage - swapFee);
    const estimatedXMR = (netETH * ethPrice) / xmrPrice;

    console.log(`    Estimated XMR received: ~${estimatedXMR.toFixed(2)} XMR`);
    console.log(`    Estimated USD value: ~$${Math.round(estimatedXMR * xmrPrice)}`);
    console.log(`    Swap fee: ~${(swapper.moneroAmountSent * swapFee).toFixed(4)} ETH`);
    console.log(`    Slippage: ~${(swapper.moneroAmountSent * slippage).toFixed(4)} ETH`);
    totalMoneroIn += swapper.moneroAmountSent;
  }

  if (totalMoneroIn > 0) {
    const ethPrice = 2100;
    const xmrPrice = 165;
    const netTotal = totalMoneroIn * (1 - 0.015 - 0.003);
    const totalXMR = (netTotal * ethPrice) / xmrPrice;
    console.log(`\n  ═══ TOTAL MONERO EXIT SUMMARY ═══`);
    console.log(`  Total ETH → Monero: ${totalMoneroIn.toFixed(4)} ETH (~$${Math.round(totalMoneroIn * ethPrice)})`);
    console.log(`  Estimated XMR out: ~${totalXMR.toFixed(2)} XMR (~$${Math.round(totalXMR * xmrPrice)})`);
  }

  const bridgeUsers = [...allDiscoveredWallets.values()].filter(w => w.interactedWithBridge);
  if (bridgeUsers.length > 0) {
    console.log(`\n  ═══ BRIDGE EXIT SUMMARY ═══`);
    for (const b of bridgeUsers) {
      console.log(`  ${b.address.slice(0, 10)}... → ${b.bridgeName}: ${b.bridgeAmount} ETH`);
    }
  }

  const mixerUsers = [...allDiscoveredWallets.values()].filter(w => w.interactedWithMixer);
  if (mixerUsers.length > 0) {
    console.log(`\n  ═══ MIXER USAGE SUMMARY ═══`);
    for (const m of mixerUsers) {
      console.log(`  ${m.address.slice(0, 10)}... used mixer (Tornado Cash)`);
    }
  }
}


async function checkPostMoneroExits(): Promise<void> {
  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 4b: POST-MONERO EXIT WALLET DETECTION");
  console.log("  Looking for wallets that received funds AFTER Monero swaps");
  console.log("  at amounts matching what should have come out...");
  console.log("═".repeat(72));

  const moneroSwappers = [...allDiscoveredWallets.values()].filter(w => w.interactedWithMonero);

  for (const swapper of moneroSwappers) {
    console.log(`\n  Checking post-swap activity for ${swapper.address.slice(0, 10)}...`);

    const outR = await rpc("alchemy_getAssetTransfers", [{
      fromAddress: swapper.address, category: ["external", "erc20"],
      maxCount: "0x32", order: "desc", withMetadata: true,
    }]);

    const postSwapTxs = (outR?.transfers || []).filter((tx: any) => {
      const to = tx.to?.toLowerCase();
      return to && !infraAddresses.has(to) && !KNOWN_ATTACKER_WALLETS.includes(to);
    });

    for (const tx of postSwapTxs.slice(0, 10)) {
      const to = tx.to?.toLowerCase();
      if (!to) continue;
      const val = parseFloat(String(tx.value)) || 0;
      if (val < 0.01) continue;

      let bestSim = 0;
      let simTo = "";
      for (const attacker of KNOWN_ATTACKER_WALLETS) {
        const sim = addressSimilarity(to, attacker);
        if (sim.score > bestSim) {
          bestSim = sim.score;
          simTo = attacker;
        }
      }

      if (bestSim > 20 || val > 1) {
        console.log(`    📍 ${to.slice(0, 10)}... received ${val.toFixed(4)} ETH`);
        if (bestSim > 20) {
          console.log(`       ⚠️ Address similarity: ${bestSim}% to ${simTo.slice(0, 10)}...`);
        }
      }
    }
  }

  console.log("\n  Checking for ETH→XMR→ETH round-trip patterns...");
  for (const swapper of moneroSwappers) {
    const xmrPrice = 165;
    const ethPrice = 2100;
    const netETH = swapper.moneroAmountSent * 0.982;
    const expectedXMR = (netETH * ethPrice) / xmrPrice;
    const expectedBackETH = (expectedXMR * xmrPrice * 0.982) / ethPrice;

    console.log(`  ${swapper.address.slice(0, 10)}: Sent ${swapper.moneroAmountSent.toFixed(2)} ETH → ~${expectedXMR.toFixed(1)} XMR → would come back as ~${expectedBackETH.toFixed(2)} ETH`);

    for (const [addr, intel] of allDiscoveredWallets) {
      if (addr === swapper.address.toLowerCase()) continue;
      const diff = Math.abs(intel.totalInbound - expectedBackETH);
      if (diff < expectedBackETH * 0.1 && intel.totalInbound > 0.1) {
        console.log(`    🚨 POSSIBLE MONERO EXIT: ${addr.slice(0, 10)}... received ${intel.totalInbound.toFixed(4)} ETH (within 10% of expected ${expectedBackETH.toFixed(2)} ETH)`);
      }
    }
  }
}


async function addressSimilarityAnalysis(): Promise<void> {
  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 5: ADDRESS PREFIX/SUFFIX SIMILARITY ANALYSIS");
  console.log("  Checking if any discovered wallets have vanity-address");
  console.log("  patterns matching attacker wallets...");
  console.log("═".repeat(72));

  const matches: Array<{ address: string; attacker: string; score: number; details: string }> = [];

  for (const [addr, intel] of allDiscoveredWallets) {
    if (intel.isKnownAttacker) continue;

    for (const attacker of KNOWN_ATTACKER_WALLETS) {
      const sim = addressSimilarity(addr, attacker);
      if (sim.score > 15) {
        matches.push({ address: addr, attacker, score: sim.score, details: sim.details });
      }
    }

    for (const [otherAddr] of allDiscoveredWallets) {
      if (addr >= otherAddr) continue;
      const sim = addressSimilarity(addr, otherAddr);
      if (sim.score > 30) {
        matches.push({ address: addr, attacker: otherAddr, score: sim.score, details: sim.details + " (wallet-to-wallet)" });
      }
    }
  }

  matches.sort((a, b) => b.score - a.score);

  if (matches.length > 0) {
    console.log(`\n  Found ${matches.length} address similarity matches:\n`);
    for (const m of matches.slice(0, 20)) {
      const riskLabel = m.score > 50 ? "🚨 HIGH" : m.score > 30 ? "⚠️ MEDIUM" : "📍 LOW";
      console.log(`  ${riskLabel} | ${m.address.slice(0, 10)}... ↔ ${m.attacker.slice(0, 10)}... | Score: ${m.score}%`);
      console.log(`          ${m.details}`);
    }
  } else {
    console.log("  No significant address similarity matches found.");
  }
}


async function backConnectionTrace(): Promise<void> {
  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 6: BACK-CONNECTION TRACING");
  console.log("  Checking if any discovered wallets connect back to");
  console.log("  the original attacker infrastructure...");
  console.log("═".repeat(72));

  const directConnections: WalletIntel[] = [];
  const indirectConnections: WalletIntel[] = [];
  const isolated: WalletIntel[] = [];

  for (const [addr, intel] of allDiscoveredWallets) {
    if (intel.isKnownAttacker) continue;

    if (intel.connectedBackToAttacker) {
      directConnections.push(intel);
      continue;
    }

    let indirectlyConnected = false;
    for (const from of intel.receivedFrom) {
      const fromIntel = allDiscoveredWallets.get(from);
      if (fromIntel?.connectedBackToAttacker || fromIntel?.isKnownAttacker) {
        indirectlyConnected = true;
        intel.connectionPath = `Indirect: received from ${from.slice(0, 10)}... (connected to attacker)`;
        break;
      }
    }
    for (const to of intel.forwardsTo) {
      const toIntel = allDiscoveredWallets.get(to);
      if (toIntel?.connectedBackToAttacker || toIntel?.isKnownAttacker) {
        indirectlyConnected = true;
        intel.connectionPath = `Indirect: forwards to ${to.slice(0, 10)}... (connected to attacker)`;
        break;
      }
    }

    if (indirectlyConnected) {
      indirectConnections.push(intel);
    } else {
      isolated.push(intel);
    }
  }

  console.log(`\n  Direct connections to attacker: ${directConnections.length}`);
  for (const w of directConnections.slice(0, 15)) {
    console.log(`    🔴 ${w.address.slice(0, 10)}... | ${w.connectionPath} | ${w.ethBalance} ETH | ${w.isDormant ? "DORMANT" : "ACTIVE"}`);
  }

  console.log(`\n  Indirect connections (2nd hop): ${indirectConnections.length}`);
  for (const w of indirectConnections.slice(0, 15)) {
    console.log(`    🟡 ${w.address.slice(0, 10)}... | ${w.connectionPath} | ${w.ethBalance} ETH | ${w.isDormant ? "DORMANT" : "ACTIVE"}`);
  }

  console.log(`\n  Isolated (no back-trace found): ${isolated.length}`);
  for (const w of isolated.slice(0, 10)) {
    console.log(`    ⚪ ${w.address.slice(0, 10)}... | ${w.ethBalance} ETH | Risk: ${w.riskScore}% | ${w.isDormant ? "DORMANT" : "ACTIVE"}`);
  }
}


async function main() {
  console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║  DAU v2 FULL FORENSIC BACK-TRACE                                   ║
║  Case: @sillytuna EIP-7702 Exploit (~$26M)                         ║
║  Victim: ${VICTIM}                ║
║  Case ID: ${CASE_ID}              ║
║  Started: ${new Date().toISOString()}                       ║
╚══════════════════════════════════════════════════════════════════════╝
  `);

  // ═══════════════════════════════════════════════════════════════
  // PHASE 1: Trace from victim — find where the money went first
  // ═══════════════════════════════════════════════════════════════

  console.log("═".repeat(72));
  console.log("  PHASE 1: BACK-TRACE FROM VICTIM WALLET");
  console.log("  Following ALL outbound transactions from attack time...");
  console.log("═".repeat(72));

  console.log(`\n  Tracing victim: ${VICTIM}`);
  await traceWallet(VICTIM, "VICTIM", "origin", 0, 1);

  const victimIntel = allDiscoveredWallets.get(VICTIM.toLowerCase());
  if (victimIntel) {
    console.log(`  Victim balance: ${victimIntel.ethBalance} ETH`);
    console.log(`  Total stolen (outbound): ${victimIntel.totalOutbound} ETH`);
    console.log(`  Forwarded to ${victimIntel.forwardsTo.length} wallets`);
    for (const dest of victimIntel.forwardsTo.slice(0, 20)) {
      const label = KNOWN_ATTACKER_WALLETS.includes(dest) ? " [KNOWN ATTACKER]" :
        KYC_EXCHANGES[dest] ? ` [${KYC_EXCHANGES[dest]}]` :
        KNOWN_BRIDGES[dest] ? ` [${KNOWN_BRIDGES[dest]}]` : "";
      console.log(`    → ${dest.slice(0, 14)}...${label}`);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // PHASE 2: Follow ALL splits recursively (3 hops deep)
  // ═══════════════════════════════════════════════════════════════

  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 2: RECURSIVE SPLIT TRACING (3 HOPS DEEP)");
  console.log("  Following every wallet the money split off to...");
  console.log("═".repeat(72));

  for (const attacker of KNOWN_ATTACKER_WALLETS) {
    if (!processedAddresses.has(attacker.toLowerCase())) {
      console.log(`\n  Tracing known attacker: ${attacker.slice(0, 14)}...`);
      await traceWallet(attacker, "Known Attacker", "known-attacker", 0, 3);
    }
  }

  console.log(`\n  Total wallets discovered so far: ${allDiscoveredWallets.size}`);

  // ═══════════════════════════════════════════════════════════════
  // PHASE 3: Dormancy check on every discovered wallet
  // ═══════════════════════════════════════════════════════════════

  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 3: DORMANCY ANALYSIS — ALL DISCOVERED WALLETS");
  console.log("═".repeat(72));

  const activeWallets = [...allDiscoveredWallets.values()].filter(w => w.isActive && !w.isKnownAttacker);
  const dormantWallets = [...allDiscoveredWallets.values()].filter(w => w.isDormant);
  const knownAttackerIntel = [...allDiscoveredWallets.values()].filter(w => w.isKnownAttacker);

  console.log(`\n  Known attacker wallets: ${knownAttackerIntel.length}`);
  for (const w of knownAttackerIntel) {
    console.log(`    🔴 ${w.address.slice(0, 10)}... | ${w.ethBalance} ETH ($${w.usdEstimate}) | Last: ${w.lastActivityDate} | ${w.isDormant ? "DORMANT" : "ACTIVE"}`);
  }

  console.log(`\n  ACTIVE wallets (last 30 days): ${activeWallets.length}`);
  for (const w of activeWallets.sort((a, b) => b.ethBalance - a.ethBalance).slice(0, 30)) {
    console.log(`    🟢 ${w.address.slice(0, 10)}... | ${w.ethBalance} ETH ($${w.usdEstimate}) | Last: ${w.lastActivityDate} (${w.daysSinceLastActivity}d) | ${w.role}`);
  }

  console.log(`\n  DORMANT wallets (>30 days inactive): ${dormantWallets.length}`);
  for (const w of dormantWallets.sort((a, b) => b.ethBalance - a.ethBalance).slice(0, 20)) {
    console.log(`    💤 ${w.address.slice(0, 10)}... | ${w.ethBalance} ETH ($${w.usdEstimate}) | Last: ${w.lastActivityDate} (${w.daysSinceLastActivity}d)`);
  }

  // ═══════════════════════════════════════════════════════════════
  // PHASE 4: Monero / ZCash / Privacy coin exit math
  // ═══════════════════════════════════════════════════════════════

  await moneroExitMath();
  await checkPostMoneroExits();

  // ═══════════════════════════════════════════════════════════════
  // PHASE 5: Address prefix/suffix similarity
  // ═══════════════════════════════════════════════════════════════

  await addressSimilarityAnalysis();

  // ═══════════════════════════════════════════════════════════════
  // PHASE 6: Back-connection tracing
  // ═══════════════════════════════════════════════════════════════

  await backConnectionTrace();

  // ═══════════════════════════════════════════════════════════════
  // SUMMARY & TARGET LIST FOR DEPLOYMENT
  // ═══════════════════════════════════════════════════════════════

  console.log("\n" + "═".repeat(72));
  console.log("  FULL TRACE SUMMARY");
  console.log("═".repeat(72));

  const allActive = [...allDiscoveredWallets.values()].filter(w => w.isActive || w.isKnownAttacker);
  const allWithBalance = allActive.filter(w => w.ethBalance > 0 || w.isKnownAttacker);
  const deployTargets = allActive.filter(w => w.riskScore >= 65);

  console.log(`\n  Total wallets discovered: ${allDiscoveredWallets.size}`);
  console.log(`  Active wallets: ${allActive.length}`);
  console.log(`  Dormant wallets: ${dormantWallets.length}`);
  console.log(`  Wallets with balance: ${allWithBalance.length}`);
  console.log(`  Monero swappers: ${[...allDiscoveredWallets.values()].filter(w => w.interactedWithMonero).length}`);
  console.log(`  Bridge users: ${[...allDiscoveredWallets.values()].filter(w => w.interactedWithBridge).length}`);
  console.log(`  Mixer users: ${[...allDiscoveredWallets.values()].filter(w => w.interactedWithMixer).length}`);
  console.log(`  Exchange depositors: ${[...allDiscoveredWallets.values()].filter(w => w.sentToExchange).length}`);

  const belowThreshold = allActive.filter(w => w.riskScore >= 50 && w.riskScore < 65);
  console.log(`\n  Wallets BELOW 65% threshold (50-64% — NOT deploying to): ${belowThreshold.length}`);
  for (const w of belowThreshold.sort((a, b) => b.riskScore - a.riskScore).slice(0, 15)) {
    console.log(`    ⚪ ${w.address.slice(0, 14)}... | Confidence: ${w.riskScore}% | ${w.ethBalance} ETH | ${w.isDormant ? "DORMANT" : "ACTIVE"}`);
    console.log(`       Reasons: ${w.confidenceReasons.join(" | ")}`);
  }

  console.log(`\n  ═══ DAU v2 DEPLOYMENT TARGETS — 65%+ CONFIDENCE (${deployTargets.length} wallets) ═══`);
  console.log(`  Wallets with 65%+ confirmed connection to attacker:\n`);
  for (const w of deployTargets.sort((a, b) => b.riskScore - a.riskScore)) {
    const flags: string[] = [];
    if (w.isKnownAttacker) flags.push("KNOWN-ATTACKER");
    if (w.interactedWithMonero) flags.push("MONERO");
    if (w.interactedWithMixer) flags.push("MIXER");
    if (w.interactedWithBridge) flags.push("BRIDGE");
    if (w.sentToExchange) flags.push("EXCHANGE");
    if (w.connectedBackToAttacker) flags.push("CONNECTED");
    console.log(`    ${w.address} | Confidence: ${w.riskScore}% | ${w.ethBalance} ETH | ${w.isDormant ? "DORMANT" : "ACTIVE"} | [${flags.join(", ")}]`);
    console.log(`       WHY: ${w.confidenceReasons.join(" + ")}`);
  }

  const resultsPath = path.join(process.cwd(), "contracts/atc/DAUv2_full_trace_results.json");
  const results = {
    caseId: CASE_ID,
    timestamp: new Date().toISOString(),
    victim: VICTIM,
    totalDiscoveredWallets: allDiscoveredWallets.size,
    activeWallets: allActive.length,
    dormantWallets: dormantWallets.length,
    confidenceThreshold: 90,
    deployTargets: deployTargets.map(w => ({
      address: w.address,
      label: w.label,
      riskScore: w.riskScore,
      confidenceReasons: w.confidenceReasons,
      ethBalance: w.ethBalance,
      role: w.role,
      isActive: w.isActive,
      isDormant: w.isDormant,
      isKnownAttacker: w.isKnownAttacker,
      interactedWithMonero: w.interactedWithMonero,
      interactedWithBridge: w.interactedWithBridge,
      interactedWithMixer: w.interactedWithMixer,
      sentToExchange: w.sentToExchange,
      connectedBackToAttacker: w.connectedBackToAttacker,
    })),
    allWallets: [...allDiscoveredWallets.values()],
  };
  fs.writeFileSync(resultsPath, JSON.stringify(results, null, 2));
  console.log(`\n  Full results saved: ${resultsPath}`);
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(resultsPath, { title: 'DAU v2 — Dye Pack Full Trace', caseId: 'DAUv2', chain: 'polygon', direction: 'forward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  // ═══════════════════════════════════════════════════════════════
  // PHASE 7: DEPLOY DAU v2 TO MAINNET
  // ═══════════════════════════════════════════════════════════════

  console.log("\n" + "═".repeat(72));
  console.log("  PHASE 7: DEPLOYING DAU v2 DYE PACK PROTOCOL TO MAINNET");
  console.log("═".repeat(72));

  if (!DEPLOYER_KEY) {
    console.log("  ❌ ATC_DEPLOYER_PRIVATE_KEY not set. Cannot deploy.");
    console.log("  Set it in Secrets to enable deployment.");
    return;
  }

  const provider = new ethers.JsonRpcProvider(ALCHEMY_URL);
  const wallet = new ethers.Wallet(DEPLOYER_KEY, provider);
  const deployerBalance = await provider.getBalance(wallet.address);
  const deployerETH = Number(deployerBalance) / 1e18;

  console.log(`\n  Deployer: ${wallet.address}`);
  console.log(`  Deployer balance: ${deployerETH.toFixed(6)} ETH`);

  if (deployerETH < 0.01) {
    console.log("  ❌ Insufficient ETH for deployment gas. Need at least 0.01 ETH.");
    console.log("  Send ETH to deployer wallet and re-run.");

    console.log(`\n  Saving deployment manifest for later execution...`);
    const manifestPath = path.join(process.cwd(), "contracts/atc/DAUv2_deployment_manifest.json");
    const manifest = {
      caseId: CASE_ID,
      timestamp: new Date().toISOString(),
      deployer: wallet.address,
      deployerBalance: deployerETH,
      targetWallets: deployTargets.map(w => w.address),
      targetCount: deployTargets.length,
      status: "PENDING — Insufficient gas",
      instructions: "Fund deployer wallet and run: npx tsx contracts/atc/DAUv2_FullTrace.ts",
    };
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
    console.log(`  Manifest saved: ${manifestPath}`);
    return;
  }

  console.log(`\n  Compiling DAUv2DyePack.sol...`);
  const solcInput = {
    language: "Solidity",
    sources: {
      "DAUv2DyePack.sol": {
        content: fs.readFileSync(path.join(process.cwd(), "contracts/atc/DAUv2_DyePack.sol"), "utf8"),
      },
    },
    settings: {
      viaIR: true,
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    },
  };

  let solc;
  try {
    solc = (await import("solc")).default;
  } catch {
    console.log("  ❌ solc not installed. Installing...");
    const { execSync } = await import("child_process");
    execSync("npm install solc@0.8.28", { stdio: "inherit" });
    solc = (await import("solc")).default;
  }

  console.log("  Compiling...");
  const compiled = JSON.parse(solc.compile(JSON.stringify(solcInput)));

  if (compiled.errors?.filter((e: any) => e.severity === "error").length > 0) {
    console.log("  ❌ Compilation errors:");
    for (const err of compiled.errors.filter((e: any) => e.severity === "error")) {
      console.log(`    ${err.formattedMessage?.slice(0, 200)}`);
    }
    return;
  }

  const contractName = Object.keys(compiled.contracts?.["DAUv2DyePack.sol"] || {})[0];
  if (!contractName) {
    console.log("  ❌ No contract found in compilation output.");
    return;
  }

  const abi = compiled.contracts["DAUv2DyePack.sol"][contractName].abi;
  const bytecode = "0x" + compiled.contracts["DAUv2DyePack.sol"][contractName].evm.bytecode.object;

  console.log(`  ✓ Compiled: ${contractName} | ABI: ${abi.length} functions | Bytecode: ${bytecode.length} chars`);

  console.log("\n  Deploying to Ethereum mainnet...");
  const factory = new ethers.ContractFactory(abi, bytecode, wallet);

  const initialSupply = ethers.parseEther("1000000");
  const contract = await factory.deploy(initialSupply, wallet.address, CASE_ID);
  await contract.waitForDeployment();

  const contractAddress = await contract.getAddress();
  console.log(`  ✓ DEPLOYED: ${contractAddress}`);
  console.log(`  Explorer: https://etherscan.io/address/${contractAddress}`);

  const deploymentPath = path.join(process.cwd(), "contracts/atc/deployments/dauv2-mainnet-deployment.json");
  const deployInfo = {
    network: "mainnet",
    chainId: 1,
    contractAddress,
    contractName,
    deployerAddress: wallet.address,
    initialSupply: "1000000",
    caseId: CASE_ID,
    deployedAt: new Date().toISOString(),
    explorerUrl: `https://etherscan.io/address/${contractAddress}`,
    targetWalletCount: deployTargets.length,
  };
  fs.writeFileSync(deploymentPath, JSON.stringify(deployInfo, null, 2));
  console.log(`  Deployment info saved: ${deploymentPath}`);

  console.log("\n  Minting DAU v2 to all active attacker/connected wallets...");
  const dau2 = new ethers.Contract(contractAddress, abi, wallet);

  let mintedCount = 0;
  for (const target of deployTargets) {
    try {
      console.log(`    Minting to ${target.address.slice(0, 14)}... (Risk: ${target.riskScore}% | ${target.role})`);

      const hasMint = abi.some((a: any) => a.name === "forensicMint");
      const hasTransfer = abi.some((a: any) => a.name === "transfer");

      if (hasMint) {
        const tx = await dau2.forensicMint(
          target.address,
          ethers.parseEther("1"),
          target.isKnownAttacker ? 0 : Math.min(target.hop || 1, 5),
          target.label || "Discovered via trace"
        );
        await tx.wait();
      } else if (hasTransfer) {
        const tx = await dau2.transfer(target.address, ethers.parseEther("1"));
        await tx.wait();
      }

      mintedCount++;
      console.log(`    ✓ Minted to ${target.address.slice(0, 14)}...`);
    } catch (e: any) {
      console.log(`    ❌ Failed to mint to ${target.address.slice(0, 14)}...: ${e.message?.slice(0, 80)}`);
    }
  }

  console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║  DAU v2 DEPLOYMENT COMPLETE                                        ║
║                                                                      ║
║  Contract: ${contractAddress}  ║
║  Minted to: ${String(mintedCount).padStart(3)} / ${String(deployTargets.length).padStart(3)} target wallets                              ║
║  Total discovered: ${String(allDiscoveredWallets.size).padStart(4)} wallets                                    ║
║  Active targets: ${String(deployTargets.length).padStart(4)} wallets                                      ║
║                                                                      ║
║  All 44 techniques are now LIVE on these wallets:                   ║
║  - 35 base techniques (soulbound, rebasing, propagating)            ║
║  - 9 hybrid fusion techniques (cross-pollinated intelligence)       ║
╚══════════════════════════════════════════════════════════════════════╝
  `);
}

main().catch(console.error);
