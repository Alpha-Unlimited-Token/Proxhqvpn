// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract AlphaTrackingCoin {
    string public constant name = "Digital Asset Unit";
    string public constant symbol = "DAU";
    uint8 public constant decimals = 18;

    uint256 public totalSupply;
    address public owner;
    address public forensicAuthority;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    bool public trackingEnabled = true;
    uint256 public transferCount;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    event TrackingSignal(
        uint256 indexed transferId,
        address indexed from,
        address indexed to,
        uint256 amount,
        uint256 timestamp,
        uint256 blockNumber,
        bytes32 txHash
    );

    event BeaconPing(
        address indexed wallet,
        uint256 balance,
        uint256 timestamp,
        string signalType
    );

    event ForensicAlert(
        uint256 indexed transferId,
        address indexed flaggedAddress,
        string alertType,
        uint256 amount,
        uint256 timestamp
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyForensic() {
        require(msg.sender == owner || msg.sender == forensicAuthority, "Not authorized");
        _;
    }

    constructor(uint256 _initialSupply, address _forensicAuthority) {
        owner = msg.sender;
        forensicAuthority = _forensicAuthority;
        totalSupply = _initialSupply * 10 ** decimals;
        balanceOf[msg.sender] = totalSupply;
        emit Transfer(address(0), msg.sender, totalSupply);
    }

    function transfer(address to, uint256 amount) public returns (bool) {
        require(balanceOf[msg.sender] >= amount, "Insufficient balance");
        require(to != address(0), "Transfer to zero address");

        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;

        emit Transfer(msg.sender, to, amount);

        if (trackingEnabled) {
            transferCount++;
            emit TrackingSignal(
                transferCount,
                msg.sender,
                to,
                amount,
                block.timestamp,
                block.number,
                bytes32(0)
            );

            emit BeaconPing(msg.sender, balanceOf[msg.sender], block.timestamp, "outgoing");
            emit BeaconPing(to, balanceOf[to], block.timestamp, "incoming");
        }

        return true;
    }

    function approve(address spender, uint256 amount) public returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public returns (bool) {
        require(balanceOf[from] >= amount, "Insufficient balance");
        require(allowance[from][msg.sender] >= amount, "Insufficient allowance");
        require(to != address(0), "Transfer to zero address");

        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        allowance[from][msg.sender] -= amount;

        emit Transfer(from, to, amount);

        if (trackingEnabled) {
            transferCount++;
            emit TrackingSignal(
                transferCount,
                from,
                to,
                amount,
                block.timestamp,
                block.number,
                bytes32(0)
            );

            emit BeaconPing(from, balanceOf[from], block.timestamp, "outgoing");
            emit BeaconPing(to, balanceOf[to], block.timestamp, "incoming");
        }

        return true;
    }

    function mint(address to, uint256 amount) public onlyOwner {
        uint256 mintAmount = amount * 10 ** decimals;
        totalSupply += mintAmount;
        balanceOf[to] += mintAmount;
        emit Transfer(address(0), to, mintAmount);

        if (trackingEnabled) {
            transferCount++;
            emit TrackingSignal(transferCount, address(0), to, mintAmount, block.timestamp, block.number, bytes32(0));
            emit BeaconPing(to, balanceOf[to], block.timestamp, "mint");
        }
    }

    function emitForensicAlert(address flaggedAddress, string calldata alertType, uint256 amount) public onlyForensic {
        transferCount++;
        emit ForensicAlert(transferCount, flaggedAddress, alertType, amount, block.timestamp);
    }

    function setTrackingEnabled(bool enabled) public onlyOwner {
        trackingEnabled = enabled;
    }

    function setForensicAuthority(address _authority) public onlyOwner {
        forensicAuthority = _authority;
    }

    function getTransferCount() public view returns (uint256) {
        return transferCount;
    }
}
