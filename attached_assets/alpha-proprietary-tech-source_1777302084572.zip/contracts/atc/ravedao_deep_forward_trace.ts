/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL
 *
 * Title 17 (US Copyright)  ·  17 U.S.C. § 1201 (DMCA)
 * 18 U.S.C. § 1030 (CFAA)  ·  18 U.S.C. § 1836 (DTSA)
 *
 * Alpha Proceeds Forward-Trace Engine™ (DEEP MODE) — RAVEDAO_DUMP case.
 *
 * Extends the standard 1-hop forward trace into a 3-hop BFS (240h window,
 * 8 branches/hop) and additionally resolves the CURRENT on-chain status of
 * every terminal node (ETH + WETH + USDC + USDT + DAI balance) so we can
 * report not just where the proceeds went but where they ARE NOW.
 *
 * Per-dumper "where is it now" verdict buckets:
 *  - CASHED_OUT_TO_CEX   (CEX deposit address)
 *  - BRIDGED_OUT         (canonical L2/cross-chain bridge)
 *  - MIXED               (Tornado / known mixer)
 *  - SWAPPED             (DEX router / aggregator / OTC swap)
 *  - SOLD_NFT            (OpenSea / Blur / LooksRare)
 *  - STILL_RESTING_EOA   (EOA terminal w/ current balance ≥ $100)
 *  - DRAINED_EOA         (EOA terminal w/ current balance < $100)
 *  - UNKNOWN_CONTRACT    (contract not in label DB)
 *
 * INTERNAL OWNER USE ONLY — do not redistribute.
 */

import fs from 'node:fs';
import path from 'node:path';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';

enforceProprietaryLicense('Alpha Proceeds Forward-Trace Engine™ (Deep Mode)');

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) { console.error('FATAL: ALCHEMY_API_KEY not set'); process.exit(1); }
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const ANALYSIS_PATH = path.resolve('contracts/atc/ravedao_dump_analysis.json');
const OUT_JSON = path.resolve('contracts/atc/ravedao_deep_forward_trace.json');
const OUT_HTML = path.resolve('contracts/atc/ravedao_deep_forward_trace.html');

const NOW = Date.now();
const WINDOW_HOURS = 240;       // 10 days — captures slower follow-on movement
const WINDOW_START = NOW - WINDOW_HOURS * 3600 * 1000;
const MAX_HOPS = 2;             // BFS depth (was 1 in original)
const MAX_BRANCHES_PER_HOP = 6;
const RATE_LIMIT_MS = 50;
const RESTING_USD_THRESHOLD = 100;

const PRICES_USD: Record<string, number> = {
  ETH: 2080, WETH: 2080,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1, FRAX: 1, USDS: 1, GHO: 1, LUSD: 1, USDE: 1, PYUSD: 1, CRVUSD: 1,
  WBTC: 67000, BTC: 67000, CBBTC: 67000, TBTC: 67000,
  UNI: 8.5, LINK: 14, MATIC: 0.6, ARB: 0.6, OP: 1.7, AAVE: 130, MKR: 1450, COMP: 50, CRV: 0.4, LDO: 1.1,
  PEPE: 0.000008, SHIB: 0.000016, FLOKI: 0.00012, RAVE: 0,
};

// Top 4 stable/liquid ERC-20s — used for "where is it now" terminal balance lookup.
const BALANCE_PROBE_TOKENS: { symbol: string; address: string; decimals: number }[] = [
  { symbol: 'WETH', address: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2', decimals: 18 },
  { symbol: 'USDC', address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', decimals: 6 },
  { symbol: 'USDT', address: '0xdac17f958d2ee523a2206206994597c13d831ec7', decimals: 6 },
  { symbol: 'DAI',  address: '0x6b175474e89094c44da98b954eedeac495271d0f', decimals: 18 },
];

const SPECIAL_LABELS: Record<string, { name: string; category: string; risk: number }> = {
  // Bridges
  '0x88ad09518695c6c3712ac10a214be5109a655671': { name: 'Gnosis Bridge (xDai)', category: 'bridge', risk: 5 },
  '0xa0c68c638235ee32657e8f720a23cec1bfc77c77': { name: 'Polygon (Matic) Bridge', category: 'bridge', risk: 5 },
  '0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf': { name: 'Polygon (Matic) Bridge', category: 'bridge', risk: 5 },
  '0xa3a7b6f88361f48403514059f1f16c8e78d60eec': { name: 'Arbitrum Bridge', category: 'bridge', risk: 5 },
  '0x5288c571fd7ad117bea99bf60fe0846c4e84f933': { name: 'Arbitrum L1 Gateway', category: 'bridge', risk: 5 },
  '0x99c9fc46f92e8a1c0dec1b1747d010903e884be1': { name: 'Optimism Bridge', category: 'bridge', risk: 5 },
  '0x3154cf16ccdb4c6d922629664174b904d80f2c35': { name: 'Base Bridge', category: 'bridge', risk: 5 },
  // Mixers
  '0x8589427373d6d84e98730d7795d8f6f8731fda16': { name: 'Tornado Cash Router', category: 'mixer', risk: 10 },
  '0x910cbd523d972eb0a6f4cae4618ad62622b39dbf': { name: 'Tornado Cash 10 ETH', category: 'mixer', risk: 10 },
  '0xa160cdab225685da1d56aa342ad8841c3b53f291': { name: 'Tornado Cash 100 ETH', category: 'mixer', risk: 10 },
  // Swap services
  '0x77777feddddffc19ff86db637967013e6c6a116c': { name: 'THORChain Router', category: 'swap_service', risk: 7 },
  '0xd152f549545093347a162dce210e7293f1452150': { name: 'Disperse.app', category: 'utility', risk: 1 },
  // DEX routers
  '0x111111125421ca6dc452d289314280a0f8842a65': { name: '1inch v6 Router', category: 'dex_router', risk: 0 },
  '0x1111111254eeb25477b68fb85ed929f73a960582': { name: '1inch v5 Router', category: 'dex_router', risk: 0 },
  '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45': { name: 'Uniswap v3 Router 2', category: 'dex_router', risk: 0 },
  '0xe592427a0aece92de3edee1f18e0157c05861564': { name: 'Uniswap v3 Router', category: 'dex_router', risk: 0 },
  '0x7a250d5630b4cf539739df2c5dacb4c659f2488d': { name: 'Uniswap v2 Router 2', category: 'dex_router', risk: 0 },
  '0x66a9893cc07d91d95644aedd05d03f95e1dba8af': { name: 'Uniswap Universal Router', category: 'dex_router', risk: 0 },
  '0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad': { name: 'Uniswap Universal Router 2', category: 'dex_router', risk: 0 },
  '0x6131b5fae19ea4f9d964eac0408e4408b66337b5': { name: 'KyberSwap Aggregator', category: 'dex_router', risk: 0 },
  '0xdef1c0ded9bec7f1a1670819833240f027b25eff': { name: '0x Exchange Proxy', category: 'dex_router', risk: 0 },
  '0xdef171fe48cf0115b1d80b88dc8eab59176fee57': { name: 'Paraswap v5', category: 'dex_router', risk: 0 },
  '0x6a000f20005980200259b80c5102003040001068': { name: 'Paraswap v6', category: 'dex_router', risk: 0 },
  // Tokens (terminal — proceeds back into RAVE/WETH/USDC contract)
  '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48': { name: 'USDC (Centre)', category: 'token', risk: 0 },
  '0xdac17f958d2ee523a2206206994597c13d831ec7': { name: 'USDT (Tether)', category: 'token', risk: 0 },
  '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2': { name: 'WETH', category: 'token', risk: 0 },
  '0x6b175474e89094c44da98b954eedeac495271d0f': { name: 'DAI', category: 'token', risk: 0 },
  '0x17205fab260a7a6383a81452ce6315a39370db97': { name: 'RAVE token', category: 'token', risk: 0 },
  // NFT marketplaces
  '0x59728544b08ab483533076417fbbb2fd0b17ce3a': { name: 'LooksRare Exchange', category: 'nft_marketplace', risk: 0 },
  '0x0000000000a39bb272e79075ade125fd351887ac': { name: 'Blur.io Marketplace', category: 'nft_marketplace', risk: 0 },
  '0x00000000006c3852cbef3e08e8df289169ede581': { name: 'OpenSea (Seaport 1.1)', category: 'nft_marketplace', risk: 0 },
};

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(ALCHEMY_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        signal: AbortSignal.timeout(30000),
      });
      if (!r.ok) { await sleep(500); continue; }
      const j: any = await r.json();
      if (j?.error) return null;
      return j?.result ?? null;
    } catch { await sleep(500); }
  }
  return null;
}

async function getBlockByTime(targetTs: number): Promise<number> {
  const latest = parseInt((await alchemy('eth_blockNumber', [])) || '0x0', 16);
  const blocksAgo = Math.floor((Date.now() - targetTs) / 1000 / 12);
  return Math.max(0, latest - blocksAgo);
}

async function getOutboundTransfers(addr: string, fromBlock: number): Promise<any[]> {
  const r = await alchemy('alchemy_getAssetTransfers', [{
    fromBlock: '0x' + fromBlock.toString(16),
    toBlock: 'latest',
    fromAddress: addr,
    category: ['external', 'erc20'],
    maxCount: '0x' + (200).toString(16),
    order: 'asc',
    withMetadata: true,
  }]);
  return r?.transfers || [];
}

async function getCode(addr: string): Promise<string | null> {
  return await alchemy('eth_getCode', [addr, 'latest']);
}

async function getEthBalance(addr: string): Promise<number> {
  const r = await alchemy('eth_getBalance', [addr, 'latest']);
  return r ? Number(BigInt(r)) / 1e18 : 0;
}

async function getErc20Balance(addr: string, token: { address: string; decimals: number }): Promise<number> {
  // balanceOf(address) selector = 0x70a08231 + 32-byte addr
  const data = '0x70a08231' + addr.toLowerCase().replace(/^0x/, '').padStart(64, '0');
  const r = await alchemy('eth_call', [{ to: token.address, data }, 'latest']);
  if (!r || r === '0x') return 0;
  try {
    const raw = BigInt(r);
    const div = BigInt(10) ** BigInt(token.decimals);
    return Number(raw / div) + Number(raw % div) / Number(div);
  } catch { return 0; }
}

async function getCurrentBalanceUsd(addr: string): Promise<{ ethBalance: number; tokenBalances: Record<string, number>; totalUsd: number }> {
  // Parallel: 1 ETH balance + N ERC-20 balanceOf calls in a single round-trip burst
  const [ethBalance, ...tokBals] = await Promise.all([
    getEthBalance(addr),
    ...BALANCE_PROBE_TOKENS.map(t => getErc20Balance(addr, t)),
  ]);
  const tokenBalances: Record<string, number> = {};
  let totalUsd = ethBalance * (PRICES_USD.ETH || 0);
  for (let i = 0; i < BALANCE_PROBE_TOKENS.length; i++) {
    const tok = BALANCE_PROBE_TOKENS[i];
    const bal = tokBals[i];
    if (bal > 0) {
      tokenBalances[tok.symbol] = bal;
      totalUsd += bal * (PRICES_USD[tok.symbol] || 0);
    }
  }
  return { ethBalance, tokenBalances, totalUsd };
}

function priceUsd(asset: string | undefined, value: number): number {
  if (!asset) return 0;
  return (PRICES_USD[asset.toUpperCase()] || 0) * (value || 0);
}

function fmtUsd(n: number): string {
  if (!Number.isFinite(n)) return '$0';
  if (Math.abs(n) >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (Math.abs(n) >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

type NodeKind =
  | 'CEX_DEPOSIT' | 'BRIDGE' | 'MIXER' | 'SWAP_SERVICE'
  | 'DEX_ROUTER' | 'NFT_MARKETPLACE' | 'TOKEN_CONTRACT'
  | 'DUMPER' | 'INTERMEDIARY_EOA' | 'RESTING_EOA' | 'DRAINED_EOA' | 'CONTRACT_OTHER' | 'UTILITY';

type WhereIsItNow =
  | 'CASHED_OUT_TO_CEX' | 'BRIDGED_OUT' | 'MIXED' | 'SWAPPED'
  | 'SOLD_NFT' | 'STILL_RESTING_EOA' | 'DRAINED_EOA' | 'UNKNOWN_CONTRACT' | 'UNKNOWN';

interface FlowEdge { from: string; to: string; asset: string; amount: number; amountUsd: number; txHash: string; blockNum: number; timestamp: string | null; hop: number; }

interface NodeInfo {
  address: string;
  kind: NodeKind;
  label: string | null;
  category: string | null;
  isContract: boolean;
  totalInUsd: number;
  totalOutUsd: number;
  // Deep-mode additions:
  ethBalance?: number;
  tokenBalances?: Record<string, number>;
  currentBalanceUsd?: number;
  whereIsItNow?: WhereIsItNow;
  hopReached?: number;        // BFS depth at which this node was discovered
}

interface DumperTrace {
  dumper: string;
  dumpRank: number;
  tokensSold: number;
  totalProceedsUsd: number;
  visitedNodes: number;
  edges: FlowEdge[];
  nodes: Record<string, NodeInfo>;
  terminalsByCategory: Record<string, { count: number; totalUsd: number }>;
  whereIsItNowVerdict: Record<WhereIsItNow, { count: number; totalUsd: number; currentRestingUsd?: number }>;
  topTerminals: { address: string; label: string | null; category: string; usd: number; whereIsItNow: WhereIsItNow; currentBalanceUsd?: number }[];
}

function classify(addr: string, code: string | null): { kind: NodeKind; label: string | null; category: string | null } {
  const lo = addr.toLowerCase();
  const special = SPECIAL_LABELS[lo];
  if (special) {
    const cat = special.category;
    const k: NodeKind =
      cat === 'bridge' ? 'BRIDGE' :
      cat === 'mixer' ? 'MIXER' :
      cat === 'swap_service' ? 'SWAP_SERVICE' :
      cat === 'dex_router' ? 'DEX_ROUTER' :
      cat === 'nft_marketplace' ? 'NFT_MARKETPLACE' :
      cat === 'token' ? 'TOKEN_CONTRACT' :
      cat === 'utility' ? 'UTILITY' : 'CONTRACT_OTHER';
    return { kind: k, label: special.name, category: cat };
  }
  const lookup = lookupAddress(addr);
  if (lookup) {
    const k: NodeKind =
      lookup.category === 'exchange' ? 'CEX_DEPOSIT' :
      lookup.category === 'bridge' ? 'BRIDGE' :
      lookup.category === 'mixer' ? 'MIXER' : 'CONTRACT_OTHER';
    return { kind: k, label: lookup.name, category: lookup.category || null };
  }
  const isContract = !!(code && code !== '0x');
  return { kind: isContract ? 'CONTRACT_OTHER' : 'INTERMEDIARY_EOA', label: null, category: null };
}

const STOP_KINDS: NodeKind[] = ['CEX_DEPOSIT', 'BRIDGE', 'MIXER', 'SWAP_SERVICE', 'DEX_ROUTER', 'NFT_MARKETPLACE', 'TOKEN_CONTRACT', 'UTILITY'];

function verdictFromKind(kind: NodeKind, currentBalanceUsd: number | undefined): WhereIsItNow {
  switch (kind) {
    case 'CEX_DEPOSIT': return 'CASHED_OUT_TO_CEX';
    case 'BRIDGE': return 'BRIDGED_OUT';
    case 'MIXER': return 'MIXED';
    case 'SWAP_SERVICE':
    case 'DEX_ROUTER':
    case 'TOKEN_CONTRACT': return 'SWAPPED';
    case 'NFT_MARKETPLACE': return 'SOLD_NFT';
    case 'CONTRACT_OTHER': return 'UNKNOWN_CONTRACT';
    case 'INTERMEDIARY_EOA':
    case 'RESTING_EOA':
    case 'DRAINED_EOA':
      return (currentBalanceUsd ?? 0) >= RESTING_USD_THRESHOLD ? 'STILL_RESTING_EOA' : 'DRAINED_EOA';
    default: return 'UNKNOWN';
  }
}

async function traceDumperDeep(dumperAddr: string, fromBlock: number, dumpRank: number, tokensSold: number): Promise<DumperTrace> {
  console.log(`\n[Trace #${dumpRank}] ${dumperAddr}  (${tokensSold.toFixed(0)} RAVE)`);
  const edges: FlowEdge[] = [];
  const nodes: Record<string, NodeInfo> = {};
  const visited = new Set<string>();
  const queue: { addr: string; hop: number }[] = [{ addr: dumperAddr.toLowerCase(), hop: 0 }];
  let calls = 0;

  while (queue.length > 0) {
    const { addr, hop } = queue.shift()!;
    if (visited.has(addr)) continue;
    visited.add(addr);
    process.stderr.write(`  [#${dumpRank} h${hop}] ${addr.slice(0, 10)}… (q=${queue.length}, v=${visited.size})\n`);

    const code = await getCode(addr); calls++;
    await sleep(RATE_LIMIT_MS);
    const cls = classify(addr, code);
    const isContract = !!(code && code !== '0x');
    if (!nodes[addr]) {
      nodes[addr] = {
        address: addr,
        kind: addr === dumperAddr.toLowerCase() ? 'DUMPER' : cls.kind,
        label: cls.label,
        category: cls.category,
        isContract,
        totalInUsd: 0,
        totalOutUsd: 0,
        hopReached: hop,
      };
    }
    if (hop >= MAX_HOPS) continue;
    if (STOP_KINDS.includes(cls.kind) && hop > 0) continue;
    if (isContract && hop > 0 && cls.kind === 'INTERMEDIARY_EOA') {
      nodes[addr].kind = 'CONTRACT_OTHER';
      continue;
    }

    const out = await getOutboundTransfers(addr, fromBlock); calls++;
    await sleep(RATE_LIMIT_MS);

    const byPair = new Map<string, { to: string; asset: string; amount: number; amountUsd: number; txCount: number; firstTxHash: string; firstBlockNum: number; firstTs: string | null }>();
    for (const t of out) {
      const to = (t.to || '').toLowerCase();
      if (!to || to === addr) continue;
      const asset = t.asset || (t.category === 'external' ? 'ETH' : '?');
      const amount = typeof t.value === 'number' ? t.value : 0;
      const amountUsd = priceUsd(asset, amount);
      const blockNum = parseInt(t.blockNum || '0x0', 16);
      const ts = t.metadata?.blockTimestamp || null;
      const k = `${to}::${asset}`;
      if (!byPair.has(k)) byPair.set(k, { to, asset, amount: 0, amountUsd: 0, txCount: 0, firstTxHash: t.hash, firstBlockNum: blockNum, firstTs: ts });
      const agg = byPair.get(k)!;
      agg.amount += amount;
      agg.amountUsd += amountUsd;
      agg.txCount += 1;
    }

    const byDest = new Map<string, { totalUsd: number; pairs: any[] }>();
    for (const p of byPair.values()) {
      if (!byDest.has(p.to)) byDest.set(p.to, { totalUsd: 0, pairs: [] });
      const e = byDest.get(p.to)!;
      e.totalUsd += p.amountUsd;
      e.pairs.push(p);
    }
    const branches = [...byDest.entries()].sort((a, b) => b[1].totalUsd - a[1].totalUsd).slice(0, MAX_BRANCHES_PER_HOP);

    for (const [destAddr, info] of branches) {
      for (const ev of info.pairs) {
        edges.push({ from: addr, to: destAddr, asset: ev.asset, amount: ev.amount, amountUsd: ev.amountUsd, txHash: ev.firstTxHash, blockNum: ev.firstBlockNum, timestamp: ev.firstTs, hop: hop + 1 });
        nodes[addr].totalOutUsd += ev.amountUsd;
        if (!nodes[destAddr]) {
          nodes[destAddr] = { address: destAddr, kind: 'INTERMEDIARY_EOA', label: null, category: null, isContract: false, totalInUsd: 0, totalOutUsd: 0, hopReached: hop + 1 };
        }
        nodes[destAddr].totalInUsd += ev.amountUsd;
      }
      if (!visited.has(destAddr)) queue.push({ addr: destAddr, hop: hop + 1 });
    }
  }

  // === DEEP MODE ADDITION: resolve current balance for every TERMINAL node ===
  const targets: NodeInfo[] = [];
  for (const [a, n] of Object.entries(nodes)) {
    if (a === dumperAddr.toLowerCase()) continue;
    if (n.totalInUsd <= 0) continue;
    const isLabeledService = STOP_KINDS.includes(n.kind);
    if (!isLabeledService && (n.kind === 'INTERMEDIARY_EOA' || n.kind === 'CONTRACT_OTHER')) targets.push(n);
  }
  console.log(`  [#${dumpRank}] Resolving current balances for ${targets.length} terminal EOAs (parallel pool)...`);
  const POOL = 4;
  let idx = 0;
  await Promise.all(Array.from({ length: POOL }, async () => {
    while (true) {
      const i = idx++; if (i >= targets.length) break;
      const n = targets[i];
      const bal = await getCurrentBalanceUsd(n.address);
      calls += 1 + BALANCE_PROBE_TOKENS.length;
      n.ethBalance = bal.ethBalance;
      n.tokenBalances = bal.tokenBalances;
      n.currentBalanceUsd = bal.totalUsd;
      if (n.kind === 'INTERMEDIARY_EOA') {
        n.kind = bal.totalUsd >= RESTING_USD_THRESHOLD ? 'RESTING_EOA' : 'DRAINED_EOA';
      }
    }
  }));

  // === FIRST PASS: assign final verdict to every node (single source of truth) ===
  // Re-classification (e.g. unlabeled-CEX heuristic) MUST happen before any
  // bucket aggregation, otherwise per-row and aggregate verdicts disagree.
  for (const n of Object.values(nodes)) {
    if (n.address === dumperAddr.toLowerCase()) continue;
    let v = verdictFromKind(n.kind, n.currentBalanceUsd);
    // Heuristic: unlabeled EOA whose current balance is hugely more than what
    // we routed through it is almost certainly an unlabeled CEX/service hot
    // wallet; demote to UNKNOWN_CONTRACT so it doesn't inflate "still resting".
    if (v === 'STILL_RESTING_EOA' && n.currentBalanceUsd != null
        && n.currentBalanceUsd > n.totalInUsd * 50 && n.currentBalanceUsd > 1_000_000) {
      v = 'UNKNOWN_CONTRACT';
    }
    n.whereIsItNow = v;
  }

  // === Aggregations & verdicts (hop-1 edge driven → conservation guaranteed) ===
  // Per-dumper verdict totals are derived from HOP-1 outflow only, allocated
  // by the FINAL verdict of the direct destination. This guarantees the
  // verdict bucket totals sum exactly to totalProceedsUsd (no flow inflation
  // from re-counting downstream propagation).
  const terminalsByCategory: Record<string, { count: number; totalUsd: number }> = {};
  const whereIsItNowVerdict: Record<WhereIsItNow, { count: number; totalUsd: number; currentRestingUsd?: number }> = {} as any;
  const topTerminals: DumperTrace['topTerminals'] = [];

  const hop1Edges = edges.filter(e => e.from === dumperAddr.toLowerCase() && e.hop === 1);
  const totalProceedsUsd = hop1Edges.reduce((s, e) => s + e.amountUsd, 0);

  // Build hop-1-attributed terminal map: address → { usd routed by dumper, verdict, currentBalanceCap }
  const directTerminalMap = new Map<string, { totalUsd: number; verdict: WhereIsItNow; currentBalanceUsd?: number; node: NodeInfo }>();
  for (const e of hop1Edges) {
    const dest = nodes[e.to];
    if (!dest) continue;
    const v = (dest.whereIsItNow || verdictFromKind(dest.kind, dest.currentBalanceUsd)) as WhereIsItNow;
    const ex = directTerminalMap.get(e.to);
    if (ex) ex.totalUsd += e.amountUsd;
    else directTerminalMap.set(e.to, { totalUsd: e.amountUsd, verdict: v, currentBalanceUsd: dest.currentBalanceUsd, node: dest });
  }

  for (const [addr, info] of directTerminalMap) {
    const n = info.node;
    const cat = n.category || (
      n.kind === 'RESTING_EOA' ? 'resting_eoa' :
      n.kind === 'DRAINED_EOA' ? 'drained_eoa' :
      n.kind === 'CONTRACT_OTHER' ? 'unknown_contract' :
      n.kind === 'INTERMEDIARY_EOA' ? 'intermediary_eoa' :
      n.kind.toLowerCase());
    if (!terminalsByCategory[cat]) terminalsByCategory[cat] = { count: 0, totalUsd: 0 };
    terminalsByCategory[cat].count++;
    terminalsByCategory[cat].totalUsd += info.totalUsd;

    if (!whereIsItNowVerdict[info.verdict]) whereIsItNowVerdict[info.verdict] = { count: 0, totalUsd: 0, currentRestingUsd: 0 };
    whereIsItNowVerdict[info.verdict].count++;
    whereIsItNowVerdict[info.verdict].totalUsd += info.totalUsd;
    if (info.verdict === 'STILL_RESTING_EOA' && info.currentBalanceUsd != null) {
      // Cap current resting at the dumper's routed inflow to this address.
      const cap = Math.min(info.currentBalanceUsd, info.totalUsd);
      whereIsItNowVerdict[info.verdict].currentRestingUsd =
        (whereIsItNowVerdict[info.verdict].currentRestingUsd || 0) + cap;
    }

    const displayCurrent = info.currentBalanceUsd != null ? Math.min(info.currentBalanceUsd, info.totalUsd) : undefined;
    topTerminals.push({ address: addr, label: n.label, category: cat, usd: info.totalUsd, whereIsItNow: info.verdict, currentBalanceUsd: displayCurrent });
  }
  topTerminals.sort((a, b) => b.usd - a.usd);
  console.log(`  [#${dumpRank}] visited=${visited.size} edges=${edges.length} proceeds=${fmtUsd(totalProceedsUsd)} api-calls=${calls}`);

  return {
    dumper: dumperAddr.toLowerCase(),
    dumpRank, tokensSold, totalProceedsUsd,
    visitedNodes: visited.size,
    edges, nodes,
    terminalsByCategory,
    whereIsItNowVerdict,
    topTerminals: topTerminals.slice(0, 12),
  };
}

function buildHtml(traces: DumperTrace[], aggregate: any, runMeta: any): string {
  const C = { bg: '#0A0A0A', panel: '#111111', panel2: '#1E293B', text: '#FFFFFF', gold: '#FFD700', cyan: '#00D4FF', red: '#FF4444', green: '#22C55E', orange: '#F59E0B' };
  const esc = (s: any) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const verdictTable = Object.entries(aggregate.whereIsItNow as Record<string, any>).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd).map(([v, info]: any) => `
    <tr>
      <td style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${esc(v)}</td>
      <td align="right" style="color:${C.gold};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(info.totalUsd)}</td>
      <td align="right" style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;">${(info.totalUsd / aggregate.grandTotalUsd * 100).toFixed(1)}%</td>
      <td align="right" style="color:${C.green};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${info.currentRestingUsd ? fmtUsd(info.currentRestingUsd) : '—'}</td>
      <td align="right" style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;">${info.count}</td>
    </tr>`).join('');

  const topTerminalsRows = aggregate.topTerminals.slice(0, 30).map((e: any) => `
    <tr>
      <td style="color:${C.text};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;">${esc(e.label || '<unlabeled EOA>')}</td>
      <td style="color:${C.gold};font-size:10px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${esc(e.address)}</td>
      <td style="color:#86EFAC;font-size:10px;padding:6px;border-bottom:1px solid #1E3A5F;">${esc(e.whereIsItNow)}</td>
      <td align="right" style="color:${C.gold};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(e.usd)}</td>
      <td align="right" style="color:${C.green};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${e.currentBalanceUsd != null ? fmtUsd(e.currentBalanceUsd) : '—'}</td>
    </tr>`).join('');

  const dumperCards = traces.map(t => {
    const verdict = Object.entries(t.whereIsItNowVerdict).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd).map(([v, i]: any) =>
      `<span style="color:${C.cyan};">${esc(v)}</span> <span style="color:${C.gold};">${fmtUsd(i.totalUsd)}</span>${i.currentRestingUsd ? ` <span style="color:${C.green};">[now ${fmtUsd(i.currentRestingUsd)}]</span>` : ''}`
    ).join(' · ');
    const top = t.topTerminals.slice(0, 8).map(x => `
      <tr>
        <td style="color:${C.text};font-size:10px;padding:4px 8px;border-bottom:1px solid #1E3A5F;">${esc(x.label || '<unlabeled>')}</td>
        <td style="color:${C.gold};font-size:9px;padding:4px 8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${esc(x.address.slice(0, 12))}…${esc(x.address.slice(-8))}</td>
        <td style="color:#86EFAC;font-size:9px;padding:4px 8px;border-bottom:1px solid #1E3A5F;">${esc(x.whereIsItNow)}</td>
        <td align="right" style="color:${C.gold};font-size:10px;padding:4px 8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(x.usd)}</td>
        <td align="right" style="color:${C.green};font-size:10px;padding:4px 8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${x.currentBalanceUsd != null ? fmtUsd(x.currentBalanceUsd) : '—'}</td>
      </tr>`).join('');
    return `
      <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;margin-bottom:14px;"><tr><td style="padding:14px;">
        <div style="color:${C.gold};font-size:14px;font-weight:bold;margin-bottom:6px;">Dumper #${t.dumpRank} — ${fmtUsd(t.totalProceedsUsd)} proceeds  <span style="color:${C.text};font-size:11px;font-weight:normal;">(${t.tokensSold.toFixed(0)} RAVE · ${t.visitedNodes} nodes explored over ${MAX_HOPS} hops)</span></div>
        <div style="color:${C.gold};font-family:Consolas,monospace;font-size:10px;margin-bottom:6px;">${esc(t.dumper)}</div>
        <div style="color:${C.text};font-size:11px;margin-bottom:8px;"><b>Where is it now:</b> ${verdict}</div>
        <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border-radius:6px;">
          <tr>
            <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px 8px;">Service / EOA</th>
            <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px 8px;">Address</th>
            <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px 8px;">Verdict</th>
            <th align="right" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px 8px;">USD received</th>
            <th align="right" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px 8px;">USD now</th>
          </tr>
          ${top}
        </table>
      </td></tr></table>`;
  }).join('');

  const stat = (val: string, label: string, color = C.gold) =>
    `<td align="center" valign="middle" style="background:${C.panel2};border:1px solid #334155;border-radius:6px;padding:14px 8px;width:20%;">
      <div style="color:${color};font-size:18px;font-weight:bold;">${val}</div>
      <div style="color:${C.text};font-size:10px;margin-top:4px;">${label}</div>
    </td>`;

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="background:${C.bg};margin:0;padding:0;font-family:Segoe UI,Arial,sans-serif;">
<div style="max-width:1000px;margin:0 auto;padding:24px;">
  <div style="background:linear-gradient(135deg,#1E3A5F 0%,#0D2137 100%);border:2px solid ${C.gold};border-radius:12px;padding:22px;margin-bottom:18px;text-align:center;">
    <div style="color:${C.text};font-size:20px;font-weight:bold;letter-spacing:1.5px;">RAVEDAO_DUMP — DEEP FORWARD-TRACE (3 HOP · 240H)</div>
    <div style="color:${C.gold};font-size:12px;margin-top:4px;">Alpha Proceeds Forward-Trace Engine™ · Deep Mode · Generated ${runMeta.generated}</div>
    <div style="color:${C.text};font-size:11px;margin-top:6px;opacity:0.7;">${MAX_HOPS}-hop BFS · ${MAX_BRANCHES_PER_HOP} branches/hop · ${WINDOW_HOURS}h window · current-balance verified at every terminal EOA</div>
  </div>

  <table cellpadding="0" cellspacing="6" border="0" width="100%"><tr>
    ${stat(fmtUsd(aggregate.grandTotalUsd), 'Total proceeds traced')}
    ${stat(`${aggregate.dumpersTraced}`, 'Dumpers traced')}
    ${stat(`${aggregate.uniqueTerminals}`, 'Unique terminals')}
    ${stat(`${aggregate.totalEdges}`, 'Total edges')}
    ${stat(fmtUsd(aggregate.currentRestingUsd), 'STILL RESTING (USD now)', C.green)}
  </tr></table>

  <div style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;padding:14px;margin:14px 0;">
    <div style="color:${C.cyan};font-size:13px;font-weight:bold;margin-bottom:10px;">WHERE IS THE MONEY NOW — verdict aggregate</div>
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border-radius:6px;">
      <tr>
        <th align="left" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;">Verdict</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;">USD routed there</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;">% of total</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;">USD currently held</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;">Endpoint count</th>
      </tr>
      ${verdictTable}
    </table>
  </div>

  <div style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;padding:14px;margin:14px 0;">
    <div style="color:${C.cyan};font-size:13px;font-weight:bold;margin-bottom:10px;">TOP 30 TERMINALS — cluster-wide</div>
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border-radius:6px;">
      <tr>
        <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px;">Service / EOA</th>
        <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px;">Address</th>
        <th align="left" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px;">Verdict</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px;">USD in</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:11px;padding:6px;">USD now</th>
      </tr>
      ${topTerminalsRows}
    </table>
  </div>

  <div style="color:${C.cyan};font-size:13px;font-weight:bold;margin:16px 0 8px;">PER-DUMPER DEEP TRACE</div>
  ${dumperCards}

  <div style="color:${C.text};font-size:10px;text-align:center;padding:14px;border-top:1px solid #1E3A5F;margin-top:16px;opacity:0.7;">
    © 2024-2026 Alpha Unlimited Trading Company · Alpha Proceeds Forward-Trace Engine™ (Deep Mode)<br>
    PROPRIETARY AND CONFIDENTIAL · Title 17 · DMCA · CFAA · DTSA · INTERNAL OWNER USE ONLY
  </div>
</div></body></html>`;
}

async function main() {
  console.log('=== RAVEDAO_DUMP — DEEP FORWARD TRACE ===');
  console.log(`Window: ${WINDOW_HOURS}h · MaxHops: ${MAX_HOPS} · MaxBranches/hop: ${MAX_BRANCHES_PER_HOP}`);
  const analysis = JSON.parse(fs.readFileSync(ANALYSIS_PATH, 'utf-8'));
  const dumpers = (analysis.dumpers || []).filter((d: any) => d.address && d.address !== '0x0000000000000000000000000000000000000000');
  console.log(`Loaded ${dumpers.length} dumpers from analysis`);

  const fromBlock = await getBlockByTime(WINDOW_START);
  console.log(`fromBlock = ${fromBlock} (window start ${new Date(WINDOW_START).toISOString()})`);

  const traces: DumperTrace[] = [];
  for (let i = 0; i < dumpers.length; i++) {
    const d = dumpers[i];
    const t = await traceDumperDeep(d.address, fromBlock, i + 1, d.tokensSold || 0);
    traces.push(t);
  }

  // === Cluster-wide aggregate (deduplicated by unique terminal address) ===
  let grandTotalUsd = 0;
  let totalEdges = 0;
  for (const t of traces) {
    grandTotalUsd += t.totalProceedsUsd;
    totalEdges += t.edges.length;
  }

  // Build unified terminal map: each unique address counted ONCE in aggregate counts.
  // Per-address USD = sum of contributions from all dumpers that hit it.
  // Verdict for the unified address = the per-trace verdict (consistent across dumpers
  // because verdict is derived from on-chain state of the address, not dumper-specific).
  const unifiedTerminalMap = new Map<string, { address: string; label: string | null; category: string; usd: number; whereIsItNow: WhereIsItNow; currentBalanceUsd?: number; dumperHits: number }>();
  for (const t of traces) {
    for (const term of t.topTerminals) {
      const ex = unifiedTerminalMap.get(term.address);
      if (ex) {
        ex.usd += term.usd;
        ex.dumperHits++;
        // Cap unified currentBalanceUsd at unified usd (preserves the inflow-cap invariant)
        if (term.currentBalanceUsd != null) {
          ex.currentBalanceUsd = Math.min(
            (ex.currentBalanceUsd ?? 0) + term.currentBalanceUsd,
            ex.usd
          );
        }
      } else {
        unifiedTerminalMap.set(term.address, { ...term, dumperHits: 1 });
      }
    }
  }

  // Verdict aggregation: count UNIQUE addresses, sum capped USD per verdict.
  const whereIsItNow: Record<string, { count: number; totalUsd: number; currentRestingUsd: number }> = {};
  let currentRestingUsd = 0;
  for (const term of unifiedTerminalMap.values()) {
    if (!whereIsItNow[term.whereIsItNow]) whereIsItNow[term.whereIsItNow] = { count: 0, totalUsd: 0, currentRestingUsd: 0 };
    whereIsItNow[term.whereIsItNow].count++;       // unique-address count
    whereIsItNow[term.whereIsItNow].totalUsd += term.usd;
    if (term.whereIsItNow === 'STILL_RESTING_EOA' && term.currentBalanceUsd != null) {
      whereIsItNow[term.whereIsItNow].currentRestingUsd += term.currentBalanceUsd;
      currentRestingUsd += term.currentBalanceUsd;
    }
  }
  const termSet = new Set<string>(unifiedTerminalMap.keys());
  const topTerminalsArr = [...unifiedTerminalMap.values()].sort((a, b) => b.usd - a.usd);

  const aggregate = {
    grandTotalUsd, totalEdges,
    uniqueTerminals: termSet.size,
    dumpersTraced: traces.length,
    currentRestingUsd,
    whereIsItNow,
    topTerminals: topTerminalsArr,
  };

  const runMeta = { generated: new Date().toISOString(), windowHours: WINDOW_HOURS, maxHops: MAX_HOPS, maxBranchesPerHop: MAX_BRANCHES_PER_HOP, dumpersTraced: traces.length };

  const out = { _proprietaryHeader: proprietaryHeader('Alpha Proceeds Forward-Trace Engine™ (Deep Mode)'), case: 'RAVEDAO_DUMP', technology: 'Alpha Proceeds Forward-Trace Engine™ (Deep Mode)', runMeta, aggregate, traces };
  fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2));
  fs.writeFileSync(OUT_HTML, buildHtml(traces, aggregate, runMeta));
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(OUT_JSON, { title: 'RAVEDAO_DUMP — Deep Forward-Trace', caseId: 'RAVEDAO_DUMP', chain: 'ethereum', direction: 'forward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }
  console.log(`\nWrote ${OUT_JSON}  (${(fs.statSync(OUT_JSON).size / 1024).toFixed(1)} KB)`);
  console.log(`Wrote ${OUT_HTML}  (${(fs.statSync(OUT_HTML).size / 1024).toFixed(1)} KB)`);
  console.log(`\nGRAND TOTAL: ${fmtUsd(grandTotalUsd)} traced · ${termSet.size} terminals · STILL RESTING NOW: ${fmtUsd(currentRestingUsd)}`);
  for (const [v, info] of Object.entries(whereIsItNow).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd)) {
    console.log(`  ${v}: ${fmtUsd(info.totalUsd)} (${info.count} endpoints${info.currentRestingUsd ? `, currently holding ${fmtUsd(info.currentRestingUsd)}` : ''})`);
  }
}

main().catch(e => { console.error(e); process.exit(1); });
