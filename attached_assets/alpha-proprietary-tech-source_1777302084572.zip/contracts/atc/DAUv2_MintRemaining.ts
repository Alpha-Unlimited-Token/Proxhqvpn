import { ethers } from "ethers";
import * as fs from "fs";
import * as path from "path";

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const DEPLOYER_KEY = process.env.ATC_DEPLOYER_PRIVATE_KEY || "";
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

const CONTRACT_ADDRESS = "0x875D639ffE58c39324256be7E388Fc85921c76AB";

async function mintRemaining() {
  console.log("DAU v2 — MINTING REMAINING TARGETS");
  console.log("Contract: " + CONTRACT_ADDRESS + "\n");

  const provider = new ethers.JsonRpcProvider(ALCHEMY_URL);
  const wallet = new ethers.Wallet(DEPLOYER_KEY, provider);

  const balance = await provider.getBalance(wallet.address);
  console.log(`Deployer balance: ${(Number(balance) / 1e18).toFixed(6)} ETH\n`);

  const artifact = JSON.parse(
    fs.readFileSync(path.join(process.cwd(), "contracts/atc/artifacts/DAUv2DyePack.json"), "utf8")
  );
  const dau2 = new ethers.Contract(CONTRACT_ADDRESS, artifact.abi, wallet);

  const traceResults = JSON.parse(
    fs.readFileSync(path.join(process.cwd(), "contracts/atc/DAUv2_full_trace_results.json"), "utf8")
  );

  const targets = traceResults.deployTargets || [];
  console.log(`Total 90%+ targets: ${targets.length}\n`);

  let alreadyMinted = 0;
  let newMints = 0;
  let failed = 0;

  for (const target of targets) {
    try {
      const bal = await dau2.balanceOf(target.address);
      if (bal > 0n) {
        alreadyMinted++;
        console.log(`  [SKIP] ${target.address.slice(0, 14)}... already has ${(Number(bal) / 1e18).toFixed(0)} DAU2`);
        continue;
      }

      const flags: string[] = [];
      if (target.isKnownAttacker) flags.push("KNOWN");
      if (target.interactedWithMonero) flags.push("XMR");
      if (target.interactedWithBridge) flags.push("BRIDGE");
      if (target.sentToExchange) flags.push("CEX");
      if (target.connectedBackToAttacker) flags.push("LINKED");

      console.log(`  [MINT] ${target.address.slice(0, 14)}... | ${target.riskScore}% | [${flags.join(",")}]`);
      console.log(`         WHY: ${(target.confidenceReasons || []).join(" + ")}`);

      const tx = await dau2.forensicMint(
        target.address,
        1,
        target.isKnownAttacker ? 0 : 1,
        target.label || "Traced wallet"
      );
      await tx.wait();
      newMints++;
      console.log(`         Done (TX: ${tx.hash.slice(0, 14)}...)\n`);
    } catch (e: any) {
      failed++;
      console.log(`         FAILED: ${e.message?.slice(0, 100)}\n`);
    }
  }

  const finalBalance = await provider.getBalance(wallet.address);
  console.log(`\n${"=".repeat(60)}`);
  console.log(`  MINTING COMPLETE`);
  console.log(`  Already had DAU2: ${alreadyMinted}`);
  console.log(`  Newly minted: ${newMints}`);
  console.log(`  Failed: ${failed}`);
  console.log(`  Total targets: ${targets.length}`);
  console.log(`  Deployer remaining: ${(Number(finalBalance) / 1e18).toFixed(6)} ETH`);
  console.log(`${"=".repeat(60)}`);
}

mintRemaining().catch(console.error);
