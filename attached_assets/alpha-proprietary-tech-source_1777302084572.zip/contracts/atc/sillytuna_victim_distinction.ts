/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * SillyTuna Victim Distinction — 5-Axis Test (Are these wallets PERPETRATORS, not VICTIMS?)
 *
 * For each of the 26 tagged wallets, runs FIVE independent tests to confirm
 * the wallet is a perpetrator/mule (or downstream beneficiary of the attack)
 * and NOT itself a victim:
 *
 *   AXIS V1 — Direct flow with the victim 0x6fe0fab2...
 *             (Did funds flow FROM victim TO this wallet → perpetrator/mule?
 *              Or FROM this wallet TO victim → potential co-victim?)
 *   AXIS V2 — Wallet age (first-ever tx date)
 *             Burner wallets created days before attack = perpetrator
 *             Years of normal history = potential victim
 *   AXIS V3 — Sudden-drain pattern detection
 *             Did wallet ever lose >95% of its balance in a single tx
 *             that went to one of the 26 attacker addresses? (Victim signature)
 *   AXIS V4 — EIP-7702 delegation status
 *             Was the EOA ever delegated to a malicious contract? (Victim signature)
 *   AXIS V5 — Forward-trace role + confidence reasons cross-check
 *             "KNOWN ATTACKER WALLET" / "Received funds directly from known attacker"
 *             confirms perpetrator status.
 *
 * Augments contracts/atc/sillytuna_backtrace_mapping.json with `victimDistinction` per wallet.
 * Updates the HTML viewer.
 */

import fs from 'node:fs';
import path from 'node:path';
import { enforceProprietaryLicense } from '../../private/security/alpha_proprietary_guard.js';

enforceProprietaryLicense('Alpha Perpetrator-vs-Victim Distinction Engine™');

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) { console.error('[VictimDist] FATAL: ALCHEMY_API_KEY not set'); process.exit(1); }
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const VICTIM = '0x6fe0fab2164d8e0d03ad6a628e2af78624060322';
const RATE_LIMIT_MS = 250;
const SUDDEN_DRAIN_PCT = 95;

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

interface VictimDistinctionResult {
  // V1
  txsFromVictim: number;        // victim → wallet (perpetrator signal)
  txsToVictim: number;          // wallet → victim (co-victim signal)
  earliestVictimReceiptTs: string | null;
  earliestVictimSendTs: string | null;
  // V2
  firstEverTxTs: string | null;
  walletAgeDays: number;
  preAttackTxCount: number;
  postAttackTxCount: number;
  // V3
  hadSuddenDrain: boolean;
  drainTxHash: string | null;
  drainPctOfBalance: number;
  drainRecipientWasAttacker: boolean;
  // V4
  hasDelegatedCode: boolean;
  delegatedCodeHash: string | null;
  // V5
  forwardTraceConfidenceReasons: string[];
  knownAttackerLabel: boolean;
  // VERDICT
  victimSignals: string[];
  perpetratorSignals: string[];
  victimScore: number;
  perpetratorScore: number;
  verdict: 'CONFIRMED_PERPETRATOR' | 'DOWNSTREAM_MULE' | 'POSSIBLE_CO_VICTIM' | 'NEEDS_REVIEW';
}

async function alchemyCall(method: string, params: any[]): Promise<any> {
  try {
    const r = await fetch(ALCHEMY_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      signal: AbortSignal.timeout(20000),
    });
    if (!r.ok) return null;
    const j: any = await r.json();
    return j?.result ?? null;
  } catch { return null; }
}

async function getTransfersBetween(from: string, to: string): Promise<any[]> {
  const result = await alchemyCall('alchemy_getAssetTransfers', [{
    fromBlock: '0x0', toBlock: 'latest',
    fromAddress: from, toAddress: to,
    category: ['external', 'erc20', 'internal'],
    maxCount: '0x32', order: 'asc', withMetadata: true,
  }]);
  return result?.transfers || [];
}

async function getFirstTxDate(addr: string): Promise<string | null> {
  const result = await alchemyCall('alchemy_getAssetTransfers', [{
    fromBlock: '0x0', toBlock: 'latest',
    toAddress: addr,
    category: ['external', 'erc20', 'internal'],
    maxCount: '0x1', order: 'asc', withMetadata: true,
  }]);
  return result?.transfers?.[0]?.metadata?.blockTimestamp || null;
}

async function getCodeAtAddress(addr: string): Promise<string | null> {
  const result = await alchemyCall('eth_getCode', [addr, 'latest']);
  return result || null;
}

async function getRecentLargeOutbound(addr: string): Promise<any[]> {
  const result = await alchemyCall('alchemy_getAssetTransfers', [{
    fromBlock: '0x0', toBlock: 'latest',
    fromAddress: addr,
    category: ['external', 'erc20'],
    maxCount: '0x64', order: 'asc', withMetadata: true,
  }]);
  return result?.transfers || [];
}

async function verifyWallet(addr: string, fwdMeta: any, attackerSet: Set<string>): Promise<VictimDistinctionResult> {
  const addrLower = addr.toLowerCase();

  // V1 — direct flow with victim
  const [fromVictim, toVictim] = await Promise.all([
    getTransfersBetween(VICTIM, addrLower),
    getTransfersBetween(addrLower, VICTIM),
  ]);
  await sleep(RATE_LIMIT_MS);

  // V2 — age
  const firstTs = await getFirstTxDate(addrLower);
  const ageDays = firstTs ? Math.floor((Date.now() - new Date(firstTs).getTime()) / 86_400_000) : -1;

  // V3 + pre/post counts — use outbound history
  const allOut = await getRecentLargeOutbound(addrLower);
  const ATTACK_BOUNDARY = new Date('2026-01-01T00:00:00Z');
  let preCount = 0, postCount = 0;
  for (const t of allOut) {
    const ts = t?.metadata?.blockTimestamp;
    if (!ts) continue;
    if (new Date(ts) < ATTACK_BOUNDARY) preCount++;
    else postCount++;
  }

  // V3 — sudden-drain detection: look for the largest outbound tx and compare to inbound up to that point
  let hadSuddenDrain = false;
  let drainTx: string | null = null;
  let drainPct = 0;
  let drainToAttacker = false;
  const sortedOut = allOut.filter(t => typeof t.value === 'number' && t.value > 0).sort((a, b) => (b.value || 0) - (a.value || 0));
  if (sortedOut.length > 0) {
    const biggest = sortedOut[0];
    const biggestVal = biggest.value;
    const totalInThisAsset = allOut.filter(t => t.asset === biggest.asset).reduce((s, t) => s + (t.value || 0), 0);
    if (totalInThisAsset > 0) {
      drainPct = (biggestVal / Math.max(totalInThisAsset, biggestVal)) * 100;
      // Heuristic: if a single tx accounts for >95% of all outbound in that asset, it's a drain pattern
      if (drainPct >= SUDDEN_DRAIN_PCT) {
        hadSuddenDrain = true;
        drainTx = biggest.hash;
        drainToAttacker = attackerSet.has((biggest.to || '').toLowerCase());
      }
    }
  }

  await sleep(RATE_LIMIT_MS);

  // V4 — EIP-7702 / contract delegation
  const code = await getCodeAtAddress(addrLower);
  const hasCode = !!code && code !== '0x' && code !== '0x0';
  const codeHash = hasCode ? code.slice(0, 18) + '...' : null;

  // V5 — forward trace
  const fwdReasons = Array.isArray(fwdMeta?.confidenceReasons) ? fwdMeta.confidenceReasons : [];
  const isKnown = fwdReasons.some((r: string) => /KNOWN ATTACKER/i.test(r));

  // SCORING
  const victimSignals: string[] = [];
  const perpetratorSignals: string[] = [];
  let vScore = 0, pScore = 0;

  // V1
  if (fromVictim.length > 0) {
    perpetratorSignals.push(`V1: Received ${fromVictim.length} transfer(s) directly FROM victim wallet — direct beneficiary of stolen funds`);
    pScore += 50;
  }
  if (toVictim.length > 0) {
    victimSignals.push(`V1: Sent ${toVictim.length} transfer(s) TO victim wallet — could indicate prior legitimate relationship`);
    vScore += 15;
  }
  if (fromVictim.length === 0 && toVictim.length === 0) {
    perpetratorSignals.push('V1: No direct interaction with victim — downstream of attacker chain (mule pattern)');
    pScore += 15;
  }

  // V2 — age + pre-attack history
  if (ageDays >= 0) {
    if (ageDays < 90) {
      perpetratorSignals.push(`V2: Wallet only ${ageDays} days old — fresh burner created near attack window`);
      pScore += 25;
    } else if (ageDays < 365) {
      perpetratorSignals.push(`V2: Wallet ${ageDays} days old — created within likely attack-prep window`);
      pScore += 10;
    } else {
      victimSignals.push(`V2: Wallet ${ageDays} days old (long pre-attack history) — could be legitimate user`);
      vScore += 15;
    }
  }
  if (preCount > 50) {
    victimSignals.push(`V2: ${preCount} pre-attack outbound txs — extensive normal-use history`);
    vScore += 15;
  } else if (preCount === 0) {
    perpetratorSignals.push('V2: ZERO pre-attack outbound txs — no legitimate use history');
    pScore += 20;
  }

  // V3
  if (hadSuddenDrain && drainToAttacker) {
    victimSignals.push(`V3: 🚨 SUDDEN DRAIN detected — single tx (${drainTx?.slice(0, 14)}...) drained ${drainPct.toFixed(0)}% of balance to a known attacker → CLASSIC VICTIM SIGNATURE`);
    vScore += 60;
  } else if (hadSuddenDrain) {
    perpetratorSignals.push(`V3: Single large outbound (${drainPct.toFixed(0)}% of activity) — but recipient is NOT an attacker (consolidation pattern)`);
    pScore += 5;
  } else {
    perpetratorSignals.push('V3: No sudden-drain pattern — outflows are spread across many txs (perpetrator distribution pattern)');
    pScore += 15;
  }

  // V4
  if (hasCode) {
    victimSignals.push(`V4: ⚠️ Address has code deployed (${codeHash}) — could be EIP-7702 delegated victim, OR an attacker-deployed contract. Manual review needed.`);
    vScore += 20;
  } else {
    perpetratorSignals.push('V4: Plain EOA, no code (no EIP-7702 delegation) — not a hijacked smart wallet');
    pScore += 10;
  }

  // V5
  if (isKnown) {
    perpetratorSignals.push('V5: Tagged as "KNOWN ATTACKER WALLET" by forward-trace engine');
    pScore += 40;
  }
  if (fwdReasons.some((r: string) => /Received funds directly from known attacker/i.test(r))) {
    perpetratorSignals.push('V5: Forward trace: "Received funds directly from known attacker"');
    pScore += 25;
  }
  if (fwdReasons.some((r: string) => /mule pattern/i.test(r))) {
    perpetratorSignals.push('V5: Forward trace: classified as MULE (high forward rate)');
    pScore += 20;
  }

  // VERDICT
  let verdict: VictimDistinctionResult['verdict'];
  if (pScore - vScore >= 60) verdict = 'CONFIRMED_PERPETRATOR';
  else if (pScore - vScore >= 30) verdict = 'DOWNSTREAM_MULE';
  else if (vScore > pScore) verdict = 'POSSIBLE_CO_VICTIM';
  else verdict = 'NEEDS_REVIEW';

  return {
    txsFromVictim: fromVictim.length, txsToVictim: toVictim.length,
    earliestVictimReceiptTs: fromVictim[0]?.metadata?.blockTimestamp || null,
    earliestVictimSendTs: toVictim[0]?.metadata?.blockTimestamp || null,
    firstEverTxTs: firstTs, walletAgeDays: ageDays,
    preAttackTxCount: preCount, postAttackTxCount: postCount,
    hadSuddenDrain, drainTxHash: drainTx, drainPctOfBalance: drainPct, drainRecipientWasAttacker: drainToAttacker,
    hasDelegatedCode: hasCode, delegatedCodeHash: codeHash,
    forwardTraceConfidenceReasons: fwdReasons, knownAttackerLabel: isKnown,
    victimSignals, perpetratorSignals, victimScore: vScore, perpetratorScore: pScore, verdict,
  };
}

function buildHtml(merged: any): string {
  const reports = merged.reports;
  const counts = new Map<string, number>();
  for (const r of reports) {
    const v = r.victimDistinction?.verdict || 'NEEDS_REVIEW';
    counts.set(v, (counts.get(v) || 0) + 1);
  }

  const color = (v: string) =>
    v === 'CONFIRMED_PERPETRATOR' ? '#4ade80' :
    v === 'DOWNSTREAM_MULE' ? '#88ff88' :
    v === 'POSSIBLE_CO_VICTIM' ? '#ff4444' :
    '#ffcc00';

  const summary = Array.from(counts.entries()).map(([v, n]) =>
    `<div style="background:#111;padding:14px;border-radius:8px;text-align:center;border:1px solid ${color(v)};">
      <div style="font-size:26px;color:${color(v)};font-weight:bold;">${n}</div>
      <div style="color:#888;font-size:11px;">${v.replace(/_/g, ' ')}</div>
    </div>`).join('');

  const rows = reports.map((r: any) => {
    const v = r.victimDistinction;
    if (!v) return '';
    const c = color(v.verdict);
    const sigs = (label: string, list: string[], col: string) =>
      list.length === 0 ? '' :
      `<div style="margin-top:6px;"><div style="color:${col};font-size:11px;font-weight:bold;margin-bottom:4px;">${label}</div>` +
      list.map(s => `<div style="padding:4px 8px;margin:2px 0;background:${col === '#4ade80' ? '#0a1f0a' : '#1f0a0a'};border-left:3px solid ${col};font-size:11px;color:#ccc;">${s}</div>`).join('') +
      '</div>';

    return `
    <div style="background:#111;border-left:4px solid ${c};padding:14px;margin:12px 0;border-radius:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
        <div style="font-family:monospace;font-size:13px;color:#fff;font-weight:bold;">${r.address}</div>
        <div>
          <span style="background:${c}22;color:${c};padding:5px 14px;border-radius:12px;font-size:12px;font-weight:bold;">🎯 ${v.verdict.replace(/_/g, ' ')}</span>
          <span style="color:#888;font-size:11px;margin-left:6px;">P:<b style="color:#4ade80;">${v.perpetratorScore}</b> / V:<b style="color:#ff4444;">${v.victimScore}</b></span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;margin:10px 0;font-size:11px;">
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">From victim:</span> <b style="color:${v.txsFromVictim > 0 ? '#4ade80' : '#888'};">${v.txsFromVictim} txs</b></div>
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">To victim:</span> <b style="color:${v.txsToVictim > 0 ? '#ff4444' : '#888'};">${v.txsToVictim} txs</b></div>
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">Age:</span> <b style="color:#fff;">${v.walletAgeDays >= 0 ? v.walletAgeDays + 'd' : '?'}</b></div>
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">Pre-attack txs:</span> <b style="color:#fff;">${v.preAttackTxCount}</b></div>
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">Sudden drain:</span> <b style="color:${v.hadSuddenDrain && v.drainRecipientWasAttacker ? '#ff4444' : '#4ade80'};">${v.hadSuddenDrain ? (v.drainRecipientWasAttacker ? 'YES → attacker' : 'YES → other') : 'NO'}</b></div>
        <div style="background:#0a0a0a;padding:8px;border-radius:4px;"><span style="color:#888;">Has code:</span> <b style="color:${v.hasDelegatedCode ? '#ffcc00' : '#4ade80'};">${v.hasDelegatedCode ? 'YES' : 'NO (EOA)'}</b></div>
      </div>
      ${sigs('✅ PERPETRATOR SIGNALS', v.perpetratorSignals, '#4ade80')}
      ${sigs('🚨 VICTIM SIGNALS', v.victimSignals, '#ff4444')}
    </div>`;
  }).join('');

  const oldHtml = fs.readFileSync(path.resolve('contracts/atc/sillytuna_backtrace_mapping.html'), 'utf-8');
  const insertion = `
<h2 style="color:#ff4444;margin-top:30px;border-bottom:1px solid #ff4444;padding-bottom:8px;">🎯 VICTIM DISTINCTION TEST — Are these PERPETRATORS or VICTIMS?</h2>
<p style="color:#ccc;">Each wallet was tested against 5 axes to confirm it is a perpetrator/mule (NOT itself a hack victim):
<br><b style="color:#d4a017;">V1</b> — Direct flow with the SillyTuna victim (received from = perpetrator | sent to = potential co-victim)
<br><b style="color:#d4a017;">V2</b> — Wallet age & pre-attack history (burner = perpetrator | long history = potential victim)
<br><b style="color:#d4a017;">V3</b> — Sudden-drain pattern (95%+ balance drained in single tx to attacker = victim signature)
<br><b style="color:#d4a017;">V4</b> — EIP-7702 delegation status (EOA with deployed code = potential hijacked smart wallet)
<br><b style="color:#d4a017;">V5</b> — Forward-trace cross-check (KNOWN ATTACKER label, mule pattern, etc.)</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:20px;">${summary}</div>
${rows}
`;
  const target = '<h2 style="color:#d4a017;margin-top:30px;border-bottom:1px solid #d4a017;padding-bottom:8px;">PER-WALLET FULL MAPPING';
  if (oldHtml.includes(target)) return oldHtml.replace(target, insertion + '\n' + target);
  return oldHtml + insertion;
}

async function main() {
  const jsonPath = path.resolve('contracts/atc/sillytuna_backtrace_mapping.json');
  const merged: any = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
  const fwd: any = JSON.parse(fs.readFileSync(path.resolve('contracts/atc/DAUv2_full_trace_results.json'), 'utf-8'));
  const fwdByAddr = new Map<string, any>();
  for (const w of fwd.allWallets || []) fwdByAddr.set((w.address || '').toLowerCase(), w);
  const attackerSet = new Set(merged.reports.map((r: any) => r.address.toLowerCase()));

  console.log('[VictimDist] === SillyTuna Victim Distinction (5-Axis) ===\n');
  console.log(`[VictimDist] Victim: ${VICTIM}`);
  console.log(`[VictimDist] Verifying ${merged.reports.length} wallets\n`);

  for (let i = 0; i < merged.reports.length; i++) {
    const r = merged.reports[i];
    console.log(`[VictimDist] [${i + 1}/${merged.reports.length}] ${r.address}`);
    try {
      r.victimDistinction = await verifyWallet(r.address, fwdByAddr.get(r.address.toLowerCase()), attackerSet);
      const v = r.victimDistinction;
      console.log(`             verdict=${v.verdict} | P=${v.perpetratorScore} V=${v.victimScore} | fromVic=${v.txsFromVictim} toVic=${v.txsToVictim} | age=${v.walletAgeDays}d | drain=${v.hadSuddenDrain} | code=${v.hasDelegatedCode}`);
    } catch (e) {
      console.log(`[VictimDist] ERROR: ${(e as Error).message}`);
    }
  }

  merged.victimDistinctionMeta = {
    generatedAt: new Date().toISOString(),
    victim: VICTIM,
    method: '5-axis perpetrator-vs-victim test',
  };
  fs.writeFileSync(jsonPath, JSON.stringify(merged, null, 2));
  console.log(`\n[VictimDist] ✅ Updated ${jsonPath}`);
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(jsonPath, { title: 'SillyTuna — Victim/Perpetrator Distinction', caseId: merged.caseId || 'SILLYTUNA', chain: 'polygon', direction: 'bidirectional' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  fs.writeFileSync(path.resolve('contracts/atc/sillytuna_backtrace_mapping.html'), buildHtml(merged));
  console.log(`[VictimDist] ✅ Wrote sillytuna_backtrace_mapping.html`);

  const counts = new Map<string, number>();
  for (const r of merged.reports) counts.set(r.victimDistinction?.verdict || 'NEEDS_REVIEW', (counts.get(r.victimDistinction?.verdict || 'NEEDS_REVIEW') || 0) + 1);
  console.log('\n=== VERDICT SUMMARY ===');
  for (const [v, n] of Array.from(counts.entries()).sort((a, b) => b[1] - a[1])) console.log(`  ${v.padEnd(28)} ${n}`);
  const possibleVictims = merged.reports.filter((r: any) => r.victimDistinction?.verdict === 'POSSIBLE_CO_VICTIM');
  console.log('\n=== POSSIBLE CO-VICTIMS (NEED MANUAL REVIEW) ===');
  if (possibleVictims.length === 0) console.log('  ✅ NONE — all 26 wallets confirmed as perpetrators or downstream mules');
  else for (const r of possibleVictims) console.log(`  🚨 ${r.address}  (P:${r.victimDistinction.perpetratorScore} V:${r.victimDistinction.victimScore})`);
}

main().catch(e => { console.error(e); process.exit(1); });
