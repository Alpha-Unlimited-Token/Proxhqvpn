import { ethers } from 'ethers';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NETWORKS: Record<string, { rpcUrl: string; name: string; explorer: string }> = {
  sepolia: {
    rpcUrl: 'https://eth-sepolia.g.alchemy.com/v2/',
    name: 'Sepolia Testnet',
    explorer: 'https://sepolia.etherscan.io',
  },
  mainnet: {
    rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/',
    name: 'Ethereum Mainnet',
    explorer: 'https://etherscan.io',
  },
};

async function sendATC() {
  const action = process.argv[2];
  const toAddress = process.argv[3];
  const amount = process.argv[4];

  if (!action || !toAddress || !amount) {
    console.log('Usage:');
    console.log('  npx tsx contracts/atc/send.ts mint  <address> <amount>   — Mint new ATC tokens');
    console.log('  npx tsx contracts/atc/send.ts send  <address> <amount>   — Transfer ATC tokens');
    console.log();
    console.log('Examples:');
    console.log('  npx tsx contracts/atc/send.ts mint 0xYourMetaMask 10000');
    console.log('  npx tsx contracts/atc/send.ts send 0xOtherWallet 5000');
    process.exit(1);
  }

  const network = process.env.ATC_NETWORK || 'sepolia';
  const alchemyKey = process.env.ALCHEMY_API_KEY;
  const senderKey = process.env.ATC_DEPLOYER_PRIVATE_KEY;
  const contractAddress = process.env.ATC_CONTRACT_ADDRESS;

  if (!alchemyKey || !senderKey || !contractAddress) {
    console.error('Missing environment variables. Need: ALCHEMY_API_KEY, ATC_DEPLOYER_PRIVATE_KEY, ATC_CONTRACT_ADDRESS');
    process.exit(1);
  }

  const networkConfig = NETWORKS[network];
  if (!networkConfig) {
    console.error(`Unknown network: ${network}`);
    process.exit(1);
  }

  const artifactPath = path.join(__dirname, 'artifacts', 'AlphaTrackingCoin.json');
  const artifact = JSON.parse(fs.readFileSync(artifactPath, 'utf8'));

  const provider = new ethers.JsonRpcProvider(networkConfig.rpcUrl + alchemyKey);
  const wallet = new ethers.Wallet(senderKey, provider);
  const contract = new ethers.Contract(contractAddress, artifact.abi, wallet);

  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  ALPHA TRACKING COIN™ — ${action.toUpperCase()}`);
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Network:    ${networkConfig.name}`);
  console.log(`  Contract:   ${contractAddress}`);
  console.log(`  From:       ${wallet.address}`);
  console.log(`  To:         ${toAddress}`);
  console.log(`  Amount:     ${Number(amount).toLocaleString()} ATC`);
  console.log('───────────────────────────────────────────────────────────────\n');

  let tx;

  if (action === 'mint') {
    console.log('[ATC] Minting tokens...');
    tx = await contract.mint(toAddress, BigInt(amount));
  } else if (action === 'send') {
    const amountWei = ethers.parseEther(amount);
    console.log('[ATC] Sending tokens...');
    tx = await contract.transfer(toAddress, amountWei);
  } else {
    console.error(`Unknown action: ${action}. Use "mint" or "send"`);
    process.exit(1);
  }

  console.log(`  TX Hash:    ${tx.hash}`);
  console.log('  Waiting for confirmation...\n');

  const receipt = await tx.wait();

  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  TRANSACTION CONFIRMED');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Block:      ${receipt.blockNumber}`);
  console.log(`  Gas used:   ${receipt.gasUsed.toString()}`);
  console.log(`  Explorer:   ${networkConfig.explorer}/tx/${tx.hash}`);
  console.log('───────────────────────────────────────────────────────────────\n');

  const trackingEvents = receipt.logs.filter((log: any) => {
    try {
      const parsed = contract.interface.parseLog(log);
      return parsed?.name === 'TrackingSignal';
    } catch {
      return false;
    }
  });

  if (trackingEvents.length > 0) {
    console.log(`  🚨 ${trackingEvents.length} TrackingSignal event(s) emitted on-chain`);
    console.log('  The listener will pick these up and forward to Spider Beacon\n');
  }

  const balance = await contract.balanceOf(toAddress);
  console.log(`  Recipient balance: ${ethers.formatEther(balance)} ATC\n`);
}

sendATC().catch((err) => {
  console.error('[ATC Send] Error:', err.message || err);
  process.exit(1);
});
