/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  DAU v2 — ADDRESS POISONING DETECTION ENGINE                       ║
 * ║  Alpha Unlimited Forensic Intelligence Division                     ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * Detects and catalogs address poisoning / phishing token attacks
 * targeting the attacker's wallets. These fake tokens use Unicode
 * homoglyphs (lookalike characters) to impersonate real tokens.
 *
 * TECHNIQUES:
 * 1. Unicode Homoglyph Detection — identifies non-ASCII chars in token names
 * 2. Address Similarity Scoring — finds near-match addresses for confusion
 * 3. Zero-Value Transfer Detection — catches dust/poisoning transfers
 * 4. Fake Token Catalog — builds database of attacker-targeting phishing
 */

const ALCHEMY_KEY = process.env.ALCHEMY_API_KEY || "";
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}`;

const UNICODE_HOMOGLYPHS: Record<string, string[]> = {
  "U": ["∪", "Ʊ", "Ü", "Ú", "Ù", "Û", "Ū", "Ŭ"],
  "S": ["Ѕ", "Ꮪ", "Ƨ", "Ś", "Š", "Ş"],
  "D": ["Ɗ", "Ɖ", "Đ", "Ď", "Ꭰ"],
  "C": ["Ⅽ", "Ꮯ", "Ç", "Ć", "Č", "Ĉ"],
  "T": ["Ꭲ", "Ţ", "Ť", "Ŧ"],
  "E": ["Ė", "Ę", "Ě", "Ē", "Ȩ"],
  "H": ["Ḩ", "Ħ", "Ĥ"],
  "A": ["Ꭺ", "Ά", "Ā", "Ă", "Ą"],
};

interface PoisonToken {
  contractAddress: string;
  name: string;
  symbol: string;
  impersonates: string;
  homoglyphsFound: string[];
  balance: string;
  firstSeen: string;
}

async function rpc(method: string, params: any[]): Promise<any> {
  const r = await fetch(ALCHEMY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  return (await r.json() as any).result;
}

function detectHomoglyphs(text: string): { isPhishing: boolean; homoglyphs: string[]; impersonates: string } {
  const found: string[] = [];
  let cleaned = text;

  for (const [real, fakes] of Object.entries(UNICODE_HOMOGLYPHS)) {
    for (const fake of fakes) {
      if (text.includes(fake)) {
        found.push(`${fake}→${real}`);
        cleaned = cleaned.replace(new RegExp(fake, "g"), real);
      }
    }
  }

  const hasNonASCII = /[^\x00-\x7F]/.test(text);
  if (hasNonASCII && found.length === 0) {
    for (let i = 0; i < text.length; i++) {
      if (text.charCodeAt(i) > 127) {
        found.push(`U+${text.charCodeAt(i).toString(16).toUpperCase().padStart(4, "0")}`);
      }
    }
  }

  return {
    isPhishing: found.length > 0 || hasNonASCII,
    homoglyphs: found,
    impersonates: cleaned,
  };
}

function addressSimilarity(addr1: string, addr2: string): number {
  const a = addr1.toLowerCase().slice(2);
  const b = addr2.toLowerCase().slice(2);
  let matches = 0;
  
  const prefixMatch = a.slice(0, 4) === b.slice(0, 4) ? 20 : 0;
  const suffixMatch = a.slice(-4) === b.slice(-4) ? 20 : 0;
  
  for (let i = 0; i < 40; i++) {
    if (a[i] === b[i]) matches++;
  }
  
  return prefixMatch + suffixMatch + Math.round((matches / 40) * 60);
}

export async function scanForPoisonTokens(walletAddress: string): Promise<PoisonToken[]> {
  const poisonTokens: PoisonToken[] = [];

  const balances = await rpc("alchemy_getTokenBalances", [walletAddress, "erc20"]);
  const tokens = (balances?.tokenBalances || []).filter(
    (t: any) => t.tokenBalance !== "0x0000000000000000000000000000000000000000000000000000000000000000"
  );

  for (const tok of tokens) {
    try {
      const meta = await rpc("alchemy_getTokenMetadata", [tok.contractAddress]);
      if (!meta?.symbol) continue;

      const symbolCheck = detectHomoglyphs(meta.symbol);
      const nameCheck = detectHomoglyphs(meta.name || "");

      if (symbolCheck.isPhishing || nameCheck.isPhishing) {
        poisonTokens.push({
          contractAddress: tok.contractAddress,
          name: meta.name || "Unknown",
          symbol: meta.symbol,
          impersonates: symbolCheck.impersonates || nameCheck.impersonates,
          homoglyphsFound: [...symbolCheck.homoglyphs, ...nameCheck.homoglyphs],
          balance: tok.tokenBalance,
          firstSeen: new Date().toISOString(),
        });
      }
    } catch (e) {}
  }

  return poisonTokens;
}

export async function detectZeroValueTransfers(walletAddress: string): Promise<any[]> {
  const transfers = await rpc("alchemy_getAssetTransfers", [{
    toAddress: walletAddress,
    category: ["erc20"],
    maxCount: "0x64",
    order: "desc",
    withMetadata: true,
  }]);

  return ((transfers?.transfers as any[]) || []).filter((tx: any) => {
    const val = parseFloat(String(tx.value));
    return val === 0 || val < 0.0001;
  });
}

async function main() {
  const CASHOUT = "0x8e04af7f7c76daa9ab429b1340e0327b5b835748";

  console.log("════════════════════════════════════════════════════════════════");
  console.log("  ADDRESS POISONING DETECTION SCAN");
  console.log("════════════════════════════════════════════════════════════════");

  const poisons = await scanForPoisonTokens(CASHOUT);
  console.log(`\nFound ${poisons.length} phishing/poison tokens in Cashout wallet:\n`);

  for (const p of poisons) {
    console.log(`  Token: ${p.name} (${p.symbol})`);
    console.log(`    Impersonates: ${p.impersonates}`);
    console.log(`    Homoglyphs: ${p.homoglyphsFound.join(", ")}`);
    console.log(`    Contract: ${p.contractAddress}`);
    console.log("");
  }

  const zeroTransfers = await detectZeroValueTransfers(CASHOUT);
  console.log(`Zero/dust-value transfers received: ${zeroTransfers.length}`);

  console.log("\n════════════════════════════════════════════════════════════════");
}

main().catch(console.error);
