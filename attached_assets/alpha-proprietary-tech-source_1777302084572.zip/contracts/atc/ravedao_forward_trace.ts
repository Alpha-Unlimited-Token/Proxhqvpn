/**
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL
 *
 * Title 17 (US Copyright)  ·  17 U.S.C. § 1201 (DMCA)
 * 18 U.S.C. § 1030 (CFAA)  ·  18 U.S.C. § 1836 (DTSA)
 *
 * Alpha Proceeds Forward-Trace Engine™ — RAVEDAO_DUMP case.
 *
 * Takes the 20 top RAVE dumpers and recursively follows their proceeds
 * (ETH external + ERC20) hop-by-hop on Ethereum mainnet until each path
 * terminates at a CEX deposit, bridge, mixer/swap service, DEX router,
 * or a still-active resting wallet. Produces a per-dumper map and a
 * cluster-wide aggregate of where the dumped value currently sits.
 *
 * INTERNAL OWNER USE ONLY — do not redistribute.
 */

import fs from 'node:fs';
import path from 'node:path';
import {
  enforceProprietaryLicense,
  proprietaryHeader,
} from '../../private/security/alpha_proprietary_guard.js';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';

enforceProprietaryLicense('Alpha Proceeds Forward-Trace Engine™');

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) { console.error('FATAL: ALCHEMY_API_KEY not set'); process.exit(1); }
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const ANALYSIS_PATH = path.resolve('contracts/atc/ravedao_dump_analysis.json');
const OUT_JSON = path.resolve('contracts/atc/ravedao_forward_trace.json');
const OUT_HTML = path.resolve('contracts/atc/ravedao_forward_trace.html');

const NOW = Date.now();
const WINDOW_HOURS = 96; // a bit wider than the 72h dump window — catch fast-moves
const WINDOW_START = NOW - WINDOW_HOURS * 3600 * 1000;
const MAX_HOPS = 1;
const MAX_BRANCHES_PER_HOP = 8;
const RATE_LIMIT_MS = 150;

const PRICES_USD: Record<string, number> = {
  ETH: 2080, WETH: 2080,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1, FRAX: 1, USDS: 1, GHO: 1, LUSD: 1, USDE: 1, PYUSD: 1, CRVUSD: 1,
  WBTC: 67000, BTC: 67000, CBBTC: 67000, TBTC: 67000,
  UNI: 8.5, LINK: 14, MATIC: 0.6, ARB: 0.6, OP: 1.7, AAVE: 130, MKR: 1450, COMP: 50, CRV: 0.4, LDO: 1.1,
  PEPE: 0.000008, SHIB: 0.000016, FLOKI: 0.00012, RAVE: 0,
};

// Known bridges / swap services / mixers
const SPECIAL_LABELS: Record<string, { name: string; category: string; risk: number }> = {
  // Bridges
  '0x88ad09518695c6c3712ac10a214be5109a655671': { name: 'Gnosis Bridge (xDai)', category: 'bridge', risk: 5 },
  '0xa0c68c638235ee32657e8f720a23cec1bfc77c77': { name: 'Polygon (Matic) Bridge', category: 'bridge', risk: 5 },
  '0x40ec5b33f54e0e8a33a975908c5ba1c14e5bbbdf': { name: 'Polygon (Matic) Bridge', category: 'bridge', risk: 5 },
  '0xa3a7b6f88361f48403514059f1f16c8e78d60eec': { name: 'Arbitrum Bridge', category: 'bridge', risk: 5 },
  '0x5288c571fd7ad117bea99bf60fe0846c4e84f933': { name: 'Arbitrum L1 Gateway', category: 'bridge', risk: 5 },
  '0x99c9fc46f92e8a1c0dec1b1747d010903e884be1': { name: 'Optimism Bridge', category: 'bridge', risk: 5 },
  '0x3154cf16ccdb4c6d922629664174b904d80f2c35': { name: 'Base Bridge', category: 'bridge', risk: 5 },
  '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48': { name: 'USDC (Centre)', category: 'token', risk: 0 },
  // Mixers (cautionary — mostly sanctioned)
  '0x8589427373d6d84e98730d7795d8f6f8731fda16': { name: 'Tornado Cash Router', category: 'mixer', risk: 10 },
  '0x910cbd523d972eb0a6f4cae4618ad62622b39dbf': { name: 'Tornado Cash 10 ETH', category: 'mixer', risk: 10 },
  '0xa160cdab225685da1d56aa342ad8841c3b53f291': { name: 'Tornado Cash 100 ETH', category: 'mixer', risk: 10 },
  // Swap services / on-ramps to Monero
  '0x77777feddddffc19ff86db637967013e6c6a116c': { name: 'THORChain Router', category: 'swap_service', risk: 7 },
  '0xd152f549545093347a162dce210e7293f1452150': { name: 'Disperse.app', category: 'utility', risk: 1 },
  '0x111111125421ca6dc452d289314280a0f8842a65': { name: '1inch v6 Router', category: 'dex_router', risk: 0 },
  '0x1111111254eeb25477b68fb85ed929f73a960582': { name: '1inch v5 Router', category: 'dex_router', risk: 0 },
  '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45': { name: 'Uniswap v3 Router 2', category: 'dex_router', risk: 0 },
  '0xe592427a0aece92de3edee1f18e0157c05861564': { name: 'Uniswap v3 Router', category: 'dex_router', risk: 0 },
  '0x7a250d5630b4cf539739df2c5dacb4c659f2488d': { name: 'Uniswap v2 Router 2', category: 'dex_router', risk: 0 },
  '0x66a9893cc07d91d95644aedd05d03f95e1dba8af': { name: 'Uniswap Universal Router', category: 'dex_router', risk: 0 },
  '0x3fc91a3afd70395cd496c647d5a6cc9d4b2b7fad': { name: 'Uniswap Universal Router 2', category: 'dex_router', risk: 0 },
  '0x6131b5fae19ea4f9d964eac0408e4408b66337b5': { name: 'KyberSwap Aggregator', category: 'dex_router', risk: 0 },
  '0xdef1c0ded9bec7f1a1670819833240f027b25eff': { name: '0x Exchange Proxy', category: 'dex_router', risk: 0 },
  '0xdef171fe48cf0115b1d80b88dc8eab59176fee57': { name: 'Paraswap v5', category: 'dex_router', risk: 0 },
  '0x6a000f20005980200259b80c5102003040001068': { name: 'Paraswap v6', category: 'dex_router', risk: 0 },
  '0xf21661d0d1d76d3ecb8e1b9f1c923dbfffae4097': { name: 'Realio Network', category: 'token', risk: 0 },
  '0x59728544b08ab483533076417fbbb2fd0b17ce3a': { name: 'LooksRare Exchange', category: 'nft_marketplace', risk: 0 },
  '0x0000000000a39bb272e79075ade125fd351887ac': { name: 'Blur.io Marketplace', category: 'nft_marketplace', risk: 0 },
};

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(ALCHEMY_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        signal: AbortSignal.timeout(30000),
      });
      if (!r.ok) { await sleep(500); continue; }
      const j: any = await r.json();
      if (j?.error) { return null; }
      return j?.result ?? null;
    } catch { await sleep(500); }
  }
  return null;
}

async function getBlockByTime(targetTs: number): Promise<number> {
  const latest = parseInt((await alchemy('eth_blockNumber', [])) || '0x0', 16);
  const blocksAgo = Math.floor((Date.now() - targetTs) / 1000 / 12);
  return Math.max(0, latest - blocksAgo);
}

async function getOutboundTransfers(addr: string, fromBlock: number): Promise<any[]> {
  const params = {
    fromBlock: '0x' + fromBlock.toString(16),
    toBlock: 'latest',
    fromAddress: addr,
    category: ['external', 'erc20'],
    maxCount: '0x' + (200).toString(16),
    order: 'asc',
    withMetadata: true,
  };
  const r = await alchemy('alchemy_getAssetTransfers', [params]);
  return r?.transfers || [];
}

async function getCode(addr: string): Promise<string | null> {
  return await alchemy('eth_getCode', [addr, 'latest']);
}

async function getEthBalance(addr: string): Promise<number> {
  const r = await alchemy('eth_getBalance', [addr, 'latest']);
  return r ? Number(BigInt(r)) / 1e18 : 0;
}

function priceUsd(asset: string | undefined, value: number): number {
  if (!asset) return 0;
  const p = PRICES_USD[asset.toUpperCase()] || 0;
  return p * (value || 0);
}

function fmtUsd(n: number): string {
  if (!Number.isFinite(n)) return '$0';
  if (Math.abs(n) >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (Math.abs(n) >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

type NodeKind =
  | 'CEX_DEPOSIT' | 'BRIDGE' | 'MIXER' | 'SWAP_SERVICE'
  | 'DEX_ROUTER' | 'NFT_MARKETPLACE' | 'TOKEN_CONTRACT'
  | 'DUMPER' | 'INTERMEDIARY_EOA' | 'RESTING_EOA' | 'CONTRACT_OTHER' | 'UTILITY';

interface FlowEdge {
  from: string;
  to: string;
  asset: string;
  amount: number;
  amountUsd: number;
  txHash: string;
  blockNum: number;
  timestamp: string | null;
  hop: number;
}

interface NodeInfo {
  address: string;
  kind: NodeKind;
  label: string | null;
  category: string | null;
  isContract: boolean;
  ethBalance?: number;
  totalInUsd: number;
  totalOutUsd: number;
}

interface DumperTrace {
  dumper: string;
  dumpRank: number;
  tokensSold: number;
  totalProceedsUsd: number;
  totalHopsExplored: number;
  edges: FlowEdge[];
  nodes: Record<string, NodeInfo>;
  terminalsByCategory: Record<string, { count: number; totalUsd: number; addresses: string[] }>;
  topTerminals: { address: string; label: string | null; category: string; usd: number }[];
}

function classify(addr: string, code: string | null): { kind: NodeKind; label: string | null; category: string | null } {
  const lo = addr.toLowerCase();
  const special = SPECIAL_LABELS[lo];
  if (special) {
    const cat = special.category;
    const k: NodeKind =
      cat === 'bridge' ? 'BRIDGE' :
      cat === 'mixer' ? 'MIXER' :
      cat === 'swap_service' ? 'SWAP_SERVICE' :
      cat === 'dex_router' ? 'DEX_ROUTER' :
      cat === 'nft_marketplace' ? 'NFT_MARKETPLACE' :
      cat === 'token' ? 'TOKEN_CONTRACT' :
      cat === 'utility' ? 'UTILITY' : 'CONTRACT_OTHER';
    return { kind: k, label: special.name, category: cat };
  }
  const lookup = lookupAddress(addr);
  if (lookup) {
    const k: NodeKind = lookup.category === 'exchange' ? 'CEX_DEPOSIT'
                       : lookup.category === 'bridge' ? 'BRIDGE'
                       : lookup.category === 'mixer' ? 'MIXER'
                       : 'CONTRACT_OTHER';
    return { kind: k, label: lookup.name, category: lookup.category || null };
  }
  const isContract = !!(code && code !== '0x');
  return { kind: isContract ? 'CONTRACT_OTHER' : 'INTERMEDIARY_EOA', label: null, category: null };
}

const TERMINAL_KINDS: NodeKind[] = ['CEX_DEPOSIT', 'BRIDGE', 'MIXER', 'SWAP_SERVICE', 'DEX_ROUTER', 'NFT_MARKETPLACE', 'TOKEN_CONTRACT', 'UTILITY'];

async function traceDumper(dumperAddr: string, fromBlock: number, dumpRank: number, tokensSold: number): Promise<DumperTrace> {
  console.log(`\n[Trace] #${dumpRank}  ${dumperAddr}  (${tokensSold.toFixed(0)} RAVE sold)`);
  const edges: FlowEdge[] = [];
  const nodes: Record<string, NodeInfo> = {};
  const visited = new Set<string>();

  // BFS queue of (address, hop, valueAvailable)
  const queue: { addr: string; hop: number }[] = [{ addr: dumperAddr.toLowerCase(), hop: 0 }];
  let totalCalls = 0;

  while (queue.length > 0) {
    const { addr, hop } = queue.shift()!;
    if (visited.has(addr)) continue;
    visited.add(addr);
    process.stderr.write(`    [#${dumpRank} h${hop}] ${addr.slice(0, 10)}… (q=${queue.length}, v=${visited.size})\n`);

    // Always classify the node (label DB + on-chain code lookup) — even at MAX_HOPS,
    // so terminals are properly categorised for aggregation.
    const code = await getCode(addr); totalCalls++;
    await sleep(RATE_LIMIT_MS);
    const cls = classify(addr, code);
    const isContract = !!(code && code !== '0x');
    if (!nodes[addr]) {
      nodes[addr] = {
        address: addr,
        kind: addr === dumperAddr.toLowerCase() ? 'DUMPER' : cls.kind,
        label: cls.label,
        category: cls.category,
        isContract,
        totalInUsd: 0,
        totalOutUsd: 0,
      };
    }
    // At max hop: stop expansion entirely (node already classified above)
    if (hop >= MAX_HOPS) continue;
    // Stop expansion at terminals (we still record the node)
    if (TERMINAL_KINDS.includes(cls.kind) && hop > 0) continue;
    // Treat unknown contracts as terminals — they're DEX routers/swap services/etc.
    if (isContract && hop > 0 && cls.kind === 'INTERMEDIARY_EOA') {
      nodes[addr].kind = 'CONTRACT_OTHER';
      continue;
    }

    // Pull outbound transfers
    const out = await getOutboundTransfers(addr, fromBlock); totalCalls++;
    await sleep(RATE_LIMIT_MS);

    // Aggregate by (destination, asset) — one summed edge per pair (massively reduces edge count)
    const byPair = new Map<string, { to: string; asset: string; amount: number; amountUsd: number; txCount: number; firstTxHash: string; firstBlockNum: number; firstTs: string | null }>();
    for (const t of out) {
      const to = (t.to || '').toLowerCase();
      if (!to || to === addr) continue;
      const asset = t.asset || (t.category === 'external' ? 'ETH' : '?');
      const amount = typeof t.value === 'number' ? t.value : 0;
      const amountUsd = priceUsd(asset, amount);
      const blockNum = parseInt(t.blockNum || '0x0', 16);
      const ts = t.metadata?.blockTimestamp || null;
      const k = `${to}::${asset}`;
      if (!byPair.has(k)) byPair.set(k, { to, asset, amount: 0, amountUsd: 0, txCount: 0, firstTxHash: t.hash, firstBlockNum: blockNum, firstTs: ts });
      const agg = byPair.get(k)!;
      agg.amount += amount;
      agg.amountUsd += amountUsd;
      agg.txCount += 1;
    }

    // Group by destination for ranking
    const byDest = new Map<string, { totalUsd: number; pairs: typeof byPair extends Map<string, infer V> ? V[] : never }>();
    for (const p of byPair.values()) {
      if (!byDest.has(p.to)) byDest.set(p.to, { totalUsd: 0, pairs: [] as any });
      const e = byDest.get(p.to)!;
      e.totalUsd += p.amountUsd;
      e.pairs.push(p as any);
    }
    const ranked = [...byDest.entries()].sort((a, b) => b[1].totalUsd - a[1].totalUsd);
    const branches = ranked.slice(0, MAX_BRANCHES_PER_HOP);

    for (const [destAddr, info] of branches) {
      for (const ev of info.pairs) {
        edges.push({
          from: addr, to: destAddr,
          asset: ev.asset, amount: ev.amount, amountUsd: ev.amountUsd,
          txHash: ev.firstTxHash, blockNum: ev.firstBlockNum, timestamp: ev.firstTs,
          hop: hop + 1,
        });
        nodes[addr].totalOutUsd += ev.amountUsd;
        if (!nodes[destAddr]) {
          nodes[destAddr] = {
            address: destAddr, kind: 'INTERMEDIARY_EOA', label: null, category: null,
            isContract: false, totalInUsd: 0, totalOutUsd: 0,
          };
        }
        nodes[destAddr].totalInUsd += ev.amountUsd;
      }
      if (!visited.has(destAddr)) queue.push({ addr: destAddr, hop: hop + 1 });
    }
  }

  // Final classification of any unclassified nodes + check if RESTING (still has balance)
  for (const [a, n] of Object.entries(nodes)) {
    if (n.kind === 'INTERMEDIARY_EOA' && n.totalOutUsd === 0 && n.totalInUsd > 0) {
      const bal = await getEthBalance(a); totalCalls++;
      n.ethBalance = bal;
      if (bal > 0.001) n.kind = 'RESTING_EOA';
      await sleep(RATE_LIMIT_MS);
    }
  }

  // Build per-category terminal aggregation
  const terminalsByCategory: Record<string, { count: number; totalUsd: number; addresses: string[] }> = {};
  const terminalNodes: { address: string; label: string | null; category: string; usd: number }[] = [];
  for (const n of Object.values(nodes)) {
    // At MAX_HOPS=1, every non-dumper node is a terminal (no further expansion happens).
    // Include INTERMEDIARY_EOA explicitly so totals reconcile with traced proceeds.
    const isTerm =
      TERMINAL_KINDS.includes(n.kind) ||
      n.kind === 'RESTING_EOA' ||
      n.kind === 'CONTRACT_OTHER' ||
      n.kind === 'INTERMEDIARY_EOA';
    if (!isTerm || n.address === dumperAddr.toLowerCase()) continue;
    const cat = n.category || (
      n.kind === 'RESTING_EOA' ? 'resting_eoa' :
      n.kind === 'CONTRACT_OTHER' ? 'unknown_contract' :
      n.kind === 'INTERMEDIARY_EOA' ? 'intermediary_eoa' :
      n.kind.toLowerCase());
    if (!terminalsByCategory[cat]) terminalsByCategory[cat] = { count: 0, totalUsd: 0, addresses: [] };
    terminalsByCategory[cat].count++;
    terminalsByCategory[cat].totalUsd += n.totalInUsd;
    if (!terminalsByCategory[cat].addresses.includes(n.address)) terminalsByCategory[cat].addresses.push(n.address);
    terminalNodes.push({ address: n.address, label: n.label, category: cat, usd: n.totalInUsd });
  }
  terminalNodes.sort((a, b) => b.usd - a.usd);

  const totalProceedsUsd = edges.filter(e => e.from === dumperAddr.toLowerCase() && e.hop === 1).reduce((s, e) => s + e.amountUsd, 0);
  console.log(`         visited=${visited.size}  edges=${edges.length}  proceeds=${fmtUsd(totalProceedsUsd)}  api-calls=${totalCalls}`);

  return {
    dumper: dumperAddr.toLowerCase(),
    dumpRank,
    tokensSold,
    totalProceedsUsd,
    totalHopsExplored: visited.size,
    edges,
    nodes,
    terminalsByCategory,
    topTerminals: terminalNodes.slice(0, 10),
  };
}

function buildHtml(traces: DumperTrace[], aggregate: any, runMeta: any): string {
  const C = {
    bg: '#0A0A0A', panel: '#111111', panel2: '#1E293B',
    text: '#FFFFFF', gold: '#FFD700', cyan: '#00D4FF', red: '#FF4444', green: '#22C55E', orange: '#F59E0B',
  };

  const stat = (val: string, label: string, color = C.gold) =>
    `<td align="center" valign="middle" style="background:${C.panel2};border:1px solid #334155;border-radius:6px;padding:14px 8px;width:25%;">
      <div style="color:${color};font-size:20px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;">${val}</div>
      <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;margin-top:4px;">${label}</div>
    </td>`;

  // Sort aggregate categories by USD
  const aggRows = Object.entries(aggregate.byCategory as Record<string, any>).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd);

  const aggTable = `
    <table cellpadding="6" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:${C.panel2};border-radius:6px;">
      <tr>
        <th align="left" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">Terminal Category</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">USD Value</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">% of total</th>
        <th align="right" style="background:${C.panel};color:${C.cyan};font-size:12px;padding:8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">Endpoint count</th>
      </tr>
      ${aggRows.map(([cat, info]: any) => `
        <tr>
          <td style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${cat}</td>
          <td align="right" style="color:${C.gold};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(info.totalUsd)}</td>
          <td align="right" style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${(info.totalUsd / aggregate.grandTotalUsd * 100).toFixed(1)}%</td>
          <td align="right" style="color:${C.text};font-size:12px;padding:8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${info.uniqueEndpoints}</td>
        </tr>`).join('')}
    </table>`;

  // Top exchanges/bridges/mixers/services across cluster
  const topEndpointRows = aggregate.topEndpoints.slice(0, 25).map((e: any) => `
    <tr>
      <td style="color:${C.text};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${e.label || '<unlabeled>'}</td>
      <td style="color:${C.gold};font-size:10px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${e.address}</td>
      <td style="color:#86EFAC;font-size:10px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${e.category}</td>
      <td align="right" style="color:${C.gold};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(e.totalUsd)}</td>
      <td align="right" style="color:${C.text};font-size:11px;padding:6px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${e.dumperHits}</td>
    </tr>`).join('');

  // Per-dumper cards
  const dumperCards = traces.map(t => {
    const topT = t.topTerminals.slice(0, 6).map(x => `
      <tr>
        <td style="color:${C.text};font-size:11px;padding:5px 8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${x.label || '<unlabeled>'}</td>
        <td style="color:${C.gold};font-size:10px;padding:5px 8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${x.address.slice(0, 12)}…${x.address.slice(-8)}</td>
        <td style="color:#86EFAC;font-size:10px;padding:5px 8px;border-bottom:1px solid #1E3A5F;font-family:Segoe UI,Arial,sans-serif;">${x.category}</td>
        <td align="right" style="color:${C.gold};font-size:11px;padding:5px 8px;border-bottom:1px solid #1E3A5F;font-family:Consolas,monospace;">${fmtUsd(x.usd)}</td>
      </tr>`).join('');
    const catSummary = Object.entries(t.terminalsByCategory).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd).slice(0, 5)
      .map(([c, i]: any) => `<span style="color:${C.cyan};">${c}</span> <span style="color:${C.gold};">${fmtUsd(i.totalUsd)}</span>`).join(' · ');
    return `
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;margin-bottom:14px;"><tr><td style="padding:14px;">
        <div style="color:${C.gold};font-size:14px;font-weight:bold;font-family:Segoe UI,Arial,sans-serif;margin-bottom:6px;">Dumper #${t.dumpRank} — ${fmtUsd(t.totalProceedsUsd)} traced  <span style="color:${C.text};font-size:11px;font-weight:normal;">(${t.tokensSold.toFixed(0)} RAVE sold · ${t.totalHopsExplored} nodes explored)</span></div>
        <div style="color:${C.gold};font-family:Consolas,monospace;font-size:11px;background:${C.bg};padding:5px 8px;border-radius:4px;display:inline-block;margin-bottom:8px;">${t.dumper}</div>
        <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:8px;">Where it ended up: ${catSummary || '<span style="color:#94A3B8;">(no terminals — funds still at this address)</span>'}</div>
        ${topT ? `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border-radius:6px;margin-top:6px;">
          <tr>
            <th align="left" style="color:${C.cyan};font-size:11px;padding:5px 8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">Terminal Label</th>
            <th align="left" style="color:${C.cyan};font-size:11px;padding:5px 8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">Address</th>
            <th align="left" style="color:${C.cyan};font-size:11px;padding:5px 8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">Type</th>
            <th align="right" style="color:${C.cyan};font-size:11px;padding:5px 8px;border-bottom:1px solid #334155;font-family:Segoe UI,Arial,sans-serif;">USD</th>
          </tr>
          ${topT}
        </table>` : ''}
      </td></tr></table>`;
  }).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>RAVEDAO Forward Trace</title></head>
<body style="background:${C.bg};margin:0;padding:0;font-family:Segoe UI,Arial,sans-serif;color:${C.text};">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.bg};"><tr><td align="center" style="padding:24px;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="980" style="max-width:980px;width:100%;">

  <tr><td style="background:linear-gradient(135deg,#7F1D1D 0%,#1a0000 100%);background-color:#7F1D1D;border:2px solid ${C.red};border-radius:12px;padding:28px;text-align:center;">
    <div style="color:${C.red};font-size:24px;font-weight:bold;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:8px;">📡 RAVEDAO_DUMP — PROCEEDS FORWARD-TRACE</div>
    <div style="color:#FCA5A5;font-size:14px;font-family:Segoe UI,Arial,sans-serif;margin-bottom:6px;">Where the dumped value is sitting right now</div>
    <div style="color:${C.text};font-size:11px;font-family:Segoe UI,Arial,sans-serif;">Generated ${runMeta.generated} · ${MAX_HOPS}-hop trace · top ${MAX_BRANCHES_PER_HOP} branches per hop · ${runMeta.windowHours}h window</div>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;padding:18px;">
    <div style="color:${C.cyan};font-size:15px;font-weight:bold;border-bottom:1px solid #1E3A5F;padding-bottom:6px;margin-bottom:12px;">📊 Cluster-Wide Aggregate</div>
    <table cellpadding="0" cellspacing="6" border="0" width="100%"><tr>
      ${stat(`${traces.length}`, 'Dumpers traced')}
      ${stat(fmtUsd(aggregate.grandTotalUsd), 'Total proceeds traced', C.green)}
      ${stat(`${aggregate.uniqueTerminalsTotal}`, 'Unique terminal endpoints')}
      ${stat(`${aggregate.totalEdges}`, 'Hop-by-hop edges recorded')}
    </tr></table>
    <div style="height:14px;"></div>
    ${aggTable}
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;padding:18px;">
    <div style="color:${C.cyan};font-size:15px;font-weight:bold;border-bottom:1px solid #1E3A5F;padding-bottom:6px;margin-bottom:12px;">🎯 Top 25 Terminal Endpoints (across all dumpers)</div>
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:${C.panel2};border-radius:6px;">
      <tr>
        <th align="left" style="color:${C.cyan};font-size:11px;padding:7px;border-bottom:1px solid #334155;">Label</th>
        <th align="left" style="color:${C.cyan};font-size:11px;padding:7px;border-bottom:1px solid #334155;">Address</th>
        <th align="left" style="color:${C.cyan};font-size:11px;padding:7px;border-bottom:1px solid #334155;">Type</th>
        <th align="right" style="color:${C.cyan};font-size:11px;padding:7px;border-bottom:1px solid #334155;">USD</th>
        <th align="right" style="color:${C.cyan};font-size:11px;padding:7px;border-bottom:1px solid #334155;">Dumpers hit</th>
      </tr>
      ${topEndpointRows}
    </table>
  </td></tr>

  <tr><td style="height:14px;"></td></tr>

  <tr><td style="background:${C.panel};border:1px solid #1E3A5F;border-radius:8px;padding:18px;">
    <div style="color:${C.cyan};font-size:15px;font-weight:bold;border-bottom:1px solid #1E3A5F;padding-bottom:6px;margin-bottom:12px;">🔍 Per-Dumper Forward Trace</div>
    ${dumperCards}
  </td></tr>

  <tr><td style="text-align:center;padding-top:14px;">
    <div style="color:${C.text};font-size:11px;line-height:1.6;">
      © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.<br>
      ${proprietaryHeader('Alpha Proceeds Forward-Trace Engine™').replace(/\n/g, ' · ')}<br>
      INTERNAL OWNER USE ONLY · DO NOT FORWARD
    </div>
  </td></tr>

</table>
</td></tr></table>
</body></html>`;
}

async function main() {
  console.log(proprietaryHeader('Alpha Proceeds Forward-Trace Engine™'));
  console.log('=== RAVEDAO_DUMP — Proceeds Forward-Trace ===');

  const analysis = JSON.parse(fs.readFileSync(ANALYSIS_PATH, 'utf-8'));
  const dumpers = analysis.dumpers as any[];
  console.log(`[Init] Loaded ${dumpers.length} dumpers from analysis JSON`);
  console.log(`[Init] Window: ${WINDOW_HOURS}h · MaxHops: ${MAX_HOPS} · MaxBranches/hop: ${MAX_BRANCHES_PER_HOP}`);

  const fromBlock = await getBlockByTime(WINDOW_START);
  console.log(`[Init] Starting from block ~${fromBlock}`);

  const traces: DumperTrace[] = [];
  for (let i = 0; i < dumpers.length; i++) {
    const d = dumpers[i];
    if (d.address === '0x0000000000000000000000000000000000000000') {
      console.log(`\n[Trace] #${i + 1}  zero address — skipping (burn/mint events)`); console.log('---FLUSH---');
      continue;
    }
    try {
      const t = await traceDumper(d.address, fromBlock, i + 1, d.tokensSold || 0);
      traces.push(t);
    } catch (err: any) {
      console.log(`         ❌ trace failed for #${i + 1}: ${err?.message || err}`);
    }
    // Checkpoint after each dumper (so we have something even if process dies)
    try {
      fs.writeFileSync(OUT_JSON + '.checkpoint', JSON.stringify({ partialTraces: traces.length, traces }, null, 2));
    } catch {}
    console.log('---FLUSH---');
  }

  // Build cluster-wide aggregate
  const byCategory: Record<string, { totalUsd: number; uniqueEndpoints: number; addresses: Set<string> }> = {};
  const byEndpoint: Record<string, { label: string | null; category: string; totalUsd: number; dumperHits: Set<number> }> = {};

  for (const t of traces) {
    for (const [cat, info] of Object.entries(t.terminalsByCategory)) {
      if (!byCategory[cat]) byCategory[cat] = { totalUsd: 0, uniqueEndpoints: 0, addresses: new Set() };
      byCategory[cat].totalUsd += info.totalUsd;
      info.addresses.forEach(a => byCategory[cat].addresses.add(a));
    }
    for (const term of t.topTerminals) {
      if (!byEndpoint[term.address]) byEndpoint[term.address] = { label: term.label, category: term.category, totalUsd: 0, dumperHits: new Set() };
      byEndpoint[term.address].totalUsd += term.usd;
      byEndpoint[term.address].dumperHits.add(t.dumpRank);
    }
  }
  for (const c of Object.keys(byCategory)) byCategory[c].uniqueEndpoints = byCategory[c].addresses.size;
  const grandTotalUsd = Object.values(byCategory).reduce((s, c) => s + c.totalUsd, 0);
  const uniqueTerminalsTotal = new Set(Object.keys(byEndpoint)).size;
  const totalEdges = traces.reduce((s, t) => s + t.edges.length, 0);
  const topEndpoints = Object.entries(byEndpoint)
    .map(([addr, info]) => ({ address: addr, label: info.label, category: info.category, totalUsd: info.totalUsd, dumperHits: info.dumperHits.size }))
    .sort((a, b) => b.totalUsd - a.totalUsd);

  const aggregate = {
    byCategory: Object.fromEntries(Object.entries(byCategory).map(([c, v]) => [c, { totalUsd: v.totalUsd, uniqueEndpoints: v.uniqueEndpoints }])),
    grandTotalUsd,
    uniqueTerminalsTotal,
    totalEdges,
    topEndpoints,
  };

  const runMeta = {
    generated: new Date().toISOString(),
    windowHours: WINDOW_HOURS,
    maxHops: MAX_HOPS,
    maxBranchesPerHop: MAX_BRANCHES_PER_HOP,
    dumpersTraced: traces.length,
  };

  const out = {
    proprietary: proprietaryHeader('Alpha Proceeds Forward-Trace Engine™'),
    case: 'RAVEDAO_DUMP',
    technology: 'Alpha Proceeds Forward-Trace Engine™',
    runMeta,
    aggregate,
    traces,
  };

  fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf-8');
  fs.writeFileSync(OUT_HTML, buildHtml(traces, aggregate, runMeta), 'utf-8');
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(OUT_JSON, { title: 'RAVEDAO_DUMP — Forward-Trace', caseId: 'RAVEDAO_DUMP', chain: 'ethereum', direction: 'forward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  console.log(`\n=== Forward-Trace Complete ===`);
  console.log(`Dumpers traced:           ${traces.length}`);
  console.log(`Total proceeds traced:    ${fmtUsd(grandTotalUsd)}`);
  console.log(`Unique terminal nodes:    ${uniqueTerminalsTotal}`);
  console.log(`Hop edges recorded:       ${totalEdges}`);
  console.log(`\nTop categories by USD:`);
  for (const [cat, info] of Object.entries(aggregate.byCategory).sort((a: any, b: any) => b[1].totalUsd - a[1].totalUsd)) {
    console.log(`  ${cat.padEnd(28)} ${fmtUsd((info as any).totalUsd).padStart(10)}  (${(info as any).uniqueEndpoints} endpoints)`);
  }
  console.log(`\nTop 10 terminal endpoints:`);
  for (const e of topEndpoints.slice(0, 10)) {
    console.log(`  ${(e.label || '<unlabeled>').padEnd(28)} ${e.category.padEnd(20)} ${fmtUsd(e.totalUsd).padStart(10)}  (hit by ${e.dumperHits} dumpers)`);
  }
  console.log(`\nOutputs:`);
  console.log(`  ${OUT_JSON}`);
  console.log(`  ${OUT_HTML}`);
}

main().catch(e => { console.error(e); process.exit(1); });
