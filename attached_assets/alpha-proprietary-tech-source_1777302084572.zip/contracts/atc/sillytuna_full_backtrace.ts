/**
 * PROPRIETARY AND CONFIDENTIAL
 * © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.
 *
 * SillyTuna Full Back-Trace + KYC Mapping Engine
 *
 * Forward-trace data (from existing DAU v2 Full Trace Engine) is loaded from
 *   contracts/atc/DAUv2_full_trace_results.json
 *
 * Back-trace performed here using:
 *   - Alchemy alchemy_getAssetTransfers (inbound, multi-hop)
 *   - Alpha Address Label Database™ (KYC chokepoint identification)
 *   - Wallet Leech Protocol™ patterns
 *
 * Outputs:
 *   - contracts/atc/sillytuna_backtrace_mapping.json   (full data)
 *   - contracts/atc/sillytuna_backtrace_mapping.html   (viewer)
 */

import fs from 'node:fs';
import path from 'node:path';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) {
  console.error('[BackTrace] FATAL: ALCHEMY_API_KEY not set');
  process.exit(1);
}
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const HOPS = 2;
const MAX_SOURCES_PER_WALLET = 25;
const RATE_LIMIT_MS = 150;
const HOP2_BRANCH_CAP = 12;

interface IncomingTransfer {
  from: string;
  hash: string;
  blockNum: string;
  asset: string;
  value: number;
  category: string;
}

interface KycHit {
  exchange: string;
  category: string;
  hopAddress: string;
  hopLevel: number;
  amount: number;
  asset: string;
  txHash: string;
}

interface BackTraceNode {
  address: string;
  hop: number;
  label: string | null;
  category: string | null;
  isKycChokepoint: boolean;
  fundedBy: string[];
  inboundCount: number;
  totalInboundEth: number;
  topSources: { address: string; valueEth: number; label: string | null }[];
}

interface AttackerWalletReport {
  address: string;
  forwardTraceMeta: any;
  backTraceNodes: BackTraceNode[];
  kycChokepoints: KycHit[];
  hopsAnalyzed: number;
  totalSourcesAnalyzed: number;
  riskAssessment: 'KYC_EXPOSED' | 'PARTIAL_KYC' | 'OBFUSCATED' | 'UNKNOWN';
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function getInboundTransfers(address: string, maxCount = 50): Promise<IncomingTransfer[]> {
  try {
    const resp = await fetch(ALCHEMY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'alchemy_getAssetTransfers',
        params: [{
          fromBlock: '0x0',
          toBlock: 'latest',
          toAddress: address,
          category: ['external', 'erc20'],
          maxCount: `0x${maxCount.toString(16)}`,
          order: 'desc',
          withMetadata: false,
        }],
      }),
      signal: AbortSignal.timeout(30000),
    });
    if (!resp.ok) {
      console.log(`[BackTrace] Alchemy HTTP ${resp.status} for ${address.slice(0, 10)}`);
      return [];
    }
    const data: any = await resp.json();
    if (data.error) {
      console.log(`[BackTrace] Alchemy error: ${data.error.message}`);
      return [];
    }
    const transfers = data?.result?.transfers || [];
    return transfers.map((t: any) => ({
      from: (t.from || '').toLowerCase(),
      hash: t.hash || '',
      blockNum: t.blockNum || '',
      asset: t.asset || 'ETH',
      value: typeof t.value === 'number' ? t.value : 0,
      category: t.category || 'external',
    })).filter((t: IncomingTransfer) => t.from && t.from !== '0x0000000000000000000000000000000000000000');
  } catch (e) {
    console.log(`[BackTrace] Fetch error for ${address.slice(0, 10)}: ${(e as Error).message}`);
    return [];
  }
}

async function backTraceWallet(targetAddress: string): Promise<AttackerWalletReport> {
  console.log(`\n[BackTrace] === Tracing ${targetAddress} ===`);

  const visited = new Set<string>([targetAddress.toLowerCase()]);
  const nodes: BackTraceNode[] = [];
  const kycHits: KycHit[] = [];

  let currentLevel: string[] = [targetAddress.toLowerCase()];
  let totalSources = 0;

  for (let hop = 1; hop <= HOPS; hop++) {
    const nextLevel = new Set<string>();

    for (const addr of currentLevel) {
      const transfers = await getInboundTransfers(addr, MAX_SOURCES_PER_WALLET);
      await sleep(RATE_LIMIT_MS);

      const grouped = new Map<string, { totalEth: number; txs: IncomingTransfer[] }>();
      for (const t of transfers) {
        const src = t.from;
        if (!grouped.has(src)) grouped.set(src, { totalEth: 0, txs: [] });
        const g = grouped.get(src)!;
        if (t.asset === 'ETH') g.totalEth += t.value;
        g.txs.push(t);
      }

      const topSources = Array.from(grouped.entries())
        .sort((a, b) => b[1].totalEth - a[1].totalEth)
        .slice(0, 10)
        .map(([address, data]) => {
          const lbl = lookupAddress(address);
          return { address, valueEth: data.totalEth, label: lbl?.name || null };
        });

      const node: BackTraceNode = {
        address: addr,
        hop,
        label: lookupAddress(addr)?.name || null,
        category: lookupAddress(addr)?.category || null,
        isKycChokepoint: false,
        fundedBy: Array.from(grouped.keys()),
        inboundCount: transfers.length,
        totalInboundEth: Array.from(grouped.values()).reduce((s, g) => s + g.totalEth, 0),
        topSources,
      };

      // Check each source for KYC chokepoint
      for (const [src, data] of grouped.entries()) {
        const lbl = lookupAddress(src);
        if (lbl && (lbl.category === 'exchange')) {
          // CEX = KYC exposure
          for (const tx of data.txs) {
            kycHits.push({
              exchange: lbl.name,
              category: lbl.subcategory || lbl.category,
              hopAddress: addr,
              hopLevel: hop,
              amount: tx.value,
              asset: tx.asset,
              txHash: tx.hash,
            });
          }
          node.isKycChokepoint = true;
        }

        // Queue next hop if not already visited and not a known terminal entity
        if (!visited.has(src) && !lbl) {
          nextLevel.add(src);
        }
        visited.add(src);
        totalSources++;
      }

      nodes.push(node);
      console.log(`  Hop ${hop}: ${addr.slice(0, 10)} → ${transfers.length} inbound | ${grouped.size} unique sources | ${node.isKycChokepoint ? '🔑 KYC HIT' : ''}`);
    }

    currentLevel = Array.from(nextLevel).slice(0, HOP2_BRANCH_CAP);
    if (currentLevel.length === 0) break;
  }

  let risk: AttackerWalletReport['riskAssessment'] = 'UNKNOWN';
  if (kycHits.some(k => k.hopLevel === 1)) risk = 'KYC_EXPOSED';
  else if (kycHits.length > 0) risk = 'PARTIAL_KYC';
  else if (totalSources > 5) risk = 'OBFUSCATED';

  console.log(`[BackTrace] ✅ ${targetAddress.slice(0, 10)} → ${nodes.length} nodes, ${kycHits.length} KYC hits, risk=${risk}`);

  return {
    address: targetAddress,
    forwardTraceMeta: null,
    backTraceNodes: nodes,
    kycChokepoints: kycHits,
    hopsAnalyzed: HOPS,
    totalSourcesAnalyzed: totalSources,
    riskAssessment: risk,
  };
}

function buildHtml(reports: AttackerWalletReport[], forwardData: any): string {
  const totalKyc = reports.reduce((s, r) => s + r.kycChokepoints.length, 0);
  const exposedCount = reports.filter(r => r.riskAssessment === 'KYC_EXPOSED').length;
  const partialCount = reports.filter(r => r.riskAssessment === 'PARTIAL_KYC').length;
  const obfuscCount = reports.filter(r => r.riskAssessment === 'OBFUSCATED').length;

  const exchangeHits = new Map<string, number>();
  for (const r of reports) for (const k of r.kycChokepoints) {
    exchangeHits.set(k.exchange, (exchangeHits.get(k.exchange) || 0) + 1);
  }

  const exchangeRows = Array.from(exchangeHits.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([ex, n]) => `<tr><td style="padding:8px;color:#d4a017;font-weight:bold;">${ex}</td><td style="padding:8px;text-align:right;color:#4ade80;">${n}</td></tr>`)
    .join('');

  const reportCards = reports.map(r => {
    const riskColor = r.riskAssessment === 'KYC_EXPOSED' ? '#4ade80'
      : r.riskAssessment === 'PARTIAL_KYC' ? '#ffcc00'
      : r.riskAssessment === 'OBFUSCATED' ? '#ff8800' : '#888';
    const kycRows = r.kycChokepoints.slice(0, 50).map(k => `
      <tr>
        <td style="padding:6px;color:#d4a017;font-family:monospace;font-size:12px;">${k.exchange}</td>
        <td style="padding:6px;color:#888;font-family:monospace;font-size:11px;">hop ${k.hopLevel}</td>
        <td style="padding:6px;color:#ccc;font-family:monospace;font-size:11px;">${k.hopAddress.slice(0, 10)}...${k.hopAddress.slice(-6)}</td>
        <td style="padding:6px;text-align:right;color:#4ade80;font-family:monospace;">${k.amount.toFixed(4)} ${k.asset}</td>
        <td style="padding:6px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${k.txHash}" style="color:#4488ff;">${k.txHash.slice(0, 14)}...</a></td>
      </tr>`).join('');
    const sourceRows = r.backTraceNodes.flatMap(n => n.topSources.slice(0, 5).map(s => `
      <tr>
        <td style="padding:4px;color:#888;font-size:11px;">hop ${n.hop}</td>
        <td style="padding:4px;font-family:monospace;font-size:11px;color:#ccc;">${n.address.slice(0, 10)}...${n.address.slice(-4)}</td>
        <td style="padding:4px;color:#666;">←</td>
        <td style="padding:4px;font-family:monospace;font-size:11px;color:${s.label ? '#d4a017' : '#999'};">${s.address.slice(0, 10)}...${s.address.slice(-4)}</td>
        <td style="padding:4px;font-size:11px;color:${s.label ? '#4ade80' : '#666'};">${s.label || '(unknown wallet)'}</td>
        <td style="padding:4px;text-align:right;font-family:monospace;font-size:11px;color:#4ade80;">${s.valueEth.toFixed(3)} ETH</td>
      </tr>`)).join('');

    return `
    <div style="background:#111;border-left:4px solid ${riskColor};padding:16px;margin:16px 0;border-radius:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="font-family:monospace;font-size:13px;color:#fff;font-weight:bold;">${r.address}</div>
        <div style="background:${riskColor}22;color:${riskColor};padding:4px 12px;border-radius:12px;font-size:11px;font-weight:bold;">${r.riskAssessment.replace('_',' ')}</div>
      </div>
      <div style="color:#888;font-size:12px;margin:6px 0;">
        ${r.backTraceNodes.length} nodes traced | ${r.totalSourcesAnalyzed} sources analyzed | <span style="color:#4ade80;">${r.kycChokepoints.length} KYC hits</span>
      </div>
      ${r.kycChokepoints.length > 0 ? `
        <details style="margin-top:10px;">
          <summary style="color:#4ade80;font-weight:bold;cursor:pointer;font-size:13px;">🔑 KYC CHOKEPOINTS (${r.kycChokepoints.length}) — subpoenable exchange deposits</summary>
          <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">
            <tr style="background:#1a1a1a;"><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">EXCHANGE</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">HOP</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">FUNDED ADDRESS</th><th style="padding:6px;text-align:right;color:#d4a017;font-size:11px;">AMOUNT</th><th style="padding:6px;text-align:left;color:#d4a017;font-size:11px;">TX</th></tr>
            ${kycRows}
          </table>
        </details>` : ''}
      <details style="margin-top:8px;">
        <summary style="color:#888;cursor:pointer;font-size:12px;">📊 Top funding sources (all hops)</summary>
        <table style="width:100%;margin-top:8px;background:#0a0a0a;border-radius:4px;">${sourceRows}</table>
      </details>
    </div>`;
  }).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>SillyTuna Back-Trace + KYC Mapping</title><style>
body{background:#0a0a0a;color:#fff;font-family:'Segoe UI',Arial,sans-serif;padding:20px;max-width:1400px;margin:0 auto;line-height:1.6;}
::-webkit-scrollbar{width:8px;}::-webkit-scrollbar-track{background:#111;}::-webkit-scrollbar-thumb{background:#333;border-radius:4px;}
</style></head><body>
<div style="text-align:center;border-bottom:2px solid #d4a017;padding-bottom:20px;margin-bottom:30px;">
<div style="font-size:11px;color:#d4a017;letter-spacing:4px;">ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY AND CONFIDENTIAL</div>
<h1 style="margin:10px 0;font-size:28px;">SillyTuna Full Back-Trace + KYC Mapping</h1>
<div style="color:#888;font-size:14px;">Forward Trace + Reverse Origin Intelligence + KYC Chokepoint Analysis</div>
<div style="color:#666;font-size:12px;margin-top:8px;">Case: 306db48a-36e2-42c1-9d7c-3b49d5bfdb49 | Victim: 0x6fe0fab2164d8e0d03ad6a628e2af78624060322 | Generated: ${new Date().toISOString()}</div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:30px;">
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #d4a017;"><div style="font-size:32px;color:#d4a017;font-weight:bold;">${reports.length}</div><div style="color:#888;font-size:12px;">Wallets Back-Traced</div></div>
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:32px;color:#4ade80;font-weight:bold;">${totalKyc}</div><div style="color:#888;font-size:12px;">KYC Chokepoints Found</div></div>
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:32px;color:#4ade80;font-weight:bold;">${exposedCount}</div><div style="color:#888;font-size:12px;">KYC Exposed (1-hop)</div></div>
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #ffcc00;"><div style="font-size:32px;color:#ffcc00;font-weight:bold;">${partialCount}</div><div style="color:#888;font-size:12px;">Partial KYC</div></div>
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #ff8800;"><div style="font-size:32px;color:#ff8800;font-weight:bold;">${obfuscCount}</div><div style="color:#888;font-size:12px;">Obfuscated</div></div>
  <div style="background:#111;padding:18px;border-radius:8px;text-align:center;border:1px solid #4488ff;"><div style="font-size:32px;color:#4488ff;font-weight:bold;">${forwardData?.totalDiscoveredWallets || 0}</div><div style="color:#888;font-size:12px;">Forward Trace (DAU v2)</div></div>
</div>

${exchangeHits.size > 0 ? `
<h2 style="color:#4ade80;margin-top:30px;border-bottom:1px solid #4ade80;padding-bottom:8px;">🎯 KYC EXCHANGE FUNDING SOURCES</h2>
<p style="color:#ccc;">Each row = an exchange that directly or indirectly funded an attacker wallet. Subpoena these exchanges for KYC records.</p>
<table style="width:60%;background:#111;border-radius:6px;">
<tr style="background:#1a1a1a;"><th style="padding:10px;text-align:left;color:#d4a017;">EXCHANGE</th><th style="padding:10px;text-align:right;color:#d4a017;">FUNDING TXS</th></tr>
${exchangeRows}
</table>` : ''}

<h2 style="color:#d4a017;margin-top:30px;border-bottom:1px solid #d4a017;padding-bottom:8px;">PER-WALLET BACK-TRACE REPORTS</h2>
${reportCards}

<div style="margin-top:40px;padding:20px;background:#111;border-radius:8px;border:1px solid #333;color:#888;font-size:12px;">
<strong style="color:#d4a017;">Methodology:</strong> Each attacker wallet was back-traced ${HOPS} hops using Alpha Transaction Origin Intelligence™ + Alchemy alchemy_getAssetTransfers. Every funding source was cross-referenced against the Alpha Address Label Database™ (${'~'}80 known CEX/bridge/mixer addresses across Binance, Coinbase, Kraken, OKX, Huobi, KuCoin, Bittrex, Crypto.com, Bybit, Gate.io, Gemini, Bitfinex, Upbit, Bitstamp, ChangeNow, FixedFloat). Any direct or indirect funding from a centralized exchange = KYC chokepoint = subpoenable identity reveal.
</div>
</body></html>`;
}

async function main() {
  console.log('[BackTrace] === SillyTuna Full Back-Trace Engine ===\n');

  const forwardPath = path.resolve('contracts/atc/DAUv2_full_trace_results.json');
  const forward = JSON.parse(fs.readFileSync(forwardPath, 'utf-8'));
  console.log(`[BackTrace] Loaded forward trace: ${forward.totalDiscoveredWallets} wallets discovered, ${forward.deployTargets.length} deploy targets`);

  const targets: string[] = forward.deployTargets.map((t: any) =>
    typeof t === 'string' ? t : t.address
  ).filter(Boolean);

  console.log(`[BackTrace] Back-tracing ${targets.length} attacker wallets, ${HOPS} hops each\n`);

  const reports: AttackerWalletReport[] = [];
  for (let i = 0; i < targets.length; i++) {
    const addr = targets[i];
    console.log(`\n[BackTrace] [${i + 1}/${targets.length}] ${addr}`);
    try {
      const r = await backTraceWallet(addr);
      // attach forward-trace metadata if present
      const fwd = (forward.allWallets || []).find((w: any) => w.address?.toLowerCase() === addr.toLowerCase());
      r.forwardTraceMeta = fwd ? {
        confidence: fwd.confidence,
        ethBalance: fwd.ethBalance,
        usdEstimate: fwd.usdEstimate,
        totalInbound: fwd.totalInbound,
        totalOutbound: fwd.totalOutbound,
        sentToExchange: fwd.sentToExchange,
        exchangeName: fwd.exchangeName,
        interactedWithMonero: fwd.interactedWithMonero,
        interactedWithBridge: fwd.interactedWithBridge,
        bridgeName: fwd.bridgeName,
        role: fwd.role,
        riskScore: fwd.riskScore,
      } : null;
      reports.push(r);
    } catch (e) {
      console.log(`[BackTrace] ERROR on ${addr}: ${(e as Error).message}`);
    }
  }

  // Write outputs
  const jsonOut = path.resolve('contracts/atc/sillytuna_backtrace_mapping.json');
  fs.writeFileSync(jsonOut, JSON.stringify({
    generatedAt: new Date().toISOString(),
    caseId: forward.caseId,
    victim: forward.victim,
    forwardSummary: {
      total: forward.totalDiscoveredWallets,
      active: forward.activeWallets,
      dormant: forward.dormantWallets,
    },
    backTraceConfig: { hops: HOPS, maxSourcesPerWallet: MAX_SOURCES_PER_WALLET },
    reports,
  }, null, 2));
  console.log(`\n[BackTrace] ✅ Wrote ${jsonOut}`);
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(jsonOut, { title: `SillyTuna — Backward Trace (Source-of-Funds)`, caseId: forward.caseId || 'SILLYTUNA', chain: 'polygon', direction: 'backward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }

  const htmlOut = path.resolve('contracts/atc/sillytuna_backtrace_mapping.html');
  fs.writeFileSync(htmlOut, buildHtml(reports, forward));
  console.log(`[BackTrace] ✅ Wrote ${htmlOut}`);

  // Final summary
  const totalKyc = reports.reduce((s, r) => s + r.kycChokepoints.length, 0);
  const exchanges = new Set<string>();
  for (const r of reports) for (const k of r.kycChokepoints) exchanges.add(k.exchange);
  console.log('\n=== FINAL SUMMARY ===');
  console.log(`Wallets back-traced: ${reports.length}`);
  console.log(`Total KYC chokepoints: ${totalKyc}`);
  console.log(`Unique exchanges in funding chain: ${exchanges.size}`);
  console.log(`  → ${Array.from(exchanges).join(', ')}`);
  console.log(`KYC_EXPOSED:  ${reports.filter(r => r.riskAssessment === 'KYC_EXPOSED').length}`);
  console.log(`PARTIAL_KYC:  ${reports.filter(r => r.riskAssessment === 'PARTIAL_KYC').length}`);
  console.log(`OBFUSCATED:   ${reports.filter(r => r.riskAssessment === 'OBFUSCATED').length}`);
  console.log(`UNKNOWN:      ${reports.filter(r => r.riskAssessment === 'UNKNOWN').length}`);
}

main().catch(e => { console.error(e); process.exit(1); });
