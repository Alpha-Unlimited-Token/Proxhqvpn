import solc from 'solc';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const contractPath = path.join(__dirname, 'AlphaTrackingCoin.sol');
const source = fs.readFileSync(contractPath, 'utf8');

const input = {
  language: 'Solidity',
  sources: {
    'AlphaTrackingCoin.sol': { content: source },
  },
  settings: {
    optimizer: { enabled: true, runs: 200 },
    outputSelection: {
      '*': {
        '*': ['abi', 'evm.bytecode.object'],
      },
    },
  },
};

console.log('[ATC Compiler] Compiling AlphaTrackingCoin.sol...');

const output = JSON.parse(solc.compile(JSON.stringify(input)));

if (output.errors) {
  const errors = output.errors.filter((e: any) => e.severity === 'error');
  if (errors.length > 0) {
    console.error('[ATC Compiler] Compilation errors:');
    for (const err of errors) {
      console.error(`  ${err.formattedMessage}`);
    }
    process.exit(1);
  }
  const warnings = output.errors.filter((e: any) => e.severity === 'warning');
  if (warnings.length > 0) {
    console.log(`[ATC Compiler] ${warnings.length} warning(s) (non-fatal)`);
  }
}

const contract = output.contracts['AlphaTrackingCoin.sol']['AlphaTrackingCoin'];
const abi = contract.abi;
const bytecode = contract.evm.bytecode.object;

const artifactDir = path.join(__dirname, 'artifacts');
if (!fs.existsSync(artifactDir)) fs.mkdirSync(artifactDir, { recursive: true });

const artifact = {
  contractName: 'AlphaTrackingCoin',
  abi,
  bytecode: `0x${bytecode}`,
  compiler: 'solc 0.8.28',
  compiledAt: new Date().toISOString(),
};

fs.writeFileSync(path.join(artifactDir, 'AlphaTrackingCoin.json'), JSON.stringify(artifact, null, 2));

console.log('[ATC Compiler] Compilation successful!');
console.log(`[ATC Compiler] ABI: ${abi.length} functions/events`);
console.log(`[ATC Compiler] Bytecode: ${bytecode.length / 2} bytes`);
console.log(`[ATC Compiler] Artifact saved to contracts/atc/artifacts/AlphaTrackingCoin.json`);
