import { ethers } from 'ethers';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NETWORKS: Record<string, { rpcWs: string; rpcHttp: string; name: string }> = {
  sepolia: {
    rpcWs: 'wss://eth-sepolia.g.alchemy.com/v2/',
    rpcHttp: 'https://eth-sepolia.g.alchemy.com/v2/',
    name: 'Sepolia Testnet',
  },
  mainnet: {
    rpcWs: 'wss://eth-mainnet.g.alchemy.com/v2/',
    rpcHttp: 'https://eth-mainnet.g.alchemy.com/v2/',
    name: 'Ethereum Mainnet',
  },
};

interface TrackingEvent {
  transferId: bigint;
  from: string;
  to: string;
  amount: bigint;
  timestamp: bigint;
  blockNumber: bigint;
  txHash: string;
  eventTxHash: string;
}

interface BeaconPingEvent {
  wallet: string;
  balance: bigint;
  timestamp: bigint;
  signalType: string;
}

const EVENT_LOG: Array<TrackingEvent | BeaconPingEvent> = [];

async function startListener() {
  const network = process.env.ATC_NETWORK || 'sepolia';
  const alchemyKey = process.env.ALCHEMY_API_KEY;
  const contractAddress = process.env.ATC_CONTRACT_ADDRESS;

  if (!alchemyKey) {
    console.error('[ATC Listener] ERROR: ALCHEMY_API_KEY not set');
    process.exit(1);
  }

  if (!contractAddress) {
    console.error('[ATC Listener] ERROR: ATC_CONTRACT_ADDRESS not set');
    console.error('  Deploy the contract first: npx tsx contracts/atc/deploy.ts');
    process.exit(1);
  }

  const networkKey = network === 'ethereum' ? 'mainnet' : network;
  const networkConfig = NETWORKS[networkKey];
  if (!networkConfig) {
    console.error(`[ATC Listener] ERROR: Unknown network "${network}"`);
    process.exit(1);
  }

  const artifactPath = path.join(__dirname, 'artifacts', 'AlphaTrackingCoin.json');
  if (!fs.existsSync(artifactPath)) {
    console.error('[ATC Listener] ERROR: Contract artifact not found. Compile first.');
    process.exit(1);
  }

  const artifact = JSON.parse(fs.readFileSync(artifactPath, 'utf8'));

  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  ALPHA TRACKING COIN™ — ON-CHAIN BEACON LISTENER');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Network:          ${networkConfig.name}`);
  console.log(`  Contract:         ${contractAddress}`);
  console.log(`  Listening for:    TrackingSignal, BeaconPing, ForensicAlert`);
  console.log('───────────────────────────────────────────────────────────────\n');

  let provider: ethers.Provider;
  let usingWebSocket = false;

  try {
    provider = new ethers.WebSocketProvider(networkConfig.rpcWs + alchemyKey);
    usingWebSocket = true;
    console.log('[ATC Listener] Connected via WebSocket (real-time)\n');
  } catch {
    provider = new ethers.JsonRpcProvider(networkConfig.rpcHttp + alchemyKey);
    console.log('[ATC Listener] Connected via HTTP (polling mode)\n');
  }

  const contract = new ethers.Contract(contractAddress, artifact.abi, provider);

  const currentBlock = await provider.getBlockNumber();
  console.log(`[ATC Listener] Current block: ${currentBlock}`);
  console.log('[ATC Listener] Listening for events...\n');

  contract.on('TrackingSignal', (transferId, from, to, amount, timestamp, blockNumber, txHash, event) => {
    const amountFormatted = ethers.formatEther(amount);
    const trackingEvent: TrackingEvent = {
      transferId,
      from,
      to,
      amount,
      timestamp,
      blockNumber,
      txHash: txHash,
      eventTxHash: event.log.transactionHash,
    };
    EVENT_LOG.push(trackingEvent);

    console.log('═══════════════════════════════════════════════════════════════');
    console.log('  🚨 TRACKING SIGNAL DETECTED');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log(`  Transfer ID:   #${transferId.toString()}`);
    console.log(`  From:          ${from}`);
    console.log(`  To:            ${to}`);
    console.log(`  Amount:        ${amountFormatted} ATC`);
    console.log(`  Block:         ${blockNumber.toString()}`);
    console.log(`  Timestamp:     ${new Date(Number(timestamp) * 1000).toISOString()}`);
    console.log(`  TX Hash:       ${event.log.transactionHash}`);
    console.log('───────────────────────────────────────────────────────────────');

    forwardToSpiderBeacon({
      type: 'tracking_signal',
      transferId: transferId.toString(),
      from,
      to,
      amount: amountFormatted,
      blockNumber: blockNumber.toString(),
      txHash: event.log.transactionHash,
      network,
      timestamp: new Date(Number(timestamp) * 1000).toISOString(),
    });
  });

  contract.on('BeaconPing', (wallet, balance, timestamp, signalType, event) => {
    const balanceFormatted = ethers.formatEther(balance);
    const pingEvent: BeaconPingEvent = { wallet, balance, timestamp, signalType };
    EVENT_LOG.push(pingEvent);

    console.log(`  📡 Beacon Ping: ${signalType.toUpperCase()} | Wallet: ${wallet.slice(0, 10)}...${wallet.slice(-6)} | Balance: ${balanceFormatted} ATC | TX: ${event.log.transactionHash.slice(0, 16)}...`);

    forwardToSpiderBeacon({
      type: 'beacon_ping',
      wallet,
      balance: balanceFormatted,
      signalType,
      network,
      timestamp: new Date(Number(timestamp) * 1000).toISOString(),
    });
  });

  contract.on('ForensicAlert', (transferId, flaggedAddress, alertType, amount, timestamp, event) => {
    const amountFormatted = ethers.formatEther(amount);

    console.log('═══════════════════════════════════════════════════════════════');
    console.log('  🔴 FORENSIC ALERT');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log(`  Flagged Address: ${flaggedAddress}`);
    console.log(`  Alert Type:      ${alertType}`);
    console.log(`  Amount:          ${amountFormatted} ATC`);
    console.log(`  TX Hash:         ${event.log.transactionHash}`);
    console.log('───────────────────────────────────────────────────────────────');

    forwardToSpiderBeacon({
      type: 'forensic_alert',
      flaggedAddress,
      alertType,
      amount: amountFormatted,
      network,
      txHash: event.log.transactionHash,
      timestamp: new Date(Number(timestamp) * 1000).toISOString(),
    });
  });

  contract.on('Transfer', (from, to, value, event) => {
    const amountFormatted = ethers.formatEther(value);
    const isMint = from === ethers.ZeroAddress;
    console.log(`  💰 Transfer: ${isMint ? 'MINT' : from.slice(0, 10) + '...'} → ${to.slice(0, 10)}... | ${amountFormatted} ATC | TX: ${event.log.transactionHash.slice(0, 16)}...`);
  });

  if (!usingWebSocket) {
    console.log('[ATC Listener] HTTP mode — polling every 12 seconds for new events');
    let lastBlock = currentBlock;

    setInterval(async () => {
      try {
        const newBlock = await provider.getBlockNumber();
        if (newBlock > lastBlock) {
          const events = await contract.queryFilter('TrackingSignal', lastBlock + 1, newBlock);
          for (const event of events) {
            console.log(`[ATC Listener] Caught event in block ${event.blockNumber} (polling)`);
          }
          lastBlock = newBlock;
        }
      } catch (err) {
        console.error('[ATC Listener] Polling error:', err);
      }
    }, 12000);
  }

  console.log('\n[ATC Listener] 🟢 ACTIVE — Monitoring all ATC transfers on-chain');
  console.log('[ATC Listener] Press Ctrl+C to stop\n');

  process.on('SIGINT', () => {
    console.log(`\n[ATC Listener] Shutting down. ${EVENT_LOG.length} events captured.\n`);

    const logPath = path.join(__dirname, 'deployments', `${network}-event-log.json`);
    fs.writeFileSync(logPath, JSON.stringify(EVENT_LOG, null, 2, ));
    console.log(`[ATC Listener] Event log saved to ${logPath}`);
    process.exit(0);
  });
}

async function forwardToSpiderBeacon(data: Record<string, string>) {
  try {
    const baseUrl = process.env.REPLIT_DEV_DOMAIN
      ? `https://${process.env.REPLIT_DEV_DOMAIN}`
      : 'http://localhost:5000';

    const response = await fetch(`${baseUrl}/api/forensic/spider-beacon/on-chain-signal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (response.ok) {
      console.log(`  → Signal forwarded to Spider Beacon ✓`);
    } else {
      console.log(`  → Spider Beacon forward failed (${response.status})`);
    }
  } catch {
    console.log(`  → Spider Beacon endpoint not reachable (standalone mode)`);
  }
}

startListener().catch((err) => {
  console.error('[ATC Listener] Fatal error:', err.message || err);
  process.exit(1);
});
