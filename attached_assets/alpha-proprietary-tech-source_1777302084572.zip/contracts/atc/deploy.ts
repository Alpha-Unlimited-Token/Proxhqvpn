import { ethers } from 'ethers';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NETWORKS: Record<string, { rpcUrl: string; chainId: number; explorer: string; name: string }> = {
  sepolia: {
    rpcUrl: 'https://eth-sepolia.g.alchemy.com/v2/',
    chainId: 11155111,
    explorer: 'https://sepolia.etherscan.io',
    name: 'Sepolia Testnet',
  },
  mainnet: {
    rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/',
    chainId: 1,
    explorer: 'https://etherscan.io',
    name: 'Ethereum Mainnet',
  },
};

async function deploy() {
  const network = process.argv[2] || 'sepolia';
  const alchemyKey = process.env.ALCHEMY_API_KEY;
  const deployerKey = process.env.ATC_DEPLOYER_PRIVATE_KEY;
  const forensicAuthority = process.env.ATC_FORENSIC_AUTHORITY || '';
  const initialSupply = process.env.ATC_INITIAL_SUPPLY || '1000000000';

  if (!alchemyKey) {
    console.error('[ATC Deploy] ERROR: ALCHEMY_API_KEY environment variable not set');
    console.error('  Get a free key at https://www.alchemy.com/');
    process.exit(1);
  }

  if (!deployerKey) {
    console.error('[ATC Deploy] ERROR: ATC_DEPLOYER_PRIVATE_KEY environment variable not set');
    console.error('  This is the private key of the wallet that will deploy the contract');
    console.error('  It needs Sepolia ETH (free from faucets) or real ETH for mainnet');
    process.exit(1);
  }

  const networkConfig = NETWORKS[network];
  if (!networkConfig) {
    console.error(`[ATC Deploy] ERROR: Unknown network "${network}". Use "sepolia" or "mainnet"`);
    process.exit(1);
  }

  const artifactPath = path.join(__dirname, 'artifacts', 'AlphaTrackingCoin.json');
  if (!fs.existsSync(artifactPath)) {
    console.error('[ATC Deploy] ERROR: Contract not compiled. Run compile first:');
    console.error('  npx tsx contracts/atc/compile.ts');
    process.exit(1);
  }

  const artifact = JSON.parse(fs.readFileSync(artifactPath, 'utf8'));

  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  ALPHA TRACKING COIN™ — CONTRACT DEPLOYMENT');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Network:          ${networkConfig.name}`);
  console.log(`  Chain ID:         ${networkConfig.chainId}`);
  console.log(`  Initial Supply:   ${Number(initialSupply).toLocaleString()} ATC`);
  console.log(`  Forensic Auth:    ${forensicAuthority || '(deployer will be authority)'}`);
  console.log('───────────────────────────────────────────────────────────────\n');

  const rpcUrl = networkConfig.rpcUrl + alchemyKey;
  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const wallet = new ethers.Wallet(deployerKey, provider);

  const balance = await provider.getBalance(wallet.address);
  const balanceEth = ethers.formatEther(balance);
  console.log(`  Deployer address: ${wallet.address}`);
  console.log(`  Deployer balance: ${balanceEth} ETH\n`);

  if (balance === 0n) {
    console.error('[ATC Deploy] ERROR: Deployer wallet has 0 ETH');
    if (network === 'sepolia') {
      console.error('  Get free Sepolia ETH from: https://sepoliafaucet.com/');
    }
    process.exit(1);
  }

  const forensicAddr = forensicAuthority || wallet.address;

  console.log('[ATC Deploy] Deploying contract...\n');

  const factory = new ethers.ContractFactory(artifact.abi, artifact.bytecode, wallet);

  const gasEstimate = await provider.estimateGas({
    data: factory.getDeployTransaction(BigInt(initialSupply), forensicAddr).data,
    from: wallet.address,
  });
  const feeData = await provider.getFeeData();
  const estimatedCost = gasEstimate * (feeData.gasPrice || 0n);
  console.log(`  Estimated gas:    ${gasEstimate.toString()}`);
  console.log(`  Estimated cost:   ${ethers.formatEther(estimatedCost)} ETH\n`);

  const contract = await factory.deploy(BigInt(initialSupply), forensicAddr);

  console.log(`  Transaction hash: ${contract.deploymentTransaction()?.hash}`);
  console.log('  Waiting for confirmation...\n');

  await contract.waitForDeployment();
  const contractAddress = await contract.getAddress();

  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  DEPLOYMENT SUCCESSFUL!');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`  Contract address: ${contractAddress}`);
  console.log(`  Explorer:         ${networkConfig.explorer}/address/${contractAddress}`);
  console.log(`  TX:               ${networkConfig.explorer}/tx/${contract.deploymentTransaction()?.hash}`);
  console.log('───────────────────────────────────────────────────────────────\n');

  console.log('  ADD TO METAMASK:');
  console.log(`    Token Contract: ${contractAddress}`);
  console.log('    Token Symbol:   ATC');
  console.log('    Decimals:       18');
  console.log();

  const deploymentRecord = {
    network,
    chainId: networkConfig.chainId,
    contractAddress,
    deployerAddress: wallet.address,
    forensicAuthority: forensicAddr,
    initialSupply,
    transactionHash: contract.deploymentTransaction()?.hash,
    deployedAt: new Date().toISOString(),
    explorerUrl: `${networkConfig.explorer}/address/${contractAddress}`,
  };

  const deploymentsDir = path.join(__dirname, 'deployments');
  if (!fs.existsSync(deploymentsDir)) fs.mkdirSync(deploymentsDir, { recursive: true });
  fs.writeFileSync(
    path.join(deploymentsDir, `${network}-deployment.json`),
    JSON.stringify(deploymentRecord, null, 2)
  );

  console.log(`  Deployment record saved to contracts/atc/deployments/${network}-deployment.json`);
  console.log();
  console.log('  NEXT STEPS:');
  console.log('  1. Add ATC_CONTRACT_ADDRESS to your environment secrets');
  console.log(`     Value: ${contractAddress}`);
  console.log('  2. Add ATC_NETWORK to your environment secrets');
  console.log(`     Value: ${network}`);
  console.log('  3. Start the on-chain beacon listener:');
  console.log('     npx tsx contracts/atc/listener.ts');
  console.log();
}

deploy().catch((err) => {
  console.error('[ATC Deploy] Fatal error:', err.message || err);
  process.exit(1);
});
