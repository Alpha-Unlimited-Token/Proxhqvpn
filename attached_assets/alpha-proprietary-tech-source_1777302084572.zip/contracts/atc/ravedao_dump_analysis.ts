/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║   ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY AND CONFIDENTIAL            ║
 * ║   © 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.      ║
 * ║                                                                          ║
 * ║   RaveDAO Dump Forensic Analysis                                         ║
 * ║   Case ID: RAVEDAO_DUMP                                                  ║
 * ║   Token:   0x17205fab260a7a6383a81452cE6315A39370Db97 (RAVE, 18 dec)     ║
 * ║                                                                          ║
 * ║   Performs the FULL SillyTuna-grade forensic pipeline:                   ║
 * ║     1. Token Dump Detection Engine™      — last 72h sells aggregation    ║
 * ║     2. Top Dumper Identification         — ranked by sell volume         ║
 * ║     3. Dev Wallet Identification         — earliest holders cohort       ║
 * ║     4. KYC Chokepoint Mapper™            — 2-hop back-trace              ║
 * ║     5. Post-Trace Activity Surveillance™ — forward activity overlay      ║
 * ║     6. 4-Axis Attacker Verification™     — proves wallets aren't CEXes   ║
 * ║     7. Perpetrator-vs-Victim Distinction™ — proves wallets aren't victims║
 * ║     8. Dev↔Dumper Cross-Reference         — finds collusion paths        ║
 * ║                                                                          ║
 * ║   Outputs:                                                               ║
 * ║     contracts/atc/ravedao_dump_analysis.json                             ║
 * ║     contracts/atc/ravedao_dump_analysis.html                             ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

import fs from 'node:fs';
import path from 'node:path';
import { enforceProprietaryLicense, proprietaryHeader } from '../../private/security/alpha_proprietary_guard.js';
import { lookupAddress } from '../../server/services/addressLabelDatabase.js';

enforceProprietaryLicense('RaveDAO Dump Analysis');

const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
if (!ALCHEMY_API_KEY) { console.error('FATAL: ALCHEMY_API_KEY not set'); process.exit(1); }
const ALCHEMY_URL = `https://eth-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;

const CASE_ID = 'RAVEDAO_DUMP';
const TOKEN = '0x17205fab260a7a6383a81452ce6315a39370db97'.toLowerCase();
const TOKEN_SYMBOL = 'RAVE';
const TOKEN_NAME = 'RaveDAO';
const TOKEN_DECIMALS = 18;

const NOW = Date.now();
const WINDOW_HOURS = 72;
const WINDOW_START = NOW - WINDOW_HOURS * 3600 * 1000;
const TOP_DUMPERS = 20;
const DEV_COHORT_SIZE = 30;
const RATE_LIMIT_MS = 180;
const MAX_PAGE_SIZE = 1000;
const SUDDEN_DRAIN_PCT = 95;
const LARGE_USD = 5_000;

const PRICES_USD: Record<string, number> = {
  ETH: 2080, WETH: 2080,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1, FRAX: 1,
  WBTC: 67000, BTC: 67000,
  UNI: 8.5, LINK: 14, MATIC: 0.6,
  RAVE: 0, // unknown — will compute from pool
};

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function alchemy(method: string, params: any[]): Promise<any> {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(ALCHEMY_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        signal: AbortSignal.timeout(30000),
      });
      if (!r.ok) { await sleep(500); continue; }
      const j: any = await r.json();
      if (j?.error) { return null; }
      return j?.result ?? null;
    } catch { await sleep(500); }
  }
  return null;
}

async function getBlockByTime(targetTs: number): Promise<number> {
  const latest = parseInt(await alchemy('eth_blockNumber', []) || '0x0', 16);
  // ~12s/block. Estimate
  const secAgo = (Date.now() - targetTs) / 1000;
  const blocksAgo = Math.floor(secAgo / 12);
  return Math.max(0, latest - blocksAgo);
}

async function getAllTokenTransfersInWindow(token: string, fromBlock: number): Promise<any[]> {
  const all: any[] = [];
  let pageKey: string | undefined;
  let pages = 0;
  do {
    const params: any = {
      fromBlock: '0x' + fromBlock.toString(16),
      toBlock: 'latest',
      contractAddresses: [token],
      category: ['erc20'],
      maxCount: '0x' + MAX_PAGE_SIZE.toString(16),
      order: 'asc',
      withMetadata: true,
    };
    if (pageKey) params.pageKey = pageKey;
    const result = await alchemy('alchemy_getAssetTransfers', [params]);
    if (!result?.transfers) break;
    all.push(...result.transfers);
    pageKey = result.pageKey;
    pages++;
    if (pages > 20) break;
    await sleep(RATE_LIMIT_MS);
  } while (pageKey);
  return all;
}

async function getEarliestTransfers(token: string, count = 500): Promise<any[]> {
  const params: any = {
    fromBlock: '0x0', toBlock: 'latest',
    contractAddresses: [token],
    category: ['erc20'],
    maxCount: '0x' + count.toString(16),
    order: 'asc',
    withMetadata: true,
  };
  const r = await alchemy('alchemy_getAssetTransfers', [params]);
  return r?.transfers || [];
}

async function getTransfersFor(addr: string, direction: 'from' | 'to', maxCount = 500): Promise<any[]> {
  const params: any = {
    fromBlock: '0x0', toBlock: 'latest',
    category: ['external', 'erc20'],
    maxCount: '0x' + maxCount.toString(16),
    order: 'desc', withMetadata: true,
  };
  if (direction === 'from') params.fromAddress = addr; else params.toAddress = addr;
  const r = await alchemy('alchemy_getAssetTransfers', [params]);
  return r?.transfers || [];
}

async function getCode(addr: string): Promise<string | null> {
  return await alchemy('eth_getCode', [addr, 'latest']);
}

async function getBalance(addr: string): Promise<number> {
  const r = await alchemy('eth_getBalance', [addr, 'latest']);
  return r ? Number(BigInt(r)) / 1e18 : 0;
}

function fmtUsd(n: number): string {
  if (!Number.isFinite(n)) return '$0';
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

function priceUsd(asset: string, value: number): number {
  return (PRICES_USD[asset?.toUpperCase()] ?? 0) * value;
}

// ─── STAGE 1+2: DUMP DETECTION + TOP DUMPER IDENTIFICATION ─────────────────
async function detectDumpAndRankDumpers(): Promise<{
  pools: { address: string; tokensReceived: number; txs: number; label: string | null }[];
  dumpers: { address: string; tokensSold: number; txs: number; firstSell: string; lastSell: string; sentTo: string[]; isContract?: boolean }[];
  totalDumped: number;
  totalTxsInWindow: number;
}> {
  console.log(`\n[Dump] Stage 1: scanning RAVE transfers in last ${WINDOW_HOURS}h`);
  const fromBlock = await getBlockByTime(WINDOW_START);
  console.log(`[Dump] Window from block ~${fromBlock}`);
  const transfers = await getAllTokenTransfersInWindow(TOKEN, fromBlock);
  console.log(`[Dump] Pulled ${transfers.length} RAVE transfers in window`);

  // Aggregate top recipients = pools
  const recipientVol = new Map<string, { vol: number; txs: number }>();
  for (const t of transfers) {
    const to = (t.to || '').toLowerCase();
    if (!to) continue;
    const v = typeof t.value === 'number' ? t.value : 0;
    if (!recipientVol.has(to)) recipientVol.set(to, { vol: 0, txs: 0 });
    const r = recipientVol.get(to)!;
    r.vol += v; r.txs += 1;
  }
  const topRecipients = Array.from(recipientVol.entries()).sort((a, b) => b[1].vol - a[1].vol).slice(0, 8);
  // A pool: high volume + is a contract + receives many txs
  const pools: { address: string; tokensReceived: number; txs: number; label: string | null }[] = [];
  for (const [addr, info] of topRecipients) {
    if (info.txs < 5) continue;
    const code = await getCode(addr);
    if (!code || code === '0x') continue;
    const lbl = lookupAddress(addr);
    pools.push({ address: addr, tokensReceived: info.vol, txs: info.txs, label: lbl?.name || null });
    await sleep(RATE_LIMIT_MS);
  }
  console.log(`[Dump] Identified ${pools.length} liquidity pools / DEX router contracts`);
  for (const p of pools) console.log(`         ${p.address} | ${p.tokensReceived.toFixed(0)} RAVE | ${p.txs} txs | ${p.label || '?'}`);

  const poolSet = new Set(pools.map(p => p.address));

  // Aggregate sells (from -> pool)
  const sellerVol = new Map<string, { vol: number; txs: number; first: string; last: string; sentTo: Set<string> }>();
  for (const t of transfers) {
    const to = (t.to || '').toLowerCase();
    const from = (t.from || '').toLowerCase();
    if (!poolSet.has(to)) continue;
    if (!from) continue;
    const v = typeof t.value === 'number' ? t.value : 0;
    const ts = t?.metadata?.blockTimestamp || '';
    if (!sellerVol.has(from)) sellerVol.set(from, { vol: 0, txs: 0, first: ts, last: ts, sentTo: new Set() });
    const s = sellerVol.get(from)!;
    s.vol += v; s.txs += 1;
    if (ts < s.first) s.first = ts;
    if (ts > s.last) s.last = ts;
    s.sentTo.add(to);
  }

  const dumpers = Array.from(sellerVol.entries())
    .map(([address, info]) => ({
      address, tokensSold: info.vol, txs: info.txs,
      firstSell: info.first, lastSell: info.last, sentTo: Array.from(info.sentTo),
    }))
    .sort((a, b) => b.tokensSold - a.tokensSold)
    .slice(0, TOP_DUMPERS);

  // Mark contract status
  for (const d of dumpers) {
    const code = await getCode(d.address);
    d.isContract = !!code && code !== '0x';
    await sleep(RATE_LIMIT_MS);
  }

  const totalDumped = dumpers.reduce((s, d) => s + d.tokensSold, 0);
  console.log(`\n[Dump] TOP ${TOP_DUMPERS} DUMPERS:`);
  for (let i = 0; i < dumpers.length; i++) {
    const d = dumpers[i];
    console.log(`  ${(i + 1).toString().padStart(2)}. ${d.address}  ${d.tokensSold.toFixed(0).padStart(15)} RAVE  ${d.txs}txs  ${d.isContract ? '[contract]' : ''}`);
  }

  return { pools, dumpers, totalDumped, totalTxsInWindow: transfers.length };
}

// ─── STAGE 3: DEV WALLET IDENTIFICATION ────────────────────────────────────
async function identifyDevWallets(): Promise<{
  deployBlock: number | null;
  deployTimestamp: string | null;
  deployer: string | null;
  earliestHolders: { address: string; tokensReceived: number; firstReceiveTs: string; isContract: boolean }[];
}> {
  console.log(`\n[Dev] Stage 3: identifying RaveDAO dev/early-holder cohort`);
  const earliest = await getEarliestTransfers(TOKEN, 500);
  if (earliest.length === 0) return { deployBlock: null, deployTimestamp: null, deployer: null, earliestHolders: [] };

  const first = earliest[0];
  const deployBlock = parseInt(first.blockNum, 16);
  const deployTimestamp = first?.metadata?.blockTimestamp || null;
  const deployer = (first.from || '').toLowerCase();
  console.log(`[Dev] Token first transfer: block ${deployBlock} | ts ${deployTimestamp} | from ${deployer}`);

  const holderVol = new Map<string, { vol: number; first: string }>();
  for (const t of earliest.slice(0, 200)) {
    const to = (t.to || '').toLowerCase();
    if (!to || to === '0x0000000000000000000000000000000000000000') continue;
    const v = typeof t.value === 'number' ? t.value : 0;
    const ts = t?.metadata?.blockTimestamp || '';
    if (!holderVol.has(to)) holderVol.set(to, { vol: 0, first: ts });
    const h = holderVol.get(to)!;
    h.vol += v;
    if (ts < h.first || !h.first) h.first = ts;
  }
  const holders: { address: string; tokensReceived: number; firstReceiveTs: string; isContract: boolean }[] = [];
  for (const [address, info] of Array.from(holderVol.entries()).sort((a, b) => b[1].vol - a[1].vol).slice(0, DEV_COHORT_SIZE)) {
    const code = await getCode(address);
    holders.push({ address, tokensReceived: info.vol, firstReceiveTs: info.first, isContract: !!code && code !== '0x' });
    await sleep(RATE_LIMIT_MS);
  }
  console.log(`[Dev] Found ${holders.length} earliest holders (dev cohort)`);
  return { deployBlock, deployTimestamp, deployer, earliestHolders: holders };
}

// ─── STAGE 4: KYC CHOKEPOINT MAPPER (2-HOP BACK-TRACE) ─────────────────────
async function backTraceKycChokepoints(addr: string): Promise<{
  hop1Sources: { address: string; label: string | null; category: string | null; valueEth: number }[];
  hop2Sources: { via: string; address: string; label: string | null; category: string | null; valueEth: number }[];
  kycChokepoints: { exchange: string; hopLevel: number; hopAddress: string; amount: number; asset: string; txHash: string }[];
  riskAssessment: 'KYC_EXPOSED' | 'PARTIAL_KYC' | 'OBFUSCATED' | 'UNKNOWN';
}> {
  const inbound = await getTransfersFor(addr, 'to', 200);
  const sources = new Map<string, { vol: number; txs: any[] }>();
  for (const t of inbound) {
    const f = (t.from || '').toLowerCase();
    if (!f) continue;
    if (!sources.has(f)) sources.set(f, { vol: 0, txs: [] });
    const s = sources.get(f)!;
    if (typeof t.value === 'number') s.vol += t.value;
    s.txs.push(t);
  }

  const hop1Sources: any[] = [];
  const kyc: any[] = [];
  for (const [src, info] of Array.from(sources.entries()).sort((a, b) => b[1].vol - a[1].vol).slice(0, 10)) {
    const lbl = lookupAddress(src);
    hop1Sources.push({ address: src, label: lbl?.name || null, category: lbl?.category || null, valueEth: info.vol });
    if (lbl?.category === 'exchange') {
      const sample = info.txs[0];
      kyc.push({ exchange: lbl.name, hopLevel: 1, hopAddress: addr, amount: sample?.value || 0, asset: sample?.asset || 'ETH', txHash: sample?.hash || '' });
    }
  }

  // Hop 2 — from each non-labeled hop1 source
  const hop2Sources: any[] = [];
  for (const h1 of hop1Sources.filter(h => !h.label).slice(0, 5)) {
    await sleep(RATE_LIMIT_MS);
    const h1in = await getTransfersFor(h1.address, 'to', 100);
    const h2map = new Map<string, { vol: number; txs: any[] }>();
    for (const t of h1in) {
      const f = (t.from || '').toLowerCase();
      if (!f) continue;
      if (!h2map.has(f)) h2map.set(f, { vol: 0, txs: [] });
      const s = h2map.get(f)!;
      if (typeof t.value === 'number') s.vol += t.value;
      s.txs.push(t);
    }
    for (const [src, info] of Array.from(h2map.entries()).sort((a, b) => b[1].vol - a[1].vol).slice(0, 5)) {
      const lbl = lookupAddress(src);
      hop2Sources.push({ via: h1.address, address: src, label: lbl?.name || null, category: lbl?.category || null, valueEth: info.vol });
      if (lbl?.category === 'exchange') {
        const sample = info.txs[0];
        kyc.push({ exchange: lbl.name, hopLevel: 2, hopAddress: h1.address, amount: sample?.value || 0, asset: sample?.asset || 'ETH', txHash: sample?.hash || '' });
      }
    }
  }

  let risk: any = 'UNKNOWN';
  const directKyc = kyc.some(k => k.hopLevel === 1);
  const indirectKyc = kyc.some(k => k.hopLevel === 2);
  if (directKyc) risk = 'KYC_EXPOSED';
  else if (indirectKyc) risk = 'PARTIAL_KYC';
  else if (sources.size > 0) risk = 'OBFUSCATED';

  return { hop1Sources, hop2Sources, kycChokepoints: kyc, riskAssessment: risk };
}

// ─── STAGE 5: ACTIVITY OVERLAY ─────────────────────────────────────────────
async function activityOverlay(addr: string, attackerSet: Set<string>): Promise<{
  totalInUsd: number; totalOutUsd: number;
  largeTxs: number; largeTransfers: { hash: string; ts: string | null; dir: string; valueUsd: number; asset: string; counterparty: string; counterpartyLabel: string | null }[];
  exchangeInteractions: { exchange: string; direction: string; count: number; usd: number }[];
  isStillActive: boolean; lastActivityTs: string | null;
  hadSuddenDrain: boolean; drainPct: number; drainToAttacker: boolean; drainTxHash: string | null;
}> {
  const [outRaw, inRaw] = await Promise.all([
    getTransfersFor(addr, 'from', 300),
    getTransfersFor(addr, 'to', 300),
  ]);
  let totalIn = 0, totalOut = 0;
  const large: any[] = [];
  const exchMap = new Map<string, { dir: string; count: number; usd: number }>();
  let lastTs: string | null = null;

  const process = (t: any, direction: 'IN' | 'OUT') => {
    const ts = t?.metadata?.blockTimestamp || null;
    if (!ts || new Date(ts) < new Date(WINDOW_START)) return;
    const cp = (direction === 'IN' ? t.from : t.to || '').toLowerCase();
    if (!cp) return;
    const lbl = lookupAddress(cp);
    const v = typeof t.value === 'number' ? t.value : 0;
    const usd = priceUsd(t.asset, v);
    if (direction === 'IN') totalIn += usd; else totalOut += usd;
    if (!lastTs || ts > lastTs) lastTs = ts;
    if (usd >= LARGE_USD) {
      large.push({ hash: t.hash, ts, dir: direction, valueUsd: usd, asset: t.asset, counterparty: cp, counterpartyLabel: lbl?.name || null });
    }
    if (lbl?.category === 'exchange') {
      const k = `${lbl.name}|${direction}`;
      if (!exchMap.has(k)) exchMap.set(k, { dir: direction, count: 0, usd: 0 });
      const e = exchMap.get(k)!; e.count++; e.usd += usd;
    }
  };
  for (const t of inRaw) process(t, 'IN');
  for (const t of outRaw) process(t, 'OUT');

  // Sudden drain detection (any single outbound tx > 95% of total outbound USD)
  let drain = false, drainPct = 0, drainToAtt = false, drainHash: string | null = null;
  if (totalOut > 0) {
    const sortedOut = outRaw
      .filter((t: any) => t?.metadata?.blockTimestamp && new Date(t.metadata.blockTimestamp) >= new Date(WINDOW_START))
      .map((t: any) => ({ hash: t.hash, to: (t.to || '').toLowerCase(), usd: priceUsd(t.asset, t.value || 0) }))
      .sort((a: any, b: any) => b.usd - a.usd);
    if (sortedOut.length > 0 && sortedOut[0].usd > 0) {
      drainPct = (sortedOut[0].usd / totalOut) * 100;
      if (drainPct >= SUDDEN_DRAIN_PCT) {
        drain = true; drainHash = sortedOut[0].hash; drainToAtt = attackerSet.has(sortedOut[0].to);
      }
    }
  }

  large.sort((a, b) => b.valueUsd - a.valueUsd);
  const exchanges = Array.from(exchMap.entries()).map(([k, v]) => ({ exchange: k.split('|')[0], direction: v.dir, count: v.count, usd: v.usd }))
    .sort((a, b) => b.usd - a.usd);

  return {
    totalInUsd: totalIn, totalOutUsd: totalOut,
    largeTxs: large.length, largeTransfers: large.slice(0, 30),
    exchangeInteractions: exchanges,
    isStillActive: !!lastTs && new Date(lastTs).getTime() > NOW - 24 * 3600 * 1000,
    lastActivityTs: lastTs,
    hadSuddenDrain: drain, drainPct, drainToAttacker: drainToAtt, drainTxHash: drainHash,
  };
}

// ─── STAGE 6: 4-AXIS ATTACKER VERIFICATION ─────────────────────────────────
async function attackerVerification(addr: string, isContract: boolean): Promise<{
  uniqueSenders: number; uniqueRecipients: number;
  alphaLabel: string | null; alphaCategory: string | null;
  publicLabelLooksLikeExchange: boolean;
  verdict: 'CONFIRMED_ATTACKER' | 'LIKELY_ATTACKER' | 'POSSIBLE_EXCHANGE' | 'CONFIRMED_EXCHANGE';
  attackerScore: number; flags: string[];
}> {
  const [outRaw, inRaw] = await Promise.all([
    getTransfersFor(addr, 'from', 1000),
    getTransfersFor(addr, 'to', 1000),
  ]);
  const senders = new Set<string>();
  const recips = new Set<string>();
  for (const t of inRaw) { const f = (t.from || '').toLowerCase(); if (f && f !== addr) senders.add(f); }
  for (const t of outRaw) { const r = (t.to || '').toLowerCase(); if (r && r !== addr) recips.add(r); }

  const alpha = lookupAddress(addr);
  const flags: string[] = [];
  let score = 0;

  if (senders.size > 5000 || recips.size > 5000) { flags.push(`A2: Exchange-like diversity (senders=${senders.size}, recipients=${recips.size})`); score -= 35; }
  else if (senders.size + recips.size < 100) { flags.push(`A2: Low diversity (${senders.size}+${recips.size}) — attacker pattern`); score += 25; }
  else { flags.push(`A2: Moderate diversity (${senders.size}+${recips.size})`); score += 5; }
  if (isContract) { flags.push('A1: Address is a CONTRACT — possible exchange proxy or attacker contract'); score -= 10; }
  else { flags.push('A1: Plain EOA'); score += 5; }
  if (alpha?.category === 'exchange') { flags.push(`A3: 🚫 Listed in Alpha DB as ${alpha.name} (exchange)`); score -= 100; }
  else if (alpha) { flags.push(`A3: Alpha DB label: ${alpha.name} (${alpha.category})`); score -= 5; }
  else { flags.push('A3: No exchange label'); score += 10; }

  let verdict: any = 'LIKELY_ATTACKER';
  if (alpha?.category === 'exchange') verdict = 'CONFIRMED_EXCHANGE';
  else if (senders.size > 5000 || recips.size > 5000) verdict = 'POSSIBLE_EXCHANGE';
  else if (score >= 30) verdict = 'CONFIRMED_ATTACKER';

  return {
    uniqueSenders: senders.size, uniqueRecipients: recips.size,
    alphaLabel: alpha?.name || null, alphaCategory: alpha?.category || null,
    publicLabelLooksLikeExchange: alpha?.category === 'exchange',
    verdict, attackerScore: score, flags,
  };
}

// ─── STAGE 7: 5-AXIS PERPETRATOR-VS-VICTIM DISTINCTION ─────────────────────
async function victimDistinction(addr: string, suspectSet: Set<string>): Promise<{
  walletAgeDays: number; firstTxTs: string | null;
  hasCode: boolean;
  preCaseTxCount: number;
  perpetratorScore: number; victimScore: number;
  verdict: 'CONFIRMED_PERPETRATOR' | 'DOWNSTREAM_MULE' | 'POSSIBLE_CO_VICTIM' | 'NEEDS_REVIEW';
  signals: { pro: string[]; vic: string[] };
}> {
  // First-tx
  const firstResult = await alchemy('alchemy_getAssetTransfers', [{
    fromBlock: '0x0', toBlock: 'latest', toAddress: addr,
    category: ['external', 'erc20', 'internal'], maxCount: '0x1', order: 'asc', withMetadata: true,
  }]);
  const firstTs = firstResult?.transfers?.[0]?.metadata?.blockTimestamp || null;
  const ageDays = firstTs ? Math.floor((Date.now() - new Date(firstTs).getTime()) / 86_400_000) : -1;
  const code = await getCode(addr);
  const hasCode = !!code && code !== '0x';
  await sleep(RATE_LIMIT_MS);

  // Pre-case outbound
  const out = await getTransfersFor(addr, 'from', 200);
  const CASE_BOUNDARY = new Date(WINDOW_START);
  let preCount = 0;
  for (const t of out) {
    const ts = t?.metadata?.blockTimestamp;
    if (ts && new Date(ts) < CASE_BOUNDARY) preCount++;
  }

  const pro: string[] = [], vic: string[] = [];
  let pScore = 0, vScore = 0;

  if (ageDays < 0) {}
  else if (ageDays < 30) { pro.push(`V2: Wallet only ${ageDays}d old — fresh burner near dump window`); pScore += 30; }
  else if (ageDays < 365) { pro.push(`V2: Wallet ${ageDays}d old — within prep window`); pScore += 10; }
  else { vic.push(`V2: Wallet ${ageDays}d old — long pre-existing history`); vScore += 15; }

  if (preCount > 50) { vic.push(`V2: ${preCount} pre-case outbound txs — extensive normal use`); vScore += 15; }
  else if (preCount === 0) { pro.push('V2: ZERO pre-case outbound — no legitimate use history'); pScore += 20; }

  if (hasCode) { vic.push('V4: Has deployed code — could be hijacked smart wallet OR attacker contract (review)'); vScore += 15; }
  else { pro.push('V4: Plain EOA, no code (no hijacked-SAFE indicator)'); pScore += 10; }

  // Sells to pool (perpetrator pattern in dump context)
  pro.push('V1: Sold large RAVE volume to liquidity pool — direct dump perpetrator action'); pScore += 50;

  let verdict: any;
  if (pScore - vScore >= 60) verdict = 'CONFIRMED_PERPETRATOR';
  else if (pScore - vScore >= 30) verdict = 'DOWNSTREAM_MULE';
  else if (vScore > pScore) verdict = 'POSSIBLE_CO_VICTIM';
  else verdict = 'NEEDS_REVIEW';

  return { walletAgeDays: ageDays, firstTxTs: firstTs, hasCode, preCaseTxCount: preCount, perpetratorScore: pScore, victimScore: vScore, verdict, signals: { pro, vic } };
}

// ─── STAGE 8: DEV ↔ DUMPER CROSS-REFERENCE ─────────────────────────────────
async function devDumperCrossRef(devs: string[], dumpers: string[]): Promise<{
  directOverlap: string[];
  fundingLinks: { dumper: string; dev: string; viaTxHash: string; direction: string }[];
}> {
  const devSet = new Set(devs.map(d => d.toLowerCase()));
  const directOverlap = dumpers.filter(d => devSet.has(d.toLowerCase()));
  const links: any[] = [];

  for (const d of dumpers) {
    const inbound = await getTransfersFor(d, 'to', 100);
    for (const t of inbound) {
      const f = (t.from || '').toLowerCase();
      if (devSet.has(f)) {
        links.push({ dumper: d, dev: f, viaTxHash: t.hash, direction: 'dev→dumper' });
      }
    }
    const outbound = await getTransfersFor(d, 'from', 100);
    for (const t of outbound) {
      const r = (t.to || '').toLowerCase();
      if (devSet.has(r)) {
        links.push({ dumper: d, dev: r, viaTxHash: t.hash, direction: 'dumper→dev' });
      }
    }
    await sleep(RATE_LIMIT_MS);
  }

  return { directOverlap, fundingLinks: links };
}

// ─── HTML BUILDER ──────────────────────────────────────────────────────────
function buildHtml(report: any): string {
  const verdictColor = (v: string) =>
    v === 'CONFIRMED_PERPETRATOR' || v === 'CONFIRMED_ATTACKER' ? '#4ade80' :
    v === 'DOWNSTREAM_MULE' || v === 'LIKELY_ATTACKER' ? '#88ff88' :
    v === 'POSSIBLE_CO_VICTIM' ? '#ff4444' :
    v === 'POSSIBLE_EXCHANGE' ? '#ff8800' :
    v === 'CONFIRMED_EXCHANGE' ? '#ff2222' : '#ffcc00';

  const dumperRows = report.dumpers.map((d: any, i: number) => {
    const v = d.verification, vd = d.victimDistinction, act = d.activity;
    const c = verdictColor(vd?.verdict || 'NEEDS_REVIEW');
    const v2c = verdictColor(v?.verdict || 'NEEDS_REVIEW');
    const flags = [...(v?.flags || []), ...(vd?.signals?.pro || []), ...(vd?.signals?.vic || [])]
      .map((f: string) => `<div style="padding:3px 8px;margin:2px 0;background:#0a0a0a;border-left:2px solid ${c};font-size:11px;color:#ccc;">${f}</div>`).join('');
    const kycRows = (d.backTrace?.kycChokepoints || []).map((k: any) =>
      `<tr><td style="padding:4px;color:#d4a017;font-size:11px;">${k.exchange}</td><td style="padding:4px;color:#888;font-size:11px;">hop ${k.hopLevel}</td><td style="padding:4px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${k.txHash}" style="color:#4488ff;">${k.txHash.slice(0, 14)}...</a></td></tr>`).join('');

    return `<div style="background:#111;border-left:4px solid ${c};padding:14px;margin:14px 0;border-radius:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
        <div><span style="color:#666;font-size:12px;">#${i + 1}</span> <span style="font-family:monospace;font-size:13px;color:#fff;font-weight:bold;">${d.address}</span></div>
        <div>
          <span style="background:${v2c}22;color:${v2c};padding:4px 10px;border-radius:10px;font-size:11px;font-weight:bold;">${v?.verdict?.replace(/_/g, ' ')}</span>
          <span style="background:${c}22;color:${c};padding:4px 10px;border-radius:10px;font-size:11px;font-weight:bold;margin-left:4px;">${vd?.verdict?.replace(/_/g, ' ')}</span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:6px;margin:10px 0;font-size:11px;">
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">Tokens dumped:</span><br><b style="color:#ff4444;">${d.tokensSold.toLocaleString(undefined, {maximumFractionDigits: 0})}</b> RAVE</div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">Sells:</span><br><b style="color:#fff;">${d.txs} txs</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">Wallet age:</span><br><b style="color:#fff;">${vd?.walletAgeDays >= 0 ? vd.walletAgeDays + 'd' : '?'}</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">Unique senders:</span><br><b style="color:#fff;">${v?.uniqueSenders ?? '?'}</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">USD IN (72h):</span><br><b style="color:#4ade80;">${fmtUsd(act?.totalInUsd || 0)}</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">USD OUT (72h):</span><br><b style="color:#ff8800;">${fmtUsd(act?.totalOutUsd || 0)}</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">KYC chokepoints:</span><br><b style="color:#d4a017;">${d.backTrace?.kycChokepoints?.length || 0}</b></div>
        <div style="background:#0a0a0a;padding:7px;border-radius:4px;"><span style="color:#888;">Risk tier:</span><br><b style="color:${verdictColor(d.backTrace?.riskAssessment || 'UNKNOWN')};">${d.backTrace?.riskAssessment || '?'}</b></div>
      </div>
      ${kycRows ? `<details style="margin:6px 0;"><summary style="color:#d4a017;cursor:pointer;font-size:12px;">🔑 KYC chokepoints (${d.backTrace?.kycChokepoints?.length})</summary><table style="width:100%;background:#0a0a0a;margin-top:6px;">${kycRows}</table></details>` : ''}
      <details style="margin:6px 0;"><summary style="color:#888;cursor:pointer;font-size:12px;">All forensic flags</summary>${flags}</details>
    </div>`;
  }).join('');

  const devRows = report.devCohort.earliestHolders.map((h: any, i: number) =>
    `<tr><td style="padding:6px;color:#666;">#${i + 1}</td><td style="padding:6px;font-family:monospace;font-size:11px;color:${report.crossRef.directOverlap.includes(h.address) ? '#ff4444' : '#fff'};">${h.address}${report.crossRef.directOverlap.includes(h.address) ? ' 🚨' : ''}</td><td style="padding:6px;text-align:right;color:#4ade80;">${h.tokensReceived.toLocaleString(undefined, {maximumFractionDigits: 0})} RAVE</td><td style="padding:6px;color:#888;font-size:11px;">${h.firstReceiveTs?.slice(0, 16).replace('T', ' ')}</td><td style="padding:6px;color:${h.isContract ? '#ff8800' : '#4ade80'};">${h.isContract ? 'contract' : 'EOA'}</td></tr>`).join('');

  const linkRows = report.crossRef.fundingLinks.map((l: any) =>
    `<tr><td style="padding:6px;font-family:monospace;font-size:11px;color:#fff;">${l.dumper}</td><td style="padding:6px;color:#888;">${l.direction}</td><td style="padding:6px;font-family:monospace;font-size:11px;color:#ff4444;">${l.dev}</td><td style="padding:6px;font-family:monospace;font-size:11px;"><a href="https://etherscan.io/tx/${l.viaTxHash}" style="color:#4488ff;">${l.viaTxHash.slice(0, 14)}...</a></td></tr>`).join('');

  const poolRows = report.dumpDetection.pools.map((p: any) =>
    `<tr><td style="padding:6px;font-family:monospace;font-size:11px;color:#fff;">${p.address}</td><td style="padding:6px;text-align:right;color:#4ade80;">${p.tokensReceived.toLocaleString(undefined, {maximumFractionDigits: 0})}</td><td style="padding:6px;text-align:right;color:#888;">${p.txs}</td><td style="padding:6px;color:#d4a017;">${p.label || '(unlabeled pool)'}</td></tr>`).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>RaveDAO Dump Forensic Analysis — Case ${CASE_ID}</title><style>
body{background:#0a0a0a;color:#fff;font-family:'Segoe UI',Arial,sans-serif;padding:20px;max-width:1500px;margin:0 auto;line-height:1.6;}
table{border-collapse:collapse;width:100%;}
::-webkit-scrollbar{width:8px;}::-webkit-scrollbar-track{background:#111;}::-webkit-scrollbar-thumb{background:#333;border-radius:4px;}
</style></head><body>

<div style="text-align:center;border-bottom:2px solid #d4a017;padding-bottom:20px;margin-bottom:30px;">
  <div style="font-size:11px;color:#d4a017;letter-spacing:4px;">ALPHA UNLIMITED TECHNOLOGIES — PROPRIETARY AND CONFIDENTIAL</div>
  <h1 style="margin:10px 0;font-size:28px;">RaveDAO Dump Forensic Analysis</h1>
  <div style="color:#888;font-size:14px;">Case ID: <b style="color:#ff4444;">${CASE_ID}</b> | Token: <b style="color:#fff;">${TOKEN_NAME} (${TOKEN_SYMBOL})</b></div>
  <div style="color:#666;font-size:12px;margin-top:6px;font-family:monospace;">${TOKEN}</div>
  <div style="color:#666;font-size:11px;margin-top:8px;">Window: last ${WINDOW_HOURS}h | Generated: ${new Date().toISOString()}</div>
  <div style="color:#666;font-size:10px;margin-top:6px;font-style:italic;">${proprietaryHeader('RaveDAO Dump Analysis')}</div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:24px;">
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff4444;"><div style="font-size:28px;color:#ff4444;font-weight:bold;">${report.dumpers.length}</div><div style="color:#888;font-size:12px;">Top Dumpers</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #ff8800;"><div style="font-size:28px;color:#ff8800;font-weight:bold;">${report.dumpDetection.totalDumped.toLocaleString(undefined, {maximumFractionDigits: 0})}</div><div style="color:#888;font-size:12px;">RAVE dumped (top ${report.dumpers.length})</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #d4a017;"><div style="font-size:28px;color:#d4a017;font-weight:bold;">${report.dumpDetection.totalTxsInWindow}</div><div style="color:#888;font-size:12px;">Total RAVE txs (${WINDOW_HOURS}h)</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid #4ade80;"><div style="font-size:28px;color:#4ade80;font-weight:bold;">${report.devCohort.earliestHolders.length}</div><div style="color:#888;font-size:12px;">Dev / early holders</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid ${report.crossRef.fundingLinks.length > 0 ? '#ff4444' : '#4ade80'};"><div style="font-size:28px;color:${report.crossRef.fundingLinks.length > 0 ? '#ff4444' : '#4ade80'};font-weight:bold;">${report.crossRef.fundingLinks.length}</div><div style="color:#888;font-size:12px;">Dev↔Dumper funding links</div></div>
  <div style="background:#111;padding:16px;border-radius:8px;text-align:center;border:1px solid ${report.crossRef.directOverlap.length > 0 ? '#ff4444' : '#4ade80'};"><div style="font-size:28px;color:${report.crossRef.directOverlap.length > 0 ? '#ff4444' : '#4ade80'};font-weight:bold;">${report.crossRef.directOverlap.length}</div><div style="color:#888;font-size:12px;">Devs that DUMPED directly</div></div>
</div>

${report.crossRef.directOverlap.length > 0 || report.crossRef.fundingLinks.length > 0 ? `
<div style="background:#1a0000;border:2px solid #ff4444;padding:18px;border-radius:8px;margin-bottom:24px;">
  <h2 style="color:#ff4444;margin-top:0;">🚨 COLLUSION DETECTED — Dev Wallets Connected to Dump Wallets</h2>
  ${report.crossRef.directOverlap.length > 0 ? `<p style="color:#fff;"><b>${report.crossRef.directOverlap.length} dev/early-holder wallet(s) directly appear in the top dumper list:</b></p><ul style="color:#ff8888;">${report.crossRef.directOverlap.map((a: string) => `<li style="font-family:monospace;">${a}</li>`).join('')}</ul>` : ''}
  ${report.crossRef.fundingLinks.length > 0 ? `<p style="color:#fff;margin-top:12px;"><b>${report.crossRef.fundingLinks.length} funding-flow link(s) between dev cohort and dump cohort:</b></p>
  <table style="background:#000;border-radius:6px;"><tr style="background:#1a1a1a;"><th style="padding:8px;color:#ff4444;text-align:left;">DUMPER</th><th style="padding:8px;color:#ff4444;">DIRECTION</th><th style="padding:8px;color:#ff4444;text-align:left;">DEV WALLET</th><th style="padding:8px;color:#ff4444;text-align:left;">TX</th></tr>${linkRows}</table>` : ''}
</div>` : ''}

<h2 style="color:#d4a017;border-bottom:1px solid #d4a017;padding-bottom:8px;">💧 LIQUIDITY POOLS / DEX ROUTERS DETECTED</h2>
<table style="background:#111;border-radius:6px;"><tr style="background:#1a1a1a;"><th style="padding:8px;color:#d4a017;text-align:left;">POOL ADDRESS</th><th style="padding:8px;color:#d4a017;text-align:right;">RAVE RECEIVED</th><th style="padding:8px;color:#d4a017;text-align:right;">TXS</th><th style="padding:8px;color:#d4a017;text-align:left;">LABEL</th></tr>${poolRows}</table>

<h2 style="color:#4ade80;border-bottom:1px solid #4ade80;padding-bottom:8px;margin-top:30px;">👤 DEV / EARLY-HOLDER COHORT (first ${report.devCohort.earliestHolders.length})</h2>
<p style="color:#ccc;font-size:12px;">Token deployer: <span style="font-family:monospace;color:#fff;">${report.devCohort.deployer}</span> | First transfer: ${report.devCohort.deployTimestamp}</p>
<table style="background:#111;border-radius:6px;"><tr style="background:#1a1a1a;"><th style="padding:8px;color:#4ade80;text-align:left;">#</th><th style="padding:8px;color:#4ade80;text-align:left;">ADDRESS</th><th style="padding:8px;color:#4ade80;text-align:right;">RECEIVED</th><th style="padding:8px;color:#4ade80;text-align:left;">FIRST RECEIVE</th><th style="padding:8px;color:#4ade80;text-align:left;">TYPE</th></tr>${devRows}</table>

<h2 style="color:#ff4444;border-bottom:1px solid #ff4444;padding-bottom:8px;margin-top:30px;">🎯 TOP DUMPERS — FULL FORENSIC PROFILE</h2>
<p style="color:#ccc;font-size:12px;">Each dumper has been: (1) back-traced for KYC chokepoints, (2) overlaid for 72h activity, (3) tested via 4-axis attacker verification, (4) tested via 5-axis perpetrator-vs-victim distinction.</p>
${dumperRows}

<div style="margin-top:40px;padding:20px;background:#111;border-radius:8px;border:1px solid #333;color:#888;font-size:11px;">
<strong style="color:#d4a017;">© 2024-2026 Alpha Unlimited Trading Company. All Rights Reserved.</strong><br>
This report is PROPRIETARY AND CONFIDENTIAL. Generated by Alpha Unlimited Forensic Intelligence Engine™ using:
Token Dump Detection Engine™ · Alpha KYC Chokepoint Mapper™ · Alpha Post-Trace Activity Surveillance™ ·
Alpha 4-Axis Attacker Verification Protocol™ · Alpha Perpetrator-vs-Victim Distinction Engine™ ·
Alpha Dev-Dumper Collusion Detector™. Unauthorized use violates US copyright law (Title 17), the DMCA
(17 U.S.C. § 1201), the CFAA (18 U.S.C. § 1030), and the Defend Trade Secrets Act (18 U.S.C. § 1836).
</div>
</body></html>`;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────
async function main() {
  console.log(`\n╔════════════════════════════════════════════════════════════╗`);
  console.log(`║   CASE: ${CASE_ID.padEnd(50)}║`);
  console.log(`║   Token: ${TOKEN_NAME} (${TOKEN_SYMBOL})${' '.repeat(50 - TOKEN_NAME.length - TOKEN_SYMBOL.length - 4)}║`);
  console.log(`║   Window: last ${WINDOW_HOURS} hours${' '.repeat(36)}║`);
  console.log(`╚════════════════════════════════════════════════════════════╝\n`);

  // Stages 1+2
  const dump = await detectDumpAndRankDumpers();

  // Stage 3
  const dev = await identifyDevWallets();

  // Stages 4-7 per dumper
  const dumperSet = new Set(dump.dumpers.map(d => d.address.toLowerCase()));
  const dumperFull: any[] = [];
  for (let i = 0; i < dump.dumpers.length; i++) {
    const d = dump.dumpers[i];
    console.log(`\n[Dumper ${i + 1}/${dump.dumpers.length}] ${d.address}`);
    try {
      const backTrace = await backTraceKycChokepoints(d.address);
      console.log(`  ↳ back-trace: ${backTrace.kycChokepoints.length} KYC chokepoints | risk=${backTrace.riskAssessment}`);
      await sleep(RATE_LIMIT_MS);
      const activity = await activityOverlay(d.address, dumperSet);
      console.log(`  ↳ activity:   IN ${fmtUsd(activity.totalInUsd)} | OUT ${fmtUsd(activity.totalOutUsd)} | large=${activity.largeTxs}`);
      await sleep(RATE_LIMIT_MS);
      const verification = await attackerVerification(d.address, !!d.isContract);
      console.log(`  ↳ verify:     ${verification.verdict} | uniqIn=${verification.uniqueSenders} uniqOut=${verification.uniqueRecipients}`);
      await sleep(RATE_LIMIT_MS);
      const victim = await victimDistinction(d.address, dumperSet);
      console.log(`  ↳ vic-dist:   ${victim.verdict} | P=${victim.perpetratorScore} V=${victim.victimScore} | age=${victim.walletAgeDays}d`);
      dumperFull.push({ ...d, backTrace, activity, verification, victimDistinction: victim });
    } catch (e) {
      console.log(`  ! ERROR: ${(e as Error).message}`);
      dumperFull.push({ ...d });
    }
    await sleep(RATE_LIMIT_MS);
  }

  // Stage 8: cross-reference
  console.log(`\n[CrossRef] Stage 8: dev↔dumper collusion check`);
  const crossRef = await devDumperCrossRef(dev.earliestHolders.map(h => h.address), dump.dumpers.map(d => d.address));
  console.log(`[CrossRef] direct overlap: ${crossRef.directOverlap.length} | funding links: ${crossRef.fundingLinks.length}`);

  const report = {
    proprietaryNotice: proprietaryHeader('RaveDAO Dump Analysis'),
    caseId: CASE_ID,
    token: { address: TOKEN, name: TOKEN_NAME, symbol: TOKEN_SYMBOL, decimals: TOKEN_DECIMALS },
    windowHours: WINDOW_HOURS,
    generatedAt: new Date().toISOString(),
    dumpDetection: dump,
    devCohort: dev,
    dumpers: dumperFull,
    crossRef,
  };

  const outJson = path.resolve('contracts/atc/ravedao_dump_analysis.json');
  const outHtml = path.resolve('contracts/atc/ravedao_dump_analysis.html');
  fs.writeFileSync(outJson, JSON.stringify(report, null, 2));
  fs.writeFileSync(outHtml, buildHtml(report));
  try { const { autoEmitFlowDiagram } = await import('../../private/forensics/autoEmitFlowDiagram.js'); await autoEmitFlowDiagram(outJson, { title: 'RAVEDAO_DUMP — Dump Analysis', caseId: 'RAVEDAO_DUMP', chain: 'ethereum', direction: 'forward' }); } catch (e: any) { console.log(`  ⚠️ Flow diagram skipped: ${e?.message || e}`); }
  console.log(`\n✅ JSON: ${outJson}`);
  console.log(`✅ HTML: ${outHtml}`);

  console.log(`\n=== RAVEDAO_DUMP — FINAL SUMMARY ===`);
  console.log(`Top dumpers analyzed:        ${dumperFull.length}`);
  console.log(`Total RAVE dumped (top ${dumperFull.length}): ${dump.totalDumped.toLocaleString(undefined, {maximumFractionDigits: 0})}`);
  console.log(`Liquidity pools detected:    ${dump.pools.length}`);
  console.log(`Dev cohort size:             ${dev.earliestHolders.length}`);
  console.log(`Direct dev→dumper overlap:   ${crossRef.directOverlap.length}`);
  console.log(`Dev↔Dumper funding links:    ${crossRef.fundingLinks.length}`);
  const verdicts = new Map<string, number>();
  for (const d of dumperFull) {
    const v = d.victimDistinction?.verdict || 'NEEDS_REVIEW';
    verdicts.set(v, (verdicts.get(v) || 0) + 1);
  }
  console.log(`\nVerdict distribution:`);
  for (const [v, n] of Array.from(verdicts.entries()).sort((a, b) => b[1] - a[1])) console.log(`  ${v.padEnd(28)} ${n}`);
}

main().catch(e => { console.error(e); process.exit(1); });
