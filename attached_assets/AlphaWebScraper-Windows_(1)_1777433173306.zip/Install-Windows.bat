@echo off
REM ============================================================
REM  Alpha Web Scraper(TM) - Windows Installer
REM  Installs to: %LOCALAPPDATA%\AlphaWebScraper
REM  Creates: Start Menu shortcut + Desktop shortcut
REM  Includes: Uninstall.bat
REM ============================================================
setlocal EnableExtensions EnableDelayedExpansion
title Alpha Web Scraper - Installer

set "HERE=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\AlphaWebScraper"
set "START_MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
set "SHORTCUT=%START_MENU%\Alpha Web Scraper.lnk"
set "DESKTOP_SHORTCUT=%USERPROFILE%\Desktop\Alpha Web Scraper.lnk"

echo.
echo ============================================================
echo   Alpha Web Scraper - Windows Installer
echo ============================================================
echo.
echo Install location:  %INSTALL_DIR%
echo Start Menu entry:  Alpha Web Scraper
echo Desktop shortcut:  Yes
echo.
choice /C YN /M "Continue"
if errorlevel 2 (
  echo Cancelled.
  pause
  exit /b 0
)

REM --- Verify required source files exist next to installer ---
if not exist "%HERE%AlphaWebScraper-Standalone.html" (
  echo [ERROR] AlphaWebScraper-Standalone.html not found beside this installer.
  pause
  exit /b 1
)
if not exist "%HERE%AlphaWebScraper-Windows.bat" (
  echo [ERROR] AlphaWebScraper-Windows.bat not found beside this installer.
  pause
  exit /b 1
)

echo.
echo [1/4] Creating install directory...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" 2>nul
if errorlevel 1 (
  echo [ERROR] Could not create %INSTALL_DIR%
  pause
  exit /b 1
)

echo [2/4] Copying files...
copy /Y "%HERE%AlphaWebScraper-Standalone.html" "%INSTALL_DIR%\" >nul || goto :copyfail
copy /Y "%HERE%AlphaWebScraper-Windows.bat"     "%INSTALL_DIR%\" >nul || goto :copyfail
if exist "%HERE%README-Windows.txt" copy /Y "%HERE%README-Windows.txt" "%INSTALL_DIR%\" >nul

REM Drop an Uninstall.bat into the install directory. To survive deleting
REM its own parent dir, it copies itself to %TEMP% and re-runs from there.
> "%INSTALL_DIR%\Uninstall.bat" echo @echo off
>>"%INSTALL_DIR%\Uninstall.bat" echo setlocal
>>"%INSTALL_DIR%\Uninstall.bat" echo title Alpha Web Scraper - Uninstaller
>>"%INSTALL_DIR%\Uninstall.bat" echo if /I not "%%~dp0"=="%%TEMP%%\" (
>>"%INSTALL_DIR%\Uninstall.bat" echo   copy /Y "%%~f0" "%%TEMP%%\AlphaWebScraperUninstall.bat" ^>nul
>>"%INSTALL_DIR%\Uninstall.bat" echo   start "" /B "%%TEMP%%\AlphaWebScraperUninstall.bat"
>>"%INSTALL_DIR%\Uninstall.bat" echo   exit /b 0
>>"%INSTALL_DIR%\Uninstall.bat" echo )
>>"%INSTALL_DIR%\Uninstall.bat" echo echo Uninstalling Alpha Web Scraper...
>>"%INSTALL_DIR%\Uninstall.bat" echo choice /C YN /M "Remove %INSTALL_DIR% and all shortcuts"
>>"%INSTALL_DIR%\Uninstall.bat" echo if errorlevel 2 exit /b 0
>>"%INSTALL_DIR%\Uninstall.bat" echo del /Q "%SHORTCUT%" 2^>nul
>>"%INSTALL_DIR%\Uninstall.bat" echo del /Q "%DESKTOP_SHORTCUT%" 2^>nul
>>"%INSTALL_DIR%\Uninstall.bat" echo rmdir /S /Q "%INSTALL_DIR%" 2^>nul
>>"%INSTALL_DIR%\Uninstall.bat" echo echo.
>>"%INSTALL_DIR%\Uninstall.bat" echo echo Uninstalled.
>>"%INSTALL_DIR%\Uninstall.bat" echo pause

echo [3/4] Creating Start Menu shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$s = $ws.CreateShortcut('%SHORTCUT%');" ^
  "$s.TargetPath = '%INSTALL_DIR%\AlphaWebScraper-Windows.bat';" ^
  "$s.WorkingDirectory = '%INSTALL_DIR%';" ^
  "$s.IconLocation = '%SystemRoot%\System32\shell32.dll,13';" ^
  "$s.Description = 'Alpha Web Scraper - standalone offline web scraper with built-in SQLite';" ^
  "$s.Save()"

echo [4/4] Creating Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$s = $ws.CreateShortcut('%DESKTOP_SHORTCUT%');" ^
  "$s.TargetPath = '%INSTALL_DIR%\AlphaWebScraper-Windows.bat';" ^
  "$s.WorkingDirectory = '%INSTALL_DIR%';" ^
  "$s.IconLocation = '%SystemRoot%\System32\shell32.dll,13';" ^
  "$s.Description = 'Alpha Web Scraper - standalone offline web scraper with built-in SQLite';" ^
  "$s.Save()"

echo.
echo ============================================================
echo   Installation complete.
echo ============================================================
echo.
echo Installed to:    %INSTALL_DIR%
echo Start Menu:      Alpha Web Scraper
echo Desktop:         Alpha Web Scraper
echo Uninstaller:     %INSTALL_DIR%\Uninstall.bat
echo.
choice /C YN /M "Launch Alpha Web Scraper now"
if errorlevel 2 goto :end
start "" "%INSTALL_DIR%\AlphaWebScraper-Standalone.html"

:end
echo.
pause
exit /b 0

:copyfail
echo [ERROR] Could not copy files into %INSTALL_DIR%
pause
exit /b 1
