================================================================================
  Alpha Web Scraper(TM) - Windows Edition
  PRIVATE / PERSONAL USE ONLY - NOT FOR PUBLIC DISTRIBUTION
================================================================================

CONTENTS
--------
  AlphaWebScraper-Standalone.html    The scraper (open in any browser)
  AlphaWebScraper-Windows.bat        Double-click launcher
  README-Windows.txt                 This file

REQUIREMENTS
------------
  Windows 7, 8, 10, or 11.
  Any modern browser (Edge, Chrome, Firefox, Brave, Opera).

INSTALL
-------
  1. Extract this entire ZIP to a folder of your choice
     (e.g. C:\Tools\AlphaWebScraper or your Desktop).
     IMPORTANT: keep all files in the same folder.

  2. If Windows shows "Windows protected your PC" (SmartScreen) when you
     double-click the .bat file:
       - Click "More info"
       - Click "Run anyway"
     This happens because the file was downloaded from the internet.

  3. Optional: right-click AlphaWebScraper-Windows.bat -> Properties ->
     check "Unblock" -> OK.   (One-time fix to silence the warning forever.)

LAUNCH
------
  Double-click AlphaWebScraper-Windows.bat
  -> Opens the scraper in your default browser.

  OR drag AlphaWebScraper-Standalone.html into any browser window.

USING WITH TOR BROWSER (the "plug-in" mode)
-------------------------------------------
  1. Install Tor Browser from https://www.torproject.org/
  2. Launch Tor Browser.
  3. Drag AlphaWebScraper-Standalone.html into a Tor Browser tab,
     or open file:///C:/path/to/AlphaWebScraper-Standalone.html in the URL bar.
  4. Click the "Tor Mode" toggle in the top-right header.
  5. Scrape clearnet OR .onion URLs - direct fetch routes through Tor.

USING WITH A VPN
----------------
  Connect your VPN (NordVPN, ExpressVPN, Mullvad, ProtonVPN, etc.) at the
  Windows level, then launch normally. The scraper uses whatever network
  path your browser uses - nothing extra to configure.

CUSTOM PROXY
------------
  In the scraper UI, "Network Strategy & Proxy" card has a "Custom Proxy URL"
  field. Use the {URL} placeholder (e.g. https://my-proxy.example/?u={URL})
  to point at your own CORS-anywhere instance, corporate mirror, or an
  HTTP-to-SOCKS bridge (privoxy / polipo) for SOCKS-only networks.

OFFLINE USE
-----------
  The HTML file contains everything (UI + SQLite engine). It runs without
  any internet connection at all - useful for analyzing previously-saved
  databases, querying with SQL, or pasting HTML manually.

SAVING YOUR WORK
----------------
  - Auto-saves to browser IndexedDB (disabled in Tor Mode).
  - Manual export: in the Export tab, click "Download .sqlite" for a
    standard SQLite database file you can open in DB Browser for SQLite,
    DBeaver, or any other SQLite tool.

PRIVACY
-------
  Single-file, no installation, no accounts, no telemetry. View source on
  the HTML file to verify - everything is in plain JavaScript.

LICENSE
-------
  Alpha Web Scraper(TM) - Proprietary. PRIVATE USE ONLY.
  Bundled sql.js is MIT-licensed (Ophir LOJKINE).
