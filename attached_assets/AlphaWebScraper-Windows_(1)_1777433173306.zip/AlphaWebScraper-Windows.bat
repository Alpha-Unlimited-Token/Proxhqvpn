@echo off
REM ============================================================
REM  Alpha Web Scraper - Windows Launcher
REM  Double-click this file to open the scraper in your default
REM  browser. Works on Windows 7, 8, 10, 11.
REM
REM  For Tor Browser users:
REM    1. Install Tor Browser (https://www.torproject.org/)
REM    2. Run this file once to extract the HTML beside it.
REM    3. Drag AlphaWebScraper-Standalone.html into a Tor Browser
REM       tab and toggle Tor Mode in the header.
REM ============================================================
setlocal
set "HERE=%~dp0"
set "APP=%HERE%AlphaWebScraper-Standalone.html"

if not exist "%APP%" (
  echo [ERROR] AlphaWebScraper-Standalone.html not found next to this launcher.
  echo Put both files in the same folder.
  pause
  exit /b 1
)

echo Opening Alpha Web Scraper in your default browser...
start "" "%APP%"
exit /b 0
