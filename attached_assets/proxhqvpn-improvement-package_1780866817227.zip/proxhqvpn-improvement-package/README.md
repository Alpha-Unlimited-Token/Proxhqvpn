# ProxhqVPN Critical Improvement Code Package

This ZIP contains drop-in code and scripts to harden ProxhqVPN based on the uploaded prompt and code dump.

## What this package fixes

- Adds standalone local authentication with Argon2 password hashing and signed sessions.
- Adds role-based access control for admin/security/operator/viewer routes.
- Replaces permissive CORS with an explicit allowlist.
- Adds CSRF protection for cookie-authenticated mutation requests.
- Adds security headers, request IDs, safer JSON limits, and audit logging.
- Adds encrypted secret storage for WireGuard/private keys and other sensitive values.
- Adds a production/demo data boundary so simulated values are not confused with real security telemetry.
- Adds a safer terminal executor that stays allowlisted and removes unrestricted browser-shell mode.
- Adds a tier/feature entitlement gate for VPN, security, developer/pentest, antivirus, and enterprise features.
- Adds beginner-friendly UX components and dashboard layout.
- Adds install, migration, and verification scripts.
- Adds a Replit-ready upgrade prompt.

## How to use

1. Copy `patches/standalone/src/**` into your standalone source tree.
2. Wire the middleware into `standalone/src/server.ts` using `docs/WIRING_GUIDE.md`.
3. Copy `patches/frontend/src/**` into your React frontend.
4. Run `patches/scripts/install-security-deps.sh`.
5. Run `patches/scripts/apply-standalone-security-patch.sh` from your project root.
6. Set environment variables from `.env.example`.
7. Run the verification checklist in `docs/VERIFY.md`.

This package intentionally keeps offensive/counterattack payload material out of the production patch. It replaces that category with defensive OSINT, honeypot reporting, evidence export, abuse-contact generation, and authorized testing gates.
