import type { Request, Response, NextFunction } from "express";

export type Tier = "vpn" | "security" | "devpro" | "av" | "enterprise";

const FEATURES: Record<Tier, string[]> = {
  vpn: ["vpn", "wireguard", "kill-switch", "leak-test", "split-tunnel", "smart-dns"],
  security: ["vpn", "wireguard", "kill-switch", "leak-test", "split-tunnel", "smart-dns", "ghost-trap", "silkweb", "firewall", "dns-sinkhole", "siem", "canary", "threat-intel"],
  devpro: ["vpn", "wireguard", "kill-switch", "leak-test", "split-tunnel", "smart-dns", "ghost-trap", "silkweb", "firewall", "dns-sinkhole", "siem", "canary", "threat-intel", "jwt", "sast", "http-probe", "dir-fuzzer", "subdomain", "sql-readonly", "terminal-safe"],
  av: ["vpn", "wireguard", "kill-switch", "leak-test", "split-tunnel", "smart-dns", "ghost-trap", "silkweb", "firewall", "dns-sinkhole", "siem", "canary", "threat-intel", "proxhqav", "yara", "ioc", "secure-shredder"],
  enterprise: ["*"],
};

export function hasFeature(tier: Tier, feature: string): boolean {
  const list = FEATURES[tier] || [];
  return list.includes("*") || list.includes(feature);
}

export function requireFeature(feature: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const tier = ((req as any).user?.tier || process.env.PROXHQVPN_DEFAULT_TIER || "enterprise") as Tier;
    if (hasFeature(tier, feature)) return next();
    res.status(402).json({ error: `Feature '${feature}' requires a higher plan`, requiredFeature: feature });
  };
}
