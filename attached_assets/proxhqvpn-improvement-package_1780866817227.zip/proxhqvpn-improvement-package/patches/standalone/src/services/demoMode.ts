import crypto from "crypto";
export type DataSource = "real" | "demo" | "simulated";

export function isDemoMode(): boolean {
  return String(process.env.PROXHQVPN_DEMO_MODE || "false").toLowerCase() === "true";
}

export function requireRealMode(feature: string) {
  if (isDemoMode()) {
    const err: any = new Error(`${feature} is disabled while PROXHQVPN_DEMO_MODE=true`);
    err.status = 409;
    throw err;
  }
}

export function labelTelemetry<T extends object>(data: T, source: DataSource): T & { dataSource: DataSource; generatedAt: string } {
  return { ...data, dataSource: source, generatedAt: new Date().toISOString() };
}

export function secureRandomInt(min: number, max: number): number {
  if (max < min) throw new Error("Invalid range");
  return crypto.randomInt(min, max + 1);
}
