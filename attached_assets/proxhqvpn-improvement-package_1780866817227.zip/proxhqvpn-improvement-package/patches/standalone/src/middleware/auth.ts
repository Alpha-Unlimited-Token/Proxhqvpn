import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import argon2 from "argon2";
import { z } from "zod";
import { queryOne, run } from "../db.js";

export type Role = "admin" | "security" | "operator" | "viewer";
const COOKIE = "proxhq_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 12;

function secret(): Buffer {
  const s = process.env.PROXHQVPN_SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("PROXHQVPN_SESSION_SECRET must be set to 32+ chars");
  return Buffer.from(s);
}

function sign(data: string) {
  return crypto.createHmac("sha256", secret()).update(data).digest("base64url");
}

function createToken(payload: Record<string, unknown>): string {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

function verifyToken(token?: string): any | null {
  if (!token || !token.includes(".")) return null;
  const [body, sig] = token.split(".");
  const expected = sign(body);
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  if (!payload.exp || Date.now() > payload.exp) return null;
  return payload;
}

export function initAuthSchema() {
  run(`CREATE TABLE IF NOT EXISTS local_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin',
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`);
  run(`CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT,
    user_id INTEGER,
    action TEXT NOT NULL,
    resource TEXT,
    ip TEXT,
    user_agent TEXT,
    metadata TEXT,
    created_at TEXT NOT NULL
  )`);
}

export async function bootstrapAdmin() {
  const existing = queryOne("SELECT id FROM local_users LIMIT 1");
  if (existing) return;
  const email = process.env.PROXHQVPN_BOOTSTRAP_ADMIN_EMAIL;
  const password = process.env.PROXHQVPN_BOOTSTRAP_ADMIN_PASSWORD;
  if (!email || !password || password.length < 16) return;
  const hash = await argon2.hash(password, { type: argon2.argon2id });
  const now = new Date().toISOString();
  run("INSERT INTO local_users (email,password_hash,role,created_at,updated_at) VALUES (?,?,?,?,?)", [email, hash, "admin", now, now]);
}

export function currentUser(req: Request, _res: Response, next: NextFunction) {
  const cookie = req.headers.cookie || "";
  const token = cookie.split(";").map(v => v.trim()).find(v => v.startsWith(`${COOKIE}=`))?.split("=")[1];
  const payload = verifyToken(token);
  if (payload) (req as any).user = payload;
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if ((req as any).user?.sub) return next();
  res.status(401).json({ error: "Authentication required" });
}

export function requireRole(...roles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const role = (req as any).user?.role as Role | undefined;
    if (role && (roles.includes(role) || role === "admin")) return next();
    res.status(403).json({ error: "Insufficient role" });
  };
}

export function authRoutes(app: any, loginLimiter: any) {
  app.post("/api/auth/login", loginLimiter, async (req: Request, res: Response) => {
    const body = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(req.body);
    const user: any = queryOne("SELECT * FROM local_users WHERE email=?", [body.email.toLowerCase()]);
    if (!user) return res.status(401).json({ error: "Invalid login" });
    if (user.locked_until && Date.now() < new Date(user.locked_until).getTime()) {
      return res.status(429).json({ error: "Account temporarily locked" });
    }
    const ok = await argon2.verify(user.password_hash, body.password);
    if (!ok) {
      const failed = Number(user.failed_logins || 0) + 1;
      const lock = failed >= 5 ? new Date(Date.now() + 60 * 60 * 1000).toISOString() : null;
      run("UPDATE local_users SET failed_logins=?, locked_until=?, updated_at=? WHERE id=?", [failed, lock, new Date().toISOString(), user.id]);
      return res.status(401).json({ error: "Invalid login" });
    }
    run("UPDATE local_users SET failed_logins=0, locked_until=NULL, updated_at=? WHERE id=?", [new Date().toISOString(), user.id]);
    const csrf = crypto.randomBytes(24).toString("base64url");
    const token = createToken({ sub: user.id, email: user.email, role: user.role, csrf, exp: Date.now() + SESSION_TTL_MS });
    res.cookie(COOKIE, token, { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: SESSION_TTL_MS });
    res.json({ ok: true, user: { id: user.id, email: user.email, role: user.role }, csrf });
  });

  app.post("/api/auth/logout", (_req: Request, res: Response) => {
    res.clearCookie(COOKIE);
    res.json({ ok: true });
  });

  app.get("/api/auth/me", requireAuth, (req: Request, res: Response) => {
    const u = (req as any).user;
    res.json({ user: { id: u.sub, email: u.email, role: u.role }, csrf: u.csrf });
  });
}

export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const u = (req as any).user;
  if (!u) return next();
  const header = req.header("x-csrf-token");
  if (header && header === u.csrf) return next();
  res.status(403).json({ error: "CSRF token missing or invalid" });
}

export function audit(action: string, resource?: string) {
  return (req: Request, _res: Response, next: NextFunction) => {
    try {
      const u = (req as any).user;
      run("INSERT INTO audit_log (request_id,user_id,action,resource,ip,user_agent,metadata,created_at) VALUES (?,?,?,?,?,?,?,?)", [
        (req as any).requestId || null,
        u?.sub || null,
        action,
        resource || req.path,
        req.ip || req.socket.remoteAddress || null,
        req.header("user-agent") || null,
        JSON.stringify({ method: req.method, path: req.path }),
        new Date().toISOString(),
      ]);
    } catch {}
    next();
  };
}
