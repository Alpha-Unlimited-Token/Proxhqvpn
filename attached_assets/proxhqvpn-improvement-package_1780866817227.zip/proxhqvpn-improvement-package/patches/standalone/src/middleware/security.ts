import type { Request, Response, NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import crypto from "crypto";

function parseOrigins(): string[] {
  return (process.env.PROXHQVPN_ALLOWED_ORIGINS || "http://127.0.0.1:7474,http://localhost:7474")
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);
}

export function requestId(req: Request, res: Response, next: NextFunction) {
  const id = req.header("x-request-id") || crypto.randomUUID();
  (req as any).requestId = id;
  res.setHeader("x-request-id", id);
  next();
}

export function hardenedHelmet() {
  return helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        baseUri: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        imgSrc: ["'self'", "data:", "blob:"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'", "data:"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        upgradeInsecureRequests: process.env.NODE_ENV === "production" ? [] : null as any,
      },
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: "no-referrer" },
    hsts: process.env.NODE_ENV === "production" ? { maxAge: 15552000, includeSubDomains: true } : false,
  });
}

export function strictCors() {
  const allowed = new Set(parseOrigins());
  return cors({
    credentials: true,
    origin(origin, cb) {
      if (!origin) return cb(null, true); // local desktop/native clients
      if (allowed.has(origin)) return cb(null, true);
      return cb(new Error(`CORS blocked origin: ${origin}`));
    },
  });
}

export function requireLocalhostWhenStandalone(req: Request, res: Response, next: NextFunction) {
  const bindHost = process.env.PROXHQVPN_BIND_HOST || "127.0.0.1";
  if (bindHost !== "127.0.0.1" && bindHost !== "localhost") return next();
  const ip = req.ip || req.socket.remoteAddress || "";
  const ok = ip.includes("127.0.0.1") || ip === "::1" || ip.includes("::ffff:127.0.0.1");
  if (!ok) return res.status(403).json({ error: "Standalone server is locked to localhost." });
  next();
}

export function noStoreApi(req: Request, res: Response, next: NextFunction) {
  if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
  next();
}

export function jsonErrorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  const status = err?.status || err?.statusCode || 500;
  const safeMessage = status >= 500 ? "Internal server error" : String(err?.message || "Request failed");
  res.status(status).json({ error: safeMessage });
}
