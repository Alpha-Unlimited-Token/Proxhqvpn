import type { Express, Request, Response } from "express";
import { z } from "zod";
import { requireAuth, requireRole, audit } from "../middleware/auth.js";
import { requireFeature } from "../services/entitlements.js";

function sanitizeHost(input: string): string {
  const u = input.replace(/^https?:\/\//, "").split("/")[0].trim().toLowerCase();
  if (!/^[a-z0-9.-]{1,253}$/.test(u)) throw new Error("Invalid host");
  return u;
}

export function registerDefensiveTools(app: Express) {
  app.post("/api/defense/abuse-report-template", requireAuth, requireRole("admin", "security"), requireFeature("ghost-trap"), audit("defense.abuse_report"), (req: Request, res: Response) => {
    const body = z.object({ attackerIp: z.string().min(3).max(80), endpoint: z.string().max(200).optional(), evidenceSummary: z.string().max(2000).optional() }).parse(req.body);
    res.json({
      subject: `Abuse report for malicious traffic from ${body.attackerIp}`,
      body: [
        "Hello Abuse Desk,",
        "",
        `We observed malicious or unauthorized probing from IP: ${body.attackerIp}`,
        body.endpoint ? `Targeted endpoint: ${body.endpoint}` : null,
        body.evidenceSummary ? `Evidence summary: ${body.evidenceSummary}` : null,
        "",
        "Please investigate this host/account under your acceptable-use policy.",
        "We can provide timestamps, request IDs, and sanitized logs on request.",
        "",
        "Regards,",
        "ProxhqVPN Security Team",
      ].filter(Boolean).join("\n"),
    });
  });

  app.post("/api/defense/authorized-scope-check", requireAuth, requireRole("admin", "security"), requireFeature("http-probe"), audit("defense.scope_check"), (req: Request, res: Response) => {
    const body = z.object({ target: z.string().min(3).max(300), confirmation: z.literal("I_AM_AUTHORIZED_TO_TEST_THIS_TARGET") }).parse(req.body);
    const host = sanitizeHost(body.target);
    res.json({ ok: true, host, allowedActions: ["passive DNS lookup", "TLS certificate inspection", "HTTP header check", "robots.txt fetch"], blockedActions: ["exploit payloads", "credential attacks", "reverse shells", "destructive scans"] });
  });
}
