import type { Express, Request, Response } from "express";
import { requireAuth, requireRole, audit } from "../middleware/auth.js";
import { query } from "../db.js";

export function registerAdminSecurityRoutes(app: Express) {
  app.get("/api/admin/audit-log", requireAuth, requireRole("admin", "security"), audit("audit.read"), (req: Request, res: Response) => {
    const limit = Math.min(Number(req.query.limit || 100), 500);
    const rows = query("SELECT id,request_id,user_id,action,resource,ip,user_agent,metadata,created_at FROM audit_log ORDER BY id DESC LIMIT ?", [limit]);
    res.json({ rows, totalReturned: rows.length });
  });

  app.get("/api/admin/security-posture", requireAuth, requireRole("admin", "security"), (_req: Request, res: Response) => {
    const checks = [
      { id: "session_secret", ok: Boolean(process.env.PROXHQVPN_SESSION_SECRET && process.env.PROXHQVPN_SESSION_SECRET.length >= 32), fix: "Set PROXHQVPN_SESSION_SECRET to a 32+ character random value." },
      { id: "master_key", ok: Boolean(process.env.PROXHQVPN_MASTER_KEY && process.env.PROXHQVPN_MASTER_KEY.length >= 32), fix: "Set PROXHQVPN_MASTER_KEY for private key encryption." },
      { id: "cors_allowlist", ok: !String(process.env.PROXHQVPN_ALLOWED_ORIGINS || "").includes("*"), fix: "Use explicit origins only." },
      { id: "terminal_disabled_by_default", ok: String(process.env.PROXHQVPN_ENABLE_TERMINAL || "false") !== "true", fix: "Keep terminal disabled unless actively administering locally." },
      { id: "offensive_payloads_disabled", ok: String(process.env.PROXHQVPN_ENABLE_OFFENSIVE_PAYLOADS || "false") !== "true", fix: "Do not ship offensive payload generation in production." },
    ];
    res.json({ score: checks.filter(c => c.ok).length, maxScore: checks.length, checks });
  });
}
