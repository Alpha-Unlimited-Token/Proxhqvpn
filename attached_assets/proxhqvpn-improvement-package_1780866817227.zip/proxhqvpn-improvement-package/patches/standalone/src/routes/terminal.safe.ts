import type { Express, Request, Response } from "express";
import { execFile } from "child_process";
import { promisify } from "util";
import { z } from "zod";
import { requireAuth, requireRole, audit } from "../middleware/auth.js";
import { requireFeature } from "../services/entitlements.js";

const execFileAsync = promisify(execFile);

const COMMANDS: Record<string, { bin: string; fixedArgs?: string[]; maxArgs: number }> = {
  pwd: { bin: "pwd", maxArgs: 0 },
  whoami: { bin: "whoami", maxArgs: 0 },
  hostname: { bin: "hostname", maxArgs: 0 },
  date: { bin: "date", maxArgs: 0 },
  uptime: { bin: "uptime", maxArgs: 0 },
  df: { bin: "df", fixedArgs: ["-h"], maxArgs: 0 },
  free: { bin: "free", fixedArgs: ["-m"], maxArgs: 0 },
  wg: { bin: "wg", fixedArgs: ["show"], maxArgs: 0 },
  ip_route: { bin: "ip", fixedArgs: ["route", "show"], maxArgs: 0 },
  ss_listen: { bin: "ss", fixedArgs: ["-lntp"], maxArgs: 0 },
};

export function registerSafeTerminal(app: Express, limiter: any) {
  app.post(
    "/api/terminal/execute-safe",
    requireAuth,
    requireRole("admin", "operator"),
    requireFeature("terminal-safe"),
    limiter,
    audit("terminal.execute.safe"),
    async (req: Request, res: Response) => {
      if (String(process.env.PROXHQVPN_ENABLE_TERMINAL || "false") !== "true") {
        return res.status(403).json({ error: "Terminal is disabled. Set PROXHQVPN_ENABLE_TERMINAL=true to enable." });
      }
      const body = z.object({ command: z.enum(Object.keys(COMMANDS) as [string, ...string[]]), args: z.array(z.string().max(80)).default([]) }).parse(req.body);
      const spec = COMMANDS[body.command];
      if (body.args.length > spec.maxArgs) return res.status(400).json({ error: "Too many arguments for command" });
      const args = [...(spec.fixedArgs || []), ...body.args];
      try {
        const { stdout, stderr } = await execFileAsync(spec.bin, args, { timeout: 5000, windowsHide: true, maxBuffer: 1024 * 128 });
        res.json({ command: body.command, output: stdout || stderr, exitCode: 0 });
      } catch (e: any) {
        res.status(200).json({ command: body.command, output: e.stderr || e.message, exitCode: e.code || 1 });
      }
    }
  );
}
