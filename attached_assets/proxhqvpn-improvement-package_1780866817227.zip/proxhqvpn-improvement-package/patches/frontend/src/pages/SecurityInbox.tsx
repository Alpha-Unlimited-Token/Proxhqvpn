import React from "react";

type Alert = {
  id: string;
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  plainEnglish: string;
  recommendedAction: string;
  when: string;
};

const demoAlerts: Alert[] = [
  { id: "1", severity: "high", title: "Repeated admin-page probing", plainEnglish: "Someone tried common admin URLs like /wp-admin and /.env.", recommendedAction: "Keep Ghost Trap enabled, block the IP, and export the incident report if it continues.", when: "Just now" },
  { id: "2", severity: "medium", title: "DNS Shield blocked tracker domain", plainEnglish: "A connected device tried to contact a known tracker/ad domain.", recommendedAction: "No action needed unless this happens from an unknown device.", when: "12 min ago" },
];

export default function SecurityInbox() {
  return (
    <main className="min-h-screen bg-black text-[#d7ffe8] p-4 md:p-8">
      <section className="max-w-5xl mx-auto space-y-4">
        <h1 className="text-4xl font-bold">Threat Inbox</h1>
        <p className="text-[#d7ffe8]/70">Plain-English security alerts for non-technical users.</p>
        {demoAlerts.map(a => (
          <article key={a.id} className="rounded-2xl border border-[#00ff88]/20 bg-[#020806] p-5">
            <div className="flex justify-between gap-4">
              <h2 className="text-xl font-bold">{a.title}</h2>
              <span className="text-xs uppercase text-[#00ff88]">{a.severity}</span>
            </div>
            <p className="mt-3"><strong>What happened:</strong> {a.plainEnglish}</p>
            <p className="mt-2"><strong>Recommended action:</strong> {a.recommendedAction}</p>
            <p className="mt-3 text-xs text-[#d7ffe8]/50">{a.when}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
