import React from "react";

type Status = "good" | "warning" | "danger" | "off";

type Card = {
  title: string;
  description: string;
  status: Status;
  action: string;
  href: string;
};

const cards: Card[] = [
  { title: "VPN Connection", description: "Connect to WireGuard, rotate exit node, and verify your public IP.", status: "warning", action: "Connect / Verify", href: "/wireguard" },
  { title: "Leak Protection", description: "Run DNS, IPv6, and WebRTC leak checks before browsing.", status: "good", action: "Run Leak Test", href: "/leaks" },
  { title: "Kill Switch", description: "Block traffic automatically if the VPN tunnel drops.", status: "off", action: "Enable Kill Switch", href: "/kill-switch" },
  { title: "Ad + Malware DNS Shield", description: "Block ad, tracker, malware, phishing, and botnet domains.", status: "good", action: "Manage DNS Shield", href: "/dns-sinkhole" },
  { title: "Threat Inbox", description: "Plain-English list of alerts, risk level, and recommended action.", status: "warning", action: "Review Threats", href: "/security-inbox" },
  { title: "Device Setup", description: "Add phones, computers, routers, TVs, and consoles with QR/config files.", status: "good", action: "Add Device", href: "/devices" },
];

const label: Record<Status, string> = { good: "Protected", warning: "Needs review", danger: "Action needed", off: "Off" };

export function BeginnerDashboard() {
  return (
    <main className="min-h-screen bg-black text-[#d7ffe8] p-4 md:p-8">
      <section className="max-w-6xl mx-auto space-y-6">
        <header className="border border-[#00ff88]/30 rounded-2xl p-6 bg-[#001b10]">
          <p className="text-xs tracking-[0.3em] text-[#00ff88]/70">PROXHQVPN SIMPLE MODE</p>
          <h1 className="text-3xl md:text-5xl font-bold mt-2">Your protection dashboard</h1>
          <p className="mt-3 text-[#d7ffe8]/75 max-w-3xl">
            Start here if you are not technical. Each card tells you what matters, why it matters, and the safest next step.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {cards.map(card => (
            <a key={card.title} href={card.href} className="block rounded-2xl border border-[#00ff88]/20 p-5 bg-[#020806] hover:border-[#00ff88]/60 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-xl font-semibold">{card.title}</h2>
                <span className="text-[10px] uppercase tracking-widest border border-[#00ff88]/30 rounded-full px-2 py-1 text-[#00ff88]">{label[card.status]}</span>
              </div>
              <p className="mt-3 text-sm text-[#d7ffe8]/70 leading-relaxed">{card.description}</p>
              <div className="mt-5 text-sm font-bold text-[#00ff88]">{card.action} →</div>
            </a>
          ))}
        </div>
      </section>
    </main>
  );
}
