import React, { useState } from "react";

type Props = {
  title: string;
  risk: "advanced" | "admin" | "authorized-testing";
  children: React.ReactNode;
};

const text = {
  advanced: "This feature changes advanced security settings. Use it only if you understand the impact.",
  admin: "This feature requires administrator access and every action is audit logged.",
  "authorized-testing": "Only use this on systems you own or have written permission to test. Offensive payloads are disabled in production.",
};

export function SafetyGate({ title, risk, children }: Props) {
  const [accepted, setAccepted] = useState(false);
  if (accepted) return <>{children}</>;
  return (
    <section className="rounded-2xl border border-yellow-400/40 bg-yellow-950/20 p-5 text-yellow-50">
      <p className="text-xs uppercase tracking-[0.25em] text-yellow-300">Safety confirmation</p>
      <h2 className="text-2xl font-bold mt-2">{title}</h2>
      <p className="mt-3 text-yellow-100/80">{text[risk]}</p>
      <label className="mt-4 flex gap-3 items-start text-sm">
        <input type="checkbox" className="mt-1" onChange={e => setAccepted(e.target.checked)} />
        <span>I understand and will only use this feature legally and safely.</span>
      </label>
    </section>
  );
}
