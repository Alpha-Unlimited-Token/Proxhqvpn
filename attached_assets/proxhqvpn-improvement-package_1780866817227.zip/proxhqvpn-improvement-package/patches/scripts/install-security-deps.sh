#!/usr/bin/env bash
set -euo pipefail

if command -v pnpm >/dev/null 2>&1; then
  pnpm add argon2 cookie-parser express-rate-limit zod helmet cors pino pino-http
  pnpm add -D @types/cookie-parser
elif command -v npm >/dev/null 2>&1; then
  npm install argon2 cookie-parser express-rate-limit zod helmet cors pino pino-http
  npm install -D @types/cookie-parser
else
  echo "Neither pnpm nor npm found." >&2
  exit 1
fi
