import { initDb, query, run } from "../standalone/src/db.js";
import { encryptSecret } from "../standalone/src/services/secrets.js";

async function main() {
  const dataDir = process.env.PROXHQVPN_DATA || "./data";
  await initDb(dataDir);
  const nodes: any[] = query("SELECT id, private_key FROM nodes");
  let changed = 0;
  for (const n of nodes) {
    if (!n.private_key || String(n.private_key).startsWith("v1:")) continue;
    run("UPDATE nodes SET private_key=? WHERE id=?", [encryptSecret(n.private_key), n.id]);
    changed++;
  }
  console.log(`Encrypted ${changed} node private key(s).`);
}

main().catch(err => { console.error(err); process.exit(1); });
