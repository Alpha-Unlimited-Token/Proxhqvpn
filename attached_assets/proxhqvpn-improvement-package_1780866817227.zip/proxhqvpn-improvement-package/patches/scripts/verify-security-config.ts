const checks = [
  ["PROXHQVPN_SESSION_SECRET", (v?: string) => !!v && v.length >= 32],
  ["PROXHQVPN_MASTER_KEY", (v?: string) => !!v && v.length >= 32],
  ["PROXHQVPN_ALLOWED_ORIGINS", (v?: string) => !!v && !v.includes("*")],
];

let ok = true;
for (const [name, fn] of checks as [string, (v?: string) => boolean][]) {
  const pass = fn(process.env[name]);
  console.log(`${pass ? "PASS" : "FAIL"} ${name}`);
  ok = ok && pass;
}

if (String(process.env.PROXHQVPN_ENABLE_OFFENSIVE_PAYLOADS || "false") === "true") {
  console.log("FAIL PROXHQVPN_ENABLE_OFFENSIVE_PAYLOADS must not be true in production");
  ok = false;
}

process.exit(ok ? 0 : 1);
