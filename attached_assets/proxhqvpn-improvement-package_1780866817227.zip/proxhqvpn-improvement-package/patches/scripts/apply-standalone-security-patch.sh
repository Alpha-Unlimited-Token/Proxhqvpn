#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

mkdir -p "$ROOT/standalone/src/middleware" "$ROOT/standalone/src/services" "$ROOT/standalone/src/routes"
cp -R "$PKG_DIR/patches/standalone/src/middleware/." "$ROOT/standalone/src/middleware/"
cp -R "$PKG_DIR/patches/standalone/src/services/." "$ROOT/standalone/src/services/"
cp -R "$PKG_DIR/patches/standalone/src/routes/." "$ROOT/standalone/src/routes/"

mkdir -p "$ROOT/frontend/src/components" "$ROOT/frontend/src/pages"
cp -R "$PKG_DIR/patches/frontend/src/components/." "$ROOT/frontend/src/components/" || true
cp -R "$PKG_DIR/patches/frontend/src/pages/." "$ROOT/frontend/src/pages/" || true

if [ ! -f "$ROOT/.env" ]; then
  cp "$PKG_DIR/.env.example" "$ROOT/.env.example"
fi

echo "Patch files copied. Now follow docs/WIRING_GUIDE.md to wire server.ts routes and middleware."
