# Replit Prompt — ProxhqVPN Critical Security, Architecture, UX Upgrade

You are upgrading the ProxhqVPN codebase for Alpha Unlimited Technologies LLC.

## Source context

The current platform is React + Vite frontend, Express/Node backend, PostgreSQL/Drizzle cloud mode, SQLite standalone mode, Clerk cloud auth, and standalone ZIP/Electron/mobile distributions. The uploaded audit found the product has strong scope but needs production hardening before launch.

## Your task

Apply every patch in this ZIP and wire it into the existing app without deleting working product features.

## Mandatory security fixes

1. Add standalone local authentication:
   - Use `patches/standalone/src/middleware/auth.ts`.
   - Use Argon2id hashing.
   - Add bootstrap admin from env only on first run.
   - Add signed HTTP-only session cookie.
   - Add account lockout after failed attempts.
   - Add `/api/auth/login`, `/api/auth/logout`, `/api/auth/me`.

2. Add CSRF protection:
   - All POST/PUT/PATCH/DELETE routes must require `x-csrf-token` when cookie-authenticated.

3. Replace permissive CORS:
   - Remove `cors({ origin: true, credentials: true })`.
   - Use explicit `PROXHQVPN_ALLOWED_ORIGINS` only.

4. Add RBAC:
   - `admin`: everything.
   - `security`: security/defense/SIEM/honeypot routes.
   - `operator`: VPN/node/device routes.
   - `viewer`: read-only dashboard.

5. Add entitlement gates:
   - VPN tier: VPN, WireGuard, kill switch, leak tests, split tunnel, smart DNS.
   - Security tier: VPN + Ghost Trap, SilkWeb, firewall, DNS sinkhole, SIEM, canary, threat intel.
   - Dev/Pentest Pro: Security + JWT, SAST, HTTP probe, directory fuzzer, subdomain, SQL read-only, safe terminal.
   - AV tier: Security + ProxhqAV, YARA, IOC, secure shredder.
   - Enterprise: everything.

6. Encrypt secrets:
   - Use `services/secrets.ts`.
   - Encrypt WireGuard private keys and sensitive tokens at rest.
   - Never return raw private keys from general list/detail APIs.
   - Require re-authentication for config export.

7. Replace terminal route:
   - Disable old unrestricted `/api/terminal/execute` or make it admin-only and local-only.
   - Add `/api/terminal/execute-safe` from `routes/terminal.safe.ts`.
   - Use `execFile`, not shell `exec`, and only named allowlisted commands.

8. Separate demo from production:
   - Every route using random/simulated telemetry must return `dataSource: "simulated"`.
   - Add visible Demo Mode badge in frontend when `PROXHQVPN_DEMO_MODE=true`.
   - Production dashboards must not represent simulated alerts as real security events.

9. Remove/gate offensive payload generation:
   - Do not ship reverse shells, keyloggers, credential theft examples, destructive payloads, or exploit automation in production.
   - Replace with defensive reports, authorized-scope checks, passive checks, and evidence export.

10. Add audit logging:
   - Every admin/security/terminal/mutation action must write to `audit_log`.

## UX improvements

1. Add Simple Mode dashboard:
   - Use `BeginnerDashboard.tsx`.
   - Route: `/simple` or `/dashboard/simple`.

2. Add Threat Inbox:
   - Use `SecurityInbox.tsx`.
   - Route: `/security-inbox`.
   - Convert technical alerts to: what happened, risk, recommended action.

3. Add SafetyGate component:
   - Use before advanced firewall, terminal, security research, and destructive settings.

4. Add beginner/expert mode toggle.

## Scripts

Run:

```bash
bash patches/scripts/install-security-deps.sh
bash patches/scripts/apply-standalone-security-patch.sh .
```

Then manually wire `server.ts` using `docs/WIRING_GUIDE.md`.

## Verification

Complete every item in `docs/VERIFY.md`.

## Acceptance criteria

- No private API returns data without auth.
- CORS rejects untrusted origins.
- CSRF blocks mutation requests without token.
- Terminal is disabled by default.
- Private keys are encrypted at rest.
- Raw private keys are masked in normal API responses.
- Demo/simulated data is clearly labeled.
- Beginner dashboard and Threat Inbox compile.
- No production code ships offensive reverse-shell/keylogger/credential-theft payloads.
- TypeScript builds.
- Existing VPN/security features still load.
