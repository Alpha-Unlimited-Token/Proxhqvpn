# Wiring Guide

## 1. Install dependencies

```bash
pnpm add argon2 cookie-parser express-rate-limit zod helmet cors pino pino-http
```

## 2. Patch `standalone/src/server.ts`

Add imports near the top:

```ts
import cookieParser from "cookie-parser";
import { rateLimit } from "express-rate-limit";
import { requestId, hardenedHelmet, strictCors, noStoreApi, jsonErrorHandler, requireLocalhostWhenStandalone } from "./middleware/security.js";
import { initAuthSchema, bootstrapAdmin, currentUser, authRoutes, csrfProtection, requireAuth, requireRole, audit } from "./middleware/auth.js";
import { registerSafeTerminal } from "./routes/terminal.safe.js";
import { registerAdminSecurityRoutes } from "./routes/adminSecurity.js";
import { registerDefensiveTools } from "./routes/defensiveTools.js";
import { requireFeature } from "./services/entitlements.js";
```

Immediately after `await initDb(DATA_DIR);` add:

```ts
initAuthSchema();
await bootstrapAdmin();
```

Replace the old Helmet/CORS setup:

```ts
app.use(helmet(...));
app.use(cors({ origin: true, credentials: true }));
```

with:

```ts
app.use(requestId);
app.use(requireLocalhostWhenStandalone);
app.use(hardenedHelmet());
app.use(strictCors());
app.use(noStoreApi);
app.use(cookieParser());
```

After `app.use(express.urlencoded(...))`, add:

```ts
app.use(currentUser);
const loginLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false });
authRoutes(app, loginLimiter);
app.use(csrfProtection);
```

Protect all private API routes. Example:

```ts
app.get("/api/nodes", requireAuth, requireFeature("wireguard"), (req, res) => { ... });
app.post("/api/nodes", requireAuth, requireRole("admin", "operator"), requireFeature("wireguard"), mutateLimiter, (req, res) => { ... });
```

Replace the old `/api/terminal/execute` route with:

```ts
registerSafeTerminal(app, terminalLimiter);
```

Add admin/security routes before static frontend serving:

```ts
registerAdminSecurityRoutes(app);
registerDefensiveTools(app);
```

Add the error handler last:

```ts
app.use(jsonErrorHandler);
```

## 3. Encrypt private keys

Where the existing code creates `private_key`, use:

```ts
import { encryptSecret, decryptSecret, maskSecret } from "./services/secrets.js";
const encryptedPrivateKey = encryptSecret(priv);
```

Never return raw private keys from `/api/nodes`. Return `privateKey: maskSecret(nd.private_key)` unless the user explicitly exports a WireGuard config after re-authentication.

## 4. Mark demo/simulated routes

Any route that uses `Math.random()` for security-related output should return:

```ts
{ dataSource: "simulated", generatedAt: new Date().toISOString(), ...payload }
```

Production telemetry must come from real logs, agents, WireGuard status, DNS logs, firewall counters, or SIEM events.
