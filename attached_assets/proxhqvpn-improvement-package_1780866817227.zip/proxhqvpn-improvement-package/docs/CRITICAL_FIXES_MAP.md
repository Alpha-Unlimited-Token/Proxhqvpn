# Critical Fixes Map

| Finding | Code delivered | Where to wire |
|---|---|---|
| Standalone has no local auth | `middleware/auth.ts` | Mount before private API routes |
| Permissive CORS with credentials | `middleware/security.ts` | Replace old `cors({ origin: true })` |
| No CSRF protection | `csrfProtection` | Mount after `currentUser` and auth routes |
| Raw private keys in DB/API | `services/secrets.ts` | Encrypt on insert/update; mask on response |
| Browser terminal risk | `routes/terminal.safe.ts` | Replace old unrestricted route |
| No RBAC | `requireRole()` | Add per route |
| No feature gating | `services/entitlements.ts` | Add `requireFeature()` per route |
| Simulation mixed with production | `services/demoMode.ts` | Label or block demo-only routes |
| No security posture page | `routes/adminSecurity.ts` | Add to admin section |
| Non-technical UX too complex | `BeginnerDashboard.tsx`, `SecurityInbox.tsx` | Add `/simple` and `/security-inbox` routes |
