# Verification Checklist

Run these checks before shipping.

## Auth

- Start with no users and bootstrap env set.
- Confirm `/api/auth/login` works.
- Remove bootstrap password from env after first admin is created.
- Confirm `/api/nodes` returns 401 when logged out.
- Confirm mutation without `x-csrf-token` returns 403.

## CORS

- Request from an unlisted origin must fail.
- Request from listed `PROXHQVPN_ALLOWED_ORIGINS` must pass.

## Secrets

- Inspect SQLite/Postgres records and confirm private keys are encrypted.
- Confirm API responses mask private keys.

## Terminal

- With `PROXHQVPN_ENABLE_TERMINAL=false`, terminal route must return 403.
- With true, only named safe commands should run.
- Arbitrary shell strings must not execute.

## Demo separation

- Every simulated/random security metric must include `dataSource: simulated`.
- Production dashboard must show a visible Demo Mode badge when `PROXHQVPN_DEMO_MODE=true`.

## UX

- Beginner dashboard loads.
- Threat Inbox explains alerts in plain English.
- Advanced features show a safety gate.
