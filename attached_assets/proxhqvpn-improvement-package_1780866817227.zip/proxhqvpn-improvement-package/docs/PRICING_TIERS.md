# Recommended Pricing Tiers

## Tier A — VPN Only
- Individual: $7.99/mo or $79/yr
- Family: $12.99/mo or $129/yr, up to 6 users/devices policy
- Team: $6/user/mo, 5-user minimum
- Includes VPN, WireGuard, kill switch, leak tests, split tunnel, smart DNS, router configs.

## Tier B — Security Suite
- Individual: $19.99/mo or $199/yr
- Business: $15/user/mo, 5-user minimum
- Includes Tier A + Ghost Trap, SilkWeb, firewall, DNS sinkhole, SIEM, canaries, threat intel, Ghost Trace/Ghost Chain.

## Tier C — Developer / Pentest Pro
- Individual: $49.99/mo or $499/yr
- Team: $39/user/mo, 3-user minimum
- Includes Tier B + JWT analyzer, SAST, HTTP probe, directory fuzzer, subdomain scanner, SQL read-only, safe terminal, audit reports.

## Tier D — Enterprise
- Base: $999–$4,999/mo depending on deployment size
- Seats: $25–$75/user/mo depending on included modules
- Includes everything + ProxhqAV/YARA/IOC, endpoint agent, QuantumAudit where legally appropriate, dedicated deployment, support SLA, custom nodes.

## Standalone Self-Hosted
- Personal: $299 one-time + $99/yr updates
- Business: $1,499–$9,999/yr depending on seats and support
