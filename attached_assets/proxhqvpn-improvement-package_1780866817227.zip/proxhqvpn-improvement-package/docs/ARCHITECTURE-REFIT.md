# ProxhqVPN Architecture Refit

## Target architecture

1. `vpn-core-service`
   - WireGuard peers, device registry, node inventory, config generation, kill switch scripts, leak tests.

2. `security-service`
   - Ghost Trap, SilkWeb, DNS Sinkhole, SIEM, canaries, threat intel, firewall policy.

3. `devtools-service`
   - JWT analyzer, SAST, HTTP header checks, passive OSINT, CVE lookup, authorized-scope checks.

4. `endpoint-agent`
   - OS firewall application, real-time filesystem monitor, registry monitor, YARA scans, rootkit checks, secure shredder.
   - Must be signed and installed with explicit user consent.

5. `billing-entitlement-service`
   - Stripe webhooks, subscription status, team seats, feature gating.

6. `frontend`
   - Simple Mode for non-technical users.
   - Expert Mode for administrators and security researchers.

## Required boundaries

- Demo data must never appear as real telemetry.
- Local standalone must bind to localhost by default.
- Offensive payload generation must not ship in production.
- All mutation routes require auth + CSRF + audit log.
- All admin routes require RBAC.
- All private keys and tokens must be encrypted at rest.

## Database changes

Add tables:

```sql
CREATE TABLE local_users (...);
CREATE TABLE audit_log (...);
CREATE TABLE feature_entitlements (...);
CREATE TABLE secret_store (...);
CREATE TABLE telemetry_sources (...);
```

## Release gates

- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm audit --prod`
- VPN leak test pass on Windows/macOS/Linux
- No unauthenticated access to private APIs
- No raw private keys in API responses
- No permissive CORS in production
