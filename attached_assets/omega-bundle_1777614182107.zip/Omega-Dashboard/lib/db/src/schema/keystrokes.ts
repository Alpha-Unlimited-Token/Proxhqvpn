import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

export const keystrokesTable = pgTable("keystrokes", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull(),
  windowTitle: text("window_title").notNull().default("Unknown"),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Keystroke = typeof keystrokesTable.$inferSelect;
export type InsertKeystroke = typeof keystrokesTable.$inferInsert;
