import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

export const clipboardTable = pgTable("clipboard_entries", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull(),
  content: text("content").notNull().default(""),
  contentType: text("content_type").notNull().default("text"),
  capturedAt: timestamp("captured_at").defaultNow().notNull(),
});

export type ClipboardEntry = typeof clipboardTable.$inferSelect;
export type InsertClipboardEntry = typeof clipboardTable.$inferInsert;
