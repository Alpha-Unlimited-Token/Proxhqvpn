import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

export const remoteCommandsTable = pgTable("remote_commands", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull(),
  commandType: text("command_type").notNull(),
  params: text("params").notNull().default(""),
  status: text("status").notNull().default("sent"),
  result: text("result").notNull().default(""),
  executedAt: timestamp("executed_at").defaultNow().notNull(),
});

export type RemoteCommand = typeof remoteCommandsTable.$inferSelect;
export type InsertRemoteCommand = typeof remoteCommandsTable.$inferInsert;
