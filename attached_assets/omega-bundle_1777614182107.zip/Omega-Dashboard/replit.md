# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push-force` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Omega Dashboard

A modern web reimagining of the 2001 VB6 "Omega Controller" RAT (Ghost Productions), ported as a network monitoring and host management UI.

### Pages (15 total)

**SYSTEM group:**
- `/` — Overview (stats, pie chart, bar chart, activity stream)
- `/hosts` — Host list with status, latency, OS
- `/hosts/:id` — Host detail view
- `/events` — Filtered event log
- `/system-info` — OS, CPU, RAM, disk, uptime per host

**TOOLS group:**
- `/chat` — Chat messages per host
- `/keylogger` — Captured keystrokes per host
- `/screen-capture` — Screenshot gallery per host
- `/file-manager` — Simulated C:\\ / D:\\ drive browser per host
- `/processes` — Process list with CPU/mem, kill action
- `/windows` — Open windows manager, close action
- `/clipboard` — Read/write remote clipboard

**CONTROL group:**
- `/message-manager` — Compose & send popup message boxes (icon/button options)
- `/remote-commands` — 13 commands: open_url, find_files, flip_screen, set_resolution, screensaver, restart_windows, shutdown_windows, set_volume, set_time, set_date, win_colors, print_text, set_mouse_speed

**NETWORK group:**
- `/ip-scanner` — Scan IP range for open ports
- `/ip-tool` — Ping + DNS resolve/reverse lookup

### DB Tables (11)

`hosts`, `events`, `chat_messages`, `keystrokes`, `processes`, `screenshots`, `system_info`, `windows_list`, `clipboard_entries`, `sent_messages`, `remote_commands`

### Important Notes

- All tool pages NOT in OpenAPI spec — use plain `fetch` in frontend with `${BASE}/api/...`
- `serializeDates`/`serializeDateArray` helpers in `api-server/src/lib/serialize.ts` MUST wrap all rows with timestamp columns when returning through Zod `.parse()`
- After adding DB tables: update schema index → `push-force` → rebuild db package (`tsc -p tsconfig.json`)
- Demo data seeded via `scripts/seed-tools.mjs` and `scripts/seed-control.mjs`
- Design: dark terminal aesthetic, monospace fonts, primary green `#00ff41`
