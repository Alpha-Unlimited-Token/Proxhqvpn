import AdmZip from '/home/runner/workspace/node_modules/adm-zip/adm-zip.js';
import fs from 'fs';
import path from 'path';

const ROOT = '/home/runner/workspace';
const OUT  = `${ROOT}/omega-bundle.zip`;
const ORIG = `${ROOT}/attached_assets/Omega_1776480610850.zip`;

// Directories/files to skip in project source
const SKIP_DIRS = new Set([
  'node_modules', '.git', 'dist', '.next', 'build',
  'attached_assets', '.local', '.cache', '.pnpm-store',
]);
const SKIP_FILES = new Set([
  'omega-bundle.zip', 'pnpm-lock.yaml',
]);

function shouldSkip(relPath) {
  const parts = relPath.split('/');
  return parts.some(p => SKIP_DIRS.has(p)) ||
         SKIP_FILES.has(path.basename(relPath));
}

function walkDir(dir, baseDir, zip, zipPrefix) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full    = path.join(dir, entry.name);
    const rel     = path.relative(baseDir, full);
    if (shouldSkip(rel)) continue;

    if (entry.isDirectory()) {
      walkDir(full, baseDir, zip, zipPrefix);
    } else {
      const zipPath = path.join(zipPrefix, rel);
      zip.addLocalFile(full, path.dirname(zipPath), path.basename(zipPath));
    }
  }
}

// ── Build the output zip ──────────────────────────────────────
const zip = new AdmZip();

// 1. Add original VB6 source files under "Omega-Original-VB6/"
console.log('Adding original VB6 files...');
const origZip = new AdmZip(ORIG);
const entries = origZip.getEntries();
for (const entry of entries) {
  if (!entry.isDirectory) {
    const data = entry.getData();
    zip.addFile(`Omega-Original-VB6/${entry.entryName}`, data);
  }
}
console.log(`  → ${entries.filter(e => !e.isDirectory).length} files`);

// 2. Add project source under "Omega-Dashboard/"
console.log('Adding project source files...');
walkDir(ROOT, ROOT, zip, 'Omega-Dashboard');
console.log('  → done');

// 3. Write
if (fs.existsSync(OUT)) fs.unlinkSync(OUT);
zip.writeZip(OUT);
const size = (fs.statSync(OUT).size / 1024 / 1024).toFixed(2);
console.log(`\nCreated: omega-bundle.zip (${size} MB)`);
