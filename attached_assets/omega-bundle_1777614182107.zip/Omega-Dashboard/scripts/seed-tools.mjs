import pg from '/home/runner/workspace/lib/db/node_modules/pg/lib/index.js';

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const ago = (mins) => new Date(Date.now() - mins * 60 * 1000);

await pool.query(`DELETE FROM chat_messages`);
const chats = [
  [1, 'out', 'hey you there?', ago(120)],
  [1, 'in',  'yeah im here', ago(119)],
  [1, 'out', 'send me the system info', ago(118)],
  [1, 'in',  'Windows 11 Pro, 16GB RAM, Intel i7-12700K', ago(117)],
  [1, 'out', 'good. keep this session open', ago(116)],
  [1, 'in',  'ok', ago(115)],
  [2, 'out', 'status check', ago(60)],
  [2, 'in',  'all systems nominal', ago(59)],
  [2, 'out', 'run task manager and tell me cpu usage', ago(58)],
  [2, 'in',  'cpu at 12%, memory 58%, all normal', ago(57)],
  [2, 'out', 'any users logged in?', ago(55)],
  [2, 'in',  'administrator only', ago(54)],
];
for (const [h, d, m, t] of chats)
  await pool.query(`INSERT INTO chat_messages (host_id,direction,message,created_at) VALUES ($1,$2,$3,$4)`,[h,d,m,t]);

await pool.query(`DELETE FROM keystrokes`);
const strokes = [
  [1,'Chrome - Google Search','www.google.com\nsearch results for omega controller',ago(200)],
  [1,'Notepad','hello this is a test document\nnew line here\nsaving file to desktop',ago(195)],
  [1,'Chrome - Gmail','password: hunter2\nlogging into email now',ago(180)],
  [1,'cmd.exe','ipconfig /all\nnetstat -an\nping 8.8.8.8',ago(160)],
  [1,'File Explorer','C:\\Users\\John\\Documents\\private',ago(140)],
  [2,'Terminal - bash','ls -la /home\ncat /etc/shadow\nsudo su',ago(90)],
  [2,'Firefox - Login','username: admin\npassword: P@ssw0rd123',ago(85)],
  [2,'Terminal - bash','sudo apt-get update\nsudo apt-get upgrade -y\nreboot',ago(70)],
  [3,'Outlook','meeting at 3pm tomorrow re: budget\nplease keep confidential',ago(300)],
  [3,'Chrome','https://internal.corp.net/admin\nlogging into corp VPN',ago(290)],
  [4,'Word - report.docx','Q4 financial summary\nrevenue: $4.2M\ncosts: $2.8M',ago(400)],
  [5,'Terminal','ssh root@10.0.0.1\npassword: toor',ago(500)],
];
for (const [h,w,t,ts] of strokes)
  await pool.query(`INSERT INTO keystrokes (host_id,window_title,text,created_at) VALUES ($1,$2,$3,$4)`,[h,w,t,ts]);

await pool.query(`DELETE FROM processes`);
const defs = [
  ['System',4,0.1,1.2],['svchost.exe',892,0.3,12.4],['explorer.exe',1234,1.2,45.6],
  ['chrome.exe',2345,8.4,312.0],['chrome.exe',2346,3.1,180.0],['notepad.exe',3100,0.0,4.2],
  ['taskmgr.exe',4001,0.5,8.0],['winlogon.exe',512,0.0,6.1],['lsass.exe',624,0.1,18.3],
  ['RuntimeBroker.exe',1900,0.2,22.1],['SearchIndexer.exe',2800,1.4,64.5],
  ['OneDrive.exe',3300,0.3,55.0],['Discord.exe',5100,2.1,240.0],
  ['spoolsv.exe',1500,0.0,8.8],['audiodg.exe',1700,0.1,14.2],
];
for (let hostId=1; hostId<=6; hostId++) {
  for (const [name,basePid,cpu,mem] of defs) {
    const pid = basePid + hostId*10;
    const c = +(cpu + Math.random()*0.5).toFixed(1);
    const m = +(mem + Math.random()*20).toFixed(1);
    await pool.query(`INSERT INTO processes (host_id,pid,name,cpu_pct,mem_mb,status) VALUES ($1,$2,$3,$4,$5,'running')`,[hostId,pid,name,c,m]);
  }
}

await pool.query(`DELETE FROM screenshots`);
const labels = ['Desktop','Browser Window','File Explorer','Terminal Session','Email Client'];
for (let h=1; h<=4; h++) {
  for (let i=0; i<5; i++) {
    const ts = ago((i+1)*45 + Math.floor(Math.random()*30));
    const kb = Math.floor(Math.random()*600)+150;
    await pool.query(`INSERT INTO screenshots (host_id,label,width_px,height_px,size_kb,created_at) VALUES ($1,$2,1920,1080,$3,$4)`,[h,labels[i%labels.length],kb,ts]);
  }
}

await pool.end();
console.log('Seeded all tool tables');
