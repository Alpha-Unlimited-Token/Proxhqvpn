import pg from '/home/runner/workspace/lib/db/node_modules/pg/lib/index.js';

const { Client } = pg;
const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

async function run(sql, params = []) {
  return client.query(sql, params);
}

const HOST_IDS = [1, 2, 3, 4, 5, 6];

// ── System Info ──────────────────────────────────────────────
await run(`DELETE FROM system_info`);
const OS_PRESETS = [
  { os: "Windows XP Professional",     ver: "5.1.2600 SP3",  cpu: "Intel Pentium 4 2.40GHz",  ram: 1024 },
  { os: "Windows 98 SE",               ver: "4.10.2222",     cpu: "Intel Celeron 700MHz",      ram: 256  },
  { os: "Windows 2000 Professional",   ver: "5.0.2195 SP4",  cpu: "Intel Pentium III 800MHz",  ram: 512  },
  { os: "Windows XP Home Edition",     ver: "5.1.2600 SP1",  cpu: "AMD Athlon XP 1800+",       ram: 768  },
  { os: "Windows Me",                  ver: "4.90.3000",     cpu: "Intel Celeron 500MHz",       ram: 256  },
  { os: "Windows 2000 Server",         ver: "5.0.2195 SP2",  cpu: "Intel Pentium III 1GHz",    ram: 1024 },
];
const USERS     = ["Administrator", "JohnDoe", "Guest", "SYSTEM", "mary.jones", "server_admin"];
const COMPUTERS = ["ALPHA-PC", "DELTA-LAPTOP", "GAMMA-WORKSTATION", "OMEGA-SERVER", "EPSILON-HOME", "BETA-OFFICE"];
const RESOLS    = ["1024x768", "800x600", "1280x1024", "640x480", "1024x768", "1280x1024"];
const DISKS_GB  = [8, 20, 40, 80, 160, 120];

for (let i = 0; i < HOST_IDS.length; i++) {
  const p = OS_PRESETS[i];
  const ramUsed  = Math.floor(p.ram * (0.4 + Math.random() * 0.4));
  const diskUsed = parseFloat((DISKS_GB[i] * (0.3 + Math.random() * 0.5)).toFixed(1));
  const uptime   = Math.floor(3600 * (1 + Math.random() * 200));
  await run(
    `INSERT INTO system_info
       (host_id, os_name, os_version, cpu, ram_total_mb, ram_used_mb,
        username, computer_name, uptime_seconds, disk_total_gb, disk_used_gb, resolution)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
    [HOST_IDS[i], p.os, p.ver, p.cpu, p.ram, ramUsed,
     USERS[i], COMPUTERS[i], uptime, DISKS_GB[i], diskUsed, RESOLS[i]]
  );
}
console.log("✓ system_info seeded");

// ── Windows List ─────────────────────────────────────────────
await run(`DELETE FROM windows_list`);
const WIN_DATA = [
  [
    { t: "Microsoft Internet Explorer",            p: "iexplore.exe",  a: true  },
    { t: "C:\\Documents and Settings\\JohnDoe",   p: "explorer.exe",  a: false },
    { t: "Notepad - readme.txt",                   p: "notepad.exe",   a: false },
    { t: "Task Manager",                           p: "taskmgr.exe",   a: false },
    { t: "WinAmp 2.91",                            p: "winamp.exe",    a: false },
  ],
  [
    { t: "Counter-Strike",                         p: "hl.exe",        a: true  },
    { t: "mIRC - #omega",                          p: "mirc.exe",      a: false },
    { t: "C:\\",                                   p: "explorer.exe",  a: false },
  ],
  [
    { t: "Outlook Express",                        p: "msimn.exe",     a: true  },
    { t: "Microsoft Word - document1.doc",         p: "winword.exe",   a: false },
    { t: "Calculator",                             p: "calc.exe",      a: false },
    { t: "Run",                                    p: "explorer.exe",  a: false },
  ],
  [
    { t: "cmd.exe - C:\\WINDOWS\\system32",        p: "cmd.exe",       a: true  },
    { t: "Services",                               p: "services.msc",  a: false },
    { t: "Task Scheduler",                         p: "mstask.exe",    a: false },
  ],
  [
    { t: "Windows Media Player",                   p: "wmplayer.exe",  a: true  },
    { t: "My Computer",                            p: "explorer.exe",  a: false },
    { t: "Solitaire",                              p: "sol.exe",       a: false },
    { t: "Paint",                                  p: "mspaint.exe",   a: false },
  ],
  [
    { t: "IIS Manager",                            p: "inetmgr.exe",   a: true  },
    { t: "Event Viewer",                           p: "eventvwr.exe",  a: false },
    { t: "Server Manager",                         p: "compmgmt.msc",  a: false },
    { t: "Telnet - 192.168.1.200",                 p: "telnet.exe",    a: false },
  ],
];

for (let i = 0; i < HOST_IDS.length; i++) {
  for (const w of WIN_DATA[i]) {
    const handle = `0x${Math.floor(Math.random() * 0xFFFF).toString(16).toUpperCase().padStart(4, "0")}`;
    await run(
      `INSERT INTO windows_list (host_id, window_handle, title, process_name, is_active)
       VALUES ($1, $2, $3, $4, $5)`,
      [HOST_IDS[i], handle, w.t, w.p, w.a]
    );
  }
}
console.log("✓ windows_list seeded");

// ── Clipboard ─────────────────────────────────────────────────
await run(`DELETE FROM clipboard_entries`);
const CLIPS = [
  "192.168.1.1",
  "password123",
  "C:\\Documents and Settings\\JohnDoe\\My Documents\\secret.txt",
  "http://www.example.com/login?user=admin&pass=1234",
  "Dear John,\nPlease find attached the Q4 financial report.\nBest regards,\nMary",
  "1234-5678-9012-3456",
];
for (let i = 0; i < HOST_IDS.length; i++) {
  for (let j = 0; j < 3; j++) {
    const ts = new Date(Date.now() - (j * 3600 + Math.random() * 3600) * 1000);
    await run(
      `INSERT INTO clipboard_entries (host_id, content, content_type, captured_at)
       VALUES ($1, $2, 'text', $3)`,
      [HOST_IDS[i], CLIPS[(i + j) % CLIPS.length], ts]
    );
  }
}
console.log("✓ clipboard_entries seeded");

// ── Sent Messages ─────────────────────────────────────────────
await run(`DELETE FROM sent_messages`);
const MSGS = [
  { title: "Alert",    body: "Your system has been compromised!",      icon: "error",    btn: "ok"           },
  { title: "Notice",   body: "System maintenance scheduled tonight.",   icon: "info",     btn: "ok-cancel"    },
  { title: "Warning",  body: "Unauthorized access detected.",           icon: "warn",     btn: "ok"           },
  { title: "Question", body: "Do you want to restart now?",             icon: "question", btn: "yes-no"       },
  { title: "Error",    body: "Connection to server lost.",              icon: "error",    btn: "retry-cancel" },
  { title: "Info",     body: "Software update available.",              icon: "info",     btn: "ok"           },
];
for (let i = 0; i < HOST_IDS.length; i++) {
  const m = MSGS[i];
  const ts = new Date(Date.now() - Math.random() * 86400000);
  await run(
    `INSERT INTO sent_messages (host_id, title, body, icon_type, button_type, status, sent_at)
     VALUES ($1,$2,$3,$4,$5,'sent',$6)`,
    [HOST_IDS[i], m.title, m.body, m.icon, m.btn, ts]
  );
}
console.log("✓ sent_messages seeded");

// ── Remote Commands ───────────────────────────────────────────
await run(`DELETE FROM remote_commands`);
const CMDS = [
  { t: "open_url",      p: "http://www.google.com", r: "URL opened in browser"  },
  { t: "flip_screen",   p: "",                      r: "Screen flipped"          },
  { t: "set_volume",    p: "75",                    r: "Volume adjusted"         },
  { t: "screensaver",   p: "",                      r: "Screen saver activated"  },
  { t: "find_files",    p: "*.doc",                 r: "File search initiated"   },
  { t: "set_resolution",p: "800x600",               r: "Resolution changed"      },
];
for (let i = 0; i < HOST_IDS.length; i++) {
  for (let j = 0; j < 2; j++) {
    const s = CMDS[(i + j) % CMDS.length];
    const ts = new Date(Date.now() - (j * 1800 + Math.random() * 3600) * 1000);
    await run(
      `INSERT INTO remote_commands (host_id, command_type, params, status, result, executed_at)
       VALUES ($1,$2,$3,'executed',$4,$5)`,
      [HOST_IDS[i], s.t, s.p, s.r, ts]
    );
  }
}
console.log("✓ remote_commands seeded");

await client.end();
console.log("\nAll control tables seeded successfully.");
