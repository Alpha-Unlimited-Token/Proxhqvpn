#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
command -v node &>/dev/null || { echo "ERROR: Node.js not found. Install from https://nodejs.org (v20+)"; exit 1; }
MAJOR=$(node -e "process.stdout.write(process.versions.node.split('.')[0])")
[ "$MAJOR" -lt 20 ] && { echo "ERROR: Node.js 20+ required"; exit 1; }
[ ! -d node_modules ] && { echo "Installing dependencies..."; npm install --production --omit=dev; }
echo "ProxhqVPN starting at http://localhost:7474"
(sleep 2 && { command -v xdg-open && xdg-open http://localhost:7474 || command -v open && open http://localhost:7474 || true; }) &>/dev/null &
node server.bundle.cjs
