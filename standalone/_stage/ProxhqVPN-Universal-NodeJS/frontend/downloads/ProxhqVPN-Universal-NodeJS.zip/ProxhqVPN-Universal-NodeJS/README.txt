╔══════════════════════════════════════════════════════════════════╗
║               PROXHQVPN — STANDALONE EDITION              ║
║                  Version 2.0.0 — For Personal Use            ║
╚══════════════════════════════════════════════════════════════════╝

Platform: Universal — Any OS (Windows / macOS / Linux)

  NOTE: Requires Node.js 20+ from https://nodejs.org

QUICK START
───────────
  ./start.sh  (Linux/macOS)  or  start.bat  (Windows)

  Then open your browser to: http://localhost:7474

WHAT IS PROXHQVPN?
──────────────────
ProxhqVPN is an advanced VPN orchestration and security platform featuring:
  • 60-node architecture (50 outer + 10 inner nodes)
  • Beacon / Spider / Worm agents on every node
  • Silk Web trap network for attacker detection & fingerprinting
  • Built-in stateful firewall with ISP & localhost masking
  • WireGuard configuration generator for all nodes
  • Continuous IP rotation (instant or scheduled every 3s)
  • SOCKS5 / Tor / Multi-OS proxy compatibility
  • GhostNet Onion Browser with double-layer protection
  • SQL interface (SELECT queries against all VPN tables)
  • Live system monitor (CPU, memory, network, connections)
  • Sandboxed terminal (read-only safe command set)
  • Port knocking, mTLS, and multi-hop routing

DATA STORAGE
────────────
All configuration and node data is stored in the "data/" folder
inside the same directory as this package.
  • Backup "data/ghostnet.db" to preserve your configuration.
  • Delete it to reset to defaults (60 nodes will be re-seeded).

CUSTOM PORT
────────────
  PORT=8080 ./start.sh

CUSTOM DATA DIRECTORY
──────────────────────
  GHOSTNET_DATA=/path/to/data ./start.sh

SECURITY NOTES
──────────────
  • This is a LOCAL management interface — do NOT expose port 7474
    to the internet without adding authentication middleware.
  • The terminal command set is restricted to safe read-only cmds.
  • All SQL queries are SELECT-only (no data modification).
  • Rate limiting is active: 500 req/min global, 30/min terminal.

API REFERENCE
────────────
  GET  /api/healthz                  — Health check
  GET  /api/nodes                    — List all nodes
  POST /api/nodes/shuffle-all        — Rotate all IPs instantly
  GET  /api/beacons                  — Beacon alerts
  GET  /api/silkweb                  — Silk web trap status
  GET  /api/firewall/rules           — Firewall rules
  GET  /api/monitor/stats            — System stats
  POST /api/terminal/execute         — Run allowed commands

LICENSE
───────
  For personal use only. All rights reserved.
  © 2026 Alpha Unlimited Technologies LLC

─────────────────────────────────────────────────────────────────
