@echo off
title ProxhqVPN (Universal)
where node >nul 2>&1 || (echo ERROR: Node.js not found. Install from https://nodejs.org & pause & exit /b 1)
if not exist node_modules\ (echo Installing dependencies... & npm install --production --omit=dev)
echo ProxhqVPN starting at http://localhost:7474
start "" "http://localhost:7474"
node server.bundle.cjs
pause
