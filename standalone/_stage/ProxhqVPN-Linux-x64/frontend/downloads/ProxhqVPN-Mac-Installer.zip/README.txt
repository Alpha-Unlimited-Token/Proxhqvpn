ProxhqVPN macOS Installer
===========================
by ALPHA UNLIMITED TECHNOLOGIES LLC

HOW TO INSTALL:
  1. Double-click "ProxhqVPN-Mac-Installer.app"

  If macOS says "can't be opened because it's from an unidentified developer":
  → Go to: Apple Menu  →  System Settings  →  Privacy & Security
  → Scroll down to Security section
  → Click "Open Anyway" next to ProxhqVPN

  OR: Right-click (Control+click) the app → Open → Open

WHY THIS HAPPENS:
  macOS Gatekeeper warns about apps downloaded from the internet that are not
  from the Mac App Store or Apple-notarized developers. This is a one-time
  step — after you allow it once, it opens normally forever.

WHAT THE WIZARD DOES:
  1. Welcome screen
  2. License agreement
  3. Choose install location (All Users or Just Me)
  4. Installs WireGuard (required for VPN tunnel)
  5. Installs ProxhqVPN to your Applications folder
  6. Launch ProxhqVPN

SUPPORT: proxhqvpn.com
